import 'package:daeguro_admin_ext/ISWidget/is_button.dart';
import 'package:daeguro_admin_ext/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_ext/Model/shop/shop_history.dart';
import 'package:daeguro_admin_ext/Util/select_option_vo.dart';
import 'package:daeguro_admin_ext/View/ShopManager/Account/shopAccount_controller.dart';
import 'package:flutter/material.dart';

class ShopBasicInfoHistory extends StatefulWidget {
  final String selectBox_shopCd;
  const ShopBasicInfoHistory({Key key, this.selectBox_shopCd}) : super(key: key);

  @override
  State<ShopBasicInfoHistory> createState() => _ShopBasicInfoHistoryState();
}

class _ShopBasicInfoHistoryState extends State<ShopBasicInfoHistory> {
  final List<ShopHistoryModel> dataHistoryList = <ShopHistoryModel>[];
  ScrollController _scrollController;

  @override
  void initState(){
    super.initState();
    _scrollController = ScrollController();
    loadData();
  }


  loadData() async{
    dataHistoryList.clear();

    await ShopController.to.getHistoryData(widget.selectBox_shopCd, '1', '10000').then((value) {
      if (value == null) {
        ISAlert(context, '변경이력이 정상조회 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else{
        value.forEach((element) {
          ShopHistoryModel tempData = ShopHistoryModel.fromJson(element);
          dataHistoryList.add(tempData);
        });
      }
    });

    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {
    var result = Scaffold(
      appBar: AppBar(
        title: Text('가맹점 기본정보 변경 이력'),
      ),
      body: getHistoryTabView(),
      bottomNavigationBar: buttonBar(),
    );

    return SizedBox(
      width: 500,
      height: 650,
      child: result,
    );

  }
  /// 03.08 - kjr
  /// 상단 appBar. 닫기버튼
  /// return ButtonBar
  ButtonBar buttonBar(){
    return ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '닫기',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );
  }

  /// 변경내역 내부
  Widget getHistoryTabView() {
    return ListView.builder(
      controller: _scrollController,
      padding: EdgeInsets.only(left: 20, right: 20, bottom: 20, top: 20),
      itemCount: dataHistoryList.length,
      itemBuilder: (BuildContext context, int index) {
        return dataHistoryList != null
            ? GestureDetector(
          // onTap: (){
          //   Navigator.pushNamed(context, '/editor', arguments: UserController.to.userData[index]);
          // },
          child: Card(
            color: Colors.white,
            elevation: 2.0,
            child: ListTile(
              //leading: Text(dataList[index].siguName),
              title: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  //Text('No.' + dataHistoryList[index].NO.toString() ?? '--', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  Container(
                      padding: EdgeInsets.only(top: 5),
                      child: SelectableText(
                        dataHistoryList[index].memo ?? '--',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 13),
                        showCursor: true,
                      )),
                ],
              ),
              subtitle: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      alignment: Alignment.centerRight,
                      child: Text(
                          dataHistoryList[index]
                              .insertDate
                              .replaceAll('T', ' ') ??
                              '--',
                          style: TextStyle(fontSize: 12),
                          textAlign: TextAlign.right))
                ],
              ),
            ),
          ),
        )
            : Text('Data is Empty');
      },
    );
  }
}
