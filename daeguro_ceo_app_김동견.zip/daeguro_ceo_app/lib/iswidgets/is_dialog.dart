
import 'package:flutter/material.dart';

const kDefaultContentDialogConstraints = BoxConstraints(maxWidth: 368.0,  maxHeight: 756.0);

class ContentDialog extends StatelessWidget {
  /// Creates a content dialog.
  const ContentDialog({
    Key? key,
    this.title,
    this.content,
    this.actions,
    //this.style,
    this.contentPadding,
    this.constraints = kDefaultContentDialogConstraints,
    this.isFillActions = false,
    this.isPopupNotice = false
  }) : super(key: key);

  final Widget? title;
  final Widget? content;
  final List<Widget>? actions;
  final BoxConstraints? constraints;
  final EdgeInsetsGeometry? contentPadding;
  final bool isFillActions;
  final bool isPopupNotice;


  @override
  Widget build(BuildContext context) {

    //final style = ContentDialogThemeData.standard(FluentTheme.of(context,)).merge(FluentTheme.of(context).dialogTheme.merge(this.style),);
    final style = ContentDialogThemeData.standard(Theme.of(context,));

    return Align(
      alignment: AlignmentDirectional.center,
      child: Container(
        constraints: constraints,
        //decoration: style.decoration,
        decoration: BoxDecoration(
          color: isPopupNotice == true ? Colors.transparent : Colors.white,//const Color(0xff333333)
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Flexible(
              child: Padding(
                padding: title != null ? style.padding! : EdgeInsets.zero,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (title != null)...[
                      Padding(
                        padding: style.titlePadding ?? EdgeInsets.zero,
                        child: DefaultTextStyle(
                          style: style.titleStyle ?? const TextStyle(),
                          child: title!,
                        ),
                      ),
                      const Divider(color: Colors.grey, height: 0.0,),
                    ],
                    if (content != null)
                      Flexible(
                        child: Padding(
                          padding: contentPadding ?? const EdgeInsets.all(0.0),//style.bodyPadding ?? EdgeInsets.zero,
                          child: DefaultTextStyle(
                            style: style.bodyStyle ?? const TextStyle(),
                            child: content!,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            if (actions != null)
              Container(
                decoration: style.actionsDecoration,
                padding: isFillActions ? const EdgeInsets.all(0.0) : style.actionsPadding,
                child: ButtonTheme.fromButtonThemeData(
                  data: const ButtonThemeData(),
                  child: () {
                    if (actions!.length == 1) {
                      return Align(alignment: AlignmentDirectional.centerEnd, child: actions!.first,);
                    }
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: actions!.map((e) {
                        final index = actions!.indexOf(e);
                        return Expanded(
                          child: Padding(
                            padding: isFillActions ? const EdgeInsetsDirectional.only(end: 0.0) : EdgeInsetsDirectional.only(end: index != (actions!.length - 1) ? style.actionsSpacing ?? 3 : 0,),
                            child: e,
                          ),
                        );
                      }).toList(),
                    );
                  }(),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

@immutable
class ContentDialogThemeData {
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? titlePadding;
  final EdgeInsetsGeometry? bodyPadding;

  //final Decoration? decoration;
  final Color? barrierColor;

  //final ButtonThemeData? actionThemeData;
  final double? actionsSpacing;
  final Decoration? actionsDecoration;
  final EdgeInsetsGeometry? actionsPadding;

  final TextStyle? titleStyle;
  final TextStyle? bodyStyle;

  const ContentDialogThemeData({
    //this.decoration,
    this.barrierColor,
    this.titlePadding,
    this.bodyPadding,
    this.padding,
    this.actionsSpacing,
    //this.actionThemeData,
    this.actionsDecoration,
    this.actionsPadding,
    this.titleStyle,
    this.bodyStyle,
  });

  factory ContentDialogThemeData.standard(ThemeData theme) {
    return ContentDialogThemeData(
      // decoration: BoxDecoration(
      //   color: const Color(0xff333333),//Colors.white,//const Color(0xFFf9f9f9),
      //   borderRadius: BorderRadius.circular(12),
      //   //boxShadow: kElevationToShadow[6],
      // ),
      padding: const EdgeInsets.only(top: 20),//const EdgeInsets.all(20),
      titlePadding: const EdgeInsets.only(left: 20, right: 20, bottom: 12),//const EdgeInsetsDirectional.only(bottom: 12),
      actionsSpacing: 10,
      actionsDecoration: const BoxDecoration(
        color: Color(0xFFf9f9f9),//Color(0xFFf3f3f3),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(12)),
        // boxShadow: kElevationToShadow[1],
      ),

      actionsPadding: const EdgeInsets.all(20),
      barrierColor: Colors.grey[200]!.withOpacity(0.8),
      titleStyle: const TextStyle(fontSize: 28, color: Color(0xE4000000), fontWeight: FontWeight.w600),
      bodyStyle: const TextStyle(fontSize: 14, color: Color(0xE4000000), fontWeight: FontWeight.normal,),
    );
  }

  // static ContentDialogThemeData lerp(
  //     ContentDialogThemeData? a,
  //     ContentDialogThemeData? b,
  //     double t,
  //     ) {
  //   return ContentDialogThemeData(
  //     decoration: Decoration.lerp(a?.decoration, b?.decoration, t),
  //     barrierColor: Color.lerp(a?.barrierColor, b?.barrierColor, t),
  //     padding: EdgeInsetsGeometry.lerp(a?.padding, b?.padding, t),
  //     bodyPadding: EdgeInsetsGeometry.lerp(a?.bodyPadding, b?.bodyPadding, t),
  //     titlePadding:
  //     EdgeInsetsGeometry.lerp(a?.titlePadding, b?.titlePadding, t),
  //     actionsSpacing: lerpDouble(a?.actionsSpacing, b?.actionsSpacing, t),
  //     actionThemeData:
  //     ButtonThemeData.lerp(a?.actionThemeData, b?.actionThemeData, t),
  //     actionsDecoration:
  //     Decoration.lerp(a?.actionsDecoration, b?.actionsDecoration, t),
  //     actionsPadding:
  //     EdgeInsetsGeometry.lerp(a?.actionsPadding, b?.actionsPadding, t),
  //     titleStyle: TextStyle.lerp(a?.titleStyle, b?.titleStyle, t),
  //     bodyStyle: TextStyle.lerp(a?.bodyStyle, b?.bodyStyle, t),
  //   );
  // }

  // ContentDialogThemeData merge(ContentDialogThemeData? style) {
  //   if (style == null) return this;
  //   return ContentDialogThemeData(
  //     decoration: style.decoration ?? decoration,
  //     barrierColor: style.barrierColor ?? barrierColor,
  //     padding: style.padding ?? padding,
  //     bodyPadding: style.bodyPadding ?? bodyPadding,
  //     titlePadding: style.titlePadding ?? titlePadding,
  //     actionsSpacing: style.actionsSpacing ?? actionsSpacing,
  //     actionThemeData: style.actionThemeData ?? actionThemeData,
  //     actionsDecoration: style.actionsDecoration ?? actionsDecoration,
  //     actionsPadding: style.actionsPadding ?? actionsPadding,
  //     titleStyle: style.titleStyle ?? titleStyle,
  //     bodyStyle: style.bodyStyle ?? bodyStyle,
  //   );
  // }
}

