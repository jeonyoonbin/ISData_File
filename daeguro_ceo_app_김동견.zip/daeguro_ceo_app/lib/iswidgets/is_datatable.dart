﻿import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:flutter/material.dart';

class ISDatatable extends StatelessWidget {


  final double? listWidth;
  final double? listHeight;
  final double? minWidth;
  //double? minHeight;
  //double? topPadding;
  final VoidCallback? onPressed;
  final List<DataColumn> columns;
  final List<DataRow> rows;
  final double? headingRowHeight;
  final double? dataRowHeight;
  final bool? showCheckboxColumn;
  final ScrollController? controller;

  ISDatatable({
    Key? key,
    this.listWidth,
    this.listHeight,
    this.minWidth,
    //this.minHeight,
    //this.topPadding,
    this.onPressed,
    required this.rows,
    required this.columns,
    this.headingRowHeight,
    this.dataRowHeight,
    this.showCheckboxColumn,
    this.controller}) : super(key: key) ;

  @override
  Widget build(BuildContext context) {
    final ScrollController _controller = ScrollController();

    return Card(
      margin: const EdgeInsets.all(0.0),
      clipBehavior: Clip.antiAlias,
      shape: const RoundedRectangleBorder(
        //borderRadius: BorderRadius.all(Radius.circular(4)),
        side: BorderSide(color: Color(0xffDCDCDC),),
      ),
      elevation: 0,
      shadowColor: const Color(0xffCCCCCC),
      child: Scrollbar(
        controller: _controller,
        child: SizedBox(
          height: listHeight,
          child: ListView(
            controller: _controller,
            physics: const ClampingScrollPhysics(),
            // shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(0, 0, 0, 0), //(20, 0, 20, 20),
            children: <Widget>[
              Container(
                width: listWidth,//listWidth == null ? MediaQuery.of(context).size.width - 40 : (listWidth! - 40), //MediaQuery.of(context).size.width,
                constraints: BoxConstraints(minWidth: minWidth ?? 1140),
                child: ListView(
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    children: <Widget>[
                      DataTable(
                        horizontalMargin: 8,
                        checkboxHorizontalMargin: 10,
                        headingRowColor: MaterialStateProperty.all(Colors.grey[100],),//MaterialStateColor.resolveWith((states) => const Color(0xffF9F9F9)),
                        headingTextStyle: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54),
                        headingRowHeight: headingRowHeight ?? 50,
                        dataRowHeight: dataRowHeight ?? 50.0,
                        dataTextStyle: const TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black, fontSize: 13),
                        columnSpacing: 0,
                        showCheckboxColumn: showCheckboxColumn ?? false,
                        rows: rows,
                        columns: columns,
                      ),
                    ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
