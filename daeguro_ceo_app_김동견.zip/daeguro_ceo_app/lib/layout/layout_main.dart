import 'dart:js_util';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/LogInManager/loginController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopStatusEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:date_format/date_format.dart';
import 'package:get/get.dart';
import 'package:get/instance_manager.dart';
import 'package:get_storage/get_storage.dart';
import 'package:go_router/go_router.dart';
import 'package:fluent_ui/fluent_ui.dart';
import 'package:flutter/material.dart' as material;
import 'package:encrypt/encrypt.dart' as EncryptPack;
import 'package:crypto/crypto.dart' as CryptoPack;
import 'package:provider/provider.dart';
import 'dart:convert';

import 'package:url_launcher/url_launcher.dart';
class LayoutMain extends StatefulWidget {
  const LayoutMain({Key? key, required this.child, required this.shellContext, required this.state,}) : super(key: key);

  final Widget child;
  final BuildContext? shellContext;
  final GoRouterState state;

  @override
  State<LayoutMain> createState() => _LayoutMainState();
}

class _LayoutMainState extends State<LayoutMain> {
  bool value = false;

  final viewKey = GlobalKey(debugLabel: 'Navigation View Key');
  final searchKey = GlobalKey(debugLabel: 'Search Bar Key');
  final searchFocusNode = FocusNode();
  final menuFocusNode = FocusNode();
  final searchController = TextEditingController();

  List<NavigationPaneItem>? baseNaviItem;

  String? selMultiShop= '';
  List<ISOptionModel> selectMultiShopList = [];

  requestAPIData() async {
    selectMultiShopList.clear();

    await ShopController.to.getMultiShopListData(AuthService.MultiShopCd).then((value) {
      if (value == null) {
        ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      }
      else {
        value.forEach((element) {
          if(AuthService.SHOPCD == element['shopCd'].toString()) {
            selMultiShop = element['shopCd'].toString();
          }

          selectMultiShopList.add(ISOptionModel(value: element['shopCd'].toString(), label: '${element['shopName'].toString().trim()} / ${element['shopCd'].toString()}', id: element['shopId'].toString(), pass: element['shopPass'].toString()));
        });
      }
    });
    setState(() {});
  }

  Future<String> _requestMoveAPIData(String mvShopCd) async {
    String rtn = '99';
    await ShopController.to.getMultiShopCheck(mvShopCd).then((value) {
      if (value == null) {
        ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
        rtn = '99';
      }
      else {
        if(value == '00') {
          rtn = '00';
        } else {
          ISAlert(context, content: '연결 멀티샵 검증에 실패 했습니다. \n\n다시 시도해 주세요.');
          rtn ='99';
        }
      }
    });

    return rtn;
  }

  late List<NavigationPaneItem> deliveryItems = [
    PaneItem(
      key: const Key('/'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_daeguro.png'))),//const Icon(FluentIcons.home),
      title: const Text('우리 매장 현황', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
        if (router.location != '/') {
          router.go('/');
        }
      },
    ),
    //PaneItemSeparator(),
    PaneItem(
      key: const Key('/shop/kindInfo'),
      icon: const Padding(
        padding: EdgeInsets.only(right: 6),
        child: SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_crown_left_24_dp.png'))),
      ),//const Icon(FluentIcons.home),
      title: const Text('착한 매장', style: naviItemTextStyle),
      trailing: const Padding(
          padding: EdgeInsets.only(right: 58),
          child: SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_crown_right_24_dp.png'))),
      ),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
        if (router.location != '/shop/kindInfo') {
          router.go('/shop/kindInfo');
        }
      },
    ),
    //PaneItemSeparator(),
    if (AuthService.MultiShopYn == 'Y' && AuthService.RepYn == 'Y')
      PaneItem(
        key: const Key('/multiShopDashboard/info'),
        icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_new.png'))),//const Icon(FluentIcons.home),
        title: const Text('전체 매장 현황', style: naviItemTextStyle),
        body: const SizedBox.shrink(),
        isChild: true,
        onTap: () {

          //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
          if (router.location != '/multiShopDashboard/info') {
            router.go('/multiShopDashboard/info');
          }
        },
      ),
    PaneItemSeparator(),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
          child: Text('이벤트/할인 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/liveEvent/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_event_hall.png'))),//const Icon(FluentIcons.special_event),
      title: const Text('라이브 이벤트', style: naviItemTextStyle,),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/liveEvent/info') {
          router.go('/liveEvent/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/sale/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_shop_coupon_enable.png'))),//const Icon(material.Icons.payments),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('우리 가게 쿠폰', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/sale/info') {
          router.go('/sale/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/sale/packDiscount'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_discount_sticker_32.png'))),//const Icon(material.Icons.payments),//const SizedBox(width: 0,),//const Icon(FluentIcons.bulleted_tree_list, color: Colors.white),
      title: const Text('포장 할인', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/sale/packDiscount') {
          router.go('/sale/packDiscount');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
          child: Text('매장 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_project_reserve_on.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/info') {
          router.go('/shop/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/order/deliTip'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_project_delivery_on.png'))),//const Icon(material.Icons.receipt),//const SizedBox(width: 0,),//const Icon(FluentIcons.table_header_row, color: Colors.white),
      title: const Text('배달 지역 및 배달팁', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/order/deliTip') {
          router.go('/order/deliTip');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/notifyInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/reserve_shop_notice_23.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장·리뷰 알림', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/notifyInfo') {
          router.go('/shop/notifyInfo');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('메뉴 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/menu/menuInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_korean_food.png'))),
      title: const Text('메뉴 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/menu/menuInfo') {
          router.go('/menu/menuInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/menu/soldOutInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_out_of_stock.png'))),
      title: const Text('품절 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/menu/soldOutInfo') {
          router.go('/menu/soldOutInfo');
          //router.pop();
        }
        // if (router.location != (ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo')) {
        //   router.go(ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo');
        //   //router.pop();
        // }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('주문/매출 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/order/orderInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_card_list.png'))),//const Icon(material.Icons.receipt),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('주문 정보', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/order/orderInfo') {
          router.go('/order/orderInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/account/info'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_pay_type_account_sel_32.png'))),//const Icon(material.Icons.calculate),//const SizedBox(width: 0,),//const Icon(FluentIcons.text_field),
      title: const Text('매출 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/account/info') {
          router.go('/account/info', extra: 0);
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('리뷰 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      key: const Key('/review/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_review.png'))),//const Icon(material.Icons.rate_review),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('리뷰 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/review/info') {
          router.go('/review/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      key: const Key('/request/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_alert_notice.png'))),//const Icon(material.Icons.info),
      title: const Text('변경 요청 내역', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //print('[변경]router.location:${router.location}');
        if (router.location != '/request/info') {
          router.go('/request/info');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('이용 가이드', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/noticeInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_board.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('공지사항', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/noticeInfo') {
          router.go('/guide/noticeInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/faqInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/taxi_alert_safe_message.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('FAQ', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/faqInfo') {
          router.go('/guide/faqInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/userGuide'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_help.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('이용자 가이드', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/userGuide') {
          router.go('/guide/userGuide');
          //router.pop();
        }
      },
    ),
  ];

  late List<NavigationPaneItem> flowerItems = [
    PaneItem(
      key: const Key('/'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_daeguro.png'))),
      title: const Text('우리 매장 현황', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
        if (router.location != '/') {
          router.go('/');
        }
      },
    ),
    PaneItem(
      key: const Key('/shop/kindInfo'),
      icon: const Padding(
        padding: EdgeInsets.only(right: 6),
        child: SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_crown_left_24_dp.png'))),
      ),//const Icon(FluentIcons.home),
      title: const Text('착한 매장', style: naviItemTextStyle),
      trailing: const Padding(
        padding: EdgeInsets.only(right: 58),
        child: SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_crown_right_24_dp.png'))),
      ),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
        if (router.location != '/shop/kindInfo') {
          router.go('/shop/kindInfo');
        }
      },
    ),
    //PaneItemSeparator(),
    if (AuthService.MultiShopYn == 'Y' && AuthService.RepYn == 'Y')
      PaneItem(
        key: const Key('/multiShopDashboard'),
        icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_new.png'))),//const Icon(FluentIcons.home),
        title: const Text('전체 매장 현황', style: naviItemTextStyle),
        body: const SizedBox.shrink(),
        isChild: true,
        onTap: () {
          //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
          if (router.location != '/multiShopDashboard') {
            router.go('/multiShopDashboard');
          }
        },
      ),
    PaneItemSeparator(),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
          child: Text('이벤트/할인 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/sale/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_shop_coupon_enable.png'))),//const Icon(material.Icons.payments),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('우리 가게 쿠폰', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/sale/info') {
          router.go('/sale/info');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
          child: Text('매장 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_project_reserve_on.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/info') {
          router.go('/shop/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/notifyInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/reserve_shop_notice_23.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장·리뷰 알림', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/notifyInfo') {
          router.go('/shop/notifyInfo');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('상품 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/menu/productInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_flower.png'))),
      title: const Text('상품 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/menu/productInfo') {
          router.go('/menu/productInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/menu/soldOutInfo'),//Key(ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_out_of_stock.png'))),//const Icon(material.Icons.room_service),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('품절 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/menu/soldOutInfo') {
          router.go('/menu/soldOutInfo');
          //router.pop();
        }
        // if (router.location != (ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo')) {
        //   router.go(ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo');
        //   //router.pop();
        // }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('주문/매출 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/order/orderInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_card_list.png'))),//const Icon(material.Icons.receipt),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('주문 정보', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/order/orderInfo') {
          router.go('/order/orderInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/account/info'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_pay_type_account_sel_32.png'))),//const Icon(material.Icons.calculate),//const SizedBox(width: 0,),//const Icon(FluentIcons.text_field),
      title: const Text('매출 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/account/info') {
          router.go('/account/info', extra: 0);
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('리뷰 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      key: const Key('/review/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_review.png'))),//const Icon(material.Icons.rate_review),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('리뷰 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/review/info') {
          router.go('/review/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      key: const Key('/request/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_alert_notice.png'))),//const Icon(material.Icons.info),
      title: const Text('변경 요청 내역', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //print('[변경]router.location:${router.location}');
        if (router.location != '/request/info') {
          router.go('/request/info');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('이용 가이드', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/noticeInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_board.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('공지사항', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/noticeInfo') {
          router.go('/guide/noticeInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/faqInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/taxi_alert_safe_message.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('FAQ', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/faqInfo') {
          router.go('/guide/faqInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/userGuide'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_help.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('이용자 가이드', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/userGuide') {
          router.go('/guide/userGuide');
          //router.pop();
        }
      },
    ),
  ];

  late List<NavigationPaneItem> electmarketItems = [
    PaneItem(
      key: const Key('/'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_daeguro.png'))),//const Icon(FluentIcons.home),
      title: const Text('우리 매장 현황', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
        if (router.location != '/') {
          router.go('/');
        }
      },
    ),
    //PaneItemSeparator(),
    // PaneItem(
    //   key: const Key('/shop/kindInfo'),
    //   icon: const Padding(
    //     padding: EdgeInsets.only(right: 6),
    //     child: SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_crown_left_24_dp.png'))),
    //   ),//const Icon(FluentIcons.home),
    //   title: const Text('착한 매장', style: naviItemTextStyle),
    //   trailing: const Padding(
    //     padding: EdgeInsets.only(right: 58),
    //     child: SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_crown_right_24_dp.png'))),
    //   ),
    //   body: const SizedBox.shrink(),
    //   isChild: true,
    //   onTap: () {
    //     //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
    //     if (router.location != '/shop/kindInfo') {
    //       router.go('/shop/kindInfo');
    //     }
    //   },
    // ),
    //PaneItemSeparator(),
    if (AuthService.MultiShopYn == 'Y' && AuthService.RepYn == 'Y')
      PaneItem(
        key: const Key('/multiShopDashboard/info'),
        icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_new.png'))),//const Icon(FluentIcons.home),
        title: const Text('전체 매장 현황', style: naviItemTextStyle),
        body: const SizedBox.shrink(),
        isChild: true,
        onTap: () {

          //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
          if (router.location != '/multiShopDashboard/info') {
            router.go('/multiShopDashboard/info');
          }
        },
      ),
    PaneItemSeparator(),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
          child: Text('이벤트/할인 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/liveEvent/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_event_hall.png'))),//const Icon(FluentIcons.special_event),
      title: const Text('라이브 이벤트', style: naviItemTextStyle,),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/liveEvent/info') {
          router.go('/liveEvent/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/sale/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_shop_coupon_enable.png'))),//const Icon(material.Icons.payments),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('우리 가게 쿠폰', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/sale/info') {
          router.go('/sale/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/sale/packDiscount'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_discount_sticker_32.png'))),//const Icon(material.Icons.payments),//const SizedBox(width: 0,),//const Icon(FluentIcons.bulleted_tree_list, color: Colors.white),
      title: const Text('포장 할인', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/sale/packDiscount') {
          router.go('/sale/packDiscount');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
          child: Text('매장 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_project_reserve_on.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/info') {
          router.go('/shop/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/order/deliTip'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_project_delivery_on.png'))),//const Icon(material.Icons.receipt),//const SizedBox(width: 0,),//const Icon(FluentIcons.table_header_row, color: Colors.white),
      title: const Text('배달팁', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/order/deliTip') {
          router.go('/order/deliTip');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/notifyInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/reserve_shop_notice_23.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장·리뷰 알림', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/notifyInfo') {
          router.go('/shop/notifyInfo');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('상품 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/menu/productInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_flower.png'))),
      title: const Text('상품 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/menu/productInfo') {
          router.go('/menu/productInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/menu/soldOutInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_out_of_stock.png'))),
      title: const Text('품절 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/menu/soldOutInfo') {
          router.go('/menu/soldOutInfo');
          //router.pop();
        }
        // if (router.location != (ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo')) {
        //   router.go(ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo');
        //   //router.pop();
        // }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('주문/매출 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/order/orderInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_card_list.png'))),//const Icon(material.Icons.receipt),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('주문 정보', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/order/orderInfo') {
          router.go('/order/orderInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/account/info'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_pay_type_account_sel_32.png'))),//const Icon(material.Icons.calculate),//const SizedBox(width: 0,),//const Icon(FluentIcons.text_field),
      title: const Text('매출 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/account/info') {
          router.go('/account/info', extra: 0);
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('리뷰 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      key: const Key('/review/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_review.png'))),//const Icon(material.Icons.rate_review),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('리뷰 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/review/info') {
          router.go('/review/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      key: const Key('/request/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_alert_notice.png'))),//const Icon(material.Icons.info),
      title: const Text('변경 요청 내역', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //print('[변경]router.location:${router.location}');
        if (router.location != '/request/info') {
          router.go('/request/info');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('이용 가이드', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/noticeInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_board.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('공지사항', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/noticeInfo') {
          router.go('/guide/noticeInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/faqInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/taxi_alert_safe_message.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('FAQ', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/faqInfo') {
          router.go('/guide/faqInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/userGuide'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_help.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('이용자 가이드', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/userGuide') {
          router.go('/guide/userGuide');
          //router.pop();
        }
      },
    ),
  ];

  late List<NavigationPaneItem> reserveItems = [
    PaneItem(
      key: const Key('/'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_daeguro.png'))),//const Icon(FluentIcons.home),
      title: const Text('매장 예약 현황', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
        if (router.location != '/') {
          router.go('/reserve/info');
        }
      },
    ),
    PaneItemSeparator(),
    PaneItemHeader(
        header: GestureDetector(
          child: const Padding(
            padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
            child: Text('매장 관리', style: naviHeaderTextStyle),
          ),
          onTap: () {
            // isOpen = !isOpen;
          },
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_project_reserve_on.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/info') {
          router.go('/shop/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/reserve/notifyInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_new_sticker_more_padding_26.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 소식', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/reserve/notifyInfo') {
          router.go('/reserve/notifyInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/reserve/notifyImageInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/delivery_good_shop.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 사진', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/reserve/notifyImageInfo') {
          router.go('/reserve/notifyImageInfo');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: GestureDetector(
          child: const Padding(
            padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
            child: Text('예약 관리', style: naviHeaderTextStyle),
          ),
          onTap: () {
            // isOpen = !isOpen;
          },
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/reserve/timeSchedule'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_mypage_notice.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('시간별 예약 설정', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/reserve/timeSchedule') {
          router.go('/reserve/timeSchedule');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/reserve/infoDashboard'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_mypage_customer_center.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('예약 현황', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/reserve/infoDashboard') {
          router.go('/reserve/infoDashboard');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('리뷰 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      key: const Key('/reserve/review'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_review.png'))),//const Icon(material.Icons.rate_review),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('리뷰 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/reserve/review') {
          router.go('/reserve/review');
          //router.pop();
        }
      },
    ),
    PaneItem(
      key: const Key('/request/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_alert_notice.png'))),//const Icon(material.Icons.info),
      title: const Text('변경 요청 내역', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //print('[변경]router.location:${router.location}');
        if (router.location != '/request/info') {
          router.go('/request/info');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('이용 가이드', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/noticeInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_board.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('공지사항', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/noticeInfo') {
          router.go('/guide/noticeInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/faqInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/taxi_alert_safe_message.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('FAQ', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/faqInfo') {
          router.go('/guide/faqInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/userGuide'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_help.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('이용자 가이드', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/userGuide') {
          router.go('/guide/userGuide');
          //router.pop();
        }
      },
    ),
  ];

  late List<NavigationPaneItem> marketMainShopItems = [
    PaneItem(
      key: const Key('/'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_daeguro.png'))),
      title: const Text('우리 매장 현황', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
        if (router.location != '/') {
          router.go('/');
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
          child: Text('매장 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_project_reserve_on.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/info') {
          router.go('/shop/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/notifyInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/reserve_shop_notice_23.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('시장 알림', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/notifyInfo') {
          router.go('/shop/notifyInfo');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('주문/매출 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/order/orderInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_card_list.png'))),//const Icon(material.Icons.receipt),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('주문 정보', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/order/orderInfo') {
          router.go('/order/orderInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/account/info'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_pay_type_account_sel_32.png'))),//const Icon(material.Icons.calculate),//const SizedBox(width: 0,),//const Icon(FluentIcons.text_field),
      title: const Text('매출 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/account/info') {
          router.go('/account/info', extra: 0);
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('리뷰 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      key: const Key('/review/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_review.png'))),//const Icon(material.Icons.rate_review),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('리뷰 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/review/info') {
          router.go('/review/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      key: const Key('/request/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_alert_notice.png'))),//const Icon(material.Icons.info),
      title: const Text('변경 요청 내역', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //print('[변경]router.location:${router.location}');
        if (router.location != '/request/info') {
          router.go('/request/info');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('이용 가이드', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/noticeInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_board.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('공지사항', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/noticeInfo') {
          router.go('/guide/noticeInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/faqInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/taxi_alert_safe_message.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('FAQ', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/faqInfo') {
          router.go('/guide/faqInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/userGuide'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_help.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('이용자 가이드', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/userGuide') {
          router.go('/guide/userGuide');
          //router.pop();
        }
      },
    ),
  ];

  late List<NavigationPaneItem> marketShopItems = [
    PaneItem(
      key: const Key('/'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_daeguro.png'))),
      title: const Text('우리 매장 현황', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
        if (router.location != '/') {
          router.go('/');
        }
      },
    ),
    PaneItemSeparator(),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
          child: Text('이벤트/할인 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/liveEvent/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_event_hall.png'))),//const Icon(FluentIcons.special_event),
      title: const Text('라이브 이벤트', style: naviItemTextStyle,),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/liveEvent/info') {
          router.go('/liveEvent/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/sale/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_shop_coupon_enable.png'))),//const Icon(material.Icons.payments),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('우리 가게 쿠폰', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/sale/info') {
          router.go('/sale/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/sale/packDiscount'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_discount_sticker_32.png'))),//const Icon(material.Icons.payments),//const SizedBox(width: 0,),//const Icon(FluentIcons.bulleted_tree_list, color: Colors.white),
      title: const Text('포장 할인', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/sale/packDiscount') {
          router.go('/sale/packDiscount');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
          child: Text('매장 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_project_reserve_on.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/info') {
          router.go('/shop/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/notifyInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/reserve_shop_notice_23.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장·리뷰 알림', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/notifyInfo') {
          router.go('/shop/notifyInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/order/deliTip'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_project_delivery_on.png'))),//const Icon(material.Icons.receipt),//const SizedBox(width: 0,),//const Icon(FluentIcons.table_header_row, color: Colors.white),
      title: const Text('배달 지역 및 배달팁', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/order/deliTip') {
          router.go('/order/deliTip');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('상품/메뉴 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/menu/productInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_flower.png'))),
      title: const Text('장바구니 상품 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/menu/productInfo') {
          router.go('/menu/productInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/menu/menuInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_korean_food.png'))),
      title: const Text('메뉴 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/menu/menuInfo') {
          router.go('/menu/menuInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/menu/soldOutInfo'),//Key(ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_out_of_stock.png'))),//const Icon(material.Icons.room_service),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('품절 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/menu/soldOutInfo') {
          router.go('/menu/soldOutInfo');
          //router.pop();
        }
        // if (router.location != (ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo')) {
        //   router.go(ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo');
        //   //router.pop();
        // }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('주문/매출 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/order/orderInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_card_list.png'))),//const Icon(material.Icons.receipt),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('주문 정보', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/order/orderInfo') {
          router.go('/order/orderInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/account/info'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_pay_type_account_sel_32.png'))),//const Icon(material.Icons.calculate),//const SizedBox(width: 0,),//const Icon(FluentIcons.text_field),
      title: const Text('매출 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/account/info') {
          router.go('/account/info', extra: 0);
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('리뷰 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      key: const Key('/review/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_review.png'))),//const Icon(material.Icons.rate_review),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('리뷰 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/review/info') {
          router.go('/review/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      key: const Key('/request/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_alert_notice.png'))),//const Icon(material.Icons.info),
      title: const Text('변경 요청 내역', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //print('[변경]router.location:${router.location}');
        if (router.location != '/request/info') {
          router.go('/request/info');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('이용 가이드', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/noticeInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_board.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('공지사항', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/noticeInfo') {
          router.go('/guide/noticeInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/faqInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/taxi_alert_safe_message.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('FAQ', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/faqInfo') {
          router.go('/guide/faqInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/userGuide'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_help.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('이용자 가이드', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/userGuide') {
          router.go('/guide/userGuide');
          //router.pop();
        }
      },
    ),
  ];

  final List<NavigationPaneItem> commonItems = [
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('주문/매출 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/order/orderInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_card_list.png'))),//const Icon(material.Icons.receipt),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('주문 정보', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/order/orderInfo') {
          router.go('/order/orderInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/account/info'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_pay_type_account_sel_32.png'))),//const Icon(material.Icons.calculate),//const SizedBox(width: 0,),//const Icon(FluentIcons.text_field),
      title: const Text('매출 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/account/info') {
          router.go('/account/info', extra: 0);
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('리뷰 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      key: const Key('/review/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_review.png'))),//const Icon(material.Icons.rate_review),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('리뷰 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/review/info') {
          router.go('/review/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      key: const Key('/request/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_alert_notice.png'))),//const Icon(material.Icons.info),
      title: const Text('변경 요청 내역', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //print('[변경]router.location:${router.location}');
        if (router.location != '/request/info') {
          router.go('/request/info');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('이용 가이드', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/noticeInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_board.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('공지사항', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/noticeInfo') {
          router.go('/guide/noticeInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/faqInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/taxi_alert_safe_message.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('FAQ', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/faqInfo') {
          router.go('/guide/faqInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/userGuide'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_help.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('이용자 가이드', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/userGuide') {
          router.go('/guide/userGuide');
          //router.pop();
        }
      },
    ),
  ];

  /// Footer Item 리스트
  final List<NavigationPaneItem> footerItems = [
    PaneItemSeparator(),
    PaneItem(
      key: const Key('/privateInfo'),
      icon: const Icon(FluentIcons.settings),
      title: const Text('개인정보 변경', style: naviFooterTextStyle),
      body: const SizedBox.shrink(),
      // trailing: material.Material(
      //   child: material.InkWell(
      //     child: const Row(
      //       children: [
      //         Icon(FluentIcons.sign_out),
      //         SizedBox(width: 6,),
      //         Text('로그아웃', style: naviFooterTextStyle),
      //         SizedBox(width: 12,),
      //       ],
      //     ),
      //     onTap: () {
      //       AuthService.to.logout();
      //     },
      //   ),
      // ),
      height: 30,
      onTap: () {
        if (router.location != '/privateInfo') {
          router.go('/privateInfo');
        }
      },
    ),
    PaneItem(
      key: const Key('/logout'),
      icon: const Icon(FluentIcons.sign_out),
      title: const Text('로그아웃', style: naviFooterTextStyle),
      body: const SizedBox.shrink(),
      height: 30,
      onTap: () {
        AuthService.to.logout();
      },
    ),
  ];

  bool isOrderDeli = true;
  bool isReserve = false;
  late List<bool> isSelected;

  void bindingMultiShopListInfo() async {
    await AuthService().userStorage.write(key: 'key', value: '');

    //Get.offAllNamed('/login');
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    final String url = Uri.base.toString();

    isSelected = [isOrderDeli, isReserve];

    if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER) {
      baseNaviItem = flowerItems;
    }
    else if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET) {
      baseNaviItem = (AuthService.TradShopMainYn == 'Y') ? marketMainShopItems : marketShopItems;
    }
    else if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET) {
      baseNaviItem = electmarketItems;
    }
    else {
      baseNaviItem = deliveryItems;
    }

    //baseNaviItem!.addAll(commonItems);

    // if (AppUseState.currentShopMode == AppUseState.MODE_FOOD) {
    //   baseNaviItem = foodNaviItems;
    // }
    // else if (AppUseState.currentShopMode == AppUseState.MODE_FLOWER) {
    //   baseNaviItem = flowerNaviItems;
    // }
    //
    // baseNaviItem.forEach((element) {
    // });

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    baseNaviItem!.clear();

    deliveryItems.clear();
    footerItems.clear();

    menuFocusNode.dispose();

    searchController.dispose();
    searchFocusNode.dispose();
    super.dispose();
  }

  int _calculateSelectedIndex(BuildContext context) {
    final location = router.location;
    int indexOriginal = baseNaviItem!.where((element) => element.key != null).toList().indexWhere((element) => element.key == Key(location));

    if (indexOriginal == -1) {
      int indexFooter = footerItems.where((element) => element.key != null).toList().indexWhere((element) => element.key == Key(location));
      if (indexFooter == -1) {
        return 0;
      }

      return baseNaviItem!.where((element) => element.key != null).toList().length + indexFooter;
    }
    else {
      return indexOriginal;
    }
  }

  @override
  Widget build(BuildContext context) {
    //final localizations = FluentLocalizations.of(context);
    final appTheme = context.watch<AppTheme>();

    if (widget.shellContext != null) {
      if (router.canPop() == false) {
        setState(() {});
      }
    }

    return NavigationView(
      key: viewKey,
      appBar: NavigationAppBar(
        height: 60,
        automaticallyImplyLeading: false,
        // leading: () {
        //   final enabled = widget.shellContext != null && router.canPop();
        //   final onPressed = enabled
        //       ? () {
        //     if (router.canPop()) {
        //       context.pop();
        //       setState(() {});
        //     }
        //   }
        //       : null;
        //   return NavigationPaneTheme(
        //     data: NavigationPaneTheme.of(context).merge(NavigationPaneThemeData(
        //       unselectedIconColor: ButtonState.resolveWith((states) {
        //         if (states.isDisabled) {
        //           return ButtonThemeData.buttonColor(context, states);
        //         }
        //         return ButtonThemeData.uncheckedInputColor(FluentTheme.of(context), states,).basedOnLuminance();
        //       }),
        //     )),
        //     child: Builder(
        //       builder: (context) => PaneItem(
        //         icon: const Center(child: Icon(FluentIcons.back, size: 14.0)),
        //         title: Text("Back"),
        //         body: const SizedBox.shrink(),
        //         enabled: enabled,
        //       ).build(context, false, onPressed, displayMode: PaneDisplayMode.compact,),
        //     ),
        //   );
        // }(),
        title: () {
          return material.Material(
            child: material.InkWell(
              onTap: () {

                // if (widget.shellContext != null && router.canPop()){
                //   if (router.canPop()) {
                //     context.pop();
                //     setState(() {});
                //   }
                // }

                if (router.location != '/') router.go('/');
              },
              child: SizedBox(height: 50, child: Image(image: AssetImage(Responsive.isMobile(context) == true ? 'images/img_header_logo.png' : 'images/img_aside_logo.png')),),
            ),
          );
        }(),
        actions: SizedBox(
          height: 60,
          child: Row(
              mainAxisAlignment:Responsive.isMobile(context) == true ? MainAxisAlignment.end : MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children:  [
                Row(
                  children: [
                    if (Responsive.isMobile(context) == false)...[
                      Padding(
                        padding: const EdgeInsetsDirectional.only(start: naviPaneOpenWidth+8),
                        child: MouseRegion(
                          cursor: SystemMouseCursors.click,
                          child: GestureDetector(
                              child: Container(
                                  alignment: Alignment.center,
                                  //padding: const EdgeInsets.symmetric(horizontal: 10),
                                  height: 40,
                                  width: 120,
                                  decoration: BoxDecoration(
                                      color: appTheme.currentShopStatusGbn == 'Y' ? const material.Color(0xff01CAFF) : material.Colors.grey,
                                      borderRadius: BorderRadius.circular(10)
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(appTheme.currentShopStatusGbn == 'Y' ? '영업 중' : '휴점 중', style: const TextStyle(color: material.Colors.white, fontSize: 22, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON),),
                                      const SizedBox(width: 8,),
                                      Icon(appTheme.currentShopStatusGbn == 'Y' ? material.Icons.wb_sunny_outlined : material.Icons.cloud_outlined, color: material.Colors.white, size: 22,)
                                    ],
                                  )
                              ),
                              onTap: () {
                                showDialog(
                                  context: context,
                                  barrierDismissible: true,
                                  builder: (context) => const ShopStatusEdit(),
                                );
                              }
                          ),
                        ),
                      ),
                    ],
                    if (AuthService.MultiShopYn == 'Y' && AuthService.ShopMode == AuthService.SHOPMODE_DELIVERY)
                      Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Row(
                        children: [
                          material.Material(
                            child: ISSearchDropdown(
                              width: Responsive.isMobile(context)
                                  ? Get.width > 390 ? 170 : 145
                                  : 250,
                              label: '',
                              value: selMultiShop,
                              onChange: (value) {
                                if(selMultiShop == value) {
                                  return;
                                }

                                selMultiShop = value;
                                _requestMoveAPIData(value).then((v) {
                                  if(v.toString() == '00'){
                                    // 멀티샵 여부 체크 검증
                                    var tt = selectMultiShopList.where((element) => element.value == value);
                                    final str2 = utf8.decode(base64.decode(tt.first.pass.toString()));

                                    mulitiShopLogin(tt.first.value.toString(), tt.first.id.toString(), str2, context, appTheme);
                                  }
                                });},
                              item: selectMultiShopList,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                if (Responsive.isMobile(context) == false)
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 8.0),
                        child: material.TextButton(
                          style: material.ButtonStyle(
                            animationDuration: const Duration(microseconds: 100),
                            overlayColor: material.MaterialStateProperty.resolveWith<Color>((Set<material.MaterialState> states) => Colors.transparent),
                            foregroundColor: material.MaterialStateProperty.resolveWith<Color>(
                                    (Set<material.MaterialState> states) {
                                  if (states.contains(material.MaterialState.hovered)) {
                                    return const Color(0xff01CAFF);
                                  }
                                  return Colors.black;//Colors.white;
                                }),
                          ),
                          onPressed: () async{
                              final key = EncryptPack.Key.fromBase64('d25hbnNkbXNlb3JuZmhxb2VrZmRtc2VvcmRtZmhhYmM=');
                              final iv = EncryptPack.IV.fromLength(16);
                              final encrypter = EncryptPack.Encrypter(EncryptPack.AES(key, mode: EncryptPack.AESMode.cbc));

                              // Base64Codec base64 = const Base64Codec();
                              Codec<String, String> stringToBase64 = utf8.fuse(base64);
                              String decoded = stringToBase64.decode(AuthService.apiComCode!);

                              var _json;

                              // _json = {
                              //   "mappType": "3",
                              //   "mappCode": "$apiComCode",
                              //   "mappGbn": "ISPOS",
                              // };

                              _json = {
                                "mapp": "ISPOS",
                                "code": "$decoded",
                                "job_name": "Main",
                                "uname": "${AuthService.uName}",
                                "type": "3",
                                "date": formatDate(DateTime.now(), [yyyy, mm, dd, HH, mm, ss]),
                              };

                              var _aesEncoded = encrypter.encrypt(json.encode(_json), iv: iv).base64;
                              var _urlEncoded = Uri.encodeComponent(_aesEncoded);

                              if (await canLaunch('https://ceo.daeguro.co.kr/LinkTo?url=$_urlEncoded')) {
                                await launch(
                                  'https://ceo.daeguro.co.kr/LinkTo?url=$_urlEncoded',
                                );
                              } else {
                                throw 'Web Request Fail https://ceoflower.daeguro.co.kr/#/LinkTo?url=$_urlEncoded';
                              }
                            },
                          // },
                          child: const Text('> (구)사장님 사이트 이동하기', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),

                        ),
                      ),
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 8.0),
                        //child: Text('안녕하세요 XXX 사장님', style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY_NEXON),),
                        child: AuthService.MallUseGbn == 'Y' ? material.TextButton(
                          style: material.ButtonStyle(
                            animationDuration: const Duration(microseconds: 100),
                            overlayColor: material.MaterialStateProperty.resolveWith<Color>((Set<material.MaterialState> states) => Colors.transparent),
                            foregroundColor: material.MaterialStateProperty.resolveWith<Color>(
                                    (Set<material.MaterialState> states) {
                                  if (states.contains(material.MaterialState.hovered)) {
                                    return const Color(0xff01CAFF);
                                  }
                                  return Colors.black;//Colors.white;
                                }),
                          ),
                          onPressed: () async {
                            final key = EncryptPack.Key.fromBase64('d25hbnNkbXNlb3JuZmhxb2VrZmRtc2VvcmRtZmhhYmM=');
                            final iv = EncryptPack.IV.fromLength(16);
                            final encrypter = EncryptPack.Encrypter(EncryptPack.AES(key, mode: EncryptPack.AESMode.cbc));

                            Codec<String, String> stringToBase64 = utf8.fuse(base64);
                            String decoded = stringToBase64.decode(AuthService.apiComCode!);

                            var _json;

                            _json = {
                              "mapp": "ISPOS",
                              "code": "$decoded",
                              "type": "3",
                            };

                            var _aesEncoded = encrypter.encrypt(json.encode(_json), iv: iv).base64;
                            var _urlEncoded = Uri.encodeComponent(_aesEncoded);

                            if (await canLaunch('https://m.daeguromall.com/api/V1/login/?url=$_urlEncoded')) {
                              await launch(
                                'https://m.daeguromall.com/api/V1/login/?url=$_urlEncoded',
                              );
                            } else {
                              throw 'Web Request Fail https://m.daeguromall.com?url=$_urlEncoded';
                            }
                          },
                          child: const Text('> 대구로몰 이동하기', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                        ) : const SizedBox.shrink(),
                ),
                    ],
                  ),
              ]),
        ),
      ),
      transitionBuilder: (child, animation) {
        return SuppressPageTransition(
          //animation: animation,
          child: child,
        );
      },
      pane: NavigationPane(
        size: const NavigationPaneSize(openWidth: naviPaneOpenWidth, compactWidth: naviPaneCompactWidth),
        selected: _calculateSelectedIndex(context),
        displayMode: PaneDisplayMode.auto,
        items: baseNaviItem!,
        menuButton: Responsive.isTablet(context) ? const SizedBox.shrink() : Container(
          //color: Colors.yellow,
          width: double.infinity,
          alignment: Alignment.center,
          child: Column(
            children: [
              const Divider(),
              material.ToggleButtons(
                //constraints: BoxConstraints(maxWidth: Responsive.isMobile(context) ? naviPaneCompactWidth : naviPaneOpenWidth, maxHeight: 160),
                isSelected: isSelected,
                onPressed: (v) {
                  if (v == 0) {
                    isOrderDeli = true;
                    isReserve = false;
                  } else {
                    isOrderDeli = false;
                    isReserve = true;
                  }


                  setState(() {
                    isSelected = [isOrderDeli, isReserve];
                  });

                  if (isReserve == true) {
                    baseNaviItem = reserveItems;
                    AuthService.ShopMode = AuthService.SHOPMODE_RESERVE;

                    router.go('/reserve/info');
                  }
                  else {
                    if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER) {
                      baseNaviItem = flowerItems;
                    }
                    else if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET) {
                      baseNaviItem = (AuthService.TradShopMainYn == 'Y') ? marketMainShopItems : marketShopItems;
                    }
                    else if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET) {
                      baseNaviItem = electmarketItems;
                    }
                    else {
                    baseNaviItem = deliveryItems;
                    }

                    //baseNaviItem!.addAll(commonItems);

                    AuthService.ShopMode = AuthService.SHOPMODE_DELIVERY;

                    router.go('/');
                  }
                },
                borderColor: Colors.transparent,//Colors.black,
                fillColor: const Color(0xff01CAFF),//Colors.grey,
                borderWidth: 2,
                selectedBorderColor: Colors.transparent,//Colors.black,
                selectedColor: Colors.white,
                borderRadius: BorderRadius.circular(0),
                children: [
                  Container(
                    width: (naviPaneOpenWidth/2)-4,
                    height: 32,
                    alignment: Alignment.center,
                    child: const Text('배달/포장', style: TextStyle(fontSize: 18,  fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                  ),
                  Container(
                    width: naviPaneOpenWidth/2-4,
                    height: 32,
                    alignment: Alignment.center,
                    child: const Text('예약', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                  ),
                ],
              ),
              const Divider(),
            ],
          ),
        ),
        // header: GestureDetector(
        //   onTap: () {
        //     if (router.location != '/') router.go('home');
        //   },
        //   child: SizedBox(
        //     height: 70,
        //     child: Image.asset('assets/img_aside_logo.png'),
        //   ),
        // ),
        // indicator: () {
        //   switch (appTheme.indicator) {
        //     case NavigationIndicators.end:
        //       return const EndNavigationIndicator();
        //     case NavigationIndicators.sticky:
        //     default:
        //       return const StickyNavigationIndicator();
        //   }
        // }(),
        autoSuggestBox: AutoSuggestBox(
          key: searchKey,
          focusNode: searchFocusNode,
          controller: searchController,
          unfocusedColor: Colors.transparent,
          onChanged: (String value, TextChangedReason reason){
            if (value.isEmpty) {
              searchController.text = ' ';
            }
          },
          items: baseNaviItem!.whereType<PaneItem>().map((item) {
            assert(item.title is Text);
            final text = (item.title as Text).data!;
            return AutoSuggestBoxItem(
              label: text,
              value: text,
              onSelected: () {
                item.onTap?.call();
                searchController.clear();
              },
            );
          }).toList(),
          trailingIcon: IgnorePointer(
            child: IconButton(
              onPressed: () {},
              icon: const Icon(FluentIcons.search),
            ),
          ),
          placeholder: "검색",
        ),
        autoSuggestBoxReplacement: const Icon(FluentIcons.search),
        footerItems: footerItems,
      ),
      paneBodyBuilder: (item, child) {
        final name = item?.key is ValueKey ? (item!.key as ValueKey).value : null;

        return FocusTraversalGroup(
          key: ValueKey('body$name'),
          child: widget.child,//Container(color: Colors.teal, child: widget.child),//컨텐츠 영역
        );
      },
      onOpenSearch: () {
        searchFocusNode.requestFocus();
      },
    );
  }

  mulitiShopLogin(String shopCd, String id, String pass, BuildContext context, AppTheme appTheme) async {
    await LoginController.to.connectedlogIn(shopcd: shopCd, loginid: id, loginpass: pass).then((value) async {
      if (value == '') {
        ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
        //Navigator.of(context).pop;
      }
      else{
        String code = value.toString().split('|').first;
        String msg = value.toString().split('|').last;

        if (code == '00') {
          appTheme.currentShopStatusGbn = AuthService.ShopStatus;
          appTheme.ShopRefresh = true;


          if (mounted) {
            WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
              await Future.delayed(const Duration(milliseconds: 500), () {
                setState(() {
                  if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER) {
                    baseNaviItem = flowerItems;
                  }
                  else if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET) {
                    baseNaviItem = (AuthService.TradShopMainYn == 'Y') ? marketMainShopItems : marketShopItems;
                  }
                  else if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET) {
                    baseNaviItem = electmarketItems;
                  }
                  else {
                    baseNaviItem = deliveryItems;
                  }

                  //baseNaviItem!.addAll(commonItems);

                });
              });
            });
          }
        }
        else{
          ISAlert(context, content: '멀티샵 변경 실패\n→ ${msg} ');
        }
      }
    });
  }
}

class _NavigationBodyItem extends StatelessWidget {
  const _NavigationBodyItem({
    this.header,
    this.content,
  });

  final String? header;
  final Widget? content;

  @override
  Widget build(BuildContext context) {
    return ScaffoldPage.withPadding(
      header: PageHeader(title: Text(header ?? 'This is a header text')),
      content: content ?? const SizedBox.shrink(),
    );
  }
}