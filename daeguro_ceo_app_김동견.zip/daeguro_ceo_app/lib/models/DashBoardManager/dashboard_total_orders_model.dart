class DashboardTotalOrdersModel {
  DashboardTotalOrdersModel();

  String status = '';
  int count = 0;
}
