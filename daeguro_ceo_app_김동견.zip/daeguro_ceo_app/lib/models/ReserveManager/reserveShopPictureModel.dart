import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveShopPictureModel {
  ReserveShopPictureModel();

  int? seq;
  String? noticeName;
  String? fileName;
  String? fileUrl;
  int? sortSeq;
  String? temaName;
  String? temaCode;
}
