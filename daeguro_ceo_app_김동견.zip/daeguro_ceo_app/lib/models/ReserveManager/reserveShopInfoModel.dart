import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveShopInfoModel {
  ReserveShopInfoModel();

  String? shopName;
  String? salesName;
  String? shopFileName;
  String? telNo;
  String? mobile;
  String? addr1;
  String? addr2;
  String? loc;
  String? itemCd;
  String? itemCd1;
  String? introduce;
  String? notice;
  String? reviewUseGbn;
  String? shopReviewIntro;
  List<dynamic> ssNoticeImages = [];
  List<dynamic> ssReviewImage = [];
}

