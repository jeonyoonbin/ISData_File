import 'package:json_annotation/json_annotation.dart';

import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class DeliTipAmtEditModel {
  DeliTipAmtEditModel();

  List<String>? jobGbn = [];
  String? shopCd = '';
  List<String>? tipSeq = [];
  List<String>? tipGbn = [];
  List<String>? tipDay = [];
  List<String>? tipFrStand = [];
  List<String>? tipToStand = [];
  List<String>? tipAmt = [];
  List<String>? tipAmtRate = [];
  List<String>? tipNextDay = [];
  String? uCode = '';
  String? uName = '';

  factory DeliTipAmtEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

DeliTipAmtEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return DeliTipAmtEditModel()
    ..jobGbn = json['jobGbn'].cast<String>()
    ..shopCd = json['shopCd']
    ..tipSeq = json['tipSeq'].cast<String>()
    ..tipGbn = json['tipGbn'].cast<String>()
    ..tipDay = json['tipDay'].cast<String>()
    ..tipFrStand = json['tipFrStand'].cast<String>()
    ..tipToStand = json['tipToStand'].cast<String>()
    ..tipAmt = json['tipAmt'].cast<String>()
    ..tipAmtRate = json['tipAmtRate'].cast<String>()
    ..tipNextDay = json['tipNextDay'].cast<String>()
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(DeliTipAmtEditModel instance) =>
    <String, dynamic>{
      'jobGbn' : instance.jobGbn,
      'shopCd' : instance.shopCd,
      'tipSeq' : instance.tipSeq,
      'tipGbn' : instance.tipGbn,
      'tipDay' : instance.tipDay,
      'tipFrStand' : instance.tipFrStand,
      'tipToStand' : instance.tipToStand,
      'tipAmt' : instance.tipAmt,
      'tipAmtRate' : instance.tipAmtRate,
      'tipNextDay' : instance.tipNextDay,
      'uCode' : instance.uCode,
      'uName' : instance.uName
    };