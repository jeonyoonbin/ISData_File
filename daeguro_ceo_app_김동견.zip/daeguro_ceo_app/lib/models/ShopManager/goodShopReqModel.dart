class GoodShopReqModel {
  String? kindShopYn = '';
  String? kindShopCancelDt = '';
  String? seq = '';
  String? status = '';
  String? statusName = '';
  String? serviceGbn = '';
  String? btnReqYn = '';
  String? btnReqCancelYn = '';
  String? btnDelYn = '';
  String? btnDelCancelYn = '';
  String? answerText = '';
  String? btnGoodShopYn = '';
  String? goodShopReapply = '';
}