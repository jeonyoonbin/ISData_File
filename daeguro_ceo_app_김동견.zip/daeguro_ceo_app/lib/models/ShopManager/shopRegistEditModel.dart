import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopRegistEditModel {
  ShopRegistEditModel();

  bool? selected = false;
  String? shopCd;
  String? email;
  String? modUcode;
  String? modName;

  factory ShopRegistEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopRegistEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopRegistEditModel()
    ..shopCd = json['shopCd'] as String
    ..email = json['email'] as String
    ..modUcode = json['modUcode'] as String
    ..modName = json['modName'] as String;

}

Map<String, dynamic> _$ModelToJson(ShopRegistEditModel instance) => <String, dynamic>{
  'shopCd': instance.shopCd,
  'email': instance.email,
  'modUcode': instance.modUcode,
  'modName': instance.modName
};