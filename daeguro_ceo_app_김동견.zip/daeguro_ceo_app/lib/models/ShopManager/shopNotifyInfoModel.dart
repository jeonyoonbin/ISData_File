
class ShopNotifyInfoModel {
  ShopNotifyInfoModel({
    this.introCd,
    this.shopCd,
    this.introGbn,
    this.introContents,
    this.modDate,
    this.introImage,
    this.introImage2,
    this.useGbn
  });
  bool selected = false;

  String? introCd;
  String? shopCd;
  String? introGbn;
  String? introContents;
  String? modDate;
  String? introImage;
  String? introImage2;
  String? introImageFullPath;
  String? introImageFullPath2;
  String? useGbn;
}

