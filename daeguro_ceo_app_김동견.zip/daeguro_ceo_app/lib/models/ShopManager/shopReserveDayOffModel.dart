import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopReserveDayOffModel {
  ShopReserveDayOffModel();

  String? shopCode = '';
  String? gbn = '';
  List<dynamic>? list = [];

  factory ShopReserveDayOffModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopReserveDayOffModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopReserveDayOffModel()
    ..shopCode = json['shopCode'] as String
    ..gbn = json['gbn'] as String
    ..list = json['list'] as List<dynamic>;
}

Map<String, dynamic> _$ModelToJson(ShopReserveDayOffModel instance) => <String, dynamic>{
  'shopCode': instance.shopCode,
  'gbn': instance.gbn,
  'list': instance.list
};