import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class NoticeDetailModel {
  NoticeDetailModel();

  bool? selected = false;

  String? noticeSeq;
  String? noticeGbn;
  String? dispGbn;
  String? dispFrDate;
  String? dispToDate;
  String? noticeTitle;
  String? noticeContents;
  String? noticeUrl1;
  String? noticeUrl2;
  String? noticeUrl3;
  String? orderDate;
  String? insUcode;
  String? insName;
  String? insDate;
  String? modUcode;
  String? modName;
  String? modDate;
}