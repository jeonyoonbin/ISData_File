import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class SoldOutOptionListModel {
  SoldOutOptionListModel();

  bool? selected = false;
  String? optionCd;
  String? optGrpCd;
  String? optName;
  String? optCost;
  String? optUseGbn;
  String? adultOnly;
  String? optNoFlag;
}