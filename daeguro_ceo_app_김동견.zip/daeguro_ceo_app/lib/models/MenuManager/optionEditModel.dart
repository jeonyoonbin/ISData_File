import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionEditModel {
  OptionEditModel();

  bool selected = false;
  String? shopCd;
  String? groupCd;
  String? optionCd;
  String? optionName;
  String? optionMemo;
  String? cost;
  String? useYn;
  String? noFlag;
  String? adultOnly;
  String? uName;

  factory OptionEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

OptionEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return OptionEditModel()
  // ..selected = json['selected'] as bool
      ..shopCd = json['shopCd']
      ..groupCd = json['groupCd']
      ..optionCd = json['optionCd']
      ..optionName = json['optionName']
      ..optionMemo = json['optionMemo']
      ..cost = json['cost']
      ..useYn = json['useYn']
      ..noFlag = json['noFlag']
      ..adultOnly = json['adultOnly']
      ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(OptionEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'groupCd': instance.groupCd,
      'optionCd': instance.optionCd,
      'optionName': instance.optionName,
      'optionMemo': instance.optionMemo,
      'cost': instance.cost,
      'useYn': instance.useYn,
      'noFlag': instance.noFlag,
      'adultOnly': instance.adultOnly,
      'uName': instance.uName
    };
