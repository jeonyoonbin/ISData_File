import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class SoldOutEditModel {
  SoldOutEditModel();

  bool? selected = false;
  String? cost = '';
  String? deliTip = '';
}