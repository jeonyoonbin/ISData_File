import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class MenuGroupListModel {
  MenuGroupListModel();

  bool selected = false;
  String? menuGroupCd;
  String? menuGroupName;
  String? menuNames;
  String? menuGroupMemo;
  String? useYn;
  String? mainCount;

  factory MenuGroupListModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

MenuGroupListModel _$ModelFromJson(Map<String, dynamic> json) {
  return MenuGroupListModel()
    ..selected = json['selected'] as bool
    ..menuGroupCd = json['menuGroupCd'] as String
    ..menuGroupName = json['menuGroupName'] as String
    ..menuNames = json['menuNames'] as String
    ..menuGroupMemo = json['menuGroupMemo'] as String
    ..useYn = json['useYn'] as String
    ..mainCount = json['mainCount'] as String;
}

Map<String, dynamic> _$ModelToJson(MenuGroupListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'menuGroupCd': instance.menuGroupCd,
  'menuGroupName': instance.menuGroupName,
  'menuNames': instance.menuNames,
  'menuGroupMemo': instance.menuGroupMemo,
  'useYn': instance.useYn,
  'mainCount': instance.mainCount,
};
