import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class MenuListModel {
  MenuListModel();

  bool selected = false;
  String? menuCd;
  String? menuName;
  String? menuCost;
  String? menuDesc;
  String? mAloneOrder;
  String? mMainYn;
  String? fileName;
  String? useGbn;
  String? noFlag;
  String? adultOnly;
  String? menuEventYn;
  String? orderLimitYn;
  String? orderLimitQnt;
  String? singleOrderYn;

  factory MenuListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

MenuListModel _$ModelFromJson(Map<String, dynamic> json) {
  return MenuListModel()
  // ..selected = json['selected'] as bool
    ..menuCd = json['menuCd'] as String
    ..menuName = json['menuName'] as String
    ..menuCost = json['menuCost'] as String
    ..menuDesc = json['menuDesc'] as String
    ..mAloneOrder = json['mAloneOrder'] as String
    ..mMainYn = json['mMainYn'] as String
    ..fileName = json['fileName'] as String
    ..useGbn = json['useGbn'] as String
    ..noFlag = json['noFlag'] as String
    ..adultOnly = json['adultOnly'] as String
    ..menuEventYn = json['menuEventYn'] as String
    ..orderLimitYn = json['orderLimitYn'] as String
    ..orderLimitQnt = json['orderLimitQnt'] as String
    ..singleOrderYn = json['singleOrderYn'] as String;
}

Map<String, dynamic> _$ModelToJson(MenuListModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'menuCd': instance.menuCd,
      'menuName': instance.menuName,
      'menuCost': instance.menuCost,
      'menuDesc': instance.menuDesc,
      'mAloneOrder': instance.mAloneOrder,
      'mMainYn': instance.mMainYn,
      'fileName': instance.fileName,
      'useGbn': instance.useGbn,
      'noFlag': instance.noFlag,
      'adultOnly': instance.adultOnly,
      'menuEventYn': instance.menuEventYn,
      'orderLimitYn': instance.orderLimitYn,
      'orderLimitQnt': instance.orderLimitQnt,
      'singleOrderYn': instance.singleOrderYn
    };
