import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReviewAnswerModel {
  ReviewAnswerModel();

  String? orderNo;
  String? shopCode;
  String? content;
  String? modUcode;
  String? modName;
  String? answerVisibleGbn;

  factory ReviewAnswerModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReviewAnswerModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReviewAnswerModel()
    ..orderNo = json['orderNo']
    ..shopCode = json['shopCode']
    ..content = json['content']
    ..modUcode = json['modUcode']
    ..modName = json['modName']
    ..answerVisibleGbn = json['answerVisibleGbn'];
}

Map<String, dynamic> _$ModelToJson(ReviewAnswerModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'orderNo': instance.orderNo,
      'shopCode': instance.shopCode,
      'content': instance.content,
      'modUcode': instance.modUcode,
      'modName': instance.modName,
      'answerVisibleGbn': instance.answerVisibleGbn
};
