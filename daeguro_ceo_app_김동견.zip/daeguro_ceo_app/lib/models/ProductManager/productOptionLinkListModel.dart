import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOptionLinkListModel {
  ProductOptionLinkListModel();

  bool isFlag = false;
  String? selected = '';
  String? prodOptGrpCd = '';
  String? optGrpCd = '';
  String? name = '';
  String? minCount = '';
  String? multiCount = '';
  String? useGbn = '';
  String? optNames = '';
}