import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOriginLocalListModel {
  ProductOriginLocalListModel();

  bool selected = false;
  String? seq;
  String? title;
  String? contents;
  String? useGbn;

  factory ProductOriginLocalListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ProductOriginLocalListModel _$ModelFromJson(Map<String, dynamic> json) {
  return ProductOriginLocalListModel()
    ..selected = json['selected'] as bool
    ..seq = json['seq'] as String
    ..title = json['title'] as String
    ..contents = json['contents'] as String
    ..useGbn = json['useGbn'] as String;
}

Map<String, dynamic> _$ModelToJson(ProductOriginLocalListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'seq': instance.seq,
  'title': instance.title,
  'contents': instance.contents,
  'useGbn': instance.useGbn
};


