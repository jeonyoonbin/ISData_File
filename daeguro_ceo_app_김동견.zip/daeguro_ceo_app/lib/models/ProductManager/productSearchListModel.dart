import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductSearchListModel {
  ProductSearchListModel();

  bool selected = false;
  bool isFlag = false;

  String? prodCd;
  String? name;
  String? cost;
  String? useGbn;
  String? noFlag;
  String? mainYn;
}