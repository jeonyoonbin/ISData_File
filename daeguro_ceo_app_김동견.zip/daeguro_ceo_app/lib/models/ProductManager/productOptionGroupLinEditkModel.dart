import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOptionGroupLinkEditModel {
  String? shopCd;
  String? optGrpCd;
  List<String>? prodCd;
  String? uCode;
  String? uName;

  ProductOptionGroupLinkEditModel({this.shopCd, this.optGrpCd, this.prodCd, this.uCode, this.uName});

  ProductOptionGroupLinkEditModel.fromJson(Map<String, dynamic> json) {
    shopCd = json['shopCd'];
    optGrpCd = json['optGrpCd'];
    prodCd = json['prodCd'].cast<String>();
    uCode = json['uCode'];
    uName = json['uName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['shopCd'] = shopCd;
    data['optGrpCd'] = optGrpCd;
    data['prodCd'] = prodCd;
    data['uCode'] = uCode;
    data['uName'] = uName;
    return data;
  }
}