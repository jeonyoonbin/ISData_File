import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/models/Common/commonNoFlagModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionSoldOutEditModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class CommonNoFlagEdit extends StatefulWidget {
  final String? jobGbn;
  final String? subGbn;
  final String? targetCd;
  final String? noFlag;
  const CommonNoFlagEdit({Key? key, this.jobGbn, this.subGbn, this.targetCd, this.noFlag})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CommonNoFlagEditState();
  }
}

enum RadioNoFlagGbn { noflagGbnY, noflagGbnN }

class CommonNoFlagEditState extends State<CommonNoFlagEdit> {

  CommonNoFlagModel formData = CommonNoFlagModel();

  RadioNoFlagGbn? _radioNoFlagGbn;

  DateTime? soldOutDateTimeSelected;
  String? selectSoldOutStr;

  String getTitleStr(){
    String? tempStr = '';

    if (widget.subGbn == 'M'){
      tempStr = widget.jobGbn == 'D' ? '메뉴 품절' : '상품 품절';
    }
    else if (widget.subGbn == 'O'){
      tempStr = '옵션 품절';
    }

    return tempStr;
  }

  @override
  void dispose() {
    super.dispose();
    formData = CommonNoFlagModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    _radioNoFlagGbn = widget!.noFlag == 'Y' ? RadioNoFlagGbn.noflagGbnN : RadioNoFlagGbn.noflagGbnY;

    formData.jobGbn = widget.jobGbn;
    formData.subGbn = widget.subGbn;
    formData.shopCd = AuthService.SHOPCD;
    formData.targetCd = widget.targetCd;
    formData.noFlag = widget.noFlag;
    formData.uCode = AuthService.uCode;
    formData.uName = AuthService.uName;
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 225),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text(getTitleStr(), style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //const Divider(color: Colors.grey, height: 0.0,),
              const SizedBox(height: 12,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('${getTitleStr()} 여부', style: const TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                  Row(
                    children: [
                      Radio(
                          value: RadioNoFlagGbn.noflagGbnY,
                          groupValue: _radioNoFlagGbn,
                          onChanged: (v) async {
                            setState(() {
                              _radioNoFlagGbn = v as RadioNoFlagGbn?;

                              formData.noFlag = 'N';
                            });
                          }),
                      const Text('판매중', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      const SizedBox(width: 20,),
                      Radio(
                          value: RadioNoFlagGbn.noflagGbnN,
                          groupValue: _radioNoFlagGbn,
                          onChanged: (v) async {


                            setState(() {
                              _radioNoFlagGbn = v as RadioNoFlagGbn?;

                              formData.noFlag = 'Y';
                            });
                          }),
                      const Text('품절', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      const SizedBox(width: 16,),
                    ],
                  )
                ],
              ),
              const SizedBox(height: 10,),
              // 추후 품절제한시간 기능 적용시 주석해제필요
              // if (_radioSoldOutGbn == RadioSoldOutGbn.soldOutGbnN)
              //   Column(
              //     mainAxisAlignment: MainAxisAlignment.start,
              //     crossAxisAlignment: CrossAxisAlignment.start,
              //     children: [
              //       const Divider(),
              //       SizedBox(
              //         width: double.infinity,
              //         child: Column(
              //           mainAxisAlignment: MainAxisAlignment.center,
              //           crossAxisAlignment: CrossAxisAlignment.center,
              //           children: [
              //             fluentUI.DatePicker(
              //               locale: const Locale('ko', 'KR'),
              //               header: '품절 해제 일시',
              //               headerStyle: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
              //               selected: soldOutDateTimeSelected,
              //               onChanged: (time) {
              //                 setState(() {
              //                   soldOutDateTimeSelected = time;
              //
              //                   String yearMonthDay = DateFormat('yy.MM.dd').format(soldOutDateTimeSelected!);
              //                   String dayChar = DateFormat.E('ko_KR').format(soldOutDateTimeSelected!);
              //                   String hourMinute = DateFormat('aa hh시mm분', 'ko').format(soldOutDateTimeSelected!);
              //
              //                   selectSoldOutStr = '${yearMonthDay}(${dayChar}) ${hourMinute}에 품절이 해제됩니다.';
              //                 });
              //               },
              //             ),
              //             const SizedBox(height: 8,),
              //             fluentUI.TimePicker(
              //               selected: soldOutDateTimeSelected,
              //               onChanged: (time) {
              //                 setState(() {
              //                   soldOutDateTimeSelected = time;
              //
              //                   String yearMonthDay = DateFormat('yy.MM.dd').format(soldOutDateTimeSelected!);
              //                   String dayChar = DateFormat.E('ko_KR').format(soldOutDateTimeSelected!);
              //                   String hourMinute = DateFormat('aa hh시mm분', 'ko').format(soldOutDateTimeSelected!);
              //
              //                   selectSoldOutStr = '${yearMonthDay}(${dayChar}) ${hourMinute}에 품절이 해제됩니다.';
              //                 });
              //               },
              //             ),
              //           ],
              //         ),
              //       ),
              //       const SizedBox(height: 10,),
              //       Row(
              //         children: [
              //           if (selectSoldOutStr != null)
              //             Container(
              //               width: 30,
              //               height: 16,
              //               alignment: Alignment.center,
              //               color: Colors.red,
              //               child: const Center(child: Text('품절', style: TextStyle(fontSize: 8, fontFamily: FONT_FAMILY, color: Colors.white),)),
              //             ),
              //           const SizedBox(width: 8,),
              //           Text(selectSoldOutStr == null ? '' : selectSoldOutStr!, style: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY)),
              //         ],
              //       ),
              //       const Divider(),
              //     ],
              //   ),
              // if (_radioSoldOutGbn == RadioSoldOutGbn.soldOutGbnY)
              //   const SizedBox(height: 156,),
              //
              // const SizedBox(height: 8,),
              // const Text('※ 품절은 가게 오픈 시간에 맞춰 해제됩니다. 품절 설정 후 변경된 운영시간은 반영되지 않습니다.', style: TextStyle(fontSize: 12, color: Colors.black45, fontFamily: FONT_FAMILY)),
              //const Divider(),
            ],
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              ISConfirm(context, getTitleStr(), '${getTitleStr()} 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  var value = await showDialog(
                      context: context,
                      barrierColor: Colors.transparent,
                      builder: (context) => FutureProgressDialog(ProductInfoController.to.updateNoFlag(formData.toJson()))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


