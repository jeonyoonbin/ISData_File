import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/Common/commonNoFlagModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/solodOutMenuListModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class SoldOutMenuInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const SoldOutMenuInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<SoldOutMenuInfoMain> createState() => _SoldOutMenuInfoMainState();
}

class _SoldOutMenuInfoMainState extends State<SoldOutMenuInfoMain> {
  final List<SoldOutMenuListModel> dataList = <SoldOutMenuListModel>[];

  bool isGroupProduct = true;
  bool isGroupMenu = false;
  late List<bool> isGroupSelected;

  String currentJobGbn = 'D';

  String prodCnt = '0';
  String menuCnt = '0';

  requestAPIData() async {
    bool isProductUse = (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER || AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET || AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET) ? true : false;

    currentJobGbn = (isProductUse == true && isGroupProduct == true) ? 'F' : 'D';

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getProductNoFlagList(currentJobGbn, 'M'))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        SoldOutMenuListModel temp = SoldOutMenuListModel();
        temp.code = (isGroupProduct == true) ? element['prodCd'] as String : element['menuCd'] as String;
        temp.name = (isGroupProduct == true) ? element['name'] as String : element['menuName'] as String;
        temp.cost = (isGroupProduct == true) ? element['cost'] as String : element['menuCost'] as String;
        temp.useGbn = element['useGbn'] as String;
        temp.noFlag = element['noFlag'] as String;
        temp.mainYn = (isGroupProduct == true) ? element['mainYn'] as String : '';
        temp.ribbonCardYn = (isGroupProduct == true) ? element['ribbonCardYn'] as String : '';
        temp.adultOnly = (isGroupProduct == true) ? '' : element['adultOnly'] as String;
        temp.singleOrderYn = (isGroupProduct == true) ? '' : element['singleOrderYn'] as String;

        dataList.add(temp);
      });

      prodCnt = ProductInfoController.to.prodCnt;
      menuCnt = ProductInfoController.to.menuCnt;
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    isGroupSelected = [isGroupProduct, isGroupMenu];

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    isGroupSelected.clear();
    dataList.clear();
  }

void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET
    //     ? (isGroupProduct = true, isGroupMenu = false)
    //     : AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER
    //     ? (isGroupProduct = true, isGroupMenu = false)
    //     : (isGroupProduct = false, isGroupMenu = true);

    (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET || AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER || AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET)
        ? (isGroupProduct = true, isGroupMenu = false)
        : (isGroupProduct = false, isGroupMenu = true);

    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          elevation: 1,
          shape: appTheme.cardShapStyle,
          child: Container(
            constraints: const BoxConstraints(minWidth: double.infinity),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: SingleChildScrollView(
                scrollDirection: Responsive.isMobile(context) ? Axis.horizontal : Axis.vertical,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET)...[
                      ToggleButtons(
                        constraints: const BoxConstraints(minWidth: 160, minHeight: 40),
                        borderRadius: const BorderRadius.all(Radius.circular(4)),
                        isSelected: isGroupSelected,
                        onPressed: (value) async {
                          if (value == 0) {
                            isGroupProduct = true;
                            isGroupMenu = false;
                          } else {
                            isGroupProduct = false;
                            isGroupMenu = true;
                          }

                          await requestAPIData();

                          setState(() {
                            isGroupSelected = [isGroupProduct, isGroupMenu];
                          });
                        },
                        children: [
                          Padding(
                              padding: const EdgeInsets.symmetric(horizontal:  16),
                              child: Text('장보기 상품 ($prodCnt)개', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY))
                          ),
                          Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: Text('우리 가게 메뉴 ($menuCnt)개', style:const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY))
                          ),
                        ],
                      ),
                    ]
                    else...[
                      Text(AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER || AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET ? '상품 품절' : '메뉴 품절', style: const TextStyle(fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                    ],
                    const SizedBox.shrink()
                    // ISInput(
                    //   value: tempStr,
                    //   width: 260,
                    //   label: ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '메뉴명으로 검색해 보세요.' : '상품명으로 검색해 보세요.',
                    //   prefixIcon: const Icon(Icons.search, color: Colors.black54,),
                    //   onChange: (v) {
                    //     tempStr = v;
                    //
                    //   },
                    // )
                  ],
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 4),
        //const Divider(color: Colors.black,),//fluentUI.Divider(style: fluentUI.DividerThemeData(horizontalMargin: EdgeInsets.zero)),
        itemListView(),
      ],
    );
  }

  Widget itemListView() {
    final appTheme = context.watch<AppTheme>();

    return SizedBox(
      height: (widget.tabviewHeight! - (Responsive.isMobile(context) == true ? 104 : 74)),
      child: ListView.builder(
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          itemBuilder: (ctx, index) {
            return Card(
              elevation: 1,
              shape: appTheme.cardShapStyle,
              child: Padding(
                key: Key('$index'),
                padding: EdgeInsets.symmetric(horizontal: Responsive.isMobile(context) ? 5 : 16.0),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Flexible(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Container(
                            padding: const EdgeInsets.only(left: 4, right: 0, top: 8, bottom: 2),
                            alignment: Alignment.topLeft,
                            child: Column(
                              children: <Widget>[
                                Row(
                                  children: [
                                    dataList[index].useGbn == 'Y'
                                        ? Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                        child: const Center(
                                            child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                            ))
                                    ) : Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                        child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                    ),
                                    dataList[index].ribbonCardYn == 'Y'
                                        ? Container(
                                      width: 44,
                                      height: 18,
                                      margin: const EdgeInsets.only(left: 2.0),
                                      alignment: Alignment.center,
                                      decoration: AppTheme.getListBadgeDecoration(Colors.blueAccent.shade100),
                                      child: const Center(child: Text('리본/카드', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                      ),
                                    ) : const SizedBox.shrink(),
                                    dataList[index].mainYn == 'Y'
                                        ? Container(
                                        width: 26,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(141, 65, 217, 1.0)),
                                        child: const Center(child: Text('대표', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                    dataList[index].noFlag == 'Y'
                                        ? Container(
                                        width: 26,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.redAccent.shade100),
                                        child: const Center(child: Text('품절', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                    dataList[index].adultOnly == 'Y'
                                        ? Container(
                                      width: 26,
                                      height: 18,
                                      margin: const EdgeInsets.only(left: 2.0),
                                      alignment: Alignment.center,
                                      decoration: AppTheme.getListBadgeDecoration(Colors.red),
                                      child: const Center(child: Text('성인', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)),
                                    ) : const SizedBox.shrink(),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: Text(dataList[index].name ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY),),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(left: 4, right: 10, top: 2, bottom: 8),
                            alignment: Alignment.topLeft,
                            child: Text('${Utils.getCashComma(dataList[index].cost!)} 원', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                          ),
                        ],
                      ),
                    ),
                    // Padding(
                    //   padding: const EdgeInsets.fromLTRB(0, 0, 30, 0),
                    //   child: ToggleButtons(
                    //     constraints: const BoxConstraints(minWidth: 80, minHeight: 30),
                    //     fillColor: Colors.blueAccent,
                    //     selectedColor: Colors.white,
                    //     selectedBorderColor: Colors.blueAccent,
                    //     textStyle: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY),
                    //     borderRadius: const BorderRadius.all(Radius.circular(4)),
                    //     isSelected: dataList[index].isSelected!,
                    //     onPressed: (value) {// 0: 판매중, 1: 품절
                    //       //dataList[index].noFlag = (value == 0) ? 'N': 'Y';
                    //       showDialog(
                    //         context: context,
                    //         barrierDismissible: true,
                    //         builder: (context) => CommonNoFlagEdit(jobGbn: 'F', subGbn: 'M', targetCd: dataList[index].prodCd, noFlag: dataList[index].noFlag),
                    //       ).then((value) async {
                    //         if (value == true){
                    //           await Future.delayed(const Duration(milliseconds: 500), () {
                    //             requestAPIData();
                    //           });
                    //         }
                    //       });
                    //     },
                    //     children: const [
                    //       Text('판매중', style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                    //       Text('품절', style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY))
                    //     ],
                    //   ),
                    // ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 20, 0),
                      child: OutlinedButton(
                        style: ButtonStyle(side: MaterialStateProperty.all(const BorderSide(color: Colors.red))),
                        onPressed: () {
                          ISConfirm(context, '품절 해제', '해당 상품을 품절 해제하시겠습니까?', (context, isOK) async {
                            Navigator.of(context).pop();

                            if (isOK){
                              CommonNoFlagModel formData = CommonNoFlagModel();

                              formData.jobGbn = currentJobGbn;
                              formData.subGbn = 'M';
                              formData.shopCd = AuthService.SHOPCD;
                              formData.targetCd = dataList[index].code;
                              formData.noFlag = 'N';
                              formData.uCode = AuthService.uCode;
                              formData.uName = AuthService.uName;

                              var value = await showDialog(
                                  context: context,
                                  barrierColor: Colors.transparent,
                                  builder: (context) => FutureProgressDialog(ProductInfoController.to.updateNoFlag(formData.toJson()))
                              );

                              if (value == null) {
                                ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                              }
                              else {
                                if (value == '00') {
                                  requestAPIData();
                                }
                                else{
                                  ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                }
                              }
                            }
                          });
                        },
                        child: const Text('품절 해제', style: TextStyle(color: Colors.red),),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
          //separatorBuilder: (BuildContext context, int index) { return const Divider(thickness: 1, height: 0.0,); },
          itemCount: dataList.length
      ),
    );
  }
}