


import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';

class FAQShopInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const FAQShopInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<FAQShopInfoMain> createState() => _FAQShopInfoMainState();
}

class _FAQShopInfoMainState extends State<FAQShopInfoMain> {

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    fluentUI.ButtonState<Color> headerColor = fluentUI.ButtonState.resolveWith((states) => Colors.grey.shade200);
    const headerTextStyle = TextStyle(fontSize: 16, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);
    const contentTextStyle = TextStyle(fontSize: 15, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, height: 2);//letterSpacing: 0.6,

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FAQform(headerColor, headerTextStyle, contentTextStyle,'"대구로"란 어떤 건가요?','대구시와 인성데이타 주식회사가 협업을 통하여 운영하게 되는 대구형 배달앱이며, 서비스 품질 향상, 수수료 및 운영비 부담 경감, 음식점 운영 효율화, 시민 편익 증진을 목표로 하고 있습니다.\n현재는 배달앱으로서 도약을 위해 준비하고 있으며, 차후 택시, 대리운전, 퀵 서비스, 문화 시설 예약 등 모든 생활 편의 서비스를 집약한 앱이 되기를 목표로 하고 있습니다.\n현재 배달앱으로서 카드 결제 즉시 정산, 행복페이 온라인 결제 및 추가 할인 등 다른 배달앱과는 차별화하여, 대구로의 모든 이해관계자들이 만족할 수 있도록 하고, 활성화될 수 있도록 노력하겠습니다.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[입점 신청] 입점 신청 방법이 궁금해요.','신청은 대구로 홈페이지(www.daeguro.co.kr)를 통해 간편 입점 신청을 할 수 있습니다.\n신청이 완료되면, 담당자가 순차적으로 연락 후 방문해 드릴 예정입니다.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[입점 신청] 입점 신청했는데 연락이 안 와요.','늦어져서 죄송합니다.\n현재 입점 문의가 많이 들어오고 있기 때문에 순차적으로 연락을 드리고 있습니다.\n기다려주시면 담당자가 순차적으로 확인 및 연락을 하고 방문 드릴 예정입니다.\n혹시나 입점 신청을 한 지 2주 이상 아무 연락이 없다면, 카카오톡 채널을 통해서 문의해 주시거나, 고객센터(1661-3773)로 전화 주시면 확인해 드리도록 하겠습니다.',56),
          FAQform(headerColor, headerTextStyle,contentTextStyle,'[입점 신청] 입점할 때 필요한 서류에는 뭐가 있나요?','개인 사업자일 경 우,\n1) 사업자등록증 2) 대표자 신분증 3) 통장 사본 4) 영업 신고증을 준비해 주세요.\n만약 법인 사업자일 경우, 추가적으로 법인 등기부등본 확인이 필요합니다.\n추가적으로 앱에 등록할 메뉴 이미지, 로고 이미지가 있다면 준비해 주세요.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[입점 신청] 제 사업자등록번호가 왜 중복으로 뜨나요?','고객센터(1661-3773)으로 문의해 주세요.',56),
            FAQform(headerColor, headerTextStyle, contentTextStyle,'[배달] 배달 대행사를 쓰게 되면 자동으로 연동이 되나요?','현재 배달 대행사들에게 API를 제공하여 저희 주문 정보를 배달 대행 프로그램으로 전송할 수 있도록 대구 지역에 있는 많은 배달 대행사들을 상대로 협조 요청을 진행 중입니다.\n현재는 생각대로 배달대행, 비욘드 딜리버리 배달 연동을 제공하고 있으며, 차후 다른 배달 대행사 연동 작업도 진행 예정입니다.',56),
        ],
          ),
    );
  }


  Widget FAQform(fluentUI.ButtonState<fluentUI.Color> headerColor, fluentUI.TextStyle headerTextStyle, fluentUI.TextStyle contentTextStyle, headerText, contentText, headerHeight) {
    return fluentUI.Expander(
        headerHeight: headerHeight,
        contentPadding: EdgeInsets.symmetric(vertical: 10,horizontal: 10),
              headerBackgroundColor: headerColor,
              shapeRadius: 0.0,
              contentBackgroundColor: Colors.transparent,
        header: Text(headerText, style: headerTextStyle),
        content: SingleChildScrollView(
            child: Text(contentText,
                      style: contentTextStyle)
              )
    );
  }

  requestAPIData() async {
  }


}