import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopTypeGbnEdit extends StatefulWidget {
  final ShopInfoModel? sData;
  const ShopTypeGbnEdit({Key? key, this.sData}) :
        super(key: key);

  @override
  State<ShopTypeGbnEdit> createState() {
    return ShopTypeGbnEditState();
  }
}

class ShopTypeGbnEditState extends State<ShopTypeGbnEdit> {
  ShopInfoModel formData = ShopInfoModel();

  @override
  void dispose() {
    super.dispose();
    formData = ShopInfoModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    formData = widget.sData!;

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
    });
  }


  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 260),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('매장 유형', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 12,),
              const Text('매장 유형', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
              const Text('매장 유형을 선택해 주세요.', style: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
              const SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ISCheckbox(
                      label: '배달 가능',
                      value: formData.deliAvailable,
                      onChanged: (v) => setState(() => formData.deliAvailable = v!)
                  ),
                  ISCheckbox(
                      label: '포장 가능',
                      value: formData.packAvailable,
                      onChanged: (v) => setState(() => formData.packAvailable = v!)
                  ),
                  // ISCheckbox(
                  //     label: '예약 가능',
                  //     value: formData.reservAvailable,
                  //     onChanged: (v) => setState(() => formData.reservAvailable = v!)
                  // ),
                ],
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              BuildContext oldContext = context;

              if(formData.deliAvailable == false &&formData.packAvailable == false){
                ISAlert(oldContext, title: '알림', content: '반드시 한가지 유형을 선택해야 합니다.\n휴업 시 영업상태를 휴점중으로 변경해 주세요.');
                return;
              }

              ISConfirm(context, '매장 유형 변경', '매장 유형을 변경합니다. \n\n계속 진행하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  List<String> sendDataParam = [];
                  if (formData.deliAvailable == true)    sendDataParam.add('5');
                  if (formData.packAvailable == true)      sendDataParam.add('7');
                  // if (formData.reservAvailable == true)   sendDataParam.add('9');

                  String sendData = sendDataParam.join(',');

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ShopController.to.updateShopInfo('9', sendData.toString(), '', ''))
                  );

                  if (value == '00') {
                    Navigator.of(oldContext).pop(true);
                    ISAlert(oldContext, title: '알림', content: '변경이 완료되었습니다.');
                  }
                  else {
                    ISAlert(context, content: '정상 등록되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
                  }
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}
