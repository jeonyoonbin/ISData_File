import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/iswidgets/timepicker/is_selectTime.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateHourListModel.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopOperateHourEdit extends StatefulWidget {
  final ShopOperateHourListModel? sData;
  final List<ShopOperateHourListModel>? sListData;
  const ShopOperateHourEdit({Key? key, this.sData, this.sListData})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopOperateHourEditState();
  }
}

class ShopOperateHourEditState extends State<ShopOperateHourEdit> {
  ShopOperateHourListModel formData = ShopOperateHourListModel();

  String? frStandTimeSelected;
  String? toStandTimeSelected;

  List<ISOptionModel> selectDayList = [];
  List<String> sListDataTipDay = [];
  List dayState = [false, false, false, false, false, false, false, false, false, false];
  List checkBoxColor = [false, false, false, false, false, false, false, false, false, false];
  List<String> sendDayIndex = [];

  String _dayGbn(String gbn) {
    if(gbn == '1')        {      return '일요일';    }
    else if (gbn == '2')  {      return '월요일';    }
    else if (gbn == '3')  {      return '화요일';    }
    else if (gbn == '4')  {      return '수요일';    }
    else if (gbn == '5')  {      return '목요일';    }
    else if (gbn == '6')  {      return '금요일';    }
    else                  {      return '토요일';    }
  }

  @override
  void dispose() {
    super.dispose();
    formData = ShopOperateHourListModel();
    selectDayList.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    formData = widget.sData!;

    if (formData.jobGbn == 'I'){
      frStandTimeSelected = '0900';
      toStandTimeSelected = '2359';

      formData.tipNextDay = 'N';

      selectDayList.clear();
      if (widget.sListData == null || widget.sListData!.isEmpty){
          for (int i = 1; i<7; i++){
            selectDayList.add(ISOptionModel(value: i.toString(), label: _dayGbn(i.toString())));
          }
          selectDayList.add(ISOptionModel(value: 7, label: '토요일'));
      }
      else{
        widget.sListData!.forEach((element) {
          switch (element.tipDay) {
            case '1':
              dayState[1] = true;
              checkBoxColor[1] = true;
              sListDataTipDay.add('1');
              break;
            case '2':
              dayState[2] = true;
              checkBoxColor[2] = true;
              sListDataTipDay.add('2');
              break;
            case '3':
              dayState[3] = true;
              checkBoxColor[3] = true;
              sListDataTipDay.add('3');
              break;
            case '4':
              dayState[4] = true;
              checkBoxColor[4] = true;
              sListDataTipDay.add('4');
              break;
            case '5':
              dayState[5] = true;
              checkBoxColor[5] = true;
              sListDataTipDay.add('5');
              break;
            case '6':
              dayState[6] = true;
              checkBoxColor[6] = true;
              sListDataTipDay.add('6');
              break;
            case '7':
              dayState[7] = true;
              checkBoxColor[7] = true;
              sListDataTipDay.add('7');
              break;
            default:
              break;
          }
        });
      }
    }
    else{
      frStandTimeSelected = formData.tipFrStand;
      toStandTimeSelected = formData.tipToStand;

      selectDayList.clear();
      selectDayList.add(ISOptionModel(value: formData.tipDay, label: _dayGbn(formData.tipDay!)));
    }

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return widget.sListData == null ? editDataDialog(context, appTheme) : insertDataDialog(context, appTheme);
  }

  editDataDialog(fluentUI.BuildContext context, AppTheme appTheme) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
      constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('영업일 설정', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12,),
                const Text('요일별 정기 영업시간', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                // const Text('※ 중복 선택시, 최소 시간 및 최대 시간이 사용자 앱에 적용됩니다.', style: TextStyle(color: Colors.black54,fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                // const Text('   ex) 10분 ~ 120분', style: TextStyle(color: Colors.black54,fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                // const Text('※ 소요시간 미 선택시, POS 기본 설정 시간이 적용됩니다.', style: TextStyle(color: Colors.black54, fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                const SizedBox(height: 16),
                ISLabelBarSub(
                  title: '정기 영업 일시',
                  body: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const SizedBox(width: 110, child: Text('영업일', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                          const SizedBox(width: 8),
                          ISSearchDropdown(
                            label: '영업일',
                            value: formData.tipDay,
                            width: Responsive.isMobile(context) ? 170 : 200,
                            ignoring: (formData.jobGbn == 'I') ? false : true,
                            onChange: (value) {
                              setState(() {
                                formData.tipDay = value;
                              });
                            },
                            item: selectDayList
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                       Column(
                        children: [
                          Row(
                            children: [
                              const SizedBox(
                                  width: 110,
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 20.0),
                                    child: Text('영업 시작 시간', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                  )),
                              const SizedBox(width: 8,),
                              SizedBox(
                                width: Responsive.isMobile(context) ? 210 : 200,
                                child: ISSelectTime(
                                  title: '',
                                  hour: frStandTimeSelected !.substring(0, 2),
                                  minute: frStandTimeSelected !.substring(2, 4),
                                  onTimeSelected: (time) {
                                    setState(() {
                                      frStandTimeSelected  = time;
                                      formData.tipNextDay = (int.parse(frStandTimeSelected !) > int.parse(toStandTimeSelected!)) ? 'Y' : 'N';
                                    });
                                  },
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const SizedBox(
                                  width: 110,
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 20.0),
                                    child: Text('영업 종료 시간', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                  )),
                              const SizedBox(width: 8,),
                              SizedBox(
                                width: Responsive.isMobile(context) ? 210 : 200,
                                child: ISSelectTime(
                                  title: formData.tipNextDay == 'Y' ? '[다음날]' : '',
                                  hour: toStandTimeSelected!.substring(0, 2),
                                  minute: toStandTimeSelected!.substring(2, 4),
                                  onTimeSelected: (time) {
                                    setState(() {
                                      toStandTimeSelected = time;
                                      formData.tipNextDay = (int.parse(frStandTimeSelected !) > int.parse(toStandTimeSelected!)) ? 'Y' : 'N';
                                    });
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      )
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              ISConfirm(context, widget.sListData == null ? '영업일 변경' : '영업일 등록', '영업일을 변경합니다.\n\n계속 진행하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  ShopOperateEditModel sendData = ShopOperateEditModel();
                  sendData.shopCd = AuthService.SHOPCD;
                  sendData.modUcode = AuthService.uCode;
                  sendData.modName = AuthService.uName;
                  sendData.jobGbn = '4';
                  sendData.day = formData.tipDay;
                  sendData.frTime = frStandTimeSelected;
                  sendData.toTime = toStandTimeSelected;
                  sendData.nextDay = formData.tipNextDay;

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ShopController.to.updateOperateInfo(sendData.toJson()))
                  );

                  if (value == '00') {
                    Navigator.of(context).pop(true);
                    ISAlert(context, title: '알림', content: '변경이 완료되었습니다.');
                  }
                  else {
                    ISAlert(context, content: '정상 등록되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
                  }
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
  ),
    );
  }
  insertDataDialog(fluentUI.BuildContext context, AppTheme appTheme) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: BoxConstraints(maxWidth: 460.0, maxHeight: Responsive.isMobile(context) ? 425 : 370),
        contentPadding: const EdgeInsets.all(0.0),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            const Text('영업일 설정', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ISLabelBarSub(
                  title: '요일',
                  bodyPadding: EdgeInsets.zero,
                  body: Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 8.0,
                    children: [
                    ISCheckbox(label: '월', value: dayState[2], activeColor: checkBoxColor[2] == true ? const Color(0xffd3d3d3) : null, onChanged: (v) {
                        setState(() {
                          if((!sListDataTipDay.contains('2'))){
                            dayState[2] = v;
                            if(dayState[2]){
                              sendDayIndex.add('2');
                            }else{
                              sendDayIndex.removeWhere((element) => element == '2');
                            }
                          }
                        });
                      }),
                    ISCheckbox(label: '화', value: dayState[3], activeColor: checkBoxColor[3] == true ? const Color(0xffd3d3d3) : null, onChanged: (v) {
                        setState(() {
                          if((!sListDataTipDay.contains('3'))){
                            dayState[3] = v;
                            if(dayState[3]){
                              sendDayIndex.add('3');
                            }else{
                              sendDayIndex.removeWhere((element) => element == '3');
                            }
                          }
                        });
                      }),
                    ISCheckbox(label: '수', value: dayState[4], activeColor: checkBoxColor[4] == true ? const Color(0xffd3d3d3) : null, onChanged: (v) {
                        setState(() {
                          if((!sListDataTipDay.contains('4'))){
                            dayState[4] = v;
                            if(dayState[4]){
                              sendDayIndex.add('4');
                            }else{
                              sendDayIndex.removeWhere((element) => element == '4');
                            }
                          }
                        });
                      }),
                    ISCheckbox(label: '목', value: dayState[5], activeColor: checkBoxColor[5] == true ? const Color(0xffd3d3d3) : null, onChanged: (v) {
                        setState(() {
                          if((!sListDataTipDay.contains('5'))){
                            dayState[5] = v;
                            if(dayState[5]){
                              sendDayIndex.add('5');
                            }else{
                              sendDayIndex.removeWhere((element) => element == '5');
                            }
                          }
                        });
                      }),
                    ISCheckbox(label: '금', value: dayState[6], activeColor: checkBoxColor[6] == true ? const Color(0xffd3d3d3) : null, onChanged: (v) {
                        setState(() {
                          if((!sListDataTipDay.contains('6'))){
                            dayState[6] = v;
                            if(dayState[6]){
                              sendDayIndex.add('6');
                            }else{
                              sendDayIndex.removeWhere((element) => element == '6');
                            }
                          }
                        });
                      }),
                    ISCheckbox(label: '토', value: dayState[7], activeColor: checkBoxColor[7] == true ? const Color(0xffd3d3d3) : null, onChanged: (v) {
                        setState(() {
                          if((!sListDataTipDay.contains('7'))){
                            dayState[7] = v;
                            if(dayState[7]){
                              sendDayIndex.add('7');
                            }else{
                              sendDayIndex.removeWhere((element) => element == '7');
                            }
                          }
                        });
                      }),
                    ISCheckbox(label: '일', value: dayState[1], activeColor: checkBoxColor[1] == true ? const Color(0xffd3d3d3) : null, onChanged: (v) {
                        setState(() {
                          if((!sListDataTipDay.contains('1'))){
                            dayState[1] = v;
                            if(dayState[1]){
                              sendDayIndex.add('1');
                            }else{
                              sendDayIndex.removeWhere((element) => element == '1');
                            }
                          }
                        });
                      }),
                    ],
                  ),
                  trailing: null,
                ),
                const Divider(height: 1),
                ISLabelBarSub(
                  title: '적용 시간',
                  body: SingleChildScrollView(
                    scrollDirection: Responsive.isMobile(context) ? Axis.horizontal : Axis.vertical,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        ISSelectTime(
                          title: '시작 시간',
                          hour: frStandTimeSelected!.substring(0, 2),
                          minute: frStandTimeSelected!.substring(2, 4),
                          onTimeSelected: (time) {
                            setState(() {
                              frStandTimeSelected = time;
                              formData.tipNextDay = (int.parse(frStandTimeSelected!) > int.parse(toStandTimeSelected!)) ? 'Y' : 'N';
                            });
                          },
                        ),
                        ISSelectTime(
                          title: formData.tipNextDay == 'Y' ? '종료 시간  [다음날]' : '종료 시간',
                          hour: toStandTimeSelected!.substring(0, 2),
                          minute: toStandTimeSelected!.substring(2, 4),
                          onTimeSelected: (time) {
                            setState(() {
                              toStandTimeSelected = time;
                              formData.tipNextDay = (int.parse(frStandTimeSelected!) > int.parse(toStandTimeSelected!)) ? 'Y' : 'N';
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                  trailing: null,
                ),
              ],
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () async {

                await Future.forEach(sendDayIndex, (element) async {
                  ShopOperateEditModel sendData = ShopOperateEditModel();
                  sendData.shopCd = AuthService.SHOPCD;
                  sendData.modUcode = AuthService.uCode;
                  sendData.modName = AuthService.uName;
                  sendData.jobGbn = '4';
                  sendData.day = element;
                  sendData.frTime = frStandTimeSelected;
                  sendData.toTime = toStandTimeSelected;
                  sendData.nextDay = formData.tipNextDay;

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ShopController.to.updateOperateInfo(sendData.toJson()))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                    return;
                  }
                });
                Navigator.of(context).pop();
                ISAlert(context, content: '등록이 완료되었습니다.');

              },
              child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }

  // setTipDayTime(){
  //   // 시작 시간
  //   String frTime = DateFormat('HH mm').format(frStandTimeSelected!);
  //   List<String> frTimeArr = frTime.split(' ');
  //   if (frTimeArr.isEmpty == false) {
  //     formData.tipFrStand = '${frTimeArr[0]}${frTimeArr[1]}';
  //   }
  //
  //   // 종료 시간
  //   String toTime = DateFormat('HH mm').format(toStandTimeSelected!);
  //   List<String> toTimeArr = toTime.split(' ');
  //   if (toTimeArr.isEmpty == false) {
  //     formData.tipToStand = '${toTimeArr[0]}${toTimeArr[1]}';
  //   }
  //
  //   if (int.parse(formData.tipFrStand!) > int.parse(formData.tipToStand!)){//if (frTimeArr[0] == 'PM' && toTimeArr[0] == 'AM'){
  //     formData.tipNextDay = 'Y';
  //   }
  //   else{
  //     formData.tipNextDay = 'N';
  //   }
  // }
}


