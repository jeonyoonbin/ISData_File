import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveShopUpdateNoticeModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ReserveShopUpdateNoticeEdit extends StatefulWidget {
  final String? notice;
  final String ? ccCode;
  const ReserveShopUpdateNoticeEdit({Key? key, this.notice, this.ccCode})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ReserveShopUpdateNoticeEditState();
  }
}

class ReserveShopUpdateNoticeEditState extends State<ReserveShopUpdateNoticeEdit> {
  String? setNotice;

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    setNotice = widget.notice!;

    Get.put(ShopController());
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 640),
        contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            const Text('매장 알림', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Material(
            color: Colors.transparent,
            borderOnForeground: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12,),
                  const Text('매장을 소개할 소개글을 입력해 주세요.(매장 소개, 혜택 등)', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  const SizedBox(height: 10),
                  ISInput(
                    autofocus: true,
                    value: setNotice == 'null' ? '' : setNotice,
                    //padding: 0,
                    height: 200,
                    maxLines: 10,
                    label: '한 줄 매장 소개',
                    maxLength: 2000,
                    keyboardType: TextInputType.multiline,
                    onChange: (v) {
                      setNotice = v;
                    },
                  ),
                  SizedBox(height: 10)
                ],
              ),
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () async {
                ISConfirm(context, '매장 알림 변경', '매장 알림 정보를 변경합니다. \n\n계속 진행하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                  Navigator.of(context).pop();
                  if (isOK){
                    ReserveShopUpdateNoticeModel sendData = ReserveShopUpdateNoticeModel();

                    sendData.shopCd = AuthService.SHOPCD;
                    sendData.ccCode = widget.ccCode.toString();
                    sendData.notice = setNotice.toString();
                    sendData.userID = AuthService.uCode;

                    var value = await showDialog(
                        context: context,
                        builder: (context) => FutureProgressDialog(ReserveController.to.updateReserveShopNotice(sendData.toJson()))
                    );

                    if (value == null) {
                      // ignore: use_build_context_synchronously
                      ISAlert(context, content: '매장 알림 수정에 실패했습니다. \n\n관리자에게 문의 바랍니다');
                      return;
                    }
                    else{
                      Navigator.of(context).pop(true);
                      ISAlert(context, title: '알림', content: '변경이 완료되었습니다.');
                    }
                  }
                });
              },
              child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }
}


