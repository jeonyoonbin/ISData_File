import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_datatable.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveTimeScheduleModel.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/instance_manager.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class ReserveTimeScheduleMain extends StatefulWidget {
  const ReserveTimeScheduleMain({Key? key}) : super(key: key);

  @override
  State<ReserveTimeScheduleMain> createState() => _ReserveTimeScheduleMainState();
}

class _ReserveTimeScheduleMainState extends State<ReserveTimeScheduleMain> with PageMixin {
  String? date = '';
  String selectedYN = '';
  List<ReserveTimeScheduleModel> dataList = <ReserveTimeScheduleModel>[];
  Color? buttonColor;

  requestAPIData() async {
    var value = await showDialog(context: context, barrierColor: Colors.transparent,builder: (context) => FutureProgressDialog(ReserveController.to.getReserveTimeScheduleList(date!.replaceAll('-', ''))));
    if (value == null) {
      ISAlert(context, content: '영업시간이 설정되어 있지 않습니다.');
    } else {
      dataList.clear();
      selectedYN = '';
      value.forEach((element) {
        ReserveTimeScheduleModel temp = ReserveTimeScheduleModel();
        temp.orderDate = element['orderDate'] as String;
        temp.time = element['time'].toString();
        temp.reserYN = element['reserYN'] as String;
        temp.cnt = element['cnt'];
        temp.personCnt = element['personCnt'];
        dataList.add(temp);
      });
    }
    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());

    date = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) async {
      requestAPIData();
    });
  }

  @override
  void dispose() {

    super.dispose();
    dataList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    double contentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 398 : 400);
    TextStyle columnTextStyle = const TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY);

    return fluentUI.ScaffoldPage.withPadding(
      resizeToAvoidBottomInset: false,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ISLabelBarMain(
              leading: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text('시간별 예약 현황', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold)),
                  const SizedBox(width: 6),
                  Responsive.isMobile(context) ? Container() : const Text("※ 상태를 변경하시려면 '가능' / '마감' 버튼을 클릭해 주세요.", style: TextStyle(color: Colors.grey, fontSize: 14)),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Responsive.isMobile(context) == true ? Column(children: searchBarView()) : Row(children: searchBarView()),
            const SizedBox(height: 8),
            Responsive.isMobile(context) ? const Text("※ 상태를 변경하시려면 '가능' / '마감' 버튼을 클릭해 주세요.", style: TextStyle(color: Colors.grey, fontSize: 14)) : Container(),
            const SizedBox(height: 8),
            const SizedBox(height: 8),
            Material(
              child: Responsive.isMobile(context) ? mobileReserveTimeScheduleDataTable(context, contentHeight, columnTextStyle) : reserveTimeScheduleDataTable(context, contentHeight, columnTextStyle),
            ),
          ],
        ),
      ),
    );
  }

  Widget reserveTimeScheduleDataTable(fluentUI.BuildContext context, double contentHeight, fluentUI.TextStyle columnTextStyle) {
    return ISDatatable(
      headingRowHeight: 40,
      dataRowHeight: 50,
      listWidth: Responsive.getResponsiveWidth(context),
      listHeight: contentHeight,
      minWidth: 800,
      rows: dataList.map((item) {
        selectedYN = item.reserYN == 'Y' ? 'Y' : 'N';
        buttonColor = selectedYN == 'Y' ? Colors.lightBlue : Colors.grey;
        return DataRow(cells: [
          DataCell(Align(alignment: Alignment.center, child: Text(DateFormat('yyyy-MM-dd').format(DateTime.parse(item.orderDate.toString())), style: columnTextStyle))),
          DataCell(Align(alignment: Alignment.center, child: Text(getReserTime(item.time!), style: columnTextStyle))),
          DataCell(Align(alignment: Alignment.center, child: Text('${item.cnt!}건 (${item.personCnt!}명)', style: columnTextStyle))),
          DataCell(Align(alignment: Alignment.center, child: Text(getReserYN(item.reserYN!), style: columnTextStyle))),
          DataCell(Padding(padding: const EdgeInsets.all(8.0), child: Align(alignment: Alignment.center, child: Row(mainAxisSize: MainAxisSize.min, children: [YNButton(context, item, 'Y'), const SizedBox(width: 8), YNButton(context, item, 'N')])))),
        ]);
      }).toList(),
      columns: const <DataColumn>[
        DataColumn(label: Expanded(child: Text('날짜', textAlign: TextAlign.center))),
        DataColumn(label: Expanded(child: Text('시간', textAlign: TextAlign.center))),
        DataColumn(label: Expanded(child: Text('건수(총 인원)', textAlign: TextAlign.center))),
        DataColumn(label: Expanded(child: Text('현재 상태', textAlign: TextAlign.center))),
        DataColumn(label: Expanded(child: Text('예약 설정', textAlign: TextAlign.center))),
      ],
    );
  }

  Widget mobileReserveTimeScheduleDataTable(fluentUI.BuildContext context, double contentHeight, fluentUI.TextStyle columnTextStyle) {
    return Column(
      children: [
        ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: EdgeInsets.zero,
            itemBuilder: (ctx, index) {
              return Padding(
                padding: const EdgeInsets.only(top: 30, bottom: 30, left: 10, right: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                        padding: EdgeInsets.zero,
                        alignment: Alignment.center,
                        child: Container(
                          alignment: Alignment.center,
                          width: 85,
                          height: 37,
                          decoration: dataList[index].reserYN == null ? null : BoxDecoration(color: dataList[index].reserYN! == 'Y' ? Colors.lightBlueAccent : Colors.grey, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.transparent)),
                          child: Text(dataList[index].reserYN == null ? '' : (getReserYN(dataList[index].reserYN!) ?? ''), style: const TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY_NEXON)),
                        )),
                    const SizedBox(width: 15),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('날짜 : ${DateFormat('yyyy-MM-dd').format(DateTime.parse(dataList[index].orderDate.toString()))}', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY)),
                        const SizedBox(height: 5),
                        Text('시간 : ${getReserTime(dataList[index].time!) ?? ''}', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY)),
                        const SizedBox(height: 5),
                        Text('건수 : ${dataList[index].cnt!}건 (${dataList[index].personCnt!}명)', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY)),
                      ],
                    ),
                    Expanded(child: Container()),
                    Column(
                      children: [
                        YNButton(context, dataList[index], 'Y'),
                        const SizedBox(height: 8),
                        YNButton(context, dataList[index], 'N'),
                      ],
                    ),
                  ],
                ),
              );
            },
            separatorBuilder: (BuildContext context, int index) {
              return const Divider(thickness: 1, height: 0.0);
            },
            itemCount: dataList.length)
      ],
    );
  }

  List<Widget> searchBarView() {
    return [
      Material(
        child: ISSearchSelectDate(
          label: '기간 선택',
          width: Responsive.isMobile(context) == true ? double.infinity : 150,
          value: date.toString(),
          onTap: () async {
            showGeneralDialog(
                context: context,
                barrierDismissible: true,
                barrierLabel: '',
                barrierColor: Colors.black54,
                pageBuilder: (context, animation, secondaryAnimation) {
                  return Dialog(
                      insetPadding: EdgeInsets.zero,
                      elevation: 0,
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                      child: Container(
                        width: 400,
                        height: 400,
                        padding: const EdgeInsets.all(16.0),
                      child: CalendarDatePicker(
                        initialDate: DateTime.parse(date!),
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2050),
                        onDateChanged: (DateTime value) {
                          setState(() {
                            Navigator.pop(context);
                            date = value.toString().substring(0, 10);
                            requestAPIData();
                          });
                        },
                        ),
                      ));
                });
          },
        ),
      ),
    ];
  }

  getReserYN(String reserYN) {
    String temp;
    if (reserYN == 'N') {
      temp = '예약 마감';
    } else {
      temp = '예약 가능';
    }
    return temp;
  }

  getReserTime(String time) {
    String temp;
    if (int.parse(time.toString().substring(0, 2)) < 12) {
      temp = '오전 ${Utils.getTimeFormat(time.toString())}';
    } else {
      temp = '오후 ${Utils.getTimeFormat(time.toString())}';
    }
    return temp;
  }

  TextButton YNButton(fluentUI.BuildContext context, ReserveTimeScheduleModel item, YN) {
    return TextButton(
      onPressed: () {
        setState(() {
          ISConfirm(context, '예약 접수', ' ${YN == 'Y' ? '접수' : '마감'} 상태로 변경하시겠습니까?', (context, isOK) async {
            Navigator.of(context).pop();
            if (isOK) {
              ReserveTimeScheduleModel formData = ReserveTimeScheduleModel();
              formData.shopCode = AuthService.SHOPCD;
              formData.orderDate = date!.replaceAll('-', '');
              formData.dayTime = item.time!.toString();
              formData.reserYN = YN;
              formData.userId = AuthService.to.userId.toString();
              var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(ReserveController.to.updateShopTimeOff(formData.toJson())));
              if (value == null) {
                ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
              } else {
                if (value == '00') {
                  requestAPIData();
                } else {
                  ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                }
              }
            }
          });
        });
      },
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.resolveWith<Color>(
          (states) {
            if (item.reserYN == 'Y' && YN == 'Y') {
              return Colors.lightBlueAccent;
            } else if (item.reserYN == 'N' && YN == 'N') {
              return Colors.lightBlueAccent;
            } else {
              return Colors.grey;
            }
          },
        ),
      ),
      child: Text(YN == 'Y' ? '가능' : '마감', style: const TextStyle(color: Colors.white)),
    );
  }
}