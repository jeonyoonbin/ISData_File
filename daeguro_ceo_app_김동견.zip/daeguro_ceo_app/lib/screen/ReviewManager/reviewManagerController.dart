import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:daeguro_ceo_app/network/DioReserveReviewClient.dart';
import 'package:daeguro_ceo_app/network/DioReviewClient.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ReviewController extends GetxController{
  static ReviewController get to => Get.find();

  int total_count = 0;
  int total_page = 0;
  int remainAmt = 0;

  int? totalDeposit = 0;
  int? totalWithdraw = 0;
  int? totalReward = 0;

  int? totIssueCnt = 0;
  int? totAmt = 0;
  int? totUseCnt = 0;

  Future<dynamic> getReviewStatistics({String reserveGbn = ''}) async {
    dynamic qData;

    var response;

    if(reserveGbn == 'R') {
      response = await DioReserveReviewClient().get('${ServerInfo.RESTURL_REVIEWSTATISTICS}?shopCode=${AuthService.SHOPCD}');
    } else {
      response = await DioReviewClient().get('${ServerInfo.RESTURL_REVIEWSTATISTICS}?shopCode=${AuthService.SHOPCD}');
    }

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    }
    else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getReviewList(String jobGbn, String page, {String reserveGbn = ''}) async {
    List<dynamic> qData = [];

    var response;

    if(reserveGbn == 'R') {
      response = await DioReserveReviewClient().get('${ServerInfo.RESTURL_REVIEWLIST}?shopCode=${AuthService.SHOPCD}&pageNum=${page}&jobGbn=${jobGbn}&photoYn=Y&sortGbn=1');
    } else {
      response = await DioReviewClient().get('${ServerInfo.RESTURL_REVIEWLIST}?shopCode=${AuthService.SHOPCD}&pageNum=${page}&jobGbn=${jobGbn}&photoYn=Y&sortGbn=1');
    }

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']['items']);
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> setReviewAnswer(dynamic data, {String reserveGbn = ''}) async {
    var response;

    if(reserveGbn == 'R') {
      response = await DioReserveReviewClient().post(ServerInfo.RESTURL_REVIEWANSWER_SET, data: data);
    } else {
      response = await DioReviewClient().post(ServerInfo.RESTURL_REVIEWANSWER_SET, data: data);
    }

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> updateReviewAnswer(dynamic data, {String reserveGbn = ''}) async {
    var response;

    if(reserveGbn == 'R') {
      response = await DioReserveReviewClient().put(ServerInfo.RESTURL_REVIEWANSWER_SET, data: data);
    } else {
      response = await await DioReviewClient().put(ServerInfo.RESTURL_REVIEWANSWER_SET, data: data);
    }

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> deleteReviewAnswer(dynamic data, {String reserveGbn = ''}) async {
    var response;

    if(reserveGbn == 'R') {
      response = await DioReserveReviewClient().delete(ServerInfo.RESTURL_REVIEWANSWER_SET, data: data);
    } else {
      response = await DioReviewClient().delete(ServerInfo.RESTURL_REVIEWANSWER_SET, data: data);
    }

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<List<dynamic>?> getReviewBlindList(String startdate, String enddate, {String reserveGbn = ''}) async {
    List<dynamic> qData = [];

    final response = await DioReviewClient().get('${ServerInfo.RESTURL_REVIEWBLINDLIST}?shopCode=${AuthService.SHOPCD}&blindStandDt=${startdate}&blindEndDt=${enddate}');

    if (response.data['code'] == '00') {
      // total_count = int.parse(response.data['totalCnt'].toString());
      // total_page = int.parse(response.data['pageCnt'].toString());
      //

      qData.assignAll(response.data['data']);
    }
    else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getReviewBlindType({String reserveGbn = ''}) async {
    List<dynamic> qData = [];

    final response = await DioReviewClient().get('${ServerInfo.RESTURL_REVIEWBLINDTYPE}?shopCode=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> setReviewBlind(dynamic data, {String reserveGbn = ''}) async {
    final response = await DioReviewClient().post(ServerInfo.RESTURL_REVIEWBLINDREQUEST, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }
}