

import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionGroupListModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionListModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/Common/commonNoFlagEdit.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productOptionCountSetting.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productOptionGroupEdit.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productOptionGroupLinkEdit.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productOptionGroupNew.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productOptionListEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductOptionInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const ProductOptionInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ProductOptionInfoMain> createState() => _ProductOptionInfoMainState();
}

class _ProductOptionInfoMainState extends State<ProductOptionInfoMain> {

  static const int MODE_GROUPVIEW = 1000;
  static const int MODE_ITEMVIEW = 1001;

  int currentMode = MODE_GROUPVIEW;

  String selectedGroupName = '';
  String selectedGroupCd = '';

  String optionTotalCnt = '';
  String optionMultiCnt = '';
  String optionMinCnt = '';
  String optionProdGrp = '';

  String liveEventYn = '';

  final List<ProductOptionGroupListModel> dataGroupList =  <ProductOptionGroupListModel>[];
  final List<ProductOptionListModel> dataItemList = <ProductOptionListModel>[];

  requestAPI_ProductOptionGroupData() async {

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getOptionGroupList())
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataGroupList.clear();

      value.forEach((element) {
        ProductOptionGroupListModel temp = ProductOptionGroupListModel();

        temp.optionGroupCd = element['optionGroupCd'] as String;
        temp.name = element['name'] as String;
        temp.useGbn = element['useGbn'] as String;
        temp.minCount = element['minCount'] as String;
        temp.multiCount = element['multiCount'] as String;
        temp.optNames = element['optNames'] as String;
        temp.optCode = element['optCode'] as String;
        temp.connectProd = element['connectProd'] as String;
        temp.addYn = element['addYn'] as String;

        if (temp.minCount == '') {
          temp.minCount = '0';
        }

        if (temp.multiCount == '') {
          temp.multiCount = '0';
        }

        dataGroupList.add(temp);
      });

      liveEventYn = ProductInfoController.to.eventYn;

      optionTotalCnt = ProductInfoController.to.optionTotalCnt;
    }

    setState(() {});
  }

  requestAPI_ProductOptionData(String optionGroupCd) async {

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getProductOptionList(optionGroupCd))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {

      dataItemList.clear();

      value.forEach((element) {
        ProductOptionListModel temp = ProductOptionListModel();

        temp.optionCd = element['optionCd'] as String;
        temp.optName = element['optName'] as String;
        temp.optSortSeq = element['optSortSeq'] as String;
        temp.optCost = element['optCost'] as String;
        temp.useGbn = element['useGbn'] as String;
        temp.optNoFlag = element['optNoFlag'] as String;
        temp.optionMemo = element['optionMemo'] as String;

        dataItemList.add(temp);
      });

      liveEventYn = ProductInfoController.to.eventYn;
      optionMultiCnt = ProductInfoController.to.optionMultiCnt;
      optionMinCnt = ProductInfoController.to.optionMinCnt;
      optionProdGrp = ProductInfoController.to.optionProdGrp;

      selectedGroupCd = optionGroupCd;
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPI_ProductOptionGroupData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    dataGroupList.clear();
    dataItemList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER){
            currentMode = MODE_GROUPVIEW;
            requestAPI_ProductOptionGroupData();
          }
          else{
            router.go('/');
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          elevation: 1,
          shape: appTheme.cardShapStyle,
          child: Container(
            constraints: const BoxConstraints(minWidth: double.infinity),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: currentMode == MODE_GROUPVIEW
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.feed_outlined, size: 20),
                            const SizedBox(width: 8,),
                            Text('옵션 그룹 (${dataGroupList.length}개)', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),)
                          ],
                        ),
                        ISButton(
                          child: const Text('옵션 그룹 추가'),
                          onPressed: () {
                            liveEventYn== 'Y'
                                ?
                            ISAlert(context, content: '라이브 이벤트 중에는 수정이 불가능합니다.')
                                :
                            showDialog(
                              context: context,
                              barrierDismissible: true,
                              builder: (context) => ProductOptionGroupNew(optionCnt: optionTotalCnt),
                            ).then((value) async {
                              if (value == true) {
                                await Future.delayed(Duration(milliseconds: 500), () {
                                  requestAPI_ProductOptionGroupData();
                                });
                              }
                            });
                          },
                        )
                      ],
                    )
                  : SingleChildScrollView(
                    scrollDirection: Responsive.isMobile(context) ? Axis.horizontal : Axis.vertical,
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.feed_outlined, size: 20),
                              TextButton(
                                style: ButtonStyle(
                                  animationDuration: const Duration(microseconds: 100),
                                  overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
                                  foregroundColor: MaterialStateProperty.resolveWith<Color>(
                                          (Set<MaterialState> states) {
                                        if (states.contains(MaterialState.hovered))
                                          return Color(0xff01CAFF);

                                        return Colors.grey;
                                      }),
                                ),
                                onPressed: () {
                                  currentMode = MODE_GROUPVIEW;

                                  setState(() {});
                                },
                                child: const Text('옵션 그룹', style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                              ),
                              const Text('>', style: TextStyle(fontSize: 14, color: Colors.grey, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                              Text('  ${selectedGroupName}', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                            ],
                          ),
                          Responsive.isMobile(context) ? const SizedBox(width: 18,) : Container(),
                          ISButton(
                            child: const Text('옵션 추가'),
                            onPressed: () {
                              showDialog(
                                context: context,
                                barrierDismissible: true,
                                builder: (context) => ProductOptionListEdit(sData: null, optionGrpCd: selectedGroupCd),
                              ).then((value) async {
                                if (value == true){
                                  await Future.delayed(const Duration(milliseconds: 500), () {
                                    requestAPI_ProductOptionData(selectedGroupCd);
                                  });
                                }
                              });
                            },
                          )
                        ],
                      ),
                  ),
            ),
          ),
        ),
        const SizedBox(height: 4),
        if (currentMode == MODE_ITEMVIEW)
          Column(
            children: [
              // Card(
              //   elevation: 0,
              //   color: const Color(0xFFf3f3f3),
              //   child: Padding(
              //     padding: const EdgeInsets.all(18),
              //     child: Row(
              //       mainAxisAlignment: MainAxisAlignment.start,
              //       children: [
              //         Container(
              //             width: 70,
              //             height: 26,
              //             alignment: Alignment.center,
              //             padding: const EdgeInsets.only(bottom: 1),
              //             decoration: BoxDecoration(
              //                 borderRadius: BorderRadius.circular(4.0),
              //                 border: Border.all(color: Colors.cyan),
              //             ),
              //             child: const Text('옵션수', textAlign: TextAlign.center, style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, fontSize: 12, color: Colors.cyan),)
              //         ),
              //         const SizedBox(width: 10,),
              //         Text('최소 ${optionMinCnt}개, 최대 ${optionMultiCnt}개 선택 가능', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: Colors.black54),),
              //         const SizedBox(width: 10,),
              //         ISButton(
              //           child: const Text('변경'),
              //           onPressed: () {
              //             showDialog(
              //               context: context,
              //               barrierDismissible: true,
              //               builder: (context) => ProductOptionCountSetting(optGrpCd: selectedGroupCd, optionCnt: optionTotalCnt, minCnt: optionMinCnt, maxCnt: optionMultiCnt,),
              //             ).then((value) async {
              //               if (value == true){
              //                 await Future.delayed(const Duration(milliseconds: 500), () {
              //                   requestAPI_ProductOptionData(selectedGroupCd);
              //                 });
              //               }
              //             });
              //           },
              //         )
              //       ],
              //     ),
              //   ),
              // ),
              Card(
                elevation: 0,
                color: const Color(0xFFf3f3f3),
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                              width: 70,
                              height: 26,
                              alignment: Alignment.center,
                              padding: const EdgeInsets.only(bottom: 1),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4.0),
                                border: Border.all(color: Colors.cyan),
                              ),
                              child: const Text('연결상품', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: Colors.cyan),)
                          ),
                          const SizedBox(width: 10,),
                          const Text('수정 시 동시 적용됩니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: Colors.black54),),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(optionProdGrp, style: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: Colors.black54),),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 4),
            ],
          ),

        currentMode == MODE_GROUPVIEW ? groupListView() : itemListView(),

        const Divider(height: 1)
      ],
    );
  }

  void _onGroupListReorder(int oldIndex, int newIndex) {
    // 라이브 이벤트 진행중일때 리턴
    //if (widget.eventYn == 'Y') return;

    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final ProductOptionGroupListModel item = dataGroupList.removeAt(oldIndex);
      dataGroupList.insert(newIndex, item);

      List<String> sortDataList = [];
      dataGroupList.forEach((element) {
        sortDataList.add(element.optionGroupCd!);
      });

      _editListSort('1', sortDataList);
    });
  }

  _editListSort(String div, List<String> sortDataList) async {
    String jsonData = jsonEncode(sortDataList);

    await ProductInfoController.to.updateListSort(div, jsonData);

    await Future.delayed(Duration(milliseconds: 500), () {
      if (div == '1')
        requestAPI_ProductOptionGroupData();
      else if (div == '3')
        requestAPI_ProductOptionData(selectedGroupCd);
    });
  }

  void _onItemListReorder(int oldIndex, int newIndex) {
    // 라이브 이벤트 진행중일때 리턴
    //if (widget.eventYn == 'Y') return;

    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final ProductOptionListModel item = dataItemList.removeAt(oldIndex);
      dataItemList.insert(newIndex, item);

      List<String> sortDataList = [];
      dataItemList.forEach((element) {
        sortDataList.add(element.optionCd!);
      });

      _editListSort('3', sortDataList);
    });
  }

  Widget groupListView() {
    final appTheme = context.watch<AppTheme>();

    double listMaxWidth = 540;
    if (Responsive.isDesktop(context) == true)        listMaxWidth = 530;
    else if (Responsive.isTablet(context) == true)    listMaxWidth = 340;
    else if (Responsive.isMobile(context) == true)    listMaxWidth = 270;

    return SizedBox(
      height: widget.tabviewHeight! - 91,
      child: dataGroupList != 0 ? ReorderableListView(
        buildDefaultDragHandles: false,
        scrollController: ScrollController(),
        onReorder: _onGroupListReorder,
        scrollDirection: Axis.vertical,
        padding: const EdgeInsets.only(bottom: 8.0),

        children: List.generate(dataGroupList.length, (index) {
          return Card(
            key: Key('$index'),
            elevation: 1,
            shape: appTheme.cardShapStyle,
            margin: const EdgeInsets.all(4),
            //color: dataGroupList[index].selected == true ? const Color.fromRGBO(165, 216, 252, 1.0) : Colors.white,
            child: InkWell(
              //splashColor: const Color.fromRGBO(165, 216, 252, 1.0),
              onTap: () {
                for (var element in dataGroupList) {
                  element.selected = false;
                }

                // _menuGroupCd = dataGroupList[index].menuGroupCd;
                //
                // ShopController.to.MainCount.value = int.parse(dataGroupList[index].mainCount);
                //
                dataGroupList[index].selected = true;

                selectedGroupName = dataGroupList[index].name!;

                currentMode = MODE_ITEMVIEW;

                requestAPI_ProductOptionData(dataGroupList[index].optionGroupCd!);

                //setState(() {});
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: ReorderableDragStartListener(
                          index: index,
                          child: Icon(Icons.reorder, color: Colors.grey, size: 24.0,)
                      ),
                    ),
                    const SizedBox(width: 8,),
                    Flexible(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            dataGroupList[index].useGbn == 'Y'
                                ? Container(
                                width: 36,
                                height: 18,
                                alignment: Alignment.center,
                                decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                child: const Center(
                                    child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                    ))
                            ) : Container(
                                width: 36,
                                height: 18,
                                alignment: Alignment.center,
                                decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                            ),
                            const SizedBox(height: 5),
                            Text(dataGroupList[index].name ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY ),),
                            Text(dataGroupList[index].optNames ?? '--', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                            const SizedBox(height: 8,),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    width: 48,
                                    height: 16,
                                    alignment: Alignment.center,
                                    padding: const EdgeInsets.only(bottom: 1),
                                    decoration: BoxDecoration(
                                        border: Border.all(color: Colors.black54, width: 0.5),
                                        borderRadius: BorderRadius.circular(6)
                                    ),
                                    child: const Text('옵션 수', style: TextStyle(fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54),)
                                ),
                                const SizedBox(width: 8,),
                                SizedBox(
                                    width: MediaQuery.of(context).size.width - listMaxWidth,
                                    child: Text('(최소) ${dataGroupList[index].minCount} ~ (최대) ${dataGroupList[index].multiCount}', style: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54)))
                              ],
                            ),
                            const SizedBox(height: 4,),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    width: 48,
                                    height: 18,
                                    alignment: Alignment.center,
                                    padding: const EdgeInsets.only(bottom: 1),
                                    decoration: BoxDecoration(
                                        border: Border.all(color: Colors.black54, width: 0.5),
                                        borderRadius: BorderRadius.circular(6)
                                    ),
                                    child: const Text('연결상품', style: TextStyle(fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54),)
                                ),
                                const SizedBox(width: 8,),
                                SizedBox(
                                  width: MediaQuery.of(context).size.width - listMaxWidth,
                                  child: Text(dataGroupList[index].connectProd ?? '--', style: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54)))
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12.0),
                      child: IconButton(
                        icon: const Icon(Icons.more_horiz, size: 20),
                        color: Colors.black,
                        tooltip: '수정',
                        onPressed: () {
                          List<String> values = ['옵션 그룹 수정', '상품 연결', '옵션 그룹 삭제'];

                          liveEventYn== 'Y'
                              ?
                          ISAlert(context, content: '라이브 이벤트 중에는 수정이 불가능합니다.')
                              :
                          ISOptionDialog(context, const BoxConstraints(maxWidth: 360.0, maxHeight: 232), dataGroupList[index].name!, values, (context, selectIdx) async {
                            Navigator.of(context).pop();

                            if (selectIdx == 0){
                              showDialog(
                                context: context,
                                barrierDismissible: true,
                                builder: (context) => ProductOptionGroupEdit(sData: dataGroupList.elementAt(index),),
                              ).then((value) async {
                                if (value == true){
                                  await Future.delayed(Duration(milliseconds: 500), () {
                                    requestAPI_ProductOptionGroupData();
                                  });
                                }
                              });
                            }
                            else if (selectIdx == 1){
                              showDialog(
                                context: context,
                                barrierDismissible: true,
                                builder: (context) => ProductOptionGroupLinkEdit(optionGroupName: dataGroupList[index].name, optionGrouCd: dataGroupList[index].optionGroupCd),
                              ).then((value) async {
                                if (value == true){
                                  await Future.delayed(Duration(milliseconds: 500), () {
                                    requestAPI_ProductOptionGroupData();
                                  });
                                }
                              });
                            }
                            else if (selectIdx == 2){
                              ISConfirm(context, '삭제', '[${dataGroupList[index].name!}] 옵션 그룹을 삭제합니다.\n삭제 시, 연결 상품 및 하부 옵션이 모두 삭제됩니다. \n\n계속 진행하시겠습니까?', constraints: BoxConstraints(maxWidth: 420), (context, isOK) async {
                                Navigator.pop(context);

                                if (isOK){
                                  var value = await showDialog(
                                      context: context,
                                      builder: (context) => FutureProgressDialog(ProductInfoController.to.deleteProductOptionGroup(dataGroupList[index].optionGroupCd!))
                                  );

                                  if (value == null) {
                                    ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                                  }
                                  else {
                                    if (value == '00') {
                                      requestAPI_ProductOptionGroupData();
                                    }
                                    else{
                                      ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                    }
                                  }
                                }
                              });
                            }
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
        ),
      ) : const Center(child: Text('조회 결과 없음', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)))
    );
  }

  Widget itemListView() {
    final appTheme = context.watch<AppTheme>();

    return SizedBox(
      height: Responsive.isMobile(context) ? widget.tabviewHeight! - 246 : widget.tabviewHeight! - 188,
      child: dataItemList != 0 ? ReorderableListView(
        buildDefaultDragHandles: false,
        scrollController: ScrollController(),
        onReorder: _onItemListReorder,
        scrollDirection: Axis.vertical,
        padding: const EdgeInsets.only(bottom: 8.0),

        children: List.generate(dataItemList.length, (index) {
          return Card(
            key: Key('$index'),
            elevation: 1,
            shape: appTheme.cardShapStyle,
            margin: const EdgeInsets.all(4),
            //color: dataMenuList[index].selected == true ? const Color.fromRGBO(165, 216, 252, 1.0) : Colors.white,
            child: InkWell(
              //splashColor: const Color.fromRGBO(165, 216, 252, 1.0),
              onTap: () {
                showProductSelectList(index);
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: ReorderableDragStartListener(
                          index: index,
                          child: Icon(Icons.reorder, color: Colors.grey, size: 24.0,)
                      ),
                    ),
                    const SizedBox(width: 4,),
                    Flexible(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                Row(
                                  children: [
                                    dataItemList[index].useGbn == 'Y'
                                        ? Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                        child: const Center(
                                            child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                            ))
                                    ) : Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                        child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                    ),
                                    dataItemList[index].optNoFlag == 'Y'
                                        ? Container(
                                        width: 26,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.redAccent.shade100),
                                        child: const Center(child: Text('품절', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: Text(dataItemList[index].optName ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY)),
                                ),
                              ],
                            ),
                            Text('${Utils.getCashComma(dataItemList[index].optCost!)} 원', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                        padding: const EdgeInsets.fromLTRB(0, 0, 30, 0),
                        child: IconButton(
                          icon: const Icon(Icons.more_horiz, size: 20),
                          color: Colors.black,
                          tooltip: '수정',
                          onPressed: () {
                            liveEventYn== 'Y'
                                ? ISAlert(context, content: '라이브 이벤트 중에는 수정이 불가능합니다.')
                                : showProductSelectList(index);
                          },
                        )
                    ),
                  ],
                ),
              ),
            ),
          );
        },
        ),
      ) : const Center(child: Text('조회 결과 없음', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
    );
  }

  showProductSelectList(int index){
    List<String> values = ['옵션 및 가격 변경', '옵션 품절', '옵션 삭제'];

    ISOptionDialog(context, const BoxConstraints(maxWidth: 360.0, maxHeight: 232), dataItemList[index].optName!, values, (context, selectIdx) async {
      Navigator.of(context).pop();

      if (selectIdx == 0){
        showDialog(
          context: context,
          barrierDismissible: true,
          builder: (context) => ProductOptionListEdit(sData: dataItemList.elementAt(index), optionGrpCd: selectedGroupCd),
        ).then((value) async {
          if (value == true){
            await Future.delayed(const Duration(milliseconds: 500), () {
              requestAPI_ProductOptionData(selectedGroupCd);
            });
          }
        });
      }
      else if (selectIdx == 1){
        showDialog(
          context: context,
          barrierDismissible: true,
          builder: (context) => CommonNoFlagEdit(jobGbn: 'F', subGbn: 'O', targetCd: dataItemList[index].optionCd, noFlag: dataItemList[index].optNoFlag),
        ).then((value) async {
          if (value == true){
            await Future.delayed(const Duration(milliseconds: 500), () {
              requestAPI_ProductOptionData(selectedGroupCd);
            });
          }
        });
      }
      else if (selectIdx == 2){
        ISConfirm(context, '삭제', '[${dataItemList[index].optName!}] 옵션을 삭제합니다.\n\n계속 진행하시겠습니까?', constraints: BoxConstraints(maxWidth: 420), (context, isOK) async {
          Navigator.pop(context);

          if (isOK){
            var value = await showDialog(
                context: context,
                builder: (context) => FutureProgressDialog(ProductInfoController.to.deleteProductOption(dataItemList[index].optionCd!))
            );

            if (value == null) {
              ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
            }
            else {
              if (value == '00') {
                requestAPI_ProductOptionData(selectedGroupCd);
              }
              else{
                ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
              }
            }
          }
        });
      }
    });
  }
}