import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/MenuManager/menuGroupEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOriginLocalEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOriginLocalListModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductOriginLocalEdit extends StatefulWidget {
  final ProductOriginLocalListModel? sData;
  const ProductOriginLocalEdit({Key? key, this.sData})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ProductOriginLocalEditState();
  }
}

enum RadioUseGbn { useGbnY, useGbnN }

class ProductOriginLocalEditState extends State<ProductOriginLocalEdit> {

  ProductOriginLocalEditModel formData = ProductOriginLocalEditModel();

  RadioUseGbn? _radioUseGbn;

  requestOriginLocalData() async {
    var value = await showDialog(
        context: context,
      barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.updateSubThemeMenuSort(formData.toJson())),
    );

    if (value != '00') {
      ISAlert(context, content: '정상 등록되지 않았습니다\n[다시 시도해 주세요]\n→ ${value}');
      //Navigator.of(context).pop;
    }
    else {
      Navigator.of(context).pop(true);
    }
  }

  @override
  void dispose() {
    super.dispose();
    formData = ProductOriginLocalEditModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    if (widget.sData == null){
      formData.jobGbn = 'I';
      formData.shopCd = AuthService.SHOPCD;
      formData.title = '';
      formData.contents = '';
      formData.useGbn = 'Y';
      formData.uCode = AuthService.uCode;
      formData.uName = AuthService.uName;

      _radioUseGbn = RadioUseGbn.useGbnY;
    }
    else{
      formData.jobGbn = 'U';
      formData.seq = widget.sData!.seq;
      formData.shopCd = AuthService.SHOPCD;
      formData.title = widget.sData!.title;
      formData.contents = widget.sData!.contents;
      formData.useGbn = widget.sData!.useGbn;
      formData.uCode = AuthService.uCode;
      formData.uName = AuthService.uName;

      _radioUseGbn = (widget.sData!.useGbn == 'Y') ? RadioUseGbn.useGbnY : RadioUseGbn.useGbnN;
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: Responsive.isMobile(context) ? SingleChildScrollView(child: buildContentDialog(context, appTheme),) : buildContentDialog(context, appTheme),
    );
  }

  ContentDialog buildContentDialog(fluentUI.BuildContext context, AppTheme appTheme) {
    return ContentDialog(
        constraints: BoxConstraints(maxWidth: 360.0, maxHeight: 500),//(widget.sData == null) ? 490 : 420),
        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            Text(widget.sData == null ? '원산지 신규 등록' : '원산지 정보 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //const Divider(color: Colors.grey, height: 0.0,),
              const SizedBox(height: 12,),
              const Text('원산지 그룹명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
              const SizedBox(height: 8),
              ISInput(
                autofocus: true,
                value: formData.title ?? '',
                context: context,
                height: 64,
                //padding: 0,
                label: '원산지 그룹명',
                maxLength: 25,
                onChange: (v) {
                  formData.title = v;
                },
              ),

              const Text('원산지 상세 설명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
              const SizedBox(height: 8),
              ISInput(
                value: formData.contents ?? '',
                context: context,
                height: 150,
                //padding: 0,
                label: '원산지 상세 설명',
                keyboardType: TextInputType.multiline,
                maxLines: 8,
                maxLength: 250,
                onChange: (v) {
                  formData.contents = v;
                },
              ),
              const SizedBox(height: 8,),
              const Divider(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10.0),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('사용 여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                        Row(
                          children: [
                            Radio(
                                value: RadioUseGbn.useGbnY,
                                groupValue: _radioUseGbn,
                                onChanged: (v) async {
                                  _radioUseGbn = v as RadioUseGbn?;

                                  formData.useGbn = 'Y';

                                  setState(() {});
                                }),
                            const Text('사용', style: TextStyle(fontSize: 12)),
                            const SizedBox(width: 40,),
                            Radio(
                                value: RadioUseGbn.useGbnN,
                                groupValue: _radioUseGbn,
                                onChanged: (v) async {
                                  _radioUseGbn = v as RadioUseGbn?;

                                  formData.useGbn = 'N';

                                  setState(() {});
                                }),
                            const Text('미사용', style: TextStyle(fontSize: 12)),
                          ],
                        )

                      ],
                    ),
                  ],
                ),
              ),
              const Divider(),
            ],
          ),
        ),
        actions: [
          // SizedBox(//싱글 버튼 처리
          //   width: double.infinity,
          //   child: FilledButton(
          //     style: ButtonStyle(
          //         backgroundColor: const MaterialStatePropertyAll(Colors.blueAccent),
          //       shape: MaterialStatePropertyAll(
          //           RoundedRectangleBorder(
          //               borderRadius: BorderRadius.circular(4.0))
          //       ),
          //     ),
          //     onPressed: () {
          //
          //     },
          //     child: const Text('적용'),
          //   ),
          // ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () {
                ISConfirm(context, '원산지 정보 ${widget.sData == null ? '등록' : '수정'}', '원산지 정보를 ${widget.sData == null ? '등록' : '수정'}합니다. \n\n계속 진행하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                  Navigator.of(context).pop();

                  if (isOK){
                    requestOriginLocalData();
                  }

                });
              },
              child: Text(widget.sData == null ? '등록' : '변경', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      );
  }
}


