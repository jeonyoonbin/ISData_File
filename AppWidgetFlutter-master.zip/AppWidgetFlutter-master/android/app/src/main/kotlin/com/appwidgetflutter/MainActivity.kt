package com.appwidgetflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
