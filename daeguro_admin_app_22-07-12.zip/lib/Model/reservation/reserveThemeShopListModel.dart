import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveThemeShopListModel {
  ReserveThemeShopListModel();

  bool selected;
  String shopName;
  String shopCd;
  String regNo;
  String addr1;
  String addr2;
  String useGbn;

  factory ReserveThemeShopListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveThemeShopListModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveThemeShopListModel()
    ..selected = json['selected'] as bool
    ..shopName = json['shopName'] as String
    ..shopCd = json['shopCd'] as String
    ..regNo = json['regNo'] as String
    ..addr1 = json['addr1'] as String
    ..addr2 = json['addr2'] as String
    ..useGbn = json['useGbn'] as String;
}

Map<String, dynamic> _$ModelToJson(ReserveThemeShopListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'shopName': instance.shopName,
  'shopCd': instance.shopCd,
  'regNo': instance.regNo,
  'addr1': instance.addr1,
  'addr2': instance.addr2,
  'useGbn': instance.useGbn
};
