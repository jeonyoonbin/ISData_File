import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveChangeStatusModel {
  ReserveChangeStatusModel();

  int seqNo;
  String status;
  String cancelReason;
  String cancelMemo;
  String modGbn;
  String modId;

  factory ReserveChangeStatusModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveChangeStatusModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveChangeStatusModel()
    ..seqNo = json['seqNo'] as int
    ..status = json['status'] as String
    ..cancelReason = json['cancelReason'] as String
    ..cancelMemo = json['cancelMemo'] as String
    ..modGbn = json['modGbn'] as String
    ..modId = json['modId'] as String;
}

Map<String, dynamic> _$ModelToJson(ReserveChangeStatusModel instance) => <String, dynamic>{
  'seqNo': instance.seqNo,
  'status': instance.status,
  'cancelReason': instance.cancelReason,
  'cancelMemo': instance.cancelMemo,
  'modGbn': instance.modGbn,
  'modId': instance.modId,
};
