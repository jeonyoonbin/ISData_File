import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
// ignore: camel_case_types
class ShopCalcHistoryModel {
  ShopCalcHistoryModel();

  String NO;
  String HIST_DATE;
  String MEMO;

  factory ShopCalcHistoryModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopCalcHistoryModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopCalcHistoryModel()
    ..NO = json['NO'] as String
    ..HIST_DATE = json['HIST_DATE'] as String
    ..MEMO = json['MEMO'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopCalcHistoryModel instance) => <String, dynamic>{
  'NO': instance.NO,
  'HIST_DATE': instance.HIST_DATE,
  'MEMO': instance.MEMO
};
