import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiFAQDeleteModel {
  TaxiFAQDeleteModel();

  bool selected = false;
  String idUsrIns;
  String nmUsrIns;
  int seqBoard;
  int noParent;
  int noThread;
  int noDepth;
  String rmkDel;

  factory TaxiFAQDeleteModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiFAQDeleteModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiFAQDeleteModel()

    ..selected = json['selected'] as bool
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..seqBoard = json['seqBoard'] as int
    ..noParent = json['noParent'] as int
    ..noThread = json['noThread'] as int
    ..noDepth = json['noDepth'] as int
    ..rmkDel = json['rmkDel'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiFAQDeleteModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'idUsrIns': instance.idUsrIns,
  'nmUsrIns': instance.nmUsrIns,
  'seqBoard': instance.seqBoard,
  'noParent': instance.noParent,
  'noThread': instance.noThread,
  'noDepth': instance.noDepth,
  'rmkDel': instance.rmkDel
};