import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiCompMstModel {
  TaxiCompMstModel();

  bool selected = false;
  bool viewSelected;
  String cdComp;
  String dtmIns;
  String nmComp;
  String ynUse;
  String ynUseText;
  String divComp;
  String divCompText;
  String noTel;
  String amtSave;

  factory TaxiCompMstModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiCompMstModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiCompMstModel()
    ..selected = json['selected'] as bool
    ..viewSelected = json['viewSelected'] as bool
    ..cdComp = json['cdComp'] as String
    ..dtmIns = json['dtmIns'] as String
    ..nmComp = json['nmComp'] as String
    ..ynUse = json['ynUse'] as String
    ..ynUseText = json['ynUseText'] as String
    ..divComp = json['divComp'] as String
    ..divCompText = json['divCompText'] as String
    ..noTel = json['noTel'] as String
    ..amtSave = json['amtSave'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiCompMstModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'viewSelected': instance.viewSelected,
  'cdComp': instance.cdComp,
  'dtmIns': instance.dtmIns,
  'nmComp': instance.nmComp,
  'ynUse': instance.ynUse,
  'ynUseText': instance.ynUseText,
  'divComp': instance.divComp,
  'divCompText': instance.divCompText,
  'noTel': instance.noTel,
  'amtSave': instance.amtSave,
};
