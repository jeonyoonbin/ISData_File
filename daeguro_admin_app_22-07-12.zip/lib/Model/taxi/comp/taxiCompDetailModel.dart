import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiCompDetailModel {
  TaxiCompDetailModel();

  bool selected = false;
  bool viewSelected;
  String cdComp;
  String dtmIns;
  String idUsrIns;
  String nmUsrIns;
  String dtmUpd;
  String idUsrUpd;
  String nmUsrUpd;
  String idGroup;
  String cdMember;
  String nmComp;
  String ynUse;
  String ynUseText;
  String dtmUse;
  String lvComp;
  String lvCompText;
  String divComp;
  String divCompText;
  String divBusi;
  String divBusiText;
  String noBusi;
  String noSoId;
  String divTax;
  String divTaxText;
  String ynTax;
  String ynTaxText;
  String dtmTax;
  String divVatCharge;
  String divVatChargeText;
  String taxEmail;
  String noTel;
  String noFax;
  String cdBank;
  String cdBankText;
  String noAcc;
  String nmAccOwner;
  String rmk;
  String rmkSummary;
  String divPg;
  String divPgText;
  String divPgMethod;
  String divPgMethodText;
  String pgMid;
  String pgKey;
  String cntDayTrans;
  String amtDayTrans;
  String cntMonTrans;
  String amtMonTrans;
  String amtMinSave;
  String urlCs;
  String amtSave;
  String cntSms;
  String cntEtax;

  factory TaxiCompDetailModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiCompDetailModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiCompDetailModel()
    ..selected = json['selected'] as bool
    ..viewSelected = json['viewSelected'] as bool
    ..cdComp = json['cdComp'] as String
    ..dtmIns = json['dtmIns'] as String
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..dtmUpd = json['dtmUpd'] as String
    ..idUsrUpd = json['idUsrUpd'] as String
    ..nmUsrUpd = json['nmUsrUpd'] as String
    ..idGroup = json['idGroup'] as String
    ..cdMember = json['cdMember'] as String
    ..nmComp = json['nmComp'] as String
    ..ynUse = json['ynUse'] as String
    ..ynUseText = json['ynUseText'] as String
    ..dtmUse = json['dtmUse'] as String
    ..lvComp = json['lvComp'] as String
    ..lvCompText = json['lvCompText'] as String
    ..divComp = json['divComp'] as String
    ..divCompText = json['divCompText'] as String
    ..divBusi = json['divBusi'] as String
    ..divBusiText = json['divBusiText'] as String
    ..noBusi = json['noBusi'] as String
    ..noSoId = json['noSoId'] as String
    ..divTax = json['divTax'] as String
    ..divTaxText = json['divTaxText'] as String
    ..ynTax = json['ynTax'] as String
    ..ynTaxText = json['ynTaxText'] as String
    ..dtmTax = json['dtmTax'] as String
    ..divVatCharge = json['divVatCharge'] as String
    ..divVatChargeText = json['divVatChargeText'] as String
    ..taxEmail = json['taxEmail'] as String
    ..noTel = json['noTel'] as String
    ..noFax = json['noFax'] as String
    ..cdBank = json['cdBank'] as String
    ..cdBankText = json['cdBankText'] as String
    ..noAcc = json['noAcc'] as String
    ..nmAccOwner = json['nmAccOwner'] as String
    ..rmk = json['rmk'] as String
    ..rmkSummary = json['rmkSummary'] as String
    ..divPg = json['divPg'] as String
    ..divPgText = json['divPgText'] as String
    ..divPgMethod = json['divPgMethod'] as String
    ..divPgMethodText = json['divPgMethodText'] as String
    ..pgMid = json['pgMid'] as String
    ..pgKey = json['pgKey'] as String
    ..cntDayTrans = json['cntDayTrans'] as String
    ..amtDayTrans = json['amtDayTrans'] as String
    ..cntMonTrans = json['cntMonTrans'] as String
    ..amtMonTrans = json['amtMonTrans'] as String
    ..amtMinSave = json['amtMinSave'] as String
    ..urlCs = json['urlCs'] as String
    ..amtSave = json['amtSave'] as String
    ..cntSms = json['cntSms'] as String
    ..cntEtax = json['cntEtax'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiCompDetailModel instance) => <String, dynamic>{
      'selected': instance.selected,
      'viewSelected': instance.viewSelected,
'cdComp': instance.cdComp,
'dtmIns': instance.dtmIns,
'idUsrIns': instance.idUsrIns,
'nmUsrIns': instance.nmUsrIns,
'dtmUpd': instance.dtmUpd,
'idUsrUpd': instance.idUsrUpd,
'nmUsrUpd': instance.nmUsrUpd,
'idGroup': instance.idGroup,
'cdMember': instance.cdMember,
'nmComp': instance.nmComp,
'ynUse': instance.ynUse,
'ynUseText': instance.ynUseText,
'dtmUse': instance.dtmUse,
'lvComp': instance.lvComp,
'lvCompText': instance.lvCompText,
'divComp': instance.divComp,
'divCompText': instance.divCompText,
'divBusi': instance.divBusi,
'divBusiText': instance.divBusiText,
'noBusi': instance.noBusi,
'noSoId': instance.noSoId,
'divTax': instance.divTax,
'divTaxText': instance.divTaxText,
'ynTax': instance.ynTax,
'ynTaxText': instance.ynTaxText,
'dtmTax': instance.dtmTax,
'divVatCharge': instance.divVatCharge,
'divVatChargeText': instance.divVatChargeText,
'taxEmail': instance.taxEmail,
'noTel': instance.noTel,
'noFax': instance.noFax,
'cdBank': instance.cdBank,
'cdBankText': instance.cdBankText,
'noAcc': instance.noAcc,
'nmAccOwner': instance.nmAccOwner,
'rmk': instance.rmk,
'rmkSummary': instance.rmkSummary,
'divPg': instance.divPg,
'divPgText': instance.divPgText,
'divPgMethod': instance.divPgMethod,
'divPgMethodText': instance.divPgMethodText,
'pgMid': instance.pgMid,
'pgKey': instance.pgKey,
'cntDayTrans': instance..cntDayTrans,
'amtDayTrans': instance.amtDayTrans,
'cntMonTrans': instance.cntMonTrans,
'amtMonTrans': instance.amtMonTrans,
'amtMinSave': instance.amtMinSave,
'urlCs': instance.urlCs,
'amtSave': instance.amtSave,
'cntSms': instance.cntSms,
'cntEtax': instance.cntEtax,
    };
