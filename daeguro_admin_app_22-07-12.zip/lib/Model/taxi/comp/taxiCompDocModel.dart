import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiCompDocModel {
  TaxiCompDocModel();

  bool selected = false;
  String cdComp;
  String dtmIns;
  String oper;
  String terms;
  String privacy;
  String personal;
  String consign;
  String third;
  String loc;
  String epay;
  String etax;
  String push;
  String join;
  String termsCalc;

  factory TaxiCompDocModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiCompDocModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiCompDocModel()
    ..selected = json['selected'] as bool
    ..cdComp = json['cdComp'] as String
    ..dtmIns = json['dtmIns'] as String
    ..oper = json['oper'] as String
    ..terms = json['terms'] as String
    ..privacy = json['privacy'] as String
    ..personal = json['personal'] as String
    ..consign = json['consign'] as String
    ..third = json['third'] as String
    ..loc = json['loc'] as String
    ..epay = json['epay'] as String
    ..etax = json['etax'] as String
    ..push = json['push'] as String
    ..join = json['join'] as String
    ..termsCalc = json['termsCalc'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiCompDocModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'cdComp': instance.cdComp,
  'dtmIns': instance.dtmIns,
  'oper': instance.oper,
  'terms': instance.terms,
  'privacy': instance.privacy,
  'personal': instance.personal,
  'consign': instance.consign,
  'third': instance.third,
  'loc': instance.loc,
  'epay': instance.epay,
  'etax': instance.etax,
  'push': instance.push,
  'join': instance.join,
  'termsCalc': instance.termsCalc
};
