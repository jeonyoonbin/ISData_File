import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiCompHistModel {
  TaxiCompHistModel();

  bool selected = false;
  String cdComp;
  String dtmIns;
  String idUsrIns;
  String nmUsrIns;
  String divDevice;
  String statusCol;
  String colComments;
  String statusDesc;

  factory TaxiCompHistModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiCompHistModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiCompHistModel()

    ..selected = json['selected'] as bool
    ..cdComp = json['cdComp'] as String
    ..dtmIns = json['dtmIns'] as String
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..divDevice = json['divDevice'] as String
    ..statusCol = json['statusCol'] as String
    ..colComments = json['colComments'] as String
    ..statusDesc = json['statusDesc'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiCompHistModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'cdComp': instance.cdComp,
  'dtmIns': instance.dtmIns,
  'idUsrIns': instance.idUsrIns,
  'nmUsrIns': instance.nmUsrIns,
  'divDevice': instance.divDevice,
  'statusCol': instance.statusCol,
  'colComments': instance.colComments,
  'statusDesc': instance.statusDesc,
};