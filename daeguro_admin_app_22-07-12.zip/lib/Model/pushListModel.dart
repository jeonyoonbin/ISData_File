import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class pushListModel {
  pushListModel();

  bool selected = false;
  String rnum;
  String push_cd;
  String push_title;
  String push_msg;
  String send_gbn;
  String st_date;
  String object_gbn;
  String range_gbn;
  String marketing_push_gbn;
  String status;
  String s_cnt;
  String cnt;
  String ins_date;
  String ins_name;
  String mod_date;
  String mod_name;

  factory pushListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

pushListModel _$ModelFromJson(Map<String, dynamic> json) {
  return pushListModel()
    ..selected = json['selected'] as bool
    ..rnum = json['rnum'] as String
    ..push_cd = json['push_cd'] as String
    ..push_title = json['push_title'] as String
    ..push_msg = json['push_msg'] as String
    ..send_gbn = json['send_gbn'] as String
    ..st_date = json['st_date'] as String
    ..object_gbn = json['object_gbn'] as String
    ..range_gbn = json['range_gbn'] as String
    ..marketing_push_gbn = json['marketing_push_gbn'] as String
    ..status = json['status'] as String
    ..s_cnt = json['s_cnt'] as String
    ..cnt = json['cnt'] as String
    ..ins_date = json['ins_date'] as String
    ..ins_name = json['ins_name'] as String
    ..mod_date = json['mod_date'] as String
    ..mod_name = json['mod_name'] as String;
}

Map<String, dynamic> _$ModelToJson(pushListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'rnum': instance.rnum,
  'push_cd': instance.push_cd,
  'push_title': instance.push_title,
  'push_msg': instance.push_msg,
  'send_gbn': instance.send_gbn,
  'st_date': instance.st_date,
  'object_gbn': instance.object_gbn,
  'range_gbn': instance.range_gbn,
  'marketing_push_gbn': instance.marketing_push_gbn,
  'status': instance.status,
  's_cnt': instance.s_cnt,
  'cnt': instance.cnt,
  'ins_date': instance.ins_date,
  'ins_name': instance.ins_name,
  'mod_date': instance.mod_date,
  'mod_name': instance.mod_name,
};
