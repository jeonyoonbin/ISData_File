import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/is_select_date.dart';
import 'package:daeguro_admin_app/Model/notice/noticeDetailModel.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveFAQEditModel.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/NoticeManager/noticeFileUpload.dart';
import 'package:daeguro_admin_app/View/NoticeManager/notice_controller.dart';

import 'package:daeguro_admin_app/Network/FileUpLoader.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reservationmanager_controller.dart';
import 'package:daeguro_admin_app/constants/serverInfo.dart';

import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';

class ReserveFAQEdit extends StatefulWidget {
  final String gbn;
  final String question;
  final String answer;
  final int seq;

  const ReserveFAQEdit({
    Key key,
    this.gbn,
    this.question,
    this.answer,
    this.seq,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ReserveFAQEditState();
  }
}

class ReserveFAQEditState extends State<ReserveFAQEdit> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  ReserveFAQEditModel editData;

  List<SelectOptionVO> selectBox_FAQGbn = List();

  @override
  void dispose() {
    selectBox_FAQGbn.clear();
    editData = null;

    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReservationController());

    editData = ReserveFAQEditModel();

    editData.gbn = widget.gbn;
    editData.question = widget.question;
    editData.answer = widget.answer;
    editData.seq = widget.seq;

    selectBox_FAQGbn.clear();

    selectBox_FAQGbn.add(new SelectOptionVO(value: '1', label: '주문/결제'));
    selectBox_FAQGbn.add(new SelectOptionVO(value: '2', label: '회원정보'));
    selectBox_FAQGbn.add(new SelectOptionVO(value: '3', label: '이용문의'));
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: ISInput(value: widget.seq.toString(), autofocus: true, readOnly: true, context: context, label: '순번'),
              ),
              Flexible(
                flex: 1,
                child: ISSelect(
                  label: 'FAQ 구분',
                  value: editData.gbn,
                  dataList: selectBox_FAQGbn,
                  onChange: (value) {
                    setState(() {
                      editData.gbn = value;
                      formKey.currentState.save();
                    });
                  },
                ),
              ),
            ],
          ),
          ISInput(
            value: editData.question,
            autofocus: true,
            context: context,
            label: '질문 내용',
            onSaved: (v) {
              editData.question = v;
            },
          ),
          ISInput(
            value: editData.answer,
            context: context,
            label: '질문 답글',
            height: 140,
            contentPadding: 20,
            keyboardType: TextInputType.multiline,
            maxLines: 8,
            onSaved: (v) {
              editData.answer = v;
            },
          ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () async {
            FormState form = formKey.currentState;
            if (editData.question == null) {
              ISAlert(context, '제목은 필수 입력값 입니다.');
              return;
            }

            form.save();

            editData.userId = GetStorage().read('logininfo')['id'];

            await ReservationController.to.setReserveFAQ(context, editData.toJson(), 'UPDATE').then((value) async {
              if (value == '00') {
                Navigator.pop(context, true);
              }
            });
          },
        ),
        ISButton(
          label: '삭제',
          buttonColor: Colors.redAccent,
          iconData: Icons.delete,
          onPressed: () {
            ISConfirm(_scaffoldKey.currentContext, 'FAQ 삭제', '해당 FAQ 정보를 삭제 하시겠습니까?', (context) async {
              ReservationController.to.deleteReserveFAQ(context, widget.seq.toString()).then((value) async {
                Navigator.pop(context, true);

                if (value == '00') {
                  Navigator.pop(context, true);
                }
              });
            });
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text('FAQ 수정'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10),
            Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 480,
      height: 380,
      child: result,
    );
  }
}
