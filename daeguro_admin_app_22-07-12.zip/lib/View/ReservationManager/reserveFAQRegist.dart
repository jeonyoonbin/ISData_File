import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/is_select_date.dart';
import 'package:daeguro_admin_app/Model/notice/noticeDetailModel.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveFAQEditModel.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/NoticeManager/noticeFileUpload.dart';
import 'package:daeguro_admin_app/View/NoticeManager/notice_controller.dart';

import 'package:daeguro_admin_app/Network/FileUpLoader.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reservationmanager_controller.dart';
import 'package:daeguro_admin_app/constants/serverInfo.dart';

import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';

class ReserveFAQRegist extends StatefulWidget {
  const ReserveFAQRegist({
    Key key,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ReserveFAQRegistState();
  }
}

class ReserveFAQRegistState extends State<ReserveFAQRegist> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  ReserveFAQEditModel registData;

  List<SelectOptionVO> selectBox_FAQGbn = List();

  @override
  void dispose() {
    selectBox_FAQGbn.clear();
    registData = null;

    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReservationController());

    registData = ReserveFAQEditModel();

    registData.gbn = '1';
    selectBox_FAQGbn.clear();

    selectBox_FAQGbn.add(new SelectOptionVO(value: '1', label: '주문/결제'));
    selectBox_FAQGbn.add(new SelectOptionVO(value: '2', label: '회원정보'));
    selectBox_FAQGbn.add(new SelectOptionVO(value: '3', label: '이용문의'));
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          ISSelect(
            label: 'FAQ 구분',
            value: registData.gbn,
            dataList: selectBox_FAQGbn,
            onChange: (value) {
              setState(() {
                registData.gbn = value;
                formKey.currentState.save();
              });
            },
          ),
          ISInput(
            value: registData.question,
            autofocus: true,
            context: context,
            label: '질문 내용',
            onChange: (v) {
              registData.question = v;
              setState(() {});
            },
          ),
          ISInput(
            value: registData.answer,
            context: context,
            label: '질문 답글',
            height: 140,
            contentPadding: 20,
            keyboardType: TextInputType.multiline,
            maxLines: 8,
            onChange: (v) {
              registData.answer = v;
              setState(() {});
            },
          ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () async {
            FormState form = formKey.currentState;
            if (registData.question == null) {
              ISAlert(context, '질문내용은 필수 입력값 입니다.');
              return;
            }

            form.save();

            registData.seq = 0;
            registData.userId = GetStorage().read('logininfo')['id'];

            print(registData.toJson());

            await ReservationController.to.setReserveFAQ(context, registData.toJson(), 'INSERT').then((value) async {
              if (value == '00') {
                Navigator.pop(context, true);
              }
            });
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('FAQ 등록'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10),
            Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 480,
      height: 380,
      child: result,
    );
  }
}
