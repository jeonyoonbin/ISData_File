
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/Network/DioClient.dart';

import 'package:daeguro_admin_app/constants/serverInfo.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class PushController extends GetxController with SingleGetTickerProviderMixin {
  static PushController get to => Get.find();
  BuildContext context;

  List qDataItems = [];

  int totalRowCnt = 0;

  RxInt raw = 0.obs;
  RxInt page = 0.obs;

  @override
  void onInit() {
    raw.value = 15;
    page.value = 1;

    super.onInit();
  }

  Future<List<dynamic>> getData(String status, String keyword) async {
    List<dynamic> qData = [];

    final response = await DioClient().get(ServerInfo.REST_URL_PUSH + '?status=${status.toString()}&keyword=${keyword.toString()}&page=${page.value}&rows=${raw.value}');

    if (response.data['code'].toString() == null || response.data['code'].toString() == 'null' || response.data['code'].toString() == '') {
      return null;
    }

    if (response.data['code'] == '00') {
      totalRowCnt = int.parse(response.data['count'].toString());

      qData.assignAll(response.data['data']);
    }
    else
      return null;

    return qData;

  }


  Future<dynamic> postPushData(dynamic data) async {
    final response = await DioClient().post(ServerInfo.REST_URL_PUSH_SET, data: data);

    if (response.data['code'] != '00') {
      return response;//.data['msg'];
    }
    else
      return null;
  }

  Future<dynamic> putPushData(dynamic data) async {
    final response = await DioClient().put(ServerInfo.REST_URL_PUSH_UPDATE, data: data);

    if (response.data['code'] != '00') {
      return response;
    }
    else
      return null;
  }

  Future<dynamic> getDetailData(String pushCd) async {
    final response = await DioClient().get(ServerInfo.REST_URL_PUSH + '/${pushCd}');

    if (response.data['code'] == '00') {
      return response.data['data'];
    }

    return null;
  }

  Future<dynamic> getPushCount(String range_gbn, String marketing_push_gbn) async {
    final response = await DioClient().get(ServerInfo.REST_URL_PUSH_COUNT  + '?range_gbn=$range_gbn&marketing_push_gbn=$marketing_push_gbn');

    if (response.data['code'] == '00') {
      return response.data['count'];
    }

    return null;
  }

  Future<List<dynamic>> getHistData(String push_cd) async {
    List<dynamic> qData = [];

    final response = await DioClient().get(ServerInfo.REST_URL_PUSH_HIST  + '?push_cd=${push_cd.toString()}&page=${page.value}&rows=${raw.value}');

    if (response.data['code'].toString() == null || response.data['code'].toString() == 'null' || response.data['code'].toString() == '') {
      return null;
    }

    if (response.data['code'] == '00') {
      totalRowCnt = int.parse(response.data['count'].toString());

      qData.assignAll(response.data['data']);
    }
    else
      return null;

    return qData;

  }

  Future<dynamic> postSendSimplFCM(String telno, String title, String msg) async {
    final response = await DioClient().post(ServerInfo.REST_URL_PUSH_SIMPLEFCM + '?telno=${telno}&title=${title}&msg=${msg}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return null;
  }

  Future<dynamic> deletePushData(String pushCd) async {
    final response = await DioClient().delete(ServerInfo.REST_URL_PUSH_DELETE  + '?push_cd=${pushCd}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return null;
  }

}
