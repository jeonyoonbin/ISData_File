


import 'dart:typed_data';

import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/is_tableInput.dart';
import 'package:daeguro_admin_app/Model/pushRequestModel.dart';
import 'package:daeguro_admin_app/Util/multi_masked_formatter.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/PushManager/push_controller.dart';

import 'package:date_format/date_format.dart';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';


class PushSendRegist extends StatefulWidget {
  const PushSendRegist({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return PushSendRegistState();
  }
}

enum RadioUseGbn { gbn1, gbn2 }

class PushSendRegistState extends State<PushSendRegist> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  List<SelectOptionVO> selectBox_Year = [];
  List<SelectOptionVO> selectBox_Month = [];
  List<SelectOptionVO> selectBox_Day = [];

  List<SelectOptionVO> selectBox_Hour = [];
  List<SelectOptionVO> selectBox_Minute = [];

  List<SelectOptionVO> selectBox_sendDataType = [];

  List<SelectOptionVO> selectBox_sendTargetUser = [];
  List<SelectOptionVO> selectBox_sendTarget = [];

  RadioUseGbn _radioUseGbn;

  List<String> telNoArray = [];

  String _pushTestPhonenum = '';

  String _send_gbn = 'I';
  String _push_title = '';
  String _push_msg = '';
  String _object_gbn = 'D';
  String _range_gbn = 'M';
  String _marketing_push_gbn = 'Y';

  String _sendTypeYear = '';
  String _sendTypeMonth = '';
  String _sendTypeDay = '';
  String _sendTypeHour = '09';
  String _sendTypeMinute = '00';

  String _sendlimitStartHour = '';
  String _sendlimitStartMinute = '';
  String _sendlimitEndHour = '';
  String _sendlimitEndMinute = '';

  String btnTypeString = '';

  String selectedArrayStr = '선택된 파일이 없습니다.';

  @override
  void dispose(){
    selectBox_Year.clear();
    selectBox_Month.clear();
    selectBox_Hour.clear();
    selectBox_Minute.clear();

    super.dispose();
  }

  _reset() {
    selectBox_Year.add(new SelectOptionVO(value: DateTime.now().year.toString(), label: DateTime.now().year.toString()));

    var Monthlist = Iterable<int>.generate(13).toList();
    Monthlist.forEach((element) {
      String value = (element < 10) ? '0${element}': element.toString();

      if (element > 0) {
        selectBox_Month.add(new SelectOptionVO(value: '${value}', label: '${value}'));
      }
    });

    var Hourlist = Iterable<int>.generate(24).toList();
    selectBox_Hour.add(new SelectOptionVO(value: '', label: ' '));
    Hourlist.forEach((element) {
      String value = (element < 10) ? '0${element}': element.toString();
      selectBox_Hour.add(new SelectOptionVO(value: '${value}', label: '${value}'));
    });

    var Minutelist = Iterable<int>.generate(6).toList();
    selectBox_Minute.add(new SelectOptionVO(value: '', label: ' '));
    Minutelist.forEach((element) {
      String value = (element == 0) ? '00': '${(element*10)}';
      selectBox_Minute.add(new SelectOptionVO(value: '${value}', label: '${value}'));
    });


    selectBox_sendDataType.add(new SelectOptionVO(value: 'D', label: 'DB'));
    selectBox_sendDataType.add(new SelectOptionVO(value: 'C', label: 'CSV'));

    selectBox_sendTargetUser.add(new SelectOptionVO(value: 'A', label: '전체회원'));
    selectBox_sendTargetUser.add(new SelectOptionVO(value: 'M', label: '회원만'));
    selectBox_sendTargetUser.add(new SelectOptionVO(value: 'N', label: '비회원'));

    selectBox_sendTarget.add(new SelectOptionVO(value: 'N', label: '전체'));
    selectBox_sendTarget.add(new SelectOptionVO(value: 'Y', label: '마케팅 동의만'));


    setState(() {

    });
  }

  _query() {


    setMonthlyDayReset();

    setState(() {

    });
  }

  setMonthlyDayReset(){
    selectBox_Day.clear();

    String endDay = formatDate(DateTime(int.parse(_sendTypeYear), int.parse(_sendTypeMonth) + 1, 0), [dd]);

    var Daylist = Iterable<int>.generate(int.parse(endDay)+1).toList();

    Daylist.forEach((element) {
      String value = (element < 10) ? '0${element}': element.toString();

      if (element > 0)
        selectBox_Day.add(new SelectOptionVO(value: '${value}', label: '${value}'));
    });
  }

  Future<List<String>> openExcelCSVFile() async {
    List<String> returnData = [];
    try {

      FilePickerResult result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['csv', 'xls', 'xlsx'],);
      Uint8List uploadfile = result.files.single.bytes;

      if (uploadfile == null)
        return null;

      if(result != null) {
        if (result.files.first.name.contains('csv') == true){
          String str = new String.fromCharCodes(uploadfile);
          //print('str:${str}');

          List<List<String>> tempList = Utils.splitCSV(str);
          tempList.removeAt(0);
          tempList.forEach((element) {
            List<String> tempInner = element;

            tempInner.forEach((data) {
              returnData.add("${data}");
              //print('data:${data.toString()}');
            });
          });

          // CSV Parser(구)
          // List csvList;
          // List csvFileContentList = [];
          // List CsvModuleList = [];
          //
          // String csvFileHeaderRowColumnTitles = 'telno';
          // var outputAsUint8List = new Uint8List.fromList(str.codeUnits);
          // csvFileContentList = utf8.decode(outputAsUint8List).split('\r\n');
          // print('Selected CSV File contents: ${csvFileContentList}');
          //
          // // 열 제목과 순서를 확인하십시오. CSV 파일이 올바른 템플릿 형식인지 확인하십시오.?
          // if (csvFileContentList[0].toString().trim().hashCode != csvFileHeaderRowColumnTitles.hashCode) {
          //   // CSV 파일 형식이 올바르지 않습니다.
          //   print('CSV 파일의 형식이 잘못된 것 같습니다.');
          //   //return '오류: CSV 파일의 형식이 잘못된 것 같습니다.';
          // }
          //
          // // CSV 파일에 내용이 있는지 확인 - 내용 길이 > 0?
          // if (csvFileContentList.length == 0 || csvFileContentList[1].length == 0) {
          //   // CSV 파일에 내용이 없습니다.
          //   print('CSV 파일에 내용이 없습니다.');
          //   //return '오류: CSV 파일에 콘텐츠가 없습니다.';
          // }
          // // CSV 파일 형식이 유효한 것 같습니다.
          // print('CSV 파일의 형식이 유효하고 내용이 있으므로 구문 분석 진행...');
          //
          // // CSV 파일의 현재 첫 번째 행에 열 헤더가 있습니다. 제거하십시오.
          // csvFileContentList.removeAt(0);
          // print('Column Header를 제거한 후 선택한 CSV 파일 내용:');
          //
          // // CSV 파일에서 중복 행 제거
          // csvList = csvFileContentList.toSet().toList();
          // print('중복 제거/중복 제거 후 CSV 파일 내용');
          // //CSV Files in Array
          // print('csvList:${csvList}');
          //
          // //Array to class module
          // csvList.forEach((csvRow) {
          //   if (csvRow != null && csvRow.trim().isNotEmpty) {
          //     print('result:${csvRow.split(',').toString()}');
          //     // 현재 행에 내용이 있고 null 또는 비어 있지 않음
          //     //CsvModuleList.add(CsvModuleList.fromList(csvRow.split(','));
          //   }
          // });

        }
        else{
          var excel = Excel.decodeBytes(uploadfile);
          for (var sheetName in excel.tables.keys) {
            // print(excel.tables[sheetName].maxRows);
            // print(excel.tables[sheetName].maxCols);
            for (var row in excel.tables[sheetName].rows) {
              if (row != null) {
                row.forEach((data) {
                  if(data != null && data.value != null){
                    if (data.rowIndex > 0)
                      returnData.add("${data.value}");
                  }
                });
              }
            }} //for
        }
      }
      return returnData;
    }
    catch(e) {
      print(e);
      return null;
    }
  }

  @override
  void initState() {
    super.initState();

    Get.put(PushController());

    DateTime now = DateTime.now();
    _sendTypeYear = now.year.toString();
    _sendTypeMonth = now.month.toString();
    _sendTypeDay = now.day.toString();

    if (int.parse(_sendTypeMonth) < 10)
      _sendTypeMonth = '0${_sendTypeMonth}';

    if (int.parse(_sendTypeDay) < 10)
      _sendTypeDay = '0${_sendTypeDay}';


    _sendTypeHour = '09';
    _sendTypeMinute = '00';

    // _send_gbn = 'I';
    // _push_title = '';
    // _push_msg = '';
    // _object_gbn = 'D';
    // _range_gbn = 'M';
    // _marketing_push_gbn = 'Y';
    // _status = '00';

    _radioUseGbn = RadioUseGbn.gbn1;
    btnTypeString = '즉시';

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      _query();
    });
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Table(
              columnWidths: const {0: FixedColumnWidth(130), 1: FlexColumnWidth(),},
              defaultVerticalAlignment: TableCellVerticalAlignment.middle,
              border: TableBorder.symmetric(inside: BorderSide(width: 0.1, color: Colors.black), outside: BorderSide(width: 1.2, color: Colors.black12)),
              children: [
                TableRow(children: [
                  Container(
                      color: Colors.blue[50],
                      height: 44,
                      alignment: Alignment.center,
                      child: Text('제목', style: TextStyle(fontSize: 12),)
                  ),
                  Container(
                    color: Colors.white,
                    child: ISTableInput(
                      height: 30,
                      value: _push_title,
                      textStyle: TextStyle(fontSize: 12),
                      onChange: (v) {
                        _push_title = v;
                        setState(() {

                        });
                      },
                    ),
                  ),
                ]),
                TableRow(children: [
                  Container(
                      color: Colors.blue[50],
                      height: 74,
                      alignment: Alignment.center,
                      child: Text('발송 방식', style: TextStyle(fontSize: 12))
                  ),
                  Container(
                    color: Colors.white,
                    height: 76,
                    padding: EdgeInsets.only(left: 16),//symmetric(horizontal: 16),
                    child: Column(
                      children: [
                        SizedBox(height: 4,),
                        Row(
                          children: [
                            Radio(
                                value: RadioUseGbn.gbn1,
                                groupValue: _radioUseGbn,
                                onChanged: (v) async {
                                  _radioUseGbn = v;
                                  _send_gbn = 'I';
                                  setState(() {
                                    btnTypeString = '즉시';
                                  });
                                }),
                            Text('즉시', style: TextStyle(fontSize: 12)),
                            Container(
                              margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                              child: Radio(
                                  value: RadioUseGbn.gbn2,
                                  groupValue: _radioUseGbn,
                                  onChanged: (v) async {
                                    _radioUseGbn = v;
                                    _send_gbn = 'R';
                                    setState(() {
                                      btnTypeString = '예약';
                                    });
                                  }),
                            ),
                            Text('예약', style: TextStyle(fontSize: 12)),
                          ],
                        ),
                        SizedBox(height: 4,),
                        _send_gbn == 'I' ? Container(height: 30,) : Row(
                          children: [
                            ISSelect(
                              width: 70,
                              height: 30,
                              paddingEnabled: false,
                              value: _sendTypeYear ?? '',
                              dataList: selectBox_Year,
                              onChange: (v){
                                _sendTypeYear = v;
                              },
                            ),
                            SizedBox(width: 4,),
                            Text('년'),
                            SizedBox(width: 10,),
                            ISSelect(
                              width: 60,
                              height: 30,
                              paddingEnabled: false,
                              value: _sendTypeMonth ?? '',
                              dataList: selectBox_Month,
                              onChange: (v){
                                _sendTypeMonth = v;
                                setMonthlyDayReset();
                                setState(() {

                                });
                              },
                            ),
                            SizedBox(width: 4,),
                            Text('월'),
                            SizedBox(width: 4,),
                            ISSelect(
                              width: 60,
                              height: 30,
                              paddingEnabled: false,
                              value: _sendTypeDay ?? '',
                              dataList: selectBox_Day,
                              onChange: (v){
                                _sendTypeDay = v;
                              },
                            ),
                            SizedBox(width: 4,),
                            Text('일'),
                            SizedBox(width: 10,),
                            ISSelect(
                              width: 60,
                              height: 30,
                              paddingEnabled: false,
                              value: _sendTypeHour ?? '',
                              dataList: selectBox_Hour,
                              onChange: (v){
                                _sendTypeHour = v;
                              },
                            ),
                            SizedBox(width: 4,),
                            Text('시'),
                            SizedBox(width: 4,),
                            ISSelect(
                              width: 60,
                              height: 30,
                              paddingEnabled: false,
                              value: _sendTypeMinute ?? '',
                              dataList: selectBox_Minute,
                              onChange: (v){
                                _sendTypeMinute = v;
                              },
                            ),
                            SizedBox(width: 4,),
                            Text('분'),
                          ],
                        )
                      ],
                    ),
                  ),
                ]),
                TableRow(children: [
                  Container(
                      color: Colors.blue[50],
                      height: 54,
                      alignment: Alignment.center,
                      child: Text('발송제한시간', style: TextStyle(fontSize: 12))
                  ),
                  Container(
                    color: Colors.white,
                    height: 56,
                    padding: EdgeInsets.only(left: 16),//symmetric(horizontal: 16),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            ISSelect(
                              width: 60,
                              height: 30,
                              paddingEnabled: false,
                              value: _sendlimitStartHour ?? '',
                              dataList: selectBox_Hour,
                              onChange: (v){
                                _sendlimitStartHour = v;
                              },
                            ),
                            SizedBox(width: 4,),
                            Text('시'),
                            SizedBox(width: 10,),
                            ISSelect(
                              width: 60,
                              height: 30,
                              paddingEnabled: false,
                              value: _sendlimitStartMinute ?? '',
                              dataList: selectBox_Minute,
                              onChange: (v){
                                _sendlimitStartMinute = v;
                              },
                            ),
                            SizedBox(width: 4,),
                            Text('분'),
                            SizedBox(width: 10,),
                            Text('~'),
                            SizedBox(width: 10,),
                            ISSelect(
                              width: 60,
                              height: 30,
                              paddingEnabled: false,
                              value: _sendlimitEndHour ?? '',
                              dataList: selectBox_Hour,
                              onChange: (v){
                                _sendlimitEndHour = v;
                              },
                            ),
                            SizedBox(width: 4,),
                            Text('시'),
                            SizedBox(width: 10,),
                            ISSelect(
                              width: 60,
                              height: 30,
                              paddingEnabled: false,
                              value: _sendlimitEndMinute ?? '',
                              dataList: selectBox_Minute,
                              onChange: (v){
                                _sendlimitEndMinute = v;
                              },
                            ),
                            SizedBox(width: 4,),
                            Text('분'),
                          ],
                        ),
                        SizedBox(height: 4,),
                        Text('* 설정된 시간까지 발송이 중지 됩니다.', style: TextStyle(fontSize: 10, color: Colors.red),),
                      ],
                    ),
                  ),
                ]),
                TableRow(children: [
                  Container(
                      color: Colors.blue[50],
                      height: 74,
                      alignment: Alignment.center,
                      child: Text('발송 대상(DB/CSV)', style: TextStyle(fontSize: 12))
                  ),
                  Container(
                    color: Colors.white,
                    height: 76,
                    padding: EdgeInsets.only(left: 16),//symmetric(horizontal: 16),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 4,),
                        Row(
                          children: [
                            Row(
                              children: [
                                ISSelect(
                                  width: 120,
                                  height: 30,
                                  paddingEnabled: false,
                                  value: _object_gbn ?? '',
                                  dataList: selectBox_sendDataType,
                                  onChange: (v){
                                    _object_gbn = v;

                                    setState(() {
                                      // if (_object_gbn == 'C'){
                                      //   _range_gbn = '';
                                      //   _marketing_push_gbn = '';
                                      // }
                                    });
                                  },
                                )
                              ],
                            ),
                            SizedBox(width: 20,),
                            (_object_gbn == 'D') ? Container(height: 30,) :
                            Row(
                              children: [
                                MaterialButton(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Icon(Icons.file_download, color: Colors.blue, size: 21,),
                                      SizedBox(width: 4,),
                                      Text('샘플파일(sample.csv) 다운로드', style: TextStyle(color: Colors.black, fontSize: 12))
                                    ],
                                  ),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                                  onPressed: ()  {
                                    //_launchInBrowser(_themeImageRealURL +'?tm=${Utils.getTimeStamp()}');
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),
                        SizedBox(height: 4,),
                        (_object_gbn == 'D') ? Container(height: 30,) :
                        Row(
                          children: [
                            MaterialButton(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Icon(Icons.folder_open, color: Colors.blue, size: 21,),
                                  SizedBox(width: 4,),
                                  Text(selectedArrayStr, style: TextStyle(color: Colors.black, fontSize: 11, fontWeight: FontWeight.bold))
                                ],
                              ),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                              onPressed: ()  async {
                                await openExcelCSVFile().then((value) {
                                  if(value==null){
                                    ISAlert(context, '양식에 맞춰 파일을 다시 등록해주세요.');
                                  }else{
                                    telNoArray.clear();
                                    telNoArray = value.toSet().toList();
                                    // telNoArray.forEach((element) {
                                    //   print('telNoArray:${element.toString()}');
                                    // });

                                    if (telNoArray.length > 0)
                                      selectedArrayStr = ' 데이터 로드 성공 : [${telNoArray.length}건]';
                                  }
                                });

                                setState(() {
                                });
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
                TableRow(children: [
                  Container(
                      color: Colors.blue[50],
                      height: 44,
                      alignment: Alignment.center,
                      child: Text('발송 범위', style: TextStyle(fontSize: 12))
                  ),
                  Container(
                    color: Colors.white,
                    height: 46,
                    padding: EdgeInsets.only(left: 16),//symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        if (_object_gbn == 'D')
                        ISSelect(
                          //ignoring: _object_gbn == 'C' ? true : false,
                          width: 120,
                          height: 30,
                          paddingEnabled: false,
                          value: _range_gbn ?? '',
                          dataList: selectBox_sendTargetUser,
                          onChange: (v){
                            _range_gbn = v;
                          },
                        ),
                        SizedBox(width: 10,),
                        if (_object_gbn == 'D')
                        Row(
                          children: [
                            ISSelect(
                              //ignoring: _object_gbn == 'C' ? true : false,
                              width: 120,
                              height: 30,
                              paddingEnabled: false,
                              value: _marketing_push_gbn ?? '',
                              dataList: selectBox_sendTarget,
                              onChange: (v){
                                _marketing_push_gbn = v;
                              },
                            ),
                          ],
                        ),
                        if (_object_gbn == 'D')
                          Container(
                            padding: EdgeInsets.only(left: 10),
                            child: MaterialButton(
                              color: Colors.blue,
                              minWidth: 70,
                              height: 36,
                              child: Text('대상 건수 조회', style: TextStyle(color: Colors.white, fontSize: 12),),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                              onPressed: (){
                                PushController.to.getPushCount(_range_gbn, _marketing_push_gbn).then((value) {
                                  if (value == null){
                                    ISAlert(context, '조회 실패 \n\n다시 시도해 주세요.');
                                  }
                                  else{
                                    ISAlert(context, '해당 대상은 [${Utils.getCashComma(value.toString())}]건입니다.');
                                  }
                                });
                              },
                            ),
                          ),
                      ],
                    ),
                  ),
                ]),
                TableRow(children: [
                  Container(
                      color: Colors.blue[50],
                      height: 134,
                      alignment: Alignment.center,
                      child: Text('푸시 문구', style: TextStyle(fontSize: 12))
                  ),
                  Container(
                    color: Colors.white,
                    child: ISTableInput(
                      value: _push_msg,// formData.menuGroupMemo ?? '',
                      //context: context,
                      height: 120,
                      keyboardType: TextInputType.multiline,
                      maxLines: 8,
                      maxLength: 50,//임시로 50글자로 제한
                      onChange: (v) {
                        _push_msg = v;
                      },
                    ),
                  ),
                ]),
                TableRow(children: [
                  Container(
                      color: Colors.blue[50],
                      height: 44,
                      alignment: Alignment.center,
                      child: Text('테스트 발송 번호', style: TextStyle(fontSize: 12),)
                  ),
                  Container(
                    color: Colors.white,
                    child: Row(
                      children: [
                        ISTableInput(
                          width: 200,
                          height: 30,
                          value: _pushTestPhonenum,//formData.bussCon ?? '',
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[
                            MultiMaskedTextInputFormatter(masks: ['xxx-xxxx-xxxx', 'xxxx-xxxx-xxxx', 'xxx-xxx-xxxx', 'xxxx-xxxx'], separator: '-')
                          ],
                          //label: '업태',
                          textStyle: TextStyle(fontSize: 12),
                          onChange: (v) {
                            _pushTestPhonenum = v;
                            setState(() {

                            });
                          },
                        ),
                        SizedBox(width: 4,),
                        MaterialButton(
                          color: Colors.blue,
                          minWidth: 70,
                          height: 36,
                          child: Text('단건 발송 테스트', style: TextStyle(color: Colors.white, fontSize: 12),),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                          onPressed: (){
                            ISConfirm(context, '단건 발송 테스트', '단건 테스트 발송 하시겠습니까?', (context) async {
                              String uCode = GetStorage().read('logininfo')['uCode'];

                              PushController.to.postSendSimplFCM(_pushTestPhonenum.toString().replaceAll('-', ''), '테스트', '대구로 푸시 테스트\n\n발송자:관리앱[${uCode}]').then((value) {
                                if (value != null){
                                  ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                }
                                else{
                                  Navigator.pop(context);
                                  ISAlert(context, '정상 발송 되었습니다.');
                                }
                              });
                            });
                          },
                        )

                      ],
                    ),
                  )
                ]),
              ]
          ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '${btnTypeString} 발송',
          iconData: Icons.sms,
          onPressed: () async {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            form.save();

            ISConfirm(context, '푸시 발송 수정(${btnTypeString})', '푸시 발송을 수정 하시겠습니까?', (contextPopup) async {
              Navigator.pop(contextPopup);

              await ISProgressDialog(context).show(status: '발송 등록중...');

              pushRequestModel formData = pushRequestModel();
              //formData.push_cd = widget.push_cd;
              formData.push_title = _push_title;
              formData.send_gbn = _send_gbn;
              formData.reserve_send_dt = _send_gbn == 'I' ? '' : (_sendTypeYear+_sendTypeMonth+_sendTypeDay+_sendTypeHour+_sendTypeMinute);
              formData.send_limit_st_time = (_sendlimitStartHour+_sendlimitStartMinute);
              formData.send_limit_end_time = (_sendlimitEndHour+_sendlimitEndMinute);
              formData.object_gbn = _object_gbn;
              formData.range_gbn = _object_gbn == 'C' ? '' : _range_gbn;
              formData.marketing_push_gbn = _object_gbn == 'C' ? '' : _marketing_push_gbn;
              formData.push_msg = _push_msg;
              formData.telno = telNoArray;
              formData.ucode = GetStorage().read('logininfo')['uCode'];

              PushController.to.postPushData(formData.toJson()).then((value) async {
                if (value != null){
                  Navigator.pop(context);

                  String errorStr = value.data['msg'];
                  if (value.data['code'] == '50')
                    errorStr = '- ${value.data['msg']}\n\n발송 예정내역 확인 후, 다시 시도해주세요.';

                  ISAlert(context, '정상처리 되지 않았습니다. \n\n${errorStr}');
                }
                else{
                  ISProgressDialog(context).dismiss();
                  Navigator.pop(context, true);
                }
              });
            });


          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('푸시 발송 등록'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
                padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
                child: form
            ),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 700,
      height: 620,
      child: result,
    );
  }

}