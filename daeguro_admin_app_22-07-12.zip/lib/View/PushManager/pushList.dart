import 'dart:convert';

import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_input.dart';
import 'package:daeguro_admin_app/Model/pushListModel.dart';
import 'package:daeguro_admin_app/Network/FileDownLoader.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/PushManager/pushMsgPopup.dart';
import 'package:daeguro_admin_app/View/PushManager/pushSendEdit.dart';
import 'package:daeguro_admin_app/View/PushManager/pushSendRegist.dart';
import 'package:daeguro_admin_app/View/PushManager/push_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:daeguro_admin_app/constants/serverInfo.dart';
import 'package:date_format/date_format.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import 'package:http/http.dart' as http;
import 'package:universal_html/html.dart' show AnchorElement;


class PushList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return PushListState();
  }
}

class PushListState extends State {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<pushListModel> dataList = <pushListModel>[];

  String _div = ' ';
  String _pushKeyword = '';

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  bool downloadSuccess = false;

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    //loadData();
  }

  _edit({String noticeSeq}) async {

  }

  _regist() async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: PushSendRegist(),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 500), () {
          loadData();
        });
      }
    });
  }

  _query() {
    formKey.currentState.save();

    PushController.to.page.value = _currentPage;
    PushController.to.raw.value = _selectedpagerows;
    loadData();
  }

  loadData() async {
    dataList.clear();

    await PushController.to.getData(_div, _pushKeyword).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((e) {
          pushListModel temp = pushListModel.fromJson(e);

          temp.st_date = temp.st_date.replaceAll('T', '  ');

          dataList.add(temp);
        });

        _totalRowCnt = PushController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
      }
    });

    //if (this.mounted) {
    setState(() {

    });
    //}
  }

  @override
  void initState() {
    super.initState();

    Get.put(PushController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      _query();
    });

    setState(() {
    });
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //testSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Row(
            children: [
              Text('총: ${Utils.getCashComma(PushController.to.totalRowCnt.toString())}건', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
            ],
          ),
          Row(
            children: [
              Column(
                children: [
                  ISSearchDropdown(
                    label: '전송 상태',
                    width: 100,
                    value: _div,
                    onChange: (value) {
                      setState(() {
                        _div = value;
                        _currentPage = 1;
                        _query();
                      });
                    },
                    item: [
                      DropdownMenuItem(value: ' ', child: Text('전체'),),
                      DropdownMenuItem(value: '00', child: Text('대기'),),
                      DropdownMenuItem(value: '10', child: Text('발송중'),),
                      DropdownMenuItem(value: '20', child: Text('완료'),),
                      DropdownMenuItem(value: '30', child: Text('중지'),),
                    ].cast<DropdownMenuItem<String>>(),
                  ),
                ],
              ),
              ISSearchInput(
                label: '제목',//'키워드',
                width: 200,
                value: _pushKeyword,
                onChange: (v) {
                  _pushKeyword = v;
                },
                onFieldSubmitted: (value) {
                  _currentPage = 1;
                  _query();
                },
              ),
              Row(
                children: [
                  ISSearchButton(
                      width: 80,
                      label: '조회',
                      iconData: Icons.search,
                      onPressed: () => {_currentPage = 1, _query()}),
                  SizedBox(width: 8,),
                  if (AuthUtil.isAuthCreateEnabled('241') == true)
                    ISSearchButton(
                        width: 110,
                        label: '발송 등록', iconData: Icons.add, onPressed: () => _regist()),
                ],
              )
            ],
          )
        ],
      ),
    );

    return Container(
      //padding: EdgeInsets.only(left: 140, right: 140, bottom: 0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          form,
          buttonBar,
          Divider(),
          ISDatatable(
            panelHeight: (MediaQuery.of(context).size.height-defaultContentsHeight),
            listWidth: Responsive.getResponsiveWidth(context, 640), // Responsive.isTablet(context) ? MediaQuery.of(context).size.width : contentListWidth,
            rows: dataList.map((item) {
              return DataRow(cells: [
                DataCell(Center(child: SelectableText(item.rnum.toString() ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                //DataCell(Align(child: SelectableText(item.PUSH_TITLE.toString() ?? '--', style: TextStyle(color: Colors.black), showCursor: true),alignment: Alignment.centerLeft)),
                DataCell(Align(child: MaterialButton(
                  height: 30.0,
                  minWidth: 40,
                  child: Text(item.push_title.toString() ?? '--',style: TextStyle(color: Colors.black, fontSize: 13),),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) => Dialog(
                        child: PushMsgPopup(title: item.push_title, msg: item.push_msg),
                      ),
                    ).then((v) async {
                      if (v != null) {

                      }
                    });
                  },
                ), alignment: Alignment.centerLeft)),
                DataCell(Center(child: SelectableText(item.send_gbn.toString() ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(Center(child: SelectableText(item.st_date.toString() ?? '--', style: TextStyle(color: Colors.black, fontSize: 12), showCursor: true))),
                DataCell(Center(child: SelectableText(item.object_gbn.toString() ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(Align(child: getSendTargetStr(item.object_gbn, item.range_gbn, item.marketing_push_gbn), alignment: Alignment.center)),
                DataCell(
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // SelectableText(item.s_cnt.toString(), style: TextStyle(color: Colors.black, fontSize: 12), showCursor: true),
                        // Text('/'),
                        SelectableText(Utils.getCashComma(item.cnt.toString()), style: TextStyle(color: Colors.black, fontSize: 12), showCursor: true),
                      ],
                    ),
                  ),
                ),
                DataCell(Center(child: InkWell(
                  child: Icon(Icons.file_download, size: 16, color: Colors.blue,),
                  onTap: () async {
                    downloadSuccess = false;

                    String ucode = GetStorage().read('logininfo')['uCode'];

                    String tempURL = ServerInfo.jobMode == 'dev' ? 'https://dgpub.282.co.kr:8500' + ServerInfo.REST_URL_PUSH_EXPORT_TEXT : ServerInfo.REST_URL_PUSH_EXPORT_TEXT;

                    await http.get(tempURL + '?push_cd=${item.push_cd}&ucode=$ucode').then((http.Response response) {
                      var bytes = response.bodyBytes;

                      DateTime now = DateTime.now();
                      DateTime date = DateTime(now.year, now.month, now.day);

                      AnchorElement(href: 'data:text/plain;charset=utf-16le;base64,${base64.encode(bytes)}')
                        ..setAttribute('download', '푸시로그_${item.push_title}_${formatDate(date, [yy, mm, dd])}.txt')
                        ..click();
                    }).then((value) => downloadSuccess = true);

                  },
                ))),
                //DataCell(Center(child: SelectableText(_getStatus(item.status.toString()) ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(
                  Center(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SelectableText(item.ins_name.toString() == '' ? '등록: --' : '등록: ${item.ins_name.toString()}(${item.ins_date.toString()})', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                          SelectableText(item.mod_name.toString() == '' ? '수정: --' : '수정: ${item.mod_name.toString()}(${item.mod_date.toString()})', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                        ],
                      ),
                    ),
                  ),
                ),
                DataCell(
                  Center(
                    child: item.status == '30' ? Container(): Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // if (item.status == '00' || item.status == '10')
                        //   MaterialButton(
                        //     height: Responsive.isDesktop(context) == true ? 34.0 : 30.0,
                        //     color: Colors.redAccent,
                        //     minWidth: 40,
                        //     child: Text('중지',style: TextStyle(color: Colors.white, fontSize: 12),),
                        //     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                        //     onPressed: () async {
                        //       ISConfirm(context, '푸시 발송 중지', '해당 푸시 발송을 중지하시겠습니까?', (context) async {
                        //         // await PushController.to.deletePushData(item.push_cd).then((value) {
                        //         //   _query();
                        //         //   Navigator.of(context).pop();
                        //         // });
                        //       });
                        //     },
                        //   ),
                        //SizedBox(width: 8,),
                        if (item.status == '00')
                          Container(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: MaterialButton(
                              height: Responsive.isDesktop(context) == true ? 34.0 : 30.0,
                              color: Colors.green,
                              minWidth: 40,
                              child: Text('수정',style: TextStyle(color: Colors.white, fontSize: 12),),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                              onPressed: () async {
                                if (AuthUtil.isAuthEditEnabled('241') == false) {
                                  ISAlert(context, '처리 권한이 없습니다. \n\n관리자에게 문의 바랍니다');
                                  return;
                                }

                                showDialog(
                                  context: context,
                                  builder: (BuildContext context) => Dialog(
                                    child: PushSendEdit(push_cd: item.push_cd),
                                  ),
                                ).then((v) async {
                                  if (v != null) {
                                    await Future.delayed(Duration(milliseconds: 500), () {
                                      loadData();
                                    });
                                  }
                                });
                              },
                            ),
                          ),
                        //SizedBox(width: 8,),
                        if (item.status == '00' || item.status == '20')
                          Container(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: MaterialButton(
                              height: Responsive.isDesktop(context) == true ? 34.0 : 30.0,
                              color: Colors.black38,
                              minWidth: 40,
                              child: Text('삭제',style: TextStyle(color: Colors.white, fontSize: 12),),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                              onPressed: () async {
                                ISConfirm(context, '푸시 발송 삭제', '해당 푸시 발송을 삭제하시겠습니까?', (context) async {
                                  await PushController.to.deletePushData(item.push_cd).then((value) {
                                    _query();
                                    Navigator.of(context).pop();
                                  });
                                });
                              },
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ]);
            }).toList(),
            columns: <DataColumn>[
              DataColumn(label: Expanded(child: Text('번호', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('제목', textAlign: TextAlign.left)),),
              DataColumn(label: Expanded(child: Text('발송방식', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('발송(예정)일시', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('대상', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('발송범위', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('대상 건수', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('로그', textAlign: TextAlign.center)),),
              //DataColumn(label: Expanded(child: Text('상태', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('등록자/수정자', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('관리', textAlign: TextAlign.center)),),
            ],
          ),
          Divider(),
          showPagerBar(),
        ],
      ),
    );
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                //Text('row1'),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context) ? Container(height: 48) : Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Text('페이지당 행 수 : ', style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),),
                Container(
                  width: 70,
                  child: DropdownButton(
                      value: _selectedpagerows,
                      isExpanded: true,
                      style: TextStyle(
                          fontSize: 12,
                          color: Colors.black,
                          fontFamily: 'NotoSansKR'),
                      items: Utils.getPageRowList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedpagerows = value;
                          _currentPage = 1;
                          _query();
                        });
                      }),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget getSendTargetStr(String objectGbn, String rangeGbn, String marketingPushGbn) {
    Widget retWidget;

    if (objectGbn == 'DB'){
      retWidget = Column(
         mainAxisAlignment: MainAxisAlignment.center,
         children: [
             SelectableText(rangeGbn ?? '--', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
             SelectableText(marketingPushGbn ?? '--', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
         ],
      );
    }
    else if (objectGbn == 'CSV'){
      retWidget = SelectableText('파일', style: TextStyle(color: Colors.black), showCursor: true);
    }
    else
      retWidget = SelectableText('--', style: TextStyle(color: Colors.black), showCursor: true);

    return retWidget;
  }

  String _getStatus(String value) {
    String retValue = '--';

    if (value.toString().compareTo('00') == 0)           retValue = '대기';
    else if (value.toString().compareTo('10') == 0)      retValue = '발송중';
    else if (value.toString().compareTo('20') == 0)      retValue = '완료';
    else if (value.toString().compareTo('30') == 0)      retValue = '중지';
    else                                                 retValue = '--';

    return retValue;
  }
}
