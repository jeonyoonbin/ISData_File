import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:flutter/material.dart';

import 'package:js/js.dart';

@JS('pagePrev')
external void pagePrev();

class PageIPGetFail extends StatelessWidget {
  const PageIPGetFail({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.warning_outlined),
              SizedBox(width: 4,),
              Text('System Message'),
            ],
          ),
          SizedBox(height: 20,),
          Text('사용자 클라이언트의 장치 정보 조회가 실패하였습니다.', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
          SizedBox(height: 20,),
          ISButton(
            iconData: Icons.check,
            iconColor: Colors.white,
            label: '이전화면',
            textStyle: TextStyle(color: Colors.white),
            onPressed: () {
              //Navigator.pop(context);
              pagePrev();

              //Utils.logout();
              //Navigator.pushNamed(context, '/login');
            },
          ),
        ],
      ),
    );
  }
}
