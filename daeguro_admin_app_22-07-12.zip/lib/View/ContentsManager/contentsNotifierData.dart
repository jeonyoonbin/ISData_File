
class ContentsNotifierData{
  ContentsNotifierData();

  String contents_cd = '';
}