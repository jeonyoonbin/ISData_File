import 'dart:convert';
import 'package:daeguro_admin_app/Model/Contents/contentsWebtoonSortListModel.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contents_controller.dart';
import 'package:daeguro_admin_app/View/NoticeManager/Reser/reserNotice_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/get_core.dart';
import 'package:get/get_instance/src/extension_instance.dart';

class ContentsWebtoonUpdateSort extends StatefulWidget {
  final String cartegory_gbn;

  const ContentsWebtoonUpdateSort({Key key, this.cartegory_gbn}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ContentsWebtoonUpdateSortState();
  }
}

class ContentsWebtoonUpdateSortState extends State<ContentsWebtoonUpdateSort> with SingleTickerProviderStateMixin {
  //final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  //final ScrollController _scrollController = ScrollController();
  final List<ContentsWebtoonSrotListModel> sortList = <ContentsWebtoonSrotListModel>[];

  bool isSaveEnabled = false;

  _query() {
    loadData();
  }

  loadData() async {
    sortList.clear();

    await ContentsController.to.getSortList(widget.cartegory_gbn, context);

    if (this.mounted) {
      ContentsController.to.qDataSortList.forEach((e) {
        ContentsWebtoonSrotListModel temp = ContentsWebtoonSrotListModel.fromJson(e);

        sortList.add(temp);
      });

      if (isSaveEnabled == true) {
        await Future.delayed(Duration(milliseconds: 500), () async {
          List<String> sortDataList = [];
          sortList.forEach((element) {
            sortDataList.add(element.CONTENTS_CD.toString());
          });

          if (sortDataList.length != 0) {
            String jsonData = jsonEncode(sortDataList);
            await ContentsController.to.updateSort(jsonData, context);
          }

          isSaveEnabled = false;
        });
      }

      setState(() {});
    }
  }

  _editListSort(List<String> sortDataList) async {
    String jsonData = jsonEncode(sortDataList);

    await ContentsController.to.updateSort(jsonData, context);

    await Future.delayed(Duration(milliseconds: 500), () {
      loadData();
    });
  }

  @override
  void initState() {
    super.initState();

    Get.put(ContentsController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      isSaveEnabled = true;
      _query();
    });
  }

  @override
  Widget build(BuildContext context) {
    var form = Container(
      padding: EdgeInsets.only(left: 30, right: 30),
      child: Text(
        '- 게시 상태만 표시 됩니다.',
        style: TextStyle(fontSize: 12.0),
      ),
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('노출 순서 변경'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 10),
          form,
          SizedBox(height: 10),
          Expanded(
            child: ReorderableListView(
                onReorder: _onReorder_Event,
                scrollDirection: Axis.vertical,
                padding: const EdgeInsets.only(bottom: 8.0),
                children: List.generate(sortList.length, (index) {
                  return GestureDetector(
                    // onTap: (){
                    //   Navigator.pushNamed(context, '/editor', arguments: UserController.to.userData[index]);
                    // },
                    key: Key('$index'),
                    child:
                    Card(
                      color: Colors.white,
                      elevation: 2.0,
                      child: ListTile(
                        //leading: Text(dataList[index].siguName),
                        title: Row(
                          children: [
                            Text(
                              '[' + sortList[index].CONTENTS_CD.toString() + '] ' + sortList[index].CONTENTS_TITLE ?? '--',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                            ),
                            Container(
                                margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                width: 30,
                                height: 16,
                                alignment: Alignment.center,
                                color: Color.fromRGBO(87, 170, 58, 0.8431372549019608),
                                child: Text(
                                  '게시',
                                  style: TextStyle(fontSize: 8, color: Colors.white),
                                ))
                          ],
                        ),
                      ),
                    ),
                  );
                })),
          ),
        ],
      )
    );
    return SizedBox(
      width: 420,
      height: 580, //isDisplayDesktop(context) ? 580 : 1000,
      child: result,
    );
  }

  void _onReorder_Event(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final ContentsWebtoonSrotListModel item = sortList.removeAt(oldIndex);
      sortList.insert(newIndex, item);

      List<String> sortDataList = [];
      sortList.forEach((element) {
        sortDataList.add(element.CONTENTS_CD.toString());
      });
      _editListSort(sortDataList);
    });
  }
}
