

import 'dart:convert';

import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/Model/notice/noticeEmListModel.dart';
import 'package:daeguro_admin_app/Network/DioClient.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/NoticeManager/notice_controller.dart';

import 'package:daeguro_admin_app/constants/serverInfo.dart';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:http/http.dart' as http;
import 'package:image/image.dart' as Im;
import 'package:flutter/foundation.dart' show compute;

class NoticeEmRegist extends StatefulWidget {
  const NoticeEmRegist({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return NoticeEmRegistState();
  }
}

class NoticeEmRegistState extends State<NoticeEmRegist> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  noticeEmListModel editData;

  List<SelectOptionVO> selectBox_noticeGbn = List();

  //String _imageURLStr = '';
  String _pickedImagePath = '';
  var _fileImage = null;

  @override
  void dispose(){
    selectBox_noticeGbn.clear();
    editData = null;

    PaintingBinding.instance.imageCache.clearLiveImages();
    PaintingBinding.instance.imageCache.clear();

    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    Get.put(NoticeController());

    selectBox_noticeGbn.clear();

    selectBox_noticeGbn.add(new SelectOptionVO(value: '0', label: '앱 중지 처리'));
    selectBox_noticeGbn.add(new SelectOptionVO(value: '1', label: '앱 사용 처리'));
    selectBox_noticeGbn.add(new SelectOptionVO(value: '2', label: '앱 사용 처리(팝업 후)'));


    editData = new noticeEmListModel();
    editData.use = '0';
    editData.title = '';
    editData.contents = '';
    editData.url = '';

    editData.android_ver = '';
    editData.android_min = '';
    editData.ios_ver = '';
    editData.ios_min = '';
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: ISSelect(
                  //ignoring: true,
                  label: '앱사용구분',
                  value: editData.use,
                  dataList: selectBox_noticeGbn,
                  onChange: (value) {
                    setState(() {
                      editData.use = value;
                      formKey.currentState.save();
                    });
                  },
                ),
              ),
              // Flexible(
              //   flex: 1,
              //   child: ISSelect(
              //     ignoring: true,
              //     label: '공지타입',
              //     value: editData.noticeType,
              //     dataList: selectBox_noticeType,
              //     onChange: (value) {
              //       setState(() {
              //         editData.noticeType = value;
              //         formKey.currentState.save();
              //       });
              //     },
              //   ),
              // ),
            ],
          ),
          ISInput(
            value: editData.title,
            autofocus: true,
            context: context,
            label: '제목',
            onChange: (v) {
              editData.title = v;
            },
          ),
          ISInput(
            value: editData.contents,
            context: context,
            label: '내용',
            height: 140,
            contentPadding: 20,
            keyboardType: TextInputType.multiline,
            maxLines: 8,
            onChange: (v) {
              editData.contents = v;
            },
          ),
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: ISInput(
                  value: editData.android_min,
                  autofocus: true,
                  context: context,
                  label: 'Android(최소 앱버전)',
                  onChange: (v) {
                    editData.android_min = v;
                  },
                ),
              ),
              Flexible(
                flex: 1,
                child: ISInput(
                  value: editData.android_ver,
                  autofocus: true,
                  context: context,
                  label: 'Android(권장 앱버전)',
                  onChange: (v) {
                    editData.android_ver = v;
                  },
                ),
              ),
            ],
          ),
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: ISInput(
                  value: editData.ios_min,
                  autofocus: true,
                  context: context,
                  label: 'IOS(최소 앱버전)',
                  onChange: (v) {
                    editData.ios_min = v;
                  },
                ),
              ),
              Flexible(
                flex: 1,
                child: ISInput(
                  value: editData.ios_ver,
                  autofocus: true,
                  context: context,
                  label: 'IOS(권장 앱버전)',
                  onChange: (v) {
                    editData.ios_ver = v;
                  },
                ),
              ),
            ],
          ),
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: ISInput(
                  value: editData.url,
                  autofocus: true,
                  context: context,
                  label: '클릭시 이동될 URL',
                  onChange: (v) {
                    editData.url = v;
                  },
                ),
              ),
            ],
          ),
          ISInput(
            value: _pickedImagePath,
            readOnly: true,
            context: context,
            label: '공지 이미지(클릭)',
            //hintText: '클릭 후, 파일 선택',
            onTap: () async {
              FilePickerResult result = await FilePicker.platform.pickFiles(withReadStream: false);

              if (result != null) {
                _fileImage = null;
                _fileImage = result;

                String fileName = result.files.first.name;

                setState(() {
                  _pickedImagePath = fileName;

                  editData.img_url = '';

                  print('_pickedImagePath:${_pickedImagePath}');
                });

              }
              else {
                // User canceled the picker
              }

              setState(() {});
            },
            suffixIcon: InkWell(
              child: Icon(null, size: 16, color: Colors.grey,),
              onTap: () {

              },
            ),
            onChange: (v) {
              //editData.noticeTitle = v;
            },
          )
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
          ISButton(
            label: '저장',
            iconData: Icons.save,
            onPressed: () async {
              FormState form = formKey.currentState;
              if (!form.validate()) {
                return;
              }

              form.save();

              await ISProgressDialog(context).show(status: '이미지 업로드중...');

              String ucode = GetStorage().read('logininfo')['uCode'];

              String tempURL = ServerInfo.jobMode == 'dev' ? 'https://ext.daeguro.co.kr:45010' + ServerInfo.REST_URL_NOTICEEM : ServerInfo.REST_URL_NOTICEEM;
              //print('tempURL:${tempURL}');

              var request = http.MultipartRequest('POST', Uri.parse(tempURL));//ServerInfo.REST_URL_NOTICEEM));
              request.headers.addAll({'Content-Type' : 'multipart/form-data'});

              if  (_fileImage != null){
                var bytes = _fileImage.files.first.bytes;
                String filename = _fileImage.files.first.name;

                await Future.delayed(Duration(milliseconds: 500), () async {
                  Im.Image image = await compressImage(bytes);

                  //request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));//리사이징 없이 업로드 할 경우
                  request.files.add(http.MultipartFile.fromBytes('formFile', Im.encodeJpg(image, quality: 100), filename: filename));
                });
              }

              //request.fields['seq'] = editData.seq;
              request.fields['use'] = editData.use;
              request.fields['title'] = editData.title;
              request.fields['contents'] = editData.contents;
              request.fields['url'] = editData.url;
              request.fields['android_ver'] = editData.android_ver;
              request.fields['android_min'] = editData.android_min;
              request.fields['ios_ver'] = editData.ios_ver;
              request.fields['ios_min'] = editData.ios_min;
              request.fields['ucode'] = ucode;

              //print('fields: ${request.fields.toString()}');

              request.send().then((response) async {
                //print('response status:${response.statusCode}, data:${response.toString()}');
                if (response.statusCode == 200) {
                  response.stream.bytesToString().asStream().listen((event) async {
                    var responseData = json.decode(event);
                    await DioClient().postRestLog('0', '/NoticeEm/post', 'upload Success \n\n statusCode: ${response.statusCode} \n msg: ${responseData['msg'].toString()} ');
                    //print('response code:${response.statusCode}, responseData:${responseData.toString()}');
                    //print('response path:${responseData['msg'].toString()}');

                    setState(() {
                      //isImageSaveEnabled = true;
                    });
                  });
                }
                else{
                  await DioClient().postRestLog('0', '/NoticeEm/post', 'upload Fail \n\n statusCode: ${response.statusCode} \n param:${request.fields.toString()}');
                  //_showResult = '[전송오류] 관리자에게 문의하세요.';
                }
              });


              await ISProgressDialog(context).dismiss();

              await Future.delayed(Duration(milliseconds: 500), () {
                Navigator.pop(context, true);

                // setState(() {
                //   _deleteImageFromCache();
                // });
              });
            },
          ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('앱긴급공지 등록'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10),
            Container(
                padding: EdgeInsets.symmetric(horizontal: 8.0),
                child: form
            ),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 480,
      height: 620,
      child: result,
    );
  }

  Future _deleteImageFromCache() async {
    //await CachedNetworkImage.evictFromCache(url);

    PaintingBinding.instance.imageCache.clearLiveImages();
    PaintingBinding.instance.imageCache.clear();

    //await DefaultCacheManager().removeFile(key);
    //await DefaultCacheManager().emptyCache();
    setState(() {});
  }

  static Future<Im.Image> compressImage(List<int> list) async {
    return compute(_decodeImage, list);
  }

  static Im.Image _decodeImage(List<int> list) {
    Im.Image retImage = null;

    Im.Image image = Im.decodeImage(list);
    //print('original_image w:${image.width}, h:${image.height}, length:${image.length}');
    if (image.width > 1280) {
      retImage = Im.copyResize(image, width: 1280); // choose the size here, it will maintain aspect ratio
      //print('resize_image w:${retImage.width}, h:${retImage.height}, length:${retImage.length}');
    }
    else
      retImage = image;

    return retImage;
  }
}
