import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/Model/notice/noticeEmListModel.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/NoticeManager/noticeEmEdit.dart';
import 'package:daeguro_admin_app/View/NoticeManager/noticeEmRegist.dart';
import 'package:daeguro_admin_app/View/NoticeManager/notice_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

List items = List();

class NoticeEmList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return NoticeEmListState();
  }
}

class NoticeEmListState extends State {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<noticeEmListModel> dataList = <noticeEmListModel>[];

  String _noticeUseGbn = ' ';

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    //loadData();
  }

  _edit({String noticeSeq}) async {
    noticeEmListModel editData = null;

    await NoticeController.to.getEmDetailData(noticeSeq.toString()).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        editData = noticeEmListModel.fromJson(value);
      }
    });

    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: NoticeEmEdit(sData: editData),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 500), (){
          _query();
        });
      }
    });
  }

  _regist() async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: NoticeEmRegist(),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 500), () {
          loadData();
        });
      }
    });
  }

  _query() {
    formKey.currentState.save();

    NoticeController.to.page.value = _currentPage;
    NoticeController.to.raw.value = _selectedpagerows;
    loadData();
  }

  loadData() async {
    dataList.clear();

    await NoticeController.to.getEmData(_noticeUseGbn).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((e) {
          noticeEmListModel temp = noticeEmListModel.fromJson(e);
          dataList.add(temp);
        });

        _totalRowCnt = NoticeController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
      }
    });

    //if (this.mounted) {
    setState(() {

    });
    //}
  }

  @override
  void initState() {
    super.initState();

    Get.put(NoticeController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      _query();
    });

    setState(() {
    });
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //testSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Row(
            children: [
              Text('총: ${Utils.getCashComma(NoticeController.to.totalRowCnt.toString())}건', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
            ],
          ),
          Row(
            children: [
              Column(
                children: [
                  ISSearchDropdown(
                    label: '사용구분',
                    width: 240,
                    value: _noticeUseGbn,
                    onChange: (value) {
                      setState(() {
                        _noticeUseGbn = value;
                        _currentPage = 1;
                        _query();
                      });
                    },
                    item: [
                      DropdownMenuItem(value: ' ', child: Text('전체'),),
                      DropdownMenuItem(value: '0', child: Text('앱 중지 처리'),),
                      DropdownMenuItem(value: '1', child: Text('앱 사용 처리'),),
                      DropdownMenuItem(value: '2', child: Text('앱 사용 처리(팝업 후)'),),
                    ].cast<DropdownMenuItem<String>>(),
                  ),
                ],
              ),
              SizedBox(width: 8,),
              Row(
                children: [
                  ISSearchButton(
                      width: 80,
                      label: '조회',
                      iconData: Icons.search,
                      onPressed: () => {_currentPage = 1, _query()}),
                  // SizedBox(width: 8,),
                  // if (AuthUtil.isAuthCreateEnabled('239') == true)
                  //   ISSearchButton(
                  //       width: 80,
                  //       label: '등록', iconData: Icons.add, onPressed: () => _regist()),
                ],
              )
            ],
          )
        ],
      ),
    );

    return Container(
      //padding: EdgeInsets.only(left: 140, right: 140, bottom: 0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          form,
          buttonBar,
          Divider(),
          ISDatatable(
            panelHeight: (MediaQuery.of(context).size.height-defaultContentsHeight),
            listWidth: Responsive.getResponsiveWidth(context, 640), // Responsive.isTablet(context) ? MediaQuery.of(context).size.width : contentListWidth,
            rows: dataList.map((item) {
              return DataRow(cells: [
                DataCell(Center(
                    child: Text(
                      item.seq.toString() ?? '--',
                      style: TextStyle(color: Colors.black),
                    ))),
                DataCell(Align(
                    child: Text(
                      item.title.toString() ?? '--',
                      style: TextStyle(color: Colors.black),
                    ),alignment: Alignment.centerLeft)),
                DataCell(Center(
                    child: Text(
                        _getNoticeUse(item.use.toString()) ?? '--',
                        style: TextStyle(color: item.use.toString() == '0' ? Colors.red : Colors.green, fontWeight: FontWeight.bold)))),

                DataCell(
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SelectableText(item.android_min.toString() == '' ? '최소: --' : '최소: ${item.android_min.toString()}', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                        SelectableText(item.android_ver.toString() == '' ? '권장: --' : '권장: ${item.android_ver.toString()}', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                      ],
                    ),
                  ),
                ),
                DataCell(
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SelectableText(item.ios_min.toString() == '' ? '최소: --' : '최소: ${item.ios_min.toString()}', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                        SelectableText(item.ios_ver.toString() == '' ? '권장: --' : '권장: ${item.ios_ver.toString()}', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                      ],
                    ),
                  ),
                ),
                DataCell(
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SelectableText(item.ins_name.toString() == '' ? '등록자: --' : '등록자: ${item.ins_name.toString()}', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                        SelectableText(item.ins_date.toString() == '' ? '등록일: --' : '등록일: ${item.ins_date.toString()}', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                      ],
                    ),
                  ),
                ),
                DataCell(
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SelectableText(item.mod_name.toString() == '' ? '수정자: --' : '수정자: ${item.mod_name.toString()}', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                        SelectableText(item.mod_date.toString() == '' ? '수정일: --' : '수정일: ${item.mod_date.toString()}', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                      ],
                    ),
                  ),
                ),

                DataCell(
                  Center(
                    child: InkWell(
                        onTap: () {
                          _edit(noticeSeq: item.seq);
                        },
                        child: Icon(Icons.edit)
                    ),
                  ),
                ),
              ]);
            }).toList(),
            columns: <DataColumn>[
              DataColumn(label: Expanded(child: Text('순번', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('게시제목', textAlign: TextAlign.left)),),
              DataColumn(label: Expanded(child: Text('앱사용구분', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('앱버전(Android)', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('앱버전(IOS)', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('등록정보', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('수정정보', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('관리', textAlign: TextAlign.center)),),
            ],
          ),
          Divider(),
          showPagerBar(),
        ],
      ),
    );
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                //Text('row1'),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context) ? Container(height: 48) : Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Text('페이지당 행 수 : ', style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),),
                Container(
                  width: 70,
                  child: DropdownButton(
                      value: _selectedpagerows,
                      isExpanded: true,
                      style: TextStyle(
                          fontSize: 12,
                          color: Colors.black,
                          fontFamily: 'NotoSansKR'),
                      items: Utils.getPageRowList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedpagerows = value;
                          _currentPage = 1;
                          _query();
                        });
                      }),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _getNoticeUse(String value) {
    String retValue = '--';

    if (value.toString().compareTo('0') == 0)      retValue = '(공지 후) 사용불가';
    else if (value.toString().compareTo('1') == 0) retValue = '정상사용';
    else if (value.toString().compareTo('2') == 0) retValue = '(공지 후) 정상사용';
    return retValue;
  }
}
