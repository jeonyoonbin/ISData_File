﻿import 'package:flutter/material.dart';

class ISDatatable extends StatelessWidget {
  final double panelHeight;
  final double listWidth;
  final VoidCallback onPressed;
  final List<DataColumn> columns;
  final List<DataRow> rows;
  final double headingRowHeight;
  final double dataRowHeight;
  final double dividerThickness;
  final bool showCheckboxColumn;
  final Axis viewScrollAxis;
  final ScrollController controller;
  final EdgeInsetsGeometry padding;
  ISDatatable({
    this.panelHeight,
    this.listWidth,
    this.onPressed,
    this.rows,
    this.columns,
    this.headingRowHeight,
    this.dataRowHeight,
    this.dividerThickness,
    this.showCheckboxColumn,
    this.viewScrollAxis,
    this.controller,
    this.padding
  });

  @override
  Widget build(BuildContext context) {
    return Scrollbar(
      isAlwaysShown: controller == null ? false : true,
      controller: controller,
      child: Container(
        height: panelHeight,
        child: ListView(
          controller: controller,
          physics: ClampingScrollPhysics(),
          shrinkWrap: true,
          scrollDirection: viewScrollAxis ?? Axis.horizontal,
          padding: padding ?? const EdgeInsets.fromLTRB(0, 0, 0, 20),//(20, 0, 20, 20),
          children: <Widget>[
            Container(
              width: listWidth ?? 1650,//MediaQuery.of(context).size.width,
              child: ListView(
                  shrinkWrap: true,
                  scrollDirection: Axis.vertical,
                  children: <Widget>[
                    DataTable(
                      dividerThickness: dividerThickness ?? 1.0,
                      horizontalMargin: 8,
                      checkboxHorizontalMargin: 10,
                      headingRowColor:MaterialStateColor.resolveWith((states) => Colors.blue[50]),
                      headingTextStyle: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'NotoSansKR', color: Colors.black54, fontSize: 12),
                      headingRowHeight: headingRowHeight ?? 34,
                      dataRowHeight: dataRowHeight ?? 40.0,
                      dataTextStyle: TextStyle(fontWeight: FontWeight.normal, fontFamily: 'NotoSansKR', color: Colors.black, fontSize: 13),
                      columnSpacing: 0,
                      showCheckboxColumn: showCheckboxColumn  ?? false,
                      rows: rows,
                      columns: columns,
                    ),
                  ]
              ),
            ),
          ],
        ),
      ),
    );
  }
}
