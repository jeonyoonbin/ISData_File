import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/models/Common/commonNoFlagModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionSoldOutEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateInfoReserveModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopReserveFacilitiesEdit extends StatefulWidget {
  final ShopOperateInfoReserveModel? sData;
  final String? ccCode;
  const ShopReserveFacilitiesEdit({Key? key, this.sData, this.ccCode})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopReserveFacilitiesEditState();
  }
}

class ShopReserveFacilitiesEditState extends State<ShopReserveFacilitiesEdit> {

  ShopOperateInfoReserveModel? setData;

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());

    setData = widget.sData;
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 400),
      contentPadding: const EdgeInsets.symmetric(horizontal: 0.0),
      isFillActions: true,
      title: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('편의시설', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          SizedBox(width: 10),
          Text('*중복 선택이 가능합니다.', style: const TextStyle(fontSize: 14, color: Colors.grey),),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image(image: AssetImage('images/Convenience_1.png')),
                    SizedBox(height: 3),
                    Text('주차가능', style: TextStyle(fontSize: 13)),
                    ISCheckbox(
                        label: '',
                        value: setData?.facilities_1.toString() == 'Y' ? true : false,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              setData?.facilities_1 = 'Y';
                            } else {
                              setData?.facilities_1 = 'N';
                            }
                          });
                        }
                    ),
                  ],
                ),
                Column(
                  children: [
                    Image(image: AssetImage('images/Convenience_2.png')),
                    SizedBox(height: 3),
                    Text('발렛가능', style: TextStyle(fontSize: 13)),
                    ISCheckbox(
                        label: '',
                        value: setData?.facilities_2.toString() == 'Y' ? true : false,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              setData?.facilities_2 = 'Y';
                            } else {
                              setData?.facilities_2 = 'N';
                            }
                          });
                        }
                    ),
                  ],
                ),
                Column(
                  children: [
                    Image(image: AssetImage('images/Convenience_3.png')),
                    SizedBox(height: 3),
                    Text('단체석', style: TextStyle(fontSize: 13)),
                    ISCheckbox(
                        label: '',
                        value: setData?.facilities_3.toString() == 'Y' ? true : false,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              setData?.facilities_3 = 'Y';
                            } else {
                              setData?.facilities_3 = 'N';
                            }
                          });
                        }
                    ),
                  ],
                ),
                Column(
                  children: [
                    Image(image: AssetImage('images/Convenience_4.png')),
                    SizedBox(height: 3),
                    Text('프라이빗룸', style: TextStyle(fontSize: 13)),
                    ISCheckbox(
                        label: '',
                        value: setData?.facilities_4.toString() == 'Y' ? true : false,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              setData?.facilities_4 = 'Y';
                            } else {
                              setData?.facilities_4 = 'N';
                            }
                          });
                        }
                    ),
                  ],
                ),
                Column(
                  children: [
                    Image(image: AssetImage('images/Convenience_5.png')),
                    SizedBox(height: 3),
                    Text('테라스', style: TextStyle(fontSize: 13)),
                    ISCheckbox(
                        label: '',
                        value: setData?.facilities_5.toString() == 'Y' ? true : false,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              setData?.facilities_5 = 'Y';
                            } else {
                              setData?.facilities_5 = 'N';
                            }
                          });
                        }
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image(image: AssetImage('images/Convenience_6.png')),
                    SizedBox(height: 3),
                    Text('콜키지', style: TextStyle(fontSize: 13)),
                    ISCheckbox(
                        label: '',
                        value: setData?.facilities_6.toString() == 'Y' ? true : false,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              setData?.facilities_6 = 'Y';
                            } else {
                              setData?.facilities_6 = 'N';
                            }
                          });
                        }
                    ),
                  ],
                ),
                Column(
                  children: [
                    Image(image: AssetImage('images/Convenience_7.png')),
                    SizedBox(height: 3),
                    Text('아기의자', style: TextStyle(fontSize: 13)),
                    ISCheckbox(
                        label: '',
                        value: setData?.facilities_7.toString() == 'Y' ? true : false,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              setData?.facilities_7 = 'Y';
                            } else {
                              setData?.facilities_7 = 'N';
                            }
                          });
                        }
                    ),
                  ],
                ),
                Column(
                  children: [
                    Image(image: AssetImage('images/Convenience_8.png')),
                    SizedBox(height: 3),
                    Text('놀이방', style: TextStyle(fontSize: 13)),
                    ISCheckbox(
                        label: '',
                        value: setData?.facilities_8.toString() == 'Y' ? true : false,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              setData?.facilities_8 = 'Y';
                            } else {
                              setData?.facilities_8 = 'N';
                            }
                          });
                        }
                    ),
                  ],
                ),
                Column(
                  children: [
                    Image(image: AssetImage('images/Convenience_9.png')),
                    SizedBox(height: 3),
                    Text('노키즈존', style: TextStyle(fontSize: 13)),
                    ISCheckbox(
                        label: '',
                        value: setData?.facilities_9.toString() == 'Y' ? true : false,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              setData?.facilities_9 = 'Y';
                            } else {
                              setData?.facilities_9 = 'N';
                            }
                          });
                        }
                    ),
                  ],
                ),
                Column(
                  children: [
                    Image(image: AssetImage('images/Convenience_10.png')),
                    SizedBox(height: 3),
                    Text('반려동물', style: TextStyle(fontSize: 13)),
                    ISCheckbox(
                        label: '',
                        value: setData?.facilities_10.toString() == 'Y' ? true : false,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              setData?.facilities_10 = 'Y';
                            } else {
                              setData?.facilities_10 = 'N';
                            }
                          });
                        }
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10,),
          ],
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              ISConfirm(context, '편의시설 변경', '편의시설 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                var sendData = {
                  '"shopCd"': '"' + AuthService.SHOPCD + '"',
                  '"ccCode"': '"' + widget.ccCode.toString() + '"',
                  '"facilities_1"': '"' + setData!.facilities_1.toString() + '"',
                  '"facilities_2"': '"' + setData!.facilities_2.toString() + '"',
                  '"facilities_3"': '"' + setData!.facilities_3.toString() + '"',
                  '"facilities_4"': '"' + setData!.facilities_4.toString() + '"',
                  '"facilities_5"': '"' + setData!.facilities_5.toString() + '"',
                  '"facilities_6"': '"' + setData!.facilities_6.toString() + '"',
                  '"facilities_7"': '"' + setData!.facilities_7.toString() + '"',
                  '"facilities_8"': '"' + setData!.facilities_8.toString() + '"',
                  '"facilities_9"': '"' + setData!.facilities_9.toString() + '"',
                  '"facilities_10"': '"' + setData!.facilities_10.toString() + '"',
                  '"userId"': '"' + AuthService.uCode + '"',
                };

                if (isOK){
                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ReserveController.to.updateReserveFacilities(sendData.toString()))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                      ISAlert(context, title: '알림', content: '변경이 완료되었습니다.');
                    }
                    else {
                      ISAlert(context, content: '정상 등록되지 않았습니다.\n[관리자에게 문의 바랍니다]\n→ ${value}');
                    }
                  }
                }
              });
            },
            child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


