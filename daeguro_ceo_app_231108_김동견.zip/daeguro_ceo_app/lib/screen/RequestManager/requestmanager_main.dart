import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown_v2.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/RequestManager/requestListModel.dart';
import 'package:daeguro_ceo_app/models/RequestManager/requestServiceDataModel.dart';
import 'package:daeguro_ceo_app/models/RequestManager/requestShopInfoEditModel.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:data_table_2/data_table_2.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class RequestInfoMain extends StatefulWidget {
  final double? tabviewHeight;

  const RequestInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<RequestInfoMain> createState() => _RequestInfoMainState();
}

class _RequestInfoMainState extends State<RequestInfoMain> with PageMixin {
  bool _initialized = false;

  String? startdate = '';
  String? enddate = '';
  String? tempStr;
  String? selectedType = '1000';

  String? selectedStatus = '%';
  String? selectedRequestType = '%';

  int selectedPageNumber = 1;
  int totalPage = 0;
  bool pickDate = false;

  bool hasRowTaps = true;

  // Override height values for certain rows
  bool hasRowHeightOverrides = true;

  // Color each Row by index's parity
  bool hasZebraStripes = false;

  int _selectedCount = 0;

  //status [상태] %: 전체, 10:접수(요청), 30:진행중(심사중), 35:보완, 40:완료, 50:취소, 20:취소요청
  //serviceGbn [요청 구분]  %: 전체, 100:사업자 정보변경, 101: 사업자번호변경, 102: 해지요청, 200:매장정보(주소)  201:매장정보(업종카테고리), 202:매장정보(POS/배달 연동), 203:매장정보(매장유형)
  //300:메뉴이미지변경, 600: 착한매장 신청, 601: 착한매장 해지

  List<RequestListModel> dataList = <RequestListModel>[];
  List<RequestListModel> dataDetailList = <RequestListModel>[];
  Map<int, List<RequestServiceDataModel>> mobileDataDetailSourceMap = {};

  List<ISOptionModel> requireTypeList = <ISOptionModel>[];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // if (!_initialized) {
    //   requestManagerDataSource = RequestManagerSource(context, dataList, false, true, true, false);
    //   // Default sorting sample. Set __sortColumnIndex to 0 and uncoment the lines below
    //   // if (_sortColumnIndex == 0) {
    //   //   _sort<String>((d) => d.name, _sortColumnIndex!, _sortAscending);
    //   // }
    //   _initialized = true;
    //   requestManagerDataSource.addListener(() {
    //     setState(() {});
    //   });
    // }
  }

  @override
  void dispose() {
    //requestManagerDataSource.dispose();
    dataList.clear();
    dataDetailList.clear();
    mobileDataDetailSourceMap.clear();
    requireTypeList.clear();
    super.dispose();
  }

  requestRequireTypeData() async {
    requireTypeList.clear();
    RequestController.to.getRequireType().then((value) {
      if (value == null){
        ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      }
      else{
        requireTypeList.add(ISOptionModel(value: '%', label: '요청 내용'));
        value.forEach((element) {
          String typeCode = element['type_code'].toString();
          if (typeCode == '200' || typeCode == '201' || typeCode == '202' || typeCode == '300' || typeCode == '301' || typeCode == '302' || typeCode == '400' || typeCode == '600' ) {
            requireTypeList.add(ISOptionModel(value: typeCode, label: element['type_name'].toString()));
          }
        });
      }
    });
  }

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(RequestController.to.getRequireList(selectedStatus!, selectedRequestType!, startdate!.replaceAll('-', ''), enddate!.replaceAll('-', ''), selectedPageNumber.toString()))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        RequestListModel temp = RequestListModel();

        temp.seq = element['seq'] as String;
        temp.status = element['status'] as String;
        temp.statusName = element['statusName'] as String;
        temp.serviceGbn = element['serviceGbn'] as String;
        temp.serviceGbnName = element['serviceGbnName'] as String;
        temp.insertDate = element['insertDate'] as String;
        temp.modDate = element['modDate'] as String;
        temp.answerText = element['answerText'] as String;
        temp.serviceData = '[' + element['serviceData'].toString() + ']';
        temp.fileName = element['fileName'] as String;

        // if (temp.serviceGbn == '600'){//착한매장 신청
        //
        // }

        dataList.add(temp);
      });

      totalPage = RequestController.to.total_page;
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(RequestController());

    startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestRequireTypeData();
      requestAPIData();
    });
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;
        selectedStatus = '%';
        selectedRequestType = '%';
        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestRequireTypeData();
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    double contentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 401 : 373);

    return fluentUI.ScaffoldPage.withPadding(
      resizeToAvoidBottomInset: false,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: ScrollConfiguration(
        behavior: ScrollConfiguration.of(context).copyWith(scrollbars: Responsive.isMobile(context) ? false : true),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ISLabelBarMain(
                leading: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('변경 요청 내역', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(width: 6,),
                    Responsive.isMobile(context) ? Container() : const Text('* 최대 6개월 이내 요청 처리 이력만 조회 가능합니다.', style: TextStyle(color: Colors.grey, fontSize: 14),),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
              const SizedBox(height: 8),
              Responsive.isMobile(context)
                  ? const Text(
                '* 최대 6개월 이내 요청 처리 이력만 조회 가능합니다.',
                style: TextStyle(color: Colors.grey, fontSize: 14),
              )
                  : Container(),
              const SizedBox(height: 8),
              Responsive.isMobile(context) ? mobileRequestListView(context) : requestDataTable(contentHeight, context),
              Material(
                child: ISNumberPagination(
                  threshold: 5,
                  controlButton: const SizedBox(
                    width: 10,
                    height: 10,
                  ),
                  onPageChanged: (int pageNumber) {
                    //do somthing for selected page
                    setState(() {
                      selectedPageNumber = pageNumber;
                    });

                    requestAPIData();
                  },
                  fontSize: 12,
                  pageTotal: totalPage,
                  pageInit: selectedPageNumber,
                  // picked number when init page
                  colorPrimary: Colors.black,
                  colorSub: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Material requestDataTable(double contentHeight, fluentUI.BuildContext context) {
    return Material(
      child: SizedBox(
        height: contentHeight,
        child: DataTable2(
            headingRowHeight: 40,
            columnSpacing: 0,
            horizontalMargin: 0,
            headingRowColor: MaterialStateProperty.all(Colors.grey[100],),
            headingTextStyle: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54),
            border: TableBorder(
              borderRadius: BorderRadius.circular(10),
              top: BorderSide(color: Colors.grey[300]!),
              right: BorderSide(color: Colors.grey[300]!),
              bottom: BorderSide(color: Colors.grey[300]!),
              left: BorderSide(color: Colors.grey[300]!),
              horizontalInside: BorderSide.none,
            ),

            dividerThickness: 0, // this one will be ignored if [border] is set above
            bottomMargin: 10,
            minWidth: 900,
            columns: [
              DataColumn2(
                fixedWidth: 150,
                label: Center(
                  child: ISSearchDropdownV2(
                    // label: '업체타입',
                    value: selectedStatus,
                    onChange: (value) {
                      selectedStatus = value;

                      selectedPageNumber = 1;

                      requestAPIData();
                    },
                    item: [
                      const DropdownMenuItem(value: '%', child: Text('상태 전체'),),
                      const DropdownMenuItem(value: '10', child: Text('요청'),),
                      const DropdownMenuItem(value: '30', child: Text('심사 중'),),
                      const DropdownMenuItem(value: '40', child: Text('완료'),),
                      const DropdownMenuItem(value: '35', child: Text('반려'),),
                      const DropdownMenuItem(value: '50', child: Text('취소'),),
                    ].cast<DropdownMenuItem<String>>(),
                  ),
                ),
                size: ColumnSize.S,
                numeric: true,
              ),
              DataColumn2(
                label: Center(
                  child: ISSearchDropdownV2(
                    // label: '업체타입',
                    value: selectedRequestType,
                    onChange: (value) {
                      selectedRequestType = value;

                      selectedPageNumber = 1;

                      requestAPIData();
                    },
                    //item: requireTypeList.cast<DropdownMenuItem<String>>(),
                    item: requireTypeList.map((item) {
                      return DropdownMenuItem<String>(value: item.value.toString(), child: Text(item.label.toString()));
                    }).toList(),
                    // item: [
                    //   // %: 전체,
                    //   // 100:사업자 정보변경,
                    //   // 101: 사업자번호변경,
                    //   // 102: 해지요청,
                    //   // 200:매장정보(주소)
                    //   // 201:매장정보(업종카테고리),
                    //   // 202:매장정보(POS/배달 연동),
                    //   // 203:매장정보(매장유형)
                    //   // 300:메뉴이미지변경,
                    //   // 600: 착한매장 신청,
                    //   // 601: 착한매장 해지
                    //   const DropdownMenuItem(value: '%', child: Text('요청 내용'),),
                    //   const DropdownMenuItem(value: '1', child: Text('매장정보(가맹점명)'),),
                    //   const DropdownMenuItem(value: '2', child: Text('매장정보(휴대전화번호)'),),
                    //   const DropdownMenuItem(value: '3', child: Text('매장정보(로고이미지)'),),
                    //   const DropdownMenuItem(value: '4', child: Text('메뉴 이미지 입력/수정'),),
                    //   const DropdownMenuItem(value: '5', child: Text('메뉴 이미지 삭제 요청'),),
                    //   const DropdownMenuItem(value: '6', child: Text('가맹점 해지 요청'),),
                    //   const DropdownMenuItem(value: '7', child: Text('착한매장 요청'),),
                    // ].cast<DropdownMenuItem<String>>(),
                  ),
                ),
                size: ColumnSize.S,
                numeric: true,
              ),
              DataColumn2(
                fixedWidth: 150,
                label: Container(alignment: Alignment.centerRight, child: const Text('요청 일시')),
                size: ColumnSize.S,
                numeric: true,
              ),
              const DataColumn2(
                fixedWidth: 150,
                label: Center(child: Text('')),
                size: ColumnSize.S,
                numeric: true,
              ),
            ],
            empty: Center(
                child: Container(
                    padding: const EdgeInsets.all(20),
                    child: const Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)))),
            //rows: List<DataRow>.generate(requestManagerDataSource.rowCount, (index) => requestManagerDataSource.getRow(index)),
            rows: List<DataRow>.generate(
                dataList.length,
                    (index) => DataRow2.byIndex(
                  index: index,
                  // selected: data.selected,
                  //color: MaterialStateProperty.all(color),
                  // color: color != null
                  //     ? MaterialStateProperty.all(color)
                  //     : dataList[index].isChild
                  //     ? MaterialStateProperty.all(Colors.transparent)//Colors.grey[200])
                  //     : MaterialStateProperty.all(Colors.transparent),
                  // (hasZebraStripes && index.isEven
                  //     ? MaterialStateProperty.all(Theme.of(context).highlightColor)
                  //     : null),
                  // onSelectChanged: (value) {
                  //   if (data.selected != value) {
                  //     _selectedCount += value! ? 1 : -1;
                  //     assert(_selectedCount >= 0);
                  //     data.selected = value;
                  //     notifyListeners();
                  //   }
                  // },

                  // onTap: hasRowTaps ? () => {
                  //   data.isChild
                  //       ? null : data.isOpened
                  //       ? {dataSource.removeRange(index + 1, index + 2), dataSource[index].isOpened = false}
                  //       : {
                  //         // dataSource.insert(index + 1, RequestMangerModel(requestType: data.requestType, requestContent: data.requestContent, requestImage: data.requestImage, replyContent: data.replyContent, replyDate: data.replyDate, isChild: true,),),
                  //         // dataSource[index].isOpened = true
                  //       },
                  //     notifyListeners()
                  // } : null,
                  onTap: hasRowTaps ? () async {
                    if (dataList[index].serviceGbn == '200' ||
                        dataList[index].serviceGbn == '201' ||
                        dataList[index].serviceGbn == '202' ||
                        dataList[index].serviceGbn == '300' ||
                        dataList[index].serviceGbn == '301' ||
                        dataList[index].serviceGbn == '302' ||
                        dataList[index].serviceGbn == '400' ||
                        dataList[index].serviceGbn == '500' ||
                        dataList[index].serviceGbn == '600') {
                      if (hasRowTaps) {
                        if (dataList[index].isChild) {
                          null;

                          return;
                        }
                        else {
                          if (dataList[index].isOpened) {
                            dataList.removeRange(index + 1, index + 2);
                            dataList[index].isOpened = false;
                          }
                          else {
                            dataList.insert(index + 1, RequestListModel(seq: dataList[index].seq,
                                //status: data.status,
                                statusName: dataList[index].statusName,
                                serviceGbn: dataList[index].serviceGbn,
                                serviceGbnName: dataList[index].serviceGbnName,
                                //insertDate: data.insertDate,
                                modDate: dataList[index].modDate,
                                answerText: dataList[index].answerText,
                                serviceData: dataList[index].serviceData,
                                fileName: dataList[index].fileName,
                                isChild: true),);
                            dataList[index].isOpened = true;
                          }

                          setState(() {});
                        }
                      }
                    }
                  }
                      : null,
                  specificRowHeight: hasRowHeightOverrides && (dataList[index].isChild) ? getDetailRowHeight(dataList[index].serviceGbn) : null,
                  cells: [
                    DataCell(
                      Container(
                          padding: EdgeInsets.zero,
                          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !dataList[index].isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
                          alignment: Alignment.center,
                          child: Container(
                            alignment: Alignment.center,
                            width: 60,
                            height: 26,
                            decoration: dataList[index].status == null
                                ? null
                                : BoxDecoration(
                                color: getStatusColor(dataList[index].status!),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.transparent)
                            ),
                            child: Text(dataList[index].status == null ? '' : (dataList[index].statusName ?? ''), style: const TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY_NEXON),),
                          )
                      ),
                    ),
                    DataCell(
                      dataList[index].isChild
                          ? requestDetailWidget(dataList[index])
                          : Container(
                          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !dataList[index].isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
                          alignment: Alignment.centerLeft,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  //Text('[${data.seq}] ${data.serviceGbnName} (${data.serviceData ?? ''})', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: fontSize, fontFamily: FONT_FAMILY),),
                                  Text('[${dataList[index].seq}] ${dataList[index].serviceGbnName}', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY),),
                                ],
                              ),
                              Icon(dataList[index].isOpened ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, color: Colors.black, size: 20),
                            ],
                          )
                      ),
                    ),
                    DataCell(
                      Container(
                          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !dataList[index].isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
                          alignment: Alignment.centerRight,
                          child: Text(dataList[index].insertDate ?? '', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY),)
                      ),
                    ),
                    DataCell(
                      Container(
                        decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !dataList[index].isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
                        alignment: Alignment.center,
                        child: (dataList[index].isChild == true)
                            ? const SizedBox.shrink()
                            : (dataList[index].statusName == '요청' ? ISButton(//
                          isReverseColor: true,
                          child: const Text('취소하기'),
                          onPressed: () {
                            ISConfirm(context, '변경 요청 취소', '[${dataList[index].seq}] ${dataList[index].serviceGbnName} 을(를)\n 취소 처리하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                              Navigator.of(context).pop();

                              if (isOK){
                                List<dynamic> conData = jsonDecode(dataList[index].serviceData!.toString());
                                RequestShopInfoEditModel sendData = RequestShopInfoEditModel();
                                sendData.seq = dataList[index].seq;
                                sendData.shopCd = AuthService.SHOPCD;
                                sendData.status = '20';
                                sendData.serviceGbn = dataList[index].serviceGbn;
                                sendData.uCode = AuthService.uCode;
                                sendData.uName = AuthService.uName;
                                sendData.filter = conData[0]['menuCd'] ?? '';

                                var value = await showDialog(
                                    context: context,
                                    builder: (context) => FutureProgressDialog(dataList[index].serviceGbn == '300' || dataList[index].serviceGbn == '301' || dataList[index].serviceGbn == '302' ? RequestController.to.setRequireSingleImageService(sendData, []) : RequestController.to.setRequireMultiImageService(sendData, [])));

                                if (value == null) {
                                  ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                }
                                else {
                                  await Future.delayed(const Duration(milliseconds: 500), () {
                                    requestAPIData();
                                  });
                                }
                              }
                            });
                          },
                        ) : const SizedBox.shrink()),
                      ),
                      // onTap: () {
                      //   if (data.isOpened == true) {
                      //     data.isOpened = false;
                      //   } else {
                      //     data.isOpened = true;
                      //   }
                      // },
                    ),
                  ],
                ))),
      ),
    );
  }

  Material mobileRequestListView(fluentUI.BuildContext context) {
    return Material(
      child: Column(
        children: [
          ListView(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: List.generate(dataList.length, (index) {
              return fluentUI.Expander(
                contentBackgroundColor: Colors.grey[200],
                onStateChanged: (val) async {
                  Widget? tempWidget;
                  if (val == true) {
                    List<dynamic> conData = jsonDecode(dataList[index].serviceData!.toString());
                    List<RequestServiceDataModel> tempList = conData.map<RequestServiceDataModel>((element) {
                      RequestServiceDataModel detailData = RequestServiceDataModel();
                      if (dataList[index].serviceGbn == '200') {
                        detailData.afterShopName = element['afterShopName'] == null ? element['AfterShopName'] == null ? '' : element['AfterShopName'] as String : element['afterShopName'] as String;
                        detailData.beforeShopName = element['beforeShopName'] == null ? element['BeforeShopName'] == null ? '' : element['BeforeShopName'] as String  : element['beforeShopName'] as String;
                        detailData.afterMobile = element['afterMobile'] == null ? element['AfterMobile'] == null ? '' : element['AfterMobile'] as String : element['afterMobile'] as String;
                        detailData.beforeMobile = element['beforeMobile'] == null ? element['BeforeMobile'] == null ? '' : element['BeforeMobile'] as String : element['beforeMobile'] as String;
                        detailData.fileNames = element['fileNames'].cast<String>();
                      }
                      else if (dataList[index].serviceGbn == '201') {
                        detailData.afterShopName = element['afterShopName'] == null ? element['AfterShopName'] == null ? '' : element['AfterShopName'] as String : element['afterShopName'] as String;
                        detailData.beforeShopName = element['beforeShopName'] == null ? element['BeforeShopName'] == null ? '' : element['BeforeShopName'] as String  : element['beforeShopName'] as String;
                        detailData.afterMobile = element['afterMobile'] == null ? element['AfterMobile'] == null ? '' : element['AfterMobile'] as String : element['afterMobile'] as String;
                        detailData.beforeMobile = element['beforeMobile'] == null ? element['BeforeMobile'] == null ? '' : element['BeforeMobile'] as String : element['beforeMobile'] as String;
                        detailData.fileNames = (element['fileNames'] ?? []).cast<String>();
                      }
                      else if (dataList[index].serviceGbn == '202') {
                        detailData.beforeImageURL = element['beforeImageURL'] == null ? '' : element['beforeImageURL'] as String;
                        detailData.afterImageURL = element['afterImageURL'] is List<dynamic> && element['afterImageURL'].isNotEmpty ? element['afterImageURL'][0] : element['afterImageURL'] is String ? element['afterImageURL'] : '';

                        if(ServerInfo.jobMode == 'real') {
                          detailData.beforeImageURL = detailData.beforeImageURL.toString().replaceAll('https://image.daeguro.co.kr:40443/', '/');
                          detailData.afterImageURL = detailData.afterImageURL.toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/').replaceAll('https://owner.daeguro.co.kr/', '/');
                        }
                      }
                      else if (dataList[index].serviceGbn == '300' || dataList[index].serviceGbn == '302') {
                        detailData.menuName = element['menuName'] == null ? '' : element['menuName'] as String;
                        detailData.imageName = element['imageName'] == null ? '' : element['imageName'] as String;
                        detailData.image_url = element['image_url'] == null ? '' : element['image_url'] as String;
                        detailData.afterImageURL = element['afterImageURL'] is List<dynamic> && element['afterImageURL'].isNotEmpty ? element['afterImageURL'][0] : element['afterImageURL'] is String ? element['afterImageURL'] : '';

                        if(ServerInfo.jobMode == 'real') {
                          detailData.image_url = detailData.image_url.toString().replaceAll('https://image.daeguro.co.kr:40443/', '/');
                          detailData.afterImageURL = detailData.afterImageURL.toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/');
                          detailData.afterImageURL = detailData.afterImageURL.toString().replaceAll('https://owner.daeguro.co.kr/', '/');
                        }
                      }
                      else if (dataList[index].serviceGbn == '301') {
                        detailData.imageName = element['imageName'] == null ? '' : element['imageName'] as String;

                        if(ServerInfo.jobMode == 'real')
                          detailData.imageName = detailData.imageName.toString().replaceAll('https://image.daeguro.co.kr:40443/', '/');
                      }
                      else if (dataList[index].serviceGbn == '400') {
                        detailData.reason = element['reason'] == null ? '' : element['reason'] as String;
                        detailData.fileNames = element['fileNames'].cast<String>();
                      }
                      else if (dataList[index].serviceGbn == '500'){
                        detailData.fileNames = element['fileNames'].cast<String>();
                      }
                      else if (dataList[index].serviceGbn == '600') {
                        detailData.first = element['first'] == null ? '' : element['first'] as String;
                        detailData.second = element['second'] == null ? '' : element['second'] as String;
                        detailData.third = element['third'] == null ? '' : element['third'] as String;
                      }

                      if (dataList[index].serviceGbn == '200') {
                        // 매장정보(가맹점명)
                        tempWidget = Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(
                                    width: 60,
                                    child: Text('변경 전: ', style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)),
                                Text(' ${detailData.beforeShopName}', style: const TextStyle(color: Colors.black54, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(
                                    width: 60,
                                    child: Text('변경 후: ', style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)),
                                Text(' ${detailData.afterShopName}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                              ],
                            ),
                            const Divider(height: 20),
                            SizedBox(
                              height: 100,
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                children: List.generate(detailData.fileNames!.length, (index) {
                                  return (detailData.fileNames![index] == null)
                                      ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                      : Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 6),
                                    child: Image.network('${detailData.fileNames![index].toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/').replaceAll('https://owner.daeguro.co.kr/', '/')}?tm=${Utils.getTimeStamp()}',
                                      fit: BoxFit.cover, gaplessPlayback: true, width: 100, height: 100,
                                      errorBuilder: (context, error, stackTrace) {
                                        return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                                      },
                                    ),
                                  );
                                }),
                              ),
                            ),
                          ],
                        );
                      } else if (dataList[index].serviceGbn == '201') {
                        // 매장정보(휴대전화번호)
                        tempWidget = Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(
                                    width: 60,
                                    child: Text('변경 전: ', style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)),
                                Text(' ${detailData.beforeMobile}', style: const TextStyle(color: Colors.black54, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(
                                    width: 60,
                                    child: Text('변경 후: ', style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)
                                ),
                                Text(' ${Utils.getPhoneNumFormat(detailData.afterMobile!, false)}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                              ],
                            ),
                            const Divider(height: 20),
                            SizedBox(
                              height: 100,
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                children: List.generate(detailData.fileNames!.length, (index) {
                                  return (detailData.fileNames![index] == null)
                                      ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                      : Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 6),
                                    child: Image.network('${detailData.fileNames![index].toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/').replaceAll('https://owner.daeguro.co.kr/', '/')}?tm=${Utils.getTimeStamp()}',
                                      fit: BoxFit.cover, gaplessPlayback: true, width: 100, height: 100,
                                      errorBuilder: (context, error, stackTrace) {
                                        return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                                      },
                                    ),
                                  );
                                }),
                              ),
                            ),
                          ],
                        );
                      } else if (dataList[index].serviceGbn == '202') {
                        // 매장정보(로고이미지)
                        tempWidget = Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Column(
                                  children: [
                                    const SizedBox(width: 50, child: Text('변경 전')),
                                    (detailData.beforeImageURL == null)
                                        ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                        : Image.network('${detailData.beforeImageURL!}?tm=${Utils.getTimeStamp()}',
                                      fit: BoxFit.fill, gaplessPlayback: true, width: 100, height: 100,
                                      errorBuilder: (context, error, stackTrace) {
                                        return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                                      },
                                    )
                                  ],
                                ),
                                const Icon(Icons.arrow_right, size: 70,),
                                Column(
                                  children: [
                                    const SizedBox(width: 50, child: Text('변경 후')),
                                    (detailData.afterImageURL == null)
                                        ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                        : Image.network('${detailData.afterImageURL!}?tm=${Utils.getTimeStamp()}',
                                      fit: BoxFit.fill, gaplessPlayback: true, width: 100, height: 100,
                                      errorBuilder: (context, error, stackTrace) {
                                        return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                                      },
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ],
                        );
                      } else if (dataList[index].serviceGbn == '302' || dataList[index].serviceGbn == '300') {
                        tempWidget = Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Column(
                                  children: [
                                    const SizedBox(width: 50, child: Text('변경 전')),
                                    (detailData.image_url == null || detailData.imageName == null)
                                        ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                        : Image.network('${detailData.image_url!}${detailData.imageName!}?tm=${Utils.getTimeStamp()}',
                                      fit: BoxFit.fill, gaplessPlayback: true, width: 100, height: 100,
                                      errorBuilder: (context, error, stackTrace) {
                                        return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                                      },
                                    )
                                  ],
                                ),
                                const Icon(Icons.arrow_right, size: 70,),
                                Column(
                                  children: [
                                    const SizedBox(width: 50, child: Text('변경 후')),
                                    (detailData.afterImageURL == null)
                                        ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                        : Image.network('${detailData.afterImageURL!}?tm=${Utils.getTimeStamp()}',
                                      fit: BoxFit.fill, gaplessPlayback: true, width: 100, height: 100,
                                      errorBuilder: (context, error, stackTrace) {
                                        return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                                      },
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ],
                        );
                      } else if (dataList[index].serviceGbn == '301') {
                        //메뉴 이미지 삭제 요청
                        tempWidget = Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 10,),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                const SizedBox(width: 80, child: Text('삭제 이미지', style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
                                (detailData.imageName == null)
                                    ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                    : Image.network('${detailData.imageName!}?tm=${Utils.getTimeStamp()}',
                                  fit: BoxFit.fill, gaplessPlayback: true, width: 100, height: 100,
                                  errorBuilder: (context, error, stackTrace) {
                                    return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                                  },
                                )
                              ],
                            ),
                          ],
                        );
                      } else if (dataList[index].serviceGbn == '400') {
                        //가맹점 해지 요청
                        tempWidget = Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(
                                    width: 60,
                                    child: Text('해지 사유: ', style: TextStyle(color: Colors.red, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)
                                ),
                                Text(' ${detailData.reason}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                              ],
                            ),
                            const Divider(height: 20),
                            SizedBox(
                              height: 100,
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                children: List.generate(detailData.fileNames!.length, (index) {
                                  return (detailData.fileNames![index] == null)
                                      ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                      : Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 6),
                                    child: Image.network('${detailData.fileNames![index].toString().replaceAll('https://ceo.daeguro.co.kr/RequestServiceImage/', '/request-images/')
                                        .toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/')
                                        .toString().replaceAll('https://owner.daeguro.co.kr/', '/')}?tm=${Utils.getTimeStamp()}',
                                      fit: BoxFit.cover, gaplessPlayback: true, width: 100, height: 100,
                                      errorBuilder: (context, error, stackTrace) {
                                        return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                                      },
                                    ),
                                  );
                                }),
                              ),
                            ),
                          ],
                        );
                      } else if(dataList[index].serviceGbn == '500'){
                        // 출금 계좌 변경
                        tempWidget = Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 100,
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                children: List.generate(detailData.fileNames!.length, (index) {
                                  return (detailData.fileNames![index] == null)
                                      ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                      : Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 6),
                                    child: Image.network('${detailData.fileNames![index].toString().replaceAll('https://ceo.daeguro.co.kr/RequestServiceImage/', '/request-images/')
                                        .toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/')
                                        .toString().replaceAll('https://owner.daeguro.co.kr/', '/')}?tm=${Utils.getTimeStamp()}',
                                      fit: BoxFit.cover, gaplessPlayback: true, width: 100, height: 100,
                                      errorBuilder: (context, error, stackTrace) {
                                        return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                                      },
                                    ),
                                  );
                                }),
                              ),
                            ),
                          ],
                        );
                      } else if (dataList[index].serviceGbn == '600') {
                        //착한매장 요청
                        tempWidget = Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 10,),
                            const SizedBox(width: 160, child: Text('착한 매장 신청내역')),
                            const SizedBox(height: 10,),
                            Text.rich(
                                style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                textAlign: TextAlign.start,
                                TextSpan(children: [
                                  const TextSpan(text: '우리 가게는 다른 배달앱과 \'대구로\'의 메뉴 목록이 동일한가요?\n'),
                                  const TextSpan(text: '→  '),
                                  TextSpan(text: '${(detailData.first == 'Y') ? 'O' : 'X'}', style: const TextStyle(color: Colors.lightBlue)),
                                  const TextSpan(text: '\n\n'),
                                  const TextSpan(text: '우리 가게가 \'대구로\'에서 다른 배달앱보다 저렴한 항목은 무엇인가요?\n'),
                                  const TextSpan(text: '→  '),
                                  TextSpan(text: '${getKindShopResearchStr(detailData.second!)}', style: const TextStyle(color: Colors.lightBlue)),
                                  const TextSpan(text: '\n\n'),
                                  const TextSpan(text: '착한 매장 입점 후 최종 결제 금액에서 고객에게 1,000원 할인해주는 것에 동의하시나요?\n'),
                                  const TextSpan(text: '→  '),
                                  TextSpan(text: '${(detailData.third == 'Y') ? 'O' : 'X'}', style: const TextStyle(color: Colors.lightBlue)),
                                ]))
                          ],
                        );
                      } else {
                        tempWidget = const SizedBox.shrink();
                      }
                      return detailData;
                    }).toList();
                    setState(() {
                      mobileDataDetailSourceMap[index] = tempList;
                    });
                  } else {
                    mobileDataDetailSourceMap.remove(index);
                  }
                },
                headerHeight: 80,
                header: Padding(
                  padding: const EdgeInsets.only(top: 10, bottom: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                              padding: EdgeInsets.zero,
                              alignment: Alignment.center,
                              child: Container(
                                alignment: Alignment.center,
                                width: 53,
                                height: 26,
                                decoration: dataList[index].status == null ? null : BoxDecoration(color: getStatusColor(dataList[index].status!), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.transparent)),
                                child: Text(dataList[index].status == null ? '' : (dataList[index].statusName ?? ''), style: const TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY_NEXON),),
                              )),
                          const SizedBox(width: 8,),
                          Text('[${dataList[index].seq}] ${dataList[index].serviceGbnName}', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY),),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const SizedBox(width: 62,),
                          Text(
                            dataList[index].insertDate ?? '',
                            style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                content: mobileDataDetailSourceMap.containsKey(index)
                    ? ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: mobileDataDetailSourceMap[index]?.length ?? 0,
                  itemBuilder: (ctx, idx) {
                    RequestServiceDataModel detail = mobileDataDetailSourceMap[index]![idx];
                    return requestDetailWidget(dataList[index]);
                  },
                )
                    : Container(),
              );
            }),
          )
        ],
      ),
    );
  }

  List<Widget> searchBarView() {
    return [
      Material(
        child: Column(
          children: [
            ISSearchSelectDate(
              label: '기간 선택',
              width: Responsive.isMobile(context) == true ? double.infinity : 230,
              value: '${startdate.toString()} ~ ${enddate.toString()}',
              onTap: () async {
                showGeneralDialog(
                    context: context,
                    barrierDismissible: true,
                    barrierLabel: '',
                    barrierColor: Colors.black54,
                    pageBuilder: (context, animation, secondaryAnimation) {
                      return Dialog(
                          insetPadding: EdgeInsets.zero,
                          elevation: 0,
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                          child: MultipleViewDateRangePicker(
                            startDate: DateTime.parse(startdate!),
                            endDate: DateTime.parse(enddate!),
                            setDateActionCallback: ({startDate, endDate}) {
                              Navigator.of(context).pop();

                              startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                              enddate = DateFormat('yyyy-MM-dd').format(endDate!);

                              selectedPageNumber = 1;
                              pickDate = true;

                              requestAPIData();
                            },
                          ));
                    });
              },
            ),
            Responsive.isMobile(context)
                ? Column(
              children: [
                const SizedBox(height: 8,),
                ISSearchDropdown(
                  label: '주문 유형',
                  width: double.infinity,
                  height: 50,
                  value: selectedStatus,
                  onChange: (value) {
                    selectedStatus = value;

                    selectedPageNumber = 1;

                    requestAPIData();
                  },
                  item: [
                    ISOptionModel(value: '%', label: '상태 전체'),
                    ISOptionModel(value: '10', label: '요청'),
                    ISOptionModel(value: '30', label: '심사 중'),
                    ISOptionModel(value: '40', label: '완료'),
                    ISOptionModel(value: '35', label: '반려'),
                    ISOptionModel(value: '50', label: '취소'),
                  ].cast<ISOptionModel>(),
                ),
                const SizedBox(height: 8,),
                ISSearchDropdown(
                  label: '주문 유형',
                  width: double.infinity,
                  height: 50,
                  value: selectedRequestType,
                  onChange: (value) {
                    selectedRequestType = value;

                    selectedPageNumber = 1;

                    requestAPIData();
                  },
                  item: [
                    ...requireTypeList.map((e) {
                      return ISOptionModel(value: e.value.toString(), label: e.label.toString());
                    })
                  ].toList().cast<ISOptionModel>(),
                ),
              ],
            ) : Container(),
          ],
        ),
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8,) : const SizedBox(width: 8,),
      ISToggleButtons(
        [
          ISOptionModel(value: '1000', label: '오늘'),
          ISOptionModel(value: '1001', label: '5일'),
          ISOptionModel(value: '1002', label: '7일'),
          ISOptionModel(value: '1003', label: '1개월'),
          ISOptionModel(value: '1004', label: '3개월'),
        ],
        buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 5) - 6) : 60,
        defaultValue: selectedType,
        pickDate: pickDate,
        afterOnPress: (v) {
          if (v == '1000'){
            startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1001'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 5)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1002'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 7)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1003'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 30)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1004'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 90)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }

          setState(() {
            selectedType = v.toString();
            pickDate = false;
          });

          selectedPageNumber = 1;

          requestAPIData();
        },
      ),
    ];
  }

  Widget requestDetailWidget(RequestListModel data) {
    Widget? tempWidget;

    //String editStr = data.serviceData!.toString().replaceAll(RegExp('\\.'), '');

    //print('editStr:${editStr}');

    List<dynamic> conData = jsonDecode(data.serviceData!.toString());

    //print('conData:${conData.toString()}');

    RequestServiceDataModel detailData = RequestServiceDataModel();

    try{
      conData.forEach((element) {
        if (data.serviceGbn == '200') {
          detailData.afterShopName = element['afterShopName'] == null ? element['AfterShopName'] == null ? '' : element['AfterShopName'] as String : element['afterShopName'] as String;
          detailData.beforeShopName = element['beforeShopName'] == null ? element['BeforeShopName'] == null ? '' : element['BeforeShopName'] as String  : element['beforeShopName'] as String;
          detailData.afterMobile = element['afterMobile'] == null ? element['AfterMobile'] == null ? '' : element['AfterMobile'] as String : element['afterMobile'] as String;
          detailData.beforeMobile = element['beforeMobile'] == null ? element['BeforeMobile'] == null ? '' : element['BeforeMobile'] as String : element['beforeMobile'] as String;
          detailData.fileNames = element['fileNames'].cast<String>();
        }
        else if (data.serviceGbn == '201') {
          detailData.afterShopName = element['afterShopName'] == null ? element['AfterShopName'] == null ? '' : element['AfterShopName'] as String : element['afterShopName'] as String;
          detailData.beforeShopName = element['beforeShopName'] == null ? element['BeforeShopName'] == null ? '' : element['BeforeShopName'] as String  : element['beforeShopName'] as String;
          detailData.afterMobile = element['afterMobile'] == null ? element['AfterMobile'] == null ? '' : element['AfterMobile'] as String : element['afterMobile'] as String;
          detailData.beforeMobile = element['beforeMobile'] == null ? element['BeforeMobile'] == null ? '' : element['BeforeMobile'] as String : element['beforeMobile'] as String;
          detailData.fileNames = element['fileNames'].cast<String>();
        }
        else if (data.serviceGbn == '202') {
          detailData.beforeImageURL = element['beforeImageURL'] == null ? '' : element['beforeImageURL'] as String;
          detailData.afterImageURL = element['afterImageURL'] == null ? '' : element['afterImageURL'] as String;

          if(ServerInfo.jobMode == 'real') {
            detailData.beforeImageURL = detailData.beforeImageURL.toString().replaceAll('https://image.daeguro.co.kr:40443/', '/');
            detailData.afterImageURL = detailData.afterImageURL.toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/').replaceAll('https://owner.daeguro.co.kr/', '/');
          }

          // 예전 요청관리 데이터
          List<String>? fileNames = element['afterImageUrl'] == null ? '' : element['afterImageUrl'].cast<String>();
          if (fileNames != null && fileNames.isNotEmpty) {
            // fileNames!.forEach((element) {
            // });
            detailData.afterImageURL = fileNames[0];
          }
        }
        else if (data.serviceGbn == '300' || data.serviceGbn == '302') {
          detailData.menuName = element['menuName'] == null ? '' : element['menuName'] as String;
          detailData.imageName = element['imageName'] == null ? '' : element['imageName'] as String;
          detailData.image_url = element['image_url'] == null ? '' : element['image_url'] as String;
          detailData.afterImageURL = element['afterImageURL'] == null ? '' : element['afterImageURL'] as String;

          if(ServerInfo.jobMode == 'real') {
            detailData.image_url = detailData.image_url.toString().replaceAll('https://image.daeguro.co.kr:40443/', '/');
            detailData.afterImageURL = detailData.afterImageURL.toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/');
            detailData.afterImageURL = detailData.afterImageURL.toString().replaceAll('https://owner.daeguro.co.kr/', '/');
          }

          // 예전 요청관리 데이터
          List<String>? fileNames = element['afterImageUrl'] == null ? '' : element['afterImageUrl'].cast<String>();
          if (fileNames != null && fileNames.isNotEmpty) {
            // fileNames!.forEach((element) {
            // });
            detailData.afterImageURL = fileNames[0];
          }
        }
        else if (data.serviceGbn == '301') {
          detailData.imageName = element['imageName'] == null ? '' : element['imageName'] as String;

          if(ServerInfo.jobMode == 'real')
            detailData.imageName = detailData.imageName.toString().replaceAll('https://image.daeguro.co.kr:40443/', '/');
        }
        else if (data.serviceGbn == '400') {
          detailData.reason = element['reason'] == null ? '' : element['reason'] as String;
          detailData.fileNames = element['fileNames'].cast<String>();
        }
        else if (data.serviceGbn == '500'){
          detailData.fileNames = element['fileNames'].cast<String>();
        }
        else if (data.serviceGbn == '600') {
          detailData.first = element['first'] == null ? '' : element['first'] as String;
          detailData.second = element['second'] == null ? '' : element['second'] as String;
          detailData.third = element['third'] == null ? '' : element['third'] as String;
        }
      });
    }
    catch (ex){
    }

    if (data.serviceGbn == '200') {// 매장정보(가맹점명)
      tempWidget = Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 60, child: Text('변경 전: ', style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)),
              Text(' ${detailData.beforeShopName}', style: const TextStyle(color: Colors.black54, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 60, child: Text('변경 후: ', style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)),
              Text(' ${detailData.afterShopName}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
            ],
          ),
          const Divider(height: 20),
          SizedBox(
            height: 100,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: List.generate(detailData.fileNames!.length, (index) {
                return (detailData.fileNames![index] == null)
                    ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                    : Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Image.network('${detailData.fileNames![index].toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/').replaceAll('https://owner.daeguro.co.kr/', '/')}?tm=${Utils.getTimeStamp()}', fit: BoxFit.cover, gaplessPlayback: true, width: 100, height: 100,
                    errorBuilder: (context, error, stackTrace) {
                      return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                    },
                  ),
                );
              }),
            ),
          ),
        ],
      );
    }
    else if (data.serviceGbn == '201') {// 매장정보(휴대전화번호)
      tempWidget = Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 60, child: Text('변경 전: ', style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)),
              Text(' ${detailData.beforeMobile}', style: const TextStyle(color: Colors.black54, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 60, child: Text('변경 후: ', style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)),
              Text(' ${Utils.getPhoneNumFormat(detailData.afterMobile!, false)}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
            ],
          ),
          const Divider(height: 20),
          SizedBox(
            height: 100,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: List.generate(detailData.fileNames!.length, (index) {
                return (detailData.fileNames![index] == null)
                    ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                    : Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Image.network('${detailData.fileNames![index].toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/').replaceAll('https://owner.daeguro.co.kr/', '/')}?tm=${Utils.getTimeStamp()}', fit: BoxFit.cover, gaplessPlayback: true, width: 100, height: 100,
                    errorBuilder: (context, error, stackTrace) {
                      return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                    },
                  ),
                );
              }),
            ),
          ),
        ],
      );
    }
    else if (data.serviceGbn == '202') {// 매장정보(로고이미지)
      tempWidget = Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                children: [
                  const SizedBox(width: 50, child: Text('변경 전')),
                  (detailData.beforeImageURL == null)
                      ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                      : Image.network('${detailData.beforeImageURL!}?tm=${Utils.getTimeStamp()}',
                    fit: BoxFit.fill, gaplessPlayback: true, width: 100, height: 100,
                    errorBuilder: (context, error, stackTrace) {
                      return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                    },
                  )
                ],
              ),
              const Icon(Icons.arrow_right, size: 70,),
              Column(
                children: [
                  const SizedBox(width: 50, child: Text('변경 후')),
                  (detailData.afterImageURL == null)
                      ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                      : Image.network(
                    '${detailData.afterImageURL!}?tm=${Utils.getTimeStamp()}',
                    fit: BoxFit.fill, gaplessPlayback: true, width: 100, height: 100,
                    errorBuilder: (context, error, stackTrace) {
                      return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,
                      );
                    },
                  )
                ],
              ),
            ],
          ),
        ],
      );
    } else if (data.serviceGbn == '302' || data.serviceGbn == '300') {
      tempWidget = Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                children: [
                  const SizedBox(width: 50, child: Text('변경 전')),
                  (detailData.image_url == null || detailData.imageName == null)
                      ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                      : Image.network('${detailData.image_url!}?tm=${Utils.getTimeStamp()}',
                    fit: BoxFit.fill, gaplessPlayback: true, width: 100, height: 100,
                    errorBuilder: (context, error, stackTrace) {
                      return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                    },
                  )
                ],
              ),
              const Icon(Icons.arrow_right, size: 70,),
              Column(
                children: [
                  const SizedBox(width: 50, child: Text('변경 후')),
                  (detailData.afterImageURL == null)
                      ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                      : Image.network('${detailData.afterImageURL!}?tm=${Utils.getTimeStamp()}',
                    fit: BoxFit.fill, gaplessPlayback: true, width: 100, height: 100,
                    errorBuilder: (context, error, stackTrace) {
                      return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                    },
                  )
                ],
              ),
            ],
          ),
        ],
      );
    } else if (data.serviceGbn == '301') {
      //메뉴 이미지 삭제 요청
      tempWidget = Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 10,),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(width: 80, child: Text('삭제 이미지', style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
              (detailData.imageName == null)
                  ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                  : Image.network('${detailData.imageName!}?tm=${Utils.getTimeStamp()}',
                fit: BoxFit.fill, gaplessPlayback: true, width: 100, height: 100,
                errorBuilder: (context, error, stackTrace) {
                  return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                },
              )
            ],
          ),
        ],
      );
    } else if (data.serviceGbn == '400') {
      //가맹점 해지 요청
      tempWidget = Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 60, child: Text('해지 사유: ', style: TextStyle(color: Colors.red, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)),
              Flexible(
                  child: RichText(
                    overflow:  TextOverflow.ellipsis,
                    maxLines: 1,
                    text: TextSpan(text: '${detailData.reason}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))
                  ),
              )
            ],
          ),
          const Divider(height: 20),
          SizedBox(
            height: 100,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: List.generate(detailData.fileNames!.length, (index) {
                return (detailData.fileNames![index] == null)
                    ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                    : Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Image.network('${detailData.fileNames![index].toString().replaceAll('https://ceo.daeguro.co.kr/RequestServiceImage/', '/request-images/')
                      .toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/')
                      .toString().replaceAll('https://owner.daeguro.co.kr/', '/')}?tm=${Utils.getTimeStamp()}',
                    fit: BoxFit.cover, gaplessPlayback: true, width: 100, height: 100,
                    errorBuilder: (context, error, stackTrace) {
                      return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                    },
                  ),
                );
              }),
            ),
          ),
        ],
      );
    } else if(data.serviceGbn == '500'){
      // 출금 계좌 변경
      tempWidget = Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 100,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: List.generate(detailData.fileNames!.length, (index) {
                return (detailData.fileNames![index] == null)
                    ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                    : Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Image.network('${detailData.fileNames![index].toString().replaceAll('https://ceo.daeguro.co.kr/RequestServiceImage/', '/request-images/')
                      .toString().replaceAll('https://ceoflower.daeguro.co.kr/', '/')
                      .toString().replaceAll('https://owner.daeguro.co.kr/', '/')}?tm=${Utils.getTimeStamp()}',
                    fit: BoxFit.cover, gaplessPlayback: true, width: 100, height: 100,
                    errorBuilder: (context, error, stackTrace) {
                      return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                    },
                  ),
                );
              }),
            ),
          ),
        ],
      );
    }
    else if (data.serviceGbn == '600') {
      //착한매장 요청
      tempWidget = Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 10,),
          const SizedBox(width: 160, child: Text('착한 매장 신청내역')),
          const SizedBox(height: 10,),
          Text.rich(
              style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
              textAlign: TextAlign.start,
              TextSpan(children: [
                const TextSpan(text: '우리 가게는 다른 배달앱과 \'대구로\'의 메뉴 목록이 동일한가요?\n'),
                const TextSpan(text: '→  '),
                TextSpan(text: '${(detailData.first == 'Y') ? 'O' : 'X'}', style: const TextStyle(color: Colors.lightBlue)),
                const TextSpan(text: '\n\n'),
                const TextSpan(text: '우리 가게가 \'대구로\'에서 다른 배달앱보다 저렴한 항목은 무엇인가요?\n'),
                const TextSpan(text: '→  '),
                TextSpan(text: '${getKindShopResearchStr(detailData.second!)}', style: const TextStyle(color: Colors.lightBlue)),
                const TextSpan(text: '\n\n'),
                const TextSpan(text: '착한 매장 입점 후 최종 결제 금액에서 고객에게 1,000원 할인해주는 것에 동의하시나요?\n'),
                const TextSpan(text: '→  '),
                TextSpan(text: '${(detailData.third == 'Y') ? 'O' : 'X'}', style: const TextStyle(color: Colors.lightBlue)),
              ]))
          // Column(
          //   mainAxisAlignment: MainAxisAlignment.start,
          //   crossAxisAlignment: CrossAxisAlignment.start,
          //   children: [
          //     Text(),
          //     const SizedBox(height: 10,),
          //     const Text('우리가게가 \'대구로\'에서 다른 배달앱보다 저렴한 항목은 무엇인가요?'),
          //     Text('${getKindShopResearchStr(detailData.second!)}'),
          //     const SizedBox(height: 10,),
          //     Text('착한매장 입점 후 최종 결제금액에서 고객에게 1,000원 할인해주는 것에 동의하시나요? : ${detailData.third == 'Y' ? 'O' : 'X'}'),
          //   ],
          // ),
        ],
      );
    } else {
      tempWidget = const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Column(
        children: [
          tempWidget!,
          //const Divider(height: 20,),
          data.answerText == null
              ? const SizedBox.shrink()
              : Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Divider(height: 15,),
              Row(
                children: [
                  const SizedBox(width: 60, child: Text('답변 내용: ', style: TextStyle(color: Colors.red, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)),
                  Expanded(
                      child: Text(data.answerText!, style: const TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, overflow: TextOverflow.ellipsis))),
                ],
              ),
              Row(
                children: [
                  const SizedBox(width: 60, child: Text('답변 일시: ', style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
                  Expanded(
                      child: Text(data.modDate!, style: const TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
                ],
              ),
              Responsive.isMobile(context) ? Container(
                decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Colors.transparent, width: 1))),
                alignment: Alignment.centerRight,
                child: (data.statusName == '요청' ? ISButton(
                  isReverseColor: true,
                  child: const Text('취소하기'),
                  onPressed: () {
                    ISConfirm(context, '변경 요청 취소', '[${data.seq}] ${data.serviceGbnName} 을(를)\n 취소 처리하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                      Navigator.of(context).pop();

                      if (isOK){
                        RequestShopInfoEditModel sendData = RequestShopInfoEditModel();
                        sendData.seq = data.seq;
                        sendData.shopCd = AuthService.SHOPCD;
                        sendData.status = '20';
                        sendData.serviceGbn = data.serviceGbn;
                        sendData.serviceGbn = data.serviceGbn;
                        sendData.uCode = AuthService.uCode;
                        sendData.uName = AuthService.uName;
                        sendData.filter = conData[0]['menuCd'] ?? '';


                        var value = await showDialog(
                            context: context,
                            builder: (context) => FutureProgressDialog(sendData.serviceGbn == '300' || sendData.serviceGbn == '301' || sendData.serviceGbn == '302' ? RequestController.to.setRequireSingleImageService(sendData, []) : RequestController.to.setRequireMultiImageService(sendData, []))
                        );

                        if (value == null) {
                          ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                        }
                        else {
                          await Future.delayed(const Duration(milliseconds: 500), () {
                            requestAPIData();
                          });
                        }
                      }
                    });
                  },
                ) : const SizedBox.shrink()),
              ) : Container()
            ],
          ),
        ],
      ),
    );
  }

  String getKindShopResearchStr(String value) {
    String? tempStr;

    if (value == '1')           tempStr = '메뉴 금액';
    else if (value == '2')      tempStr = '배달팁';
    else if (value == '3')      tempStr = '가맹점 쿠폰';
    else if (value == '4')      tempStr = '포장 할인';
    else                        tempStr = '없음';

    return tempStr;
  }

  Color getStatusColor(String status) {
    Color tempColor;

    if (status == '10')      {      tempColor = Colors.yellow;              } // 요청
    else if (status == '30') {      tempColor = Colors.green;               } // 심사중
    else if (status == '40') {      tempColor = const Color(0xff01CAFF);    } // 완료
    else if (status == '35') {      tempColor = Colors.red;                 } // 반려
    else if (status == '50') {      tempColor = Colors.grey;                } // 취소
    else                     {      tempColor = Colors.grey;                }

    return tempColor;
  }

  double getDetailRowHeight(String? serviceGbn) {
    double rowHeight = 0.0;

    if (serviceGbn == '200')      {     rowHeight = 240.0;    }
    else if (serviceGbn == '201') {     rowHeight = 250.0;    }
    else if (serviceGbn == '202') {     rowHeight = 210.0;    }
    else if (serviceGbn == '300') {     rowHeight = 210.0;    }
    else if (serviceGbn == '301') {     rowHeight = 200.0;    }
    else if (serviceGbn == '302') {     rowHeight = 210.0;    }
    else if (serviceGbn == '400') {     rowHeight = 230.0;    }
    else if (serviceGbn == '500') {     rowHeight = 200.0;    }
    else if (serviceGbn == '600') {     rowHeight = 320.0;    }
    else                          {     rowHeight = 40.0;     }

    return rowHeight;
  }
}