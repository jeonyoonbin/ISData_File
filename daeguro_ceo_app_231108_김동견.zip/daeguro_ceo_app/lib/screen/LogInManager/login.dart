
import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/screen/LogInManager/loginController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';

import 'package:provider/provider.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    FocusNode focusID = FocusNode();
    FocusNode focusPW = FocusNode();
    // FocusNode focusOTP = FocusNode();

    final appTheme = context.watch<AppTheme>();

    Get.put(LoginController());
    
    //https://jh-industry.tistory.com/123  로그인 처리작업 필요

    return Scaffold(
      // resizeToAvoidBottomInset: false,
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          controller: LoginController.to.scrollController,
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            constraints: const BoxConstraints(minHeight: 650),
            child: SafeArea(
              child: GetBuilder<LoginController>(
                builder: (controller) {
                  return Column(
                    //crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Container(
                        color: Colors.white,
                        height: 70,
                        child: Column(
                          // crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 23, right: 20),
                                  child: SizedBox(
                                    width: double.infinity,
                                    //child: Text('version ${ServerInfo.APP_VERSION}', textAlign: TextAlign.right, style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 12, color: const Color(0xffFFFFFF).withOpacity(0.5),),),
                                    child: Text('version ${ServerInfo.APP_VERSION}', textAlign: TextAlign.right, style: TextStyle(fontFamily: FONT_FAMILY, fontSize: 12, color: const Color(0xff000000).withOpacity(0.5),),),
                                  ),
                                ),
                                Container(
                                  alignment: Alignment.topRight,
                                  margin: const EdgeInsets.only(top: 0, right: 15),
                                  padding: const EdgeInsets.all(0),
                                  width: double.infinity,
                                  child: TextButton(
                                    style: const ButtonStyle(padding: MaterialStatePropertyAll(EdgeInsets.zero)),
                                    onPressed: () {
                                      Get.offAllNamed('/');
                                    },
                                    child: Text('업데이트', style: TextStyle(fontFamily: FONT_FAMILY,fontSize: 12, color: const Color(0xff000000).withOpacity(0.5),),),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 70,),
                      Container(
                        width: Responsive.isMobile(context) ? double.infinity : 460,
                        height: 520,
                        //color: Colors.yellow,
                        padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 30),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.0),
                            border: Responsive.isMobile(context) ? const Border.symmetric(vertical: BorderSide.none, horizontal: BorderSide.none) : Border.all(color: Colors.grey.shade300, width: 1.0,) //BorderSide()
                        ),
                        child:  Column(
                          // crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Image(image: AssetImage('images/img_header_logo.png')),
                            const Padding(
                              padding: EdgeInsets.only(top: 41, left: 20),
                              child: SizedBox(
                                width: double.infinity,
                                child: Text('사장님 아이디', textAlign: TextAlign.left, style: TextStyle(fontFamily: FONT_FAMILY, fontSize: 13, color: Color(0xff000000),),),
                              ),
                            ),
                            const SizedBox(height: 4,),
                            Padding(
                              padding: const EdgeInsets.only(left: 20, right: 20),
                              child: SizedBox(
                                height: 45,
                                width: double.infinity,
                                child: RawKeyboardListener(
                                  focusNode: focusID,
                                  onKey: (event) {
                                    if (event.logicalKey == LogicalKeyboardKey.tab) {
                                      FocusScope.of(context).nextFocus();
                                    }
                                  },
                                  child: TextField(
                                      controller: controller.idTextController,
                                      style: const TextStyle(fontSize: 16, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                                      onTap: () {
                                        controller.keyboardVisible();
                                      },
                                      textInputAction: TextInputAction.next,
                                      onSubmitted: (_) => {
                                        FocusScope.of(context).nextFocus(),
                                      },
                                      decoration: InputDecoration(
                                          isDense: true,
                                          enabledBorder: OutlineInputBorder(
                                            //borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                            borderSide: BorderSide(color: Colors.grey.shade300, width: 1.0),//(color: Colors.black12, width: 1.0),
                                          ),
                                          focusedBorder: const OutlineInputBorder(
                                            //borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                            borderSide: BorderSide(color: Colors.lightBlueAccent, width: 1.0),
                                          ),
                                          hintText: '사장님 아이디 입력',
                                          hintStyle: const TextStyle(fontSize: 16, color: Color(0xff999999), fontFamily: FONT_FAMILY),
                                          errorBorder: controller.submitError1 ? const UnderlineInputBorder(borderSide: BorderSide(color: Color(0xffBA292F))) : null
                                      ),
                                      onChanged: (String value) => {
                                        controller.submitError1 = false,
                                        controller.update(),
                                        controller.loginID = (value),
                                      },
                                      onEditingComplete: () => {
                                        FocusScope.of(context).nextFocus(),
                                      }
                                  ),
                                ),
                              ),
                            ),
                            const Padding(
                              padding: EdgeInsets.only(top: 20, left: 20),
                              child: SizedBox(
                                width: double.infinity,
                                child: Text('사장님 비밀번호', textAlign: TextAlign.left, style: TextStyle(fontFamily: FONT_FAMILY, fontSize: 13, color: Color(0xff000000),),),
                              ),
                            ),
                            const SizedBox(height: 4,),
                            Padding(
                              padding: const EdgeInsets.only(left: 20, right: 20),
                              child: SizedBox(
                                height: 45,
                                width: double.infinity,
                                child: RawKeyboardListener(
                                  focusNode: focusPW,
                                  child: TextField(
                                      obscureText: true,
                                      style: const TextStyle(fontSize: 16, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                                      decoration: InputDecoration(
                                        isDense: true,
                                        enabledBorder: OutlineInputBorder(
                                          //borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                          borderSide: BorderSide(color: Colors.grey.shade300, width: 1.0),//(color: Colors.black12, width: 1.0),
                                        ),
                                        focusedBorder: const OutlineInputBorder(
                                          //borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                          borderSide: BorderSide(color: Colors.lightBlueAccent, width: 1.0),
                                        ),
                                        hintText: '사장님 비밀번호 입력',
                                        hintStyle: const TextStyle(fontSize: 16, color: Color(0xff999999), fontFamily: FONT_FAMILY),
                                      ),
                                      onChanged: (String value) => {
                                        controller.submitError1 = false,
                                        controller.update(),
                                        controller.loginPW = (value),
                                      },
                                      onEditingComplete: () {
                                        if (controller.loginID == '' || controller.loginPW == '') {
                                          ISAlert(context, content: '아이디와 비밀번호를 입력해 주세요.');
                                          return;
                                        }
                                        setLogin(context, appTheme, controller);
                                      }
                                    // FocusScope.of(context).nextFocus(),
                                  ),
                                ),
                              ),
                            ),

                            Padding(
                              padding: const EdgeInsets.only(top: 10, left: 10),
                              child: Row(
                                children: [
                                  Checkbox(
                                    // tristate: !controller.saveID,
                                    //shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                    checkColor: Colors.white,
                                    // fillColor: MaterialStateProperty.resolveWith(getColor),
                                    activeColor: const Color(0xff01CAFF),
                                    materialTapTargetSize: MaterialTapTargetSize.padded,
                                    side: const BorderSide(width: 1),//, color: Color(0xff01CAFF)),
                                    value: controller.isIdSaved,
                                    onChanged: (value) {
                                      controller.isIdSaved = value!;
                                      controller.update();
                                    },
                                  ),
                                  const SizedBox(
                                    // width: double.infinity,
                                    height: 24,
                                    child: Text('아이디 저장', textAlign: TextAlign.left, style: TextStyle(fontFamily: FONT_FAMILY, fontSize: 16, color: Color(0xff000000),),),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 30, left: 20, right: 20),
                              child: SizedBox(
                                width: double.infinity,
                                height: 50,
                                child: TextButton(style: TextButton.styleFrom(backgroundColor: const Color(0xff01CAFF)),
                                  child: const Text("로그인", style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, fontSize: 24, color: Color(0xffFFFFFF)),),
                                  onPressed: () async {

                                    if (controller.loginID == '' || controller.loginPW == '') {
                                      ISAlert(context, content: '아이디와 비밀번호를 입력해 주세요.');
                                      return;
                                    }
                                    setLogin(context, appTheme, controller);

                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  );
                },
              ),
            ),
          ),
        ),
    );
  }

  setLogin(BuildContext context, AppTheme appTheme, LoginController controller) async {
    await showDialog(context: context, barrierColor: Colors.transparent,builder: (context) => FutureProgressDialog(LoginController.to.connectedlogIn())
    ).then((value) {
      if (value == '') {
        ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
        //Navigator.of(context).pop;
      }
      else{
        String code = value.split('|').first;
        String msg = value.split('|').last;

        if (code == '00') {
          appTheme.currentShopStatusGbn = AuthService.ShopStatus;

          context.go('/');
        }
        else{
          controller.submitError1 = false;
          controller.update();

          ISAlert(context, content: '로그인 실패.\n→ ${msg} ');
        }
      }
    });
  }
}
