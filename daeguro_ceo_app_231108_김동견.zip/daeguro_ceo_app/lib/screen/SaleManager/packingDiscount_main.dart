import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/models/SaleManager/packingDiscountModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManagerController.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/packingDiscountEdit.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/packingMinCostEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class PackDiscountMain extends StatefulWidget {
  const PackDiscountMain({Key? key}) : super(key: key);

  @override
  State<PackDiscountMain> createState() => _PackDiscountMainState();
}

class _PackDiscountMainState extends State<PackDiscountMain> with PageMixin{

  final ScrollController _scrollController = ScrollController();

  String? toGoDiscAmt = '0';//[포장할인금액]
  String? toGoMinAmt = '0';// [최소주문금액]
  String? toGoMinDiscAmt = '0';// [포장할인 최소 적용 금액]

  requestAPIData({bool? isRefresh = false}) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(CouponController.to.getPackDiscountInfo())
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      toGoDiscAmt = value['toGoDiscAmt'] as String;//[포장할인금액]
      toGoMinAmt = value['toGoMinAmt'] as String;// [최소주문금액]
      toGoMinDiscAmt = value['toGoMinDiscAmt'] as String;// [포장할인 최소 적용 금액]
    }

    if (isRefresh == true) {
      setState(() {});
    }
  }

  @override
  void initState() {
    super.initState();

    Get.put(CouponController());
    Get.put(ShopController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData(isRefresh: true);
    });
  }

  @override
  void dispose() {

    super.dispose();
    _scrollController.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          if (AuthService.ShopServiceGbn != AuthService.SHOPGBN_FLOWER){
            requestAPIData();
          }
          else{
            router.go('/');
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return fluentUI.ScaffoldPage.scrollable(
      scrollController: _scrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      children: <Widget>[
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ISLabelBarMain(
                leading: const Text('포장 할인', style: TextStyle( color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
                underLine: false,
                trailing: ISButton(
                  child: const Text('초기화'),
                  buttonColor: Colors.redAccent,
                  onPressed: () {
                    BuildContext oldContext = context;

                    ISConfirm(context, '포장 설정', '포장 최소 주문 금액을\n0원으로 초기화 하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                      Navigator.of(context).pop();

                      if (isOK){
                        showDialog(
                            context: context,
                            barrierColor: Colors.transparent,
                            builder: (context) => FutureProgressDialog(ShopController.to.updateShopInfo('7', '0', '0', '0'))
                        ).then((value) async {
                          if (value == null) {
                            ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                          }
                          else {
                            if (value == '00') {
                              ISAlert(oldContext, title: '알림', content: '변경이 완료되었습니다.');
                              await Future.delayed(const Duration(milliseconds: 250), () async {
                                requestAPIData();
                                await Future.delayed(const Duration(milliseconds: 250), () {
                                  setState(() { });
                                });
                              });
                            }
                            else{
                              ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                            }
                          }
                        });
                      }
                    });

                  },
                ),
            ),
            ISLabelBarSub(
              title: '포장 설정',
              body: Text('[최소 주문 금액]  ${Utils.getCashComma(toGoMinAmt!)} 원'),
              trailing: ISButton(
                child: const Text('변경'),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => PackingMinCostEdit(discAmt: toGoDiscAmt, minAmt: toGoMinAmt, minDiscAmt: toGoMinDiscAmt),
                  ).then((value) async {
                    //if (value == true){
                    await Future.delayed(const Duration(milliseconds: 250), () async {
                      requestAPIData();
                      await Future.delayed(const Duration(milliseconds: 250), () {
                        setState(() { });
                      });
                    });
                    //}
                  });
                },
              ),
            ),
            ISLabelBarSub(
              title: '포장 할인',
              body: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('[할인 최소 적용금액]  ${Utils.getCashComma(toGoMinDiscAmt !)} 원'),
                  const SizedBox(height: 8,),
                  Text('[할인금액]  ${Utils.getCashComma(toGoDiscAmt !)} 원'),

                ],
              ),
              trailing: ISButton(
                child: const Text('변경'),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => PackingDiscountEdit(discAmt: toGoDiscAmt, minAmt: toGoMinAmt, minDiscAmt: toGoMinDiscAmt),
                  ).then((value) async {
                    //if (value == true){
                    await Future.delayed(const Duration(milliseconds: 250), () async {
                      requestAPIData();
                      await Future.delayed(const Duration(milliseconds: 250), () {
                        setState(() { });
                      });
                    });
                    //}
                  });
                },
              ),
            ),
            const Divider(height: 1),
          ],
        ),
        //const SizedBox(height: 22.0),
      ],
    );
  }
}