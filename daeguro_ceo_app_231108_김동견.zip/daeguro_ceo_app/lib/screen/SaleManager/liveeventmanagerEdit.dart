import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/LiveEventManager/liveeventInfoEditModel.dart';
import 'package:daeguro_ceo_app/models/LiveEventManager/liveeventMenuListEditModel.dart';
import 'package:daeguro_ceo_app/models/LiveEventManager/liveeventMenuEditModel.dart';
import 'package:daeguro_ceo_app/models/LiveEventManager/liveeventTargetMenuListModel.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManagerController.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

enum Type { amount, percentage }

class LiveeventmanagerEdit extends StatefulWidget {
  // sData : 메뉴추가할때 쓰는 거 / iData : 라이브 이벤트 등록할 때 쓰는 거 / dData : 라이브 이벤트 삭제할 때 쓰는거 / eData : 라이브 이벤트 수정할 때 쓰는거
  final List<LiveEventTargetMenuListModel>? sData;
  final LiveEventInfoEditModel? iData;
  final LiveEventInfoEditModel? dData;
  final LiveEventInfoEditModel? eData;
  const LiveeventmanagerEdit({Key? key, this.sData, this.iData, this.dData, this.eData,}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return LiveeventmanagerEditState();
  }
}

class LiveeventmanagerEditState extends State<LiveeventmanagerEdit> {

  List<LiveEventMenuEditModel> dataList = [];

  Type discountType = Type.amount;

  List<ISOptionModel> selectBoxAmount = [];
  List<ISOptionModel> selectBoxPercentage = [];
  String? selectedBoxValue = '0';

  // 직접입력 표시여부
  bool isDirectInputVisible = false;

  String? directInputValue = '';

  String? couponYN = '';
  String? packYN = '';


  requestAPIData() async {



    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(CouponController.to.getLiveEventMenuList(AuthService.ShopServiceGbn == '5' ? 'P' : 'M'))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      List<LiveeEventMenuListEditModel> tempListData = [];
      value.forEach((element) {
        LiveeEventMenuListEditModel temp = LiveeEventMenuListEditModel();

        temp.ccCode = element['ccCode'] as String;
        temp.shopCd = element['shopCd'] as String;
        temp.menuGrpCd = element['menuGrpCd'] as String;
        temp.menuGrpName = element['menuGrpName'] as String;
        temp.menuCd = element['menuCd'] as String;
        temp.menuName = element['menuName'] as String;
        temp.noFlag = element['noFlag'] as String;
        temp.menuCost = element['menuCost'] as String;

        tempListData.add(temp);

        int result = dataList.indexWhere((element) => element.menuGroupName == temp.menuGrpName);

        if (result == -1){
          LiveEventMenuEditModel tempMainList = LiveEventMenuEditModel(menuGroupName: temp.menuGrpName, menu: []);
          dataList.add(tempMainList);
        }
      });

      dataList.forEach((element) {
        tempListData.forEach((menuElement) {
          if (element.menuGroupName == menuElement.menuGrpName){
            LiveeEventMenuListEditModel childMenu = LiveeEventMenuListEditModel();
            childMenu.selected = dataListCheckBoxCompare(menuElement.menuCd!);
            childMenu.ccCode = menuElement.ccCode;
            childMenu.shopCd = menuElement.shopCd;
            childMenu.menuGrpCd = menuElement.menuGrpCd;
            childMenu.menuGrpName = menuElement.menuGrpName;
            childMenu.menuCd = menuElement.menuCd;
            childMenu.menuName = menuElement.menuName;
            childMenu.noFlag = menuElement.noFlag;
            childMenu.menuCost = menuElement.menuCost;

            element.menu!.add(childMenu);
          }
        });
      });
    }
    if(widget.iData != null){
      var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(CouponController.to.getCouponSetList('1', '2', DateTime.now().toString(), DateTime.now().toString(), '1')),
      );
      couponYN = value.any((item) => item['status'] == 'Y') ? '사용' : '미사용';

      var value1 = await showDialog(
          context: context,
          barrierColor: Colors.transparent,
          builder: (context) => FutureProgressDialog(CouponController.to.getPackDiscountInfo())
      );
      packYN = value1['toGoDiscAmt'].toString() != '' && value1['toGoDiscAmt'] != null && value1['toGoDiscAmt'] != '0' ? '사용' : '미사용';
    }



    setState(() {});
  }

  bool dataListCheckBoxCompare(String menuCd){
    if (widget.sData != null){
      int retValue = widget.sData!.indexWhere((element) => element.menuCd == menuCd);
      if (retValue != -1) {
        return true;
      }
    }

    return false;
  }

  @override
  void dispose() {
    super.dispose();
    dataList.clear();
    selectBoxAmount.clear();
    selectBoxPercentage.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(CouponController());

    // 할인금액선택목록
    selectBoxAmount = List.generate(11, (index) {
      return ISOptionModel(
          value: (index * 1000).toString(),
          label: index == 0 ? '선택' : index == 10
              ? '직접 입력' : '${Utils.getCashComma((index * 1000).toString())}원');
    });

    // 할인율선택목록
    selectBoxPercentage = List.generate(11, (index) {
      return ISOptionModel(
          value: (index * 10).toString(),
          label: index == 0 ? '선택' : index == 10
              ? '직접 입력' : '${Utils.getCashComma((index * 10).toString())}%');
    });

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });

  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 720),
      // contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          (widget.sData == null || widget.sData == '') ? Text((widget.iData != null && widget.iData != '') ? '라이브 이벤트를 등록하시겠습니까?' : '라이브 이벤트 종료', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY),) : const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text('메뉴 등록', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
              SizedBox(width: 8,),
              Tooltip(message: '할인금액 및 할인율은 선택된 메뉴에 일괄 적용됩니다.',
                child: Icon(Icons.help_outline, color: Colors.blue, size: 22,),
              ),
            ],
          ),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: (widget.iData != '' && widget.iData != null) ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10,),
                AuthService.ShopServiceGbn == '5'?
                const Text('※ 주의: 해당 쿠폰은 다른 혜택과 중복 적용 가능합니다.\n※ 주의: 상품 할인 전 가격 기준으로 할인이 적용 됩니다.', style: TextStyle(color: Colors.red, fontSize: 18, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)):
                const Text('※ 주의: 해당 쿠폰은 다른 혜택과 중복 적용 가능합니다.', style: TextStyle(color: Colors.red, fontSize: 18, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                const SizedBox(height: 5,),
                const Text( '* 현재 사용 중인 혜택', style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD),),
                const SizedBox(height: 5,),
                Text('포장 할인 : $packYN', style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL),),
                const SizedBox(height: 5,),
                Text('우리 가게 쿠폰 : $couponYN', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL),),
                const SizedBox(height: 18,),
              ],
            ) : (widget.sData != '' && widget.sData != null) ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 16,),
                const Text('금액 설정', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),),
                SizedBox(
                  height: 46,
                  child: Row(
                    children: [
                      Radio(
                        visualDensity: const VisualDensity(horizontal: VisualDensity.minimumDensity, vertical: VisualDensity.minimumDensity),
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        groupValue: discountType,
                        onChanged: (Type? value) {
                          setState(() {
                            isDirectInputVisible = false;
                            selectedBoxValue = '0';
                            discountType = value!;
                          });
                        },
                        value: Type.amount,
                      ),
                      const Text("할인금액", style: TextStyle(fontSize: 13),),
                      const SizedBox(width: 8,),
                      Radio(
                        visualDensity: const VisualDensity(horizontal: VisualDensity.minimumDensity, vertical: VisualDensity.minimumDensity),
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        groupValue: discountType,
                        onChanged: (Type? value) {
                          setState(() {
                            isDirectInputVisible = false;
                            selectedBoxValue = '0';
                            discountType = value!;
                          });
                        },
                        value: Type.percentage,
                      ),
                      const Text("할인율", style: TextStyle(fontSize: 13),),
                      const SizedBox(width: 8,),
                      ISSearchDropdown(
                        width: 100,
                        height: 40,
                        label: '선택',
                        value: selectedBoxValue,
                        onChange: (value) {
                          //
                          selectedBoxValue = value;
                          directInputValue = '';
                          if (selectedBoxValue == '10000' || selectedBoxValue == '100') {
                            isDirectInputVisible = true;
                          } else {

                            isDirectInputVisible = false;
                          }

                          setState(() {
                          });
                        },
                        item: discountType == Type.amount ? selectBoxAmount : selectBoxPercentage,
                      ),
                      const SizedBox(width: 8,),
                      Visibility(
                        visible: isDirectInputVisible,
                        child: ISInput(
                          context: context,
                          width: 100,
                          autofocus: true,
                          textAlign: TextAlign.end,
                          value: Utils.getCashComma(directInputValue!) ,
                          suffixText: discountType == Type.amount ? '원' : '%',
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                          onChange: (v) {
                            setState(() {
                              directInputValue = v.toString();
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                // menuList(data!)!,
                const SizedBox(height: 6,),
                Column(
                  children: [
                    ...dataList.map((memberMenu) =>
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10),
                                width: double.infinity,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: Colors.black12,
                                  border: Border.all(width: 1.0, color: Colors.black26),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    SizedBox(width: Responsive.isMobile(context) ? 250 : null, child: Text(memberMenu.menuGroupName!, style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, overflow: TextOverflow.ellipsis),)),
                                    const Text('가격', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                  ],
                                )
                            ),
                            ...memberMenu.menu!.map((memberData) =>
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10),
                                  width: double.infinity,
                                  height: 40,
                                  decoration: BoxDecoration(color: Colors.white, border: Border.all(width: 1.0, color: Colors.black26),),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      fluentUI.Checkbox(
                                          content: SizedBox(
                                              width: Responsive.isMobile(context) ? 195 : 290,
                                              child: Text(memberData.menuName!, style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, overflow: TextOverflow.ellipsis))
                                          ),
                                          checked: memberData.selected,
                                          onChanged: (v) => setState(() => memberData.selected = v!)
                                      ),
                                      Text('${Utils.getCashComma(memberData.menuCost!)}원', style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                    ],
                                  ),
                                )
                            ).toList(),
                          ],
                        ),
                    ).toList(),
                  ],
                ),
                const SizedBox(height: 20,),
                // ISInput(
                //   value: data!.notifyMessage ?? '',
                //   context: context,
                //   height: 220,
                //   //padding: 0,
                //   label: '알림 메시지를 작성해주세요!',
                //   keyboardType: TextInputType.multiline,
                //   maxLines: 8,
                //   maxLength: 4000,
                //   onChange: (v) {
                //     setState(() {
                //       data!.notifyMessage = v;
                //     });
                //   },
                // ),
              ],
            ) : (widget.dData != '' && widget.dData != null) ? const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 10,),
                Text( '라이브 이벤트를 종료하시겠습니까?', style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD),),
                SizedBox(height: 5,),
                Text('※ 종료 시 다시 등록할 수 없습니다.\n(1일 1회 제한 됩니다.)', style: TextStyle(color: Colors.red, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                SizedBox(height: 18,),
              ],
            ) : Container(),
          ),
        ),
      ),
      actions: [
        SizedBox(
          //width: double.infinity,
          child: FilledButton(
            style: ButtonStyle(
              minimumSize: MaterialStateProperty.all(const Size(60, 70)), //Size.fromHeight(60),
              backgroundColor: const MaterialStatePropertyAll(Color(0xff333333)),
              shape: const MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.only(bottomLeft: Radius.circular(11.0)) //.circular(4.0)
              )),
            ),
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          //width: double.infinity,
          child: FilledButton(
            style: ButtonStyle(
              minimumSize: MaterialStateProperty.all(const Size(60, 70)), //Size.fromHeight(60),
              backgroundColor: const MaterialStatePropertyAll(Color(0xff01CAFF)),
              shape: const MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.only(bottomRight: Radius.circular(11.0)) //BorderRadius.circular(4.0))
              )),
            ),
            onPressed: () {

              BuildContext oldContext = context;

              if(widget.sData == null || widget.sData == ''){
                if(widget.dData == null || widget.dData == ''){
                  ISConfirm(context, '알림' , '라이브 이벤트를 등록하시겠습니까? \n\n저장 후에는 수정이 불가합니다.', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                    Navigator.of(context).pop();
                    if (isOK){
                      var value = await showDialog(
                          context: context,
                          builder: (context) => FutureProgressDialog(CouponController.to.setShopLiveEvent(widget.iData!.toJson()))
                      );
                      if (value == null) {
                        ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                      }
                      else {
                        if (value == '00') {
                          Navigator.of(oldContext).pop(true);
                          ISAlert(oldContext, content: '라이브 이벤트 등록이 완료되었습니다.');
                        }
                        else{
                          ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                        }
                      }
                    }
                  });
                }else{
                  ISConfirm(context, '알림' , '라이브 이벤트를 종료하시겠습니까?\n종료 시 다시 등록할 수 없습니다.\n(1일 1회 제한됩니다.)', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                    Navigator.of(context).pop();
                    if (isOK){
                      var value = await showDialog(
                          context: context,
                          builder: (context) => FutureProgressDialog(CouponController.to.setShopLiveEvent(widget.dData!.toJson()))
                      );
                      if (value == null) {
                        ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                      }
                      else {
                        if (value == '00') {
                          Navigator.of(oldContext).pop(true);
                        }
                        else{
                          ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                        }
                      }
                    }
                  });
                }
              }else{
                String? discountValue = (isDirectInputVisible == true) ? directInputValue : selectedBoxValue;

                if (discountValue == '' || discountValue == '0'){
                  ISAlert(context, content: '할인금액(율) 미입력 하셨습니다. 작성 후 이용해 주세요.');
                  return;
                }

                List<LiveEventTargetMenuListModel> targetList = [];
                List<LiveeEventMenuListEditModel> tempList = [];

                int index = 1;
                dataList.forEach((element) {
                  tempList = element.menu!.where((element) => element.selected == true).toList();
                  tempList.forEach((childElement) {
                    LiveEventTargetMenuListModel targetTemp = LiveEventTargetMenuListModel();
                    targetTemp.menuCd = childElement.menuCd;
                    targetTemp.menuIdx = index.toString();
                    targetTemp.menuName = childElement.menuName;
                    targetTemp.menuPrice = childElement.menuCost;
                    targetTemp.eventAmt = discountValue;
                    targetTemp.eventGbn = (discountType == Type.amount) ? '1' : '3'; //1:정액(할인금액), 3:정율(할인율)

                    // 처리순서 절대 바꾸지말것!!
                    if (targetTemp.eventGbn == '1'){
                      targetTemp.menuDiscCost = targetTemp.eventAmt;

                      var _calc = 100 - ((int.parse(targetTemp.menuPrice!) - int.parse(targetTemp.eventAmt!)) * 100 / int.parse(targetTemp.menuPrice!)).floor();
                      targetTemp.menuDiscPer = _calc.toString();

                      targetTemp.totalPrice = (int.parse(targetTemp.menuPrice!) - int.parse(targetTemp.eventAmt!)).toString();
                    }
                    else if (targetTemp.eventGbn == '3'){
                      targetTemp.menuDiscPer = targetTemp.eventAmt;

                      var _calc = (int.parse(targetTemp.menuPrice!) - (int.parse(targetTemp.menuPrice!) * int.parse(targetTemp.eventAmt!) / 100)).floor();
                      targetTemp.totalPrice = _calc.toString();//(int.parse(targetTemp.menuPrice!) - int.parse(targetTemp.menuDiscCost!)).toString();

                      targetTemp.menuDiscCost = (int.parse(targetTemp.menuPrice!) - int.parse(targetTemp.totalPrice!)).toString();
                    }

                    targetList.add(targetTemp);
                    index++;
                  });
                });

                if (targetList.length > 10){
                  ISAlert(context, content: '이벤트 메뉴 10개를 초과하셨습니다.\n다시 선택해 주세요.');
                  return;
                }

                if (discountType == Type.amount){
                  var retValue = targetList.where((element) => (int.parse(discountValue!) > int.parse(element.menuPrice!))).toList();
                  if (retValue.isNotEmpty){
                    ISAlert(context, content: '${retValue[0].menuName}는(은) 메뉴 금액보다 할인금액이 더 큽니다.');
                    return;
                  }
                }
                Navigator.of(context).pop(targetList);
              }
            },
            child: Text((widget.sData == null || widget.sData == '')  ? '확인' : '저장', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}
