import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_datatable.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/SaleManager/couponEditModel.dart';
import 'package:daeguro_ceo_app/models/SaleManager/couponListModel.dart';
import 'package:daeguro_ceo_app/models/SaleManager/couponUseStatusListModel.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManagerController.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:provider/provider.dart';

class CouponInfoMain extends StatefulWidget {
  final double? tabviewHeight;

  const CouponInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<CouponInfoMain> createState() => _CouponInfoMainState();
}

class _CouponInfoMainState extends State<CouponInfoMain> {

  final List<CouponListModel> dataList = <CouponListModel>[];
  List<CouponUseStatusListModel> couponStatusList = <CouponUseStatusListModel>[];
  final ScrollController _scrollController = ScrollController();

  String? startdate = '';
  String? enddate = '';
  String? searchGbn = '2';
  String? searchStatus = '2';
  String? selectDate = '1000';

  int selectedPageNumber = 1;
  int totalPage = 0;
  bool pickDate = false;

  int? totIssueCnt;
  int? totAmt;
  int? totUseCnt;

  String? tipFrStand = '';
  requestAPIData() async {
    var value = await showDialog(

      context: context,
      barrierColor: Colors.transparent,
      builder: (context) =>
          FutureProgressDialog(CouponController.to.getCouponSetList(
              (selectDate == '1000' ? '1' : searchGbn!), searchStatus!, startdate!.replaceAll('-', ''), enddate!.replaceAll('-', ''), selectedPageNumber.toString())),
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    } else {
      dataList.clear();

      value.forEach((element) {
        CouponListModel temp = CouponListModel();

        temp.rNum = element['rNum'] as String;
        temp.seq = element['seq'] as String;
        temp.shopCd = element['shopCd'] as String;
        temp.couponType = element['couponType'] as String;
        temp.applyGbn = element['applyGbn'] as String;
        temp.couponName = element['couponName'] as String;
        temp.displayStDate = element['displayStDate'] as String;
        temp.displayEndDate = element['displayEndDate'] as String;
        temp.expSetDate = element['expSetDate'] as String;
        temp.useGbn = element['useGbn'] as String;
        temp.status = element['status'] as String;
        temp.couponNotice = element['couponNotice'] as String;
        temp.couponAmt = element['couponAmt'] as String;
        temp.tipFrStand = element['tipFrStand'] as String;
        temp.issueQnt = element['issueQnt'] as String;
        temp.useQnt = element['useQnt'] as String;

        dataList.add(temp);
        tipFrStand = element['tipFrStand'] as String;
      });

      totalPage = CouponController.to.total_page;
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(CouponController());

    startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    dataList.clear();
    _scrollController.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return Responsive.isMobile(context) ? mobileCouponinfoWidget() : CouponinfoWidget();
  }

  Widget CouponinfoWidget() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ISLabelBarMain(
            leading: const Text(
              '* 쿠폰 적용까지 시간이 일부 소요될 수 있습니다.',
              style: TextStyle(color: Colors.grey, fontSize: 14),
            ),
            trailing: ISButton(
              child: const Text('쿠폰 등록'),
              onPressed: () {
                showDialog(
                  context: context,
                  barrierDismissible: true,
                  builder: (context) => CouponEdit(tipFrStand: tipFrStand!),
                ).then((v) async {
                  if (v == true) {
                    await Future.delayed(Duration(milliseconds: 500), () {
                      requestAPIData();
                    });
                  }
                });
              },
            ),
          ),
          const SizedBox(
            height: 8,
          ),
          Row(children: searchBarView()),
          const SizedBox(
            height: 8,
          ),
          Material(
            child: ISDatatable(
              listWidth: Responsive.getResponsiveWidth(context),
              //MediaQuery.of(context).size.width,
              listHeight: (widget.tabviewHeight! - 138.0),
              headingRowHeight: 40,
              dataRowHeight: 40,
              minWidth: 800,
              columns: const <DataColumn>[
                DataColumn(
                  label: Expanded(child: Text('쿠폰 이벤트', textAlign: TextAlign.center)),
                ),
                DataColumn(
                  label: Expanded(child: Text('상태', textAlign: TextAlign.center)),
                ),
                DataColumn(
                  label: Expanded(child: Text('쿠폰 이름', textAlign: TextAlign.center)),
                ),
                DataColumn(
                  label: Expanded(child: Text('쿠폰 발급 가능 기간', textAlign: TextAlign.center)),
                ),
                DataColumn(
                  label: Expanded(child: Text('주문 유형', textAlign: TextAlign.center)),
                ),
                DataColumn(
                  label: Expanded(child: Text('할인금액', textAlign: TextAlign.center)),
                ),
                DataColumn(
                  label: Expanded(child: Text('쿠폰 발급 건', textAlign: TextAlign.center)),
                ),
                DataColumn(
                  label: Expanded(child: Text('쿠폰 사용 건', textAlign: TextAlign.center)),
                ),
                DataColumn(
                  label: Expanded(child: Text('관리', textAlign: TextAlign.center)),
                ),
              ],
              rows: List<DataRow>.generate(dataList.length, (index) {
                return DataRow(
                    selected: dataList[index].selected!,
                    color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
                      if (dataList[index].selected == true) {
                        return Colors.grey.shade200;
                        //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
                      }

                      return Theme
                          .of(context)
                          .colorScheme
                          .primary
                          .withOpacity(0.00);
                    }),
                    onSelectChanged: (bool? value) {
                      // dataList.forEach((element) {
                      //   element.selected = false;
                      // });

                      //
                      // dataList[index].isChild
                      //     ? null
                      //     : dataList[index].selected == true
                      //     ? {dataList.removeRange(index + 1, index + 2),dataList[index].selected = false}
                      //     : {dataList.insert(
                      //     index + 1,
                      //     CouponListModel(
                      //         useGbn : '쿠폰상세',
                      //         isChild : true
                      //     )),
                      //   dataList[index].selected = true};
                      //


                      // showDialog(
                      //   context: context,
                      //   barrierDismissible: true,
                      //   builder: (context) => const OrderDetailInfo(),
                      // );

                      setState(() {});
                    },
                    cells: [
                      DataCell(Align(
                        alignment: Alignment.center,
                        //child: Text(item.useGbn.toString() == null ? '--' : item.useGbn.toString()),
                        child: fluentUI.ToggleSwitch(
                          checked: dataList[index].useGbn.toString() == 'Y' ? true : false,
                          onChanged: (v) {
                            String oldUseGbn = dataList[index].useGbn.toString();

                            ISConfirm(context, '쿠폰 이벤트 변경', v == true ? '[${dataList[index].couponName}]가 진행됩니다. \n\n이벤트를 진행하시겠습니까?' : '[${dataList[index].couponName}]가 중단됩니다. \n\n이벤트를 중단하시겠습니까?',
                                constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                                  Navigator.of(context).pop();

                                  if (isOK) {
                                    //setState(() {
                                    dataList[index].useGbn = v == true ? 'Y' : 'N';
                                    //});

                                    CouponEditModel sendData = CouponEditModel();
                                    sendData.jobGbn = '2';
                                    sendData.shopCd = AuthService.SHOPCD;
                                    sendData.couponName = dataList[index].couponName;
                                    sendData.displayStDate = dataList[index].displayStDate;
                                    sendData.displayEndDate = dataList[index].displayEndDate;
                                    sendData.useGbn = dataList[index].useGbn;
                                    sendData.applyMinAmt = [];
                                    sendData.couponAmt = [];
                                    sendData.seq = dataList[index].seq;
                                    sendData.couponType = dataList[index].couponType;
                                    sendData.applyGbn = dataList[index].applyGbn;
                                    sendData.expSetDate = dataList[index].expSetDate;
                                    sendData.uCode = AuthService.uCode;
                                    sendData.uName = AuthService.uName;

                                    var value = await showDialog(
                                        context: context, barrierColor: Colors.transparent, builder: (context) => FutureProgressDialog(CouponController.to.setCoupon(sendData.toJson())));

                                    if (value == null) {
                                      setState(() {
                                        dataList[index].useGbn = oldUseGbn;
                                      });

                                      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                                      return;
                                    } else {
                                      if (value == '00') {
                                        setState(() {
                                          dataList[index].useGbn = v == true ? 'Y' : 'N';
                                        });

                                        requestAPIData();
                                      } else {
                                        setState(() {
                                          dataList[index].useGbn = oldUseGbn;
                                        });

                                        ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                        return;
                                      }
                                    }
                                  } else {
                                    setState(() {
                                      dataList[index].useGbn = oldUseGbn;
                                    });
                                  }
                                });
                          },
                        ),
                      )),
                      DataCell(Align(
                        alignment: Alignment.center,
                        child: _buildPanelContainer(
                            child: Text(getStatusStr(dataList[index].status!), style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                            height: 26,
                            color: getStatusColor(dataList[index].status!)),
                      )),
                      DataCell(Align(
                        alignment: Alignment.center,
                        child: Text(dataList[index].couponName!.toString() == null ? '--' : dataList[index].couponName.toString(), style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                      )),
                      DataCell(Align(
                        alignment: Alignment.center,
                        child: Text('${Utils.getDateFormat(dataList[index].displayStDate!)} ~ ${Utils.getDateFormat(dataList[index].displayEndDate!)}',
                            style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                      )),
                      DataCell(Align(
                        alignment: Alignment.center,
                        child: Text(getApplyGbnStr(dataList[index].applyGbn!), style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                      )),
                      DataCell(Align(
                        alignment: Alignment.center,
                        child: Text(dataList[index].couponAmt!.toString() == null ? '--' : dataList[index].couponAmt.toString(), style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                      )),
                      DataCell(Align(
                        alignment: Alignment.center,
                        child: Text(dataList[index].issueQnt!.toString() == null ? '--' : '${dataList[index].issueQnt!.toString()}건', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                      )),
                      DataCell(Align(
                        alignment: Alignment.center,
                        child: Text(dataList[index].useQnt!.toString() == null ? '--' : '${dataList[index].useQnt!.toString()}건', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                      )),
                      DataCell(
                          dataList[index].status! != 'E' ?
                          Align(
                            alignment: Alignment.center,
                            child: ISButton(
                              child: const Text('수정'),
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  barrierDismissible: true,
                                  builder: (context) => CouponEdit(sData: dataList[index], tipFrStand: tipFrStand!),
                                ).then((v) async {
                                  if (v == true) {
                                    await Future.delayed(Duration(milliseconds: 500), () {
                                      requestAPIData();
                                    });
                                  }
                                });
                              },
                            ),
                          )
                      : Container()
                      ),
                    ]);
              }).toList(),
            ),
          ),
          ISNumberPagination(
            threshold: 5,
            controlButton: const SizedBox(
              width: 10,
              height: 10,
            ),
            onPageChanged: (int pageNumber) {
              setState(() {
                selectedPageNumber = pageNumber;
              });

              requestAPIData();
            },
            fontSize: 12,
            pageTotal: totalPage,
            pageInit: selectedPageNumber,
            // picked number when init page
            colorPrimary: Colors.black,
            colorSub: Colors.white,
          ),
          Container(
            padding: const EdgeInsets.all(16.0),
            width: double.infinity,
            //color: Colors.grey[300],
            decoration: const BoxDecoration(
                color: Color(0xffF3F5F7), //Colors.grey[300],
                // border: Border.all(
                //   width: 20,
                //   color: Colors.grey[700]!,
                // ),
                borderRadius: BorderRadius.all(Radius.circular(6))),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('· 고객이 이미 쿠폰을 발급받았으면 쿠폰의 유효기간 내에는 혜택 상태와 관계없이 쿠폰 사용이 가능합니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                SizedBox(
                  height: 8,
                ),
                Text('· 주문 앱 노출 시기는 쿠폰 적용 날짜 및 쿠폰 활성화 시 적용됩니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, color: Colors.red, fontWeight: FontWeight.bold)),
                SizedBox(
                  height: 8,
                ),
                Text('· 쿠폰은 고객이 사용할 경우 다시 다운로드 가능합니다.(미사용 했을 경우 한 번에 여러 장 발급 불가능)', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                SizedBox(
                  height: 8,
                ),
                Text('· 사장님의 과실로 일어난 비용 부담에 대한 책임은 사장님에게 있습니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                SizedBox(
                  height: 8,
                ),
                Text('· 쿠폰 이벤트는 최대 5개까지 등록 가능합니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                SizedBox(
                  height: 8,
                ),
                Text('· 포장 할인 / 라이브 이벤트와 중복 적용 가능합니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY))
              ],
            ),
          ),
          //const Divider(height: 1)
        ],
      ),
    );
  }

  Widget mobileCouponinfoWidget() {
    return SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8,),
          const Text('* 쿠폰 적용까지 시간이 일부 소요될 수 있습니다.', style: TextStyle(color: Colors.grey, fontSize: 14),),
          const SizedBox(height: 8,),
          Column(children: searchBarView()),
          const SizedBox(height: 8,),
          ISButton(
            height: 48,
            width: double.infinity,
            child: const Text('쿠폰 등록'),
            onPressed: () {
              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => CouponEdit(tipFrStand: tipFrStand!),
              ).then((v) async {
                if (v == true) {
                  await Future.delayed(Duration(milliseconds: 500), () {
                    requestAPIData();
                  });
                }
              });
            },
          ),
          const SizedBox(height: 8,),
          ListView(
              controller: _scrollController,
              shrinkWrap: true,
              children: List.generate(
                dataList.length,
                    (index) {
                  return fluentUI.Expander(
                      headerHeight: Get.width < 375 ? 80 : 60,
                      shapeRadius: 0.0,
                      contentBackgroundColor: const Color.fromARGB(255, 234, 234, 234),
                      header: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 5,),
                          Row(
                            children: [
                              _buildPanelContainer(child: Text(
                                  getStatusStr(dataList[index].status!), style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                                  height: 23,
                                  color: getStatusColor(dataList[index].status!)),
                              const SizedBox(width: 10,),
                              Flexible(child: Text(dataList[index].couponName.toString(), style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD), overflow: TextOverflow.ellipsis , maxLines: 1,)),
                            ],
                          ),
                          const SizedBox(height: 5,),
                          Container(
                              margin: const EdgeInsets.only(left: 8),
                              child: Text('발급 가능 기간 : ${Utils.getDateFormat(dataList[index].displayStDate!)} ~ ${Utils.getDateFormat(dataList[index].displayEndDate!)}', style: const TextStyle(
                                  color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                        ],
                      ),
                      content: Padding(
                        padding: const EdgeInsets.only(left: 16, right: 56, top: 8, bottom: 8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('주문 유형', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                Text(getApplyGbnStr(dataList[index].applyGbn!), style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('할인금액', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                Text(dataList[index].couponAmt!.toString() == null ? '--' : dataList[index].couponAmt.toString(),
                                    style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('쿠폰 발급 건', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                Text(dataList[index].issueQnt!.toString() == null ? '--' : '${dataList[index].issueQnt!.toString()}건', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('쿠폰 사용 건', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                Text(dataList[index].useQnt!.toString() == null ? '--' : '${dataList[index].useQnt!.toString()}건', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  margin: const EdgeInsets.only(left: 5),
                                  child: fluentUI.ToggleSwitch(
                                    checked: dataList[index].useGbn.toString() == 'Y' ? true : false,
                                    onChanged: (v) {
                                      String oldUseGbn = dataList[index].useGbn.toString();
                                      ISConfirm(context, '쿠폰 이벤트 변경',
                                          v == true ? '[${dataList[index].couponName}]가 진행됩니다. \n\n이벤트를 진행하시겠습니까?' : '[${dataList[index].couponName}]가 중단됩니다. \n\n이벤트를 중단하시겠습니까?',
                                          constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260),
                                              (context, isOK) async {
                                            Navigator.of(context).pop();

                                            if (isOK) {
                                              //setState(() {
                                              dataList[index].useGbn = v == true ? 'Y' : 'N';
                                              //});

                                              CouponEditModel sendData = CouponEditModel();
                                              sendData.jobGbn = '2';
                                              sendData.shopCd = AuthService.SHOPCD;
                                              sendData.couponName = dataList[index].couponName;
                                              sendData.displayStDate = dataList[index].displayStDate;
                                              sendData.displayEndDate = dataList[index].displayEndDate;
                                              sendData.useGbn = dataList[index].useGbn;
                                              sendData.applyMinAmt = [];
                                              sendData.couponAmt = [];
                                              sendData.seq = dataList[index].seq;
                                              sendData.couponType = dataList[index].couponType;
                                              sendData.applyGbn = dataList[index].applyGbn;
                                              sendData.expSetDate = dataList[index].expSetDate;
                                              sendData.uCode = AuthService.uCode;
                                              sendData.uName = AuthService.uName;

                                              var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(CouponController.to.setCoupon(sendData.toJson())));

                                              if (value == null) {
                                                setState(() {
                                                  dataList[index].useGbn = oldUseGbn;
                                                });

                                                ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                                                return;
                                              } else {
                                                if (value == '00') {
                                                  setState(() {
                                                    dataList[index].useGbn = v == true ? 'Y' : 'N';
                                                  });

                                                  requestAPIData();
                                                } else {
                                                  setState(() {
                                                    dataList[index].useGbn = oldUseGbn;
                                                  });

                                                  ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                                  return;
                                                }
                                              }
                                            } else {
                                              setState(() {
                                                dataList[index].useGbn = oldUseGbn;
                                              });
                                            }
                                          });
                                    },
                                  ),
                                ),
                                dataList[index].status! != 'E' ?
                                ISButton(
                                  child: const Text('수정'),
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      barrierDismissible: true,
                                      builder: (context) => CouponEdit(sData: dataList[index], tipFrStand: tipFrStand!),
                                    ).then((v) async {
                                      if (v == true) {
                                        await Future.delayed(Duration(milliseconds: 500), () {
                                          requestAPIData();
                                        });
                                      }
                                    });
                                  },
                                ) : Container()
                              ],
                            )
                          ],
                        ),
                      ));
                },
              )),
          ISNumberPagination(
            threshold: 5,
            controlButton: const SizedBox(
              width: 10,
              height: 10,
            ),
            onPageChanged: (int pageNumber) {
              setState(() {
                selectedPageNumber = pageNumber;
              });

              requestAPIData();
            },
            fontSize: 12,
            pageTotal: totalPage,
            pageInit: selectedPageNumber,
            // picked number when init page
            colorPrimary: Colors.black,
            colorSub: Colors.white,
          ),
          Container(
            padding: const EdgeInsets.all(16.0),
            width: double.infinity,
            //color: Colors.grey[300],
            decoration: const BoxDecoration(
                color: Color(0xffF3F5F7), //Colors.grey[300],
                // border: Border.all(
                //   width: 20,
                //   color: Colors.grey[700]!,
                // ),
                borderRadius: BorderRadius.all(Radius.circular(6))),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('· 고객이 이미 쿠폰을 발급받았으면 쿠폰의 유효기간 내에는 혜택 상태와 관계없이 쿠폰 사용이 가능합니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                SizedBox(
                  height: 8,
                ),
                Text('· 주문 앱 노출 시기는 쿠폰 적용 날짜 및 쿠폰 활성화 시 적용됩니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, color: Colors.red, fontWeight: FontWeight.bold)),
                SizedBox(
                  height: 8,
                ),
                Text('· 쿠폰은 고객이 사용할 경우 다시 다운로드 가능합니다.(미사용 했을 경우 한 번에 여러 장 발급 불가능)', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                SizedBox(
                  height: 8,
                ),
                Text('· 사장님의 과실로 일어난 비용 부담에 대한 책임은 사장님에게 있습니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                SizedBox(
                  height: 8,
                ),
                Text('· 쿠폰 이벤트는 최대 5개까지 등록 가능합니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                SizedBox(
                  height: 8,
                ),
                Text('· 포장 할인 / 라이브 이벤트와 중복 적용 가능합니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY))
              ],
            ),
          ),
          //const Divider(height: 1)
        ],
      ),
    );
  }

  List<Widget> searchBarView() {
    return [
      ISSearchDropdown(
        width: Responsive.isMobile(context) == true ? double.infinity : 120,
        label: '업체 타입',
        value: searchStatus,
        onChange: (value) {
          searchStatus = value;

          selectedPageNumber = 1;
          requestAPIData();
        },
        item: [
          ISOptionModel(value: '2', label: '진행 중/대기'),
          ISOptionModel(value: '1', label: '종료'),
        ].cast<ISOptionModel>(),
      ),
      Responsive.isMobile(context) == true
          ? const SizedBox(
        height: 8,
      )
          : const SizedBox(
        width: 8,
      ),
      ISSearchDropdown(
        width: Responsive.isMobile(context) == true ? double.infinity : 120,
        label: '조회 구분',
        value: searchGbn,
        onChange: (value) {
          searchGbn = value;

          selectedPageNumber = 1;
          requestAPIData();
        },
        item: [
          ISOptionModel(value: '2', label: '시작일'),
          ISOptionModel(value: '3', label: '종료일'),
        ].cast<ISOptionModel>(),
      ),
      Responsive.isMobile(context) == true
          ? const SizedBox(
        height: 8,
      )
          : const SizedBox(
        width: 8,
      ),
      Material(
        child: ISSearchSelectDate(
          label: '기간 선택',
          width: Responsive.isMobile(context) == true ? double.infinity : 230,
          value: '${startdate.toString()} ~ ${enddate.toString()}',
          onTap: () async {
            showGeneralDialog(
                context: context,
                barrierDismissible: true,
                barrierLabel: '',
                barrierColor: Colors.black54,
                pageBuilder: (context, animation, secondaryAnimation) {
                  return Dialog(
                    insetPadding: EdgeInsets.zero,
                      elevation: 0,
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                      child: MultipleViewDateRangePicker(
                        startDate: DateTime.parse(startdate!),
                        endDate: DateTime.parse(enddate!),
                        setDateActionCallback: ({startDate, endDate}) {
                          Navigator.of(context).pop();

                          startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                          enddate = DateFormat('yyyy-MM-dd').format(endDate!);

                          Duration diff = DateTime.parse(enddate!).difference(DateTime.parse(startdate!));

                          selectDate = diff.inDays.toString();

                          selectedPageNumber = 1;
                          pickDate = true;

                          requestAPIData();
                        },
                      ));
                });
          },
        ),
      ),
      Responsive.isMobile(context) == true
          ? const SizedBox(
        height: 8,
      )
          : const SizedBox(
        width: 8,
      ),
      ISToggleButtons(
        [
          ISOptionModel(value: '30', label: '1개월'),
          ISOptionModel(value: '90', label: '3개월'),
          ISOptionModel(value: '180', label: '6개월'),
          ISOptionModel(value: '365', label: '1년'),
          ISOptionModel(value: '1000', label: '전체'),
        ],
        buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 5) - 6) : 60,
        defaultValue: selectDate,
        pickDate: pickDate,
        afterOnPress: (v) {
          setState(() {
            if (v != '1000') {

              if(searchStatus == '2' && searchGbn == '3'){
                startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
                enddate = formatDate(DateTime.now().add(Duration(days: int.parse(v.toString()))), [yyyy, '-', mm, '-', dd]);
              } else{
              startdate = formatDate(DateTime.now().subtract(Duration(days: int.parse(v.toString()))), [yyyy, '-', mm, '-', dd]);
              enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
            }
            }

            selectDate = v;
            pickDate = false;
          });

          selectedPageNumber = 1;

          requestAPIData();
        },
      ),
    ];
  }

  String getApplyGbnStr(String applyGbn) {
    String? tempStr;

    if (applyGbn == 'D')
      tempStr = '배달';
    else if (applyGbn == 'T')
      tempStr = '포장';
    else if (applyGbn == 'A')
      tempStr = '배달/포장';
    else
      tempStr = '';

    return tempStr!;
  }

  String getStatusStr(String status) {
    String? tempStr;

    if (status == 'E')
      tempStr = '종료';
    else if (status == 'Y')
      tempStr = '진행중';
    else if (status == 'N')
      tempStr = '대기';
    else
      tempStr = '';

    return tempStr!;
  }

  Color getStatusColor(String status) {
    Color? color;

    if (status == 'E')
      color = Colors.grey.shade400;
    else if (status == 'Y')
      color = Colors.green;
    else if (status == 'N') color = Colors.red;

    return color!;
  }

  Widget _buildPanelContainer({Widget? child, double? height, Color? color}) {
    return Container(
        alignment: Alignment.center,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(horizontal: 10),
        height: height ?? 34,
        width: 60,
        decoration: BoxDecoration(color: color ?? Colors.grey.shade400, borderRadius: BorderRadius.circular(12)),
        child: child);
  }
}

