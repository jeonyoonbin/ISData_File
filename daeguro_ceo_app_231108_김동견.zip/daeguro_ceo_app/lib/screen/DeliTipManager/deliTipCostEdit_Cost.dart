import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipAmtEditModel.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipAmtListModel.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipSectorEditModel.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/delitipController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class DeliTipCost_CostEdit extends StatefulWidget {
  final String? jobGbn;
  final List<DeliTipAmtListModel>? sData;


  const DeliTipCost_CostEdit({Key? key, this.jobGbn, this.sData}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return DeliTipCost_CostEditState();
  }
}

class DeliTipCost_CostEditState extends State<DeliTipCost_CostEdit> {

  List<DeliTipAmtListModel> formData = <DeliTipAmtListModel>[];

  String? sendValiText;

  requestAPIData() async {
    setState(() {});
  }

  requestAPI_SetData(DeliTipAmtEditModel sendData) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(DeliTipController.to.setShopTipAmt(sendData.toJson()))
    );

    if (value == null) {
      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
    }
    else {
      if (value == '00') {
        Navigator.of(context).pop(true);
      }
      else{
        ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
    widget.sData?.clear();
    formData.clear();

    Get.put(DeliTipController()).deliTipError?.value = '';
  }

  @override
  void initState() {
    super.initState();

    Get.put(DeliTipController());

    formData = widget.sData!;

    if (widget.jobGbn == '1') {

    }
    else{
    }

    WidgetsBinding.instance.addPostFrameCallback((c) {

    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 420.0, maxHeight: 600),
        contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            Text(widget.jobGbn == '1' ? '주문 금액별 배달팁 추가' : '주문 시간대별 배달팁 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Material(
            color: Colors.transparent,
            borderOnForeground: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: ISLabelBarSub(
                title: '주문 금액별 배달팁',
                bodyPadding: const EdgeInsets.all(0.0),
                body: Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                      child: DataTable(
                        headingRowHeight: 34,
                        dataRowHeight: 50.0,
                        columnSpacing: 0.0,
                        columns: const [
                          DataColumn(label: SizedBox(width: 160, child: Text('주문 금액', textAlign: TextAlign.center))),
                          DataColumn(label: SizedBox(width: 140,child: Text('배달팁', textAlign: TextAlign.center))),
                          DataColumn(label: SizedBox(width: 40, child: Text('', textAlign: TextAlign.center))),
                        ],
                        rows: formData.map((item){
                          return DataRow(
                              cells: [
                                DataCell(Align(alignment: Alignment.center,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        ISInput(
                                          context: context,
                                          value: Utils.getCashComma(item.tipFrStand!),
                                          textAlign: TextAlign.end,
                                          width: 80,
                                          label: '주문 금액',
                                          keyboardType: TextInputType.number,
                                          inputFormatters: [
                                            FilteringTextInputFormatter.digitsOnly,
                                            TextInputFormatter.withFunction(
                                                  (oldValue, newValue) {
                                                if (newValue.text.isEmpty) {
                                                  return newValue;
                                                }
                                                try {
                                                  final parsedValue = int.parse(newValue.text);
                                                  if (parsedValue <= 100000) {
                                                    final formattedValue = Utils.getCashComma(parsedValue.toString());

                                                    // 커서 위치 계산
                                                    final cursorPosition = newValue.selection.baseOffset;
                                                    final newCursorPosition = cursorPosition + (formattedValue.length - newValue.text.length);

                                                    return TextEditingValue(
                                                      text: formattedValue,
                                                      selection: TextSelection.collapsed(offset: newCursorPosition),
                                                    );
                                                  }
                                                } catch (_) {}
                                                return oldValue;
                                              },
                                            ),
                                          ],
                                          onChange: (v) {
                                              item.tipFrStand = v.toString().replaceAll(',', '');
                                          },
                                        ),
                                        const SizedBox(width: 6,),
                                        const Text('원 이상')
                                      ],
                                    )
                                )
                                ),
                                DataCell(Align(alignment: Alignment.center,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        ISInput(
                                          context: context,
                                          value: Utils.getCashComma(item.tipAmt!),
                                          textAlign: TextAlign.end,
                                          width: 80,
                                          label: '배달팁',
                                          // keyboardType: TextInputType.number,
                                          // inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          keyboardType: TextInputType.number,
                                          inputFormatters: [
                                            FilteringTextInputFormatter.digitsOnly,
                                            TextInputFormatter.withFunction(
                                                  (oldValue, newValue) {
                                                if (newValue.text.isEmpty) {
                                                  return newValue;
                                                }
                                                try {
                                                  final parsedValue = int.parse(newValue.text);
                                                  if (parsedValue <= 999900) {
                                                    final formattedValue = Utils.getCashComma(parsedValue.toString());

                                                    // 커서 위치 계산
                                                    final cursorPosition = newValue.selection.baseOffset;
                                                    final newCursorPosition = cursorPosition + (formattedValue.length - newValue.text.length);

                                                    return TextEditingValue(
                                                      text: formattedValue,
                                                      selection: TextSelection.collapsed(offset: newCursorPosition),
                                                    );
                                                  }
                                                } catch (_) {}
                                                return oldValue;
                                              },
                                            ),
                                          ],
                                          onChange: (v) {
                                              item.tipAmt = v.toString().replaceAll(',', '');

                                              try{
                                                if(int.parse(v!.toString().replaceAll(',', '')) % 100 != 0){
                                                  Get.put(DeliTipController()).deliTipError?.value = '100원 단위 이상의 금액만 입력 가능합니다.' ;
                                                }
                                                else{
                                                  Get.put(DeliTipController()).deliTipError?.value = '';
                                                }
                                              }
                                              catch(_){
                                                Get.put(DeliTipController()).deliTipError?.value = '';
                                              }
                                          },
                                          validator: (v){
                                            return sendValiText;
                                          },
                                        ),
                                        const SizedBox(width: 6,),
                                        const Text('원')
                                      ],
                                    )
                                )
                                ),
                                DataCell(
                                    Align(
                                        alignment: Alignment.center,
                                        child: item.jobGbn == 'I' ? InkWell(
                                          child: const Icon(Icons.cancel, color: Color(0xff01CAFF), size: 21),
                                          onTap: (){
                                            formData.remove(item);
                                            setState(() {

                                            });
                                          },
                                        ) : const SizedBox.shrink()
                                    )
                                ),
                              ]
                          );
                        }).toList(),
                      ),
                    ),
                    ),
                    Obx(() {
                      if(Get.find<DeliTipController>().deliTipError!.value != ''){
                        sendValiText = Get.find<DeliTipController>().deliTipError!.value;
                        return Text(sendValiText!, style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: Colors.redAccent));
                      }
                      else {
                        sendValiText = null;
                        return Container();
                      }
                    }),
                  ],
                ),
                trailing: ISButton(
                  child: const Text('항목 추가'),
                  onPressed: () {
                    DeliTipAmtListModel addData = DeliTipAmtListModel();
                    addData.jobGbn = 'I';
                    addData.tipDay = '1';
                    addData.tipGbn = '3';
                    addData.tipToStand = '0';

                    formData.add(addData);// ShopDeliTipCostModel());

                    formData.forEach((element) {
                    });

                    setState(() {

                    });
                  },
                ),
              ),
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () async {
                formData.forEach((element) {
                });

                int ret = formData.indexWhere((element) => (element.tipFrStand == '' || element.tipFrStand == '0'));
                if (ret != -1){
                  ISAlert(context, content: '주문 금액을 입력해 주세요.');
                  return;
                }

                ret = formData.indexWhere((element) => (element.tipAmt == '' || element.tipAmt == '0'));
                if (ret != -1){
                  ISAlert(context, content: '배달팁을 입력해 주세요.');
                  return;
                }else if (sendValiText != null){
                  ISAlert(context, content: '올바른 배달팁을 입력해 주세요.');
                  return;
                }

                DeliTipAmtEditModel sendData = DeliTipAmtEditModel();
                sendData.shopCd = AuthService.SHOPCD;

                List<String> sendjobGbn = [];
                List<String> sendtipSeq = [];
                List<String> sendtipGbn= [];
                List<String> sendtipDay = [];
                List<String> sendtipFrStand = [];
                List<String> sendtipToStand = [];
                List<String> sendtipAmt = [];

                formData.forEach((element) {
                  sendjobGbn.add(element.jobGbn!);
                  sendtipSeq.add(element.tipSeq!);
                  sendtipGbn.add(element.tipGbn!);
                  sendtipDay.add(element.tipDay!);
                  sendtipFrStand.add(element.tipFrStand!);
                  sendtipToStand.add(element.tipToStand!);
                  sendtipAmt.add(element.tipAmt!);
                });

                sendData.jobGbn = sendjobGbn;
                sendData.tipSeq = sendtipSeq;
                sendData.tipGbn = sendtipGbn;
                sendData.tipDay = sendtipDay;
                sendData.tipFrStand = sendtipFrStand;
                sendData.tipToStand = sendtipToStand;
                sendData.tipAmt = sendtipAmt;

                sendData.uCode = AuthService.uCode;
                sendData.uName = AuthService.uName;

                requestAPI_SetData(sendData);
              },
              child: Text(widget.jobGbn == '1' ? '저장' : '적용', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }
}


