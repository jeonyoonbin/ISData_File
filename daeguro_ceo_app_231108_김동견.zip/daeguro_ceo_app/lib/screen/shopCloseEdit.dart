import 'dart:convert';

import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;

import '../common/constant.dart';
import '../config/auth_service.dart';
import '../iswidgets/is_progressDialog.dart';
import '../models/RequestManager/requestShopInfoEditModel.dart';
import '../theme.dart';
import 'RequestManager/requestManagerController.dart';

class ShopCloseEdit extends StatefulWidget {
  const ShopCloseEdit({super.key});

  @override
  State<ShopCloseEdit> createState() => _ShopCloseEditState();
}

class _ShopCloseEditState extends State<ShopCloseEdit> {

  final ScrollController _scrollController = ScrollController();

  List<PickedFile>? imageFileList = <PickedFile>[];

  String? inputTextData;

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }

  @override
  void initState() {
    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 480.0, maxHeight: 800),
      contentPadding: const EdgeInsets.all(0.0),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text('입점 해지 요청', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                const SizedBox(height: 12,),
                Text(imageFileList!.isEmpty ? '첨부 서류' : '첨부 서류(총 ${imageFileList!.length}개)', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                if (imageFileList!.isNotEmpty)...[
                  const SizedBox(height: 8),
                  SizedBox(
                    height: 120,
                    child: Scrollbar(
                      //isAlwaysShown: true,
                      thumbVisibility: true,
                      trackVisibility: true,
                      controller: _scrollController,
                      radius: const Radius.circular(0.0),
                      showTrackOnHover: true,
                      thickness: 8,
                      child: ListView.builder(
                          controller: _scrollController,
                          itemCount: imageFileList!.length,
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (context, idx) {
                            return Stack(
                              alignment: AlignmentDirectional.topEnd,
                              children: [
                                (imageFileList![idx] == null) ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                    : Padding(
                                  padding: const EdgeInsets.fromLTRB(4, 0, 4, 20),//symmetric(horizontal: 4, vertical: 20),
                                  child: Image.network(imageFileList![idx].path, fit: BoxFit.cover, gaplessPlayback: true, width: 100, height: 100,
                                    loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                      if (loadingProgress == null) return child;
                                      return const Center(
                                        child: CircularProgressIndicator(
                                          valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                        ),
                                      );
                                    },
                                    errorBuilder: (context, error, stackTrace) {
                                      return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                                    },
                                  ),
                                ),
                                Positioned(
                                  top: 2,
                                  right: 6,
                                  child: InkWell(
                                    child: const Image(image: AssetImage('images/image_remove_small.png'), width: 20, height: 20,),
                                    onTap: () {
                                      imageFileList!.removeAt(idx);

                                      setState(() {

                                      });
                                    },
                                  ),
                                )
                              ],
                            );
                          }),
                    ),
                  ),
                ],
                Container(
                  constraints: const BoxConstraints(minWidth: 210),
                  width: double.infinity,
                  alignment: Alignment.center,
                  margin: const EdgeInsets.only(top: 10.0),
                  child: InkWell(
                    child: DottedBorder(padding:const EdgeInsets.only(top: 6, bottom: 6,),
                      color: const Color(0xffDDDDDD),
                      strokeWidth: 1,
                      radius: const Radius.circular(10.0),
                      child: const ClipRRect(borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        child: Row(
                          mainAxisAlignment:MainAxisAlignment.center,
                          children: [
                            Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                            SizedBox(width: 8,),
                            Text('이미지 파일 선택', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, color: Color(0xff999999),),),
                          ],
                        ),
                      ),
                    ),
                    onTap: () async {
                      // 이미지 등록
                      ImagePicker imagePicker = ImagePicker();
                      Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                      imageFile.then((file) async {
                        imageFileList!.add(file!);

                        setState(() {

                        });
                      });
                    },
                  ),
                ),
                const SizedBox(height: 12,),
                Container(
                  //width: MediaQuery.of(context).size.width - 500,//double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  decoration: const BoxDecoration(
                      color: Color.fromARGB(255, 240, 240, 240),
                      borderRadius: BorderRadius.all(Radius.circular(10))),
                  // height: 35,
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('해지 요청 시 첨부 서류 : 영업신고증(대체 서류 : 마스킹 처리된 신분증)', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                      SizedBox(height: 8,),
                      Text('※ 마스킹 처리된 신분증 ex)', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                      SizedBox(height: 8,),
                      Align(alignment: Alignment.center, child: Image(image: AssetImage('images/invalid-name@2x.png'), fit: BoxFit.cover, height: 80,)),
                      SizedBox(height: 8,),
                      Text('· 내용을 충분히 확인할 수 있도록 선명하게 촬영된 이미지를 첨부 부탁드리며 정보 확인이 어려울 경우 승인이 지연될 수 있다는 점 양해 바랍니다.', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                      Text('· 로고, 첨부 서류 이미지는 5MB 이하, JPG/PNG 파일만 올릴 수 있습니다.', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                    ],
                  ),
                ),
                const SizedBox(height: 12,),

                Column(
                  children: [
                    Text('사유', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                    const SizedBox(height: 8),
                    ISInput(
                      height: 150,
                      keyboardType: TextInputType.multiline,
                      maxLines: 8,
                      value: '',
                      context: context,
                      maxLength: 2000,
                      onChange: (v) {
                        if(v.length <= 2000) {
                          inputTextData = v.toString();
                        }
                      },
                    ),
                    const SizedBox(height: 16),
                  ],
                ),

              ],

            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if(inputTextData == null || inputTextData == ''){
                ISAlert(context, content: '해지 사유를 입력해 주세요.' );
                return;
              }else if (imageFileList == null || imageFileList!.isEmpty){
                ISAlert(context, content: '선택된 이미지가 없습니다.\n이미지를 선택해 주세요.');
                return;
              }

              BuildContext dialogContext = context;

              ISConfirm(context, '입점 해지 요청', '입점 해지를 신청하시겠습니까?', constraints: BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async{
                Navigator.of(context).pop();
                if(isOK){
                  RequestShopInfoEditModel sendData = RequestShopInfoEditModel();

                  sendData.serviceGbn = '400';
                  sendData.reason = inputTextData;
                  sendData.shopCd = AuthService.SHOPCD;
                  sendData.status = '10';
                  sendData.uCode = AuthService.uCode;
                  sendData.uName = AuthService.uName;

                  await showDialog(
                      context: context,
                      barrierColor: Colors.transparent,
                      builder: (context) => FutureProgressDialog(RequestController.to.setRequireMultiImageService(sendData, imageFileList!))
                  ).then((value) async {
                    if (value == null) {
                      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                    }
                    else {
                      http.Response.fromStream(value).asStream().listen((event) {
                        if (event.statusCode == 200) {
                          var result = jsonDecode(event.body);

                          String code = result['code'].toString();
                          String msg = result['msg'].toString();

                          if (code == '00'){
                            Navigator.of(dialogContext).pop(true);
                          }
                          else{
                            ISAlert(dialogContext, content: '정상 처리가 되지 않았습니다.\n→ ${msg} ');
                          }
                        }
                        else{
                          Navigator.of(dialogContext).pop(true);
                        }
                      });
                    }
                  });
                }
              });

            },
            child: const Text('해지요청', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}
