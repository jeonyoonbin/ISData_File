import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class LoginLinkToModel {
  LoginLinkToModel();

  String? jobGbn;
  String? mappType;
  String? mappGbn;
  String? mappCode;

  factory LoginLinkToModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

LoginLinkToModel _$ModelFromJson(Map<String, dynamic> json) {
  return LoginLinkToModel()
    ..jobGbn = json['jobGbn'] as String
    ..mappType = json['mappType'] as String
    ..mappGbn = json['mappGbn'] as String
    ..mappCode = json['mappCode'] as String;
}

Map<String, dynamic> _$ModelToJson(LoginLinkToModel instance) => <String, dynamic>{
  'jobGbn': instance.jobGbn,
  'mappType': instance.mappType,
  'mappGbn': instance.mappGbn,
  'mappCode': instance.mappCode
};