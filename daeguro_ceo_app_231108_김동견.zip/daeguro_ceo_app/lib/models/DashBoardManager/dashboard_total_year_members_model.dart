class DashboardTotalYearMembersModel {
  DashboardTotalYearMembersModel();

  String? year = '';
  int? count = 0;
}
