class DashboardTodayCountModel {
  int? TOTAL_MEMBER = 0;
  int? TODAY_APP_INSTALL = 0;
  int? TODAY_MEMBER = 0;
  int? TODAY_ORDER = 0;
  int? TODAY_SHOP_CONFIRM = 0;
  int? TODAY_COMPLETE_COUNT = 0;
  int? RESER_INS = 0;
  int? RESER_SHOP_CONFIRM = 0;
  int? TODAY_RESER = 0;
  int? RESER_COMPLETE_COUNT = 0;

  DashboardTodayCountModel({
    this.TOTAL_MEMBER,
    this.TODAY_APP_INSTALL,
    this.TODAY_MEMBER,
    this.TODAY_ORDER,
    this.TODAY_SHOP_CONFIRM,
    this.TODAY_COMPLETE_COUNT,
    this.RESER_INS,
    this.RESER_SHOP_CONFIRM,
    this.TODAY_RESER,
    this.RESER_COMPLETE_COUNT,
  });

  DashboardTodayCountModel.fromJson(Map<String, dynamic> json) {
    TOTAL_MEMBER = json['TOTAL_MEMBER'];
    TODAY_APP_INSTALL = json['TODAY_APP_INSTALL'];
    TODAY_MEMBER = json['TODAY_MEMBER'];
    TODAY_ORDER = json['TODAY_ORDER'];
    TODAY_SHOP_CONFIRM = json['TODAY_SHOP_CONFIRM'];
    TODAY_COMPLETE_COUNT = json['TODAY_COMPLETE_COUNT'];
    RESER_INS = json['RESER_INS'];
    RESER_SHOP_CONFIRM = json['RESER_SHOP_CONFIRM'];
    TODAY_RESER = json['TODAY_RESER'];
    RESER_COMPLETE_COUNT = json['RESER_COMPLETE_COUNT'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['TOTAL_MEMBER'] = TOTAL_MEMBER;
    data['TODAY_APP_INSTALL'] = TODAY_APP_INSTALL;
    data['TODAY_MEMBER'] = TODAY_MEMBER;
    data['TODAY_ORDER'] = TODAY_ORDER;
    data['TODAY_SHOP_CONFIRM'] = TODAY_SHOP_CONFIRM;
    data['TODAY_COMPLETE_COUNT'] = TODAY_COMPLETE_COUNT;
    data['RESER_INS'] = RESER_INS;
    data['RESER_SHOP_CONFIRM'] = RESER_SHOP_CONFIRM;
    data['TODAY_RESER'] = TODAY_RESER;
    data['RESER_COMPLETE_COUNT'] = RESER_COMPLETE_COUNT;
    return data;
  }
}

class DashboardTodayCountModelData {
  final List<DashboardTodayCountModel> list;

  DashboardTodayCountModelData({
    required this.list,
  });

  factory DashboardTodayCountModelData.fromJson(List<dynamic> parsedJson) {
    List<DashboardTodayCountModel> list;
    list = parsedJson.map((e) => DashboardTodayCountModel.fromJson(e)).toList();
    return DashboardTodayCountModelData(list: list);
  }
}
