import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class SoldOutMenuListModel {
  SoldOutMenuListModel();

  bool? selected = false;
  String? code;
  String? name;
  String? cost;
  String? useGbn;
  String? noFlag;
  String? mainYn;
  String? ribbonCardYn;

  String? adultOnly;
  String? singleOrderYn; 
}