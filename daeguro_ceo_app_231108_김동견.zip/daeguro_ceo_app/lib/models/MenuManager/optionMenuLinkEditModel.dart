import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionMenuLinkEditModel {
  OptionMenuLinkEditModel();

  bool selected = false;
  String? shopCd;
  String? optGrpCd;
  List<String>? menuCd;

  factory OptionMenuLinkEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

OptionMenuLinkEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return OptionMenuLinkEditModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd'] as String
    ..optGrpCd = json['optGrpCd'] as String
    ..menuCd = json['menuCd'].cast<String>();
}

Map<String, dynamic> _$ModelToJson(OptionMenuLinkEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'optGrpCd': instance.optGrpCd,
      'menuCd': instance.menuCd
    };
