import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class LinkToModel {
  LinkToModel();

  String? mapp;
  String? code;
  String? job_name;
  String? uname;
  String? type;
  String? date;

  factory LinkToModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

LinkToModel _$ModelFromJson(Map<String, dynamic> json) {
  return LinkToModel()
  // ..selected = json['selected'] as bool
    ..mapp = json['mapp']
    ..code = json['code']
    ..job_name = json['job_name']
    ..uname = json['uname']
    ..type = json['type']
    ..date = json['date'];
}

Map<String, dynamic> _$ModelToJson(LinkToModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'mapp': instance.mapp,
      'code': instance.code,
      'job_name': instance.job_name,
      'uname': instance.uname,
      'type': instance.type,
      'date': instance.date
    };
