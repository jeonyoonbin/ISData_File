import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class LiveEventInfoEditModel {
  LiveEventInfoEditModel();

  bool selected = false;
  String? jobGbn;
  String? div;
  String? shopCd;
  String? eventTitle;
  String? frTime;
  String? toTime;
  String? uName;
  List<String>? code;
  List<String>? eventAmtGbn;
  List<String>? eventAmt;

  factory LiveEventInfoEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

LiveEventInfoEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return LiveEventInfoEditModel()
  // ..selected = json['selected'] as bool
    ..jobGbn = json['jobGbn']
    ..div = json['div']
    ..shopCd = json['shopCd']
    ..eventTitle = json['eventTitle']
    ..frTime = json['frTime']
    ..toTime = json['toTime']
    ..uName = json['uName']
    ..code = json['code'].cast<String>()
    ..eventAmtGbn = json['eventAmtGbn'].cast<String>()
    ..eventAmt = json['eventAmt'].cast<String>();
}

Map<String, dynamic> _$ModelToJson(LiveEventInfoEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'jobGbn': instance.jobGbn,
      'div': instance.div,
      'shopCd': instance.shopCd,
      'eventTitle': instance.eventTitle,
      'frTime': instance.frTime,
      'toTime': instance.toTime,
      'uName': instance.uName,
      'code': instance.code,
      'eventAmtGbn': instance.eventAmtGbn,
      'eventAmt': instance.eventAmt
    };
