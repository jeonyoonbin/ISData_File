class PackingDiscountModel {
  String? gkfdlsrmador = '5000';
  String? chlthwnansrmador = '12000';
  String? vhwkdgkfdlschlthwjrdydrmador = '10000';
}
