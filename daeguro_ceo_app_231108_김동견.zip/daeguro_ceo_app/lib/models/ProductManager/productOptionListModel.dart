import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOptionListModel {
  ProductOptionListModel();

  bool selected = false;

  String? optionCd;
  String? optName;
  String? optSortSeq;
  String? optCost;
  String? useGbn;
  String? optNoFlag;
  String? optionMemo;
}


