
import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductGroupEditModel{

  ProductGroupEditModel();

  String? shopCd;
  String? grpCode;
  String? grpName;
  String? grpMemo;
  String? useYn;
  String? uCode;
  String? uName;

  factory ProductGroupEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ProductGroupEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ProductGroupEditModel()
    ..shopCd = json['shopCd']
    ..grpCode = json['grpCode']
    ..grpName = json['grpName']
    ..grpMemo = json['grpMemo']
    ..useYn = json['useYn']
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(ProductGroupEditModel instance) =>
    <String, dynamic>{
      'shopCd': instance.shopCd,
      'grpCode': instance.grpCode,
      'grpName': instance.grpName,
      'grpMemo': instance.grpMemo,
      'useYn': instance.useYn,
      'uCode': instance.uCode,
      'uName': instance.uName
    };