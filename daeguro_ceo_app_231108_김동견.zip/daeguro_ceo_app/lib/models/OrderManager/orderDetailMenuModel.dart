import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OrderDetailMenuModel {
  OrderDetailMenuModel();

  bool? selected = false;
  String? menuCode;
  double? cost;
  int? menuCost;
  int? saleCost;
  int? count;
  String? menuName;
  String? eventYn;
  String? discMenuGbn;
  String? orderUnitOptions;
  String? dataGbn;
}