import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OrderDetailModel {
  OrderDetailModel();

  bool? selected = false;
  String? orderNo = '';
  String? shopName = '';
  String? status = '';
  String? cancelReason = '';
  String? menuName = '';
  String? menuAmt = '';
  String? orderAmtTip = '';
  String? couponAmt = '';
  String? amount = '';
  String? orderTime = '';
  // String? shopDongAddr = '';
  // String? shopRoadAddr = '';
  // String? shopAddrDetail = '';
  // String? lon = '';
  // String? lat = '';
  String? custDongAddr = '';
  String? custRoadAddr = '';
  String? custAddrDetail = '';
  String? packOrderYn = '';
  String? appPayGbn = '';
  String? payGbn = '';
  String? riderDeliMemo = '';
  String? shopDeliMemo = '';
  String? myNumber = '';
  String? mileageUseAmt = '';
  String? happyDiscAmt = '';
  String? deliTipDiscAmt = '';
  String? toGoDiscAmt = '';
  String? menuDesc = '';
  // String? custLon = '';
  // String? custLat = '';
  String? shopCouponAmt = '';

  // 꽃배달 주문상세 사용 데이터
  String? reserDate = '';
  String? senderName = '';
  String? senderTelno = '';
  String? receiverName = '';
  String? receiverTelno = '';
  String? custName = '';
  String? telNo = '';
}