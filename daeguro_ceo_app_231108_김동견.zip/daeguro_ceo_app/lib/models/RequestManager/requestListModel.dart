import 'package:daeguro_ceo_app/models/RequestManager/requestServiceDataModel.dart';

class RequestListModel {
  RequestListModel({
    this.seq,
    this.status,
    this.statusName,
    this.serviceGbn,
    this.serviceGbnName,
    this.insertDate,
    this.modDate,
    this.answerText,
    this.serviceData,
    this.fileName,
    this.serviceDesc,
    this.isChild = false,
  });
  bool selected = false;
  bool viewSelected = false;
  bool isChild = false;
  bool isOpened = false;

  String? seq;
  String? status;
  String? statusName;
  String? serviceGbn;
  String? serviceGbnName;
  String? insertDate;
  String? modDate;
  String? answerText;
  String? serviceData;
  String? fileName;

  List<RequestServiceDataModel>? serviceDesc;
}
