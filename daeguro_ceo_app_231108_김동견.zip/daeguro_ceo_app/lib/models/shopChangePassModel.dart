import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopChangePassModel {
  ShopChangePassModel();

  String? shopCd;
  String? mCode;
  String? id;
  String? current;
  String? password;
  String? password_confirm;
  String? mallYn;
  String? uCode;
  String? uName;

  factory ShopChangePassModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopChangePassModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopChangePassModel()
    ..shopCd = json['shopCd'] as String
    ..mCode = json['mCode'] as String
    ..id = json['id'] as String
    ..current = json['current'] as String
    ..password = json['password'] as String
    ..password_confirm = json['password_confirm'] as String
    ..mallYn = json['mallYn'] as String
    ..uCode = json['uCode'] as String
    ..uName = json['uName'] as String;

}

Map<String, dynamic> _$ModelToJson(ShopChangePassModel instance) => <String, dynamic>{
  'shopCd': instance.shopCd,
  'mCode': instance.mCode,
  'id': instance.id,
  'current': instance.current,
  'password': instance.password,
  'password_confirm': instance.password_confirm,
  'mallYn': instance.mallYn,
  'uCode': instance.uCode,
  'uName': instance.uName,
};