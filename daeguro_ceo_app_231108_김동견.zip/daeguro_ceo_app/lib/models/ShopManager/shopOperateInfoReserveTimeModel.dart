class ShopOperateInfoReserveTimeModel {
  String? dayGbn = '';
  String? closeGbn = '';
  List<List<dynamic>>? reserTime = <List<dynamic>>[];
}