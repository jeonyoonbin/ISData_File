import 'package:daeguro_ceo_app/screen/ShopManager/shopRegistInfo_main.dart';

class ShopRegistInfoModel {
  String? regNo = '';
  String? bussOwner = '';
  String? bussCon = '';
  String? bussType = '';
  String? bussAddr = '';
  String? bussTaxType = '';
  String? email = '';
}
