import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopOperateInfoReserveModel {
  ShopOperateInfoReserveModel();

  String? useGbn = '';
  String? reserveYn = '';
  String? absentYn = '';
  String? shopFileName = '';
  String? facilities_1 = '';
  String? facilities_2 = '';
  String? facilities_3 = '';
  String? facilities_4 = '';
  String? facilities_5 = '';
  String? facilities_6 = '';
  String? facilities_7 = '';
  String? facilities_8 = '';
  String? facilities_9 = '';
  String? facilities_10 = '';
  String? reviewUseGbn = '';
  List<dynamic>? sbTimeLists = [];
}