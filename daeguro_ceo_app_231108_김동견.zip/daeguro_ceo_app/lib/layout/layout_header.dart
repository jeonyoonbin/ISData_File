import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_controller.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:url_launcher/url_launcher.dart';

class LayoutHeader extends StatefulWidget {
  final String? titleName;

  const LayoutHeader({Key? key, this.titleName}) : super(key: key);

  @override
  _LayoutHeaderState createState() => _LayoutHeaderState();
}

class _LayoutHeaderState extends State<LayoutHeader> {
  int _current = 0;
  final CarouselController _controller = CarouselController();
  late List<String> imgList = [];
  late List<Widget> imageSliders;

  refresh() {
    setState(() {

    });
  }

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) async {
      // imgList = ShopUseState.bannerImageList!;
      // setState(() {
      //   imgList.forEach((element) {
      //   });
      // });
    });
  }

  @override
  Widget build(BuildContext context) {
    //final appTheme = context.watch<AppTheme>();
    //final List<String> imgList = ['assets/954.jpg','assets/956.jpg','assets/1097.jpg','assets/1168.jpg'];

    if (AuthService.bannerImageList == null){
      return const fluentUI.PageHeader(
          title: SizedBox(width: double.infinity, height: 100,)
          );
    }
    else{
      imageSliders = AuthService.bannerImageList!.asMap().map((index, item) =>
          MapEntry(
            index,
            MouseRegion(
              cursor: AuthService.urlList![index] != null && AuthService.urlList![index] != '' ? SystemMouseCursors.click : MouseCursor.defer,
              child: GestureDetector(
                onTap: () async {
                  if (await canLaunch(AuthService.urlList![index])) {
                    await launch(
                      AuthService.urlList![index],
                    );
                  }
                },
                child: Image.network(
                  item,
                  fit: BoxFit.fitWidth,
                  loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                    if (loadingProgress == null) return child;
                    return const Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                      ),
                    );
                  },
                ),
              ),
            ),
          )
      ).values.toList();
    }

    return fluentUI.PageHeader(
      title: Wrap(
          alignment: WrapAlignment.center,
          spacing: 10.0,
          children: [
            Container(
              alignment: Alignment.center,
              child: Stack(
                  children: <Widget>[
                    CarouselSlider(
                      items: imageSliders,
                      carouselController: _controller,
                      options: CarouselOptions(
                          initialPage: AuthService.timeOutCounter >= 3599 ? -1 : 0,
                          height: Responsive.isMobile(context) ? 80 : 100,
                          autoPlayInterval: const Duration(seconds: 3),
                          autoPlayAnimationDuration: const Duration(milliseconds: 800),
                          autoPlayCurve: Curves.fastOutSlowIn,
                          autoPlay: true,
                          enlargeCenterPage: false,
                          viewportFraction: 1.0,
                          enlargeStrategy: CenterPageEnlargeStrategy.zoom,
                          onPageChanged: (index, reason) {
                            setState(() {
                              _current = index;
                            });
                          }
                      ),
                    ),
                    Positioned(
                      bottom: 0.0,
                      left: 0.0,
                      right: 0.0,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: AuthService.bannerImageList!.asMap().entries.map((entry) {
                          return MouseRegion(
                            cursor: SystemMouseCursors.click,
                            child: GestureDetector(
                              onTap: () => _controller.animateToPage(entry.key),
                              child: Container(
                                width: Responsive.isMobile(context) ? 8.0 : 12.0,
                                height:Responsive.isMobile(context) ? 8.0 : 12.0,
                                margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: (const Color.fromARGB(0, 0, 0, 0)).withOpacity(_current == entry.key ? 0.9 : 0.4)//(Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black).withOpacity(_current == entry.key ? 0.9 : 0.4)
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ]
              ),
            ),
            //SizedBox(height: Responsive.isMobile(context) ? 0.0 : 0.0),
          ]
      ),
    );
  }}