import 'dart:async';

import 'package:daeguro_ceo_app/models/Common/linkToModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/LogInManager/loginController.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';

// 로그인 로직
class AuthService extends GetxService {
  static AuthService get to => Get.find();

  static final String SHOPGBN_FOOD = '0';
  //static final String SHOPGBN_SPECIAL = '1';
  static final String SHOPGBN_FLOWER = '2';
  //static final String SHOPGBN_LOCALFOOD = '3';
  static final String SHOPGBN_MARKET = '4';
  static final String SHOPGBN_ELECTMARKET = '5';
  static final String SHOPGBN_MEALKIT = '6';

  static final int SHOPMODE_DELIVERY = 0;
  static final int SHOPMODE_RESERVE = 1;

  final userStorage = const FlutterSecureStorage();

  final userId = ''.obs;

  final isLoggedIn = false.obs;
  bool get isLoggedInValue => isLoggedIn.value;

  static Timer? timer;
  static Timer? counter;

  static const autoLogoutTimer = 3599;//19;//
  static var timeOutCounter = 3599;//10;//

  static int ShopMode = SHOPMODE_DELIVERY;

  static String SHOPID = '';//GetStorage().read('logininfo')['uCode'];
  static String SHOPCD = '';//'1';//;
  static String SHOPNAME = '';//'1';//;
  static String? ShopStatus = 'Y'; // Y: 영업 중, N:휴무중
  static String? ShopType = 'Y'; //  3: 현장주문, 5: 배달, 7: 포장, 9: 예약
  static String? ShopServiceGbn = '0'; // 0: 주문, 1: 특별관, 2: 꽃배달, 3: 로컬푸드, 4: 전통시장, 5: 전자관, 6: 밀키트
  static String? OldShopServiceGbn;
  static String? GoodShopYn = 'N'; //  착한매장
  static String? MallUseGbn = 'N'; //  쇼핑몰사용유무
  static String? apiComCode = ''; //

  static String? TradShopMainYn = ''; //  장바구니 사용유무
  static String? BundleYn = 'N'; // 장바구니 시장대표 매장유무

  static String mCode = '';//GetStorage().read('logininfo')['uCode'];
  static String uCode = SHOPCD;//GetStorage().read('logininfo')['uCode'];
  static String uName = SHOPNAME;//GetStorage().read('logininfo')['name'];

  static String MultiShopYn = ''; //멀티샵 여부
  static String MultiShopCd = ''; //멀티샵 코드
  static String RepYn = ''; //대표상점 여부 여부

  static String Token = '';

  //static int initTabIndex_Account = 0;

  static List<String>? bannerImageList = [];
  static List<String>? urlList = [];

  static LinkToModel? linkToModel;

  static String initLocation = '/login';

  // 로그인
  void login(uid, token) async {
    userId.value = uid;
    await userStorage.write(key: '@user_token', value: token);
    isLoggedIn.value = true;
    startNewTimer();
    //Get.offAllNamed('/');

    //router.pushNamed('home');
  }

  // 로그아웃
  void logout() async {
    stopTimer();
    userId.value = '';
    await userStorage.delete(key: '@user_token');
    isLoggedIn.value = false;

    SHOPCD = '';
    SHOPNAME = '';
    ShopStatus = '';
    ShopServiceGbn = '';
    ShopType = '';
    MultiShopYn = '';
    MultiShopCd = '';
    RepYn = '';
    GoodShopYn = '';
    MallUseGbn =  '';
    apiComCode = '';

    userStorage.read(key: '@saveID').then((value) {
      if (value == null) {
        LoginController.to.loginID = '';
      }
      else {
        LoginController.to.loginID = value.toString();
      }
    });

    // userStorage.read(key: '@saveID').then((value) {
    //   if (value != null) {
    //     idTextController.text = value;
    //     loginID = value;
    //     isIdSaved = true;
    //     update();
    //   }
    //   else {
    //     idTextController.text = '';
    //     loginID = '';
    //     isIdSaved = false;
    //     update();
    //   }
    // });

    //Get.offAllNamed('/login');
    router.go('/login');
  }

  // reset or start timer
  void startNewTimer() {
    stopTimer();
    if (isLoggedInValue) {
      timer = Timer.periodic(Duration(seconds: timeOutCounter), (timer) {
        timeOut();
      });
      counter = Timer.periodic(const Duration(seconds: 1), (timer) {
        timeOutCounter = timeOutCounter - 1;
      });
    }
  }

  // stop timer
  void stopTimer() {
    if (timer != null || (timer?.isActive != null && timer!.isActive)) {
      timer?.cancel();
      counter?.cancel();
      timeOutCounter = 3599;
    }
  }

  // 자동로그아웃
  Future<void> timeOut() async {
    stopTimer();
    if (isLoggedInValue) {
      logout();
    }
  }
}
