import 'package:flutter/material.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;

class ISTier extends StatelessWidget {

  final String name;
  final String price;
  //final int? benifitsColorIndex;
  //final Color? benifitsColor;
  final List<String> benefits;

  const ISTier({
    Key? key,
    required this.name,
    required this.price,
    //this.benifitsColorIndex,
    //this.benifitsColor,
    required this.benefits,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = fluentUI.FluentTheme.of(context);

    int index = 0;

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Text(name, style: theme.typography.bodyLarge?.copyWith(fontWeight: FontWeight.bold,),),
        Text(price, style: theme.typography.caption),
        const SizedBox(height: 20.0),
        ...benefits.map((benefit) {
          //debugPrint('index:${index++}');
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsetsDirectional.only(end: 6.0, top: 9.0),
                child: Icon(fluentUI.FluentIcons.circle_fill, size: 4.0),
              ),
              Expanded(child: Text(benefit,/* style: TextStyle(color: (benifitsColorIndex == index) ? benifitsColor : Colors.black)*/)),
            ],
          );
        }),
      ],
    );
  }
}