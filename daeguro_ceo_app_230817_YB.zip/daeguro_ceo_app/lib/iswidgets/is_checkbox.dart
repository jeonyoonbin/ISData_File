import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:flutter/material.dart';

class ISCheckbox extends StatefulWidget {
  final String? label;
  final bool? value;
  final EdgeInsetsGeometry? padding;
  //final TextStyle labelStyle;
  final ValueChanged<bool>? onChanged;
  final FocusNode? focusNode;

  const ISCheckbox({Key? key, this.label, this.value, this.padding, this.onChanged, this.focusNode}) : super(key: key);

  @override
  _ISCheckboxState createState() => _ISCheckboxState();
}

class _ISCheckboxState extends State<ISCheckbox> {
  bool? _value;

  @override
  void didUpdateWidget(covariant ISCheckbox oldWidget) {
    _value = widget.value;
    super.didUpdateWidget(oldWidget);
  }

  @override
  void initState() {
    _value = widget.value;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var result = Padding(
      padding: widget.padding ?? EdgeInsets.zero,//only(right: 10),//all(10),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          Checkbox(
            value: _value,
            checkColor: Colors.white,
            activeColor: const Color(0xff01CAFF),
            materialTapTargetSize: MaterialTapTargetSize.padded,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
            onChanged: (v) {
              this._value = v;
              widget.onChanged!(v!);
              setState(() {});
            },
            focusNode: widget.focusNode,
          ),
          Text(widget.label!, style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
        ],
      ),
    );
    return result;
  }
}
