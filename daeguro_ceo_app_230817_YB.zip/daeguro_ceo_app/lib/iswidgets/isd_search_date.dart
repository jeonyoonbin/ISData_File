
import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:flutter/material.dart';

class ISSearchSelectDate extends StatelessWidget {

  final String? value;
  final String? label;
  final double? width;
  final bool? enable;
  final ValueChanged? onChange;
  final FormFieldSetter? onSaved;
  final GestureTapCallback? onTap;

  const ISSearchSelectDate({
    Key? key,
    this.value,
    this.label,
    this.width,
    this.enable,
    this.onChange,
    this.onSaved,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      //padding: const EdgeInsets.fromLTRB(8, 0, 0, 0),
      alignment: Alignment.center,
      width: width ?? 230,
      height: 40,
      child: TextFormField(
        textAlign: TextAlign.center,
        enabled: enable,
        readOnly: true,
        style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY),
        decoration: InputDecoration(
          suffixIcon: const Icon(Icons.calendar_month_outlined, color: Colors.black54),
          isDense: true,
          fillColor: Colors.white,
          filled: true,
          hintText: label,
          hintStyle: const TextStyle(color: Colors.black54, fontSize: 13, fontFamily: FONT_FAMILY),
          //border: const OutlineInputBorder(),
          enabledBorder: const OutlineInputBorder(
            //borderRadius: BorderRadius.all(Radius.circular(12.0)),
            borderSide: BorderSide(color: Colors.black12),
          ),
          focusedBorder: const OutlineInputBorder(
            //borderRadius: BorderRadius.all(Radius.circular(10.0)),
            borderSide: BorderSide(color: Colors.black12, width: 1.4),
          ),
        ),
        controller: TextEditingController(text: value),
        onChanged: (v) {
          if (onChange != null) {
            onChange!(v);
          }
        },
        onTap: onTap,
        onSaved: onSaved,
      ),
    );
  }
}
