enum DateRangeType { last90days, last30days, last7days, last5days, thisMonth, nowDay }

extension DateRangeTypeReturn on DateRangeType {
  String getTitle({
    last90daysTitle,
    last30daysTitle,
    last7daysTitle,
    last5daysTitle,
    thisMonthTitle,
    nowDayTitle,
  }) {
    switch (this) {
      case DateRangeType.last90days:
        return last90daysTitle ?? '3개월';
      case DateRangeType.last30days:
        return last30daysTitle ?? '1개월';
      case DateRangeType.last7days:
        return last7daysTitle ?? '7일';
      case DateRangeType.last5days:
        return last5daysTitle ?? '5일';
      case DateRangeType.thisMonth:
        return thisMonthTitle ?? '이번달';
      case DateRangeType.nowDay:
        return nowDayTitle ?? '오늘';
    }
  }
}
