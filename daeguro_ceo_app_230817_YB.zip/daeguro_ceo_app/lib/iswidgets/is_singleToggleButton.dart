import 'package:flutter/material.dart';

class ISSingleToggleButton extends StatelessWidget {

  final bool? value;
  final Widget? content;
  final double? width;
  final double? height;
  final ValueChanged? onChange;

  const ISSingleToggleButton({Key? key, this.value, this.width, this.height, this.content, this.onChange}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      //color: Colors.transparent,
      width: width ?? 160,
      child: SwitchListTile(
        dense: true,
        value: value!,
        hoverColor: Colors.transparent,
        //tileColor: Colors.transparent,
        title: content, //const Text('휴점중', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY),),
        onChanged: (v) {
          if (onChange != null) {
            onChange!(v);
          }
        },
      ),
    );
  }
}

