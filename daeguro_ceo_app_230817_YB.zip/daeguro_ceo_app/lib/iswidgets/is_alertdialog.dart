import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:flutter/material.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;

void ISAlert(BuildContext context, {String? title, String? content, BoxConstraints? constraints}) {
  showDialog<void>(
    context: context,
    builder: (context) {
      return ContentDialog(
        constraints: constraints ?? const BoxConstraints(maxWidth: 360.0),
        contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),//all(20),
        //isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            Text((title == null) ? '알림' : title, style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY, overflow: TextOverflow.ellipsis)),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(content!, style: const TextStyle(fontSize: 16, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
            ],
          ),
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: ButtonStyle(
                backgroundColor: const MaterialStatePropertyAll(Colors.blueAccent),
                shape: MaterialStatePropertyAll(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0))
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('확인'),
            ),
          ),
        ],
      );
    },
  );
}

void ISConfirm(BuildContext context, String title, String content, onConfirm, {BoxConstraints? constraints}) {
  showDialog<void>(
    context: context,
    builder: (context) {
      return ContentDialog(
        constraints: (constraints == null) ? const BoxConstraints(maxWidth: 360.0, maxHeight: 550) : constraints,
        contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 40),//all(20),
        //isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            Text((title == null) ? '알림' : title, style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY, overflow: TextOverflow.ellipsis)),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: SizedBox(
            width: double.infinity,
            child: Text(content, style: const TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL/*, overflow: TextOverflow.ellipsis*/))),
        actions: [
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              //style: popupButtonStyleLeft,
              style: ButtonStyle(
                backgroundColor: const MaterialStatePropertyAll(Colors.black54),
                shape: MaterialStatePropertyAll(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0))
                ),
              ),
              onPressed: () {
                onConfirm(context, false);
              },
              child: const Text('취소'),
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              //style: popupButtonStyleRight,
              style: ButtonStyle(
                backgroundColor: const MaterialStatePropertyAll(Colors.blueAccent),
                shape: MaterialStatePropertyAll(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0))
                ),
              ),
              onPressed: () {
                onConfirm(context, true);
              },
              child: const Text('확인'),
            ),
          ),
        ],
      );
    },
  );
}

void ISOptionDialog(BuildContext context, BoxConstraints constraints, String title, List<String> values, onConfirm) {
  showDialog<void>(
    context: context,
    builder: (context) {
      return ContentDialog(
        constraints: constraints,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            Flexible(
                child: Text(title, style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY, overflow: TextOverflow.ellipsis))
            ),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          child: Column(
            children: [
              //const Divider(height: 0.0),
              ListView.separated(
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  itemBuilder: (ctx, index) {
                    return SimpleDialogOption(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      onPressed: () {
                        onConfirm(context, index);
                      },
                      child: Text(values[index], textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: (values[index].contains('삭제') == true) ? Colors.red : Colors.black))
                    );
                  },
                  separatorBuilder: (BuildContext context, int index) { return const Divider(thickness: 1, height: 0.0,); },
                  itemCount: values.length
              ),
              // ListView.builder(
              //   shrinkWrap: true,
              //   itemBuilder: (ctx, index) {
              //     return SimpleDialogOption(
              //       onPressed: () {
              //         onConfirm(context, index);
              //       },
              //       child: Center(child: Text(values[index], style: TextStyle(fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: (values[index].contains('삭제') == true) ? Colors.red : Colors.black))),
              //     );
              //   },
              //   itemCount: values.length,
              // ),
              const Divider(height: 0.0),
            ],
          ),
        ),
        actions: null,
      );
    },
  );
}

