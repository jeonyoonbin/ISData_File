import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionListModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductOptionListEdit extends StatefulWidget {
  final ProductOptionListModel? sData;
  final String? optionGrpCd;

  const ProductOptionListEdit({Key? key, this.sData, this.optionGrpCd})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ProductOptionListEditState();
  }
}

enum RadioUseGbn { useGbnY, useGbnN }
enum RadioNoFlagGbn { noflagGbnY, noflagGbnN }

class ProductOptionListEditState extends State<ProductOptionListEdit> {
  ProductOptionEditModel formData = ProductOptionEditModel();

  RadioUseGbn? _radioUseGbn;
  RadioNoFlagGbn? _radioNoFlagGbn;

  @override
  void dispose() {
    super.dispose();
    formData = ProductOptionEditModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    formData.shopCd = AuthService.SHOPCD;
    formData.uCode = AuthService.uCode;
    formData.uName = AuthService.uName;

    if (widget.sData == null){
      formData.optGrpCd = widget.optionGrpCd;
      formData.optionCd = '';
      formData.optName = '';
      formData.optCost = '';
      formData.optUseGbn = 'Y';
      formData.optNoFlag = 'N';
      formData.optionMemo = '';

      _radioUseGbn = RadioUseGbn.useGbnY;
      _radioNoFlagGbn = RadioNoFlagGbn.noflagGbnN;
    }
    else{
      formData.optionCd = widget.sData!.optionCd;
      formData.optName = widget.sData!.optName;
      formData.optCost = widget.sData!.optCost;
      formData.optUseGbn = widget.sData!.useGbn;
      formData.optNoFlag = widget.sData!.optNoFlag;
      formData.optionMemo = widget.sData!.optionMemo;

      _radioUseGbn = formData.optUseGbn == 'Y' ? RadioUseGbn.useGbnY : RadioUseGbn.useGbnN ;
      _radioNoFlagGbn = formData.optNoFlag == 'N' ? RadioNoFlagGbn.noflagGbnY : RadioNoFlagGbn.noflagGbnN;
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 400),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text(widget.sData == null ? '옵션 신규 등록' : '옵션명 및 가격 변경', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            //const Divider(color: Colors.grey, height: 0.0,),
            const SizedBox(height: 16,),
            const Text('옵션명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            const SizedBox(height: 8),
            ISInput(
              autofocus: true,
              value: formData.optName,
              //padding: 0,
              height: 64,
              label: '옵션명',
              maxLength: 25,
              context: context,
              onChange: (v) {
                setState(() {
                  formData.optName = v;
                });
              },
            ),
            const Text('가격', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            const SizedBox(height: 8),
            ISInput(
              textAlign: TextAlign.end,
              suffixText: '원',
              value: formData.optCost == null
                  ? ''
                  : Utils.getCashComma(formData.optCost!),
              // : Utils.getCashComma(formData.cost!) ?? '',
              label: '가격',
              maxLines: 1,
              context: context,
              keyboardType: TextInputType.number,
              inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
              onChange: (v) {
                setState(() {
                  formData.optCost = v.toString().replaceAll(',', '');
                });
              },
              // validator: (v) {
              //   return v.isEmpty ? '[필수] 금액' : null;
              // },
            ),
            const SizedBox(height: 16,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('사용여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                Row(
                  children: [
                    Radio(
                        value: RadioUseGbn.useGbnY,
                        groupValue: _radioUseGbn,
                        onChanged: (v) async {
                          setState(() {
                            _radioUseGbn = v as RadioUseGbn?;

                            formData.optUseGbn = 'Y';
                          });
                        }),
                    const Text('사용', style: TextStyle(fontSize: 12)),
                    const SizedBox(width: 40,),
                    Radio(
                        value: RadioUseGbn.useGbnN,
                        groupValue: _radioUseGbn,
                        onChanged: (v) async {
                          setState(() {
                            _radioUseGbn = v as RadioUseGbn?;

                            formData.optUseGbn = 'N';
                          });
                        }),
                    const Text('미사용', style: TextStyle(fontSize: 12)),
                    const SizedBox(width: 16,)
                  ],
                )

              ],
            ),
            const SizedBox(height: 6,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('품절 여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                Row(
                  children: [
                    Radio(
                        value: RadioNoFlagGbn.noflagGbnY,
                        groupValue: _radioNoFlagGbn,
                        onChanged: (v) async {
                          setState(() {
                            _radioNoFlagGbn = v as RadioNoFlagGbn?;

                            formData.optNoFlag = 'N';
                          });
                        }),
                    const Text('판매중', style: TextStyle(fontSize: 12)),
                    const SizedBox(width: 30,),
                    Radio(
                        value: RadioNoFlagGbn.noflagGbnN,
                        groupValue: _radioNoFlagGbn,
                        onChanged: (v) async {
                          setState(() {
                            _radioNoFlagGbn = v as RadioNoFlagGbn?;

                            formData.optNoFlag = 'Y';
                          });
                        }),
                    const Text('품절', style: TextStyle(fontSize: 12)),
                    const SizedBox(width: 26,),
                  ],
                )
              ],
            ),
          ],
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (formData.optName == '' || formData.optName == null) {
                ISAlert(context, content: '옵션명을 확인해주세요.');
                return;
              }

              if (formData.optCost == '' || formData.optCost == null) {
                ISAlert(context, content: '옵션 금액을 확인해주세요.');
                return;
              }

              ISConfirm(context, widget.sData == null ? '옵션 등록' : '옵션 수정', widget.sData == null ? '신규 옵션 정보를 등록하시겠습니까?' : '옵션 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();
                if (isOK){
                  var value = null;

                  if (widget.sData == null){
                    value = await showDialog(
                        context: context,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(ProductInfoController.to.addProductOption(formData.toJson()))
                    );
                  }
                  else{
                    value = await showDialog(
                        context: context,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(ProductInfoController.to.updateProductOption(formData.toJson()))
                    );
                  }

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: Text(widget.sData == null ? '등록' : '적용', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


