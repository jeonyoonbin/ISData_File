import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:get/get.dart';

class ProductInfoController extends GetxController{
  static ProductInfoController get to => Get.find();

  int catogoryGroupCnt = 0;

  int themeGroupCnt = 0;

  String optionTotalCnt = '';

  String optionMultiCnt = '';
  String optionMinCnt = '';
  String optionProdGrp = '';

  String prodCnt = '';
  String menuCnt = '';

  Future<List<dynamic>?> getTypeList(String jobGbn, String classGbn) async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTTYPELIST}?jobGbn=${jobGbn}&classGbn=${classGbn}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getGroupList(String classGbn, String jobGbn) async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTGROUPLIST}?classGbn=${classGbn}&jobGbn=${jobGbn}');

    if (response.data['code'] == '00') {
      catogoryGroupCnt = int.parse(response.data['catCnt'].toString());
      themeGroupCnt = int.parse(response.data['themCnt'].toString());

      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getProductList(String jobGbn, String code) async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTLIST}?jobGbn=${jobGbn}&code=${code}&shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }


  Future<dynamic> addProduct(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_PRODUCT_ADD, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> setProduct(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_PRODUCT_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> addProductOptionGroup(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_PRODUCTOPTIONGROUP_ADD, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> updateProductOptionGroup(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_PRODUCTOPTIONGROUP_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> deleteProductOptionGroup(String optGrpCd) async {
    final response = await DioClient().put('${ServerInfo.RESTURL_PRODUCTOPTIONGROUP_DEL}?shopCd=${AuthService.SHOPCD}&optGrpCd=${optGrpCd}&uName=${AuthService.uName}&uCode=${AuthService.uCode}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }



  Future<List<dynamic>?> getOptionGroupList() async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTOPTIONGROUPLIST}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      optionTotalCnt = response.data['cnt'].toString();

      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getProductOptionList(String optionGroupCd) async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTOPTIONLIST}?shopCd=${AuthService.SHOPCD}&optGrpCd=${optionGroupCd}');

    if (response.data['code'] == '00') {
      optionMultiCnt = response.data['multiCnt'].toString();
      optionMinCnt = response.data['minCnt'].toString();
      optionProdGrp = response.data['prodGrp'].toString();

      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }



  Future<List<dynamic>?> getProductLinkList(String optionGroupCd) async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTOPTIONGROUPLINKLIST}?shopCd=${AuthService.SHOPCD}&optGrpCd=${optionGroupCd}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateProductLink(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_PRODUCTOPTIONGROUPLINK_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> getProductLegal(String productCd) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTLEGAL}?prodCd=${productCd}&shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getProductBundleLegal(String productCd) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTBUNDLELEGAL}?prodCd=${productCd}&shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getProductOptionLinkList(String productCd) async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTOPTIONLINKLIST}?shopCd=${AuthService.SHOPCD}&prodCd=${productCd}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateProductOptionLink(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_PRODUCTOPTIONLINK_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> deleteProductOptionGroupLink(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_PRODUCTOPTIONGROUPLINK_DELETE, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> addProductOption(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_PRODUCTOPTION_ADD, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> updateProductOption(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_PRODUCTOPTION_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> deleteProductOption(String optCd) async {
    final response = await DioClient().put('${ServerInfo.RESTURL_PRODUCTOPTION_DEL}?shopCd=${AuthService.SHOPCD}&optCd=${optCd}&uName=${AuthService.uName}&uCode=${AuthService.uCode}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> updateProductLegal(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_PRODUCTLEGAL_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> updateProductBundleLegal(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_PRODUCTBUNDLELEGAL_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> setOptioGroupCount(String optionGroupCd, String minCnt, String multiCnt) async {
    final response = await DioClient().put('${ServerInfo.RESTURL_PRODUCTOPTIONGROUPCOUNT_SET}?shopCd=${AuthService.SHOPCD}&optGrpCd=${optionGroupCd}&minCnt=${minCnt}&multiCnt=${multiCnt}&uName=${AuthService.uName}&uCode=${AuthService.uCode}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<List<dynamic>?> getProductSearchList(String keyword) async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTSEARCHLIST}?shopCd=${AuthService.SHOPCD}&keyword=${keyword}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getProductTopMenuList() async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTTOPMENULIST}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> addProductTopMenu(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_PRODUCTTOPMENU_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> removeProductTopMenu(String prodCode) async {
    final response = await DioClient().put(ServerInfo.RESTURL_PRODUCTTOPMENUREMOVE + '?shopCd=${AuthService.SHOPCD}&prodCd=${prodCode}&uName=${AuthService.uName}&uCode=${AuthService.uCode}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<List<dynamic>?> getProductOriginList() async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTORIGINLIST}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateSubThemeMenuSort(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_PRODUCTORIGIN_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<List<dynamic>?> getProductNoFlagList(String jobGbn, String subGbn) async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_PRODUCTNOFLAGLIST}?jobGbn=${jobGbn}&subGbn=${subGbn}&shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      prodCnt = response.data['prodCnt'].toString();
      menuCnt = response.data['menuCnt'].toString();

      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateNoFlag(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_NOFLAG_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> updateListSort(String div, dynamic data) async {
    final response = await DioClient().post('${ServerInfo.RESTURL_PRODUCTSORT_SET}?div=${div}', data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<List<dynamic>?> getMultiImageList(String prodCd, String div) async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_MULTIIMAGELIST}?jobGbn=2&div=${div}&shopCd=${AuthService.SHOPCD}&targetCd=${prodCd}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }
}