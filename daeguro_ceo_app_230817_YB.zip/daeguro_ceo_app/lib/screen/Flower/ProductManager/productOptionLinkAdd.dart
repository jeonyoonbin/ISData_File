import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionLinkDeleteModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionLinkEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionLinkListModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductOptionLinkAdd extends StatefulWidget {
  final String? productCode;
  final String? productName;
  const ProductOptionLinkAdd({Key? key, this.productCode, this.productName})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ProductOptionLinkAddState();
  }
}

class ProductOptionLinkAddState extends State<ProductOptionLinkAdd> {

  final List<ProductOptionLinkListModel> dataList = <ProductOptionLinkListModel>[];

  requestAPIData({bool? isShowAlertPopup = false}) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getProductOptionLinkList(widget.productCode!))
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();
      value.forEach((element) {
        ProductOptionLinkListModel temp = ProductOptionLinkListModel();
        temp.selected = element['selected'] as String;
        temp.prodOptGrpCd = element['prodOptGrpCd'] as String;
        temp.optGrpCd = element['optGrpCd'] as String;
        temp.name = element['name'] as String;
        temp.minCount = element['minCount'] as String;
        temp.multiCount = element['multiCount'] as String;
        temp.useGbn = element['useGbn'] as String;
        temp.optNames = element['optNames'] as String;

        temp.isFlag = temp.selected == 'Y' ? true : false;

        dataList.add(temp);
      });
    }

    setState(() {});

    if (isShowAlertPopup == true)
      ISAlert(context, content: '저장되었습니다.', constraints: BoxConstraints(maxWidth: 240.0));
  }

  requestOptionLinkEditAdd(ProductOptionLinkEditModel sendData) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.updateProductOptionLink(sendData.toJson()))
    );

    if (value != '00') {
      ISAlert(context, content: '정상 등록 되지 않았습니다\n[다시 시도해 주세요]\n→ ${value}');
      //Navigator.of(context).pop;
    }
    else {
      //Navigator.of(context).pop(true);
      requestAPIData(isShowAlertPopup: true);
    }

    //setState(() {});
  }

  requestOptionLinkDelete(ProductOptionLinkDeleteModel sendData) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.deleteProductOptionGroupLink(sendData.toJson()))
    );

    if (value != '00') {
      ISAlert(context, content: '정상 등록 되지 않았습니다\n[다시 시도해 주세요]\n→ ${value}');
      //Navigator.of(context).pop;
    }
    else {
      //Navigator.of(context).pop(true);
      requestAPIData(isShowAlertPopup: true);
    }

    //setState(() {});
  }
  @override
  void dispose() {
    super.dispose();
    dataList.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData(isShowAlertPopup: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();//.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 600),
      contentPadding: const EdgeInsets.symmetric(horizontal: 8),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('옵션 연결', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('연결 옵션 선택', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                    Text('[${widget.productName}]에 연결할 옵션을 선택해 주세요.', style: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                  ],
                ),
              ),
              const Divider(),
              const SizedBox(height: 8),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.only(right: 16),
                  itemCount: dataList.length,
                  itemBuilder: (BuildContext context, int index) {
                    return dataList == null ?
                    const Text('Data is Empty')
                        : Card(
                      color: Colors.white,
                      elevation: 1,
                      shape: appTheme.cardShapStyle,
                      margin: const EdgeInsets.all(4),
                      child: CheckboxListTile(
                        contentPadding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                        activeColor: Colors.blue,
                        controlAffinity: ListTileControlAffinity.leading,
                        value: dataList[index].isFlag,
                        title: Text(dataList[index].name ?? '--', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            //Text(dataList[index].optNames ?? '--', style: const TextStyle(fontSize: 12, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                            const SizedBox(height: 8,),
                            Container(
                              width: double.infinity,
                              //padding: const EdgeInsets.symmetric(vertical: 8),
                              // decoration: BoxDecoration(
                              //   color: Colors.grey.shade200,
                              //   borderRadius: BorderRadius.circular(4.0),
                              // ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                      width: 30,
                                      height: 20,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        border: Border.all(color: Colors.black, width: 0.1),
                                      ),
                                      child: const Text('옵션', style: TextStyle(fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54),)
                                  ),
                                  const SizedBox(width: 6,),
                                  SizedBox(
                                    width: 190,
                                    child: Text(dataList[index].optNames ?? '--', style: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54)),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                        onChanged: (val){
                          dataList[index].isFlag = val!;

                          if (dataList[index].isFlag == false){
                            ProductOptionLinkDeleteModel sendData = ProductOptionLinkDeleteModel();
                            sendData.shopCd = AuthService.SHOPCD;
                            sendData.prodCd = widget.productCode;
                            sendData.optGrpCd = dataList[index].optGrpCd;
                            sendData.prodOptGrpCd = dataList[index].prodOptGrpCd;
                            sendData.uCode = AuthService.uCode;
                            sendData.uName = AuthService.uName;

                            requestOptionLinkDelete(sendData);
                          }
                          else{
                            ProductOptionLinkEditModel sendData = ProductOptionLinkEditModel();

                            sendData.shopCd = AuthService.SHOPCD;
                            sendData.prodCd = widget.productCode;

                            List<String> optionGroupCdList = [];
                            dataList.forEach((element) {
                              if (element.isFlag){
                                optionGroupCdList.add(element.optGrpCd!);
                              }
                            });

                            sendData.optGrpCd = optionGroupCdList;
                            sendData.uCode = AuthService.uCode;
                            sendData.uName = AuthService.uName;

                            requestOptionLinkEditAdd(sendData);
                          }
                        },
                      ),
                    );
                  },
                ),
              )
            ],
          ),
        ),
      ),
      actions: [
        // SizedBox(
        //   child: FilledButton(
        //     style: appTheme.popupButtonStyleLeft,
        //     onPressed: () {
        //       Navigator.pop(context);
        //     },
        //     child: const Text('닫기', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
        //   ),
        // ),
        // SizedBox(
        //   child: FilledButton(
        //     style: appTheme.popupButtonStyleRight,
        //     onPressed: () {
        //       ISConfirm(context, '옵션 연결', '옵션 연결 상태를 변경합니다. \n\n계속 진행 하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context) async {
        //         Navigator.of(context).pop();
        //
        //         ProductOptionLinkEditModel sendData = ProductOptionLinkEditModel();
        //
        //         sendData.shopCd = ShopUseState.SHOPCD;
        //         sendData.prodCd = widget.productCode;
        //
        //         List<String> optionGroupCdList = [];
        //         dataList.forEach((element) {
        //           if (element.isFlag){
        //             optionGroupCdList.add(element.optGrpCd!);
        //           }
        //         });
        //
        //         sendData.optGrpCd = optionGroupCdList;
        //         sendData.uCode = ShopUseState.uCode;
        //         sendData.uName = ShopUseState.uName;
        //
        //         requestOptionLinkEditData(sendData);
        //       });
        //     },
        //     child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
        //   ),
        // ),
      ],
    );
  }
}


