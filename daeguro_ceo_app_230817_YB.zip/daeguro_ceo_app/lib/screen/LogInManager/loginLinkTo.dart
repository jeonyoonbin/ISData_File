import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/screen/LogInManager/loginController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';

import 'package:provider/provider.dart';

class LoginLinkToPage extends StatefulWidget {
  const LoginLinkToPage({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return LoginLinkToPageState();
  }
}

class LoginLinkToPageState extends State<LoginLinkToPage> {
  AppTheme? appTheme;

  @override
  void initState() {
    super.initState();

    Get.put(LoginController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      LinkToLogin(context, appTheme!);
    });
  }

  @override
  Widget build(BuildContext context) {
    appTheme = context.watch<AppTheme>();

    //https://jh-industry.tistory.com/123  로그인 처리작업 필요

    return const SizedBox.shrink();
  }

  LinkToLogin(BuildContext context, AppTheme appTheme) async {
    debugPrint('------------ LinkToLogin call');

    await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(LoginController.to.linkTologIn())
    ).then((value) {
      if (value == '') {
        ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
        //Navigator.of(context).pop;
      }
      else{
        debugPrint('LinkToLogin result:${value.toString()}');
        String code = value.split('|').first;
        String msg = value.split('|').last;

        if (code == '00') {
          appTheme.currentShopStatusGbn = AuthService.ShopStatus;

          if (AuthService.linkToModel!.job_name == 'Main') {
            context.go('/');
          }
          else if (AuthService.linkToModel!.job_name == 'Statics'){
            //AuthService.initTabIndex_Account = 3;
            context.go('/account/info', extra: 3);
          }
          else{
            context.go('/');
          }

          AuthService.initLocation = '/login';

          debugPrint('LinkToLogin login Success');
        }
        else{
          ISAlert(context, content: '로그인 실패.\n→ ${msg} ');
        }
      }
    });
  }
}
