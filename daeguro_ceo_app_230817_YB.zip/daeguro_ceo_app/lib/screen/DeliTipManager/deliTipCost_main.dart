import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipAmtAreaModel.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipAmtEditModel.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipAmtListModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopDeliTipCostModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/deliTipCostEdit_Cost.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/deliTipCostEdit_Local.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/deliTipCostEdit_Time.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/delitipController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class DeliTipCostMain extends StatefulWidget {
  const DeliTipCostMain({Key? key}) : super(key: key);

  @override
  State<DeliTipCostMain> createState() => _DeliTipCostMainState();
}

class _DeliTipCostMainState extends State<DeliTipCostMain> {

  final ScrollController _scrollController = ScrollController();

  List<ShopDeliTipCostModel> mDeliTipCostList = <ShopDeliTipCostModel>[];

  List<DeliTipAmtListModel> mTipAmtList_Time = <DeliTipAmtListModel>[];
  List<DeliTipAmtListModel> mTipAmtList_Cost = <DeliTipAmtListModel>[];
  List<DeliTipAmtListModel> mTipAmtList_Sector = <DeliTipAmtListModel>[];
  List<DeliTipAmtListModel> mTipAmtList_AllSector = <DeliTipAmtListModel>[];

  requestAPIData() async {
    await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(getDeliTipData())
    ).then((value) {
      if (value == '00'){
          setState(() {
        });
      }
      else{
        ISAlert(context, content: '정상조회가 되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
      }
    });
  }

  Future<String?> getDeliTipData() async {
    var ret1 = await requestAPI_TimeCostData();
    var ret2 = await requestAPI_CostData();
    var ret3 = await requestAPI_SectorData();

    if (ret1 != '00') {
      return ret1.toString();
    }

    if (ret2 != '00') {
      return ret2.toString();
    }

    if (ret3 != '00') {
      return ret3.toString();
    }

    return '00';
  }

  Future<String?> requestAPI_TimeCostData() async {
    String retValue = '';

    await DeliTipController.to.getShopTipAmt('3', '').then((value) {
      if (value == null) {
        //ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
        retValue = '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요';
      }
      else {
        mTipAmtList_Time.clear();

        value.forEach((element) {
          DeliTipAmtListModel temp = DeliTipAmtListModel();
          temp.tipSeq = element['tipSeq'] as String;
          temp.tipGbn = element['tipGbn'] as String;
          temp.tipDay = element['tipDay'] as String;
          temp.tipFrStand = element['tipFrStand'] as String;
          temp.tipToStand = element['tipToStand'] as String;
          temp.tipAmt = element['tipAmt'] as String;
          temp.tipAmtRate = element['tipAmtRate'] as String;
          temp.tipNextDay = element['tipNextDay'] as String;

          mTipAmtList_Time.add(temp);
        });

        retValue = '00';
      }
    });

    setState(() {});

    return retValue;
  }

  Future<String?> requestAPI_CostData() async {
    String retValue = '';
    await DeliTipController.to.getShopTipAmt('1', '3').then((value) {
      if (value == null) {
        //ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
        retValue = '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요';
      }
      else {
        mTipAmtList_Cost.clear();

        value.forEach((element) {
          DeliTipAmtListModel temp = DeliTipAmtListModel();
          temp.tipSeq = element['tipSeq'] as String;
          temp.tipGbn = element['tipGbn'] as String;
          temp.tipDay = element['tipDay'] as String;
          temp.tipFrStand = element['tipFrStand'] as String;
          temp.tipToStand = element['tipToStand'] as String;
          temp.tipAmt = element['tipAmt'] as String;
          temp.tipAmtRate = element['tipAmtRate'] as String;
          temp.tipNextDay = element['tipNextDay'] as String;

          mTipAmtList_Cost.add(temp);
        });

        mTipAmtList_Cost.sort((b, a) {
          if (int.parse(a.tipFrStand!) < int.parse(b.tipFrStand!)) {
            return 1;
          }

          return 0;
        });

        retValue = '00';
      }
    });

    setState(() {});

    return retValue;
  }

  Future<String?> requestAPI_SectorData() async {
    String retValue = '';

    await DeliTipController.to.getShopTipAmt('1', '9').then((value) {
      if (value == null) {
        //ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
        retValue = '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요';
      }
      else {
        mTipAmtList_Sector.clear();
        mTipAmtList_AllSector.clear();

        List<DeliTipAmtListModel> tempListData = [];

        value.forEach((element) {
          DeliTipAmtListModel temp = DeliTipAmtListModel();
          temp.tipSeq = element['tipSeq'] as String;
          temp.tipGbn = element['tipGbn'] as String;
          temp.tipDay = element['tipDay'] as String;
          temp.tipFrStand = element['tipFrStand'] as String;
          temp.tipToStand = element['tipToStand'] as String;
          temp.tipAmt = element['tipAmt'] as String;
          temp.tipAmtRate = element['tipAmtRate'] as String;
          temp.tipNextDay = element['tipNextDay'] as String;

          tempListData.add(temp);

          mTipAmtList_AllSector.add(temp);

          int result = mTipAmtList_Sector.indexWhere((element) => element.tipAmt == temp.tipAmt);

          if (result == -1) {
            DeliTipAmtListModel tempMainList = DeliTipAmtListModel();
            tempMainList.tipAmt = temp.tipAmt;
            tempMainList.mTipAmt_SectorNameList = [];

            mTipAmtList_Sector.add(tempMainList);
          }
        });

        mTipAmtList_Sector.forEach((element) {
          tempListData.forEach((menuElement) {
            if (element.tipAmt == menuElement.tipAmt){
              element.mTipAmt_SectorNameList!.add(menuElement.tipFrStand!);
            }
          });
        });

        mTipAmtList_Sector.sort((b, a) {
          if (int.parse(a.tipAmt!) < int.parse(b.tipAmt!)) {
            return 1;
          }

          return 0;
        });

        retValue = '00';
      }
    });

    setState(() {});

    return retValue;
  }

  requestAPI_SetData(DeliTipAmtEditModel sendData, String jobGbn) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(DeliTipController.to.setShopTipAmt(sendData.toJson()))
    );

    if (value == null) {
      ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
    }
    else {
      if (value == '00') {
        if (jobGbn == 'T')         requestAPI_TimeCostData();
        else if (jobGbn == 'C')         requestAPI_CostData();
        else if (jobGbn == 'S')         requestAPI_SectorData();
      }
      else{
        ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
      }
    }
  }

  @override
  void initState() {
    super.initState();

    Get.put(DeliTipController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    mDeliTipCostList.clear();
    mTipAmtList_Time.clear();
    mTipAmtList_Cost.clear();
    mTipAmtList_Sector.clear();
    mTipAmtList_AllSector.clear();
    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          if (AuthService.ShopServiceGbn != AuthService.SHOPGBN_FLOWER){
            requestAPIData();
          }
          else{
            router.go('/');
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
        controller: _scrollController,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ISLabelBarMain(
              leading: Text('배달팁 설정', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
              underLine: false,
            ),
            ISLabelBarSub(
              title: '주문 배달팁 (시간대별)',
              trailing: ISButton(
                child: const Text('추가'),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => DeliTipCost_TimeEdit(jobGbn: '1'),
                  ).then((value) async {
                    if (value == true) {
                      await Future.delayed(const Duration(milliseconds: 500), () {
                        requestAPI_TimeCostData();
                      });
                    }
                  });
                },
              ),
            ),
            Column(
              children: [
                ...mTipAmtList_Time.map((member) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 40,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('${Utils.getDay(member.tipDay!)} ${Utils.getTimeFormat(member.tipFrStand!)} ~ ${Utils.getTimeFormat(member.tipToStand!)} : ${Utils.getCashComma(member.tipAmt!)}원',
                                style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            Row(
                              children: [
                                ISButton(
                                  child: const Text('변경'),
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      barrierDismissible: true,
                                      builder: (context) => DeliTipCost_TimeEdit(jobGbn: '3', tipSeq: member.tipSeq, tipDay: member.tipDay, tipFrStand: member.tipFrStand, tipToStand: member.tipToStand, tipAmt: member.tipAmt),
                                    ).then((value) async {
                                      if (value == true) {
                                        await Future.delayed(const Duration(milliseconds: 500), () {
                                          requestAPI_TimeCostData();
                                        });
                                      }
                                    });
                                  },
                                ),
                                const SizedBox(width: 6),
                                ISButton(
                                  isReverseColor: true,
                                  child: const Text('삭제'),
                                  onPressed: () {
                                    ISConfirm(context, '삭제', '해당 배달팁을 삭제 하시겠습니까?', constraints: BoxConstraints(maxWidth: 420), (context, isOK) async {
                                      Navigator.pop(context);

                                      if (isOK){
                                        DeliTipAmtEditModel sendData = DeliTipAmtEditModel();
                                        sendData.shopCd = AuthService.SHOPCD;

                                        List<String> sendjobGbn = [];
                                        List<String> sendtipSeq = [];
                                        List<String> sendtipGbn= [];
                                        List<String> sendtipDay = [];
                                        List<String> sendtipFrStand = [];
                                        List<String> sendtipToStand = [];
                                        List<String> sendtipAmt = [];

                                        sendjobGbn.add('D');
                                        sendtipSeq.add(member.tipSeq!);
                                        sendtipGbn.add(member.tipGbn!);
                                        sendtipDay.add(member.tipDay!);
                                        sendtipFrStand.add(member.tipFrStand!);
                                        sendtipToStand.add(member.tipToStand!);
                                        sendtipAmt.add(member.tipAmt!);

                                        sendData.jobGbn = sendjobGbn;
                                        sendData.tipSeq = sendtipSeq;
                                        sendData.tipGbn = sendtipGbn;
                                        sendData.tipDay = sendtipDay;
                                        sendData.tipFrStand = sendtipFrStand;
                                        sendData.tipToStand = sendtipToStand;
                                        sendData.tipAmt = sendtipAmt;

                                        sendData.uCode = AuthService.uCode;
                                        sendData.uName = AuthService.uName;

                                        requestAPI_SetData(sendData, 'T');
                                      }
                                    });
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    identical(member, mTipAmtList_Time.last) ? const SizedBox.shrink() : const Divider(height: 1,),
                  ],
                ),
                ).toList(),
              ],
            ),
            ISLabelBarSub(
              title: '주문 배달팁 (금액별)',
              trailing: ISButton(
                child: const Text('추가'),
                onPressed: () {

                  List<DeliTipAmtListModel> mTipAmtList_TempCost = <DeliTipAmtListModel>[];

                  mTipAmtList_Cost.forEach((element) {
                    DeliTipAmtListModel tempData = DeliTipAmtListModel();
                    tempData.jobGbn = 'U';
                    tempData.shopCd = element.shopCd;
                    tempData.shopName = element.shopName;
                    tempData.tipSeq = element.tipSeq;
                    tempData.tipGbn = element.tipGbn;
                    tempData.tipDay = element.tipDay;
                    tempData.tipFrStand = element.tipFrStand;
                    tempData.tipToStand = element.tipToStand;
                    tempData.tipAmt = element.tipAmt;
                    tempData.tipAmtRate = element.tipAmtRate;
                    tempData.tipNextDay = element.tipNextDay;
                    tempData.insUcode = element.insUcode;
                    tempData.insName = element.insName;
                    tempData.insDate = element.insDate;
                    tempData.modUcode = element.modUcode;
                    tempData.modName = element.modName;
                    tempData.modDate = element.modDate;

                    mTipAmtList_TempCost.add(tempData);
                  });

                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => DeliTipCost_CostEdit(jobGbn: '1', sData: mTipAmtList_TempCost),
                  ).then((value) async {
                    if (value == true) {
                      await Future.delayed(const Duration(milliseconds: 500), () {
                        requestAPI_CostData();
                      });
                    }
                  });
                },
              ),
            ),
            Column(
              children: [
                ...mTipAmtList_Cost.map((member) =>
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 40,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('${Utils.getCashComma(member.tipFrStand!)}원 이상 : ${Utils.getCashComma(member.tipAmt!)}원',
                                    style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                ISButton(
                                  isReverseColor: true,
                                  child: const Text('삭제'),
                                  onPressed: () {
                                    ISConfirm(context, '삭제', '해당 배달팁을 삭제 하시겠습니까?', constraints: BoxConstraints(maxWidth: 420), (context, isOK) async {
                                      Navigator.pop(context);

                                      if (isOK){
                                        DeliTipAmtEditModel sendData = DeliTipAmtEditModel();
                                        sendData.shopCd = AuthService.SHOPCD;

                                        List<String> sendjobGbn = [];
                                        List<String> sendtipSeq = [];
                                        List<String> sendtipGbn= [];
                                        List<String> sendtipDay = [];
                                        List<String> sendtipFrStand = [];
                                        List<String> sendtipToStand = [];
                                        List<String> sendtipAmt = [];

                                        sendjobGbn.add('D');
                                        sendtipSeq.add(member.tipSeq!);
                                        sendtipGbn.add(member.tipGbn!);
                                        sendtipDay.add(member.tipDay!);
                                        sendtipFrStand.add(member.tipFrStand!);
                                        sendtipToStand.add(member.tipToStand!);
                                        sendtipAmt.add(member.tipAmt!);

                                        sendData.jobGbn = sendjobGbn;
                                        sendData.tipSeq = sendtipSeq;
                                        sendData.tipGbn = sendtipGbn;
                                        sendData.tipDay = sendtipDay;
                                        sendData.tipFrStand = sendtipFrStand;
                                        sendData.tipToStand = sendtipToStand;
                                        sendData.tipAmt = sendtipAmt;

                                        sendData.uCode = AuthService.uCode;
                                        sendData.uName = AuthService.uName;

                                        requestAPI_SetData(sendData, 'C');
                                      }
                                    });
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                        identical(member, mTipAmtList_Cost.last) ? const SizedBox.shrink() : const Divider(height: 1,),
                      ],
                    ),
                ).toList(),
              ],
            ),
            ISLabelBarSub(
              title: '주문 배달팁 (지역별)',
              trailing: ISButton(
                child: const Text('추가'),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => DeliTipCost_LocalEdit(jobGbn: '1', selectDong: []),
                  ).then((value) async {
                    if (value == true) {
                      await Future.delayed(const Duration(milliseconds: 500), () {
                        requestAPI_SectorData();
                      });
                    }
                  });
                },
              ),
            ),
            Column(
              children: [
                ...mTipAmtList_Sector.map((member) =>
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 52,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 4.0),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('${Utils.getCashComma(member.tipAmt!)}원', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                      const SizedBox(height: 4),
                                      Text('${member.mTipAmt_SectorNameList.join(',')}', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                    ],
                                  ),
                                ),
                                Row(
                                  children: [
                                    ISButton(
                                      child: const Text('변경'),
                                      onPressed: () {
                                        showDialog(
                                          context: context,
                                          barrierDismissible: true,
                                          builder: (context) => DeliTipCost_LocalEdit(jobGbn: '3', selectDong: member.mTipAmt_SectorNameList, tipAmt: member.tipAmt, sData: mTipAmtList_AllSector),
                                        ).then((value) async {
                                          if (value == true) {
                                            await Future.delayed(const Duration(milliseconds: 500), () {
                                              //requestAPI_ProductData(selectedCatCode!);
                                            });
                                          }
                                        });
                                      },
                                    ),
                                    const SizedBox(width: 6),
                                    ISButton(
                                      isReverseColor: true,
                                      child: const Text('삭제'),
                                      onPressed: () {
                                        ISConfirm(context, '삭제', '해당 배달팁을 전체 삭제 하시겠습니까?\n전체 삭제 시 해당금액에 포함된 지역이 모두 삭제됩니다.\n\n→ [${member.mTipAmt_SectorNameList.join(',')}]', constraints: BoxConstraints(maxWidth: 460), (context, isOK) async {
                                          Navigator.pop(context);

                                          if (isOK){
                                            DeliTipAmtEditModel sendData = DeliTipAmtEditModel();
                                            sendData.shopCd = AuthService.SHOPCD;

                                            List<String> sendjobGbn = [];
                                            List<String> sendtipSeq = [];
                                            List<String> sendtipGbn= [];
                                            List<String> sendtipDay = [];
                                            List<String> sendtipFrStand = [];
                                            List<String> sendtipToStand = [];
                                            List<String> sendtipAmt = [];

                                            mTipAmtList_AllSector.forEach((element) {
                                              if (element.tipAmt == member.tipAmt){
                                                sendjobGbn.add('D');
                                                sendtipSeq.add(element.tipSeq!);
                                                sendtipGbn.add(element.tipGbn!);
                                                sendtipDay.add(element.tipDay!);
                                                sendtipFrStand.add(element.tipFrStand!);
                                                sendtipToStand.add(element.tipToStand!);
                                                sendtipAmt.add(element.tipAmt!);
                                              }
                                            });

                                            sendData.jobGbn = sendjobGbn;
                                            sendData.tipSeq = sendtipSeq;
                                            sendData.tipGbn = sendtipGbn;
                                            sendData.tipDay = sendtipDay;
                                            sendData.tipFrStand = sendtipFrStand;
                                            sendData.tipToStand = sendtipToStand;
                                            sendData.tipAmt = sendtipAmt;

                                            sendData.uCode = AuthService.uCode;
                                            sendData.uName = AuthService.uName;

                                            requestAPI_SetData(sendData, 'S');
                                          }
                                        });
                                      },
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        identical(member, mTipAmtList_Sector.last) ? const SizedBox.shrink() : const Divider(height: 1,),
                      ],
                    ),
                ).toList(),
              ],
            ),

            const Divider(height: 1),
          ],
        )
    );
  }
}