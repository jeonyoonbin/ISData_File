import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipSectorEditModel.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/delitipController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class DeliTipSectorEdit extends StatefulWidget {
  final String? jobGbn;
  final String? gungu;
  final List<ISOptionModel>? gunguList;
  final List<String>? matchDong;

  const DeliTipSectorEdit({Key? key, this.jobGbn, this.gungu, this.gunguList, this.matchDong}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return DeliTipSectorEditState();
  }
}

class DeliTipSectorEditState extends State<DeliTipSectorEdit> {

  List<String> selectedDongList = [];
  List<String> originalDongList = [];

  List<ISOptionModel> selectGunguList = [];

  DeliTipSectorEditModel sendData = DeliTipSectorEditModel();

  requestAPIData() async {
    setState(() {});
  }

  loadDongData(String? sido, String? gungu, List<String> restList) async {
    originalDongList.clear();
    selectedDongList.clear();

    if (gungu == null || gungu == '%') {
      setState(() {

      });

      return;
    }

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(DeliTipController.to.getDongData(sido!, gungu!))
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
      //Navigator.of(context).pop;
    }
    else {
      for (var item in value) {
        originalDongList.add(item['dongName'].toString());
      }

      if (restList.isNotEmpty){
        for (var element in restList) {
          if (_getCompareData(element)){
            selectedDongList.add(element);
          }
        }
      }
    }

    setState(() {});
  }

  bool _getCompareData(String item){
    bool temp = false;

    for (final element in originalDongList){
      if (element == item) {
        temp = true;
        break;
      }
    }
    return temp;
  }

  @override
  void dispose() {
    super.dispose();
    widget.gunguList?.clear();
    widget.matchDong?.clear();
    selectedDongList.clear();
    originalDongList.clear();
    selectGunguList.clear();
    sendData = DeliTipSectorEditModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(DeliTipController());

    if (widget.jobGbn == '1') {
      sendData = DeliTipSectorEditModel();
      sendData.sido = '대구광역시';
      sendData.gungu = '%';

      selectGunguList = widget.gunguList!;
    }
    else{
      sendData = DeliTipSectorEditModel();
      sendData.sido = '대구광역시';
      sendData.gungu = widget.gungu;

      selectGunguList.add(ISOptionModel(value: widget.gungu, label: widget.gungu));


    }

    WidgetsBinding.instance.addPostFrameCallback((c) {
      if (widget.jobGbn == '3')
        loadDongData(sendData.sido, sendData.gungu, widget.matchDong!);
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text(widget.jobGbn == '1' ? '배달지역 추가' : '배달지역 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ISLabelBarSub(
                title: '시도/시군구',
                  body: SingleChildScrollView(
                    scrollDirection: Responsive.isMobile(context) ? Axis.horizontal : Axis.vertical,
                    child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ISSearchDropdown(
                      ignoring: true,
                      width: 180,
                      label: '- 시도 -',
                      value: sendData.sido ?? '',
                      onChange: (value) {
                        setState(() {
                          sendData.sido = value;
                        });
                      },
                      item: [
                        ISOptionModel(value: '대구광역시', label: '대구광역시')
                      ].cast<ISOptionModel>(),
                    ),
                        SizedBox(width: 10,),
                    ISSearchDropdown(
                      ignoring: widget.jobGbn == '3' ? true : false,
                      label: '- 군구 -',
                      value: sendData.gungu,
                      onChange: (value) {
                        selectedDongList.clear();

                        sendData.sido = '대구광역시';
                        sendData.gungu = value;

                        loadDongData(sendData.sido, sendData.gungu, []);
                      },
                      //item: widget.jobGbn == '3' ? selectBox_EditGungu : selectBox_Gungu,
                      item: selectGunguList
                    ),
                  ],
                ),
              ),
                ),
              const Divider(height: 1),

              ISLabelBarSub(
                title: '배달지역 설정',
                body: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _DongMultiSelectView(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              if (sendData.gungu == '%' || sendData.gungu == ''){
                ISAlert(context, content: '시군구를 선택해주세요.');
                return;
              }

              if (selectedDongList.length == 0 || selectedDongList.isEmpty){
                ISAlert(context, content: '선택된 지역이 없습니다.\n확인 후, 다시 시도해주세요.');
                return;
              }

              //DeliTipSectorEditModel sendData = DeliTipSectorEditModel();
              sendData.jobGbn = '1';
              sendData.shopCd = AuthService.SHOPCD;
              sendData.sido = sendData.sido;
              sendData.gungu = sendData.gungu;
              sendData.dong = selectedDongList;
              sendData.uCode = AuthService.uCode;
              sendData.uName = AuthService.uName;


              var value = await showDialog(
                  context: context,
                  builder: (context) => FutureProgressDialog(DeliTipController.to.setDeliTipSectorInfo(sendData.toJson()))
              );

              if (value == null) {
                ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
              }
              else {
                if (value == '00') {
                  // currentMode = MODE_MAIN_VIEW;
                  // _scrollController!.jumpTo(0.0);
                  //
                  // requestAPIData();
                }
                else{
                  ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                }
              }
            },
            child: Text(widget.jobGbn == '1' ? '등록' : '적용', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }

  Widget _DongMultiSelectView()
  {
    List<Widget> checkBoxList = [];
    if (originalDongList != null){
      originalDongList.forEach((item) {
        checkBoxList.add(
            Padding(
              padding: const EdgeInsets.only(right: 8.0, top: 10.0),//symmetric(vertical: 8.0, horizontal: 8.0),
              child: ISCheckbox(
                  label: item,
                  value: selectedDongList.contains(item),
                  onChanged: (v) {
                    setState(() {
                      selectedDongList.contains(item) ? selectedDongList.remove(item) : selectedDongList.add(item);

                      // if (selectedDongList.length == originalDongList.length)
                      //   isAllSelected = true;
                      // else
                      //   isAllSelected = false;
                    });
                  }
              ),
            )
        );
      });
    }

    return Expanded(child: Wrap(children: checkBoxList,));
  }
}


