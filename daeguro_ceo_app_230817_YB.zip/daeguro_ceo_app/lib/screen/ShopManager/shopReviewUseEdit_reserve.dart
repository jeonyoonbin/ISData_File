import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/models/Common/commonNoFlagModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionSoldOutEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateEditModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopReviewUseEditReserve extends StatefulWidget {
  final String? sReviewUseGbn;
  final String? ccCode;
  const ShopReviewUseEditReserve({Key? key, this.sReviewUseGbn, this.ccCode})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopReviewUseEditReserveState();
  }
}

class ShopReviewUseEditReserveState extends State<ShopReviewUseEditReserve> {

  String? reviewUseGbn;

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());


    reviewUseGbn = widget.sReviewUseGbn;
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 260),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text('고객 리뷰', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 12,),
              const Text('고객 리뷰', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
              const Text('고객 리뷰 사용여부를 선택해주세요.', style: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
              const SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ISCheckbox(
                      label: '사용중',
                      value: reviewUseGbn == 'Y' ? true : false,
                      onChanged: (v) {
                        setState(() {
                          if (v == true) {
                            reviewUseGbn = 'Y';
                          }
                        });
                      }
                  ),
                  const SizedBox(width: 8,),
                  ISCheckbox(
                      label: '미사용',
                      value: reviewUseGbn == 'Y' ? false : true,
                      onChanged: (v) {
                        setState(() {
                          if (v == true) {
                            reviewUseGbn = 'N';
                          }
                        });
                      }
                  ),
                ],
              ),
              const SizedBox(height: 10,),
            ],
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              ISConfirm(context, '고객 리뷰 사용 변경', '고객 리뷰 사용 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ReserveController.to.updateReserveReviewUse(AuthService.SHOPCD, widget.ccCode.toString(), reviewUseGbn.toString(), AuthService.uCode))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                    }
                    else {
                      ISAlert(context, content: '정상 등록 되지 않았습니다.\n[관리자에게 문의 바랍니다]\n→ ${value}');
                    }
                  }
                }
              });
            },
            child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


