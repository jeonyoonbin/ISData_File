import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateDeliInfoEdit.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopProductDeliInfoModel.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopProductDeliInfoEdit extends StatefulWidget {
  final List<ShopProductDeliInfoModel>? sData;
  const ShopProductDeliInfoEdit({Key? key, this.sData})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopProductDeliInfoEditState();
  }
}

class ShopProductDeliInfoEditState extends State<ShopProductDeliInfoEdit> {
  final ScrollController _scrollController = ScrollController();

  List<ShopProductDeliInfoModel> formData = <ShopProductDeliInfoModel>[];

  @override
  void dispose() {
    super.dispose();
    formData = [];
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    formData = widget.sData!;

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('배송 안내', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: SingleChildScrollView(
        controller: _scrollController,
        child: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12,),
                ISLabelBarSub(
                    title: '배송 안내',
                    bodyPadding: EdgeInsets.zero,
                    body: Column(
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: DataTable(
                            headingRowHeight: 0.0,
                            dataRowHeight: 230.0,
                            columnSpacing: 0.0,
                            horizontalMargin: 0.0,
                            columns: [
                              const DataColumn(label: Flexible(child: Text('', textAlign: TextAlign.center))),
                              DataColumn(label: Container(
                                  width: 60,
                                  color: Colors.yellow,
                                  child: const Text('', textAlign: TextAlign.center))
                              ),
                            ],
                            rows: formData.map((item){
                              return DataRow(
                                  cells: [
                                    DataCell(Align(alignment: Alignment.centerLeft,
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          ISInput(
                                            value: item.title,
                                            context: context,
                                            width: 340,
                                            height: 65,
                                            label: '배송 안내 타이틀',
                                            maxLines: 1,
                                            maxLength: 50,
                                            onChange: (v) {
                                              item.title = v;
                                            },
                                          ),
                                          const SizedBox(height: 12,),
                                          ISInput(
                                            value: item.content,
                                            context: context,
                                            width: 340,
                                            height: 120,
                                            //padding: 0,
                                            label: '배송 안내 상세 설명',
                                            keyboardType: TextInputType.multiline,
                                            maxLines: 4,
                                            maxLength: 200,
                                            onChange: (v) {
                                              item.content = v;
                                            },
                                          )
                                        ],
                                      ),
                                    )
                                    ),
                                    DataCell(
                                        Align(alignment: Alignment.center,
                                            child: InkWell(
                                              child: const Icon(Icons.cancel, color: Color(0xff01CAFF), size: 21),
                                              onTap: (){
                                                formData.remove(item);
                                                setState(() {

                                                });
                                              },
                                            )
                                        )
                                    ),
                                  ]
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                    trailing: ISButton(
                        child: const Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.add),
                            Text('배송 안내 추가')
                          ],
                        ),
                        //onPressed: () => _addOptionGroup()
                        onPressed: () {
                          formData.add(ShopProductDeliInfoModel());
                          setState(() {
                            _scrollController!.jumpTo(1000);
                          });
                        }
                    ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              if (formData.isEmpty || formData.length == 0){
                ISAlert(context, content: '배송안내를 추가해주세요.');
                return;
              }

              BuildContext oldContext = context;

              ISConfirm(context, '배송 안내 변경', '배송 안내 정보를 변경합니다. \n\n계속 진행 하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  ShopOperateDeliInfoEditModel sendData = ShopOperateDeliInfoEditModel();
                  sendData.jobGbn = 'I';
                  sendData.shopCd = AuthService.SHOPCD;

                  List<String> tempDeliNoticeCdArr = [];
                  List<String> tempTitleArr = [];
                  List<String> tempContentArr = [];

                  formData.forEach((element) {
                    //tempDeliNoticeCdArr.add(element.deliNoticeCode!);//미사용
                    tempTitleArr.add(element.title!);
                    tempContentArr.add(element.content!);
                  });

                  sendData.deliNoticeCd = tempDeliNoticeCdArr;
                  sendData.title = tempTitleArr;
                  sendData.content = tempContentArr;
                  sendData.uCode = AuthService.uCode;
                  sendData.uName = AuthService.uName;

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ShopController.to.setOperateDeliInfo(sendData.toJson()))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(oldContext).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ $value ');
                    }
                  }
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


