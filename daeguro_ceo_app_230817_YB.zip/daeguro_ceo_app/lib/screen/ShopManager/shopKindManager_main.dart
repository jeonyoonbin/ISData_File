import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/RequestManager/requestShopInfoEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateInfoModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopOperateInfoKindView.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;

class ShopKindManagerMain extends StatefulWidget {
  const ShopKindManagerMain({Key? key}) : super(key: key);

  @override
  State<ShopKindManagerMain> createState() => _ShopKindManagerMainState();
}

class _ShopKindManagerMainState extends State<ShopKindManagerMain> with PageMixin {

  final ScrollController _scrollController = ScrollController();
  final ShopOperateInfoModel shopOperatorInfoData = ShopOperateInfoModel();

  var setDate;


  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ShopController.to.getOperateInfo())
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
      //Navigator.of(context).pop;
    }
    else {
      shopOperatorInfoData.absentYn = value['absentYn'] as String;
      shopOperatorInfoData.reviewUseGbn = value['reviewUseGbn'] as String;
      shopOperatorInfoData.holiDayTerm = value['holiDayTerm'] as String;
      shopOperatorInfoData.kindShopStatus = value['kindShopStatus'] as String;
      shopOperatorInfoData.childMealYn = value['childMealYn'] as String;
      shopOperatorInfoData.minAmtPass = value['minAmtPass'] as String;
      shopOperatorInfoData.answerText = value['answerText'] as String;
      shopOperatorInfoData.kindShopCancelDt = value['kindShopCancelDt'] as String;
      shopOperatorInfoData.exchangeNotice = value['exchangeNotice'] as String;
      shopOperatorInfoData.returnNotice = value['returnNotice'] as String;
      shopOperatorInfoData.rejectNotice = value['rejectNotice'] as String;
      shopOperatorInfoData.reserveTerm = value['reserveTerm'] as String;
      shopOperatorInfoData.lAuth = value['lAuth'] as String;
      shopOperatorInfoData.lTel = value['lTel'] as String;
      shopOperatorInfoData.lSeller = value['lSeller'] as String;

      AuthService.ShopStatus = shopOperatorInfoData.absentYn;
    }

    // 착한매장 해지날짜 없을시 임의로 셋팅 날짜 현재년 + 100으로 설정
    if (shopOperatorInfoData.kindShopCancelDt == '' || shopOperatorInfoData.kindShopCancelDt == null) {      
      setDate = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day);
    } else {
    String cancelDate = shopOperatorInfoData.kindShopCancelDt.toString() + '000000';
    String cancelDateWithT = cancelDate.substring(0, 8) + 'T' + cancelDate.substring(8);
    DateTime cancelDateTime = DateTime.parse(cancelDateWithT);

    setDate = DateTime(cancelDateTime.year, cancelDateTime.month, cancelDateTime.day + 90);
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());
    Get.put(RequestController());


    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    double contentHeight = MediaQuery.of(context).size.height;

    return fluentUI.ScaffoldPage.scrollable(
      //scrollController: _scrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      children: deskTopLiveEventManagerMain(contentHeight)
    );

  }

  List<Widget> deskTopLiveEventManagerMain(double contentHeight){
    return [
      SingleChildScrollView(
        controller: _scrollController,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ISLabelBarMain(
              leading: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const Text('착한매장', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
                  shopOperatorInfoData.kindShopStatus! == '임시중지' ? const Text(' ※ 임시중지 해지는 고객센터(1661-3773)으로 문의 바랍니다.', style: TextStyle(color: Colors.red, fontSize: 15)) : SizedBox.shrink(),
                ],
              ),
              underLine: false,
            ),
            Container(
                margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [BoxShadow(color: Colors.black26, offset: Offset(0.0, 2.0), blurRadius: 4.0),],
                ),
                child: Container(
                  margin: EdgeInsets.all(20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('상태', style: TextStyle(color: Colors.black,fontSize: 18, fontWeight: FontWeight.bold),),
                      SizedBox(height: 10,),
                      Row(
                        children: [
                          Text(shopOperatorInfoData.kindShopStatus!, style: TextStyle(color: shopOperatorInfoData.kindShopStatus! == '해지' ? Colors.red : Colors.green, fontSize: 20, fontWeight: FontWeight.bold)),
                          const SizedBox(width: 20),
                          _kindBtn(shopOperatorInfoData.kindShopStatus!)
                        ],
                      ),
                      SizedBox(height: 5),
                      shopOperatorInfoData.kindShopStatus == '반려' ?
                      Text('(사유 : ${shopOperatorInfoData.answerText})', style: TextStyle(color: Colors.black, fontSize: 15, fontWeight: FONT_BOLD))
                          : SizedBox.shrink(),
                      SizedBox(height: 20),
                      Responsive.isMobile(context) ? Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('* 신청내역 보기 및 신청취소는 ', style: TextStyle(color: Colors.black, fontSize: 15)),
                          Row(
                            children: [
                              Material(
                                child: InkWell(child: Text('"변경요청내역"', style: TextStyle(color: Color(0xff01CAFF), fontSize: 15, fontWeight: FontWeight.bold)), onTap: (){
                                  router.go('/request/info');
                                }),
                              ),
                              Text(' 에서 할 수 있습니다.', style: TextStyle(color: Colors.black ,fontSize: 15)),
                            ],
                          ),
                        ],
                      ) : Row(
                        children: [
                          Text('* 신청내역 보기 및 신청취소는 ', style: TextStyle(color: Colors.black, fontSize: 15)),
                          Row(
                            children: [
                              Material(
                                child: InkWell(child: Text('"변경요청내역"', style: TextStyle(color: Color(0xff01CAFF), fontSize: 15, fontWeight: FontWeight.bold)), onTap: (){
                                  router.go('/request/info');
                                }),
                              ),
                              Text(' 에서 할 수 있습니다.', style: TextStyle(color: Colors.black ,fontSize: 15)),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(height: 5),
                      Responsive.isMobile(context) ? Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('* 보류에 대한 사유는', style: TextStyle(color: Colors.black, fontSize: 15)),
                          Row(
                            children: [
                              Material(child: InkWell(child: Text(' "변경요청내역"', style: TextStyle(color: Color(0xff01CAFF), fontSize: 15, fontWeight: FontWeight.bold)), onTap: (){
                                router.go('/request/info');
                              })),
                              Text(' 에서 조회할 수 있습니다.', style: TextStyle(color: Colors.black ,fontSize: 15)),
                            ],
                          ),
                        ],
                      ): Row(
                        children: [
                          Text('* 보류에 대한 사유는', style: TextStyle(color: Colors.black, fontSize: 15)),
                          Row(
                            children: [
                              Material(child: InkWell(child: Text(' "변경요청내역"', style: TextStyle(color: Color(0xff01CAFF), fontSize: 15, fontWeight: FontWeight.bold)), onTap: (){
                                router.go('/request/info');
                              })),
                              Text(' 에서 조회할 수 있습니다.', style: TextStyle(color: Colors.black ,fontSize: 15)),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                )
            ),
            Container(
                margin: const EdgeInsets.all(10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('※ 유의사항 (필독)', style: TextStyle(color: Colors.black ,fontSize: 15)),
                    SizedBox(height: 5,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 20, child: Text('1.')),
                        SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 64 : MediaQuery.of(context).size.width - 328, child: Text('착한매장 입점시 메뉴, 메뉴금액, 배달팁 수정은 불가합니다.', maxLines: 5)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 20, child: Text('2.')),
                        SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 64 : MediaQuery.of(context).size.width - 328, child: Text('착한매장 해지시 해지일로 부터 90일간 재신청이 불가합니다.', maxLines: 5,)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 20, child: Text('3.')),
                        SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 64 : MediaQuery.of(context).size.width - 328, child: Text('타 배달앱 가격 조작 등 부정행위로 인한 입점 탈락 및 해지 시 재신청 불가합니다.', maxLines: 5)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 20, child: Text('4.')),
                        SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 64 : MediaQuery.of(context).size.width - 328, child: Text('착한매장 해지 후 메뉴 및 배달팁 등은 원상복구 되지 않으며, 별도 수정이 필요합니다.', maxLines: 5)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 20, child: Text('5.')),
                        SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 64 : MediaQuery.of(context).size.width - 328, child: Text('착한매장 검수 완료시 별도 문자 발송을 통해 안내드릴 예정입니다.(약7일 소요)', maxLines: 5)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 20, child: Text('6.')),
                        SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 64 : MediaQuery.of(context).size.width - 328, child: Text('착한매장 신청시 메뉴, 배달팁, 가맹점쿠폰, 리뷰이벤트등 모든 운영조건은 신청한 가맹점이 운영하는 배달앱 중 가장 저렴한 곳 기준으로 동일하게 수정됩니다.', maxLines: 5)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 20, child: Text('7.')),
                        SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 64 : MediaQuery.of(context).size.width - 328, child: Text('착한매장 임시중지 또는 임시중지해제 요청은 고객센터(1661-3773)으로 문의 바랍니다.', maxLines: 2,)),
                      ],
                    ),
                  ],
                )
            ),
          ],
        ),
      )
    ];
  }
  Widget _kindBtn (String gbn) {
    if (gbn == '사용중' || gbn == '임시중지') {
      return ISButton(
        child: const Text('착한매장 해지'),
        buttonColor: Colors.redAccent,
        onPressed: () {
          showDialog(
              context: context,
              builder: (context) {
                return btnRtnPopup('1', context);
              }).then((value) {
            if(value == true) {
              showDialog<void>(
                  context: context,
                  builder: (context) {
                    return btnRtnPopup('3', context);
                  });

              requestAPIData();
            }
          });

          requestAPIData();
        },
      );
    } else if (gbn == '사용안함' || gbn == '반려' || gbn == '해지') {
      return ISButton(
        child: Text('착한매장 신청'),
        onPressed: () {
          if(double.parse(formatDate(setDate, [yyyy, mm, mm]).toString()) > double.parse(formatDate(DateTime.now(), [yyyy, mm, mm]).toString())) {
            showDialog<void>(
                context: context,
                builder: (context) {
                  return btnRtnPopup('4', context);
                });

            return;
          }

          showDialog(
            context: context,
            builder: (BuildContext context) => const Dialog(
                child: ShopOperateInfoKindView()
            ),
          ).then((value) {
            if(value == true) {
              showDialog<void>(
                  context: context,
                  builder: (context) {
                    return btnRtnPopup('2', context);
                  });

              requestAPIData();
            }
          });
        },
      );
    } else {
      return const SizedBox.shrink();
    }
  }

  Widget btnRtnPopup (String gbn, BuildContext context) {
    if(gbn == '1') {
      return ContentDialog(
        constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 260),
        contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),//all(20),
        //isFillActions: true,
        title: const Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.warning_rounded, color: Colors.redAccent, size: 25),
            SizedBox(width: 5),
            Text('착한매장을 해지하시겠습니까?', style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD))
          ],
        ),
        content: const SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('해지시 ', style: TextStyle(color: Colors.black ,fontSize: 14)),
                  Text('3개월(90일)간', style: TextStyle(color: Colors.redAccent, fontSize: 14, fontWeight: FontWeight.bold)),
                  Text(' 착한매장 신청이 불가능합니다.', style: TextStyle(color: Colors.black ,fontSize: 14)),
                ],
              ),
              SizedBox(height: 10),
              Text('※ 브랜드 쿠폰 이벤트로 인한 일시적인 탈퇴는 운영사에 문의 바랍니다.', style: TextStyle(fontSize: 14, color: Colors.black54, fontFamily: FONT_FAMILY)),
              SizedBox(height: 5),
              Center(child: Text('고객센터 : 1661-3773', style: TextStyle(color: Colors.black ,fontSize: 14))),
            ],
          ),
        ),
        actions: [
          SizedBox(
            width: double.infinity / 2,
            child: FilledButton(
              style: ButtonStyle(
                backgroundColor: const MaterialStatePropertyAll(Colors.redAccent),
                shape: MaterialStatePropertyAll(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0))
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop(false);
              },
              child: const Text('취소'),
            ),
          ),
          SizedBox(
            width: double.infinity / 2,
            child: FilledButton(
              style: ButtonStyle(
                backgroundColor: const MaterialStatePropertyAll(Colors.blueAccent),
                shape: MaterialStatePropertyAll(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0))
                ),
              ),
              onPressed: () async {
                BuildContext dialogContext = context;

                RequestShopInfoEditModel sendData = RequestShopInfoEditModel();
                sendData.shopCd = AuthService.SHOPCD;
                sendData.status = '10';
                sendData.serviceGbn = '601';
                sendData.uCode = AuthService.uCode;
                sendData.uName = AuthService.uName;

                var value = await showDialog(
                    context: context,
                    builder: (context) => FutureProgressDialog(RequestController.to.setRequireServiceV2(sendData, [])));

                if (value == null) {
                  ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                }
                else {
                  http.Response.fromStream(value).asStream().listen((event) {
                    if (event.statusCode == 200) {
                      var result = jsonDecode(event.body);

                      String code = result['code'].toString();
                      String msg = result['msg'].toString();

                      if (code == '00'){
                        Navigator.of(dialogContext).pop(true);
                      }
                      else{
                        ISAlert(dialogContext, content: '정상처리가 되지 않았습니다.\n→ ${msg} ');
                      }
                    }
                    else{
                      Navigator.of(dialogContext).pop(true);
                    }
                  });
                }
              },
              child: const Text('확인'),
            ),
          ),
        ],
      );
    } else if(gbn == '2') {
      return ContentDialog(
        constraints: const BoxConstraints(maxWidth: 370.0, maxHeight: 255),
        contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),//all(20),
        //isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 10),
            Text('착한매장 신청완료', style: const TextStyle(fontSize: 15, fontFamily: FONT_FAMILY, overflow: TextOverflow.ellipsis)),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: const SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('착한매장 신청이 완료 되었습니다.', style: TextStyle(fontSize: 15, color: Colors.black)),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('상세내용은 ', style: TextStyle(color: Colors.black ,fontSize: 15)),
                  Text('"변경요청내역"', style: TextStyle(color: Color(0xff01CAFF), fontSize: 15, fontWeight: FontWeight.bold)),
                  Text(' 에서 확인해주세요.', style: TextStyle(color: Colors.black ,fontSize: 15)),
                ],
              ),
              SizedBox(height: 10),
              Text('※ 착한매장 입점 시 고객 결제금액에서 1,000원 자동차감됩니다.(가맹점 부담)', style: TextStyle(fontSize: 13, color: Colors.red, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
            ],
          ),
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: ButtonStyle(
                backgroundColor: const MaterialStatePropertyAll(Colors.blueAccent),
                shape: MaterialStatePropertyAll(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0))
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('확인'),
            ),
          ),
        ],
      );
    } else if(gbn == '3') {
      return ContentDialog(
        constraints: const BoxConstraints(maxWidth: 375.0, maxHeight: 220),
        contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),//all(20),
        //isFillActions: true,
        title: const Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(Icons.check_circle, color: Color(0xff01CAFF), size: 25),
            SizedBox(width: 5),
            Text('착한매장 해지완료!', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY, overflow: TextOverflow.ellipsis))
          ],
        ),
        content: const SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('착한매장 해지가 완료 되었습니다.', style: TextStyle(fontSize: 15, color: Colors.black)),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('결과는  ', style: TextStyle(color: Colors.black ,fontSize: 15)),
                  Text('"변경요청이력"', style: TextStyle(color: Color(0xff01CAFF), fontSize: 15, fontWeight: FontWeight.bold)),
                  Text(' 메뉴에서 확인해 주세요.', style: TextStyle(color: Colors.black ,fontSize: 15)),
                ],
              ),
            ],
          ),
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: ButtonStyle(
                backgroundColor: const MaterialStatePropertyAll(Colors.blueAccent),
                shape: MaterialStatePropertyAll(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0))
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('확인'),
            ),
          ),
        ],
      );
    }  else if(gbn == '4') {
      return ContentDialog(
        constraints: const BoxConstraints(maxWidth: 375.0, maxHeight: 200),
        contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),//all(20),
        //isFillActions: true,
        content: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              const Text('착한매장 해지시 해지일로부터 90일 후 재신청 가능 합니다.', style: TextStyle(fontSize: 15, color: Colors.black)),
              const SizedBox(height: 10),
              Text('신청가능일자 : ${formatDate(setDate, [yyyy, '년 ', mm, '월 ', dd, '일']).toString()}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 15, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: ButtonStyle(
                backgroundColor: const MaterialStatePropertyAll(Colors.blueAccent),
                shape: MaterialStatePropertyAll(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0))
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('확인'),
            ),
          ),
        ],
      );
    } else {
      return SizedBox.shrink();
    }
  }
}
