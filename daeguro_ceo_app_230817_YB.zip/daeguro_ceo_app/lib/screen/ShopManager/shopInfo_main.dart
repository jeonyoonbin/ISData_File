import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveShopInfoModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestShopInfoEdit.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveShopInfoIntroduceEdit.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveShopReviewIntroEdit.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveShopUpdateNoticeEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopDeliInfoEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopDeliPackTimeEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopPaymentGbnEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopInfoMain extends StatefulWidget {
  final double? tabviewHeight;

  const ShopInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ShopInfoMain> createState() => _ShopInfoMainState();
}

class _ShopInfoMainState extends State<ShopInfoMain> {
  final ScrollController _scrollController = ScrollController();

  ShopInfoModel shopInfoModel = ShopInfoModel();

  //List<Shadow>? textShadows = [const Shadow(blurRadius: 1.0,  color: Colors.blue, offset: Offset(2.0,2.0))];

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ShopController.to.getShopInfo())
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
    }
    else {
      shopInfoModel.shopName = value['shopName'] as String;
      shopInfoModel.ccCode = value['ccCode'] as String;
      shopInfoModel.owner = value['owner'] as String;
      shopInfoModel.telNo = value['telNo'] as String;
      shopInfoModel.mobile = value['mobile'] as String;
      shopInfoModel.addrJibun = value['addrJibun'] as String;
      shopInfoModel.addrRoad = value['addrRoad'] as String;
      shopInfoModel.addrDetail = value['addrDetail'] as String;
      shopInfoModel.items = value['items'] as String;
      shopInfoModel.shopType = value['shopType'] as String;
      shopInfoModel.acceptState = value['acceptState'] as String;
      shopInfoModel.deliInfo = value['deliInfo'] as String;
      shopInfoModel.appPayType = value['appPayType'] as String;
      shopInfoModel.toGoAcceptState = value['toGoAcceptState'] as String;

      List<String> appPayTypeArr = shopInfoModel.appPayType!.split(',');
      if (appPayTypeArr.isEmpty){
        shopInfoModel.meetToPay = false;
        shopInfoModel.appType = false;
        shopInfoModel.meetToCard = false;
      }
      else{
        shopInfoModel.meetToPay = appPayTypeArr.contains('1');//appPayTypeArr.any((item) => item.toString() == '1');
        shopInfoModel.appType = appPayTypeArr.contains('3');
        shopInfoModel.meetToCard = appPayTypeArr.contains('5');
      }

      ShopController.to.ccCode.value = shopInfoModel.ccCode.toString();

      shopInfoModel.shopImgURL = ServerInfo.REST_IMG_BASEURL + '/images/' + shopInfoModel.ccCode! + '/' + AuthService.SHOPCD + '/shop.jpg?tm=${Utils.getTimeStamp()}';
      //https://image.daeguro.co.kr:40443/images/3/1/shop.jpg?202304260647446
      ////ServerInfo.REST_IMG_BASEURL + '/images/' + item.ccCode + '/' + item.shopCd + '/shop.jpg?tm=${Utils.getTimeStamp()}',
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    shopInfoModel = ShopInfoModel();

    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  bool showCategoryEnabled() {
    if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER){
      return false;
    }
    else if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET){
      return AuthService.TradShopMainYn == 'Y' ? false : true;
    }
    else {
      return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    const TextStyle elementStyle = TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY);

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
        controller: _scrollController,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ISLabelBarMain(
              underLine: false,
              leading: ISButton(
                child: const Text('매장 정보 변경 요청'),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => RequestShopInfoEdit(sData: shopInfoModel),
                  ).then((value) async {
                    if (value == true){
                      await Future.delayed(const Duration(milliseconds: 500), () {
                        ISAlert(context, title: '매장 정보 변경요청 완료', content: '매장정보 변경 요청이 접수되었습니다.\n\n운영사 확인 후, 2~3일내로 처리될 예정입니다.\n결과는 [변경 요청 이력]메뉴에서 확인해 주세요.', constraints: BoxConstraints(maxWidth: 360.0));
                      });
                    }
                  });
                },
              ),
            ),
            const Divider(height: 1,),
            const SizedBox(height: 4),
            Responsive.isMobile(context)
                ? Container(
              padding: const EdgeInsets.only(left: 15, top: 8, bottom: 3),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: shopInfoModel.shopImgURL == null
                          ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 160, height: 160,)
                          : Image.network('${shopInfoModel.shopImgURL!}?tm=${Utils.getTimeStamp()}', fit: BoxFit.fitWidth, gaplessPlayback: true, width: 160, height: 160,
                        errorBuilder: (context, error, stackTrace) {
                          return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 160, height: 160,);
                        },
                      ),
                    ),
                    Row(
                        children: [
                          SizedBox(
                            width: 100,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(alignment: Alignment.centerLeft, height: 30, child: const Text(textAlign: TextAlign.left, '가맹점명', style: elementStyle)),
                                Container(alignment: Alignment.centerLeft, height: 30, child: const Text(textAlign: TextAlign.left, '대표자명', style: elementStyle)),
                                Container(alignment: Alignment.centerLeft, height: 30, child: const Text(textAlign: TextAlign.left, '매장 전화번호', style: elementStyle)),
                                Container(alignment: Alignment.centerLeft, height: 30, child: const Text(textAlign: TextAlign.left, '휴대전화 번호', style: elementStyle)),
                              ],
                            ),
                          ),
                          Flexible(
                            fit: FlexFit.tight,
                            flex: 3,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(alignment: Alignment.centerLeft, height: 30, child: Tooltip(message: shopInfoModel.shopName, child: Text(textAlign: TextAlign.left, shopInfoModel.shopName ?? '', overflow: TextOverflow.ellipsis, style: elementStyle))),
                                Container(alignment: Alignment.centerLeft, height: 30, child: Text(textAlign: TextAlign.left, shopInfoModel.owner ?? '', style: elementStyle)),
                                Container(
                                  alignment: Alignment.centerLeft,
                                  height: 30,
                                  child: Wrap(
                                    crossAxisAlignment: WrapCrossAlignment.center,
                                    children: [
                                      ISInput(
                                        width: 120,
                                        height: 30,
                                        value: Utils.getPhoneNumFormat(shopInfoModel.telNo!, false),
                                        onChange: (v) {
                                          setState(() {
                                            shopInfoModel.telNo = v.toString();
                                          });
                                        },
                                      ),
                                      const SizedBox(
                                        width: 8,
                                      ),
                                      ISButton(
                                        height: 38,
                                        onPressed: () async {
                                          var value = await showDialog(context: context, barrierColor: Colors.transparent,builder: (context) => FutureProgressDialog(ShopController.to.updateShopInfo('8', shopInfoModel.telNo.toString(), '', '')));

                                          if (value == null) {
                                            ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                          } else {
                                            if (value == '00') ISAlert(context, title: '매장 전화번호 수정', content: '수정되었습니다.');
                                          }
                                        },
                                        child: const Text('변경', style: elementStyle),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(alignment: Alignment.centerLeft, height: 30, child: Text(textAlign: TextAlign.left, Utils.getPhoneNumFormat(shopInfoModel.mobile!, false) ?? '', style: elementStyle)),
                              ],
                            ),
                          ),
                        ]
                    ),
                  ]),
            ) : SizedBox(
              height: 200,
              child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 30),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8.0),
                        child: shopInfoModel.shopImgURL == null
                            ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 160, height: 160,)
                            : Image.network('${shopInfoModel.shopImgURL!}?tm=${Utils.getTimeStamp()}', fit: BoxFit.fitWidth, gaplessPlayback: true, width: 160, height: 160,
                          errorBuilder: (context, error, stackTrace) {
                            return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 160, height: 160,);
                          },
                        ),
                      ),
                    ),
                    Expanded(
                      child: Row(
                          children: [
                            SizedBox(
                              width: 100,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left,'가맹점명', style: elementStyle)),
                                  Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left,'대표자명', style: elementStyle)),
                                  Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left,'매장 전화번호', style: elementStyle)),
                                  Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left,'휴대전화 번호', style: elementStyle)),
                                ],
                              ),
                            ),
                            Flexible(
                              fit: FlexFit.tight,
                              flex: 3,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, shopInfoModel.shopName ?? '', style: elementStyle)),
                                  Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, shopInfoModel.owner ?? '', style: elementStyle)),
                                  Container(alignment: Alignment.centerLeft,
                                    height: 40,
                                    child: Wrap(
                                      crossAxisAlignment: WrapCrossAlignment.center,
                                      children: [
                                        ISInput(
                                          width: 120,
                                          height: 36,
                                          value:  Utils.getPhoneNumFormat(shopInfoModel.telNo!, false),
                                          onChange: (v) {
                                            setState(() {
                                              shopInfoModel.telNo = v.toString();
                                            });
                                          },
                                        ),
                                        const SizedBox(width: 8,),
                                        ISButton(
                                          height: 40,
                                          onPressed: () async {
                                            var value = await showDialog(
                                                context: context,
                                                builder: (context) => FutureProgressDialog(ShopController.to.updateShopInfo('8', shopInfoModel.telNo.toString(), '', ''))
                                            );

                                            if (value == null) {
                                              ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                            }
                                            else {
                                              if (value == '00')
                                                ISAlert(context, title: '매장 전화번호 수정', content: '수정되었습니다.');
                                            }
                                          },
                                          child: const Text('변경', style: elementStyle),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, Utils.getPhoneNumFormat(shopInfoModel.mobile!, false) ?? '', style: elementStyle)),
                                ],
                              ),
                            ),
                          ]),
                    ),
                  ]
              ),
            ),

            ISLabelBarSub(
              title: '주소',
              body: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('[지번] ${shopInfoModel.addrJibun}', style: elementStyle),
                  Text('[도로명] ${shopInfoModel.addrRoad}', style: elementStyle),
                  Text('[상세주소] ${shopInfoModel.addrDetail}', style: elementStyle),
                ],
              ),
            ),

            ISLabelBarSub(
              title: '업종 카테고리',
              body: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(shopInfoModel.items!.replaceAll(', ', ' | '), style: elementStyle),
                ],
              ),
            ),
            ISLabelBarSub(
              title: '매장 유형',
              body: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (shopInfoModel.shopType!.contains('5') == true) _buildPanelContainer(child: const Text('배달가능', style: TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON))),
                  if (shopInfoModel.shopType!.contains('7') == true) _buildPanelContainer(child: const Text('포장가능', style: TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON))),
                  if (shopInfoModel.shopType!.contains('9') == true) _buildPanelContainer(child: const Text('예약가능', style: TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON))),
                ],
              ),
            ),
            if (showCategoryEnabled())
              ISLabelBarSub(
                title: '배달/포장 소요 시간',
                body: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('[배달] ${shopInfoModel.acceptState!.replaceAll(',', '분, ')}분', style: elementStyle),
                    Text('[포장] ${shopInfoModel.toGoAcceptState!.replaceAll(',', '분, ')}분', style: elementStyle),
                  ],
                ),
                trailing: ISButton(
                  child: const Text('변경'),
                  onPressed: () {
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => ShopDeliPackTimeEdit(sData: shopInfoModel),
                    ).then((value) async {
                      //if (value == true) {
                        await Future.delayed(const Duration(milliseconds: 500), () {
                          requestAPIData();
                        });
                      //}
                    });
                  },
                ),
              ),
            ISLabelBarSub(
              title: '결제 수단',
              body: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (shopInfoModel.appPayType!.contains('3') == true) _buildPanelContainer(child: const Text('앱결제', style: TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON))),
                    if (shopInfoModel.appPayType!.contains('1') == true) _buildPanelContainer(child: const Text('만나서 결제(현금)', style: TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON))),
                    if (shopInfoModel.appPayType!.contains('5') == true) _buildPanelContainer(child: const Text('만나서 결제(카드)', style: TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON))),
                  ],
                ),
              ),
              trailing: (showCategoryEnabled()) ? ISButton(
                child: const Text('변경', style: elementStyle),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => ShopPaymentGbnEdit(sData: shopInfoModel),
                  ).then((value) async {
                    //if (value == true) {
                      await Future.delayed(const Duration(milliseconds: 500), () {
                        requestAPIData();
                      });
                    //}
                  });
                },
              ) : const SizedBox.shrink(),
            ),
            if (showCategoryEnabled())
              ISLabelBarSub(
                title: '배달 안내',
                body: Container(
                  alignment: Alignment.centerLeft,
                  width: double.infinity,
                  child: Text(shopInfoModel.deliInfo!, style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                ),
                trailing: ISButton(
                  child: const Text('변경'),
                  onPressed: () {
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => ShopDeliInfoEdit(sData: shopInfoModel),
                    ).then((value) async {
                      //if (value == true) {
                        await Future.delayed(const Duration(milliseconds: 500), () {
                          requestAPIData();
                        });
                      //}
                    });
                  },
                ),
              ),
            const Divider(height: 1),
          ],
        )
    );
  }
  Widget _buildPanelContainer({Widget? child, double? height, Color? color}){
    return Container(
        alignment: Alignment.center,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(horizontal: 10),
        height: height ?? 34,
        //width: 120,
        decoration: BoxDecoration(
            color: color ?? Colors.grey.shade400,//const Color(0xff01CAFF),//
            borderRadius: BorderRadius.circular(6)
        ),
        child: child
    );
  }
}