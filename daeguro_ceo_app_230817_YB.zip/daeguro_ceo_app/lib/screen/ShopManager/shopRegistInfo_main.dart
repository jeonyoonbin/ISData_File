import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopRegistEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopRegistInfoModel.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopRegistInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const ShopRegistInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ShopRegistInfoMain> createState() => _ShopRegistInfoMainState();
}

class _ShopRegistInfoMainState extends State<ShopRegistInfoMain> {

  final ScrollController _scrollController = ScrollController();

  String? mMailAccount;
  String? mMailServiceName;
  String? mMailServiceType;

  ShopRegistInfoModel shopRegistInfoData = ShopRegistInfoModel();

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ShopController.to.getRegistInfo())
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
    }
    else {
      shopRegistInfoData.regNo = value['regNo'] as String;
      shopRegistInfoData.bussOwner = value['bussOwner'] as String;
      shopRegistInfoData.bussCon = value['bussCon'] as String;
      shopRegistInfoData.bussType = value['bussType'] as String;
      shopRegistInfoData.bussAddr = value['bussAddr'] as String;
      shopRegistInfoData.bussTaxType = value['bussTaxType'] as String;
      shopRegistInfoData.email = value['email'] as String;

      mMailAccount = shopRegistInfoData.email?.split('@').first;
      mMailServiceName = shopRegistInfoData.email?.split('@').last;

      mMailServiceType = getMailServiceType(shopRegistInfoData.email!);
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    mMailServiceType = ' ';

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    shopRegistInfoData = ShopRegistInfoModel();
    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    const TextStyle titleStyle = TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY);
    const TextStyle elementStyle = TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY);
    const EdgeInsetsGeometry elementPadding = EdgeInsets.only(left: 40, right: 16, top: 20, bottom: 20);

    return SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        children: [
          ISLabelBarSub(
            title: '사업자 등록 번호',
            titleStyle: titleStyle,
            bodyPadding: elementPadding,
            body: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(Utils.getStoreRegNumberFormat(shopRegistInfoData.regNo ?? '', false), textAlign: TextAlign.left,  style: elementStyle),
              ],
            ),

          ),
          ISLabelBarSub(
            title: '사업자명',
            titleStyle: titleStyle,
            bodyPadding: elementPadding,
            body: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(textAlign: TextAlign.left, shopRegistInfoData.bussOwner ?? '', style: elementStyle),
              ],
            ),

          ),
          ISLabelBarSub(
            title: '업태',
            titleStyle: titleStyle,
            bodyPadding: elementPadding,
            body: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(textAlign: TextAlign.left, shopRegistInfoData.bussCon ?? '', style: elementStyle),
              ],
            ),
          ),
          ISLabelBarSub(
            title: '업종',
            titleStyle: titleStyle,
            bodyPadding: elementPadding,
            body: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(textAlign: TextAlign.left, shopRegistInfoData.bussType ?? '', style: elementStyle),
              ],
            ),
          ),
          ISLabelBarSub(
            title: '사업자 주소',
            titleStyle: titleStyle,
            bodyPadding: elementPadding,
            body: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(textAlign: TextAlign.left, shopRegistInfoData.bussAddr ?? '', style: elementStyle),
              ],
            ),
          ),
          ISLabelBarSub(
            title: '사업자 유형',
            titleStyle: titleStyle,
            bodyPadding: elementPadding,
            body: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(textAlign: TextAlign.left, getBussTypeStr(shopRegistInfoData.bussTaxType!) ?? '', style: elementStyle),
              ],
            ),
          ),
          ISLabelBarSub(
            title: '이메일',
            titleStyle: titleStyle,
            bodyPadding: elementPadding,
            body: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(alignment: Alignment.centerLeft,
                    child: Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        ISInput(
                          width: 150,
                          //readOnly: (_type == ' ' || _type == '7') ? false : true,
                          value: mMailAccount,
                          onChange: (v) {
                            setState(() {
                              mMailAccount = v;
                            });
                          },
                        ),
                        Text(' @ ', style: elementStyle!),
                        if (mMailServiceType == '7')...[
                          ISInput(
                            width: 150,
                            readOnly: (mMailServiceType == '7') ? false : true,
                            value: mMailServiceName,
                            onChange: (v) {
                              if (mMailServiceType == '7'){
                                setState(() {
                                  mMailServiceName = v;
                                });
                              }
                            },
                          ),
                          const SizedBox(width: 8),
                        ],
                        ISSearchDropdown(
                          label: '선택하세요',
                          width: 150,
                          value: mMailServiceType,
                          onChange: (value) {
                            //if (mMailServiceType != ' ' && mMailServiceType != '7'){
                            setState(() {
                              mMailServiceType = value;
                              mMailServiceName = getMailServiceStr(value);
                              debugPrint('mMailServiceName:${mMailServiceName}');
                              //_query();
                            });
                            //}
                          },
                          item: [
                            ISOptionModel(value: ' ', label: '선택하세요'),
                            ISOptionModel(value: '1', label: 'naver.com'),
                            ISOptionModel(value: '2', label: 'hanmail.net'),
                            ISOptionModel(value: '3', label: 'daum.net'),
                            ISOptionModel(value: '4', label: 'nate.com'),
                            ISOptionModel(value: '5', label: 'hotmail.com'),
                            ISOptionModel(value: '6', label: 'gmail.com'),
                            ISOptionModel(value: '7', label: '직접입력'),
                          ].cast<ISOptionModel>(),
                        ),
                        const SizedBox(width: 8),
                        ISButton(
                          child: const Text('저장', style: elementStyle),
                          height: 46,
                          onPressed: () async {

                            if (mMailAccount == '' || mMailAccount == null || mMailServiceName == '' || mMailServiceName == null) {
                              ISAlert(context, title: '이메일 입력', content: '이메일 주소를 확인해주세요.');
                              return;
                            }

                            ShopRegistEditModel sendData = ShopRegistEditModel();
                            sendData.shopCd = AuthService.SHOPCD;
                            sendData.email = '${mMailAccount}@${mMailServiceName}';
                            sendData.modUcode = AuthService.uCode;
                            sendData.modName = AuthService.uName;

                            debugPrint('email:${sendData.email}');

                            var value = await showDialog(
                                context: context,
                                barrierColor: Colors.transparent,
                                builder: (context) => FutureProgressDialog(ShopController.to.updateRegistInfo(sendData.toJson()))
                            );

                            if (value == null) {
                              ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                            }
                            else {
                              if (value == '00')
                                ISAlert(context, title: '이메일 수정', content: '수정되었습니다.');
                            }
                          },
                        ),
                      ],
                    )
                )
              ],
            ),
          ),
          const SizedBox(height: 20,)
        ],
      ),
      // child: SizedBox(
      //   width: double.infinity,
      //   child: Column(
      //     crossAxisAlignment: CrossAxisAlignment.start,
      //     children: [
      //       Padding(
      //         padding: const EdgeInsets.symmetric(horizontal: 46.0),
      //         child: Row(
      //           children: [
      //             SizedBox(
      //               width: 170,
      //               child: Column(
      //                 crossAxisAlignment: CrossAxisAlignment.start,
      //                 mainAxisAlignment: MainAxisAlignment.center,
      //                 children: [
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left,'사업자등록번호', style: elementStyle,)),
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left,'사업자명', style: elementStyle)),
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left,'업태', style: elementStyle)),
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left,'업종', style: elementStyle)),
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left,'사업장 주소', style: elementStyle)),
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left,'사업자 유형', style: elementStyle)),
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left,'이메일', style: elementStyle)),
      //                 ],
      //               ),
      //             ),
      //             Flexible(
      //               fit: FlexFit.tight,
      //               flex: 3,
      //               child: Column(
      //                 crossAxisAlignment: CrossAxisAlignment.start,
      //                 mainAxisAlignment: MainAxisAlignment.center,
      //                 children: [
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, shopRegistInfoData.regNo ?? '', style: elementStyle)),
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, shopRegistInfoData.bussOwner ?? '', style: elementStyle)),
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, shopRegistInfoData.bussCon ?? '', style: elementStyle)),
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, shopRegistInfoData.bussType ?? '', style: elementStyle)),
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, shopRegistInfoData.bussAddr ?? '', style: elementStyle)),
      //                   Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, getBussTypeStr(shopRegistInfoData.bussTaxType!) ?? '', style: elementStyle)),
      //                   Container(alignment: Alignment.centerLeft,
      //                     height: 50,
      //                     child: Wrap(
      //                       crossAxisAlignment: WrapCrossAlignment.center,
      //                       children: [
      //                         ISInput(
      //                           width: 150,
      //                           //readOnly: (_type == ' ' || _type == '7') ? false : true,
      //                           value: mMailAccount,
      //                           onChange: (v) {
      //                               setState(() {
      //                                 mMailAccount = v;
      //                               });
      //                           },
      //                         ),
      //                         const Text(' @ ', style: elementStyle),
      //                         if (mMailServiceType == '7')...[
      //                           ISInput(
      //                             width: 150,
      //                             readOnly: (mMailServiceType == '7') ? false : true,
      //                             value: mMailServiceName,
      //                             onChange: (v) {
      //                               if (mMailServiceType == '7'){
      //                                 setState(() {
      //                                   mMailServiceName = v;
      //                                 });
      //                               }
      //                             },
      //                           ),
      //                           const SizedBox(width: 8),
      //                         ],
      //                         ISSearchDropdown(
      //                           label: '선택하세요',
      //                           width: 150,
      //                           value: mMailServiceType,
      //                           onChange: (value) {
      //                             //if (mMailServiceType != ' ' && mMailServiceType != '7'){
      //                               setState(() {
      //                                 mMailServiceType = value;
      //                                 mMailServiceName = getMailServiceStr(value);
      //                                 debugPrint('mMailServiceName:${mMailServiceName}');
      //                                 //_query();
      //                               });
      //                             //}
      //                           },
      //                           item: [
      //                             ISOptionModel(value: ' ', label: '선택하세요'),
      //                             ISOptionModel(value: '1', label: 'naver.com'),
      //                             ISOptionModel(value: '2', label: 'hanmail.net'),
      //                             ISOptionModel(value: '3', label: 'daum.net'),
      //                             ISOptionModel(value: '4', label: 'nate.com'),
      //                             ISOptionModel(value: '5', label: 'hotmail.com'),
      //                             ISOptionModel(value: '6', label: 'gmail.com'),
      //                             ISOptionModel(value: '7', label: '직접입력'),
      //                           ].cast<ISOptionModel>(),
      //                         ),
      //                         const SizedBox(width: 8),
      //                         ISButton(
      //                           child: const Text('저장', style: elementStyle),
      //                           height: 46,
      //                           onPressed: () async {
      //
      //                             if (mMailAccount == '' || mMailAccount == null || mMailServiceName == '' || mMailServiceName == null) {
      //                               ISAlert(context, title: '이메일 입력', content: '이메일 주소를 확인해주세요.');
      //                               return;
      //                             }
      //
      //                             ShopRegistEditModel sendData = ShopRegistEditModel();
      //                             sendData.shopCd = AuthService.SHOPCD;
      //                             sendData.email = '${mMailAccount}@${mMailServiceName}';
      //                             sendData.modUcode = AuthService.uCode;
      //                             sendData.modName = AuthService.uName;
      //
      //                             debugPrint('email:${sendData.email}');
      //
      //                             var value = await showDialog(
      //                                 context: context,
      //                                 builder: (context) => FutureProgressDialog(ShopController.to.updateRegistInfo(sendData.toJson()))
      //                             );
      //
      //                             if (value == null) {
      //                               ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
      //                             }
      //                             else {
      //                               if (value == '00')
      //                                 ISAlert(context, title: '이메일 수정', content: '수정되었습니다.');
      //                             }
      //                           },
      //                         ),
      //                       ],
      //                     ),
      //                   )
      //                 ],
      //               ),
      //             ),
      //           ]),
      //       ),
      //     ],
      //   ),
      // ),
    );
  }

  String getBussTypeStr(String type){
    String? tempStr = '';

    if (type == '1')         tempStr = '일반';
    else if (type == '3')    tempStr = '간이';
    else if (type == '5')    tempStr = '법인';
    else if (type == '7')    tempStr = '면세';
    else {
      return '';
    }

    return '${tempStr} 사업자';
  }

  String getMailServiceType(String email){
    if (email == null || email == ''){
      return ' ';
    }

    String emailLast = email.split('@').last;

    if (emailLast.contains('naver.com'))        {     return '1';     }
    else if (emailLast.contains('hanmail.net')) {     return '2';     }
    else if (emailLast.contains('daum.net'))    {     return '3';     }
    else if (emailLast.contains('nate.com'))    {     return '4';     }
    else if (emailLast.contains('hotmail.com')) {     return '5';     }
    else if (emailLast.contains('gmail.com'))   {     return '6';     }
    else                                        {     return '7';     }
  }

  String getMailServiceStr(String type){
    if (type == null || type == ''){
      return '';
    }

    if (type =='1')         {     return 'naver.com';       }
    else if (type =='2')    {     return 'hanmail.net';     }
    else if (type =='3')    {     return 'daum.net';        }
    else if (type =='4')    {     return 'nate.com';        }
    else if (type =='5')    {     return 'hotmail.com';     }
    else if (type =='6')    {     return 'gmail.com';       }
    else                    {     return '';                }
  }
}