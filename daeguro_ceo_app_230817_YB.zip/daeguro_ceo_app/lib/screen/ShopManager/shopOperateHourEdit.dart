import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateHourListModel.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopOperateHourEdit extends StatefulWidget {
  final ShopOperateHourListModel? sData;
  final List<ShopOperateHourListModel>? sListData;
  const ShopOperateHourEdit({Key? key, this.sData, this.sListData})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopOperateHourEditState();
  }
}

class ShopOperateHourEditState extends State<ShopOperateHourEdit> {
  ShopOperateHourListModel formData = ShopOperateHourListModel();

  DateTime? frStandTimeSelected;
  DateTime? toStandTimeSelected;

  List<ISOptionModel> selectDayList = [];

  String _dayGbn(String gbn) {
    if(gbn == '1')        {      return '일요일';    }
    else if (gbn == '2')  {      return '월요일';    }
    else if (gbn == '3')  {      return '화요일';    }
    else if (gbn == '4')  {      return '수요일';    }
    else if (gbn == '5')  {      return '목요일';    }
    else if (gbn == '6')  {      return '금요일';    }
    else                  {      return '토요일';    }
  }

  @override
  void dispose() {
    super.dispose();
    formData = ShopOperateHourListModel();
    selectDayList.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    formData = widget.sData!;

    if (formData.jobGbn == 'I'){
      DateTime currDateTime = DateTime.now();
      frStandTimeSelected = DateTime(currDateTime.year, currDateTime.month, currDateTime.day, 09, 00);
      toStandTimeSelected = DateTime(currDateTime.year, currDateTime.month, currDateTime.day, 23, 59);

      setTipDayTime();

      selectDayList.clear();
      if (widget.sListData == null || widget.sListData!.isEmpty){        
          for (int i = 1; i<7; i++){
            selectDayList.add(ISOptionModel(value: i.toString(), label: _dayGbn(i.toString())));
          }
          selectDayList.add(ISOptionModel(value: 7, label: '토요일'));
      }
      else{
        for (int i = 1; i < 8; i++){
          int retVal = widget.sListData!.indexWhere((element) => element.tipDay == i.toString());
          if (retVal == -1){
            selectDayList.add(ISOptionModel(value: i.toString(), label: _dayGbn(i.toString())));
          }
        }
        formData.tipDay = selectDayList.first.value.toString();
      }
    }
    else{
      DateTime currDateTime = DateTime.now();

      int tempHour = int.parse(formData.tipFrStand!.substring(0,2));
      int tempMin = int.parse(formData.tipFrStand!.substring(2,4));
      frStandTimeSelected = DateTime(currDateTime.year, currDateTime.month, currDateTime.day, tempHour, tempMin);

      tempHour = int.parse(formData.tipToStand!.substring(0,2));
      tempMin = int.parse(formData.tipToStand!.substring(2,4));
      toStandTimeSelected = DateTime(currDateTime.year, currDateTime.month, currDateTime.day, tempHour, tempMin);

      selectDayList.clear();
      selectDayList.add(ISOptionModel(value: formData.tipDay, label: _dayGbn(formData.tipDay!)));
    }

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('배달/포장 소요 시간', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12,),
                const Text('요일별 정기영업시간', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                // const Text('※ 중복 선택시, 최소 시간 및 최대 시간이 사용자 앱에 적용됩니다.', style: TextStyle(color: Colors.black54,fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                // const Text('   ex) 10분 ~ 120분', style: TextStyle(color: Colors.black54,fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                // const Text('※ 소요시간 미 선택시, POS 기본 설정 시간이 적용됩니다.', style: TextStyle(color: Colors.black54, fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                const SizedBox(height: 16),
                ISLabelBarSub(
                  title: '정기 영업 일시',
                  body: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const SizedBox(width: 110, child: Text('영업일', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                          const SizedBox(width: 8),
                          ISSearchDropdown(
                            label: '영업일',
                            value: formData.tipDay,
                            width: Responsive.isMobile(context) ? 170 : 200,
                            ignoring: (formData.jobGbn == 'I') ? false : true,
                            onChange: (value) {
                              setState(() {
                                formData.tipDay = value;
                              });
                            },
                            item: selectDayList
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                       Column(
                        children: [
                          Row(
                            children: [
                              const SizedBox(
                                  width: 110,
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 20.0),
                                    child: Text('영업 시작 시간', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                  )),
                              const SizedBox(width: 8,),
                              SizedBox(
                                width: Responsive.isMobile(context) ? 170 : 200,
                                child: fluentUI.TimePicker(
                                  header: '',
                                  selected: frStandTimeSelected,
                                  hourFormat: HourFormat.HH,
                                  minuteIncrement: 5,
                                  onChanged: (time) {
                                    frStandTimeSelected = time;
                                    setTipDayTime();

                                    setState(() {});
                                  },
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const SizedBox(
                                  width: 110,
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 20.0),
                                    child: Text('영업 종료 시간', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                  )),
                              const SizedBox(width: 8,),
                              SizedBox(
                                width: Responsive.isMobile(context) ? 170 : 200,
                                child: fluentUI.TimePicker(
                                  header: (formData.tipNextDay == 'Y') ? '[다음날]' : '',
                                  headerStyle: const TextStyle(color: Colors.lightBlueAccent, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                  selected: toStandTimeSelected,
                                  hourFormat: HourFormat.HH,
                                  minuteIncrement: 5,
                                  onChanged: (time) {
                                    toStandTimeSelected = time;
                                    setTipDayTime();

                                    setState(() {});
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      )
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              ISConfirm(context, '배달/포장 소요시간 변경', '소요 시간 정보를 변경합니다. \n\n계속 진행 하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  ShopOperateEditModel sendData = ShopOperateEditModel();
                  sendData.shopCd = AuthService.SHOPCD;
                  sendData.modUcode = AuthService.uCode;
                  sendData.modName = AuthService.uName;
                  sendData.jobGbn = '4';
                  sendData.day = formData.tipDay;
                  sendData.frTime = formData.tipFrStand;
                  sendData.toTime = formData.tipToStand;
                  sendData.nextDay = formData.tipNextDay;

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ShopController.to.updateOperateInfo(sendData.toJson()))
                  );

                  if (value == '00') {
                    Navigator.of(context).pop(true);
                  }
                  else {
                    ISAlert(context, content: '정상 등록 되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
                  }
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }

  setTipDayTime(){
    // 시작 시간
    String frTime = DateFormat('HH mm').format(frStandTimeSelected!);
    List<String> frTimeArr = frTime.split(' ');
    if (frTimeArr.isEmpty == false) {
      formData.tipFrStand = '${frTimeArr[0]}${frTimeArr[1]}';
    }

    // 종료 시간
    String toTime = DateFormat('HH mm').format(toStandTimeSelected!);
    List<String> toTimeArr = toTime.split(' ');
    if (toTimeArr.isEmpty == false) {
      formData.tipToStand = '${toTimeArr[0]}${toTimeArr[1]}';
    }

    if (int.parse(formData.tipFrStand!) > int.parse(formData.tipToStand!)){//if (frTimeArr[0] == 'PM' && toTimeArr[0] == 'AM'){
      formData.tipNextDay = 'Y';
    }
    else{
      formData.tipNextDay = 'N';
    }
  }
}


