import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopDeliPackTimeEdit extends StatefulWidget {
  final ShopInfoModel? sData;
  const ShopDeliPackTimeEdit({Key? key, this.sData})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopDeliPackTimeEditState();
  }
}

class ShopDeliPackTimeEditState extends State<ShopDeliPackTimeEdit> {
  ShopInfoModel formData = ShopInfoModel();

  List<String> deliTimeHourList = ['10', '20', '30', '40', '50', '60', '75', '90', '120', '150'];
  List<String> packTimeHourList = ['10', '20', '30', '40', '50', '60', '75', '90', '120', '150'];

  List<String>? selectDeliTimeHourList = <String>[];
  List<String>? selectPackTimeHourList = <String>[];

  bool _getCompareListData(String item, List<String> resList){
    bool temp = false;

    for (final element in resList!){
      if (element == item) {
        temp = true;
        break;
      }
    }
    return temp;
  }

  @override
  void dispose() {
    super.dispose();
    formData = ShopInfoModel();
    selectDeliTimeHourList?.clear();
    selectPackTimeHourList?.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    formData = widget.sData!;

    List<String> deliAcceptArr = formData.acceptState!.split(',');
    if (deliAcceptArr.isEmpty){
    }
    else{
      selectDeliTimeHourList!.clear();
      for (var element in deliAcceptArr) {
        if (_getCompareListData(element, deliTimeHourList)){
          selectDeliTimeHourList!.add(element);
        }
      }
    }

    List<String> toGoAcceptArr = formData.toGoAcceptState!.split(',');
    if (toGoAcceptArr.isEmpty){
    }
    else{
      selectPackTimeHourList!.clear();
      for (var element in toGoAcceptArr) {
        if (_getCompareListData(element, packTimeHourList)){
          selectPackTimeHourList!.add(element);
        }
      }
    }

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('배달/포장 소요 시간', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12,),
                const Text('배달/포장 소요시간', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                const Text('※ 중복 선택시, 최소 시간 및 최대 시간이 사용자 앱에 적용됩니다.', style: TextStyle(color: Colors.black54,fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                const Text('   ex) 10분 ~ 120분', style: TextStyle(color: Colors.black54,fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                const Text('※ 소요시간 미 선택시, POS 기본 설정 시간이 적용됩니다.', style: TextStyle(color: Colors.black54, fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                const SizedBox(height: 16),
                ISLabelBarSub(
                  title: '배달 소요 시간',
                  body: Flex(
                      direction: Axis.horizontal,
                      children: [
                        Expanded(
                          child: Wrap(
                            spacing: 16.0,
                            runSpacing: 4.0,
                            children: _buildDeliTimeCheckBox(),
                          ),
                        ),
                      ]
                  ),
                ),
                const Divider(height: 1),

                ISLabelBarSub(
                  title: '포장 소요 시간',
                  body: Flex(
                      direction: Axis.horizontal,
                      children: [
                        Expanded(
                          child: Wrap(
                            spacing: 16.0,
                            runSpacing: 4.0,
                            children: _buildPackTimeCheckBox(),
                          ),
                        ),
                      ]
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              ISConfirm(context, '배달/포장 소요시간 변경', '소요 시간 정보를 변경합니다. \n\n계속 진행 하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(requestAPIData())
                  );

                  if (value == '00') {
                    Navigator.of(context).pop(true);
                  }
                  else {
                    ISAlert(context, content: '정상 등록 되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
                  }
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }

  List<Widget> _buildDeliTimeCheckBox(){
    List<Widget> retWidget = [];

    deliTimeHourList.forEach((element) {
      retWidget.add(
        ISCheckbox(
            label: '${element}분',
            value: selectDeliTimeHourList!.contains(element),
            onChanged: (v) {
              setState(() {
                //selectDeliTimeHourList!.clear();
                selectDeliTimeHourList!.contains(element) ? selectDeliTimeHourList!.remove(element) : selectDeliTimeHourList!.add(element);
              });
            }
        ),
      );
    });

    return retWidget;
  }

  List<Widget> _buildPackTimeCheckBox(){
    List<Widget> retWidget = [];

    packTimeHourList.forEach((element) {
      retWidget.add(
        ISCheckbox(
            label: '${element}분',
            value: selectPackTimeHourList!.contains(element),
            onChanged: (v) {
              setState(() {
                //selectPackTimeHourList!.clear();
                selectPackTimeHourList!.contains(element) ? selectPackTimeHourList!.remove(element) : selectPackTimeHourList!.add(element);
              });
            }
        ),
      );
    });
    return retWidget;
  }

  Future<String?> requestDeliTimeData() async {
    String retValue = '';

    List<int> tempArr = [];
    selectDeliTimeHourList!.forEach((element) {
      tempArr.add(int.parse(element));
    });
    tempArr.sort();

    String sendData = tempArr.join(',');

    await ShopController.to.updateShopInfo('1', sendData.toString(), '', '').then((value) {
      retValue = value.toString();
    });

    return retValue;
  }

  Future<String?> requestPackTimeData() async {
    String retValue = '';

    List<int> tempArr = [];
    selectPackTimeHourList!.forEach((element) {
      tempArr.add(int.parse(element));
    });
    tempArr.sort();

    String sendData = tempArr.join(',');

    await ShopController.to.updateShopInfo('6', sendData.toString(), '', '').then((value) {
      retValue = value.toString();
    });

    return retValue;
  }

  Future<String?> requestAPIData() async {
    var ret1 = await requestDeliTimeData();
    var ret2 = await requestPackTimeData();

    debugPrint('ret1:${ret1}, ret2:${ret2}');

    if (ret1 != '00') {
      return ret1.toString();
    }

    if (ret2 != '00') {
      return ret2.toString();
    }

    return '00';
  }
}


