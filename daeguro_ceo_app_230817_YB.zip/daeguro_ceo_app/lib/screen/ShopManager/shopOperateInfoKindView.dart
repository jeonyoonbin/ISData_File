import 'dart:convert';
import 'dart:ui';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/RequestManager/requestShopInfoEditModel.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestManagerController.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class ShopOperateInfoKindView extends StatefulWidget {

  const ShopOperateInfoKindView({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopOperateInfoKindViewState();
  }
}

enum RadioUseGbn { useGbnY, useGbnN }

enum RadioUseGbnAccept { useGbnY, useGbnN }

class ShopOperateInfoKindViewState extends State<ShopOperateInfoKindView> {
  final ScrollController _scrollController = ScrollController();
  final ScrollController _scrollController2 = ScrollController();

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<dynamic> statusHistories = [];

  RadioUseGbn? _radioUseGbn;
  RadioUseGbnAccept? _radioAcceptGbn;

  bool chk1 = false;
  bool chk2 = false;
  bool chk3 = false;
  bool chk4 = false;
  bool chk5 = false;

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
    _scrollController2.dispose();
    statusHistories.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(RequestController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Container(
        alignment: Alignment.centerLeft,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 80 : 800,
              child: const ISLabelBarMain(
                  leading: Row(
                    children: [
                      const Icon(Icons.check_circle, color: Color(0xff01CAFF), size: 25),
                      SizedBox(width: 10),
                      Text('착한매장 신청', style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),),
                    ],
                  ),
                  underLine: true
              ),
            ),
            Container(
              width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 100 : 780,
              margin: const EdgeInsets.all(10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('"착한매장"은 공공배달앱의 저렴한 수수료로 시민들에게 혜택을 돌려드리고 있는 가맹점이며, 대구로 앱에서 "착한매장" 별도 필터 기능, 소개 영상 등의 가맹점 혜택을 드리고 있습니다.', maxLines: 5, style: TextStyle(fontSize: 13)),
                  const SizedBox(height: 20),
                  const Text('착한매장을 신청한 가맹점은 고객최종 결제시 전체 금액에서 1,000원 할인이 자동 적용되며, ', maxLines: 5, style: TextStyle(fontSize: 13)),
                  const Text('할인 금액은 가맹점 부담입니다.', maxLines: 5,style: TextStyle(fontSize: 13, fontWeight: FONT_BOLD)),
                  const Text('(착한매장 입점시 메뉴, 메뉴금액, 배달팁 수정은 불가합니다.)', maxLines: 5, style: TextStyle(fontSize: 13, fontWeight: FONT_BOLD)),
                  const SizedBox(height: 20),
                  const Text('※ 착한매장 자가진단', maxLines: 5, style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD)),
                  const SizedBox(height: 10),
                  const Text('- 우리 가게가 착한매장에 해당되는 내용을 점검해보세요.', maxLines: 5, style: TextStyle(fontSize: 13)),
                  const Text('- 해당 설문은 자가진단을 위한 단순 설문입니다.', maxLines: 5, style: TextStyle(fontSize: 13)),
                  const Text('- 실제 신청시 별도 검수가 진행되며, "단건배달" 플랫폼은 비교대상에서 제외됩니다.', style: TextStyle(fontSize: 13, fontWeight: FONT_BOLD), maxLines: 5),
                  const SizedBox(height: 15),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(width: 20, child: Text('1.', style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD))),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 120 : 760,
                              child: const Text('우리가게는 다른배달앱과 "대구로"의 메뉴 목록이 동일한가요?', maxLines: 5, style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD))),
                          SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 120 : 760, child: const Text('(Ex: 대표메뉴, 세트메뉴 등의 목록이 동일한지 여부)', maxLines: 5, style: TextStyle(fontSize: 13))),
                        ],
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Radio(
                          value: RadioUseGbn.useGbnY,
                          groupValue: _radioUseGbn,
                          onChanged: (v) async {
                            _radioUseGbn = v as RadioUseGbn?;

                            setState(() {});
                          }),
                      const Icon(Icons.circle_outlined, color: Colors.blueAccent),
                      const SizedBox(width: 20,),
                      Radio(
                          value: RadioUseGbn.useGbnN,
                          groupValue: _radioUseGbn,
                          onChanged: (v) async {
                            _radioUseGbn = v as RadioUseGbn?;

                            setState(() {});
                          }),
                      const Icon(Icons.close, color: Colors.redAccent)
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(width: 20, child: Text('2.', style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD))),
                      SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 120 : 760,
                          child: Responsive.isMobile(context) ? const Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('우리가게가 "대구로"에서 다른 배달앱보다 저렴한 항목은 무엇인가요?', maxLines: 5, style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD)),
                              Text('(중복 선택 가능)', maxLines: 5, style: TextStyle(fontSize: 13)),
                            ],
                          ) :const Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('우리가게가 "대구로"에서 다른 배달앱보다 저렴한 항목은 무엇인가요?', maxLines: 5, style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD)),
                              Text('(중복 선택 가능)', maxLines: 5, style: TextStyle(fontSize: 13)),
                            ],
                          )
                      )
                    ],
                  ),
                  Responsive.isMobile(context) ? ListView(
                    controller: _scrollController2,
                    shrinkWrap: true,
                    children: [
                      Row(
                        children: [
                          Checkbox(
                            value: chk1,
                            onChanged: (onChanged) {
                              chk1 = onChanged!;
                              setState(() {});
                            },
                          ),
                          const Text('메뉴금액'),
                          const SizedBox(width: 10,),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: chk2,
                            onChanged: (onChanged) {
                              chk2 = onChanged!;
                              setState(() {});
                            },
                          ),
                          const Text('배달팁'),
                          const SizedBox(width: 10,),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: chk3,
                            onChanged: (onChanged) {
                              chk3 = onChanged!;
                              setState(() {});
                            },
                          ),
                          const Text('가맹점쿠폰'),
                          const SizedBox(width: 10,),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: chk4,
                            onChanged: (onChanged) {
                              chk4 = onChanged!;
                              setState(() {});
                            },
                          ),
                          const Text('포장할인'),
                          const SizedBox(width: 10,),
                        ],
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: chk5,
                            onChanged: (onChanged) {
                              chk5 = onChanged!;
                              setState(() {});
                            },
                          ),
                          const Text('없음'),
                        ],
                      ),
                    ],
                  ) :
                  Wrap(
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      Checkbox(
                        value: chk1,
                        onChanged: (onChanged) {
                          chk1 = onChanged!;
                          setState(() {});
                        },
                      ),
                      const Text('메뉴금액'),
                      const SizedBox(width: 10,),
                      Checkbox(
                        value: chk2,
                        onChanged: (onChanged) {
                          chk2 = onChanged!;
                          setState(() {});
                        },
                      ),
                      const Text('배달팁'),
                      const SizedBox(width: 10,),
                      Checkbox(
                        value: chk3,
                        onChanged: (onChanged) {
                          chk3 = onChanged!;
                          setState(() {});
                        },
                      ),
                      const Text('가맹점쿠폰'),
                      const SizedBox(width: 10,),
                      Checkbox(
                        value: chk4,
                        onChanged: (onChanged) {
                          chk4 = onChanged!;
                          setState(() {});
                        },
                      ),
                      const Text('포장할인'),
                      const SizedBox(width: 10,),
                      Checkbox(
                        value: chk5,
                        onChanged: (onChanged) {
                          chk5 = onChanged!;
                          setState(() {});
                        },
                      ),
                      const Text('없음'),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(width: 20, child: Text('3.', style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD))),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 120 : 760,
                              child: const Text('착한매장 입점 후 최종 결제금액에서 고객에게 1,000원 할인해주는 것에 동의하시나요?', maxLines: 5, style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD))),
                          SizedBox(width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width - 120 : 760, child: const Text('(*착한매장 신청 시 모든 운영조건은 가장 저렴한 배달앱 기준으로 동일하게 수정됩니다.)', maxLines: 5, style: TextStyle(fontSize: 13, color: Colors.redAccent))),
                        ],
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Radio(
                          value: RadioUseGbnAccept.useGbnY,
                          groupValue: _radioAcceptGbn,
                          onChanged: (v) async {
                            _radioAcceptGbn = v as RadioUseGbnAccept?;

                            setState(() {});
                          }),
                      const Text('동의'),
                      const SizedBox(width: 20,),
                      Radio(
                          value: RadioUseGbnAccept.useGbnN,
                          groupValue: _radioAcceptGbn,
                          onChanged: (v) async {
                            _radioAcceptGbn = v as RadioUseGbnAccept?;

                            setState(() {});
                          }),
                      const Text('미동의'),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );

    var result = Scaffold(
      body: SingleChildScrollView(
        controller: _scrollController,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            form,
            SizedBox(height: 28),
            Row(
              children: [
                Expanded(flex: 1, child: InkWell(child: Container(height: 50, color: Colors.grey,
                    child: Center(child: Text('취소', style: TextStyle(color: Colors.white, fontSize: 18)))), onTap: (){
                  Navigator.of(context).pop(false);
                })),
                Expanded(flex: 1, child: InkWell(child: Container(height: 50, color: Color(0xff01CAFF),
                    child: Center(child: Text('신청하기', style: TextStyle(color: Colors.white, fontSize: 18)))), onTap: () async {
                  List<dynamic> _chkData = [];

                  if(chk1 == true) {
                    _chkData.add('1');
                  }

                  if(chk2 == true) {
                    _chkData.add('2');
                  }

                  if(chk3 == true) {
                    _chkData.add('3');
                  }

                  if(chk4 == true) {
                    _chkData.add('4');
                  }

                  if(chk5 == true) {
                    _chkData.add('5');
                  }

                  String _serviceData = _chkData.join(',');
                  String _useYn;
                  String _acceptYn;

                  if(_radioUseGbn == RadioUseGbn.useGbnY) {
                    _useYn = 'Y';
                  } else if (_radioUseGbn == RadioUseGbn.useGbnN){
                    _useYn = 'N';
                  } else {
                    _useYn = '';
                  }

                  if(_radioAcceptGbn == RadioUseGbnAccept.useGbnY) {
                    _acceptYn = 'Y';
                  } else if (_radioAcceptGbn == RadioUseGbnAccept.useGbnN){
                    _acceptYn = 'N';
                  } else {
                    _acceptYn = '';
                  }

                  if(_useYn == '' || _acceptYn == '' || _serviceData == '') {
                    ISAlert(context, content: '체크되지 않은 항목이 있습니다. 착한매장을 신청하시려면 모든 항목에 체크를 해주세요.');
                    return;
                  }

                  if(_acceptYn != 'Y') {
                    ISAlert(context, content: '1,000원 할인에 동의하지 않으셨습니다. 착한매장을 신청하시려면 할인정책에 동의해주세요.\n\n*착한매장을 신청한 가맹점은 고객 최종 결제시 전체금액에서 1,000원 할인이 자동 적용되며, 할인금액은 가맹점 부담입니다.');
                    return;
                  }

                  // var _jsonData;
                  //
                  // _jsonData = {
                  //   '"first"': '"' + _useYn + '"',
                  //   '"second"': '"' + _serviceData + '"',
                  //   '"third"': '"' + _acceptYn + '"'
                  // };

                  RequestShopInfoEditModel sendData = RequestShopInfoEditModel();
                  sendData.shopCd = AuthService.SHOPCD;
                  sendData.status = '10';
                  sendData.serviceGbn = '600';
                  sendData.first = '${_useYn}';
                  sendData.second = '${_serviceData}';
                  sendData.third = '${_acceptYn}';
                  sendData.uCode = AuthService.uCode;
                  sendData.uName = AuthService.uName;
                  //sendData.serviceData = _jsonData.toString();

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(RequestController.to.setRequireServiceV2(sendData, [])));

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                  }
                  else {
                    Navigator.of(context).pop(true);
                  }
                })),
              ],
            ),
          ],
        )
      ),
    );

    return SizedBox(
      width: Responsive.isMobile(context) ? MediaQuery.of(context).size.width : 800,
      height: 580,
      child: result,
    );
  }
}
