import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';

class AccountController extends GetxController{
  static AccountController get to => Get.find();

  int total_count = 0;
  int total_page = 0;
  int remainAmt = 0;

  int totaldeposit = 0;
  int totalwithdraw = 0;
  int moneySum = 0;

  int salesAmt = 0;
  int settlementAmt = 0;

  String mobile = '';

  String msg = '';

  Future<dynamic> getAccountInfo() async {
    dynamic qData;

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPACCOUNTINFO}?shopCd=${AuthService.SHOPCD}');

    //if (response.data['code'] == '00') {
      qData = response.data['data'];
    // }
    // else {
    //     msg = response.data['msg'];
    //    return null;
    // }

    return qData;
  }

  Future<dynamic> getWithdrawInfo() async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_WITHDRAWINFO}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    }
    else {
      msg = response.data['msg'];
      return null;
    }

    return qData;
  }

  Future<dynamic> getShopOrderList(String startdate, String enddate, String page) async {
    dynamic qData;

    //debugPrint('getShopOrderList startdate:${startdate}, enddate:${enddate}, page:${page}');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPORDERLIST}?shopCd=${AuthService.SHOPCD}&dateBegin=${startdate}&dateEnd=${enddate}&rows=10&page=${page}');

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['totalCnt'].toString());
      total_page = int.parse(response.data['pageCnt'].toString());

      //debugPrint('totalCnt:${total_count}, total_page:${total_page}');

      qData = response.data['data'];


    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getShopOrderDetail(String jobGbn, String orderNo) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPORDER_DETAIL}?shopCd=${AuthService.SHOPCD}&jobGbn=$jobGbn&orderNo=$orderNo');

    if (response.data['code'] == '00') {

      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getShopAccountHistoryList(String packOrderYn, String appOrderGbn, String payGbn, String chargeGbn, String viewGbn, String startdate, String enddate, String page) async {
    dynamic qData;

    //debugPrint('startdate:${startdate}, enddate:${enddate}, page:${page}');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPACCOUNTHISTORYLIST}?jobGbn=1001&shopCd=${AuthService.SHOPCD}&packOrderYn=${packOrderYn}&appOrderGbn=${appOrderGbn}&payGbn=${payGbn}&chargeGbn=${chargeGbn}&viewGbn=${viewGbn}&frDate=${startdate}&toDate=${enddate}&rows=10&page=${page}');

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['totalCnt'].toString());
      total_page = int.parse(response.data['pageCnt'].toString());
      remainAmt = int.parse(response.data['remainAmt'].toString());

      totaldeposit = int.parse(response.data['totaldeposit'].toString());
      totalwithdraw = int.parse(response.data['totalwithdraw'].toString());
      moneySum = int.parse(response.data['moneySum'].toString());

      //debugPrint('totalCnt:${total_count}, total_page:${total_page}');

      qData = response.data['data'];


    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getShopAccountHistoryMallList(String startdate, String enddate, String page) async {
    dynamic qData;

    //debugPrint('startdate:${startdate}, enddate:${enddate}, page:${page}');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPACCOUNTHISTORYLIST}?jobGbn=1002&shopCd=${AuthService.SHOPCD}&packOrderYn=%&appOrderGbn=%&payGbn=%&chargeGbn=%&frDate=${startdate}&toDate=${enddate}&rows=10&page=${page}');

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['totalCnt'].toString());
      total_page = int.parse(response.data['pageCnt'].toString());
      remainAmt = int.parse(response.data['remainAmt'].toString());

      totaldeposit = int.parse(response.data['totaldeposit'].toString());
      totalwithdraw = int.parse(response.data['totalwithdraw'].toString());

      qData = response.data['data'];


    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getShopAccountHistoryMallDetail(String frDate) async {
    List<dynamic> qDataAddrDongList = [];

    qDataAddrDongList.clear();

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPACCOUNTHISTORYMALL_DETAIL}?shopCd=${AuthService.SHOPCD}&frDate=${frDate}');

    if (response.data['code'] == '00') {
      qDataAddrDongList.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qDataAddrDongList;
  }



  Future<dynamic> getShopAccountSaleList(String viewGbn, String startdate, String enddate, String page) async {
    dynamic qData;

    debugPrint('startdate:${startdate}, enddate:${enddate}, page:${page}');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPACCOUNTSALELIST}?shopCd=${AuthService.SHOPCD}&frDate=${startdate}&toDate=${enddate}&viewGbn=${viewGbn}&rows=10&page=${page}');

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['totalCnt'].toString());
      total_page = int.parse(response.data['pageCnt'].toString());
      if(response.data['salesAmt'] != 'null'){
      salesAmt = int.parse(response.data['salesAmt'].toString());
      }
      if(response.data['settlementAmt'] != 'null'){
      settlementAmt = int.parse(response.data['settlementAmt'].toString());
      }
      debugPrint('totalCnt:${total_count}, total_page:${total_page}');

      qData = response.data['data'];

    } else {
      return null;
    }

    return qData;
  }

  // jobGbn: 1(매출), 3(매입), 5(엑셀)
  Future<dynamic> getShopAccountVATReport(String jobGbn, String viewGbn, String meetPayment, String receiptProcessing, String startdate, String enddate) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPACCOUNTVATINFO}?jobGbn=${jobGbn}&shopCd=${AuthService.SHOPCD}&meetYn=${meetPayment}&viewGbn=${viewGbn}&frDate=${startdate}&toDate=${enddate}&cashIngYn=${receiptProcessing}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> shopTransSMSCheck(String jobGbn, String? smsConfNo) async {

    final response = await DioClient().post('${ServerInfo.RESTURL_SHOPTRANSSMSCHECK}?jobGbn=$jobGbn&shopCd=${AuthService.SHOPCD}&smsConfNo=$smsConfNo');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else {
        mobile = response.data['mobile'].toString();
      return response.data['code'];
    }
  }

  Future<dynamic> getShopAutoWithdrawSet() async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPAUTOWITHDRAWSET}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> setAutoWithdrawSet(String shopCd, String cycle, String date, String day, String hour, String minute, String amt, String allYn, String modUcode, String modName, String useYn) async {
    final response = await DioClient().put('${ServerInfo.RESTURL_SHOPAUTOWITHDRAWSET_SET}?shopCd=$shopCd&cycle=$cycle&date=$date&day=$day&hour=$hour&minute=$minute&amt=$amt&allYn=$allYn&modUcode=$modUcode&modName=$modName&useYn=$useYn');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
    }
  }

  Future<dynamic> setShopInfoTran(dynamic data) async {

    final response = await DioClient().post('${ServerInfo.RESTURL_SHOPINFOTRAN_SET}', data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else {
      return response.data['code'];
    }
   }
}