import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/AccountManager/withdrawModel.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:crypto/crypto.dart' as CryptoPack;

class SMSCheck extends StatefulWidget {
  String? remainAmt;
  SMSCheck({Key? key, this.remainAmt}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return SMSCheckState();
  }
}

class SMSCheckState extends State<SMSCheck> {
  WithdrawModel data = WithdrawModel();

  String chk = '';
  String smsConfNo = '';
  String btnText = '인증번호 요청';
  String remainAmt = '';
  String selectedType = '';
  String amt = '';
  var shopPass;

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(AccountController.to.getShopAutoWithdrawSet())
    );

    if(value['shopCd'] == null){
      data.shopCd = AuthService.SHOPCD;
      data.withdrawCycle = 'D';
      data.withdrawDate = '1';
      data.withdrawDay = '1';
      data.withdrawHour = '08';
      data.withdrawMinute = '00';
      data.withdrawAmt = '';
      data.fullWithdrawalYn = 'N';
    }else{
      data.shopCd = value['shopCd'].toString();
      data.withdrawCycle = value['withdrawCycle'].toString();
      data.withdrawDate = value['withdrawDate'].toString();
      data.withdrawDay = value['withdrawDay'].toString();
      data.withdrawHour = value['withdrawHour'].toString();
      data.withdrawMinute = value['withdrawMinute'].toString();
      data.withdrawAmt = value['withdrawAmt'].toString();
      data.fullWithdrawalYn = value['fullWithdrawalYn'].toString();
    }
    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    data = WithdrawModel();
  }

  @override
  void initState() {
    super.initState();
    Get.put(AccountController());
    remainAmt = widget.remainAmt ?? '';

    WidgetsBinding.instance!.addPostFrameCallback((_) {
      requestAPIData();
    });
  }
  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    return widget.remainAmt != null ? SelfWithdraw(context) : AutoWithdraw(context);
  }

  Widget SelfWithdraw(fluentUI.BuildContext context) {
    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 433.0, maxHeight: 720),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(btnText == '인증번호 요청' ? 'SMS 문자 인증' : '인증 절차', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: SingleChildScrollView(
          child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 15),
              child: btnText != '출금요청' ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('- 본인 확인을 위해 SMS 인증이 필요합니다.', style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL),),
                  const SizedBox(height: 10,),
                  const Text('- 인증 요청 버튼을 눌러 수신 되는 인증번호를 입력해주세요.', style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL),),
                  chk == 'Y' ? Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 5, top: 10, right: 10),
                        child: ISInput(
                          width: 200,
                          height: 30,
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                          value: smsConfNo,
                          onChange: (v) {
                            setState(() {
                              smsConfNo = v;
                            });
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: ISButton(
                          height: 38,
                          onPressed: () async {
                            var value = await showDialog(
                                context: context,
                                builder: (context) => FutureProgressDialog(AccountController.to.shopTransSMSCheck('3', smsConfNo))
                            );
                            if (value == '00') {
                              setState(() {
                                btnText = '출금요청';
                              });
                            }
                            else{
                              ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value}');
                              return;
                            }
                          },
                          child: const Text('제출', style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL),),
                        ),
                      ),
                    ],
                  ) : Container(),
                ],
              ) : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('출금 가능 금액', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  Row(
                    children: [
                      Expanded(
                        child: ISInput(
                          readOnly: true,
                          value: Utils.getCashComma(remainAmt!),
                          textAlign: TextAlign.end,
                          suffixText: '원',
                          context: context,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10,),
                  Text('찾으실 금액', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: ISToggleButtons(
                      [
                        ISOptionModel(value: '1000', label: '+1만'),
                        ISOptionModel(value: '1001', label: '+3만'),
                        ISOptionModel(value: '1002', label: '+5만'),
                        ISOptionModel(value: '1003', label: '+10만'),
                        ISOptionModel(value: '1004', label: '+20만'),
                        ISOptionModel(value: '1005', label: '+30만'),
                        ISOptionModel(value: '1006', label: '+50만'),
                        ISOptionModel(value: '1007', label: '+100만'),
                      ],
                      buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 8)) : 43,
                      defaultValue: selectedType,
                      afterOnPress: (v) {
                        setState(() {
                          if (v == '1000'){
                            if(int.parse(remainAmt!) - 10000 > 0){
                              data.withdrawAmt = '10000';
                            }else{
                              ISAlert(context, content: '출금 가능 금액을 초과하였습니다.\n금액을 다시 확인 해 주시기 바랍니다.');
                              return;
                            }
                          }
                          else if (v == '1001'){
                            if(int.parse(remainAmt!) - 30000 > 0){
                              data.withdrawAmt = '30000';
                            }else{
                              ISAlert(context, content: '출금 가능 금액을 초과하였습니다.\n금액을 다시 확인 해 주시기 바랍니다.');
                              return;
                            }
                          }
                          else if (v == '1002'){
                            if(int.parse(remainAmt!) - 50000 > 0){
                              data.withdrawAmt = '50000';
                            }else{
                              ISAlert(context, content: '출금 가능 금액을 초과하였습니다.\n금액을 다시 확인 해 주시기 바랍니다.');
                              return;
                            }
                          }
                          else if (v == '1003'){
                            if(int.parse(remainAmt!) - 100000 > 0){
                              data.withdrawAmt = '100000';
                            }else{
                              ISAlert(context, content: '출금 가능 금액을 초과하였습니다.\n금액을 다시 확인 해 주시기 바랍니다.');
                              return;
                            }
                          }
                          else if (v == '1004'){
                            if(int.parse(remainAmt!) - 200000 > 0){
                              data.withdrawAmt = '200000';
                            }else{
                              ISAlert(context, content: '출금 가능 금액을 초과하였습니다.\n금액을 다시 확인 해 주시기 바랍니다.');
                              return;
                            }
                          }
                          else if (v == '1005'){
                            if(int.parse(remainAmt!) - 300000 > 0){
                              data.withdrawAmt = '300000';
                            }else{
                              ISAlert(context, content: '출금 가능 금액을 초과하였습니다.\n금액을 다시 확인 해 주시기 바랍니다.');

                              return;
                            }
                          }
                          else if (v == '1006'){
                            if(int.parse(remainAmt!) - 500000 > 0){
                              data.withdrawAmt = '500000';
                            }else{
                              ISAlert(context, content: '출금 가능 금액을 초과하였습니다.\n금액을 다시 확인 해 주시기 바랍니다.');
                              return;
                            }
                          }
                          else if (v == '1007'){
                            if(int.parse(remainAmt!) - 1000000 > 0){
                              data.withdrawAmt = '1000000';
                            }else{
                              ISAlert(context, content: '출금 가능 금액을 초과하였습니다.\n금액을 다시 확인 해 주시기 바랍니다.');
                              return;
                            }
                          }
                        });
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: ISButton(
                      child: const Text('전액 출금'),
                      onPressed: () {
                        setState(() {
                          amt = remainAmt;
                          data.withdrawAmt = remainAmt;
                        });
                      },
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: ISInput(
                          value: amt != '' ? Utils.getCashComma(amt) : amt,
                          textAlign: TextAlign.end,
                          label: '직접입력',
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                          suffixText: amt != '' ? '원' : '',
                          onChange: (v) {
                            if(int.parse(v) > int.parse(remainAmt!)){
                              ISAlert(context, content: '출금 가능 금액을 초과하였습니다.\n금액을 다시 확인 해 주시기 바랍니다.');
                              setState(() {
                                amt = '';
                              });
                            }else{
                              setState(() {
                                amt = v;
                                data.withdrawAmt = v;
                              });
                            }

                          },
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 10,),
                  const Text('로그인 비밀번호', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  Row(
                    children: [
                      Expanded(
                        child: ISInput(
                          value: '',
                          textAlign: TextAlign.end,
                          obscureText: true,
                          onChange: (v) {
                            var password = utf8.encode(v);
                            data.shopPass = CryptoPack.sha256.convert(password).toString();
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10,),
                ],
              )
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: ButtonStyle(
              minimumSize: MaterialStateProperty.all(const Size(60, 70)), //Size.fromHeight(60),
              backgroundColor: const MaterialStatePropertyAll(Color(0xff333333)),
              shape: const MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.only(bottomLeft: Radius.circular(11.0)) //.circular(4.0)
              )),
            ),
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: ButtonStyle(
              minimumSize: MaterialStateProperty.all(const Size(60, 70)), //Size.fromHeight(60),
              backgroundColor: const MaterialStatePropertyAll(Color(0xff01CAFF)),
              shape: const MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.only(bottomRight: Radius.circular(11.0))
              )),
            ),
            onPressed: () async {
              if(btnText != '출금요청'){
                var value = await showDialog(
                    context: context,
                    builder: (context) => FutureProgressDialog(AccountController.to.shopTransSMSCheck('1', ''))
                );
                if (value == '00') {
                  ISAlert(context, content: '사장님 휴대전화로 인증번호가 발송 되었습니다.');
                  setState(() {
                    chk = 'Y';
                  });
                }
                else{
                  ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value}');
                  return;
                }
              }else{
                data.shopCd = AuthService.SHOPCD;
                data.mobile = AccountController.to.mobile;
                print(data.mobile);
                var value = await showDialog(
                    context: context,
                    builder: (context) => FutureProgressDialog(AccountController.to.setShopInfoTran(data.toJson()))
                );
                if (value == null) {
                  ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                  return;
                }
                else {
                  if (value == '00') {
                    Navigator.of(context).pop(true);
                  }
                  else{
                    ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                    return;
                  }
                }
              }

            },
            child: Text(btnText, style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }


  Widget AutoWithdraw(fluentUI.BuildContext context) {
    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 433.0, maxHeight: 720),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(btnText == '인증번호 요청' ? 'SMS 문자 인증' : '자동 출금 설정', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: SingleChildScrollView(
          child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 15),
              child: btnText != '저장' ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('- 본인 확인을 위해 SMS 인증이 필요합니다.', style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL),),
                  const SizedBox(height: 10,),
                  const Text('- 인증 요청 버튼을 눌러 수신 되는 인증번호를 입력해주세요.', style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL),),
                  chk == 'Y' ? Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 5, top: 10, right: 10),
                        child: ISInput(
                          width: 200,
                          height: 30,
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                          value: smsConfNo,
                          onChange: (v) {
                            setState(() {
                              smsConfNo = v;
                            });
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: ISButton(
                          height: 38,
                          onPressed: () async {
                            var value = await showDialog(
                                context: context,
                                builder: (context) => FutureProgressDialog(AccountController.to.shopTransSMSCheck('3', smsConfNo))
                            );
                            if (value == '00') {
                              setState(() {
                                btnText = '저장';
                              });
                            }
                            else{
                              ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value}');
                              return;
                            }
                          },
                          child: const Text('제출', style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL),),
                        ),
                      ),
                    ],
                  ) : Container(),
                ],
              ) : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      Text('자동 출금일', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                      Responsive.isMobile(context) ? Container() : Text('  설정 된 출금날짜가 해당 달에 없을 경우 말일에 출금됩니다.', style: TextStyle(color: Colors.grey, fontSize: 11) ,
                      ),
                    ],
                  ),
                  Responsive.isMobile(context) ? Text('설정 된 출금날짜가 해당 달에 없을 경우 말일에 출금됩니다.', style: TextStyle(color: Colors.grey, fontSize: 11)) : Container(),
                  Row(
                    children: [
                      Material(
                        child: Container(
                          padding: const EdgeInsets.only(top: 10, right: 10),
                          child: ISSearchDropdown(
                            width: 80,
                            label: '출금일',
                            value: data.withdrawCycle ?? 'D',
                            onChange: (value) {
                              setState(() {
                                data.withdrawCycle = value;
                                data.withdrawDate = '1';
                                data.withdrawDay = '1';
                                data.withdrawHour = '08';
                                data.withdrawMinute = '00';
                              });
                            },
                            item: [
                              ISOptionModel(value: 'D', label: '매일'),
                              ISOptionModel(value: 'W', label: '매주'),
                              ISOptionModel(value: 'M', label: '매달'),
                            ].cast<ISOptionModel>(),
                          ),
                        ),
                      ),
                      Visibility(
                        visible: data.withdrawCycle == 'W' ? true : false,
                        child: Material(
                          child: Container(
                            padding: const EdgeInsets.only(top: 10, right: 10),
                            child: ISSearchDropdown(
                              width: 80,
                              label: '출금일',
                              value: data.withdrawDay,
                              onChange: (value) {
                                setState(() {
                                  data.withdrawDay = value;
                                });
                              },
                              item: [
                                ISOptionModel(value: '1', label: '일요일'),
                                ISOptionModel(value: '2', label: '월요일'),
                                ISOptionModel(value: '3', label: '화요일'),
                                ISOptionModel(value: '4', label: '수요일'),
                                ISOptionModel(value: '5', label: '목요일'),
                                ISOptionModel(value: '6', label: '금요일'),
                                ISOptionModel(value: '7', label: '토요일'),
                              ].cast<ISOptionModel>(),
                            ),
                          ),
                        ),
                      ),
                      Visibility(
                        visible: data.withdrawCycle == 'M' ? true : false,
                        child: Material(
                          child: Container(
                            padding: const EdgeInsets.only(top: 10, right: 10),
                            child: ISSearchDropdown(
                              width: 80,
                              label: '출금일',
                              value: data.withdrawDate,
                              onChange: (value) {
                                setState(() {
                                  data.withdrawDate = value;
                                });
                              },
                              item: List<ISOptionModel>.generate(31, (index) => ISOptionModel(value: (index+1).toString(), label: '${index+1}일')),

                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Material(
                        child: Container(
                          padding: const EdgeInsets.only(top: 10),
                          child: ISSearchDropdown(
                            width: 80,
                            label: '시간',
                            value: data.withdrawHour,
                            onChange: (value) {
                              setState(() {
                                data.withdrawHour = value;
                              });
                            },
                            item: [
                              ISOptionModel(value: '08', label: '08'),
                              ISOptionModel(value: '09', label: '09'),
                              ISOptionModel(value: '10', label: '10'),
                            ].cast<ISOptionModel>(),
                          ),
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(left: 3, right: 5, top: 10),
                        child: Text('시'),
                      ),
                      Material(
                        child: Container(
                          padding: const EdgeInsets.only(top: 10),
                          child: ISSearchDropdown(
                              width: 80,
                              label: '분',
                              value: data.withdrawMinute,
                              onChange: (value) {
                                setState(() {
                                  data.withdrawMinute = value;
                                });
                              },
                              item: [
                                ISOptionModel(value: '00', label: '00'),
                                ISOptionModel(value: '30', label: '30'),
                              ]
                          ),
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(left: 3, top: 10),
                        child: Text('분'),
                      ),
                    ],
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 5),
                    child: Text('※ 출금 가능 시간은 오전 08:30 ~ 10:00 까지 설정 가능합니다.', style: TextStyle(color: Colors.red, fontSize: 11),),
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      Text('출금 금액', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                      Responsive.isMobile(context) ? Container() : Text('  출금금액은 입점지원금과 이체수수료가 제외된 금액입니다.', style: TextStyle(color: Colors.grey, fontSize: 11),
                      ),
                    ],
                  ),
                  Responsive.isMobile(context) ? Text('출금금액은 입점지원금과 이체수수료가 제외된 금액입니다.', style: TextStyle(color: Colors.grey, fontSize: 11)) : Container(),
                  ISCheckbox(label: '전액 출금', value: data.fullWithdrawalYn == 'Y' ? true : false,  onChanged: (v) {
                    setState(() {
                      if(v == true){
                        data.fullWithdrawalYn = 'Y';
                        data.withdrawAmt = '0';
                      }else{
                        data.fullWithdrawalYn = 'N';

                      }
                    });
                  }),
                  ISInput(
                    value: data.withdrawAmt == '0' || data.withdrawAmt == null ? '' : Utils.getCashComma(data.withdrawAmt!),
                    textAlign: TextAlign.end,
                    label: '직접입력',
                    readOnly: data.fullWithdrawalYn == 'Y' ? true : false,
                    keyboardType: TextInputType.number,
                    inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                    suffixText: data.withdrawAmt != '0' && data.withdrawAmt != null ? '원' : '',
                    onChange: (v) {
                      setState(() {
                        data.withdrawAmt = v;
                      });
                    },
                  ),
                  const Text('※ 자동이체 수수료는 건당 200원이 발생합니다.', style: TextStyle(color: Colors.red, fontSize: 11),),
                  const Text('ex)적립금 10,000원 → 10,200원이 차감됩니다.', style: TextStyle(color: Colors.grey, fontSize: 11),),
                  const SizedBox(height: 10,),
                ],
              )
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: ButtonStyle(
              minimumSize: MaterialStateProperty.all(const Size(60, 70)), //Size.fromHeight(60),
              backgroundColor: const MaterialStatePropertyAll(Color(0xff333333)),
              shape: const MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.only(bottomLeft: Radius.circular(11.0)) //.circular(4.0)
              )),
            ),
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: ButtonStyle(
              minimumSize: MaterialStateProperty.all(const Size(60, 70)), //Size.fromHeight(60),
              backgroundColor: const MaterialStatePropertyAll(Color(0xff01CAFF)),
              shape: const MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.only(bottomRight: Radius.circular(11.0))
              )),
            ),
            onPressed: () async {
              if(btnText != '저장'){
                var value = await showDialog(
                    context: context,
                    builder: (context) => FutureProgressDialog(AccountController.to.shopTransSMSCheck('1', ''))
                );
                if (value == '00') {
                  ISAlert(context, content: '사장님 휴대전화로 인증번호가 발송 되었습니다.');
                  setState(() {
                    chk = 'Y';
                  });
                }
                else{
                  ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value}');
                  return;
                }
              }else{
                if(data.withdrawHour == '08' && data.withdrawMinute == '00'){
                  ISAlert(context, content: '출금 가능 시간은 오전 08:30 ~ 10:00 까지 설정 가능합니다.');
                  return;
                }
                if(data.withdrawHour == '10' && data.withdrawMinute == '30'){
                  ISAlert(context, content: '출금 가능 시간은 오전 08:30 ~ 10:00 까지 설정 가능합니다.');
                  return;
                }
                data.modUcode = AuthService.uCode;
                data.modName = AuthService.uName;
                data.useYn = 'Y';
                if(data.withdrawAmt == null || data.withdrawAmt == ''){
                  data.withdrawAmt = '0';
                }

                var value = await showDialog(
                    context: context,
                    builder: (context) => FutureProgressDialog(AccountController.to.setAutoWithdrawSet(data.shopCd!, data.withdrawCycle!,data.withdrawDate!, data.withdrawDay!, data.withdrawHour!, data.withdrawMinute!, data.withdrawAmt!, data.fullWithdrawalYn!, data.modUcode!, data.modName!, data.useYn!))
                );

                if (value == '00') {
                  Navigator.of(context).pop(true);
                }
                else{
                  ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                  return;
                }
              }
            },
            child: Text(btnText, style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}
