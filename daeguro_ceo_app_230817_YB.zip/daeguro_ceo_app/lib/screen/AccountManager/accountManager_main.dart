

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/VATInfo_main.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountHistoryMall_main.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountHistory_main.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountWithdraw_main.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/saleInfo_main.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AccountManagerMain extends StatefulWidget {
  final int? initTabIndex;
  const AccountManagerMain({Key? key, this.initTabIndex}) : super(key: key);

  @override
  State<AccountManagerMain> createState() => _AccountManagerMainState();
}

class _AccountManagerMainState extends State<AccountManagerMain> with PageMixin{
  List<Tab> currTabs = [
    const Tab(height: 60, text: '     적립금 출금     '),
    const Tab(height: 60, text: '     적립 내역     '),
    const Tab(height: 60, text: '     적립 내역(대구로몰)     '),
    const Tab(height: 60, text: '     매출 현황     '),
    const Tab(height: 60, text: '     부가세 신고자료     '),
  ];

  int initTabIndex = 0;

  @override
  void initState() {
    super.initState();

    initTabIndex = widget.initTabIndex!;

    WidgetsBinding.instance.addPostFrameCallback((c) {
      setState(() {
      });
    });
  }

  @override
  void dispose() {
    //debugPrint('dispose AccountManagerMain');

    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;
        _appTheme.ShopRefreshChild = true;
        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          setState(() {
          });
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    double tapviewContentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 280 : 330);

    return fluentUI.ScaffoldPage.withPadding(
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: SizedBox(
        height: tapviewContentHeight,
        child: DefaultTabController(
          initialIndex: initTabIndex,
          length: currTabs.length,
          child: Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              backgroundColor: Colors.transparent,
              elevation: 0.0,
              title: TabBar(
                indicatorColor: Colors.black,
                labelStyle: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
                unselectedLabelStyle: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                indicatorWeight: 10,
                indicatorSize: TabBarIndicatorSize.label,
                labelColor: Colors.black,
                isScrollable: true,
                padding: const EdgeInsets.all(0),
                labelPadding: const EdgeInsets.all(0),
                tabs: currTabs,
              ),
            ),
            body: TabBarView(
              physics: const NeverScrollableScrollPhysics(),
              children: [
                AccountWithdrawMain(tabviewHeight: tapviewContentHeight),
                AccountHistoryMain(tabviewHeight: tapviewContentHeight),
                AccountHistoryMallMain(tabviewHeight: tapviewContentHeight),
                SaleInfoMain(tabviewHeight: tapviewContentHeight),
                const VATInfoMain(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}