import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/AccountManager/accountInfoModel.dart';
import 'package:daeguro_ceo_app/models/AccountManager/withdrawModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/smsCheck.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class AccountWithdrawMain extends StatefulWidget {
  final double? tabviewHeight;
  const AccountWithdrawMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<AccountWithdrawMain> createState() => _AccountWithdrawMainState();
}

class _AccountWithdrawMainState extends State<AccountWithdrawMain> {

  final ScrollController _scrollController = ScrollController();

  AccountInfoModel accInfoModel = AccountInfoModel();
  WithdrawModel withdrawData = WithdrawModel();

  String payConfirm = '';
  String autoWithdrawYn = '';
  String autoWithdrawDt = '';
  String autoWithdrawAmt = '';

  Future<String?> requestAccountData() async {
    String retValue = '';

    await AccountController.to.getAccountInfo().then((value) {
      // if (value == null) {
      //   //ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
      //   retValue = '${AccountController.to.msg}';
      // }
      // else {
        accInfoModel = AccountInfoModel();
        accInfoModel.bankName = value['bankName'] as String;
        accInfoModel.bankCode = value['bankCode'] as String;
        accInfoModel.accountNo = value['accountNo'] as String;
        accInfoModel.accOwner = value['accOwner'] as String;
        accInfoModel.realRemainAmt = value['realRemainAmt'] as String;
        accInfoModel.remainAmt = value['remainAmt'] as String;
        accInfoModel.withdrawAmt = value['withdrawAmt'] as String;
        accInfoModel.accConfirmGbn = value['accConfirmGbn'] as String;
        accInfoModel.amtTransSmsGbn = value['amtTransSmsGbn'] as String;
      //}

      if (accInfoModel.remainAmt == null || accInfoModel.remainAmt == ''){
        accInfoModel.remainAmt = '0';
      }
      else{
        if(int.parse(accInfoModel.remainAmt!) >= 200){
          accInfoModel.remainAmt = (int.parse(accInfoModel.remainAmt!) - 200).toString();
        }
      }

      retValue = '00';
    });

    return retValue;
  }

  Future<String?> requestWithdrawAPIData() async {
    String retValue = '';

    await AccountController.to.getWithdrawInfo().then((value) {
      if (value == null) {
        //ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
        retValue = '${AccountController.to.msg}';
      }
      else {
        payConfirm = '';
        autoWithdrawYn = '';
        autoWithdrawDt = '';
        autoWithdrawAmt = '';

        payConfirm = value['payConfirm'] as String;
        autoWithdrawYn = value['autoWithdrawYn'] as String;
        autoWithdrawDt = value['autoWithdrawDt'] as String;
        autoWithdrawAmt = value['autoWithdrawAmt'] as String;
      }

      retValue = '00';
    });

    return retValue;
  }

  Future<String?> requestAutoWithdrawAPIData() async {
    String retValue = '';

    await AccountController.to.getShopAutoWithdrawSet().then((value) {
      if (value == null) {
        //ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
        retValue = '${AccountController.to.msg}';
      }
      else {
        withdrawData = WithdrawModel();
        withdrawData.shopCd = value['shopCd'].toString();
        withdrawData.withdrawCycle = value['withdrawCycle'].toString();
        withdrawData.withdrawDate = value['withdrawDate'].toString();
        withdrawData.withdrawDay = value['withdrawDay'].toString();
        withdrawData.withdrawHour = value['withdrawHour'].toString();
        withdrawData.withdrawMinute = value['withdrawMinute'].toString();
        withdrawData.withdrawAmt = value['withdrawAmt'].toString();
        withdrawData.fullWithdrawalYn = value['fullWithdrawalYn'].toString();

        if(autoWithdrawAmt != '전액출금'){
          autoWithdrawAmt = '${Utils.getCashComma(withdrawData.withdrawAmt!)}원';
        }
      }
      retValue = '00';
    });

    return retValue;
  }

  Future<String?> getWithdrawData() async {
    var ret1 = await requestAccountData();
    var ret2 = await requestWithdrawAPIData();
    var ret3 = await requestAutoWithdrawAPIData();

    if (ret1 != '00') {
      return ret1.toString();
    }
    else{
      setState(() {

      });
    }

    if (ret2 != '00') {
      return ret2.toString();
    }
    else{
      setState(() {

      });
    }

    if (ret3 != '00') {
      return ret3.toString();
    }
    else{
      setState(() {

      });
    }

    return '00';
  }

  requestAPIData() async {
    await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(getWithdrawData())
    ).then((value) {
      if (value == '00'){
        setState(() {
        });
      }
      else{
        ISAlert(context, content: '정상조회가 되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
      }
    });
  }

  @override
  void initState() {
    super.initState();

    Get.put(AccountController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      if (AuthService.ShopServiceGbn != AuthService.SHOPGBN_FLOWER)
        requestAPIData();
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    accInfoModel = AccountInfoModel();
    withdrawData = WithdrawModel();

    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefreshChild == true ) {
        _appTheme.ShopRefreshChild = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          debugPrint('AuthService.ShopServiceGbn: ${AuthService.ShopServiceGbn}');
          if (AuthService.ShopServiceGbn != AuthService.SHOPGBN_FLOWER) {
            requestAPIData();
          }
          else{
            setState(() {
            });
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
      controller: _scrollController,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 22),
        child: (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER)
            ? Container(
              width: double.infinity,
              height: widget.tabviewHeight,
              alignment: Alignment.center,
              child: const Text('적립금 출금기능 미지원', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
            )
            : ISLabelBarSub(
          title: accInfoModel.bankCode == '' ? '계좌 정보를 확인하지 못했습니다.' : int.parse(accInfoModel.realRemainAmt!) > 200 ? '' : '출금 가능 금액이 부족합니다.',
          backgroundColor: accInfoModel.bankCode == '' ? Color(0xfff8d7da) : int.parse(accInfoModel.realRemainAmt!) > 200 ? Colors.transparent : Color(0xfff8d7da),
          titleStyle: const TextStyle(color: Color(0xff721c24), fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              accInfoModel.bankCode == '' || int.parse(accInfoModel.realRemainAmt!) > 200 ? Divider() : Container(),
              Container(
                padding: EdgeInsets.symmetric(horizontal: Responsive.isMobile(context) == true ? 0 : 40),
                height: 320,
                child: Row(
                    children: [
                      SizedBox(
                        width: Responsive.isMobile(context) == true ? 120 : 200,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '은행명', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '계좌번호', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '예금주', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '적립금', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '입점 지원금', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '출금 가능 금액', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '출금 가능 시간', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                          ],
                        ),
                      ),
                      Flexible(
                        fit: FlexFit.tight,
                        flex: 3,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, getBankName(accInfoModel.bankCode!, accInfoModel.bankName!), style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, Utils.getAccountNoFormat(accInfoModel.accountNo!, false), style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, accInfoModel.accOwner ?? '', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, '${Utils.getCashComma(accInfoModel.realRemainAmt!)}원', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, '10,000원 (퇴점 시 출금 가능합니다.)', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, '${Utils.getCashComma(accInfoModel.remainAmt!)}원 (이체 수수료 200원)', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, '01:00 ~ 22:30', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.topLeft, height: 26, child: const Text('(22:30 ~ 01:00 은행 점검 시간입니다.)', style: TextStyle(color: Colors.redAccent, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),overflow: TextOverflow.visible, softWrap: true,)),
                          ],
                        ),
                      ),
                    ]
                ),
              ),
              const Divider(height: 10,),
              Visibility(
                visible: autoWithdrawYn == 'Y' ? true : false,
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: Responsive.isMobile(context) == true ? 0 : 40),
                      height: Responsive.isMobile(context) ? 135 : 80,
                      child: Row(
                          children: [
                            SizedBox(
                              width: Responsive.isMobile(context) == true ? 130 : 200,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '자동 이체', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)),
                                  Responsive.isMobile(context) ? Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, '', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))) : Container(),
                                  Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '자동 출금 금액', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                                ],
                              ),
                            ),
                            Flexible(
                              fit: FlexFit.tight,
                              flex: 3,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(alignment: Alignment.centerLeft, height: 40, child: Row(
                                    children: [
                                      Text(textAlign: TextAlign.left, autoWithdrawDt, style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                      Responsive.isMobile(context) ?  Container() : Padding(
                                        padding: const EdgeInsets.only(left: 10),
                                        child: ISButton(
                                          child: const Text('자동출금 해지'),
                                          onPressed: () {
                                            ISConfirm(context, '자동출금', '자동 출금을 해지하시겠습니까?', constraints: BoxConstraints(maxWidth: 420), (context, isOK) async {
                                              Navigator.pop(context);
                                              if (isOK){
                                                withdrawData.modUcode = AuthService.uCode;
                                                withdrawData.modName = AuthService.uName;
                                                withdrawData.useYn = 'N';

                                                var value = await showDialog(
                                                    context: context,
                                                    builder: (context) => FutureProgressDialog(AccountController.to.setAutoWithdrawSet(withdrawData.shopCd!, withdrawData.withdrawCycle!,withdrawData.withdrawDate!, withdrawData.withdrawDay!, withdrawData.withdrawHour!, withdrawData.withdrawMinute!, withdrawData.withdrawAmt!, withdrawData.fullWithdrawalYn!, withdrawData.modUcode!, withdrawData.modName!, withdrawData.useYn!))
                                                );
                                                if (value == '00') {
                                                  requestAPIData();
                                                }
                                                else{
                                                  ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                                                }
                                              }
                                            });
                                          },
                                        ),
                                      ),
                                    ],
                                  )),
                                  Responsive.isMobile(context) ? Container(alignment: Alignment.topLeft, height: 26, child: ISButton(
                                    child: const Text('자동출금 해지'),
                                    onPressed: () {
                                      ISConfirm(context, '자동출금', '자동 출금을 해지하시겠습니까?', constraints: BoxConstraints(maxWidth: 420), (context, isOK) async {
                                        Navigator.pop(context);
                                        if (isOK){
                                          withdrawData.modUcode = AuthService.uCode;
                                          withdrawData.modName = AuthService.uName;
                                          withdrawData.useYn = 'N';

                                          var value = await showDialog(
                                              context: context,
                                              builder: (context) => FutureProgressDialog(AccountController.to.setAutoWithdrawSet(withdrawData.shopCd!, withdrawData.withdrawCycle!,withdrawData.withdrawDate!, withdrawData.withdrawDay!, withdrawData.withdrawHour!, withdrawData.withdrawMinute!, withdrawData.withdrawAmt!, withdrawData.fullWithdrawalYn!, withdrawData.modUcode!, withdrawData.modName!, withdrawData.useYn!))
                                          );
                                          if (value == '00') {
                                            requestAPIData();
                                          }
                                          else{
                                            ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                                          }
                                        }
                                      });
                                    },
                                  ),) : Container(),
                                  Container(alignment: Alignment.centerLeft, height: Responsive.isMobile(context) ? 66 : 40, child: Text(textAlign: TextAlign.left, autoWithdrawAmt, style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                          ],
                        ),
                      ),
                    ]
                ),
              ),
              const Divider(),
                  ],
                ),
              ),
              Row(
                mainAxisAlignment: Responsive.isMobile(context) ? MainAxisAlignment.center : MainAxisAlignment.end,
                children: [
                  ISButton(
                    child: const Text('직접 출금'),
                    onPressed: () {
                      if(int.parse(accInfoModel.realRemainAmt!) < 200){
                        ISAlert(context, content: '출금 가능 금액이 부족합니다.');
                        return;
                      }
                      if(payConfirm == 'N'){
                        ISAlert(context, content: '이체 불가 가맹점입니다. 고객센터로 문의 바랍니다.');
                      }else{
                        showDialog(
                          context: context,
                          barrierDismissible: true,
                          builder: (context) => SMSCheck(remainAmt: accInfoModel.remainAmt!,),
                        ).then((v) async {
                          if (v == true) {
                            ISAlert(context, content: '정상적으로 출금이 완료되었습니다.');
                            await Future.delayed(Duration(milliseconds: 500), () {
                              requestAPIData();
                            });
                          }
                        });
                      }
                    },
                  ),
                  const SizedBox(width: 10,),
                  ISButton(
                    child: const Text('자동출금설정'),
                    onPressed: () {
                      showDialog(
                        context: context,
                        barrierDismissible: true,
                        builder: (context) => SMSCheck(),
                      ).then((v) async {
                        if (v == true) {
                          await Future.delayed(Duration(milliseconds: 500), () {
                            requestAPIData();
                          });
                        }
                      });
                    },
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  // "02" : "산업";
  // "03" : "기업";
  // "04" : "국민";
  // "05" : "외환";
  // "07" : "수협";
  // "08" : "수출";
  // "11" : "농협";
  // "12" : "단협";
  // "20" : "우리";
  // "23" : "SC은행";
  // "27" : "씨티";
  // "32" : "부산";
  // "34" : "광주";
  // "35" : "제주";
  // "37" : "전북";
  // "39" : "경남";
  // "71" : "우체국";
  // "81" : "KEB하나";
  // "88" : "신한";
  // "31" : "대구";
  // "50" : "상호저축";
  // "48" : "신협";
  // "45" : "새마을";
  // "89" : "K,뱅크";
  // "90" : "카카오뱅크";

  String getBankName(String bankCode, String bankName){
    String? bankNameStr;

    if (bankCode =='' || bankName == '') {
      return '';
    }

    if (bankCode == "07" || bankCode == "11" || bankCode == "12" || bankCode == "23" || bankCode == "71" || bankCode == "48" || bankCode == "89" || bankCode == "90" ) {
      return bankName;
    }
    else if (bankCode == "45") {
      return '${bankName!}금고';
    }
    else {
      return '${bankName!}은행';
    }
  }
}