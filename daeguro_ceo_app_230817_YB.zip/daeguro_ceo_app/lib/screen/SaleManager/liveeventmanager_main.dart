import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_datatable.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/iswidgets/timepicker/is_selectTime.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/LiveEventManager/liveeventInfoEditModel.dart';
import 'package:daeguro_ceo_app/models/LiveEventManager/liveeventMenuEditModel.dart';
import 'package:daeguro_ceo_app/models/LiveEventManager/liveeventTargetMenuListModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManagerController.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/liveeventmanagerEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:slide_countdown/slide_countdown.dart';

class LiveEventManagerMain extends StatefulWidget {
  const LiveEventManagerMain({Key? key}) : super(key: key);

  @override
  State<LiveEventManagerMain> createState() => _LiveEventManagerMainState();
}

class _LiveEventManagerMainState extends State<LiveEventManagerMain> with PageMixin {

  final ScrollController _scrollController = ScrollController();
  final TextEditingController _textEditingController = TextEditingController(text: '');

  DateTime? startdate;
  DateTime? enddate;

  String? selectedTimeType = '30';
  String? tempStr;

  String? _type = '0';
  String? _eventTitle = '';
  //String? _eventImageURL = 'https://images.pexels.com/photos/343870/pexels-photo-343870.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1';

  String? mShopName = '';
  String? mShopLogo = '';
  String? mEventYn = '';
  String? mEventTitle = '';
  String? mFrTime = '';
  String? mToTime = '';
  String? mRemainTime = '';
  String? mPushYn = '';

  String? eventGbn = '';
  String? eventGbnTxt = '';

  // 시간 부분
  String? hours = '0';
  String? minutes = '0';
  Duration timer = const Duration(hours: 2, minutes: 30);

  List<LiveEventTargetMenuListModel> dataList = <LiveEventTargetMenuListModel>[];
  LiveEventInfoEditModel formData = LiveEventInfoEditModel();

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(CouponController.to.getLiveEventInfo())
    );

    if (value == '99') {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
      //Navigator.of(context).pop;
    }
    else {
      debugPrint('check 1111');
      eventGbn = '';
      eventGbnTxt = '';
      mShopName = CouponController.to.liveEvent_shopName;
      mShopLogo = CouponController.to.liveEvent_shopLogo;
      mEventYn = CouponController.to.liveEvent_eventYn;
      mEventTitle = CouponController.to.liveEvent_eventTitle;
      mFrTime = CouponController.to.liveEvent_frTime;
      mToTime = CouponController.to.liveEvent_toTime;
      mRemainTime = CouponController.to.liveEvent_remainTime;
      mPushYn = CouponController.to.liveEvent_pushYn;
      if(mEventYn == 'Y'){
        startdate = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, int.parse(mFrTime!.substring(0, 2)), int.parse(mFrTime!.substring(2, 4)));
        enddate = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, int.parse(mToTime!.substring(0, 2)), int.parse(mToTime!.substring(2, 4)));
        hours = (int.parse(mRemainTime!) ~/ 60).toString();
        minutes = (int.parse(mRemainTime!) % 60).toString();
        timer = Duration(hours: int.parse(hours!), minutes: int.parse(minutes!));
        _textEditingController.text = mEventTitle!;
      }

      value.asMap().forEach((index, element) {
        LiveEventTargetMenuListModel temp = LiveEventTargetMenuListModel();
        temp.menuCd = element['menuCd'] as String;
        temp.menuName = element['menuName'] as String;
        temp.menuPrice = element['menuCost'] as String;
        temp.menuDiscCost = element['discCost'] as String;
        temp.eventAmt = element['eventAmtGbn'] as String;
        temp.menuSeq = element['menuSeq'] as String;
        temp.menuIdx = (index + 1).toString();
        if(temp.eventAmt == '1'){
          temp.menuDiscPer = (double.parse(temp.menuDiscCost!) / double.parse(temp.menuPrice!) * 100).ceil().toString();
          temp.totalPrice = (int.parse(temp.menuPrice!) - int.parse(temp.menuDiscCost!)).toString();
          eventGbn = '1';
          eventGbnTxt = '${Utils.getCashComma(temp.menuDiscCost!)}원 할인';
        }
        else if(temp.eventAmt == '3'){
          temp.menuDiscPer = temp.menuDiscCost;
          temp.menuDiscCost = (double.parse(temp.menuPrice!) * double.parse(temp.menuDiscCost!) / 100).toString();
          temp.totalPrice = (int.parse(temp.menuPrice!) - int.parse(temp.menuDiscCost!)).toString();
          eventGbn = '3';
          eventGbnTxt = '${temp.menuDiscPer}% 할인';
        }
        dataList.add(temp);
      });

      debugPrint('check 2222');
      debugPrint(mRemainTime);

      if(mEventYn == 'E'){
        ISAlert(context, content: '금일 이벤트가 종료되었습니다.\n다음에 이용해주세요!');
        router.go('/');
      }


    }

    setState(() {

    });
  }

  @override
  void initState() {
    super.initState();
    dataList.clear();

    Get.put(CouponController());

    DateTime tempDateTime = DateTime.now();

    if (tempDateTime.minute < 30) {
      startdate = DateTime(tempDateTime.year, tempDateTime.month, tempDateTime.day, tempDateTime.hour, 30);
      enddate = startdate!.add(const Duration(minutes: 30));
    }
    else{
      startdate = DateTime(tempDateTime.year, tempDateTime.month, tempDateTime.day, tempDateTime.hour + 1, 0);
      enddate = startdate!.add(const Duration(minutes: 30));
    }

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    _textEditingController.dispose();
    dataList.clear();
    formData = LiveEventInfoEditModel();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((c) {
          if (AuthService.ShopServiceGbn != AuthService.SHOPGBN_FLOWER){
            requestAPIData();
          }
          else{
            router.go('/');
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));
    double contentHeight = MediaQuery.of(context).size.height;
//
    return fluentUI.ScaffoldPage.scrollable(
      //scrollController: _scrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      children: Responsive.isMobile(context) ? mobileLiveEventManagerMain(contentHeight) : deskTopLiveEventManagerMain(contentHeight),
    );
  }

  _deleteEventMenu(LiveEventTargetMenuListModel item) {
    ISConfirm(context, '이벤트 메뉴 삭제', '[${item.menuName}]을(를) 삭제하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 280), (context, isOK) async {
      //await ShopController.to.deleteMenuOptionGroupData(menuOptionGroupCd, context);

      Navigator.of(context).pop();

      if (isOK){
        if(mEventYn == 'Y'){
          var value = await showDialog(
              context: context,
              barrierColor: Colors.transparent,
              builder: (context) => FutureProgressDialog(CouponController.to.setShopLiveMenuDel(AuthService.SHOPCD, item.menuCd!, AuthService.uName))
          );
          if (value == null) {
            ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
          }
          else {
            dataList.clear();
            requestAPIData();
          }
        }else{
          dataList.remove(item);
        }
        setState(() {

        });
      }
    });
  }

  List<Widget> mobileLiveEventManagerMain(double contentHeight){
    return [
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('라이브 이벤트', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
              Expanded(child: Container()),
              mEventYn == 'Y' ? SlideCountdown(
                duration: timer,
                decoration: const BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.all(Radius.circular(5)),
                ),
                onDone: (){
                  setState(() {
                    dataList.clear();
                    requestAPIData();
                  });
                },
              ) : Container(),
            ],
          ),
          const SizedBox(height: 6,),
          const Text('하루 한번, 상점 상단 노출(1일 1회성 이벤트)', style: TextStyle(color: Color(0xff01CAFF), fontSize: 14),),
        ],
      ),
      const SizedBox(height: 16,),
      Material(
        child: ISSearchDropdown(
          label: '이벤트 선택',
          //height: 40,
          value: _type,
          onChange: (value) {
            setState(() {
              _type = value;
              if (value == '1') {
                ISAlert(context, content: '종료된 이벤트 조회는 추후 제공 예정입니다.');
              }
            });
          },
          item: [
            ISOptionModel(value: '0', label: '진행중 이벤트'),
            ISOptionModel(value: '1', label: '종료된 이벤트'),
          ].cast<ISOptionModel>(),
        ),
      ),
      const SizedBox(height: 16,),
      // ISLabelBarSub(
      //   title: '미리보기',
      //   body: Container(
      //     width: double.infinity,
      //     //color: Colors.yellow,
      //     alignment: Alignment.center,
      //     child: Container(
      //         width: 300,
      //         height: 150,
      //         alignment: Alignment.center,
      //         decoration: BoxDecoration(
      //           borderRadius: BorderRadius.circular(10.0),
      //           border: Border.all(color: const Color(0xffB3AAF5), width: 4.0),
      //         ),
      //         child: Padding(
      //             padding: const EdgeInsets.all(16.0),
      //             child: Row(
      //               children: [
      //                 const SizedBox(
      //                   width: 165,
      //                   child: Column(
      //                     crossAxisAlignment: CrossAxisAlignment.start,
      //                     children: [
      //                       Text('롯데리아(테스트)', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
      //                       SizedBox(height: 8,),
      //                       Text('', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
      //                     ],
      //                   ),
      //                 ),
      //                 const SizedBox(width: 8,),
      //                 Column(
      //                   crossAxisAlignment: CrossAxisAlignment.start,
      //                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //                   children: [
      //                     const Text('0시간 0분 남음', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
      //                     ClipRRect(
      //                         borderRadius: BorderRadius.circular(8.0),
      //                         child: Image.network('${_eventImageURL!}?tm=${Utils.getTimeStamp()}', width: 86, height: 86,)
      //                     )
      //                   ],
      //                 )
      //               ],
      //             ))),
      //   ),
      // ),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Text('이벤트 제목', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
              Text('(최대 20자, 이모지 사용 불가)', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
            ],
          ),
          const SizedBox(height: 4,),
          // Material(
          //   child: ISInput(
          //     context: context,
          //     value: tempStr,
          //     label: '이벤트 제목을 입력해 주세요.',
          //     height: 70,
          //     maxLength: 20,
          //     onChange: (v) {
          //       tempStr = v;
          //     },
          //   ),
          // )
          Material(
            child: TextFormField(
              readOnly: mEventYn == 'Y' ? true : false,
              style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
              //initialValue: dataList[index].answerContent,
              controller: _textEditingController,
              maxLength: 20,
              onChanged: (v) {
                setState(() {
                  _eventTitle = v;
                });
              },
              decoration: const InputDecoration(
                fillColor: Colors.white,
                filled: true,
                enabled: true,
                //hintStyle: TextStyle(color: Colors.black54, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.black12, width: 1.0)),
                focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.lightBlueAccent, width: 1.0)),
                isDense: true,
              ),
            ),
          )
        ],
      ),
      const SizedBox(height: 4,),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Text('시간 설정', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
              Tooltip(
                richMessage: TextSpan(
                  text: '시작 시간은 현재 시간보다 작을 수 없으며, ',
                  children: [
                    TextSpan(
                      text: '최대 5시간',
                      style: TextStyle(fontWeight: FontWeight.bold,color: Colors.lightBlueAccent),
                    ),
                    TextSpan(
                      text: "까지 설정 가능합니다.",
                    ),
                  ],
                ),
                child: Icon(Icons.help_outline, color: Colors.blue, size: 18,),
              ),
            ],
          ),
          const SizedBox(height: 8,),
          SizedBox(
            width: double.infinity,
            height: 43,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 200,
                    height: 40,
                    child: AbsorbPointer(
                      absorbing: mEventYn == 'Y' ? true : false,
                      child: fluentUI.TimePicker(
                        selected: startdate,
                        onChanged: (time) {
                          if (time!.compareTo(enddate!) != -1){
                            setState(() {
                              startdate = null;
                            });
                            ISAlert(context, content: '시작 시간이 종료 시간보다 클 수 없습니다.');
                            return;
                          }
                          else{
                            setState(() {
                              startdate = time;
                            });
                          }
                        },
                        hourFormat: HourFormat.HH,
                        minuteIncrement: 30,
                      ),
                    ),
                  ),
                  const Text('    ~    ', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                  SizedBox(
                    width: 200,
                    height: 40,
                    child: AbsorbPointer(
                      absorbing: mEventYn == 'Y' ? true : false,
                      child: fluentUI.TimePicker(
                        selected: enddate,
                        onChanged: (time) {
                          if (startdate!.compareTo(time) != -1){
                            setState(() {
                              enddate = null;
                            });
                            ISAlert(context, content: '종료 시간이 시작 시간보다 작을 수 없습니다.');
                            return;
                          }
                          else{
                            setState(() {
                              enddate = time;
                            });
                          }
                        },
                        hourFormat: HourFormat.HH,
                        minuteIncrement: 30,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
      const SizedBox(height: 16,),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: AbsorbPointer(
          absorbing: mEventYn == 'Y' ? true : false,
          child: ISToggleButtons(
            [
              ISOptionModel(value: '30', label: '30분'),
              ISOptionModel(value: '60', label: '1시간'),
              ISOptionModel(value: '120', label: '2시간'),
              ISOptionModel(value: '180', label: '3시간'),
              ISOptionModel(value: '240', label: '4시간'),
              ISOptionModel(value: '300', label: '5시간'),
            ],
            defaultValue: selectedTimeType,
            buttonHeight: 40,
            buttonWidth: (MediaQuery.of(context).size.width/7)+6.6,
            afterOnPress: (v) {
              DateTime tempDT = startdate!.add(Duration(minutes: int.parse(v.toString())));

              debugPrint('month:${tempDT.month}, day:${tempDT.day}, hour:${tempDT.hour}, min:${tempDT.minute}');

              if (tempDT.day != startdate!.day){
                enddate = null;
                setState(() {
                });
                ISAlert(context, content: '종료 시간은 23:59분을 넘을 수 없습니다.');
                return;
              }
              else{
                enddate = tempDT;
                setState(() {
                });
              }
            },
          ),
        ),
      ),
      const SizedBox(height: 16,),
      mEventYn == 'Y' ? Container() : Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ISButton(
            width: double.infinity,
            height: 48,
            child: const Text('메뉴 등록'),
            onPressed: () {
              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => LiveeventmanagerEdit(sData: dataList),
              ).then((value) {
                if (value != null){
                  dataList.clear();
                  formData = LiveEventInfoEditModel();
                  dataList = value;

                  if(dataList[0].eventGbn == '1'){
                    eventGbn = '1';
                    eventGbnTxt = '${Utils.getCashComma(dataList[0].menuDiscCost!)}원 할인';
                  }else {
                    eventGbn = '3';
                    eventGbnTxt = '${dataList[0].menuDiscPer}% 할인';
                  }

                  debugPrint('dataList.length:${dataList.length}');

                  setState(() {

                  });
                }
              });
            },
          ),
          const SizedBox(height: 8,),
          const Text('* 메뉴 등록은 최소 1개 ~ 최대 10개까지 등록 가능합니다.', style: TextStyle(color: Colors.black54, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
        ],
      ),
      mEventYn == 'Y' ? Container(
        padding: const EdgeInsets.only(bottom: 8),
        child: ISButton(
          height: 40,
          buttonColor: Colors.black,
          onPressed: () {
              ISConfirm(context, 'PUSH 알림을 발송하시겠습니까?', 'PUSH 이벤트 제공 동의 고객 중 매장 이용내역이 있는 고객에게 알림이 발송됩니다.', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 280), (context, isOK) async {
                Navigator.of(context).pop();
              if (isOK){
                var value = await showDialog(
                    context: context,
                    barrierColor: Colors.transparent,
                    builder: (context) => FutureProgressDialog(CouponController.to.pushAlarm()));
                if (value == null) {
                  ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                }
                else {
                }
                setState(() {
                });
              }
              });
          },
          child: const Text('PUSH 알림 발송',style: TextStyle(color: Colors.white),),
        ),
      ) : Container(),
      Align(
        alignment: Alignment.centerRight,
        child: TextButton(
          onPressed: () {
            showModalBottomSheet(
              backgroundColor: Colors.transparent,
              context: context,
              builder: (BuildContext context) {
                return Container(
                  height: 265,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(15.0),
                      topRight: Radius.circular(15.0),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Image(image: AssetImage('images/img_bulb_32px@2x.png'), width: 46, height: 46,),
                          const Padding(
                            padding: EdgeInsets.only(top: 7.0),
                            child: Text('미리보기', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                          ),
                          Expanded(child: Container()),
                          Padding(
                            padding: const EdgeInsets.only(top: 7.0),
                            child: fluentUI.SmallIconButton(
                              child: fluentUI.Tooltip(
                                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                                child: fluentUI.IconButton(
                                  icon: const Icon(fluentUI.FluentIcons.chrome_close, size: 18,),
                                  onPressed: Navigator.of(context).pop,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                          height: 185,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            border: Border.all(color: const Color(0xffB3AAF5), width: 4.0),
                          ),
                          child: Padding(
                              padding: const EdgeInsets.all(13.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(15),
                                    width: 135,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(AuthService.SHOPNAME, style: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                                        const SizedBox(height: 5,),
                                        Text(mEventYn == 'Y' ? mEventTitle! : _eventTitle!, style: const TextStyle(fontSize: 15, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                                        const SizedBox(height: 5,),
                                        Text(eventGbnTxt!, style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: Colors.red),),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 8,),
                                  Container(
                                    padding: const EdgeInsets.all(15),
                                    width: 135,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text('$hours시간 $minutes분 남음', style: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                                        ClipRRect(
                                          borderRadius: BorderRadius.circular(8.0),
                                          child: (mShopLogo == null || mShopLogo == '') ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 130, height: 130,)
                                              : Image.network('${mShopLogo}}', fit: BoxFit.cover, gaplessPlayback: true, width: 130, height: 100,
                                            loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                              if (loadingProgress == null) return child;
                                              return const Center(
                                                child: CircularProgressIndicator(
                                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                                ),
                                              );
                                            },
                                            errorBuilder: (context, error, stackTrace) {
                                              debugPrint('image load error -> ${mShopLogo}\nerror:${error.toString()}\nstackTrace:${stackTrace.toString()}');
                                              return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 130, height: 100,);
                                            },
                                          ),
                                        )
                                      ],
                                    ),
                                  )
                                ],
                              )
                          )
                      ),
                    ],
                  )

                );
              },
            );
          },
          child: const Text('앱 화면 미리 보기'),
        ),
      ),
      const SizedBox(height: 8,),
      Material(
        child: (dataList.length! == 0)
            ? const Column(
              children: [
                Divider(),
                Align(
                    alignment: Alignment.center,
                    child: Text('현재 등록된 라이브 이벤트 메뉴가 없습니다.\n이벤트 제목과 시간 설정 후 메뉴를 등록해 주세요.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
                Divider(),
              ],
            )
            : Column(
                // controller: _scrollController,
                // shrinkWrap: true,
                children: List.generate(dataList.length, (index) {
                  return Container(
                    height: 180,
                    padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.black.withOpacity(0.1)))),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('메뉴이름', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                            Expanded(child: Text('${dataList[index].menuName}' ?? '', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),overflow: TextOverflow.ellipsis,textAlign: TextAlign.end,)),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('금액', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                            Expanded(child: Text('${Utils.getCashComma(dataList[index].menuPrice!)}원' ?? '', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),overflow:TextOverflow.ellipsis ,textAlign: TextAlign.end,)),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('할인금액', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                            Expanded(child: Text('${dataList[index].menuDiscCost ?? ''}원'  '', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),overflow:TextOverflow.ellipsis ,textAlign: TextAlign.end,)),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('할인율', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                            Expanded(child: Text('${dataList[index].menuDiscPer}%', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),overflow:TextOverflow.ellipsis ,textAlign: TextAlign.end,)),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('적용 금액', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                            Expanded(child: Text('${Utils.getCashComma(dataList[index].totalPrice!)}원' ?? '', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),overflow:TextOverflow.ellipsis ,textAlign: TextAlign.end,)),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Container(
                          width: double.infinity,
                          alignment: Alignment.centerRight,
                          child: OutlinedButton(
                            style: ButtonStyle(side: MaterialStateProperty.all(const BorderSide(color: Colors.red))),
                            onPressed: () {
                              _deleteEventMenu(dataList[index]);
                            },
                            child: const Text('삭제', style: TextStyle(color: Colors.red),),
                          ),
                        )
                      ],
                    ),
                  );
                })
            ),
      ),
      const SizedBox(height: 8,),
      (eventGbnTxt != '' && mEventYn != 'Y') ? Container(padding: const EdgeInsets.only(bottom: 8), child: const Text('* 할인 금액 수정 시 상단의 메뉴 등록 버튼을 클릭해 주세요.', style: TextStyle(color: Colors.black54, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))) : Container(),
      ISButton(
        height: 48,
        child: Text(mEventYn == 'Y' ? '종료' : '이벤트 등록'),
        onPressed: () {
          formData = LiveEventInfoEditModel();
          if(mEventYn == 'N'){
            if(_eventTitle == '' || _eventTitle == null){
              ISAlert(context, content: '라이브 이벤트 제목이 존재하지 않습니다.');
              return;
            }
            if(startdate == '' || startdate == null || enddate == '' || enddate == null){
              ISAlert(context, content: '라이브 이벤트 등록 시간이 존재하지 않습니다.');
              return;
            }
            if(dataList.length == 0){
              ISAlert(context, content: '메뉴가 존재하지 않습니다. 메뉴 등록 후 이용해 주세요');
              return;
            }
            formData.jobGbn = 'I';
            formData.shopCd = AuthService.SHOPCD!;
            formData.eventTitle = _eventTitle;
            formData.frTime = DateFormat('HHmm').format(startdate!).toString().replaceAll(':', '');
            formData.toTime = DateFormat('HHmm').format(enddate!).toString().replaceAll(':', '');
            formData.uName = AuthService.uName;
            dataList.forEach((element) {
              formData.menuCd ??= [];
              formData.menuCd!.add(element.menuCd!);
            });
            dataList.forEach((element) {
              formData.eventAmtGbn ??= [];
              formData.eventAmtGbn!.add(eventGbn!);
            });
            dataList.forEach((element) {
              formData.eventAmt ??= [];
              formData.eventAmt!.add(element.eventAmt!);
            });
            showDialog(
              context: context,
              barrierDismissible: true,
              builder: (context) => LiveeventmanagerEdit(iData: formData,),
            ).then((value) {
              setState(() {
                dataList.clear();
                requestAPIData();
              });
            });
          }else{
            formData.jobGbn = 'D';
            formData.shopCd = AuthService.SHOPCD!;
            formData.eventTitle = mEventTitle;
            formData.frTime = DateFormat('HHmm').format(startdate!).toString().replaceAll(':', '');
            formData.toTime = DateFormat('HHmm').format(enddate!).toString().replaceAll(':', '');
            formData.uName = AuthService.uName;
            dataList.forEach((element) {
              formData.menuCd ??= [];
              formData.menuCd!.add(element.menuCd!);
            });
            dataList.forEach((element) {
              formData.eventAmtGbn ??= [];
              formData.eventAmtGbn!.add(eventGbn!);
            });
            dataList.forEach((element) {
              formData.eventAmt ??= [];
              formData.eventAmt!.add(element.menuDiscCost!!);
            });
            showDialog(
              context: context,
              barrierDismissible: true,
              builder: (context) => LiveeventmanagerEdit(dData: formData,),
            ).then((value) {
              setState(() {
                dataList.clear();
                requestAPIData();
              });
            });
          }
        },
      )
    ];
  }

  List<Widget> deskTopLiveEventManagerMain(double contentHeight){
      return [
        ISLabelBarMain(
          underLine: false,
          leading: const Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('라이브 이벤트', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
              SizedBox(width: 8,),
              Text('하루 한번, 상점 상단 노출(1일 1회성 이벤트)', style: TextStyle(color: Color(0xff01CAFF), fontSize: 14),),
            ],
          ),
          trailing: Material(
            child: ISSearchDropdown(
              label: '이벤트 선택',
              width: 160,
              //height: 40,
              value: _type,
              onChange: (value) {
                setState(() {
                  _type = value;
                  if (value == '1') {
                    ISAlert(context, content: '종료된 이벤트 조회는 추후 제공 예정입니다.');
                  }
                });
              },
              item: [
                ISOptionModel(value: '0', label: '진행중 이벤트'),
                ISOptionModel(value: '1', label: '종료된 이벤트'),
              ].cast<ISOptionModel>(),
            ),
          ),
        ),
        ISLabelBarSub(
          title: '이벤트 등록',
          body: SizedBox(
            width: double.infinity,
            child: Wrap(
              crossAxisAlignment: WrapCrossAlignment.end,
              alignment: WrapAlignment.center,
              spacing: 40,
              runSpacing: 10,
              children: [
                Column(
                  children: [
                    const Text('미리보기', style: TextStyle(fontSize: 20, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                    const SizedBox(width: 8,),
                    Container(
                        width: 430,
                        height: 200,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          border: Border.all(color: const Color(0xffB3AAF5), width: 4.0),
                        ),
                        child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 210,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(AuthService.SHOPNAME, style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                                      const SizedBox(height: 8,),
                                      Text(mEventYn == 'Y' ? mEventTitle! : _eventTitle!, style: const TextStyle(fontSize: 20, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                                      const SizedBox(height: 8,),
                                      Text(eventGbnTxt!, style: const TextStyle(fontSize: 30, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: Colors.red),),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8,),
                                Container(
                                  width: 170,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text('$hours시간 $minutes분 남음', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                                      ClipRRect(
                                          borderRadius: BorderRadius.circular(8.0),
                                          //child: Image.network('${mShopLogo!}?tm=${Utils.getTimeStamp()}', width: 130, height: 130,)
                                          child: (mShopLogo == null || mShopLogo == '') ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 130, height: 130,)
                                              : Image.network('${mShopLogo}}', fit: BoxFit.cover, gaplessPlayback: true, width: 130, height: 130,
                                            loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                              if (loadingProgress == null) return child;
                                              return const Center(
                                                child: CircularProgressIndicator(
                                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                                ),
                                              );
                                            },
                                            errorBuilder: (context, error, stackTrace) {
                                              debugPrint('image load error -> ${mShopLogo}\nerror:${error.toString()}\nstackTrace:${stackTrace.toString()}');
                                              return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 130, height: 130,);
                                            },
                                          ),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            )
                        )
                    ),
                  ],
                ),
                Container(
                  width: 430,
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                  decoration: const BoxDecoration(
                      color: Color.fromARGB(255, 240, 240, 240),
                      borderRadius: BorderRadius.all(Radius.circular(10))),
                  child: Column(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              Text('이벤트 제목', style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                              Text('(최대 20자, 이모지 사용 불가)', style: TextStyle(fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                            ],
                          ),
                          Material(
                            color: Colors.transparent,
                            child: ISInput(
                              readOnly: mEventYn == 'Y' ? true : false,
                              value: _eventTitle,
                              height: 64,
                              label: mEventYn == 'Y' ? mEventTitle : '이벤트 제목을 입력해 주세요.',
                              maxLength: 20,
                              maxLines: 1,
                              onChange: (v) {
                                String oldStr = _eventTitle!;
                                if (v.toString().length > 20){
                                  _eventTitle = oldStr;
                                  return;
                                }
                                else{
                                  setState(() {
                                    _eventTitle = v;
                                  });
                                }
                              },
                              // validator: (v) {
                              //   debugPrint('validator input:${v.toString()}');
                              //   return v.toString().length > 20 ? '입력 가능한 글자수(20자)를 초과하였습니다.' : null;
                              // },
                            ),
                          )
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              Text('시간 설정', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                              Tooltip(
                                richMessage: TextSpan(
                                  text: '시작 시간은 현재 시간보다 작을 수 없으며, ',
                                  children: [
                                    TextSpan(
                                      text: '최대 5시간',
                                      style: TextStyle(fontWeight: FontWeight.bold,color: Colors.lightBlueAccent),
                                    ),
                                    TextSpan(
                                      text: "까지 설정 가능합니다.",
                                    ),
                                  ],
                                ),
                                child: Icon(Icons.help_outline, color: Colors.blue, size: 18,),
                              ),
                            ],
                          ),
                          SizedBox(
                            width: 400,
                            child: Column(
                              children: [
                                const SizedBox(height: 8),
                                SizedBox(
                                  width: 400,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      SizedBox(
                                        width: 160,
                                        child: AbsorbPointer(
                                          absorbing: mEventYn == 'Y' ? true : false,
                                          child: fluentUI.TimePicker(
                                            selected: startdate,
                                            onChanged: (time) {
                                              if (time!.compareTo(enddate!) != -1){
                                                setState(() {
                                                  startdate = null;
                                                });
                                                ISAlert(context, content: '시작 시간이 종료 시간보다 클 수 없습니다.');
                                                return;
                                              }
                                              else{
                                                setState(() {
                                                  startdate = time;
                                                });
                                              }
                                            },
                                            hourFormat: HourFormat.HH,
                                            minuteIncrement: 30,
                                            header: '   시작시간',
                                            headerStyle: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                                          ),
                                        ),
                                      ),
                                      const Padding(
                                        padding: EdgeInsets.only(top: 12),
                                        child: Text('    ~    ', style: TextStyle(fontSize: 24, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                                      ),
                                      SizedBox(
                                        width: 160,
                                        child: AbsorbPointer(
                                          absorbing: mEventYn == 'Y' ? true : false,
                                          child: fluentUI.TimePicker(
                                            selected: enddate,
                                            onChanged: (time) {
                                              if (startdate!.compareTo(time) != -1){
                                                setState(() {
                                                  enddate = null;
                                                });
                                                ISAlert(context, content: '종료 시간이 시작 시간보다 작을 수 없습니다.');
                                                return;
                                              }
                                              else{
                                                setState(() {
                                                  enddate = time;
                                                });
                                              }
                                            },
                                            hourFormat: HourFormat.HH,
                                            minuteIncrement: 30,
                                            header: '   종료시간',
                                            headerStyle: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 12,),
                                AbsorbPointer(
                                  absorbing: mEventYn == 'Y' ? true : false,
                                  child: ISToggleButtons(
                                    [
                                      ISOptionModel(value: '30', label: '30분'),
                                      ISOptionModel(value: '60', label: '1시간'),
                                      ISOptionModel(value: '120', label: '2시간'),
                                      ISOptionModel(value: '180', label: '3시간'),
                                      ISOptionModel(value: '240', label: '4시간'),
                                      ISOptionModel(value: '300', label: '5시간'),
                                    ],
                                    defaultValue: selectedTimeType,
                                    buttonWidth:  65,
                                    buttonHeight: 32,
                                    afterOnPress: (v) {
                                      DateTime tempDT = startdate!.add(Duration(minutes: int.parse(v.toString())));

                                      debugPrint('month:${tempDT.month}, day:${tempDT.day}, hour:${tempDT.hour}, min:${tempDT.minute}');

                                      if (tempDT.day != startdate!.day){
                                        enddate = null;
                                        setState(() {
                                        });
                                        ISAlert(context, content: '종료 시간은 23:59분을 넘을 수 없습니다.');
                                        return;
                                      }
                                      else{
                                        enddate = tempDT;
                                        setState(() {
                                        });
                                      }
                                    },
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
          trailing: Row(
            children: [
              mEventYn == 'Y' ? SlideCountdown(
                duration: timer,
                decoration: const BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.all(Radius.circular(5)),
                ),
                onDone: (){
                  setState(() {
                    ISAlert(context, content: '금일 이벤트가 종료되었습니다.\n다음에 이용해주세요!');
                    router.go('/');
                  });
                },
              ) : Container(),
              const SizedBox(width: 10,),
              ISButton(
                buttonColor: Colors.red,
                onPressed: () {
                  formData = LiveEventInfoEditModel();
                  if(mEventYn == 'N'){
                    if(_eventTitle == '' || _eventTitle == null){
                      ISAlert(context, content: '라이브 이벤트 제목이 존재하지 않습니다.');
                      return;
                    }
                    if(startdate == '' || startdate == null || enddate == '' || enddate == null){
                      ISAlert(context, content: '라이브 이벤트 등록 시간이 존재하지 않습니다.');
                      return;
                    }
                    if(dataList.length == 0){
                      ISAlert(context, content: '메뉴가 존재하지 않습니다. 메뉴 등록 후 이용해 주세요');
                      return;
                    }
                    formData.jobGbn = 'I';
                    formData.shopCd = AuthService.SHOPCD!;
                    formData.eventTitle = _eventTitle;
                    formData.frTime = DateFormat('HHmm').format(startdate!).toString().replaceAll(':', '');
                    formData.toTime = DateFormat('HHmm').format(enddate!).toString().replaceAll(':', '');
                    formData.uName = AuthService.uName;
                    dataList.forEach((element) {
                      formData.menuCd ??= [];
                      formData.menuCd!.add(element.menuCd!);
                    });
                    dataList.forEach((element) {
                      formData.eventAmtGbn ??= [];
                      formData.eventAmtGbn!.add(eventGbn!);
                    });
                    dataList.forEach((element) {
                      formData.eventAmt ??= [];
                      formData.eventAmt!.add(element.eventAmt!);
                    });
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => LiveeventmanagerEdit(iData: formData,),
                    ).then((value) {
                      setState(() {
                        dataList.clear();
                      requestAPIData();
                      });
                    });
                  }else{
                    formData.jobGbn = 'D';
                    formData.shopCd = AuthService.SHOPCD!;
                    formData.eventTitle = mEventTitle;
                    formData.frTime = DateFormat('HHmm').format(startdate!).toString().replaceAll(':', '');
                    formData.toTime = DateFormat('HHmm').format(enddate!).toString().replaceAll(':', '');
                    formData.uName = AuthService.uName;
                    dataList.forEach((element) {
                      formData.menuCd ??= [];
                      formData.menuCd!.add(element.menuCd!);
                    });
                    dataList.forEach((element) {
                      formData.eventAmtGbn ??= [];
                      formData.eventAmtGbn!.add(eventGbn!);
                    });
                    dataList.forEach((element) {
                      formData.eventAmt ??= [];
                      formData.eventAmt!.add(element.menuDiscCost!!);
                    });
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => LiveeventmanagerEdit(dData: formData,),
                    ).then((value) {
                      setState(() {
                        dataList.clear();
                      requestAPIData();
                      });
                    });
                  }
                },
                child: Text(mEventYn == 'Y' ? '종료' : '이벤트 등록'),
              ),
              mEventYn == 'Y' ? Container(
                padding: const EdgeInsets.only(left: 10),
                child: ISButton(
                  buttonColor: Colors.black,
                  onPressed: () {
                    ISConfirm(context, 'PUSH 알림을 발송하시겠습니까?', 'PUSH 이벤트 제공 동의 고객 중 매장 이용내역이 있는 고객에게 알림이 발송됩니다.', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 280), (context, isOK) async {
                      Navigator.of(context).pop();
                      if (isOK){
                        var value = await showDialog(
                            context: context,
                            barrierColor: Colors.transparent,
                            builder: (context) => FutureProgressDialog(CouponController.to.pushAlarm()));
                        if (value == null) {
                          ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                        }
                        else {
                        }
                        setState(() {
                        });
                      }
                    });

                  },
                  child: const Text('PUSH 알림 발송',style: TextStyle(color: Colors.white),),
                ),
              ) : Container(),
            ],
          ),
        ),
        const Divider(height: 1),
        ISLabelBarMain(
          leading: Row(
            children: [
              const Text('이벤트 메뉴', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
              const Tooltip(
                richMessage: TextSpan(
                  text: '이벤트 메뉴는 ',
                  children: [
                    TextSpan(
                      text: '최소 1개 ~ 최대 10개',
                      style: TextStyle(fontWeight: FontWeight.bold,color: Colors.lightBlueAccent),
                    ),
                    TextSpan(
                      text: "까지 등록 가능합니다.",
                    ),
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.only(left: 5.0, top: 2, right: 5.0),
                  child: Icon(Icons.help_outline, color: Colors.blue, size: 22,),
                ),
              ),
              (eventGbnTxt != '' && mEventYn != 'Y') ? Text('$eventGbnTxt이 적용되어 있습니다. 할인 금액 수정 시 우측의 이벤트메뉴 추가 버튼을 클릭해 주세요.', style: const TextStyle(color: Colors.blue, fontSize: 14, fontWeight: FontWeight.bold),) : Container(),
            ],
          ),
          trailing: mEventYn == 'Y' ? Container() : Padding(
            padding: const EdgeInsets.only(bottom: 10.0),
            child: ISButton(
              child: const Text('이벤트메뉴 추가'),
              onPressed: () {
                showDialog(
                  context: context,
                  barrierDismissible: true,
                  builder: (context) => LiveeventmanagerEdit(sData: dataList),
                ).then((value) {
                  if (value != null){
                    dataList.clear();
                    formData = LiveEventInfoEditModel();
                    dataList = value;

                    if(dataList[0].eventGbn == '1'){
                      eventGbn = '1';
                      eventGbnTxt = '${Utils.getCashComma(dataList[0].menuDiscCost!)}원 할인';
                    }else {
                      eventGbn = '3';
                      eventGbnTxt = '${dataList[0].menuDiscPer}% 할인';
                    }

                    debugPrint('dataList.length:${dataList.length}');

                    setState(() {

                    });
                  }
                });
              },
            ),
          ),
        ),
        Material(
          child: ISDatatable(
            listWidth: Responsive.getResponsiveWidth(context), //MediaQuery.of(context).size.width,
            listHeight: contentHeight - 620,
            minWidth: 500,
            headingRowHeight: 36,
            dataRowHeight: 40,
            //controller: _scrollController,
            rows: dataList.map((item) {
              return DataRow(
                  selected: item.selected!,
                  color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
                    if (item.selected == true) {
                      return Colors.grey.shade300;
                      //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
                    }

                    return Theme.of(context).colorScheme.primary.withOpacity(0.00);
                  }),
                  onSelectChanged: (bool? value) {
                    dataList.forEach((element) {
                      element.selected = false;
                    });

                    item.selected = true;

                    // showDialog(
                    //   context: context,
                    //   barrierDismissible: true,
                    //   builder: (context) => const OrderDetailInfo(),
                    // );

                    //setState(() {});
                  },
                  cells: [
                    DataCell(Align(alignment: Alignment.center, child: Text(item.menuIdx.toString() == null ? '--' : item.menuIdx.toString(), style: const TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black, fontSize: 14)),)),
                    DataCell(Align(alignment: Alignment.centerLeft, child: Text(item.menuName.toString() == null ? '--' : item.menuName.toString(), style: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black, fontSize: 14)),)),
                    DataCell(Align(alignment: Alignment.centerRight, child: Text('${Utils.getCashComma(item.menuPrice!)}원', style: const TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black, fontSize: 14)),)),
                    DataCell(Align(alignment: Alignment.centerRight, child: Text('${Utils.getCashComma(item.menuDiscCost.toString())}원', style: const TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black, fontSize: 14)),)),
                    DataCell(Align(alignment: Alignment.centerRight, child: Text('${Utils.getCashComma(item.menuDiscPer.toString())}%', style: const TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black, fontSize: 14)),)),
                    DataCell(Align(alignment: Alignment.centerRight, child: Text('${Utils.getCashComma(item.totalPrice.toString())}원', style: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black, fontSize: 14),),                    )),
                    DataCell(Align(
                        alignment: Alignment.center,
                        child: OutlinedButton(
                          style: ButtonStyle(side: MaterialStateProperty.all(const BorderSide(color: Colors.red))),
                          onPressed: () {
                            _deleteEventMenu(item);
                          },
                          child: const Text('삭제', style: TextStyle(color: Colors.red),),
                        ))),
                  ]);
            }).toList(),
            columns: const <DataColumn>[
              DataColumn(label: Expanded(child: Text('순번', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('메뉴이름', textAlign: TextAlign.left)),),
              DataColumn(label: Expanded(child: Text('금액', textAlign: TextAlign.right)),),
              DataColumn(label: Expanded(child: Text('할인금액', textAlign: TextAlign.right)),),
              DataColumn(label: Expanded(child: Text('할인율', textAlign: TextAlign.right)),),
              DataColumn(label: Expanded(child: Text('적용금액', textAlign: TextAlign.right)),),
              DataColumn(label: Expanded(child: Text('관리', textAlign: TextAlign.center)),),
            ],
          ),
        ),
        // Container(
        //   width: double.infinity,
        //   alignment: Alignment.center,
        //   padding: const EdgeInsets.symmetric(vertical: 22),
        //   child: ISButton(
        //     width: 128,
        //     height: 52,
        //     child: const Text('이벤트 등록'),
        //     onPressed: () {},
        //   ),
        // )
      ];
  }
}
