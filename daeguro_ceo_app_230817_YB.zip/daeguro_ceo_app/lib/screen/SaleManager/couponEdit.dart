import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/models/SaleManager/couponDetailModel.dart';
import 'package:daeguro_ceo_app/models/SaleManager/couponEditModel.dart';
import 'package:daeguro_ceo_app/models/SaleManager/couponListModel.dart';
import 'package:daeguro_ceo_app/models/SaleManager/couponNewItemModel.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class CouponEdit extends StatefulWidget {
  final CouponListModel? sData;

  const CouponEdit({Key? key, this.sData}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CouponEditState();
  }
}

enum RadioOrderGbn { requireGbnDeli, requireGbnPack,  requireGbnBoth}

class CouponEditState extends State<CouponEdit> {

  CouponEditModel formData = CouponEditModel();

  RadioOrderGbn? _radioOrderGbn;

  String? frdate = '';
  String? todate = '';

  List<ISOptionModel> selectBox_discCost = [];
  List<CouponDetailModel> mDetailData = <CouponDetailModel>[];
  List<CouponItemModel> mCouponAddList = <CouponItemModel>[];

  String minTipCost = '0';

  requestAPIData(String couponType) async {
    var value = await showDialog(
      context: context,
      barrierColor: Colors.transparent,
      builder: (context) => FutureProgressDialog(CouponController.to.getCouponSetDetailList(couponType)),
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
      //Navigator.of(context).pop;
    }
    else {
      mDetailData.clear();

      value.forEach((element) {
        CouponDetailModel temp = CouponDetailModel();
        temp.itemCd = element['itemCd'] as String;
        temp.couponType = element['couponType'] as String;
        temp.couponAmt = element['couponAmt'] as String;
        temp.applyMinAmt = element['applyMinAmt'] as String;

        mDetailData.add(temp);
      });

      if (mDetailData.isNotEmpty){
        mDetailData.forEach((element) {
          mCouponAddList.add(CouponItemModel(element.applyMinAmt, element.couponAmt));
        });
      }

    }

    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    selectBox_discCost.clear();
    mDetailData.clear();
    mCouponAddList.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(CouponController());

    int startCost = 1000;
    selectBox_discCost.add(ISOptionModel(value: '', label: '할인 금액'));
    selectBox_discCost = List.generate(19, (index) {
      return ISOptionModel(value: (startCost+(index*500)).toString(), label: '${Utils.getCashComma((startCost+(index*500)).toString()) }원');
    });

    formData.shopCd = AuthService.SHOPCD;
    formData.uCode = AuthService.uCode;
    formData.uName = AuthService.uName;

    if (widget.sData == null){
      formData.jobGbn = '1';// 1:등록, 2:수정
      formData.applyGbn = 'D';
      formData.couponName = '';
      formData.displayStDate = '';
      formData.displayEndDate = '';
      formData.applyMinAmt = null;
      formData.couponAmt = null;
      formData.expSetDate = '14';
      formData.useGbn = 'Y';
      formData.seq = '';
      formData.couponType = '';

      _radioOrderGbn = RadioOrderGbn.requireGbnDeli;

      mCouponAddList.add(CouponItemModel('0', '1000'));

      frdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
      todate = formatDate(DateTime(int.parse(DateTime.now().year.toString()), int.parse(DateTime.now().month.toString()) + 1, 0), [yyyy, '-', mm, '-', dd]);
    }
    else{
      minTipCost = widget.sData!.tipFrStand.toString();

      formData.jobGbn = '2';// 1:등록, 2:수정
      formData.applyGbn = widget.sData!.applyGbn;
      formData.couponName = widget.sData!.couponName;
      formData.displayStDate = widget.sData!.displayStDate;
      formData.displayEndDate = widget.sData!.displayEndDate;
      // formData.applyMinAmt = widget.sData!.applyGbn;
      // formData.couponAmt = widget.sData!.applyGbn;
      formData.expSetDate = widget.sData!.expSetDate;
      formData.useGbn = widget.sData!.useGbn;
      formData.seq = widget.sData!.seq;
      formData.couponType = widget.sData!.couponType;

      if (formData.applyGbn == 'D')         _radioOrderGbn = RadioOrderGbn.requireGbnDeli;
      else if (formData.applyGbn == 'T')    _radioOrderGbn = RadioOrderGbn.requireGbnPack;
      else if (formData.applyGbn == 'A')    _radioOrderGbn = RadioOrderGbn.requireGbnBoth;
      else                                  _radioOrderGbn = RadioOrderGbn.requireGbnDeli;


      //mDetailList.add(CouponItemModel());

      frdate = DateFormat('yyyy-MM-dd').format(DateTime.parse(formData.displayStDate.toString())).toString();
      todate = DateFormat('yyyy-MM-dd').format(DateTime.parse(formData.displayEndDate.toString())).toString();
    }

    WidgetsBinding.instance.addPostFrameCallback((c) {
      if (widget.sData == null){
        setState(() {});
      }
      else{
        requestAPIData(formData.couponType!);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();//.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text(widget.sData == null ? '쿠폰 등록' : '쿠폰 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //const Divider(color: Colors.grey, height: 0.0,),
                const SizedBox(height: 16,),
                const Text('· 쿠폰의 최소 주문 금액에 따라 하나의 이벤트 당 최대 3개의 할인쿠폰을 등록할 수 있습니다.', style: TextStyle(color: Colors.black87, fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                const SizedBox(height: 8),
                const Text('· 쿠폰 할인금액은 사장님이 부담하는 금액으로, 바로결제 정산시 입금되지 않습니다.', style: TextStyle(color: Colors.black87, fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                if (widget.sData != null)...[
                  const SizedBox(height: 8),
                  const Text('· 쿠폰을 수정할 경우 적용기간만 수정 가능합니다.', style: TextStyle(color: Colors.red, fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                ],
                const SizedBox(height: 16),
                Row(
                  children: [
                    Text('쿠폰 이름', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                    SizedBox(width: 3,),
                    Tooltip(
                        richMessage: TextSpan(
                          text: '쿠폰 이름은 사장님 사이트에서 사장님에게만 보이고, 고객에게는 노출되지 않습니다.\n',
                          children: [
                            TextSpan(
                              text: 'TIP',
                              style: TextStyle(fontWeight: FontWeight.bold,color: Colors.lightBlueAccent),
                            ),
                            TextSpan(
                              text: " : '9월 3주차 오천원 쿠폰'과 같이 쿠폰 적용 기간, 할인 금액 등을 추가하면 쉽게 구분 할 수 있어요!",
                            ),
                          ],
                        ),
                        child: Icon(Icons.help_outline, color: Colors.blue,),
                    )
                  ],
                ),
                const SizedBox(height: 8),
                ISInput(
                  //autofocus: true,
                  value: formData.couponName,
                  readOnly: (widget.sData == null) ? false : true,
                  height: 64,
                  //padding: 0,
                  context: context,
                  label: '최대 40Byte까지 입력 가능',
                  maxLength: 40,
                  onChange: (v) {
                    formData.couponName = v;
                  },
                ),
                const SizedBox(height: 8),
                ISLabelBarSub(
                  title: '금액 설정',
                  height: 30,
                  underLine: false,
                  backgroundColor: Colors.transparent,
                  titlePadding: EdgeInsets.zero,
                  bodyPadding: EdgeInsets.zero,
                  trailing: (widget.sData == null) ? ISButton(
                      width: 60,
                      child: const Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.add),
                          Text('쿠폰 추가')
                        ],
                      ),
                      //onPressed: () => _addOptionGroup()
                      onPressed: () {
                        mCouponAddList.add(CouponItemModel('0', '1000'));
                        setState(() {

                        });
                      }
                  ) : const SizedBox.shrink(),
                  body: SizedBox(
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text.rich(
                            style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                            textAlign: TextAlign.end,
                            TextSpan(
                                children: [
                                  const TextSpan(text: '* 우리 매장의 배달 최소 주문 금액은 '),
                                  TextSpan(text: Utils.getCashComma(minTipCost), style: const TextStyle(color: Colors.lightBlue)),
                                  const TextSpan(text: '원 입니다.')
                                ]
                            )
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: DataTable(
                            headingRowHeight: 0.01,
                            dataRowHeight: 46.0,
                            columnSpacing: 0.01,
                            horizontalMargin: 8,
                            dividerThickness: 0.01,
                            columns: const [
                              DataColumn(label: Expanded(child: Text('0', textAlign: TextAlign.right))),
                              DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.center))),
                              DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.center))),
                              DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.center))),
                            ],
                            rows: mCouponAddList.map((item){
                              return DataRow(
                                  cells: [
                                    DataCell(Align(alignment: Alignment.centerRight,
                                        child: ISInput(
                                          readOnly: (widget.sData == null) ? false : true,
                                          textAlign: TextAlign.end,
                                          value: Utils.getCashComma(item.frCost!),
                                          //textAlign: TextAlign.start,
                                          width: 100,
                                          maxLines: 1,
                                          label: '최소주문금액',
                                          onChange: (v) {
                                            setState(() {
                                              item.frCost = v.toString().replaceAll(',', '');
                                            });
                                          },
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                        )
                                      )
                                    ),
                                    DataCell(Align(alignment: Alignment.center, child: const Text('원 이상 주문 시', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))),
                                    DataCell(Align(alignment: Alignment.center,
                                      child: ISSearchDropdown(
                                        ignoring: (widget.sData == null) ? false : true,
                                        width: 110,
                                        height: 46,
                                        label: '할인 금액',
                                        value: item.discCost,
                                        onChange: (value) {
                                          setState(() {
                                            item.discCost = value;

                                            debugPrint('item.discCost:${item.discCost}');
                                            //_query();
                                          });
                                        },
                                        item: selectBox_discCost,
                                      ),
                                    )
                                    ),
                                    DataCell(Align(alignment: Alignment.center,
                                        child: InkWell(
                                          child: Icon(Icons.cancel, color: widget.sData == null ? Color(0xff01CAFF) : Colors.grey.shade400, size: 21),
                                          onTap: (){
                                            if (widget.sData != null){
                                              return;
                                            }
                                            mCouponAddList.remove(item);
                                            setState(() {

                                            });
                                          },
                                        )
                                    )
                                    ),
                                  ]
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                  ),
                  //trailing: ,
                ),
                const SizedBox(height: 8),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('쿠폰 주문 유형', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                        Row(
                          children: [
                            Radio(
                                value: RadioOrderGbn.requireGbnDeli,
                                groupValue: _radioOrderGbn,
                                onChanged: (v) async {
                                  if (widget.sData != null){
                                    return;
                                  }

                                  setState(() {
                                    _radioOrderGbn = v as RadioOrderGbn?;
                                    formData.applyGbn == 'D';
                                  });
                                }),
                            const Text('배달', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const SizedBox(width: 10,),
                            Radio(
                                value: RadioOrderGbn.requireGbnPack,
                                groupValue: _radioOrderGbn,
                                onChanged: (v) async {
                                  if (widget.sData != null){
                                    return;
                                  }

                                  setState(() {
                                    _radioOrderGbn = v as RadioOrderGbn?;
                                    formData.applyGbn == 'T';
                                  });
                                }),
                            const Text('포장', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const SizedBox(width: 10,),
                            Radio(
                                value: RadioOrderGbn.requireGbnBoth,
                                groupValue: _radioOrderGbn,
                                onChanged: (v) async {
                                  if (widget.sData != null){
                                      return;
                                  }

                                  setState(() {
                                    _radioOrderGbn = v as RadioOrderGbn?;
                                    formData.applyGbn == 'A';
                                  });
                                }),
                            const Text('배달/포장', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                          ],
                        )

                      ],
                    ),
                    const SizedBox(height: 8,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                        const Text('적용 기간', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                            SizedBox(width: 3,),
                            Tooltip(
                                message: '1. 쿠폰 적용 시작일은 오늘로부터 1개월 이내로 설정 가능합니다.\n2. 적용 기간은 시작일로부터 최소 7일, 최대 1년까지 설정 가능합니다.',
                                child: Icon(Icons.help_outline, color: Colors.blue,),
                            )
                          ],
                        ),
                        Material(
                          child: ISSearchSelectDate(
                            label: '기간 선택',
                            width: 230,
                            value: '${frdate.toString()} ~ ${todate.toString()}',
                            onTap: () async {
                              showGeneralDialog(
                                  context: context,
                                  barrierDismissible: true,
                                  barrierLabel: '',
                                  barrierColor: Colors.black54,
                                  pageBuilder: (context, animation, secondaryAnimation) {
                                    return Dialog(
                                        elevation: 0,
                                        backgroundColor: Colors.white,
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                                        child: MultipleViewDateRangePicker(
                                          startDate: DateTime.parse(frdate!),
                                          endDate: DateTime.parse(todate!),
                                          setDateActionCallback: ({startDate, endDate}) {
                                            if (widget.sData == null){
                                              frdate = DateFormat('yyyy-MM-dd').format(startDate!);
                                              todate = DateFormat('yyyy-MM-dd').format(endDate!);
                                            }
                                            else{
                                              String tempDate = DateFormat('yyyy-MM-dd').format(startDate!);

                                              if (frdate != tempDate){
                                                Navigator.of(context).pop();

                                                ISAlert(context, content: '시작일은 변경 불가합니다.');

                                                return;
                                              }
                                              else{
                                                frdate = DateFormat('yyyy-MM-dd').format(startDate!);
                                                todate = DateFormat('yyyy-MM-dd').format(endDate!);
                                              }
                                            }

                                            setState(() {
                                            });

                                            Navigator.of(context).pop();
                                          },
                                        ));
                                  });
                            },
                          ),
                        )

                      ],
                    ),
                    const SizedBox(height: 8,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('쿠폰 유효 기간', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                        ISSearchDropdown(
                          ignoring: (widget.sData == null) ? false : true,
                          width: 170,
                          label: '쿠폰 유효 기간',
                          value: formData.expSetDate,
                          onChange: (value) {
                            setState(() {
                              formData.expSetDate = value;
                              //_query();
                            });
                          },
                          item: [
                            ISOptionModel(value: '14', label: '발급일로 부터 14일'),
                            ISOptionModel(value: '30', label: '발급일로 부터 30일'),

                          ].cast<ISOptionModel>(),
                        ),

                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (formData.couponName == '' || formData.couponName == null) {
                ISAlert(context, content: '쿠폰 이름을 확인해주세요.');
                return;
              }

              ISConfirm(context, widget.sData == null ? '쿠폰 등록' : '쿠폰 수정', widget.sData == null ? '신규 쿠폰을 등록하시겠습니까?' : '쿠폰 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  List<String> applyMinAmtArr = [];
                  List<String> couponAmtArr = [];
                  if (mCouponAddList.isNotEmpty){
                    mCouponAddList.forEach((element) {
                      applyMinAmtArr.add(element.frCost!);
                      couponAmtArr.add(element.discCost!);
                    });
                  }

                  formData.applyMinAmt = applyMinAmtArr;
                  formData.couponAmt = couponAmtArr;
                  formData.displayStDate = frdate!.replaceAll('-', '');
                  formData.displayEndDate = todate!.replaceAll('-', '');

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(CouponController.to.setCoupon(formData.toJson()))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: Text(widget.sData == null ? '등록' : '변경', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


