

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponInfo_main.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponUseHistory_main.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponUseStatus_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopInfo_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopOperateInfo_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopRegistInfo_main.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CouponManagerMain extends StatefulWidget {
  const CouponManagerMain({Key? key}) : super(key: key);

  @override
  State<CouponManagerMain> createState() => _CouponManagerMainState();
}

class _CouponManagerMainState extends State<CouponManagerMain> with PageMixin{
  List<Tab> currTabs = <Tab>[
    const Tab(height: 60, text: '     쿠폰 관리     '),
    const Tab(height: 60, text: '     쿠폰 사용 내역     '),
    const Tab(height: 60, text: '     쿠폰 사용 현황     '),
  ];

  @override
  void initState() {
    super.initState();

    debugPrint('initState CouponManagerMain');

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {
    debugPrint('dispose CouponManagerMain');

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    double tapviewContentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 280 : 330);

    return fluentUI.ScaffoldPage.withPadding(
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: SizedBox(
        //width: double.infinity,
        height: tapviewContentHeight,
        child: DefaultTabController(
          initialIndex: 0,
          length: currTabs.length,
          child: Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              backgroundColor: Colors.transparent,
              elevation: 0.0,
              title: TabBar(
                indicatorColor: Colors.black,
                labelStyle: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
                unselectedLabelStyle: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                indicatorWeight: 10,
                indicatorSize: TabBarIndicatorSize.label,
                labelColor: Colors.black,
                isScrollable: true,
                padding: EdgeInsets.all(0),
                labelPadding: EdgeInsets.all(0),
                tabs: currTabs,
              ),
            ),
            body: TabBarView(
              physics: const NeverScrollableScrollPhysics(),
              children: <Widget>[
                CouponInfoMain(tabviewHeight: tapviewContentHeight),
                CouponUseHistoryMain(tabviewHeight: tapviewContentHeight),
                CouponUseStatusMain(tabviewHeight: tapviewContentHeight),
              ],
            ),
          ),
        ),
      ),
    );
  }

  requestAPIData() async {
  }
}