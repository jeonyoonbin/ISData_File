import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class CouponController extends GetxController{
  static CouponController get to => Get.find();

  int total_count = 0;
  int total_page = 0;
  int remainAmt = 0;

  int? totalDeposit = 0;
  int? totalWithdraw = 0;
  int? totalReward = 0;

  int? totIssueCnt = 0;
  int? totAmt = 0;
  int? totUseCnt = 0;

  String? liveEvent_shopName = '';
  String? liveEvent_shopLogo = '';
  String? liveEvent_eventYn = '';
  String? liveEvent_eventTitle = '';
  String? liveEvent_frTime = '';
  String? liveEvent_toTime = '';
  String? liveEvent_remainTime = '';
  String? liveEvent_pushYn = '';

  Future<List<dynamic>?> getCouponSetList(String searchGbn, String status, String startdate, String enddate, String page) async {
    List<dynamic> qData = [];

    String useGbn = (searchGbn == '1' || searchGbn == '3' ) ? '%' : 'N';

    final response = await DioClient().get('${ServerInfo.RESTURL_COUPONSETLIST}?shopCd=${AuthService.SHOPCD}&searchGbn=${searchGbn}&frDate=${startdate}&toDate=${enddate}&useGbn=${useGbn}&status=${status}&rows=10&page=${page}');

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['totalCnt'].toString());
      total_page = int.parse(response.data['pageCnt'].toString());

      debugPrint('totalCnt:${total_count}, total_page:${total_page}');

      qData.assignAll(response.data['data']);
    }
    else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getCouponSetDetailList(String couponType) async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_COUPONSETDETAIL}?shopCd=${AuthService.SHOPCD}&couponType=${couponType}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data2']);
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> setCoupon(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_COUPONSETDETAIL_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<List<dynamic>?> getCouponUseList(String packOrderGbn, String orderNo, String startdate, String enddate, String page) async {
    List<dynamic> qData = [];

    debugPrint('getCouponUseList packOrderGbn:${packOrderGbn}, orderNo:${orderNo}, startdate:${startdate}, enddate:${enddate}, page:${page}');

    final response = await DioClient().get('${ServerInfo.RESTURL_COUPONUSELIST}?shopCd=${AuthService.SHOPCD}&searchGbn=2&packOrderGbn=${packOrderGbn}&orderNo=${orderNo}&frDate=${startdate}&toDate=${enddate}&rows=10&page=${page}');

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['totalCnt'].toString());
      total_page = int.parse(response.data['pageCnt'].toString());
      totalDeposit = int.parse(response.data['totalCnt'].toString());
      totalWithdraw = int.parse(response.data['totalUseAmt'].toString());

      debugPrint('totalCnt:${total_count}, total_page:${total_page}');

      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getCouponStatusList(String jobGbn, String startdate, String enddate, String page) async {
    List<dynamic> qData = [];

    String rows = jobGbn == '2' ? '9999' : '9';

    final response = await DioClient().get('${ServerInfo.RESTURL_COUPONSTATUSLIST}?jobGbn=${jobGbn}&shopCd=${AuthService.SHOPCD}&frDate=${startdate}&toDate=${enddate}&rows=${rows}&page=${page}');

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['totalCnt'].toString());
      total_page = int.parse(response.data['pageCnt'].toString());
      totIssueCnt = int.parse(response.data['totIssueCnt'].toString());
      totAmt = int.parse(response.data['totAmt'].toString());
      totUseCnt = int.parse(response.data['totUseCnt'].toString());

      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getPackDiscountInfo() async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_PACKDISCOUNTINFO}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    }
    else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getLiveEventMenuList() async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_LIVEEVENTMENULIST}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }
    return qData;
  }

  Future<List<dynamic>?> getShopTogoDisc() async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_LIVEEVENTMENULIST}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getLiveEventInfo() async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_LIVEEVENTINFO}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      liveEvent_shopName = response.data['shopName'].toString();
      liveEvent_shopLogo = response.data['shopLogo'].toString();
      liveEvent_eventYn = response.data['eventYn'].toString();
      liveEvent_eventTitle = response.data['eventTitle'].toString();
      liveEvent_frTime = response.data['frTime'].toString();
      liveEvent_toTime = response.data['toTime'].toString();
      liveEvent_remainTime = response.data['remainTime'].toString();
      liveEvent_pushYn = response.data['pushYn'].toString();

      qData = response.data['data'];
    }
    else {
      return '99';//response.data['code'];
    }

    return qData;
  }

  Future<dynamic> setShopLiveEvent(dynamic data) async {
    print(data);
    final response = await DioClient().post(ServerInfo.RESTURL_SHOPLIVEEVENT_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> setShopLiveMenuDel(String shopCd, String menuCd, String uName) async {
    final response = await DioClient().put('${ServerInfo.RESTURL_SHOPLIVEMENU_DEL}?shopCd=$shopCd&menuCd=$menuCd&uName=$uName');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> pushAlarm() async {
    final response = await DioClient().post('${ServerInfo.RESTURL_SHOPLIVEEVENTPUSHALARM}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }
}