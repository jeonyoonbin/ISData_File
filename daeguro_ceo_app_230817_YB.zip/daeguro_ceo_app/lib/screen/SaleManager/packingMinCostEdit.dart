import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionListModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class PackingMinCostEdit extends StatefulWidget {
  final String? discAmt;
  final String? minAmt;
  final String? minDiscAmt;

  const PackingMinCostEdit({Key? key, this.discAmt, this.minAmt, this.minDiscAmt})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return PackingMinCostEditState();
  }
}

class PackingMinCostEditState extends State<PackingMinCostEdit> {

  String? toGoDiscAmt = '0';//[포장할인금액]
  String? toGoMinAmt = '0';// [최소주문금액]
  String? toGoMinDiscAmt = '0';// [포장할인 최소 적용 금액]

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    toGoDiscAmt = widget.discAmt;
    toGoMinAmt = widget.minAmt;
    toGoMinDiscAmt = widget.minDiscAmt;
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text('포장 설정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            //const Divider(color: Colors.grey, height: 0.0,),
            const SizedBox(height: 16,),
            ISLabelBarSub(
              title: '최소 주문금액',
              body: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Material(
                    color: Colors.transparent,
                    child: ISInput(
                      context: context,
                      value: Utils.getCashComma(toGoMinAmt!),
                      textAlign: TextAlign.end,
                      width: 120,
                      label: '최소 주문금액',
                      onChange: (v) {
                        toGoMinAmt = v.toString().replaceAll(',', '');
                      },
                    ),
                  ),
                  const SizedBox(width: 8,),
                  const Text('원', style: TextStyle(fontSize:16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              ISConfirm(context, '포장 설정', '최소 주문금액 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  var value = await showDialog(
                      context: context,
                      barrierColor: Colors.transparent,
                      builder: (context) => FutureProgressDialog(ShopController.to.updateShopInfo('7', toGoDiscAmt!, toGoMinAmt!, toGoMinDiscAmt!))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


