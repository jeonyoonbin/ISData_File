import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:get/get.dart';

class NoticeController extends GetxController{
  static NoticeController get to => Get.find();

  int total_count = 0;
  //int total_page = 0;

  Future<List<dynamic>?> getNoticeList(dynamic data) async {
    List<dynamic> qData = [];

    final response = await DioClient().post('${ServerInfo.RESTURL_NOTICELIST}', data: data);

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['totalCnt'].toString());
      //total_page = int.parse(response.data['pageCnt'].toString());

      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getNoticeDetail(String jobGbn, String seq) async {
    dynamic qData;

    final response = await DioClient().post('${ServerInfo.RESTURL_NOTICELISTDETAIL}?jobGbn=${jobGbn}&seq=${seq}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }
}