


import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';

class FAQPOSInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const FAQPOSInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<FAQPOSInfoMain> createState() => _FAQPOSInfoMainState();
}

class _FAQPOSInfoMainState extends State<FAQPOSInfoMain> {

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    fluentUI.ButtonState<Color> headerColor = fluentUI.ButtonState.resolveWith((states) => Colors.grey.shade200);
    const headerTextStyle = TextStyle(fontSize: 16, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);
    const contentTextStyle = TextStyle(fontSize: 15, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);//letterSpacing: 0.6,

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FAQform(headerColor, headerTextStyle, contentTextStyle,'POS기가 없을 경우는 어떻게 하나요?','모바일로 접수를 받아야 하고, 대신 영수증 출력을 하지 못해서 수기로 작성을 해야 합니다.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'POS 설치는 무료인 것인지?','설치에 대한 비용은 별도로 없으며, 대구로 주문은을 받을 수 있도록 영업사원이 방문하고나 아웃바운드를 통해 설치를 도와드립니다.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'POS 설치하면 영수증 출력까지 되는 건지?','영수증 출력까지 되도록 설치해드릴 것입니다.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'영수증 프린터는 어떻게 연결할 수 있나요?','쓰시는 다른 주문앱 (예를 들어, 배달의 민족) 있다면 해당 프로그램의 환경설정에서 프린터가 연결된 포트를 확인해주세요. 해당 포트를 동일하게 대구로에서도 설정을 하고 저장 후 프로그램을 재시작 해주시면 됩니다.\n만약 다른 주문앱을 사용하는 것이 없다면,\n장치 관리자 → 포트 (COM & LPT) → 통신 포트 (COM1) 확인.\nCOM1에 연결되어있다는 뜻이므로, 대구로에 COM1 연결',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'POS기로 로그인 했는데 로그인 정보가 없다고 떠요.','Windows XP Service Pack 3 이상 Windows POS Ready 2009 Service Pack 1 이상이어야 가능해서 확인해보고, 버전 낮으면 설치하셔야 한다고 안내.',56),
        ],
          ),
    );
  }
  fluentUI.Expander FAQform(fluentUI.ButtonState<fluentUI.Color> headerColor, fluentUI.TextStyle headerTextStyle, fluentUI.TextStyle contentTextStyle, headerText, contentText, headerHeight) {
    return fluentUI.Expander(
        headerHeight: headerHeight,
        contentPadding: EdgeInsets.symmetric(vertical: 15,horizontal: 10),
              headerBackgroundColor: headerColor,
              shapeRadius: 0.0,
              contentBackgroundColor: Colors.transparent,
        header: Text(headerText, style: headerTextStyle),
        content: SingleChildScrollView(
            child: Text(contentText,
                      style: contentTextStyle)
              )
    );
  }

  requestAPIData() async {
  }
}