


import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';

class FAQOperateInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const FAQOperateInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<FAQOperateInfoMain> createState() => _FAQOperateInfoMainState();
}

class _FAQOperateInfoMainState extends State<FAQOperateInfoMain> {

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    fluentUI.ButtonState<Color> headerColor = fluentUI.ButtonState.resolveWith((states) => Colors.grey.shade200);
    const headerTextStyle = TextStyle(fontSize: 16, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);
    const contentTextStyle = TextStyle(fontSize: 15, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);//letterSpacing: 0.6,

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[수수료] 수수료는 어떻게 되나요?','중개 수수료 2% [VAT 별도, 주문앱을 통한 모든 주문완료 건에 부과]\n카드결제 수수료(앱바로결제 수수료) 2.2%',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[수수료] 카드 결제 수수료는 어떤 건가요?','앱 바로 결제로서, 고객이 ‘대구로’ 앱을 통해 카드등록 및 간편결제를 진행하면 발생하게 되는 수수료이며, 사장님들의 부담을 낮추기위해 카드수수료율을 최대한 낮추었습니다.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[리뷰] 리뷰 별점 집계 기준은 어떻게 되나요?','최근 6개월(180일) 내 가게에 표시되어있는 리뷰 기준입니다.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[리뷰] 사장님 댓글은 언제까지 작성할 수 있나요?','고객이 리뷰를 작성한 완료일로부터 30일간 가능합니다.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[리뷰] 고객이 리뷰 며칠까지 작성할 수 있나요?','주문 완료로부터 3일 간 작성 가능합니다.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[리뷰] 라이더가 (늦게 도착해서 or 잘못 배달해서) 리뷰 별점을 낮게 썼어요. 이런 것은 어떻게 처리해야 하나요?','대구로는 악성댓글 및 음식과 관계없는 리뷰에 대한 필터링 및 대처를 위해 여러가지 시스템을 준비중이나, 현재로서는 운영사를 통해 대처할 수 있도록 진행중입니다. 악성댓글하나가 사장님의 사업에 영향을 끼치지 않도록 최대한 도움을 드릴 수 있도록 할 것이며, 차후 리뷰시스템을 대체할 수 있는 여러가지 시스템을 기획중이니 기대해주세요.\n※ 악성리뷰 처리방법 : 사장님 사이트 → ‘리뷰관리’ → ‘신고’ → ‘신고내용 작성’\n※ 악성리뷰기준 – 욕설, 욕설단어일부를 마스킹 처리한 리뷰, 음란한 내용, 청소년에게 부적합한 리뷰, 타가게 홍보리뷰, 개인정보 노출 리뷰, 주문한음식 또는 가게와 관련없는 리뷰, 운영사를 사칭한 경우 등',Responsive.isMobile(context) ? 100 : 56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[노출기준] 제가 배달의 민족에서 샵앤샵(사업자등록번호 1개로 다중 브랜드 매장을운영할 때)하고 있는데 대구로에서는 어떻게 해요?','현재는 사업자 하나당 1개씩 올리실 수 있습니다. 곧 샵앤샵 매장도 운영할 수 있도록 준비중이니 현재는 대표 상점만 선정하셔서 입점진행해주시면 감사하겠습니다.',Responsive.isMobile(context) ? 100 : 56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[노출기준] 대구로에 저희 가게매장을 상단에 노출하고 싶은데, 기준이 뭔가요?','현재 추천순/거리순/별점높은순/주문많은순/신규매장순 으로 필터를 제공하고 있습니다. 어플의 기본설정 값은 추천 순이며, 추천의 기준은 리뷰와 별점이 많은 순이나 현재는 대구로 리뷰/별점이 없으므로 기본 거리순으로 정렬됩니다.',Responsive.isMobile(context) ? 100 : 56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[정산] 정산 관련해서 궁금해요.','대구로는 타주문앱사들과는 차별화전략으로서, 앱바로결제에 대한 정산을 즉시 해드립니다. 만약 20,000원짜리 주문을 배달완료하셨다면, 그 즉시 사장님들이 출금할 수 있는 적립금으로서 지급이 됩니다.\n적립내역확인 : 사장님 사이트 → ‘적립내역’\n적립금 출금 : 사장님 사이트 → ‘계좌정보’ → ‘출금하기’ → 매장정보에 등록된 휴대전화로 인증 후 출금 가능',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[정산] 적립금 출금 시 통장에 어떻게 보이나요?','사장님이 만약 10만원을 출금요청하시면, 대구로 앱을 개발한 ‘인성데이타(주)’가 99,800원을 사장님에게 계좌로 입금을 해드립니다. 출금 시 200원의 수수료가 발생하는데, 해당 수수료는 인성데이타(주)가 사용하는 가상계좌 시스템의 사용료입니다.',56),
        ],
          ),
    );
  }

  fluentUI.Expander FAQform(fluentUI.ButtonState<fluentUI.Color> headerColor, fluentUI.TextStyle headerTextStyle, fluentUI.TextStyle contentTextStyle, headerText, contentText, headerHeight) {
    return fluentUI.Expander(
        headerHeight: headerHeight,
        contentPadding: EdgeInsets.symmetric(vertical: 15,horizontal: 10),
              headerBackgroundColor: headerColor,
              shapeRadius: 0.0,
              contentBackgroundColor: Colors.transparent,
        header: Text(headerText, style: headerTextStyle),
        content: SingleChildScrollView(
            child: Text(contentText,
                      style: contentTextStyle)
              )
    );
  }

  requestAPIData() async {
  }
}