import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/OrderManager/orderDetailMenuModel.dart';
import 'package:daeguro_ceo_app/models/OrderManager/orderDetailModel.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class OrderDetailInfoFlower extends StatefulWidget {
  final String? orderNo;

  const OrderDetailInfoFlower({Key? key, this.orderNo}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return OrderDetailInfoFlowerState();
  }
}

class OrderDetailInfoFlowerState extends State<OrderDetailInfoFlower> {

  int _menuCnt = 0;

  OrderDetailModel mDetailList = OrderDetailModel();

  final List<OrderDetailMenuModel> menuDataList = <OrderDetailMenuModel>[];
  final List<OrderDetailMenuModel> mDetailAmount = <OrderDetailMenuModel>[];
  OrderDetailMenuModel temp2 = OrderDetailMenuModel();

  final List<List<String>> menuList = [];

  requestAPIData() async {
    mDetailList = OrderDetailModel();
    menuDataList.clear();

    var value = await showDialog(context: context, barrierColor: Colors.transparent,builder: (context) => FutureProgressDialog(AccountController.to.getShopOrderDetail('10', widget.orderNo.toString())));

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
      //Navigator.of(context).pop;
    } else {
      mDetailList.orderNo = value['orderNo'] as String;
      mDetailList.status = value['status'] as String;
      mDetailList.appPayGbn = value['appPayGbn'] as String;
      mDetailList.payGbn = value['payGbn'] as String;
      mDetailList.myNumber = value['myNumber'] as String;
      // mDetailList.shopRoadAddr = value['shopRoadAddr'] as String;
      // mDetailList.shopDongAddr = value['shopDongAddr'] as String;
      // mDetailList.shopAddrDetail = value['shopAddrDetail'] as String;
      mDetailList.custDongAddr = value['custDongAddr'] as String;
      mDetailList.custRoadAddr = value['custRoadAddr'] as String;
      mDetailList.custAddrDetail = value['custAddrDetail'] as String;
      mDetailList.shopDeliMemo = value['shopDeliMemo'] as String;
      mDetailList.riderDeliMemo = value['riderDeliMemo'] as String;
      mDetailList.menuDesc = value['menuDesc'] as String;
      mDetailList.reserDate = value['reserDate'] as String;
      mDetailList.senderName = value['senderName'] as String;
      mDetailList.senderTelno = value['senderTelno'] as String;
      mDetailList.receiverName = value['receiverName'] as String;
      mDetailList.receiverTelno = value['receiverTelno'] as String;
      mDetailList.custName = value['custName'] as String;
      mDetailList.telNo = value['telNo'] as String;

      String tempStr = mDetailList.menuDesc.toString();
      String editStr = tempStr.replaceAll(RegExp('\\.'), '');

      List<dynamic> conData = jsonDecode(editStr);

      // 메뉴 상세 내역
      conData.forEach((element) {
        OrderDetailMenuModel temp = OrderDetailMenuModel();

        temp.menuName = element['name'];
        temp.menuCost = element['cost'];
        temp.count = element['count'];
        temp.cost = element['saleCost'];
        temp.dataGbn = 'P';

        menuDataList.add(temp);

        menuList.add([
          element['name'],
          element['count'].toString(),
          element['saleCost'].toString(),
          'P',
        ]);

        // 메뉴 상세 옵션
        if (element['options'].toString() != '[]') {
          List<dynamic> optionsData = element['options'];

          optionsData.forEach((data) {
            menuList.add([' - ' + data['name'], data['count'].toString(), data['cost'].toString(), 'C']);
          });
        }

        if (element['selectOptions'].toString() != '[]') {
          List<dynamic> selectOptionsData = element['selectOptions'];

          selectOptionsData.forEach((data) {
            menuList.add([' - 추가옵션 : ' + data['name'], data['count'].toString(), data['cost'].toString(), 'C']);
          });
        }

        _menuCnt = _menuCnt + int.parse(element['count'].toString());

        // ribbonLeft, ribbonRight 이 null 인경우 리본 메세지가 아예없는 상품으로 표시하지 않음
        // ribbonLeft, ribbonRight 이 '' 로 공백인 경우 메세지를 입력 안한 것으로 '--' 로 표시
        if (element['ribbonLeft'].toString() == 'null' && element['ribbonRight'].toString() == 'null') {
        } else {
          menuList.add([' - 리본', '', '', 'C']);
        }

        if (element['ribbonRight'].toString() != 'null') {
          menuList.add([element['ribbonRight'].toString() == ''? '[우측] : --' : '[우측] : ' + element['ribbonRight'].toString(), '', '', 'CC']);
        }

        if (element['ribbonLeft'].toString() != 'null') {
          menuList.add([element['ribbonLeft'].toString() == ''? '[좌측] : --' : '[좌측] : ' + element['ribbonLeft'].toString(), '', '', 'CC']);
        }

        if (element['cardMsg'].toString() != 'null') {
          menuList.add([element['cardMsg'] == '' ? ' - 카드 : --' : ' - 카드 : ' + element['cardMsg'], '', '', 'C']);
        }
      });

      // 쿠폰 할인
      if (value['couponAmt'] != '0') {
        temp2 = OrderDetailMenuModel();

        temp2.menuName = '쿠폰';
        temp2.menuCost = null;
        temp2.count = null;
        temp2.cost = double.parse(value['couponAmt'].toString()) * -1;
        temp2.dataGbn = 'T';

        menuList.add(['쿠폰', '', temp2.cost.toString(), 'T']);
      }

      // 가맹점 할인
      if (value['shopCouponAmt'] != '0') {
        temp2 = OrderDetailMenuModel();

        temp2.menuName = '가맹점 쿠폰';
        temp2.menuCost = null;
        temp2.count = null;
        temp2.cost = double.parse(value['shopCouponAmt'].toString()) * -1;
        temp2.dataGbn = 'T';

        menuList.add(['가맹점 쿠폰', '', temp2.cost.toString(), 'T']);
      }

      // 착한매장 할인
      if (value['goodShopDiscAmt'] != '0') {
        temp2 = OrderDetailMenuModel();

        temp2.menuName = '착한매장 할인';
        temp2.menuCost = null;
        temp2.count = null;
        temp2.cost = double.parse(value['goodShopDiscAmt'].toString()) * -1;
        temp2.dataGbn = 'T';

        menuList.add(['착한매장 할인', '', temp2.cost.toString(), 'T']);
      }

      // 마일리지 사용
      if (value['mileageUseAmt'] != '0') {
        temp2 = OrderDetailMenuModel();

        temp2.menuName = '마일리지';
        temp2.menuCost = null;
        temp2.count = null;
        temp2.cost = double.parse(value['mileageUseAmt'].toString()) * -1;
        temp2.dataGbn = 'T';

        menuList.add(['마일리지', '', temp2.cost.toString(), 'T']);
      }

      // 총 합계 표시
      temp2 = OrderDetailMenuModel();
      temp2.menuName = '총 결제 금액';
      temp2.menuCost = null;
      temp2.count = null;
      temp2.cost = double.parse(value['amount']);
      temp2.dataGbn = 'A';

      menuList.add(['총 결제 금액', '', temp2.cost.toString(), 'A']);
    }

    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    mDetailList = OrderDetailModel();
    menuDataList.clear();
    mDetailAmount.clear();
    temp2 = OrderDetailMenuModel();
    menuList.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(AccountController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>(); //.watch<AppTheme>();

    const receiptTitleTextStyle = TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: Colors.black87);
    const receiptContentTextStyle = TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: Colors.black87);

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 500.0, maxHeight: 750),
      contentPadding: const EdgeInsets.all(0.0),
      //const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text(
            '주문 상세',
            style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),
          ),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 8),
                Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: DataTable(
                        headingRowHeight: 24,
                        dataRowHeight: 27.0,
                        headingRowColor: MaterialStateProperty.all(
                          Colors.grey[100],
                        ),
                        // dataRowMinHeight: 22.0,
                        // dataRowMaxHeight: 40.0,
                        columnSpacing: 0,
                        horizontalMargin: 8,
                        headingTextStyle: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: Colors.black54),
                        dataTextStyle: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                        dividerThickness: 0.01,
                        columns: const [
                          DataColumn(label: Expanded(child: Text('항목', textAlign: TextAlign.left))),
                          DataColumn(label: Expanded(child: Text('수량', textAlign: TextAlign.center))),
                          DataColumn(label: Expanded(child: Text('금액', textAlign: TextAlign.right))),
                        ],
                        rows: menuList.map((item) {
                          return DataRow(cells: [
                            DataCell(Container(
                                margin: EdgeInsets.only(left: item[3] == 'CC' ? 20 : 0), // CC(child-child) 일경우 magin 설정
                                width: Responsive.isMobile(context) ? 150 : 320,
                                alignment: Alignment.centerLeft,
                                child: Text(item[0].toString(), style: TextStyle(fontWeight: FontWeight.bold, fontSize: _getFontSize(item[3].toString()), color: _getFontColor(item[3].toString()))))),
                            DataCell(Align(
                                alignment: Alignment.center,
                                child: Text(item[1].toString() == '' ? '' : Utils.getCashComma(item[1].toString()),
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: _getFontSize(item[3].toString()), color: _getFontColor(item[3].toString()))))),
                            DataCell(Align(
                                alignment: Alignment.centerRight,
                                child: Text(
                                    item[3] == 'A' || item[3] == 'T' || item[3] == 'TDC'
                                        ? Utils.getCashComma(item[2].toString())
                                        : item[1].toString() == '' || item[2].toString() == ''
                                        ? ''
                                        : Utils.getCashComma((double.parse(item[2].toString()) * double.parse(item[1].toString())).toString()),
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: _getFontSize(item[3].toString()), color: _getFontColor(item[3].toString()))))),
                          ]);
                        }).toList(),
                      ),
                    ),
                  ],
                ),
                const Divider(color: Colors.black),
                const SizedBox(
                  height: 8,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('예약배송 일자', style: receiptTitleTextStyle)),
                        SizedBox(width: Responsive.isMobile(context) ? 150 : 320, child: Text(mDetailList.reserDate.toString(), style: receiptContentTextStyle)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('주문유형', style: receiptTitleTextStyle)),
                        SizedBox(width: Responsive.isMobile(context) ? 150 : 320, child: Text(_getStatus(mDetailList.status.toString()), style: receiptContentTextStyle)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('결제방법', style: receiptTitleTextStyle)),
                        SizedBox(width:Responsive.isMobile(context) ? 150 : 320, child: Text(mDetailList.appPayGbn.toString(), style: receiptContentTextStyle)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('결제수단', style: receiptTitleTextStyle)),
                        SizedBox(width: Responsive.isMobile(context) ? 150 : 320,child: Text(mDetailList.payGbn.toString(), style: receiptContentTextStyle)),
                      ],
                    ),
                    const Divider(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('주문하신 분 정보', style: receiptTitleTextStyle)),
                        SizedBox(width: Responsive.isMobile(context) ? 150 : 320, child: Text('${mDetailList.custName} / ${Utils.getPhoneNumFormat(mDetailList.telNo.toString(), false)}', style: receiptContentTextStyle)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('보내는 분 정보', style: receiptTitleTextStyle)),
                        SizedBox(
                            width:Responsive.isMobile(context) ? 150 : 320, child: Text('${mDetailList.senderName} / ${Utils.getPhoneNumFormat(mDetailList.senderTelno.toString(), false)}', style: receiptContentTextStyle)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('받으시는분 정보', style: receiptTitleTextStyle)),
                        SizedBox(
                            width: Responsive.isMobile(context) ? 150 : 320,child: Text('${mDetailList.receiverName} / ${Utils.getPhoneNumFormat(mDetailList.receiverTelno.toString(), false)}', style: receiptContentTextStyle)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('배달주소(도로명)', style: receiptTitleTextStyle)),
                        SizedBox(width:Responsive.isMobile(context) ? 150 : 320, child: Text(mDetailList.custRoadAddr.toString(), style: receiptContentTextStyle)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('배달주소(지번)', style: receiptTitleTextStyle)),
                        SizedBox(width: Responsive.isMobile(context) ? 150 : 320, child: Text(mDetailList.custDongAddr.toString(), style: receiptContentTextStyle)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('배달 상세주소', style: receiptTitleTextStyle)),
                        SizedBox(width: Responsive.isMobile(context) ? 150 : 320, child: Text(mDetailList.custAddrDetail.toString(), style: receiptContentTextStyle)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('매장 요청사항', style: receiptTitleTextStyle)),
                        SizedBox(width: Responsive.isMobile(context) ? 150 : 320, child: Text(mDetailList.shopDeliMemo.toString(), style: receiptContentTextStyle)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(width: 120, child: Text('배달 요청사항', style: receiptTitleTextStyle)),
                        SizedBox(width: Responsive.isMobile(context) ? 150 : 320, child: Text(maxLines: 5, mDetailList.riderDeliMemo.toString(), style: receiptContentTextStyle)),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
      // actions: [
      //   SizedBox(
      //     child: FilledButton(
      //       style: appTheme.popupButtonStyleLeft,
      //       onPressed: () {
      //         Navigator.pop(context);
      //       },
      //       child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
      //     ),
      //   ),
      //   SizedBox(
      //     child: FilledButton(
      //       style: appTheme.popupButtonStyleRight,
      //       onPressed: () {
      //
      //       },
      //       child: const Text('등록', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
      //     ),
      //   ),
      // ],
    );
  }

  String _getStatus(String value) {
    String retValue = '--';

    if (value.toString().compareTo('10') == 0)
      retValue = '접수';
    else if (value.toString().compareTo('20') == 0)
      retValue = '대기';
    else if (value.toString().compareTo('30') == 0)
      retValue = '가맹점 접수확인';
    else if (value.toString().compareTo('35') == 0)
      retValue = '운행';
    else if (value.toString().compareTo('40') == 0)
      retValue = '완료';
    else if (value.toString().compareTo('50') == 0)
      retValue = '취소';
    else if (value.toString().compareTo('80') == 0)
      retValue = '결제대기';
    else
      retValue = '--';

    return retValue;
  }

  double _getFontSize(String value) {
    double retValue;

    if (value.toString().compareTo('P') == 0 || value.toString().compareTo('T') == 0)
      retValue = 14;
    else if (value.toString().compareTo('A') == 0)
      retValue = 14;
    else
      retValue = 13;

    return retValue;
  }

  // P:메인메뉴, C:옵션, A:총결제금액, T:포장할인,배달팁, TDC:배달팁할인
  Color _getFontColor(String value) {
    Color retValue;

    if (value.toString().compareTo('P') == 0 || value.toString().compareTo('T') == 0)
      retValue = Colors.black;
    else if (value.toString().compareTo('A') == 0)
      retValue = Colors.blueAccent;
    else
      retValue = Colors.black54;

    return retValue;
  }
}