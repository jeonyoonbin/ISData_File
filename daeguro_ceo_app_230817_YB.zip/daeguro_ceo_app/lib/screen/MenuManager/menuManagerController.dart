import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:get/get.dart';

class MenuInfoController extends GetxController{
  static MenuInfoController get to => Get.find();

  // String optionMultiCnt = '';
  // String optionMinCnt = '';
  // String optionMenuList = '';
  // String optionMultiYn = '';
  // String optionReqYn = '';

  Future<List<dynamic>?> getGroupList() async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_MENUGROUPLIST}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getMenuList(String menuGroupCd) async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_MENULIST}?shopCd=${AuthService.SHOPCD}&menuGroupCd=${menuGroupCd}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> addMenuGroup(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_MENUGROUP_ADD, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> updateMenuGroup(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_MENUGROUP_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> addMenu(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_MENU_ADD, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> updateMenu(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_MENU_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<List<dynamic>?> getOptionGroupList() async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_OPTIONGROUPLIST}?jobGbn=1&shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getOptionList(String optGrpCd) async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_OPTIONLIST}?shopCd=${AuthService.SHOPCD}&optGrpCd=${optGrpCd}');

    if (response.data['code'] == '00') {
      // optionMultiCnt = response.data['multiCnt'].toString();
      // optionMinCnt = response.data['minCnt'].toString();
      // optionMenuList = response.data['menuList'].toString();
      // optionMultiYn = response.data['multiYn'].toString();
      // optionReqYn = response.data['reqYn'].toString();

      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getOptionLinkList(String menuCd) async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_OPTIONGROUPLIST}?jobGbn=2&shopCd=${AuthService.SHOPCD}&menuCd=${menuCd}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getOptionLinkAddList(String menuCd) async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_OPTIONLINKLIST}?shopCd=${AuthService.SHOPCD}&menuCd=${menuCd}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> addOptionLink(dynamic data) async {
    final response = await DioClient().put('${ServerInfo.RESTURL_OPTIONLINK_SET}', data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> deleteOptionLink(String menuCd, String menuOptGrpCd) async {
    final response = await DioClient().put('${ServerInfo.RESTURL_OPTIONLINK_DEL}?shopCd=${AuthService.SHOPCD}&menuCd=${menuCd}&menuOptGrpCd=${menuOptGrpCd}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> addOptionGroup(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_OPTIONGROUP_ADD, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> updateOptionGroup(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_OPTIONGROUP_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> deleteOptionGroup(String groupCd) async {
    final response = await DioClient().put('${ServerInfo.RESTURL_OPTIONGROUP_DEL}?shopCd=${AuthService.SHOPCD}&groupCd=${groupCd}&uName=${AuthService.uName}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> addOption(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_OPTION_ADD, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> updateOption(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_OPTION_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> deleteOption(String optionCd) async {
    final response = await DioClient().put('${ServerInfo.RESTURL_OPTION_DEL}?shopCd=${AuthService.SHOPCD}&optionCd=${optionCd}&uName=${AuthService.uName}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<List<dynamic>?> getMenuLinkList(String optionGroupCd) async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_OPTIONGROUPMENULINKLIST}?shopCd=${AuthService.SHOPCD}&optGrpCd=${optionGroupCd}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateMenuLink(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_OPTIONGROUPMENULINK_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> getOriginData() async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_MENUORIGIN}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> setOptioGroupCount(String optionGroupCd, String minCnt, String multiCnt, String multiYn, String reqYn) async {
    final response = await DioClient().put('${ServerInfo.RESTURL_OPTIONGROUPCOUNT_SET}?shopCd=${AuthService.SHOPCD}&optGrpCd=${optionGroupCd}&reqYn=${reqYn}&minCount=${minCnt}&multiCount=${multiCnt}&multiYn=${multiYn}&uName=${AuthService.uName}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<List<dynamic>?> getTopMenuList() async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_MENUTOPMENULIST}?jobGbn=1&shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> addTopMenu(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_TOPMENU_ADD, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> removeTopMenu(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_TOPMENU_DEL, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<List<dynamic>?> getMenuSearchList(String keyword) async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_MENUSEARCHLIST}?shopCd=${AuthService.SHOPCD}&keyword=${keyword}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateListSort(String div, dynamic data) async {
    final response = await DioClient().post('${ServerInfo.RESTURL_MENUSORT_SET}?div=${div}', data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<List<dynamic>?> getMultiImageList(String menuCd, String div) async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_MULTIIMAGELIST}?jobGbn=1&div=${div}&shopCd=${AuthService.SHOPCD}&targetCd=${menuCd}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }
}