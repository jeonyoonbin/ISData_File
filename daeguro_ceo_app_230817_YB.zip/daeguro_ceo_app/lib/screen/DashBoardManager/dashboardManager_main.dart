import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/DashBoardManager/dashboard_week_order_model.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/Common/commonPopup_main.dart';
import 'package:daeguro_ceo_app/screen/DashBoardManager/dashboardManagerController.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeDetailInfo.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopStatusEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/instance_manager.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class DashBoardMain extends StatefulWidget {
  const DashBoardMain({Key? key}) : super(key: key);

  @override
  State<DashBoardMain> createState() => _DashBoardMainState();
}

class _DashBoardMainState extends State<DashBoardMain> with PageMixin {
  final ScrollController _scrollController = ScrollController();

  List<NoticeListModel> popupList = <NoticeListModel>[];

  Future<String?> requestAPIData() async {
    String retValue = '';
    var date = DateTime.now();

    //팝업
    await DashBoardController.to.getNoticeList('6', '10').then((value) {
      if (value == null) {
        retValue = '조회 오류';
      }
      else {
        popupList.clear();

        String todayDate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

        int index = 1;
        value.forEach((element) {
          NoticeListModel temp = NoticeListModel();
          temp.rnum = index.toString();
          temp.noticeSeq = element['noticeSeq'] as String;
          temp.noticeGbn = element['noticeGbn'] as String;
          temp.dispGbn = element['dispGbn'] as String;
          temp.dispFrDate = element['dispFrDate'] as String;
          temp.dispToDate = element['dispToDate'] as String;
          temp.noticeTitle = element['noticeTitle'] as String;
          temp.noticeContents = element['noticeContents'] as String;
          temp.noticeUrl1 = element['noticeUrl1'] as String;
          temp.noticeUrl2 = element['noticeUrl2'] as String;
          temp.noticeUrl3 = element['noticeUrl3'] as String;
          temp.orderDate = element['orderDate'] as String;
          temp.insDate = element['insDate'] as String;
          temp.sortSeq = element['sortSeq'] as String;
          temp.extUrlYn = element['extUrlYn'] as String;

          String loadDate = GetStorage().read('popupEnabled${temp.noticeSeq}').toString();

          if ((loadDate == null || loadDate == ''  || loadDate == 'null')){
            popupList.add(temp);
          }
          else{
            if (loadDate != todayDate) {
              GetStorage().remove('popupEnabled${temp.noticeSeq}');
              popupList.add(temp);
            }
          }

          index++;
        });

        retValue = '00';
      }
    });
    refreshUI();

    //배너
    await DashBoardController.to.getNoticeList('4', '999');
    refreshUI();

    await DashBoardController.to.getAccountInfo();
    refreshUI();

    //공지
    await DashBoardController.to.getNoticeList('2', '6');
    refreshUI();

    await DashBoardController.to.getShopWeeklyStat('%', formatDate(DateTime(date.year, date.month, date.day - 6), [yyyy, mm, dd]), formatDate(DateTime.now(), [yyyy, mm, dd]));
    refreshUI();

    await DashBoardController.to.getLiveEventInfo();
    refreshUI();

    return retValue;
  }

  refreshUI() {
    if (this.mounted) {
      setState(() {});
    }
  }

  @override
  void initState() {
    super.initState();

    Get.put(DashBoardController());

    debugPrint('initState HomePage');

    WidgetsBinding.instance.addPostFrameCallback((c) async {
      await requestAPIData().then((value) {
        if (popupList.isNotEmpty){
          showDialog(
            context: context,
            barrierDismissible: true,
            builder: (context) => CommonPopupMain(sData: popupList),
          );
        }
      });

      refreshUI();
    });
  }

  @override
  void dispose() {
    debugPrint('dispose HomePage');
    //dataWeekOrderList.clear();
    DashBoardController.to.dataWeekOrderList.value.clear();
    DashBoardController.to.dataNoticeList.value.clear();
    //dataList.clear();
    _scrollController.dispose();
    popupList.clear();
    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((c) async {
          await requestAPIData().then((value) {
            if (popupList.isNotEmpty){
              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => CommonPopupMain(sData: popupList),
              );
            }
          });
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    var mobileOrderContent = SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        children: [
          Container(height: 10,),
          Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  // margin: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow: [
                      BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                    ],
                  ),
                  height: 150,
                  child: _buildPanelContainer(title: const SizedBox.shrink(),
                      memoGbn: false,
                      verticalCenterAlign: false,
                      horizontalStartAlign: true,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Row(
                          //   children: const [
                          //     Text('안녕하세요', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          //     Text('테스트', style: TextStyle(color: Color(0xff01CAFF), fontSize: 22, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                          //     Text('사장님.', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          //   ],
                          // ),
                          Text.rich(TextSpan(children: [
                            const TextSpan(text: '안녕하세요', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                            TextSpan(text: ' ${AuthService.SHOPNAME}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 20, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                            const TextSpan(text: ' 사장님', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          ])),
                          const SizedBox(height: 8,),
                          const Text('오늘도 행복한 하루 되시길 바랍니다.', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                        ],
                      )),
                ),
                const SizedBox(height: 10),
                Container(
                  // margin: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow: [BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),],
                  ),
                  height: 300,
                  child: _buildPanelContainer(
                      title: Material(
                        child: InkWell(
                          child: const Text('공지 사항 >', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
                          onTap: () {
                            router.go('/guide/noticeInfo');
                          },
                        ),
                      ),
                      memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: Expanded(child: getNoticeListView())),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
          Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  // margin: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow: [BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),],
                  ),
                  height: 300,
                  child: _buildPanelContainer(
                    title: Material(
                      child: InkWell(
                        child: const Text('주간 주문 건 >', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
                        onTap: () {
                          router.go('/order/orderInfo');
                        },
                      ),
                    ),
                    memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: _WeeklyOrderChart(300),),
                ),
                const SizedBox(height: 10),
                Container(
                  // margin: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow: [BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),],
                  ),
                  height: 300,
                  child: _buildPanelContainer(
                    title: Material(
                      child: InkWell(
                        child: const Text('주간 매출 >', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
                        onTap: () {
                          router.go('/account/info', extra: 3);
                        },
                      ),
                    ),
                  memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: _WeeklyOrderChartAmt(300),),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
          const SizedBox(height: 10,),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                // padding: const EdgeInsets.only(right: 10),
                // margin: const EdgeInsets.symmetric(horizontal: 10),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                height: 300,
                child: _buildPanelContainer(
                    title: Material(
                      child: InkWell(
                        child: const Text('리뷰 현황 >', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
                        onTap: () {
                          router.go('/review/info');
                        },
                      ),
                    )
                , memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: const SizedBox.shrink()),
              ),
              const SizedBox(height: 10,),
              Container(
                // padding: const EdgeInsets.only(right: 10),
                // margin: const EdgeInsets.symmetric(horizontal: 10),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                height: 300,
                child: _buildPanelContainer(
                    title: Material(
                      child: InkWell(
                          child: const Text('라이브 이벤트 >', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
                          onTap: () {
                            router.go('/liveEvent/info');
                          },
                      ),
                    ),
                    memoGbn: false,
                    verticalCenterAlign: true,
                    horizontalStartAlign: true,
                    child: Obx(() =>
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            const SizedBox(height: 40),
                            DashBoardController.to.mEventYn == 'N' ? const Align(
                              alignment: Alignment.centerRight,
                              child: Text.rich(TextSpan(children: [
                                TextSpan(text: '현재 이벤트가 ', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                                TextSpan(text: '대기', style: TextStyle(color: Colors.green, fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                                TextSpan(text: ' 중입니다.', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                              ])),
                            ) : DashBoardController.to.mEventYn == 'Y'  ? Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                const Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Icon(Icons.timer_sharp,size: 25,),
                                    Text('이벤트 시간', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                                  ],
                                ),
                                Text('${Utils.getTimeFormat(DashBoardController.to.mFrTime.value!)} ~ ${Utils.getTimeFormat(DashBoardController.to.mToTime.value!)}', style: const TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                                const Text.rich(TextSpan(children: [
                                  TextSpan(text: '현재 이벤트가 ', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                                  TextSpan(text: '진행', style: TextStyle(color: Colors.green, fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                                  TextSpan(text: ' 중입니다.', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                                ])),
                              ],
                            ) : const Align(
                              alignment: Alignment.centerRight,
                              child: Text.rich(TextSpan(children: [
                                TextSpan(text: '금일 이벤트가', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                                TextSpan(text: ' 종료 ', style: TextStyle(color: Colors.red, fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                                TextSpan(text: '되었습니다.', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                              ])),
                            ),
                            const SizedBox(height: 8,),
                            Text(DashBoardController.to.mEventYn == 'N' ? '1일 1회 무료로 진행 가능합니다.' : DashBoardController.to.mEventYn == 'E' ? '내일 다시 만나요!' : '' , style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          ],
                        ))
                    ),
              ),
            ],
          ),
          const SizedBox(height: 20,),
        ],
      ),
    );

    var orderContent = Column(
      children: <Widget>[
        Container(height: 20,),
        Container(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer(title: const SizedBox.shrink(),
                        memoGbn: false,
                        horizontalStartAlign: false,
                        verticalCenterAlign: true,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            const Text('안녕하세요', style: TextStyle(fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                            const SizedBox(height: 8,),
                            Text.rich(TextSpan(children: [
                              TextSpan(text: '${AuthService.SHOPNAME}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                              const TextSpan(text: ' 사장님', style: TextStyle(fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                            ])),
                            const SizedBox(height: 8,),
                            const Text('오늘도 행복한 하루 되시길 바랍니다.', style: TextStyle(fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          ],
                        )),
                  ),
                  const SizedBox(width: 20,),
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer(
                        title: Material(
                          child: InkWell(
                              child: const Text('공지 사항 >', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
                              onTap: () {
                                router.go('/guide/noticeInfo');
                              },
                          ),
                        ),
                         memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: Expanded(child: getNoticeListView())),
                  ),
                ],
              ),
              const SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer(
                      title: Material(
                        child: InkWell(
                          child: const Text('주간 주문 건 >', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
                          onTap: () {
                            router.go('/order/orderInfo');
                          },
                        ),
                      ),
                       memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: _WeeklyOrderChart(300),),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer(
                      title: Material(
                        child: InkWell(
                          child: const Text('주간 매출 >', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
                          onTap: () {
                            router.go('/account/info', extra: 3);
                          },
                        ),
                      ),
                       memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: _WeeklyOrderChartAmt(300),),
                  ),
                ],
              ),
              const SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    // padding: const EdgeInsets.only(right: 10),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer(
                        title: Material(
                          child: InkWell(
                            child: const Text('리뷰 현황 >', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
                            onTap: () {
                              router.go('/review/info');
                            },
                          ),
                        ),
                         memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: const SizedBox.shrink()),
                  ),
                  const SizedBox(width: 20,),
                  Container(
                    // padding: const EdgeInsets.only(right: 10),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer(
                        title: Material(
                          child: InkWell(
                            child: const Text('라이브 이벤트 >', style: TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
                            onTap: () {
                              router.go('/liveEvent/info');
                            },
                          ),
                        ),
                         memoGbn: false, horizontalStartAlign: true, verticalCenterAlign: true,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            const SizedBox(height: 40),
                            DashBoardController.to.mEventYn == 'N' ? const Align(
                              alignment: Alignment.centerRight,
                              child: Text.rich(TextSpan(children: [
                                TextSpan(text: '현재 이벤트가 ', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                                TextSpan(text: '대기', style: TextStyle(color: Colors.green, fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                                TextSpan(text: ' 중입니다.', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                              ])),
                            ) : DashBoardController.to.mEventYn == 'Y'  ? Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                const Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Icon(Icons.timer_sharp,size: 25,),
                                    Text('이벤트 시간', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                                  ],
                                ),
                                Text('${Utils.getTimeFormat(DashBoardController.to.mFrTime.value!)} ~ ${Utils.getTimeFormat(DashBoardController.to.mToTime.value!)}', style: const TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                                const Text.rich(TextSpan(children: [
                                  TextSpan(text: '현재 이벤트가 ', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                                  TextSpan(text: '진행', style: TextStyle(color: Colors.green, fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                                  TextSpan(text: ' 중입니다.', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                                ])),
                              ],
                            ) : const Align(
                              alignment: Alignment.centerRight,
                              child: Text.rich(TextSpan(children: [
                                TextSpan(text: '금일 이벤트가', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                                TextSpan(text: ' 종료 ', style: TextStyle(color: Colors.red, fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                                TextSpan(text: '되었습니다.', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                              ])),
                            ),
                            const SizedBox(height: 8,),
                            Text(DashBoardController.to.mEventYn == 'N' ? '1일 1회 무료로 진행 가능합니다.' : DashBoardController.to.mEventYn == 'E' ? '내일 다시 만나요!' : '' , style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          ],
                        )),
                  ),
                ],
              ),
              const SizedBox(height: 20,),
            ],
          ),
        ),
      ],
    );

    return fluentUI.ScaffoldPage.scrollable(
      header: const LayoutHeader(titleName: '사장님사이트 현황'),//SizedBox(width: double.infinity, height: 100,),//
      bottomBar: const LayoutBottom(),
      children: [
        const SizedBox(height: 16,),
        Responsive.isMobile(context) ? Column(children: shopInfoBarView(),) : Row(children: shopInfoBarView(),),
        Responsive.isMobile(context) ? mobileOrderContent : orderContent,
      ],
    );
  }

  Widget getNoticeListView() {
    return Obx(() =>
        ListView.separated(
          controller: _scrollController,
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          separatorBuilder: (BuildContext context, int index) { return const Divider(thickness: 1, height: 0.0,); },
          itemCount: DashBoardController.to.dataNoticeList.value.length,
          itemBuilder: (ctx, index) {
            return Material(
              child: InkWell(
                onTap: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => NoticeDetailInfo(noticeSeq: DashBoardController.to.dataNoticeList.value[index].noticeSeq),
                  );
                },
                child: Container(
                  height: 40,
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(child: Text(DashBoardController.to.dataNoticeList.value[index].noticeTitle ?? '--', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY), overflow: TextOverflow.ellipsis,)),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Text(DashBoardController.to.dataNoticeList.value[index].dispFrDate.toString() ?? '--', style: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        )
    );
  }

  List<Widget> shopInfoBarView() {
    final appTheme = context.watch<AppTheme>();

    return [
      Responsive.isMobile(context) == true ? const SizedBox(height: 8) : const SizedBox(width: 8),
      Responsive.isMobile(context) == true
          ? Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                  child: Container(
                      alignment: Alignment.center,
                      //padding: const EdgeInsets.symmetric(horizontal: 10),
                      height: 40,
                      width: 120,
                      decoration: BoxDecoration(
                          color: appTheme.currentShopStatusGbn == 'Y' ? const Color(0xff01CAFF) : Colors.grey,
                          borderRadius: BorderRadius.circular(10)
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(appTheme.currentShopStatusGbn == 'Y' ? '영업중' : '휴무중', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON),),
                          const SizedBox(width: 8,),
                          Icon(appTheme.currentShopStatusGbn == 'Y' ? Icons.wb_sunny_outlined : Icons.cloud_outlined, color: Colors.white, size: 22,)
                        ],
                      )
                  ),
                  onTap: () {
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => const ShopStatusEdit(),
                    );
                  }
              ),
              if (AuthService.MallUseGbn == 'Y')
                TextButton(
                  style: ButtonStyle(
                    animationDuration: const Duration(microseconds: 100),
                    overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
                    foregroundColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) {
                      if (states.contains(MaterialState.hovered)) {
                        return const Color(0xff01CAFF);
                      }
                      return Colors.black; //Colors.white;
                    }),
                  ),
                  onPressed: () {
                    Utils.launchURL('https://m.daeguromall.com');
                  },
                  child: const Text('> 대구로몰 이동하기', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                ),
            ]
          ) : const SizedBox.shrink(),
      Responsive.isMobile(context) == true ? const SizedBox(height: 22) : const SizedBox.shrink(),

      Row(
        children: [
          const Text('현재 적립된 금액은 ', style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
          Obx(() =>
              Text(Utils.getCashComma(DashBoardController.to.shopRemainAmt.value!), style: const TextStyle(color: Color(0xff01CAFF), fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
          ),
          const Text('원 입니다.', style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
        ],
      ),

      Responsive.isMobile(context) == true ? const SizedBox(height: 12) : const SizedBox(width: 12),
      ISButton(
        //buttonColor: Colors.black,
        isReverseColor: true,
        width: Responsive.isMobile(context) == true ? double.infinity : 64,
        child: const Text('적립내역', style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON),),
        onPressed: () {
          router.go('/account/info', extra: 1);
        },
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8) : const SizedBox(width: 8),
      ISButton(
        width: Responsive.isMobile(context) == true ? double.infinity : 64,
        child: const Text('출금하기', style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON),),
        onPressed: () {
          router.go('/account/info', extra: 0);
        },
      ),
    ];
  }

  // double getPanelWidth(){
  //   double nWidth = 0.0;
  //
  //   final _media = MediaQuery.of(context).size;
  //
  //   if (Responsive.isDesktop(context) == true)        nWidth = 400;
  //   else if (Responsive.isTablet(context) == true)    nWidth = 210;
  //   else if (Responsive.isMobile(context) == true)    nWidth = 130;
  //
  //   return nWidth;
  // }

  // Container _buildShopTitlePanelContainer(String title, {Widget? child, double? width, double? height, bool? memoGbn, bool? centerAlignEnable,})
  // {
  //   double nWidth = 0.0;
  //
  //   if (Responsive.isDesktop(context) == true) {
  //     nWidth = (MediaQuery.of(context).size.width - 308) / 2;
  //   } else if (Responsive.isTablet(context) == true) {
  //     nWidth = (MediaQuery.of(context).size.width - 118) / 2;
  //   } else if (Responsive.isMobile(context) == true) {
  //     nWidth = MediaQuery.of(context).size.width - 30;
  //   }
  //
  //   return Container(
  //     padding: const EdgeInsets.only(left: 16.0, right: 16.0, top: 16.0),
  //     width: nWidth,
  //     height: height ?? (MediaQuery.of(context).size != null ? MediaQuery.of(context).size.height / 4.4 : height),
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.end,
  //       children: <Widget>[
  //         Padding(
  //           padding: const EdgeInsets.only(left: 5),
  //           child: Column(
  //             crossAxisAlignment: CrossAxisAlignment.start,
  //             children: [
  //               Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
  //               if (memoGbn == true) const Text('※ 전일 자정까지의 집계 데이터입니다.', style: TextStyle(color: Color(0xff666666), fontSize: 12)),
  //             ],
  //           ),
  //         ),
  //         if (child != null) ...[
  //           SizedBox(height: centerAlignEnable == true ? 40.0 : 10.0),
  //           child
  //           //Responsive.isMobile(context) ? SizedBox(height: height ?? 250, child: child) : child,
  //         ]
  //       ],
  //     ),
  //   );
  // }

  Container _buildPanelContainer({Widget? title, Widget? child, double? width, double? height, bool? memoGbn, bool? verticalCenterAlign, bool? horizontalStartAlign})
  {
    double nWidth = 0.0;

    if (Responsive.isDesktop(context) == true) {
      nWidth = (MediaQuery.of(context).size.width - 308) / 2;
    } else if (Responsive.isTablet(context) == true) {
      nWidth = (MediaQuery.of(context).size.width - 118) / 2;
    } else if (Responsive.isMobile(context) == true) {
      nWidth = MediaQuery.of(context).size.width - 30;
    }

    return Container(
      padding: const EdgeInsets.only(left: 16.0, right: 16.0, top: 16.0),
      width: nWidth,
      height: height ?? (MediaQuery.of(context).size != null ? MediaQuery.of(context).size.height / 4.4 : height),
      child: Column(
        crossAxisAlignment: horizontalStartAlign == true ? CrossAxisAlignment.start : CrossAxisAlignment.end,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left: 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                title ?? const SizedBox.shrink(),
                if (memoGbn == true) const Text('※ 전일 자정까지의 집계 데이터입니다.', style: TextStyle(color: Color(0xff666666), fontSize: 12)),
              ],
            ),
          ),
          if (child != null) ...[
            SizedBox(height: verticalCenterAlign == true ? 40.0 : 10.0),
            child
            //Responsive.isMobile(context) ? SizedBox(height: height ?? 250, child: child) : child,
          ]
        ],
      ),
    );
  }

  Widget _WeeklyOrderChart(double height) {
    return SizedBox(
      height: height - 55,
      //color: Colors.yellow,
      child: Obx(() =>
          SfCartesianChart(
              selectionType: SelectionType.series,
              isTransposed: false,
              selectionGesture: ActivationMode.none,
              //.singleTap,
              primaryXAxis: CategoryAxis(
                isVisible: true,
                opposedPosition: false,
                isInversed: false,
                // labelStyle: TextStyle(fontFamily: 'Roboto'),
              ),
              primaryYAxis: NumericAxis(
                decimalPlaces: 0,
                numberFormat: NumberFormat("#,###", "en_US"),
                title: AxisTitle(
                  text: '건수',
                  textStyle: const TextStyle(fontFamily: FONT_FAMILY, color: Colors.black87, fontSize: 10),
                ),
              ),
              axes: <ChartAxis>[
                NumericAxis(
                    name: 'xAxis',
                    opposedPosition: true,
                    interval: 1,
                    minimum: 0,
                    maximum: 5,
                    labelStyle: const TextStyle(
                      fontFamily: FONT_FAMILY,
                    )),
                NumericAxis(name: 'yAxis', opposedPosition: true, labelStyle: const TextStyle(fontFamily: FONT_FAMILY))
              ],
              legend: Legend(
                isVisible: true,
                toggleSeriesVisibility: true,
                position: LegendPosition.bottom,
                overflowMode: LegendItemOverflowMode.wrap,
                alignment: ChartAlignment.center,
                // legendItemBuilder: (String name, dynamic series, dynamic point, int index) {
                //   debugPrint(series.isVisible);
                //
                //   return SizedBox(
                //       width: 87,
                //       child: Row(children: <Widget>[
                //         SizedBox(
                //             child: Icon(
                //               Icons.bar_chart,
                //               color: series.color,
                //             )),
                //         const SizedBox(
                //           width: 1,
                //         ),
                //         Text(series.name),
                //       ]));
                // },
                textStyle: const TextStyle(
                  fontFamily: FONT_FAMILY,
                  fontSize: 10,
                ),
              ),
              crosshairBehavior: CrosshairBehavior(
                lineType: CrosshairLineType.horizontal,
                enable: true,
                shouldAlwaysShow: false,
                activationMode: ActivationMode.singleTap, //.singleTap,
              ),
              tooltipBehavior: TooltipBehavior(
                enable: true,
                shared: true,
                activationMode: ActivationMode.singleTap,
                textStyle: const TextStyle(fontSize: 12, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
              ),
              series: <CartesianSeries>[
                SplineSeries<DashboardWeekOrderModel, String>(
                  color: const Color(0xff49A4ED),
                  name: '총 건수',
                  splineType: SplineType.natural,
                  dataSource: DashBoardController.to.dataWeekOrderList.value,
                  legendIconType: LegendIconType.horizontalLine,
                  xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
                  yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.totCnt.toString()),
                  dataLabelSettings: const DataLabelSettings(
                      isVisible: false,
                      labelPosition: ChartDataLabelPosition.outside,
                      textStyle: TextStyle(
                        fontFamily: FONT_FAMILY,
                        fontSize: 11,
                        color: Colors.white,
                      ),
                      color: Color(0xff49A4ED),
                      labelAlignment: ChartDataLabelAlignment.outer),
                  //Modify data points (show circles)
                  markerSettings: const MarkerSettings(isVisible: true),
                  //yAxisName: 'yAxis'
                ),
                SplineSeries<DashboardWeekOrderModel, String>(
                  color: const Color(0xff8146e7),
                  name: '취소건수',
                  splineType: SplineType.natural,
                  dataSource: DashBoardController.to.dataWeekOrderList.value,
                  legendIconType: LegendIconType.horizontalLine,
                  xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
                  yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.cancelCnt.toString()),
                  dataLabelSettings: const DataLabelSettings(
                      isVisible: false,
                      labelPosition: ChartDataLabelPosition.outside,
                      textStyle: TextStyle(
                        fontFamily: FONT_FAMILY,
                        fontSize: 11,
                        color: Colors.white,
                      ),
                      color: Color(0xffFFA00E),
                      labelAlignment: ChartDataLabelAlignment.bottom),
                  //Modify data points (show circles)
                  markerSettings: const MarkerSettings(isVisible: true),
                  //yAxisName: 'yAxis'
                ),
                SplineSeries<DashboardWeekOrderModel, String>(
                  color: const Color(0xffFFA00E),
                  name: '완료건수',
                  splineType: SplineType.natural,
                  dataSource: DashBoardController.to.dataWeekOrderList.value,
                  legendIconType: LegendIconType.horizontalLine,
                  xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
                  yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.okCnt.toString()),
                  dataLabelSettings: const DataLabelSettings(
                      isVisible: false,
                      labelPosition: ChartDataLabelPosition.outside,
                      textStyle: TextStyle(
                        fontFamily: FONT_FAMILY,
                        fontSize: 11,
                        color: Colors.white,
                      ),
                      color: Color(0xffFFA00E),
                      labelAlignment: ChartDataLabelAlignment.bottom),
                  //Modify data points (show circles)
                  markerSettings: const MarkerSettings(isVisible: true),
                  //yAxisName: 'yAxis'
                )
              ])
      ),
    );
  }

  Widget _WeeklyOrderChartAmt(double height) {
    return SizedBox(
      height: height - 55,
      //color: Colors.yellow,
      child: Obx(() =>
          SfCartesianChart(
              selectionType: SelectionType.series,
              isTransposed: false,
              selectionGesture: ActivationMode.none,
              //.singleTap,
              primaryXAxis: CategoryAxis(
                isVisible: true,
                opposedPosition: false,
                isInversed: false,
                // labelStyle: TextStyle(fontFamily: 'Roboto'),
              ),
              primaryYAxis: NumericAxis(
                decimalPlaces: 0,
                numberFormat: NumberFormat("#,###", "en_US"),
                title: AxisTitle(
                  text: '건수',
                  textStyle: const TextStyle(fontFamily: FONT_FAMILY, color: Colors.black87, fontSize: 10),
                ),
              ),
              axes: <ChartAxis>[
                NumericAxis(
                    name: 'xAxis',
                    opposedPosition: true,
                    interval: 1,
                    minimum: 0,
                    maximum: 5,
                    labelStyle: const TextStyle(
                      fontFamily: FONT_FAMILY,
                    )),
                NumericAxis(name: 'yAxis', opposedPosition: true, labelStyle: const TextStyle(fontFamily: FONT_FAMILY))
              ],
              legend: Legend(
                isVisible: true,
                toggleSeriesVisibility: true,
                position: LegendPosition.bottom,
                overflowMode: LegendItemOverflowMode.wrap,
                alignment: ChartAlignment.center,
                textStyle: const TextStyle(
                  fontFamily: FONT_FAMILY,
                  fontSize: 10,
                ),
              ),
              crosshairBehavior: CrosshairBehavior(
                lineType: CrosshairLineType.horizontal,
                enable: true,
                shouldAlwaysShow: false,
                activationMode: ActivationMode.singleTap, //.singleTap,
              ),
              tooltipBehavior: TooltipBehavior(
                enable: true,
                shared: true,
                activationMode: ActivationMode.singleTap,
                textStyle: const TextStyle(fontSize: 12, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
              ),
              series: <CartesianSeries>[
                SplineSeries<DashboardWeekOrderModel, String>(
                  color: const Color(0xff49A4ED),
                  name: '총 매출액',
                  splineType: SplineType.natural,
                  dataSource: DashBoardController.to.dataWeekOrderList.value,
                  legendIconType: LegendIconType.horizontalLine,
                  xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
                  yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.totAmt.toString()),
                  dataLabelSettings: const DataLabelSettings(
                      isVisible: false,
                      labelPosition: ChartDataLabelPosition.outside,
                      textStyle: TextStyle(
                        fontFamily: FONT_FAMILY,
                        fontSize: 11,
                        color: Colors.white,
                      ),
                      color: Color(0xff49A4ED),
                      labelAlignment: ChartDataLabelAlignment.outer),
                  //Modify data points (show circles)
                  markerSettings: const MarkerSettings(isVisible: true),
                  //yAxisName: 'yAxis'
                ),
                SplineSeries<DashboardWeekOrderModel, String>(
                  color: const Color(0xff8146e7),
                  name: '취소 금액',
                  splineType: SplineType.natural,
                  dataSource: DashBoardController.to.dataWeekOrderList.value,
                  legendIconType: LegendIconType.horizontalLine,
                  xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
                  yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.cancelAmt.toString()),
                  dataLabelSettings: const DataLabelSettings(
                      isVisible: false,
                      labelPosition: ChartDataLabelPosition.outside,
                      textStyle: TextStyle(
                        fontFamily: FONT_FAMILY,
                        fontSize: 11,
                        color: Colors.white,
                      ),
                      color: Color(0xffFFA00E),
                      labelAlignment: ChartDataLabelAlignment.bottom),
                  //Modify data points (show circles)
                  markerSettings: const MarkerSettings(isVisible: true),
                  //yAxisName: 'yAxis'
                ),
                SplineSeries<DashboardWeekOrderModel, String>(
                  color: const Color(0xffFFA00E),
                  name: '실 매출액',
                  splineType: SplineType.natural,
                  dataSource: DashBoardController.to.dataWeekOrderList.value,
                  legendIconType: LegendIconType.horizontalLine,
                  xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
                  yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.okAmt.toString()),
                  dataLabelSettings: const DataLabelSettings(
                      isVisible: false,
                      labelPosition: ChartDataLabelPosition.outside,
                      textStyle: TextStyle(
                        fontFamily: FONT_FAMILY,
                        fontSize: 11,
                        color: Colors.white,
                      ),
                      color: Color(0xffFFA00E),
                      labelAlignment: ChartDataLabelAlignment.bottom),
                  //Modify data points (show circles)
                  markerSettings: const MarkerSettings(isVisible: true),
                  //yAxisName: 'yAxis'
                )
              ])
      ),
    );
  }
}