import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveReviewImageInsertModel.dart';
import 'package:daeguro_ceo_app/network/DioReserveClient.dart';
import 'package:date_format/date_format.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:typed_data';

class ReserveController extends GetxController{
  static ReserveController get to => Get.find();
  RxString reserveApplyDate = ''.obs;
  RxString reservePageGbn = ''.obs;

  int total_count = 0;
  int total_page = 1;
  int statuS10 = 0;
  int statuS12 = 0;
  int statuS30 = 0;
  int statuS40 = 0;
  int statuS90 = 0;

  String msg = '';

  Future<dynamic> getReserveList(String startdate, String enddate, String status, String search) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVATIONLIST}?shopCd=${AuthService.SHOPCD}&dateBegin=${startdate}&dateEnd=${enddate}&status=${status}');

    if (response.data['code'] == '00') {
      if(status == '' ){
        total_count = int.parse(response.data['totalCnt'].toString());
        total_page = ((total_count / 10).ceil());
        statuS10 = response.data['statuS10'];
        statuS12 = response.data['statuS12'];
        statuS30 = response.data['statuS30'];
        statuS40 = response.data['statuS40'];
        statuS90 = response.data['statuS90'];
      }else{
        if(int.parse(response.data['totalCnt'].toString()) > 0){
          total_page = ((int.parse(response.data['totalCnt'].toString()) / 10).ceil());
        }else{
          total_page = 0;
        }
      }
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getShopReserveStatus(String shopCode) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVESTATUS}?shopCode=$shopCode');

    if (response.data['code'] == '00')
      qData = response.data['data'];
    else {
      msg = '예약 정보조회 실패(${response.data['msg']})';
      return null;
    }

    return qData;
  }

  Future<dynamic> getReserveDateStatus(String shopCode, String dateBegin, String dateEnd) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVEDATESTATUS}?shopCd=$shopCode&dateBegin=$dateBegin&dateEnd=$dateEnd');

    if (response.data['code'] == '00')
      qData = response.data['data'];
    else
      return null;

    return qData;
  }

  Future<dynamic> getReserveDateStatusTotal(String shopCode) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVEDATESTATUS_TOTAL}?shopCd=$shopCode&dateBegin=${formatDate(DateTime.now(), [yyyy, mm, '01']).toString()}&dateEnd=${formatDate(DateTime.now(), [yyyy, mm,  DateTime(DateTime.now().year, DateTime.now().month + 1, 0).day.toString()])}');

    if (response.data['code'] == '00')
      qData = response.data['data'];
    else
      return null;

    return qData;
  }


  Future<dynamic> getReserveShopMagam(String shopCode) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_SHOPMAGAM}/$shopCode');

    if (response.data['code'] == '00')
      qData = response.data['data'];
    else
      return null;

    return qData;
  }

  Future<dynamic> updateReserveShopMagam(dynamic data) async {

    final response = await DioReserveClient().put(ServerInfo.RESTURL_RESERVE_SHOPMAGAM, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> updateReserveApply(dynamic data) async {

    final response = await DioReserveClient().put(ServerInfo.RESTURL_RESERVE_APPLY, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> getReserveTimeScheduleList(String yyyyMMdd) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVETIMESCHEDULELIST}/${AuthService.SHOPCD}?yyyyMMdd=${yyyyMMdd}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateShopTimeOff(dynamic data) async {
    final response = await DioReserveClient().put(ServerInfo.RESTURL_RESERVETIMESCHEDULESET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<List<dynamic>?> getShopNews(String jobGbn, String searchInfo, String page) async {
    List<dynamic> qData = [];
    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_SHOPNEWS}?jobGbn=$jobGbn&shopCd=${AuthService.SHOPCD}&searchInfo=$searchInfo&page=$page&rows=10');
    
    if(response.data['code'] == '00'){
      total_count = int.parse(response.data['data']['count'].toString());
      qData.assignAll(response.data['data']['list']);
    }else{
      return null;
    }
    print(qData);
    return qData;

  }

  Future<dynamic> getShopNewsDetail(String seq) async {
    dynamic qData;
    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_SHOPNEWS}/$seq?shopCd=${AuthService.SHOPCD}');

    if(response.data['code'] == '00'){
      qData = response.data['data'];
    }else{
      return null;
    }

    print(qData);
    return qData;

  }

  Future<dynamic> addShopNews(dynamic data) async {

    final response = await DioReserveClient().post(ServerInfo.RESTURL_RESERVE_SHOPNEWS, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> updateShopNews(dynamic data) async {

    final response = await DioReserveClient().put(ServerInfo.RESTURL_RESERVE_SHOPNEWS, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> delShopNews(dynamic data) async {
    final response = await DioReserveClient().delete(ServerInfo.RESTURL_RESERVE_SHOPNEWS, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<List<dynamic>?> getShopInfoReserveTime(String shopCode) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_TIME}/$shopCode');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    }
    else {
      msg = '예약 정보조회 실패(${response.data['msg']})';
      return null;
    }

    return qData;
  }

  Future<dynamic> getShopInfoReserveCasePeople(String shopCode) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_CASEPEOPLE}?shopCode=$shopCode');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      msg = '예약 정보조회 실패(${response.data['msg']})';
      return null;
    }

    return qData;
  }

  Future<dynamic> updateReserveCasesPeople(dynamic data) async {

    final response = await DioReserveClient().put(ServerInfo.RESTURL_RESERVE_CASEPEOPLE, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> setReserTime(dynamic data) async {
    final response = await DioReserveClient().post(ServerInfo.RESTURL_RESERVE_TIME, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> setReserTimeCancel(dynamic data) async {
    final response = await DioReserveClient().post(ServerInfo.RESTURL_RESERVE_TIME_CANCEL, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<List<dynamic>?> getShopPicture(String shopCd, String temaCode, String page, String pageRows) async {
    List<dynamic> qData = [];

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_SHOP_PICTURE}/$shopCd?temaCode=${temaCode}&page=${page}&pageRows=${pageRows}');

    if (response.data['code'] == '00') {
      qData = response.data['data']['items'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateShopPictureListSort(dynamic data) async {
    final response = await DioReserveClient().post('${ServerInfo.RESTURL_SHOPPICTURE_SORT_SET}', data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> getReserveShopInfo() async {
    dynamic qData;

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_SHOPINFO}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateReserveShopIntroduce(String shopCd, String ccCode, String introduce, String userId) async {
    final response = await DioReserveClient().put(ServerInfo.RESTURL_RESERVE_SHOPINFO_INTRODUCE + '?shopCd=$shopCd&ccCode=$ccCode&introduce=$introduce&userId=$userId');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> updateReserveShopNotice(dynamic data) async {
    final response = await DioReserveClient().put(ServerInfo.RESTURL_RESERVE_SHOPINFO_NOTICE, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> updateReserveShopReviewIntro(dynamic data) async {
    final response = await DioReserveClient().put(ServerInfo.RESTURL_RESERVE_REVIEW_INTRO, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> deleteReviewImage(dynamic data) async {
    final response = await DioReserveClient().delete(ServerInfo.RESTURL_RESERVE_DELETE_REVIEWIMAGE, data: data);

    if (response.data['code'] != '00') {
      return null;
    } else
      return response.data['code'];
  }

  Future<dynamic> setReviewImage(ReserveReviewImageInsertModel setData, var fileResArr) async {
    var request = await http.MultipartRequest('PUT', Uri.parse(ServerInfo.REST_RESERVE_URL + '${ServerInfo.RESTURL_RESERVE_INSERT_REVIEWIMAGE}'));

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    request.fields['ccCode'] = setData.ccCode.toString();
    request.fields['shopCode'] = setData.shopCode.toString();
    //request.fields['userId'] = GetStorage().read('logininfo')['uCode'];

    var responseData;

    Uint8List data = await fileResArr.readAsBytes();
    List<int> list = data.cast();
    request.files.add(http.MultipartFile.fromBytes('file', list, filename: 'upload_temp.png'));

    var response = await request.send();

    return response.statusCode;
  }

  Future<dynamic> getShopInfoReserveManageInfo(String shopCode) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_SHOPINFO_MANAGE}?shopCd=$shopCode');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }
    return qData;
  }


  Future<dynamic> updateReserveReviewUse(String shopCd, String ccCode, String reviewUseGbn, String userId) async {

    final response = await DioReserveClient().put(ServerInfo.RESTURL_RESERVE_REVIEW_USE + '?shopCd=$shopCd&ccCode=$ccCode&reviewUseGbn=$reviewUseGbn&userId=$userId');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
    }
  }

  Future<dynamic> updateReserveFacilities(dynamic data) async {

    final response = await DioReserveClient().post(ServerInfo.RESTURL_RESERVE_FACILITIES, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
    }
  }

  Future<dynamic> updateReserveShopSbTime(dynamic data) async {
    final response = await DioReserveClient().post(ServerInfo.RESTURL_RESERVE_SBTIME, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
    }
  }

  Future<dynamic> getShopInfoReserveDayOff(String shopCode, String gbn) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_DAYOFF}/$shopCode?gbn=$gbn');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateReserveShopDayOff(dynamic data) async {
    final response = await DioReserveClient().post('${ServerInfo.RESTURL_RESERVE_DAYOFF}', data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> deleteReserveShopDayOff(dynamic data) async {
    final response = await DioReserveClient().delete('${ServerInfo.RESTURL_RESERVE_DAYOFF}', data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

}