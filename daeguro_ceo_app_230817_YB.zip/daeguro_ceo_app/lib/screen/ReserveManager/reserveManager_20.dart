import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ReserveManager20 extends StatefulWidget {
  final double? tabviewHeight;
  const ReserveManager20({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ReserveManager20> createState() => _ReserveManager20State();
}

class _ReserveManager20State extends State<ReserveManager20> {

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());
  }

  @override
  void dispose() {
    debugPrint('dispose HomePage');

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    var mobileContent = Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const Icon(fluentUI.FluentIcons.skype_circle_check, color: Color(0xff01CAFF), size: 40),
        const SizedBox(height: 20),
        const Text('예약 서비스 입점 신청이 접수되어 ', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON)),
        const SizedBox(height: 10),
        const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text('운영사 심사중', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON, color:  Color(0xff01CAFF), fontWeight: FONT_BOLD)),
            Text(' 입니다.', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON)),
          ],
        ),
        const SizedBox(height: 20),
        Container(
          height: 35,
          width: 280,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: const Color(0xFFEFEFEF)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text('신청 일시 : ', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON)),
              Text(ReserveController.to.reserveApplyDate.toString(), style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, color:  Color(0xff01CAFF)))
            ],
          ),
        ),
        const SizedBox(height: 10),
        const Text('대구로 담당자가 사장님께 직접 연락 후', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY_NEXON)),
        const SizedBox(height: 5),
        const Text('예약 서비스 신청 절차를 도와드리겠습니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY_NEXON)),
        const SizedBox(height: 10),
        const Text('*신청일 기준 15일 이내 연락 예정', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
        const SizedBox(height: 100),
        const Text('문의사항은 대구로 고객센터로 연락바랍니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY_NEXON)),
        const SizedBox(height: 20),
        Container(
          height: 45,
          width: 150,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: const Color(0xFFEFEFEF)),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(fluentUI.FluentIcons.reminder_person, color: Color(0xff01CAFF), size: 20),
              SizedBox(width: 10),
              Text('1661-3773', style: TextStyle(fontSize: 13)),
            ],
          ),
        ),
      ],
    );

    var desktopContent = Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const Icon(fluentUI.FluentIcons.skype_circle_check, color: Color(0xff01CAFF), size: 60),
        const SizedBox(height: 30),
        const Text('예약 서비스 입점 신청이 접수되어 ', style: TextStyle(fontSize: 35, fontFamily: FONT_FAMILY_NEXON)),
        const SizedBox(height: 10),
        const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text('운영사 심사중', style: TextStyle(fontSize: 35, fontFamily: FONT_FAMILY_NEXON, color:  Color(0xff01CAFF), fontWeight: FONT_BOLD)),
            Text(' 입니다.', style: TextStyle(fontSize: 35, fontFamily: FONT_FAMILY_NEXON)),
          ],
        ),
        const SizedBox(height: 30),
        Container(
          height: 35,
          width: 300,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: const Color(0xFFEFEFEF)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text('신청 일시 : ', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON)),
              Text(ReserveController.to.reserveApplyDate.toString(), style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, color:  Color(0xff01CAFF)))
            ],
          ),
        ),
        const SizedBox(height: 10),
        const Text('대구로 담당자가 사장님께 직접 연락 후 예약 서비스 신청 절차를 도와드리겠습니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY_NEXON)),
        const SizedBox(height: 10),
        const Text('*신청일 기준 15일 이내 연락 예정', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
        const SizedBox(height: 150),
        const Text('문의사항은 대구로 고객센터로 연락바랍니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY_NEXON)),
        const SizedBox(height: 20),
        Container(
          height: 45,
          width: 200,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: const Color(0xFFEFEFEF)),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(fluentUI.FluentIcons.reminder_person, color: Color(0xff01CAFF), size: 20),
              SizedBox(width: 10),
              Text('1661-3773', style: TextStyle(fontSize: 13)),
            ],
          ),
        ),
      ],
    );

    return Container(
      // header: const LayoutHeader(titleName: '사장님사이트 현황'),//SizedBox(width: double.infinity, height: 100,),//
      // bottomBar: const LayoutBottom(),
      child: Responsive.isMobile(context) ? mobileContent : desktopContent,
    );
  }
}