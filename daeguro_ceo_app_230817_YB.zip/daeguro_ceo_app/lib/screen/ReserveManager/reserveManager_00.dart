import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveApplyModel.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ReserveManager00 extends StatefulWidget {
  final double? tabviewHeight;

  const ReserveManager00({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ReserveManager00> createState() => _ReserveManager00State();
}

class _ReserveManager00State extends State<ReserveManager00> {
  final ScrollController _scrollController = ScrollController();
  final anchor = GlobalKey();
  bool _okChk = false;

  requestAPIData() async {
    await ReserveController.to.getShopReserveStatus(AuthService.SHOPCD).then((value) {
      if (value == null) {
        ISAlert(context, title: '예약 정보 조회 실패', content: '예약 정보 조회에 실패하였습니다.');
      } else {
        ReserveController.to.reserveApplyDate.value = value[0]['applyDate'];
        ReserveController.to.reservePageGbn.value = value[0]['status'];
      }
    });

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());

    debugPrint('initState HomePage');

    WidgetsBinding.instance.addPostFrameCallback((c) async {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    debugPrint('dispose HomePage');

    super.dispose();
    _scrollController.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    var mobileContent = SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Column(
              children: [
                Stack(
                    children: [
                      const Row(
                        children: [
                          Text('대구로', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                          Text(' 방문 예약서비스', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY_NEXON,fontWeight: FONT_BOLD))
                        ],
                      ),
                      Container(padding: const EdgeInsets.only(top: 30), child: const Text('입점 안내', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL))),
                      Container(
                        padding: const EdgeInsets.only(top: 70),
                        child: const Row(
                          children: [
                            Text('클릭 몇 번으로 쉽고', style: TextStyle(fontSize: 14)),
                            Text(' 간편하게!', style: TextStyle(fontSize: 14, color:  Color(0xff01CAFF)))
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.only(top: 90),
                        child: const Row(
                          children: [
                            Text('예약 관리', style: TextStyle(fontSize: 14, color:  Color(0xff01CAFF))),
                            Text('는 한 눈에 보기 쉽게!', style: TextStyle(fontSize: 14))
                          ],
                        ),
                      ),
                    ]),
                const SizedBox(width: 120),
                const Image(image: AssetImage('images/img_alerts_258px@2x.png')),
              ],
            ),
          ),
          Container(
            color: const Color(0xFFEFEFEF),
            width: MediaQuery.of(context).size.width,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  margin: const EdgeInsets.only(top:30),
                  alignment: Alignment.center,
                  child: Stack(
                      alignment: Alignment.topCenter,
                      children: [
                        Container(alignment: Alignment.center, height: 25, width: 55, decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: const Color(0xff01CAFF)),
                            child: const Text('step 1', style: TextStyle(color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                        Container(padding: const EdgeInsets.only(top: 40), child: const Text('담당자가 전화 또는 방문하여', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON,fontWeight: FONT_NORMAL))),
                        Container(padding: const EdgeInsets.only(top: 75), child: const Text('서류 작성 후 제출', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                        Container(padding: const EdgeInsets.only(top: 130), child: const Text('대구로 담당자가 사장님께 직접 연락드린 후', style: TextStyle(fontSize: 14))),
                        Container(padding: const EdgeInsets.only(top: 155), child: const Text('예약서비스 신청 절차를 도와드립니다.', style: TextStyle(fontSize: 14))),
                        Container(
                            padding: const EdgeInsets.only(top: 200),
                            child: Container(
                              height: 45,
                              width: 320,
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.white),
                              child: Row(
                                children: [
                                  const SizedBox(width: 5),
                                  Container(alignment: Alignment.center, height: 20, width: 20, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
                                      color: const Color(0xff01CAFF)), child: const Text('1', style: TextStyle(fontSize: 12, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                  Container(alignment: Alignment.center, child: const Text(' 한 눈에 똭! 한 줄 ', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON))),
                                  Container(alignment: Alignment.center, child: const Text('매장 소개글', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                  Container(alignment: Alignment.center, child: const Text(' (최대 20자)', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY_NEXON))),
                                ],
                              ),
                            )
                        ),
                        Container(
                            padding: const EdgeInsets.only(top: 255),
                            child: Container(
                              height: 45,
                              width: 320,
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.white),
                              child: Row(
                                children: [
                                  const SizedBox(width: 5),
                                  Container(alignment: Alignment.center, height: 20, width: 20, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
                                      color: const Color(0xff01CAFF)), child: const Text('2', style: TextStyle(fontSize: 12, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                  Container(alignment: Alignment.center, child: const Text(' 깔끔하고 멋진 ', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON))),
                                  Container(alignment: Alignment.center, child: const Text('매장 소개사진', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                  Container(alignment: Alignment.center, child: const Text(' (최대 20장)', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY_NEXON))),
                                ],
                              ),
                            )
                        ),
                        Container(
                            padding: const EdgeInsets.only(top: 310),
                            child: Container(
                              height: 45,
                              width: 320,
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.white),
                              child: Row(
                                children: [
                                  const SizedBox(width: 5),
                                  Container(alignment: Alignment.center, height: 20, width: 20, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
                                      color: const Color(0xff01CAFF)), child: const Text('3', style: TextStyle(fontSize: 12, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                  Container(alignment: Alignment.center, child: const Text(' 사장님의 매장을 ', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON))),
                                  Container(alignment: Alignment.center, child: const Text('소개할 문구', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                  Container(alignment: Alignment.center, child: const Text(' (최대 2,000자)', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY_NEXON))),
                                ],
                              ),
                            )
                        ),
                      ]),
                ),
                const Image(image: AssetImage('images/pc_cellphone_1@2x.png')),
              ],
            ),
          ),
          SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  margin: const EdgeInsets.only(top:30),
                  alignment: Alignment.center,
                  child: Stack(
                      alignment: Alignment.topCenter,
                      children: [
                        Container(alignment: Alignment.center, height: 25, width: 55, decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: const Color(0xff01CAFF)),
                            child: const Text('step 2', style: TextStyle(color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                        Container(
                          padding: const EdgeInsets.only(top: 50),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('운영사 ', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON)),
                              Text('내부 서류 심사', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                              Text('를 통해 ', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON)),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.only(top: 80),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('우리매장의 ', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON)),
                              Text('기본 정보를 등록', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))
                            ],
                          ),
                        ),
                        Container(padding: const EdgeInsets.only(top: 120), child: const Text('대구로 담당자가 사장님께 직접 연락드린 후', style: TextStyle(fontSize: 14))),
                        Container(padding: const EdgeInsets.only(top: 140), child: const Text('예약서비스 신청 절차를 도와드립니다.', style: TextStyle(fontSize: 14))),
                      ]),
                ),
                const Image(image: AssetImage('images/pc_cellphone_2@2x.png')),
              ],
            ),
          ),
          Container(
              width: MediaQuery.of(context).size.width,
              alignment: Alignment.center,
              color: const Color(0xff01CAFF),
              child: fluentUI.Container(
                margin: const EdgeInsets.only(top: 30, bottom: 30),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(alignment: Alignment.center, child: const Text('예약서비스에 입점하고', style: TextStyle(fontSize: 20, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL))),
                    const SizedBox(height: 5),
                    Container(
                      alignment: Alignment.center,
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text('20만 대구로 고객', style: TextStyle(fontSize: 20, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                          Text(' 에게 ', style: TextStyle(fontSize: 20, color: Colors.white, fontFamily: FONT_FAMILY_NEXON)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 5),
                    const Text('우리 매장을 더욱 알려보세요!', style: TextStyle(fontSize: 20, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                    const SizedBox(height: 20),
                    const Text('계약서 작성일 기준 약 2주 후에', style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                    const Text('대구로 예약 서비스 입점이 완료됩니다.', style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),

                  ],
                ),
              )
          ),
          Container(
              width: MediaQuery.of(context).size.width,
              alignment: Alignment.center,
              child: fluentUI.Container(
                margin: const EdgeInsets.only(top: 20, bottom: 20),
                child: const Text('* 예약 서비스를 통해 오더가 접수되었으나, 예약자가 나타나지 않아 발생하는 노쇼 문제는 대구로에서 책임 지지 않습니다.', style: TextStyle(fontSize: 12, color: Colors.grey)),
              )
          ),
          Container(alignment: Alignment.centerLeft, child: Material(child: ISCheckbox(label: '위 서비스 입점 안내를 모두 확인하였습니다.', value: _okChk, onChanged: (v) => setState(() => _okChk = v)))),
          const SizedBox(height: 20),
          ISButton(
            height: 45,
            child: const Text('예약 간편 입점 신청'),
            onPressed: () async {
              if(_okChk == false) {
                ISAlert(context, content: '입점 안내 확인 정보를 체크 해주시길 바랍니다.');
                return;
              }

              ReserveApplyModel sendData = ReserveApplyModel();
              sendData.shopCd = AuthService.SHOPCD;
              sendData.uCode = AuthService.uCode;
              sendData.userName = AuthService.uName;
              sendData.gbn = '1';

              var value = await showDialog(
                  context: context,
                  builder: (context) => FutureProgressDialog(ReserveController.to.updateReserveApply(sendData.toJson()))
              );

              if (value == null) {
                // ignore: use_build_context_synchronously
                ISAlert(context, content: '예약 서비스 입점 신청이 정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
              }

              requestAPIData();
            },
          )
        ],
      ),
    );

    var desktopContent = SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        children: <Widget>[
          Container(
              alignment: Alignment.centerLeft,
              height: 400,
              child: Row(
                children: [
                  Container(
                    margin: const EdgeInsets.only(left: 100),
                    child: Stack(
                        children: [
                          const Text('대구로', style: TextStyle(fontSize: 40, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                          Container(padding: const EdgeInsets.only(top: 50), child: const Text('방문 예약서비스', style: TextStyle(fontSize: 40, fontFamily: FONT_FAMILY_NEXON,fontWeight: FONT_BOLD))),
                          Container(padding: const EdgeInsets.only(top: 100), child: const Text('입점 안내', style: TextStyle(fontSize: 40, fontFamily: FONT_FAMILY_NEXON,fontWeight: FONT_NORMAL))),
                          Container(padding: const EdgeInsets.only(top: 170), child: const Text('클릭 몇 번으로 쉽고 간편하게!', style: TextStyle(fontSize: 16))),
                          Container(padding: const EdgeInsets.only(top: 195), child: const Text('예약 관리는 한 눈에 보기 쉽게!', style: TextStyle(fontSize: 16))),
                          Container(padding: const EdgeInsets.only(top: 240),
                            child: ISButton(
                              height: 55,
                              child: const Text('예약 간편 입점 신청'),
                              onPressed: () async {
                                _scrollController.animateTo(
                                    _scrollController.position.maxScrollExtent,
                                    curve: Curves.easeOut,
                                    duration: const Duration(milliseconds: 300));
                              },
                            ),
                          ),
                        ]),
                  ),
                  const SizedBox(width: 120),
                  const Image(image: AssetImage('images/img_alerts_405px@2x.png'), height: 400)
                ],
              )),
          Container(
              color: const Color(0xFFEFEFEF),
              alignment: Alignment.centerLeft,
              height: 500,
              child: Row(
                children: [
                  const Image(image: AssetImage('images/pc_cellphone_1@2x.png'), width: 400, height: 400),
                  const SizedBox(width: 50),
                  Container(
                    margin: const EdgeInsets.only(left: 100),
                    child: Stack(
                        children: [
                          Container(alignment: Alignment.center, height: 25, width: 55, decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: const Color(0xff01CAFF)), child: const Text('step 1', style: TextStyle(color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                          Container(padding: const EdgeInsets.only(top: 40), child: const Text('담당자가 전화 또는 방문하여', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY_NEXON,fontWeight: FONT_NORMAL))),
                          Container(padding: const EdgeInsets.only(top: 75), child: const Text('서류 작성 후 제출', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                          Container(padding: const EdgeInsets.only(top: 130), child: const Text('대구로 담당자가 사장님께 직접 연락드린 후', style: TextStyle(fontSize: 16))),
                          Container(padding: const EdgeInsets.only(top: 155), child: const Text('예약서비스 신청 절차를 도와드립니다.', style: TextStyle(fontSize: 16))),
                          Container(
                              padding: const EdgeInsets.only(top: 200),
                              child: Container(
                                height: 45,
                                width: 320,
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.white),
                                child: Row(
                                  children: [
                                    const SizedBox(width: 5),
                                    Container(alignment: Alignment.center, height: 20, width: 20, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
                                        color: const Color(0xff01CAFF)), child: const Text('1', style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                    Container(alignment: Alignment.center, child: const Text(' 한 눈에 똭! 한 줄 ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY_NEXON))),
                                    Container(alignment: Alignment.center, child: const Text('매장 소개글', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                    Container(alignment: Alignment.center, child: const Text(' (최대 20자)', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON))),
                                  ],
                                ),
                              )
                          ),
                          Container(
                              padding: const EdgeInsets.only(top: 255),
                              child: Container(
                                height: 45,
                                width: 320,
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.white),
                                child: Row(
                                  children: [
                                    const SizedBox(width: 5),
                                    Container(alignment: Alignment.center, height: 20, width: 20, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
                                        color: const Color(0xff01CAFF)), child: const Text('2', style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                    Container(alignment: Alignment.center, child: const Text(' 깔끔하고 멋진 ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY_NEXON))),
                                    Container(alignment: Alignment.center, child: const Text('매장 소개사진', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                    Container(alignment: Alignment.center, child: const Text(' (최대 20장)', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON))),
                                  ],
                                ),
                              )
                          ),
                          Container(
                              padding: const EdgeInsets.only(top: 310),
                              child: Container(
                                height: 45,
                                width: 320,
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.white),
                                child: Row(
                                  children: [
                                    const SizedBox(width: 5),
                                    Container(alignment: Alignment.center, height: 20, width: 20, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
                                        color: const Color(0xff01CAFF)), child: const Text('3', style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                    Container(alignment: Alignment.center, child: const Text(' 사장님의 매장을 ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY_NEXON))),
                                    Container(alignment: Alignment.center, child: const Text('소개할 문구', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                    Container(alignment: Alignment.center, child: const Text(' (최대 2,000자)', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON))),
                                  ],
                                ),
                              )
                          ),
                        ]),
                  ),
                ],
              )),
          Container(
              alignment: Alignment.centerLeft,
              height: 400,
              child: Row(
                children: [
                  Container(
                    margin: const EdgeInsets.only(left: 100),
                    child: Stack(
                        children: [
                          Container(alignment: Alignment.center, height: 25, width: 55, decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: const Color(0xff01CAFF)), child: const Text('step 2', style: TextStyle(color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                          Container(
                              padding: const EdgeInsets.only(top: 40),
                              child: Container(
                                height: 45,
                                width: 320,
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.white),
                                child: Row(
                                  children: [
                                    Container(alignment: Alignment.center, child: const Text('운영사', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY_NEXON))),
                                    Container(alignment: Alignment.center, child: const Text(' 내부 서류 심사', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                    Container(alignment: Alignment.center, child: const Text('를 통해', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY_NEXON))),
                                  ],
                                ),
                              )
                          ),
                          Container(
                              padding: const EdgeInsets.only(top: 75),
                              child: Container(
                                height: 45,
                                width: 320,
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.white),
                                child: Row(
                                  children: [
                                    Container(alignment: Alignment.center, child: const Text('우리매장의 ', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY_NEXON))),
                                    Container(alignment: Alignment.center, child: const Text('기본 정보를 등록', style: TextStyle(fontSize: 25, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                                  ],
                                ),
                              )
                          ),
                          Container(padding: const EdgeInsets.only(top: 130), child: const Text('대구로 담당자가 사장님께 직접 연락드린 후', style: TextStyle(fontSize: 16))),
                          Container(padding: const EdgeInsets.only(top: 155), child: const Text('예약서비스 신청 절차를 도와드립니다.', style: TextStyle(fontSize: 16))),
                        ]),
                  ),
                  const SizedBox(width: 80),
                  const Image(image: AssetImage('images/pc_cellphone_2@2x.png'), width: 400, height: 400),
                ],
              )),
          Container(
              alignment: Alignment.centerLeft,
              height: 400,
              child: Row(
                children: [
                  Stack(children: [
                    Image(image: const AssetImage('images/img_bluecellphone_445px@2x.png'), height: 400, width: MediaQuery.of(context).size.width - 288, fit: BoxFit.cover),
                    Container(
                      margin: const EdgeInsets.only(left: 100),
                      alignment: Alignment.centerLeft,
                      child: Stack(
                          children: [
                            const Row(
                              children: [
                                Text('예약서비스에 입점하고', style: TextStyle(fontSize: 25, color: Colors.white, fontFamily: FONT_FAMILY_NEXON,fontWeight: FONT_NORMAL)),
                                Text(' 20만 대구로 고객에게', style: TextStyle(fontSize: 25, color: Colors.white, fontFamily: FONT_FAMILY_NEXON,fontWeight: FONT_BOLD)),
                              ],
                            ),
                            Container(padding: const EdgeInsets.only(top: 35), child: const Text('우리 매장을 더욱 알려보세요!', style: TextStyle(fontSize: 25, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                            Container(padding: const EdgeInsets.only(top: 80), child: const Text('계약서 작성일 기준 약 2주 후에 대구로 예약 서비스 입점이 완료됩니다.', style: TextStyle(color: Colors.white, fontSize: 16))),
                            Container(
                                padding: const EdgeInsets.only(top: 150),
                                child: Container(
                                  height: 80,
                                  width: 700,
                                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.white),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(margin: const EdgeInsets.only(left: 20), child: Material(child: ISCheckbox(label: '위 서비스 입점 안내를 모두 확인하였습니다.', value: _okChk, onChanged: (v) => setState(() => _okChk = v!)))),
                                      Container(
                                        margin: const EdgeInsets.only(right: 20),
                                        child: ISButton(
                                          height: 50,
                                          child: const Text('예약 간편 입점 신청'),
                                          onPressed: () async {
                                            if(_okChk == false) {
                                              ISAlert(context, content: '입점 안내 확인 정보를 체크 해주시길 바랍니다.');
                                              return;
                                            }

                                            ReserveApplyModel sendData = ReserveApplyModel();
                                            sendData.shopCd = AuthService.SHOPCD;
                                            sendData.uCode = AuthService.uCode;
                                            sendData.userName = AuthService.uName;
                                            sendData.gbn = '1';

                                            var value = await showDialog(
                                                context: context,
                                                builder: (context) => FutureProgressDialog(ReserveController.to.updateReserveApply(sendData.toJson()))
                                            );

                                            if (value == null) {
                                              // ignore: use_build_context_synchronously
                                              ISAlert(context, content: '예약 서비스 입점 신청이 정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                            }

                                            requestAPIData();
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                            ),
                            Container(padding: const EdgeInsets.only(top: 250), child: const Text('* 예약 서비스를 통해 오더가 접수되었으나, 예약자가 나타나지 않아 발생하는 노쇼 문제는 대구로에서 책임 지지 않습니다.', style: TextStyle(color: Colors.white, fontSize: 13))),
                          ]),
                    ),
                  ])
                ],
              )),
        ],
      ),
    );

    return Container(
     // header: const LayoutHeader(titleName: '사장님사이트 현황'),//SizedBox(width: double.infinity, height: 100,),//
     // bottomBar: const LayoutBottom(),
      child: Responsive.isMobile(context) ? mobileContent : desktopContent,
    );
  }

  void _scrollDown() {
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(seconds: 2),
      curve: Curves.fastOutSlowIn,
    );
  }

  void scrollToMaxExtent() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 100),
        curve: Curves.easeIn,
      );
    });
  }
}