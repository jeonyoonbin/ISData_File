import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/shopNewsListModel.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopNewsEdit extends StatefulWidget {
  final String? seq;

  const ShopNewsEdit({Key? key, this.seq}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopNewsEditState();
  }
}

class ShopNewsEditState extends State<ShopNewsEdit> {
  TextEditingController title = TextEditingController(text: '');
  TextEditingController contents = TextEditingController(text: '');

  ShopNewsListModel data = ShopNewsListModel();

  int getByteLength(String text) {
    return utf8.encode(text).length;
  }


  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ReserveController.to.getShopNewsDetail(widget.seq! ?? ''))
    );

    if (value == null) {
      data.shopCd = '';
      data.seq = '';
      data.title = '';
      data.contents = '';
      data.insertDate = '';
      data.useGbn = '';
      data.sortSeq = '';
    }
    else {
      value.forEach((element) {
        data.shopCd = element['shopCd'].toString();
        data.seq = element['seq'].toString();
        data.title = element['title'].toString();
        data.contents = element['contents'].toString();
        data.insertDate = element['insertDate'].toString();
        data.useGbn = element['useGbn'].toString();
        data.sortSeq = element['sortSeq'].toString();

      });
    }
    title.text = data.title!;
    contents.text = data.contents!;
    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    title.dispose();
    contents.dispose();
    data = ShopNewsListModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(CouponController());
    WidgetsBinding.instance.addPostFrameCallback((c) {
      if(widget.seq != null){
      requestAPIData();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(widget.seq == null ? '매장 소식 등록' : '매장 소식 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
              const SizedBox(width: 5,),
              Responsive.isMobile(context) ? Container() : const Text('매장 소식 내용을 입력해 주세요', style: TextStyle(color: Colors.grey, fontSize: 11) ,
              ),
            ],
          ),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //const Divider(color: Colors.grey, height: 0.0,),
                const SizedBox(height: 20,),
                const Text(
                  '* 제목과 내용은 필수 입력입니다.',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Text('제목', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                    Text('(${getByteLength(title.text)} / 60 byte)', style: TextStyle(color: Colors.grey, fontSize: 13),),
                  ],
                ),
                const SizedBox(height: 3,),
                TextFormField(
                  controller: title,
                  style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                  onChanged: (v) {
                    if (getByteLength(title.text) <= 60) {
                      setState(() {
                        data.title = v;
                      });
                    } else {
                      title.text = data.title!;
                      ISAlert(context, content: '60byte를 초과할 수 없습니다.');
                      return;
                    }
                  },
                  decoration: const InputDecoration(
                    hintText: '제목을 입력해주세요.',
                    fillColor: Colors.white,
                    filled: true,
                    enabled: true,
                    enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.black12, width: 1.0)),
                    focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.lightBlueAccent, width: 1.0)),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Text('내용', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                    Text('(${getByteLength(contents.text)} / 4000 byte)', style: TextStyle(color: Colors.grey, fontSize: 13),),
                  ],
                ),
                const SizedBox(height: 3,),
                TextFormField(
                  controller: contents,
                  maxLines: 7,
                  style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                  onChanged: (v) {
                    if (getByteLength(contents.text) <= 4000) {
                      setState(() {
                        data.contents = v;
                      });
                    } else {
                      contents.text = data.contents!;
                      ISAlert(context, content: '4000byte를 초과할 수 없습니다.');
                      return;
                    }
                  },
                  decoration: const InputDecoration(
                    hintText: '내용을 입력해주세요.',
                    fillColor: Colors.white,
                    filled: true,
                    enabled: true,
                    //hintStyle: TextStyle(color: Colors.black54, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                    enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.black12, width: 1.0)),
                    focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.lightBlueAccent, width: 1.0)),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 50,),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {

              if(data.title == null || data.title == ''){
                ISAlert(context, content: '제목을 입력해주세요.');
                return;
              }
              if(data.contents == null || data.contents == ''){
                ISAlert(context, content: '내용을 입력해주세요.');
                return;
              }

              if(widget.seq == null){
                ISConfirm(context, '알림', '매장 소식을 등록하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                  Navigator.of(context).pop();

                  if (isOK){
                    data.shopCd = AuthService.SHOPCD;
                    data.useGbn = 'Y';
                    data.userId = AuthService.SHOPNAME;
                    data.seq = '0';
                    var value = await showDialog(
                        context: context,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(ReserveController.to.addShopNews(data.toJson()))
                    );

                    if (value == null) {
                      ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                    }
                    else {
                      if (value == '00') {
                        Navigator.of(context).pop(true);
                      }
                      else{
                        ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                      }
                    }
                  }
                });
              }else{
                ISConfirm(context, '알림', '매장 소식을 수정하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                  Navigator.of(context).pop();

                  if (isOK){
                    data.shopCd = AuthService.SHOPCD;
                    data.userId = AuthService.SHOPNAME;
                    var value = await showDialog(
                        context: context,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(ReserveController.to.updateShopNews(data.toJson()))
                    );
                    if (value == null) {
                      ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                    }
                    else {
                      if (value == '00') {
                        Navigator.of(context).pop(true);
                      }
                      else{
                        ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                      }
                    }
                  }
                });
              }
            },
            child: Text(widget.seq == null ? '등록' : '변경', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


