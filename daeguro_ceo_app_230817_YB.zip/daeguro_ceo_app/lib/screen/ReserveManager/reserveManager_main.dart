import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/DashBoardManager/dashboard_week_order_model.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListModel.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListRequestModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/screen/Common/commonPopup_main.dart';
import 'package:daeguro_ceo_app/screen/DashBoardManager/dashboardManagerController.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeDetailInfo.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManager_00.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManager_20.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManager_30.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:get/instance_manager.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class ReserveMain extends StatefulWidget {
  const ReserveMain({Key? key}) : super(key: key);

  @override
  State<ReserveMain> createState() => _ReserveMainState();
}
    
class _ReserveMainState extends State<ReserveMain> with PageMixin {

  Future<String?> requestReserAPIData() async {
    String retValue = '';
    await ReserveController.to.getShopReserveStatus(AuthService.SHOPCD).then((value) {
      if (value == null) {
        //ISAlert(context, title: '예약 정보 조회 실패', content: '예약 정보 조회에 실패하였습니다.');
        retValue = '${ReserveController.to.msg}';
      } else {
        ReserveController.to.reserveApplyDate.value = value[0]['applyDate'];
        ReserveController.to.reservePageGbn.value = value[0]['status'];
        retValue = '00';
      }
    });

    //setState(() {});

    return retValue;
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());

    debugPrint('initState ReserveMain');

    WidgetsBinding.instance.addPostFrameCallback((c) async {
      String? retValue = await requestReserAPIData();

      if (retValue == '00'){
        setState(() { });
      }
      else{
        ISAlert(context, content: '정상 조회 되지 않았습니다.\n[다시 시도해 주세요]\n→ ${retValue}');
      }
    });
  }

  @override
  void dispose() {
    debugPrint('dispose ReserveMain');

    super.dispose();
  }

  Widget _rtnReserMenu (String _pageGbn) {
    // 00:신청가능, 20:신청중, 30:심사완료
    if (_pageGbn == '00')      {      return const ReserveManager00();    }
    else if (_pageGbn == '20') {      return const ReserveManager20();    }
    else if (_pageGbn == '30') {      return const ReserveManager30();    }
    else                       {      return const SizedBox.shrink();     }
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
          String? retValue = await requestReserAPIData();

          if (retValue == '00'){
          }
          else{
            ISAlert(context, content: '정상 조회 되지 않았습니다.\n[다시 시도해 주세요]\n→ ${retValue}');
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return fluentUI.ScaffoldPage.withPadding(
      header: const LayoutHeader(titleName: '사장님사이트 현황'),//SizedBox(width: double.infinity, height: 100,),//
      bottomBar: const LayoutBottom(),
      content: Obx(() => Container(child: _rtnReserMenu(ReserveController.to.reservePageGbn.toString())))
    );
  }
}