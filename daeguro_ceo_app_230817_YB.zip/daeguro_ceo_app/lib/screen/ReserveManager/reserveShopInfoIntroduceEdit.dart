import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ReserveShopInfoIntroduceEdit extends StatefulWidget {
  final String? Introduce;
  final String ? ccCode;
  const ReserveShopInfoIntroduceEdit({Key? key, this.Introduce, this.ccCode})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ReserveShopInfoIntroduceEditState();
  }
}

class ReserveShopInfoIntroduceEditState extends State<ReserveShopInfoIntroduceEdit> {
  String? setIntroduce;

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    setIntroduce = widget.Introduce!;

    Get.put(ShopController());
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('한줄 매장 소개글', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12,),
                const Text('대구로 앱에 노출할 매장 소개글을 한줄로 입력해 주세요', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                const Text('(특수문자, 띄어쓰기 포함 최대 20자)', style: TextStyle(color: Colors.black54,fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                ISInput(
                  autofocus: true,
                  value: setIntroduce == 'null' ? '' : setIntroduce,
                  //padding: 0,
                  height: 80,
                  label: '한줄 매장 소개',
                  maxLength: 20,
                  onChange: (v) {
                    setIntroduce = v;
                  },
                ),
                const Text('*입력예시: 재방문 100% 대구 찜닭 맛집, 대구 수성구 분위기 좋은 레스토랑 맛집, 조미료 없는 건강한 식당', style: TextStyle(color: Colors.black54,fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                const SizedBox(height: 10)
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              ISConfirm(context, '한줄 매장 소개글 변경', '한줄 매장 소개글 정보를 변경합니다. \n\n계속 진행 하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                if (isOK){
                  Navigator.of(context).pop();

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ReserveController.to.updateReserveShopIntroduce(AuthService.SHOPCD, widget.ccCode.toString(), setIntroduce.toString(), AuthService.uCode))
                  );

                  if (value == null) {
                    // ignore: use_build_context_synchronously
                    ISAlert(context, content: '한줄 매장 소개글 변경에 실패했습니다. \n\n관리자에게 문의 바랍니다');
                    return;
                  }

                  Navigator.of(context).pop();
                } else {
                  Navigator.of(context).pop();
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


