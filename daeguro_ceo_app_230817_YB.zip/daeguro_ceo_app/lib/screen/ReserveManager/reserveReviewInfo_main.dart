import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/DashBoardManager/dashboard_week_order_model.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListModel.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListRequestModel.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/screen/Common/commonPopup_main.dart';
import 'package:daeguro_ceo_app/screen/DashBoardManager/dashboardManagerController.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeDetailInfo.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/instance_manager.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class ReserveReviewInfoMain extends StatefulWidget {
  const ReserveReviewInfoMain({Key? key}) : super(key: key);

  @override
  State<ReserveReviewInfoMain> createState() => _ReserveReviewInfoMainState();
}

class _ReserveReviewInfoMainState extends State<ReserveReviewInfoMain> with PageMixin {
  final ScrollController _scrollController = ScrollController();

  requestAPIData() async {
    // var value = await showDialog(
    //     context: context,
    //     builder: (context) => FutureProgressDialog(DashBoardController.to.getShopWeeklyStat('%', formatDate(DateTime(date.year, date.month, date.day - 6), [yyyy, mm, dd]), formatDate(DateTime.now(), [yyyy, mm, dd])))
    // );
    //
    // if (value == null) {
    //   // ignore: use_build_context_synchronously
    //   ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
    //   //Navigator.of(context).pop;
    // } else {
    //   value.forEach((element) {
    //     // tempData.orderDate = element['orderDate'].toString();
    //     // tempData.totCnt = int.parse(element['totCnt'].toString());
    //     // tempData.totAmt = int.parse(element['totAmt'].toString());
    //     // tempData.okCnt = int.parse(element['okCnt'].toString());
    //     // tempData.okAmt = int.parse(element['okAmt'].toString());
    //     // tempData.cancelCnt = int.parse(element['cancelCnt'].toString());
    //     // tempData.cancelAmt = int.parse(element['cancelAmt'].toString());
    //     //
    //     // dataWeekOrderList.add(tempData);
    //   });
    // }

    setState(() {});

  }

  @override
  void initState() {
    super.initState();

    Get.put(DashBoardController());

    debugPrint('initState HomePage');

    WidgetsBinding.instance.addPostFrameCallback((c) async {
      requestAPIData();

      await Future.delayed(const Duration(milliseconds: 500), () {
        requestAPIData();
      });
    });

    //setState(() {});
  }

  @override
  void dispose() {
    debugPrint('dispose HomePage');

    super.dispose();
    _scrollController.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
          requestAPIData();

          await Future.delayed(const Duration(milliseconds: 500), () {
            requestAPIData();
          });
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    var mobileContent = SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        children: [
          Container(height: 10,),

          const SizedBox(height: 20,),
        ],
      ),
    );

    var desktopContent = Column(
      children: <Widget>[
        Container(height: 20,),

      ],
    );

    return fluentUI.ScaffoldPage.scrollable(
      header: const LayoutHeader(titleName: '사장님사이트 현황'),//SizedBox(width: double.infinity, height: 100,),//
      bottomBar: const LayoutBottom(),
      children: [
        const SizedBox(height: 16,),
        Responsive.isMobile(context) ? mobileContent : desktopContent,
      ],
    );
  }
}