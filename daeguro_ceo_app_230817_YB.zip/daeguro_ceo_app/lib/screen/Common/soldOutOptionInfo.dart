import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/Common/commonNoFlagModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/soldOutOptionListModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class SoldOutOptionInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const SoldOutOptionInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<SoldOutOptionInfoMain> createState() => _SoldOutOptionInfoMainState();
}

class _SoldOutOptionInfoMainState extends State<SoldOutOptionInfoMain> {

  final List<SoldOutOptionListModel> dataList = <SoldOutOptionListModel>[];

  bool isGroupProduct = true;
  bool isGroupMenu = false;
  late List<bool> isGroupSelected;

  String currentJobGbn = 'D';

  String prodCnt = '0';
  String menuCnt = '0';

  requestAPIData() async {
    bool isProductUse = (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER || AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET) ? true : false;

    currentJobGbn = (isProductUse == true && isGroupProduct == true) ? 'F' : 'D';

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getProductNoFlagList(currentJobGbn, 'O'))
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        SoldOutOptionListModel temp = SoldOutOptionListModel();
        temp.optionCd = element['optionCd'] as String;
        temp.optGrpCd = element['optGrpCd'] as String;
        temp.optName = element['optName'] as String;
        temp.optCost = element['optCost'] as String;
        temp.optUseGbn = element['optUseGbn'] as String;
        temp.optNoFlag = element['optNoFlag'] as String;

        dataList.add(temp);
      });

      prodCnt = ProductInfoController.to.prodCnt;
      menuCnt = ProductInfoController.to.menuCnt;
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    isGroupSelected = [isGroupProduct, isGroupMenu];

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    isGroupSelected.clear();
    dataList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          elevation: 1,
          shape: appTheme.cardShapStyle,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET)...[
                  ToggleButtons(
                    constraints: const BoxConstraints(minWidth: 160, minHeight: 40),
                    borderRadius: const BorderRadius.all(Radius.circular(4)),
                    isSelected: isGroupSelected,
                    onPressed: (value) {
                      if (value == 0) {
                        isGroupProduct = true;
                        isGroupMenu = false;
                      } else {
                        isGroupProduct = false;
                        isGroupMenu = true;
                      }

                      requestAPIData();

                      setState(() {
                        isGroupSelected = [isGroupProduct, isGroupMenu];
                      });
                    },
                    children:  [
                      Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Text('장보기 상품옵션 (${prodCnt})개', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY))
                      ),
                      Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Text('우리가게 메뉴옵션 (${menuCnt})개', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY))
                      ),
                    ],
                  ),
                ]
                else...[
                  const Text('옵션 품절', style: TextStyle(fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                ],
                const SizedBox.shrink()
                // ISInput(
                //   value: tempStr,
                //   width: 260,
                //   label: '옵션명으로 검색해 보세요.',
                //   prefixIcon: const Icon(Icons.search, color: Colors.black54,),
                //   onSaved: (v) {
                //     tempStr = v;
                //
                //     debugPrint('tempStr:${tempStr}');
                //   },
                // )
              ],
            ),
          ),
        ),
        const SizedBox(height: 4),
        //const Divider(color: Colors.black,),//fluentUI.Divider(style: fluentUI.DividerThemeData(horizontalMargin: EdgeInsets.zero)),
        itemListView(),

        const Divider(height: 1)
      ],
    );
  }

  Widget itemListView() {
    final appTheme = context.watch<AppTheme>();

    return SizedBox(
      height: (widget.tabviewHeight! - (Responsive.isMobile(context) == true ? 105 : 75)),
      child: ListView.builder(
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          itemBuilder: (ctx, index) {
            return Card(
              elevation: 1,
              shape: appTheme.cardShapStyle,
              child: Padding(
                key: Key('$index'),
                padding: EdgeInsets.symmetric(horizontal: Responsive.isMobile(context) ? 5 : 16.0),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Flexible(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Container(
                            padding: const EdgeInsets.only(left: 4, right: 0, top: 8, bottom: 2),
                            alignment: Alignment.topLeft,
                            child: Column(
                              children: <Widget>[
                                Row(
                                  children: [
                                    dataList[index].optUseGbn == 'Y'
                                        ? Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                        child: const Center(
                                            child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                            ))
                                    ) : Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                        child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                    ),
                                    dataList[index].optNoFlag == 'Y'
                                        ? Container(
                                        width: 26,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.redAccent.shade100),
                                        child: const Center(child: Text('품절', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: Text(dataList[index].optName ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY),),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(left: 10, right: 10, top: 2, bottom: 8),
                            alignment: Alignment.topLeft,
                            child: Text('${Utils.getCashComma(dataList[index].optCost!)} 원', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                          ),
                        ],
                      ),
                    ),
                    // Padding(
                    //   padding: const EdgeInsets.fromLTRB(0, 0, 30, 0),
                    //   child: ISToggleButtons(
                    //     [
                    //       ISOptionModel(value: 'Y', label: '판매중'),
                    //       ISOptionModel(value: 'N', label: '품절'),
                    //     ],
                    //     buttonHeight: 30,
                    //     borderColor: Colors.blueAccent,
                    //     defaultValue: dataList[index].optNoFlag,
                    //     afterOnPress: (v) {
                    //       showDialog(
                    //         context: context,
                    //         barrierDismissible: true,
                    //         builder: (context) => const SoldOutEdit(),
                    //       );
                    //       // setState(() {
                    //       //   this.selectedImageType = v;
                    //       // });
                    //       //
                    //       // loadData();
                    //     },
                    //   ),
                    // ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 20, 0),
                      child: OutlinedButton(
                        style: ButtonStyle(side: MaterialStateProperty.all(const BorderSide(color: Colors.red))),
                        onPressed: () {
                          ISConfirm(context, '품절 해제', '해당 옵션을 품절 해제 하시겠습니까?', (context, isOK) async {
                            Navigator.of(context).pop();

                            if (isOK){
                              CommonNoFlagModel formData = CommonNoFlagModel();

                              formData.jobGbn = currentJobGbn;
                              formData.subGbn = 'O';
                              formData.shopCd = AuthService.SHOPCD;
                              formData.targetCd = dataList[index].optionCd;
                              formData.noFlag = 'N';
                              formData.uCode = AuthService.uCode;
                              formData.uName = AuthService.uName;

                              var value = await showDialog(
                                  context: context,
                                  barrierColor: Colors.transparent,
                                  builder: (context) => FutureProgressDialog(ProductInfoController.to.updateNoFlag(formData.toJson()))
                              );

                              if (value == null) {
                                ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                              }
                              else {
                                if (value == '00') {
                                  requestAPIData();
                                }
                                else{
                                  ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                                }
                              }
                            }
                          });
                        },
                        child: const Text('품절 해제', style: TextStyle(color: Colors.red),),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
          //separatorBuilder: (BuildContext context, int index) { return const Divider(thickness: 1, height: 0.0,); },
          itemCount: dataList.length
      ),
    );
  }
}