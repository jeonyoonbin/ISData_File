import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CommonImageVerticalPreviewMain extends StatefulWidget {
  final List<String>? imageList;

  const CommonImageVerticalPreviewMain({Key? key, this.imageList})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CommonImageVerticalPreviewMainState();
  }
}

class CommonImageVerticalPreviewMainState extends State<CommonImageVerticalPreviewMain> {
  int totalCnt = 0;
  int currentIdx = 0;

  List<String> listData = [];

  @override
  void initState() {
    super.initState();

    //debugPrint('initState CommonPopupMain');

    listData = widget.imageList!;

    totalCnt = widget.imageList!.length;
  }
  @override
  void dispose() {
    super.dispose();
    listData.clear();
    widget.imageList?.clear();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 500.0, maxHeight: 720),
      //contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      //isPopupNotice: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text('설명 이미지(총: ${totalCnt}개)', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Card(
          clipBehavior: Clip.antiAlias,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(12))),
          margin: EdgeInsets.zero,
          child: listData[currentIdx] == null
              ? const Image(image: AssetImage('images/thumbnail-empty.png'))
              : SingleChildScrollView(
                child: Column(children: setImageView(),),
              ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleSingle,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('닫기', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),        
      ],
    );
  }

  List<Widget> setImageView() {
    List<Widget> list = [];

    for (int i = 0; i < totalCnt; i++) {
      list.add(Image.network('${listData[i]}?tm=${Utils.getTimeStamp()}', fit: BoxFit.cover, gaplessPlayback: true,
          loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
            if (loadingProgress == null) return child;
            return const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
              ),
            );
          },
          errorBuilder: (context, error, stackTrace) {
            return const SizedBox(
                width: double.infinity,
                child: Image(image: AssetImage('images/thumbnail-empty.png'), fit: BoxFit.cover));
          },
        ),
      );
    }

    return list;
  }
}


