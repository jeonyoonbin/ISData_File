import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopDeliTipCostModel {
  ShopDeliTipCostModel();

  bool? selected = false;
  String? cost = '';
  String? deliTip = '';
}