class ShopOperateInfoModel {
  String? absentYn = '';
  String? reviewUseGbn = '';
  String? holiDayTerm = '';
  String? kindShopStatus = '';
  String? childMealYn = '';
  String? minAmtPass = '';
  String? answerText = '';
  String? kindShopCancelDt = '';
  String? exchangeNotice = '';
  String? returnNotice = '';
  String? rejectNotice = '';
  String? reserveTerm = '';
  String? lAuth = '';
  String? lTel = '';
  String? lSeller = '';
}
