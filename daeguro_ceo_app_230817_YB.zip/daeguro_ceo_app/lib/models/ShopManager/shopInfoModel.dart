import 'package:daeguro_ceo_app/screen/ShopManager/shopRegistInfo_main.dart';

class ShopInfoModel {
  ShopInfoModel();
  String? shopName = '';
  String? ccCode = '';
  String? shopImgURL = '';
  String? owner = '';
  String? telNo = '';
  String? mobile = '';
  String? addrJibun = '';
  String? addrRoad = '';
  String? addrDetail = '';
  String? items = '';
  String? shopType = '';
  String? acceptState = '';
  String? deliInfo = '';
  String? appPayType = '';
  String? toGoAcceptState = '';

  bool? meetToPay = false;
  bool? appType = false;
  bool? meetToCard = false;


}
