import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveShopUpdateNoticeModel {
  ReserveShopUpdateNoticeModel();

  String? shopCd;
  String? ccCode;
  String? notice;
  String? userID;

  factory ReserveShopUpdateNoticeModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveShopUpdateNoticeModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveShopUpdateNoticeModel()
    ..shopCd = json['shopCd'] as String
    ..ccCode = json['ccCode'] as String
    ..notice = json['notice'] as String
    ..userID = json['userID'] as String;
}

Map<String, dynamic> _$ModelToJson(ReserveShopUpdateNoticeModel instance) => <String, dynamic>{
  'shopCd': instance.shopCd,
  'ccCode': instance.ccCode,
  'notice': instance.notice,
  'userID': instance.userID
};