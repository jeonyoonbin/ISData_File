import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopNewsListModel {
  ShopNewsListModel();

  bool? selected = false;
  String? rNum;
  String? shopCd;
  String? seq;
  String? title;
  String? contents;
  String? insertDate;
  String? useGbn;
  String? sortSeq;
  String? userId;

  factory ShopNewsListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopNewsListModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopNewsListModel()
    ..rNum = json['rNum']
    ..shopCd = json['shopCd']
    ..seq = json['seq']
    ..title = json['title']
    ..contents = json['contents']
    ..insertDate = json['insertDate']
    ..useGbn = json['useGbn']
    ..sortSeq = json['sortSeq'];
}

Map<String, dynamic> _$ModelToJson(ShopNewsListModel instance) =>
    <String, dynamic>{
      'rNum': instance.rNum,
      'shopCd': instance.shopCd,
      'seq': instance.seq,
      'title': instance.title,
      'contents': instance.contents,
      'insertDate': instance.insertDate,
      'useGbn': instance.useGbn,
      'sortSeq': instance.sortSeq,
      'userId': instance.userId,
    };
