class AccountHistoryModel {
  AccountHistoryModel({
    this.orderNo,
    this.orderDate,
    this.status,
    this.packOrderYn,
    this.packOrderYnName,
    this.totAmt,
    this.menuAmt,
    this.deliTipAmt,
    this.totalDiscAmt,
    this.shopDiscAmt,
    this.totalFeeAmt,
    this.appFeeAmt,
    this.pgFeeAmt,
    this.deliTotAmt,
    this.totalAmt,
    this.deliCashAmt,
    this.deliCardAmt,
    this.memo,
    this.appPayGbnName,
    this.transferAmt,
    this.liveDiscAmt,
    this.adminAmt,
    this.packDiscAmt,
    this.shopCouponAmt,
    this.rNum,
    this.chargeDate,
    this.inAmt,
    this.outAmt,
    this.chargeAmt,
    this.shopCd,
    this.appMenuAmt,
    this.appTipAmt,
    this.meetMenuAmt,
    this.meetTipAmt,
    this.isChild = false,
    this.isChild2 = false,
    this.accumulationClassification,
    this.orderProductInformation,
    this.ioGbn
  });

  bool selected = false;
  bool viewSelected = false;
  bool isChild = false;
  bool isChild2 = false;
  bool isOpened = false;

  String? orderNo;
  String? orderDate;
  String? status;
  String? packOrderYn;
  String? packOrderYnName;
  String? totAmt;
  String? menuAmt;
  String? deliTipAmt;
  String? totalDiscAmt;
  String? shopDiscAmt;
  String? totalFeeAmt;
  String? appFeeAmt;
  String? pgFeeAmt;
  String? deliTotAmt;
  String? totalAmt;
  String? deliCashAmt;
  String? deliCardAmt;
  String? memo;
  String? appPayGbnName;
  String? transferAmt;
  String? liveDiscAmt;
  String? adminAmt;
  String? packDiscAmt;
  String? shopCouponAmt;
  String? rNum;
  String? chargeDate;
  String? inAmt;
  String? outAmt;
  String? chargeAmt;
  String? shopCd;
  String? appMenuAmt;
  String? appTipAmt;
  String? meetMenuAmt;
  String? meetTipAmt;
  String? accumulationClassification;
  String? orderProductInformation;
  String? ioGbn;


  // String? orderDate;
  // String? orderNo;
  // String? appPayGbnName;
  // String? packOrderYnName;
  // String? status;
  //
  // String? deposit;
  // String? withdraw;
  // String? finalAmount;
  //
  // String? orderAmount;
  // String? deliveryCharge;
  // String? brokerageFee;
  // String? pGCharge;

  int? totalDeposit;
  int? totalWithdraw;
  int? totalReward;
}
