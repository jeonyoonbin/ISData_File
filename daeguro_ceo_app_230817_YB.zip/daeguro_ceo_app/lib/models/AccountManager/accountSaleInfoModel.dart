class AccountSaleInfoModel {
  AccountSaleInfoModel({
    this.orderDate,
    this.packOrderYnName,
    this.body,
    this.totAmt,
    this.appMenuAmt,
    this.appTipAmt,
    this.meetMenuAmt,
    this.meetTipAmt,
    this.pgFeeAmt,
    this.packDiscAmt,
    this.totalAmt,
    this.appFeeAmt,
    this.totalFeeAmt,
    this.totalDiscAmt,
    this.shopCouponAmt,
    this.isChild = false,
    this.isChild2 = false,
    this.tooltip
  });
  bool selected = false;
  bool viewSelected = false;
  bool isChild = false;
  bool isChild2 = false;
  bool isOpened = false;

  String? orderDate;          // 매출일
  String? packOrderYnName;    // 매출처
  String? body;             // 매출상세

  String? totAmt;           // 매출금액
  String? appMenuAmt;       // 주문금액
  String? appTipAmt;        // 배달팁
  String? meetMenuAmt;      // 만나서결제 금액
  String? meetTipAmt;
  String? pgFeeAmt;         // PG수수료
  String? packDiscAmt;      // 포장할인
  String? totalAmt;         //정산 금액
  String? appFeeAmt;        // 중계 수수료
  String? totalFeeAmt;      // 차감금액
  String? totalDiscAmt;     // 고객 할인 비용
  String? shopCouponAmt;    // 가맹점쿠폰
  String? tooltip;   // 툴팁


  int? totalSaleAmount;
  int? totalReward;
}
