import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class WithdrawModel {
  WithdrawModel();

  String? shopCd;
  String? withdrawCycle;
  String? withdrawDate;
  String? withdrawDay;
  String? withdrawHour;
  String? withdrawMinute;
  String? withdrawAmt;
  String? fullWithdrawalYn;
  String? modUcode;
  String? modName;
  String? useYn;

  String? mobile;
  String? amt;
  String? shopPass;

  factory WithdrawModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

WithdrawModel _$ModelFromJson(Map<String, dynamic> json) {
  return WithdrawModel()
    ..shopCd = json['shopCd'] as String
    ..withdrawCycle = json['withdrawCycle'] as String
    ..withdrawDate = json['withdrawDate'] as String
    ..withdrawDay = json['withdrawDay'] as String
    ..withdrawHour = json['withdrawHour'] as String
    ..withdrawMinute = json['withdrawMinute'] as String
    ..withdrawAmt = json['withdrawAmt'] as String
    ..fullWithdrawalYn = json['fullWithdrawalYn'] as String
    ..useYn = json['useYn'] as String;

}

Map<String, dynamic> _$ModelToJson(WithdrawModel instance) =>
    <String, dynamic>{
      'shopCd': instance.shopCd,
      'cycle': instance.withdrawCycle,
      'date': instance.withdrawDate,
      'day': instance.withdrawDay,
      'hour': instance.withdrawHour,
      'minute': instance.withdrawMinute,
      'amt': instance.withdrawAmt,
      'allYn': instance.fullWithdrawalYn,
      'modUcode': instance.modUcode,
      'modName': instance.modName,
      'useYn': instance.useYn,
      'mobile': instance.mobile,
      'shopPass': instance.shopPass,

    };
