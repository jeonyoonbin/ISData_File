import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionLinkAddEditModel {
  OptionLinkAddEditModel();

  String? shopCd;
  String? menuCd;
  String? count;
  List<String>? optGrpCd = [];

  factory OptionLinkAddEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

OptionLinkAddEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return OptionLinkAddEditModel()
    ..shopCd = json['shopCd'] as String
    ..menuCd = json['menuCd'] as String
    ..count = json['count'] as String
    ..optGrpCd = json['optGrpCd'].cast<String>();
}

Map<String, dynamic> _$ModelToJson(OptionLinkAddEditModel instance) => <String, dynamic>{
  'shopCd': instance.shopCd,
  'menuCd': instance.menuCd,
  'count': instance.count,
  'optGrpCd': instance.optGrpCd
};