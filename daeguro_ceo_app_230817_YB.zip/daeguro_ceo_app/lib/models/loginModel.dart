import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class LoginModel {
  LoginModel();

  String? jobGbn;
  String? shopCd;
  String? id;
  String? pwd;
  String? key;

  factory LoginModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

LoginModel _$ModelFromJson(Map<String, dynamic> json) {
  return LoginModel()
    ..jobGbn = json['jobGbn'] as String
    ..shopCd = json['shopCd'] as String
    ..id = json['id'] as String
    ..pwd = json['pwd'] as String
    ..key = json['key'] as String;

}

Map<String, dynamic> _$ModelToJson(LoginModel instance) => <String, dynamic>{
  'jobGbn': instance.jobGbn,
  'shopCd': instance.shopCd,
  'id': instance.id,
  'pwd': instance.pwd,
  'key': instance.key
};