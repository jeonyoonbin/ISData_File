

import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductBundleLegalInfoModel {
  ProductBundleLegalInfoModel();

  String? jobGbn;
  String? prodCd;
  String? shopCd;
  String? lName;
  String? lType;
  String? lMarker;
  String? lLocation;
  String? lDop;
  String? lUbd;
  String? lQpp;
  String? lRawMaterial;
  String? lNutrient;
  String? lGmo;
  String? lCaution;
  String? lImports;
  String? uCode;
  String? uName;

  factory ProductBundleLegalInfoModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ProductBundleLegalInfoModel _$ModelFromJson(Map<String, dynamic> json) {
  return ProductBundleLegalInfoModel()
    ..jobGbn = json['jobGbn']
    ..prodCd = json['prodCd']
    ..shopCd = json['shopCd']
    ..lName = json['lName']
    ..lType = json['lType']
    ..lMarker = json['lMarker']
    ..lLocation = json['lLocation']
    ..lDop = json['lDop']
    ..lUbd = json['lUbd']
    ..lQpp = json['lQpp']
    ..lRawMaterial = json['lRawMaterial']
    ..lNutrient = json['lNutrient']
    ..lGmo = json['lGmo']
    ..lCaution = json['lCaution']
    ..lImports = json['lImports']
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(ProductBundleLegalInfoModel instance) =>
    <String, dynamic>{
      'jobGbn': instance.jobGbn,
      'prodCd': instance.prodCd,
      'shopCd': instance.shopCd,
      'lName': instance.lName,
      'lType': instance.lType,
      'lMarker': instance.lMarker,
      'lLocation': instance.lLocation,
      'lDop': instance.lDop,
      'lUbd': instance.lUbd,
      'lQpp': instance.lQpp,
      'lRawMaterial': instance.lRawMaterial,
      'lNutrient': instance.lNutrient,
      'lGmo': instance.lGmo,
      'lCaution': instance.lCaution,
      'lImports': instance.lImports,
      'uCode': instance.uCode,
      'uName': instance.uName
    };