import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOptionLinkEditModel {
  String? shopCd;
  String? prodCd;
  List<String>? optGrpCd;
  String? uCode;
  String? uName;

  ProductOptionLinkEditModel({this.shopCd, this.prodCd, this.uCode, this.uName});

  ProductOptionLinkEditModel.fromJson(Map<String, dynamic> json) {
    shopCd = json['shopCd'];
    prodCd = json['prodCd'];
    optGrpCd = json['optGrpCd'].cast<String>();
    uCode = json['uCode'];
    uName = json['uName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['shopCd'] = shopCd;
    data['prodCd'] = prodCd;
    data['optGrpCd'] = optGrpCd;
    data['uCode'] = uCode;
    data['uName'] = uName;
    return data;
  }
}