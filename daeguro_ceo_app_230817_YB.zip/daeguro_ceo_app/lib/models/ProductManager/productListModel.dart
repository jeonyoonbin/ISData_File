import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductListModel {
  ProductListModel();

  bool selected = false;

  String? alwaysDiscountYn = '';
  //String? isDiscountYn = '';

  String? divName = '';
  String? prodCode = '';
  String? prodName = '';
  String? cost = '';
  String? useGbn = '';
  String? noFlag = '';
  String? mainYn = '';
  String? discStDt = '';
  String? discToDt = '';
  String? amount = '';
  String? discAmt = '';
  String? discRatio = '';
  String? ribbonCardYn = '';
  String? fileName = '';
  String? categorys = '';
  String? thems = '';
  String? discMarkGbn = '';
  String? catCodes = '';
  String? themCodes = '';
}


