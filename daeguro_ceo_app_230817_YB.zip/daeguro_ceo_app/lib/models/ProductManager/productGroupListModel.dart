import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductGroupListModel {
  ProductGroupListModel();

  bool selected = false;

  String? code = '';
  String? name = '';
  String? memo = '';
  String? useGbn = '';
  String? sortSeq = '';
}
