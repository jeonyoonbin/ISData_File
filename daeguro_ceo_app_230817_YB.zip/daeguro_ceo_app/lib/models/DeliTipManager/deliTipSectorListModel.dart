import 'package:daeguro_ceo_app/models/LiveEventManager/liveeventMenuListEditModel.dart';

class DeliTipSectorListModel {
  DeliTipSectorListModel();

  String? ccCode;
  String? shopCd;
  String? sidoName;
  String? sidoCode;
  String? gunguName;
  String? gunguCode;
  String? dongName;

  List<String>? dongRiName;
}
