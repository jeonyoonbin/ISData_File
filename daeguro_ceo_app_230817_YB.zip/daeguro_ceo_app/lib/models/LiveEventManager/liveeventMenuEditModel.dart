import 'package:daeguro_ceo_app/models/LiveEventManager/liveeventMenuListEditModel.dart';

class LiveEventMenuEditModel {
  LiveEventMenuEditModel({
    required this.menuGroupName,
    required this.menu,
  });

  bool selected = false;
  String? menuGroupName;
  List<LiveeEventMenuListEditModel>? menu;
}
