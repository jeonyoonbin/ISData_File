import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_acrylic/flutter_acrylic.dart';

enum NavigationIndicators { sticky, end }

class AppTheme extends ChangeNotifier {
  // String? _selMultiShop;
  // String? get selMultiShop => _selMultiShop;
  // set selMultiShop(String? value) {
  //   _selMultiShop = value;
  //   notifyListeners();
  // }

  bool? _shopRefresh;
  bool? get ShopRefresh => _shopRefresh;
  set ShopRefresh(bool? value) {
    _shopRefresh = value;
    notifyListeners();
  }

  // 메인메뉴 및에 탭으로 하위 메뉴들 있을때 사용
  bool? _shopRefreshChild;
  bool? get ShopRefreshChild => _shopRefreshChild;
  set ShopRefreshChild(bool? value) {
    _shopRefreshChild = value;
    notifyListeners();
  }

  // static final int SHOPGBN_FOOD = 0;
  // static final int SHOPGBN_SPECIAL = 1;
  // static final int SHOPGBN_FLOWER = 2;
  //
  // //static String currentShopCd = '1';//'15699';//15579';
  //
  // //static int? currentShopGbn = 2; //0: 음식주문, 2:꽃배달
  // //static String? currentShopStatusGbn; //0: 음식주문, 2:꽃배달
  //
  //
  // String? _currentShopCd;
  // String? get currentShopCd => _currentShopCd;
  // set shopCd(String? value) {
  //   _currentShopCd = value;
  //   notifyListeners();
  // }
  //
  // String? _currentShopGbn;
  // String? get currentShopGbn => _currentShopGbn;
  // set shopGbn(String? value) {
  //   _currentShopGbn = value;
  //   notifyListeners();
  // }
  //
  // String? _currentShopStatusGbn;
  // String? get currentShopStatusGbn => _currentShopStatusGbn;
  // set shopStatusGbn(String? value) {
  //   _currentShopStatusGbn = value;
  //   notifyListeners();
  // }

  // fluentUI.AccentColor _color = fluentUI.Colors.blue;//systemAccentColor;
  // fluentUI.AccentColor get color => _color;
  // set color(fluentUI.AccentColor color) {
  //   _color = color;
  //   notifyListeners();
  // }

  // static ScrollController _scrollController = ScrollController();
  // static ScrollController get mainScrollController => _scrollController;

  // ThemeMode _mode = ThemeMode.system;
  // ThemeMode get mode => _mode;
  // set mode(ThemeMode mode) {
  //   _mode = mode;
  //   notifyListeners();
  // }
  //
  // fluentUI.PaneDisplayMode _displayMode = fluentUI.PaneDisplayMode.auto;
  // fluentUI.PaneDisplayMode get displayMode => _displayMode;
  // set displayMode(fluentUI.PaneDisplayMode displayMode) {
  //   //debugPrint('displayMode:${displayMode.toString()}');
  //   _displayMode = displayMode;
  //   notifyListeners();
  // }

  //NavigationIndicators? _indicator = null;//NavigationIndicators.sticky;
  // NavigationIndicators get indicator => _indicator;
  // set indicator(NavigationIndicators indicator) {
  //   _indicator = indicator;
  //   notifyListeners();
  // }

  // WindowEffect _windowEffect = WindowEffect.disabled;
  // WindowEffect get windowEffect => _windowEffect;
  // set windowEffect(WindowEffect windowEffect) {
  //   _windowEffect = windowEffect;
  //   notifyListeners();
  // }

  // void setEffect(WindowEffect effect, BuildContext context) {
  //   Window.setEffect(
  //     effect: effect,
  //     color: [
  //       WindowEffect.solid,
  //       WindowEffect.acrylic,
  //     ].contains(effect)
  //         ? fluentUI.FluentTheme.of(context).micaBackgroundColor.withOpacity(0.05)
  //         : Colors.transparent,
  //     dark: fluentUI.FluentTheme.of(context).brightness.isDark,
  //   );
  // }

  // TextDirection _textDirection = TextDirection.ltr;
  // TextDirection get textDirection => _textDirection;
  // set textDirection(TextDirection direction) {
  //   _textDirection = direction;
  //   notifyListeners();
  // }
  //
  // Locale? _locale;
  // Locale? get locale => _locale;
  // set locale(Locale? locale) {
  //   _locale = locale;
  //   notifyListeners();
  // }

  //List<String>? bannerImageList = [];

  String? _currentShopStatusGbn;
  String? get currentShopStatusGbn => _currentShopStatusGbn;
  set currentShopStatusGbn(String? value) {
    _currentShopStatusGbn = value;

    debugPrint('--- apptheme shopStatus:${_currentShopStatusGbn}');
    notifyListeners();
  }

  String? _loginUserID;
  String? get loginUserID => _loginUserID;
  set loginUserID(String? value) {
    _loginUserID = value;
    notifyListeners();
  }

  // List<String>? _bannerImageList;
  // List<String>? get bannerImageList => _bannerImageList;
  // set bannerImageList(List<String>? imgList) {
  //   _bannerImageList = imgList;
  //   notifyListeners();
  // }

  ButtonStyle? get popupButtonStyleLeft => ButtonStyle(
    minimumSize: MaterialStateProperty.all(const Size(60,70)),
    backgroundColor: const MaterialStatePropertyAll(Color(0xff333333)),
    shape: const MaterialStatePropertyAll(
        RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(12.0))
        )
    ),
  );
  ButtonStyle? get popupButtonStyleRight => ButtonStyle(
    minimumSize: MaterialStateProperty.all(const Size(60,70)),//Size.fromHeight(60),
    backgroundColor: const MaterialStatePropertyAll(Color(0xff01CAFF)),
    shape: const MaterialStatePropertyAll(
        RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomRight: Radius.circular(12.0))//BorderRadius.circular(4.0))
        )
    ),
  );

  ButtonStyle? get popupButtonStyleSingle => ButtonStyle(
    minimumSize: MaterialStateProperty.all(const Size(double.infinity,70)),//Size.fromHeight(60),
    backgroundColor: const MaterialStatePropertyAll(Color(0xff01CAFF)),
    shape: const MaterialStatePropertyAll(
        RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(12.0), bottomRight: Radius.circular(12.0))//BorderRadius.circular(4.0))
        )
    ),
  );

  ButtonStyle? get imageButtonStyleLeft => ButtonStyle(
    minimumSize: MaterialStateProperty.all(const Size(52,20)),
    backgroundColor: const MaterialStatePropertyAll(Color(0xff333333)),
    shape: const MaterialStatePropertyAll(
        RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(6.0))
        )
    ),
  );
  ButtonStyle? get imageButtonStyleRight => ButtonStyle(
    minimumSize: MaterialStateProperty.all(const Size(52,20)),//Size.fromHeight(60),
    backgroundColor: const MaterialStatePropertyAll(Color(0xff01CAFF)),
    shape: const MaterialStatePropertyAll(
        RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomRight: Radius.circular(6.0))//BorderRadius.circular(4.0))
        )
    ),
  );

  RoundedRectangleBorder? get cardShapStyle => RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(4.0),
      side: BorderSide(color: Colors.grey.shade300, width: 1.0,)
  );

  static Decoration? getListBadgeDecoration(Color backgroundColor){
    return BoxDecoration(
      color: backgroundColor,
      border: const Border.symmetric(vertical: BorderSide.none, horizontal: BorderSide.none),
      boxShadow: const [],
      borderRadius: BorderRadius.circular(4),
    );
  }
}

// AccentColor get systemAccentColor {
//   if ((defaultTargetPlatform == TargetPlatform.windows ||
//       defaultTargetPlatform == TargetPlatform.android) &&
//       !kIsWeb) {
//     return AccentColor.swatch({
//       'darkest': SystemTheme.accentColor.darkest,
//       'darker': SystemTheme.accentColor.darker,
//       'dark': SystemTheme.accentColor.dark,
//       'normal': SystemTheme.accentColor.accent,
//       'light': SystemTheme.accentColor.light,
//       'lighter': SystemTheme.accentColor.lighter,
//       'lightest': SystemTheme.accentColor.lightest,
//     });
//   }
//   return Colors.blue;
// }
