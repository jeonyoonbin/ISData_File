# home_widget_example

Demonstrates how to use the home_widget plugin.
