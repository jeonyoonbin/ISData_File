class SelectOptionVO {
  SelectOptionVO({this.value, this.label, this.label2});

  Object value;
  String label;
  String label2;
}