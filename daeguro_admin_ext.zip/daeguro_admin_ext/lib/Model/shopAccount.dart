﻿
class ShopAccount {
  ShopAccount();

  bool selected = false;
  bool viewSelected = false;
  String ccCode;
  String shopCd;
  String shopName;
  String regNo;
  String regNoYn;
  //String telNo;
  //String owner;
  String addr1;
  String addr2;
  String loc; // 03.08 - kjr 상세주소 추가
  String useGbn;
  //String shopId;
  //String shopPwd;
  String openDate;
  String salesmanCode;
  String salesmanName;
  String operatorCode;
  String operatorName;
  String imageStatus;
  String memo;
  String absentYn;
  String calcYn;
  String shopInfoYn;
  String menuYn;
  String deliYn;
  String tipYn;
  String saleYn;
  String basicInfoYn;
  String appOrderYn;
  String isCharged;
  String isPosInstalled;
  String isPosLogined;
  String loginTime;
  String apiComCode;
  String shopImageYn;
  String menuComplete;
  String franchiseCd;
  String reserveYn;
}

