class SearchItems{
  String code = '';
  String name = '';
  String reg_no_yn = '';
  String use_yn = '';
  String app_order_yn = '';
  String pos_yn = '';
  String memo_yn = '';
  String tel = '';
  String ceo = '';
  String address = '';
  String memo = '';
  int useyn = 0;
  String status;
  String img_yn = '';
  // DateTime startdate = DateTime.now();
  // DateTime enddate= DateTime.now();
  String startdate = '';
  String enddate= '';
  String chargeGbn = ' ';
}