
class StatShopOrderCountModel {
  StatShopOrderCountModel();

  String rnum;
  String shop_cd;
  String shop_name;
  String gungu;
  String tot_order_cnt;
  String comp_cnt;
  String cancel_cnt;
}