
class DashBoardWeekOrderModel {
  DashBoardWeekOrderModel();

  String ORDER_DATE;
  int COUNT;
  int COMPLETE_COUNT;
}
