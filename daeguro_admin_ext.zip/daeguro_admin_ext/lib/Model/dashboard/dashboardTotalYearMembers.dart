
class DashBoardTotalYearMembers {
  DashBoardTotalYearMembers();

  String year = '';
  int count = 0;
}
