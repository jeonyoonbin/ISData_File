
class DashBoardTotalOrders {
  DashBoardTotalOrders();

  String status = '';
  int count = 0;
}
