
class DashBoardTotalOs {
  DashBoardTotalOs();

  String device_gbn = '';
  int count = 0;
}
