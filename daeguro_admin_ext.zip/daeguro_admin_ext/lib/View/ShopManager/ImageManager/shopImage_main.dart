
import 'package:daeguro_admin_ext/View/ShopManager/ImageManager/shopImageList.dart';
import 'package:daeguro_admin_ext/View/ShopManager/Account/shopAccountList.dart';
import 'package:daeguro_admin_ext/View/Today/header.dart';
import 'package:daeguro_admin_ext/constants/constant.dart';
import 'package:daeguro_admin_ext/View/Layout/responsive.dart';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ShopImageMain extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //print('AgentAccountMain refresh');

    //Get.put(AgentController());

    return SafeArea(
      child: SingleChildScrollView(
        physics: NeverScrollableScrollPhysics(),
        padding: EdgeInsets.symmetric(horizontal: defaultWidthPadding, vertical: defaultHeightPadding),
        //child: Container(),
        child: Column(
          //mainAxisSize: MainAxisSize.min,
          children: [
            Header(title: "이미지 관리"),
            //SizedBox(height: defaultHeightPadding),
            ShopImageList(),
          ],
        ),
      ),
    );
  }
}