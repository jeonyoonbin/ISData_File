import 'package:daeguro_admin_ext/View/ShopManager/Event/shopEventList.dart';
import 'package:daeguro_admin_ext/View/Today/header.dart';
import 'package:daeguro_admin_ext/constants/constant.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopEventMain extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return SafeArea(
      child: SingleChildScrollView(
        physics: NeverScrollableScrollPhysics(),
        padding: EdgeInsets.symmetric(horizontal: defaultWidthPadding, vertical: defaultHeightPadding),
        //child: Container(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Header(title: "라이브 이벤트 조회"),
            //SizedBox(height: defaultHeightPadding),
            ShopEventList(),
          ],
        ),
      ),
    );
  }
}
