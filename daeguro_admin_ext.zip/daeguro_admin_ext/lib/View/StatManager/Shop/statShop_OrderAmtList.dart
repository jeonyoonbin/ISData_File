import 'dart:convert';
import 'dart:html';

import 'package:daeguro_admin_ext/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_ext/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_ext/ISWidget/search/is_search_date.dart';
import 'package:daeguro_admin_ext/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_ext/ISWidget/search/is_search_input.dart';
import 'package:daeguro_admin_ext/Model/search_items.dart';
import 'package:daeguro_admin_ext/Model/stat/statShopOrderAmtModel.dart';
import 'package:daeguro_admin_ext/Util/select_option_vo.dart';
import 'package:daeguro_admin_ext/Util/utils.dart';
import 'package:daeguro_admin_ext/View/Layout/responsive.dart';
import 'package:daeguro_admin_ext/View/ShopManager/Account/shopAccount_controller.dart';
import 'package:daeguro_admin_ext/View/StatManager/stat_controller.dart';
import 'package:daeguro_admin_ext/constants/constant.dart';
import 'package:daeguro_admin_ext/constants/serverInfo.dart';
import 'package:date_format/date_format.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:get/get.dart';

import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:http/http.dart' as http;

class StatShopAmtCountList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return StatShopAmtCountListState();
  }
}

class DailyDataSource extends DataGridSource {
  DailyDataSource({List<StatShopOrderAmtModel> dailyDataSource}) {
    _data = dailyDataSource.map<DataGridRow>((e) =>
        DataGridRow(cells: [
          DataGridCell<String>(columnName: 'shop_cd', value: e.shop_cd.toString()),
          DataGridCell<String>(columnName: 'shop_name', value: e.shop_name.toString()),
          DataGridCell<String>(columnName: 'gungu', value: e.gungu.toString()),
          DataGridCell<String>(columnName: 'tot_sales_amt', value: Utils.getCashComma(e.tot_sales_amt.toString())),
          DataGridCell<String>(columnName: 'comp_amt', value: Utils.getCashComma(e.comp_amt.toString())),
          DataGridCell<String>(columnName: 'cancel_amt', value: Utils.getCashComma(e.cancel_amt.toString()))
        ])).toList();
  }

  List<DataGridRow> _data = [];

  @override
  List<DataGridRow> get rows => _data;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    Color getRowBackgroundColor() {
      final String gbn = row.getCells()[0].value;
      if (gbn == '합계') {
        return Colors.blue[50];
      } else {
        return null;
      }
      return Colors.transparent;
    }

    TextStyle getRowTextStyle(String value) {
      final String gbn = row.getCells()[0].value;
      if (gbn == '합계') {
        return TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY);
      } else {
        return TextStyle(fontWeight: FontWeight.normal, fontFamily: FONT_FAMILY);
      }
    }

    return DataGridRowAdapter(
        color: getRowBackgroundColor(),
        cells: row.getCells().map<Widget>((dataGridCell) {
          AlignmentGeometry _alignment;
          EdgeInsetsGeometry _margin;
          if (dataGridCell.columnName == 'shop_cd' || dataGridCell.columnName == 'shop_name' || dataGridCell.columnName == 'gungu') {
            _alignment = Alignment.centerLeft;
            _margin = EdgeInsets.fromLTRB(10, 0, 0, 0);
          } else {
            _alignment = Alignment.centerRight;
            _margin = EdgeInsets.fromLTRB(0, 0, 10, 0);
          }

          return Container(
            alignment: _alignment,
            margin: _margin,
            padding: EdgeInsets.all(2.0),
            child: Text(dataGridCell.value.toString(), overflow: TextOverflow.ellipsis, style: (dataGridCell.columnName == 'ORDER_DATE' && dataGridCell.value.toString() == '합계') ? TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY) : getRowTextStyle(dataGridCell.value.toString())),
          );
        }).toList());
  }
}

class StatShopAmtCountListState extends State with AutomaticKeepAliveClientMixin {
  List<StatShopOrderAmtModel> dataList = <StatShopOrderAmtModel>[];
  DailyDataSource _dailyDataSource;

  SearchItems _searchItems = new SearchItems();

  final Map<String, dynamic> sumData = new Map<String, dynamic>();

  List<SelectOptionVO> selectBox_gungu = [
    new SelectOptionVO(value: ' ', label: '전체'),
    new SelectOptionVO(value: '달서구', label: '달서구'),
    new SelectOptionVO(value: '수성구', label: '수성구'),
    new SelectOptionVO(value: '동구', label: '동구'),
    new SelectOptionVO(value: '서구', label: '서구'),
    new SelectOptionVO(value: '남구', label: '남구'),
    new SelectOptionVO(value: '북구', label: '북구'),
    new SelectOptionVO(value: '중구', label: '중구'),
    new SelectOptionVO(value: '달성군', label: '달성군'),
  ];

  List<SelectOptionVO> selectBox_order = [
    new SelectOptionVO(value: ' ', label: '오름차순'),
    new SelectOptionVO(value: 'r', label: '내림차순'),
  ];

  String _gungu = ' ';
  String _order = ' ';
  String _div = '1';

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    _searchItems = null;
    _searchItems = new SearchItems();

    _searchItems.name = '';
    _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
    _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
  }

  _query() {
    StatController.to.fromDate.value = _searchItems.startdate.replaceAll('-', '');
    StatController.to.toDate.value = _searchItems.enddate.replaceAll('-', '');

    loadData();
  }

  loadData() async {
    await ISProgressDialog(context).show(status: 'Loading...');

    await StatController.to.getShopOrderAmtData(_gungu, _order, _div, _searchItems.name, _currentPage.round().toString(), _selectedpagerows.toString()).then((value) {
      dataList.clear();

      if (this.mounted) {
        setState(() {
          value.forEach((element) {
            StatShopOrderAmtModel temp = StatShopOrderAmtModel(); //.fromJson(element);

            temp.rnum = element['rnum'] as String;
            temp.shop_cd = element['shop_cd'] as String;
            temp.shop_name = element['shop_name'] as String;
            temp.gungu = element['gungu'] as String;
            temp.tot_sales_amt = element['tot_sales_amt'] as String;
            temp.comp_amt = element['comp_amt'] as String;
            temp.cancel_amt = element['cancel_amt'] as String;

            dataList.add(temp);
          });

          _totalRowCnt = StatController.to.totalRowCnt;
          _totalPages = (_totalRowCnt / _selectedpagerows).ceil();

          _dailyDataSource = DailyDataSource(dailyDataSource: dataList);
        });
      }
    });

    await ISProgressDialog(context).dismiss();
  }

  @override
  void initState() {
    super.initState();

    Get.put(StatController());
    Get.put(ShopController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      _query();
    });

    setState(() {
      _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
      _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    });
  }

  @override
  void dispose() {
    if (dataList != null) {
      dataList.clear();
      dataList = null;
    }
    _searchItems = null;

    selectBox_gungu.clear();
    selectBox_order.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var buttonBar = Expanded(
      flex: 0,
      child: Row(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Column(
                children: [
                  ISSearchDropdown(
                    label: '군구 구분',
                    width: 120,
                    value: _gungu,
                    item: [
                      DropdownMenuItem(
                        value: ' ',
                        child: Text('전체'),
                      ),
                      DropdownMenuItem(
                        value: '달서구',
                        child: Text('달서구'),
                      ),
                      DropdownMenuItem(
                        value: '수성구',
                        child: Text('수성구'),
                      ),
                      DropdownMenuItem(
                        value: '동구',
                        child: Text('동구'),
                      ),
                      DropdownMenuItem(
                        value: '서구',
                        child: Text('서구'),
                      ),
                      DropdownMenuItem(
                        value: '남구',
                        child: Text('남구'),
                      ),
                      DropdownMenuItem(
                        value: '북구',
                        child: Text('북구'),
                      ),
                      DropdownMenuItem(
                        value: '중구',
                        child: Text('중구'),
                      ),
                      DropdownMenuItem(
                        value: '달성군',
                        child: Text('달성군'),
                      ),
                    ].cast<DropdownMenuItem<String>>(),
                    onChange: (v) {
                      setState(() {
                        _gungu = v;
                      });
                    },
                  ),
                  SizedBox(height: 8),
                  ISSearchSelectDate(
                    context,
                    label: '시작일',
                    width: 120,
                    value: _searchItems.startdate.toString(),
                    onTap: () async {
                      DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.startdate);
                      final DateTime picked = await showDatePicker(
                        context: context,
                        initialDate: valueDt,
                        firstDate: DateTime(1900, 1),
                        lastDate: DateTime(2031, 12),
                      );

                      setState(() {
                        if (picked != null) {
                          _searchItems.startdate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                        }
                      });
                    },
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ISSearchDropdown(
                    label: '가맹점코드 정렬',
                    width: 120,
                    value: _order,
                    item: [
                      DropdownMenuItem(
                        value: ' ',
                        child: Text('오름차순'),
                      ),
                      DropdownMenuItem(
                        value: 'r',
                        child: Text('내림차순'),
                      ),
                    ].cast<DropdownMenuItem<String>>(),
                    onChange: (v) {
                      setState(() {
                        _order = v;
                      });
                    },
                  ),
                  SizedBox(height: 8),
                  ISSearchSelectDate(
                    context,
                    label: '종료일',
                    width: 120,
                    value: _searchItems.enddate.toString(),
                    onTap: () async {
                      DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.enddate);
                      final DateTime picked = await showDatePicker(
                        context: context,
                        initialDate: valueDt,
                        firstDate: DateTime(1900, 1),
                        lastDate: DateTime(2031, 12),
                      );

                      setState(() {
                        if (picked != null) {
                          _searchItems.enddate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                        }
                      });
                    },
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      ISSearchDropdown(
                        label: '검색구분',
                        width: 192,
                        value: _div,
                        item: [
                          DropdownMenuItem(
                            value: '1',
                            child: Text('가맹점코드'),
                          ),
                          DropdownMenuItem(
                            value: '2',
                            child: Text('가맹점명'),
                          ),
                        ].cast<DropdownMenuItem<String>>(),
                        onChange: (v) {
                          setState(() {
                            _div = v;
                          });
                        },
                      ),
                    ],
                  ),
                  SizedBox(height: 8),
                  ISSearchInput(
                    //label: _keyWordLabel,
                    width: 200,
                    value: _searchItems.name,
                    onChange: (v) {
                      _searchItems.name = v;
                    },
                    onFieldSubmitted: (v) {
                      _query();
                    },
                  )
                ],
              ),
              SizedBox(width: 8),
              ISSearchButton(
                label: '조회',
                iconData: Icons.search,
                onPressed: () {
                  _query();
                },
              ),
            ],
          ),
        ],
      ),
    );

    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [Text('※ 주문시간 기준 조회 데이터 입니다.', style: TextStyle(color: Colors.blue[400], fontSize: 12)), Text('※ 총 매출 = 취소(결제대기) 를 제외한 모든 매출', style: TextStyle(color: Colors.blue[400], fontSize: 12))],
              ),
              buttonBar,
            ],
          ),
          Divider(),
          Expanded(
            child: dataList.length == 0
                ? Container()
                : MediaQuery(
                    data: MediaQueryData(textScaleFactor: 1.0),
                    child: SfDataGrid(
                      source: _dailyDataSource,
                      columnWidthMode: ColumnWidthMode.fill,
                      gridLinesVisibility: GridLinesVisibility.vertical,
                      headerGridLinesVisibility: GridLinesVisibility.both,
                      onQueryRowHeight: (details) {
                        if (details.rowIndex == 0 || details.rowIndex == 1) {
                          return 35;
                        }
                        return 35;
                      },
                      columns: <GridColumn>[
                        GridColumn(columnName: 'shop_cd', width: 120, label: Container(color: Colors.blue[50], alignment: Alignment.center, child: Text('가맹점코드', overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.black45, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 11)))),
                        GridColumn(columnName: 'shop_name', width: 350, label: Container(color: Colors.blue[50], alignment: Alignment.center, child: Text('가맹점명', overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.black45, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 11)))),
                        GridColumn(columnName: 'gungu', width: 150, label: Container(color: Colors.blue[50], alignment: Alignment.center, child: Text('군/구', overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.black45, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 11)))),
                        GridColumn(columnName: 'tot_sales_amt', width: 120, label: Container(color: Colors.blue[50], alignment: Alignment.center, child: Text('총 매출', overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.black45, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 11)))),
                        GridColumn(columnName: 'comp_amt', width: 120, label: Container(color: Colors.blue[50], alignment: Alignment.center, child: Text('완료 매출', overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.black45, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 11)))),
                        GridColumn(columnName: 'cancel_amt', width: 120, label: Container(color: Colors.blue[50], alignment: Alignment.center, child: Text('취소 매출', overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.black45, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 11)))),
                      ],
                    ),
                  ),
          ),
          Divider(
            height: 30,
          ),
          showPagerBar(),
        ],
      ), //bottomNavigationBar: showPagerBar(),
    );
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                Container(),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context)
                ? Container(height: 48)
                : Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      //Text('조회 데이터 : ', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL),),
                      //Text(UserController.to.totalRowCnt.toString() + ' / ' + UserController.to.total_count.toString(), style: TextStyle(fontSize: 12, fontWeight: FONT_BOLD),),
                      //SizedBox(width: 20,),
                      Text(
                        '페이지당 행 수 : ',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),
                      ),
                      Container(
                        width: 70,
                        height: 24,
                        decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(5.0)),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton2(
                              value: _selectedpagerows,
                              isExpanded: true,
                              style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: FONT_FAMILY),
                              items: Utils.getPageRowList(),
                              dropdownMaxHeight: 180,
                              itemHeight: 36,
                              itemPadding: const EdgeInsets.only(left: 16, right: 16),
                              dropdownPadding: const EdgeInsets.symmetric(vertical: 6),
                              dropdownDecoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(6),
                              ),
                              onChanged: (value) {
                                setState(() {
                                  _selectedpagerows = value;
                                  _currentPage = 1;
                                  _query();
                                });
                              }),
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
