import 'dart:convert';
import 'dart:html';

import 'package:daeguro_admin_ext/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_ext/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_ext/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_ext/ISWidget/search/is_search_input.dart';
import 'package:daeguro_admin_ext/Model/search_items.dart';
import 'package:daeguro_admin_ext/Model/stat/statShopIntroYnModel.dart';
import 'package:daeguro_admin_ext/Util/select_option_vo.dart';
import 'package:daeguro_admin_ext/Util/utils.dart';
import 'package:daeguro_admin_ext/View/Layout/responsive.dart';
import 'package:daeguro_admin_ext/View/ShopManager/Account/shopAccount_controller.dart';
import 'package:daeguro_admin_ext/View/StatManager/stat_controller.dart';
import 'package:daeguro_admin_ext/constants/constant.dart';
import 'package:daeguro_admin_ext/constants/serverInfo.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:get/get.dart';

import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:http/http.dart' as http;

class StatShopIntroYnList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return StatShopIntroYnListState();
  }
}

class DailyDataSource extends DataGridSource {
  DailyDataSource({List<StatShopIntroYnModel> dailyDataSource}) {
    _data = dailyDataSource
        .map<DataGridRow>((e) => DataGridRow(cells: [
              DataGridCell<String>(columnName: 'shop_cd', value: e.shop_cd.toString()),
              DataGridCell<String>(columnName: 'shop_name', value: e.shop_name.toString()),
              DataGridCell<String>(columnName: 'r_yn', value: e.r_yn.toString()),
              DataGridCell<String>(columnName: 'i_yn', value: e.i_yn.toString()),
            ]))
        .toList();
  }

  List<DataGridRow> _data = [];

  @override
  List<DataGridRow> get rows => _data;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    Color getRowBackgroundColor() {
      final String gbn = row.getCells()[0].value;
      if (gbn == '합계') {
        return Colors.blue[50];
      } else {
        return null;
      }
      return Colors.transparent;
    }

    TextStyle getRowTextStyle(String value) {
      final String gbn = row.getCells()[0].value;
      if (gbn == '합계') {
        return TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY);
      } else {
        return TextStyle(fontWeight: FontWeight.normal, fontFamily: FONT_FAMILY);
      }
    }

    return DataGridRowAdapter(
        color: getRowBackgroundColor(),
        cells: row.getCells().map<Widget>((dataGridCell) {
          AlignmentGeometry _alignment;
          EdgeInsetsGeometry _margin;
          Widget _widget;

          if (dataGridCell.columnName == 'shop_cd' || dataGridCell.columnName == 'shop_name') {
            _alignment = Alignment.centerLeft;
            _margin = EdgeInsets.fromLTRB(10, 0, 0, 0);
          } else {
            _alignment = Alignment.center;
          }

          if (dataGridCell.columnName == 'r_yn' || dataGridCell.columnName == 'i_yn') {
            _widget = dataGridCell.value.toString() == 'Y' ? Icon(Icons.radio_button_unchecked, color: Colors.blue, size: 16) : Icon(Icons.clear, color: Colors.grey.shade400, size: 16);
          } else {
            _widget = Text(dataGridCell.value.toString(), overflow: TextOverflow.ellipsis, style: getRowTextStyle(dataGridCell.value.toString()));
          }

          return Container(
            alignment: _alignment,
            margin: _margin,
            padding: EdgeInsets.all(2.0),
            child: _widget,
          );
        }).toList());
  }
}

class StatShopIntroYnListState extends State with AutomaticKeepAliveClientMixin {
  List<StatShopIntroYnModel> dataList = <StatShopIntroYnModel>[];
  DailyDataSource _dailyDataSource;

  SearchItems _searchItems = new SearchItems();

  final Map<String, dynamic> sumData = new Map<String, dynamic>();

  List<SelectOptionVO> selectBox_order = [
    new SelectOptionVO(value: ' ', label: '오름차순'),
    new SelectOptionVO(value: 'r', label: '내림차순'),
  ];

  String _order = ' ';
  String _div = '1';

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    _searchItems = null;
    _searchItems = new SearchItems();

    _searchItems.name = '';
  }

  _query() {
    loadData();
  }

  loadData() async {
    await ISProgressDialog(context).show(status: 'Loading...');

    await StatController.to.getShopIntroYnData(_order, _div, _searchItems.name, _currentPage.round().toString(), _selectedpagerows.toString()).then((value) {
      dataList.clear();

      if (this.mounted) {
        setState(() {
          value.forEach((element) {
            StatShopIntroYnModel temp = StatShopIntroYnModel(); //.fromJson(element);

            temp.rnum = element['rnum'] as String;
            temp.shop_cd = element['shop_cd'] as String;
            temp.shop_name = element['shop_name'] as String;
            temp.r_yn = element['r_yn'] as String;
            temp.i_yn = element['i_yn'] as String;

            dataList.add(temp);
          });

          _totalRowCnt = StatController.to.totalRowCnt;
          _totalPages = (_totalRowCnt / _selectedpagerows).ceil();

          _dailyDataSource = DailyDataSource(dailyDataSource: dataList);
        });
      }
    });

    await ISProgressDialog(context).dismiss();
  }

  @override
  void initState() {
    super.initState();

    Get.put(StatController());
    Get.put(ShopController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      _query();
    });

    setState(() {});
  }

  @override
  void dispose() {
    if (dataList != null) {
      dataList.clear();
      dataList = null;
    }
    _searchItems = null;

    selectBox_order.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var buttonBar = Expanded(
      flex: 0,
      child: Row(
        children: [
          ISSearchDropdown(
            label: '가맹점코드 정렬',
            width: 120,
            value: _order,
            item: [
              DropdownMenuItem(
                value: ' ',
                child: Text('오름차순'),
              ),
              DropdownMenuItem(
                value: 'r',
                child: Text('내림차순'),
              ),
            ].cast<DropdownMenuItem<String>>(),
            onChange: (v) {
              setState(() {
                _order = v;
              });
            },
          ),
          ISSearchDropdown(
            label: '검색구분',
            width: 192,
            value: _div,
            item: [
              DropdownMenuItem(
                value: '1',
                child: Text('가맹점코드'),
              ),
              DropdownMenuItem(
                value: '2',
                child: Text('가맹점명'),
              ),
            ].cast<DropdownMenuItem<String>>(),
            onChange: (v) {
              setState(() {
                _div = v;
              });
            },
          ),
          ISSearchInput(
            //label: _keyWordLabel,
            width: 200,
            value: _searchItems.name,
            onChange: (v) {
              _searchItems.name = v;
            },
            onFieldSubmitted: (v) {
              _query();
            },
          ),
          ISSearchButton(
            label: '조회',
            iconData: Icons.search,
            onPressed: () {
              _query();
            },
          ),
        ],
      ),
    );

    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('', style: TextStyle(color: Colors.blue[400], fontSize: 12)),
              buttonBar,
            ],
          ),
          Divider(),
          Expanded(
            child: dataList.length == 0
                ? Container()
                : MediaQuery(
                    data: MediaQueryData(textScaleFactor: 1.0),
                    child: SfDataGrid(
                      source: _dailyDataSource,
                      columnWidthMode: ColumnWidthMode.fill,
                      gridLinesVisibility: GridLinesVisibility.vertical,
                      headerGridLinesVisibility: GridLinesVisibility.both,
                      onQueryRowHeight: (details) {
                        if (details.rowIndex == 0 || details.rowIndex == 1) {
                          return 35;
                        }
                        return 35;
                      },
                      columns: <GridColumn>[
                        GridColumn(columnName: 'shop_cd', width: 120, label: Container(color: Colors.blue[50], alignment: Alignment.center, child: Text('가맹점코드', overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.black45, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 11)))),
                        GridColumn(columnName: 'shop_name', width: 350, label: Container(color: Colors.blue[50], alignment: Alignment.center, child: Text('가맹점명', overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.black45, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 11)))),
                        GridColumn(columnName: 'r_yn', width: 100, label: Container(color: Colors.blue[50], alignment: Alignment.center, child: Text('리뷰 안내', overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.black45, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 11)))),
                        GridColumn(columnName: 'i_yn', width: 100, label: Container(color: Colors.blue[50], alignment: Alignment.center, child: Text('사장님 알림', overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: TextStyle(color: Colors.black45, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 11)))),
                      ],
                    ),
                  ),
          ),
          Divider(
            height: 30,
          ),
          showPagerBar(),
        ],
      ), //bottomNavigationBar: showPagerBar(),
    );
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[Container()],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context)
                ? Container(height: 48)
                : Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      //Text('조회 데이터 : ', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL),),
                      //Text(UserController.to.totalRowCnt.toString() + ' / ' + UserController.to.total_count.toString(), style: TextStyle(fontSize: 12, fontWeight: FONT_BOLD),),
                      //SizedBox(width: 20,),
                      Text(
                        '페이지당 행 수 : ',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),
                      ),
                      Container(
                        width: 70,
                        height: 24,
                        decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(5.0)),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton2(
                              value: _selectedpagerows,
                              isExpanded: true,
                              style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: FONT_FAMILY),
                              items: Utils.getPageRowList(),
                              dropdownMaxHeight: 180,
                              itemHeight: 36,
                              itemPadding: const EdgeInsets.only(left: 16, right: 16),
                              dropdownPadding: const EdgeInsets.symmetric(vertical: 6),
                              dropdownDecoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(6),
                              ),
                              onChanged: (value) {
                                setState(() {
                                  _selectedpagerows = value;
                                  _currentPage = 1;
                                  _query();
                                });
                              }),
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
