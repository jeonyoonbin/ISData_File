import 'package:daeguro_admin_ext/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_ext/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_ext/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_ext/ISWidget/search/is_search_date.dart';
import 'package:daeguro_admin_ext/Model/businessMenuItem.dart';
import 'package:daeguro_admin_ext/Model/search_items.dart';
import 'package:daeguro_admin_ext/Model/stat/statCustomerRankOrderModel.dart';
import 'package:daeguro_admin_ext/Util/utils.dart';
import 'package:daeguro_admin_ext/View/ShopManager/Account/shopAccount_controller.dart';
import 'package:daeguro_admin_ext/View/StatManager/stat_controller.dart';
import 'package:daeguro_admin_ext/constants/constant.dart';

import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:horizontal_data_table/horizontal_data_table.dart';

class StatCustomerRankOrderList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return StatCustomerRankOrderListState();
  }
}

class StatCustomerRankOrderListState extends State with AutomaticKeepAliveClientMixin{
  List<StatCustomerRankOrderModel> dataList = <StatCustomerRankOrderModel>[];

  List<String> rightColumnTitle = [];
  List<BusinessMenuItem> leftColumnList = [];

  SearchItems _searchItems = new SearchItems();

  final double left_ColumnWidth = 130;
  final double right_ColumnWidth = 120;
  final double ColumnHeight = 30;

  final ScrollController _scrollHorizontalController = ScrollController();

  int listDummyMaxSize = 1;

  _reset() {
    _searchItems = null;
    _searchItems = new SearchItems();

    _searchItems.startdate = formatDate(DateTime.now(), ['2021-08-09']);
    _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
  }

  _query() {
    StatController.to.fromDate.value = _searchItems.startdate.replaceAll('-', '');
    StatController.to.toDate.value = _searchItems.enddate.replaceAll('-', '');

    loadData();
  }

  loadData() async {
    await ISProgressDialog(context).show(status: 'Loading...');

    if (rightColumnTitle != null) rightColumnTitle.clear();
    if (dataList != null) dataList.clear();

    if (leftColumnList != null) leftColumnList.clear();

    await StatController.to.getCustomerRankOrderData().then((value) {
      if (this.mounted) {
        if (value == null) {
          ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
        }
        else {
          setState(() {
            //rightColumnTitle.add('합계');

            rightColumnTitle.add('ORDER_COUNT');
            rightColumnTitle.add('CUST_NAME');
            rightColumnTitle.add('TELNO');

            int index = 0;
            value.forEach((element) {
              StatCustomerRankOrderModel temp = StatCustomerRankOrderModel();//.fromJson(element);

              temp.ORDER_COUNT = element['ORDER_COUNT'] as int;
              temp.CUST_NAME = element['CUST_NAME'] as String;
              temp.TELNO = element['TELNO'] as String;

              //print('dataList temp.ITEM_CD: '+temp.ITEM_CD.toString());
              // if (temp.ITEM_CD == null || temp.ITEM_CD == 'null')
              //   temp.ITEM_CD = '합계';

              dataList.add(temp);

              leftColumnList.add(new BusinessMenuItem(title: (index+1).toString(), isOpened: false));
              index++;
            });

            if (listDummyMaxSize > rightColumnTitle.length) {
              int dummyCount = listDummyMaxSize - rightColumnTitle.length;
              for (int i = 0; i < dummyCount; i++) {
                rightColumnTitle.add('');
              }
            }
          });
        }
      }
    });

    await ISProgressDialog(context).dismiss();
  }

  String getHeaderTitle(String title){
    String tempStr = '';

    if (title == '합계')
      return '합계';

    if (title == 'ORDER_COUNT')      tempStr = '주문실적';
    if (title == 'CUST_NAME')        tempStr = '이름';
    if (title == 'TELNO')            tempStr = '휴대번호';

    return tempStr;
  }

  @override
  void initState() {
    super.initState();

    Get.put(StatController());
    Get.put(ShopController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      _query();
      _scrollHorizontalController.jumpTo(100.0);
    });

    setState(() {
      _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
      _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    });
  }

  @override
  void dispose() {
    if (dataList != null){
      dataList.clear();
      dataList = null;
    }

    if (rightColumnTitle != null){
      rightColumnTitle.clear();
      rightColumnTitle = null;
    }

    if (leftColumnList != null){
      leftColumnList.clear();
      leftColumnList = null;
    }


    if (_scrollHorizontalController != null)
      _scrollHorizontalController.dispose();

    _searchItems = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var buttonBar = Expanded(
      flex: 0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          ISSearchSelectDate(
            context,
            label: '시작일',
            width: 120,
            value: _searchItems.startdate.toString(),
            onTap: () async {
              DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.startdate);
              final DateTime picked = await showDatePicker(
                context: context,
                initialDate: valueDt,
                firstDate: DateTime(1900, 1),
                lastDate: DateTime(2031, 12),
              );

              setState(() {
                if (picked != null) {
                  _searchItems.startdate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                }
              });
            },
          ),
          ISSearchSelectDate(
            context,
            label: '종료일',
            width: 120,
            value: _searchItems.enddate.toString(),
            onTap: () async {
              DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.enddate);
              final DateTime picked = await showDatePicker(
                context: context,
                initialDate: valueDt,
                firstDate: DateTime(1900, 1),
                lastDate: DateTime(2031, 12),
              );

              setState(() {
                if (picked != null) {
                  _searchItems.enddate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                }
              });
            },
          ),
          SizedBox(width: 8,),
          ISSearchButton(
            label: '조회',
            iconData: Icons.search,
            onPressed: () {
              _query();
            },
          ),
        ],
      ),
    );

    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(height: 10,),
          buttonBar,
          Divider(),
          Expanded(
            //height: MediaQuery.of(context).size.height - 286,
            //padding: const EdgeInsets.only(top: 10.0),
            //height: 400,
            child: HorizontalDataTable(
              leftHandSideColumnWidth: left_ColumnWidth,
              rightHandSideColumnWidth: (rightColumnTitle.length * right_ColumnWidth),
              isFixedHeader: true,
              headerWidgets: getTitleWidget(),
              leftSideItemBuilder: generateLeftSideColumn,
              rightSideItemBuilder: generateRightSideColumn,
              itemCount: leftColumnList.length,
              rowSeparatorWidget: const Divider(color: Colors.black12, height: 1.0, thickness: 0.0),
              leftHandSideColBackgroundColor: Color(0xffffff),
              rightHandSideColBackgroundColor: Color(0xffffff),
              verticalScrollbarStyle: const ScrollbarStyle(thumbColor: Colors.black12, isAlwaysShown: false, thickness: 8.0, radius: Radius.circular(5.0)),
              horizontalScrollbarStyle: const ScrollbarStyle(thumbColor: Colors.black12, isAlwaysShown: true, thickness: 8.0, radius: Radius.circular(5.0)),
              enablePullToRefresh: false,
              horizontalScrollController: _scrollHorizontalController,
            ),
          ),
          Divider(height: 20,),
          SizedBox(height: 30,)
        ],
      ),
    );
  }

  List<Widget> getTitleWidget() {
    List<Widget> tempWidget = [];

    tempWidget.add(Container(
        color: MaterialStateColor.resolveWith((states) => Colors.blue[50]),
        width: left_ColumnWidth,
        height: ColumnHeight,
        alignment: Alignment.center,
        child: Align(
            child: Text('구분', style: TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54, fontSize: 14), textAlign: TextAlign.center), alignment: Alignment.center))
    );

    rightColumnTitle.forEach((element) {
      tempWidget.add(Container(
          color: MaterialStateColor.resolveWith((states) => Colors.blue[50]),
          width: right_ColumnWidth,
          height: ColumnHeight,
          alignment: Alignment.center,
          child: Text(getHeaderTitle(element), style: TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54, fontSize: 14,), textAlign: TextAlign.center,))
      );
    });

    return tempWidget;
  }

  Widget generateLeftSideColumn(BuildContext context, int index) {
    return Container(
      width: left_ColumnWidth,
      height: ColumnHeight,
      alignment: Alignment.center,
      padding: EdgeInsets.symmetric(horizontal: 16.0),
      color: leftColumnList[index].title.toString() == '합계' ? MaterialStateColor.resolveWith((states) => Colors.blue[50]) : Colors.transparent,
      child: Text(leftColumnList[index].title.toString(), style: TextStyle(color: Colors.black,
          fontWeight: leftColumnList[index].title.toString() == '합계' ? FONT_BOLD : FONT_NORMAL,
          fontFamily: FONT_FAMILY_ROBOTO, fontSize: leftColumnList[index].isChildItem == true ? 12 : 14),
      ),
    );
  }

  Widget generateRightSideColumn(BuildContext context, int index) {
    List<Widget> tempWidget = [];

    rightColumnTitle.forEach((headerElement) {
      String compareTitle = leftColumnList[index].title.toString();
      String value = '';

      if (compareTitle.toString() == '합계')
        compareTitle = 'null';

      if (headerElement == 'ORDER_COUNT')            value = dataList[index].ORDER_COUNT.toString();
      else if (headerElement == 'CUST_NAME')         value = dataList[index].CUST_NAME.toString();
      else if (headerElement == 'TELNO')             value = Utils.getPhoneNumFormat(dataList[index].TELNO.toString(), true);
      else                                           value ='';

      tempWidget.add(getValueWidget(index, value, headerElement.toString()));
    });

    return Row(
      children: tempWidget,
    );
  }

  Widget getValueWidget(int index, String value, String headerTitle){
    double fontSize = 14.0;
    FontWeight fontWeight = FONT_NORMAL;

    if (leftColumnList[index].title.toString() == '합계' || headerTitle == '합계')
      fontWeight = FONT_BOLD;

    if (leftColumnList[index].isChildItem == true)
      fontSize = 12.0;

    if (headerTitle == '')
      value = '';

    return  Container(
      width: right_ColumnWidth,
      height: ColumnHeight,
      alignment: Alignment.center,
      color: leftColumnList[index].title.toString() == '합계' ? MaterialStateColor.resolveWith((states) => Colors.blue[50]) : Colors.transparent,
      child: Text(value, style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontFamily: headerTitle == 'CUST_NAME' ? FONT_FAMILY : FONT_FAMILY_ROBOTO, fontSize: fontSize),),
    );
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;

}
