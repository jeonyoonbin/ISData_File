﻿import 'package:daeguro_admin_ext/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_ext/Provider/RestApiProvider.dart';
import 'package:daeguro_admin_ext/constants/serverInfo.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class CouponController extends GetxController with SingleGetTickerProviderMixin {
  static CouponController get to => Get.find();
  BuildContext context;

  //List<dynamic> qData = [];
  List<dynamic> qDataDetail = [];

  //List<dynamic> qB2BData = [];
  //List<dynamic> qB2BDataDetail = [];


  //List qB2BDataItems = [];
  //List qB2BCodeItems = [];

  //List qBrandListItems = [];
  //List qBrandCouponListItems = [];

  int totalRowCnt = 0;
  int pub = 0;
  int giv = 0;
  int use = 0;
  int del = 0;

  String totalHistoryCnt = '0';
  String totalB2BHistoryCnt = '0';

  // RxString couponType = 'IS_C100'.obs;
  // RxString couponB2BType = 'B2B_C100'.obs;
  // RxString couponStatus = '00'.obs;
  // RxString couponB2BStatus = '00'.obs;
  RxString divKey = ''.obs;
  RxString keyword = ''.obs;
  RxInt raw = 0.obs;
  RxInt page = 0.obs;
  RxString fromDate = ''.obs;
  RxString toDate = ''.obs;

  @override
  void onInit() {
    Get.put(RestApiProvider());

    raw.value = 15;
    page.value = 1;

    //getData(context);

    super.onInit();
  }

  Future<List> getDataCodeItems(String systemGbn, String pubGbn, String testYn, BuildContext context) async {
    List qDataItems = [];

    final result = await Dio().get(ServerInfo.REST_URL_COUPON_CODE_R + '?systemGbn=$systemGbn&pubGbn=$pubGbn&testYn=$testYn');

    if (result.data['code'] == '00')
      qDataItems.assignAll(result.data['data']);
    else
      return null;

    return qDataItems;
  }

}
