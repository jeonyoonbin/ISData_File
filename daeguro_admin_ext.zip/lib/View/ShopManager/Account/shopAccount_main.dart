
import 'package:daeguro_admin_ext/View/ShopManager/Account/shopAccountList.dart';
import 'package:daeguro_admin_ext/View/Today/header.dart';
import 'package:daeguro_admin_ext/constants/constant.dart';
import 'package:daeguro_admin_ext/View/Layout/responsive.dart';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopAccountMain extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return SafeArea(
      child: SingleChildScrollView(
        physics: NeverScrollableScrollPhysics(),
        padding: EdgeInsets.symmetric(horizontal: defaultWidthPadding, vertical: defaultHeightPadding),
        //child: Container(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Header(title: "가맹점 관리"),
            //SizedBox(height: defaultHeightPadding),
            ShopAccountList(),
          ],
        ),
      ),
    );
  }
}