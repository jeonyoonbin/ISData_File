import 'package:flutter/material.dart';

const primaryColor = Color(0xFF2697FF);
const secondaryColor = Color(0xFF2A2D3E);
const bgColor = Color(0xFF212332);

const defaultWidthPadding = 10.0;//32.0;
const defaultHeightPadding = 16.0;
const defaultAllPadding = 16.0;
const defaultContentsHeight = 178;//194;

const sidebarWidth = 220.0;//240.0
