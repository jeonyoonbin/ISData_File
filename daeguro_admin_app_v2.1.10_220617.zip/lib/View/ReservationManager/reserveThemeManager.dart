import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/is_tableInput.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveThemeListModel.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveThemeMainDetailModel.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveThemeShopListModel.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveThemeSubDetailModel.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveThemeSubModel.dart';
import 'package:daeguro_admin_app/Network/FileUpLoader.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/PostCode/postCodeRequest.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reservationmanager_controller.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reserveThemeHistory.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reserveThemeRegist.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reserveThemeShopAdd.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccount_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';

import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

import 'dart:async';
import 'package:kopo/kopo.dart';

import 'package:flutter/foundation.dart' show kIsWeb;

import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

class ReserveThemeManager extends StatefulWidget {
  const ReserveThemeManager({Key key})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ReserveThemeManagerState();
  }
}

enum RadioUseGbn { gbn1, gbn2 }
enum RadioAppMainVisible { gbn1, gbn2 }
enum RadioGunguUseGbn { gbn1, gbn2 }

class ReserveThemeManagerState extends State<ReserveThemeManager>  with SingleTickerProviderStateMixin{
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<ReserveThemeListModel> dataList = <ReserveThemeListModel>[];

  final List<ReserveThemeShopListModel> dataShopList = <ReserveThemeShopListModel>[];

  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  List<SelectOptionVO> selectBox_Sido = [];
  List<SelectOptionVO> selectBox_Gungu = [];

  List<SelectOptionVO> selectBox_ShopSearchType = [];

  List items = List();

  List<SelectOptionVO> selectBox_piditem = [];

  String _shopJobGbn = '1';
  String _shopSearchKeyword = '';

  String _selectedComment = '';
  String _selectedCode = '';
  int _selectedSubCode = 0;

  RadioUseGbn _radioUseGbn;
  RadioAppMainVisible _radioAppMainVisible;
  RadioGunguUseGbn _radioGunguUseGbn;

  String _themeName = '';
  String _themeMemo = '';
  String _themeAddress = '';
  String _themeX = '';
  String _themeY = '';

  String _themeSido;
  String _themeGungu;
  String _themeImageURL = '';
  String _themeImageRealURL = '';

  
  bool _isMainTheme = true;

  _reset() {
    dataList.clear();

    _selectedComment = '테마를 선택해주세요.';

    //_themeImageURL = '저장된 파일이 없습니다.';

    selectBox_Sido.add(new SelectOptionVO(value: '대구광역시', label: '대구광역시'));

    selectBox_ShopSearchType.add(new SelectOptionVO(value: '1', label: '가맹점명'));
    selectBox_ShopSearchType.add(new SelectOptionVO(value: '2', label: '사업자번호'));
    selectBox_ShopSearchType.add(new SelectOptionVO(value: '3', label: '주소'));

    _themeSido = '대구광역시';

    loadGunguData(_themeSido);
  }

  _query() {
    ReservationController.to.page.value = _currentPage.round().toString();
    ReservationController.to.raw.value = _selectedpagerows.toString();

    loadThemeShopList();
  }

  void _pageMove(int _page) {
    _query();
  }

  loadGunguData(String sido) async {

    selectBox_Gungu.clear();

    await ShopController.to.getGunguData(sido).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        int idx = 0;
        value.forEach((element) async {

          selectBox_Gungu.add(new SelectOptionVO(value: element['gunGuName'], label: element['gunGuName']));

          if (idx == 0) {
            _themeGungu = element['gunGuName'];
          }

          idx++;
        });
      }
    });

    setState(() {});
  }

  loadThemeShopList() async {
    dataShopList.clear();

    await ReservationController.to.getReserveThemeShopList(_shopJobGbn,  _selectedCode, _selectedSubCode, _shopSearchKeyword).then((value) {
      if(value == null){
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        value.forEach((e) {
          ReserveThemeShopListModel temp = ReserveThemeShopListModel.fromJson(e);
          dataShopList.add(temp);
        });

        int _totalRowCnt = ReservationController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
      }
    });

    setState(() {

    });
  }

  loadMainThemeListData() async {
    dataList.clear();

    await ReservationController.to.getReserveMainThemeList().then((value) {
      if(value == null){
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        value.forEach((e) {
          ReserveThemeListModel temp = ReserveThemeListModel.fromJson(e);
          dataList.add(temp);
        });
      }
    });

    setState(() {

    });
  }

  loadMainThemeDetail(String code) async {
    _themeAddress = '';
    _themeImageURL = '';
    _themeImageRealURL = '';

    await ReservationController.to.getReserveMainThemeDetail(code).then((value) {
      if(value == null){
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        _themeName = value['nameMain'];
        _themeMemo = value['name'];
        _themeAddress = value['addr'];

        (value['url'] == null || value['url'] == '') ? _themeImageRealURL = '' : _themeImageRealURL = value['url'].toString();

        if (_themeImageRealURL != ''){
          List<String> sTemp = _themeImageRealURL.split('/');
          _themeImageURL = sTemp[sTemp.length-1];
        }

        value['useGbn'] == 'Y' ? _radioUseGbn = RadioUseGbn.gbn1 : _radioUseGbn = RadioUseGbn.gbn2;
        value['mainVisibleGbn'] == 'Y' ? _radioAppMainVisible = RadioAppMainVisible.gbn1 : _radioAppMainVisible = RadioAppMainVisible.gbn2;
        value['gunguUseGbn'] == 'Y' ? _radioGunguUseGbn = RadioGunguUseGbn.gbn1 : _radioGunguUseGbn = RadioGunguUseGbn.gbn2;
      }
    });

    setState(() {

    });
  }

  loadSubThemeDetail(String code, int subCode) async {
    _themeAddress = '';
    _themeImageURL = '';
    _themeImageRealURL = '';

    await ReservationController.to.getReserveSubThemeDetail(code, subCode).then((value) {
      if(value == null){
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        _themeName = value['temaName'];
        _themeMemo = value['temaMemo'];
        _themeAddress = value['addr'];
        _themeGungu = value['gungu'];

        (value['url'] == null || value['url'] == '') ? _themeImageRealURL = '' : _themeImageRealURL = value['url'].toString();

        if (_themeImageRealURL != ''){
          List<String> sTemp = _themeImageRealURL.split('/');
          _themeImageURL = sTemp[sTemp.length-1];
        }

        value['useGbn'] == 'Y' ? _radioUseGbn = RadioUseGbn.gbn1 : _radioUseGbn = RadioUseGbn.gbn2;
      }
    });

    setState(() {

    });
  }

  addSubThemeData(String code) async {
    List<ReserveThemeListModel> tempMainThemeList = <ReserveThemeListModel>[];

    await ReservationController.to.getReserveSubThemeList(code).then((value) {
      value.forEach((element) {
        ReserveThemeSubModel subThemeItem = ReserveThemeSubModel.fromJson(element);

        int compareIndex = dataList.indexWhere((item) => item.code == subThemeItem.temaCode);
        if (compareIndex != -1){
          ReserveThemeListModel listItem = ReserveThemeListModel();
          listItem.isChild = true;
          listItem.code = subThemeItem.temaCode;
          listItem.subcode = subThemeItem.subTemaCode;
          listItem.nameMain = subThemeItem.gungu != '' ? '[${subThemeItem.gungu}] ${subThemeItem.temaName}' : subThemeItem.temaName;

          tempMainThemeList.add(listItem);
        }
      });

      tempMainThemeList = List.from(tempMainThemeList.reversed);

      int selectindex = dataList.indexWhere((item) => item.code.toString() == code);
      tempMainThemeList.forEach((element) {
        if (element.code != null) dataList.insert(selectindex + 1, element);
      });

    });

    setState(() {
    });
  }

  removeSubThemeData(String code) {
    setState(() {
      dataList.removeWhere((item) => (item.code == code && item.isChild == true));
    });
  }

  _regist() async {
    List<SelectOptionVO> tempMainThemeList = List();

    dataList.forEach((element) {
        if (element.isChild == false)
          tempMainThemeList.add(new SelectOptionVO(value: element.code, label: '[${element.code}] ${element.nameMain}'));
    });

    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: ReserveThemeRegist(selectBox_mainTheme: tempMainThemeList),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 500), () {
          _selectedComment = '테마를 선택해주세요.';
          _selectedCode = '';

          loadMainThemeListData();
        });
      }
    });
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());
    Get.put(ReservationController());

    _selectedComment = '테마를 선택해주세요.';
    _selectedCode = '';

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      loadMainThemeListData();
      //_query();
    });
  }

  @override
  void dispose() {
    dataList.clear();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //testSearchBox(),
        ],
      ),
    );

    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          form,
          Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 360,//getListMainPanelWidth(),
                height: (MediaQuery.of(context).size.height-100),
                padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                  color: Colors.white,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                            padding: EdgeInsets.only(left: 10),
                            child: Text('테마목록', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),)
                        ),
                        Container(
                          alignment: Alignment.centerRight,
                          padding: EdgeInsets.symmetric(vertical: 2),
                          child: ISButton(
                              label: '테마 추가',
                              iconColor: Colors.white,
                              textStyle: TextStyle(color: Colors.white),
                              iconData: Icons.save,
                              onPressed: () async {
                                _regist();
                              }
                          ),
                        ),
                      ],
                    ),
                    Divider(),
                    ISDatatable(
                      controller: ScrollController(),
                      headingRowHeight: 0.01,
                      dividerThickness: 0.01,
                      viewScrollAxis: Axis.vertical,
                      panelHeight: (MediaQuery.of(context).size.height-175),
                      listWidth: 400,
                      dataRowHeight: 30,
                      rows: getDataRow(),
                      columns: getDataColumn(),
                    )
                  ],
                ),
              ),
              //Divider(height: 1000,),
              getDetailData(),
            ],
          ),
        ],
      ),
    );
  }

  List<DataRow> getDataRow() {
    List<DataRow> tempData = [];

    dataList.forEach((element) {
      double fontSize = 14.0;

      if (element.isChild == true) fontSize = 12.0;

      tempData.add(
          DataRow(
              selected: element.selected ?? false,
              color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
                if (element.selected == true) {
                  return Colors.grey.shade200;
                  //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
                }

                return Theme.of(context).colorScheme.primary.withOpacity(0.00);
              }),
              onSelectChanged: (bool value){
                dataList.forEach((element) {
                  element.selected = false;
                });

                element.selected = true;

                //print('selected: mainCd[${element.code}]${element.nameMain} - subCd[${element.subcode}]');

                if (element.subcode == '' || element.subcode == null) {
                  _isMainTheme = true;
                  loadMainThemeDetail(element.code);
                }
                else {
                  _isMainTheme = false;
                  loadSubThemeDetail(element.code, element.subcode);
                }

                _selectedCode = element.code;
                _selectedSubCode = element.subcode;

                //loadThemeShopList();
                _currentPage = 1;
                _query();

                setState(() {

                });
              },
              cells: [
                  DataCell(Align(
                      alignment: Alignment.centerLeft,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          (element.isChild == true) ? Container(width: 30,)
                          : InkWell(
                            child: Icon(element.isOpened == true ? Icons.remove_circle : Icons.add_circle, color: Colors.blue, size: 20),
                            onTap: () {
                              if (element.isOpened == true) {
                                element.isOpened = false;
                                removeSubThemeData(element.code);
                              }
                              else {
                                element.isOpened = true;
                                addSubThemeData(element.code);
                              }
                            },
                          ),
                          (element.isChild == true) ? Icon(Icons.folder, color: Colors.blue, size: 20) : Container(),
                          SizedBox(width: 10,),
                          Align(child:
                                Container(
                                    padding: EdgeInsets.only(bottom: 2),
                                    child: Text(element.nameMain.toString(), style: TextStyle(color: Colors.black, fontSize: fontSize),)
                                ), alignment: element.isChild == true ? Alignment.centerLeft : Alignment.center)
                        ],
                      ),
                    )
                  ),
              ]
          )
      );
    });

    return tempData;
  }

  List<DataColumn> getDataColumn() {
    List<DataColumn> tempData = [];

    tempData.add(DataColumn(
      label: Expanded(child: Text('', textAlign: TextAlign.center)),
    ));

    return tempData;
  }

  Widget getDetailData(){
    return Container(
      width: getListMainPanelWidth(),
      height: (MediaQuery.of(context).size.height-100),
      padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
        ],
      ),
      child: Column(
        //mainAxisAlignment: MainAxisAlignment.spaceBetween,

        children: [
          Container(
            height: MediaQuery.of(context).size.height - 116,
            alignment: Alignment.center,
            child: _selectedCode == '' ?  Text(_selectedComment, style: TextStyle(color: Colors.black45),)
          : Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 25),// .all(25),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Text('테마 정보', style: TextStyle(fontSize: 20)),
                              ],
                            ),
                            Row(
                              children: [
                                ISButton(
                                  label: '수정',
                                  iconColor: Colors.white,
                                  textStyle: TextStyle(color: Colors.white),
                                  onPressed: () {
                                    if (_themeImageURL == ''){
                                      ISAlert(context, '테마이미지는 필수등록 사항입니다.\n\n 확인 후, 다시 시도해주세요.');
                                      return;
                                    }


                                    ISConfirm(context, _isMainTheme == true ? '메인테마 수정' : '서브테마 수정', '테마를 수정 하시겠습니까?', (context) async {
                                      if (_isMainTheme == true){
                                        String tempUseGbn = _radioUseGbn == RadioUseGbn.gbn1 ? 'Y' : 'N';
                                        String tempAppMainVisible = _radioAppMainVisible == RadioAppMainVisible.gbn1 ? 'Y' : 'N';
                                        String tempGunguUseGbn = _radioGunguUseGbn == RadioGunguUseGbn.gbn1 ? 'Y' : 'N';

                                        ReserveThemeMainDetailModel formData = ReserveThemeMainDetailModel();
                                        formData.mainName = _themeName;
                                        formData.name = _themeMemo;
                                        formData.useGbn = tempUseGbn;
                                        formData.mainVisibleGbn = tempAppMainVisible;
                                        formData.gunguUseGbn = tempGunguUseGbn;

                                        ReservationController.to.putReserMainTheme(_selectedCode, formData.toJson(), context).then((value) {
                                          if (value != null){
                                            ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                          }
                                          else{
                                            loadMainThemeListData();

                                            _isMainTheme = true;
                                            loadMainThemeDetail(_selectedCode);

                                            Navigator.pop(context);
                                          }
                                        });
                                      }
                                      else{
                                        String tempUseGbn = _radioUseGbn == RadioUseGbn.gbn1 ? 'Y' : 'N';

                                        ReserveThemeSubDetailModel formData = ReserveThemeSubDetailModel();
                                        formData.temaName = _themeName;
                                        formData.sido = _themeSido;
                                        formData.gungu = _themeGungu;
                                        formData.temaMemo = _themeMemo;
                                        formData.useGbn = tempUseGbn;
                                        formData.lon = _themeX;
                                        formData.lat = _themeY;
                                        formData.addr = _themeAddress;

                                        ReservationController.to.putReserSubTheme(_selectedCode, _selectedSubCode, formData.toJson(), context).then((value) {
                                          if (value != null){
                                            ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                          }
                                          else{
                                            loadMainThemeListData();

                                            _isMainTheme = false;
                                            loadSubThemeDetail(_selectedCode, _selectedSubCode);

                                            Navigator.pop(context);
                                          }
                                        });
                                      }
                                    });
                                  },
                                ),
                                SizedBox(width: 10,),
                                ISButton(
                                  label: '삭제',
                                  iconColor: Colors.white,
                                  textStyle: TextStyle(color: Colors.white),
                                  onPressed: () {
                                    ISConfirm(context, _isMainTheme == true ? '메인테마 삭제' : '서브테마 삭제', '테마를 삭제 하시겠습니까?', (context) async {
                                      if (_isMainTheme == true){
                                        ReservationController.to.deleteMainTheme(_selectedCode).then((value) {
                                          if (value != null){
                                            ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                          }
                                          else{
                                            _selectedComment = '테마를 선택해주세요.';
                                            _selectedCode = '';

                                            loadMainThemeListData();

                                            Navigator.pop(context);
                                            //Navigator.pop(context, true);
                                          }
                                        });
                                      }
                                      else{
                                        ReservationController.to.deleteSubTheme(_selectedCode, _selectedSubCode).then((value) {
                                          if (value != null){
                                            ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                          }
                                          else{
                                            _selectedComment = '테마를 선택해주세요.';
                                            _selectedCode = '';

                                            loadMainThemeListData();

                                            Navigator.pop(context);
                                            //Navigator.pop(context, true);
                                          }
                                        });
                                      }
                                    });
                                  },
                                ),
                                SizedBox(width: 10,),
                                ISButton(
                                  label: '변경이력',
                                  iconColor: Colors.white,
                                  textStyle: TextStyle(color: Colors.white),
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      builder: (BuildContext context) => Dialog(
                                        child: ReserveThemeHistory(isMainTheme: _isMainTheme, code: _selectedCode, subCode: _selectedSubCode),
                                      ),
                                    ).then((v) async {});
                                  },
                                )
                              ],
                            ),
                          ],
                        ),
                        SizedBox(height: 10,),
                        Table(
                          columnWidths: const {0: FixedColumnWidth(170), 1: FlexColumnWidth(),},
                          defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                          //border: TableBorder.all(width: 0.8, color: Colors.black),
                          border: TableBorder.symmetric(inside: BorderSide(width: 0.1, color: Colors.black), outside: BorderSide(width: 1.2, color: Colors.black12)),
                          // border: TableBorder(
                          //     horizontalInside: BorderSide(color: Colors.black, width: 0.2),
                          //     verticalInside: BorderSide(color: Colors.black),
                          //     top: BorderSide(color: Colors.black),
                          //     bottom: BorderSide(color: Colors.black),
                          //     left: BorderSide(color: Colors.black),
                          //     right: BorderSide(color: Colors.black),
                          //
                          // ),
                          children: [
                            TableRow(children: [
                              Container(
                                  color: Colors.blue[50],
                                  height: 44,
                                  alignment: Alignment.center,
                                  child: Text('테마명')
                              ),
                              Container(
                                color: Colors.white,
                                child: ISTableInput(
                                  height: 30,
                                  value: _themeName,//formData.bussCon ?? '',
                                  //label: '업태',
                                  textStyle: TextStyle(fontSize: 12),
                                  onChange: (v) {
                                    _themeName = v;
                                    setState(() {

                                    });
                                  },
                                ),
                              ),
                            ]),
                            TableRow(children: [
                              Container(
                                  color: Colors.blue[50],
                                  height: 38,
                                  alignment: Alignment.center,
                                  child: Text('사용여부')
                              ),
                              Container(
                                color: Colors.white,
                                height: 30,
                                padding: EdgeInsets.symmetric(horizontal: 16),
                                child: Row(
                                  children: [
                                    Radio(
                                        value: RadioUseGbn.gbn1,
                                        groupValue: _radioUseGbn,
                                        onChanged: (v) async {
                                          _radioUseGbn = v;

                                          setState(() {

                                          });
                                        }),
                                    Text('사용', style: TextStyle(fontSize: 12)),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                      child: Radio(
                                          value: RadioUseGbn.gbn2,
                                          groupValue: _radioUseGbn,
                                          onChanged: (v) async {
                                            _radioUseGbn = v;

                                            setState(() {

                                            });
                                          }),
                                    ),
                                    Text('미사용', style: TextStyle(fontSize: 12)),
                                  ],
                                ),
                              ),
                            ]),
                            _isMainTheme == true ?
                            TableRow(children: [
                              Container(
                                  color: Colors.blue[50],
                                  height: 38,
                                  alignment: Alignment.center,
                                  child: Text('군구필터보임여부')
                              ),
                              Container(
                                color: Colors.white,
                                height: 30,
                                padding: EdgeInsets.symmetric(horizontal: 16),
                                child: Row(
                                  children: [
                                    Radio(
                                        value: RadioGunguUseGbn.gbn1,
                                        groupValue: _radioGunguUseGbn,
                                        onChanged: (v) async {
                                          _radioGunguUseGbn = v;

                                          setState(() {

                                          });
                                        }),
                                    Text('사용', style: TextStyle(fontSize: 12)),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                      child: Radio(
                                          value: RadioGunguUseGbn.gbn2,
                                          groupValue: _radioGunguUseGbn,
                                          onChanged: (v) async {
                                            _radioGunguUseGbn = v;

                                            setState(() {

                                            });
                                          }),
                                    ),
                                    Text('미사용', style: TextStyle(fontSize: 12)),
                                  ],
                                ),
                              ),
                            ]) : TableRow(children: [
                              Container(
                                  color: Colors.blue[50],
                                  height: 74,
                                  alignment: Alignment.center,
                                  child: Text('지역')
                              ),
                              Container(
                                color: Colors.white,
                                height: 76,
                                padding: EdgeInsets.only(left: 16),//symmetric(horizontal: 16),
                                child: Column(
                                  children: [
                                    SizedBox(height: 4,),
                                    Row(
                                      children: [
                                        Row(
                                          children: [
                                            Text('시/도'),
                                            SizedBox(width: 8),
                                            ISSelect(
                                              width: 120,
                                              height: 30,
                                              paddingEnabled: false,
                                              value: _themeSido ?? '',
                                              dataList: selectBox_Sido,
                                              onChange: (v){
                                                //current_Sido = v;
                                              },
                                            )
                                          ],
                                        ),
                                        SizedBox(width: 20,),
                                        Row(
                                          children: [
                                            Text('군/구'),
                                            SizedBox(width: 8),
                                            ISSelect(
                                              width: 100,
                                              height: 30,
                                              paddingEnabled: false,
                                              value: _themeGungu ?? '',
                                              dataList: selectBox_Gungu,
                                              onChange: (v){
                                                _themeGungu = v;
                                              },
                                            ),
                                            SizedBox(width: 8),
                                            Text('* 군/구는 서브 테마일 경우에만  \n   적용됩니다.', style: TextStyle(color: Colors.red, fontSize: 10),)
                                          ],
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        MaterialButton(
                                          color: Colors.blue,
                                          minWidth: 40,
                                          height: 30,
                                          child: Text('주소검색', style: TextStyle(color: Colors.white, fontSize: 12),),
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                                          onPressed: (){
                                            _searchPost();
                                          },
                                        ),
                                        Container(
                                          color: Colors.white,
                                          child: ISTableInput(
                                            readOnly: true,
                                            height: 26,
                                            width: getListMainPanelWidth() - 320,
                                            value: _themeAddress,//formData.bussCon ?? '',
                                            textStyle: TextStyle(fontSize: 12),
                                            onChange: (v) {
                                              _themeAddress = v;
                                              setState(() {

                                              });
                                            },
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            ]),
                            _isMainTheme == true ? TableRow(children: [
                              Container(
                                  color: Colors.blue[50],
                                  height: 74,
                                  alignment: Alignment.center,
                                  child: Text('메인배너')
                              ),
                              Container(
                                color: Colors.white,
                                height: 60,
                                padding: EdgeInsets.symmetric(horizontal: 16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        MaterialButton(
                                          color: Colors.blue,
                                          minWidth: 40,
                                          height: 30,
                                          child: Text('업로드', style: TextStyle(color: Colors.white, fontSize: 12),),
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                                          onPressed: (){
                                            ImagePicker imagePicker = ImagePicker();
                                            imagePicker.getImage(source: ImageSource.gallery).then((file) async {
                                              await ISProgressDialog(context).show(status: '이미지 업로드중...');

                                              FileUpLoadProvider provider = FileUpLoadProvider();
                                              provider.setResource('image', file);
                                              provider.makeReserThemeMainPostResourceRequest(_selectedCode).then((value) async {
                                                _isMainTheme = true;
                                                loadMainThemeDetail(_selectedCode);

                                                setState(() {
                                                });

                                                await Future.delayed(Duration(milliseconds: 500), () {
                                                  setState(() {
                                                    _deleteImageFromCache();
                                                  });
                                                });

                                                await ISProgressDialog(context).dismiss();
                                              });
                                            });
                                          },
                                        ),
                                        SizedBox(width: 8,),
                                        if (_themeImageURL != '')
                                        MaterialButton(
                                          color: Colors.blue,
                                          minWidth: 40,
                                          height: 30,
                                          child: Text('삭제', style: TextStyle(color: Colors.white, fontSize: 12),),
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                                          onPressed: (){
                                            ISConfirm(context, '메인테마 이미지 삭제', '해당 이미지를 삭제하시겠습니까?', (context) async {
                                              ReservationController.to.deleteThemeMainImage(_selectedCode, context).then((value) {
                                                if (value != null){
                                                  ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                                }
                                                else{
                                                  _isMainTheme = true;
                                                  loadMainThemeDetail(_selectedCode);

                                                  setState(() {
                                                  });

                                                  Navigator.pop(context);

                                                  setState(() {

                                                  });
                                                }
                                              });
                                            });
                                          },
                                        ),
                                        SizedBox(width: 8,),
                                        //Text(_themeImageURL == '' ? '저장된 파일이 없습니다.' : _themeImageURL, style: TextStyle(fontSize: 12))
                                        _themeImageURL == '' ? Text('저장된 파일이 없습니다.', style: TextStyle(fontSize: 12)) : MaterialButton(
                                          height: 30.0,
                                          child: Text(_themeImageURL, style: TextStyle(color: Colors.black, fontSize: 13)),
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                                          onPressed: ()  {
                                            _launchInBrowser(_themeImageRealURL +'?tm=${Utils.getTimeStamp()}');
                                          },
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                            // color: Colors.blue[50],
                                            // height: 44,
                                            // alignment: Alignment.center,
                                            child: Text('앱메인화면 표기', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),)
                                        ),
                                        Container(
                                          color: Colors.white,
                                          padding: EdgeInsets.symmetric(horizontal: 16),
                                          child: Row(
                                            children: [
                                              Radio(
                                                  value: RadioAppMainVisible.gbn1,
                                                  groupValue: _radioAppMainVisible,
                                                  onChanged: (v) async {
                                                    _radioAppMainVisible = v;

                                                    setState(() {

                                                    });

                                                  }),
                                              Text('사용', style: TextStyle(fontSize: 12)),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                                child: Radio(
                                                    value: RadioAppMainVisible.gbn2,
                                                    groupValue: _radioAppMainVisible,
                                                    onChanged: (v) async {
                                                      _radioAppMainVisible = v;

                                                      setState(() {

                                                      });
                                                    }),
                                              ),
                                              Text('미사용', style: TextStyle(fontSize: 12)),
                                            ],
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                )
                              ),
                            ]) : TableRow(children: [
                                Container(
                                    color: Colors.blue[50],
                                    height: 38,
                                    alignment: Alignment.center,
                                    child: Text('서브메뉴 썸네일')
                                ),
                                Container(
                                  color: Colors.white,
                                  height: 30,
                                  padding: EdgeInsets.symmetric(horizontal: 16),
                                  child: Row(
                                    children: [
                                      MaterialButton(
                                        color: Colors.blue,
                                        minWidth: 40,
                                        height: 30,
                                        child: Text('업로드', style: TextStyle(color: Colors.white, fontSize: 12),),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                                        onPressed: (){
                                          ImagePicker imagePicker = ImagePicker();
                                          imagePicker.getImage(source: ImageSource.gallery).then((file) async {
                                            await ISProgressDialog(context).show(status: '이미지 업로드중...');

                                            FileUpLoadProvider provider = FileUpLoadProvider();
                                            provider.setResource('image', file);
                                            provider.makeReserThemeSubPostResourceRequest(_selectedCode, _selectedSubCode).then((value) async {
                                              _isMainTheme = false;
                                              loadSubThemeDetail(_selectedCode, _selectedSubCode);


                                              // loadData();
                                              setState(() {
                                                //Url_1 = file.path;
                                              });

                                              await Future.delayed(Duration(milliseconds: 500), () {
                                                setState(() {
                                                  _deleteImageFromCache();
                                                });
                                              });

                                              await ISProgressDialog(context).dismiss();
                                            });
                                          });
                                        },
                                      ),
                                      SizedBox(width: 8,),
                                      if (_themeImageURL != '')
                                        MaterialButton(
                                          color: Colors.blue,
                                          minWidth: 40,
                                          height: 30,
                                          child: Text('삭제', style: TextStyle(color: Colors.white, fontSize: 12),),
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                                          onPressed: (){
                                            ISConfirm(context, '서브테마 이미지 삭제', '해당 이미지를 삭제하시겠습니까?', (context) async {
                                              ReservationController.to.deleteThemeSubImage(_selectedCode, _selectedSubCode, context).then((value) {
                                                if (value != null){
                                                  ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                                }
                                                else{
                                                  _isMainTheme = false;
                                                  loadSubThemeDetail(_selectedCode, _selectedSubCode);

                                                  setState(() {
                                                  });

                                                  Navigator.pop(context);

                                                  setState(() {

                                                  });
                                                }
                                              });
                                            });
                                          },
                                        ),
                                      SizedBox(width: 8,),
                                      //Text(_themeImageURL == '' ? '저장된 파일이 없습니다.' : _themeImageURL, style: TextStyle(fontSize: 12))
                                      _themeImageURL == '' ? Text('저장된 파일이 없습니다.', style: TextStyle(fontSize: 12)) : MaterialButton(
                                        height: 30.0,
                                        child: Text(_themeImageURL, style: TextStyle(color: Colors.black, fontSize: 13)),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                                        onPressed: ()  {
                                          _launchInBrowser(_themeImageRealURL +'?tm=${Utils.getTimeStamp()}');
                                        },
                                      )
                                    ],
                                  ),
                                ),
                            ]),
                            TableRow(children: [
                              Container(
                                  color: Colors.blue[50],
                                  height: 134,
                                  alignment: Alignment.center,
                                  child: Text('요약설명')
                              ),
                              Container(
                                color: Colors.white,
                                child: ISTableInput(
                                  value: _themeMemo,// formData.menuGroupMemo ?? '',
                                  //context: context,
                                  height: 120,
                                  keyboardType: TextInputType.multiline,
                                  maxLines: 8,
                                  maxLength: 50,//임시로 50글자로 제한
                                  onChange: (v) {
                                    _themeMemo = v;
                                  },
                                ),
                              ),
                            ]),
                          ],

                        ),
                      ],
                    ),
                  ),
                  Divider(),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 25),// .all(25),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('테마에 등록된 가맹점', style: TextStyle(fontSize: 20)),
                            Row(
                              children: [
                                Container(
                                  height: 30,
                                  child: ISSelect(
                                    width: 100,
                                    paddingEnabled: false,
                                    value: _shopJobGbn ?? '1',
                                    dataList: selectBox_ShopSearchType,
                                    onChange: (v){
                                      _shopJobGbn = v;
                                    },
                                  ),
                                ),
                                ISInput(
                                  height: 30,
                                  width: 180,
                                  value: _shopSearchKeyword,
                                  textStyle: TextStyle(fontSize: 12),
                                  onChange: (v) {
                                    _shopSearchKeyword = v;

                                  },
                                  onFieldSubmitted: (value) {
                                    _currentPage = 1;
                                    _query();
                                  },
                                ),
                                ISButton(
                                  label: '조회',
                                  iconData: Icons.search,
                                  iconColor: Colors.white,
                                  textStyle: TextStyle(color: Colors.white),
                                  onPressed: () {
                                    _currentPage = 1;
                                    _query();
                                  },
                                ),
                                SizedBox(width: 8,),
                                ISButton(
                                  label: '추가',
                                  iconData: Icons.add,
                                  iconColor: Colors.white,
                                  textStyle: TextStyle(color: Colors.white),
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      builder: (BuildContext context) => Dialog(
                                        child: ReserveThemShopAdd(code: _selectedCode, subCode: _selectedSubCode,),
                                      ),
                                    ).then((v) async {
                                      if (v != null) {
                                        await Future.delayed(Duration(milliseconds: 500), (){
                                          _currentPage = 1;
                                          _query();

                                          setState(() {

                                          });
                                        });
                                      }
                                    });
                                  }
                                ),
                              ],
                            ),
                          ],
                        ),
                        SizedBox(height: 4,),
                        Container(
                          decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(1),
                          border: Border.all(width: 1, color: Colors.black12)
                          ),
                          child: Column(
                            children: [
                              ISDatatable(
                                controller: ScrollController(),
                                panelHeight: (MediaQuery.of(context).size.height-618),
                                listWidth: getListMainPanelWidth()-68,//900,
                                dataRowHeight: 30,
                                headingRowHeight: 24,
                                padding: EdgeInsets.all(0.0),
                                //showCheckboxColumn: (widget.shopName == null) ? true : false,
                                rows: dataShopList.map((item) {
                                  return DataRow(
                                      selected: item.selected ?? false,
                                      color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
                                        if (item.selected == true) {
                                          return Colors.grey.shade200;
                                          //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
                                        }

                                        return Theme.of(context).colorScheme.primary.withOpacity(0.00);
                                      }),
                                      onSelectChanged: (bool value){
                                        dataShopList.forEach((element) {
                                          element.selected = false;
                                        });

                                        item.selected = true;

                                        //loadAuthData(item.uCode);

                                        setState(() {
                                        });
                                      },
                                      cells: [
                                        DataCell(Align(child: Text('[${item.shopCd.toString()}] ${item.shopName.toString()}' ?? '--', style: TextStyle(color: Colors.black, fontSize: 12),), alignment: Alignment.centerLeft)),
                                        DataCell(Align(child: Text(Utils.getStoreRegNumberFormat(item.regNo.toString(), false) ?? '--', style: TextStyle(color: Colors.black, fontSize: 12),), alignment: Alignment.center)),
                                        DataCell(Align(child: Text('${item.addr1.toString()} ${item.addr2.toString()}' ?? '--', style: TextStyle(color: Colors.black, fontSize: 12)), alignment: Alignment.centerLeft),),
                                        DataCell(
                                          Center(
                                            child: InkWell(
                                                onTap: () {
                                                  ISConfirm(context, '테마 가맹점 해제', '해당 가맹점을 해제하시겠습니까?', (context) async {
                                                    ReservationController.to.putReserThemeShopConfirm('2', _selectedCode, _selectedSubCode, item.shopCd, context).then((value) {
                                                      if (value != null){
                                                        ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                                      }
                                                      else{
                                                        _currentPage = 1;
                                                        _query();

                                                        Navigator.pop(context);

                                                        setState(() {

                                                        });
                                                      }
                                                    });
                                                  });
                                                },
                                                child: Icon(Icons.delete, size: 16)
                                            ),
                                          ),
                                        ),
                                      ]);
                                }).toList(),
                                columns: <DataColumn>[
                                  DataColumn(label: Expanded(child: Text('가맹점명', textAlign: TextAlign.center)),),
                                  DataColumn(label: Expanded(child: Text('사업자번호', textAlign: TextAlign.center)),),
                                  DataColumn(label: Expanded(child: Text('주소', textAlign: TextAlign.center)),),
                                  DataColumn(label: Expanded(child: Text('관리', textAlign: TextAlign.center)),),
                                ],
                              ),
                              showPagerBar(),
                            ],
                          ),
                        )
                      ],
                    ),
                  )
                ],
          )
          )
        ],
      ),
    );
  }

  double getListMainPanelWidth(){
    double nWidth = MediaQuery.of(context).size.width-660;

    if (Responsive.isTablet(context) == true)           nWidth = nWidth + sidebarWidth;
    else if (Responsive.isMobile(context) == true)      nWidth = MediaQuery.of(context).size.width;

    return nWidth;
  }

  _searchPost() async {
    if (kIsWeb) {
      showDialog(
          context: context,
          builder: (BuildContext context) => Dialog(
            child: Container(width: 0, height: 0, child: PostCodeRequest()),
          )).then((v) async {
        if (v != null)  {
          //formKey.currentState.save();

          String addr1 = v[1];
          String addr2 = v[2];

          await ShopController.to.getNaverData(addr1, addr2);

          await Future.delayed(Duration(milliseconds: 500), () async {
            _themeAddress = addr2;

            _themeX = await ShopController.to.x;
            _themeY = await ShopController.to.y;

            if (_themeX == '' || _themeX == null || _themeY == '' || _themeY == null )
              ISAlert(context, '해당 주소에 대한 좌표조회에 실패하였습니다. \n\n 주소 확인후, 다시 시도해주세요.');

            setState(() {

            });
          });

        }
      });
    } else {
      var v = await Navigator.of(context).push(MaterialPageRoute(builder: (context) => Kopo()));

      if (v != null) {
        setState(() async {
          print('check2222');
          // if (v.userSelectedType == 'R') {
          //   formData.zipCode = v.zoncode;
          //   formData.addr1 = v.roadAddress;
          // } else {
          //   formData.zipCode = v.zoncode;
          //   formData.addr1 = v.jibunAddress;
          // }
          //
          // formData.zipCode = v.zoncode;
          // formData.addr1 = v.jibunAddress;
          // formData.addr2 = v.roadAddress;
          //
          // await ShopController.to.getNaverData(formData.addr1, formData.addr2);
        });
      }
    }
  }

  Future<void> _launchInBrowser(String url) async {
    if (await canLaunch(url)) {
      await launch(
        url,
        forceSafariVC: false, //true로 설정시, iOS 인앱 브라우저를 통해픈
        forceWebView: false, //true로 설정시, Android 인앱 브라우저를 통해 오픈
        headers: <String, String>{'my_header_key': 'my_header_value'},
      );
    } else {
      throw 'Web Request Fail $url';
    }
  }

  Future _deleteImageFromCache() async {
    //await CachedNetworkImage.evictFromCache(url);

    PaintingBinding.instance.imageCache.clearLiveImages();
    PaintingBinding.instance.imageCache.clear();

    //await DefaultCacheManager().removeFile(key);
    //await DefaultCacheManager().emptyCache();
    setState(() {});
  }

  Widget showPagerBar() {
    return Expanded(
        flex: 0,
        child: Container(
          height: 30,
          padding: EdgeInsets.symmetric(horizontal: 8.0),
          child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                  width: 100,
                  child: Row(
                    children: <Widget>[
                      Text('총: ${Utils.getCashComma(ReservationController.to.totalRowCnt.toString())}건', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                    ],
                  ),
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      InkWell(
                          onTap: () {
                            _currentPage = 1;

                            _pageMove(_currentPage);
                          },
                          child: Icon(Icons.first_page)),
                      InkWell(
                          onTap: () {
                            if (_currentPage == 1) return;

                            _pageMove(_currentPage--);
                          },
                          child: Icon(Icons.chevron_left)),
                      Container(
                        //width: 70,
                        child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                      ),
                      InkWell(
                          onTap: () {
                            if (_currentPage >= _totalPages) return;

                            _pageMove(_currentPage++);
                          },
                          child: Icon(Icons.chevron_right)),
                      InkWell(
                          onTap: () {
                            _currentPage = _totalPages;
                            _pageMove(_currentPage);
                          },
                          child: Icon(Icons.last_page))
                    ],
                  ),
                ),
                Container(
                  //height: 36,
                  child: Responsive.isMobile(context) ? Container(/*height: 36*/) :  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      //
                      // Text(ShopController.to.totalRowCnt.toString() + ' / ' + ShopController.to.total_count.toString(), style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                      // SizedBox(width: 20,),
                      Text('페이지당 행 수 : ', style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal)),
                      Container(
                        width: 70,
                        child: DropdownButton(
                            value: _selectedpagerows,
                            underline: Container(),
                            isExpanded: true,
                            style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: 'NotoSansKR'),
                            items: Utils.getPageRowList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedpagerows = value;
                                _currentPage = 1;
                                _query();
                              });
                            }),
                      ),
                    ],
                  ),
                ),
              ]
          ),
        )
    );
  }
}


