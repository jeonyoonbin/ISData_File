import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ContentsSubListModel {
  ContentsSubListModel();

  bool viewSelected = false;
  int EPISODE;
  String EP_TITLE;
  String DISP_GBN;
  int HIT;
  String INS_DATE;
  int INS_UCODE;

  factory ContentsSubListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ContentsSubListModel _$ModelFromJson(Map<String, dynamic> json) {
  return ContentsSubListModel()
    ..viewSelected = json['viewSelected'] as bool
    ..EPISODE = json['EPISODE'] as int
    ..EP_TITLE = json['EP_TITLE'] as String
    ..DISP_GBN = json['DISP_GBN'] as String
    ..HIT = json['HIT'] as int
    ..INS_DATE = json['INS_DATE'] as String
    ..INS_UCODE = json['INS_UCODE'] as int;
}

Map<String, dynamic> _$ModelToJson(ContentsSubListModel instance) => <String, dynamic>{
  'viewSelected': instance.viewSelected,
  'EPISODE': instance.EPISODE,
  'EP_TITLE': instance.EP_TITLE,
  'DISP_GBN': instance.DISP_GBN,
  'HIT': instance.HIT,
  'INS_DATE': instance.INS_DATE,
  'INS_UCODE': instance.INS_UCODE
};
