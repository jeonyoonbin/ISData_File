import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ContentsRegistModel {
  ContentsRegistModel();

  bool selected = false;
  String cartegory_gbn;
  String contents_cd;
  String contents_title;
  String disp_gbn;
  String main_url;
  String emoji_code;
  String thumbnail_url;
  String ins_ucode;
  String mod_ucode;

  factory ContentsRegistModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ContentsRegistModel _$ModelFromJson(Map<String, dynamic> json) {
  return ContentsRegistModel()
    ..selected = json['selected'] as bool
    ..cartegory_gbn = json['cartegory_gbn'] as String
    ..contents_cd = json['contents_cd'] as String
    ..contents_title = json['contents_title'] as String
    ..disp_gbn = json['disp_gbn'] as String
    ..main_url = json['main_url'] as String
    ..emoji_code = json['emoji_code'] as String
    ..thumbnail_url = json['thumbnail_url'] as String
    ..ins_ucode = json['ins_ucode'] as String
    ..mod_ucode = json['mod_ucode'] as String;
}

Map<String, dynamic> _$ModelToJson(ContentsRegistModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'cartegory_gbn': instance.cartegory_gbn,
  'contents_cd': instance.contents_cd,
  'contents_title': instance.contents_title,
  'disp_gbn': instance.disp_gbn,
  'main_url': instance.main_url,
  'emoji_code': instance.emoji_code,
  'thumbnail_url': instance.thumbnail_url,
  'ins_ucode': instance.ins_ucode,
  'mod_ucode': instance.mod_ucode,
};
