import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ContentsDetailList {
  ContentsDetailList();

  bool selected = false;
  String CARTEGORY_GBN;
  int CONTENTS_CD;
  String CONTENTS_TITLE;
  String DISP_GBN;
  String MAIN_URL;
  String EMOJI_CODE;
  String THUMBNAIL_URL;
  int INS_UCODE;
  String INS_DATE;
  int MOD_UCODE;
  String MOD_DATE;

  factory ContentsDetailList.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ContentsDetailList _$ModelFromJson(Map<String, dynamic> json) {
  return ContentsDetailList()
    ..selected = json['selected'] as bool
    ..CARTEGORY_GBN = json['CARTEGORY_GBN'] as String
    ..CONTENTS_CD = json['CONTENTS_CD'] as int
    ..CONTENTS_TITLE = json['CONTENTS_TITLE'] as String
    ..DISP_GBN = json['DISP_GBN'] as String
    ..MAIN_URL = json['MAIN_URL'] as String
    ..EMOJI_CODE = json['EMOJI_CODE'] as String
    ..THUMBNAIL_URL = json['THUMBNAIL_URL'] as String
    ..INS_UCODE = json['INS_UCODE'] as int
    ..INS_DATE = json['INS_DATE'] as String
    ..MOD_UCODE = json['MOD_UCODE'] as int
    ..MOD_DATE = json['MOD_DATE'] as String;
}

Map<String, dynamic> _$ModelToJson(ContentsDetailList instance) => <String, dynamic>{
  'selected': instance.selected,
  'CARTEGORY_GBN': instance.CARTEGORY_GBN,
  'CONTENTS_CD': instance.CONTENTS_CD,
  'CONTENTS_TITLE': instance.CONTENTS_TITLE,
  'DISP_GBN': instance.DISP_GBN,
  'MAIN_URL': instance.MAIN_URL,
  'EMOJI_CODE': instance.EMOJI_CODE,
  'THUMBNAIL_URL': instance.THUMBNAIL_URL,
  'INS_UCODE': instance.INS_UCODE,
  'INS_DATE': instance.INS_DATE,
  'MOD_UCODE': instance.MOD_UCODE,
  'MOD_DATE': instance.MOD_DATE
};
