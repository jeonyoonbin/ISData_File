import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveThemeMainDetailModel {
  ReserveThemeMainDetailModel();

  bool selected = false;
  String mainName;
  String name;
  String useGbn;
  String mainVisibleGbn;
  String gunguUseGbn;

  factory ReserveThemeMainDetailModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveThemeMainDetailModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveThemeMainDetailModel()
  //..selected = json['selected'] as bool
    ..mainName = json['mainName'] as String
    ..name = json['name'] as String
    ..useGbn = json['useGbn'] as String
    ..mainVisibleGbn = json['mainVisibleGbn'] as String
    ..gunguUseGbn = json['gunguUseGbn'] as String;
}

Map<String, dynamic> _$ModelToJson(ReserveThemeMainDetailModel instance) => <String, dynamic>{
  //'selected': instance.selected,
  'mainName': instance.mainName,
  'name': instance.name,
  'useGbn': instance.useGbn,
  'mainVisibleGbn': instance.mainVisibleGbn,
  'gunguUseGbn': instance.gunguUseGbn
};
