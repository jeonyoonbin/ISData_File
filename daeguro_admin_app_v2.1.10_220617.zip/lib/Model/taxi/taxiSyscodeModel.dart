import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiSyscodeModel {
  TaxiSyscodeModel();

  bool selected = false;
  String fdValue;
  String fdDisplay;

  factory TaxiSyscodeModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiSyscodeModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiSyscodeModel()
    ..selected = json['selected'] as bool
    ..fdValue = json['fdValue'] as String
    ..fdDisplay = json['fdDisplay'] as String;

}

Map<String, dynamic> _$ModelToJson(TaxiSyscodeModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'fdValue': instance.fdValue,
  'fdDisplay': instance.fdDisplay
};