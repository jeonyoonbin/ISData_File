import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class taxiCouponListModel {
  taxiCouponListModel();

  bool selected = false;
  String noCoup;
  String dtmIns;
  String idUsrIns;
  String nmUsrIns;
  String cdComp;
  String cdCoup;
  String nmCoup;
  String ynUse;
  String ynUseText;
  String divStatus;
  String divStatusText;
  String amtCoup;
  String dtmConf;
  String dtStart;
  String dtEnd;
  String idPers;
  String idUsePers;
  String dtmUse;

  factory taxiCouponListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

taxiCouponListModel _$ModelFromJson(Map<String, dynamic> json) {
  return taxiCouponListModel()
    ..selected = json['selected'] as bool
    ..noCoup = json['noCoup'] as String
    ..dtmIns = json['dtmIns'] as String
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..cdComp = json['cdComp'] as String
    ..cdCoup = json['cdCoup'] as String
    ..nmCoup = json['nmCoup'] as String
    ..ynUse = json['ynUse'] as String
    ..ynUseText = json['ynUseText'] as String
    ..divStatus = json['divStatus'] as String
    ..divStatusText = json['divStatusText'] as String
    ..amtCoup = json['amtCoup'] as String
    ..dtmConf = json['dtmConf'] as String
    ..dtStart = json['dtStart'] as String
    ..dtEnd = json['dtEnd'] as String
    ..idPers = json['idPers'] as String
    ..idUsePers = json['idUsePers'] as String
    ..dtmUse = json['dtmUse'] as String;

}

Map<String, dynamic> _$ModelToJson(taxiCouponListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'noCoup': instance.noCoup,
  'dtmIns': instance.dtmIns,
  'idUsrIns': instance.idUsrIns,
  'nmUsrIns': instance.nmUsrIns,
  'cdComp': instance.cdComp,
  'cdCoup': instance.cdCoup,
  'nmCoup': instance.nmCoup,
  'ynUse': instance.ynUse,
  'ynUseText': instance.ynUseText,
  'divStatus': instance.divStatus,
  'divStatusText': instance.divStatusText,
  'amtCoup': instance.amtCoup,
  'dtmConf': instance.dtmConf,
  'dtStart': instance.dtStart,
  'dtEnd': instance.dtEnd,
  'idPers': instance.idPers,
  'idUsePers': instance.idUsePers,
  'dtmUse': instance.dtmUse
};
