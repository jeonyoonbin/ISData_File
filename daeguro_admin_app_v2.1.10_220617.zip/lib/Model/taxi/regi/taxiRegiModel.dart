import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiRegiModel {
  TaxiRegiModel();

  String idUsrIns;
  String nmUsrIns;
  String nmBusi;
  String noBusi;
  String noCorp;
  String nmOwner;
  String taxType;
  String divBusi;
  String addrDtl;
  String lon;
  String lat;
  String busiItem;
  String busiType;

  factory TaxiRegiModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiRegiModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiRegiModel()
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..nmBusi = json['nmBusi'] as String
    ..noBusi = json['noBusi'] as String
    ..noCorp = json['noCorp'] as String
    ..nmOwner = json['nmOwner'] as String
    ..taxType = json['taxType'] as String
    ..divBusi = json['divBusi'] as String
    ..addrDtl = json['addrDtl'] as String
    ..lon = json['lon'] as String
    ..lat = json['lat'] as String
    ..busiItem = json['busiItem'] as String
    ..busiType = json['busiType'] as String;

}

Map<String, dynamic> _$ModelToJson(TaxiRegiModel instance) => <String, dynamic>{
  'idUsrIns': instance.idUsrIns,
  'nmUsrIns': instance.nmUsrIns,
  'nmBusi': instance.nmBusi,
  'noBusi': instance.noBusi,
  'noCorp': instance.noCorp,
  'nmOwner': instance.nmOwner,
  'taxType': instance.taxType,
  'divBusi': instance.divBusi,
  'addrDtl': instance.addrDtl,
  'lon': instance.lon,
  'lat': instance.lat,
  'busiItem': instance.busiItem,
  'busiType': instance.busiType
};