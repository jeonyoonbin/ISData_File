﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DG_App_Rest.Common
{
    public class Utils
    {
        public static string serverGbn;
        public static string oracleConnectString;
        public static string oracleConnectStringTest;
        public static string fcmKey;
        public static string Data_go_kr_Key;
        public static string mallKey;
        public static string mallKeyT;
        public static string posKey;
        public static string nasPath = @"\\10.10.10.100\dgnas\Files";
        public static string origianlPath = @"\\10.10.10.100\dgnas\Files\OriginalImage";
        public static string productPath = @"\\10.10.10.100\dgnas\Files\ProductImage";
        public static string eventPath = @"\\10.10.10.100\dgnas\Files\EventImage";
        public static string URL_BIZTALK_NEW_T = "http://payment-dev.daeguro.co.kr:23785/LunaTalkSend"; // 개발
        //public static string URL_BIZTALK_NEW = "http://192.168.30.131:23785/LunaTalkSend"; // 개발
        public static string URL_BIZTALK_NEW = "http://172.17.30.102:23785/LunaTalkSend"; //운영

        public static async Task SaveErrorAsync(string position, string msg)
        {
            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.Text,
                CommandText = "INSERT INTO REST_ERROR(DIV, POSITION, MSG, INSERT_TIME) VALUES (:div, :position, :msg, SYSDATE)",
            };

            // div 0: 관리앱, div 1: 시스템(rest,DB)
            cmd.Parameters.Add("div", OracleDbType.Varchar2, 1).Value = "1";
            cmd.Parameters.Add("position", OracleDbType.Varchar2, 100).Value = position;
            cmd.Parameters.Add("msg", OracleDbType.Varchar2, 2000).Value = msg;


            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Agent : Post", ex.Message);
            }
        }

        //개인정보 조회 로그 기록 rest
        public static async Task setPrivacyLog(string ucode, string pid, string log_gbn, string content, string position)
        {
            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.Text,
                CommandText = "insert into admin_privacy_log(app_gbn, ucode, log_time, pid, log_gbn, CONTENT, POSITION) values(:app_gbn, :ucode, sysdate, :pid, :log_gbn, :content, :position)",
            };

            // app_gbn 앱구분 (W: 관리앱, E: 외부사용자용 관리앱)
            // log_gbn 로그구분 (10: 조회, 20: 개인정보해지, 30: 회원탈퇴, 40: 다운로드)
            cmd.Parameters.Add("app_gbn", OracleDbType.Varchar2, 1).Value = "W";
            cmd.Parameters.Add("ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("pid", OracleDbType.Int32).Value = pid;
            cmd.Parameters.Add("log_gbn", OracleDbType.Varchar2, 2).Value = log_gbn;
            cmd.Parameters.Add("content", OracleDbType.Varchar2, 2000).Value = content;
            cmd.Parameters.Add("position", OracleDbType.Varchar2, 100).Value = position;


            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Utils/setPrivacyLog : Post", ex.Message);
            }
        }

        //에러X 내역 기록용 rest
        public static async Task SaveTempLogAsync(string position, string msg)
        {
            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.Text,
                CommandText = "INSERT INTO temp_log(DIV, POSITION, MSG, INSERT_TIME) VALUES (:div, :position, :msg, SYSDATE)",
            };

            // div 0: 관리앱, div 1: 시스템(rest,DB), div 2: 외부앱 rest
            cmd.Parameters.Add("div", OracleDbType.Varchar2, 1).Value = "1";
            cmd.Parameters.Add("position", OracleDbType.Varchar2, 100).Value = position;
            cmd.Parameters.Add("msg", OracleDbType.Varchar2, 2000).Value = msg;


            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveTempLogAsync("/Agent : Post", ex.Message);
            }
        }

        public static string base64Encoding(string input)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(input);
            string result = Convert.ToBase64String(bytes);

            return result;
        }

        public static string SHA256Hash(string input)
        {
            SHA256 sha = new SHA256Managed();
            byte[] bytes = sha.ComputeHash(Encoding.ASCII.GetBytes(input));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                sb.AppendFormat("{0:x2}",bytes[i]);
            }
            string result = sb.ToString();

            sb.Clear();

            return result;
        }

    }
}
