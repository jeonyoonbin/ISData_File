﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;


namespace DG_App_Rest.Common
{
    public class BiztalkHelper
    {
        public static int biztalkNo = 0;        

        public static async Task<ResultBasic> BiztalkVoucherSend(int voucherSeq, string templateCode, string receiveTelNo, string recv_name, string send_name)
        {
            ResultBasic result = new ResultBasic();

            DynamicParameters param = new DynamicParameters();
            param.Add("voucherSeq", voucherSeq);

            try
            {
                string msgId = "";
                var message = "";

                string today = DateTime.Now.ToString("yyMMddHHmmss");
                string gbn = "A";
                string gbnStr = templateCode.Replace("daeguro", "").PadRight(6, '0');
                msgId = $"{today}{gbn}{gbnStr}";                    


                if (templateCode == "50056")
                {
                    message = Biztalk_50056(recv_name, send_name);
                }
                else
                {
                    message = "";
                }

                if (message == null || message == "")
                {
                // message 없을 경우 Log 기록필요

                    result.code = "99";
                    result.msg = "템플릿 코드가 잘못되었습니다.";
                }
                else
                {
                    LunaBiztalkBtn btn = new LunaBiztalkBtn();
                    btn.url_pc = "https://www.daeguro.co.kr";
                    btn.url_mobile = "https://www.daeguro.co.kr";
                    btn.scheme_android = "https://app.daeguro.co.kr/app/public_link.html?project=DELIVERY&action=ACTION_LINK_VOUCHER";
                    btn.scheme_ios = "https://app.daeguro.co.kr/app/public_link.html?project=DELIVERY&action=ACTION_LINK_VOUCHER";

                    LunaBiztalkContetns contents = new LunaBiztalkContetns();
                    contents.btn_url = new List<LunaBiztalkBtn>();

                    contents.no = msgId.ToString();
                    contents.tel_num = receiveTelNo;
                    contents.reserve_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    contents.custom_key = "";
                    contents.msg_content = message;
                    contents.sms_content = message + "\n\n" + btn.scheme_android;
                    contents.use_sms = "1";
                    contents.app_user_id = "";
                    contents.btn_url.Add(btn);

                    LunaBiztalkModel payload = new LunaBiztalkModel();
                    payload.template_id = templateCode;
                    payload.message = contents;

                    // 비즈톡API 호출                        
                    result = await SendLunaBiztalkAsync(payload);
                }

            }
            catch (Exception ex)
            {
                //Utils.SaveServiceLog("SendBiztalkAsync Exception : " + ex.ToString());
                // 예외발생할 경우 Log 기록필요

                result.code = "98";
                result.msg = ex.Message;
            }

            return result;
        }

        public static async Task<ResultBasic> BiztalkOrderSend(int orderSeq)
        {
            ResultBasic result = new ResultBasic();

            DynamicParameters param = new DynamicParameters();
            param.Add("orderSeq", orderSeq);

            try
            {
                BizTalkOrder reqData = await getBizTalkOrder(orderSeq);

                string msgId = "";
                var message = "";

                string templateCode = string.Empty;

                if(reqData == null)
                {
                    result.code = "99";
                    result.msg = "reqData 조회실패";

                    return result;
                }
                else if (reqData.SYSTEM_GBN == "DELIVERY")
                {
                    if (reqData.ITEM_CD == "1031" || reqData.ITEM_CD == "1032" ||
                        reqData.ITEM_CD == "1033" || reqData.ITEM_CD == "1035")
                    {
                        templateCode = "50044";
                        message = Biztalk_50044(reqData.CANCEL_REASON, reqData.ORDER_TIME, reqData.ORDER_NO, reqData.SHOP_NAME, reqData.MENU_NAME);
                    }
                    else
                    {
                        templateCode = "50036";
                        message = Biztalk_50036(reqData.CANCEL_REASON, reqData.ORDER_TIME, reqData.ORDER_NO, reqData.SHOP_NAME, reqData.MENU_NAME);
                    }
                }
                else if (reqData.SYSTEM_GBN == "BUNDLE")
                {
                    templateCode = "50065";
                    message = Biztalk_50065(reqData.CANCEL_REASON, reqData.ORDER_TIME, reqData.ORDER_NO, reqData.MENU_NAME);
                }
                else if (reqData.SYSTEM_GBN == "ELECTRIC" || reqData.SYSTEM_GBN == "FLOWER")
                {
                    templateCode = "50044";
                    message = Biztalk_50044(reqData.CANCEL_REASON, reqData.ORDER_TIME, reqData.ORDER_NO, reqData.SHOP_NAME, reqData.MENU_NAME);
                }
                else
                {
                    message = "";
                }

                string today = DateTime.Now.ToString("yyMMddHHmmss");
                string gbn = "A";
                string gbnStr = templateCode.Replace("daeguro", "").PadRight(6, '0');
                msgId = $"{today}{gbn}{gbnStr}";

                if (message == null || message == "")
                {
                    // message 없을 경우 Log 기록필요

                    result.code = "99";
                    result.msg = "템플릿 코드가 잘못되었습니다.";
                }
                else
                {
                    LunaBiztalkContetns contents = new LunaBiztalkContetns();

                    contents.no = msgId.ToString();
                    contents.tel_num = reqData.DEST_TELNO;
                    contents.reserve_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    contents.custom_key = "";
                    contents.msg_content = message;
                    contents.sms_content = message;
                    contents.use_sms = "1";
                    contents.app_user_id = "";

                    LunaBiztalkModel payload = new LunaBiztalkModel();
                    payload.template_id = templateCode;
                    payload.message = contents;

                    // 비즈톡API 호출                        
                    result = await SendLunaBiztalkAsync(payload);
                }

            }
            catch (Exception ex)
            {
                result.code = "98";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync("/BiztalkHelper/BiztalkOrderSend", ex.Message);
            }

            return result;
        }

        public static async Task<ResultBasic> SendLunaBiztalkAsync(LunaBiztalkModel send)
        {
            string url = string.Empty;

            if(Utils.serverGbn == "R")
            {
                url = Utils.URL_BIZTALK_NEW;
            }
            else
            {
                url = Utils.URL_BIZTALK_NEW_T;
            }

            ResultBasic result = new ResultBasic();
            HttpClient httpClient = new HttpClient();

            try
            {
                // List<BizTalkModel> payload = new List<BizTalkModel>();
                // payload.Add(send);

                LunaBiztalkModel payload = new LunaBiztalkModel();
                payload = send;

                var stringPayload = JsonConvert.SerializeObject(payload);

                HttpContent httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");
                //HttpResponseMessage httpResponse = new HttpResponseMessage();

                HttpResponseMessage httpResponse = await httpClient.PostAsync(url, httpContent);

                string responseStr = await httpResponse.Content.ReadAsStringAsync();

                ResultData retResult = JsonConvert.DeserializeObject<ResultData>(responseStr);
                if (retResult == null)
                {
                    // null일 경우 Log 기록필요
                    result.code = "99";
                    result.msg = "내부오류";
                }
                else
                {
                    if (retResult.code == "0")
                    {
                        Debug.WriteLine($"code:{retResult.code}");
                        result.code = retResult.code;
                        result.msg = "성공";
                    }
                    else
                    {
                        Debug.WriteLine($"code:{retResult.code}");
                        Debug.WriteLine($"message:{retResult.msg.messages[0].result_msg.ToString()}");
                        result.code = retResult.code;
                        result.msg = retResult.msg.messages[0].result_msg;
                    }                    
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("오류: " + ex.Message);

                result.code = "98";
                result.msg = ex.Message;
            }

            return result;
        }


        private static async Task<BizTalkOrder> getBizTalkOrder(int orderNo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            BizTalkOrder Rdata = new BizTalkOrder();


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("orderSeq", orderNo);

                db.Open();

                string sql = $@"  
                                SELECT   A.ORDER_NO               AS ORDER_NO      -- 오더번호
                                        , A.STATUS                 AS STATUS        -- 오더상태    
                                        , C.SHOP_NAME              AS SHOP_NAME     -- 상점명                                            
                                        , A.TELNO                 AS DEST_TELNO                   -- 도착지 전화번호                                              
                                        , B.MEMO                    AS MENU_NAME
                                        , TO_CHAR(A.ORDER_TIME, 'MM/DD AM HH:MI') AS ORDER_TIME                            -- 주문일시
                                        , CASE WHEN A.CANCEL_CODE = 11 THEN '매장부재로 인한 취소' ELSE A.CANCEL_REASON END AS CANCEL_REASON                -- 취소사유
                                        , A.SHOP_CD AS SHOP_CD -- 상점코드
                                        , NVL(B.SYSTEM_GBN,'DELIVERY') SYSTEM_GBN -- 주문구분
                                        , C.ITEM_CD -- 카테고리1
                                 FROM   DORDER A, DORDER_DETAIL B, SHOP_INFO C, APP_CUSTOMER D
                                 WHERE  A.ORDER_NO = :orderSeq
                                 AND    A.ORDER_NO = B.ORDER_NO              
                                 AND    A.SHOP_CD = C.SHOP_CD
                                 AND    A.APP_CUST_CODE = D.CUST_CODE                 
                                 AND    D.USE_GBN       = '1'    -- 고객 해지유무 추가, 2021/05/31                 
                                 AND    A.TEST_GBN = 'N'
                                UNION ALL
                                SELECT   A.ORDER_NO               AS ORDER_NO      -- 오더번호
                                        , A.STATUS                 AS STATUS        -- 오더상태     
                                        , C.SHOP_NAME              AS SHOP_NAME     -- 상점명                                            
                                        , A.TELNO                 AS DEST_TELNO                   -- 도착지 전화번호                                                
                                        , B.MEMO                    AS MENU_NAME
                                        , TO_CHAR(A.ORDER_TIME, 'MM/DD AM HH:MI') AS ORDER_TIME                            -- 주문일시
                                        , CASE WHEN A.CANCEL_CODE = 11 THEN '매장부재로 인한 취소' ELSE A.CANCEL_REASON END AS CANCEL_REASON                -- 취소사유
                                        , A.SHOP_CD AS SHOP_CD -- 상점코드
                                        , NVL(B.SYSTEM_GBN,'DELIVERY') SYSTEM_GBN -- 주문구분
                                        , C.ITEM_CD -- 카테고리1
                                 FROM   DORDER_PAST A, DORDER_DETAIL B, SHOP_INFO C, APP_CUSTOMER D
                                 WHERE  A.ORDER_NO = :orderSeq
                                 AND    A.ORDER_NO = B.ORDER_NO              
                                 AND    A.SHOP_CD = C.SHOP_CD
                                 AND    A.APP_CUST_CODE = D.CUST_CODE                 
                                 AND    D.USE_GBN       = '1'    -- 고객 해지유무 추가, 2021/05/31                 
                                 AND    A.TEST_GBN = 'N'
                            ";


                Rdata = await db.QuerySingleOrDefaultAsync<BizTalkOrder>(sql, param, commandType: CommandType.Text);

                db.Close();
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/BiztalkHelper/getBizTalkOrder : Get", ex.Message);
                return null;
            }

            return Rdata;
        }


        #region [상품권_도착, daeguro023]
        public static string Biztalk_daeguro023(string recv_name, string send_name)
        {
            //return string.Join(Environment.NewLine, "대구로 상품권이 도착했어요!\n",
            //    $"{recv_name}님!\n",
            //    $"{send_name} 님이 대구로 상품권을",            
            //    "보냈어요.\r\n",
            //    "아래 버튼을 클릭해, 지금 선물 받은",
            //    "상품권을 등록해보세요!\n",
            //    "※ 선물받은 상품권은",
            //    "아래 링크에서 확인하세요.",
            //    "※ 7일간 등록하지 않으면",
            //    $"{send_name}에게 상품권이 환불됩니다.\r\n");            
            return string.Join(Environment.NewLine, "대구로 상품권이 도착했어요!\n",
                $"{recv_name}님!\n",
                $"{send_name} 님이 대구로 상품권을",
                "보냈어요.\r\n",
                "아래 버튼을 클릭해, 지금 선물 받은",
                "상품권을 등록해보세요!\n",
                "※ 선물받은 상품권은",
                "아래 링크에서 확인하세요.",
                "※ 7일간 등록하지 않으면",
                $"{send_name}에게 상품권이 환불됩니다.\r\n");
        }

        public static string Biztalk_50056(string recv_name, string send_name)
        {            
            return string.Join(Environment.NewLine, "대구로 상품권이 도착했어요!\r\n",
                $"{recv_name}님!\r\n",
                $"{send_name} 님이 대구로 상품권을",
                "보냈어요.",
                "아래 버튼을 클릭해, 지금 선물 받은",
                "상품권을 등록해보세요!\r\n",
                "※ 선물받은 상품권은",
                "아래 링크에서 확인하세요.",
                "※ 7일간 등록하지 않으면",
                $"{send_name}에게 상품권이 환불됩니다.");
        }
        #endregion

        #region [음식,밀키트 / 취소(50) / 50036] 
        public static string Biztalk_50036(string cancelReason, string orderTime, string orderNo, string shopName, string menu)
        {
            string message = string.Join(Environment.NewLine, "대구로 주문취소 알림\n",
                 "고객님",
                 "요청 주신 주문 건, 아래의 사유로 취소 처리되었습니다.\n",
                 $"▶취소 사유 : {cancelReason}",
                 $"▶주문 일시 : {orderTime}",
                 $"▶주문 번호 : {orderNo}",
                 $"▶매장 이름 : {shopName}",
                 $"▶메뉴 : {menu}");

            return message;
        }
        #endregion

        #region [상생,전자관,꽃배달 / 취소(50) / 50044] 
        public static string Biztalk_50044(string cancelReason, string orderTime, string orderNo, string shopName, string menu)
        {
            string message = string.Join(Environment.NewLine, "대구로 주문취소 알림\n",
                 "고객님",
                 "요청 주신 주문 건, 아래의 사유로 취소 처리되었습니다.\n",
                 $"▶취소 사유 : {cancelReason}",
                 $"▶주문 일시 : {orderTime}",
                 $"▶주문 번호 : {orderNo}",
                 $"▶매장 이름 : {shopName}",
                 $"▶주문 상품 : {menu}");

            return message;
        }
        #endregion

        #region [배달 / 장보기 / 취소 / 50065] 
        public static string Biztalk_50065(string cancelReason, string orderTime, string orderNo, string menu)
        {
            string result = string.Join(Environment.NewLine, "대구로 주문 취소 알림\n",
                 "고객님",
                 "요청 주신 주문 건,",
                 "아래의 사유로 취소되었음을 안내 드립니다.\n",
                 $"▶취소 사유 : {cancelReason}",
                 $"▶주문 일시 : {orderTime}",
                 $"▶주문 번호 : {orderNo}",
                 $"▶상품 : {menu}");

            Debug.WriteLine(result);

            return result;
        }
        #endregion

    }
}
