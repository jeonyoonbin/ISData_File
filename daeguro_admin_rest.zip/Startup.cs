using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.IO;
using System.Reflection;

namespace DG_App_Rest
{
    public class Startup
    {
        readonly string MyAllowSpecificOrigins = "InsungRestPolicy";

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            
            Utils.oracleConnectString = Configuration.GetConnectionString("IS_DAEGU");            
            Utils.oracleConnectStringTest = Configuration.GetConnectionString("IS_DAEGU_TEST");

            Utils.fcmKey = Configuration["FcmKey:ServerApiKey"];
            Utils.Data_go_kr_Key = Configuration["Data_go_kr:ApiKey"];
            Utils.mallKey = Configuration["Mall:ApiKey"];
            Utils.mallKeyT = Configuration["Mall:ApiKeyT"];
            Utils.posKey = Configuration["Pos:ApiKey"];
            Utils.serverGbn = Configuration["serverGbn"];

            Oracle.ManagedDataAccess.Client.OracleConfiguration.LoadBalancing = false;
            Oracle.ManagedDataAccess.Client.OracleConfiguration.HAEvents = false;

            // DB ù ���� �� ������ ���̱� ���� ����
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            db.Open();
            db.Execute("SELECT SYSDATE FROM DUAL");
            db.Close();
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // CORS ��å �߰�
            services.AddCors(options =>
            {
                options.AddPolicy(name: MyAllowSpecificOrigins,
                                  builder =>
                                  {
                                      builder.AllowAnyOrigin()   // � �ּ��̵� ���
                                            .AllowAnyMethod()  // � �޽���̵� ���
                                            .AllowAnyHeader(); // � ����̵� ���
                                  });
            });

            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "DG_App_Rest", Version = "v1" });

                // XML������� �ּ� ������ swagger�� ������ش�.
                var xmlFilename = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                c.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFilename));

                // ��Ʈ�ѷ� ������ ���� SwaggerTag ������̼��� ����ϱ� ���� �߰�
                c.EnableAnnotations();
            });

            // JWT ����
            services.Configure<JwtConfig>(Configuration.GetSection("JwtConfig"));

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(JWT =>
            {
                var key = System.Text.Encoding.ASCII.GetBytes(Configuration["JwtConfig:Secret"]);

                JWT.SaveToken = true;
                JWT.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ValidateLifetime = true,
                    RequireExpirationTime = true,
                    ClockSkew = System.TimeSpan.Zero    // �� �ɼ��� �޾ƾ� expiration�� ����ȴ�.
                };
            });

            services.AddSignalR();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //    app.UseSwagger();
            //    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "DG_App_Rest v1"));
            //}

            app.UseDeveloperExceptionPage();
            app.UseSwagger();

            // Debug
            //app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "DG_App_Rest v1"));

            // Release
            app.UseSwaggerUI(c => c.SwaggerEndpoint("/api/swagger/v1/swagger.json", "DG_App_Rest v1"));

            // ���� �߰��� CORS��å�� ��������� �����Ѵ�.
            app.UseCors(MyAllowSpecificOrigins);

            //app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHub<Socket>("/socket");
            });

        }
    }
}
