﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class AddFile
    {
        public string kind { get; set; }
        public string fileName { get; set; }
    }
}
