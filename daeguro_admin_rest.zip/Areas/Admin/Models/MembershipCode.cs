﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class MembershipCode
    {
        public string mCode { get; set; }
        public string mName { get; set; }
    }
}
