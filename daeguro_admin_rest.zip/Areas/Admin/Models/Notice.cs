﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class Notice
    {
        public string noticeSeq { get; set; }
        public string noticeType { get; set; }
        public string noticeGbn { get; set; }
        public string systemGbn { get; set; }
        public string systemGbnM { get; set; }
        public string dispGbn { get; set; }
        public string dispFromDate { get; set; }
        public string dispToDate { get; set; }
        public string dispFromTimeH { get; set; }
        public string dispFromTimeM { get; set; }
        public string dispToTimeH{ get; set; }
        public string dispToTimeM { get; set; }
        [MaxLength(400)]
        public string noticeTitle { get; set; }
        [MaxLength(4000)]
        public string noticeContents { get; set; }
        public string extUrlYn { get; set; }
        /// <summary>
        /// get only
        /// </summary>
        public string noticeUrl_1 { get; set; }
        public string noticeUrl_2 { get; set; }
        public string hit { get; set; }

        public string connect_gbn { get; set; }
        public string boardseq { get; set; }
        /// <summary>
        /// get only
        /// </summary>
        public string orderDate { get; set; }
        /// <summary>
        /// get only
        /// </summary>
        public string insDate { get; set; }
        /// <summary>
        /// post only
        /// </summary>
        public string insUCode { get; set; }
        /// <summary>
        /// post only
        /// </summary>
        public string insName { get; set; }
        /// <summary>
        /// get only
        /// </summary>
        public string modDate { get; set; }
        /// <summary>
        /// put only
        /// </summary>
        public string modUCode { get; set; }
        /// <summary>
        /// put only
        /// </summary>
        public string modName { get; set; }

    }

    public class NoticeList
    {
        public string notice_seq { get; set; }
        public string notice_type { get; set; }
        public string notice_gbn { get; set; }
        public string notice_title { get; set; }
        public string disp_fr_date { get; set; }
        public string disp_to_date { get; set; }
    }
}
