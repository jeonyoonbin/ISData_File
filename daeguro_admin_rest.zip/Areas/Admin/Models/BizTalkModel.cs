﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class LunaBiztalkModel
    {
        public LunaBiztalkContetns message { get; set; }
        public string template_id { get; set; }
    }

    public class LunaBiztalkContetns
    {
        public string no { get; set; }
        public string tel_num { get; set; }
        public string reserve_time { get; set; }
        public string custom_key { get; set; }
        public string msg_content { get; set; }
        public string sms_content { get; set; }
        public string use_sms { get; set; }
        public string app_user_id { get; set; }
        public string price { get; set; }
        public string currency_code { get; set; }
        public List<LunaBiztalkBtn> btn_url { get; set; }
    }

    public class LunaBiztalkBtn
    {
        public string url_pc { get; set; }
        public string url_mobile { get; set; }
        public string scheme_ios { get; set; }
        public string scheme_android { get; set; }
    }


    [DataContract]
    public class ResultData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "msg")]
        public ResultMessage msg { get; set; }

        public ResultData()
        {
            msg = new ResultMessage();
        }
    }

    public class ResultMessage
    {
        public string userid { get; set; }
        public string requested_at { get; set; }

        public List<ResultDetailMessage> messages { get; set; }

        public ResultMessage()
        {
            messages = new List<ResultDetailMessage>();
        }
    }

    public class ResultDetailMessage
    {
        public string no { get; set; }
        public string tel_num { get; set; }
        public string result_code { get; set; }
        public string result_msg { get; set; }

    }
}
