﻿using System.Collections.Generic;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class BussRegNoResult
    {
        public string code { get; set; }
        public string msg { get; set; }
        public string status_code { get; set; }
        public int match_cnt { get; set; }
        public int request_cnt { get; set; }
        public List<BussRegNoResultDetail> data { get; set; }
    }

    public class BussRegNoResultDetail
    {
        public string b_no { get; set; }
        public string b_stt { get; set; }
        public string b_stt_cd { get; set; }
        public string tax_type { get; set; }
        public string tax_type_cd { get; set; }
        public string end_dt { get; set; }
        public string utcc_yn { get; set; }
        public string tax_type_change_dt { get; set; }
        public string invoice_apply_dt { get; set; }
    }
}
