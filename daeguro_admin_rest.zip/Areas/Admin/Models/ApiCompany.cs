﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ApiCompany
    {
        public string seq { get; set; }
        public string comType { get; set; }
        public string comGbn { get; set; }
        public string comName { get; set; }
        public string comToken { get; set; }
        public string comAuth { get; set; }
        public string userCode { get; set; }
        public string userName { get; set; }
    }
}
