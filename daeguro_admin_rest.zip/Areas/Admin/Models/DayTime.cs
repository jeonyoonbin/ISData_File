﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class DayTime
    {
        public string tipDay { get; set; }
        public string tipFrStand { get; set; }
        public string tipToStand { get; set; }
        public string tipNextDay { get; set; }
    }
}
