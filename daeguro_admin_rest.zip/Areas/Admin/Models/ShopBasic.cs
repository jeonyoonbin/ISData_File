﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    #region[가맹점 기본정보]
    public class ShopBasic
    {
        public string shopCd { get; set; }
        public string mCode { get; set; }
        public string ccCode { get; set; }
        public string serviceGbn { get; set; }
        public string franchiseCd { get; set; }
        public string sEtcGbn6 { get; set; }
        public string shopName { get; set; }
        public string telNo { get; set; }
        public string regNo { get; set; }
        public string email { get; set; }
        public string useGbn { get; set; }
        public string owner { get; set; }
        public string bussOwner { get; set; }
        public string bussAddr { get; set; }
        public string mobile { get; set; }
        public string addr1 { get; set; }
        public string addr2 { get; set; }
        public string zipCode { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
        public string sidoName { get; set; }
        public string gunguName { get; set; }
        public string dongName { get; set; }
        public string destJibun { get; set; }
        public string roadDestDong { get; set; }
        public string roadDestAddr { get; set; }
        public string roadDestBuilding { get; set; }
        public string loc { get; set; }
        public string pos_road { get; set; }// pos_only
        public string pos_hdong { get; set; }// pos_only
        public string pos_bdong { get; set; }// pos_only
        public string pos_ri { get; set; }// pos_only
        public string memo { get; set; }
        public string shopId { get; set; }
        public string shopPass { get; set; }
        public string bussShopname { get; set; }
        public string bussCon { get; set; }
        public string bussType { get; set; }
        public string bussTaxType { get; set; }
        public string modUCode { get; set; }
        public string modName { get; set; }
        public string salesmanCode { get; set; }
        public string salesmanName { get; set; }
        public string operatorCode { get; set; }
        public string operatorName { get; set; }
        public string apiComCode { get; set; }
        public string contractEndDt { get; set; }
        public string mobileChgCnt { get; set; }
        public string sEtcGbn5 { get; set; } // 종사업장번호
        public string licenseNo { get; set; } // 인허가번호

    }

    public class GetShopBasic
    {
        public string shopCd { get; set; }
        public string mCode { get; set; }
        public string ccCode { get; set; }
        public string serviceGbn { get; set; }
        public string franchiseCd { get; set; }
        public string sEtcGbn6 { get; set; }
        public string shopName { get; set; }
        public string telNo { get; set; }
        public string regNo { get; set; }
        public string email { get; set; }
        public string useGbn { get; set; }
        public string owner { get; set; }
        public string bussOwner { get; set; }
        public string bussAddr { get; set; }
        public string mobile { get; set; }
        public string addr1 { get; set; }
        public string addr2 { get; set; }
        public string zipCode { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
        public string sidoName { get; set; }
        public string gunguName { get; set; }
        public string dongName { get; set; }
        public string destJibun { get; set; }
        public string roadDestDong { get; set; }
        public string roadDestAddr { get; set; }
        public string roadDestBuilding { get; set; }
        public string loc { get; set; }
        public string pos_road { get; set; }// pos_only
        public string pos_hdong { get; set; }// pos_only
        public string pos_bdong { get; set; }// pos_only
        public string pos_ri { get; set; }// pos_only
        public string memo { get; set; }
        public string shopId { get; set; }
        public string shopPass { get; set; }
        public string bussShopname { get; set; }
        public string bussCon { get; set; }
        public string bussType { get; set; }
        public string bussTaxType { get; set; }
        public string modUCode { get; set; }
        public string modName { get; set; }
        public string salesmanCode { get; set; }
        public string salesmanName { get; set; }
        public string operatorCode { get; set; }
        public string operatorName { get; set; }
        public string apiComCode { get; set; }
        public string contractEndDt { get; set; }
        public string mobileChgCnt { get; set; }
        public string sEtcGbn5 { get; set; } // 종사업장번호
        public string licenseNo { get; set; } // 인허가번호
        public string taxpayerStatus { get; set; } // 납세자상태
        public string taxationType { get; set; } // 과세유형

    }
    #endregion[가맹점 기본정보]

    #region[POS 가맹점]
    public class PosShop
    {
        public string app_name { get; set; }
        public string app_type { get; set; }
        public PosShopInfo shop_info { get; set; }
    }

    public class PosShopInfo
    {
        public string job_gbn { get; set; }
        public string use_gbn { get; set; }
        public string login_id { get; set; }
        public string login_pw { get; set; } 
        public string shop_name { get; set; }
        public string shop_manage { get; set; } //관리자 패스워드
        public string address { get; set; }
        public string address_detail { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string bdong { get; set; }
        public string hdong { get; set; }
        public string ri { get; set; }
        public string road { get; set; }
        public double lon { get; set; }
        public double lat { get; set; }
        public string telno { get; set; }
        public string mobile { get; set; }
        public string reg_no { get; set; }
        public string owner { get; set; }
        public string zone_code { get; set; }
        public string mod_ucode { get; set; }
        public string account_owner { get; set; }
        public string account_no { get; set; }
        public string account_bankcode { get; set; }
        public string is_fooddelivery { get; set; }
        public string is_reserve { get; set; }
        public string is_flower { get; set; }
        public string shop_token { get; set; } // POS 연동코드(매핑코드)
        public string shop_mac { get; set; }
    }

    public class PosShopResult
    {
        public string shop_token { get; set; }
        public PosShopInfoResult pos_shop_info { get; set; }
        public int code { get; set; }
        public string message { get; set; }
    }

    public class PosShopInfoResult
    {
        public string gubun { get; set; }
        public string mcode { get; set; }
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string use_gbn { get; set; }
        public string login_id { get; set; }
        public string shop_name { get; set; }
        public string address { get; set; }
        public string address_detail { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string bdong { get; set; }
        public string hdong { get; set; }
        public string ri { get; set; }
        public string road { get; set; }
        public double lon { get; set; }
        public double lat { get; set; }
        public string telno { get; set; }
        public string mobile { get; set; }
        public string reg_no { get; set; }
        public string owner { get; set; }
        public string zone_code { get; set; }
        public string mod_ucode { get; set; }
    }
    #endregion[POS 가맹점]
}
