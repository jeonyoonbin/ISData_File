﻿using System.Collections.Generic;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class BussRegNo
    {
        public List<string> b_no { get; set; }
    }
}
