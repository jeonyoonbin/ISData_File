﻿namespace DG_App_Rest.Areas.Admin.Models
{    
    public class ShopNotUse
    {
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string shop_status { get; set; }
        public string reg_no { get; set; }
        public string remain_amt { get; set; }
        public string taxpayer_status { get; set; }
        public string taxation_type { get; set; }
        public string closure_dt { get; set; }        
        public string tot_cnt { get; set; }        
        public string comp_cnt { get; set; }        
        public string cancel_cnt { get; set; }        
        public string service_gbn { get; set; }        
        public string shop_type { get; set; }        
        public string open_dt { get; set; }        
        public string absent_yn { get; set; }        
    }
}
