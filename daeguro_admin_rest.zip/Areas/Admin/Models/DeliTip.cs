﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class DeliTip
    {
        public string shopCd { get; set; }
        public string tipSeq { get; set; }
        public string tipDay { get; set; }
        public string tipGbn { get; set; }
        public string tipFromStand { get; set; }
        public string tipNextDay { get; set; }
        public string tipToStand { get; set; }
        public string appOrderyn { get; set; }
        public string useGbn { get; set; }
        public string happyPayUseGbn { get; set; }
        public string tipAmt { get; set; }
        public string tipAmtRate { get; set; }
        public string closedLogin { get; set; }
        public string supportFund { get; set; }
        public string reserveYn { get; set; }
        public string autoCancelGbn { get; set; }
        //public string autoCompYn { get; set; }
        public string autoCompType { get; set; }
        public string autoCompTerm { get; set; }
        public string autoCancelType { get; set; }
        public string autoCancelTerm { get; set; }
        public string pushGbn { get; set; }
        public string kakaoBiztalkGbn { get; set; }
        public string mall_use_gbn { get; set; }

        public string kind_shop_status { get; set; }
        public string kind_shop_answer { get; set; }
        public string kind_shop_memo { get; set; }
        public string youtube_url { get; set; }
        public string child_meal_yn { get; set; }
        public string child_meal_cd { get; set; }
        public string min_amt_pass { get; set; }
        
        public string modUCode { get; set; }
        public string modName { get; set; }
    }

    //가맹점 반품/교환, 교환 및 환불 불가 안내
    public class ERRNotice
    {
        public string shopCd { get; set; }
        public string exchange_notice { get; set; }
        public string return_notice { get; set; }
        public string reject_notice { get; set; }

        public string modUCode { get; set; }
        public string modName { get; set; }
    }
}
