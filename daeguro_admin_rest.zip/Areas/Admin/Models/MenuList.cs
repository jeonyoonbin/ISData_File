﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class MenuList
    {
        public string menuCd { get; set; }
        public string Name { get; set; }
        public string cost { get; set; }
        public string fileName { get; set; }
        public string multiCnt { get; set; }
        public string aloneOrderYn { get; set; }
        public string mainMenuYn { get; set; }
        public string useGbn { get; set; }
        public string noFlag { get; set; }
        public string adultOnly { get; set; }
        public string singleOrderYn { get; set; }
        public string menuEventYn { get; set; }
        //public string discYn { get; set; }
        //public string discRatio { get; set; }
        //public string amount { get; set; }
    }

    public class MenuMultiList
    {
        public string seq { get; set; }
        public string file_name { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }
}
