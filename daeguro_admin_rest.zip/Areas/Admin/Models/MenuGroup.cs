﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class MenuGroup
    {
        public string shopCd { get; set; }
        public string menuGroupCd { get; set; }
        public string menuGroupName { get; set; }
        public string menuGroupMemo { get; set; }
        public string useYn { get; set; }
        public string optionYn { get; set; }
        public string mainImageYn { get; set; }
        public string sortSeq { get; set; }
        public string groupFileName { get; set; }
        public string insertName { get; set; }
    }
}
