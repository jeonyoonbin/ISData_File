﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class CouponHistory
    {
        public string SeqNo { get; set; }
        public string couponType { get; set; }
        public string couponNo { get; set; }
        public string histDate { get; set; }
        public string memo { get; set; }
    }
}
