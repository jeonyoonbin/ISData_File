﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class BizTalkOrder
    {
        public string ORDER_NO { get; set; }            // 오더번호
        public string STATUS { get; set; }              // 오더상태
        public string SHOP_NAME { get; set; }           // 상점명
        public string DEST_TELNO { get; set; }          // 도착지 전화번호  
        public string MENU_NAME { get; set; }           // 주문메뉴
        public string ORDER_TIME { get; set; }          // 주문일시
        public string CANCEL_REASON { get; set; }       // 취소사유
        public string SHOP_CD { get; set; }             // 상점코드
        public string SYSTEM_GBN { get; set; }             // 주문구분
        public string ITEM_CD { get; set; }             // 카테고리1
    }

}
