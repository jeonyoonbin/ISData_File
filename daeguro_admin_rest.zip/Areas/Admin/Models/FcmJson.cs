﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class FcmJson
    {
        [JsonProperty(PropertyName = "registration_ids")]
        public List<string> registration_ids { get; set; }

        [JsonProperty(PropertyName = "priority")]
        public string priority { get; set; }

        [JsonProperty(PropertyName = "content_available")]
        public bool content_available { get; set; }

        [JsonProperty(PropertyName = "notification")]
        public Notification notification { get; set; }

        [JsonProperty(PropertyName = "direct_boot_ok")]
        public bool direct_boot_ok { get; set; }

        [JsonProperty(PropertyName = "data")]
        public Data data { get; set; }

        public FcmJson()
        {
            data = new Data();
            notification = new Notification();
        }
    }

    [DataContract]
    public class Notification
    {
        [JsonProperty(PropertyName = "body")]
        public string body { get; set; }

        [JsonProperty(PropertyName = "title")]
        public string title { get; set; }
    }

    [DataContract]
    public class Data
    {
        [JsonProperty(PropertyName = "daeguro")]
        public Default defaultJ { get; set; }


        //아이폰용
        [JsonProperty(PropertyName = "body")]
        public Iphone iphone { get; set; }

        public Data()
        {
            defaultJ = new Default();
            iphone = new Iphone();
        }
    }

    [DataContract]
    public class Default
    {
        [JsonProperty(PropertyName = "project")]
        public string project { get; set; } // 서비스구분(DELIVERY)

        [JsonProperty(PropertyName = "channelId")]
        public string channelId { get; set; } // 

        [JsonProperty(PropertyName = "channelName")]
        public string channelName { get; set; } // 서비스구분

        [JsonProperty(PropertyName = "contentTitle")]
        public string contentTitle { get; set; } // fcm 제목

        [JsonProperty(PropertyName = "contentText")]
        public string contentText { get; set; } // fcm 내용

        [JsonProperty(PropertyName = "pushSeq")]
        public string pushSeq { get; set; } // 푸시번호

        [JsonProperty(PropertyName = "deliveryData")]
        public PushMessage pushMessage { get; set; }

        [JsonProperty(PropertyName = "flowerData")]
        public PushMessage pushFlowerMessage { get; set; }

        public Default()
        {
            pushMessage = new PushMessage();
            pushFlowerMessage = new PushMessage();
        }
    }

    [DataContract]
    public class Iphone
    {
        [JsonProperty(PropertyName = "project")]
        public string project { get; set; } // 서비스구분(DELIVERY)

        [JsonProperty(PropertyName = "channelId")]
        public string channelId { get; set; } // 

        [JsonProperty(PropertyName = "channelName")]
        public string channelName { get; set; } // 서비스구분

        [JsonProperty(PropertyName = "contentTitle")]
        public string contentTitle { get; set; } // fcm 제목

        [JsonProperty(PropertyName = "contentText")]
        public string contentText { get; set; } // fcm 내용

        [JsonProperty(PropertyName = "pushSeq")]
        public string pushSeq { get; set; } // 푸시번호

        [JsonProperty(PropertyName = "deliveryData")]
        public PushMessage pushMessage { get; set; }

        [JsonProperty(PropertyName = "flowerData")]
        public PushMessage pushFlowerMessage { get; set; }

        public Iphone()
        {
            pushMessage = new PushMessage();
            pushFlowerMessage = new PushMessage();
        }
    }

    public class PushMessage
    {
        [JsonProperty(PropertyName = "pushSeq")]
        public string pushSeq { get; set; } // 푸시번호

        [JsonProperty(PropertyName = "pushTitle")]
        public string pushTitle { get; set; } // 푸쉬 종류

        [JsonProperty(PropertyName = "pushMsg")]
        public string pushMsg { get; set; } // 푸쉬내용

        [JsonProperty(PropertyName = "boardSeq")]
        public string boardSeq { get; set; } // 푸시번호

        [JsonProperty(PropertyName = "shopCode")]
        public string shopCode { get; set; } // 가맹점 코드

        [JsonProperty(PropertyName = "pushGbn")]
        public string pushGbn { get; set; } // 푸쉬ID
        [JsonProperty(PropertyName = "tabCode")]
        public string tabCode { get; set; } // 탭 코드
        [JsonProperty(PropertyName = "imageUrl")]
        public string imageUrl { get; set; } // 푸쉬ID

    }
}
