﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ClassList
    {
        public string class_gbn { get; set; }
        public string name { get; set; }
        public string base_gbn { get; set; }
        public string sort_seq { get; set; }
    }

    #region[상품 카테고리]
    public class ProdCatList
    {
        public string class_gbn { get; set; }
        public string cat_code { get; set; }
        public string name { get; set; }
        public string use_gbn { get; set; }
        public string sort_seq { get; set; }
    }

    public class ProdCat
    {
        public string class_gbn { get; set; }
        public string cat_code { get; set; }
        public string name { get; set; }
        public string use_gbn { get; set; }
        public string test_yn { get; set; }
        public string img { get; set; }
        public string memo { get; set; }
    }

    public class ProdCatPost
    {
        public string class_gbn { get; set; }
        public string name { get; set; }
        public string ucode { get; set; }
    }

    public class ProdCatPut
    {
        public string cat_code { get; set; }
        public string name { get; set; }
        public string use_gbn { get; set; }
        public string test_yn { get; set; }
        public string memo { get; set; }
        public string ucode { get; set; }
    }
    #endregion[상품 카테고리]

    #region[장보기 상품 카테고리]
    public class BundleCatList
    {
        public string class_gbn { get; set; }
        public string m_shop_cd { get; set; }
        public string cat_code { get; set; }
        public string name { get; set; }
        public string use_gbn { get; set; }
        public string sort_seq { get; set; }
    }

    public class BundleCatPost
    {
        public string m_shop_cd { get; set; }
        public string name { get; set; }
        public string ucode { get; set; }
    }

    public class BundleCatPut
    {
        public string m_shop_cd { get; set; }
        public string cat_code { get; set; }
        public string name { get; set; }
        public string use_gbn { get; set; }
        public string ucode { get; set; }
    }
    #endregion[장보기 상품 카테고리]

    #region[상품 테마]
    public class ProdThemaList
    {
        public string class_gbn { get; set; }
        public string thema_code { get; set; }
        public string name { get; set; }
        public string use_gbn { get; set; }
        public string sort_seq { get; set; }
    }

    public class ProdThema
    {
        public string class_gbn { get; set; }
        public string thema_code { get; set; }
        public string name { get; set; }
        public string use_gbn { get; set; }
        public string test_yn { get; set; }
        public string img { get; set; }
        public string memo { get; set; }
    }

    public class ProdThemaPut
    {
        public string thema_code { get; set; }
        public string name { get; set; }
        public string use_gbn { get; set; }
        public string test_yn { get; set; }
        public string memo { get; set; }
        public string ucode { get; set; }
    }
    #endregion[상품 테마]
}
