﻿namespace DG_App_Rest.Areas.Admin.Models
{
    public class BasicLog
    {
        public string memo { get; set; }
        public string hist_date { get; set; }
    }
}
