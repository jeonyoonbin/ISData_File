﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ChainCode
    {
        public string chainName { get; set; }
        public string chainColor { get; set; }
        public string useGbn { get; set; }
        public string testYn { get; set; }
        public string UCode { get; set; }
        public string UName { get; set; }
    }
}
