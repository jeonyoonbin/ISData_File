﻿namespace DG_App_Rest.Areas.Admin.Models
{
    public class ShopCouponItem
    {
        public string apply_min_amt { get; set; }
        public string coupon_amt { get; set; }
        public string pub { get; set; }
        public string use { get; set; }
    }
}
