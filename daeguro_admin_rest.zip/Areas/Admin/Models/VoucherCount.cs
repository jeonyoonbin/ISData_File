﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class VoucherCount
    {
        public string not_use { get; set; }
        public string use { get; set; }
        public string clear { get; set; }
        public string exp { get; set; }
    }
}
