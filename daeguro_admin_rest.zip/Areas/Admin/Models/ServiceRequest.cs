﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ServiceRequestExcel
    {
        public string seq { get; set; }
        public string status { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string insert_date { get; set; }
        public string service_gbn { get; set; }
        public string service_type { get; set; }
        public string comp_tm { get; set; }
        public string cancel_tm { get; set; }
        public string alloc_uname { get; set; }
        public string worker_name { get; set; }
        public string memo { get; set; }
        public string answer_text { get; set; }
    }
}
