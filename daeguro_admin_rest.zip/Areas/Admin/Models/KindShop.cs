﻿using System.Collections.Generic;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class KindShop
    {
        public string shop_name { get; set; }
        public string shop_cd { get; set; }
        public string kind_shop_status { get; set; }
        public string kind_shop_cancel_dt { get; set; }
        public string kind_shop_memo { get; set; }
        public string use_gbn { get; set; }
        public string absent_yn { get; set; }
        public string insert_date { get; set; }
        public string comp_date { get; set; }
        public string pos_install { get; set; }
        public string pos_login { get; set; }
        public string alloc_ucode { get; set; }
        public string alloc_uname { get; set; }
    }

    public class KindShopHist
    {        
        public string hist_date { get; set; }
        public string memo { get; set; }
    }
}
