﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class FoodSafety
    {
        public string code { get; set; }
        public string nutrition { get; set; }
        public string allergy { get; set; }
        public string modUcode { get; set; }
        public string modName { get; set; }
    }
}
