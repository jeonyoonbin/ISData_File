﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ItemList
    {
        public string code { get; set; }
        public string nameMain { get; set; }
        public string name { get; set; }
        public int sortSeq { get; set; }
    }

    public class MainTemaPost
    {
        public string mainName { get; set; }
        public string name { get; set; }
        public string useGbn { get; set; }
        public string mainVisibleGbn { get; set; }
        public string gunguUseGbn { get; set; }
        public string memo { get; set; }
    }

    public class SubTema
    {
        public string temaCode { get; set; }
        public string subTemaCode { get; set; }
        public string temaName { get; set; }
        public string sido { get; set; }
        public string gungu { get; set; }
        public string temaMemo { get; set; }
        public string useGbn { get; set; }        
        public string openYn { get; set; }        
        public string testYn { get; set; }        
        public int sortSeq { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
        public string url { get; set; }
        public string addr { get; set; }
        public string memo { get; set; }
    }

    // 앱에서 쓰는 이름으로 변경
    public class SubTemaApp 
    {
        public string groupCode { get; set; }
        public string code { get; set; }
        public string name { get; set; }
        //public string sido { get; set; }
        //public string gungu { get; set; }
        public string memo { get; set; }
        //public string useGbn { get; set; }
        //public int sortSeq { get; set; }
        public string url { get; set; }
        //public double lon { get; set; }
        //public double lat { get; set; }
        //public string addr { get; set; }
        //public int distanceMeter { get; set; } //거리
        public dynamic address { get; set; }
    }

    public class SubTemaPost
    {
        public string temaName { get; set; }
        public string sido { get; set; }
        public string gungu { get; set; }
        public string temaMemo { get; set; }
        public string useGbn { get; set; }
        public string openYn { get; set; }
        public string testYn { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
        public string addr { get; set; }
        public string memo { get; set; }
    }

    public class SubTemaShopList
    {
        public string shopName { get; set; }
        public string shopCd { get; set; }
        public string regNo { get; set; }
        public string addr1 { get; set; }
        public string addr2 { get; set; }
    }

    public class SubTemaShop
    {
        public string gbn { get; set; }
        public string temaCode { get; set; }
        public string subTemaCode { get; set; }
        public string temaName { get; set; }
    }

    public class TemaHist
    {
        public string memo { get; set; }
        public string histDate { get; set; }
    }
}
