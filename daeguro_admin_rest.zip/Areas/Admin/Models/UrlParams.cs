﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class UrlParams
    {
        List<KeyValuePair<string, string>> urlParams = new List<KeyValuePair<string, string>>();
        private string separator = "";
        private string builder = "?";

        public void AddParams(string key, string value)
        {
            urlParams.Add(new KeyValuePair<string, string>(key, value));
        }
        public string ToUrl()
        {
            StringBuilder sb = new StringBuilder(builder);
            foreach (var item in urlParams.Where(p => p.Value != null))
            {
                sb.AppendFormat($"{separator}{item.Key}={item.Value}");
                separator = "&";
            }

            return sb.ToString();
        }
    }
}
