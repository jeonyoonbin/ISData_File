﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ChildMealDup
    {
        public string seq { get; set; }
        public string ins_date { get; set; }
        public string reg_no { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string child_meal_yn { get; set; }
        public string child_meal_cd { get; set; }
        //public string sh_child_meal_cd { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class SetChildMeal
    {
        public string reg_no { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string child_meal_yn { get; set; }
        public string child_meal_cd { get; set; }
        public string mod_ucode { get; set; }
    }

    #region[신한연동]
    public class SHChildMealYn
    {
        public SHCommonHead COMMON_HEAD { get; set; }
        public SHChildMealYnReq REQ_REC { get; set; }
    }

    public class SHChildMealYnResult
    {
        public SHCommonHeadResult COMMON_HEAD { get; set; }
        public SHChildMealYnRep REP_REC { get; set; }
    }

    public class SHCommonHead
    {
        public string AGENCY_CD { get; set; }
    }

    public class SHCommonHeadResult
    {
        public string CODE { get; set; }
        public string MSG { get; set; }
        public string ERROR { get; set; }
    }

    public class SHChildMealYnReq
    {
        public string CHECK_DT { get; set; }
        public string MCHT_NO { get; set; }
        public string BRNO { get; set; }
        public string MCHT_NM { get; set; }
        public string DRO_LINK_YN { get; set; }
    }

    public class SHChildMealYnRep
    {
        public string CHECK_DT { get; set; }
        public string MCHT_NO { get; set; }
        public string BRNO { get; set; }
        public string MCHT_NM { get; set; }
        public string MSG { get; set; }
        public string ERROR { get; set; }
    }
    #endregion[신한연동]
}
