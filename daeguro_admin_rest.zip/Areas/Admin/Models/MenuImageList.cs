﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class MenuImageList
    {
        public string menuImageCd { get; set; }
        public string menuName { get; set; }
        public string fileName { get; set; }
        public string insertDate { get; set; }
    }
}
