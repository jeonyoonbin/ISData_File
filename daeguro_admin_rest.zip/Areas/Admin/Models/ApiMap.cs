﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ApiMap
    {
        public string shopCd { get; set; }
        public string ccCode { get; set; }
        public string shopName { get; set; }
        public string shopMapSeq { get; set; }
        public string apiUseYn { get; set; }
        public string apiType { get; set; }
        public string apiComGbn { get; set; }
        public string apiComCode { get; set; }
        public string apiComCode2 { get; set; }
        public string apiComToken { get; set; }
        public string apiComAuth { get; set; }
        public string apiComId { get; set; }
        public string apiComPass { get; set; }
        public string apiDailyToken { get; set; }
        public string apiMemo { get; set; }
        public string userCode { get; set; }
        public string userName { get; set; }
    }
}
