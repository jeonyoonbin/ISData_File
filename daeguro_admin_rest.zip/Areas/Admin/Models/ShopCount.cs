﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ShopCount
    {
        public string imageStatus_0 { get; set; }
        public string imageStatus_1 { get; set; }
        public string imageStatus_2 { get; set; }
        public string imageStatus_3 { get; set; }
        public string imageStatus_4 { get; set; }
        public string totalShopCount { get; set; }
        public string newShopCount { get; set; }
        public string useShopCount { get; set; }
        public string stopShopCount { get; set; }
    }

    public class ShopCount2
    {
        public string shopTypeGbn { get; set; }
        public string totalShopCount { get; set; }
        public string newShopCount { get; set; }
        public string useShopCount { get; set; }
        public string stopShopCount { get; set; }
        public string totalShopCountR { get; set; }
        public string newShopCountR { get; set; }
        public string useShopCountR { get; set; }
        public string stopShopCountR { get; set; }
    }
}
