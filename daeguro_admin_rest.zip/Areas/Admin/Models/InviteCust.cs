﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class InviteCust
    {
        public string my_referral_code { get; set; }
        public string cust_code { get; set; }
        public string cust_name { get; set; }
        public string telno { get; set; }
        public string ins_date { get; set; }
    }
}
