﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class SubContents
    {
        public string seq { get; set; }
        public string contents_cd { get; set; }
        public string sort_seq { get; set; }
        public string ep_title { get; set; }
        public string disp_gbn { get; set; }
        public string contents_url { get; set; }
        public string thumbnail_url { get; set; }
        public string ins_ucode { get; set; }
        public string mod_ucode { get; set; }
    }
}
