﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class OrderDetail
    {
        public string serviceGbn { get; set; }               // 서비스 구분
        public string addr1 { get; set; }               // 구주소
        public string addr2 { get; set; }               // 신주소
        public string loc { get; set; }                 // 상세 주소
        public string custName { get; set; }         // 고객 성함
        public string telNo { get; set; }            // 고객 전화
        public string senderName { get; set; }       // 보내는분 성함
        public string senderTelno { get; set; }      // 보내는분 전화
        public string receiverName { get; set; }     // 받으시는분 성함
        public string receiverTelno { get; set; }    // 받으시는분 전화
        public string reserDate { get; set; }        // 배송예약일시
        public string shopCd { get; set; }            // 가맹점코드
        public string shopName { get; set; }            // 가맹점명
        public string regNo { get; set; }               // 사업자등록번호
        public string shopAddr { get; set; }            // 가맹점 주소
        public string shopLoc { get; set; }             // 가맹점 상세주소
        public string orderNo { get; set; }             // 주문번호
        public string menuDesc { get; set; }            // 메뉴 내역
        public string deliTipAmt { get; set; }          // 배달팁
        public string menuAmt { get; set; }             // 총주문 금액
        public string couponName { get; set; }          // 쿠폰명
        public string couponNo { get; set; }            // 쿠폰번호
        public string couponAmt { get; set; }           // 쿠폰사용금액
        public string couponName2 { get; set; }          //브랜드 쿠폰명
        public string couponNo2 { get; set; }            //브랜드 쿠폰번호
        public string couponAmt2 { get; set; }           //브랜드 쿠폰사용금액
        public string shopCouponNo { get; set; }          //가맹점 자체쿠폰번호
        public string shopCouponAmt { get; set; }         //가맹점 자체쿠폰사용금액
        public string voucherNo { get; set; }             //모바일 상품권번호
        public string voucherUseAmt { get; set; }         //모바일 상품권사용금액
        public string mileage { get; set; }             // 마일리지
        public string eventDisc { get; set; }           // 이벤트 할인
        public string beforeAmount { get; set; }        // 행복페이 적용전 금액
        public string amount { get; set; }              // 결제금액
        public string cardName { get; set; }            // 카드명
        public string appNo { get; set; }               // 카드 승인번호
        public string cardNo { get; set; }              // 카드번호
        public string appDate { get; set; }             // 카드 승인일시
        public List<OrderStatusHistory> statusHistories { get; set; }             // 주문 상태변경 이력

        public string orderTime { get; set; }           // 주문 접수시각
        public string shopConfirmTime { get; set; }     // 상점 접수시각
        public string deliAllocTime { get; set; }       // 배달 시작시각
        public string completeTime { get; set; }        // 완료 시각
        public string cancelTime { get; set; }          // 취소 시각

        public string riderDeliMemo { get; set; }             // 배달메모
        public string shopDeliMemo { get; set; }             // 주문메모
        public string appPayGbn { get; set; }             // 현장결제 여부

        public string toGoDiscAmt { get; set; }             // 포장할인 금액

        public string geofenceYn { get; set; }             // 지오펜싱 사용여부
        public string destLon { get; set; }             // 주문자 lon
        public string destLat { get; set; }             // 주문자 lat
        public string item_cd { get; set; }             // 카테고리1
        public string item_cd2 { get; set; }             // 카테고리2
        public string item_cd3 { get; set; }             // 카테고리3

        public string child_meal_disc { get; set; }             // 아동급식카드 할인
        public string installment_yn { get; set; }             // 카드결제 할부 여부
        public string installment_months { get; set; }             // 카드결제 할부 개월 수


    }

    /*
          메뉴금액 60000
          첫주문쿠폰 -5000
          마일리지 -1500 
          배달팁 할인 -2000 EVENT_DISC 10
          ---------------
          합계금액        51500 BEFORE_AMOUNT
          행복페이 5% 할인 3000 EVENT_DISC 20
          ---------------
          결제금액  Amount
    */
}
