﻿namespace DG_App_Rest.Areas.Admin.Models
{
    public class Intro
    {
        public string intro_cd { get; set; }
        public string shop_cd { get; set; }
        public string intro_gbn { get; set; }
        public string use_gbn { get; set; }
        public string file_name_1 { get; set; }
        public string file_name_2 { get; set; }
        public string intro_contents { get; set; }
    }
}
