﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ShopCalc
    {
        public string shopCd { get; set; }
        public string bankCode { get; set; }
        public string accountNo { get; set; }
        public string accOwner { get; set; }
        public string payConfirm { get; set; }
        public string autoWithdrawYn { get; set; }
        public string modUCode { get; set; }
        public string modName { get; set; }
    }
}
