﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class Request
    {
        public string seq { get; set; }
        public string status { get; set; }
        public string alloc_ucode { get; set; }
        public string alloc_uname { get; set; }
        public string worker_ucode { get; set; }
        public string worker_name { get; set; }
        public string answer { get; set; }
        public string memo { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class RequestImg
    {
        public string seq { get; set; }
        public string insert_dt { get; set; }
        public string shop_cd { get; set; }
        public string file_name { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
        public IFormFile formFile { get; set; }
    }
}
