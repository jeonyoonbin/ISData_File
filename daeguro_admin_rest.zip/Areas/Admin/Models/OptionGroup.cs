﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class OptionGroup
    {
        public string selected { get; set; }
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string minCount { get; set; }
        public string maxCount { get; set; }
        public string multiYn { get; set; }
        public string useYn { get; set; }
        public string optionNames { get; set; }
    }

    #region[메뉴옵션그룹에 연결된 메뉴]
    public class MenuLinkedOGroup
    {
        public string selectYn{ get; set; }
        public string menuGroupCd { get; set; }
        public string menuGroupName { get; set; }
        public string menuCd { get; set; }
        public string menuName { get; set; }
        public string menuDesc { get; set; }
        public string menuCost { get; set; }
        //public string useGbn { get; set; }
    }

    public class MenuGroupLinkedOGroup
    {
        public string menuGroupCd { get; set; }
        public string menuGroupName { get; set; }
        public List<MenuLinkedOGroup> list { get; set; }
    }

    //public class MenuLinkedOGroup
    //{
    //    public string menuGroupCd { get; set; }
    //    public string menuCd { get; set; }
    //    public string menuName { get; set; }
    //    public string menuDesc { get; set; }
    //    public string menuCost { get; set; }
    //    public string useGbn { get; set; }
    //    //public string aloneOrder { get; set; }
    //    //public string mainYn { get; set; }
    //    //public string noFlag { get; set; }
    //    //public string adultOnly { get; set; }
    //    //public string multiImgYn { get; set; }
    //}
    #endregion[메뉴옵션그룹에 연결된 메뉴]

}
