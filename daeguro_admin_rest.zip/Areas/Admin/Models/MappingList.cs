﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class MappingList
    {
        public string shopMapSeq { get; set; }
        public string shopName { get; set; }
        public string companyName { get; set; }
    }
}
