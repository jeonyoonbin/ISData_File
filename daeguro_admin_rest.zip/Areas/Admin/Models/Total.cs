﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    #region[가맹점 통계]
    public class ShopOrderCnt
    {
        public string rnum { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string gungu { get; set; }
        public string tot_order_cnt { get; set; }
        public string comp_cnt { get; set; }
        public string cancel_cnt { get; set; }
    }

    public class ShopOrderAmt
    {
        public string rnum { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string gungu { get; set; }
        public string tot_sales_amt { get; set; }
        public string comp_amt { get; set; }
        public string cancel_amt { get; set; }
    }

    public class ShopLastLogin
    {
        public string rnum { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string gungu { get; set; }
        public string last_login { get; set; }
        public string dd { get; set; }
    }

    public class ShopLiveEventCnt
    {
        public string rnum { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string gungu { get; set; }
        public string cnt { get; set; }
    }
    
    public class ShopIntroYn
    {
        public string rnum { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string r_yn { get; set; }
        public string i_yn { get; set; }
    }
    #endregion[가맹점 통계]

    #region[회원 통계]
    public class MemberOrderInfo
    {
        public int cnt { get; set; }
        public int cust_cnt { get; set; }
    }
    #endregion[회원 통계]

    #region[주문 통계]
    public class DailyVmsCall
    {
        public string dt { get; set; }
        public string success_cnt { get; set; }
        public string s_receipt_cnt { get; set; }
        public string s_cancel_cnt { get; set; }
        public string fail_cnt { get; set; }
        public string f_receipt_cnt { get; set; }
        public string f_cancel_cnt { get; set; }
    }
    #endregion[주문 통계]
}
