﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class OrderCancelShop
    {
        public string cccode { get; set; }
        public string shopCd { get; set; }
        public string shopName { get; set; }
        public string shopStatus { get; set; }
        public string telNo { get; set; }
        public string posInstall { get; set; }
        public string posLogin { get; set; }
        public string cancelcnt { get; set; }
        public string absentYn { get; set; }
        public string totalcnt { get; set; }
        public string loginTime { get; set; }
        public string lastCancelTime { get; set; }
    }
}
