﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class OrderDetailMenu
    {
        public string menuName { get; set; }
        public string orderCost { get; set; }
        public string orderQty { get; set; }
        public string orderAmt { get; set; }
    }
}
