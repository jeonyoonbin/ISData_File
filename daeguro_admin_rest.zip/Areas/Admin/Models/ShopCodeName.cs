﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ShopCodeName
    {
        public string ccCode { get; set; }
        public string shopCd { get; set; }
        public string shopName { get; set; }
    }
}
