﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class TosChangeList
    {
        public string change_seq { get; set; }
        public string service_gbn { get; set; }
        public string check_gbn { get; set; }
        public string ins_date { get; set; }
        public string change_contents { get; set; }
        public string memo { get; set; }
    }
}
