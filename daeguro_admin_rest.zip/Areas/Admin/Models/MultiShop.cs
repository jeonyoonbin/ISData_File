﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace DG_App_Rest.Areas.Admin.Models
{

    public class ShopMultiTargetList
    {
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string reg_no { get; set; }
        public string owner { get; set; }
        public string open_dt { get; set; }
        public string reser_req_date { get; set; }
        public string multi_shop_yn { get; set; }
        public string api_com_code { get; set; }
    }
    public class ResultGetMultiShopList
    {
        public string code { get; set; }
        public string msg { get; set; }
        public string count { get; set; }
        public List<ShopMultiList> data { get; set; }
    }

    public class ShopMultiList
    {
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string reg_no { get; set; }
        public string owner { get; set; }
        public string open_dt { get; set; }
        public string reser_req_date { get; set; }
        public string multi_shop_yn { get; set; }
        public string representative_yn { get; set; }
        public string api_com_code { get; set; }
    }

    public class ShopMultiHist
    {
        public string no { get; set; }
        public string hist_date { get; set; }
        public string memo { get; set; }
    }

    #region[POS멀티샵]
    public class PosMultishop
    {
        public string job_gbn { get; set; }
        public string app_name { get; set; }
        public string app_type { get; set; }
        public PosMultishopInfo shop_info { get; set; }
    }

    public class PosMultishopInfo
    {
        public string login_id { get; set; }
        public string login_pw { get; set; }
        public string use_gbn { get; set; }
        public string bigo { get; set; }
        public List<string> b2b_mapping_list { get; set; }
    }

    public class PosResultBasic
    {
        public int code { get; set; }
        public string message { get; set; }
    }
    #endregion[POS멀티샵]

    #region[가맹점 카피]
    public class NewMultiShop
    {
        public string mcode { get; set; }
        public string rep_shop_cd { get; set; }
        public string shop_name { get; set; }
        public string api_com_code { get; set; }
        public string copy_calc { get; set; }
        public string copy_info { get; set; }
        public string copy_sector { get; set; }
        public string copy_deli_tip { get; set; }
        public string copy_day_time { get; set; }
        public string copy_menu { get; set; }
        public string ucode { get; set; }
    }
    #endregion[가맹점 카피]
}
