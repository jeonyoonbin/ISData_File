﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ShopCouponList
    {
        public string rnum { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string apply_gbn { get; set; }
        public string display_st_date { get; set; }
        public string display_end_date { get; set; }
        public string status { get; set; }
        public string use_gbn { get; set; }
        public string coupon_type { get; set; }
        public string coupon_name { get; set; }
        public string ins_date { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_name { get; set; }
    }
}

