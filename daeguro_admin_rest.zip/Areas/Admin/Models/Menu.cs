﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class Menu
    {
        public string menuCd { get; set; }
        public string menuName { get; set; }
        public string menuGroupCd { get; set; }
        public string menuCost { get; set; }
        public string menuDesc { get; set; }
        public string useYn { get; set; }
        public string aloneOrder { get; set; }
        public string mainYn { get; set; }
        public string noFlag { get; set; }
        public string adultOnly { get; set; }
        public string multiImgYn { get; set; }
        public string singleOrderYn { get; set; }
    }

    //메뉴 단건 다른가맹점(다중)으로 복사(옵션포함)
    public class CopyMenuTo
    {
        public string source_cccode { get; set; }
        public string source_shop_cd { get; set; }
        public IEnumerable<string> dest_cccode { get; set; }
        public IEnumerable<string> dest_shop_cd { get; set; }
        public string menu_cd { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }
}
