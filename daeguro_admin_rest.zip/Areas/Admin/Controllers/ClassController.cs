﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ClassController : ControllerBase
    {
        /// <summary>
        /// 분류 - 목록 조회
        /// </summary>
        /// <remarks>
        /// base_gbn 기준 구분: 빈값 전체, SHOP 가맹점 기준, PROD  상품기준 <br/>
        /// class_gbn 분류코드 : 빈값 전체 <br/>
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string base_gbn, string class_gbn)
        {
            string Rcode;
            string Rmsg;
            List<ClassList> items = new List<ClassList>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("base_gbn", base_gbn);
            param.Add("class_gbn", class_gbn);

            string sql = @$"
                            SELECT class_gbn,
                                   name,
                                   base_gbn,
                                   sort_seq
                            FROM CLASS_MST
                            WHERE BASE_GBN LIKE CASE WHEN :base_gbn is null then '%' ELSE :base_gbn END
                            AND class_gbn LIKE CASE WHEN :class_gbn is null then '%' ELSE :class_gbn END
                            ORDER BY BASE_GBN, SORT_SEQ
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync<ClassList>(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

    }
}
