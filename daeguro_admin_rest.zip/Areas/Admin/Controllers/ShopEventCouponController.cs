﻿using ClosedXML.Excel;
using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ShopEventCouponController : ControllerBase
    {
        //가맹점 자체쿠폰 관리

        /// <summary>
        /// 가맹점 쿠폰 목록 조회
        /// </summary>
        /// <remarks>
        /// 파라미터 <br/>
        /// mcode : 회원사 <br/>
        /// status : 상태(빈값:전체,1:대기,2:진행,3:종료) <br/>
        /// keyword : 가맹점명으로 검색 키워드 <br/>
        /// dt_gbn : 기간기준(1: 등록일, 2: 시작일) <br/>
        /// in_date_begin ~ in_date_end: 기간 기준 범위 조회 <br/>
        ///  <br/>
        /// 결과값 <br/>
        /// rnum : 조회순서 <br/>
        /// shop_cd : 가맹점 코드 <br/>
        /// shop_name : 가맹점명 <br/>
        /// apply_gbn : 주문유형(배달, 포장, 배달/포장) <br/>
        /// display_st_date : 쿠폰 발급 가능 시작일 <br/>
        /// display_end_date : 쿠폰 발급 가능 종료일 <br/>
        /// status : 진행상태(대기,진행,종료) <br/>
        /// coupon_type : 쿠폰코드 <br/>
        /// coupon_name : 쿠폰명(이벤트명)
        /// </remarks>
        [HttpGet()]
        public async Task<IActionResult> Get(string mcode, string status, string keyword, string dt_gbn, string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<ShopCouponList> itmes = new List<ShopCouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_SHOP_EVENT_COUPON_MNG.GET_SHOP_COUPON_LIST",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Varchar2, 2).Value = mcode;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 2).Value = status;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 600).Value = string.IsNullOrEmpty(keyword) ? keyword : "%" + keyword + "%";
            cmd.Parameters.Add("in_dt_gbn", OracleDbType.Varchar2, 1).Value = dt_gbn;
            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopCouponList item = new ShopCouponList
                    {
                        rnum = rd["RNUM"].ToString(),
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),
                        apply_gbn = rd["APPLY_GBN"].ToString(),
                        display_st_date = rd["DISPLAY_ST_DATE"].ToString(),
                        display_end_date = rd["DISPLAY_END_DATE"].ToString(),
                        status = rd["STATUS"].ToString(),
                        use_gbn = rd["USE_GBN"].ToString(),
                        coupon_type = rd["COUPON_TYPE"].ToString(),
                        coupon_name = rd["COUPON_NAME"].ToString(),
                        ins_date = rd["INS_DATE"].ToString(),
                        ins_name = rd["INS_NAME"].ToString(),
                        mod_date = rd["MOD_DATE"].ToString(),
                        mod_name = rd["MOD_NAME"].ToString()
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopEventCoupon : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }

        /// <summary>
        /// 가맹점 쿠폰 목록 엑셀출력
        /// </summary>
        /// <remarks>
        /// 파라미터 <br/>
        /// mcode : 회원사 <br/>
        /// status : 상태(빈값:전체,1:대기,2:진행,3:종료) <br/>
        /// keyword : 가맹점명으로 검색 키워드 <br/>
        /// dt_gbn : 기간기준(1: 등록일, 2: 시작일) <br/>
        /// in_date_begin ~ in_date_end: 기간 기준 범위 조회 <br/>
        ///  <br/>
        /// 결과값 <br/>
        /// rnum : 조회순서 <br/>
        /// shop_cd : 가맹점 코드 <br/>
        /// shop_name : 가맹점명 <br/>
        /// apply_gbn : 주문유형(배달, 포장, 배달/포장) <br/>
        /// display_st_date : 쿠폰 발급 가능 시작일 <br/>
        /// display_end_date : 쿠폰 발급 가능 종료일 <br/>
        /// status : 진행상태(대기,진행,종료) <br/>
        /// coupon_type : 쿠폰코드 <br/>
        /// coupon_name : 쿠폰명(이벤트명)
        /// </remarks>
        [HttpGet("ExcelExport")]
        public async Task<IActionResult> ExcelExport(string mcode, string status, string keyword, string dt_gbn, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<ShopCouponList> itmes = new List<ShopCouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_SHOP_EVENT_COUPON_MNG.GET_SHOP_COUPON_LIST_EXCEL",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Varchar2, 2).Value = mcode;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 2).Value = status;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 600).Value = string.IsNullOrEmpty(keyword) ? keyword : "%" + keyword + "%";
            cmd.Parameters.Add("in_dt_gbn", OracleDbType.Varchar2, 1).Value = dt_gbn;
            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add("가맹점 자체할인쿠폰 목록");
                        var currentRow = 1;

                        worksheet.Cell(currentRow, 1).Value = "가맹점코드";
                        worksheet.Cell(currentRow, 2).Value = "가맹점명";
                        worksheet.Cell(currentRow, 3).Value = "주문유형";
                        worksheet.Cell(currentRow, 4).Value = "쿠폰발급가능 시작일";
                        worksheet.Cell(currentRow, 5).Value = "쿠폰발급가능 종료일";
                        worksheet.Cell(currentRow, 6).Value = "진행상태";
                        worksheet.Cell(currentRow, 7).Value = "사용구분";
                        worksheet.Cell(currentRow, 8).Value = "이벤트 제목";
                        worksheet.Cell(currentRow, 9).Value = "등록일";
                        worksheet.Cell(currentRow, 10).Value = "수정일";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;

                            worksheet.Cell(currentRow, 1).Value = rd["SHOP_CD"].ToString();
                            worksheet.Cell(currentRow, 2).Value = rd["SHOP_NAME"].ToString();
                            worksheet.Cell(currentRow, 3).Value = rd["APPLY_GBN"].ToString();
                            worksheet.Cell(currentRow, 4).Value = rd["DISPLAY_ST_DATE"].ToString();
                            worksheet.Cell(currentRow, 5).Value = rd["DISPLAY_END_DATE"].ToString();
                            worksheet.Cell(currentRow, 6).Value = rd["STATUS"].ToString();
                            worksheet.Cell(currentRow, 7).Value = rd["USE_GBN"].ToString();
                            worksheet.Cell(currentRow, 8).Value = rd["COUPON_NAME"].ToString();
                            worksheet.Cell(currentRow, 9).Value = rd["INS_DATE"].ToString();
                            worksheet.Cell(currentRow, 10).Value = rd["MOD_DATE"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "가맹점 자체할인쿠폰 목록.xlsx");
                        }
                    }

                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                //await Utils.SaveErrorAsync("/ShopEventCoupon/ExcelExport : Get", ex.Message);\
                return Ok(new { code = "99", msg = ex.Message });
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 가맹점 쿠폰 상세조회
        /// </summary>
        /// <remarks>
        /// coupon_type : 쿠폰 코드 <br/>
        /// coupon_name : 쿠폰명(이벤트명) <br/>
        /// display_st_date : 쿠폰 발급 가능 시작일 <br/>
        /// display_end_date : 쿠폰 발급 가능 종료일 <br/>
        /// exp_set_date : 쿠폰 유효기간 <br/>
        /// <br/>
        /// coupon_item[]  <br/>
        ///  - apply_min_amt : 최소 주문 금액 <br/>
        ///  - coupon_amt : 할인 금액 <br/>
        ///  - pub : 쿠폰 발급건수 <br/>
        ///  - use : 쿠폰 사용건수
        /// </remarks>
        [HttpGet("{coupon_type}")]
        public async Task<IActionResult> GetDetail(string coupon_type)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_SHOP_EVENT_COUPON_MNG.GET_SHOP_COUPON_DETAIL",
            };

            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 100).Value = coupon_type;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor2", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            ShopCoupon item = new ShopCoupon();

            List<ShopCouponItem> subItems = new List<ShopCouponItem>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await rd.ReadAsync();

                item.coupon_type = rd["COUPON_TYPE"].ToString();
                item.coupon_name = rd["COUPON_NAME"].ToString();
                item.display_st_date = rd["DISPLAY_ST_DATE"].ToString();
                item.display_end_date = rd["DISPLAY_END_DATE"].ToString();
                item.exp_set_date = rd["EXP_SET_DATE"].ToString();
                item.ins_date = rd["INS_DATE"].ToString();
                item.ins_name = rd["INS_NAME"].ToString();
                item.mod_date = rd["MOD_DATE"].ToString();
                item.mod_name = rd["MOD_NAME"].ToString();

                await rd.NextResultAsync();

                while (await rd.ReadAsync())
                {
                    ShopCouponItem subItem = new ShopCouponItem
                    {
                        apply_min_amt = rd["APPLY_MIN_AMT"].ToString(),
                        coupon_amt = rd["COUPON_AMT"].ToString(),
                        pub = rd["PUB"].ToString(),
                        use = rd["USE"].ToString(),

                    };

                    subItems.Add(subItem);
                }

                item.coupon_item = subItems.ToArray();

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopEventCoupon/{coupon_type} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 가맹점 쿠폰 설정 변경이력 조회
        /// </summary>
        [HttpGet("history/{coupon_type}")]
        public async Task<IActionResult> getHistory(string coupon_type)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<HistoryList> items = new List<HistoryList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_SHOP_EVENT_COUPON_MNG.GET_COUPON_HIST",
            };

            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 50).Value = coupon_type;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    HistoryList item = new HistoryList
                    {
                        no = rd["hist_seq"].ToString(),
                        insertDate = rd["HIST_DATE"].ToString(),
                        memo = rd["MEMO"].ToString(),

                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopEventCoupon/history/{coupon_type} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }


    }
}
