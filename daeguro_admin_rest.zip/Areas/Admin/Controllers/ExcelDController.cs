﻿using Dapper;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ExcelDController : ControllerBase
    {
        //대구로 통계(통합)
        //가맹점

        /// <summary>
        /// 엑셀통계 - 메뉴 미등록 가맹점
        /// </summary>
        [HttpGet("getNoMenuShop")]
        public async Task<IActionResult> getNoMenuShop()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                    SELECT a.shop_cd AS 가맹점번호,
                                           a.shop_name AS 가맹점명,
                                           a.telno AS 휴대폰,
                                           a.owner AS 대표명,
                                           a.reg_no AS 사업자번호,
                                           a.gungu_name AS 군구명,
                                           a.operator_name AS 오퍼레이터,
                                           TO_CHAR(a.open_dt, 'yyyyMMdd') AS 등록일
                                      FROM shop_info a,
                                           callcenter b
                                     WHERE a.cccode = b. cccode
                                       AND b.mcode = 2
                                       AND a.open_dt >= to_date ('2021080917', 'YYYYMMDDHH24')
                                       AND SF_SHOP_CHECK_ITEM('2', a.shop_cd) = 'Y'
                                     ORDER BY shop_cd desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 대표이미지 미비 가맹점
        /// </summary>
        [HttpGet("getNoShopImg")]
        public async Task<IActionResult> getNoShopImg()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT a.shop_cd AS 가맹점번호,
                                       a.shop_name AS 가맹점명,
                                       a.telno AS 휴대폰,
                                       a.owner AS 대표명,
                                       a.reg_no AS 사업자번호,
                                       a.salesman_name AS 영업사원,
                                       TO_CHAR(a.open_dt, 'yyyyMMdd') AS 등록일
                                  FROM shop_info a,
                                       callcenter b
                                 WHERE a.cccode = b. cccode
                                   AND b.mcode = 2
                                   AND a.open_dt >= to_date ('2021080917', 'YYYYMMDDHH24')
                                   AND a.shop_image_yn = 'N'
                                 ORDER BY shop_cd desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 첨부파일 미비 가맹점
        /// </summary>
        [HttpGet("getNoFileShop")]
        public async Task<IActionResult> getNoFileShop()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT a.shop_cd AS 가맹점번호,
                                       a.shop_name AS 가맹점명,
                                       a.telno AS 휴대폰,
                                       a.owner AS 대표명,
                                       a.reg_no AS 사업자번호,
                                       decode(a.buss_image_yn, 'Y', 'O', 'N', 'X') AS 사업자등록증,
                                       decode(a.idcard_image_yn, 'Y', 'O', 'N', 'X') AS 신분증,
                                       decode(a.bank_image_yn, 'Y', 'O', 'N', 'X') AS 통장사본,
                                       a.salesman_name AS 영업사원,
                                       TO_CHAR(a.open_dt, 'yyyyMMdd') AS 등록일
                                  FROM shop_info a,
                                       callcenter b
                                 WHERE a.cccode = b. cccode
                                   AND b.mcode = 2
                                   AND a.open_dt >= to_date ('2021080917', 'YYYYMMDDHH24')
                                   AND (a.buss_image_yn = 'N'
                                            OR a.idcard_image_yn = 'N'
                                            OR a.bank_image_yn = 'N')
                                 ORDER BY shop_cd desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

    
        /// <summary>
        /// 엑셀통계 - 휴점상태 가맹점
        /// </summary>
        [HttpGet("getAbsentShop")]
        public async Task<IActionResult> getAbsentShop()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT a.shop_cd AS 가맹점번호,
                                       a.shop_name AS 가맹점명,
                                       a.telno AS 휴대폰,
                                       a.owner AS 대표명,
                                       a.reg_no AS 사업자번호,
                                       TO_CHAR(a.open_dt, 'yyyyMMdd') AS 등록일
                                  FROM shop_info a,
                                       callcenter b
                                 WHERE a.cccode = b. cccode
                                   AND b.mcode = 2
                                   AND a.absent_yn = 'N'
                                   AND a.open_dt >= to_date ('2021080917', 'YYYYMMDDHH24')
                                 ORDER BY shop_cd desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 앱미승인 가맹점
        /// </summary>
        [HttpGet("getOrderYnShop")]
        public async Task<IActionResult> getOrderYnShop()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT a.shop_cd AS 가맹점번호,
                                       a.shop_name AS 가맹점명,
                                       a.telno AS 휴대폰,
                                       a.owner AS 대표명,
                                       a.reg_no AS 사업자번호,
                                       TO_CHAR(a.open_dt, 'yyyyMMdd') AS 등록일
                                  FROM shop_info a,
                                       callcenter b
                                 WHERE a.cccode = b. cccode
                                   AND b.mcode = 2
                                   AND a.app_order_yn = 'N'
                                   AND a.open_dt >= to_date ('2021080917', 'YYYYMMDDHH24')
                                 ORDER BY shop_cd desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 기간별 주문실적( 0, 5, 10, 15, 20, 25, 30, 35, 40 , 45회 이상 )
        /// </summary>
        [HttpGet("getShopCount")]
        public async Task<IActionResult> getShopCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT 0
                                           DAY_COUNT,
                                       (SELECT COUNT (*)
                                          FROM shop_info w, callcenter x
                                         WHERE     shop_cd NOT IN
                                                       (SELECT DISTINCT shop_cd
                                                          FROM (SELECT cccode,
                                                                       shop_cd,
                                                                       cancel_code,
                                                                       test_gbn,
                                                                       order_time
                                                                  FROM dorder
                                                                UNION ALL
                                                                SELECT cccode,
                                                                       shop_cd,
                                                                       cancel_code,
                                                                       test_gbn,
                                                                       order_time
                                                                  FROM dorder_past) a
                                                         WHERE a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                               AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                          AND :date_end
                                                               AND a.test_gbn = 'N'
                                                               AND NVL (a.cancel_code, '00') <> '30')
                                               AND w.cccode = x.cccode
                                               AND x.mcode = 2
                                               AND w.app_order_yn = 'Y'
                                               AND w.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                               AND to_char(w.open_dt,'YYYYMMDD') <= :date_end)
                                           ORDER_COUNT
                                  FROM DUAL
                                UNION ALL
                                    SELECT ROWNUM
                                               DAY_COUNT,
                                           DECODE (ROWNUM,
                                                   1, day1,
                                                   2, day2,
                                                   3, day3,
                                                   4, day4,
                                                   5, day5,
                                                   6, day6,
                                                   7, day7,
                                                   8, day8,
                                                   9, day9,
                                                   10, day10)
                                               order_count
                                      FROM (SELECT SUM (CASE WHEN (cnt BETWEEN 1 AND 5) THEN 1 ELSE 0 END)
                                                       day1,
                                                   SUM (CASE WHEN (cnt BETWEEN 6 AND 10) THEN 1 ELSE 0 END)
                                                       day2,
                                                   SUM (CASE WHEN (cnt BETWEEN 11 AND 15) THEN 1 ELSE 0 END)
                                                       day3,
                                                   SUM (CASE WHEN (cnt BETWEEN 16 AND 20) THEN 1 ELSE 0 END)
                                                       day4,
                                                   SUM (CASE WHEN (cnt BETWEEN 21 AND 25) THEN 1 ELSE 0 END)
                                                       day5,
                                                   SUM (CASE WHEN (cnt BETWEEN 26 AND 30) THEN 1 ELSE 0 END)
                                                       day6,
                                                   SUM (CASE WHEN (cnt BETWEEN 31 AND 35) THEN 1 ELSE 0 END)
                                                       day7,
                                                   SUM (CASE WHEN (cnt BETWEEN 36 AND 40) THEN 1 ELSE 0 END)
                                                       day8,
                                                   SUM (CASE WHEN (cnt BETWEEN 41 AND 45) THEN 1 ELSE 0 END)
                                                       day9,
                                                   SUM (CASE WHEN (cnt > 45) THEN 1 ELSE 0 END)
                                                       day10
                                              FROM (  SELECT shop_cd, COUNT (*) cnt
                                                        FROM (SELECT *
                                                                FROM is_daegu.dorder a, is_daegu.callcenter b
                                                               WHERE     a.cccode = b.cccode
                                                                     AND b.mcode = 2
                                                                     AND a.test_gbn = 'N'
                                                                     AND NVL (a.cancel_code, '00') <> '30'
                                                                     AND a.order_time >=
                                                                         TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                                AND :date_end
                                                              UNION
                                                              SELECT *
                                                                FROM is_daegu.dorder_past a, is_daegu.callcenter b
                                                               WHERE     a.cccode = b.cccode
                                                                     AND b.mcode = 2
                                                                     AND a.test_gbn = 'N'
                                                                     AND NVL (a.cancel_code, '00') <> '30'
                                                                     AND a.order_time >=
                                                                         TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                                AND :date_end)
                                                    GROUP BY shop_cd))
                                CONNECT BY LEVEL <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 기간별 주문실적2( 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10회 이상 )
        /// </summary>
        [HttpGet("getShopCount2")]
        public async Task<IActionResult> getShopCount2(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT 0
                                           DAY_COUNT,
                                       (SELECT COUNT (*)
                                          FROM shop_info w, callcenter x
                                         WHERE     shop_cd NOT IN
                                                       (SELECT DISTINCT shop_cd
                                                          FROM (SELECT cccode,
                                                                       shop_cd,
                                                                       cancel_code,
                                                                       test_gbn,
                                                                       order_time
                                                                  FROM dorder
                                                                UNION ALL
                                                                SELECT cccode,
                                                                       shop_cd,
                                                                       cancel_code,
                                                                       test_gbn,
                                                                       order_time
                                                                  FROM dorder_past) a
                                                         WHERE a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                               AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                          AND :date_end
                                                               AND a.test_gbn = 'N'
                                                               AND NVL (a.cancel_code, '00') <> '30')
                                               AND w.cccode = x.cccode
                                               AND x.mcode = 2
                                               AND w.app_order_yn = 'Y'
                                               AND w.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                               AND to_char(w.open_dt,'YYYYMMDD') <= :date_end)
                                           ORDER_COUNT
                                  FROM DUAL
                                UNION ALL
                                    SELECT ROWNUM
                                               DAY_COUNT,
                                           DECODE (ROWNUM,
                                                   1, day1,
                                                   2, day2,
                                                   3, day3,
                                                   4, day4,
                                                   5, day5,
                                                   6, day6,
                                                   7, day7,
                                                   8, day8,
                                                   9, day9,
                                                   10, day10)
                                               order_count
                                      FROM (SELECT SUM (CASE WHEN (cnt = 1) THEN 1 ELSE 0 END)
                                                       day1,
                                                   SUM (CASE WHEN (cnt = 2) THEN 1 ELSE 0 END)
                                                       day2,
                                                   SUM (CASE WHEN (cnt = 3) THEN 1 ELSE 0 END)
                                                       day3,
                                                   SUM (CASE WHEN (cnt = 4) THEN 1 ELSE 0 END)
                                                       day4,
                                                   SUM (CASE WHEN (cnt = 5) THEN 1 ELSE 0 END)
                                                       day5,
                                                   SUM (CASE WHEN (cnt = 6) THEN 1 ELSE 0 END)
                                                       day6,
                                                   SUM (CASE WHEN (cnt = 7) THEN 1 ELSE 0 END)
                                                       day7,
                                                   SUM (CASE WHEN (cnt = 8) THEN 1 ELSE 0 END)
                                                       day8,
                                                   SUM (CASE WHEN (cnt = 9) THEN 1 ELSE 0 END)
                                                       day9,
                                                   SUM (CASE WHEN (cnt >= 10) THEN 1 ELSE 0 END)
                                                       day10
                                              FROM (  SELECT shop_cd, COUNT (*) cnt
                                                        FROM (SELECT *
                                                                FROM is_daegu.dorder a, is_daegu.callcenter b
                                                               WHERE     a.cccode = b.cccode
                                                                     AND b.mcode = 2
                                                                     AND a.test_gbn = 'N'
                                                                     AND NVL (a.cancel_code, '00') <> '30'
                                                                     AND a.order_time >=
                                                                         TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                                AND :date_end
                                                              UNION
                                                              SELECT *
                                                                FROM is_daegu.dorder_past a, is_daegu.callcenter b
                                                               WHERE     a.cccode = b.cccode
                                                                     AND b.mcode = 2
                                                                     AND a.test_gbn = 'N'
                                                                     AND NVL (a.cancel_code, '00') <> '30'
                                                                     AND a.order_time >=
                                                                         TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                                AND :date_end)
                                                    GROUP BY shop_cd))
                                CONNECT BY LEVEL <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 취소율 순위
        /// </summary>
        [HttpGet("getShopCancelOrderRank")]
        public async Task<IActionResult> getShopCancelOrderRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @$"
                                 SELECT rownum, a.*
                                    FROM (  SELECT a.* , round(a.취소/a.총주문,2)*100 as 취소율
                                            FROM (
                                                select shop_cd, shop_name,
                                                        COUNT(shop_cd) AS 총주문,
                                                        COUNT(CASE WHEN status = '40' then 1 end) AS 완료,
                                                        COUNT(CASE WHEN status = '50' then 1 end) AS 취소
                                                FROM (select a.STATUS, c.shop_cd, c.shop_name FROM dorder a, callcenter b, shop_info c
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        AND NVL (a.CANCEL_CODE, '00') <> '30'
                                                        AND a.shop_cd = c.shop_cd
                                                      UNION ALL
                                                      select a.STATUS, c.shop_cd, c.shop_name FROM dorder_past a, callcenter b, shop_info c
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        AND NVL (a.CANCEL_CODE, '00') <> '30'
                                                        AND a.shop_cd = c.shop_cd )
                                                group by shop_cd, shop_name)a 
                                            order by round(a.취소/a.총주문,2)*100 desc, a.취소 desc) a
                                        where a.취소율 >= 50
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }

        /// <summary>
        /// 엑셀통계 - 시간지연 취소율 순위
        /// </summary>
        [HttpGet("getShopDelayCancelOrderRank")]
        public async Task<IActionResult> getShopDelayCancelOrderRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @$"
                                 SELECT to_char(b.open_dt,'YYYYMMDD') as open_dt , b.shop_name, a.*
                                    FROM (  SELECT a.* , round(a.시간지연취소/a.총주문,2)*100 as 취소율
                                            FROM (
                                                select shop_cd,
                                                        COUNT(shop_cd) AS 총주문,
                                                        COUNT(CASE WHEN status = '40' then 1 end) AS 완료,
                                                        COUNT(CASE WHEN status = '50' then 1 end) AS 취소,
                                                        COUNT(CASE WHEN status = '50' and cancel_code = '11' then 1 end) AS 시간지연취소
                                                FROM (select a.STATUS, a.shop_cd, a.cancel_code FROM dorder a, callcenter b
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        AND NVL (a.CANCEL_CODE, '00') <> '30'
                                                      UNION ALL
                                                      select a.STATUS, a.shop_cd, a.cancel_code FROM dorder_past a, callcenter b
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        AND NVL (a.CANCEL_CODE, '00') <> '30')
                                                group by shop_cd)a 
                                            order by round(a.시간지연취소/a.총주문,2)*100 desc, a.시간지연취소 desc) a, shop_info b
                                        where a.shop_cd = b.shop_cd
                                        and a.취소율 >= 50
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }


        /// <summary>
        /// 엑셀통계 - 가맹점취소 취소율 순위
        /// </summary>
        [HttpGet("getShopOwnerCancelOrderRank")]
        public async Task<IActionResult> getShopOwnerCancelOrderRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @$"
                                 SELECT to_char(b.open_dt,'YYYYMMDD') as open_dt , b.shop_name, a.*
                                    FROM (  SELECT a.* , round(a.가맹점취소/a.총주문,2)*100 as 취소율
                                            FROM (
                                                select shop_cd,
                                                        COUNT(shop_cd) AS 총주문,
                                                        COUNT(CASE WHEN status = '40' then 1 end) AS 완료,
                                                        COUNT(CASE WHEN status = '50' then 1 end) AS 취소,
                                                        COUNT(CASE WHEN status = '50' and cancel_code = '20' then 1 end) AS 가맹점취소
                                                FROM (select a.STATUS, a.shop_cd, a.cancel_code FROM dorder a, callcenter b
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        AND NVL (a.CANCEL_CODE, '00') <> '30'
                                                      UNION ALL
                                                      select a.STATUS, a.shop_cd, a.cancel_code FROM dorder_past a, callcenter b
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        AND NVL (a.CANCEL_CODE, '00') <> '30')
                                                group by shop_cd)a 
                                            order by round(a.가맹점취소/a.총주문,2)*100 desc, a.가맹점취소 desc) a, shop_info b
                                        where a.shop_cd = b.shop_cd
                                        and a.취소율 >= 50
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }

        /// <summary>
        /// 엑셀통계 - 가맹점 순위(상위, 하위)
        /// </summary>
        /// <remarks>
        /// div: 1 완료수 많은/ 2 완료기준 매출액 많은/3 취소수 많은/ 4 완료기준 매출액 적은 <br/>
        /// 매출액 기준(TOT_AMT : 메뉴주문금액 + 배달팁)
        /// </remarks>
        [HttpGet("getShopRank10")]
        public async Task<IActionResult> getShopRank10(string div, string cccode, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("div", div);
                param.Add("cccode", cccode);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string desc = (div == "4") ? "" : "desc";

                string sql = @$"
                                select rownum rnum, a.*
                                from(select case when :div in (2,4) then sum(a.tot_amt) else count(a.order_no) end as 값, b.shop_name 가맹점명,  b.shop_cd
                                from (select * from dorder union all select * from dorder_past) a, shop_info b, callcenter c
                                where a.shop_cd = b.shop_cd
                                and b.cccode = c.cccode
                                and c.mcode = 2
                                and b.cccode like case when :cccode is null then '%' else :cccode end  
                                and b.app_order_yn = 'Y'
                                and a.status = case when :div = 3 then '50' else '40' end
                                AND a.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND a.TEST_GBN = 'N'
                                AND NVL(a.CANCEL_CODE,'00') <> '30' 
                                and a.order_time between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                group by b.shop_name, b.shop_cd
                                order by case when :div in (2,4) then sum(a.tot_amt) else count(a.order_no) end {desc} ) a
                                where rownum <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }
        //가맹점 end/

        //주문//

        /// <summary>
        /// 엑셀전용 - 전체주문(기간조건:ORDER_TIME 주문시간)
        /// </summary>
        [HttpGet("getTotalOrderInfo")]
        public async Task<IActionResult> getTotalOrderInfo(string gungu, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string keywordSql = string.Empty;

                if (string.IsNullOrEmpty(gungu) == false)
                {
                    keywordSql = $@"AND A.DEST_GUNGU = '{gungu}'";
                }

                string sql = $@"
                                  select t1.*,  TRUNC (t1.OK_CNT / t1.CNT * 100, 1)     COMP_PER, case when r.reser_in_cnt is null then 0 else r.reser_in_cnt end reser_in_cnt
                                            from
                                            (SELECT TO_CHAR (z.ORDER_TIME, 'yyyyMMdd')
                                                       ORDER_DATE,
                                                   COUNT (z.ORDER_NO)
                                                       AS CNT,
                                                   SUM (z.TOT_AMT)
                                                       AS AMT,
                                                   SUM (CASE WHEN z.STATUS = '40' THEN 1 ELSE 0 END)
                                                       AS OK_CNT,
                                                   SUM (CASE WHEN z.STATUS = '40' THEN z.TOT_AMT ELSE 0 END)
                                                       AS OK_AMT,
                                                   SUM (CASE WHEN z.STATUS = '50' THEN 1 ELSE 0 END)
                                                       AS CANCEL_CNT,
                                                   SUM (CASE WHEN z.STATUS = '50' THEN z.TOT_AMT ELSE 0 END)
                                                       AS CANCEL_AMT,
                                                   SUM (CASE WHEN z.STATUS = '30' THEN 1 ELSE 0 END)
                                                       AS SHOP_CONFIRM,
                                                   SUM (CASE WHEN z.STATUS = '40' AND NVL(z.DISC_AMT,0) = 0 AND NVL(z.MILEAGE_USE_AMT,0) = 0  THEN 1 ELSE 0 END)
                                                       AS NO_DISCOUNT_OK,
                                                       SUM (CASE WHEN z.STATUS = '50' AND NVL(z.DISC_AMT,0) = 0 AND NVL(z.MILEAGE_USE_AMT,0) = 0  THEN 1 ELSE 0 END)
                                                       AS NO_DISCOUNT_CANCEL
                                    FROM (  SELECT a.*
                                              FROM DORDER A,
                                                   CALLCENTER C,
                                                   SHOP_INFO D
                                             WHERE     A.TEST_GBN = 'N'
                                                   AND A.CCCODE = C.CCCODE
                                                   AND C.MCODE = 2
                                                   AND NVL (A.CANCEL_CODE, '00') <> '30'
                                                   AND A.SHOP_CD = D.SHOP_CD
                                                   AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                   AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                       AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                                   {keywordSql}
                                           union all
                                           SELECT a.*
                                              FROM DORDER_PAST A,
                                                   CALLCENTER C,
                                                   SHOP_INFO D
                                             WHERE     A.TEST_GBN = 'N'
                                                   AND A.CCCODE = C.CCCODE
                                                   AND C.MCODE = 2
                                                   AND NVL (A.CANCEL_CODE, '00') <> '30'
                                                   AND A.SHOP_CD = D.SHOP_CD
                                                   AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                   AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                       AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                                   {keywordSql}
                                                   ) Z
                                GROUP BY TO_CHAR (Z.ORDER_TIME, 'yyyyMMdd')) t1, 
                                (select to_char(a.isrt_date, 'yyyyMMdd') isrt_date, count(*) reser_in_cnt
                                from reser_receipt_order a,
                                     CALLCENTER C,
                                     SHOP_INFO D
                                where a.shop_cd = d.shop_cd
                                and d.cccode = c.cccode
                                and c.mcode = 2
                                and a.isrt_date BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                   AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                group by to_char(a.isrt_date, 'yyyyMMdd')) r
                                where t1.ORDER_DATE = r.isrt_date(+)
                                ORDER BY t1.ORDER_DATE DESC      
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 주문별 통계,엑셀통계 - 일자별 주문취소 사유(기간조건:ORDER_TIME 주문시간)
        /// </summary>
        [HttpGet("getDailyOrderCancelReason")]
        public async Task<IActionResult> getDailyOrderCancelReason(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT TO_CHAR (a.order_time, 'yyyyMMdd')
                                             AS order_date,
                                             c.code_nm as cancel_code,
                                         COUNT (*)
                                             COUNT
                                    FROM (SELECT order_time,
                                                 NVL (cancel_code, '00')     AS cancel_code,
                                                 cccode,
                                                 test_gbn,
                                                 status
                                            FROM dorder
                                            where test_gbn = 'N'
                                            AND status = '50'
                                            AND NVL (cancel_code, '00') <> '30'
                                            AND order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                            AND order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                              AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                          UNION ALL
                                          SELECT order_time,
                                                 NVL (cancel_code, '00')     AS cancel_code,
                                                 cccode,
                                                 test_gbn,
                                                 status
                                            FROM dorder_past
                                            where test_gbn = 'N'
                                            AND status = '50'
                                            AND NVL (cancel_code, '00') <> '30'
                                            AND order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                            AND order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                              AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')) a,
                                         callcenter b,
                                         etc_code c
                                   WHERE     a.cccode = b.cccode
                                         AND b.mcode = 2
                                         AND c.pgm_group = 'O'
                                         AND c.code_grp = '10'
                                         AND a.cancel_code = c.code
                                GROUP BY TO_CHAR (a.order_time, 'yyyyMMdd'), CUBE (code_nm)
                                ORDER BY order_date DESC
                ";

                //string sql = @"
                //                  SELECT TO_CHAR (a.order_time, 'yyyyMMdd')
                //                             AS order_date,
                //                         DECODE (cancel_code,
                //                                 '00', '사유없음',
                //                                 '10', '고객본인취소',
                //                                 '11', '시간지연',
                //                                 '12', '재접수',
                //                                 '20', '가맹점취소',
                //                                 '21', '배달불가',
                //                                 '22', '메뉴품절',
                //                                 '23', '가맹점휴무',
                //                                 '24', '주소입력오류',
                //                                 '25', '가맹점 정산 접수거부',
                //                                 '26', 'POS서버 응답없음',
                //                                 '30', '결재대기 자동취소',
                //                                 '40', '예약주문 고객 취소',
                //                                 '45', '예약주문 가맹점 취소')
                //                             cancel_code,
                //                         COUNT (*)
                //                             COUNT
                //                    FROM (SELECT order_time,
                //                                 NVL (cancel_code, '00')     AS cancel_code,
                //                                 cccode,
                //                                 test_gbn,
                //                                 status
                //                            FROM dorder
                //                          UNION ALL
                //                          SELECT order_time,
                //                                 NVL (cancel_code, '00')     AS cancel_code,
                //                                 cccode,
                //                                 test_gbn,
                //                                 status
                //                            FROM dorder_past) a,
                //                         callcenter b
                //                   WHERE     a.cccode = b.cccode
                //                         AND b.mcode = 2
                //                         AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                //                         AND a.test_gbn = 'N'
                //                         AND NVL (a.cancel_code, '00') <> '30'
                //                         AND a.status = '50'
                //                         AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                //                                                                    AND :date_end
                //                GROUP BY TO_CHAR (a.order_time, 'yyyyMMdd'), CUBE (cancel_code)
                //                ORDER BY order_date DESC
                //";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 일자별 취소 사유 for 엑셀 -> 다음 엑셀 배포때 기존 rest와 통합
        [HttpGet("getDailyOrderCancelReason2")]
        public async Task<IActionResult> getDailyOrderCancelReason2(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT TO_CHAR (a.order_time, 'yyyyMMdd')
                                             AS order_date,
                                             c.code_nm as cancel_code,
                                         COUNT (*)
                                             COUNT
                                    FROM (SELECT order_time,
                                                 NVL (cancel_code, '00')     AS cancel_code,
                                                 cccode,
                                                 test_gbn,
                                                 status
                                            FROM dorder
                                          UNION ALL
                                          SELECT order_time,
                                                 NVL (cancel_code, '00')     AS cancel_code,
                                                 cccode,
                                                 test_gbn,
                                                 status
                                            FROM dorder_past) a,
                                         callcenter b,
                                         etc_code c
                                   WHERE     a.cccode = b.cccode
                                         AND b.mcode = 2
                                         AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND a.test_gbn = 'N'
                                         AND NVL (a.cancel_code, '00') <> '30'
                                         AND a.status = '50'
                                         AND c.pgm_group = 'O'
                                         AND c.code_grp = '10'
                                         AND a.cancel_code = c.code
                                         AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                    AND :date_end
                                GROUP BY TO_CHAR (a.order_time, 'yyyyMMdd'), CUBE (code_nm)
                                ORDER BY order_date DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 결제 구분(앱, 만나서) 주문일, 결제구분, 일반카드건수, 일반카드금액, 행복페이건수, 행복페이금액, 만나서카드건수, 만나서카드금액, 만나서현금건수, 만나서현금금액 + 페이류 추가
        /// <summary>
        /// 주문별 통계,엑셀통계 - 일자별 결제(완료건만)(기간조건:ORDER_TIME 주문시간)
        /// </summary>
        /// <remarks>
        /// 결제금액 기준(AMOUNT)
        /// </remarks>
        [HttpGet("getDailyOrderPyaGbn")]
        public async Task<IActionResult> getDailyOrderPyaGbn(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT ORDER_DATE
                                             주문일,
                                         case when pay_div = '11' then '만나서 현금'
                                              when pay_div = '32' then '앱 카드'
                                              when pay_div = '37' then '행복페이'
                                              when pay_div = '52' then '만나서 카드'
                                              when pay_div = '3N' then '네이버페이'
                                              when pay_div = '3K' then '카카오페이'
                                              when pay_div = '3S' then '삼성페이' 
                                         end as 결제구분,
                                         COUNT (CASE WHEN PAY_DIV = '32' THEN 1 END)
                                             AS 일반카드건수,
                                         SUM (CASE WHEN PAY_DIV = '32' THEN AMOUNT END)
                                             AS 일반카드금액,
                                         COUNT (CASE WHEN PAY_DIV = '37' THEN 1 END)
                                             AS 행복페이건수,
                                         SUM (CASE WHEN PAY_DIV = '37' THEN AMOUNT END)
                                             AS 행복페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '52' THEN 1 END)
                                             AS 만나서카드건수,
                                         SUM (CASE WHEN PAY_DIV = '52' THEN AMOUNT END)
                                             AS 만나서카드금액,
                                         COUNT (CASE WHEN PAY_DIV = '11' THEN 1 END)
                                             AS 만나서현금건수,
                                         SUM (CASE WHEN PAY_DIV = '11' THEN AMOUNT END)
                                             AS 만나서현금금액,
                                         COUNT (CASE WHEN PAY_DIV = '3N' THEN 1 END)
                                             AS 네이버페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3N' THEN AMOUNT END)
                                             AS 네이버페이금액,
                                        COUNT (CASE WHEN PAY_DIV = '3K' THEN 1 END)
                                             AS 카카오페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3K' THEN AMOUNT END)
                                             AS 카카오페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '3S' THEN 1 END)
                                             AS 삼성페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3S' THEN AMOUNT END)
                                             AS 삼성페이금액
                                    FROM (SELECT TO_CHAR (ORDER_TIME, 'yyyyMMdd')     AS ORDER_DATE,
                                                 APP_PAY_GBN || PAY_GBN               AS PAY_DIV,
                                                 AMOUNT
                                            FROM DORDER A, CALLCENTER B
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 AND NVL (CANCEL_CODE, '00') <> '30'
                                                 AND TEST_GBN = 'N'
                                                 AND STATUS = '40'
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                          UNION ALL
                                          SELECT TO_CHAR (ORDER_TIME, 'yyyyMMdd')     AS ORDER_DATE,
                                                 APP_PAY_GBN || case when app_pay_gbn = '1' then '1' else PAY_GBN end AS PAY_DIV, -- 현금결제의 아이폰 오류데이터('12')를 걸러주기 위함
                                                 AMOUNT
                                            FROM DORDER_PAST A, CALLCENTER B
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 AND NVL (CANCEL_CODE, '00') <> '30'
                                                 AND TEST_GBN = 'N'
                                                 AND STATUS = '40'
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                where pay_div in ('11','32','37','52','3N','3K','3S')
                                GROUP BY ORDER_DATE, PAY_DIV
                                ORDER BY 주문일 DESC, 결제구분
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 일자별 연령별 주문수
        /// </summary>
        /// <remarks>
        /// 엑셀통계 - 일자별 연령별 주문수 겸 대구시 요청자료용 일자별 연령 주문수 
        /// </remarks>
        [HttpGet("getDailyAgeToOrder")]
        public async Task<IActionResult> getDailyAgeToOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT X.ORDER_DATE,
                                        X.YEAR,
                                        X.COUNT,
                                        X.COMP,
                                        X.CANC
                                    FROM (SELECT case when birthday is null then 0
                                                      when birthday < 1 then 1
                                                      when birthday > 9 then 9
                                                      else birthday end || '0대' AS year, COUNT (*) COUNT, 
                                                                COUNT(CASE WHEN STATUS = '40' THEN 1 END) AS COMP, 
                                                                COUNT(CASE WHEN STATUS = '50' THEN 1 END) AS CANC,
                                                                order_date
                                                        FROM (SELECT trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                                                        birthday, STATUS, order_date
                                                            FROM (SELECT cust_code,
                                                                            birthday
                                                                    FROM app_customer
                                                                    UNION ALL
                                                                    SELECT cust_code,
                                                                            birthday
                                                                    FROM app_customer_deleted) a, 
                                                                (select ccode, STATUS, to_char(order_time,'YYYYMMDD') order_date from dorder a, callcenter b
                                                                where a.cccode = b.cccode
                                                                    AND b.mcode = 2
                                                                    AND a.order_time between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                                                    AND a.TEST_GBN = 'N'
                                                                    AND NVL(a.CANCEL_CODE,'00') <> '30'
                                                                union all
                                                                select ccode, STATUS, to_char(order_time,'YYYYMMDD') order_date from dorder_past a, callcenter b
                                                                where a.cccode = b.cccode
                                                                    AND b.mcode = 2
                                                                    AND a.order_time between to_date(case when :date_begin = '20210809' then '20210809170000' else :date_begin || '000000' end
                                                                            , 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                                                    AND a.TEST_GBN = 'N'
                                                                    AND NVL(a.CANCEL_CODE,'00') <> '30') b
                                                            where a.cust_code = b.ccode
                                                            )
                                                GROUP BY case when birthday is null then 0
                                                              when birthday < 1 then 1
                                                              when birthday > 9 then 9
                                                              else birthday end, order_date) X
                                GROUP BY X.ORDER_DATE, X.YEAR, X.COUNT, X.COMP, X.CANC
                                ORDER BY X.ORDER_DATE desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 결제 구분(앱, 만나서) 주문일, 결제구분, 일반카드건수, 일반카드금액, 행복페이건수, 행복페이금액, 만나서카드건수, 만나서카드금액, 만나서현금건수, 만나서현금금액
        /// <summary>
        /// 엑셀통계 - 일자별 결제 배달완료기준
        /// </summary>
        /// <remarks>
        /// 결제금액 기준(AMOUNT)
        /// </remarks>
        [HttpGet("getDailyOrderPyaGbnDeliTime")]
        public async Task<IActionResult> getDailyOrderPyaGbnDeliTime(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT COMP_DT
                                             주문일,
                                         DECODE (PAY_DIV,
                                                 '11', '만나서 현금',
                                                 '32', '앱 카드',
                                                 '37', '행복페이',
                                                 '52', '만나서 카드',
                                                 '3N', '네이버페이',
                                                 '3K', '카카오페이',
                                                 '3S', '삼성페이')
                                             AS 결제구분,
                                         COUNT (CASE WHEN PAY_DIV = '32' THEN 1 END)
                                             AS 일반카드건수,
                                         SUM (CASE WHEN PAY_DIV = '32' THEN AMOUNT END)
                                             AS 일반카드금액,
                                         COUNT (CASE WHEN PAY_DIV = '37' THEN 1 END)
                                             AS 행복페이건수,
                                         SUM (CASE WHEN PAY_DIV = '37' THEN AMOUNT END)
                                             AS 행복페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '52' THEN 1 END)
                                             AS 만나서카드건수,
                                         SUM (CASE WHEN PAY_DIV = '52' THEN AMOUNT END)
                                             AS 만나서카드금액,
                                         COUNT (CASE WHEN PAY_DIV = '11' THEN 1 END)
                                             AS 만나서현금건수,
                                         SUM (CASE WHEN PAY_DIV = '11' THEN AMOUNT END)
                                             AS 만나서현금금액,
                                         COUNT (CASE WHEN PAY_DIV = '3N' THEN 1 END)
                                             AS 네이버페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3N' THEN AMOUNT END)
                                             AS 네이버페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '3K' THEN 1 END)
                                             AS 카카오페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3K' THEN AMOUNT END)
                                             AS 카카오페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '3S' THEN 1 END)
                                             AS 삼성페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3S' THEN AMOUNT END)
                                             AS 삼성페이금액
                                    FROM (SELECT TO_CHAR (comp_dt, 'yyyyMMdd')     AS comp_dt,
                                                 APP_PAY_GBN || PAY_GBN               AS PAY_DIV,
                                                 AMOUNT
                                            FROM DORDER A, CALLCENTER B
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 AND NVL (CANCEL_CODE, '00') <> '30'
                                                 AND TEST_GBN = 'N'
                                                 AND STATUS = '40'
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND to_char(A.comp_dt, 'YYYYMMDD') BETWEEN :date_begin
                                                                                            AND :date_end
                                          UNION ALL
                                          SELECT TO_CHAR (comp_dt, 'yyyyMMdd')     AS comp_dt,
                                                 APP_PAY_GBN || PAY_GBN               AS PAY_DIV,
                                                 AMOUNT
                                            FROM DORDER_PAST A, CALLCENTER B
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 AND NVL (CANCEL_CODE, '00') <> '30'
                                                 AND TEST_GBN = 'N'
                                                 AND STATUS = '40'
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND to_char(A.comp_dt, 'YYYYMMDD') BETWEEN :date_begin
                                                                                            AND :date_end)
                                GROUP BY comp_dt, PAY_DIV
                                ORDER BY 주문일 DESC, 결제구분
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 결제 구분(앱, 만나서) 주문일, 결제구분, 일반카드건수, 일반카드금액, 행복페이건수, 행복페이금액, 만나서카드건수, 만나서카드금액, 만나서현금건수, 만나서현금금액
        /// <summary>
        /// 엑셀통계 - 일자별 결제 합(기간조건:ORDER_TIME 주문시간)
        /// </summary>
        /// <remarks>
        /// 완료 취소값을 모두 합한 값. <br/>
        /// div: 0 - 할인금액 차감 (실제결제금액:AMOUNT) / 1 - 할인금액 제외없이 (TOT_AMT)
        /// </remarks>
        [HttpGet("getDailyOrderPyaGbnSum")]
        public async Task<IActionResult> getDailyOrderPyaGbnSum(string date_begin, string date_end, string div)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("div", div);

                db.Open();

                string sql = @"
                                  SELECT ORDER_DATE
                                                 주문일,
                                             DECODE (PAY_DIV,
                                                     '11', '만나서 현금',
                                                     '32', '앱 카드',
                                                     '37', '행복페이',
                                                     '52', '만나서 카드',
                                                     '3N', '네이버페이',
                                                     '3K', '카카오페이',
                                                     '3S', '삼성페이')
                                                 AS 결제구분,
                                             COUNT (CASE WHEN PAY_DIV = '32' THEN 1 END)
                                                 AS 일반카드건수,
                                             SUM (CASE WHEN PAY_DIV = '32' THEN TOT_AMT END)
                                                 AS 일반카드금액,
                                             COUNT (CASE WHEN PAY_DIV = '37' THEN 1 END)
                                                 AS 행복페이건수,
                                             SUM (CASE WHEN PAY_DIV = '37' THEN TOT_AMT END)
                                                 AS 행복페이금액,
                                             COUNT (CASE WHEN PAY_DIV = '52' THEN 1 END)
                                                 AS 만나서카드건수,
                                             SUM (CASE WHEN PAY_DIV = '52' THEN TOT_AMT END)
                                                 AS 만나서카드금액,
                                             COUNT (CASE WHEN PAY_DIV = '11' THEN 1 END)
                                                 AS 만나서현금건수,
                                             SUM (CASE WHEN PAY_DIV = '11' THEN TOT_AMT END)
                                                 AS 만나서현금금액,
                                             COUNT (CASE WHEN PAY_DIV = '3N' THEN 1 END)
                                                 AS 네이버페이건수,
                                             SUM (CASE WHEN PAY_DIV = '3N' THEN TOT_AMT END)
                                                 AS 네이버페이금액,
                                             COUNT (CASE WHEN PAY_DIV = '3K' THEN 1 END)
                                                 AS 카카오페이건수,
                                             SUM (CASE WHEN PAY_DIV = '3K' THEN TOT_AMT END)
                                                 AS 카카오페이금액,
                                             COUNT (CASE WHEN PAY_DIV = '3S' THEN 1 END)
                                                 AS 삼성페이건수,
                                             SUM (CASE WHEN PAY_DIV = '3S' THEN TOT_AMT END)
                                                 AS 삼성페이금액 
                                        FROM (SELECT TO_CHAR (ORDER_TIME, 'yyyyMMdd')     AS ORDER_DATE,
                                                     APP_PAY_GBN || PAY_GBN               AS PAY_DIV,
                                                     CASE WHEN :div = 0 then AMOUNT ELSE TOT_AMT END TOT_AMT
                                                FROM DORDER A, CALLCENTER B
                                               WHERE     A.CCCODE = B.CCCODE
                                                     AND B.MCODE = 2
                                                     AND NVL (CANCEL_CODE, '00') <> '30'
                                                     AND TEST_GBN = 'N'
                                                     AND STATUS in ('40','50')
                                                     AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                     AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                          AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                              UNION ALL
                                              SELECT TO_CHAR (ORDER_TIME, 'yyyyMMdd')     AS ORDER_DATE,
                                                     APP_PAY_GBN || PAY_GBN               AS PAY_DIV,
                                                     CASE WHEN :div = 0 then AMOUNT ELSE TOT_AMT END TOT_AMT
                                                FROM DORDER_PAST A, CALLCENTER B
                                               WHERE     A.CCCODE = B.CCCODE
                                                     AND B.MCODE = 2
                                                     AND NVL (CANCEL_CODE, '00') <> '30'
                                                     AND TEST_GBN = 'N'
                                                     AND STATUS in ('40','50')
                                                     AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                     AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                          AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                    GROUP BY ORDER_DATE, PAY_DIV
                                    ORDER BY 주문일 DESC, 결제구분
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 일자별 주문(완료,최소) 주문일, 상태, 수량, 총음식금액, 총배달팁, 첫주문쿠폰, 재구매쿠폰, 이벤트쿠폰(추가), 마일리지, 행복페이 할인
        /// <summary>
        /// 주문별 통계 - 일자별 완료 및 취소(기간조건:ORDER_TIME 주문시간)
        /// </summary>
        [HttpGet("getDailyOrderCompletedCanceled")]
        public async Task<IActionResult> getDailyOrderCompletedCanceled(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                    SELECT X.ORDER_DATE AS 주문일,
                                           DECODE(X.STATUS, '40', '완료', '50', '취소') AS 상태,
                                           COUNT(X.STATUS) AS 수량,
                                           SUM(X.MENU_AMT) AS 총음식금액,
                                           SUM(X.DELI_TIP_AMT) AS 총배달팁,
                                           --SUM(X.MENU_AMT + X.DELI_TIP_AMT) AS 총금액,
                                           SUM(Y.COUPON_AMT) AS 첫주문쿠폰,
                                           SUM(Z.COUPON_AMT) AS 재구매쿠폰,
                                           SUM(x.coupon - nvl(y.coupon_amt,0) - nvl(z.coupon_amt,0)) AS 이벤트쿠폰,
                                           --SUM(x.shop_coupon_amt) AS 가맹점자체쿠폰,
                                           SUM(X.MILEAGE_USE_AMT) AS 마일리지,
                                           SUM(W.DISC_USE_AMT) AS 행복페이할인,
                                           SUM(x.to_go_disc_amt) AS 포장할인
                                           --SUM(X.DISC_AMT) AS 총할인액,
                                           --SUM(X.TOT_AMT - X.DISC_AMT) AS 결제금액
                                      FROM (SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                   ORDER_NO,
                                                   STATUS,
                                                   MENU_AMT,
                                                   DELI_TIP_AMT,
                                                   MILEAGE_USE_AMT,
                                                   TOT_AMT,
                                                   DISC_AMT,
                                                   to_go_disc_amt,
                                                   (a.coupon_amt + a.coupon_amt2) as coupon,
                                                   shop_coupon_amt
                                              FROM DORDER A,
                                                   CALLCENTER B
                                             WHERE A.CCCODE = B.CCCODE
                                               AND MCODE = 2
                                               AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                               AND STATUS IN ('40',
                                                           '50')
                                               AND NVL(CANCEL_CODE, '00') <> '30'
                                               AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                    AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                               AND TEST_GBN = 'N'
                                             UNION ALL
                                    SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                   ORDER_NO,
                                                   STATUS,
                                                   MENU_AMT,
                                                   DELI_TIP_AMT,
                                                   MILEAGE_USE_AMT,
                                                   TOT_AMT,
                                                   DISC_AMT,
                                                   to_go_disc_amt,
                                                   (a.coupon_amt + a.coupon_amt2) as coupon,
                                                   shop_coupon_amt
                                              FROM DORDER_PAST A,
                                                   CALLCENTER B
                                             WHERE A.CCCODE = B.CCCODE
                                               AND MCODE = 2
                                               AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                               AND STATUS IN ('40',
                                                           '50')
                                               AND NVL(CANCEL_CODE, '00') <> '30'
                                               AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                    AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                               AND TEST_GBN = 'N') X,
                                           (SELECT *
                                              FROM COUPON_MST
                                             WHERE COUPON_TYPE = 'IS_C100') Y,
                                           (SELECT *
                                              FROM COUPON_MST
                                             WHERE COUPON_TYPE = 'IS_C400') Z,
                                           (SELECT ORDER_NO,
                                                   DISC_USE_AMT
                                              FROM DORDER_DISC_DETAIL
                                             WHERE DISC_CODE = '20') W
                                     WHERE X.ORDER_NO = Y.ORDER_NO (+)
                                       AND X.ORDER_NO = Z.ORDER_NO (+)
                                       AND X.ORDER_NO = W.ORDER_NO (+)
                                     GROUP BY X.ORDER_DATE, X.STATUS
                                     ORDER BY 주문일 DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 일자별 주문(완료,최소) 엑셀 통계용
        /// <summary>
        /// 엑셀통계 - 일자별 완료 및 취소(기간조건:ORDER_TIME 주문시간)
        /// </summary>
        [HttpGet("getDailyOrderCompletedCanceled2")]
        public async Task<IActionResult> getDailyOrderCompletedCanceled2(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT X.ORDER_DATE AS 주문일,
                                           DECODE(X.STATUS, '40', '완료', '50', '취소') AS 상태,
                                           COUNT(X.STATUS) AS 수량,
                                           SUM(X.MENU_AMT) AS 총음식금액,
                                           SUM(X.DELI_TIP_AMT) AS 총배달팁,
                                           SUM(X.MENU_AMT + X.DELI_TIP_AMT) AS 총금액,
                                           SUM(Y.COUPON_AMT) AS 첫주문쿠폰,
                                           SUM(Z.COUPON_AMT) AS 재구매쿠폰,
                                           SUM(x.coupon - nvl(y.coupon_amt,0) - nvl(z.coupon_amt,0)) AS 이벤트쿠폰,
                                           SUM(x.shop_coupon_amt) AS 가맹점자체쿠폰,
                                           SUM(X.MILEAGE_USE_AMT) AS 마일리지,
                                           SUM(W.DISC_USE_AMT) AS 행복페이할인,
                                           SUM(x.to_go_disc_amt) AS 포장할인,
                                           SUM(X.DISC_AMT) AS 총할인액,
                                           SUM(X.TOT_AMT - X.DISC_AMT) AS 결제금액
                                      FROM (SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                   ORDER_NO,
                                                   STATUS,
                                                   MENU_AMT,
                                                   DELI_TIP_AMT,
                                                   MILEAGE_USE_AMT,
                                                   TOT_AMT,
                                                   DISC_AMT,
                                                   to_go_disc_amt,
                                                   (a.coupon_amt + a.coupon_amt2) as coupon,
                                                   shop_coupon_amt
                                              FROM DORDER A,
                                                   CALLCENTER B
                                             WHERE A.CCCODE = B.CCCODE
                                               AND MCODE = 2
                                               AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                               AND STATUS IN ('40',
                                                           '50')
                                               AND NVL(CANCEL_CODE, '00') <> '30'
                                               AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                    AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                               AND TEST_GBN = 'N'
                                             UNION ALL
                                    SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                   ORDER_NO,
                                                   STATUS,
                                                   MENU_AMT,
                                                   DELI_TIP_AMT,
                                                   MILEAGE_USE_AMT,
                                                   TOT_AMT,
                                                   DISC_AMT,
                                                   to_go_disc_amt,
                                                   (a.coupon_amt + a.coupon_amt2) as coupon,
                                                   shop_coupon_amt
                                              FROM DORDER_PAST A,
                                                   CALLCENTER B
                                             WHERE A.CCCODE = B.CCCODE
                                               AND MCODE = 2
                                               AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                               AND STATUS IN ('40',
                                                           '50')
                                               AND NVL(CANCEL_CODE, '00') <> '30'
                                               AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                    AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                               AND TEST_GBN = 'N') X,
                                           (SELECT *
                                              FROM COUPON_MST
                                             WHERE COUPON_TYPE = 'IS_C100') Y,
                                           (SELECT *
                                              FROM COUPON_MST
                                             WHERE COUPON_TYPE = 'IS_C400') Z,
                                           (SELECT ORDER_NO,
                                                   DISC_USE_AMT
                                              FROM DORDER_DISC_DETAIL
                                             WHERE DISC_CODE = '20') W
                                     WHERE X.ORDER_NO = Y.ORDER_NO (+)
                                       AND X.ORDER_NO = Z.ORDER_NO (+)
                                       AND X.ORDER_NO = W.ORDER_NO (+)
                                     GROUP BY X.STATUS,rollup(X.ORDER_DATE)
                                     ORDER BY 주문일 DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 일회용품 사용 현황(기간조건설정불가:ORDER_TIME 주문시간)
        /// </summary>
        [HttpGet("getUseDisposablePrd")]
        public async Task<IActionResult> getUseDisposablePrd()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                //param.Add("date_begin", date_begin);
                //param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT ORDER_DATE,
                                       COUNT(*) AS TOTAL_COUNT,
                                       COUNT(CASE WHEN NVL(SHOP_DELI_MEMO,'@') NOT LIKE '%수저포크 X%' THEN 1 ELSE NULL END) AS USE_COUNT,
                                       COUNT(CASE WHEN SHOP_DELI_MEMO LIKE '%수저포크 X%' THEN 1 ELSE NULL END) AS NOT_USE_COUNT
                                  FROM (SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                               SHOP_DELI_MEMO
                                          FROM DORDER A,
                                               CALLCENTER B
                                         WHERE A.CCCODE = B.CCCODE
                                           AND B.MCODE = 2
                                           AND A.ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           AND NVL(A.CANCEL_CODE, '00') <> '30'
                                           AND A.TEST_GBN = 'N'
                                         UNION ALL
                                SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                               SHOP_DELI_MEMO
                                          FROM DORDER_PAST A,
                                               CALLCENTER B
                                         WHERE A.CCCODE = B.CCCODE
                                           AND B.MCODE = 2
                                           AND A.ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           AND NVL(A.CANCEL_CODE, '00') <> '30'
                                           AND A.TEST_GBN = 'N')
                                 GROUP BY ORDER_DATE
                                 ORDER BY ORDER_DATE DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        
        /// <summary>
        /// 엑셀통계 - 배달 거리별 주문수(전체기간)
        /// </summary>
        [HttpGet("getArrivalDistance")]
        public async Task<IActionResult> getArrivalDistance()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                //param.Add("date_begin", date_begin);
                //param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT /*+ rule */ (COUNT(CASE WHEN DISTANCE < 0.5 THEN 1 ELSE NULL END)) AS DIV_05,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 0.5 AND 0.9 THEN 1 ELSE NULL END)) AS DIV_05_09,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 1.0 AND 1.4 THEN 1 ELSE NULL END)) AS DIV_10_14,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 1.5 AND 1.9 THEN 1 ELSE NULL END)) AS DIV_15_19,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 2.0 AND 2.4 THEN 1 ELSE NULL END)) AS DIV_20_24,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 2.5 AND 2.9 THEN 1 ELSE NULL END)) AS DIV_25_29,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 3.0 AND 3.4 THEN 1 ELSE NULL END)) AS DIV_30_34,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 3.5 AND 3.9 THEN 1 ELSE NULL END)) AS DIV_35_39,
                                       (COUNT(CASE WHEN DISTANCE >= 4.0 THEN 1 ELSE NULL END)) AS DIV_40
                                  FROM (SELECT (select SF_CALC_DISTANCE(C.LON, C.LAT, A.DEST_LON, A.DEST_LAT) from dual) AS DISTANCE
                                          FROM DORDER A,
                                               CALLCENTER B,
                                               SHOP_INFO C
                                         WHERE A.CCCODE = B.CCCODE
                                           AND A.SHOP_CD = C.SHOP_CD
                                           AND B.MCODE = 2
                                           AND A.ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           AND NVL(A.CANCEL_CODE, '00') <> '30'
                                           AND A.TEST_GBN = 'N'
                                         UNION ALL
                                SELECT /*+ rule */ (select SF_CALC_DISTANCE(C.LON, C.LAT, A.DEST_LON, A.DEST_LAT) from dual) AS DISTANCE
                                          FROM DORDER_PAST A,
                                               CALLCENTER B,
                                               SHOP_INFO C        
                                         WHERE A.CCCODE = B.CCCODE
                                           AND A.SHOP_CD = C.SHOP_CD
                                           AND B.MCODE = 2
                                           AND A.ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           AND NVL(A.CANCEL_CODE, '00') <> '30'
                                           AND A.TEST_GBN = 'N')
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        //주문 end/

        //회원

        /// <summary>
        /// 엑셀통계 - 일자별 가입 및 탈퇴
        /// </summary>
        [HttpGet("getDailyMemberJoinDel")]
        public async Task<IActionResult> getDailyMemberJoinDel(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> RdataJoin = new List<object>();
            List<object> RdataDel = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT INSERT_DATE AS 가입일 ,
                                       CASE
                                           WHEN CUST_ID_GBN = 'A' THEN '공공앱'
                                           WHEN CUST_ID_GBN = 'G' THEN '구글'
                                           WHEN CUST_ID_GBN = 'I' THEN '아이폰'
                                           WHEN CUST_ID_GBN = 'K' THEN '카카오'
                                           WHEN CUST_ID_GBN = 'N' THEN '네이버'
                                           WHEN CUST_ID_GBN = 'Z' THEN '비회원'
                                           ELSE CUST_ID_GBN
                                       END AS 구분 ,
                                       COUNT(INSERT_DATE) AS 수량
                                  FROM (SELECT TO_CHAR(INSERT_DATE, 'YYYYMMDD') AS INSERT_DATE,
                                               CUST_ID_GBN
                                          FROM APP_CUSTOMER
                                         WHERE MCODE = 2
                                           AND CUST_ID_GBN <> 'Z'
                                           -- AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           AND TO_CHAR(INSERT_DATE, 'YYYYMMDD') BETWEEN :date_begin AND :date_end
                                         UNION ALL
                                SELECT TO_CHAR(INSERT_DATE, 'YYYYMMDD') AS INSERT_DATE,
                                               CUST_ID_GBN
                                          FROM APP_CUSTOMER_DELETED
                                         WHERE MCODE = 2
                                           AND CUST_ID_GBN <> 'Z'
                                           -- AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           AND TO_CHAR(INSERT_DATE, 'YYYYMMDD') BETWEEN :date_begin AND :date_end)
                                 GROUP BY INSERT_DATE, CUBE(CUST_ID_GBN)
                                HAVING COUNT(CUST_ID_GBN) > 0
                                 ORDER BY INSERT_DATE DESC, CUST_ID_GBN
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                RdataJoin = temp.ToList();

                sql = @"
                        SELECT DEL_DATE AS 탈퇴일 ,
                               CASE
                                   WHEN CUST_ID_GBN = 'A' THEN '공공앱'
                                   WHEN CUST_ID_GBN = 'G' THEN '구글'
                                   WHEN CUST_ID_GBN = 'I' THEN '아이폰'
                                   WHEN CUST_ID_GBN = 'K' THEN '카카오'
                                   WHEN CUST_ID_GBN = 'N' THEN '네이버'
                                   WHEN CUST_ID_GBN = 'Z' THEN '비회원'
                                   ELSE CUST_ID_GBN
                               END AS 구분 ,
                               COUNT(DEL_DATE) AS 수량
                          FROM (SELECT TO_CHAR(DEL_DATE, 'YYYYMMDD') AS DEL_DATE,
                                       CUST_ID_GBN
                                  FROM APP_CUSTOMER_DELETED
                                 WHERE MCODE = 2
                                   AND CUST_ID_GBN <> 'Z'
                                   -- AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                   AND TO_CHAR(DEL_DATE, 'YYYYMMDD') BETWEEN :date_begin AND :date_end)
                         GROUP BY DEL_DATE, CUBE(CUST_ID_GBN)
                        HAVING COUNT(CUST_ID_GBN) > 0
                         ORDER BY DEL_DATE DESC, CUST_ID_GBN
                ";

                temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                RdataDel = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, dataJoin = RdataJoin, dataDel = RdataDel });
        }


        /// <summary>
        /// 엑셀통계 - 마일리지 내역
        /// </summary>
        [HttpGet("getMileageHistory")]
        public async Task<IActionResult> getMileageHistory(string divKey, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            string sDate = string.Empty;
            string sUnionAll = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                //1 적립일자 2 주문시간 3 배달완료시간 기준
                switch (divKey)
                {
                    case "1":
                        {
                            sDate = "a.log_date";
                            break;
                        }
                    case "2":
                        {
                            sDate = "case when b.order_time is null then a.log_date else b.order_time end";
                            break;
                        }
                    case "3":
                        {
                            sDate = "case when b.deli_dt is null then a.log_date else b.deli_dt end";
                            break;
                        }
                    default:
                        break;
                }

                date_begin = $@"{date_begin.Substring(4, 2)}/{date_begin.Substring(6, 2)}/{date_begin.Substring(0, 4)}";

                DateTime dtBegin = Convert.ToDateTime(date_begin);

                date_end = $@"{date_end.Substring(4, 2)}/{date_end.Substring(6, 2)}/{date_end.Substring(0, 4)}";

                DateTime dtEnd = Convert.ToDateTime(date_end);

                DateTime dtToday = Convert.ToDateTime(DateTime.Now.AddDays(-2).ToString("MM/dd/yyyy"));

                if (dtBegin >= dtToday || dtEnd >= dtToday)
                {
                    sUnionAll = @$"
                                    UNION ALL
                                                  SELECT a.order_no as 주문번호,a.app_cust_code as 회원코드, c.cust_name as 회원명,
                                        {sDate} as 적립일시,
                                        a.mileage_amt as 적립금액,
                                        (case when a.log_gbn = '3' then b.mileage_use_amt else 0 end) as 사용금액,
                                        a.memo as 메모,
                                        d.shop_name as 사용처
                                    FROM app_cust_mileage_log  a,
                                         dorder b,
                                         (select cust_code, cust_name from app_customer where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                         union all select cust_code, cust_name from app_customer_deleted where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                         ) c,
                                         shop_info d
                                        where a.order_no = b.order_no (+)
                                        and a.app_cust_code = c.cust_code
                                        and nvl(a.shop_cd,'0') = d.shop_cd (+)
                                        AND {sDate} >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND TO_CHAR ({sDate}, 'yyyyMMdd') BETWEEN :date_begin
                                                                                AND :date_end
                                ";
                }

                string sql = $@"
                                SELECT * FROM(SELECT a.order_no as 주문번호,a.app_cust_code as 회원코드, c.cust_name as 회원명,
                                        {sDate} as 적립일시,
                                        a.mileage_amt as 적립금액,
                                        (case when a.log_gbn = '3' then b.mileage_use_amt else 0 end) as 사용금액,
                                        a.memo as 메모,
                                        d.shop_name as 사용처
                                    FROM app_cust_mileage_log  a,
                                         dorder_past b,
                                         (select cust_code, cust_name from app_customer where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                         union all select cust_code, cust_name from app_customer_deleted where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        ) c,
                                         shop_info d
                                        where a.order_no = b.order_no (+)
                                        and a.app_cust_code = c.cust_code
                                        and nvl(a.shop_cd,'0') = d.shop_cd (+)
                                        AND {sDate} >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND TO_CHAR ({sDate}, 'yyyyMMdd') BETWEEN :date_begin
                                                                                AND :date_end
                                        {sUnionAll})
                                  order by 적립일시
                                ";

                //string sql = @"
                //                 SELECT * FROM (SELECT a.order_no AS 주문번호,
                //                        a.log_date AS 적립일시,
                //                        d.cust_name AS 회원명,
                //                        d.cust_code AS 회원코드,
                //                        a.mileage_amt AS 적립금액,
                //                        (case when a.log_gbn = '3' then b.mileage_use_amt else 0 end) AS 사용금액,
                //                        c.shop_name AS 사용처,
                //                        a.memo AS 메모
                //                    FROM app_cust_mileage_log  a,
                //                        dorder                b,
                //                        shop_info             c,
                //                        (select mcode, cust_code, cust_name from app_customer 
                //                        union all 
                //                        select mcode, cust_code, cust_name from app_customer_deleted)  d,
                //                        callcenter            e
                //                    WHERE     a.order_no = b.order_no
                //                        AND b.shop_cd = c.shop_cd
                //                        AND c.cccode = e.cccode
                //                        AND e.mcode = 2
                //                        AND d.mcode = 2
                //                        and b.status <> '50'
                //                        AND a.app_cust_code = d.cust_code
                //                        AND b.TEST_GBN = 'N'
                //                        AND NVL(b.cancel_code,'00')<>'30'
                //                        AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                //                        AND TO_CHAR (a.log_date, 'yyyyMMdd') BETWEEN :date_begin
                //                                                                AND :date_end
                //                UNION ALL
                //                SELECT a.order_no,
                //                        a.log_date,
                //                        d.cust_name,
                //                        d.cust_code,
                //                        a.mileage_amt,
                //                        (case when a.log_gbn = '3' then b.mileage_use_amt else 0 end),
                //                        c.shop_name,
                //                        a.memo
                //                    FROM app_cust_mileage_log  a,
                //                        dorder_past            b,
                //                        shop_info             c,
                //                        (select mcode, cust_code, cust_name from app_customer 
                //                        union all 
                //                        select mcode, cust_code, cust_name from app_customer_deleted)  d,
                //                        callcenter            e        
                //                    WHERE     a.order_no = b.order_no
                //                        AND b.shop_cd = c.shop_cd
                //                        AND c.cccode = e.cccode
                //                        AND e.mcode = 2
                //                        AND d.mcode = 2
                //                        and b.status <> '50'
                //                        AND a.app_cust_code = d.cust_code
                //                        AND b.TEST_GBN = 'N'
                //                        AND NVL(b.cancel_code,'00')<>'30'
                //                        AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                //                        AND TO_CHAR (a.log_date, 'yyyyMMdd') BETWEEN :date_begin
                //                                                                AND :date_end)
                //                ORDER BY 적립일시 DESC
                //";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 엑셀통계 - 마일리지 내역(기간별 마일리지 총액)
        /// </summary>
        [HttpGet("getTotalMileage")]
        public async Task<IActionResult> getTotalMileage(string divKey, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            string sDate = string.Empty;
            string sUnionAll = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                //1 적립일자 2 주문시간 3 배달완료시간 기준
                switch (divKey)
                {
                    case "1":
                        {
                            sDate = "a.log_date";
                            break;
                        }
                    case "2":
                        {
                            sDate = "case when b.order_time is null then a.log_date else b.order_time end";
                            break;
                        }
                    case "3":
                        {
                            sDate = "case when b.deli_dt is null then a.log_date else b.deli_dt end";
                            break;
                        }
                    default:
                        break;
                }

                string sql = @$"
                                SELECT a.memo as 메모, sum(a.mileage_amt) as 금액
                                    FROM app_cust_mileage_log  a,
                                         dorder_past b,
                                         (select cust_code, cust_name from app_customer where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                         union all select cust_code, cust_name from app_customer_deleted where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        ) c,
                                         shop_info d
                                        where a.order_no = b.order_no (+)
                                        and a.app_cust_code = c.cust_code
                                        and nvl(a.shop_cd,'0') = d.shop_cd (+)
                                        AND {sDate} >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND TO_CHAR ({sDate}, 'yyyyMMdd') BETWEEN :date_begin
                                                                                AND :date_end
                                                                                group by rollup(a.memo)
                                                                                order by a.memo
                                ";

                //string sql = @$"
                //                select sum(a.mileage_amt) 
                //                from app_cust_mileage_log a, 
                //                    (select cust_code, cust_name from app_customer where mcode = 2 AND TEST_GBN = 'R' AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                //                    union all 
                //                    select cust_code, cust_name from app_customer_deleted where mcode = 2 AND TEST_GBN = 'R' AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')) b
                //                where a.app_cust_code = b.cust_code   
                //                  AND a.log_date >= TO_DATE('2021080917','YYYYMMDDHH24')
                //                  and a.log_date <= TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                //";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);
                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 쿠폰내역
        /// </summary>
        [HttpGet("getCouponHistory")]
        public async Task<IActionResult> getCouponHistory(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                 SELECT A.COUPON_NAME AS 쿠폰명,
                                         A.COUPON_AMT AS 쿠폰금액,
                                         A.ST_DATE AS 지급일시,
                                         A.EXP_DATE AS 만기일시,
                                         DECODE (a.status, '00', '대기', '10', '승인', '20', '미사용', '30', '사용', '99', '만료') as 사용여부,
                                         B.CUST_NAME AS 회원명,
                                         A.APP_CUST_CODE AS 회원코드,
                                         D.SHOP_NAME AS 사용처,
                                         decode (a.status, '30', a.coupon_amt) as 사용금액
                                    FROM COUPON_MST  A,
                                         (select cust_code, cust_name from APP_CUSTOMER union all select cust_code, cust_name from APP_CUSTOMER_deleted) B,
                                         (SELECT * FROM DORDER 
                                         WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND TEST_GBN = 'N'
                                        AND NVL(CANCEL_CODE,'00') <> '30'
                                         UNION ALL 
                                         SELECT * FROM DORDER_PAST
                                         WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND TEST_GBN = 'N'
                                        AND NVL(CANCEL_CODE,'00') <> '30') C,
                                        SHOP_INFO D
                                   WHERE     A.APP_CUST_CODE = B.CUST_CODE(+)
                                         AND A.order_no = C.order_no(+)
                                         AND C.SHOP_CD = D.SHOP_CD (+)
                                         AND A.ST_DATE BETWEEN :date_begin AND :date_end
                                ORDER BY A.coupon_type, a.status desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }

        
        /// <summary>
        /// 엑셀통계 - 기간별 주문실적
        /// </summary>
        /// <remarks>
        /// 회원별 이용 ( 0회 ~ 10회 이상 )/ div: 1 주문전체, 2 완료건만 <br/>
        /// 주문기간 기준 + 종료일 당일가입 회원까지만
        /// </remarks>
        [HttpGet("getAppCustomerCount")]
        public async Task<IActionResult> getAppCustomerCount(string date_begin, string date_end, string div)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("div", div);

                db.Open();

                string sql = @"
                                SELECT 0
                                           DAY_COUNT,
                                       (SELECT COUNT (*)
                                          FROM (SELECT mcode,
                                                       test_gbn,
                                                       cust_id_gbn,
                                                       insert_date,
                                                       cust_code
                                                  FROM app_customer
                                                UNION ALL
                                                SELECT mcode,
                                                       test_gbn,
                                                       cust_id_gbn,
                                                       insert_date,
                                                       cust_code
                                                  FROM app_customer_deleted) a
                                         WHERE     a.mcode = 2
                                               AND a.test_gbn = 'R'
                                               AND a.cust_id_gbn <> 'Z'
                                               -- AND a.insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                               AND to_char(a.insert_date,'YYYYMMDD') <= :date_end
                                               AND NOT EXISTS
                                                       (SELECT b.ccode
                                                          FROM (SELECT * FROM dorder
                                                                UNION ALL
                                                                SELECT * FROM dorder_past) b
                                                         WHERE     a.cust_code = b.ccode
                                                               and case when :div = 2 then b.status else '40' end = '40' -- div에따라 전체주문기준, 완료기준
                                                               AND b.order_time >=
                                                                   TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                               AND TO_CHAR (b.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                          AND :date_end
                                                               AND b.test_gbn = 'N'
                                                               AND NVL (b.cancel_code, '00') <> '30'))
                                           ORDER_COUNT
                                  FROM DUAL
                                UNION ALL
                                    SELECT ROWNUM
                                               DAY_COUNT,
                                           DECODE (ROWNUM,
                                                   1, day1,
                                                   2, day2,
                                                   3, day3,
                                                   4, day4,
                                                   5, day5,
                                                   6, day6,
                                                   7, day7,
                                                   8, day8,
                                                   9, day9,
                                                   10, day10)
                                               order_count
                                      FROM (SELECT SUM (CASE WHEN (cnt = 1) THEN 1 ELSE 0 END)     day1,
                                                   SUM (CASE WHEN (cnt = 2) THEN 1 ELSE 0 END)     day2,
                                                   SUM (CASE WHEN (cnt = 3) THEN 1 ELSE 0 END)     day3,
                                                   SUM (CASE WHEN (cnt = 4) THEN 1 ELSE 0 END)     day4,
                                                   SUM (CASE WHEN (cnt = 5) THEN 1 ELSE 0 END)     day5,
                                                   SUM (CASE WHEN (cnt = 6) THEN 1 ELSE 0 END)     day6,
                                                   SUM (CASE WHEN (cnt = 7) THEN 1 ELSE 0 END)     day7,
                                                   SUM (CASE WHEN (cnt = 8) THEN 1 ELSE 0 END)     day8,
                                                   SUM (CASE WHEN (cnt = 9) THEN 1 ELSE 0 END)     day9,
                                                   SUM (CASE WHEN (cnt > 9) THEN 1 ELSE 0 END)     day10
                                              FROM (  SELECT ccode, COUNT (*) cnt
                                                        FROM (SELECT a.*
                                                                FROM (select * from dorder 
                                                                union all 
                                                                select * from dorder_past) a, 
                                                                (SELECT mcode,
                                                                       test_gbn,
                                                                       cust_id_gbn,
                                                                       insert_date,
                                                                       cust_code
                                                                  FROM app_customer
                                                                UNION ALL
                                                                SELECT mcode,
                                                                       test_gbn,
                                                                       cust_id_gbn,
                                                                       insert_date,
                                                                       cust_code
                                                                  FROM app_customer_deleted) c
                                                               WHERE a.ccode = c.cust_code
                                                                     AND c.mcode = 2
                                                                     AND c.cust_id_gbn <> 'Z'
                                                                     AND c.test_gbn = 'R'
                                                                     -- AND c.insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND a.test_gbn = 'N'
                                                                     and case when :div = 2 then a.status else '40' end = '40' -- div에따라 전체주문기준, 완료기준
                                                                     AND a.order_time >=
                                                                         TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND NVL (a.cancel_code, '00') <> '30'
                                                                     AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                                AND :date_end
                                                              )
                                                    GROUP BY ccode))
                                CONNECT BY LEVEL <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 연령별 주문실적
        /// </summary>
        [HttpGet("getAgeToOrder")]
        public async Task<IActionResult> getAgeToOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();


                if (date_begin.Equals("20210809"))
                {
                    date_begin = "2021080917";
                }
                else
                {
                    date_begin = date_begin + "00";
                }

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT case when birthday is null then 0
                                            when birthday < 1 then 1
                                            when birthday > 9 then 9
                                            else birthday end || '0대' AS year, COUNT (*) COUNT, 
                                       COUNT(CASE WHEN STATUS = '40' THEN 1 END) AS COMP, 
                                       COUNT(CASE WHEN STATUS = '50' THEN 1 END) AS CANC
                                FROM (SELECT trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                             birthday, STATUS
                                    FROM (SELECT cust_code,
                                                 birthday
                                            FROM app_customer
                                          UNION ALL
                                          SELECT cust_code,
                                                 birthday
                                            FROM app_customer_deleted) a, 
                                                (select ccode,STATUS from dorder
                                                where ORDER_TIME between 
                                                    TO_DATE(:date_begin,'YYYYMMDDHH24') and 
                                                    TO_DATE(:date_end || 235959,'YYYYMMDDHH24MISS')
                                                  AND TEST_GBN = 'N'
                                                  AND NVL(CANCEL_CODE,'00') <> '30'
                                                union all
                                                select ccode,STATUS from dorder_past
                                                where ORDER_TIME between 
                                                    TO_DATE(:date_begin,'YYYYMMDDHH24') and 
                                                    TO_DATE(:date_end || 235959,'YYYYMMDDHH24MISS')
                                                  AND TEST_GBN = 'N'
                                                  AND NVL(CANCEL_CODE,'00') <> '30') b
                                    where a.cust_code = b.ccode
                                   )
                        GROUP BY case when birthday is null then 0
                                      when birthday < 1 then 1
                                      when birthday > 9 then 9
                                      else birthday end
                        ORDER BY case when birthday is null then 0
                                      when birthday < 1 then 1
                                      when birthday > 9 then 9
                                      else birthday end
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        
        /// <summary>
        /// 엑셀통계 - OS별 설치
        /// </summary>
        [HttpGet("getInstalled")]
        public async Task<IActionResult> getInstalled(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @$"
                                 SELECT to_char(insert_date,'YYYYMMDD') ins_date, 
                                        count(case when device_gbn = 'A' then 1 end) android, 
                                        count(case when device_gbn = 'I' then 1 end) IOS, 
                                        count(*) total
                                    FROM (SELECT mcode,
                                                 insert_date,
                                                 cust_id_gbn,
                                                 test_gbn,
                                                 device_gbn
                                            FROM app_customer
                                          UNION ALL
                                          SELECT mcode,
                                                 insert_date,
                                                 cust_id_gbn,
                                                 test_gbn,
                                                 device_gbn
                                            FROM app_customer_deleted)
                                   WHERE     mcode = 2
                                         AND device_gbn IS NOT NULL
                                         AND cust_id_gbn = 'Z'
                                         AND test_gbn = 'R'
                                         AND insert_date between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                GROUP BY to_char(insert_date,'YYYYMMDD')
                                order by to_char(insert_date,'YYYYMMDD') desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 연령별 가입
        /// </summary>
        [HttpGet("getCustomerAge")]
        public async Task<IActionResult> getCustomerAge(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @$"
                                 SELECT insert_date, 
                                        count(case when birthday <= 1 then 1 end) as year10,
                                        count(case when birthday = 2 then 1 end) as year20,
                                        count(case when birthday = 3 then 1 end) as year30,
                                        count(case when birthday = 4 then 1 end) as year40,
                                        count(case when birthday = 5 then 1 end) as year50,
                                        count(case when birthday = 6 then 1 end) as year60,
                                        count(case when birthday = 7 then 1 end) as year70,
                                        count(case when birthday >= 8 then 1 end) as year80,
                                        count(case when birthday is null then 1 end) as nodata,
                                        count(1) as total
                            FROM (SELECT TO_CHAR (insert_date, 'YYYYMMDD')
                                             AS insert_date,
                                         trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                             birthday
                                    FROM (SELECT mcode,
                                                 insert_date,
                                                 birthday,
                                                 test_gbn,
                                                 CUST_ID_GBN
                                            FROM app_customer
                                          UNION ALL
                                          SELECT mcode,
                                                 insert_date,
                                                 birthday,
                                                 test_gbn,
                                                 CUST_ID_GBN
                                            FROM app_customer_deleted)
                                   WHERE     mcode = 2
                                         AND test_gbn = 'R'
                                         AND CUST_ID_GBN <> 'Z'
                                         AND insert_date between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS'))
                        GROUP BY insert_date
                        ORDER BY insert_date DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 회원 주문순위
        /// </summary>
        /// <remarks>
        /// div: 1 완료수 많은/ 2 완료금액 많은/ 3 주문수 많은/ 4 주문금액 많은 <br/>
        /// 금액기준 (TOT_AMT: 메뉴주문금액 + 배달팁금액)
        /// </remarks>
        [HttpGet("getCustomerRank10")]
        public async Task<IActionResult> getCustomerRank10(string div, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("div", div);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();


                string sql = @$"
                                select rownum rnum, a.*
                                from(select case when :div in (2,4) then sum(a.tot_amt) else count(1) end as 값, b.cust_name 회원명, b.cust_code
                                from (select * from dorder union all select * from dorder_past) a, 
                                (select cust_code, cust_name from app_customer where cust_id_gbn <> 'Z' and test_gbn = 'R' and mcode = 2
                                union all 
                                select cust_code, cust_name from app_customer_deleted where cust_id_gbn <> 'Z' and test_gbn = 'R' and mcode = 2) b, callcenter c
                                where a.app_cust_code = b.cust_code
                                and a.status in ('40', case when :div in (3,4) then '50' end)
                                and a.cccode = c.cccode
                                and c.mcode = 2
                                AND a.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND a.TEST_GBN = 'N'
                                AND NVL(a.CANCEL_CODE,'00') <> '30' 
                                and a.order_time between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                group by b.cust_code, b.cust_name
                                order by case when :div in (2,4) then sum(a.tot_amt) else count(a.order_no) end desc ) a
                                where rownum <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        //회원 end/

        //대구로 통계(통합) end/


        // 대구로 APP 시범서비스 운영현황 보고(미사용)
        [HttpGet("getDaeguroTotalInfo")]
        public async Task<IActionResult> getDaeguroTotalInfo()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> totalInstalled = new List<object>();
            List<object> osInstalled = new List<object>();
            List<object> totalYearMembers = new List<object>();
            List<object> yearMembers = new List<object>();
            List<object> totalOrders = new List<object>();
            List<object> orders = new List<object>();
            List<object> totalCancel = new List<object>();
            List<object> cancels = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                //DynamicParameters param = new DynamicParameters();
                //param.Add("date_begin", date_begin);
                //param.Add("date_end", date_end);

                // 누적 설치수
                string sql = @"
                                  SELECT device_gbn, COUNT (*) COUNT
                                    FROM (SELECT mcode,
                                                 insert_date,
                                                 cust_id_gbn,
                                                 test_gbn,
                                                 device_gbn
                                            FROM app_customer
                                          UNION ALL
                                          SELECT mcode,
                                                 insert_date,
                                                 cust_id_gbn,
                                                 test_gbn,
                                                 device_gbn
                                            FROM app_customer_deleted)
                                   WHERE     mcode = 2
                                         AND device_gbn IS NOT NULL
                                         AND cust_id_gbn = 'Z'
                                         AND insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND test_gbn = 'R'
                                GROUP BY device_gbn
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalInstalled = temp.ToList();

                // 당일, 전일 설치수
                sql = @"
                          SELECT TO_CHAR (insert_date, 'YYYYMMDD')     insert_date,
                                 device_gbn,
                                 COUNT (*)                             COUNT
                            FROM (SELECT mcode,
                                         device_gbn,
                                         insert_date,
                                         cust_id_gbn,
                                         test_gbn
                                    FROM app_customer
                                  UNION ALL
                                  SELECT mcode,
                                         device_gbn,
                                         insert_date,
                                         cust_id_gbn,
                                         test_gbn
                                    FROM app_customer_deleted)
                           WHERE     mcode = 2
                                 AND device_gbn IS NOT NULL
                                 AND cust_id_gbn = 'Z'
                                 AND test_gbn = 'R'
                                 AND TO_CHAR (insert_date, 'yyyyMMdd') BETWEEN TO_CHAR (SYSDATE - 2,
                                                                                        'yyyyMMdd')
                                                                           AND TO_CHAR (SYSDATE - 1,
                                                                                        'yyyyMMdd')
                        GROUP BY TO_CHAR (insert_date, 'YYYYMMDD'), device_gbn
                        ORDER BY insert_date DESC
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                osInstalled = temp.ToList();


                // 누적 회원(연령대) 수
                sql = @"
                          SELECT birthday || '0대' AS year, COUNT (*) COUNT
                            FROM (SELECT TO_CHAR (insert_date, 'YYYYMMDD')
                                             AS insert_date,
                                         SUBSTR (TO_CHAR (2021 - TO_NUMBER (SUBSTR (birthday, 1, 4))),
                                                 1,
                                                 1)
                                             birthday
                                    FROM (SELECT mcode, insert_date, birthday FROM app_customer
                                          UNION ALL
                                          SELECT mcode, insert_date, birthday FROM app_customer_deleted)
                                   WHERE     mcode = 2
                                         AND insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND test_gbn = 'R'
                                         AND birthday IS NOT NULL)
                        GROUP BY birthday
                        ORDER BY birthday
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalYearMembers = temp.ToList();

                // 당일, 전일 회원(연령대) 수
                sql = @"
                          SELECT insert_date, birthday || '0대' AS year, COUNT (*)
                            FROM (SELECT TO_CHAR (insert_date, 'YYYYMMDD')
                                             AS insert_date,
                                         SUBSTR (TO_CHAR (2021 - TO_NUMBER (SUBSTR (birthday, 1, 4))),
                                                 1,
                                                 1)
                                             birthday
                                    FROM (SELECT mcode, insert_date, birthday, test_gbn FROM app_customer
                                          UNION ALL
                                          SELECT mcode, insert_date, birthday, test_gbn FROM app_customer_deleted)
                                   WHERE     mcode = 2
                                         AND birthday IS NOT NULL
                                         AND test_gbn = 'R'
                                         AND insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND TO_CHAR (insert_date, 'yyyyMMdd') BETWEEN TO_CHAR (
                                                                                           SYSDATE - 2,
                                                                                           'yyyyMMdd')
                                                                                   AND TO_CHAR (
                                                                                           SYSDATE - 1,
                                                                                           'yyyyMMdd'))
                        GROUP BY insert_date, birthday
                        ORDER BY insert_date DESC, birthday
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                yearMembers = temp.ToList();


                // 누적 완료/취소 주문수
                sql = @"
                          SELECT /*+ full(a)full(b) */ DECODE (a.status,  '40', '완료',  '50', '취소')     status,
                                 COUNT (*) COUNT
                            FROM (SELECT * FROM dorder
                                  UNION ALL
                                  SELECT * FROM dorder_past) a,
                                 callcenter b
                           WHERE     a.cccode = b.cccode
                                 AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                 AND b.mcode = 2
                                 AND a.test_gbn = 'N'
                                 AND a.status IN ('40', '50')
                        GROUP BY a.status
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalOrders = temp.ToList();

                // 당일, 전일 완료/취소 주문수
                sql = @"
                          SELECT /*+ full(a)full(b) */ a.order_date,
                                 DECODE (a.status,  '40', '완료',  '50', '취소')     status,
                                 COUNT (*) COUNT
                            FROM (SELECT * FROM dorder
                                  UNION ALL
                                  SELECT * FROM dorder_past) a,
                                 callcenter b
                           WHERE     a.cccode = b.cccode
                                 AND b.mcode = 2
                                 AND a.test_gbn = 'N'
                                 AND a.status IN ('40', '50')
                                 AND a.order_date BETWEEN TO_CHAR (SYSDATE - 2, 'yyyyMMdd')
                                                      AND TO_CHAR (SYSDATE - 1, 'yyyyMMdd')
                        GROUP BY a.order_date, a.status
                        ORDER BY a.order_date DESC
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                orders = temp.ToList();

                // 누적 주문취소 사유별 건수
                sql = @"
                          SELECT /*+ full(a)full(b) */ DECODE (cancel_code,
                                         '00', '사유없음',
                                         '10', '고객본인취소',
                                         '11', '시간지연',
                                         '12', '재접수',
                                         '20', '가맹점취소',
                                         '21', '배달불가',
                                         '22', '메뉴품절',
                                         '23', '가맹점휴무',
                                         '24', '주소입력오류',
                                         '25', '가맹점 정산 접수거부',
                                         '26', 'POS서버 응답없음',
                                         '30', '결재대기 자동취소',
                                         '40', '예약주문 고객 취소',
                                         '45', '예약주문 가맹점 취소')
                                     cancel_code,
                                 COUNT (cancel_code)
                                     COUNT
                            FROM (SELECT * FROM dorder
                                  UNION ALL
                                  SELECT * FROM dorder_past) a,
                                 callcenter b
                           WHERE     a.cccode = b.cccode
                                 AND b.mcode = 2
                                 AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                 AND a.test_gbn = 'N'
                                 AND NVL (a.cancel_code, '00') <> '30'
                                 AND a.cancel_code IS NOT NULL
                        GROUP BY cancel_code
                        ORDER BY COUNT DESC
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalCancel = temp.ToList();

                // 당일, 전일 주문취소 사유별 건수
                sql = @"
                          SELECT /*+ full(a)full(b) */ order_date,
                                 DECODE (cancel_code,
                                         '00', '사유없음',
                                         '10', '고객본인취소',
                                         '11', '시간지연',
                                         '12', '재접수',
                                         '20', '가맹점취소',
                                         '21', '배달불가',
                                         '22', '메뉴품절',
                                         '23', '가맹점휴무',
                                         '24', '주소입력오류',
                                         '25', '가맹점 정산 접수거부',
                                         '26', 'POS서버 응답없음',
                                         '30', '결재대기 자동취소',
                                         '40', '예약주문 고객 취소',
                                         '45', '예약주문 가맹점 취소')
                                     cancel_code,
                                 COUNT (cancel_code)
                                     COUNT
                            FROM (SELECT * FROM dorder
                                  UNION ALL
                                  SELECT * FROM dorder_past) a,
                                 callcenter b
                           WHERE     a.cccode = b.cccode
                                 AND b.mcode = 2
                                 AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                 AND a.test_gbn = 'N'
                                 AND NVL (a.cancel_code, '00') <> '30'
                                 AND a.cancel_code IS NOT NULL
                                 AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN TO_CHAR (SYSDATE - 2,
                                                                                         'yyyyMMdd')
                                                                            AND TO_CHAR (SYSDATE - 1,
                                                                                         'yyyyMMdd')
                        GROUP BY order_date, cancel_code
                        ORDER BY order_date DESC
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                cancels = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalOS = totalInstalled, os = osInstalled, totalYearMembers = totalYearMembers, yearMembers = yearMembers, totalOrders = totalOrders, orders = orders, totalCancel = totalCancel, cancels = cancels });
        }


        // 일자별 회원/비회원(미사용)
        [HttpGet("getDailyMemberCount")]
        public async Task<IActionResult> getDailyMemberCount()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                  SELECT INSERT_DATE
                                             AS 가입일,
                                         CASE
                                             WHEN CUST_GBN = '1' THEN '비회원'
                                             WHEN CUST_GBN = '2' THEN '회원'
                                             ELSE CUST_GBN
                                         END
                                             AS 구분,
                                         COUNT (CUST_GBN)
                                             AS 수량
                                    FROM (SELECT TO_CHAR (INSERT_DATE, 'YYYYMMDD')       AS INSERT_DATE,
                                                 DECODE (CUST_ID_GBN, 'Z', '1', '2')     CUST_GBN
                                            FROM (SELECT mcode, insert_date, cust_id_gbn FROM app_customer
                                                  UNION ALL
                                                  SELECT mcode, insert_date, cust_id_gbn
                                                    FROM app_customer_deleted)
                                           WHERE     MCODE = 2
                                                 AND TEST_GBN = 'R'
                                                 AND INSERT_DATE > TO_DATE ('2021080917', 'YYYYMMDDHH24'))
                                GROUP BY INSERT_DATE, CUST_GBN
                                ORDER BY 가입일 DESC
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 일자별 가입회원 수 : 계정구분(미사용)
        [HttpGet("getDailyMemberDiv")]
        public async Task<IActionResult> getDailyMemberDiv()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT INSERT_DATE AS 가입일 ,
                                       CASE
                                           WHEN CUST_ID_GBN = 'A' THEN '공공앱'
                                           WHEN CUST_ID_GBN = 'G' THEN '구글'
                                           WHEN CUST_ID_GBN = 'I' THEN '아이폰'
                                           WHEN CUST_ID_GBN = 'K' THEN '카카오'
                                           WHEN CUST_ID_GBN = 'N' THEN '네이버'
                                           WHEN CUST_ID_GBN = 'Z' THEN '비회원'
                                           ELSE CUST_ID_GBN
                                       END AS 구분 ,
                                       COUNT(INSERT_DATE) AS 수량
                                  FROM (SELECT TO_CHAR(INSERT_DATE, 'YYYYMMDD') AS INSERT_DATE,
                                               CUST_ID_GBN
                                          FROM APP_CUSTOMER
                                         WHERE MCODE = 2
                                           AND CUST_ID_GBN <> 'Z'
                                           AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                         UNION ALL
                                SELECT TO_CHAR(INSERT_DATE, 'YYYYMMDD') AS INSERT_DATE,
                                               CUST_ID_GBN
                                          FROM APP_CUSTOMER_DELETED
                                         WHERE MCODE = 2
                                           AND CUST_ID_GBN <> 'Z'
                                           AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24'))
                                 GROUP BY INSERT_DATE, CUST_ID_GBN
                                HAVING COUNT(CUST_ID_GBN) > 0
                                 ORDER BY INSERT_DATE DESC, CUST_ID_GBN
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata});
        }

        // 일자별 탈퇴 회원 수
        [HttpGet("getDailyMemberDel")]
        public async Task<IActionResult> getDailyMemberDel(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT TO_CHAR(DEL_DATE, 'YYYYMMDD') AS DEL_DATE,
                                       COUNT(*) COUNT
                                  FROM APP_CUSTOMER_DELETED
                                 WHERE MCODE = 2
                                   AND CUST_ID_GBN <> 'Z'
                                   AND DEL_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                   AND TO_CHAR(DEL_DATE, 'YYYYMMDD') BETWEEN :date_begin AND :date_end
                                 GROUP BY TO_CHAR(DEL_DATE,
                                               'YYYYMMDD')
                                 ORDER BY DEL_DATE
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 일자별 성별(미사용)
        [HttpGet("getDailyMemberGender")]
        public async Task<IActionResult> getDailyMemberGender()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                  SELECT INSERT_DATE
                                             AS 가입일,
                                         CASE
                                             WHEN GENDER = 'F' THEN '여성'
                                             WHEN GENDER = 'M' THEN '남성'
                                             WHEN GENDER IS NULL THEN 'NULL'
                                             ELSE GENDER
                                         END
                                             AS 성별,
                                         COUNT (GENDER)
                                             AS 수량
                                    FROM (SELECT TO_CHAR (INSERT_DATE, 'YYYYMMDD')     AS INSERT_DATE,
                                                 NVL (GENDER, '알수없음')          AS GENDER
                                            FROM (SELECT mcode,
                                                         insert_date,
                                                         cust_id_gbn,
                                                         gender,
                                                         test_gbn
                                                    FROM app_customer
                                                  UNION ALL
                                                  SELECT mcode,
                                                         insert_date,
                                                         cust_id_gbn,
                                                         gender,
                                                         test_gbn
                                                    FROM app_customer_deleted)
                                           WHERE     MCODE = 2
                                                 AND CUST_ID_GBN <> 'Z'
                                                 AND TEST_GBN = 'R'
                                                 AND INSERT_DATE > TO_DATE ('2021080917', 'YYYYMMDDHH24'))
                                GROUP BY INSERT_DATE, GENDER
                                  HAVING COUNT (GENDER) > 0
                                ORDER BY INSERT_DATE DESC, GENDER
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 일자별 나이별(미사용)
        [HttpGet("getDailyMemberAge")]
        public async Task<IActionResult> getDailyMemberAge()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                  SELECT INSERT_DATE            가입일,
                                         BIRTHDAY || '0대'     AS 연령,
                                         COUNT (BIRTHDAY)       AS 수량
                                    FROM (SELECT TO_CHAR (INSERT_DATE, 'YYYYMMDD')
                                                     AS INSERT_DATE,
                                                 SUBSTR (TO_CHAR (2021 - TO_NUMBER (SUBSTR (BIRTHDAY, 1, 4))),
                                                         1,
                                                         1)
                                                     AS BIRTHDAY,
                                                 CASE WHEN NVL (BIRTHDAY, 1) = 1 THEN 1 ELSE 0 END
                                                     AS BIRTHDAY_NULL
                                            FROM (SELECT mcode,
                                                         insert_date,
                                                         birthday,
                                                         cust_id_gbn,
                                                         test_gbn
                                                    FROM app_customer
                                                  UNION ALL
                                                  SELECT mcode,
                                                         insert_date,
                                                         birthday,
                                                         cust_id_gbn,
                                                         test_gbn
                                                    FROM app_customer_deleted)
                                           WHERE     MCODE = 2
                                                 AND INSERT_DATE BETWEEN TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND TRUNC (SYSDATE)
                                                 AND CUST_ID_GBN <> 'Z'
                                                 AND TEST_GBN = 'R')
                                GROUP BY INSERT_DATE, BIRTHDAY
                                  HAVING COUNT (BIRTHDAY) > 0
                                ORDER BY INSERT_DATE DESC, BIRTHDAY
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // OS별 회원(미사용)
        [HttpGet("getDailyMemberOS")]
        public async Task<IActionResult> getDailyMemberOS()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                              SELECT INSERT_DATE
                                         AS 가입일,
                                     DECODE (DEVICE_GBN,  'A', '안드로이드',  'I', '아이폰')
                                         AS OS,
                                     COUNT (DEVICE_GBN)
                                         AS 수량
                                FROM (SELECT TO_CHAR (INSERT_DATE, 'YYYYMMDD') AS INSERT_DATE, DEVICE_GBN
                                        FROM (SELECT mcode,
                                                     insert_date,
                                                     cust_id_gbn,
                                                     test_gbn,
                                                     device_gbn
                                                FROM app_customer
                                              UNION ALL
                                              SELECT mcode,
                                                     insert_date,
                                                     cust_id_gbn,
                                                     test_gbn,
                                                     device_gbn
                                                FROM app_customer_deleted)
                                       WHERE     MCODE = 2
                                             AND INSERT_DATE BETWEEN TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                 AND TRUNC (SYSDATE)
                                             AND CUST_ID_GBN = 'Z'
                                             AND TEST_GBN = 'R'
                                             AND DEVICE_GBN IN ('A', 'I'))
                            GROUP BY INSERT_DATE, DEVICE_GBN
                            ORDER BY INSERT_DATE DESC
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 전체건수
        [HttpGet("getOrderCount")]
        public async Task<IActionResult> getOrderCount()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT ORDER_DATE AS 주문일,
                                       DECODE(STATUS, '10', '접수', '20', '대기', '30', '가맹점접수확인', '35', '운행', '40', '완료', '50', '취소', '80', '결제대기') AS 상태,
                                       COUNT(STATUS) AS 수량
                                  FROM (SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                               STATUS
                                          FROM DORDER A,
                                               CALLCENTER B
                                         WHERE A.CCCODE = B.CCCODE
                                           AND MCODE = 2
                                           AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           AND NVL(CANCEL_CODE, '00') <> '30'
                                           AND TEST_GBN = 'N'
                                         UNION ALL
                                SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                               STATUS
                                          FROM DORDER_PAST A,
                                               CALLCENTER B
                                         WHERE A.CCCODE = B.CCCODE
                                           AND MCODE = 2
                                           AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           AND NVL(CANCEL_CODE, '00') <> '30'
                                           AND TEST_GBN = 'N')
                                 GROUP BY ORDER_DATE, STATUS
                                 ORDER BY 주문일 DESC
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 취소사유현황
        [HttpGet("getCancelReason")]
        public async Task<IActionResult> getCancelReason()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                  SELECT DECODE (cancel_code,
                                                 '00', '사유없음',
                                                 '10', '고객본인취소',
                                                 '11', '시간지연',
                                                 '12', '재접수',
                                                 '20', '가맹점취소',
                                                 '21', '배달불가',
                                                 '22', '메뉴품절',
                                                 '23', '가맹점휴무',
                                                 '24', '주소입력오류',
                                                 '25', '가맹점 정산 접수거부',
                                                 '26', 'POS서버 응답없음',
                                                 '30', '결재대기 자동취소',
                                                 '40', '예약주문 고객 취소',
                                                 '45', '예약주문 가맹점 취소')
                                             cancel_code,
                                         COUNT (cancel_code)
                                             COUNT
                                    FROM (SELECT * FROM dorder
                                          UNION
                                          SELECT * FROM dorder_past) a,
                                         callcenter b
                                   WHERE     a.cccode = b.cccode
                                         AND b.mcode = 2
                                         AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND a.test_gbn = 'N'
                                         AND NVL (a.cancel_code, '00') <> '30'
                                         AND a.cancel_code IS NOT NULL
                                GROUP BY cancel_code
                                ORDER BY COUNT DESC
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 일자별 취소사유
        [HttpGet("getDailyCancelReason")]
        public async Task<IActionResult> getDailyCancelReason()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT ORDER_DATE AS 주문일,
                                       CODE_NM AS 취소사유,
                                       CANCEL_CNT AS 수량
                                  FROM (SELECT ORDER_DATE,
                                               NVL(CANCEL_CODE, '00') AS CANCEL_CODE,
                                               COUNT( NVL(CANCEL_CODE, '00')) AS CANCEL_CNT
                                          FROM (SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                       CANCEL_CODE
                                                  FROM DORDER A,
                                                       CALLCENTER B
                                                 WHERE A.CCCODE = B.CCCODE
                                                   AND B.MCODE = 2
                                                   AND STATUS = '50'
                                                   AND NVL(CANCEL_CODE, '00') <> '30'
                                                   AND TEST_GBN = 'N'
                                                   AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                                 UNION ALL
                                SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                       CANCEL_CODE
                                                  FROM DORDER_PAST A,
                                                       CALLCENTER B
                                                 WHERE A.CCCODE = B.CCCODE
                                                   AND B.MCODE = 2
                                                   AND STATUS = '50'
                                                   AND NVL(CANCEL_CODE, '00') <> '30'
                                                   AND TEST_GBN = 'N'
                                                   AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24'))
                                         GROUP BY ORDER_DATE, NVL(CANCEL_CODE, '00')) A,
                                       (SELECT CODE,
                                               CODE_NM
                                          FROM ETC_CODE
                                         WHERE MCODE = 0
                                           AND PGM_GROUP = 'O'
                                           AND CODE_GRP = '10'
                                           AND USE_GBN = 'Y') B
                                 WHERE A.CANCEL_CODE = B.CODE(+)
                                 ORDER BY 주문일 DESC
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 친구초대 통계
        /// </summary>
        [HttpGet("getInviteFriendsTotal")]
        public async Task<IActionResult> getInviteFriendsTotal(string date_begin, string date_end, string gender)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("in_gender", gender);

                db.Open();

                string sql = @$"
                                select ins_date, 
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then be_share_cust_cnt end),0) be_share_cust_cnt, --공유한 회원수
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then shared_cust_cnt end),0) shared_cust_cnt,  --공유받은 회원수
                                       nvl(trunc(avg(case when age_grp <> 0 and gender_grp <> 'A' then first_order_interval end),2),0) first_order_interval, --첫주문 평균시간
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then event_page_contact_cnt end),0) event_page_contact_cnt, --페이지접속
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then code_copy_cnt end),0) code_copy_cnt, --복사버튼
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then share_cnt end),0) share_cnt, --공유버튼
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then code_input_page_cnt end),0) code_input_page_cnt, --받은코드 입력화면
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then miss_input_cnt end),0) miss_input_cnt, --코드 오입력 
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then condition_mismatch end),0) condition_mismatch, --회원조건미일치 
                                       nvl(sum(case when age_grp = 0 and gender_grp = 'A' then event_page_contact_cnt end),0) z_event_page_contact_cnt --페이지접속(비회원)
                                from INVITE_EVENT_TOTAL
                                where ins_date between :date_begin and :date_end
                                and gender_grp like case when :in_gender is null then '%' else :in_gender end
                                group by ins_date
                                order by ins_date desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 친구초대 통계(연령별)
        /// </summary>
        [HttpGet("getInviteFriendsAgeTotal")]
        public async Task<IActionResult> getInviteFriendsAgeTotal(string date_begin, string date_end, string gender)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("in_gender", gender);

                db.Open();

                string sql = @$"
                                select age_grp, 
                                       SUM(be_share_cust_cnt) be_share_cust_cnt, --공유한 회원수
                                       SUM(shared_cust_cnt) shared_cust_cnt, --공유받은 회원수
                                       nvl(trunc(AVG(first_order_interval),2),0) first_order_interval, --첫주문 평균시간
                                       sum(event_page_contact_cnt) event_page_contact_cnt, --페이지 접속
                                       SUM(code_copy_cnt) code_copy_cnt, --복사버튼
                                       SUM(share_cnt) share_cnt, --공유버튼
                                       SUM(code_input_page_cnt) code_input_page_cnt, --받은코드 입력화면
                                       SUM(miss_input_cnt) miss_input_cnt, --코드 오입력
                                       SUM(condition_mismatch) condition_mismatch --회원조건 미일치
                                from INVITE_EVENT_TOTAL
                                where ins_date between :date_begin and :date_end
                                and gender_grp like case when :in_gender is null then '%' else :in_gender end
                                AND GENDER_GRP <> 'A'
                                AND AGE_GRP <> 0
                                group by age_grp
                                ORDER BY AGE_GRP DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 친구초대 순위
        /// </summary>
        /// <remarks>
        /// 쿼리시 회원명, 전화번호 블러처리
        /// </remarks>
        [HttpGet("getInviteFriendsRank")]
        public async Task<IActionResult> getInviteFriendsRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @$"
                                select rownum, x.*, substr(y.cust_name,1,1) || '*' || substr(y.cust_name,3) cust_name, 
                                        substr(y.telno,1,3) || '-****-' || substr(y.telno,8) as telno
                                from(select invite_cust_cd, count(*) cnt
                                    from INVITE_FRIEND_EVENT_CHECK
                                    where ins_date between :date_begin and :date_end
                                    group by invite_cust_cd
                                    order by count(*) desc) x, app_customer y
                                where x.invite_cust_cd = y.cust_code(+)
                                and rownum <= 100
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        //라이브이벤트 통계엑셀
        /// <summary>
        /// 라이브이벤트 진행 가맹점(횟수 높은 가맹점 순)
        /// </summary>
        [HttpGet("getEventShopHist")]
        public async Task<IActionResult> getEventShopHist(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                select c.shop_name as 가맹점명, e.진행횟수, a.첫진행, NVL(b.총주문,0) AS 총주문, NVL(b.완료,0) AS 완료, NVL(b.취소,0) AS 취소
                                from (select a.shop_cd,
                                min(case when a.memo like '%이벤트 일자%' then substr(a.memo, -8)end) as 첫진행
                                from shop_event_mst_hist a
                                group by shop_cd) a,
                                (select c.shop_cd, 
                                count(1) as 총주문, count(case when c.status = '40' then 1 end) as 완료, count(case when c.status = '50' then 1 end) as 취소
                                from (select order_no, cccode from shop_event_order group by order_no, cccode) b, 
                                (select * from dorder 
                                where ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND TEST_GBN = 'N'
                                AND NVL(CANCEL_CODE,'00') <> '30' 
                                union all 
                                select * from dorder_past
                                where ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND TEST_GBN = 'N'
                                AND NVL(CANCEL_CODE,'00') <> '30') c, callcenter d
                                where b.order_no = c.order_no
                                and b.cccode = d.cccode
                                and d.mcode = 2
                                and c.order_time between to_date(:date_begin || ' 000000','YYYYMMDD HH24MISS') and to_date(:date_end || ' 235959','YYYYMMDD HH24MISS')
                                group by shop_cd) b,
                                shop_info c,
                                (select a.shop_cd, count(1) as 진행횟수 
                                from shop_event_mst_hist a, shop_info b, callcenter c
                                where a.shop_cd = b.shop_cd
                                and b.cccode = c.cccode
                                and a.memo like '%이벤트 일자%'
                                and substr(a.memo, -8) between :date_begin and :date_end
                                and c.mcode = 2
                                and b.app_order_yn = 'Y'
                                group by a.shop_cd) e
                                where a.shop_cd = b.shop_cd (+)
                                and a.shop_cd = c.shop_cd
                                and a.shop_cd = e.shop_cd
                                and 진행횟수 > 0
                                order by 진행횟수 desc, 총주문 desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }



        /// <summary>
        /// 라이브이벤트 진행누적 수
        /// </summary>
        [HttpGet("getEventShopRank")]
        public async Task<IActionResult> getEventShopRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();


                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                select 0 day_count,(select count(*)
                                                    from shop_info b, callcenter c
                                                    where b.cccode = c.cccode
                                                    and c.mcode = 2
                                                    and b.app_order_yn = 'Y'
                                                    and shop_cd not in (select distinct a.shop_cd
                                                                        from shop_event_mst_hist a, shop_info b, callcenter c
                                                                        where a.shop_cd = b.shop_cd
                                                                        and b.cccode = c.cccode
                                                                        and a.memo like '%이벤트 일자%'
                                                                        and substr(a.memo, -8) between :date_begin and :date_end
                                                                        and c.mcode = 2
                                                                        and b.app_order_yn = 'Y')) as shop_count
                                from dual                                        
                                union all
                                SELECT ROWNUM
                                       DAY_COUNT,
                                   DECODE (ROWNUM,
                                           1, day1,
                                           2, day2,
                                           3, day3,
                                           4, day4,
                                           5, day5,
                                           6, day6,
                                           7, day7,
                                           8, day8,
                                           9, day9,
                                           10, day10)
                                       shop_count
                                FROM(SELECT nvl(SUM (CASE WHEN (cnt = 1) THEN 1 ELSE 0 END),0)
                                           day1,
                                       nvl(SUM (CASE WHEN (cnt = 2) THEN 1 ELSE 0 END),0)
                                           day2,
                                       nvl(SUM (CASE WHEN (cnt = 3) THEN 1 ELSE 0 END),0)
                                           day3,
                                       nvl(SUM (CASE WHEN (cnt = 4) THEN 1 ELSE 0 END),0)
                                           day4,
                                       nvl(SUM (CASE WHEN (cnt = 5) THEN 1 ELSE 0 END),0)
                                           day5,
                                       nvl(SUM (CASE WHEN (cnt = 6) THEN 1 ELSE 0 END),0)
                                           day6,
                                       nvl(SUM(CASE WHEN (cnt = 7) THEN 1 ELSE 0 END),0)
                                           day7,
                                       nvl(SUM (CASE WHEN (cnt = 8) THEN 1 ELSE 0 END),0)
                                           day8,
                                      nvl (SUM (CASE WHEN (cnt = 9) THEN 1 ELSE 0 END),0)
                                           day9,
                                       nvl(SUM (CASE WHEN (cnt >= 10) THEN 1 ELSE 0 END),0)
                                           day10 from(select a.shop_cd, count(1) as cnt 
                                                        from shop_event_mst_hist a, shop_info b, callcenter c
                                                        where a.shop_cd = b.shop_cd
                                                        and b.cccode = c.cccode
                                                        and a.memo like '%이벤트 일자%'
                                                        and substr(a.memo, -8) between :date_begin and :date_end
                                                        and c.mcode = 2
                                                        and b.app_order_yn = 'Y'
                                                        group by a.shop_cd))
                                CONNECT BY LEVEL <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 라이브이벤트 사용 누적회원 수
        /// </summary>
        [HttpGet("getEventCustomerRank")]
        public async Task<IActionResult> getEventCustomerRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();


                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                select 0 day_count,(select count(1) 
                                from app_customer a, 
                                    (select app_cust_code ,order_no, order_time ,cccode
                                    from dorder 
                                    where TEST_GBN = 'N'
                                    AND NVL(CANCEL_CODE,'00') <> '30'
                                    union all 
                                    select app_cust_code ,order_no, order_time, cccode
                                    from dorder_past
                                    where TEST_GBN = 'N'
                                    AND NVL(CANCEL_CODE,'00') <> '30') b,
                                    callcenter c  
                                where  a.cust_code = b.app_cust_code
                                        and b.cccode = c.cccode
                                        AND a.MCODE = 2
                                        AND a.CUST_ID_GBN <> 'Z'
                                        AND a.TEST_GBN = 'R'
                                        -- AND a.INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        and c.mcode = 2
                                        and b.app_cust_code not in (select b.app_cust_code
                                                                    from shop_event_order a, 
                                                                    (select app_cust_code ,order_no, order_time
                                                                    from dorder 
                                                                    where TEST_GBN = 'N'
                                                                    AND NVL(CANCEL_CODE,'00') <> '30'
                                                                    union all 
                                                                    select app_cust_code ,order_no, order_time
                                                                    from dorder_past
                                                                    where TEST_GBN = 'N'
                                                                    AND NVL(CANCEL_CODE,'00') <> '30') b
                                                                    where a.order_no = b.order_no
                                                                    and b.order_time between to_date(:date_begin || '000000','YYYYMMDD HH24MISS') and to_date(:date_end || '235959','YYYYMMDD HH24MISS')
                                                                    group by b.app_cust_code)) as count 
                                from dual   
                                union all               
                                SELECT ROWNUM
                                       DAY_COUNT,
                                   DECODE (ROWNUM,
                                           1, day1,
                                           2, day2,
                                           3, day3,
                                           4, day4,
                                           5, day5,
                                           6, day6,
                                           7, day7,
                                           8, day8,
                                           9, day9,
                                           10, day10)
                                       count
                                FROM(SELECT nvl(SUM (CASE WHEN (cnt = 1) THEN 1 ELSE 0 END),0)
                                           day1,
                                       nvl(SUM (CASE WHEN (cnt = 2) THEN 1 ELSE 0 END),0)
                                           day2,
                                       nvl(SUM (CASE WHEN (cnt = 3) THEN 1 ELSE 0 END),0)
                                           day3,
                                       nvl(SUM (CASE WHEN (cnt = 4) THEN 1 ELSE 0 END),0)
                                           day4,
                                       nvl(SUM (CASE WHEN (cnt = 5) THEN 1 ELSE 0 END),0)
                                           day5,
                                       nvl(SUM (CASE WHEN (cnt = 6) THEN 1 ELSE 0 END),0)
                                           day6,
                                       nvl(SUM(CASE WHEN (cnt = 7) THEN 1 ELSE 0 END),0)
                                           day7,
                                       nvl(SUM (CASE WHEN (cnt = 8) THEN 1 ELSE 0 END),0)
                                           day8,
                                      nvl (SUM (CASE WHEN (cnt = 9) THEN 1 ELSE 0 END),0)
                                           day9,
                                       nvl(SUM (CASE WHEN (cnt >= 10) THEN 1 ELSE 0 END),0)
                                           day10 from  (select b.app_cust_code, count(1) as cnt
                                                        from shop_event_order a, 
                                                        (select app_cust_code ,order_no, order_time ,cccode
                                                        from dorder 
                                                        where TEST_GBN = 'N'
                                                        AND NVL(CANCEL_CODE,'00') <> '30'
                                                        union all 
                                                        select app_cust_code ,order_no, order_time, cccode
                                                        from dorder_past
                                                        where TEST_GBN = 'N'
                                                        AND NVL(CANCEL_CODE,'00') <> '30') b,
                                                        callcenter c
                                                        where a.order_no = b.order_no
                                                        and b.cccode = c.cccode
                                                        and c.mcode = 2
                                                        and b.order_time between to_date(:date_begin || '000000','YYYYMMDD HH24MISS') and to_date(:date_end || '235959','YYYYMMDD HH24MISS')
                                                        group by b.app_cust_code))
                                CONNECT BY LEVEL <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        //  시간별 검색 불가능
        /// <summary>
        /// 라이브이벤트 평균 시간대(가맹점)
        /// </summary>
        [HttpGet("getTimeEventCount")]
        public async Task<IActionResult> getTimeEventCount()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                db.Open();

                string sql = @"
                                SELECT item_cd, HH, COUNT(item_cd) COUNT
                                    FROM (SELECT case when a.memo like '%시작 시간%' then substr(a.memo,-4,2) else substr(a.memo,-9,2) end as HH, b.item_cd
                                            FROM shop_event_mst_hist a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND b.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 and b.app_order_yn = 'Y'
                                                 and (a.memo like '%이벤트 시간%' or a.memo like '%시작 시간%'))
                                GROUP BY CUBE (item_cd, HH)
                                ORDER BY item_cd
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 라이브이벤트 사용 시간대(회원)
        /// </summary>
        [HttpGet("getTimeEventOrderCount")]
        public async Task<IActionResult> getTimeEventOrderCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();


                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT item_cd, TO_CHAR (order_time, 'HH24') AS HH, COUNT (item_cd) COUNT
                                    FROM (SELECT a.order_time, b.item_cd
                                            FROM dorder a, shop_info b, callcenter c, (select order_no from shop_event_order group by order_no) d
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 and a.order_no = d.order_no
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 AND NVL (a.cancel_code, '00') <> '30'
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end
                                          UNION ALL
                                          SELECT a.order_time, b.item_cd
                                            FROM dorder_past a, shop_info b, callcenter c, (select order_no from shop_event_order group by order_no) d
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 and a.order_no = d.order_no
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 AND NVL (a.cancel_code, '00') <> '30'
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end)
                                GROUP BY CUBE (item_cd, TO_CHAR (order_time, 'HH24'))
                                ORDER BY item_cd
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 기간별 검색 불가능
        /// <summary>
        /// 라이브이벤트 평균 할인액
        /// </summary>
        [HttpGet("getEventDiscRank")]
        public async Task<IActionResult> getEventDiscRank()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                db.Open();

                string sql = @"
                                select a.rnum as 순위, TO_NUMBER(a.amt) as 할인액, TO_NUMBER(b.per) as 할인율
                                from
                                    (select rownum as rnum, amt 
                                    from(select substr(a.memo, 25) as amt
                                        from shop_event_hist a, shop_info b, callcenter c
                                        where a.memo like '이벤트 할인구분:->정액%'
                                        and a.shop_cd = b.shop_cd
                                        and b.cccode = c.cccode
                                        and b.app_order_yn = 'Y'
                                        and c.mcode = 2
                                        group by substr(a.memo, 25)
                                        order by count(substr(a.memo, 25)) desc)
                                    where rownum < 6) a,
                                    (select rownum as rnum, per
                                    from(select substr(a.memo, 25) as per
                                        from shop_event_hist a, shop_info b, callcenter c
                                        where a.memo like '이벤트 할인구분:->정율%'
                                        and a.shop_cd = b.shop_cd
                                        and b.cccode = c.cccode
                                        and b.app_order_yn = 'Y'
                                        and c.mcode = 2
                                        group by substr(a.memo, 25)
                                        order by count(substr(a.memo, 25)) desc)
                                    where rownum < 6) b
                                where a.rnum = b.rnum
                                UNION ALL
                                select  0 순위, 
                                        round(avg(CASE WHEN a.memo like '이벤트 할인구분:->정액%' THEN substr(a.memo, 25) END),2) as 할인액, 
                                        round(avg(CASE WHEN a.memo like '이벤트 할인구분:->정율%' THEN substr(a.memo, 25) END),2) as 할인율
                                from shop_event_hist a, shop_info b, callcenter c
                                where a.shop_cd = b.shop_cd
                                and b.cccode = c.cccode
                                and b.app_order_yn = 'Y'
                                and c.mcode = 2
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 일자별 라이브이벤트 건수 및 매출액 조회
        /// </summary>
        [HttpGet("getDailyEventCount")]
        public async Task<IActionResult> getDailyEventCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT X.ORDER_DATE,
                                       DECODE(X.STATUS, '40', '완료', '50', '취소') AS status,
                                       COUNT(X.STATUS) AS count,
                                       SUM(X.ORI_AMT) AS sum
                                  FROM (select * 
                                            from dorder AA
                                            , (select a.order_no, a.ori_amt, a.disc_amt
                                                    from shop_event_order a, callcenter b 
                                                    where a.cccode=b.cccode 
                                                    and b.mcode=2 
                                                    group by a.order_no, a.ori_amt, a.disc_amt) BB
                                        where AA.order_no = BB.order_no
                                        and AA.status in ('40','50')
                                        AND AA.ORDER_TIME BETWEEN to_date(:date_begin ||' 000000', 'YYYYMMDD HH24MISS')
                                                                                      AND to_date(:date_end ||' 235959', 'YYYYMMDD HH24MISS')
                                        UNION ALL
                                        select *
                                            from dorder_past AA
                                            , (select a.order_no, a. ori_amt, a.disc_amt
                                                from shop_event_order a, callcenter b 
                                                where a.cccode=b.cccode 
                                                and b.mcode=2 
                                                group by a.order_no, a.ori_amt, a.disc_amt) BB
                                        where AA.order_no=BB.order_no
                                        and AA.status in ('40','50')
                                        AND AA.ORDER_TIME BETWEEN to_date(:date_begin ||' 000000', 'YYYYMMDD HH24MISS')
                                                                                      AND to_date(:date_end ||' 235959', 'YYYYMMDD HH24MISS') ) X
                                 GROUP BY X.ORDER_DATE, X.STATUS
                                 ORDER BY X.ORDER_DATE DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        //라이브이벤트 통계엑셀 끝


        // 성별 가입수
        [HttpGet("getCustomerGender")]
        public async Task<IActionResult> getCustomerGender(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @$"
                                 SELECT INS_DATE,
                                        SUM(CASE WHEN GENDER = 'F' THEN 1 END) AS FEMALE,
                                        SUM(CASE WHEN GENDER = 'M' THEN 1 END) AS MALE,
                                        SUM(CASE WHEN GENDER IS NULL THEN 1 END) AS NODATA,
                                        SUM(1) AS TOTAL
                                FROM(SELECT TO_CHAR(INSERT_DATE,'yyyymmdd') AS INS_DATE, GENDER
                                    FROM APP_CUSTOMER
                                    WHERE MCODE = 2
                                    AND CUST_ID_GBN <> 'Z'
                                    AND TEST_GBN = 'R'
                                    UNION ALL
                                    SELECT TO_CHAR(INSERT_DATE,'yyyymmdd') AS INS_DATE, GENDER
                                    FROM APP_CUSTOMER_DELETED
                                    WHERE MCODE = 2
                                    AND CUST_ID_GBN <> 'Z'
                                    AND TEST_GBN = 'R')
                                WHERE INS_DATE BETWEEN TO_DATE(:date_begin||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:date_end||' 235959', 'YYYYMMDD HH24MISS')
                                GROUP BY INS_DATE
                                ORDER BY INS_DATE DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }



        /// <summary>
        /// 일자별 가맹점 적립금 내역(회계기준--배달완료)
        /// </summary>
        /// <remarks>
        /// date_begin : 해당 일자 <br />
        /// page : 1페이지당 5000건씩 조회
        /// </remarks>
        [HttpGet("getDailyShopBreakdown")]
        public async Task<IActionResult> getDailyShopBreakdown(string date_begin, string page) //page를 이용해서 5000건씩 조회
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("in_fr_dt", date_begin);
                param.Add("page", page);

                db.Open();

                string sql = @"
                                SELECT tt.*
                              FROM (SELECT ROWNUM AS RNUM,
                                           te.*
                                    FROM ( select t4.shop_cd, t4.shop_name,t3.pre_amt, t3.amt, t1.카드결제금액, t1.쿠폰, t1.마일리지사용금액, t1.행복페이할인액, t1.배달팁할인액, t1.중계수수료, t1.pg수수료, t1.카드결제금액c, t1.쿠폰c, t1.마일리지사용금액c, t1.행복페이할인액c, t1.배달팁할인액c, t1.중계수수료c, t1.pg수수료c , 
                                                  t2.welcome_amt, t2.withdraw_amt, t2.withdraw_fee, t2.사입
                             from (SELECT shop_cd,
                                     nvl(COUNT(CASE WHEN STATUS = '40' THEN 1 END),0) AS COMP, 
                                     nvl(COUNT(CASE WHEN STATUS = '50' THEN 1 END),0) AS CANC,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN TOT_AMT ELSE 0 END),0) AS SUM_TOT_AMT,
                                     nvl(SUM(CASE WHEN STATUS = '40' and app_pay_gbn = '3' THEN AMOUNT ELSE 0 END ),0) AS 카드결제금액,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN COUPON_AMT ELSE 0 END),0) AS 쿠폰,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN MILEAGE_USE_AMT ELSE 0 END),0) AS 마일리지사용금액,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN happy_disc_amt ELSE 0 END),0) AS 행복페이할인액,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN deli_disc_amt ELSE 0 END),0) AS 배달팁할인액,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN DISC_AMT ELSE 0 END ),0) AS SUM_DISC_AMT,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN PGM_AMT ELSE 0 END ),0) AS 중계수수료,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN PG_PGM_AMT ELSE 0 END ),0) AS pg수수료,
                                     nvl(SUM(CASE WHEN STATUS = '50' and app_pay_gbn = '3' THEN AMOUNT ELSE 0 END ),0) AS 카드결제금액c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN COUPON_AMT ELSE 0 END),0) AS 쿠폰c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN MILEAGE_USE_AMT ELSE 0 END),0) AS 마일리지사용금액c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN happy_disc_amt ELSE 0 END),0) AS 행복페이할인액c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN deli_disc_amt ELSE 0 END),0) AS 배달팁할인액c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN DISC_AMT ELSE 0 END ),0) AS SUM_DISC_AMTc,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN PGM_AMTC ELSE 0 END ),0) AS 중계수수료c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN PG_PGM_AMTC ELSE 0 END ),0) AS pg수수료c
                                     FROM(  SELECT     case when a.status = '50' and zz.new_status = '40' and to_char(z.hist_time,'YYYYMMDD') >= :in_fr_dt then '40'
                                                            when a.status = '40' and zz.new_status = '50' then '50' else A.STATUS end as status,
                                                     A.shop_cd,
                                                     A.order_date,
                                                     A.pay_gbn,
                                                     A.APP_PAY_GBN,
                                                     A.TOT_AMT,      
                                                     NVL(A.COUPON_AMT,0) + NVL(A.COUPON_AMT2,0)     AS COUPON_AMT,
                                                     A.MILEAGE_USE_AMT,
                                                     NVL(X.happy_disc_amt,0)                          AS happy_disc_amt,
                                                     NVL(X.deli_disc_amt,0)                          AS deli_disc_amt,
                                                     A.DISC_AMT,
                                                     A.AMOUNT,
                                                     NVL(Y.PGM_AMT,0)                               AS PGM_AMT,
                                                     NVL(Y.PGM_AMTC,0)                               AS PGM_AMTC,
                                                     NVL(Y.PG_PGM_AMT,0)                            AS PG_PGM_AMT,
                                                     NVL(Y.PG_PGM_AMTC,0)                            AS PG_PGM_AMTC,
                                                     z.order_no 
                                            FROM    DORDER A, SHOP_INFO B, CALLCENTER D,
                                            (   SELECT     ORDER_DATE, 
                                                            ORDER_NO,
                                                            SUM(case when disc_code = '20' then DISC_USE_AMT end) AS happy_disc_amt,
                                                            SUM(case when disc_code = '10' then DISC_USE_AMT end) AS deli_disc_amt
                                                FROM       DORDER_DISC_DETAIL
                                               -- WHERE      ORDER_DATE    BETWEEN to_char(to_date(:in_fr_dt,'YYYYMMDD') - 1,'YYYYMMDD') AND to_char(to_date(:in_fr_dt,'YYYYMMDD') + 1,'YYYYMMDD')
                                                GROUP BY   ORDER_DATE, 
                                                            ORDER_NO ) X,
                                            ( SELECT  ORDER_DATE, 
                                                    ORDER_NO ,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'P' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT END ELSE 0 END ) AS PGM_AMT,     -- 중개수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'P' THEN CASE WHEN IO_GBN = 'O' THEN CHARGE_AMT END ELSE 0 END ) AS PGM_AMTC,     -- 중개수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'K' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT END ELSE 0 END ) AS PG_PGM_AMT,   -- PG수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'K' THEN CASE WHEN IO_GBN = 'O' THEN CHARGE_AMT END ELSE 0 END ) AS PG_PGM_AMTC   -- PG수수료
                                            FROM    INSUNG_CALC 
                                            WHERE      CHARGE_DATE    BETWEEN TO_DATE(:in_fr_dt ||' 000000', 'YYYYMMDD HH24MISS')  AND  TO_DATE(:in_fr_dt ||' 235959', 'YYYYMMDD HH24MISS')
                                            AND     CHARGE_GBN  IN ( 'P', 'K' )  
                                            GROUP BY   ORDER_DATE, 
                                                        ORDER_NO ) Y,
                                            (select order_no, 
                                                    order_date,
                                                    hist_time,
                                                    sum(order_no) 
                                            from dorder_hist 
                                            where old_status = '40' and new_status = '50'
                                            and hist_time BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS') +30
                                            group by order_no, order_date, hist_time) z,
                                            (select new_status,
                                                    old_status,
                                                    order_no, 
                                                    order_date,
                                                    hist_time,
                                                    sum(order_no) 
                                            from dorder_hist 
                                            where (old_status = '40' and new_status = '50') or (old_status in ('35','30','50') and new_status = '40')
                                            and hist_time BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS') +30
                                            group by new_status, old_status, order_no, order_date, hist_time) zz
                                            WHERE   A.CCCODE        = B.CCCODE
                                            AND     A.SHOP_CD       = B.SHOP_CD
                                            AND     A.CCCODE        = D.CCCODE
                                            AND     D.MCODE         = 2
                                            AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND     case when a.status = '40' and zz.new_status = '40' and zz.old_status <> '50' then a.comp_dt -- 일반 완료건
                                                         when a.status = '40' and zz.new_status = '40' and zz.old_status = '50' then zz.hist_time  -- 관리앱 취소 -> 완료
                                                         when a.status = '40' and zz.new_status = '50' then a.cancel_dt -- 관리앱 완료 -> 취소(이후 다시 완료처리한 건)
                                                                 when a.status = '50' and zz.new_status = '40' and to_char(z.hist_time,'YYYYMMDD') >= :in_fr_dt then zz.hist_time -- 현재 취소이나 당시 완료건
                                                                 when a.status = '50' and zz.new_status = '50' and to_char(z.hist_time,'YYYYMMDD') = :in_fr_dt then  a.cancel_dt end -- 관리앱 완료 -> 취소
                                                                 BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS')
                                            AND     A.PRCS_GBN      = 'A'
                                            AND     A.TEST_GBN = 'N'
                                            --AND     NVL(CANCEL_CODE, '00') <> '30'  
                                            AND     ZZ.ORDER_DATE   = A.ORDER_DATE  (+)                       
                                            AND     ZZ.ORDER_NO     = A.ORDER_NO    (+)
                                            AND     ZZ.ORDER_DATE   = X.ORDER_DATE  (+)                       
                                            AND     ZZ.ORDER_NO     = X.ORDER_NO    (+) 
                                            AND     ZZ.ORDER_DATE   = Y.ORDER_DATE  (+) 
                                            AND     ZZ.ORDER_NO     = Y.ORDER_NO    (+)
                                            AND     ZZ.ORDER_NO     = Z.ORDER_NO    (+)
                                            AND     ZZ.ORDER_DATE   = Z.ORDER_DATE  (+)
                                    UNION ALL
                                        SELECT     case when a.status = '50' and zz.new_status = '40' and to_char(z.hist_time,'YYYYMMDD') >= :in_fr_dt then '40'
                                                            when a.status = '40' and zz.new_status = '50' then '50' else A.STATUS end as status,
                                                     A.shop_cd,
                                                     A.order_date,
                                                     A.pay_gbn,
                                                     A.APP_PAY_GBN,
                                                     A.TOT_AMT,      
                                                     NVL(A.COUPON_AMT,0) + NVL(A.COUPON_AMT2,0)     AS COUPON_AMT,
                                                     A.MILEAGE_USE_AMT,
                                                     NVL(X.happy_disc_amt,0)                          AS happy_disc_amt,
                                                     NVL(X.deli_disc_amt,0)                          AS deli_disc_amt,
                                                     A.DISC_AMT,
                                                     A.AMOUNT,
                                                     NVL(Y.PGM_AMT,0)                               AS PGM_AMT,
                                                     NVL(Y.PGM_AMTC,0)                               AS PGM_AMTC,
                                                     NVL(Y.PG_PGM_AMT,0)                            AS PG_PGM_AMT,
                                                     NVL(Y.PG_PGM_AMTC,0)                            AS PG_PGM_AMTC,
                                                     z.order_no 
                                            FROM    DORDER_PAST A, SHOP_INFO B, CALLCENTER D,
                                            (   SELECT     ORDER_DATE, 
                                                            ORDER_NO,
                                                            SUM(case when disc_code = '20' then DISC_USE_AMT end) AS happy_disc_amt,
                                                            SUM(case when disc_code = '10' then DISC_USE_AMT end) AS deli_disc_amt
                                                FROM       DORDER_DISC_DETAIL
                                               -- WHERE      ORDER_DATE    BETWEEN to_char(to_date(:in_fr_dt,'YYYYMMDD') - 1,'YYYYMMDD') AND to_char(to_date(:in_fr_dt,'YYYYMMDD') + 1,'YYYYMMDD')
                                                GROUP BY   ORDER_DATE, 
                                                            ORDER_NO ) X,
                                            ( SELECT  ORDER_DATE, 
                                                    ORDER_NO ,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'P' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT END ELSE 0 END ) AS PGM_AMT,     -- 중개수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'P' THEN CASE WHEN IO_GBN = 'O' THEN CHARGE_AMT END ELSE 0 END ) AS PGM_AMTC,     -- 중개수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'K' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT END ELSE 0 END ) AS PG_PGM_AMT,   -- PG수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'K' THEN CASE WHEN IO_GBN = 'O' THEN CHARGE_AMT END ELSE 0 END ) AS PG_PGM_AMTC   -- PG수수료
                                            FROM    INSUNG_CALC 
                                            WHERE      CHARGE_DATE    BETWEEN TO_DATE(:in_fr_dt ||' 000000', 'YYYYMMDD HH24MISS')  AND  TO_DATE(:in_fr_dt ||' 235959', 'YYYYMMDD HH24MISS')
                                            AND     CHARGE_GBN  IN ( 'P', 'K' )  
                                            GROUP BY   ORDER_DATE, 
                                                        ORDER_NO ) Y,
                                            (select order_no, 
                                                    order_date,
                                                    hist_time,
                                                    sum(order_no) 
                                            from dorder_hist 
                                            where old_status = '40' and new_status = '50'
                                            and hist_time BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS') +30
                                            group by order_no, order_date, hist_time) z,
                                            (select new_status,
                                                    old_status,
                                                    order_no, 
                                                    order_date,
                                                    hist_time,
                                                    sum(order_no) 
                                            from dorder_hist 
                                            where (old_status = '40' and new_status = '50') or (old_status in ('35','30','50') and new_status = '40')
                                            and hist_time BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS') +30
                                            group by new_status, old_status, order_no, order_date, hist_time) zz
                                            WHERE   A.CCCODE        = B.CCCODE
                                            AND     A.SHOP_CD       = B.SHOP_CD
                                            AND     A.CCCODE        = D.CCCODE
                                            AND     D.MCODE         = 2
                                            AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND     case when a.status = '40' and zz.new_status = '40' and zz.old_status <> '50' then a.comp_dt -- 일반 완료건
                                                         when a.status = '40' and zz.new_status = '40' and zz.old_status = '50' then zz.hist_time  -- 관리앱 취소 -> 완료
                                                         when a.status = '40' and zz.new_status = '50' then a.cancel_dt -- 관리앱 완료 -> 취소(이후 다시 완료처리한 건)
                                                                 when a.status = '50' and zz.new_status = '40' and to_char(z.hist_time,'YYYYMMDD') >= :in_fr_dt then zz.hist_time -- 현재 취소이나 당시 완료건
                                                                 when a.status = '50' and zz.new_status = '50' and to_char(z.hist_time,'YYYYMMDD') = :in_fr_dt then  a.cancel_dt end -- 관리앱 완료 -> 취소
                                                                 BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS')
                                            AND     A.PRCS_GBN      = 'A'
                                            AND     A.TEST_GBN = 'N'
                                            --AND     NVL(CANCEL_CODE, '00') <> '30'  
                                            AND     ZZ.ORDER_DATE   = A.ORDER_DATE  (+)                       
                                            AND     ZZ.ORDER_NO     = A.ORDER_NO    (+)
                                            AND     ZZ.ORDER_DATE   = X.ORDER_DATE  (+)                       
                                            AND     ZZ.ORDER_NO     = X.ORDER_NO    (+) 
                                            AND     ZZ.ORDER_DATE   = Y.ORDER_DATE  (+) 
                                            AND     ZZ.ORDER_NO     = Y.ORDER_NO    (+)
                                            AND     ZZ.ORDER_NO     = Z.ORDER_NO    (+)
                                            AND     ZZ.ORDER_DATE   = Z.ORDER_DATE  (+)) 
                                            group by shop_cd) t1,
                                            (select shop_cd,
                                                    SUM(CASE WHEN memo = '가맹점 입점신청 지급' THEN charge_amt ELSE 0 END ) AS welcome_amt,     -- 입점지원금
                                                    SUM(CASE WHEN memo like '계좌이체요청 %' THEN charge_amt ELSE 0 END ) AS withdraw_amt, -- 출금금액
                                                    SUM(CASE WHEN memo like '계좌이체요청 출금%' THEN 200 
                                                             WHEN memo like '계좌이체요청 실패%' THEN 200 * -1  ELSE 0 END ) AS withdraw_fee, -- 출금수수료 한건당 200원
                                                    SUM(CASE WHEN charge_gbn = '1' THEN charge_amt ELSE 0 END ) AS 사입 -- 사입
                                                     from shop_infocharge 
                                                     where CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDD HH24MISS')
                                                     group by shop_cd) t2,
                                             (select shop_cd, 
                                                    sum(case when charge_date < to_date(:in_fr_dt || '000000','YYYYMMDD HH24MISS') then (case when io_gbn = 'I' then charge_amt else -1 * charge_amt end) end) as pre_Amt,
                                                    sum(case when io_gbn = 'I' then charge_amt else -1 * charge_amt end) as amt 
                                                    from shop_infocharge
                                                    where charge_date <= to_date(:in_fr_dt || ' 235959','YYYYMMDD HH24MISS')
                                                    group by shop_cd) t3,
                                           (select a.shop_cd, a.shop_name from shop_info a, callcenter b where a.cccode = b.cccode and b.mcode = 2) t4
                                          where t4.shop_cd = t1.shop_cd (+)
                                          and t4.shop_cd = t2.shop_cd (+)
                                          and t4.shop_cd = t3.shop_cd (+)
                                          order by t3.shop_cd ) te
                            WHERE ROWNUM <= (( :page - 1) * 5000) + 5000) tt
                            WHERE (( :page - 1) * 5000) < RNUM
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }



        //대구시 요청자료 시작

        /// <summary>
        /// 대구시 요청자료 - 시간대별 연령 통계
        /// </summary>
        [HttpGet("getTimeOrderAge")]
        public async Task<IActionResult> getTimeOrderAge(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  SELECT TO_CHAR (order_time, 'HH24') AS HH, COUNT (*) COUNT, 
                                          count(case when birthday <= 1 then 1 end) as a,
                                          count(case when birthday = 2 then 1 end) as b,
                                          count(case when birthday = 3 then 1 end) as c,
                                          count(case when birthday = 4 then 1 end) as d,
                                          count(case when birthday = 5 then 1 end) as e,
                                          count(case when birthday = 6 then 1 end) as f,
                                          count(case when birthday = 7 then 1 end) as g,
                                          count(case when birthday = 8 then 1 end) as h,
                                          count(case when birthday >= 9 then 1 end) as i,
                                          count(case when birthday is null then 1 end) as j
                                    FROM (SELECT a.order_time, ccode
                                            FROM dorder a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 AND NVL (a.cancel_code, '00') <> '30'
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end
                                          UNION ALL
                                          SELECT a.order_time, ccode
                                            FROM dorder_past a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 AND NVL (a.cancel_code, '00') <> '30'
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end) a, 
                                          (select cust_code, trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                                                        birthday from app_customer 
                                          union all 
                                          select cust_code, trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                                                        birthday from app_customer_deleted) b
                                where a.ccode = b.cust_code
                                GROUP BY CUBE (TO_CHAR (order_time, 'HH24'))
                                ORDER BY (TO_CHAR (order_time, 'HH24'))
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 대구시 요청자료 - 시간대별 성별 통계
        /// </summary>
        [HttpGet("getTimeOrderGender")]
        public async Task<IActionResult> getTimeOrderGender(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  SELECT TO_CHAR (order_time, 'HH24') AS HH, COUNT (*) COUNT,
                                          count(case when gender = 'M' then 1 end) as male,
                                          count(case when gender = 'F' then 1 end) as female, 
                                          count(case when gender is null then 1 end) as a
                                    FROM (SELECT a.order_time, ccode
                                            FROM dorder a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 AND NVL (a.cancel_code, '00') <> '30'
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end
                                          UNION ALL
                                          SELECT a.order_time, ccode
                                            FROM dorder_past a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 AND NVL (a.cancel_code, '00') <> '30'
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end) a, 
                                          (select cust_code, gender from app_customer 
                                          union all 
                                          select cust_code, gender from app_customer_deleted) b
                                where a.ccode = b.cust_code
                                GROUP BY CUBE (TO_CHAR (order_time, 'HH24'))
                                ORDER BY (TO_CHAR (order_time, 'HH24'))
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 대구시 요청자료 - 시간대별 군구별 통계
        /// </summary>
        [HttpGet("getTimeOrderCategory")]
        public async Task<IActionResult> getTimeOrderCategory(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  SELECT TO_CHAR (order_time, 'HH24') AS HH, COUNT (*) COUNT, 
                                          count(case when dest_gungu = '달서구' then 1 end) as 달서구,
                                          count(case when dest_gungu = '달성군' then 1 end) as 달성군,
                                          count(case when dest_gungu = '수성구' then 1 end) as 수성구,
                                          count(case when dest_gungu = '남구' then 1 end) as 남구,
                                          count(case when dest_gungu = '서구' then 1 end) as 서구,
                                          count(case when dest_gungu = '중구' then 1 end) as 중구,
                                          count(case when dest_gungu = '동구' then 1 end) as 동구,
                                          count(case when dest_gungu = '북구' then 1 end) as 북구,
                                          count(case when dest_gungu is null then 1 end) as 포장
                                    FROM (SELECT a.order_time, a.dest_gungu
                                            FROM dorder a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 AND NVL (a.cancel_code, '00') <> '30'
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end
                                          UNION ALL
                                          SELECT a.order_time, a.dest_gungu
                                            FROM dorder_past a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 AND NVL (a.cancel_code, '00') <> '30'
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end)
                                GROUP BY CUBE (TO_CHAR (order_time, 'HH24'))
                                ORDER BY (TO_CHAR (order_time, 'HH24'))
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 대구시 요청자료 - 일자별 성별 주문수 
        /// </summary>
        [HttpGet("getDailyGenderToOrder")]
        public async Task<IActionResult> getDailyGenderToOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT order_date,  
                                       sum(case when gender is null then 1 end) nodata,
                                       sum(case when gender = 'M' then 1 end) male,
                                       sum(case when gender = 'F' then 1 end) female
                                FROM (SELECT gender, STATUS, order_date
                                    FROM (SELECT cust_code,
                                                    gender
                                            FROM app_customer
                                            UNION ALL
                                            SELECT cust_code,
                                                    gender
                                            FROM app_customer_deleted) a, 
                                        (select ccode, STATUS, to_char(order_time,'YYYYMMDD') order_date from dorder a, callcenter b
                                        where a.cccode = b.cccode
                                            AND b.mcode = 2
                                            AND a.order_time between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            AND a.TEST_GBN = 'N'
                                            AND NVL(a.CANCEL_CODE,'00') <> '30'
                                        union all
                                        select ccode, STATUS, to_char(order_time,'YYYYMMDD') order_date from dorder_past a, callcenter b
                                        where a.cccode = b.cccode
                                            AND b.mcode = 2
                                            AND a.order_time between to_date(case when :date_begin = '20210809' then '20210809170000' else :date_begin || '000000' end
                                                                            , 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            AND a.TEST_GBN = 'N'
                                            AND NVL(a.CANCEL_CODE,'00') <> '30') b
                                    where a.cust_code = b.ccode
                                    )
                                GROUP BY order_date
                                order by order_date desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 대구시 요청자료 - 일자별 군구별 주문수 
        /// </summary>
        [HttpGet("getDailyGunguToOrder")]
        public async Task<IActionResult> getDailyGunguToOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT order_date,
                                       count(case when dest_gungu = '달서구' then 1 end) as 달서구,
                                          count(case when dest_gungu = '달성군' then 1 end) as 달성군,
                                          count(case when dest_gungu = '수성구' then 1 end) as 수성구,
                                          count(case when dest_gungu = '남구' then 1 end) as 남구,
                                          count(case when dest_gungu = '서구' then 1 end) as 서구,
                                          count(case when dest_gungu = '중구' then 1 end) as 중구,
                                          count(case when dest_gungu = '동구' then 1 end) as 동구,
                                          count(case when dest_gungu = '북구' then 1 end) as 북구,
                                          count(case when dest_gungu is null then 1 end) as 포장
                                FROM (select ccode, dest_gungu, to_char(order_time,'YYYYMMDD') order_date from dorder a, callcenter b
                                        where a.cccode = b.cccode
                                            AND b.mcode = 2
                                            AND a.order_time between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            AND a.TEST_GBN = 'N'
                                            AND NVL(a.CANCEL_CODE,'00') <> '30'
                                        union all
                                        select ccode, dest_gungu, to_char(order_time,'YYYYMMDD') order_date from dorder_past a, callcenter b
                                        where a.cccode = b.cccode
                                            AND b.mcode = 2
                                            AND a.order_time between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            AND a.order_time >= to_date('2021080917','YYYYMMDDHH24')
                                            AND a.TEST_GBN = 'N'
                                            AND NVL(a.CANCEL_CODE,'00') <> '30') 
                                GROUP BY order_date
                                order by order_date desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }




        //
        //대구시 요청자료 끝



        // 회원 비회원 여부 확인 엑셀
        [HttpGet("getCustomerYn")]
        public async Task<IActionResult> getCustomerYn(string telno)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object Rdata = string.Empty;


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("telno", telno);

                //string sql = @$"
                //                select decode(count(1), 0,'비회원',1,'회원') as customer
                //                from app_customer
                //                where use_gbn = '1' and telno = :telno
                //";

                string sql = @$"
                                select c.telno, c.cust_name, a.customer, nvl(c.mileage,0) as mileage_sum, b.memo, sum(nvl(b.mileage_amt,0)) as mileage
                                    from (select telno, decode(nvl(count(1),0), 0,'비회원',1,'회원') as customer, sum(cust_code) as cust_code
                                from app_customer where use_gbn = '1' AND MCODE = 2 AND CUST_ID_GBN <> 'Z' AND TEST_GBN = 'R' and telno = :telno) a, app_cust_mileage_log b , app_customer c
                                where a.cust_code = b.app_cust_code(+)
                                and b.app_cust_code = c.cust_code(+)
                                group by c.telno, c.cust_name, a.customer, c.mileage, b.memo
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 회원 비회원 여부 확인 엑셀(기본)
        [HttpGet("getCustomerYnV2")]
        public async Task<IActionResult> getCustomerYnV2(string telno)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object Rdata = string.Empty;


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("telno", telno);

                string sql = @$"
                                select decode(count(1), 0,'비회원',1,'회원') as customer
                                from app_customer
                                where use_gbn = '1' and telno = :telno
                                and mcode = 2
                                and test_gbn = 'R'
                ";
                ;

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 값 받아서 마일리지 충전하는 rest
        [HttpPut("chargeMileage")]
        public async Task<IActionResult> chargeMileage(string[] telno, string type, string req_mileage, string mileage_memo, string payer_id, string payer_nm)
        {


            if (string.IsNullOrEmpty(type))
            {
                return Ok(new { code = "99", msg = "타입을 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(req_mileage))
            {
                return Ok(new { code = "99", msg = "신청마일리지를 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(mileage_memo))
            {
                return Ok(new { code = "99", msg = "메모를 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(payer_nm) || string.IsNullOrEmpty(payer_id))
            {
                return Ok(new { code = "99", msg = "지급자를 제대로 설정해주세요." });
            }


            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object Rdata = string.Empty;

            string sql = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            db.Open();

            using var transaction = db.BeginTransaction();

            try
            {
                
                DynamicParameters param = new DynamicParameters();
                param.Add("type", type);
                param.Add("req_mileage", req_mileage);
                param.Add("mileage_memo", mileage_memo);
                param.Add("payer_id", payer_id);
                param.Add("payer_nm", payer_nm);

                string[] cust_cd = new string[telno.Length];
                // 각 전화번호의 회원코드 구하기
                int n = 0;
                foreach (string e in telno)
                {
                    sql = $@" SELECT TO_CHAR(CUST_CODE) FROM APP_CUSTOMER WHERE USE_GBN = '1' AND MCODE = 2 AND CUST_ID_GBN <> 'Z' AND TEST_GBN = 'R' AND TELNO = '{e}'";
                    //sql = $@" SELECT TO_CHAR(CUST_CODE) FROM APP_CUSTOMER WHERE TELNO = '{e}'";
                    cust_cd[n] = (string)await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);
                    if (string.IsNullOrEmpty(cust_cd[n]))
                    {
                        return Ok(new { code = "99", msg = e + " - 이 전화번호는 회원이 아닙니다." });
                    }
                    n++;
                }


                //대구_마일리지지급 테이블에 내역 추가
                sql = $@"INSERT INTO 대구_마일리지지급(순번, 타입, 전화번호, 신청마일리지, 마일리지메모, 지급자ID, 지급자명) SELECT SEQ_MILEAGE_IMSI.NEXTVAL, A.* FROM((";

                foreach (string e in telno)
                {
                    sql = sql + $@" SELECT :type as 타입, '{e}' as 전화번호, :req_mileage as 신청마일리지, trim(:mileage_memo) as 마일리지메모, :payer_id as 지급자ID, :payer_nm as 지급자명 FROM DUAL UNION ALL";
                }

                sql = sql.Substring(0, sql.Length - 9);
                sql = sql + $@") A)";


                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                //APP_CUST_MILEAGE_LOG 테이블에 마일리지 지급내역 추가
                sql = $@"INSERT INTO APP_CUST_MILEAGE_LOG(  LOGNO, 
                                                            ORDER_DATE, 
                                                            LOG_DATE, 
                                                            UCODE, 
                                                            USER_ID, 
                                                            USER_NAME, 
                                                            MILEAGE_AMT,  
                                                            LOG_GBN, 
                                                            MEMO,
                                                            APP_CUST_CODE, 
                                                            ORI_REMAIN_AMT ) 
                        SELECT  SEQ_APP_CUST_MILEAGE_LOG.NEXTVAL as LOGNO, 
                                SF_GETTODAY as ORDER_DATE, 
                                SYSDATE as LOG_DATE,
                                0 as UCODE, 
                                :payer_nm as USER_ID, 
                                :payer_nm as USER_NAME, 
                                :req_mileage as MILEAGE_AMT, 
                                CASE WHEN :req_mileage < 0 THEN '3' ELSE '1' END  as LOG_GBN, -- 1:적립 , 3:차감 
                                trim(:mileage_memo) as MEMO,
                                A.* FROM( (";

                foreach (string e in telno)
                {
                    sql = sql + $@" SELECT CUST_CODE as APP_CUST_CODE, MILEAGE as ORI_REMAIN_AMT FROM APP_CUSTOMER WHERE TELNO = '{e}' UNION ALL";
                }

                sql = sql.Substring(0, sql.Length - 9);
                sql = sql + $@") A)";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                Object num = new Object();
                var t = 0;

                //DAILY_APP_CUSTOMER 테이블에 현재 마일리지 내역 기록하고 마일리지 지급완료
                foreach (string e in cust_cd)
                {
                    sql = @$"SELECT to_char(COUNT(1)) FROM DAILY_APP_CUSTOMER WHERE APP_CUST_CODE = {e}";

                    num = await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);

                    if (Int32.Parse(num.ToString()) > 0)
                    {
                        sql = $@"UPDATE DAILY_APP_CUSTOMER SET MILEAGE_AMT = NVL(MILEAGE_AMT,0) + :req_mileage,
                                                                               MILEAGE_DATE = SF_GETTODAY WHERE APP_CUST_CODE = {e}";
                    }
                    else
                    {
                        sql = $@"INSERT INTO DAILY_APP_CUSTOMER ( APP_CUST_CODE, MILEAGE_DATE, MILEAGE_AMT )
                                                 VALUES ( {e} , SF_GETTODAY, :req_mileage )";
                    }

                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                    if(int.Parse(req_mileage) > 0)
                    {
                        sql = $@"UPDATE 대구_마일리지지급
                                SET    고객코드    = {e}, 
                                       작업유무    = '마일리지 지급완료',
                                       작업일자    = SYSDATE
                                WHERE  전화번호    = '{telno[t]}'  
                                AND  타입      = :type";
                    } else
                    {
                        sql = $@"UPDATE 대구_마일리지지급
                                SET    고객코드    = {e}, 
                                       작업유무    = '마일리지 차감완료',
                                       작업일자    = SYSDATE
                                WHERE  전화번호    = '{telno[t]}'  
                                AND  타입      = :type";
                    }
                    
                    t++;

                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                }

                transaction.Commit();
                //transaction.Rollback();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                Rcode = "99";
                Rmsg = ex.Message;

            }

            db.Close();
            return Ok(new { code = Rcode, msg = Rmsg});
        }




        // 가맹점(시간지연취소건) 엑셀 --미사용예정
        [HttpGet("getDelayCancelShop")]
        public async Task<IActionResult> getDelayCancelShop(string date_begin, string date_end, string gungu)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("gungu", gungu);

                string gunguSql = string.Empty; ;

                if (gungu is not null)
                {
                    gunguSql = @"AND A.GUNGU_NAME = :gungu";
                }

                string sql = @$"
                                 SELECT rownum, a.*,
                                        SF_CHECK_POS_INSTALL (A.SHOP_CD)
                                           AS POS_INSTALL,
                                        SF_CHECK_POS_LOGIN (A.SHOP_CD)
                                           AS POS_LOGIN
                                    from(SELECT * from(SELECT A.GUNGU_NAME,
                                             A.SHOP_CD,
                                             A.SHOP_NAME,
                                             TO_CHAR(A.OPEN_DT,'YYYYMMDD') AS OPEN_DT,
                                             A.TELNO,
                                             A.ABSENT_YN,
                                             C.cancel_reason,
                                             NVL(sum (case when c.status = '50' AND  NVL(CANCEL_CODE,'00') = '11' then 1 end),0) as CANCELCNT
                                        FROM SHOP_INFO        A,
                                             CALLCENTER       B,
                                             (SELECT * FROM DORDER 
                                             WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND TEST_GBN = 'N'
                                            AND NVL(CANCEL_CODE,'00') = '11'
                                            AND order_date BETWEEN :date_begin
                                                                                     AND :date_end
                                             UNION ALL 
                                             SELECT * FROM DORDER_PAST
                                             WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND TEST_GBN = 'N'
                                            AND NVL(CANCEL_CODE,'00') = '11'
                                            AND order_date BETWEEN :date_begin
                                                                                     AND :date_end) C                                          
                                       WHERE A.CCCODE = B.CCCODE
                                       AND B.MCODE = 2
                                       AND A.SHOP_CD = C.SHOP_CD
                                       and C.SHOP_CD = A.SHOP_CD
                                       {gunguSql} 
                                       GROUP BY A.GUNGU_NAME,
                                             A.SHOP_CD,
                                             A.SHOP_NAME,
                                             TO_CHAR(A.OPEN_DT,'YYYYMMDD'),
                                             A.TELNO,
                                             A.ABSENT_YN,
                                             C.cancel_reason)
                                       where CANCELCNT > 0
                                       ORDER BY CANCELCNT DESC) a
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }

        // 가맹점(가맹점취소건) 엑셀--미사용예정
        [HttpGet("getShopCancelShop")]
        public async Task<IActionResult> getShopCancelShop(string date_begin, string date_end, string gungu)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("gungu", gungu);

                string gunguSql = string.Empty;

                if (gungu is not null)
                {
                    gunguSql = @"AND A.GUNGU_NAME = :gungu";
                }

                string sql = @$"
                                 SELECT rownum, a.*, 
                                        SF_CHECK_POS_INSTALL (A.SHOP_CD)
                                           AS POS_INSTALL,
                                        SF_CHECK_POS_LOGIN (A.SHOP_CD)
                                           AS POS_LOGIN
                                    from(SELECT * from(SELECT A.GUNGU_NAME,
                                             A.SHOP_CD,
                                             A.SHOP_NAME,
                                             TO_CHAR(A.OPEN_DT,'YYYYMMDD') AS OPEN_DT,
                                             A.TELNO,
                                             A.ABSENT_YN,
                                             C.cancel_reason,
                                             NVL(sum (case when c.status = '50' AND  NVL(CANCEL_CODE,'00') = '20' then 1 end),0) as CANCELCNT
                                        FROM SHOP_INFO        A,
                                             CALLCENTER       B,
                                             (SELECT * FROM DORDER 
                                             WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND TEST_GBN = 'N'
                                            AND NVL(CANCEL_CODE,'00') = '20'
                                            AND order_date BETWEEN :date_begin
                                                                                     AND :date_end
                                             UNION ALL 
                                             SELECT * FROM DORDER_PAST
                                             WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND TEST_GBN = 'N'
                                            AND NVL(CANCEL_CODE,'00') = '20'
                                            AND order_date BETWEEN :date_begin
                                                                                     AND :date_end) C                                          
                                       WHERE A.CCCODE = B.CCCODE
                                       AND B.MCODE = 2
                                       AND A.SHOP_CD = C.SHOP_CD
                                       and C.SHOP_CD = A.SHOP_CD
                                       {gunguSql} 
                                       GROUP BY A.GUNGU_NAME,
                                             A.SHOP_CD,
                                             A.SHOP_NAME,
                                             TO_CHAR(A.OPEN_DT,'YYYYMMDD'),
                                             A.TELNO,
                                             A.ABSENT_YN,
                                             C.cancel_reason)
                                       where CANCELCNT > 0
                                       ORDER BY CANCELCNT DESC) a
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }

        // 가맹점(주문순위 역순) 엑셀--미사용예정
        [HttpGet("getShopOrderRankReverse")]
        public async Task<IActionResult> getShopOrderRankReverse(string date_begin, string date_end, string gungu)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("gungu", gungu);

                string gunguSql = string.Empty;

                if (gungu is not null)
                {
                    gunguSql = @"AND C.GUNGU_NAME = :gungu";
                }

                string sql = @$"
                                 SELECT rownum, a.*
                                    FROM (  SELECT * 
                                            FROM (
                                                select gungu_name, shop_cd, shop_name, telno, to_char(open_dt,'YYYYMMDD') as open_dt, absent_yn,
                                                        COUNT(shop_cd) AS 총주문
                                                FROM (select c.gungu_name, a.STATUS, c.shop_cd, c.shop_name, c.telno, c.open_dt, c.absent_yn FROM dorder a, callcenter b, shop_info c
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        AND NVL (a.CANCEL_CODE, '00') <> '30'
                                                        AND a.shop_cd = c.shop_cd
                                                        {gunguSql} 
                                                      UNION ALL
                                                      select c.gungu_name, a.STATUS, c.shop_cd, c.shop_name, c.telno, c.open_dt, c.absent_yn FROM dorder_past a, callcenter b, shop_info c
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        AND NVL (a.CANCEL_CODE, '00') <> '30'
                                                        AND a.shop_cd = c.shop_cd
                                                        {gunguSql})
                                                group by gungu_name, shop_cd, shop_name, telno, open_dt, absent_yn)
                                            order by 총주문) a
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }
    }
}
