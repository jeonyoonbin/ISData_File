﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class B2BUserController : ControllerBase
    {
        /// <summary>
        /// 제휴 쿠폰 처리자 관리 - 목록 조회
        /// </summary>
        /// <remarks>
        /// divKey: /1 쿠폰타입 /2 아이디 /3 이름 /4 전화번호 
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string divKey, string keyword, string page, string rows)
        {
            string RTotal = string.Empty;
            string RCount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("div_key", divKey);
                param.Add("keyword", "%" + keyword + "%");
                param.Add("page", page);
                param.Add("row_count", rows);

                string sqlTotal = $@"
                                  select count(*)
                                        from b2b_user
                                        where coupon_type like (case when :div_key = '1' then :keyword else '%' end)
                                        and login_id like (case when :div_key = '2' then :keyword else '%' end)
                                        and name like (case when :div_key = '3' then :keyword else '%' end)
                                        and mobile like (case when :div_key = '4' then :keyword else '%' end)
                                ";
                var tcount = await db.ExecuteScalarAsync(sqlTotal, param, commandType: CommandType.Text);
                RTotal = tcount.ToString();

                string sqlCount = $@"
                                  select count(*)
                                        from b2b_user
                                        where coupon_type like (case when :div_key = '1' then :keyword else '%' end)
                                        and login_id like (case when :div_key = '2' then :keyword else '%' end)
                                        and name like (case when :div_key = '3' then :keyword else '%' end)
                                        and mobile like (case when :div_key = '4' then :keyword else '%' end)
                                ";
                var count = await db.ExecuteScalarAsync(sqlCount, param, commandType: CommandType.Text);
                RCount = count.ToString();

                string sql = $@"
                                  SELECT t2.*
                                  FROM (SELECT ROWNUM AS RNUM,
                                               t1.*
                                          FROM (select user_id, name, login_id, mobile, coupon_type, reg_date, use_yn
                                        from b2b_user
                                        where coupon_type like (case when :div_key = '1' then :keyword else '%' end)
                                        and login_id like (case when :div_key = '2' then :keyword else '%' end)
                                        and name like (case when :div_key = '3' then :keyword else '%' end)
                                        and mobile like (case when :div_key = '4' then :keyword else '%' end)
                                        order by reg_date desc) t1
                                         WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                                 WHERE (( :page - 1) * :row_count) < RNUM
                                ";


                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BUser : Get", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, total = RTotal, count = RCount, data = items});
        }


        //로그인
        [HttpGet("getLogin")]
        public async Task<IActionResult> getLogin(string couponType, string id, string pwd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object item = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("in_coupon_type", couponType);
                param.Add("in_id", id);
                param.Add("in_pwd", pwd);

                string sql = $@"
                                  select nvl(a.user_id,'') user_id,
                                         nvl(a.name,'') name, 
                                         nvl(a.login_id,'') login_id, 
                                         nvl(a.mobile,'') mobile, 
                                         nvl(a.coupon_type,'') coupon_type, 
                                         nvl(a.reg_date,'') reg_date, 
                                         nvl(a.reg_ucode,'') reg_ucode, 
                                         nvl(b.user_name,'') as reg_name, 
                                         nvl(a.mod_date,'') mod_date, 
                                         nvl(a.mod_ucode,0) mod_ucode, 
                                         nvl(c.user_name,'') as mod_name, 
                                         nvl(a.use_yn,'') use_yn
                                  from b2b_user  a, users b, users c
                                  where a.reg_ucode = b.ucode (+)
                                  and a.mod_ucode = c.ucode (+)
                                  and a.coupon_type = :in_coupon_type
                                  and a.login_id = :in_id
                                  and a.login_pwd = SF_SHA256_ENCODE(:in_pwd)
                                  and a.use_yn = 'Y'
                                ";


                item = await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);

                if (item is null)
                {
                    Rcode = "-1";
                    Rmsg = "사용자ID 또는 비밀번호를 확인하십시오.";
                    
                }
                else
                {
                    item = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);
                    //items.Add(temp);

                    Rcode = "00";
                    Rmsg = "성공";
                }

                db.Close();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BUser/getLogin : Get", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }



        //상세정보
        [HttpGet("getDetail/{userId}")]
        public async Task<IActionResult> getDetail(string userId, string ucode)
        {
            string Rposition = "/B2BUser/getDetail/{userId} : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object item = string.Empty;

            string sql = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("in_user_id", int.Parse(userId));

                param.Add("in_ucode", ucode);

                sql = $@"
                                  select nvl(a.user_id,'') user_id,
                                         nvl(a.name,'') name, 
                                         nvl(a.login_id,'') login_id, 
                                         nvl(a.mobile,'') mobile, 
                                         nvl(a.coupon_type,'') coupon_type, 
                                         nvl(a.reg_date,'') reg_date, 
                                         nvl(a.reg_ucode,'') reg_ucode, 
                                         nvl(b.user_name,'') as reg_name, 
                                         nvl(a.mod_date,'') mod_date, 
                                         nvl(a.mod_ucode,0) mod_ucode, 
                                         nvl(c.user_name,'') as mod_name, 
                                         nvl(a.use_yn,'') use_yn
                                  from b2b_user a, users b, users c
                                  where a.user_id = :in_user_id
                                  and a.reg_ucode = b.ucode (+)
                                  and a.mod_ucode = c.ucode (+)
                                ";


                item = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);

                var data = item as IReadOnlyDictionary<string, object>;

                db.Close();

                //조회 로그 기록
                await Utils.setPrivacyLog(ucode, "28", "10", data["NAME"] + " - 이름, 전화번호, 비밀번호", Rposition);

                Rcode = "00";
                Rmsg = "성공";

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
                Rcode = "01";
                Rmsg = ex.Message + sql;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }



        //b2b 관리자 생성
        [HttpPost]
        public async Task<IActionResult> Post(string name, string loginId, string loginPwd, string mobile, string couponType, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("in_name", name);
                param.Add("in_login_id", loginId);
                param.Add("in_login_pwd", loginPwd);
                param.Add("in_mobile", mobile);
                param.Add("in_coupon_type", couponType);
                param.Add("in_ucode", ucode);

                string chkSql = $@"
                                    select count(*)
                                    from b2b_user
                                    where coupon_type = :in_coupon_type
                                    and login_id = :in_login_id
                                ";

                var num = await db.ExecuteScalarAsync(chkSql, param, commandType: CommandType.Text);

                if (int.Parse(num.ToString()) > 0)
                {
                    db.Close();

                    Rcode = "-1";
                    Rmsg = "이미 등록된 ID 입니다";

                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                string sql = @$"
                                INSERT INTO B2B_USER (  NAME, 
                                                        LOGIN_ID,
                                                        LOGIN_PWD, 
                                                        MOBILE, 
                                                        COUPON_TYPE, 
                                                        REG_DATE, 
                                                        REG_UCODE, 
                                                        USE_YN )  
                                            VALUES (    :in_name, 
                                                        :in_login_id,
                                                        SF_SHA256_ENCODE(:in_login_pwd), 
                                                        :in_mobile, 
                                                        :in_coupon_type, 
                                                        SYSDATE, 
                                                        :in_ucode, 
                                                        'Y' )
                ";

                var temp = await db.ExecuteAsync(sql, param, commandType: CommandType.Text);


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BUser : Post", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg});
        }

        //b2b 관리자 계정 수정
        [HttpPut]
        public async Task<IActionResult> Put(string userId, string couponType, string name, string loginId, string loginPwd, string mobile)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("in_user_id", int.Parse(userId));
                param.Add("in_coupon_type", couponType);
                param.Add("in_name", name);
                param.Add("in_login_id", loginId);
                param.Add("in_login_pwd", loginPwd);
                param.Add("in_mobile", mobile);

                string chkSql = $@"
                                    select count(*)
                                    from b2b_user
                                    where user_id <> :in_user_id
                                    and coupon_type = :in_coupon_type
                                    and login_id = :in_login_id
                                        
                                ";

                var num = await db.ExecuteScalarAsync(chkSql, param, commandType: CommandType.Text);

                if (int.Parse(num.ToString()) > 0)
                {
                    db.Close();

                    Rcode = "-1";
                    Rmsg = "이미 등록된 ID 입니다";

                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                string sql = $@"
                                    UPDATE b2b_user
                                    SET name = :in_name,
                                        login_id = :in_login_id,
                                        login_pwd = SF_SHA256_ENCODE(:in_login_pwd),
                                        mobile = :in_mobile
                                    WHERE user_id = :in_user_id
                                        
                                ";

                await db.QueryAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BUser : Put", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        //b2b 관리자 계정 수정 - 운영팀에서 수정하는경우?
        [HttpPut("setB2BUser")]
        public async Task<IActionResult> setB2BUser(string userId, string couponType, string name, string loginId, string loginPwd, string mobile, string useYn, string modUcode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("in_user_id", int.Parse(userId));
                param.Add("in_coupon_type", couponType);
                param.Add("in_name", name);
                param.Add("in_login_id", loginId);
                param.Add("in_login_pwd", loginPwd);
                param.Add("in_mobile", mobile);
                param.Add("in_ucode", modUcode);
                param.Add("in_use_yn", useYn);

                string chkSql = $@"
                                    select count(*)
                                    from b2b_user
                                    where user_id <> :in_user_id
                                    and coupon_type = :in_coupon_type
                                    and login_id = :in_login_id
                                        
                                ";
       


                var num = await db.ExecuteScalarAsync(chkSql, param, commandType: CommandType.Text);

                if (int.Parse(num.ToString()) > 0)
                {
                    db.Close();

                    Rcode = "-1";
                    Rmsg = "이미 등록된 ID 입니다";

                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                string sql = string.Empty;

                if (string.IsNullOrEmpty(loginPwd) == false )
                {
                    sql = $@"
                                    UPDATE b2b_user
                                    SET name = :in_name,
                                        login_id = :in_login_id,
                                        login_pwd = SF_SHA256_ENCODE(:in_login_pwd),
                                        mobile = :in_mobile,
                                        mod_ucode = :in_ucode,
                                        mod_date = SYSDATE,
                                        use_yn = :in_use_yn
                                    WHERE user_id = :in_user_id
                                        
                                ";
                } else 
                {
                    sql = $@"
                                    UPDATE b2b_user
                                    SET name = :in_name,
                                        coupon_type = :in_coupon_type,
                                        login_id = :in_login_id,
                                        mobile = :in_mobile,
                                        mod_ucode = :in_ucode,
                                        mod_date = SYSDATE,
                                        use_yn = :in_use_yn
                                    WHERE user_id = :in_user_id
                                        
                                ";
                }


                await db.QueryAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BUser/setB2BUser : Put", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }



    }
}
