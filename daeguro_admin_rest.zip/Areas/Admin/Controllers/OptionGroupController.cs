﻿using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [SwaggerTag("메뉴옵션그룹 관리")]
    [ApiController]
    public class OptionGroupController : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> Get(string shopCd, string menuCd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<OptionGroup> optionGroups = new List<OptionGroup>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_OPTION_GROUP_LIST",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = shopCd;
            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = menuCd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {

                    OptionGroup s = new OptionGroup
                    {
                        selected = rd["SELECTED"].ToString(),
                        optionGroupCd = rd["OPTION_GROUP_CD"].ToString(),
                        optionGroupName = rd["OPTION_GROUP_NAME"].ToString(),
                        minCount = rd["MIN_COUNT"].ToString(),
                        maxCount = rd["MULTI_COUNT"].ToString(),
                        multiYn = rd["MULTI_YN"].ToString(),
                        useYn = rd["USE_YN"].ToString(),
                        optionNames = rd["OPTION_NAMES"].ToString(),
                    };

                    optionGroups.Add(s);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/optionGroup : Get", ex.Message);

                return Ok(new { code = "99", msg = "실패", data = optionGroups });
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = optionGroups });
        }


        [HttpPost]
        public async Task<IActionResult> Post(MenuOptionGroup menuOptionGroup)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.ADD_MENU_OGROUP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = menuOptionGroup.shopCd;
            cmd.Parameters.Add("in_group_name", OracleDbType.Varchar2, 50).Value = menuOptionGroup.optionGroupName;
            cmd.Parameters.Add("in_group_memo", OracleDbType.Varchar2, 500).Value = menuOptionGroup.optionGroupMemo;
            cmd.Parameters.Add("in_min_count", OracleDbType.Varchar2, 500).Value = menuOptionGroup.minCount;
            cmd.Parameters.Add("in_max_count", OracleDbType.Varchar2, 500).Value = menuOptionGroup.maxCount;
            cmd.Parameters.Add("in_multi_yn", OracleDbType.Varchar2, 500).Value = menuOptionGroup.multiYn;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 1).Value = menuOptionGroup.useYn;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 30).Value = menuOptionGroup.insertName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuOptionGroup : Post", ex.Message);
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpPut]
        public async Task<IActionResult> Put(MenuOptionGroup menuOptionGroup)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.UPDATE_MENU_OGROUP",
            };

            cmd.Parameters.Add("in_group_cd", OracleDbType.Int32).Value = menuOptionGroup.optionGroupCd;
            cmd.Parameters.Add("in_group_name", OracleDbType.Varchar2, 50).Value = menuOptionGroup.optionGroupName;
            cmd.Parameters.Add("in_group_memo", OracleDbType.Varchar2, 500).Value = menuOptionGroup.optionGroupMemo;
            cmd.Parameters.Add("in_min_count", OracleDbType.Varchar2, 500).Value = menuOptionGroup.minCount;
            cmd.Parameters.Add("in_max_count", OracleDbType.Varchar2, 500).Value = menuOptionGroup.maxCount;
            cmd.Parameters.Add("in_multi_yn", OracleDbType.Varchar2, 500).Value = menuOptionGroup.multiYn;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 1).Value = menuOptionGroup.useYn;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 30).Value = menuOptionGroup.insertName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuOptionGroup : Put", ex.Message);
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpDelete("{option_group_cd}")]
        public async Task<IActionResult> Delete(string option_group_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.DELETE_MENU_OGROUP",
            };

            cmd.Parameters.Add("in_option_group_cd", OracleDbType.Int32).Value = option_group_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuOptionGroup : Delete", ex.Message);
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpGet("{option_group_cd}")]
        public async Task<IActionResult> Get(string option_group_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_MENU_OGROUP_DETAIL",
            };

            cmd.Parameters.Add("in_option_group_cd", OracleDbType.Int32).Value = option_group_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            MenuOptionGroup menuOptionGroup = new MenuOptionGroup();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                menuOptionGroup.optionGroupCd = rd["OPTION_GROUP_CD"].ToString();
                menuOptionGroup.optionGroupName = rd["OPTION_GROUP_NAME"].ToString();
                menuOptionGroup.optionGroupMemo = rd["OPTION_GROUP_MEMO"].ToString();
                menuOptionGroup.useYn = rd["USE_YN"].ToString();
                menuOptionGroup.minCount = rd["MIN_COUNT"].ToString();
                menuOptionGroup.maxCount = rd["MULTI_COUNT"].ToString();
                menuOptionGroup.multiYn = rd["MULTI_YN"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuOptionGroup/option_group_cd : Get", ex.Message);
                return Ok(new { code = Rcode, msg = Rmsg, data = menuOptionGroup });
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = menuOptionGroup });
        }

        [HttpPost("copyOptionGroup")]
        public async Task<IActionResult> copyMenuOption(string shop_cd, string option_group_cd, string insert_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.COPY_OPTION_GROUP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_option_group_cd", OracleDbType.Varchar2, 10).Value = option_group_cd;
            cmd.Parameters.Add("in_insert_name", OracleDbType.Varchar2, 30).Value = insert_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuOptionGroup/copyOptionGroup : Post", ex.Message);
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        ///  옵션그룹에 연결된 메뉴목록
        /// </summary>
        /// <remarks>
        /// * 사용여부 Y인 메뉴만 조회 <br/>
        /// selectYn : 연결여부 <br/>
        /// menuGroupCd : 메뉴그룹코드 <br/>
        /// menuGroupName : 메뉴그룹명 <br/>
        /// menuCd : 메뉴코드 <br/>
        /// menuName : 메뉴명 <br/>
        /// menuDesc : 메뉴설명 <br/>
        /// menuCost : 메뉴금액 <br/>
        /// </remarks>
        [HttpGet("getMenuLinked")]
        public async Task<IActionResult> getLinkedMenu(string shop_cd, string option_group_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.GET_MENU_LINKED_OGROUP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2,10).Value = shop_cd;
            cmd.Parameters.Add("in_option_group_cd", OracleDbType.Int32).Value = option_group_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<MenuLinkedOGroup> itemList = new List<MenuLinkedOGroup>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {

                    MenuLinkedOGroup item = new MenuLinkedOGroup
                    {
                        selectYn = rd["SELECT_YN"].ToString(),
                        menuGroupCd = rd["MENU_GROUP_CD"].ToString(),
                        menuGroupName = rd["MENU_GROUP_NAME"].ToString(),
                        menuCd = rd["MENU_CD"].ToString(),
                        menuName = rd["MENU_NAME"].ToString(),
                        menuDesc = rd["MENU_DESC"].ToString(),
                        menuCost = rd["MENU_COST"].ToString(),
                        //useGbn = rd["USE_GBN"].ToString(),
                    };
                    itemList.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/OptionGroup/getLinkedMenu : Get", ex.Message);
                return Ok(new { code = Rcode, msg = Rmsg, data = itemList });
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = itemList });
        }

        /// <summary>
        ///  옵션그룹에 연결된 메뉴목록 수정
        /// </summary>
        /// <remarks>
        /// shop_cd : 가맹점코드 <br/>
        /// option_group_cd : 메뉴옵션그룹코드 <br/>
        /// menu_cd : 메뉴코드 배열 <br/>
        /// </remarks>
        [HttpPut("setMenuLinked")]
        public async Task<IActionResult> setMenuLinked(string shop_cd, string option_group_cd, IEnumerable<string> menu_cd, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.SET_MENU_LINKED_OGROUP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_option_group_cd", OracleDbType.Int32).Value = option_group_cd;
            var arr = cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32);
            arr.Direction = ParameterDirection.Input;
            arr.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr.Value = menu_cd.ToArray();
            arr.Size = menu_cd.Count();
            arr.ArrayBindSize = menu_cd.Select(_ => _.Length).ToArray();
            arr.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, menu_cd.Count()).ToArray();
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2,30).Value = mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/OptionGroup/setLinkedMenu : Put", ex.Message);
                return Ok(new { code = Rcode, msg = Rmsg});
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        ///// <summary>
        /////  옵션그룹에 연결된 메뉴목록
        ///// </summary>
        ///// <remarks>
        ///// menuGroupCd : 메뉴그룹코드 <br/>
        ///// menuGroupName : 메뉴그룹명 <br/>
        ///// list : 메뉴리스트 <br/>
        ///// - menuCd : 메뉴코드 <br/>
        ///// - menuName : 메뉴명 <br/>
        ///// - menuDesc : 메뉴설명 <br/>
        ///// - menuCost : 메뉴금액 <br/>
        ///// - useGbn : 사용여부 <br/>
        ///// </remarks>
        //[HttpGet("getMenuLinked/{option_group_cd}")]
        //public async Task<IActionResult> getLinkedMenu(string option_group_cd)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_MENU.GET_MENU_LINKED_OGROUP",
        //    };

        //    cmd.Parameters.Add("in_option_group_cd", OracleDbType.Int32).Value = option_group_cd;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

        //    List<MenuGroupLinkedOGroup> groupList = new List<MenuGroupLinkedOGroup>();
        //    List<MenuLinkedOGroup> itemList = new List<MenuLinkedOGroup>();

        //    try
        //    {
        //        await conn.OpenAsync();
        //        var rd = await cmd.ExecuteReaderAsync();

        //        Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        while (await rd.ReadAsync())
        //        {
        //            MenuGroupLinkedOGroup group = new MenuGroupLinkedOGroup
        //            {
        //                menuGroupCd = rd["MENU_GROUP_CD"].ToString(),
        //                menuGroupName = rd["MENU_GROUP_NAME"].ToString(),
        //                list = new List<MenuLinkedOGroup>(),
        //            };

        //            if(groupList.TrueForAll(x => x.menuGroupCd != group.menuGroupCd))
        //            {
        //                groupList.Add(group);
        //            }

        //            MenuLinkedOGroup item = new MenuLinkedOGroup
        //            {
        //                menuGroupCd = rd["MENU_GROUP_CD"].ToString(),
        //                menuCd = rd["MENU_CD"].ToString(),
        //                menuName = rd["MENU_NAME"].ToString(),
        //                menuDesc = rd["MENU_DESC"].ToString(),
        //                menuCost = rd["MENU_COST"].ToString(),
        //                useGbn = rd["USE_GBN"].ToString(),
        //            };
        //            itemList.Add(item);
        //            groupList.ForEach(X => { if (X.menuGroupCd == item.menuGroupCd) X.list.Add(item); });
        //        }

        //        await rd.CloseAsync();
        //        await conn.CloseAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/OptionGroup/getLinkedMenu : Get", ex.Message);
        //        return Ok(new { code = Rcode, msg = Rmsg, data = groupList });
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg, data = groupList });
        //}

    }
}
