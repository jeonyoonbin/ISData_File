﻿using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [ApiController]
    [Route("admin/[controller]")]
    public class OrderDetailMenuController : ControllerBase
    {
        [HttpGet("{orderNo}")]
        public async Task<IActionResult> Get(string orderNo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<OrderDetailMenu> agents = new List<OrderDetailMenu>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_ADMIN_ORDER.GET_ORDER_DETAIL_MENU",
            };

            cmd.Parameters.Add("in_order_no", OracleDbType.Int32).Value = int.Parse(orderNo);
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                while (await rd.ReadAsync())
                {
                    Rcode = cmd.Parameters["out_code"].Value.ToString();
                    Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                    OrderDetailMenu m = new OrderDetailMenu
                    {
                        menuName = rd["MENU_NAME"].ToString(),
                        orderCost = rd["ORDER_COST"].ToString(),
                        orderQty = rd["ORDER_QTY"].ToString(),
                        orderAmt = rd["ORDER_AMT"].ToString(),
                    };

                    agents.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                Utils.SaveError("shop/OrderDetailMenu/orderNo : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = agents });

        }
    }
}
