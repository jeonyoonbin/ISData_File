﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class DeliTipController : ControllerBase
    {
        #region[가맹점 배달팁 및 운영시간 관리]
        /// <summary>
        /// 가맹점 배달팁 및 운영시간 조회
        /// </summary>
        /// <remarks>
        /// shopCd : 가맹점코드 <br/>
        /// tipGbn : 배달팁 구분(1:거리별/3:주문금액/7:요일시간/9:동기준) *현재 전통시장의 경우만 동기준 대신 거리별 사용
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string shopCd, string tipGbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<DeliTip> deliTip = new List<DeliTip>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_SHOP_TIP_AMT_LIST",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shopCd;
            cmd.Parameters.Add("in_tip_gbn", OracleDbType.Varchar2, 10).Value = tipGbn;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    DeliTip s = new DeliTip
                    {
                        tipSeq = rd["TIP_SEQ"].ToString(),
                        tipDay = rd["TIP_DAY"].ToString(),
                        tipFromStand = rd["TIP_FR_STAND"].ToString(),
                        tipNextDay = rd["TIP_NEXT_DAY"].ToString(),
                        tipToStand = rd["TIP_TO_STAND"].ToString(),
                        tipAmt = rd["TIP_AMT"].ToString(),
                    };

                    deliTip.Add(s);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/DeliTip : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = deliTip });
        }

        /// <summary>
        /// 가맹점 배달팁 등록
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> Post(DeliTip deliTip)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.ADD_SHOP_INFO_TIP_AMT",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = deliTip.shopCd;
            cmd.Parameters.Add("in_tip_gbn", OracleDbType.Varchar2, 20).Value = deliTip.tipGbn;
            cmd.Parameters.Add("in_tip_day", OracleDbType.Varchar2, 20).Value = deliTip.tipDay;
            cmd.Parameters.Add("in_tip_fr_stand", OracleDbType.Varchar2, 10).Value = deliTip.tipFromStand;
            cmd.Parameters.Add("in_tip_next_day", OracleDbType.Varchar2, 1).Value = deliTip.tipNextDay;
            cmd.Parameters.Add("in_tip_to_stand", OracleDbType.Varchar2, 10).Value = deliTip.tipToStand;
            cmd.Parameters.Add("in_tip_amt", OracleDbType.Varchar2, 20).Value = deliTip.tipAmt;
            cmd.Parameters.Add("in_tip_amt_rate", OracleDbType.Varchar2, 20).Value = deliTip.tipAmtRate;
            cmd.Parameters.Add("in_user_ucode", OracleDbType.Varchar2, 20).Value = deliTip.modUCode;
            cmd.Parameters.Add("in_user_name", OracleDbType.Varchar2, 20).Value = deliTip.modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/DeliTip : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        
        /// <summary>
        /// 가맹점 배달팁 수정
        /// </summary>
        [HttpPut]
        public async Task<IActionResult> Put(DeliTip deliTip)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.UPDATE_SHOP_INFO_TIP_AMT",
            };

            cmd.Parameters.Add("in_tip_seq", OracleDbType.Int32).Value = deliTip.tipSeq;
            cmd.Parameters.Add("in_tip_gbn", OracleDbType.Varchar2, 10).Value = deliTip.tipGbn;
            cmd.Parameters.Add("in_tip_day", OracleDbType.Varchar2, 10).Value = deliTip.tipDay;
            cmd.Parameters.Add("in_tip_fr_stand", OracleDbType.Varchar2, 10).Value = deliTip.tipFromStand;
            cmd.Parameters.Add("in_tip_next_day", OracleDbType.Varchar2, 1).Value = deliTip.tipNextDay;
            cmd.Parameters.Add("in_tip_to_stand", OracleDbType.Varchar2, 10).Value = deliTip.tipToStand;
            cmd.Parameters.Add("in_tip_amt", OracleDbType.Int32).Value = deliTip.tipAmt;
            cmd.Parameters.Add("in_tip_amt_rate", OracleDbType.Varchar2, 1).Value = deliTip.tipAmtRate;
            cmd.Parameters.Add("in_user_ucode", OracleDbType.Int32).Value = deliTip.modUCode;
            cmd.Parameters.Add("in_user_name", OracleDbType.Varchar2, 50).Value = deliTip.modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/DeliTip : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 배달팁 삭제
        /// </summary>
        /// <remarks>
        /// tipGbn : 배달팁 구분(1: 거리별 /0: 그 외)
        /// </remarks>
        [HttpDelete("{tipSeq}")]
        public async Task<IActionResult> Delete(string tipGbn, string tipSeq, string modUcode, string modName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.DELETE_SHOP_INFO_TIP_AMT",
            };

            cmd.Parameters.Add("in_tip_gbn", OracleDbType.Varchar2, 1).Value = tipGbn;
            cmd.Parameters.Add("in_tip_seq", OracleDbType.Int32).Value = tipSeq;
            cmd.Parameters.Add("in_mod_code", OracleDbType.Int32).Value = modUcode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 50).Value = modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/DeliTip : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 운영시간 수정
        /// </summary>
        [HttpPut("setDayTime")]
        public async Task<IActionResult> setDayTime(string shop_cd, IEnumerable<DayTime> dayTime,  string userCode, string userName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.SET_DAY_TIME",
            };

            List<string> tipDays = new List<string>();
            List<string> tipFrStnads = new List<string>();
            List<string> tipToStnads = new List<string>();
            List<string> tipNextDays = new List<string>();


            foreach (var item in dayTime)
            {
                tipDays.Add(item.tipDay);
                tipFrStnads.Add(item.tipFrStand);
                tipToStnads.Add(item.tipToStand);
                tipNextDays.Add(item.tipNextDay);
            }


            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;

            var arrTipDay = cmd.Parameters.Add("in_tip_day", OracleDbType.Varchar2, 10);
            arrTipDay.Direction = ParameterDirection.Input;
            arrTipDay.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrTipDay.Value = tipDays.ToArray();
            arrTipDay.Size = tipDays.Count();
            arrTipDay.ArrayBindSize = tipDays.Select(_ => _.Length).ToArray();
            arrTipDay.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, tipDays.Count()).ToArray();

            var arrTipFrStand = cmd.Parameters.Add("in_tip_fr_stand", OracleDbType.Varchar2, 50);
            arrTipFrStand.Direction = ParameterDirection.Input;
            arrTipFrStand.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrTipFrStand.Value = tipFrStnads.ToArray();
            arrTipFrStand.Size = tipFrStnads.Count();
            arrTipFrStand.ArrayBindSize = tipFrStnads.Select(_ => _.Length).ToArray();
            arrTipFrStand.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, tipFrStnads.Count()).ToArray();

            var arrTipToStand = cmd.Parameters.Add("in_tip_to_stand", OracleDbType.Varchar2, 50);
            arrTipToStand.Direction = ParameterDirection.Input;
            arrTipToStand.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrTipToStand.Value = tipToStnads.ToArray();
            arrTipToStand.Size = tipToStnads.Count();
            arrTipToStand.ArrayBindSize = tipToStnads.Select(_ => _.Length).ToArray();
            arrTipToStand.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, tipToStnads.Count()).ToArray();

            var arrTipNextDay = cmd.Parameters.Add("in_tip_next_day", OracleDbType.Varchar2, 1);
            arrTipNextDay.Direction = ParameterDirection.Input;
            arrTipNextDay.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrTipNextDay.Value = tipNextDays.ToArray();
            arrTipNextDay.Size = tipNextDays.Count();
            arrTipNextDay.ArrayBindSize = tipNextDays.Select(_ => _.Length).ToArray();
            arrTipNextDay.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, tipNextDays.Count()).ToArray();

            cmd.Parameters.Add("in_user_ucode", OracleDbType.Int32).Value = userCode;
            cmd.Parameters.Add("in_user_name", OracleDbType.Varchar2, 50).Value = userName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu/setDayTime : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        //배달팁 변경이력
        [HttpGet("history/{shop_cd}")]
        public async Task<IActionResult> history(string shop_cd, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT *
                                FROM (select ROWNUM as NO, T1.*
                                from(select mod_time, mod_desc from shop_info_tip_amt_log
                                where shop_cd = :shop_cd
                                order by logno desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2
                                WHERE ((:in_page - 1) * :in_rows) < NO
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = items.Count.ToString(), data = items });
        }

        #endregion[가맹점 배달팁 및 운영시간 관리]

        #region[가맹점 운영정보 관리]
        /// <summary>
        /// 가맹점 운영정보 조회
        /// </summary>
        /// <remarks>
        /// appOrderyn,reserveYn(앱승인(주문,예약))값 <br/>
        /// autoCancelGbn : 매장자동접수여부(Y: 수동접수(DEFAULT)/ N: 자동접수) * Y/N 구분이 의미와 반대 <br/>
        ///  <br/>
        ///  * 자동완료취소 설정이 빈값인 경우 카테고리1의 값에따라 처리됨 <br/>
        ///  (카테고리별 자동완료취소 관리기능 추후개발예정) <br/>
        ///  밀키트 : 자동완료 접수일시기준 7일(10080분)/ 자동취소 접수일시기준 1일(1440분) <br/>
        ///  꽃배달 : 자동완료 배송일시기준 1일(1440분)/ 자동취소 사용안함 <br/>
        ///  그외 모든 카테고리 : 자동완료 접수일시기준 3시간(180분)/ 자동취소 접수일시기준 5분 <br/>
        /// autoCompType : 자동완료 구분(0.사용안함, 1. 접수일시기준, 2.배송일시기준) <br/>
        /// autoCompTerm : 자동완료 처리시간(분단위) <br/>
        /// autoCancelType : 자동취소 구분(0.사용안함, 1. 접수일시기준) <br/>
        /// autoCancelTerm : 자동취소 처리시간(분단위) <br/>
        /// autoCompTypeC : 자동완료 구분(카테고리) <br/>
        /// autoCompTermC : 자동완료 처리시간(카테고리) <br/>
        /// autoCancelTypeC : 자동취소 구분(카테고리) <br/>
        /// autoCancelTermC : 자동취소 처리시간(카테고리) <br/>
        ///  <br/>
        /// pushGbn : 푸시 구분(1: 음식 00분, 2: 상품 00분, 3: 배달안내 문구) <br/>
        /// kakaoBiztalkGbn : 카카오 비즈톡 구분(1: 음식 00분, 2: 상품 00분, 3: 배달안내 문구) <br/>
        /// mall_use_gbn : 쇼핑몰 이용여부(Y:사용, N:미사용) <br/>
        /// mall_tos_agre : 쇼핑몰 서비스 이용약관 동의여부(Y:사용, N:미사용) <br/>
        /// mall_tos_agre_dt : 쇼핑몰 서비스 이용약관 동의일시 <br/>
        /// kind_shop_status : 착한매장 운영상태 <br/>
        /// kind_shop_set_date : 착한매장 등록일자 <br/>
        /// kind_shop_pause_dt : 착한매장 일시중지일자 <br/>
        /// kind_shop_cancel_dt : 착한매장 해지일자 <br/>
        /// kind_shop_memo : 착한매장 메모 <br/>
        /// youtube_url : 소개영상(유튜브 url) <br/>
        /// child_meal_yn : 아동급식여부 <br/>
        /// child_meal_cd : 아동급식가맹점코드 <br/>
        /// min_amt_pass : 최소주문금액 통과여부(기본:N) <br/>
        /// reg_no : 사업자번호 <br/>
        /// exchange_notice : 교환안내 <br/>
        /// return_notice : 반품안내 <br/>
        /// reject_notice : 교환 및 환불 불가 안내 <br/>
        /// <br/>
        /// deli_notice : 배송정보 배열 <br/>
        ///  - deli_notice_code 배송정보 pk <br/>
        ///  - title 제목 <br/>
        ///  - content 내용 <br/>
        ///  - sort_seq 순번 <br/>
        /// </remarks>
        [HttpGet("getSaleTime/{shop_cd}")]
        public async Task<IActionResult> getSaleTime(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            SaleTime saleTime = new SaleTime();
            List<DeliNotice> subItems = new List<DeliNotice>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_SALE_TIME",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor2", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                saleTime.saleFromTime = rd["SALE_FR_TIME"].ToString();
                saleTime.saleToTime = rd["SALE_TO_TIME"].ToString();
                saleTime.saleNextDay = rd["SALE_NEXT_DAY"].ToString();
                saleTime.appOrderYn = rd["APP_ORDER_YN"].ToString();
                saleTime.useGbn = rd["USE_GBN"].ToString();
                saleTime.happyPayUseGbn = rd["ISCARD_USE_GBN"].ToString();
                saleTime.confirmYn = rd["CONFIRM_YN"].ToString();
                saleTime.confirmDate = rd["CONFIRM_DATE"].ToString();
                saleTime.closedLogin = rd["CLOSED_LOGIN"].ToString();
                saleTime.supportFund = rd["SUPPORT_FUND"].ToString();
                saleTime.reserveYn = rd["RESERVE_YN"].ToString();
                saleTime.shopType = rd["SHOP_TYPE"].ToString();
                saleTime.reserveApprovalDt = rd["RESERVE_APPROVAL_DT"].ToString();
                saleTime.autoCancelGbn = rd["AUTO_CANCEL_GBN"].ToString();
                //saleTime.autoCompYn = rd["AUTO_COMP_YN"].ToString();
                saleTime.autoCompType = rd["AUTO_COMP_TYPE"].ToString();
                saleTime.autoCompTerm = rd["AUTO_COMP_TERM"].ToString();
                saleTime.autoCancelType = rd["AUTO_CANCEL_TYPE"].ToString();
                saleTime.autoCancelTerm = rd["AUTO_CANCEL_TERM"].ToString();
                saleTime.autoCompTypeC = rd["AUTO_COMP_TYPE_C"].ToString();
                saleTime.autoCompTermC = rd["AUTO_COMP_TERM_C"].ToString();
                saleTime.autoCancelTypeC = rd["AUTO_CANCEL_TYPE_C"].ToString();
                saleTime.autoCancelTermC = rd["AUTO_CANCEL_TERM_C"].ToString();
                saleTime.pushGbn = rd["PUSH_GBN"].ToString();
                saleTime.kakaoBiztalkGbn = rd["KAKAO_BIZTALK_GBN"].ToString();
                saleTime.mall_use_gbn = rd["MALL_USE_GBN"].ToString();
                saleTime.mall_tos_agre = rd["MALL_TOS_AGRE"].ToString();
                saleTime.mall_tos_agre_dt = rd["MALL_TOS_AGRE_DT"].ToString();
                saleTime.kind_shop_status = rd["KIND_SHOP_STATUS"].ToString();
                saleTime.kind_shop_set_date = rd["KIND_SHOP_SET_DATE"].ToString();
                saleTime.kind_shop_pause_dt = rd["KIND_SHOP_PAUSE_DT"].ToString();
                saleTime.kind_shop_cancel_dt = rd["KIND_SHOP_CANCEL_DT"].ToString();
                saleTime.kind_shop_memo = rd["KIND_SHOP_MEMO"].ToString();
                saleTime.youtube_url = rd["YOUTUBE_URL"].ToString();
                saleTime.child_meal_yn = rd["CHILD_MEAL_YN"].ToString();
                saleTime.child_meal_cd = rd["CHILD_MEAL_CD"].ToString();
                saleTime.min_amt_pass = rd["MIN_AMT_PASS"].ToString();
                saleTime.reg_no = rd["REG_NO"].ToString();
                saleTime.exchange_notice = rd["exchange_notice"].ToString();
                saleTime.return_notice = rd["return_notice"].ToString();
                saleTime.reject_notice = rd["reject_notice"].ToString();

                await rd.NextResultAsync();

                while (await rd.ReadAsync())
                {
                    DeliNotice subItem = new DeliNotice
                    {
                        deli_notice_code = rd["deli_notice_code"].ToString(),
                        title = rd["title"].ToString(),
                        content = rd["content"].ToString(),
                        sort_seq = rd["sort_seq"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["ins_name"].ToString(),
                        mod_date = rd["mod_date"].ToString(),
                        mod_ucode = rd["mod_ucode"].ToString(),
                        mod_name = rd["mod_name"].ToString(),
                    };

                    subItems.Add(subItem);
                }

                saleTime.deli_notice = subItems.ToArray();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/DeliTip/getSaleTime/{shop_cd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = saleTime });
        }

        /// <summary>
        /// 가맹점 운영정보 수정
        /// </summary>
        /// <remarks>
        /// appOrderyn,reserveYn(앱승인(주문,예약))값 'Y'로 최초 수정시 승인일자 기입 <br/>
        /// autoCancelGbn : 매장자동접수여부(Y: 수동접수(DEFAULT)/ N: 자동접수) * Y/N 구분이 의미와 반대 <br/>
        ///  <br/>
        ///  * 자동완료취소 설정이 빈값인 경우 카테고리1의 값에따라 처리됨 <br/>
        ///  (카테고리별 자동완료취소 관리기능 추후개발예정) <br/>
        ///  밀키트 : 자동완료 접수일시기준 7일(10080분)/ 자동취소 접수일시기준 1일(1440분) <br/>
        ///  꽃배달 : 자동완료 배송일시기준 1일(1440분)/ 자동취소 사용안함 <br/>
        ///  그외 모든 카테고리 : 자동완료 접수일시기준 3시간(180분)/ 자동취소 접수일시기준 5분 <br/>
        /// autoCompType : 자동완료 구분(0.사용안함, 1. 접수일시기준, 2.배송일시기준) <br/>
        /// autoCompTerm : 자동완료 처리시간(분단위) <br/>
        /// autoCancelType : 자동취소 구분(0.사용안함, 1. 접수일시기준) <br/>
        /// autoCancelTerm : 자동취소 처리시간(분단위) <br/>
        ///  <br/>
        /// pushGbn 푸시 구분(1: 음식 00분, 2: 상품 00분, 3: 배달안내 문구) <br/>
        /// kakaoBiztalkGbn 카카오 비즈톡 구분(1: 음식 00분, 2: 상품 00분, 3: 배달안내 문구) <br/>
        /// mall_use_gbn 쇼핑몰 이용여부(Y:사용, N:미사용)  <br/>
        /// kind_shop_status : 착한매장 운영상태 (10: 사용중, 20: 일시중지, 30: 해지완료, 40: 사용안함) <br/>        
        /// kind_shop_memo : 착한매장 메모 <br/>
        /// youtube_url : 가맹점 소개영상(유튜브 URL) <br/>
        /// child_meal_yn : 아동급식여부(Y/N) <br/>
        /// child_meal_cd : 아동급식가맹점코드 <br/>
        /// min_amt_pass : 최소주문금액 통과여부(기본:N) <br/>
        /// </remarks>
        [HttpPost("setSaleTime")]
        public async Task<IActionResult> setSaleTime(DeliTip deliTip)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            // 자동완료, 자동취소는 아예 비우거나 사용안함이 아니면 시간설정 필수
            if (string.IsNullOrEmpty(deliTip.autoCompType))
            {
                if (!string.IsNullOrEmpty(deliTip.autoCompTerm))// 타입이 빈값인데 처리시간이 들어오면 에러날리지 말고 강제 널처리 추가
                {
                    deliTip.autoCompTerm = null;
                    //return Ok(new { code = "99", msg = "자동완료 설정을 다시 확인하세요" });
                }
            }
            else if (deliTip.autoCompType != "0" && string.IsNullOrEmpty(deliTip.autoCompTerm))
            {
                return Ok(new { code = "99", msg = "자동완료 설정을 다시 확인하세요" });
            }

            if (string.IsNullOrEmpty(deliTip.autoCancelType))
            {
                if (!string.IsNullOrEmpty(deliTip.autoCancelTerm))// 타입이 빈값인데 처리시간이 들어오면 에러날리지 말고 강제 널처리 추가
                {
                    deliTip.autoCancelTerm = null;
                    //return Ok(new { code = "99", msg = "자동취소 설정을 다시 확인하세요" });
                }
            }
            else if (deliTip.autoCancelType != "0" && string.IsNullOrEmpty(deliTip.autoCancelTerm))
            {
                return Ok(new { code = "99", msg = "자동취소 설정을 다시 확인하세요" });
            }

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.SET_SALE_TIME",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = deliTip.shopCd;
            cmd.Parameters.Add("in_sale_from_time", OracleDbType.Varchar2, 4).Value = deliTip.tipFromStand;
            cmd.Parameters.Add("in_sale_to_time", OracleDbType.Varchar2, 4).Value = deliTip.tipToStand;
            cmd.Parameters.Add("in_sale_next_day", OracleDbType.Varchar2, 1).Value = deliTip.tipNextDay;
            cmd.Parameters.Add("in_app_order_yn", OracleDbType.Varchar2, 1).Value = deliTip.appOrderyn;
            cmd.Parameters.Add("in_reserve_yn", OracleDbType.Varchar2, 1).Value = deliTip.reserveYn;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = deliTip.useGbn;
            cmd.Parameters.Add("in_happypay_use_gbn", OracleDbType.Varchar2, 1).Value = deliTip.happyPayUseGbn;
            cmd.Parameters.Add("in_closed_login", OracleDbType.Varchar2, 1).Value = deliTip.closedLogin;
            cmd.Parameters.Add("in_support_fund", OracleDbType.Varchar2, 1).Value = deliTip.supportFund;
            cmd.Parameters.Add("in_auto_cancel_gbn", OracleDbType.Varchar2, 1).Value = deliTip.autoCancelGbn;
            //cmd.Parameters.Add("in_auto_comp_yn", OracleDbType.Varchar2, 1).Value = deliTip.autoCompYn;
            cmd.Parameters.Add("in_auto_comp_type", OracleDbType.Varchar2, 1).Value = deliTip.autoCompType;
            cmd.Parameters.Add("in_auto_comp_term", OracleDbType.Varchar2, 10).Value = deliTip.autoCompTerm;
            cmd.Parameters.Add("in_auto_cancel_type", OracleDbType.Varchar2, 1).Value = deliTip.autoCancelType;
            cmd.Parameters.Add("in_auto_cancel_term", OracleDbType.Varchar2, 10).Value = deliTip.autoCancelTerm;
            cmd.Parameters.Add("in_push_gbn", OracleDbType.Varchar2, 2).Value = deliTip.pushGbn;
            cmd.Parameters.Add("in_kakao_biztalk_gbn", OracleDbType.Varchar2, 2).Value = deliTip.kakaoBiztalkGbn;
            cmd.Parameters.Add("in_mall_use_gbn", OracleDbType.Varchar2, 1).Value = deliTip.mall_use_gbn;
            cmd.Parameters.Add("in_kind_shop_status", OracleDbType.Varchar2, 2).Value = deliTip.kind_shop_status;
            cmd.Parameters.Add("in_kind_shop_answer", OracleDbType.Varchar2, 500).Value = deliTip.kind_shop_answer;
            cmd.Parameters.Add("in_kind_shop_memo", OracleDbType.Varchar2, 2000).Value = deliTip.kind_shop_memo;
            cmd.Parameters.Add("in_youtube_url", OracleDbType.Varchar2, 300).Value = deliTip.youtube_url;
            cmd.Parameters.Add("in_child_meal_yn", OracleDbType.Varchar2, 1).Value = deliTip.child_meal_yn;
            cmd.Parameters.Add("in_child_meal_cd", OracleDbType.Varchar2, 20).Value = deliTip.child_meal_cd;
            cmd.Parameters.Add("in_min_amt_pass", OracleDbType.Varchar2, 1).Value = deliTip.min_amt_pass;
            cmd.Parameters.Add("in_user_ucode", OracleDbType.Varchar2, 20).Value = deliTip.modUCode;
            cmd.Parameters.Add("in_user_name", OracleDbType.Varchar2, 20).Value = deliTip.modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/DeliTip/setSaleTime : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 배송정보 등록,수정,삭제, 순서변경
        /// </summary>
        /// <remarks>
        /// deli_notice_code 배송정보 pk <br/>
        /// title 제목 <br/>
        /// content 내용 <br/>
        /// </remarks>
        [HttpPut("setDeliNotice")]
        public async Task<ResultBasic> setDeliNotice(IEnumerable<DeliNoticePut> item, string shop_cd, string ucode, string uname)
        {
            string Rposition = "/DeliTip/setDeliNotice";
            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_DELI.SET_DELI_NOTICE",
            };
            List<string> deliNoticeCodes = new List<string>();
            List<string> titles = new List<string>();
            List<string> contents = new List<string>();

            foreach (var i in item)
            {
                deliNoticeCodes.Add(i.deli_notice_code == "" ? null : i.deli_notice_code);
                titles.Add(i.title);
                contents.Add(i.content);
            }

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;

            var arrPayGbn = cmd.Parameters.Add("in_deli_notice_code", OracleDbType.Int32);
            arrPayGbn.Direction = ParameterDirection.Input;
            arrPayGbn.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrPayGbn.Value = deliNoticeCodes.ToArray().Count() == 0 ? new string[1] { "-1" } : deliNoticeCodes.ToArray();
            arrPayGbn.Size = deliNoticeCodes.ToArray().Count() == 0 ? 0 : deliNoticeCodes.Count();
            arrPayGbn.ArrayBindSize = deliNoticeCodes.Select(_ => string.IsNullOrEmpty(_) ? 0 : _.Length).ToArray();
            arrPayGbn.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, deliNoticeCodes.Count()).ToArray();

            var arrAppPayGbn = cmd.Parameters.Add("in_title", OracleDbType.Varchar2, 200);
            arrAppPayGbn.Direction = ParameterDirection.Input;
            arrAppPayGbn.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrAppPayGbn.Value = titles.ToArray().Count() == 0 ? new string[1] { null } : titles.ToArray();
            arrAppPayGbn.Size = titles.ToArray().Count() == 0 ? 0 : titles.Count();
            arrAppPayGbn.ArrayBindSize = titles.Select(_ => _.Length).ToArray();
            arrAppPayGbn.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, titles.Count()).ToArray();

            var arrAble = cmd.Parameters.Add("in_content", OracleDbType.Varchar2, 2000);
            arrAble.Direction = ParameterDirection.Input;
            arrAble.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrAble.Value = contents.ToArray().Count() == 0 ? new string[1] { null } : contents.ToArray();
            arrAble.Size = contents.ToArray().Count() == 0 ? 0 : contents.Count();
            arrAble.ArrayBindSize = contents.Select(_ => _.Length).ToArray();
            arrAble.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, contents.Count()).ToArray();

            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("in_uname", OracleDbType.Varchar2, 200).Value = uname;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 가맹점 반품/교환, 교환 및 환불 불가 안내 수정
        /// </summary>
        /// <remarks>
        /// shopCd : 가맹점코드 <br/>
        /// exchange_notice : 교환안내 <br/>
        /// return_notice : 반품안내 <br/>
        /// reject_notice : 교환 및 환불 불가 안내 <br/>
        /// </remarks>
        [HttpPut("setERRNotice")]
        public async Task<IActionResult> setERRNotice(ERRNotice item)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            
            if(string.IsNullOrEmpty(item.shopCd) ||
               string.IsNullOrEmpty(item.modUCode) ||
               string.IsNullOrEmpty(item.modName))
            {
                Rcode = "99";
                Rmsg = "가맹점코드, 수정자코드, 수정자명은 필수입니다.";
                return Ok(new { code = Rcode, msg = Rmsg});
            }
               
            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", item.shopCd);
                param.Add("exchange_notice", item.exchange_notice);
                param.Add("return_notice", item.return_notice);
                param.Add("reject_notice", item.reject_notice);
                param.Add("ucode", item.modUCode);
                param.Add("uname", item.modName);

                string sql = @" update shop_info_add
                                set exchange_notice = :exchange_notice,
                                    return_notice = :return_notice,
                                    reject_notice = :reject_notice,
                                    mod_date = sysdate,
                                    mod_ucode = :ucode,
                                    mod_name = :uname
                                where shop_cd = :shop_cd
                ";

                db.Open();

               await db.ExecuteAsync(sql, param, commandType: CommandType.Text);



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion[가맹점 운영정보 관리]


        /// <summary>
        /// 배달도 대구로 여부 및 사장님 부담 배달비 조회
        /// </summary>
        [HttpGet("getDeliDgrYn/{shop_cd}")]
        public async Task<IActionResult> getDeliDgrYn(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object yn = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);

                string sql = @" select nvl(deli_dgr_yn,'N') as deli_dgr_yn,
                                       nvl(deli_dgr_amt,0) as deli_dgr_amt
                                from shop_info
                                where shop_cd = :shop_cd
                ";

                db.Open();

                yn = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = yn });
        }

        /// <summary>
        /// 배달도 대구로 설정 및 사장님 부담 배달비 책정
        /// </summary>
        [HttpPost("setDeliDgrYn/{shop_cd}")]
        public async Task<IActionResult> setDeliDgrYn(string shop_cd, string yn, string deli_dgr_amt, string ucode, string uname)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("yn", yn);
                param.Add("deli_dgr_amt", deli_dgr_amt);
                param.Add("ucode", ucode);
                param.Add("uname", uname);



                db.Open();

                var sql = @" update shop_info
                        set deli_dgr_yn = :yn,
                            deli_dgr_amt = :deli_dgr_amt,
                            mod_date = sysdate,
                            mod_ucode = :ucode,
                            mod_name = :uname
                        where shop_cd = :shop_cd
                    ";


                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

    }
}
