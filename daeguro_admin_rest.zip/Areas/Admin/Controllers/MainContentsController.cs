﻿using Dapper;
using ClosedXML.Excel;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Linq;
using System.Drawing;
using System.Drawing.Imaging;
using System.Net.Http;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [ApiController]
    [Route("/[controller]")]
    public class MainContentsController : ControllerBase
    {
        string nasPath = @"\\10.10.10.100\dgnas\Files";
        string contentsThumbPath = @"\\10.10.10.100\dgnas\Files\ContentsThumb";


        /// <summary>
        /// 메인 웹툰 콘텐츠 및 대표사이트 콘텐츠 목록 조회
        /// </summary>
        /// <remarks>
        /// cartegory_gbn : 카테고리 구분 (필수) (R: 대표사이트 노출용, A: 주문앱 노출용(웹툰)) <br/>
        /// disp_gbn : 게시 여부(Y/N/전체) <br/>
        /// keyword : 제목 검색 키워드
        /// </remarks>
        [HttpGet()]
        public async Task<IActionResult> Get(string cartegory_gbn, string disp_gbn, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = string.Empty;
            string RCount = string.Empty;
            string RTotalCount = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("cartegory_gbn", cartegory_gbn);
                param.Add("disp_gbn", disp_gbn);
                param.Add("keyword", "%" + keyword + "%");
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = $@" SELECT t2.*
                                  FROM (SELECT ROWNUM AS RNUM,
                                               t1.*
                                        FROM (select contents_cd,
                                                     contents_title,
                                                     disp_gbn,
                                                     disp_seq,
                                                     ins_date,
                                                     ins_ucode
                                            from main_contents
                                            where cartegory_gbn = :cartegory_gbn
                                            and disp_gbn like nvl(:disp_gbn,'%')
                                            and contents_title like :keyword
                                            order by ins_date desc) t1
                                WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                                WHERE (( :page - 1) * :row_count) < RNUM
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                sql = @"
                        select count(*)
                         from main_contents
                         where cartegory_gbn = :cartegory_gbn
                        ";

                RTotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);


                sql = @$"select count(*)
                         from main_contents
                         where cartegory_gbn = :cartegory_gbn
                         and disp_gbn like nvl(:disp_gbn,'%')
                         and contents_title like :keyword";

                RCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MainContents : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RTotalCount, count = RCount, data = Rdata });
        }


        /// <summary>
        /// 콘텐츠 상세조회
        /// </summary>
        [HttpGet("{contents_cd}")]
        public async Task<IActionResult> GetDetail(int contents_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("contents_cd", contents_cd);

                string sql = $@" select cartegory_gbn,
                                       contents_cd,
                                       contents_title,
                                       disp_gbn,
                                       main_url,
                                       url_title, -- 링크 타이틀
                                       emoji_code, -- 웹툰용
                                       thumbnail_url, -- 대표사이트용
                                       get_thumbnail_url, -- 대표사이트용
                                       ins_ucode,
                                       ins_date,
                                       mod_ucode,
                                       mod_date
                                from main_contents
                                where contents_cd = :contents_cd
                ";

                db.Open();

                Rdata = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MainContents/{contents_cd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 컨텐츠 등록
        /// </summary>
        /// <remarks>
        /// 컨텐츠 등록과 수정에 동일 모델을 사용하여 불필요한 파라미터가 섞여 있습니다(MainContents) <br/>
        /// <br/>
        /// 필요 파라미터 <br/>
        /// cartegory_gbn : 카테고리 구분 (R: 대표사이트 노출용, A: 주문앱 노출용[웹툰]) <br/>
        /// contents_title : 컨텐츠 제목 <br/>
        /// disp_gbn : 게시 여부(Y/N) <br/>
        /// main_url : 컨텐츠 메인 URL <br/>
        /// url_title : 링크 타이틀(웹툰용) <br/>
        /// emoji_code : 이모지 코드(웹툰용) <br/>
        /// thumbnail_url : 썸네일 이미지 URL(대표사이트 노출용) <br/>
        /// *thumbnail_url은 비우거나 정상 이미지 url만 기입 가능 <br/>
        /// ins_ucode
        /// </remarks>
        [HttpPost("setContents")]
        public async Task<IActionResult> setContents(MainContents mainContents)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            
            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("cartegory_gbn", mainContents.cartegory_gbn);
                param.Add("contents_title", mainContents.contents_title);
                param.Add("disp_gbn", mainContents.disp_gbn);
                param.Add("main_url", mainContents.main_url);
                param.Add("url_title", mainContents.url_title);
                param.Add("emoji_code", mainContents.emoji_code); // 웹툰용
                param.Add("thumbnail_url", mainContents.thumbnail_url); // 대표사이트용
                param.Add("ins_ucode", mainContents.ins_ucode);

                db.Open();

                //썸네일 url 값이 있는지 체크
                //있으면 이미지 저장에 성공해야 생성가능
                string get_thumbnail_url = string.Empty;

                if (!string.IsNullOrEmpty(mainContents.thumbnail_url))
                {
                    string preSql = $@"
                                    select last_number
                                    from user_sequences
                                    where sequence_name = 'MAIN_CONTENTS_SEQ'
                                    ";
                    mainContents.contents_cd = await db.ExecuteScalarAsync<string>(preSql, commandType: CommandType.Text);

                    Uri uri = new Uri(mainContents.thumbnail_url);

                    get_thumbnail_url = await DownloadImageAsync(mainContents.contents_cd, uri);
                    if (get_thumbnail_url.Equals("0"))
                    {
                        return Ok(new { code = "99", msg = "썸네일 이미지 저장에 실패하였습니다" });
                    }
                }

                param.Add("get_thumbnail_url", get_thumbnail_url);

                string sql = @$"
                                    SELECT NVL(MAX(disp_seq), 0) + 1
                                        FROM main_contents
                                        WHERE cartegory_gbn = :cartegory_gbn
                                    ";

                int seq = await db.ExecuteScalarAsync<int>(sql, param);

                param.Add("disp_seq", seq);

                sql = @"
                        insert into main_contents(cartegory_gbn, 
                                                    contents_title, 
                                                    disp_gbn, 
                                                    disp_seq, 
                                                    main_url, 
                                                    url_title, 
                                                    emoji_code, 
                                                    thumbnail_url,
                                                    get_thumbnail_url,
                                                    ins_ucode,
                                                    ins_date)
                        values (:cartegory_gbn, 
                                :contents_title, 
                                :disp_gbn, 
                                :disp_seq, 
                                :main_url, 
                                :url_title, 
                                :emoji_code, 
                                :thumbnail_url,
                                :get_thumbnail_url,
                                :ins_ucode,
                                sysdate)
                        ";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MainContents/setContents : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 컨텐츠 수정
        /// </summary>
        /// <remarks>
        /// 컨텐츠 등록과 수정에 동일 모델을 사용하여 불필요한 파라미터가 섞여 있습니다(MainContents) <br/>
        /// <br/>
        /// 필요 파라미터 <br/>
        /// contents_cd : 메인 컨텐츠 코드 <br/>
        /// contents_title : 컨텐츠 제목 <br/>
        /// disp_gbn : 게시 여부(Y/N) <br/>
        /// main_url : 컨텐츠 메인 URL <br/>
        /// emoji_code : 이모지 코드(웹툰용) <br/>
        /// thumbnail_url : 썸네일 이미지 URL(대표사이트 노출용) <br/>
        /// *thumbnail_url은 비우거나 정상 이미지 url만 기입 가능 <br/>
        /// mod_ucode
        /// </remarks>
        [HttpPut("updateContents")]
        public async Task<IActionResult> updateContents(MainContents mainContents)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("contents_cd", mainContents.contents_cd);
                param.Add("contents_title", mainContents.contents_title);
                param.Add("disp_gbn", mainContents.disp_gbn);
                param.Add("main_url", mainContents.main_url);
                param.Add("url_title", mainContents.url_title);
                param.Add("emoji_code", mainContents.emoji_code); // 웹툰용
                param.Add("thumbnail_url", mainContents.thumbnail_url); // 대표사이트용
                param.Add("mod_ucode", mainContents.mod_ucode);

                //썸네일 url 수정여부 체크
                string sql = @"
                                select count(1)
                                from main_contents
                                where contents_cd = :contents_cd
                                and nvl(thumbnail_url,' ') = nvl(:thumbnail_url,' ')
                                ";

                int num = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

                string get_thumbnail_url = string.Empty;

                //썸네일 url이 기존과 다르면서 빈값이 아닐 경우 이미지 다운로드
                //실패시 수정도 실패
                if (num == 0 && !string.IsNullOrEmpty(mainContents.thumbnail_url))
                {
                    Uri uri = new Uri(mainContents.thumbnail_url);

                    get_thumbnail_url = await DownloadImageAsync(mainContents.contents_cd, uri);
                    if (get_thumbnail_url.Equals("0"))
                    {
                        return Ok(new { code = "99", msg = "썸네일 이미지 저장에 실패하였습니다" });
                    }
                }

                //num값이 1일 경우 썸네일 url이 변하지 않았으므로 기존 get_thumbnail_url 유지
                param.Add("num", num);
                param.Add("get_thumbnail_url", get_thumbnail_url);

                sql = @"
                            update main_contents
                            set contents_title = :contents_title,
                                disp_gbn = :disp_gbn,
                                main_url = :main_url,
                                url_title = :url_title,
                                emoji_code = :emoji_code,
                                thumbnail_url = :thumbnail_url,
                                get_thumbnail_url = case when :num = 0 then :get_thumbnail_url else get_thumbnail_url end,
                                mod_ucode = :mod_ucode,
                                mod_date = sysdate
                            where contents_cd = :contents_cd
                                ";

                db.Open();
                await db.ExecuteAsync(sql, param, commandType: CommandType.Text); 
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MainContents/updateContents : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 순서변경
        /// </summary>
        [HttpPost("updateSort")]
        public async Task<IActionResult> updateSort(IEnumerable<string> contents_cd)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            string Rcode;
            string Rmsg;
            int i = contents_cd.Count();

            try
            {
                db.Open();
                foreach (string cd in contents_cd)
                {
                    DynamicParameters param = new DynamicParameters();
                    param.Add("cd", cd);
                    param.Add("seq", i);

                    string sql = @$"
                             update main_contents
                                set disp_seq = :seq
                              where contents_cd = :cd                           
                            ";

                    await db.ExecuteAsync(sql, param);

                    i--;
                }


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MainContents/updateSort : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 콘텐츠 순서조회
        /// </summary>
        /// <remarks>
        /// 게시여부가 'Y'인 항목만 조회 <br/>
        /// cartegory_gbn : 카테고리 구분 (R: 대표사이트 노출용, A: 주문앱 노출용[웹툰])
        /// </remarks>
        [HttpGet("getSortList")]
        public async Task<IActionResult> getSortList(string cartegory_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("cartegory_gbn", cartegory_gbn);

                string sql = @$"
                                  SELECT contents_cd,
                                         contents_title
                                    FROM main_contents
                                    WHERE disp_gbn = 'Y'
                                    AND cartegory_gbn = :cartegory_gbn
                                   ORDER BY disp_seq desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }




        /// <summary>
        /// 메인 웹툰 하위 에피소드 목록 조회
        /// </summary>
        /// <remarks>
        /// seq: PK값 <br/>
        /// sort_seq: 정렬순서(클수록 상단) <br/>
        /// disp_gbn: 게시여부(Y,N) <br/>
        /// hit: 조회수
        /// </remarks>
        [HttpGet("getSub")]
        public async Task<IActionResult> GetSub(string contents_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = string.Empty;
            string RCount = string.Empty;
            string RTotalCount = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("contents_cd", contents_cd);
                //param.Add("page", page);
                //param.Add("row_count", rows);

                string sql = $@" select  seq,
                                        sort_seq,
                                        ep_title,
                                        disp_gbn,
                                        hit,
                                        ins_date,
                                        ins_ucode
                                 from lower_contents
                                 where contents_cd = :contents_cd
                                 order by sort_seq desc
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                sql = @"";

                //RTotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);


                sql = @$"select count(*)
                         from lower_contents
                         where contents_cd = :contents_cd";

                RCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MainContents/getSub : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = Rdata });
        }

        /// <summary>
        /// 에피소드 상세조회
        /// </summary>
        [HttpGet("getSub/{seq}")]
        public async Task<IActionResult> GetSubDetail(string seq)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("seq", seq);

                string sql = $@" select seq,
                                        sort_seq,
                                        ep_title,
                                        disp_gbn,
                                        hit,
                                        contents_url,
                                        thumbnail_url,
                                        ins_date,
                                        ins_ucode,
                                        mod_date,
                                        mod_ucode
                                 from lower_contents
                                 where seq = :seq
                ";

                db.Open();

                Rdata = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MainContents/getSub/{contents_cd}/{episode} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 에피소드 등록
        /// </summary>
        /// <remarks>
        /// 에피소드 등록과 수정에 동일 모델을 사용하여 불필요한 파라미터가 섞여 있습니다(SubContents) <br/>
        /// seq는 시퀸스값 자동생성, sort_seq는 max + 1로 자동 생성
        /// <br/>
        /// 필요 파라미터 <br/>
        /// contents_cd : 컨텐츠 코드 <br/>
        /// ep_title : 하위 컨텐츠 제목 <br/>
        /// disp_gbn : 게시 여부(Y/N) <br/>
        /// contents_url : 컨텐츠 URL <br/>
        /// thumbnail_url : 썸네일 이미지 URL <br/>
        /// ins_ucode
        /// </remarks>
        [HttpPost("setSubContents")]
        public async Task<IActionResult> setSubContents(SubContents subContents)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("contents_cd", subContents.contents_cd);
                

                string sql = @$"
                                    SELECT NVL(MAX(sort_seq), 0) + 1
                                        FROM lower_contents
                                        WHERE contents_cd = :contents_cd
                                    ";

                int seq = await db.ExecuteScalarAsync<int>(sql, param);

                param.Add("sort_seq", seq);
                param.Add("ep_title", subContents.ep_title);
                param.Add("disp_gbn", subContents.disp_gbn);
                param.Add("contents_url", subContents.contents_url);
                param.Add("thumbnail_url", subContents.thumbnail_url);
                param.Add("ins_ucode", subContents.ins_ucode);

                sql = @"
                                insert into lower_contents(contents_cd, 
                                                          sort_seq, 
                                                          ep_title,
                                                          disp_gbn, 
                                                          hit, 
                                                          contents_url, 
                                                          thumbnail_url,
                                                          ins_ucode,
                                                          ins_date)
                                values (:contents_cd, 
                                        :sort_seq, 
                                        :ep_title,
                                        :disp_gbn, 
                                        0, 
                                        :contents_url, 
                                        :thumbnail_url,
                                        :ins_ucode,
                                        sysdate)
                                ";

                db.Open();
                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MainContents/setSubContents : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 에피소드 수정
        /// </summary>
        /// <remarks>
        /// 에피소드 등록과 수정에 동일 모델을 사용하여 불필요한 파라미터가 섞여 있습니다(SubContents) <br/>
        /// <br/>
        /// 필요 파라미터 <br/>
        /// seq : PK값 <br/>
        /// <br/>
        /// 변경항목<br/>
        /// ep_title : 하위 컨텐츠 제목 <br/>
        /// disp_gbn : 게시 여부(Y/N) <br/>
        /// contents_url : 컨텐츠 URL <br/>
        /// thumbnail_url : 썸네일 이미지 URL <br/>
        /// mod_ucode
        /// </remarks>
        [HttpPut("updateSubContents")]
        public async Task<IActionResult> updateSubContents(SubContents subContents)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("seq", subContents.seq);
                param.Add("contents_cd", subContents.contents_cd);
                param.Add("ep_title", subContents.ep_title);
                param.Add("disp_gbn", subContents.disp_gbn);
                param.Add("contents_url", subContents.contents_url);
                param.Add("thumbnail_url", subContents.thumbnail_url);
                param.Add("mod_ucode", subContents.mod_ucode);

                string sql = @"
                                update lower_contents
                                set ep_title = :ep_title,
                                    disp_gbn = :disp_gbn,
                                    contents_url = :contents_url,
                                    thumbnail_url = :thumbnail_url,
                                    mod_ucode = :mod_ucode,
                                    mod_date = sysdate
                                where seq = :seq
                                ";

                db.Open();
                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MainContents/updateSubContents : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// url로 이미지 다운로드(이미지 형식 자동식별)
        /// </summary>
        /// <remarks>
        /// fileName : 파일명(ex img.jpg의 경우 img만 기입)
        /// </remarks>
        [HttpPost("SaveImage")]
        public async Task<string> DownloadImageAsync(string fileName, Uri uri)
        {
            string getUrl = string.Empty;

            try
            {
                using var httpClient = new HttpClient();

                // Get the file extension
                var uriWithoutQuery = uri.GetLeftPart(UriPartial.Path);
                var fileExtension = Path.GetExtension(uriWithoutQuery);

                getUrl = "https://image.daeguro.co.kr:40443/contentsthumb/" + fileName + fileExtension;

                using (new ConnectToSharedFolder(nasPath))
                {
                    // Create file path and ensure directory exists
                    var path = Path.Combine(contentsThumbPath, $"{fileName}{fileExtension}");

                    if (Directory.Exists(contentsThumbPath) == false)
                    {
                        Directory.CreateDirectory(contentsThumbPath);
                    }

                    // Download the image and write to the file
                    var imageBytes = await httpClient.GetByteArrayAsync(uri);
                    await System.IO.File.WriteAllBytesAsync(path, imageBytes);
                }
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MainContents : SaveImage", $"Error Msg : {ex.Message}");
                return "0";
            }
            return getUrl;
        }

    }
}
