﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;


namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class RestErrorController : ControllerBase
    {
        [HttpPost]
        public async Task<IActionResult> Post(string div, string position, string msg)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            
            DynamicParameters param = new DynamicParameters();
            param.Add("div", div);
            param.Add("position", position);
            param.Add("msg", msg);

            try
            {
                db.Open();
                await db.ExecuteAsync("INSERT INTO REST_ERROR(DIV, POSITION, MSG, INSERT_TIME) VALUES (:div, :position, :msg, SYSDATE)", param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }



            return Ok(new { code = Rcode, msg = Rmsg });
        }

        //[HttpPost("Dapper2")]
        //public async Task<IActionResult> PostDapper2(string div, string position, string msg)
        //{
        //    string Rmsg = string.Empty;

        //    Stopwatch stopWatch = new Stopwatch();

        //    stopWatch.Start();

        //    using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
        //    db.Open();
        //    DynamicParameters param = new DynamicParameters();
        //    param.Add("div", div);
        //    param.Add("position", position);
        //    param.Add("msg", msg);
        //    await db.ExecuteAsync("INSERT INTO REST_ERROR(DIV, POSITION, MSG, INSERT_TIME) VALUES (:div, :position, :msg, SYSDATE)", param);

        //    stopWatch.Stop();

        //    string Rcode = stopWatch.ElapsedMilliseconds.ToString();


        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}


        [HttpPut("/{seq}")]
        public async Task<IActionResult> Put(string seq, string div, string position, string msg)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("div", div);
            param.Add("position", position);
            param.Add("msg", msg);
            param.Add("seq", seq);

            try
            {

                db.Open();
                await db.ExecuteAsync($"UPDATE REST_ERROR SET DIV = :div, POSITION = :position, MSG = :msg WHERE SEQ = :seq", param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 에러로그 목록조회
        /// </summary>
        /// <remarks>
        /// divKey 키원드 검색구분 (1: POSITION, 2: MSG) <br/>
        /// pos_show POS로그 활성화 여부 (0: 활성화, 1: 비활성화)
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string divKey, string keyword, string pos_show, string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            string RtotalCount = string.Empty;

            string sDiv = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            
            DynamicParameters param = new DynamicParameters();
            param.Add("divKey", divKey);
            param.Add("keyword", "%" + keyword + "%");
            param.Add("pos_show", pos_show);
            param.Add("date_begin", date_begin);
            param.Add("date_end", date_end);
            param.Add("page", page);
            param.Add("row_count", rows);

            if (String.IsNullOrEmpty(keyword) == false)
            {
                
                switch (divKey)
                {
                    case "1": sDiv = @"AND UPPER(POSITION) LIKE UPPER(:keyword)"; break;
                    case "2": sDiv = @"AND UPPER(MSG) LIKE UPPER(:keyword)"; break;
                }

            }

            try
            {

                db.Open();

                string sql = @$"
                                SELECT COUNT(*)
                                FROM REST_ERROR
                            ";
                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

               
                sql = @$"
                            SELECT COUNT(*)
                            FROM REST_ERROR
                            WHERE TO_CHAR(INSERT_TIME,'YYYYMMDD') BETWEEN :date_begin AND :date_end
                            {sDiv}
                            and msg not like case when :pos_show = '1' then '[POS 가맹점%' -- pos_show 1 : pos기록 비활성화
                                                  when :pos_show = '0' then ' ' end     -- pos_show 0 : pos기록 활성화
                        ";
                Rcount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);


                sql = @$"
                            SELECT T2.SEQ,
                                   DECODE(T2.DIV, '0', '관리앱', '1', '시스템', '2', '외부앱', '3', '사장님사이트') AS DIV,
                                   T2.POSITION,
                                   T2.MSG,
                                   T2.INSERT_TIME
                              FROM (SELECT ROWNUM AS RNUM,
                                           T1.*
                                      FROM (SELECT *
                                              FROM REST_ERROR
                                              WHERE TO_CHAR(INSERT_TIME,'YYYYMMDD') BETWEEN :date_begin AND :date_end
                                              {sDiv}
                                              and msg not like case when :pos_show = '1' then '[POS 가맹점%' -- pos_show 1 : pos기록 비활성화
                                                                    when :pos_show = '0' then ' ' end     -- pos_show 0 : pos기록 활성화
                                             ORDER BY SEQ DESC) T1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) T2
                             WHERE (( :page - 1) * :row_count) < RNUM
                        ";


                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, count = Rcount, data = items });
        }


        [HttpGet("{seq}")]
        public async Task<IActionResult> Get(string seq)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            string sql = @$"
                            SELECT SEQ,
                                   DECODE(DIV, '0', '관리앱', '1', '시스템', '2', '외부앱', '3', '사장님사이트') AS DIV,
                                   POSITION,
                                   MSG,
                                   INSERT_TIME
                              FROM REST_ERROR
                             WHERE SEQ = { seq }
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        [HttpDelete("/{seq}")]
        public async Task<IActionResult> Delete(string seq)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("seq", seq);

            try
            {

                db.Open();
                await db.ExecuteAsync($"DELETE REST_ERROR WHERE SEQ = :seq", param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        //[HttpPost("PS")]
        //public async Task<IActionResult> PostPS(string div, string position, string msg)
        //{
        //    string Rmsg = string.Empty;

        //    Stopwatch stopWatch = new Stopwatch();

        //    stopWatch.Start();

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
        //    OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_SHOP.ADD_REST_ERROR",
        //    };


        //    cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
        //    cmd.Parameters.Add("in_position", OracleDbType.Varchar2, 100).Value = position;
        //    cmd.Parameters.Add("in_msg", OracleDbType.Varchar2, 2000).Value = msg;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();
        //        await cmd.ExecuteNonQueryAsync();

        //        //Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        //Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        await conn.CloseAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        Utils.SaveError("/admin/Agent : Post", ex.Message);
        //    }

        //    stopWatch.Stop();

        //    string Rcode = stopWatch.ElapsedMilliseconds.ToString();

        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}


        //[HttpPost("Cmd")]
        //public async Task<IActionResult> PostCmd(string div, string position, string msg)
        //{
        //    string Rmsg = string.Empty;

        //    Stopwatch stopWatch = new Stopwatch();

        //    stopWatch.Start();

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
        //    OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.Text,
        //        CommandText = "INSERT INTO REST_ERROR(DIV, POSITION, MSG, INSERT_TIME) VALUES (:div, :position, :msg, SYSDATE)",
        //    };


        //    cmd.Parameters.Add("div", OracleDbType.Varchar2, 1).Value = div;
        //    cmd.Parameters.Add("position", OracleDbType.Varchar2, 100).Value = position;
        //    cmd.Parameters.Add("msg", OracleDbType.Varchar2, 2000).Value = msg;


        //    try
        //    {
        //        await conn.OpenAsync();
        //        await cmd.ExecuteNonQueryAsync();

        //        //Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        //Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        await conn.CloseAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/Agent : Post", ex.Message);
        //    }

        //    stopWatch.Stop();

        //    string Rcode = stopWatch.ElapsedMilliseconds.ToString();

        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}


        //[HttpPost("insertMenuGroupCD")]
        //public async Task<IActionResult> insertMenuGroupCD(string cccode, string shop_cd, string menu_group_name, string use_y, string insert_date, string insert_name)
        //{
        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.Text,
        //        CommandText = "SELECT SF_INSERT_MENU_GROUPCD(:in_cccode, :in_shop_cd, :in_menu_group_name, :in_use_yn, :in_insert_date, :in_insert_name) FROM DUAL",
        //    };

        //    cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = cccode;
        //    cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
        //    cmd.Parameters.Add("in_menu_group_name", OracleDbType.Varchar2, 50).Value = menu_group_name;
        //    cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 1).Value = use_y;
        //    cmd.Parameters.Add("in_insert_date", OracleDbType.Varchar2, 8).Value = insert_date;
        //    cmd.Parameters.Add("in_insert_name", OracleDbType.Varchar2, 30).Value = insert_name;


        //    string Rcode, Rmsg, Rdata;

        //    try
        //    {
        //        await conn.OpenAsync();

        //        // 함수 값 반환은 여기서 한다 ★★★
        //        var re = await cmd.ExecuteScalarAsync();

        //        await conn.CloseAsync();

        //        Rcode = "00";
        //        Rmsg = "성공";
        //        Rdata = re.ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/Shop : Get", ex.Message);

        //        Rcode = "01";
        //        Rmsg = ex.Message;
        //        Rdata = string.Empty;
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        //}


        //[HttpPost("insertOptionGroupCD")]
        //public async Task<IActionResult> insertOptionGroupCD(string cccode, string shop_cd, string option_group_name, string use_y, string insert_date, string insert_name)
        //{
        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.Text,
        //        CommandText = "SELECT SF_INSERT_MENU_OPTION_GROUPCD(:in_cccode, :in_shop_cd, :in_option_group_name, :in_use_yn, :in_insert_date, :in_insert_name) FROM DUAL",
        //    };

        //    cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = cccode;
        //    cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
        //    cmd.Parameters.Add("in_option_group_name", OracleDbType.Varchar2, 50).Value = option_group_name;
        //    cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 1).Value = use_y;
        //    cmd.Parameters.Add("in_insert_date", OracleDbType.Varchar2, 8).Value = insert_date;
        //    cmd.Parameters.Add("in_insert_name", OracleDbType.Varchar2, 30).Value = insert_name;


        //    string Rcode, Rmsg, Rdata;

        //    try
        //    {
        //        await conn.OpenAsync();

        //        // 함수 값 반환은 여기서 한다 ★★★
        //        var re = await cmd.ExecuteScalarAsync();

        //        await conn.CloseAsync();

        //        Rcode = "00";
        //        Rmsg = "성공";
        //        Rdata = re.ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/Shop : Get", ex.Message);

        //        Rcode = "01";
        //        Rmsg = ex.Message;
        //        Rdata = string.Empty;
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        //}
    }
}
