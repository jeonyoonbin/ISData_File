﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ShopInfoController : ControllerBase
    {
        string productPath = @"\\10.10.10.100\dgnas\Files\ProductImage";
        string nasPath = @"\\10.10.10.100\dgnas\Files";

        #region[매장정보 관리]
        /// <summary>
        /// 가맹점 매장정보 조회
        /// </summary>
        /// <remarks>
        /// deliTypeGbn 배달타입 구분(I: 실시간 배송, R: 예약 배송) <br/>
        /// serviceGbn : 서비스 구분(0: 주문, 1: 특별관, 2: 꽃배달) <br/>
        /// trad_yn : 시장여부(Y/N) <br/>
        /// bundle_yn : 장보기여부(Y/N) / 시장이 아닐경우 null <br/>
        /// trad_desc : 시장설명 <br/>
        /// bundle_login_id : 장보기 로그인ID <br/>
        /// m_shop_cd : 시장코드 <br/>
        /// trad_name : 시장이름 <br/>
        /// </remarks>
        [HttpGet("{shop_cd}")]
        public async Task<IActionResult> Get(string shop_cd, string ucode)
        {
            string Rposition = "/ShopInfo/{shop_cd} : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.GET_SHOP_INFO",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            ShopInfo shopInfo = new ShopInfo();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                shopInfo.ccCode = rd["CCCODE"].ToString();
                shopInfo.serviceGbn = rd["SERVICE_GBN"].ToString();
                shopInfo.shopCd = rd["SHOP_CD"].ToString();
                shopInfo.telNo = rd["TELNO"].ToString();
                shopInfo.itemCd1 = rd["ITEM_CD"].ToString();
                shopInfo.itemCd2 = rd["ITEM_CD2"].ToString();
                shopInfo.itemCd3 = rd["ITEM_CD3"].ToString();
                shopInfo.appMinAmt = rd["APP_MIN_AMT"].ToString();
                shopInfo.shopType = rd["SHOP_TYPE"].ToString();
                shopInfo.shopId = rd["SHOP_ID"].ToString();
                shopInfo.shopPass = rd["SHOP_PASS"].ToString();
                shopInfo.shopImg = rd["SHOP_IMAGE_YN"].ToString();
                shopInfo.bussImg = rd["BUSS_IMAGE_YN"].ToString();
                shopInfo.idcardImg = rd["IDCARD_IMAGE_YN"].ToString();
                shopInfo.bankImg = rd["BANK_IMAGE_YN"].ToString();
                shopInfo.reserveYn = rd["RESERVE_YN"].ToString();
                shopInfo.useGbn = rd["USE_GBN"].ToString();
                shopInfo.deliTypeGbn = rd["DELI_TYPE_GBN"].ToString();
                shopInfo.multi_shop_yn = rd["MULTI_SHOP_YN"].ToString();
                shopInfo.multishop_cd = rd["MULTISHOP_CD"].ToString();
                shopInfo.representative_yn = rd["REPRESENTATIVE_YN"].ToString();
                shopInfo.rep_shop_cd = rd["REP_SHOP_CD"].ToString();
                shopInfo.multishop_login_id = rd["MULTISHOP_LOGIN_ID"].ToString();
                shopInfo.rep_shop_name = rd["REP_SHOP_NAME"].ToString();
                shopInfo.trad_yn = rd["trad_yn"].ToString();
                shopInfo.bundle_yn = rd["bundle_yn"].ToString();
                shopInfo.trad_desc = rd["trad_desc"].ToString();
                shopInfo.bundle_login_id = rd["BUNDLE_LOGIN_ID"].ToString();
                shopInfo.m_shop_cd = rd["M_SHOP_CD"].ToString();
                shopInfo.trad_name = rd["TRAD_NAME"].ToString();


                await rd.CloseAsync();
                await conn.CloseAsync();

                //조회 로그 기록
                await Utils.setPrivacyLog(ucode, "5", "10", shopInfo.shopCd + " - 매장전화번호, 사업자등록증 이미지, 영업신고증 이미지, 통장사본 이미지", Rposition);

                // 첨부파일 유무 체크
                //using (new ConnectToSharedFolder(nasPath))
                //{
                //    string path = $@"{productPath}\{shopInfo.ccCode}\{shopInfo.shopCd}\";

                //    if (System.IO.File.Exists(path + "buss.jpg"))
                //    {
                //        shopInfo.bussImg = "Y";
                //    }
                //    else
                //    {
                //        shopInfo.bussImg = "N";
                //    }

                //    if (System.IO.File.Exists(path + "idcard.jpg"))
                //    {
                //        shopInfo.idcardImg = "Y";
                //    }
                //    else
                //    {
                //        shopInfo.idcardImg = "N";
                //    }

                //    if (System.IO.File.Exists(path + "bank.jpg"))
                //    {
                //        shopInfo.bankImg = "Y";
                //    }
                //    else
                //    {
                //        shopInfo.bankImg = "N";
                //    }
                //}
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = shopInfo });
        }

        private async Task<ShopInfoPut> getShopInfo(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.GET_SHOP_INFO",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            ShopInfoPut shopInfo = new ShopInfoPut();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                shopInfo.ccCode = rd["CCCODE"].ToString();
                shopInfo.serviceGbn = rd["SERVICE_GBN"].ToString();
                shopInfo.shopCd = rd["SHOP_CD"].ToString();
                shopInfo.telNo = rd["TELNO"].ToString();
                shopInfo.itemCd1 = rd["ITEM_CD"].ToString();
                shopInfo.itemCd2 = rd["ITEM_CD2"].ToString();
                shopInfo.itemCd3 = rd["ITEM_CD3"].ToString();
                shopInfo.appMinAmt = rd["APP_MIN_AMT"].ToString();
                shopInfo.shopType = rd["SHOP_TYPE"].ToString();
                shopInfo.shopId = rd["SHOP_ID"].ToString();
                shopInfo.shopPass = rd["SHOP_PASS"].ToString();
                shopInfo.shopImg = rd["SHOP_IMAGE_YN"].ToString();
                shopInfo.bussImg = rd["BUSS_IMAGE_YN"].ToString();
                shopInfo.idcardImg = rd["IDCARD_IMAGE_YN"].ToString();
                shopInfo.bankImg = rd["BANK_IMAGE_YN"].ToString();
                shopInfo.reserveYn = rd["RESERVE_YN"].ToString();
                shopInfo.useGbn = rd["USE_GBN"].ToString();
                shopInfo.deliTypeGbn = rd["DELI_TYPE_GBN"].ToString();
                shopInfo.multi_shop_yn = rd["MULTI_SHOP_YN"].ToString();
                shopInfo.multishop_cd = rd["MULTISHOP_CD"].ToString();
                //shopInfo.trad_yn = rd["trad_yn"].ToString();
                shopInfo.bundle_yn = rd["bundle_yn"].ToString();
                shopInfo.trad_desc = rd["trad_desc"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo/getShopInfo : Get", ex.Message);
            }

            return shopInfo;
        }

        private async Task<ResultShopInfo> updateShopInfo(ShopInfoPut shopInfo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RjobGbn = string.Empty;
            string RloginId = string.Empty;
            string RjobGbn2 = string.Empty;
            string RloginId2 = string.Empty;
            string RapiComCode = string.Empty;

            string trad_yn = string.Empty;

            //서비스 전통시장, 업종1 장보기이면 trad_yn = 'Y'
            if (shopInfo.serviceGbn == "4" && shopInfo.itemCd1 == "1036")
            {
                trad_yn = "Y";
                shopInfo.itemCd2 = null;
                shopInfo.itemCd3 = null;
            }
            else
            {
                trad_yn = "N"; // 테이블 제거로 하위데이터 자동 null
                //shopInfo.bundle_yn = null;
                //shopInfo.trad_desc = null;
            }

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.UPDATE_SHOP_INFO",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shopInfo.shopCd;
            cmd.Parameters.Add("in_telno", OracleDbType.Varchar2, 20).Value = shopInfo.telNo;
            cmd.Parameters.Add("in_service_gbn", OracleDbType.Varchar2, 1).Value = shopInfo.serviceGbn;
            cmd.Parameters.Add("in_item_cd_1", OracleDbType.Varchar2, 4).Value = shopInfo.itemCd1;
            cmd.Parameters.Add("in_item_cd_2", OracleDbType.Varchar2, 4).Value = shopInfo.itemCd2;
            cmd.Parameters.Add("in_item_cd_3", OracleDbType.Varchar2, 4).Value = shopInfo.itemCd3;
            cmd.Parameters.Add("in_app_min_amt", OracleDbType.Int32).Value = shopInfo.appMinAmt;
            cmd.Parameters.Add("in_shop_type", OracleDbType.Varchar2, 10).Value = shopInfo.shopType;
            cmd.Parameters.Add("in_reserve_yn", OracleDbType.Varchar2, 10).Value = shopInfo.reserveYn;
            cmd.Parameters.Add("in_deli_type_gbn", OracleDbType.Varchar2, 1).Value = shopInfo.deliTypeGbn;
            cmd.Parameters.Add("in_multi_shop_yn", OracleDbType.Varchar2, 1).Value = shopInfo.multi_shop_yn;
            cmd.Parameters.Add("in_trad_yn", OracleDbType.Varchar2, 1).Value = trad_yn;
            cmd.Parameters.Add("in_bundle_yn", OracleDbType.Varchar2, 1).Value = shopInfo.bundle_yn;
            cmd.Parameters.Add("in_trad_desc", OracleDbType.Varchar2, 4000).Value = shopInfo.trad_desc;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = shopInfo.modUCode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 50).Value = shopInfo.modName;
            cmd.Parameters.Add("out_job_gbn", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_login_id", OracleDbType.Varchar2, 50).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_job_gbn2", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_login_id2", OracleDbType.Varchar2, 50).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_api_com_code", OracleDbType.Varchar2, 30).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;


            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                RjobGbn = cmd.Parameters["out_job_gbn"].Value.ToString();
                RloginId = cmd.Parameters["out_login_id"].Value.ToString();
                RjobGbn2 = cmd.Parameters["out_job_gbn2"].Value.ToString();
                RloginId2 = cmd.Parameters["out_login_id2"].Value.ToString();
                RapiComCode = cmd.Parameters["out_api_com_code"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo/shop_cd : Put", ex.Message);
            }

            ResultShopInfo result = new ResultShopInfo();
            result.code = Rcode;
            result.msg = Rmsg;
            result.jobGbn = RjobGbn;
            result.loginId = RloginId;
            result.jobGbn2 = RjobGbn2;
            result.loginId2 = RloginId2;
            result.apiComCode = RapiComCode;

            return result;
        }

        /// <summary>
        /// 가맹점 매장정보 수정
        /// </summary>
        /// <remarks>
        /// deliTypeGbn 배달타입 구분(I: 실시간 배송, R: 예약 배송) <br/>
        /// serviceGbn : 서비스 구분(0: 주문, 1: 특별관, 2: 꽃배달) <br/>
        /// multi_shop_yn : 멀티샵여부(Y/N) <br/>
        ///  *multi_shop_yn : Y -> N 수정시 하위 멀티샵 전체 제거처리 <br/>
        /// multishop_cd : 멀티샵코드(하위가맹점 수정시 사용) <br/>
        ///  *multi_shop_yn : N -> Y 수정시 자동 Y전환 <br/>
        /// representative_yn : 대표가맹점여부(수정시 미사용) <br/>
        /// rep_shop_cd : 대표가맹점코드(수정시 미사용) <br/>
        /// multishop_login_id : 멀티샵 로그인 id(수정시 미사용) <br/>
        /// rep_shop_name : 대표가맹점명(수정시 미사용) <br/>
        /// trad_yn : 시장여부(Y/N) <br/>
        /// * 내부처리 : 서비스 전통시장, 업종1 장보기이면 trad_yn = 'Y' <br/>
        ///  *trad_yn : Y -> N 수정시 하위 멀티샵 전체 제거처리 <br/>
        /// bundle_yn : 장보기여부(Y/N) / 시장이 아닐경우 null <br/>
        ///  * 장보기일때만 멀티샵 연동처리 <br/>
        /// trad_desc : 시장설명 <br/>
        /// </remarks>
        [HttpPut]
        public async Task<IActionResult> Put(ShopInfoPut shop)
        {
            ResultShopInfo result = new ResultShopInfo();

            string err_msg = "/";

            try
            {
                MallUser mallUserF = await MallController.getShopInfoForMall(shop.shopCd); // 폐쇄몰 연동용 데이터 조회 rest(약관동의가 되어있지 않으면  user_id에 N 리턴)

                ShopInfoPut shopInfoF = new ShopInfoPut();

                // 가맹점 연동 실패시 롤백하기 위한 정보(대구로몰,POS멀티샵)
                shopInfoF = await getShopInfo(shop.shopCd);
                
                result = await updateShopInfo(shop);

                //폐쇄몰 데이터 연동
                if (result.code == "00" && mallUserF.user_id != "N" && Utils.serverGbn == "R")
                {
                    if (!string.IsNullOrEmpty(mallUserF.user_name)
                        && !string.IsNullOrEmpty(mallUserF.tel_no)
                        && !string.IsNullOrEmpty(mallUserF.address))
                    {
                        //가맹점 수정시 폐쇄몰정보도 수정

                        string memo = await MallController.getItemName(shop.itemCd1);
                        ResultMall mallResult = await MallController.existCheck(mallUserF.mcode, mallUserF.user_id, mallUserF.password);

                        if (mallResult.data.query_code.Equals("NO")) //회원정보가 없을경우 등록
                        {
                            mallUserF.memo = memo;
                            mallResult = await MallController.signUp(mallUserF, "D");

                            if (!mallResult.code.Equals("1000")) //실패시 오류메시지 출력
                            {
                                foreach (ResultBasic i in mallResult.data.parameter)
                                {
                                    err_msg = err_msg + i.msg + ",";
                                }

                                result.code = "98";
                                result.msg = mallResult.msg + err_msg;
                                await Utils.SaveErrorAsync("/ShopInfo : Put", mallUserF.user_id + "/" + result.msg);
                            }

                            result.msg = result.msg + " 폐쇄몰 등록";
                        }
                        else if (mallResult.data.query_code.Equals("OK")) //회원정보가 있을경우 수정
                        {
                            // 폐쇄몰 수정사항이 있는경우만 수정 호출
                            // (레코드는 내부 값이 같으면 Equals -> true 리턴)
                            if (mallUserF.memo != memo) // 카테고리가 기존과 다를경우만 수정
                            {
                                mallUserF.memo = memo;
                                mallResult = await MallController.modUser(mallUserF, "D");

                                if (!mallResult.code.Equals("1000")) //실패시 롤백 후 오류메시지 출력
                                {
                                    await updateShopInfo(shopInfoF);

                                    foreach (ResultBasic i in mallResult.data.parameter)
                                    {
                                        err_msg = err_msg + i.msg + ",";
                                    }

                                    result.code = "98";
                                    result.msg = mallResult.msg + err_msg;
                                    await Utils.SaveErrorAsync("/ShopInfo : Put", mallUserF.user_id + "/" + result.msg);
                                }

                                result.msg = result.msg + " 폐쇄몰 수정";
                            }

                        }
                    }

                }

                //POS가맹점 멀티샵 생성 및 삭제
                if (result.code == "00" && result.jobGbn != "null")
                {
                    PosResultBasic posResult = new PosResultBasic();

                    PosMultishop pos = new PosMultishop();
                    pos.shop_info = new PosMultishopInfo();
                    pos.shop_info.login_id = result.loginId;
                    if (result.jobGbn == "MI")
                    {
                        pos.job_gbn = "INSERT";
                        pos.shop_info.b2b_mapping_list = new List<string>();
                        pos.shop_info.b2b_mapping_list.Add(result.apiComCode);
                    }
                    else if (result.jobGbn == "MU")
                    {
                        pos.job_gbn = "SHOPLIST_UPDATE";
                        ResultGetMultiShopList r = new ResultGetMultiShopList();
                        r.data = new List<ShopMultiList>();

                        r = await getMultiShopList(shop.multishop_cd);
                        pos.shop_info.b2b_mapping_list = r.data.Select(x => x.api_com_code).ToList();
                        
                    }
                    else if (result.jobGbn == "MD")
                    {
                        pos.job_gbn = "DELETE";
                    }
                    else
                    {
                        var msg = "존재하지 않는 작업구분, code:" + result.code + "job_gbn:" + result.jobGbn + result.jobGbn.GetType().Name;
                        await Utils.SaveErrorAsync("/ShopInfo : Put", msg);
                        result.code = "99";
                        result.msg = msg;
                        return Ok(new { code = result.code, msg = result.msg });
                    }

                    posResult = await setPosMultishop(pos);

                    if(posResult.code != 0)//롤백처리
                    {
                        await updateShopInfo(shopInfoF);
                        result.code = "98";
                        result.msg = posResult.message;
                        await Utils.SaveErrorAsync("/ShopInfo : Put", "POS멀티샵 연동실패/" + result.msg);
                    }
                }

                //장보기 POS가맹점 멀티샵 생성 및 삭제
                if (result.code == "00" && result.jobGbn2 != "null")
                {
                    result.msg = result.msg + "장보기pos연동";
                    PosResultBasic posResult = new PosResultBasic();

                    PosMultishop pos = new PosMultishop();
                    pos.shop_info = new PosMultishopInfo();
                    pos.shop_info.login_id = result.loginId2;
                    if (result.jobGbn2 == "MI")
                    {
                        pos.job_gbn = "INSERT";
                        pos.shop_info.b2b_mapping_list = new List<string>();
                        //pos.shop_info.b2b_mapping_list.Add(result.apiComCode);


                        ResultGetMultiShopList r = new ResultGetMultiShopList();
                        r.data = new List<ShopMultiList>();

                        r = await getMultiShopListB(shop.shopCd, null);
                        pos.shop_info.b2b_mapping_list = r.data.Select(x => x.api_com_code).ToList();
                    }
                    else if (result.jobGbn2 == "MD")
                    {
                        pos.job_gbn = "DELETE";
                    }
                    else
                    {
                        var msg = "존재하지 않는 작업구분, code:" + result.code + "job_gbn2:" + result.jobGbn2 + result.jobGbn2.GetType().Name;
                        await Utils.SaveErrorAsync("/ShopInfo : Put", msg);
                        result.code = "99";
                        result.msg = msg;
                        return Ok(new { code = result.code, msg = result.msg });
                    }

                    posResult = await setPosMultishop(pos);

                    if (posResult.code != 0)//롤백처리
                    {
                        await updateShopInfo(shopInfoF);
                        result.code = "98";
                        result.msg = posResult.message;
                        await Utils.SaveErrorAsync("/ShopInfo : Put", "POS멀티샵 연동실패(장보기)/" + result.msg);
                    }
                }

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo : Put", ex.Message);
                result.code = "99";
                result.msg = ex.Message;
            }

            return Ok(new { code = result.code, msg = result.msg });
        }

        //사업자번호 변경내용 조회
        /// <summary>
        /// 사업자변경 조회
        /// </summary>
        [HttpGet("getRegNoHist")]
        public async Task<IActionResult> GetRegNoHist(string page, string rows, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalCount = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("page", page);
            param.Add("row_count", rows);
            param.Add("date_begin", date_begin);
            param.Add("date_end", date_end);

            
            try
            {
                db.Open();

                string sql = @"
                            SELECT T2.SHOP_CD,
                                   T2.SEQNO,
                                   T2.shop_name,
                                   T2.owner,
                                   T2.telNo,
                                   T2.HIST_DATE,
                                   T2.REGNO_HIST
                              FROM (SELECT ROWNUM AS RNUM,
                                           T1.*
                                      FROM (SELECT a.seqno,
                                                    a.shop_cd,
                                                    b.shop_name,
                                                    b.owner,
                                                    b.telNo,
                                                    a.hist_date,
                                                    DECODE(INSTR (SUBSTR (a.memo, 8), '['), 0, SUBSTR (SUBSTR (a.memo, 8), 1), SUBSTR (SUBSTR (a.memo, 8), 1, (INSTR (SUBSTR (a.memo, 8), '[')) - 1))
                                                AS regno_hist
                                            FROM shop_info_hist a, shop_info b, callcenter C
                                            WHERE     a.memo LIKE '사업자번호%'
                                                    AND a.memo NOT LIKE '사업자번호 :@%'
                                                    AND a.shop_cd = b.shop_cd
                                                    AND b.cccode = c.cccode
                                                    And c.mcode = 2
                                                    AND to_char(HIST_DATE, 'YYYYMMDD') BETWEEN :date_begin AND :date_end
                                        ORDER BY seqno DESC) T1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) T2
                             WHERE (( :page - 1) * :row_count) < RNUM
                        ";


                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                sql = @"SELECT COUNT(*)
                        FROM shop_info_hist a, shop_info b, callcenter C
                        WHERE     a.memo LIKE '사업자번호%'
                                AND a.memo NOT LIKE '사업자번호 :@%'
                                AND a.shop_cd = b.shop_cd
                                AND b.cccode = c.cccode
                                And c.mcode = 2
                                AND to_char(HIST_DATE, 'YYYYMMDD') BETWEEN :date_begin AND :date_end";

                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, count = items.Count, data = items });
        }

        /// <summary>
        /// 가맹점 매장정보 변경이력 조회(이미지, 멀티샵)
        /// </summary>
        /// <remarks>        
        /// shop_cd: 가맹점 코드(필수) <br/>
        /// page : 페이지 <br/>
        /// row : 갯수 
        /// </remarks>
        [HttpGet("getHist")]
        public async Task<IActionResult> getHist(string shop_cd, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<ShopMultiHist> shops = new List<ShopMultiHist>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.GET_SHOP_INFO_HIST",
            };


            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopMultiHist s = new ShopMultiHist
                    {
                        no = rd["NO"].ToString(),
                        hist_date = rd["HIST_DATE"].ToString(),
                        memo = rd["MEMO"].ToString(),
                    };

                    shops.Add(s);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo : GetHist", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = shops });
        }
        #endregion[매장정보 관리]

        #region[라이브 이벤트]
        /// <summary>
        /// 라이브 이벤트 조회 - 목록
        /// </summary>
        /// shopName 가맹점명 검색 키워드 <br/>
        /// eventName 이벤트명 검색 키워드 <br/>
        [HttpGet("getShopEventList")]
        public async Task<IActionResult> getShopEventList(string mCode, string shopName, string eventName, string state, string page, string rows, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RCount = string.Empty;
            string RTotalCount = "0";

            string shopSql = string.Empty;
            string eventSql = string.Empty;
            string stateSql = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("mcode", mCode);
            param.Add("shop_name", "%" + shopName + "%");
            param.Add("eventName", "%" + eventName + "%");
            param.Add("state", state);
            param.Add("page", page);
            param.Add("row_count", rows);
            param.Add("date_begin", date_begin);
            param.Add("date_end", date_end);

            if (shopName is not null)
            {
                shopSql = @"AND B.SHOP_NAME like :shop_name";
            }

            if (eventName is not null)
            {
                eventSql = @"AND a.event_title_m like :eventName";
            }

            switch (state)
            {
                case "1": stateSql = @"AND state = '예정'"; break;
                case "2": stateSql = @"AND state = '진행'"; break;
                case "3": stateSql = @"AND state = '종료'"; break;
            }


            try
            {
                db.Open();

                string sql = @$"
                            SELECT t2.*
                              FROM (SELECT ROWNUM AS RNUM,
                                           t1.*
                                    FROM (select a.shop_cd, 
                                                b.shop_name,
                                                a.ins_date,
                                                a.ins_name,
                                                a.order_date || a.fr_tm as from_time, 
                                                a.order_date || a.to_tm as to_time, 
                                                (case 
                                                    when sysdate between to_date(a.order_date || a.fr_tm, 'YYYYMMDDHH24MI') and 
                                                                            to_date(a.order_date || a.to_tm, 'YYYYMMDDHH24MI') and a.use_gbn = 'Y' then '진행' 
                                                    when sysdate < to_date(a.order_date || a.fr_tm, 'YYYYMMDDHH24MI') then '예정'
                                                    else '종료'
                                                end) as STATE,
                                                a.event_title_m
                                        from shop_event_mst a, shop_info b, callcenter c
                             where a.shop_cd = b.shop_cd
                               AND b.cccode = c.cccode
                               AND c.mcode = :mcode
                               {shopSql}
                               {eventSql}
                               AND a.order_date BETWEEN :date_begin AND :date_end
                               order by (a.order_date || a.fr_tm) desc, a.shop_cd) t1
                            WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count {stateSql}) t2
                            WHERE (( :page - 1) * :row_count) < RNUM
                        ";


                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                sql = @"select count(*)
                        from shop_event_mst a, shop_info b, callcenter c
                        where a.shop_cd = b.shop_cd
                          AND b.cccode = c.cccode";

                //RTotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                
                sql = @$"select count(*)
                                    FROM (select  
                                                (case 
                                                    when sysdate between to_date(a.order_date || a.fr_tm, 'YYYYMMDDHH24MI') and 
                                                                            to_date(a.order_date || a.to_tm, 'YYYYMMDDHH24MI') and a.use_gbn = 'Y' then '진행' 
                                                    when (sysdate > to_date(a.order_date || a.to_tm, 'YYYYMMDDHH24MI') )
                                                         or 
                                                         (sysdate between to_date(a.order_date || a.fr_tm, 'YYYYMMDDHH24MI') and 
                                                                            to_date(a.order_date || a.to_tm, 'YYYYMMDDHH24MI') and a.use_gbn = 'N') then '종료'
                                                    when sysdate < to_date(a.order_date || a.fr_tm, 'YYYYMMDDHH24MI') then '예정'
                                                end) as STATE
                                        from shop_event_mst a, shop_info b, callcenter c
                             where a.shop_cd = b.shop_cd
                               AND b.cccode = c.cccode
                               AND c.mcode = :mcode
                               {shopSql}
                               {eventSql}
                               AND a.order_date BETWEEN :date_begin AND :date_end)
                            WHERE  1 = 1 {stateSql}";

                RCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RTotalCount, count = RCount, data = items });
        }


        /// <summary>
        /// 가맹점 이벤트 할인메뉴 조회
        /// </summary>
        /// <remarks>
        /// sale_limit_qnt 판매 한정 수량 <br/>
        /// order_qnt 이벤트 실주문 수량 <br/>
        /// left_qnt 남은수량 <br/>
        /// </remarks>
        [HttpGet("getShopEventDiscMenu/{shop_cd}")]
        public async Task<IActionResult> getShopEventDiscMenu(string shop_cd, string state, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RCount = string.Empty;

            string stateSql = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("shop_cd", shop_cd);
            param.Add("page", page);
            param.Add("row_count", rows);

            switch (state)
            {
                case "1": stateSql = @"AND state = '예정'"; break;
                case "2": stateSql = @"AND state = '진행'"; break;
                case "3": stateSql = @"AND state = '종료'"; break;
            }

            try
            {
                db.Open();

                string sql = @$"
                            SELECT t2.*
                              FROM (SELECT ROWNUM AS RNUM,
                                           t1.*
                                    FROM (select b.menu_name,
                                                b.menu_cost,
                                                a.event_amt_gbn,
                                                a.event_amt,
                                                case when a.event_amt_gbn = 1 then b.menu_cost - a.event_amt else round(b.menu_cost - b.menu_cost * (a.event_amt / 100),2) end as disc_cost,
                                                a.order_date || a.fr_tm as from_time, 
                                                a.order_date || a.to_tm as to_time, 
                                                (case 
                                                    when sysdate between to_date(a.order_date || a.fr_tm, 'YYYYMMDDHH24MI') and 
                                                                            to_date(a.order_date || a.to_tm, 'YYYYMMDDHH24MI') and a.use_gbn = 'Y' then '진행' 
                                                    when (sysdate > to_date(a.order_date || a.to_tm, 'YYYYMMDDHH24MI') )
                                                         or 
                                                         (sysdate between to_date(a.order_date || a.fr_tm, 'YYYYMMDDHH24MI') and 
                                                                            to_date(a.order_date || a.to_tm, 'YYYYMMDDHH24MI') and a.use_gbn = 'N') then '종료'
                                                    when sysdate < to_date(a.order_date || a.fr_tm, 'YYYYMMDDHH24MI') then '예정'
                                                end) as STATE,
                                                nvl(a.sale_limit_qnt,0) sale_limit_qnt, -- 판매 한정 수량
                                                nvl(c.order_qnt,0) order_qnt, -- 이벤트 실주문 수량
                                                nvl(a.sale_limit_qnt,0) - nvl(c.order_qnt,0) left_qnt -- 남은수량
                                        from shop_event a, menulist b, event_shop c
                                        where a.shop_cd = b.shop_cd
                                            and a.menu_cd = b.menu_cd
                                            and b.shop_cd = c.shop_cd (+)
                                            and b.menu_cd = c.menu_cd (+)
                                            and a.shop_cd = :shop_cd ) t1
                            WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count {stateSql}) t2
                            WHERE (( :page - 1) * :row_count) < RNUM
                        ";


                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                sql = @$"select count(*)
                        from(select (case 
                                        when sysdate between to_date(a.order_date || a.fr_tm, 'YYYYMMDDHH24MI') and 
                                                            to_date(a.order_date || a.to_tm, 'YYYYMMDDHH24MI') and a.use_gbn = 'Y' then '진행' 
                                        when sysdate > to_date(a.order_date || a.to_tm, 'YYYYMMDDHH24MI') and a.use_gbn = 'N' then '종료'
                                        when sysdate < to_date(a.order_date || a.fr_tm, 'YYYYMMDDHH24MI') and a.use_gbn = 'N' then '예정'
                                    end) as STATE
                            from shop_event a, menulist b
                            where a.shop_cd = b.shop_cd 
                                and a.menu_cd = b.menu_cd
                                and a.shop_cd = :shop_cd)
                        where 1 = 1 {stateSql}";

                RCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
        }

        
        /// <summary>
        /// 가맹점 이벤트 변경이력
        /// </summary>
        [HttpGet("getShopEventHist/{shop_cd}")]
        public async Task<IActionResult> history(string shop_cd, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT *
                                FROM (select ROWNUM as NO, T1.*
                                from(select * from shop_event_mst_hist
                                            where shop_cd = :shop_cd
                                            order by hist_date desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2
                                WHERE ((:in_page - 1) * :in_rows) < NO
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = items.Count.ToString(), data = items });
        }

        
        /// <summary>
        /// 가맹점 라이브이벤트 유무
        /// </summary>
        [HttpGet("getEventYn/{shop_cd}")]
        public async Task<IActionResult> getEventYn(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RData = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("shop_cd", shop_cd);

            try
            {
                db.Open();

                string sql = @$"
                            select case when count(1) > 0 then 'Y' else 'N' end as event_yn
                            from shop_event_mst
                            where order_date = to_char(sysdate, 'YYYYMMDD')
                            and use_gbn = 'Y'
                            and shop_cd = :shop_cd
                        ";

                RData = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = RData });
        }
        #endregion[라이브 이벤트]

        #region[멀티샵]
        /// <summary>
        /// POS멀티가맹점 정보 처리
        /// </summary>
        [HttpPost("setPosMultishop")]
        private async Task<PosResultBasic> setPosMultishop(PosMultishop pos)
        {
            string url = string.Empty;

            if (Utils.serverGbn == "T")
            {
                url = @$"https://postest.daeguro.co.kr:15505/posApi/POSData/Set_multiShopInfo/";//(테스트서버경로)
            }
            else if (Utils.serverGbn == "R")
            {
                url = @$"https://pos.daeguro.co.kr:15412/posApi/POSData/Set_multiShopInfo/"; //(운영서버경로)
            }

            pos.app_name = "대구로 어드민";
            pos.app_type = "admin-daeguroApp";
            pos.shop_info.use_gbn = "Y";
            pos.shop_info.login_pw = "eornfh";

            PosResultBasic result = new PosResultBasic();

            try
            {
                var payload = pos;

                var stringPayload = JsonConvert.SerializeObject(payload);

                HttpContent httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");

                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", Utils.posKey);

                HttpResponseMessage httpResponse = await httpClient.PostAsync(url, httpContent);

                string responseStr = await httpResponse.Content.ReadAsStringAsync();

                result = JsonConvert.DeserializeObject<PosResultBasic>(responseStr);

                await Utils.SaveTempLogAsync("/ShopInfo/setPosMultishop : Post", result.code.ToString() + "/" + stringPayload);// 호출내역 기록

                if (result.code != 0)
                {
                    await Utils.SaveErrorAsync("/ShopInfo/setPosMultishop : Post", result.message + stringPayload);
                }

            }
            catch (Exception ex)
            {
                result.code = 99;
                result.message = ex.Message;
                await Utils.SaveErrorAsync("/ShopInfo/setPosMultishop : Post", ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 가맹점 목록 조회 - 멀티샵 연결용
        /// </summary>
        /// <remarks>        
        /// mcode: 회원사코드(필수) <br/>
        /// keyword : 검색 키워드(가맹점명, 대표자명, 사업자번호) <br/>
        ///  * 가맹점 상태가 신규거나 운영인 가맹점만 조회
        /// </remarks>
        [HttpGet("getMultiShopTargetList")]
        public async Task<IActionResult> getMultiShopTargetList(string mCode, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;            

            List<ShopMultiTargetList> shops = new List<ShopMultiTargetList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.GET_SHOP_LIST",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mCode;            
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 60).Value = keyword;          
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();                
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopMultiTargetList s = new ShopMultiTargetList
                    {                        
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),                        
                        reg_no = rd["REG_NO"].ToString(),
                        owner = rd["OWNER"].ToString(),
                        open_dt = rd["OPEN_DT"].ToString(),                        
                        reser_req_date = rd["RESER_REQ_DATE"].ToString(),
                        multi_shop_yn = rd["MULTI_SHOP_YN"].ToString(),                        
                        api_com_code = rd["API_COM_CODE"].ToString(),                        
                    };

                    shops.Add(s);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo : getMultiShopTargetList", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = shops });
        }

        /// <summary>
        /// 멀티샵 가맹점 목록 조회
        /// </summary>
        /// <remarks>        
        /// multishop_cd: 멀티샵 코드(필수)
        /// </remarks>
        [HttpGet("getMultiShopList")]
        public async Task<ResultGetMultiShopList> getMultiShopList(string multishop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            ResultGetMultiShopList result = new ResultGetMultiShopList();
            List<ShopMultiList> shops = new List<ShopMultiList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.GET_MULTI_SHOP_LIST",
            };

            
            cmd.Parameters.Add("in_multishop_cd", OracleDbType.Int32).Value = multishop_cd;            
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                result.count = cmd.Parameters["out_count"].Value.ToString();
                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopMultiList s = new ShopMultiList
                    {
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),
                        reg_no = rd["REG_NO"].ToString(),
                        owner = rd["OWNER"].ToString(),
                        open_dt = rd["OPEN_DT"].ToString(),
                        reser_req_date = rd["RESER_REQ_DATE"].ToString(),
                        multi_shop_yn = rd["MULTI_SHOP_YN"].ToString(),
                        representative_yn = rd["REPRESENTATIVE_YN"].ToString(),
                        api_com_code = rd["API_COM_CODE"].ToString(),
                    };

                    shops.Add(s);
                }

                result.data = shops;

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo : GetMultiShopList", ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 멀티샵 연결추가
        /// </summary>
        /// <remarks>
        /// multishop_cd: 멀티샵 코드 (필수) <br/>
        /// shop_cd : 가맹점 코드 (필수) <br/>
        /// ucode : 작업자 코드 <br/>
        /// </remarks>
        [HttpPut("insertMultiShop")]
        public async Task<ResultBasic> insertMultiShop(string multishop_cd, string shop_cd, string ucode)
        {
            ResultBasic result = new ResultBasic();


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.INSERT_MULTI_SHOP",
            };

            cmd.Parameters.Add("in_multishop_cd", OracleDbType.Int32).Value = multishop_cd;
            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo/insertMultiShop : Put", ex.Message);
                result.code = "99";
                result.msg = ex.Message;
            }

            return result;
        }

        /// <summary>
        /// 멀티샵 연결수정
        /// </summary>
        /// <remarks>
        /// multishop_cd: 멀티샵 코드 (필수) <br/>
        /// ucode : 작업자 코드 <br/>
        /// shop_cd : 가맹점 코드 리스트(필수) <br/>
        /// </remarks>
        [HttpPut("setMultiShop")]
        public async Task<IActionResult> setMultiShop(string multishop_cd, string ucode, IEnumerable<string> shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.SET_MULTI_SHOP",
            };

            cmd.Parameters.Add("in_multishop_cd", OracleDbType.Int32).Value = multishop_cd;
            var arrShop_cd = cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10);
            arrShop_cd.Direction = ParameterDirection.Input;
            arrShop_cd.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrShop_cd.Value = shop_cd.ToArray();
            arrShop_cd.Size = shop_cd.Count();
            arrShop_cd.ArrayBindSize = shop_cd.Select(_ => _.Length).ToArray();
            arrShop_cd.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, shop_cd.Count()).ToArray();
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo/setMultiShop : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 멀티샵 가맹점 카피
        /// </summary>
        /// <remarks>       
        /// mcode : 회원사코드 <br/>
        /// rep_shop_cd : 대표가맹점 코드(필수/ 복사대상) <br/>
        /// api_com_code : pos 매핑코드(필수/ 복사대상) <br/>
        /// shop_name : 가맹점명(필수) <br/>
        /// copy_calc : 정산 복사여부(Y/N) <br/>
        /// copy_info : 매장 복사여부(Y/N) <br/>
        /// copy_sector : 배달지 복사여부(Y/N) <br/>
        /// copy_deli_tip : 배달팁 복사여부(Y/N) <br/>
        /// copy_day_time : (주문) 영업시간 복사여부(Y/N) <br/>
        /// copy_menu : 메뉴 복사여부(Y/N) <br/>
        /// ucode : 작업자 코드(필수) <br/>
        /// </remarks>
        [HttpPost("setCopyMultiShop")]
        public async Task<ResultShop> setCopyMultiShop(NewMultiShop item)
        {
            ResultShop resultM = new ResultShop();

            ResultPlus result = new ResultPlus();
            ResultPlus2 result2 = new ResultPlus2();
            PosShopResult result3 = new PosShopResult();

            string shop_id = string.Empty;
            string cccode = string.Empty;
            string new_shop_cd = string.Empty;

            try
            {
                result = await ShopBasicController.setShopId();
                if (result.code != "00")
                {
                    resultM.code = result.code;
                    resultM.msg = "shop_id 생성에 실패하였습니다. " + result.msg;
                    return resultM;
                }

                shop_id = result.item;

                PosShop posShopCopy = new PosShop();
                posShopCopy.shop_info = new PosShopInfo();
                posShopCopy.app_type = item.mcode == "1" ? "test" : "admin-daeguroApp";
                posShopCopy.shop_info.job_gbn = "COPY";
                posShopCopy.shop_info.login_id = shop_id; // 새 가맹점 로그인 id
                posShopCopy.shop_info.shop_name = item.shop_name; // 새 가맹점명
                posShopCopy.shop_info.mod_ucode = item.ucode;
                posShopCopy.shop_info.shop_token = item.api_com_code; // 복사대상 가맹점 api_com_code
                result3 = await ShopBasicController.setPosShop(posShopCopy);

                if (result3.code != 0)
                {
                    resultM.code = result3.code.ToString();
                    resultM.msg = "포스 가맹점 생성에 실패하였습니다. " + result3.message;
                    return resultM;
                }

                item.api_com_code = result3.shop_token; // 새 가맹점 api_com_code

                result2 = await setCopyShop(shop_id, item);
                if (result2.code != "00")
                {
                    resultM.code = result2.code;
                    resultM.msg = "대구로 가맹점 생성에 실패하였습니다. " + result2.msg;
                    return resultM;
                }

                cccode = result2.item;
                new_shop_cd = result2.item2;

                //가맹점 이미지 복사
                if (item.copy_info == "Y")
                {
                    await copyShopImage(cccode, item.rep_shop_cd, cccode, new_shop_cd, item.ucode);
                }
                //가맹점 메뉴복사
                if (item.copy_menu == "Y")
                {
                    string user_name = await UserController.getUserName(item.ucode);
                    await copyMenuOption(cccode, item.rep_shop_cd, cccode, new_shop_cd, user_name);
                }

                resultM.code = "00";
                resultM.msg = "성공";
                resultM.shop_cd = new_shop_cd;
                resultM.api_com_code = result3.shop_token; // 새 가맹점 api_com_code
            }
            catch (Exception ex)
            {
                resultM.code = "99";
                resultM.msg = ex.Message;
                await Utils.SaveErrorAsync("/ShopInfo/setCopyMultiShop : Post", ex.Message);
            }

            return resultM;

        }

        /// <summary>
        /// 메뉴복사(꽃배달 메뉴이미지 복사기능x)
        /// </summary>
        [HttpPost("copyMenuOption")]
        public async Task<ResultBasic> copyMenuOption(string source_cccode, string source_shop_cd, string dest_cccode, string dest_shop_cd, string insert_name)
        {
            ResultBasic result = new ResultBasic();
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.COPY_MENU_OPTION",
            };

            cmd.Parameters.Add("in_s_shop_cd", OracleDbType.Varchar2, 10).Value = source_shop_cd;
            cmd.Parameters.Add("in_d_shop_cd", OracleDbType.Varchar2, 10).Value = dest_shop_cd;
            cmd.Parameters.Add("in_insert_name", OracleDbType.Varchar2, 30).Value = insert_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();


                #region  파일 복사
                if (result.code.Equals("00"))
                {
                    // 경로 맨 뒤에 역슬래쉬가 없어야 한다.
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        // 소스 이미지 경로
                        string sourcePath = $@"{productPath}\{source_cccode}\{source_shop_cd}";
                        string destPath = $@"{productPath}\{dest_cccode}\{dest_shop_cd}";

                        if (Directory.Exists(sourcePath))
                        {
                            // 복사에서 제외될 파일명들
                            var excluedeFiles = new List<string>(new[] { "shop.jpg", "buss.jpg", "bank.jpg", "idcard.jpg" });

                            var file_Files = Directory.GetFiles(sourcePath, "*.*").Where(file => !excluedeFiles.Any<string>((file_name) => file.EndsWith(file_name, StringComparison.CurrentCultureIgnoreCase))).ToList();

                            // 복사할 파일이 존재할 때만 디렉토리를 생성하고 복사를 진행한다.
                            if (file_Files.Count > 0)
                            {
                                if (Directory.Exists($@"{productPath}\{dest_cccode}") == false)
                                {
                                    Directory.CreateDirectory($@"{productPath}\{dest_cccode}");
                                }

                                if (Directory.Exists($@"{productPath}\{dest_cccode}\{dest_shop_cd}") == false)
                                {
                                    Directory.CreateDirectory($@"{productPath}\{dest_cccode}\{dest_shop_cd}");
                                }


                                foreach (string list_file in file_Files)
                                {
                                    int iPos = list_file.LastIndexOf(@"\");
                                    string file_name = list_file.Substring(iPos + 1, list_file.Length - (iPos + 1));

                                    try
                                    {
                                        // 파일이 이미 존재하면 삭제한다.
                                        if (System.IO.File.Exists($@"{destPath}\{file_name}"))
                                        {
                                            System.GC.Collect();
                                            System.GC.WaitForPendingFinalizers();
                                            System.IO.File.Delete($@"{destPath}\{file_name}");
                                        }

                                        System.IO.File.Copy(list_file, $@"{destPath}\{file_name}");
                                    }
                                    catch (Exception ex)
                                    {
                                        await Utils.SaveErrorAsync("/ShopInfo/copyMenuOption : Post - 파일존재 확인 후 카피부분", ex.Message);
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo/copyMenuOption : Post", ex.Message + " || {source_cccode: " + source_cccode + ", source_shop_cd: " + source_shop_cd + ", dest_cccode: " + dest_cccode + ", dest_shop_cd: " + dest_shop_cd + ", insert_name: " + insert_name + "}");
                //return Ok(new { code = 01, msg = "이미지 복사 실패" });
                result.code = "01";
                result.msg = "이미지 복사 실패";
                return result;
            }

            //return Ok(new { code = Rcode, msg = Rmsg });
            return result;
        }

        /// <summary>
        /// 대구로 가맹점 복사
        /// </summary>
        /// <remarks>
        /// shop_id : pos,사싸 로그인 id(필수) <br/>
        /// rep_shop_cd : 복사대상 가맹점 코드(필수) <br/>
        /// shop_name : 가맹점명(필수) <br/>
        /// api_com_code : pos 매핑코드(필수) <br/>
        /// copy_calc : 정산 복사여부(Y/N) <br/>
        /// copy_info : 매장 복사여부(Y/N) <br/>
        /// copy_sector : 배달지 복사여부(Y/N) <br/>
        /// copy_deli_tip : 배달팁 복사여부(Y/N) <br/>
        /// copy_day_time : (주문) 영업시간 복사여부(Y/N) <br/>
        /// ucode : 작업자 코드(필수) <br/>
        /// </remarks>
        [HttpPost("setCopyShop")]
        public async Task<ResultPlus2> setCopyShop(string shop_id, NewMultiShop item)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            ResultPlus2 result = new ResultPlus2();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.SET_COPY_SHOP",
            };

            cmd.Parameters.Add("in_copy_shop_cd", OracleDbType.Varchar2, 20).Value = item.rep_shop_cd;
            cmd.Parameters.Add("in_shop_name", OracleDbType.Varchar2, 200).Value = item.shop_name;
            cmd.Parameters.Add("in_shop_id", OracleDbType.Varchar2, 20).Value = shop_id;
            cmd.Parameters.Add("in_api_com_code", OracleDbType.Varchar2, 30).Value = item.api_com_code;
            cmd.Parameters.Add("in_copy_calc", OracleDbType.Varchar2, 1).Value = item.copy_calc;
            cmd.Parameters.Add("in_copy_info", OracleDbType.Varchar2, 1).Value = item.copy_info;
            cmd.Parameters.Add("in_copy_sector", OracleDbType.Varchar2, 1).Value = item.copy_sector;
            cmd.Parameters.Add("in_copy_deli_tip", OracleDbType.Varchar2, 1).Value = item.copy_deli_tip;
            cmd.Parameters.Add("in_copy_day_time", OracleDbType.Varchar2, 1).Value = item.copy_day_time;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = item.ucode;
            cmd.Parameters.Add("out_cccode", OracleDbType.Int32).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_shop_cd", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
                result.item = cmd.Parameters["out_cccode"].Value.ToString();
                result.item2 = cmd.Parameters["out_shop_cd"].Value.ToString();
                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();

                if(result.code != "00")
                {
                    await Utils.SaveErrorAsync("/ShopInfo : setCopyShop", result.msg);
                }
            }
            catch (Exception ex)
            {
                result.code = "99";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync("/ShopInfo : setCopyShop", ex.Message);
            }

            return result;
        }

        //가맹점 이미지 복사
        [HttpPost("copyShopImage")]
        public async Task<ResultBasic> copyShopImage(string copy_cccode, string copy_shop_cd, string cccode, string shop_cd, string ucode)
        {
            ResultBasic result = new ResultBasic();
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            // 경로 맨 뒤에 역슬래쉬가 없어야 한다.
            using (new ConnectToSharedFolder(nasPath))
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
                OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_SHOP_INFO.COPY_SHOP_IMAGE",
                };

                cmd.Parameters.Add("in_copy_shop_cd", OracleDbType.Varchar2, 10).Value = copy_shop_cd;
                cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
                cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

                try
                {
                    await conn.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();

                    result.code = cmd.Parameters["out_code"].Value.ToString();
                    result.msg = cmd.Parameters["out_msg"].Value.ToString();


                    #region  파일 복사
                    if (result.code.Equals("00"))
                    {

                        // 소스 이미지 경로
                        string sourcePath = $@"{productPath}\{copy_cccode}\{copy_shop_cd}";
                        string destPath = $@"{productPath}\{cccode}\{shop_cd}";

                        if (Directory.Exists(sourcePath))
                        {
                            // 복사할 파일명들
                            var incluedeFiles = new List<string>(new[] { "shop.jpg", "buss.jpg", "bank.jpg", "idcard.jpg" });

                            var file_Files = Directory.GetFiles(sourcePath, "*.*").Where(file => incluedeFiles.Any<string>((file_name) => file.EndsWith(file_name, StringComparison.CurrentCultureIgnoreCase))).ToList();

                            // 복사할 파일이 존재할 때만 디렉토리를 생성하고 복사를 진행한다.
                            if (file_Files.Count > 0)
                            {
                                if (Directory.Exists($@"{productPath}\{cccode}") == false)
                                {
                                    Directory.CreateDirectory($@"{productPath}\{cccode}");
                                }

                                if (Directory.Exists($@"{productPath}\{cccode}\{shop_cd}") == false)
                                {
                                    Directory.CreateDirectory($@"{productPath}\{cccode}\{shop_cd}");
                                }


                                foreach (string list_file in file_Files)
                                {
                                    int iPos = list_file.LastIndexOf(@"\");
                                    string file_name = list_file.Substring(iPos + 1, list_file.Length - (iPos + 1));

                                    try
                                    {
                                        // 파일이 이미 존재하면 삭제한다.
                                        if (System.IO.File.Exists($@"{destPath}\{file_name}"))
                                        {
                                            System.GC.Collect();
                                            System.GC.WaitForPendingFinalizers();
                                            System.IO.File.Delete($@"{destPath}\{file_name}");
                                        }

                                        System.IO.File.Copy(list_file, $@"{destPath}\{file_name}");
                                    }
                                    catch (Exception ex)
                                    {
                                        await Utils.SaveErrorAsync("/ShopInfo/copyShopImage : Post - 파일존재 확인 후 카피부분", ex.Message);
                                    }
                                }
                            }

                        }
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                    await Utils.SaveErrorAsync("/ShopInfo/copyShopImage : Post", ex.Message + " || {copy_cccode: " + copy_cccode + ", copy_shop_cd: " + copy_shop_cd + ", cccode: " + cccode + ", shop_cd: " + shop_cd + ", ucode: " + ucode + "}");
                    //return Ok(new { code = 01, msg = "이미지 복사 실패" });
                    result.code = "01";
                    result.msg = "이미지 복사 실패";
                    return result;
                }
            }
            //return Ok(new { code = Rcode, msg = Rmsg });
            return result;
        }

        #endregion[멀티샵]

        #region[장보기멀티샵]
        /// <summary>
        /// 가맹점 목록 조회 - 멀티샵 연결용(장보기)
        /// </summary>
        /// <remarks>        
        /// mcode: 회원사코드(필수) <br/>
        /// keyword : 검색 키워드(가맹점명, 대표자명, 사업자번호) <br/>
        ///  * 가맹점 상태가 신규거나 운영인 가맹점만 조회
        /// </remarks>
        [HttpGet("getMultiShopTargetListB")]
        public async Task<IActionResult> getMultiShopTargetListB(string mCode, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<ShopMultiTargetList> shops = new List<ShopMultiTargetList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.GET_SHOP_LIST_B",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mCode;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 60).Value = keyword;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopMultiTargetList s = new ShopMultiTargetList
                    {
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),
                        reg_no = rd["REG_NO"].ToString(),
                        owner = rd["OWNER"].ToString(),
                        open_dt = rd["OPEN_DT"].ToString(),
                        reser_req_date = rd["RESER_REQ_DATE"].ToString(),
                        multi_shop_yn = rd["MULTI_SHOP_YN"].ToString(),
                        api_com_code = rd["API_COM_CODE"].ToString(),
                    };

                    shops.Add(s);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo : getMultiShopTargetListB", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = shops });
        }

        /// <summary>
        /// 멀티샵 가맹점 목록 조회(장보기)
        /// </summary>
        /// <remarks>        
        /// m_shop_cd : 시장코드(필수) <br/>
        /// keyword : 가맹점명, 대표자명, 사업자번호 검색
        /// </remarks>
        [HttpGet("getMultiShopListB")]
        public async Task<ResultGetMultiShopList> getMultiShopListB(string m_shop_cd, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            ResultGetMultiShopList result = new ResultGetMultiShopList();
            List<ShopMultiList> shops = new List<ShopMultiList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.GET_MULTI_SHOP_LIST_B",
            };


            cmd.Parameters.Add("in_m_shop_cd", OracleDbType.Varchar2, 10).Value = m_shop_cd;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 60).Value = keyword;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                result.count = cmd.Parameters["out_count"].Value.ToString();
                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopMultiList s = new ShopMultiList
                    {
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),
                        reg_no = rd["REG_NO"].ToString(),
                        owner = rd["OWNER"].ToString(),
                        open_dt = rd["OPEN_DT"].ToString(),
                        reser_req_date = rd["RESER_REQ_DATE"].ToString(),
                        multi_shop_yn = rd["MULTI_SHOP_YN"].ToString(),
                        representative_yn = rd["REPRESENTATIVE_YN"].ToString(),
                        api_com_code = rd["API_COM_CODE"].ToString(),
                    };

                    shops.Add(s);
                }

                result.data = shops;

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo : GetMultiShopListB", ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 멀티샵 연결수정(장보기)
        /// </summary>
        /// <remarks>
        /// m_shop_cd : 시장코드 (필수) <br/>
        /// ucode : 작업자 코드 <br/>
        /// shop_cd : 가맹점 코드 리스트(필수) <br/>
        /// * 장보기 멀티샵의 대표상점(시장)은 바꿀수 없다
        /// </remarks>
        [HttpPut("setMultiShopB")]
        public async Task<IActionResult> setMultiShopB(string m_shop_cd, string ucode, IEnumerable<string> shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_INFO.SET_MULTI_SHOP_B",
            };

            cmd.Parameters.Add("in_m_shop_cd", OracleDbType.Int32).Value = m_shop_cd;
            var arrShop_cd = cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10);
            arrShop_cd.Direction = ParameterDirection.Input;
            arrShop_cd.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrShop_cd.Value = shop_cd.ToArray();
            arrShop_cd.Size = shop_cd.Count();
            arrShop_cd.ArrayBindSize = shop_cd.Select(_ => _.Length).ToArray();
            arrShop_cd.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, shop_cd.Count()).ToArray();
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo/setMultiShopB : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        #endregion[장보기멀티샵]

        #region[가맹점 브레이크타임 관리]
        /// <summary>
        /// 가맹점 브레이크타임 조회
        /// </summary>
        /// <remarks>
        /// 사싸 프로시저 호출(PKG_IS_CEO_WEB.GET_SHOP_SB_TIME) <br/>
        /// shop_cd : 가맹점코드(필수) <br/>
        /// sb_gbn : 등록구분(S: 운영시간, B: 브레이크 시간)(필수) <br/>
        /// * 현재는 브레이크시간만 사용. 추후 이관될수 있음 <br/>
        /// [response] <br/>
        /// day_gbn 요일구분(1 ~ 7/ 일 ~ 토) <br/>
        /// open_time 시작시간(MMDD) <br/>
        /// close_time 종료시간(MMDD) <br/>
        /// use_gbn 사용여부 <br/>
        /// next_day_yn 운영시간 익일 포함 여부 <br/>
        /// </remarks>
        [HttpGet("getSbTime")]
        public async Task<IActionResult> getSbTime(string shop_cd, string sb_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<SbTime> Rdata = new List<SbTime>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_CEO_WEB.GET_SHOP_SB_TIME",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_sb_gbn", OracleDbType.Varchar2, 1).Value = sb_gbn;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    SbTime i = new SbTime
                    {
                        shop_cd = rd["shop_cd"].ToString(),
                        sb_gbn = rd["sb_gbn"].ToString(),
                        day_gbn = rd["day_gbn"].ToString(),
                        open_time = rd["open_time"].ToString(),
                        close_time = rd["close_time"].ToString(),
                        use_gbn = rd["use_gbn"].ToString(),
                        next_day_yn = rd["next_day_yn"].ToString(),
                    };

                    Rdata.Add(i);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo/getSbTime : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 가맹점 브레이크타임 수정
        /// </summary>
        /// <remarks>
        /// 사싸 프로시저 호출(PKG_IS_CEO_WEB.SET_SHOP_SB_TIME) <br/>
        /// shop_cd : 가맹점코드 <br/>
        /// sb_gbn : 등록구분(S: 운영시간, B: 브레이크 시간) <br/>
        /// * 현재는 브레이크시간만 사용. 추후 이관될수 있음 <br/>
        /// day_gbn 요일구분(1 ~ 7/ 일 ~ 토) <br/>
        /// open_time 시작시간(MMDD) <br/>
        /// close_time 종료시간(MMDD) <br/>
        /// use_gbn 사용여부 <br/>
        /// next_day_yn 운영시간 익일 포함 여부 <br/>
        /// </remarks>
        [HttpPut("setSbTime")]
        public async Task<IActionResult> setSbTime(SetSbTime item)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            if(string.IsNullOrEmpty(item.shop_cd) ||
               string.IsNullOrEmpty(item.sb_gbn) ||
               string.IsNullOrEmpty(item.ucode) ||
               string.IsNullOrEmpty(item.uname) ||
               item.day_gbn.Count() != 7 ||
               item.open_time.Count() != 7 ||
               item.close_time.Count() != 7 ||
               item.use_gbn.Count() != 7 ||
               item.next_day_yn.Count() != 7
               )
            {
                Rcode = "99";
                Rmsg = "필수항목이 누락되었습니다.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_CEO_WEB.SET_SHOP_SB_TIME",
            };


            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = item.shop_cd;
            cmd.Parameters.Add("in_sb_gbn", OracleDbType.Varchar2, 1).Value = item.sb_gbn;

            var arr1 = cmd.Parameters.Add("in_day_gbn", OracleDbType.Varchar2, 1);
            arr1.Direction = ParameterDirection.Input;
            arr1.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr1.Value = item.day_gbn.ToArray();
            arr1.Size = item.day_gbn.Count();
            arr1.ArrayBindSize = item.day_gbn.Select(_ => _.Length).ToArray();
            arr1.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, item.day_gbn.Count()).ToArray();

            var arr2 = cmd.Parameters.Add("in_open_time", OracleDbType.Varchar2, 4);
            arr2.Direction = ParameterDirection.Input;
            arr2.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr2.Value = item.open_time.ToArray();
            arr2.Size = item.open_time.Count();
            arr2.ArrayBindSize = item.open_time.Select(_ => _.Length).ToArray();
            arr2.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, item.open_time.Count()).ToArray();

            var arr3 = cmd.Parameters.Add("in_close_time", OracleDbType.Varchar2, 4);
            arr3.Direction = ParameterDirection.Input;
            arr3.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr3.Value = item.close_time.ToArray();
            arr3.Size = item.close_time.Count();
            arr3.ArrayBindSize = item.close_time.Select(_ => _.Length).ToArray();
            arr3.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, item.close_time.Count()).ToArray();

            var arr4 = cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1);
            arr4.Direction = ParameterDirection.Input;
            arr4.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr4.Value = item.use_gbn.ToArray();
            arr4.Size = item.use_gbn.Count();
            arr4.ArrayBindSize = item.use_gbn.Select(_ => _.Length).ToArray();
            arr4.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, item.use_gbn.Count()).ToArray();

            var arr5 = cmd.Parameters.Add("in_next_day", OracleDbType.Varchar2, 1);
            arr5.Direction = ParameterDirection.Input;
            arr5.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr5.Value = item.next_day_yn.ToArray();
            arr5.Size = item.next_day_yn.Count();
            arr5.ArrayBindSize = item.next_day_yn.Select(_ => _.Length).ToArray();
            arr5.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, item.next_day_yn.Count()).ToArray();

            cmd.Parameters.Add("in_ucode", OracleDbType.Varchar2, 10).Value = item.ucode;
            cmd.Parameters.Add("in_uname", OracleDbType.Varchar2, 300).Value = item.uname;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo/setSbTime : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion[가맹점 브레이크타임 관리]

    }
}
