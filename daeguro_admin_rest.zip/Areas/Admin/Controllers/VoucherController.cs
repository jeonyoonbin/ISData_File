﻿using Dapper;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Linq;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading.Tasks;
using System.Collections.Generic;
using DG_App_Rest.Areas.Admin.Models;
using System.IO;
using Microsoft.AspNetCore.Http;
using ImageProcessor;
using ImageProcessor.Imaging.Formats;
using ClosedXML.Excel;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class VoucherController : ControllerBase
    {
        string voucherPath = @"\\10.10.10.100\dgnas\Files\VoucherImage";
        string voucherCodePath = @"\\10.10.10.100\dgnas\Files\VoucherImage\Code";

        string nasPath = @"\\10.10.10.100\dgnas\Files";

        // MMS 발송 프로시저 호출
        private async Task<string> _sendMMS(string subject, string phone, string callback, string msg, int file_cnt, string file_path_1, string file_path_2, string file_path_3, string system_id, string shop_cd, string for_shop_cd, int order_no)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_COUPON.INSERT_MMS",
            };

            cmd.Parameters.Add("in_subject", OracleDbType.Varchar2, 120).Value = subject;
            cmd.Parameters.Add("in_phone", OracleDbType.Varchar2, 15).Value = phone;
            cmd.Parameters.Add("in_callback", OracleDbType.Varchar2, 15).Value = callback;
            //cmd.Parameters.Add("in_reqdate", OracleDbType.Date).Value = reqdate;
            cmd.Parameters.Add("in_msg", OracleDbType.Varchar2, 4000).Value = msg;
            cmd.Parameters.Add("in_file_cnt", OracleDbType.Int16).Value = file_cnt;
            cmd.Parameters.Add("in_file_path_1", OracleDbType.Varchar2, 128).Value = file_path_1;
            cmd.Parameters.Add("in_file_path_2", OracleDbType.Varchar2, 128).Value = file_path_2;
            cmd.Parameters.Add("in_file_path_3", OracleDbType.Varchar2, 128).Value = file_path_3;
            cmd.Parameters.Add("in_system_id", OracleDbType.Varchar2, 64).Value = system_id;
            cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 32).Value = shop_cd;
            cmd.Parameters.Add("in_for_cccode", OracleDbType.Varchar2, 32).Value = for_shop_cd;
            cmd.Parameters.Add("in_order_seq", OracleDbType.Int16).Value = order_no;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher : _sendMMS", ex.Message);
                return "99";
            }

            return Rcode;
        }

        private ImageCodecInfo GetEncoderInfo(String mimeType)
        {
            int i;
            ImageCodecInfo[] encoders;
            encoders = ImageCodecInfo.GetImageEncoders();

            for (i = 0; i < encoders.Length; i++)
            {
                if (encoders[i].MimeType == mimeType)
                {
                    return encoders[i];
                }
            }

            return null;
        }


        //[HttpPost("sendVoucher")]
        //public async Task<string> sendVoucher(int price, string coupon_no, string mobile, string expire_date)
        //{
        //    string Rcode;
        //    string Rmsg = string.Empty;

        //    try
        //    {

        //        Image bitmap = (Image)Bitmap.FromFile($@"D:\IIS\mms_image\voucher.jpg");

        //        Graphics graphicsImage = Graphics.FromImage(bitmap);

        //        StringFormat stringFormat = new StringFormat();
        //        stringFormat.Alignment = StringAlignment.Far;
        //        stringFormat.LineAlignment = StringAlignment.Far;

        //        ImageCodecInfo imageCodecInfo = GetEncoderInfo("image/jpeg");

        //        Encoder encoder = Encoder.Quality;

        //        EncoderParameters encoderParameters = new EncoderParameters(1);
        //        EncoderParameter encoderParameter = new EncoderParameter(encoder, 86L);
        //        encoderParameters.Param[0] = encoderParameter;

        //        // 번호
        //        graphicsImage.DrawString($"No. {coupon_no}", new Font("arial", 40, FontStyle.Regular), new SolidBrush(Color.FromArgb(200, 255, 255, 255)), new Point(960, 160), stringFormat);
        //        // 금액
        //        graphicsImage.DrawString(string.Format("{0:#,0}", price), new Font("arial", 160, FontStyle.Regular), new SolidBrush(Color.FromArgb(255, 255, 255)), new Point(1000, 400), stringFormat);
        //        // 유효기간
        //        graphicsImage.DrawString($"{expire_date.Substring(0, 4)}.{expire_date.Substring(4, 2)}.{expire_date.Substring(6, 2)}", new Font("arial", 46, FontStyle.Regular), new SolidBrush(Color.FromArgb(200, 0, 0, 0)), new Point(990, 520), stringFormat);

        //        bitmap.Save(@$"D:\IIS\mms_image\voucher_{coupon_no}.jpg", imageCodecInfo, encoderParameters);

        //        //파일생성여부 체크
        //        FileInfo fi = new FileInfo(@$"D:\IIS\mms_image\voucher_{coupon_no}.jpg");
        //        for (int i = 0; i < 3; i++)
        //        {
        //            //1초 지연
        //            System.Threading.Thread.Sleep(1000);

        //            if (!fi.Exists)
        //            {
        //                Rmsg = Rmsg + " 1초 지연 ";
        //            }
        //        }

        //        string sResult = await _sendMMS("대구로 모바일 상품권", mobile, "0535550037", "대구로 모바일 상품권 발송입니다. 유효기한 내에 사용해주세요.", 1, $"http://mms.daeguro.co.kr:49000/voucher_{coupon_no}.jpg", "", "", "IS_DAEGU", "", "", 0);

        //        if (sResult.Equals("00"))
        //        {
        //            Rcode = "00";
        //            Rmsg = "성공";
        //        }
        //        else
        //        {
        //            Rcode = "99";
        //            Rmsg = "MMS 실패";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/Voucher/sendVoucher : POST", ex.Message == @"D:\IIS\mms_image\voucher.jpg" ? "해당 위치에 파일이 없습니다.":ex.Message );

        //        Rcode = ex.Message;
        //        Rmsg = ex.Message;
        //    }

        //    return Rcode;
        //}

        /// <summary>
        /// 상품권 검색용 목록
        /// </summary>
        /// <remarks>
        /// prsc_gbn : 처리 구분 (M: 무상제공(이벤트), A: 고객앱구매(주문), B: 기업판매(기업)) <br/>
        /// keyword : 상품권명 검색
        /// </remarks>
        [HttpGet("getVoucherNameList")]
        public async Task<IActionResult> getVoucherNameList(string prsc_gbn, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherNameList> items = new List<VoucherNameList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_VOUCHER_NAME_LIST",
            };

            cmd.Parameters.Add("in_prsc_gbn", OracleDbType.Varchar2, 1).Value = prsc_gbn;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 50).Value = keyword;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherNameList item = new VoucherNameList
                    {
                        prsc_gbn = rd["PRSC_GBN"].ToString(),
                        voucher_type = rd["VOUCHER_TYPE"].ToString(),
                        voucher_name = rd["VOUCHER_NAME"].ToString(),
                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getVoucherNameList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 모바일상품권 그룹코드 리스트 조회
        /// </summary>
        /// <remarks>
        /// prsc_gbn : 처리 구분 (M: 무상제공(이벤트), A: 고객앱구매(주문), B: 기업판매(기업)) <br/>
        /// test_yn: 테스트여부(Y/N)
        /// </remarks>
        [HttpGet("getGroupList")]
        public async Task<IActionResult> getGroupList(string prsc_gbn, string test_yn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("prsc_gbn", prsc_gbn);
            param.Add("test_yn", test_yn);

            string sql = @$"
                            select group_cd, group_name
                            from voucher_code_grp
                            where test_yn like case when :test_yn is null then '%' else :test_yn end
                            and prsc_gbn like case when :prsc_gbn is null then '%' else :prsc_gbn end
                            order by ins_date desc
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 모바일상품권 리스트 조회
        /// </summary>
        /// <remarks>
        /// prsc_gbn : 처리 구분 (M: 무상제공(이벤트), A: 고객앱구매(주문), B: 기업판매(기업)) <br />
        /// test_yn : 상품권 그룹의 테스트 여부 <br />
        /// group_cd : 상품권그룹 코드 <br />
        /// </remarks>
        [HttpGet("getVoucherList")]
        public async Task<IActionResult> getVoucherList(string prsc_gbn, string test_yn, string group_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("prsc_gbn", prsc_gbn);
            param.Add("test_yn", test_yn);
            param.Add("group_cd", group_cd);

            string sql = @$"
                            select voucher_type, voucher_name
                            from voucher_code_grp a, voucher_code_set b
                            where a.group_cd = b.group_cd
                            and a.test_yn like case when :test_yn is null then '%' else :test_yn end
                            and a.prsc_gbn like case when :prsc_gbn is null then '%' else :prsc_gbn end
                            and b.group_cd like case when :group_cd is null then '%' else :group_cd end
                            order by b.ins_date desc
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 모바일 상품권 목록 조회
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// test_yn : 상품권 그룹의 테스트 여부<br />
        /// prsc_gbn : 처리 구분 (M: 무상제공(이벤트), A: 고객앱구매(주문), B: 기업판매(기업)) <br />
        /// group_cd : 그룹 코드 <br />
        /// voucher_type : 상품권 코드 <br />
        /// status : 상태 (WT: 결제대기, NO: 미등록, ER: 등록기간만료,  CC: 결제취소,  US: 등록완료, UD: 사용완료, EP: 기간만료, RR: 환불요청, RC: 환불완료, DU: 회원탈퇴) <br />
        /// div : 검색조건 (1: 상품권번호, 2: 등록회원명, 3: 등록회원전화, 4: 구매번호, 5: 구매 회원명, 6: 구매 회원전화, 7: 수신자명, 8: 수신자 전화번호) <br />
        /// keyword : 검색키워드 <br />
        /// <br />
        /// 결과 값 <br />
        /// voucher_seq : 상품권 원장 pk값 <br />
        /// prsc_gbn : 처리 구분 <br />
        /// group_cd : 상품권 그룹코드 <br />
        /// group_name : 상품권 그룹명 <br />
        /// voucher_type : 상품권 코드 <br />
        /// voucher_name : 상품권명 <br />
        /// sale_no : 구매번호 <br />
        /// voucher_no : 상품권 번호 <br />
        /// voucher_amt : 상품권 액수 <br />
        /// voucher_remain_amt : 상품권 잔액 <br />
        /// status : 상태 <br />
        /// reg_date : 등록일자 <br />
        /// reg_exp_date : 등록유효기한 <br />
        /// use_exp_date : 사용유효기한 <br />
        /// ins_date : 발송날짜 <br />
        /// ins_ucode : 발송담당자 코드 <br />
        /// ins_name : 발송담당자명(회원구매일 경우 비공개) <br />
        /// cust_code : 등록회원 코드 <br />
        /// cust_telno : 등록회원 전화번호 <br />
        /// cust_name : 등록회원명 <br />
        /// receive_telno : 수신자 전화번호 <br />
        /// card_reciever : 수신자명 <br />
        /// buy_ccode : 구매자 회원번호 <br />
        /// buy_telno : 구매자 전화번호 <br />
        /// buy_name : 구매자 회원명 <br />
        /// refund_acc_yn : 환불계좌 정보 유무(Y/N)
        /// </remarks>
        [HttpGet()]
        public async Task<IActionResult> getList(string test_yn, string prsc_gbn, string group_cd, string voucher_type, string status, string div, string keyword, string page, string rows)
        {
            string Rcount = string.Empty;
            string Rwt = string.Empty;
            string Rno = string.Empty;
            string Rer = string.Empty;
            string Rcc = string.Empty;
            string Rus = string.Empty;
            string Rud = string.Empty;
            string Rep = string.Empty;
            string Rrr = string.Empty;
            string Rrc = string.Empty;
            string Rdu = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherList> items = new List<VoucherList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_LIST_V2",
            };

            cmd.Parameters.Add("in_test_yn", OracleDbType.Varchar2, 2).Value = test_yn;
            cmd.Parameters.Add("in_prsc_gbn", OracleDbType.Varchar2, 2).Value = prsc_gbn;
            cmd.Parameters.Add("in_group_cd", OracleDbType.Varchar2, 20).Value = group_cd;
            cmd.Parameters.Add("in_voucher_type", OracleDbType.Varchar2, 20).Value = voucher_type;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 4).Value = status;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 2).Value = div;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 100).Value = keyword;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_wt", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_no", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_er", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cc", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_us", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ud", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ep", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_rr", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_rc", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_du", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rwt = cmd.Parameters["out_wt"].Value.ToString();
                Rno = cmd.Parameters["out_no"].Value.ToString();
                Rer = cmd.Parameters["out_er"].Value.ToString();
                Rcc = cmd.Parameters["out_cc"].Value.ToString();
                Rus = cmd.Parameters["out_us"].Value.ToString();
                Rud = cmd.Parameters["out_ud"].Value.ToString();
                Rep = cmd.Parameters["out_ep"].Value.ToString();
                Rrr = cmd.Parameters["out_rr"].Value.ToString();
                Rrc = cmd.Parameters["out_rc"].Value.ToString();
                Rdu = cmd.Parameters["out_du"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherList m = new VoucherList
                    {
                        voucher_seq = rd["VOUCHER_SEQ"].ToString(),
                        group_cd = rd["group_cd"].ToString(),
                        group_name = rd["group_name"].ToString(),
                        prsc_gbn = rd["prsc_gbn"].ToString(),
                        voucher_type = rd["VOUCHER_TYPE"].ToString(),
                        voucher_name = rd["voucher_name"].ToString(),
                        sale_no = rd["sale_no"].ToString(),
                        voucher_no = rd["voucher_no"].ToString(),
                        voucher_amt = rd["voucher_amt"].ToString(),
                        voucher_remain_amt = rd["voucher_remain_amt"].ToString(),
                        status = rd["status"].ToString(),
                        reg_date = rd["reg_date"].ToString(),
                        reg_exp_date = rd["reg_exp_date"].ToString(),
                        use_exp_date = rd["use_exp_date"].ToString(),
                        cust_code = rd["cust_code"].ToString(),
                        cust_telno = rd["cust_telno"].ToString(),
                        cust_name = rd["cust_name"].ToString(),
                        receive_telno = rd["receive_telno"].ToString(),
                        card_reciever = rd["card_reciever"].ToString(),
                        buy_ccode = rd["buy_ccode"].ToString(),
                        buy_telno = rd["buy_telno"].ToString(),
                        buy_name = rd["buy_name"].ToString(),
                        refund_acc_yn = rd["refund_acc_yn"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["ins_name"].ToString(),
                        //mod_date = rd["mod_date"].ToString(),
                        //mod_ucode = rd["mod_ucode"].ToString(),
                        //mod_name = rd["mod_name"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, wt = Rwt, no = Rno, er = Rer, cc = Rcc, us = Rus, ud = Rud, ep = Rep, rr = Rrr, rc = Rrc, du = Rdu, data = items });
        }

        /// <summary>
        /// 모바일상품권 상세조회
        /// </summary>
        /// <remarks>
        /// voucher_name : 상품권명 <br/>
        /// voucher_no : 상품권번호 <br/>
        /// voucher_amt : 상품권액수 <br/>
        /// voucher_remain_amt : 상품권잔액 <br/>
        /// use_amt : 사용금액 <br/>
        /// refund_amt : 환불금액 <br/>
        /// reg_date : 등록일자 <br/>
        /// reg_exp_date : 등록유효기한 <br/>
        /// use_exp_date : 사용유효기한 <br/>
        /// send_date : 발송날짜 <br/>
        /// cust_code : 회원번호 <br/>
        /// cust_name : 회원명 <br/>
        /// cust_telno : 회원전화 <br/>
        /// bankname : 환불요청한 은행명 <br/>
        /// r_account : 환불요청한 계좌번호 <br/>
        /// <br/>
        /// hist[]  <br/>
        ///  - hist_seq : 변경이력pk <br/>
        ///  - hist_date : 변경일시 <br/>
        ///  - memo : 내용 <br/>
        /// </remarks>
        [HttpGet("{voucher_no}")]
        public async Task<IActionResult> getDetail(string voucher_no, string ucode)
        {
            string Rposition = "/Voucher/{voucher_no} : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_DETAIL",
            };

            cmd.Parameters.Add("in_voucher_no", OracleDbType.Varchar2, 100).Value = voucher_no;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor2", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            VoucherDetail item = new VoucherDetail();

            List<VoucherHist> subItems = new List<VoucherHist>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.voucher_name = rd["VOUCHER_NAME"].ToString();
                item.voucher_no = rd["VOUCHER_NO"].ToString();
                item.voucher_amt = rd["VOUCHER_AMT"].ToString();
                item.voucher_remain_amt = rd["VOUCHER_REMAIN_AMT"].ToString();
                item.use_amt = rd["use_amt"].ToString();
                item.refund_amt = rd["refund_amt"].ToString();
                item.reg_date = rd["REG_DATE"].ToString();
                item.reg_exp_date = rd["REG_EXP_DATE"].ToString();
                item.use_exp_date = rd["USE_EXP_DATE"].ToString();
                item.send_date = rd["SEND_DATE"].ToString();
                item.cust_code = rd["CUST_CODE"].ToString();
                item.cust_name = rd["CUST_NAME"].ToString();
                item.cust_telno = rd["CUST_TELNO"].ToString();
                item.bankname = rd["bankname"].ToString();
                item.r_account = rd["R_ACCOUNT"].ToString();

                await rd.NextResultAsync();

                while (await rd.ReadAsync())
                {
                    VoucherHist subItem = new VoucherHist
                    {
                        hist_seq = rd["HIST_SEQ"].ToString(),
                        hist_date = rd["HIST_DATE"].ToString(),
                        memo = rd["MEMO"].ToString(),

                    };

                    subItems.Add(subItem);
                }

                item.hist = subItems.ToArray();

                await rd.CloseAsync();
                await conn.CloseAsync();

                //조회 로그 기록
                await Utils.setPrivacyLog(ucode, "84", "10", item.voucher_no + " - 이름, 전화번호", Rposition);

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 발송시 선택가능한 카드 이미지 조회
        /// </summary>
        /// <remarks>
        /// 이미지 경로 : https://image.daeguro.co.kr:40443/voucher-images/{img_url} <br/>
        ///              https://image.daeguro.co.kr:40443/voucher-images/thumb/{img_url} <br/>
        /// type_gbn : 타입 구분 (M: 이벤트, B: 기업) <br/>
        /// <br/>
        /// [response body] <br/>
        /// 조건 : use_gbn = 'Y'/ type_gbn = {type_gbn} , 'O' <br/>
        /// 정렬 : type_gbn 정순, ins_date 역순 <br/>
        /// img_code : pk값 <br/>
        /// img_url : url <br/>
        /// </remarks>
        [HttpGet("getImgChoice")]
        public async Task<IActionResult> getImgChoice(string type_gbn)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherImgChoice> items = new List<VoucherImgChoice>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_IMG_CHOICE",
            };

            cmd.Parameters.Add("in_type_gbn", OracleDbType.Varchar2, 1).Value = type_gbn;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherImgChoice m = new VoucherImgChoice
                    {

                        img_code = rd["img_code"].ToString(),
                        img_url = rd["img_url"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getImgChoice : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 모바일상품권 지급(미사용)
        /// </summary>
        /// <remarks>
        /// 고객 전화번호를 배열로 받아 모바일상품권을 지급. <br/>
        /// [request body] <br/>
        /// voucher_type : 상품권 코드 <br/>
        /// reciever : 발행고객명 리스트 <br/>
        /// telno : 발행고객 전화번호 리스트 <br/>
        /// card_img : 카드 이미지 코드 <br/>
        /// card_msg : 카드 메시지 <br/>
        /// ucode : 생성자 ucode
        /// </remarks>
        [HttpPost("setVoucherAppCustomerOld")]
        public async Task<IActionResult> setVoucherAppCustomer(Voucher voucher)
        {
            string RvoucherNos = string.Empty;
            string RaleNo = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string sResult = string.Empty;

            string mms = string.Empty;

            BiztalkBtn btn = new BiztalkBtn();
            btn.name = "상품권 확인하기";
            btn.type = "AL"; //앱링크
            btn.scheme_android = "https://app.daeguro.co.kr/app/public_link.html?project=DELIVERY&action=ACTION_LINK_VOUCHER";
            btn.scheme_ios = "https://app.daeguro.co.kr/app/public_link.html?project=DELIVERY&action=ACTION_LINK_VOUCHER";

            List<string> s = new List<string>();

            List<SendBiztalk> items = new List<SendBiztalk>();
            List<SendBiztalk> send;

            ResultBiztalk result = new ResultBiztalk();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.SET_VOUCHER_APP_CUSTOMER",
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 1).Value = "1";//작업구분 ('1' 관리앱 발행/ '2' 모바일 앱 고객 구매)
            cmd.Parameters.Add("in_voucher_type", OracleDbType.Varchar2, 20).Value = voucher.voucher_type;
            cmd.Parameters.Add("in_buy_ccode", OracleDbType.Int32).Value = null;
            var reciever = cmd.Parameters.Add("in_reciever", OracleDbType.Varchar2, 300);
            reciever.Direction = ParameterDirection.Input;
            reciever.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            reciever.Value = voucher.reciever.ToArray();
            reciever.Size = voucher.reciever.Count();
            reciever.ArrayBindSize = voucher.reciever.Select(_ => _.Length).ToArray();
            reciever.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, voucher.reciever.Count()).ToArray();
            var telno = cmd.Parameters.Add("in_telno", OracleDbType.Varchar2, 20);
            telno.Direction = ParameterDirection.Input;
            telno.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            telno.Value = voucher.telno.ToArray();
            telno.Size = voucher.telno.Count();
            telno.ArrayBindSize = voucher.telno.Select(_ => _.Length).ToArray();
            telno.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, voucher.telno.Count()).ToArray();
            cmd.Parameters.Add("in_card_msg_yn", OracleDbType.Varchar2, 1).Value = "Y";
            cmd.Parameters.Add("in_card_img", OracleDbType.Varchar2, 8).Value = voucher.card_img;
            cmd.Parameters.Add("in_card_msg", OracleDbType.Varchar2, 500).Value = voucher.card_msg;
            cmd.Parameters.Add("in_ucode", OracleDbType.Varchar2, 8).Value = voucher.ucode;
            cmd.Parameters.Add("out_voucher_no", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_sale_no", OracleDbType.Int32).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                RvoucherNos = cmd.Parameters["out_voucher_no"].Value.ToString();
                RaleNo = cmd.Parameters["out_sale_no"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                string pre = DateTime.Now.ToString("yyMMdd") + "W001";

                if (rd.HasRows)
                {
                    while (await rd.ReadAsync())
                    {
                        s.Add(rd["seq"].ToString());

                        SendBiztalk m = new SendBiztalk
                        {

                            msgid = pre + rd["seq"].ToString().PadLeft(9, '0'),
                            message_type = "AT",
                            receiver_num = rd["receiver_telno"].ToString(),
                            message = "대구로 상품권이 도착했어요!\n\n" +
                                      rd["receiver_name"].ToString() + "님!\n\n" +
                                      rd["sender_name"].ToString() + "님이 대구로 상품권을 보냈어요.\n" +
                                 "아래 버튼을 클릭해, 지금 선물 받은 상품권을 등록해보세요!\n\n" +
                                 "※ 선물받은 상품권은 아래 링크에서 확인하세요.\n" +
                                 "※ 7일간 등록하지 않으면 " + rd["sender_name"].ToString() + "에게 상품권이 환불됩니다.",
                            template_code = "daeguro023",
                            reserved_time = "00000000000000",
                            button1 = btn
                        };

                        items.Add(m);
                    }
                }
                else
                {
                    await Utils.SaveErrorAsync("/Voucher : Post", Rmsg + " 카카오톡 로그를 제대로 불러오지 못했습니다.");
                    return Ok(new { code = "98", msg = "카카오톡 로그를 제대로 불러오지 못했습니다. 상품권 어드민 단체발송 내역을 확인해주세요." });
                }

                await rd.CloseAsync();

                await conn.CloseAsync();

                int num = 0;
                foreach(SendBiztalk i in items)
                {
                    send = new List<SendBiztalk>();
                    send.Add(i);
                    //카카오 비즈톡 발송
                    result = await sendBiztalk(send);
                    // 발송내역 업데이트
                    await setKakaoSend(s[num], result.result, result.message);

                    if (result.result != "0" && result.result != "102") //카카오톡 전송 실패시(전화번호 오류시 제외)
                    {
                        //SMS 전송...
                        mms = i.message + "\n\n" +
                             "https://app.daeguro.co.kr/app/public_link.html?project=DELIVERY&action=ACTION_LINK_VOUCHER";

                        sResult = await _sendMMS("대구로 상품권이 도착했어요!", i.receiver_num, "16613773", mms, 0, "", "", "", "IS_DAEGU", "", "", 0);

                        await setSmsSend(s[num], sResult);
                    }

                    num++;
                }

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = Rmsg + ex.Message;
                await Utils.SaveErrorAsync("/Voucher : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, voucher_no = RvoucherNos });
        }

        /// <summary>
        /// 모바일상품권 지급V2
        /// </summary>
        /// <remarks>
        /// 고객 전화번호를 배열로 받아 모바일상품권을 지급. <br/>
        /// [request body] <br/>
        /// voucher_type : 상품권 코드 <br/>
        /// reciever : 발행고객명 리스트 <br/>
        /// telno : 발행고객 전화번호 리스트 <br/>
        /// card_img : 카드 이미지 코드 <br/>
        /// card_msg : 카드 메시지 <br/>
        /// ucode : 생성자 ucode
        /// </remarks>
        [HttpPost("setVoucherAppCustomer")]
        public async Task<IActionResult> setVoucherAppCustomerV2(Voucher voucher)
        {
            string RvoucherNos = string.Empty;
            string RaleNo = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string sResult = string.Empty;

            string mms = string.Empty;

            List<string> s = new List<string>();

            List<SendBiztalk> items = new List<SendBiztalk>();
            List<SendBiztalk> send;

            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.SET_VOUCHER_APP_CUSTOMER",
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 1).Value = "1";//작업구분 ('1' 관리앱 발행/ '2' 모바일 앱 고객 구매)
            cmd.Parameters.Add("in_voucher_type", OracleDbType.Varchar2, 20).Value = voucher.voucher_type;
            cmd.Parameters.Add("in_buy_ccode", OracleDbType.Int32).Value = null;
            var reciever = cmd.Parameters.Add("in_reciever", OracleDbType.Varchar2, 300);
            reciever.Direction = ParameterDirection.Input;
            reciever.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            reciever.Value = voucher.reciever.ToArray();
            reciever.Size = voucher.reciever.Count();
            reciever.ArrayBindSize = voucher.reciever.Select(_ => _.Length).ToArray();
            reciever.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, voucher.reciever.Count()).ToArray();
            var telno = cmd.Parameters.Add("in_telno", OracleDbType.Varchar2, 20);
            telno.Direction = ParameterDirection.Input;
            telno.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            telno.Value = voucher.telno.ToArray();
            telno.Size = voucher.telno.Count();
            telno.ArrayBindSize = voucher.telno.Select(_ => _.Length).ToArray();
            telno.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, voucher.telno.Count()).ToArray();
            cmd.Parameters.Add("in_card_msg_yn", OracleDbType.Varchar2, 1).Value = "Y";
            cmd.Parameters.Add("in_card_img", OracleDbType.Varchar2, 8).Value = voucher.card_img;
            cmd.Parameters.Add("in_card_msg", OracleDbType.Varchar2, 500).Value = voucher.card_msg;
            cmd.Parameters.Add("in_ucode", OracleDbType.Varchar2, 8).Value = voucher.ucode;
            cmd.Parameters.Add("out_voucher_no", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_sale_no", OracleDbType.Int32).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                RvoucherNos = cmd.Parameters["out_voucher_no"].Value.ToString();
                RaleNo = cmd.Parameters["out_sale_no"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                foreach (string tel in voucher.telno)
                if (rd.HasRows)
                {

                    while (await rd.ReadAsync())
                    {
                            string seq = rd["seq"].ToString();
                            string recv_telno = rd["receiver_telno"].ToString();
                            string recv_name = rd["receiver_name"].ToString();
                            string send_name = rd["sender_name"].ToString();

                            result = await BiztalkHelper.BiztalkVoucherSend(int.Parse(seq), "50056", recv_telno, recv_name, send_name);

                        // 발송내역 업데이트
                        await setKakaoSend(seq, result.code, result.msg);

                        if (result.code != "0") //카카오톡 전송 실패시 확인필요
                        {
                            await Utils.SaveErrorAsync("/Voucher/BiztalkVoucherSend", result.code + " // " + result.msg);
                            //SMS 전송 루나톡 자체 문자발송 기능 이용함에따라 기존 sms 발송 주석처리
                            //mms = BiztalkHelper.Biztalk_50056(recv_name, send_name) + "\n\n" +
                            //     "https://app.daeguro.co.kr/app/public_link.html?project=DELIVERY&action=ACTION_LINK_VOUCHER";

                            //sResult = await _sendMMS("대구로 상품권이 도착했어요!", recv_telno, "16613773", mms, 0, "", "", "", "IS_DAEGU", "", "", 0);

                            //await setSmsSend(seq, sResult);
                        }
                    }
                }
                else
                {
                    await Utils.SaveErrorAsync("/Voucher : Post", Rmsg + " 카카오톡 로그를 제대로 불러오지 못했습니다.");
                    return Ok(new { code = "98", msg = "카카오톡 로그를 제대로 불러오지 못했습니다. 상품권 어드민 단체발송 내역을 확인해주세요." });
                }

                await rd.CloseAsync();

                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = Rmsg + ex.Message;
                await Utils.SaveErrorAsync("/Voucher : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, voucher_no = RvoucherNos });
        }

        /// <summary>
        /// 비즈톡 발송(기존)
        /// </summary>
        [HttpPost("sendBiztalk")]
        public async Task<ResultBiztalk> sendBiztalk(List<SendBiztalk> send)
        {
            //string url = @$"http://192.168.30.131:23785/BiztalkSend";
            string url = @$"http://172.17.30.102:23785/BiztalkSend"; //109,110용 url
            
            
            HttpClient httpClient = new HttpClient();

            ResultBiztalk result = new ResultBiztalk();

            try
            {
                var payload = send;

                var stringPayload = JsonConvert.SerializeObject(payload);

                HttpContent httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");

                HttpResponseMessage httpResponse = await httpClient.PostAsync(url, httpContent);

                string responseStr = await httpResponse.Content.ReadAsStringAsync();
                result = JsonConvert.DeserializeObject<ResultBiztalk>(responseStr);

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("Voucher/sendBiztalk : Post", ex.Message);
                result.result = "90";
                result.message = ex.Message;
                return result;
            }

            return result;
        }

        /// <summary>
        /// 카카오톡 발송내역 기록
        /// </summary>
        [HttpPut("setKakaoSend")]
        public async Task<IActionResult> setKakaoSend(string seq, string result_code, string result_msg)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.SET_KAKAO_SEND",
            };

            cmd.Parameters.Add("in_seq", OracleDbType.Int32).Value = seq;
            cmd.Parameters.Add("in_result_code", OracleDbType.Varchar2, 2).Value = result_code;
            cmd.Parameters.Add("in_result_msg", OracleDbType.Varchar2, 200).Value = result_msg;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();

                if (Rcode != "00")
                {
                    await Utils.SaveErrorAsync("/Voucher/setKakaoSend : Put", Rcode + " : " + Rmsg);
                }
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/setKakaoSend : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 문자발송 기록
        /// </summary>
        [HttpPut("setSmsSend")]
        public async Task<IActionResult> setSmsSend(string seq, string sms_result)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.SET_SMS_SEND",
            };

            cmd.Parameters.Add("in_seq", OracleDbType.Int32).Value = seq;
            cmd.Parameters.Add("in_result_code", OracleDbType.Varchar2, 2).Value = sms_result;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/setKakaoSend : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        #region [환불관리]
        /// <summary>
        /// 환불계좌정보 조회
        /// </summary>
        /// <remarks>
        /// account : 환불 계좌번호 <br/>
        /// bankcode : 은행코드 <br/>
        /// bankname : 은행명 <br/>
        /// acc_owner : 계좌예금주 <br/>
        /// </remarks>
        [HttpGet("getRefund")]
        public async Task<IActionResult> getRefund(string cust_code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            VoucherRefundData voucherRefundData = new VoucherRefundData();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_REFUND_ACC",
            };

            cmd.Parameters.Add("in_cust_code", OracleDbType.Int32).Value = cust_code;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;



            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    voucherRefundData.account = rd["refund_account"].ToString();
                    voucherRefundData.bankcode = rd["bankcode"].ToString();
                    voucherRefundData.bankname = rd["bankname"].ToString();
                    voucherRefundData.acc_owner = rd["acc_owner"].ToString();
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getRefund : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = voucherRefundData });
        }

        /// <summary>
        /// 모바일상품권 환불요청(계좌 검증X)
        /// </summary>
        /// <remarks>
        /// voucher_no : 상품권번호 <br/>
        /// refund_amt : 환불요청금액(수수료 200원 제외한 잔액) <br/>
        /// account : 환불받을 계좌번호 <br/>
        /// bankcode : 은행코드 <br/>
        /// acc_owner : 계좌예금주 <br/>
        /// * 환불은 1회만 가능 <br/>
        /// * 이벤트 상품권(prsc_gbn = M) 환불불가 <br/>
        /// * 만원이하 상품권은 금액의 80%이상 사용시 환불가능 <br/>
        /// * 만원초과 상품권은 금액의 60%이상 사용시 환불가능 <br/>
        /// * 잔액이 수수료 200원 보다 적은 경우 환불불가 <br/>
        /// </remarks>
        [HttpPost("setRefundReq")]
        public async Task<IActionResult> setRefundReq(VoucherRefund refund)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.SET_REFUND_REQ",
            };

            cmd.Parameters.Add("in_req_gbn", OracleDbType.Varchar2, 1).Value = "C";//환불접수경로 구분(C 관리앱/ A 주문앱)
            cmd.Parameters.Add("in_voucher_no", OracleDbType.Varchar2, 50).Value = refund.voucher_no;
            cmd.Parameters.Add("in_refund_amt", OracleDbType.Int32).Value = refund.refund_amt;
            cmd.Parameters.Add("in_account", OracleDbType.Varchar2, 100).Value = refund.account;
            cmd.Parameters.Add("in_bankcode", OracleDbType.Varchar2, 2).Value = refund.bankcode;
            cmd.Parameters.Add("in_acc_owner", OracleDbType.Varchar2, 100).Value = refund.acc_owner;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 1000).Value = null;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = refund.ucode;
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 200).Value = refund.uname;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;



            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/setRefundReq : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 모바일상품권 환불요청 목록 조회
        /// </summary>
        /// <remarks>
        /// [parameter] <br/>
        /// date_begin - date_end : 요청일 기준 <br/>
        /// status : 처리 상태 (RR:환불요청, RC:환불완료) <br/>
        /// keyword : 검색조건(회원코드 or 회원명) <br/>
        /// <br/>
        /// [response] <br/>
        /// refund_seq : pk값  <br/>
        /// cust_code : 회원번호 <br/>
        /// cust_name : 회원명 <br/>
        /// voucher_no : 상품권 번호 <br/>
        /// r_req_dt : 요청일 <br/>
        /// r_comp_dt : 처리일 <br/>
        /// r_amt : 환불요청금액 <br/>
        /// acc_owner : 환불계좌 예금주명 <br/>
        /// bankcode : 환불계좌 은행코드 <br/>
        /// bankname : 환불계좌 은행명 <br/>
        /// r_account : 환불계좌번호 <br/>
        /// status : 처리구분 <br/>
        /// result_msg : 결과메시지 <br/>
        /// r_req_gbn : 접수경로 구분(관리앱/주문앱) <br/>
        /// </remarks>
        [HttpGet("getRefundList")]
        public async Task<IActionResult> getRefundList(string date_begin, string date_end, string status, string keyword, string page, string rows)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherRefundList> items = new List<VoucherRefundList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_REFUND_LIST",
            };

            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 2).Value = status;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherRefundList m = new VoucherRefundList
                    {
                        refund_seq = rd["refund_seq"].ToString(),
                        cust_code = rd["cust_code"].ToString(),
                        cust_name = rd["cust_name"].ToString(),
                        voucher_no = rd["voucher_no"].ToString(),
                        r_req_dt = rd["r_req_dt"].ToString(),
                        r_comp_dt = rd["r_comp_dt"].ToString(),
                        r_amt = rd["r_amt"].ToString(),
                        acc_owner = rd["acc_owner"].ToString(),
                        bankcode = rd["bankcode"].ToString(),
                        bankname = rd["bankname"].ToString(),
                        r_account = rd["r_account"].ToString(),
                        status = rd["status"].ToString(),
                        r_req_gbn = rd["r_req_gbn"].ToString(),
                        result_msg = rd["result_msg"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getRefundList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }
        #endregion

        #region [상품권 그룹코드 관리]
        /// <summary>
        /// 모바일상품권 그룹코드 리스트 조회
        /// </summary>
        /// <remarks>
        /// seq : pk값  <br/>
        /// group_cd : 그룹코드 <br/>
        /// group_name : 그룹코드명 <br/>
        /// prsc_gbn : 처리 구분 <br/>
        /// memo : 메모 <br/>
        /// use_yn : 사용구분(Y/N) <br/>
        /// </remarks>
        [HttpGet("getGroupCodeList")]
        public async Task<IActionResult> getGroupCodeList(string use_yn, string test_yn)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherGroupList> items = new List<VoucherGroupList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_GROUP_CODE_LIST",
            };

            cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 2).Value = use_yn;
            cmd.Parameters.Add("in_test_yn", OracleDbType.Varchar2, 2).Value = test_yn;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherGroupList m = new VoucherGroupList
                    {
                        seq = rd["seq"].ToString(),
                        group_cd = rd["group_cd"].ToString(),
                        group_name = rd["group_name"].ToString(),
                        prsc_gbn = rd["prsc_gbn"].ToString(),
                        memo = rd["memo"].ToString(),
                        use_yn = rd["use_yn"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["ins_name"].ToString(),
                        mod_date = rd["mod_date"].ToString(),
                        mod_ucode = rd["mod_ucode"].ToString(),
                        mod_name = rd["mod_name"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getGroupCodeList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 모바일상품권 그룹코드 상세조회
        /// </summary>
        /// <remarks>
        /// seq : pk값  <br/>
        /// prsc_gbn : 처리 구분 (M: 무상제공(이벤트), A: 고객앱구매(주문), B: 기업판매(기업)) <br/>
        /// use_yn : 사용구분(Y/N) <br/>
        /// test_yn : 테스트구분(Y/N) <br/>
        /// group_cd : 그룹코드 <br/>
        /// group_name : 그룹코드명 <br/>
        /// memo : 메모 <br/>
        /// </remarks>
        [HttpGet("getGroupCodeDetail/{seq}")]
        public async Task<IActionResult> getGroupCodeDetail(string seq)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            VoucherGroupDetail item = new VoucherGroupDetail();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_GROUP_CODE_DETAIL",
            };

            cmd.Parameters.Add("in_seq", OracleDbType.Varchar2, 20).Value = seq;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.seq = rd["seq"].ToString();
                item.use_yn = rd["use_yn"].ToString();
                item.test_yn = rd["test_yn"].ToString();
                item.group_cd = rd["group_cd"].ToString();
                item.group_name = rd["group_name"].ToString();
                item.prsc_gbn = rd["prsc_gbn"].ToString();
                item.memo = rd["memo"].ToString();
                item.ins_date = rd["ins_date"].ToString();
                item.ins_ucode = rd["ins_ucode"].ToString();
                item.ins_name = rd["ins_name"].ToString();
                item.mod_date = rd["mod_date"].ToString();
                item.mod_ucode = rd["mod_ucode"].ToString();
                item.mod_name = rd["mod_name"].ToString();
                    
                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getGroupCodeDetail/{seq} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 모바일상품권 그룹코드 생성
        /// </summary>
        /// <remarks>
        /// [request body] <br/>
        /// seq : pk값 (put only) <br/>
        /// prsc_gbn : 처리 구분 (M: 무상제공(이벤트), A: 고객앱구매(주문), B: 기업판매(기업)) <br/>
        /// use_yn : 사용구분(Y/N) <br/>
        /// test_yn : 테스트구분(Y/N) <br/>
        /// group_name : 그룹코드명 <br/>
        /// memo : 메모 <br/>
        /// ucode : 생성자 ucode <br/>
        /// </remarks>
        [HttpPost("setGroupCode")]
        public async Task<IActionResult> setGroupCode(VoucherGroup group)
        { 
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            DynamicParameters param = new DynamicParameters();

            string sql = string.Empty;

            db.Open();

            try
            {
                param.Add("prsc_gbn", group.prsc_gbn);
                param.Add("use_yn", group.use_yn);
                param.Add("test_yn", group.test_yn);
                param.Add("group_name", group.group_name);
                param.Add("memo", group.memo);
                param.Add("ucode", group.ucode);

                sql = @"select count(*) from voucher_code_grp where group_name = :group_name";

                int num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                if (num > 0)
                {
                    Rcode = "99";
                    Rmsg = "동일한 그룹명이 이미 존재합니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                sql = @"insert into voucher_code_grp(prsc_gbn, use_yn, test_yn, group_cd, group_name, memo, ins_ucode, ins_date)
                        values(:prsc_gbn, :use_yn, :test_yn,(select 'VG' || last_number
                                                            from user_sequences
                                                            where sequence_name = 'VOUCHER_CODE_GRP_SEQ'), :group_name, :memo, :ucode, sysdate)";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Voucher/setGroupCode : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 모바일상품권 그룹코드 수정
        /// </summary>
        /// <remarks>
        /// * 하위 상품권 코드가 존재하는 경우 처리구분을 수정할수 없다 <br/>
        /// * 테스트여부 수정가능, 23.07.10 작업<br/>
        /// [request body] <br/>
        /// seq : pk값 (put only) <br/>
        /// prsc_gbn : 처리 구분 (M: 무상제공(이벤트), A: 고객앱구매(주문), B: 기업판매(기업)) <br/>
        /// use_yn : 사용구분(Y/N) <br/>
        /// test_yn : 테스트구분(Y/N) <br/>
        /// group_name : 그룹코드명 <br/>
        /// memo : 메모 <br/>
        /// ucode : 수정자 ucode <br/>
        /// </remarks>
        [HttpPut("updateGroupCode")]
        public async Task<IActionResult> updateGroupCode(VoucherGroup group)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            DynamicParameters param = new DynamicParameters();

            string sql = string.Empty;

            db.Open();

            try
            {
                param.Add("seq", group.seq);
                param.Add("prsc_gbn", group.prsc_gbn);
                param.Add("use_yn", group.use_yn);
                param.Add("test_yn", group.test_yn);
                param.Add("group_name", group.group_name);
                param.Add("memo", group.memo);
                param.Add("ucode", group.ucode);

                sql = @"select count(*) from voucher_code_grp where group_name = :group_name and seq <> :seq";

                int num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                if (num > 0)
                {
                    Rcode = "99";
                    Rmsg = "동일한 그룹명이 이미 존재합니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                sql = @"SELECT COUNT(*)
                        FROM VOUCHER_CODE_SET
                        WHERE GROUP_CD = (select group_cd 
                                          from voucher_code_grp 
                                          where seq = :seq
                                          and prsc_gbn <> :prsc_gbn)";

                num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                if (num > 0)
                {
                    Rcode = "99";
                    Rmsg = "하위 상품권 코드가 존재하는 경우 처리구분을 수정할수 없습니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                sql = @"update voucher_code_grp
                        set prsc_gbn = :prsc_gbn, 
                            use_yn = :use_yn, 
                            test_yn = :test_yn, 
                            group_name = :group_name, 
                            memo = :memo,
                            mod_ucode = :ucode,
                            mod_date = sysdate
                        where seq = :seq";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Voucher/updateGroupCode : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion

        #region [상품권 코드 관리]
        /// <summary>
        /// 모바일상품권코드 리스트 조회
        /// </summary>
        /// <remarks>
        /// group_cd 그룹코드(필수) <br/>
        /// [response] <br/>
        /// seq : pk값  <br/>
        /// group_cd : 그룹코드 <br/>
        /// group_name : 그룹명 <br/>
        /// voucher_type : 상품권 코드 <br/>
        /// voucher_name : 상품권명 <br/>
        /// memo : 메모 <br/>
        /// use_yn : 사용구분(Y/N) <br/>
        /// voucher_amt : 상품권 금액 <br/>
        /// voucher_notice : 유의사항 <br/>
        /// </remarks>
        [HttpGet("getCodeList")]
        public async Task<IActionResult> getCodeList(string group_cd, string use_yn, string test_yn)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherCodeList> items = new List<VoucherCodeList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_CODE_LIST",
            };

            cmd.Parameters.Add("in_group_cd", OracleDbType.Varchar2, 20).Value = group_cd;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 2).Value = use_yn;
            cmd.Parameters.Add("in_test_yn", OracleDbType.Varchar2, 2).Value = test_yn;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherCodeList m = new VoucherCodeList
                    {
                        seqno = rd["seqno"].ToString(),
                        group_cd = rd["group_cd"].ToString(),
                        group_name = rd["group_name"].ToString(),
                        voucher_type = rd["voucher_type"].ToString(),
                        voucher_name = rd["voucher_name"].ToString(),
                        memo = rd["memo"].ToString(),
                        use_yn = rd["use_yn"].ToString(),
                        voucher_amt = rd["voucher_amt"].ToString(),
                        voucher_notice = rd["voucher_notice"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["ins_name"].ToString(),
                        mod_date = rd["mod_date"].ToString(),
                        mod_ucode = rd["mod_ucode"].ToString(),
                        mod_name = rd["mod_name"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getCodeList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 모바일상품권 코드 상세조회
        /// </summary>
        /// <remarks>
        /// seqno : pk값  <br/>
        /// group_cd : 상품권 그룹코드 <br/>
        /// use_yn : 사용구분(Y/N) <br/>
        /// voucher_type : 상품권 코드 <br/>
        /// voucher_name : 상품권명 <br/>
        /// voucher_amt : 상품권 금액 <br/>
        /// promotion_yn : 할인판매여부(Y/N) <br/>
        /// budget : 할인판매 예산 <br/>
        /// disc_gbn : 할인타입구분 (1: 정액, 3: 정율) <br/>
        /// disc_range : 할인 범위 (비율 또는 액수 입력) <br/>
        /// voucher_notice : 유의사항 <br/>
        /// thumb_url : 이미지 url <br/>
        /// (원본경로 : https://image.daeguro.co.kr:40443/voucher-images/code/{thumb_url} ) <br/>
        /// (썸네일경로 : https://image.daeguro.co.kr:40443/voucher-images/code/thumb/{thumb_url} ) <br/>
        /// memo : 메모 <br/>
        /// </remarks>
        [HttpGet("getCodeDetail/{seqno}")]
        public async Task<IActionResult> getCodeDetail(string seqno)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            VoucherCodeDetail item = new VoucherCodeDetail();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_CODE_DETAIL",
            };

            cmd.Parameters.Add("in_seqno", OracleDbType.Int32).Value = seqno;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.seqno = rd["seqno"].ToString();
                item.group_cd = rd["group_cd"].ToString();
                item.use_yn = rd["use_yn"].ToString();
                item.voucher_type = rd["voucher_type"].ToString();
                item.voucher_name = rd["voucher_name"].ToString();
                item.voucher_amt = rd["voucher_amt"].ToString();
                item.promotion_yn = rd["promotion_yn"].ToString();
                item.budget = rd["budget"].ToString();
                item.disc_gbn = rd["disc_gbn"].ToString();
                item.disc_range = rd["disc_range"].ToString();
                item.voucher_notice = rd["voucher_notice"].ToString();
                item.thumb_url = rd["thumb_url"].ToString();
                item.memo = rd["memo"].ToString();
                item.ins_date = rd["ins_date"].ToString();
                item.ins_ucode = rd["ins_ucode"].ToString();
                item.ins_name = rd["ins_name"].ToString();
                item.mod_date = rd["mod_date"].ToString();
                item.mod_ucode = rd["mod_ucode"].ToString();
                item.mod_name = rd["mod_name"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getCodeDetail/{seqno} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 모바일상품권 코드 생성
        /// </summary>
        /// <remarks>
        /// [request body] <br/>
        /// seqno : pk값 (put only) <br/>
        /// group_cd : 상품권 그룹코드 <br/>
        /// use_yn : 사용구분(Y/N) <br/>
        /// voucher_name : 상품권명 <br/>
        /// voucher_amt : 상품권 금액 <br/>
        /// promotion_yn : 할인판매여부(Y/N) <br/>
        /// budget : 할인판매 예산 <br/>
        /// disc_gbn : 할인타입구분 (1: 정액, 3: 정율) <br/>
        /// disc_range : 할인 범위 (비율 또는 액수 입력) <br/>
        /// voucher_notice : 유의사항 <br/>
        /// memo : 메모 <br/>
        /// ucode : 생성자 ucode <br/>
        /// formFile : IFormFile 타입 이미지 파일(png) <br/>
        /// </remarks>
        [HttpPost("setCode")]
        public async Task<IActionResult> setCode(IFormFile formFile, [FromForm] VoucherCode code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string thumb_url = string.Empty;

            try
            {

                if (formFile != null && formFile.Length > 0)
                {
                    Rmsg = "NAS서버 연결이 필요합니다.";

                    using (new ConnectToSharedFolder(nasPath))
                    {
                        ResultPlus result = await setCodeData(code, "Y");
                        thumb_url = result.item + ".png";

                        if (result.code.Equals("00"))
                        {
                            // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!

                            string folerPath = voucherCodePath;

                            if (Directory.Exists(folerPath) == false)
                            {
                                Directory.CreateDirectory(folerPath);
                            }

                            //썸네일 폴더
                            if (Directory.Exists(folerPath + "\\Thumb") == false)
                            {
                                Directory.CreateDirectory(folerPath + "\\Thumb");
                            }

                            // 파일이 이미 존재하면 삭제한다.
                            if (System.IO.File.Exists(folerPath + "\\" + thumb_url))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPath + "\\" + thumb_url);
                            }

                            //누겟 imageProcessor 필요
                            using (ImageFactory imageFactory = new ImageFactory(preserveExifData: true))
                            {
                                var ima = imageFactory.Load(formFile.OpenReadStream()).Image;
                                int isizeW = 1280;
                                int isizeH = 720;
                                int quality = 100;

                                //오리지널 저장(w:1280/h:720/q:100)
                                if (ima.Width > ima.Height)
                                {
                                    if (ima.Width < 1280)
                                    {
                                        isizeW = ima.Width;
                                    }

                                    var ratio = (float)ima.Height / ima.Width;

                                    imageFactory.Load(formFile.OpenReadStream())
                                        .Format(new PngFormat())
                                        .Resize(new Size(isizeW, (int)(isizeW * ratio)))
                                        .Quality(quality)
                                        .Save(folerPath + "\\" + thumb_url)
                                        .Quality(72)
                                        .Save(folerPath + "\\Thumb\\" + thumb_url);
                                }
                                else
                                {
                                    if (ima.Height < 720)
                                    {
                                        isizeH = ima.Height;
                                    }

                                    var ratio = (float)ima.Width / ima.Height;

                                    imageFactory.Load(formFile.OpenReadStream())
                                        .Format(new PngFormat())
                                        .Resize(new Size((int)(isizeH * ratio), isizeH))
                                        .Quality(quality)
                                        .Save(folerPath + "\\" + thumb_url)
                                        .Quality(72)
                                        .Save(folerPath + "\\Thumb\\" + thumb_url);
                                }


                            }

                        }

                        Rcode = result.code;
                        Rmsg = result.msg;
                    }



                    // Jpg 포맷으로 변환한다.

                    //using Image img = Image.FromFile(folerPath + "\\" + formFile.FileName);

                    //img.Save(folerPath + "\\" + fileName, System.Drawing.Imaging.ImageFormat.Jpeg);

                    //img.Dispose();

                    //System.IO.File.Delete(folerPath + "\\" + formFile.FileName);

                }
                else
                {

                    ResultPlus result = await setCodeData(code, "N");

                    Rcode = result.code;
                    Rmsg = result.msg;
                }


            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/Voucher/setCode : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        private async Task<ResultPlus> setCodeData(VoucherCode code, string thumb_yn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            ResultPlus result = new ResultPlus();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            DynamicParameters param = new DynamicParameters();

            string sql = string.Empty;

            int num;

            db.Open();

            try
            {
                param.Add("group_cd", code.group_cd);
                param.Add("use_yn", code.use_yn);
                param.Add("voucher_name", code.voucher_name);
                param.Add("voucher_amt", code.voucher_amt);
                param.Add("promotion_yn", code.promotion_yn);
                param.Add("budget", code.budget);
                param.Add("disc_gbn", code.disc_gbn);
                param.Add("disc_range", code.disc_range);
                param.Add("voucher_notice", code.voucher_notice);
                param.Add("memo", code.memo);
                param.Add("ucode", code.ucode);

                param.Add("thumb_yn", thumb_yn);

                sql = @"select count(*) from voucher_code_grp where group_cd = :group_cd";

                num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                if (num == 0)
                {
                    result.code = "99";
                    result.msg = "존재하지 않는 상품권 그룹입니다.";
                    return result;
                }

                sql = @"select count(*) from voucher_code_set where voucher_name = :voucher_name";

                num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                if (num > 0)
                {
                    result.code = "99";
                    result.msg = "동일한 상품권명이 이미 존재합니다.";
                    return result;
                }

                sql = @"select 'VT' || last_number
                        from user_sequences
                        where sequence_name = 'VOUCHER_CODE_SET_SEQ'";

                result.item = await db.QuerySingleAsync<string>(sql, param, commandType: CommandType.Text);

                param.Add("voucher_type", result.item);

                sql = @"insert into voucher_code_set(group_cd, 
                                                     use_yn, 
                                                     voucher_type, 
                                                     voucher_name, 
                                                     voucher_amt, 
                                                     promotion_yn, 
                                                     budget, 
                                                     disc_gbn, 
                                                     disc_range, 
                                                     thumb_url, 
                                                     voucher_notice, 
                                                     memo, 
                                                     ins_ucode, 
                                                     ins_date)
                        values(:group_cd, 
                               :use_yn, 
                               :voucher_type, 
                               :voucher_name, 
                               :voucher_amt, 
                               :promotion_yn, 
                               :budget, 
                               :disc_gbn, 
                               :disc_range, 
                               case when :thumb_yn = 'Y' then 
                                        :voucher_type || '.png' end, 
                               :voucher_notice, 
                               :memo, 
                               :ucode, 
                               sysdate)";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                result.code = "00";
                result.msg = "성공";

            }
            catch (Exception ex)
            {
                result.code = "99";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync("/Voucher/setCodeData : Post", ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 모바일상품권 코드 수정
        /// </summary>
        /// <remarks>
        /// * 생성된 상품권이 존재하는 경우 상품권 금액을 수정할수 없다 <br/>
        /// * 할인예산 수정시 기존 할인총액 미만으로 수정할수 없다 <br/>
        /// [request body] <br/>
        /// seqno : pk값 (put only) <br/>
        /// group_cd : 상품권 그룹코드 <br/>
        /// use_yn : 사용구분(Y/N) <br/>
        /// voucher_name : 상품권명 <br/>
        /// voucher_amt : 상품권 금액 <br/>
        /// promotion_yn : 할인판매여부(Y/N) <br/>
        /// budget : 할인판매 예산 <br/>
        /// disc_gbn : 할인타입구분 (1: 정액, 3: 정율) <br/>
        /// disc_range : 할인 범위 (비율 또는 액수 입력) <br/>
        /// voucher_notice : 유의사항 <br/>
        /// memo : 메모 <br/>
        /// ucode : 수정자 ucode <br/>
        /// formFile : IFormFile 타입 이미지 파일(png) <br/>
        /// </remarks>
        [HttpPut("updateCode")]
        public async Task<IActionResult> updateCode(IFormFile formFile, [FromForm] VoucherCode code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string thumb_url = string.Empty;

            try
            {

                if (formFile != null && formFile.Length > 0)
                {
                    Rmsg = "NAS서버 연결이 필요합니다.";

                    using (new ConnectToSharedFolder(nasPath))
                    {
                        ResultPlus result = await updateCodeData(code, "Y");
                        thumb_url = result.item;

                        if (result.code.Equals("00"))
                        {
                            // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!

                            string folerPath = voucherCodePath;

                            if (Directory.Exists(folerPath) == false)
                            {
                                Directory.CreateDirectory(folerPath);
                            }

                            //썸네일 폴더
                            if (Directory.Exists(folerPath + "\\Thumb") == false)
                            {
                                Directory.CreateDirectory(folerPath + "\\Thumb");
                            }

                            // 파일이 이미 존재하면 삭제한다.
                            if (System.IO.File.Exists(folerPath + "\\" + thumb_url))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPath + "\\" + thumb_url);
                            }

                            //누겟 imageProcessor 필요
                            using (ImageFactory imageFactory = new ImageFactory(preserveExifData: true))
                            {
                                var ima = imageFactory.Load(formFile.OpenReadStream()).Image;
                                int isizeW = 1280;
                                int isizeH = 720;
                                int quality = 100;

                                //오리지널 저장(w:1280/h:720/q:100)
                                if (ima.Width > ima.Height)
                                {
                                    if (ima.Width < 1280)
                                    {
                                        isizeW = ima.Width;
                                    }

                                    var ratio = (float)ima.Height / ima.Width;

                                    imageFactory.Load(formFile.OpenReadStream())
                                        .Format(new PngFormat())
                                        .Resize(new Size(isizeW, (int)(isizeW * ratio)))
                                        .Quality(quality)
                                        .Save(folerPath + "\\" + thumb_url)
                                        .Quality(72)
                                        .Save(folerPath + "\\Thumb\\" + thumb_url);
                                }
                                else
                                {
                                    if (ima.Height < 720)
                                    {
                                        isizeH = ima.Height;
                                    }

                                    var ratio = (float)ima.Width / ima.Height;

                                    imageFactory.Load(formFile.OpenReadStream())
                                        .Format(new PngFormat())
                                        .Resize(new Size((int)(isizeH * ratio), isizeH))
                                        .Quality(quality)
                                        .Save(folerPath + "\\" + thumb_url)
                                        .Quality(72)
                                        .Save(folerPath + "\\Thumb\\" + thumb_url);
                                }


                            }

                        }

                        Rcode = result.code;
                        Rmsg = result.msg;
                    }



                    // Jpg 포맷으로 변환한다.

                    //using Image img = Image.FromFile(folerPath + "\\" + formFile.FileName);

                    //img.Save(folerPath + "\\" + fileName, System.Drawing.Imaging.ImageFormat.Jpeg);

                    //img.Dispose();

                    //System.IO.File.Delete(folerPath + "\\" + formFile.FileName);

                }
                else
                {

                    ResultPlus result = await updateCodeData(code, "N");

                    Rcode = result.code;
                    Rmsg = result.msg;
                }


            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/Voucher/updateCode : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        private async Task<ResultPlus> updateCodeData(VoucherCode code, string thumb_yn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            ResultPlus result = new ResultPlus();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            DynamicParameters param = new DynamicParameters();

            string sql = string.Empty;

            int num;

            db.Open();

            try
            {
                param.Add("seqno", code.seqno);
                param.Add("group_cd", code.group_cd);
                param.Add("use_yn", code.use_yn);
                param.Add("voucher_name", code.voucher_name);
                param.Add("voucher_amt", code.voucher_amt);
                param.Add("promotion_yn", code.promotion_yn);
                param.Add("budget", code.budget);
                param.Add("disc_gbn", code.disc_gbn);
                param.Add("disc_range", code.disc_range);
                param.Add("voucher_notice", code.voucher_notice);
                param.Add("memo", code.memo);
                param.Add("ucode", code.ucode);

                param.Add("thumb_yn", thumb_yn);

                sql = @"select count(*) from voucher_code_grp where group_cd = :group_cd";

                num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                if (num == 0)
                {
                    result.code = "99";
                    result.msg = "존재하지 않는 상품권 그룹입니다.";
                    return result;
                }

                sql = @"select count(*) from voucher_code_set where voucher_name = :voucher_name and seqno <> :seqno";

                num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                if (num > 0)
                {
                    result.code = "99";
                    result.msg = "동일한 상품권명이 이미 존재합니다.";
                    return result;
                }

                sql = @"SELECT COUNT(*)
                        FROM VOUCHER_MST
                        WHERE voucher_type = (select voucher_type from VOUCHER_CODE_SET where seqno = :seqno and voucher_amt <> :voucher_amt)";

                num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                if (num > 0)
                {
                    result.code = "99";
                    result.msg = "생성된 상품권이 존재하는 경우 상품권 금액을 수정할수 없습니다.";
                    return result;
                }

                sql = @"select voucher_type from VOUCHER_CODE_SET where seqno = :seqno";

                result.item = await db.QuerySingleAsync<string>(sql, param, commandType: CommandType.Text);
                param.Add("voucher_type", result.item);
                result.item = result.item + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".png";
                param.Add("in_thumb_url", result.item);

                // 할인예산 수정시 기존 할인금액을 계산해서 그 아래로는 설정못하게 막을 필요가 있음/ 오픈후 작업예정
                //if (code.promotion_yn == "Y" && code.budget != null)
                //{
                //    sql = @"select nvl(sum(b.disc_amt),0)
                //            from voucher_sales a, voucher_mst b
                //            where a.sale_no = b.sale_no
                //            and b.voucher_type = :voucher_type
                //            and a.status in('20','40')";

                //    num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                //    if (num > int.Parse(code.budget))
                //    {
                //        result.code = "99";
                //        result.msg = "기존 사용액보다 낮은 금액을 설정할수 없습니다. (현재 할인 총액: " + num + "원)";
                //        return result;
                //    }
                //}

                sql = @"update voucher_code_set
                        set group_cd = :group_cd, 
                            use_yn = :use_yn, 
                            voucher_name = :voucher_name, 
                            voucher_amt = :voucher_amt, 
                            promotion_yn = :promotion_yn, 
                            budget = :budget, 
                            disc_gbn = :disc_gbn, 
                            disc_range = :disc_range, 
                            voucher_notice = :voucher_notice, 
                            thumb_url = case when :thumb_yn = 'Y' then :in_thumb_url else thumb_url end, 
                            memo = :memo, 
                            mod_ucode = :ucode,
                            mod_date = sysdate
                        where seqno = :seqno";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                result.code = "00";
                result.msg = "성공";

            }
            catch (Exception ex)
            {
                result.code = "99";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync("/Voucher/updateCodeData : Put", ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 모바일상품권 코드 사용여부 수정
        /// </summary>
        /// <remarks>
        /// [parameter] <br/>
        /// seqno : pk값 (식별자) <br/>
        /// use_yn : 사용구분(Y/N) <br/>
        /// ucode : 수정자 ucode <br/>
        /// </remarks>
        [HttpPut("updateUseYn")]
        public async Task<IActionResult> updateUseYn(string seqno, string use_yn, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            DynamicParameters param = new DynamicParameters();

            string sql = string.Empty;

            db.Open();

            try
            {
                param.Add("seqno", seqno);
                param.Add("use_yn", use_yn);
                param.Add("ucode", ucode);

                sql = @"update voucher_code_set
                        set use_yn = :use_yn, 
                            mod_ucode = :ucode,
                            mod_date = sysdate
                        where seqno = :seqno";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Voucher/updateUseYn : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
#endregion

        #region [카드 이미지 카테고리 관리]
        /// <summary>
        /// 카드 이미지 카테고리 리스트 조회
        /// </summary>
        /// <remarks>
        /// app_visible_yn : 앱노출여부(Y/N) <br/>
        /// <br/>
        /// [response body] <br/>
        /// sort_seq : 정렬순서(내림차순) <br/>
        /// category_cd : pk값 <br/>
        /// category_name : 카테고리명 <br/>
        /// memo : 메모 <br/>
        /// use_gbn : 사용구분 <br/>
        /// app_visible_yn : 앱노출여부 <br/>
        /// </remarks>
        [HttpGet("getImgCategoryList")]
        public async Task<IActionResult> getImgCategoryList(string app_visible_yn)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherImgCategoryList> items = new List<VoucherImgCategoryList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_IMG_CATEGORY_LIST",
            };

            //cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_app_visible_yn", OracleDbType.Varchar2, 1).Value = app_visible_yn;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherImgCategoryList m = new VoucherImgCategoryList
                    {
                        category_cd = rd["category_cd"].ToString(),
                        category_name = rd["category_name"].ToString(),
                        memo = rd["memo"].ToString(),
                        //use_gbn = rd["use_gbn"].ToString(),
                        app_visible_yn = rd["APP_VISIBLE_YN"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["ins_name"].ToString(),
                        mod_date = rd["mod_date"].ToString(),
                        mod_ucode = rd["mod_ucode"].ToString(),
                        mod_name = rd["mod_name"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getImgCategoryList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 카드 이미지 카테고리 상세조회
        /// </summary>
        /// <remarks>
        /// [response body] <br/>
        /// app_visible_yn : 앱노출여부(Y/N) <br/>
        /// category_cd : pk값 <br/>
        /// category_name : 카테고리명 <br/>
        /// memo : 메모 <br/>
        /// </remarks>
        [HttpGet("getImgCategoryDetail/{category_cd}")]
        public async Task<IActionResult> getImgCategoryDetail(string category_cd)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            VoucherImgCategoryDetail item = new VoucherImgCategoryDetail();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_IMG_CATEGORY_DETAIL",
            };

            cmd.Parameters.Add("in_category_cd", OracleDbType.Int32).Value = category_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                //item.use_gbn = rd["use_gbn"].ToString();
                item.app_visible_yn = rd["app_visible_yn"].ToString();
                item.category_cd = rd["category_cd"].ToString();
                item.category_name = rd["category_name"].ToString();
                item.memo = rd["memo"].ToString();
                item.ins_date = rd["ins_date"].ToString();
                item.ins_ucode = rd["ins_ucode"].ToString();
                item.ins_name = rd["ins_name"].ToString();
                item.mod_date = rd["mod_date"].ToString();
                item.mod_ucode = rd["mod_ucode"].ToString();
                item.mod_name = rd["mod_name"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getImgCategoryDetail/{category_cd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 카드 이미지 카테고리 생성
        /// </summary>
        /// <remarks>
        /// [request body] <br/>
        /// category_cd : pk값 (put only) <br/>
        /// category_name : 카테고리명 <br/>
        /// use_gbn : 사용구분(Y/N) <br/>
        /// app_visible_yn : 앱노출여부(Y/N) <br/>
        /// memo : 메모 <br/>
        /// ucode : 생성자 ucode <br/>
        /// </remarks>
        [HttpPost("setImgCategory")]
        public async Task<IActionResult> setImgCategory(VoucherImgCategory code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            DynamicParameters param = new DynamicParameters();

            string sql = string.Empty;

            db.Open();

            try
            {
                param.Add("category_name", code.category_name);
                //param.Add("use_gbn", code.use_gbn);
                param.Add("app_visible_yn", code.app_visible_yn);
                param.Add("memo", code.memo);
                param.Add("ucode", code.ucode);

                sql = @"select count(*) from VOUCHER_IMG_CATEGORY where category_name = :category_name";

                int num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                if (num > 0)
                {
                    Rcode = "99";
                    Rmsg = "동일한 카테고리명이 이미 존재합니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                sql = @"insert into VOUCHER_IMG_CATEGORY(category_name, 
                                                         use_gbn, 
                                                         app_visible_yn, 
                                                         memo, 
                                                         ins_ucode, 
                                                         ins_date)
                        values(:category_name, 
                               'Y', 
                               :app_visible_yn, 
                               :memo, 
                               :ucode, 
                               sysdate)";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Voucher/setImgCategory : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 카드 이미지 카테고리 수정
        /// </summary>
        /// <remarks>
        /// [request body] <br/>
        /// category_cd : pk값 (put only) <br/>
        /// category_name : 카테고리명 <br/>
        /// app_visible_yn : 앱노출여부(Y/N) <br/>
        /// memo : 메모 <br/>
        /// ucode : 수정자 ucode <br/>
        /// </remarks>
        [HttpPut("updateImgCategory")]
        public async Task<IActionResult> updateImgCategory(VoucherImgCategory code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            DynamicParameters param = new DynamicParameters();

            string sql = string.Empty;

            db.Open();

            try
            {
                param.Add("category_cd", code.category_cd);
                param.Add("category_name", code.category_name);
                //param.Add("use_gbn", code.use_gbn);
                param.Add("app_visible_yn", code.app_visible_yn);
                param.Add("memo", code.memo);
                param.Add("ucode", code.ucode);

                sql = @"select count(*) from VOUCHER_IMG_CATEGORY where category_name = :category_name and category_cd <> :category_cd";

                int num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                if (num > 0)
                {
                    Rcode = "99";
                    Rmsg = "동일한 카테고리명이 이미 존재합니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                sql = @"update VOUCHER_IMG_CATEGORY
                        set category_name = :category_name, 
                            --use_gbn = :use_gbn, 
                            app_visible_yn = :app_visible_yn, 
                            memo = :memo, 
                            mod_ucode = :ucode,
                            mod_date = sysdate
                        where category_cd = :category_cd";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Voucher/updateImgCategory : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 카드 이미지 카테고리 순서변경
        /// </summary>
        /// <remarks>
        /// 앱노출 Y일 경우 sort_seq 역순, ins_date 역순으로 정렬(null은 최상단)
        /// </remarks>
        [HttpPost("updateImgCategorySort")]
        public async Task<IActionResult> updateImgCategorySort(IEnumerable<string> category_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.UPDATE_IMG_CATEGORY_SORT",
            };

            var arrCouponNo = cmd.Parameters.Add("in_cd_array", OracleDbType.Int32);
            arrCouponNo.Direction = ParameterDirection.Input;
            arrCouponNo.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrCouponNo.Value = category_cd.ToArray();
            arrCouponNo.Size = category_cd.Count();
            arrCouponNo.ArrayBindSize = category_cd.Select(_ => _.Length).ToArray();
            arrCouponNo.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, category_cd.Count()).ToArray();

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/updateImgCategorySort : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 카드 이미지 카테고리 순서조회
        /// </summary>
        /// <remarks>
        /// 사용, 앱노출 Y일 경우 sort_seq 역순, ins_date 역순으로 정렬(null은 최상단)
        /// </remarks>
        [HttpGet("getImgCategorySortList")]
        public async Task<IActionResult> getSortList()
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherImgCategorySort> items = new List<VoucherImgCategorySort>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_IMG_CATEGORY_SORT",
            };

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherImgCategorySort m = new VoucherImgCategorySort
                    {
                        sort_seq = rd["sort_seq"].ToString(),
                        category_cd = rd["category_cd"].ToString(),
                        category_name = rd["category_name"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getImgCategorySortList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }
        #endregion

        #region [카드 이미지 관리]
        /// <summary>
        /// 카테고리 리스트 조회(드롭다운용)
        /// </summary>
        /// <remarks>
        /// app_visible_yn 앱노출 여부(Y/N)
        /// </remarks>
        [HttpGet("getCategoryList")]
        public async Task<IActionResult> getCategoryList(string app_visible_yn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_app_visible_yn", app_visible_yn);

            string sql = @$"
                            select category_cd, category_name, app_visible_yn
                            from VOUCHER_IMG_CATEGORY
                            where app_visible_yn like case when :in_app_visible_yn is null then '%' else :in_app_visible_yn end
                            order by ins_date desc
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 카드 이미지 리스트 조회
        /// </summary>
        /// <remarks>
        /// 이미지 경로 : https://image.daeguro.co.kr:40443/voucher-images/{img_url} <br/>
        ///              https://image.daeguro.co.kr:40443/voucher-images/thumb/{img_url} <br/>
        /// type_gbn : 타입 구분 (M: 이벤트, A: 주문, B: 기업, O: 공통) <br/>
        /// use_gbn : 사용여부(Y/N) 사용여부가 N이어도 고객은 본인 상품권 이미지를 볼수 있음 <br/>
        /// app_visible_yn : 고객앱 노출 여부(Y/N) <br/>
        /// category_cd : 카테고리 코드 <br/>
        /// <br/>
        /// [response body] <br/>
        /// img_code : pk값 <br/>
        /// type_gbn : 타입 구분 (M: 이벤트, A: 주문, B: 기업, O: 공통) <br/>
        /// use_gbn : 사용여부(Y/N) <br/>
        /// app_visible_yn : 고객앱 노출 여부(Y/N) <br/>
        /// category_cd : 카테고리 코드 <br/>
        /// img_url : url <br/>
        /// memo : 메모 <br/>
        /// </remarks>
        [HttpGet("getImgList")]
        public async Task<IActionResult> getImgList(string type_gbn, string use_gbn, string app_visible_yn, string category_cd)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherImgList> items = new List<VoucherImgList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_IMG_LIST",
            };

            cmd.Parameters.Add("in_type_gbn", OracleDbType.Varchar2, 1).Value = type_gbn;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_app_visible_yn", OracleDbType.Varchar2, 1).Value = app_visible_yn;
            cmd.Parameters.Add("in_category_cd", OracleDbType.Varchar2, 10).Value = category_cd;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherImgList m = new VoucherImgList
                    {
                        
                        img_code = rd["img_code"].ToString(),
                        type_gbn = rd["type_gbn"].ToString(),
                        use_gbn = rd["use_gbn"].ToString(),
                        app_visible_yn = rd["app_visible_yn"].ToString(),
                        category_cd = rd["category_cd"].ToString(),
                        img_url = rd["img_url"].ToString(),
                        memo = rd["memo"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["ins_name"].ToString(),
                        mod_date = rd["mod_date"].ToString(),
                        mod_ucode = rd["mod_ucode"].ToString(),
                        mod_name = rd["mod_name"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getImgList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 카드 이미지 상세조회
        /// </summary>
        /// <remarks>
        /// 이미지 경로 : https://image.daeguro.co.kr:40443/voucher-images/{img_url} <br/>
        ///              https://image.daeguro.co.kr:40443/voucher-images/thumb/{img_url} <br/>
        /// [response body] <br/>
        /// img_code : pk값 <br/>
        /// type_gbn : 타입 구분 (M: 이벤트, A: 주문, B: 기업, O: 공통) <br/>
        /// app_visible_yn : 고객앱 노출 여부(Y/N) <br/>
        /// use_gbn : 사용여부(Y/N) 사용여부가 N이어도 고객은 본인 상품권 이미지를 볼수 있음 <br/>
        /// category_cd : 카테고리 코드 <br/>
        /// img_url : url <br/>
        /// memo : 메모 <br/>
        /// </remarks>
        [HttpGet("getImgDetail/{img_code}")]
        public async Task<IActionResult> getImgDetail(string img_code)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            VoucherImgList item = new VoucherImgList();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_IMG_DETAIL",
            };

            cmd.Parameters.Add("in_img_code", OracleDbType.Int32).Value = img_code;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.img_code = rd["img_code"].ToString();
                item.type_gbn = rd["type_gbn"].ToString();
                item.app_visible_yn = rd["app_visible_yn"].ToString();
                item.use_gbn = rd["use_gbn"].ToString();
                item.category_cd = rd["category_cd"].ToString();
                item.img_url = rd["img_url"].ToString();
                item.memo = rd["memo"].ToString();
                item.ins_date = rd["ins_date"].ToString();
                item.ins_ucode = rd["ins_ucode"].ToString();
                item.ins_name = rd["ins_name"].ToString();
                item.mod_date = rd["mod_date"].ToString();
                item.mod_ucode = rd["mod_ucode"].ToString();
                item.mod_name = rd["mod_name"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getImgDetail/{img_code} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 카드 이미지 생성
        /// </summary>
        /// <remarks>
        /// [request body] <br/>
        /// formFile : png 타입 이미지 파일 <br/>
        /// img_code : pk값 (put only) <br/>
        /// type_gbn : 타입 구분 (M: 이벤트, A: 주문, B: 기업, O: 공통) <br/>
        /// use_gbn : 사용여부(Y/N) 사용여부가 N이어도 고객은 본인 상품권 이미지를 볼수 있음 <br/>
        /// category_cd : 카테고리 코드 <br/>
        /// memo : 메모 <br/>
        /// ucode : 생성자 ucode <br/>
        /// </remarks>
        [HttpPost("setImg")]
        public async Task<IActionResult> setImg(IFormFile formFile, [FromForm] VoucherImg img)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                if (formFile != null && formFile.Length > 0)
                {
                    img.img_code = await setImgData("Y", img);

                    if (img.img_code.Equals("0"))
                    {
                        Rcode = "99";
                        Rmsg = "카드 이미지 등록 실패";
                        return Ok(new { code = Rcode, msg = Rmsg });
                    }

                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    string folerPath = voucherPath;
                    string fileName = img.img_code + ".png";

                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        if (Directory.Exists(folerPath) == false)
                        {
                            Directory.CreateDirectory(folerPath);
                        }

                        //썸네일 폴더
                        if (Directory.Exists(folerPath + "\\Thumb") == false)
                        {
                            Directory.CreateDirectory(folerPath + "\\Thumb");
                        }

                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath + "\\" + fileName))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath + "\\" + fileName);
                        }

                        //누겟 imageProcessor 필요
                        using (ImageFactory imageFactory = new ImageFactory(preserveExifData: true))
                        {
                            var ima = imageFactory.Load(formFile.OpenReadStream()).Image;
                            int isizeW = 1280;
                            int isizeH = 720;
                            int quality = 100;

                            //오리지널 저장(w:1280/h:720/q:100)
                            if (ima.Width > ima.Height)
                            {
                                if (ima.Width < 1280)
                                {
                                    isizeW = ima.Width;
                                }

                                var ratio = (float)ima.Height / ima.Width;

                                imageFactory.Load(formFile.OpenReadStream())
                                    .Format(new PngFormat())
                                    .Resize(new Size(isizeW, (int)(isizeW * ratio)))
                                    .Quality(quality)
                                    .Save(folerPath + "\\" + fileName)
                                    .Quality(72)
                                    .Save(folerPath + "\\Thumb\\" + fileName);
                            }
                            else
                            {
                                if (ima.Height < 720)
                                {
                                    isizeH = ima.Height;
                                }

                                var ratio = (float)ima.Width / ima.Height;

                                imageFactory.Load(formFile.OpenReadStream())
                                    .Format(new PngFormat())
                                    .Resize(new Size((int)(isizeH * ratio), isizeH))
                                    .Quality(quality)
                                    .Save(folerPath + "\\" + fileName)
                                    .Quality(72)
                                    .Save(folerPath + "\\Thumb\\" + fileName);
                            }


                        }
                    }

                }
                else
                {
                    img.img_code = await setImgData("N", img);

                    if (img.img_code.Equals("0"))
                    {
                        Rcode = "99";
                        Rmsg = "카드 이미지 등록 실패";
                        return Ok(new { code = Rcode, msg = Rmsg });
                    }
                }

                Rcode = "00";
                Rmsg = "성공";


            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/Voucher/setImg : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        private async Task<string> setImgData(string img_yn, VoucherImg img)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            img.img_code = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("img_yn", img_yn);
            param.Add("type_gbn", img.type_gbn);
            param.Add("use_gbn", img.use_gbn);
            param.Add("category_cd", img.category_cd);
            param.Add("memo", img.memo);
            param.Add("ucode", img.ucode);

            string sql = @"insert into VOUCHER_CARD_IMAGE( type_gbn, 
                                                           use_gbn, 
                                                           category_cd, 
                                                           memo, 
                                                           img_url, 
                                                           ins_ucode, 
                                                           ins_date)
                            values(:type_gbn, 
                                   :use_gbn, 
                                   :category_cd, 
                                   :memo, 
                                    case when :img_yn = 'Y' then 
                                                        (select last_number
                                                        from user_sequences
                                                        where sequence_name = 'VOUCHER_CARD_IMAGE_SEQ') || '.png' 
                                            else null end, 
                                   :ucode, 
                                   sysdate)";

            db.Open();

            try
            {
                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                sql = $@"
                          select last_number - 1
                        from user_sequences
                        where sequence_name = 'VOUCHER_CARD_IMAGE_SEQ'
                        ";
                img.img_code = await db.ExecuteScalarAsync<string>(sql, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                img.img_code = "0";
                await Utils.SaveErrorAsync("/Voucher/setImgData : Post", ex.Message);
            }


            return img.img_code;
        }

        /// <summary>
        /// 카드 이미지 수정
        /// </summary>
        /// <remarks>
        /// [request body] <br/>
        /// formFile : png 타입 이미지 파일 <br/>
        /// img_code : pk값 (put only) <br/>
        /// type_gbn : 타입 구분 (M: 이벤트, A: 주문, B: 기업, O: 공통) <br/>
        /// use_gbn : 사용여부(Y/N) 사용여부가 N이어도 고객은 본인 상품권 이미지를 볼수 있음 <br/>
        /// category_cd : 카테고리 코드 <br/>
        /// memo : 메모 <br/>
        /// ucode : 수정자 ucode <br/>
        /// </remarks>
        [HttpPost("updateImg")]
        public async Task<IActionResult> updateImg(IFormFile formFile, [FromForm] VoucherImg img)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                if (formFile != null && formFile.Length > 0)
                {
                    string img_name = img.img_code + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".png";

                    Rcode = await updateImgData(img_name, img);

                    if (Rcode.Equals("99"))
                    {
                        Rcode = "99";
                        Rmsg = "카드 이미지 수정 실패";
                        return Ok(new { code = Rcode, msg = Rmsg });
                    }

                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    string folerPath = voucherPath;
                    string fileName = img_name;

                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        if (Directory.Exists(folerPath) == false)
                        {
                            Directory.CreateDirectory(folerPath);
                        }

                        //썸네일 폴더
                        if (Directory.Exists(folerPath + "\\Thumb") == false)
                        {
                            Directory.CreateDirectory(folerPath + "\\Thumb");
                        }

                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath + "\\" + fileName))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath + "\\" + fileName);
                        }

                        //누겟 imageProcessor 필요
                        using (ImageFactory imageFactory = new ImageFactory(preserveExifData: true))
                        {
                            var ima = imageFactory.Load(formFile.OpenReadStream()).Image;
                            int isizeW = 1280;
                            int isizeH = 720;
                            int quality = 100;

                            //오리지널 저장(w:1280/h:720/q:100)
                            if (ima.Width > ima.Height)
                            {
                                if (ima.Width < 1280)
                                {
                                    isizeW = ima.Width;
                                }

                                var ratio = (float)ima.Height / ima.Width;

                                imageFactory.Load(formFile.OpenReadStream())
                                    .Format(new PngFormat())
                                    .Resize(new Size(isizeW, (int)(isizeW * ratio)))
                                    .Quality(quality)
                                    .Save(folerPath + "\\" + fileName)
                                    .Quality(72)
                                    .Save(folerPath + "\\Thumb\\" + fileName);
                            }
                            else
                            {
                                if (ima.Height < 720)
                                {
                                    isizeH = ima.Height;
                                }

                                var ratio = (float)ima.Width / ima.Height;

                                imageFactory.Load(formFile.OpenReadStream())
                                    .Format(new PngFormat())
                                    .Resize(new Size((int)(isizeH * ratio), isizeH))
                                    .Quality(quality)
                                    .Save(folerPath + "\\" + fileName)
                                    .Quality(72)
                                    .Save(folerPath + "\\Thumb\\" + fileName);
                            }
                        }
                    }
                }
                else
                {
                    Rcode = await updateImgData(null, img);

                    if (Rcode.Equals("99"))
                    {
                        Rcode = "99";
                        Rmsg = "카드 이미지 수정 실패";
                        return Ok(new { code = Rcode, msg = Rmsg });
                    }
                }

                Rcode = "00";
                Rmsg = "성공";


            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/Voucher/updateImg : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        private async Task<string> updateImgData(string img_name, VoucherImg img)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("img_code", img.img_code);
            param.Add("img_name", img_name);
            param.Add("type_gbn", img.type_gbn);
            param.Add("use_gbn", img.use_gbn);
            param.Add("category_cd", img.category_cd);
            param.Add("memo", img.memo);
            param.Add("ucode", img.ucode);

            string sql = @"update VOUCHER_CARD_IMAGE
                           set type_gbn = :type_gbn,
                                img_url = case when :img_name is null then img_url else :img_name end,
                                use_gbn = :use_gbn,
                                category_cd = :category_cd,
                                memo = :memo,
                                mod_ucode = :ucode,
                                mod_date = sysdate
                           where img_code = :img_code";

            db.Open();

            try
            {
                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                sql = @"select user_name from users where ucode = :ucode";

                var name = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);
                param.Add("name", name);

                sql = @"insert into voucher_image_hist(img_code, memo, hist_date)
                        values (:img_code,'이미지 파일 수정[작업자: ' || :name || ',' || :ucode || ']',sysdate)";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                img.img_code = "0";
                await Utils.SaveErrorAsync("/Voucher/updateImgData : Put", ex.Message);
            }


            return Rcode;
        }

        /// <summary>
        /// 카드 이미지 삭제
        /// </summary>
        /// <remarks>
        /// [request body] <br/>
        /// img_code : pk값 (put only) <br/>
        /// ucode : 수정자 ucode <br/>
        /// </remarks>
        [HttpDelete("deleteImg")]
        public async Task<IActionResult> deleteImg(string img_code, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {

                Rcode = await deleteImgData(img_code, ucode);

                if (Rcode.Equals("99"))
                {
                    Rcode = "99";
                    Rmsg = "카드 이미지 삭제 실패";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                string folerPath = voucherPath;
                string fileName = Rcode;

                // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                using (new ConnectToSharedFolder(nasPath))
                {
                    if (Directory.Exists(folerPath) == false)
                    {
                        Directory.CreateDirectory(folerPath);
                    }

                    // 파일이 존재하면 삭제한다.
                    if (System.IO.File.Exists(folerPath + "\\" + fileName))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        System.IO.File.Delete(folerPath + "\\" + fileName);
                    }

                    if (System.IO.File.Exists(folerPath + "\\Thumb\\" + fileName))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        System.IO.File.Delete(folerPath + "\\Thumb\\" + fileName);
                    }

                }



                Rcode = "00";
                Rmsg = "성공";


            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/Voucher/deleteImg : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        private async Task<string> deleteImgData(string img_code, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("img_code", img_code);
            param.Add("ucode", ucode);

            try
            {
                db.Open();

                string sql = @"select img_url from VOUCHER_CARD_IMAGE
                           where img_code = :img_code";

                Rcode = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                sql = @"delete from VOUCHER_CARD_IMAGE
                           where img_code = :img_code";

                var n = await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                if (n > 0)
                {
                    sql = @"select user_name from users where ucode = :ucode";

                    var name = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);
                    param.Add("name", name);

                    sql = @"insert into voucher_image_hist(img_code, memo, hist_date)
                        values (:img_code,'이미지 삭제[작업자: ' || :name || ',' || :ucode || ']',sysdate)";

                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                    Rcode = "00";
                    Rmsg = "성공";
                }

                db.Close();

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Voucher/deleteImgData : Delete", ex.Message);
            }


            return Rcode;
        }
        #endregion

        #region[판매집계표]
        /// <summary>
        /// 판매집계표 목록 조회
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// prsc_gbn : 처리 구분 (M: 무상제공(이벤트), A: 고객앱구매(주문), B: 기업판매(기업)) <br />
        /// group_cd : 그룹 코드 <br />
        /// div 기간조건 1: 구매확정기준(등록일), 2: 판매일기준(구매일) <br />
        /// date_begin - date_end 기간
        /// <br />
        /// 결과 값 <br />
        /// prsc_gbn : 처리 구분 <br />
        /// group_cd : 상품권 그룹코드 <br />
        /// group_name : 상품권 그룹명 <br />
        /// dt : 일자 <br />
        /// remain_amt : 상품권 잔액 <br />
        /// reg_amt : 충전액(등록금액) <br />
        /// reg_cnt : 충전건수(등록건수) <br />
        /// payment_amt : 결제금액 <br />
        /// disc_amt : 할인금액 <br />
        /// use_amt : 사용금액 <br />
        /// cancel_amt : 취소금액 <br />
        /// reuse_amt : 환불후 사용금액 <br /> 
        /// re_cancel_amt : 환불후 취소금액 <br />
        /// comp_cnt : 사용완료건수 <br />
        /// r_comp_cnt : 환불후 사용완료 건수 <br />ㄴ
        /// refund_ant : 환불액 <br />
        /// refund_fee : 이체수수료 <br />
        /// refund_cnt : 환불건수 <br />
        /// </remarks>
        [HttpGet("getCalcList")]
        public async Task<IActionResult> getCalcList(string prsc_gbn, string group_cd, string div, string date_begin, string date_end, string page, string rows)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherCalcList> items = new List<VoucherCalcList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_CALC_LIST",
            };

            cmd.Parameters.Add("in_prsc_gbn", OracleDbType.Varchar2, 2).Value = prsc_gbn;
            cmd.Parameters.Add("in_group_cd", OracleDbType.Varchar2, 20).Value = group_cd;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 2).Value = div;
            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherCalcList m = new VoucherCalcList
                    {
                        prsc_gbn = rd["prsc_gbn"].ToString(),
                        group_cd = rd["group_cd"].ToString(),
                        group_name = rd["group_name"].ToString(),
                        dt = rd["dt"].ToString(),
                        remain_amt = rd["remain_amt"].ToString(),
                        reg_amt = rd["reg_amt"].ToString(),
                        reg_cnt = rd["reg_cnt"].ToString(),
                        payment_amt = rd["payment_amt"].ToString(),
                        disc_amt = rd["disc_amt"].ToString(),
                        use_amt = rd["use_amt"].ToString(),
                        cancel_amt = rd["cancel_amt"].ToString(),
                        reuse_amt = rd["reuse_amt"].ToString(),
                        re_cancel_amt = rd["re_cancel_amt"].ToString(),
                        comp_cnt = rd["comp_cnt"].ToString(),
                        r_comp_cnt = rd["r_comp_cnt"].ToString(),
                        refund_amt = rd["refund_amt"].ToString(),
                        refund_fee = rd["refund_fee"].ToString(),
                        refund_cnt = rd["refund_cnt"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getCalcList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 판매집계표 목록 엑셀출력
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// prsc_gbn : 처리 구분 (M: 무상제공(이벤트), A: 고객앱구매(주문), B: 기업판매(기업)) <br />
        /// group_cd : 그룹 코드 <br />
        /// div 기간조건 1: 구매확정기준(등록일), 2: 판매일기준(구매일) <br />
        /// date_begin - date_end 기간
        /// </remarks>
        [HttpGet("getCalcListExcel")]
        public async Task<IActionResult> getCalcListExcel(string prsc_gbn, string group_cd, string div, string date_begin, string date_end)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherCalcList> items = new List<VoucherCalcList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_CALC_LIST",
            };

            cmd.Parameters.Add("in_prsc_gbn", OracleDbType.Varchar2, 2).Value = prsc_gbn;
            cmd.Parameters.Add("in_group_cd", OracleDbType.Varchar2, 20).Value = group_cd;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 2).Value = div;
            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = null;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = null;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add(date_begin + "-" + date_end);
                        var currentRow = 1;

                        worksheet.Cell(currentRow, 1).Value = "처리구분";
                        worksheet.Cell(currentRow, 2).Value = "그룹코드";
                        worksheet.Cell(currentRow, 3).Value = "그룹명";
                        worksheet.Cell(currentRow, 4).Value = "일자";
                        worksheet.Cell(currentRow, 5).Value = "잔액";
                        worksheet.Cell(currentRow, 6).Value = "충전액";
                        worksheet.Cell(currentRow, 7).Value = "충전건수";
                        worksheet.Cell(currentRow, 8).Value = "결제금액";
                        worksheet.Cell(currentRow, 9).Value = "할인금액";
                        worksheet.Cell(currentRow, 10).Value = "사용금액";
                        worksheet.Cell(currentRow, 11).Value = "취소금액";                        
                        worksheet.Cell(currentRow, 12).Value = "사용완료건수";                        
                        worksheet.Cell(currentRow, 13).Value = "환불액";
                        worksheet.Cell(currentRow, 14).Value = "이체수수료";
                        worksheet.Cell(currentRow, 15).Value = "환불건수";
                        worksheet.Cell(currentRow, 16).Value = "환불후 사용금액";
                        worksheet.Cell(currentRow, 17).Value = "환불후 취소금액";
                        worksheet.Cell(currentRow, 18).Value = "환불후 사용완료 건수";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;

                            worksheet.Cell(currentRow, 1).Value = rd["prsc_gbn"].ToString();
                            worksheet.Cell(currentRow, 2).Value = rd["group_cd"].ToString();
                            worksheet.Cell(currentRow, 3).Value = rd["group_name"].ToString();
                            worksheet.Cell(currentRow, 4).Value = rd["dt"].ToString();
                            worksheet.Cell(currentRow, 5).Value = rd["remain_amt"].ToString();
                            worksheet.Cell(currentRow, 6).Value = rd["reg_amt"].ToString();
                            worksheet.Cell(currentRow, 7).Value = rd["reg_cnt"].ToString();
                            worksheet.Cell(currentRow, 8).Value = rd["payment_amt"].ToString();
                            worksheet.Cell(currentRow, 9).Value = rd["disc_amt"].ToString();
                            worksheet.Cell(currentRow, 10).Value = rd["use_amt"].ToString();
                            worksheet.Cell(currentRow, 11).Value = rd["cancel_amt"].ToString();                            
                            worksheet.Cell(currentRow, 12).Value = rd["comp_cnt"].ToString();                            
                            worksheet.Cell(currentRow, 13).Value = rd["refund_amt"].ToString();
                            worksheet.Cell(currentRow, 14).Value = rd["refund_fee"].ToString();
                            worksheet.Cell(currentRow, 15).Value = rd["refund_cnt"].ToString();
                            worksheet.Cell(currentRow, 16).Value = rd["reuse_amt"].ToString();
                            worksheet.Cell(currentRow, 17).Value = rd["re_cancel_amt"].ToString();
                            worksheet.Cell(currentRow, 18).Value = rd["r_comp_cnt"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "판매집계표.xlsx");
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getCalcListExcel : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 판매집계표 상세 조회
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// group_cd : 그룹 코드 <br />
        /// div 기간조건 1: 구매확정기준(등록일), 2: 판매일기준(구매일) <br />
        /// date_begin - date_end 기간 <br />
        /// voucher_type : 상품권 종류 
        /// key_div : 키워드 검색 조건(1: 고객명, 2: 고객코드)
        /// keyword : 키워드 검색
        /// remain_zero : 잔액0원 포함여부(Y/N)
        /// not_reg : 미등록건 포함여부(Y/N)
        /// <br />
        /// 결과 값 <br />
        /// group_cd : 상품권 그룹코드 <br />
        /// group_name : 상품권 그룹명 <br />
        /// voucher_type : 상품권 종류 <br />
        /// voucher_name : 상품권 이름 <br />
        /// voucher_no : 상품권 번호 <br />
        /// status : 상품권 상태 <br />
        /// cust_code : 회원코드 <br />
        /// cust_name : 회원명 <br />
        /// ins_date : 판매일 <br />
        /// reg_date : 구매확정일(등록일) <br />
        /// use_exp_date : 만료일 <br />
        /// remain_amt : 상품권 잔액 <br />
        /// reg_amt : 충전액(등록금액) <br />
        /// payment_amt : 결제금액 <br />
        /// disc_amt : 할인금액 <br />
        /// use_amt : 사용금액 <br />
        /// cancel_amt : 취소금액 <br />
        /// reuse_amt : 환불후 사용금액 <br /> 
        /// re_cancel_amt : 환불후 취소금액 <br />
        /// refund_ant : 환불액 <br />
        /// refund_fee : 이체수수료 <br />
        /// </remarks>
        [HttpGet("getCalcDetail")]
        public async Task<IActionResult> getCalcDetail(string group_cd, string div, string date_begin, string date_end, 
                                                       string voucher_type, string key_div, string keyword, string remain_zero, string not_reg, 
                                                       string page, string rows)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherCalcDetail> items = new List<VoucherCalcDetail>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_CALC_DETAIL",
            };

            cmd.Parameters.Add("in_group_cd", OracleDbType.Varchar2, 20).Value = group_cd;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_voucher_type", OracleDbType.Varchar2, 30).Value = voucher_type;
            cmd.Parameters.Add("in_key_div", OracleDbType.Varchar2, 1).Value = key_div;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
            cmd.Parameters.Add("in_remain_zero", OracleDbType.Varchar2, 1).Value = remain_zero;
            cmd.Parameters.Add("in_not_reg", OracleDbType.Varchar2, 1).Value = not_reg;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherCalcDetail m = new VoucherCalcDetail
                    {
                        group_cd = rd["group_cd"].ToString(),
                        group_name = rd["group_name"].ToString(),
                        voucher_type = rd["voucher_type"].ToString(),
                        voucher_name = rd["voucher_name"].ToString(),
                        voucher_no = rd["voucher_no"].ToString(),
                        status = rd["status"].ToString(),
                        cust_code = rd["CUST_CODE"].ToString(),
                        cust_name = rd["cust_name"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        reg_date = rd["reg_date"].ToString(),
                        use_exp_date = rd["use_exp_date"].ToString(),
                        remain_amt = rd["remain_amt"].ToString(),
                        reg_amt = rd["reg_amt"].ToString(),
                        payment_amt = rd["payment_amt"].ToString(),
                        disc_amt = rd["disc_amt"].ToString(),
                        use_amt = rd["use_amt"].ToString(),
                        cancel_amt = rd["cancel_amt"].ToString(),
                        reuse_amt = rd["reuse_amt"].ToString(),
                        re_cancel_amt = rd["re_cancel_amt"].ToString(),
                        refund_amt = rd["refund_amt"].ToString(),
                        refund_fee = rd["refund_fee"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getCalcDetail : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 판매집계표 상세 엑셀출력
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// group_cd : 그룹 코드 <br />
        /// div 기간조건 1: 구매확정기준(등록일), 2: 판매일기준(구매일) <br />
        /// date_begin - date_end 기간 <br />
        /// voucher_type : 상품권 종류 <br />
        /// key_div : 키워드 검색 조건(1: 고객명, 2: 고객코드) <br />
        /// keyword : 키워드 검색 <br />
        /// remain_zero : 잔액0원 포함여부(Y/N) <br />
        /// not_reg : 미등록건 포함여부(Y/N) <br />
        /// </remarks>
        [HttpGet("getCalcDetailExcel")]
        public async Task<IActionResult> getCalcDetailExcel(string group_cd, string div, string date_begin, string date_end,
                                                       string voucher_type, string key_div, string keyword, string remain_zero, string not_reg)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherCalcDetail> items = new List<VoucherCalcDetail>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_CALC_DETAIL",
            };

            cmd.Parameters.Add("in_group_cd", OracleDbType.Varchar2, 20).Value = group_cd;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_voucher_type", OracleDbType.Varchar2, 30).Value = voucher_type;
            cmd.Parameters.Add("in_key_div", OracleDbType.Varchar2, 1).Value = key_div;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
            cmd.Parameters.Add("in_remain_zero", OracleDbType.Varchar2, 1).Value = remain_zero;
            cmd.Parameters.Add("in_not_reg", OracleDbType.Varchar2, 1).Value = not_reg;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = null;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = null;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add(date_begin + "-" + date_end);
                        var currentRow = 1;
                        var col = 1;
                        //worksheet.Cell(currentRow, 1).SetValue("그룹코드").Comment.AddText("메모");
                        worksheet.Cell(currentRow, col++).Value = "그룹코드";
                        worksheet.Cell(currentRow, col++).Value = "그룹명";
                        worksheet.Cell(currentRow, col++).Value = "상품권타입";
                        worksheet.Cell(currentRow, col++).Value = "상품권명";
                        worksheet.Cell(currentRow, col++).Value = "상품권번호";
                        worksheet.Cell(currentRow, col++).Value = "상태";
                        worksheet.Cell(currentRow, col++).Value = "회원코드";
                        worksheet.Cell(currentRow, col++).Value = "회원명";
                        worksheet.Cell(currentRow, col++).Value = "판매일";
                        worksheet.Cell(currentRow, col++).Value = "구매확정일";
                        worksheet.Cell(currentRow, col++).Value = "만료일";
                        worksheet.Cell(currentRow, col++).Value = "잔액";
                        worksheet.Cell(currentRow, col++).Value = "충전액";
                        worksheet.Cell(currentRow, col++).Value = "결제금액";
                        worksheet.Cell(currentRow, col++).Value = "할인금액";
                        worksheet.Cell(currentRow, col++).Value = "사용금액";
                        worksheet.Cell(currentRow, col++).Value = "취소금액";                        
                        worksheet.Cell(currentRow, col++).Value = "환불액";
                        worksheet.Cell(currentRow, col++).Value = "이체수수료";
                        worksheet.Cell(currentRow, col++).Value = "환불후 사용금액";
                        worksheet.Cell(currentRow, col++).Value = "환불후 취소금액";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;
                            col = 1;
                            worksheet.Cell(currentRow, col++).Value = rd["group_cd"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["group_name"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["voucher_type"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["voucher_name"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["voucher_no"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["status"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["cust_code"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["cust_name"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["ins_date"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["reg_date"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["use_exp_date"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["remain_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["reg_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["payment_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["disc_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["use_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["cancel_amt"].ToString();                            
                            worksheet.Cell(currentRow, col++).Value = rd["refund_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["refund_fee"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["reuse_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["re_cancel_amt"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "판매집계표_상세.xlsx");
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getCalcDetailExcel : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// (판매집계표 상세조회 하부) 사용내역
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// voucher_no : 상품권 번호 <br />
        /// date_begin - date_end 기간 <br />
        /// <br />
        /// 결과 값 <br />
        /// charge_date: 일자 <br />
        /// order_no : 주문번호 <br />
        /// charge_amt : 금액 <br />
        /// </remarks>
        [HttpGet("getUseList")]
        public async Task<IActionResult> getUseList(string voucher_no, string date_begin, string date_end)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherUseList> items = new List<VoucherUseList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_USE_LIST",
            };

            cmd.Parameters.Add("in_voucher_no", OracleDbType.Varchar2, 50).Value = voucher_no;
            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherUseList m = new VoucherUseList
                    {
                        charge_date = rd["charge_date"].ToString(),
                        order_no = rd["order_no"].ToString(),
                        service_gbn = rd["service_gbn"].ToString(),
                        charge_amt = rd["charge_amt"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getUseList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }
        #endregion

        #region[구매내역]
        /// <summary>
        /// 구매내역 목록 조회
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// date_begin - date_end 기간 <br />
        /// keyword :회원코드 또는 회원명 또는 휴대폰번호 검색 <br />
        /// <br />
        /// 결과 값 <br />
        /// sale_date : 구매일자 <br />
        /// cust_code : 회원코드 <br />
        /// cust_name : 회원명 <br />
        /// telno : 회원번호 <br />
        /// cnt : 총 구매수량 <br />
        /// amt : 총 결제금액 <br />
        /// disc_amt : 총 할인금액 <br />
        /// </remarks>
        [HttpGet("getBuyList")]
        public async Task<IActionResult> getBuyList(string date_begin, string date_end, string keyword, string page, string rows)
        {
            string RtotAmt = string.Empty;
            string RtotDiscAmt = string.Empty;
            string RtotCnt = string.Empty;
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherBuyList> items = new List<VoucherBuyList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_BUY_LIST",
            };

            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_tot_amt", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_tot_disc_amt", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_tot_cnt", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                RtotAmt = cmd.Parameters["out_tot_amt"].Value.ToString();
                RtotDiscAmt = cmd.Parameters["out_tot_disc_amt"].Value.ToString();
                RtotCnt = cmd.Parameters["out_tot_cnt"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherBuyList m = new VoucherBuyList
                    {
                        sale_date = rd["sale_date"].ToString(),
                        cust_code = rd["cust_code"].ToString(),
                        cust_name = rd["cust_name"].ToString(),
                        telno = rd["telno"].ToString(),
                        cnt = rd["cnt"].ToString(),
                        amt = rd["amt"].ToString(),
                        disc_amt = rd["disc_amt"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getBuyList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, totAmt = RtotAmt, totDiscAmt = RtotDiscAmt, totCnt = RtotCnt, count = Rcount, data = items });
        }

        /// <summary>
        /// 구매내역 리스트 - 엑셀추출
        /// </summary>
        /// <remarks>
        /// date_begin - date_end 기간 <br />
        /// keyword :회원코드 또는 회원명 또는 휴대폰번호 검색 <br />
        /// </remarks>
        [HttpGet("getBuyListExcel")]
        public async Task<IActionResult> getBuyListExcel(string date_begin, string date_end, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_VOUCHER.GET_BUY_LIST_EXCEL",
                };

                cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
                cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add(date_begin + "-" + date_end);
                        var currentRow = 1;

                        worksheet.Cell(currentRow, 1).Value = "구매일자";
                        worksheet.Cell(currentRow, 2).Value = "회원코드";
                        worksheet.Cell(currentRow, 3).Value = "회원명";
                        worksheet.Cell(currentRow, 4).Value = "회원번호";
                        worksheet.Cell(currentRow, 5).Value = "총 구매수량";
                        worksheet.Cell(currentRow, 6).Value = "총 결제금액";
                        worksheet.Cell(currentRow, 7).Value = "총 할인금액";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;

                            worksheet.Cell(currentRow, 1).Value = rd["sale_date"].ToString();
                            worksheet.Cell(currentRow, 2).Value = rd["cust_code"].ToString();
                            worksheet.Cell(currentRow, 3).Value = rd["cust_name"].ToString();
                            worksheet.Cell(currentRow, 4).Value = rd["telno"].ToString();
                            worksheet.Cell(currentRow, 5).Value = rd["cnt"].ToString();
                            worksheet.Cell(currentRow, 6).Value = rd["amt"].ToString();
                            worksheet.Cell(currentRow, 7).Value = rd["disc_amt"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "상품권 구매내역.xlsx");
                        }
                    }

                }


            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 구매내역 상세 조회
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// date_begin - date_end 기간 <br />
        /// cust_code : 구매자 회원코드 <br />
        /// voucher_type : 상품권 코드 <br />
        /// keyword : 검색키워드(받는사람, 구매번호, 상품권번호, 전화번호) <br />
        /// status : 상품권 상태 <br />
        /// <br />
        /// 결과 값 <br />
        /// sale_no : 거래번호 <br />
        /// tuid : 거래번호(KCP) <br />
        /// org_app_ymd : 카드결제 승인일자(구매일자) <br />
        /// pay_gbn : 결제수단(2:카드) <br />
        /// payment_amt : 총 결제 금액 <br />
        /// cancel_amt : 결제 취소 금액 <br />
        /// cust_telno : 받는사람 전화번호 <br /> 
        /// voucher_type : 상품권 종류 <br />
        /// voucher_name : 상품권명 <br />
        /// cnt : 수량 <br />
        /// voucher_amt : 금액 <br />
        /// voucher_no : 상품권 번호 <br />
        /// purchase_price : 개별 결제금액 <br />
        /// disc_amt : 할인금액 <br />
        /// card_reciever : 받는사람 <br />
        /// use_amt : 사용금액 <br />
        /// refund_amt : 환불금액 <br />
        /// status : 상태 <br />
        /// </remarks>
        [HttpGet("getBuyDetail")]
        public async Task<IActionResult> getBuyDetail(string date_begin, string date_end, string cust_code, string voucher_type, string keyword, string status, string page, string rows)
        {
            string RAmt = string.Empty;
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherBuyDetail> items = new List<VoucherBuyDetail>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_BUY_DETAIL",
            };

            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_cust_code", OracleDbType.Int32).Value = cust_code;
            cmd.Parameters.Add("in_voucher_type", OracleDbType.Varchar2, 20).Value = voucher_type;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 100).Value = keyword;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 2).Value = status;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_amt", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                RAmt = cmd.Parameters["out_amt"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherBuyDetail m = new VoucherBuyDetail
                    {
                        sale_no = rd["sale_no"].ToString(),
                        tuid = rd["tuid"].ToString(),
                        org_app_ymd = rd["org_app_ymd"].ToString(),
                        pay_gbn = rd["pay_gbn"].ToString(),
                        payment_amt = rd["payment_amt"].ToString(),
                        cancel_amt = rd["cancel_amt"].ToString(),
                        cust_telno = rd["cust_telno"].ToString(),
                        voucher_type = rd["voucher_type"].ToString(),
                        voucher_name = rd["voucher_name"].ToString(),
                        cnt = rd["cnt"].ToString(),
                        voucher_amt = rd["voucher_amt"].ToString(),
                        voucher_no = rd["voucher_no"].ToString(),
                        purchase_price = rd["purchase_price"].ToString(),
                        disc_amt = rd["disc_amt"].ToString(),
                        card_reciever = rd["card_reciever"].ToString(),
                        use_amt = rd["use_amt"].ToString(),
                        refund_amt = rd["refund_amt"].ToString(),
                        status = rd["status"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getBuyDetail : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, amt = RAmt, count = Rcount, data = items });
        }

        /// <summary>
        /// 구매내역 상세 엑셀출력
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// date_begin - date_end 기간 <br />
        /// cust_code : 구매자 회원코드 <br />
        /// voucher_type : 상품권 코드 <br />
        /// keyword : 검색키워드(받는사람, 구매번호, 상품권번호, 전화번호) <br />
        /// status : 상품권 상태 <br />
        /// </remarks>
        [HttpGet("getBuyDetailExcel")]
        public async Task<IActionResult> getBuyDetailExcel(string date_begin, string date_end, string cust_code, string voucher_type, string keyword, string status)
        {
            string RAmt = string.Empty;
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherBuyDetail> items = new List<VoucherBuyDetail>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_BUY_DETAIL_EXCEL",
            };

            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_cust_code", OracleDbType.Int32).Value = cust_code;
            cmd.Parameters.Add("in_voucher_type", OracleDbType.Varchar2, 20).Value = voucher_type;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 100).Value = keyword;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 2).Value = status;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add(date_begin + "-" + date_end);
                        var currentRow = 1;
                        var col = 1;

                        worksheet.Cell(currentRow, col++).Value = "구매일시";
                        worksheet.Cell(currentRow, col++).Value = "구매번호";
                        worksheet.Cell(currentRow, col++).Value = "상품권명";
                        worksheet.Cell(currentRow, col++).Value = "수량";
                        worksheet.Cell(currentRow, col++).Value = "액면가";
                        worksheet.Cell(currentRow, col++).Value = "상품권 번호";
                        worksheet.Cell(currentRow, col++).Value = "총 결제 금액";
                        worksheet.Cell(currentRow, col++).Value = "개별 결제 금액";
                        worksheet.Cell(currentRow, col++).Value = "할인 금액";
                        worksheet.Cell(currentRow, col++).Value = "받는사람 이름";
                        worksheet.Cell(currentRow, col++).Value = "받는사람 전화번호";
                        worksheet.Cell(currentRow, col++).Value = "사용금액";
                        worksheet.Cell(currentRow, col++).Value = "환불금액";
                        worksheet.Cell(currentRow, col++).Value = "상태";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;
                            col = 1;

                            worksheet.Cell(currentRow, col++).Value = rd["org_app_ymd"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["sale_no"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["voucher_name"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["cnt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["voucher_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["voucher_no"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["payment_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["purchase_price"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["disc_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["card_reciever"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["cust_telno"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["use_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["refund_amt"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["status"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "상품권 구매내역상세.xlsx");
                        }
                    }

                }
                
                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getBuyDetailExcel : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        #endregion

        #region[발송내역]
        /// <summary>
        /// 어드민 단체발송 목록 조회
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// prsc_gbn : 처리 구분 (M: 무상제공(이벤트), A: 고객앱구매(주문), B: 기업판매(기업)) <br />
        /// voucher_type : 상품권 코드 <br />
        /// status : 상태 ((WT: 결제대기, NO: 미등록, ER: 등록기간만료,  CC: 결제취소,  US: 등록완료, UD: 사용완료, EP: 기간만료, RR: 환불요청, RC: 환불완료, DU: 회원탈퇴) <br />
        /// send_gbn : 발송여부(빈값 전체, 0: 발송, 1: 발송대기, 2: 발송실패) <br />
        /// keyword : 회원명 검색(미등록 상태일 경우 수신자명) <br />
        /// <br />
        /// 결과 값 <br />
        /// cust_code : 회원코드 <br />
        /// cust_name : 회원명 <br />
        /// voucher_type : 상품권 코드 <br />
        /// voucher_name : 상품권명 <br />
        /// voucher_no : 상품권 번호 <br />
        /// voucher_amt : 상품권 금액 <br />
        /// send_gbn : 발송여부 <br />
        /// result_msg : 메모 <br />
        /// send_date : 발송일 <br />
        /// status : 상태 <br />
        /// </remarks>
        [HttpGet("getSendList")]
        public async Task<IActionResult> getSendList(string prsc_gbn, string voucher_type, string status, string send_gbn, string keyword, string date_begin, string date_end, string page, string rows)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherSendList> items = new List<VoucherSendList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_SEND_LIST",
            };

            cmd.Parameters.Add("in_prsc_gbn", OracleDbType.Varchar2, 1).Value = prsc_gbn;
            cmd.Parameters.Add("in_voucher_type", OracleDbType.Varchar2, 20).Value = voucher_type;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 2).Value = status;
            cmd.Parameters.Add("in_send_gbn", OracleDbType.Varchar2, 2).Value = send_gbn;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherSendList m = new VoucherSendList
                    {
                        cust_code = rd["cust_code"].ToString(),
                        cust_name = rd["cust_name"].ToString(),
                        voucher_type = rd["voucher_type"].ToString(),
                        voucher_name = rd["voucher_name"].ToString(),
                        voucher_no = rd["voucher_no"].ToString(),
                        voucher_amt = rd["voucher_amt"].ToString(),
                        send_gbn = rd["send_gbn"].ToString(),
                        result_msg = rd["result_msg"].ToString(),
                        send_date = rd["send_date"].ToString(),
                        status = rd["status"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getSendList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 주문, 대구로 상품권 재발행 처리
        /// </summary>
        /// <remarks>
        /// * 등록기간 만료된 상품권을 다시 미등록 상태로 되돌리고 일주일의 등록가능 기간 제공 <br/>
        /// </remarks>
        [HttpPut("setReissue")]
        public async Task<IActionResult> setReissue(string voucher_no, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            DynamicParameters param = new DynamicParameters();

            string sql = string.Empty;

            db.Open();

            try
            {
                param.Add("in_voucher_no", voucher_no);
                param.Add("in_mod_ucode", mod_ucode);
                param.Add("in_mod_name", mod_name);

                sql = @"select count(*) from voucher_mst
                        where voucher_no = :in_voucher_no
                        and status = 'ER'";

                int num = await db.QuerySingleAsync<int>(sql, param, commandType: CommandType.Text);

                if (num == 0)
                {
                    Rcode = "99";
                    Rmsg = "등록기간이 만료된 상품권이 아닙니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                sql = @" update voucher_mst
                            set status = 'NO',
                                reg_exp_date = to_char(sysdate + 7,'YYYYMMDD'),
                                mod_date = sysdate,
                                mod_ucode = :in_mod_ucode,
                                mod_name = :in_mod_name
                            where voucher_no = :in_voucher_no";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Voucher/setReissue : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion

        #region[유효기간내역]
        /// <summary>
        /// 유효기간 목록 조회
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// date_begin - date_end : 만료일자 범위기간 <br />
        /// prsc_gbn : 처리 구분 (M: 무상제공(이벤트), A: 고객앱구매(주문), B: 기업판매(기업)) <br />
        /// keyword : 회원명 또는 상품권명 검색 <br />
        /// <br />
        /// 결과 값 <br />
        /// prsc_gbn : 처리 구분 <br />
        /// reg_date : 등록일자 <br />
        /// use_exp_date : 만료일자 <br />
        /// cust_code : 회원코드 <br />
        /// cust_name : 회원명 <br />
        /// voucher_type : 상품권 타입 <br />
        /// voucher_name : 상품권명 <br />
        /// voucher_amt : 상품권 금액 <br />
        /// voucher_remain_amt : 상품권 잔액 <br />
        /// voucher_no : 상품권 번호 <br />
        /// send_yn : 메일발송여부 <br />
        /// </remarks>
        [HttpGet("getExpList")]
        public async Task<IActionResult> getExpList(string date_begin, string date_end, string prsc_gbn, string keyword, string page, string rows)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherExpList> items = new List<VoucherExpList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_EXP_LIST",
            };

            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_prsc_gbn", OracleDbType.Varchar2, 1).Value = prsc_gbn;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherExpList m = new VoucherExpList
                    {
                        prsc_gbn = rd["prsc_gbn"].ToString(),
                        reg_date = rd["reg_date"].ToString(),
                        use_exp_date = rd["use_exp_date"].ToString(),
                        cust_code = rd["cust_code"].ToString(),
                        cust_name = rd["cust_name"].ToString(),
                        voucher_type = rd["voucher_type"].ToString(),
                        voucher_name = rd["voucher_name"].ToString(),
                        voucher_amt = rd["voucher_amt"].ToString(),
                        voucher_remain_amt = rd["voucher_remain_amt"].ToString(),
                        voucher_no = rd["voucher_no"].ToString(),
                        send_yn = rd["send_yn"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getExpList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 사용유효기간 연장
        /// </summary>
        /// <remarks>
        /// voucher_no 상품권 번호(필수) <br/>
        /// day 연장일수(필수) <br/>
        /// ucode 작업자(필수) <br/>
        /// </remarks>
        [HttpPut("updateExp")]
        public async Task<IActionResult> updateExp(string voucher_no, string day, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.UPDATE_EXP",
            };

            cmd.Parameters.Add("in_voucher_no", OracleDbType.Varchar2, 30).Value = voucher_no;
            cmd.Parameters.Add("in_day", OracleDbType.Int32).Value = day;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/updateExp : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 유효기간 변경이력 조회
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// voucher_no : 상품권번호<br />
        /// <br />
        /// 결과 값 <br />
        /// memo : 내용 <br />
        /// hist_date : 변경일시 <br />
        /// </remarks>
        [HttpGet("getExpHist/{voucher_no}")]
        public async Task<IActionResult> getExpHist(string voucher_no)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<BasicLog> items = new List<BasicLog>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_EXP_HIST",
            };

            cmd.Parameters.Add("in_voucher_no", OracleDbType.Varchar2, 30).Value = voucher_no;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    BasicLog m = new BasicLog
                    {
                        memo = rd["memo"].ToString(),
                        hist_date = rd["hist_date"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getExpHist : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        #endregion


        #region[상품권 취소 처리]        
        /// <summary>
        /// 모바일 상품권 결제취소 대기
        /// </summary>
        /// <remarks>
        /// 결제취소를 위한 전처리 작업. <br/>        
        /// [request body] <br/>
        /// job_gbn : 작업구분(1: 결제취소대기로, 2: 미등록으로) <br/>
        /// sale_no : 거래번호 <br/>
        /// voucher_no : 상품권 번호 <br/>
        /// ucode : 발송담당자 코드(관리앱 결제취소의 경우만 입력)<br/>
        /// uname : 발송담당자명(관리앱 결제취소의 경우만 입력)
        /// </remarks>
        [HttpPut("setCancelWait")]
        public async Task<IActionResult> setCancelWait(VoucherCancelWait voucher)
        {

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.SET_VOUCHER_CANCEL_WAIT",
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 2).Value = voucher.job_gbn;
            cmd.Parameters.Add("in_sale_no", OracleDbType.Int32).Value = voucher.sale_no;
            var voucher_no = cmd.Parameters.Add("in_voucher_no", OracleDbType.Varchar2, 300);
            voucher_no.Direction = ParameterDirection.Input;
            voucher_no.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            voucher_no.Value = voucher.voucher_no.ToArray();
            voucher_no.Size = voucher.voucher_no.Count();
            voucher_no.ArrayBindSize = voucher.voucher_no.Select(_ => _.Length).ToArray();
            voucher_no.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, voucher.voucher_no.Count()).ToArray();

            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = voucher.ucode;
            cmd.Parameters.Add("in_uname", OracleDbType.Varchar2, 20).Value = voucher.uname;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/setKakaoSend : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 모바일 상품권 결제후 처리
        /// </summary>
        /// <remarks>
        /// KCP 결제취소 성공 후 작업. <br/>        
        /// [request body] <br/>
        /// job_gbn : 작업구분(2: 결제취소) <br/>
        /// sale_no : 거래번호 <br/>
        /// voucher_no : 상품권 번호 <br/>
        /// tuid : 거래번호(KCP) <br/>
        /// cancel_amt : 총 취소 금액 <br/>
        /// cancel_code : 취소사유코드 <br/>
        /// card_cancel_time : 카드 결제 취소 시간 <br/>
        /// cancel_reason : 취소사유 메모 <br/>
        /// ucode : 작업자 코드<br/>
        /// uname : 작업자 명
        /// </remarks>
        [HttpPut("setAfterApproval")]
        public async Task<IActionResult> setAfterApproval(VoucherAfterApproval voucher)
        {

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.SET_VOUCHER_AFTER_APPROVAL",
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 2).Value = voucher.job_gbn;
            cmd.Parameters.Add("in_sale_no", OracleDbType.Int32).Value = voucher.sale_no;
            cmd.Parameters.Add("in_sale_desc", OracleDbType.Varchar2, 50).Value = null;         //미사용

            var voucher_no = cmd.Parameters.Add("in_voucher_no", OracleDbType.Varchar2, 50);
            voucher_no.Direction = ParameterDirection.Input;
            voucher_no.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            voucher_no.Value = voucher.voucher_no.ToArray();
            voucher_no.Size = voucher.voucher_no.Count();
            voucher_no.ArrayBindSize = voucher.voucher_no.Select(_ => _.Length).ToArray();
            voucher_no.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, voucher.voucher_no.Count()).ToArray();

            cmd.Parameters.Add("in_tuid", OracleDbType.Varchar2, 70).Value = voucher.tuid;
            cmd.Parameters.Add("in_sale_date", OracleDbType.Varchar2, 8).Value = null;          //미사용
            cmd.Parameters.Add("in_buy_ccode", OracleDbType.Int32).Value = null;                //미사용
            cmd.Parameters.Add("in_buy_telno", OracleDbType.Varchar2, 20).Value = null;         //미사용
            cmd.Parameters.Add("in_vorder_amt", OracleDbType.Int32).Value = null;               //미사용
            cmd.Parameters.Add("in_disc_amt", OracleDbType.Int32).Value = null;                 //미사용
            cmd.Parameters.Add("in_payment_amt", OracleDbType.Int32).Value = null;              //미사용
            cmd.Parameters.Add("in_cancel_amt", OracleDbType.Int32).Value = voucher.cancel_amt;
            cmd.Parameters.Add("in_pay_gbn", OracleDbType.Varchar2, 1).Value = null;            //미사용
            cmd.Parameters.Add("in_card_approval_gbn", OracleDbType.Varchar2, 1).Value = null;  //미사용
            cmd.Parameters.Add("in_org_app_ymd", OracleDbType.Varchar2, 8).Value = null;        //미사용
            cmd.Parameters.Add("in_cancel_code", OracleDbType.Varchar2, 2).Value = voucher.cancel_code;
            cmd.Parameters.Add("in_card_cancel_time", OracleDbType.Varchar2, 14).Value = voucher.card_cancel_time;
            cmd.Parameters.Add("in_cancel_reason", OracleDbType.Varchar2, 500).Value = voucher.cancel_reason;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = voucher.ucode;
            cmd.Parameters.Add("in_uname", OracleDbType.Varchar2, 20).Value = voucher.uname;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/setAfterApproval : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion

        #region[결제취소 내역]
        /// <summary>
        /// 결제취소 목록 조회(7일간 미등록한 경우)
        /// </summary>
        /// <remarks>
        /// [parameter] <br />
        /// date_begin - date_end : 만료일자 범위기간 <br />
        /// status : 상태 (빈값: 전체, 1: 완료, 2:실패) <br />
        /// keyword : 회원명 또는 회원코드 검색 <br />
        /// <br />
        /// 결과 값 <br />
        /// cust_code : 회원코드 <br />
        /// cust_name : 회원명 <br />
        /// telno : 회원 전화번호 <br />
        /// voucher_type : 상품권 타입 <br />
        /// voucher_name : 상품권명 <br />
        /// voucher_amt : 상품권 금액 <br />
        /// voucher_no : 상품권 번호 <br />
        /// after_exp_dt : 취소날짜 <br />
        /// partial_cancel_dt : 처리날짜 <br />
        /// status : 상태 <br />
        /// fail_reason : (실패)사유 <br />
        /// </remarks>
        [HttpGet("getCancelList")]
        public async Task<IActionResult> getCancelList(string date_begin, string date_end, string status, string keyword, string page, string rows)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<VoucherCancelList> items = new List<VoucherCancelList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_VOUCHER.GET_CANCEL_LIST",
            };

            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 1).Value = status;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    VoucherCancelList m = new VoucherCancelList
                    {
                        cust_code = rd["cust_code"].ToString(),
                        cust_name = rd["cust_name"].ToString(),
                        telno = rd["telno"].ToString(),
                        sale_no = rd["sale_no"].ToString(),
                        voucher_type = rd["voucher_type"].ToString(),
                        voucher_name = rd["voucher_name"].ToString(),
                        voucher_amt = rd["voucher_amt"].ToString(),
                        voucher_no = rd["voucher_no"].ToString(),
                        after_exp_dt = rd["after_exp_dt"].ToString(),
                        partial_cancel_dt = rd["partial_cancel_dt"].ToString(),
                        status = rd["status"].ToString(),
                        fail_reason = rd["fail_reason"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Voucher/getCancelList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        #endregion
    }
}
