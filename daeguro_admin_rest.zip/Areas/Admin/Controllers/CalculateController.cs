﻿using ClosedXML.Excel;
using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class CalculateController : ControllerBase
    {
        /// <summary>
        /// 적립구분 - 목록 조회
        /// </summary>
        /// <remarks>
        /// charge_gbn 적립구분 코드 <br/>
        /// charge_name 적립구분명 <br/>
        /// </remarks>
        [HttpGet("getChargeGbn")]
        public async Task<IActionResult> getChargeGbn()
        {
            string Rcode;
            string Rmsg;
            List<ChargeGbn> items = new List<ChargeGbn>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            //param.Add("base_gbn", base_gbn);
            //param.Add("class_gbn", class_gbn);

            string sql = @$"
                            SELECT charge_gbn, charge_name,
                                   sort_seq
                            FROM charge_mst
                            ORDER BY SORT_SEQ
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync<ChargeGbn>(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 주문별 정산금액 조회(기간조건:ORG_APP_YMD 결제승인/카드결제가 아닌경우 ORDER_TIME 주문시간)
        /// </summary>
        /// <remarks>
        /// payGbn 결제 구분 : 1. 만나서 현금, 3. 앱결제(PG), 5. 만나서 카드 <br />
        /// service_gbn : 서비스 구분(빈값 : 전체, 0 : 주문, 1 : 특별관, 2 : 꽃배달, 3 : 로컬푸드, 4 : 전통시장, 5 : 전자관) <br />
        /// divKey : 0. 가맹점명, 1. 전화번호 <br />
        /// </remarks>
        [HttpGet("getOrderCalculateList")]
        public async Task<IActionResult> getOrderCalculateList(string mcode, string status, string payGbn, string service_gbn, string date_begin, string date_end, int divKey, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalCount = string.Empty;
            object RCount = string.Empty;


            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_mcode", mcode);
                param.Add("in_status", status);
                param.Add("pay_gbn", payGbn);
                param.Add("service_gbn", service_gbn);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("keyword", "%" + keyword + "%");
                param.Add("div_key", divKey);
                param.Add("page", page);
                param.Add("row_count", rows);

                string statusSql = string.Empty;
                string paySql = string.Empty;
                string divSql = string.Empty;


                string sql = $@"
                                select t3.* , 
                                       C.CUST_NAME, NVL(Y.PGM_AMT,0)                  AS PGM_AMT,
                                       NVL(Y.PG_PGM_AMT,0)                            AS PG_PGM_AMT,
                                       ( NVL(Y.PGM_AMT,0)  + NVL(Y.PG_PGM_AMT,0) )    AS PGM_SUM_AMT
                                 from (SELECT t2.*
                                       FROM (SELECT ROWNUM AS rnum, t1.*
                                            FROM (select * 
                                                  from (select nvl(A.ORDER_NO,0) as ORDER_NO,
                                                                 TO_CHAR(A.ORDER_TIME,'YYYYMMDD')               AS ORDER_DATE_P,
                                                                 A.ORDER_DATE,
                                                                 TO_CHAR(A.ORDER_TIME,'AM HH:MI:SS')            AS ORDER_TIME,
                                                                  (CASE     WHEN A.STATUS = '10' THEN '접수'
                                                                           WHEN A.STATUS = '20' THEN '대기'
                                                                           WHEN A.STATUS = '30' THEN '확인'
                                                                           WHEN A.STATUS = '35' THEN '기사운행'
                                                                           WHEN A.STATUS = '40' THEN '완료'
                                                                           WHEN A.STATUS = '50' THEN '취소'
                                                                           WHEN A.STATUS = '70' THEN '포장'
                                                                           WHEN A.STATUS = '80' THEN '결제대기'
                                                                           WHEN A.STATUS = '90' THEN '예약'                               
                                                                  END)                                          AS STATUS,
                                                                 B.SHOP_NAME,
                                                                 B.SERVICE_GBN,
                                                                 A.TELNO,
                                                                 A.MENU_AMT,
                                                                 A.DELI_TIP_AMT,
                                                                 A.TOT_AMT,
                                                                 NVL(A.COUPON_AMT,0) + NVL(A.COUPON_AMT2,0)     AS COUPON_AMT,
                                                                 A.MILEAGE_USE_AMT,
                                                                 A.DISC_AMT,
                                                                 A.AMOUNT,        -- 카드 또는 마일리지 적립 기준금액, 
                                                                 (CASE WHEN A.PAY_GBN = '1' THEN '현금'
                                                                       WHEN A.PAY_GBN = '2' THEN '카드'
                                                                       WHEN A.PAY_GBN = '3' THEN '외상'
                                                                       WHEN A.PAY_GBN = '4' THEN '쿠폰(가맹점 자체)'
                                                                       WHEN A.PAY_GBN = '5' THEN '마일리지'
                                                                       WHEN A.PAY_GBN = '7' THEN '행복페이'
                                                                       WHEN A.PAY_GBN = '8' THEN '제로페이'
                                                                       WHEN A.PAY_GBN = '9' THEN '선결제'
                                                                       WHEN A.PAY_GBN = 'P' THEN '휴대폰'
                                                                       WHEN A.PAY_GBN = 'B' THEN '계좌이체' END)  AS PAY_GBN,    -- 지급구분(1:현금, 2:카드, 3:외상, 4.쿠폰(가맹점 자체), 5:마일리지, 7:행복페이, 8:제로페이, 9:선결제, P:휴대폰, B:계좌이체)
                                                                 (CASE WHEN A.APP_PAY_GBN = '1' THEN '만나서 현금'
                                                                       WHEN A.APP_PAY_GBN = '5' THEN '만나서 카드'
                                                                       WHEN A.APP_PAY_GBN = '3' THEN 'PG' END)  AS APP_PAY_GBN,   -- 현장결제구분('1':현장(배달시 현금), '3':앱결제, '5':현장(배달시 카드))
                                                                 A.CCODE  ,
                                                                 SUM(e.DISC_USE_AMT) AS ETC_DISC_AMT   
                                                        FROM    DORDER A, SHOP_INFO B, CALLCENTER D, DORDER_DISC_DETAIL E
                                                        WHERE   A.CCCODE        = B.CCCODE
                                                        AND     A.SHOP_CD       = B.SHOP_CD
                                                        AND     A.CCCODE        = D.CCCODE
                                                        AND     D.MCODE         = :in_mcode
                                                        and     a.order_no = e.order_no (+)
                                                        and     a.cccode = e.cccode (+)
                                                        and     a.order_date = e.order_date (+)
                                                        AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                                        AND     case when a.app_pay_gbn = '3' then A.ORG_APP_YMD else to_char(a.order_time,'YYYYMMDD')||'000000' end   BETWEEN :in_fr_dt||'000000' AND  :in_to_dt||'235959'
                                                        AND     A.STATUS like case when :in_status is null then '%' else :in_status end
                                                        AND     A.APP_PAY_GBN like case when :pay_gbn is null then '%' else :pay_gbn end 
                                                        AND     B.SERVICE_GBN like case when :service_gbn is null then '%' else :service_gbn end 
                                                        AND     B.SHOP_NAME like case when :div_key = 0 then :keyword else '%' end
                                                        AND     A.TELNO like case when :div_key = 1 then :keyword else '%' end
                                                        AND     A.PRCS_GBN      = 'A'
                                                        AND     A.TEST_GBN = 'N'
                                                        AND     NVL(CANCEL_CODE, '00') <> '30'  
                                                        group by nvl(A.ORDER_NO,0),
                                                                 TO_CHAR(A.ORDER_TIME,'YYYYMMDD'),
                                                                 A.ORDER_DATE,
                                                                 TO_CHAR(A.ORDER_TIME,'AM HH:MI:SS'),
                                                                  (CASE     WHEN A.STATUS = '10' THEN '접수'
                                                                           WHEN A.STATUS = '20' THEN '대기'
                                                                           WHEN A.STATUS = '30' THEN '확인'
                                                                           WHEN A.STATUS = '35' THEN '기사운행'
                                                                           WHEN A.STATUS = '40' THEN '완료'
                                                                           WHEN A.STATUS = '50' THEN '취소'
                                                                           WHEN A.STATUS = '70' THEN '포장'
                                                                           WHEN A.STATUS = '80' THEN '결제대기'
                                                                           WHEN A.STATUS = '90' THEN '예약'                               
                                                                  END),
                                                                 B.SHOP_NAME,
                                                                 B.SERVICE_GBN,
                                                                 A.TELNO,
                                                                 A.MENU_AMT,
                                                                 A.DELI_TIP_AMT,
                                                                 A.TOT_AMT,
                                                                 NVL(A.COUPON_AMT,0) + NVL(A.COUPON_AMT2,0),
                                                                 A.MILEAGE_USE_AMT,
                                                                 A.DISC_AMT,
                                                                 A.AMOUNT,        -- 카드 또는 마일리지 적립 기준금액, 
                                                                 (CASE WHEN A.PAY_GBN = '1' THEN '현금'
                                                                       WHEN A.PAY_GBN = '2' THEN '카드'
                                                                       WHEN A.PAY_GBN = '3' THEN '외상'
                                                                       WHEN A.PAY_GBN = '4' THEN '쿠폰(가맹점 자체)'
                                                                       WHEN A.PAY_GBN = '5' THEN '마일리지'
                                                                       WHEN A.PAY_GBN = '7' THEN '행복페이'
                                                                       WHEN A.PAY_GBN = '8' THEN '제로페이'
                                                                       WHEN A.PAY_GBN = '9' THEN '선결제'
                                                                       WHEN A.PAY_GBN = 'P' THEN '휴대폰'
                                                                       WHEN A.PAY_GBN = 'B' THEN '계좌이체' END),    -- 지급구분(1:현금, 2:카드, 3:외상, 4.쿠폰(가맹점 자체), 5:마일리지, 7:행복페이, 8:제로페이, 9:선결제, P:휴대폰, B:계좌이체)
                                                                 (CASE WHEN A.APP_PAY_GBN = '1' THEN '만나서 현금'
                                                                       WHEN A.APP_PAY_GBN = '5' THEN '만나서 카드'
                                                                       WHEN A.APP_PAY_GBN = '3' THEN 'PG' END),   -- 현장결제구분('1':현장(배달시 현금), '3':앱결제, '5':현장(배달시 카드))
                                                                 A.CCODE
                                                        union all
                                                        select /*+ full(A) leading(A) */ nvl(A.ORDER_NO,0) as ORDER_NO,
                                                                 TO_CHAR(A.ORDER_TIME,'YYYYMMDD')               AS ORDER_DATE_P,
                                                                 A.ORDER_DATE,
                                                                 TO_CHAR(A.ORDER_TIME,'AM HH:MI:SS')            AS ORDER_TIME,
                                                                  (CASE     WHEN A.STATUS = '10' THEN '접수'
                                                                           WHEN A.STATUS = '20' THEN '대기'
                                                                           WHEN A.STATUS = '30' THEN '확인'
                                                                           WHEN A.STATUS = '35' THEN '기사운행'
                                                                           WHEN A.STATUS = '40' THEN '완료'
                                                                           WHEN A.STATUS = '50' THEN '취소'
                                                                           WHEN A.STATUS = '70' THEN '포장'
                                                                           WHEN A.STATUS = '80' THEN '결제대기'
                                                                           WHEN A.STATUS = '90' THEN '예약'                               
                                                                  END)                                          AS STATUS,
                                                                 B.SHOP_NAME,
                                                                 B.SERVICE_GBN,
                                                                 A.TELNO,
                                                                 A.MENU_AMT,
                                                                 A.DELI_TIP_AMT,
                                                                 A.TOT_AMT,
                                                                 NVL(A.COUPON_AMT,0) + NVL(A.COUPON_AMT2,0)     AS COUPON_AMT,
                                                                 A.MILEAGE_USE_AMT,
                                                                 A.DISC_AMT,
                                                                 A.AMOUNT,        -- 카드 또는 마일리지 적립 기준금액, 
                                                                 (CASE WHEN A.PAY_GBN = '1' THEN '현금'
                                                                       WHEN A.PAY_GBN = '2' THEN '카드'
                                                                       WHEN A.PAY_GBN = '3' THEN '외상'
                                                                       WHEN A.PAY_GBN = '4' THEN '쿠폰(가맹점 자체)'
                                                                       WHEN A.PAY_GBN = '5' THEN '마일리지'
                                                                       WHEN A.PAY_GBN = '7' THEN '행복페이'
                                                                       WHEN A.PAY_GBN = '8' THEN '제로페이'
                                                                       WHEN A.PAY_GBN = '9' THEN '선결제'
                                                                       WHEN A.PAY_GBN = 'P' THEN '휴대폰'
                                                                       WHEN A.PAY_GBN = 'B' THEN '계좌이체' END)  AS PAY_GBN,    -- 지급구분(1:현금, 2:카드, 3:외상, 4.쿠폰(가맹점 자체), 5:마일리지, 7:행복페이, 8:제로페이, 9:선결제, P:휴대폰, B:계좌이체)
                                                                 (CASE WHEN A.APP_PAY_GBN = '1' THEN '만나서 현금'
                                                                       WHEN A.APP_PAY_GBN = '5' THEN '만나서 카드'
                                                                       WHEN A.APP_PAY_GBN = '3' THEN 'PG' END)  AS APP_PAY_GBN,   -- 현장결제구분('1':현장(배달시 현금), '3':앱결제, '5':현장(배달시 카드))
                                                                 A.CCODE,
                                                                 SUM(e.DISC_USE_AMT) AS ETC_DISC_AMT   
                                                        FROM    DORDER_past A, SHOP_INFO B, CALLCENTER D, DORDER_DISC_DETAIL E
                                                        WHERE   A.CCCODE        = B.CCCODE
                                                        AND     A.SHOP_CD       = B.SHOP_CD
                                                        AND     A.CCCODE        = D.CCCODE
                                                        AND     D.MCODE         = :in_mcode
                                                        and     a.order_no = e.order_no (+)
                                                        and     a.cccode = e.cccode (+)
                                                        and     a.order_date = e.order_date (+)
                                                        AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                                        AND     case when a.app_pay_gbn = '3' then A.ORG_APP_YMD else to_char(a.order_time,'YYYYMMDD')||'000000' end   BETWEEN :in_fr_dt||'000000' AND  :in_to_dt||'235959'
                                                        AND     A.STATUS like case when :in_status is null then '%' else :in_status end
                                                        AND     A.APP_PAY_GBN like case when :pay_gbn is null then '%' else :pay_gbn end 
                                                        AND     B.SERVICE_GBN like case when :service_gbn is null then '%' else :service_gbn end 
                                                        AND     B.SHOP_NAME like case when :div_key = 0 then :keyword else '%' end
                                                        AND     A.TELNO like case when :div_key = 1 then :keyword else '%' end
                                                        AND     A.PRCS_GBN      = 'A'
                                                        AND     A.TEST_GBN = 'N'
                                                        AND     NVL(CANCEL_CODE, '00') <> '30' 
                                                        group by nvl(A.ORDER_NO,0),
                                                                 TO_CHAR(A.ORDER_TIME,'YYYYMMDD'),
                                                                 A.ORDER_DATE,
                                                                 TO_CHAR(A.ORDER_TIME,'AM HH:MI:SS'),
                                                                  (CASE     WHEN A.STATUS = '10' THEN '접수'
                                                                           WHEN A.STATUS = '20' THEN '대기'
                                                                           WHEN A.STATUS = '30' THEN '확인'
                                                                           WHEN A.STATUS = '35' THEN '기사운행'
                                                                           WHEN A.STATUS = '40' THEN '완료'
                                                                           WHEN A.STATUS = '50' THEN '취소'
                                                                           WHEN A.STATUS = '70' THEN '포장'
                                                                           WHEN A.STATUS = '80' THEN '결제대기'
                                                                           WHEN A.STATUS = '90' THEN '예약'                               
                                                                  END),
                                                                 B.SHOP_NAME,
                                                                 B.SERVICE_GBN,
                                                                 A.TELNO,
                                                                 A.MENU_AMT,
                                                                 A.DELI_TIP_AMT,
                                                                 A.TOT_AMT,
                                                                 NVL(A.COUPON_AMT,0) + NVL(A.COUPON_AMT2,0),
                                                                 A.MILEAGE_USE_AMT,
                                                                 A.DISC_AMT,
                                                                 A.AMOUNT,        -- 카드 또는 마일리지 적립 기준금액, 
                                                                 (CASE WHEN A.PAY_GBN = '1' THEN '현금'
                                                                       WHEN A.PAY_GBN = '2' THEN '카드'
                                                                       WHEN A.PAY_GBN = '3' THEN '외상'
                                                                       WHEN A.PAY_GBN = '4' THEN '쿠폰(가맹점 자체)'
                                                                       WHEN A.PAY_GBN = '5' THEN '마일리지'
                                                                       WHEN A.PAY_GBN = '7' THEN '행복페이'
                                                                       WHEN A.PAY_GBN = '8' THEN '제로페이'
                                                                       WHEN A.PAY_GBN = '9' THEN '선결제'
                                                                       WHEN A.PAY_GBN = 'P' THEN '휴대폰'
                                                                       WHEN A.PAY_GBN = 'B' THEN '계좌이체' END),    -- 지급구분(1:현금, 2:카드, 3:외상, 4.쿠폰(가맹점 자체), 5:마일리지, 7:행복페이, 8:제로페이, 9:선결제, P:휴대폰, B:계좌이체)
                                                                 (CASE WHEN A.APP_PAY_GBN = '1' THEN '만나서 현금'
                                                                       WHEN A.APP_PAY_GBN = '5' THEN '만나서 카드'
                                                                       WHEN A.APP_PAY_GBN = '3' THEN 'PG' END),   -- 현장결제구분('1':현장(배달시 현금), '3':앱결제, '5':현장(배달시 카드))
                                                                 A.CCODE)
                                                ORDER   BY ORDER_NO DESC , ORDER_TIME DESC)t1
                                             WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                                        WHERE (( :page - 1) * :row_count) < rnum ) t3, (select cust_code, cust_name from APP_CUSTOMER union all select cust_code, cust_name from APP_CUSTOMER_deleted) c, 
                                        ( SELECT  ORDER_DATE,
                                                ORDER_NO ,
                                                SUM(CASE WHEN CHARGE_GBN  = 'P' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT ELSE CHARGE_AMT * -1 END ELSE 0 END ) AS PGM_AMT,     -- 중개수수료
                                                SUM(CASE WHEN CHARGE_GBN  = 'K' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT ELSE CHARGE_AMT * -1 END ELSE 0 END ) AS PG_PGM_AMT   -- PG수수료
                                        FROM    INSUNG_CALC 
                                        WHERE      ORDER_DATE    BETWEEN :in_fr_dt - 1 AND :in_to_dt + 1
                                        AND     CHARGE_GBN  IN ( 'P', 'K' )  
                                        GROUP BY   ORDER_DATE, 
                                                    ORDER_NO ) Y
                                where   t3.CCODE         = C.CUST_CODE
                                AND     t3.ORDER_DATE   = Y.ORDER_DATE  (+) 
                                AND     t3.ORDER_NO     = Y.ORDER_NO    (+)  
                                order by t3.rnum
                                ";
  
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                var totalSql = @"
                                 SELECT nvl(COUNT(*),0) FROM(  SELECT   A.ORDER_NO                                    
                                                        FROM    DORDER A, SHOP_INFO B, APP_CUSTOMER C  , CALLCENTER D     
                                                        WHERE   A.CCCODE        = B.CCCODE
                                                        AND     A.SHOP_CD       = B.SHOP_CD
                                                        AND     A.CCODE         = C.CUST_CODE
                                                        AND     A.CCCODE        = D.CCCODE
                                                        AND     D.MCODE         = :in_mcode
                                                        AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                                        AND     A.PRCS_GBN      = 'A'
                                                        AND     A.TEST_GBN = 'N'
                                                        AND     NVL(CANCEL_CODE, '00') <> '30'     
                                                UNION ALL
                                                    SELECT   A.ORDER_NO                                    
                                                        FROM    DORDER_PAST A, SHOP_INFO B, APP_CUSTOMER C  , CALLCENTER D    
                                                        WHERE   A.CCCODE        = B.CCCODE
                                                        AND     A.SHOP_CD       = B.SHOP_CD
                                                        AND     A.CCODE         = C.CUST_CODE
                                                        AND     A.CCCODE        = D.CCCODE
                                                        AND     D.MCODE         = :in_mcode
                                                        AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                                        AND     A.PRCS_GBN      = 'A'
                                                        AND     A.TEST_GBN = 'N'
                                                        AND     NVL(CANCEL_CODE, '00') <> '30'   
                                  ) Z
                                ";

                //RtotalCount = await db.ExecuteScalarAsync<string>(totalSql, param, commandType: CommandType.Text);


                var countSql = $@"
                                    select nvl(count(*),0) as count from (select nvl(A.ORDER_NO,0) as ORDER_NO
                                FROM    DORDER A, SHOP_INFO B, CALLCENTER D
                                WHERE   A.CCCODE        = B.CCCODE
                                AND     A.SHOP_CD       = B.SHOP_CD
                                AND     A.CCCODE        = D.CCCODE
                                AND     D.MCODE         = :in_mcode
                                AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND     case when a.app_pay_gbn = '3' then A.ORG_APP_YMD else to_char(a.order_time,'YYYYMMDD')||'000000' end   BETWEEN :in_fr_dt||'000000' AND  :in_to_dt||'235959'
                                AND     A.STATUS like case when :in_status is null then '%' else :in_status end
                                AND     A.APP_PAY_GBN like case when :pay_gbn is null then '%' else :pay_gbn end 
                                AND     B.SERVICE_GBN like case when :service_gbn is null then '%' else :service_gbn end 
                                AND     B.SHOP_NAME like case when :div_key = 0 then :keyword else '%' end
                                AND     A.TELNO like case when :div_key = 1 then :keyword else '%' end
                                AND     A.PRCS_GBN      = 'A'
                                AND     A.TEST_GBN = 'N'
                                AND     NVL(CANCEL_CODE, '00') <> '30'  
                                union all
                                select /*+ full(A) leading(A) */ nvl(A.ORDER_NO,0) as ORDER_NO
                                FROM    DORDER_past A, SHOP_INFO B, CALLCENTER D
                                WHERE   A.CCCODE        = B.CCCODE
                                AND     A.SHOP_CD       = B.SHOP_CD
                                AND     A.CCCODE        = D.CCCODE
                                AND     D.MCODE         = :in_mcode
                                AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND     case when a.app_pay_gbn = '3' then A.ORG_APP_YMD else to_char(a.order_time,'YYYYMMDD')||'000000' end   BETWEEN :in_fr_dt||'000000' AND  :in_to_dt||'235959'
                                AND     A.STATUS like case when :in_status is null then '%' else :in_status end
                                AND     A.APP_PAY_GBN like case when :pay_gbn is null then '%' else :pay_gbn end 
                                AND     B.SERVICE_GBN like case when :service_gbn is null then '%' else :service_gbn end 
                                AND     B.SHOP_NAME like case when :div_key = 0 then :keyword else '%' end
                                AND     A.TELNO like case when :div_key = 1 then :keyword else '%' end
                                AND     A.PRCS_GBN      = 'A'
                                AND     A.TEST_GBN = 'N'
                                AND     NVL(CANCEL_CODE, '00') <> '30')  
                                ";

                

                RCount = await db.ExecuteScalarAsync<Int64>(countSql, param, commandType: CommandType.Text);
                //RCount = await db.QuerySingleAsync<object>(countSql, param, commandType: CommandType.Text);


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Calculate/getOrderCalculateList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
        }

        //주문번호별 정산금액 합계 쿼리
        [HttpGet("getOrderCalculateSum")]
        public async Task<IActionResult> getOrderCalculateSum(string mcode, string status, string payGbn, string date_begin, string date_end, int divKey, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object data = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("in_mcode", mcode);
                param.Add("in_status", status);
                param.Add("pay_gbn", payGbn);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("keyword", "%" + keyword + "%");
                param.Add("div_key", divKey);

                db.Open();

                string sql = @"
                                SELECT nvl(COUNT(*),0) AS COUNT,
                                 nvl(COUNT(CASE WHEN STATUS = '40' THEN 1 END),0) AS COMP, 
                                 nvl(COUNT(CASE WHEN STATUS = '50' THEN 1 END),0) AS CANC,
                                 nvl(SUM(CASE WHEN STATUS = '40' THEN MENU_AMT ELSE 0 END),0) AS SUM_MENU_AMT,
                                 nvl(SUM(CASE WHEN STATUS = '40' THEN DELI_TIP_AMT ELSE 0 END),0) AS SUM_DELI_TIP_AMT,
                                 nvl(SUM(CASE WHEN STATUS = '40' THEN TOT_AMT ELSE 0 END),0) AS SUM_TOT_AMT,
                                 nvl(SUM(CASE WHEN STATUS = '40' THEN COUPON_AMT ELSE 0 END),0) AS SUM_COUPON_AMT,
                                 nvl(SUM(CASE WHEN STATUS = '40' THEN MILEAGE_USE_AMT ELSE 0 END),0) AS SUM_MILEAGE_USE_AMT,
                                 nvl(SUM(CASE WHEN STATUS = '40' THEN ETC_DISC_AMT ELSE 0 END),0) AS SUM_ETC_DISC_AMT,
                                 nvl(SUM(CASE WHEN STATUS = '40' THEN DISC_AMT ELSE 0 END ),0) AS SUM_DISC_AMT,
                                 nvl(SUM(CASE WHEN STATUS = '40' THEN AMOUNT ELSE 0 END ),0) AS SUM_AMOUNT,
                                 nvl(SUM(CASE WHEN STATUS = '40' THEN PGM_AMT ELSE 0 END ),0) AS SUM_PGM_AMT,
                                 nvl(SUM(CASE WHEN STATUS = '40' THEN PG_PGM_AMT ELSE 0 END ),0) AS SUM_PG_PGM_AMT,
                                 nvl(SUM(CASE WHEN STATUS = '40' THEN PGM_SUM_AMT ELSE 0 END ),0) AS SUM_PGM_SUM_AMT
                                 FROM(  SELECT   A.STATUS,
                                                 A.MENU_AMT, 
                                                 A.DELI_TIP_AMT, 
                                                 A.TOT_AMT,      
                                                 NVL(A.COUPON_AMT,0) + NVL(A.COUPON_AMT2,0)     AS COUPON_AMT,
                                                 A.MILEAGE_USE_AMT ,
                                                 NVL(X.ETC_DISC_AMT,0)                          AS ETC_DISC_AMT,
                                                 A.DISC_AMT,
                                                 A.AMOUNT,
                                                 NVL(Y.PGM_AMT,0)                               AS PGM_AMT,
                                                 NVL(Y.PG_PGM_AMT,0)                            AS PG_PGM_AMT,
                                                 ( NVL(Y.PGM_AMT,0)  + NVL(Y.PG_PGM_AMT,0) )    AS PGM_SUM_AMT
                                        FROM     DORDER A, SHOP_INFO B, CALLCENTER D,
                                        (   SELECT     ORDER_DATE, 
                                                        ORDER_NO,
                                                        SUM(DISC_USE_AMT) AS ETC_DISC_AMT 
                                            FROM       DORDER_DISC_DETAIL
                                            WHERE      ORDER_DATE    BETWEEN :in_fr_dt - 1 AND :in_to_dt + 1
                                            GROUP BY   ORDER_DATE, 
                                                        ORDER_NO ) X,
                                        ( SELECT  ORDER_DATE, 
                                                ORDER_NO ,
                                                SUM(CASE WHEN CHARGE_GBN  = 'P' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT ELSE CHARGE_AMT * -1 END ELSE 0 END ) AS PGM_AMT,     -- 중개수수료
                                                SUM(CASE WHEN CHARGE_GBN  = 'K' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT ELSE CHARGE_AMT * -1 END ELSE 0 END ) AS PG_PGM_AMT   -- PG수수료
                                        FROM    INSUNG_CALC 
                                        WHERE      CHARGE_DATE    BETWEEN TO_DATE(:in_fr_dt ||' 000000', 'YYYYMMDD HH24MISS') - 1 AND  TO_DATE(:in_to_dt ||' 235959', 'YYYYMMDD HH24MISS') + 1
                                        AND     CHARGE_GBN  IN ( 'P', 'K' )  
                                        GROUP BY   ORDER_DATE, 
                                                    ORDER_NO ) Y 
                                        WHERE   A.CCCODE        = B.CCCODE
                                        AND     A.SHOP_CD       = B.SHOP_CD
                                        AND     A.CCCODE        = D.CCCODE
                                        AND     D.MCODE         = :in_mcode
                                        AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND     case when a.app_pay_gbn = '3' then A.ORG_APP_YMD else to_char(a.order_time,'YYYYMMDD')||'000000' end   BETWEEN :in_fr_dt||'000000' AND  :in_to_dt||'235959'
                                        AND     A.PRCS_GBN      = 'A'
                                        AND     A.TEST_GBN = 'N'
                                        AND     NVL(CANCEL_CODE, '00') <> '30'   
                                        AND     A.ORDER_DATE   = X.ORDER_DATE  (+)                       
                                        AND     A.ORDER_NO     = X.ORDER_NO    (+) 
                                        AND     A.ORDER_DATE   = Y.ORDER_DATE  (+) 
                                        AND     A.ORDER_NO     = Y.ORDER_NO    (+) 
                                UNION ALL
                                    SELECT       A.STATUS,
                                                 A.MENU_AMT, 
                                                 A.DELI_TIP_AMT, 
                                                 A.TOT_AMT,      
                                                 NVL(A.COUPON_AMT,0) + NVL(A.COUPON_AMT2,0)     AS COUPON_AMT,
                                                 A.MILEAGE_USE_AMT,
                                                 NVL(X.ETC_DISC_AMT,0)                          AS ETC_DISC_AMT,
                                                 A.DISC_AMT,
                                                 A.AMOUNT,
                                                 NVL(Y.PGM_AMT,0)                               AS PGM_AMT,
                                                 NVL(Y.PG_PGM_AMT,0)                            AS PG_PGM_AMT,
                                                 ( NVL(Y.PGM_AMT,0)  + NVL(Y.PG_PGM_AMT,0) )    AS PGM_SUM_AMT                                    
                                        FROM    DORDER_PAST A, SHOP_INFO B, CALLCENTER D,
                                        (   SELECT     ORDER_DATE, 
                                                        ORDER_NO,
                                                        SUM(DISC_USE_AMT) AS ETC_DISC_AMT 
                                            FROM       DORDER_DISC_DETAIL
                                            WHERE      ORDER_DATE    BETWEEN :in_fr_dt - 1 AND :in_to_dt + 1
                                            GROUP BY   ORDER_DATE, 
                                                        ORDER_NO ) X,
                                        ( SELECT  ORDER_DATE, 
                                                ORDER_NO ,
                                                SUM(CASE WHEN CHARGE_GBN  = 'P' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT ELSE CHARGE_AMT * -1 END ELSE 0 END ) AS PGM_AMT,     -- 중개수수료
                                                SUM(CASE WHEN CHARGE_GBN  = 'K' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT ELSE CHARGE_AMT * -1 END ELSE 0 END ) AS PG_PGM_AMT   -- PG수수료
                                        FROM    INSUNG_CALC 
                                        WHERE      CHARGE_DATE    BETWEEN TO_DATE(:in_fr_dt ||' 000000', 'YYYYMMDD HH24MISS') - 1 AND  TO_DATE(:in_to_dt ||' 235959', 'YYYYMMDD HH24MISS') + 1
                                        AND     CHARGE_GBN  IN ( 'P', 'K' )  
                                        GROUP BY   ORDER_DATE, 
                                                    ORDER_NO ) Y 
                                        WHERE   A.CCCODE        = B.CCCODE
                                        AND     A.SHOP_CD       = B.SHOP_CD
                                        AND     A.CCCODE        = D.CCCODE
                                        AND     D.MCODE         = :in_mcode
                                        AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND     case when a.app_pay_gbn = '3' then A.ORG_APP_YMD else to_char(a.order_time,'YYYYMMDD')||'000000' end   BETWEEN :in_fr_dt||'000000' AND  :in_to_dt||'235959'
                                        AND     A.PRCS_GBN      = 'A'
                                        AND     A.TEST_GBN = 'N'
                                        AND     NVL(CANCEL_CODE, '00') <> '30'  
                                        AND     A.ORDER_DATE   = X.ORDER_DATE  (+)                       
                                        AND     A.ORDER_NO     = X.ORDER_NO    (+) 
                                        AND     A.ORDER_DATE   = Y.ORDER_DATE  (+) 
                                        AND     A.ORDER_NO     = Y.ORDER_NO    (+) 
                                  ) Z
                ";

                data = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Calculate/getOrderCalculateSum : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = data });
        }



        /// <summary>
        /// 가맹점 적립금 관리 - 목록 조회(기간조건:CHARGE_DATE 정산일자)
        /// </summary>
        [HttpGet("getShopCalculateList")]
        public async Task<IActionResult> getShopCalculateList(string mcode, string date_begin, string date_end, int divKey, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object RtotalCount = string.Empty;
            object RCount = string.Empty;


            List<object> items = new List<object>();

            try
            {

                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("mcode", mcode);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("div_key", divKey);
                param.Add("keyword", "%" + keyword + "%");
                param.Add("page", page);
                param.Add("row_count", rows);

                
                string sql = $@"
                                SELECT t2.*,
                                        nvl(sum(case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end),0) as all_amt, 
                                        sum(CASE WHEN a.IO_GBN = 'I' and a.memo not like '계좌이체요청 %' THEN a.CHARGE_AMT ELSE 0 END)  AS IN_AMT, 
                                        sum(nvl(case when a.charge_gbn = 'P' then case when a.io_gbn = 'O' then a.charge_amt else a.charge_amt * -1 end  end,0)) as p_amt, 
                                        sum(nvl(case when a.charge_gbn = 'K' then case when a.io_gbn = 'O' then a.charge_amt else a.charge_amt * -1 end  end,0)) as k_amt, 
                                        sum(CASE WHEN a.memo like '계좌이체요청 출금%' THEN 1
                                                 WHEN a.memo like '계좌이체요청 실패%' THEN -1 END) as take_count, 
                                        sum(CASE WHEN a.memo like '계좌이체요청 %' THEN a.CHARGE_AMT ELSE 0 END)  AS take_amt
                                FROM (SELECT ROWNUM AS rnum, t1.*
                                    FROM (select b.mcode,
                                       a.cccode,
                                       a.SHOP_CD,
                                       a.SHOP_NAME,
                                       a.REG_NO,
                                       a.REMAIN_AMT
                                from shop_info a, callcenter b
                                where a.cccode = b.cccode
                                and b.mcode = :mcode
                                AND a.SHOP_NAME LIKE CASE WHEN: DIV_KEY = 1 THEN :KEYWORD ELSE '%' END
                                AND a.REG_NO LIKE CASE WHEN: DIV_KEY = 2 THEN :KEYWORD ELSE '%' END
                                order by to_number(a.shop_cd) desc) t1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2, 
                                     (SELECT * FROM shop_infocharge 
                                     WHERE CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt || ' 000000', 'YYYYMMDD HH24MISS') AND  
                                                               TO_DATE(:in_to_dt || ' 235959', 'YYYYMMDD HH24MISS')) a
                                WHERE (( :page - 1) * :row_count) < rnum
                                and t2.shop_cd = a.shop_cd (+)
                                group by t2.rnum, t2.mcode, t2.cccode, t2.shop_cd, t2.shop_name, t2.reg_no, t2.remain_amt
                                order by t2.rnum
                                ";


                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();


                var countSql = $@"
                                    select count(a.SHOP_CD)
                                    from shop_info a, callcenter b
                                    where a.cccode = b.cccode
                                    and b.mcode = :mcode
                                    AND a.SHOP_NAME LIKE CASE WHEN: DIV_KEY = 1 THEN :KEYWORD ELSE '%' END
                                    AND a.REG_NO LIKE CASE WHEN: DIV_KEY = 2 THEN :KEYWORD ELSE '%' END
                                ";

                RCount = await db.ExecuteScalarAsync<Int64>(countSql, param, commandType: CommandType.Text);


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Calculate/getShopCalculateList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
        }

        /// <summary>
        /// 가맹점 적립금 관리 엑셀 출력
        /// </summary>
        [HttpGet("ShopExcelExport")]
        public async Task<IActionResult> ShopExcelExport(string mcode, string date_begin, string date_end, string divKey, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<ShopCalcExcel> items = new List<ShopCalcExcel>();

            try
            {
                string cccodeSql = string.Empty;
                string memoSql = string.Empty;
                string divSql = string.Empty;

                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("mcode", mcode);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("div_key", divKey);
                param.Add("keyword", "%" + keyword + "%");


                string sql = $@"
                                SELECT t2.*,
                                        nvl(sum(case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end),0) as all_amt, 
                                        sum(CASE WHEN a.IO_GBN = 'I' and a.memo not like '계좌이체요청 %' THEN a.CHARGE_AMT ELSE 0 END)  AS IN_AMT, 
                                        sum(nvl(case when a.charge_gbn = 'P' then case when a.io_gbn = 'O' then a.charge_amt else a.charge_amt * -1 end  end,0)) as p_amt, 
                                        sum(nvl(case when a.charge_gbn = 'K' then case when a.io_gbn = 'O' then a.charge_amt else a.charge_amt * -1 end  end,0)) as k_amt, 
                                        sum(CASE WHEN a.memo like '계좌이체요청 출금%' THEN 1
                                                 WHEN a.memo like '계좌이체요청 실패%' THEN -1 END) as take_count, 
                                        sum(CASE WHEN a.memo like '계좌이체요청 %' THEN a.CHARGE_AMT ELSE 0 END)  AS take_amt
                                FROM (SELECT ROWNUM AS rnum, t1.*
                                    FROM (select b.mcode,
                                       a.cccode,
                                       a.SHOP_CD,
                                       a.SHOP_NAME,
                                       a.REG_NO,
                                       a.REMAIN_AMT
                                from shop_info a, callcenter b
                                where a.cccode = b.cccode
                                and b.mcode = :mcode
                                AND a.SHOP_NAME LIKE CASE WHEN: DIV_KEY = 1 THEN :KEYWORD ELSE '%' END
                                AND a.REG_NO LIKE CASE WHEN: DIV_KEY = 2 THEN :KEYWORD ELSE '%' END
                                order by to_number(a.shop_cd) desc) t1) t2, 
                                     (SELECT * FROM shop_infocharge 
                                     WHERE CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt || ' 000000', 'YYYYMMDD HH24MISS') AND  
                                                               TO_DATE(:in_to_dt || ' 235959', 'YYYYMMDD HH24MISS')) a
                                where t2.shop_cd = a.shop_cd (+)
                                group by t2.rnum, t2.mcode, t2.cccode, t2.shop_cd, t2.shop_name, t2.reg_no, t2.remain_amt
                                order by t2.rnum
                                ";


                db.Open();

                var temp = await db.QueryAsync<ShopCalcExcel>(sql, param, commandType: CommandType.Text);

                items = temp.ToList();


                db.Close();

                Rcode = "00";
                Rmsg = "성공";


                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("가맹점적립금관리");
                    var currentRow = 1;

                    worksheet.Cell(currentRow, 1).Value = "상점코드";
                    worksheet.Cell(currentRow, 2).Value = "상점명";
                    worksheet.Cell(currentRow, 3).Value = "총적립금";
                    worksheet.Cell(currentRow, 4).Value = "출금횟수";
                    worksheet.Cell(currentRow, 5).Value = "적립금입금총액";
                    worksheet.Cell(currentRow, 6).Value = "중개수수료총액";
                    worksheet.Cell(currentRow, 7).Value = "PG수수료총액";
                    worksheet.Cell(currentRow, 8).Value = "계좌출금총액";
                    worksheet.Cell(currentRow, 9).Value = "현재적립금";

                    foreach (ShopCalcExcel i in items)
                    {
                        currentRow++;

                        worksheet.Cell(currentRow, 1).Value = i.shop_cd;
                        worksheet.Cell(currentRow, 2).Value = i.shop_name;
                        worksheet.Cell(currentRow, 3).Value = i.all_amt;
                        worksheet.Cell(currentRow, 4).Value = i.take_count;
                        worksheet.Cell(currentRow, 5).Value = i.in_amt;
                        worksheet.Cell(currentRow, 6).Value = i.p_amt;
                        worksheet.Cell(currentRow, 7).Value = i.k_amt;
                        worksheet.Cell(currentRow, 8).Value = i.take_amt;
                        worksheet.Cell(currentRow, 9).Value = i.remain_amt;

                        // 경로 맨 뒤에 역슬러쉬가 없어야 한다.
                        //using (new ConnectToSharedFolder(Utils.nasPath))
                        //{
                        //    worksheet.Cell(currentRow, 34).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\shop.jpg") ? 'O' : 'X';
                        //    worksheet.Cell(currentRow, 35).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\buss.jpg") ? 'O' : 'X';
                        //    worksheet.Cell(currentRow, 36).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\idcard.jpg") ? 'O' : 'X';
                        //    worksheet.Cell(currentRow, 37).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\bank.jpg") ? 'O' : 'X';
                        //}

                    }



                    worksheet.Columns().AdjustToContents();
                    //worksheet.Rows().AdjustToContents();


                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        return File(content, "application/octet-stream", "shop_infocharge.xlsx");
                    }
                }

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Calculate/ShopExcelExport : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 적립금 관리 엑셀 출력
        /// </summary>
        [HttpGet("ShopDetailExcelExport")]
        public async Task<IActionResult> ShopDetailExcelExport(string mcode, string date_begin, string date_end, string divKey, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<ShopCalcExcel> items = new List<ShopCalcExcel>();

            try
            {
                string cccodeSql = string.Empty;
                string memoSql = string.Empty;
                string divSql = string.Empty;

                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("mcode", mcode);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("div_key", divKey);
                param.Add("keyword", "%" + keyword + "%");


                string sql = $@"
                                SELECT t2.shop_cd, t2.shop_name, t2.reg_no,
                                        sum(nvl(case when a.charge_gbn = 'K' then case when a.io_gbn = 'O' then a.app_amount else a.app_amount * -1 end  end,0)) as amount, --결제금액합계
                                        sum(nvl(case when a.charge_gbn = 'K' then case when a.io_gbn = 'O' then a.charge_amt else a.charge_amt * -1 end  end,0)) as k_amt, --결제수수료합계
                                        sum(nvl(case when a.charge_gbn = 'P' then case when a.io_gbn = 'O' then a.charge_amt else a.charge_amt * -1 end  end,0)) as p_amt, --중개수수료합계
                                        sum(nvl(case when a.charge_gbn = 'b' then case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end  end,0)) as h_pay,
                                        sum(nvl(case when a.charge_gbn = 'U' then case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end  end,0)) as coupon,
                                        sum(nvl(case when a.charge_gbn = 'M' then case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end  end,0)) as mileage,
                                        sum(nvl(case when a.charge_gbn = 'a' then case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end  end,0)) as deli_tip,
                                        sum(nvl(case when a.charge_gbn = '3' then case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end  end,0)) as take, --계좌이체
                                        sum(nvl(case when a.charge_gbn = '1' then case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end  end,0)) as other, --사입
                                        sum(nvl(case when a.charge_gbn = 'E' then case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end  end,0)) as mall_i, --몰 물품대금
                                        sum(nvl(case when a.charge_gbn = 'F' then case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end  end,0)) as mall_d --몰 배송비
                                FROM (SELECT ROWNUM AS rnum, t1.*
                                    FROM (select b.mcode,
                                       a.cccode,
                                       a.SHOP_CD,
                                       a.SHOP_NAME,
                                       a.REG_NO,
                                       a.REMAIN_AMT
                                from shop_info a, callcenter b
                                where a.cccode = b.cccode
                                and b.mcode = :mcode
                                AND a.SHOP_NAME LIKE CASE WHEN: DIV_KEY = 1 THEN :KEYWORD ELSE '%' END
                                AND a.REG_NO LIKE CASE WHEN: DIV_KEY = 2 THEN :KEYWORD ELSE '%' END
                                order by to_number(a.shop_cd) desc) t1) t2, 
                                     (SELECT * FROM shop_infocharge 
                                     WHERE CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt || ' 000000', 'YYYYMMDD HH24MISS') AND  
                                                               TO_DATE(:in_to_dt || ' 235959', 'YYYYMMDD HH24MISS')) a
                                where t2.shop_cd = a.shop_cd (+)
                                group by t2.rnum, t2.mcode, t2.cccode, t2.shop_cd, t2.shop_name, t2.reg_no, t2.remain_amt
                                order by t2.rnum
                                ";


                db.Open();

                var temp = await db.QueryAsync<ShopCalcExcel>(sql, param, commandType: CommandType.Text);

                items = temp.ToList();


                db.Close();

                Rcode = "00";
                Rmsg = "성공";


                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("가맹점적립금관리");
                    var currentRow = 1;

                    worksheet.Cell(currentRow, 1).Value = "상점코드";
                    worksheet.Cell(currentRow, 2).Value = "상점명";
                    worksheet.Cell(currentRow, 3).Value = "총적립금";
                    worksheet.Cell(currentRow, 4).Value = "출금횟수";
                    worksheet.Cell(currentRow, 5).Value = "적립금입금총액";
                    worksheet.Cell(currentRow, 6).Value = "중개수수료총액";
                    worksheet.Cell(currentRow, 7).Value = "PG수수료총액";
                    worksheet.Cell(currentRow, 8).Value = "계좌출금총액";
                    worksheet.Cell(currentRow, 9).Value = "현재적립금";

                    foreach (ShopCalcExcel i in items)
                    {
                        currentRow++;

                        worksheet.Cell(currentRow, 1).Value = i.shop_cd;
                        worksheet.Cell(currentRow, 2).Value = i.shop_name;
                        worksheet.Cell(currentRow, 3).Value = i.all_amt;
                        worksheet.Cell(currentRow, 4).Value = i.take_count;
                        worksheet.Cell(currentRow, 5).Value = i.in_amt;
                        worksheet.Cell(currentRow, 6).Value = i.p_amt;
                        worksheet.Cell(currentRow, 7).Value = i.k_amt;
                        worksheet.Cell(currentRow, 8).Value = i.take_amt;
                        worksheet.Cell(currentRow, 9).Value = i.remain_amt;

                        // 경로 맨 뒤에 역슬러쉬가 없어야 한다.
                        //using (new ConnectToSharedFolder(Utils.nasPath))
                        //{
                        //    worksheet.Cell(currentRow, 34).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\shop.jpg") ? 'O' : 'X';
                        //    worksheet.Cell(currentRow, 35).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\buss.jpg") ? 'O' : 'X';
                        //    worksheet.Cell(currentRow, 36).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\idcard.jpg") ? 'O' : 'X';
                        //    worksheet.Cell(currentRow, 37).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\bank.jpg") ? 'O' : 'X';
                        //}

                    }



                    worksheet.Columns().AdjustToContents();
                    //worksheet.Rows().AdjustToContents();


                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        return File(content, "application/octet-stream", "shop_infocharge_detail.xlsx");
                    }
                }

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Calculate/ShopDetailExcelExport : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        //가맹점 적립금 합계
        [HttpGet("getShopCalculateSum")]
        public async Task<IActionResult> getShopCalculateSum(string mcode, string date_begin, string date_end, int divKey, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object Rtotal = string.Empty;
            Object data = string.Empty;


            List<object> items = new List<object>();

            try
            {

                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("mcode", mcode);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("div_key", divKey);
                param.Add("keyword", "%" + keyword + "%");

                var tSql = $@"
                                SELECT /*+ ORDERED full(A) full(B) full(D) use_hash(B) use_hash(D) */ sum(case when A.io_gbn = 'I' then a.charge_amt else charge_amt * -1 end) as all_amt,
                                           sum(CASE WHEN a.memo like '계좌이체요청 %' THEN A.CHARGE_AMT ELSE 0 END)  AS take_amt,
                                           sum(b.remain_amt) as remain_amt
                                    FROM IS_DAEGU.SHOP_INFOCHARGE A,  IS_DAEGU.SHOP_INFO B,  IS_DAEGU.CALLCENTER D
                                    WHERE A.CCCODE = B.CCCODE
                                    AND A.SHOP_CD = B.SHOP_CD
                                    AND B.CCCODE = D.CCCODE
                                    AND D.MCODE = :mcode
                                    --AND B.SHOP_NAME LIKE CASE WHEN: DIV_KEY = 1 THEN: KEYWORD ELSE '%' END
                                    --AND B.REG_NO LIKE CASE WHEN: DIV_KEY = 2 THEN: KEYWORD ELSE '%' END
                                    AND A.CHARGE_DATE >= TO_DATE('2021080917', 'YYYYMMDDHH24')           
                                ";

                var sql = $@"
                                  SELECT /*+ orederd  full(A) */
                                        nvl(sum(case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end),0) as all_amt_sum, 
                                        sum(CASE WHEN a.IO_GBN = 'I' and a.memo not like '계좌이체요청 %' THEN a.CHARGE_AMT ELSE 0 END)  AS IN_AMT_sum, 
                                        sum(nvl(case when a.charge_gbn = 'P' then case when a.io_gbn = 'O' then a.charge_amt else a.charge_amt * -1 end  end,0)) as p_amt_sum, 
                                        sum(nvl(case when a.charge_gbn = 'K' then case when a.io_gbn = 'O' then a.charge_amt else a.charge_amt * -1 end  end,0)) as k_amt_sum, 
                                        sum(CASE WHEN a.memo like '계좌이체요청 출금%' THEN 1
                                                 WHEN a.memo like '계좌이체요청 실패%' THEN -1 END) as take_count_sum, 
                                        sum(CASE WHEN a.memo like '계좌이체요청 %' THEN a.CHARGE_AMT ELSE 0 END)  AS take_amt_sum,
                                        sum(t2.remain_amt) as remain_amt_sum
                                FROM (SELECT ROWNUM AS rnum, t1.*
                                    FROM (select a.SHOP_CD,
                                       a.SHOP_NAME,
                                       a.REG_NO,
                                       a.REMAIN_AMT
                                from IS_DAEGU.shop_info a,IS_DAEGU. callcenter b
                                where a.cccode = b.cccode
                                and b.mcode = :mcode
                                AND a.SHOP_NAME LIKE CASE WHEN: DIV_KEY = 1 THEN :KEYWORD ELSE '%' END
                                AND a.REG_NO LIKE CASE WHEN: DIV_KEY = 2 THEN :KEYWORD ELSE '%' END) t1) t2, 
                                (SELECT * FROM shop_infocharge 
                                    WHERE CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt || ' 000000', 'YYYYMMDD HH24MISS') AND  
                                                            TO_DATE(:in_to_dt || ' 235959', 'YYYYMMDD HH24MISS')) a
                                WHERE t2.shop_cd = a.shop_cd (+)
                                ";

                
                db.Open();

                Rtotal = await db.QuerySingleAsync<object>(tSql, param, commandType: CommandType.Text);

                data = await db.QuerySingleAsync<object>(sql, param, commandType: CommandType.Text);
                //items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Calculate/getShopCalculateSum : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, total = Rtotal, sum = data });
        }

        #region[콜센터 적립금 관리]
        /// <summary>
        /// 콜센타 적립금 관리(기간조건:CHARGE_DATE 정산일자)
        /// </summary>
        /// <remarks>
        /// service_gbn : 서비스 구분(빈값 : 전체, 0 : 주문, 1 : 특별관, 2 : 꽃배달, 3 : 로컬푸드, 4 : 전통시장, 5 : 전자관) <br />
        /// trad_yn 묶음주문여부(빈값:전체, Y:묶음주문, N:일반주문) <br />
        /// charge_gbn : 적립구분<br />
        /// mcode : 3 회계 <br />
        /// dt_div : 기간기준(1 회계기준, 2 주문시간 기준) <br />
        /// test_yn : (Y: 테스트건만, N: 테스트건 제외, 공백: 전체) <br />
        /// div : keyword 검색조건 1.주문번호, 2.가맹점명  <br />
        /// </remarks>
        [HttpGet("getCcCalculateList")]
        public async Task<IActionResult> getCcCalculateList(string service_gbn, string trad_yn, string charge_gbn, string mcode, string cccode, string test_yn, string dt_div, string date_begin, string date_end, string div, string keyword, string memo, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object RtotalCount = string.Empty;
            object RCount = string.Empty;


            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("service_gbn", service_gbn);
                param.Add("trad_yn", trad_yn);
                param.Add("charge_gbn", charge_gbn);
                param.Add("mcode", mcode);
                param.Add("cccode", cccode);
                param.Add("test_yn", test_yn);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("div", div);
                param.Add("keyword", keyword);
                param.Add("memo", (string.IsNullOrEmpty(memo)) ? null : "%" + memo + "%");
                param.Add("page", page);
                param.Add("row_count", rows);

                string cccodeSql = string.Empty;
                string memoSql = string.Empty;
                string divSql = string.Empty;
                string conditionSql = string.Empty;
                
                if (test_yn == "Y")
                {
                    conditionSql = "or";
                }
                else
                {
                    conditionSql = "and";
                }


                string countSql = string.Empty;

                if (dt_div == "2")
                {
                    countSql = $@"
                                    SELECT count(*)
                                    FROM  ( 
                                            SELECT 
                                                0  AS SEQNO,
                                                A.CCCODE ,  
                                                '이월잔액' AS  MEMO
                                                --A.MCODE   AS ORDER_MCODE
                                            FROM  CALLCENTER A, MEMBERSHIP B
                                            WHERE A.MCODE  =  B.MCODE
                                            AND A.MCODE = :mcode 
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            UNION ALL  
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                A.SEQNO,
                                                A.CCCODE,
                                                A.MEMO 
                                            FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D, shop_info s, callcenter c, voucher_mst v, voucher_code_set v2, voucher_code_grp v3
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = D.MCODE
                                            AND   A.MCODE        = :mcode 
                                            AND   A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND :trad_yn is null -- 묶음주문,일반주문 구분
                                            AND ((:keyword IS NULL) or (:div = '2' and :keyword IS NOT NULL))
                                            and (a.order_no is null OR a.order_no = 0 OR a.charge_gbn = 'T') -- 주문비관련 정산내역(택시포함)
                                            and a.shop_cd = s.shop_cd (+)
                                            and s.cccode = c.cccode (+)
                                            and (nvl(to_char(c.mcode),'2') like case when :test_yn  = 'Y' then '1'   -- 테스트 회원사 구분
                                                                   when :test_yn = 'N' then '2' else '%' end 
                                                {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)               
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            and :service_gbn is null
                                            and nvl(s.shop_name,'%') like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                            UNION ALL
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                A.SEQNO,
                                                A.CCCODE,
                                                A.MEMO 
                                            FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D, voucher_mst v, voucher_code_set v2, voucher_code_grp v3,
                                                       (SELECT  X.ORDER_NO, X.CCCODE , x.order_time, y.mcode                         
                                                        FROM    DORDER X, callcenter y, shop_info z, trad_shop t
                                                        where x.cccode = y.cccode
                                                        and x.shop_cd = z.shop_cd
                                                        and z.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                                        and x.order_time BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                                        and z.shop_name like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                                        and x.shop_cd = t.m_shop_cd (+)
                                                        and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                                           when :trad_yn = 'N' then '0'
                                                                                           else '%' end
                                                        UNION ALL
                                                        SELECT /*+ FULL(X) PARALLEL(X 4) */X.ORDER_NO, X.CCCODE, x.order_time, y.mcode
                                                        FROM   DORDER_PAST X, callcenter y, shop_info z, trad_shop t
                                                        where x.cccode = y.cccode
                                                        and x.shop_cd = z.shop_cd
                                                        and z.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                                        and x.order_time BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                                        and z.shop_name like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                                        and x.shop_cd = t.m_shop_cd (+)
                                                        and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                                           when :trad_yn = 'N' then '0'
                                                                                           else '%' end
                                                        ) e
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = D.MCODE
                                            AND   b.MCODE        = :mcode 
                                            and   a.order_no = e.order_no
                                            and   a.charge_gbn <> 'T'
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = '1' and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and (e.mcode like case when :test_yn = 'Y' then '1'
                                                                           when :test_yn = 'N' then '2'
                                                                           else '%' end
                                                {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            UNION ALL
                                            SELECT    /*+ FULL(a) PARALLEL(a 4) */
                                                1    AS SEQNO,
                                                A.CCCODE ,
                                                '마감전 입출금액 ()'  AS MEMO 
                                            FROM   CALLCENTERCHARGE A, MEMBERSHIP B , CALLCENTER C ,
                                                   (SELECT  X.ORDER_NO, X.CCCODE , x.order_time                             
                                                    FROM    DORDER X
                                                    where x.order_time <= TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS')
                                                    UNION ALL
                                                    SELECT /*+ FULL(X) PARALLEL(X 4) */X.ORDER_NO, X.CCCODE, x.order_time
                                                    FROM   DORDER_PAST X
                                                    where x.order_time BETWEEN TO_DATE('210809 170000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS')) e
                                            WHERE  A.MCODE  = B.MCODE 
                                            AND    A.CCCODE = C.CCCODE
                                            AND    A.MCODE           = :mcode  
                                            and    a.order_no = e.order_no (+)
                                            AND    A.CHARGE_DATE <=  TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS')
                                            AND    nvl(e.order_time,a.charge_date) >= TO_DATE(:in_fr_dt, 'YYYYMMDD')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            GROUP BY A.CCCODE ,
                                                        C.CCNAME,
                                                        A.MCODE,
                                                        B.MNAME,
                                                        B.GROUP_ID
                                            )  Z 
                                    where Z.MEMO LIKE CASE WHEN :MEMO IS NOT NULL THEN :MEMO ELSE '%' END
                                    ";
                }
                else
                {
                    countSql = $@"
                                    SELECT count(*)
                                    FROM  ( 
                                            SELECT 
                                                0  AS SEQNO,
                                                A.CCCODE ,  
                                                '이월잔액' AS  MEMO
                                                --A.MCODE   AS ORDER_MCODE
                                            FROM  CALLCENTER A, MEMBERSHIP B
                                            WHERE A.MCODE  =  B.MCODE
                                            AND A.MCODE = :mcode 
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            UNION ALL  
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                A.SEQNO,
                                                A.CCCODE,
                                                A.MEMO 
                                            FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D, shop_info s, callcenter c, voucher_mst v, voucher_code_set v2, voucher_code_grp v3,
                                                 trad_shop t
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = D.MCODE
                                            AND   A.MCODE        = :mcode 
                                            AND   A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = '1' and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and a.shop_cd = s.shop_cd (+)
                                            and s.cccode = c.cccode (+)
                                            and (nvl(to_char(c.mcode),'2') like case when :test_yn  = 'Y' then '1'   -- 테스트 회원사 구분
                                                                   when :test_yn = 'N' then '2' else '%' end
                                                {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and nvl(s.service_gbn,'%') like case when :service_gbn is null then '%' else :service_gbn end
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            and nvl(s.shop_name,'%') like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                            and a.shop_cd = t.m_shop_cd (+)
                                            and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                               when :trad_yn = 'N' then '0'
                                                                               else '%' end
                                            and nvl(to_char(A.ORDER_NO),'%') like case when :trad_yn is null then '%'
                                                                                       else to_char(A.ORDER_NO) end
                                            UNION ALL
                                            SELECT  1    AS SEQNO,
                                                    A.CCCODE ,
                                                    '마감전 입출금액 ()'  AS MEMO 
                                            FROM   CALLCENTERCHARGE A, MEMBERSHIP B , CALLCENTER C 
                                            WHERE  A.MCODE  = B.MCODE 
                                            AND    A.CCCODE = C.CCCODE
                                            AND    A.MCODE           = :mcode  
                                            AND    A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            --AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = '1' and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            GROUP BY A.CCCODE ,
                                                        C.CCNAME,
                                                        A.MCODE,
                                                        B.MNAME,
                                                        B.GROUP_ID
                                            )  Z 
                                    where Z.MEMO LIKE CASE WHEN :MEMO IS NOT NULL THEN :MEMO ELSE '%' END
                                    ";
                }



                RCount = await db.ExecuteScalarAsync<Int64>(countSql, param, commandType: CommandType.Text);

                string sql = string.Empty;

                if (dt_div == "2")
                {
                    sql = $@"
                                SELECT t2.*, 
                                S.SHOP_NAME,
                                S.service_gbn,
                                CASE WHEN T.M_SHOP_CD IS NOT NULL THEN 'Y' ELSE 'N' END TRAD_YN,
                                C.USER_NAME AS CHARGE_NAME,
                                null AS ORDER_MCODE ,
                                (select case when t2.seqno not in (0,1) then SF_GET_CHARGE_GBN('1', t2.CHARGE_GBN) ELSE '' END from dual) AS CHARGE_GBN_NM
                                FROM (SELECT ROWNUM AS rnum, t1.*
                                    FROM (SELECT Z.SEQNO,
                                                 Z.CCCODE,
                                                 Z.CCNAME,
                                                 Z.ORDER_DATE,
                                                 Z.ORDER_TIME,
                                                 Z.CHARGE_DATE,
                                                 Z.CHARGE_GBN,
                                                 Z.IO_GBN,
                                                 Z.CHARGE_AMT,
                                                 CASE WHEN Z.SEQNO IN (0,1) THEN Z.CHARGE_AMT ELSE Z.IN_AMT END IN_AMT,
                                                 Z.OUT_AMT,
                                                 Z.CHARGE_UCODE,
                                                 Z.MEMO,
                                                 Z.MCODE,
                                                 Z.MNAME,
                                                 Z.GROUP_ID,
                                                 Z.ORDER_NO,
                                                 Z.SHOP_CD,
                                                 sum(z.CHARGE_AMT) 
                                over(order by case when seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || seqno, 'YYYYMMDD HH24MISS') else Z.CHARGE_DATE end, z.cccode rows between unbounded preceding and current row) AS PRE_AMT
                                            FROM  ( 
                                            SELECT 
                                                0  AS SEQNO,
                                                A.CCCODE ,
                                                A.CCNAME,
                                                :in_fr_dt AS  ORDER_DATE,   
                                                null ORDER_TIME,
                                                NULL CHARGE_DATE,   
                                                '' CHARGE_GBN,  
                                                '' as IO_GBN,
                                                (select SF_GET_PRE_REMAINAMT_MCODE_NEW(:in_fr_dt, a.CCCODE, '', a.MCODE) from dual) as CHARGE_AMT,
                                                0 AS IN_AMT,
                                                0 AS OUT_AMT,
                                                0 CHARGE_UCODE,   
                                                '이월잔액' AS  MEMO,   
                                                A.MCODE,
                                                B.MNAME,
                                                B.GROUP_ID,
                                                0  AS ORDER_NO,
                                                ''    AS SHOP_CD
                                                --A.MCODE   AS ORDER_MCODE
                                            FROM  CALLCENTER A, MEMBERSHIP B
                                            WHERE A.MCODE  =  B.MCODE
                                            AND A.MCODE = :mcode 
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            UNION ALL  
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                A.SEQNO,
                                                A.CCCODE,
                                                B.CCNAME,
                                                A.ORDER_DATE,
                                                null ORDER_TIME,
                                                A.CHARGE_DATE,
                                                A.CHARGE_GBN,
                                                A.IO_GBN,
                                                case when a.iO_gbn = 'I' then A.CHARGE_AMT else A.CHARGE_AMT * -1 end CHARGE_AMT,
                                                CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                                CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT,
                                                A.CHARGE_UCODE,
                                                A.MEMO ,
                                                D.MCODE, 
                                                D.MNAME,
                                                D.GROUP_ID,
                                                nvl(A.ORDER_NO,0) as ORDER_NO,
                                                A.SHOP_CD
                                                --NVL(OC.MCODE,A.MCODE) AS ORDER_MCODE 
                                            FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D, shop_info s, callcenter c, voucher_mst v, voucher_code_set v2, voucher_code_grp v3
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = D.MCODE
                                            AND   A.MCODE        = :mcode 
                                            AND   A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND :trad_yn is null -- 묶음주문,일반주문 구분
                                            AND ((:keyword IS NULL) or (:div = '2' and :keyword IS NOT NULL))
                                            and (a.order_no is null OR a.order_no = 0 OR a.charge_gbn = 'T') -- 주문비관련 정산내역(택시포함)
                                            and a.shop_cd = s.shop_cd (+)
                                            and s.cccode = c.cccode (+)
                                            and (nvl(to_char(c.mcode),'2') like case when :test_yn  = 'Y' then '1'   -- 테스트 회원사 구분
                                                                   when :test_yn = 'N' then '2' else '%' end
                                                {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            and :service_gbn is null
                                            and nvl(s.shop_name,'%') like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                            UNION ALL
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                A.SEQNO,
                                                A.CCCODE,
                                                B.CCNAME,
                                                A.ORDER_DATE,
                                                E.ORDER_TIME,
                                                A.CHARGE_DATE,
                                                A.CHARGE_GBN,
                                                A.IO_GBN,
                                                case when a.iO_gbn = 'I' then A.CHARGE_AMT else A.CHARGE_AMT * -1 end CHARGE_AMT,
                                                CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                                CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT,
                                                A.CHARGE_UCODE,
                                                A.MEMO ,
                                                D.MCODE, 
                                                D.MNAME,
                                                D.GROUP_ID,
                                                nvl(A.ORDER_NO,0) as ORDER_NO,
                                                A.SHOP_CD
                                                --NVL(OC.MCODE,A.MCODE) AS ORDER_MCODE 
                                            FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D, voucher_mst v, voucher_code_set v2, voucher_code_grp v3,
                                                       (SELECT  X.ORDER_NO, X.CCCODE , x.order_time, y.mcode                          
                                                        FROM    DORDER X, callcenter y, shop_info z, trad_shop t
                                                        where x.cccode = y.cccode
                                                        and x.shop_cd = z.shop_cd
                                                        and z.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                                        and x.order_time BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                                        and z.shop_name like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                                        and x.shop_cd = t.m_shop_cd (+)
                                                        and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                                           when :trad_yn = 'N' then '0'
                                                                                           else '%' end
                                                        UNION ALL
                                                        SELECT /*+ FULL(X) PARALLEL(X 4) */X.ORDER_NO, X.CCCODE, x.order_time, y.mcode
                                                        FROM   DORDER_PAST X, callcenter y, shop_info z, trad_shop t
                                                        where x.cccode = y.cccode
                                                        and x.shop_cd = z.shop_cd
                                                        and z.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                                        and x.order_time BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                                        and z.shop_name like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                                        and x.shop_cd = t.m_shop_cd (+)
                                                        and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                                           when :trad_yn = 'N' then '0'
                                                                                           else '%' end
                                                        ) e
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = D.MCODE
                                            AND   b.MCODE        = :mcode 
                                            and   a.order_no = e.order_no
                                            and   a.charge_gbn <> 'T'
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = '1' and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and (e.mcode like case when :test_yn = 'Y' then '1'
                                                                   when :test_yn = 'N' then '2'
                                                                   else '%' end
                                                {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            UNION ALL
                                            SELECT  1    AS SEQNO,
                                                    A.CCCODE ,
                                                    C.CCNAME,
                                                    :in_fr_dt AS  ORDER_DATE,   
                                                    null ORDER_TIME,
                                                    NULL CHARGE_DATE,   
                                                    '' CHARGE_GBN, 
                                                    '' as IO_GBN,
                                                    SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END) * -1 as CHARGE_AMT,
                                                    0   AS IN_AMT,
                                                    0   AS OUT_AMT,
                                                    0   AS CHARGE_UCODE,
                                                    '마감전 입출금액 ('  || to_char(SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END),'fm999,999,999') || ')'  AS MEMO ,   
                                                    A.MCODE,
                                                    B.MNAME,
                                                    B.GROUP_ID,
                                                     0    AS ORDER_NO,
                                                    ''    AS SHOP_CD
                                                    --NVL(OC.MCODE,A.MCODE) AS ORDER_MCODE 
                                            FROM   CALLCENTERCHARGE A, MEMBERSHIP B , CALLCENTER C 
                                            WHERE  A.MCODE  = B.MCODE 
                                            AND    A.CCCODE = C.CCCODE
                                            AND    A.MCODE           = :mcode  
                                            AND    A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            GROUP BY A.CCCODE ,
                                                        C.CCNAME,
                                                        A.MCODE,
                                                        B.MNAME,
                                                        B.GROUP_ID
                                            )  Z 
                                    where Z.MEMO LIKE CASE WHEN :MEMO IS NOT NULL THEN :MEMO ELSE '%' END
                                    ORDER BY case when seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || seqno, 'YYYYMMDD HH24MISS') -1 else Z.CHARGE_DATE end, z.cccode
                                    ) t1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2 , USERS C, SHOP_INFO S, TRAD_SHOP T
                                WHERE (( :page - 1) * :row_count) < rnum
                                AND   t2.CHARGE_UCODE = C.UCODE(+)
                                AND   t2.SHOP_CD  = S.SHOP_CD (+)
                                AND   T2.SHOP_CD  = T.M_SHOP_CD (+)
                                order by rnum
                                ";
                } 
                else
                {
                    sql = $@"
                                SELECT t2.*, 
                                S.SHOP_NAME,
                                S.service_gbn,
                                CASE WHEN T.M_SHOP_CD IS NOT NULL THEN 'Y' ELSE 'N' END TRAD_YN,
                                C.USER_NAME AS CHARGE_NAME,
                                null AS ORDER_MCODE ,
                                (select case when t2.seqno not in (0,1) then SF_GET_CHARGE_GBN('1', t2.CHARGE_GBN) ELSE '' END from dual) AS CHARGE_GBN_NM
                                FROM (SELECT ROWNUM AS rnum, t1.*
                                    FROM (SELECT Z.SEQNO,
                                                 Z.CCCODE,
                                                 Z.CCNAME,
                                                 Z.ORDER_DATE,
                                                 Z.ORDER_TIME,
                                                 Z.CHARGE_DATE,
                                                 Z.CHARGE_GBN,
                                                 Z.IO_GBN,
                                                 Z.CHARGE_AMT,
                                                 CASE WHEN Z.SEQNO IN (0,1) THEN Z.CHARGE_AMT ELSE Z.IN_AMT END IN_AMT,
                                                 Z.OUT_AMT,
                                                 Z.CHARGE_UCODE,
                                                 Z.MEMO,
                                                 Z.MCODE,
                                                 Z.MNAME,
                                                 Z.GROUP_ID,
                                                 Z.ORDER_NO,
                                                 Z.SHOP_CD,
                                                 sum(z.CHARGE_AMT)
                                over(order by case when seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || seqno, 'YYYYMMDD HH24MISS') else Z.CHARGE_DATE end, z.cccode rows between unbounded preceding and current row) AS PRE_AMT
                                            FROM  ( 
                                            SELECT 
                                                0  AS SEQNO,
                                                A.CCCODE ,
                                                A.CCNAME,
                                                :in_fr_dt AS  ORDER_DATE,   
                                                null ORDER_TIME,
                                                NULL CHARGE_DATE,   
                                                '' CHARGE_GBN,  
                                                '' as IO_GBN,
                                                (select SF_GET_PRE_REMAINAMT_MCODE_NEW(:in_fr_dt, a.CCCODE, '', a.MCODE) from dual) as CHARGE_AMT,
                                                0 AS IN_AMT,
                                                0 AS OUT_AMT,
                                                0 CHARGE_UCODE,   
                                                '이월잔액' AS  MEMO,   
                                                A.MCODE,
                                                B.MNAME,
                                                B.GROUP_ID,
                                                0  AS ORDER_NO,
                                                ''    AS SHOP_CD
                                                --A.MCODE   AS ORDER_MCODE
                                            FROM  CALLCENTER A, MEMBERSHIP B
                                            WHERE A.MCODE  =  B.MCODE
                                            AND A.MCODE = :mcode 
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            UNION ALL  
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                A.SEQNO,
                                                A.CCCODE,
                                                B.CCNAME,
                                                A.ORDER_DATE,
                                                null ORDER_TIME,
                                                A.CHARGE_DATE,
                                                A.CHARGE_GBN,
                                                A.IO_GBN,
                                                case when a.iO_gbn = 'I' then A.CHARGE_AMT else A.CHARGE_AMT * -1 end CHARGE_AMT,
                                                CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                                CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT,
                                                A.CHARGE_UCODE,
                                                A.MEMO ,
                                                D.MCODE, 
                                                D.MNAME,
                                                D.GROUP_ID,
                                                nvl(A.ORDER_NO,0) as ORDER_NO,
                                                A.SHOP_CD
                                                --NVL(OC.MCODE,A.MCODE) AS ORDER_MCODE 
                                            FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D, shop_info s, callcenter c, voucher_mst v, voucher_code_set v2, voucher_code_grp v3,
                                                 trad_shop t
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = D.MCODE
                                            AND   A.MCODE        = :mcode 
                                            AND   A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = '1' and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and a.shop_cd = s.shop_cd (+)
                                            and s.cccode = c.cccode (+)
                                            and (nvl(to_char(c.mcode),'2') like case when :test_yn  = 'Y' then '1'   -- 테스트 회원사 구분
                                                                   when :test_yn = 'N' then '2' else '%' end
                                                {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and nvl(s.service_gbn,'%') like case when :service_gbn is not null then :service_gbn else '%' end
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            and nvl(s.shop_name,'%') like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                            and a.shop_cd = t.m_shop_cd (+)
                                            and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                               when :trad_yn = 'N' then '0'
                                                                               else '%' end
                                            and nvl(to_char(A.ORDER_NO),'%') like case when :trad_yn is null then '%'
                                                                                       else to_char(A.ORDER_NO) end
                                            UNION ALL
                                            SELECT  1    AS SEQNO,
                                                    A.CCCODE ,
                                                    C.CCNAME,
                                                    :in_fr_dt AS  ORDER_DATE,   
                                                    null ORDER_TIME,
                                                    NULL CHARGE_DATE,   
                                                    '' CHARGE_GBN, 
                                                    '' as IO_GBN,
                                                    SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END) * -1 as CHARGE_AMT,
                                                    0   AS IN_AMT,
                                                    0   AS OUT_AMT,
                                                    0   AS CHARGE_UCODE,
                                                    '마감전 입출금액 ('  || to_char(SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END),'fm999,999,999') || ')'  AS MEMO ,   
                                                    A.MCODE,
                                                    B.MNAME,
                                                    B.GROUP_ID,
                                                     0    AS ORDER_NO,
                                                    ''    AS SHOP_CD
                                                    --NVL(OC.MCODE,A.MCODE) AS ORDER_MCODE 
                                                FROM   CALLCENTERCHARGE A, MEMBERSHIP B , CALLCENTER C 
                                                WHERE  A.MCODE  = B.MCODE 
                                                AND    A.CCCODE = C.CCCODE
                                                AND    A.MCODE           = :mcode  
                                                AND    A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS')
                                                AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                                GROUP BY A.CCCODE ,
                                                            C.CCNAME,
                                                            A.MCODE,
                                                            B.MNAME,
                                                            B.GROUP_ID
                                            )  Z 
                                    where Z.MEMO LIKE CASE WHEN :MEMO IS NOT NULL THEN :MEMO ELSE '%' END
                                    ORDER BY case when seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || seqno, 'YYYYMMDD HH24MISS') -1 else Z.CHARGE_DATE end, z.cccode
                                    ) t1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2 , USERS C, SHOP_INFO S, TRAD_SHOP T
                                WHERE (( :page - 1) * :row_count) < rnum
                                AND   t2.CHARGE_UCODE = C.UCODE(+)
                                AND   t2.SHOP_CD  = S.SHOP_CD (+)
                                AND   T2.SHOP_CD  = T.M_SHOP_CD (+)
                                order by rnum
                                ";
                }


                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Calculate/getCcCalculateList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
        }

        /// <summary>
        /// 콜센터 적립금 관리 엑셀 출력
        /// </summary>
        /// <remarks>
        /// service_gbn : 서비스 구분(빈값 : 전체, 0 : 주문, 1 : 특별관, 2 : 꽃배달, 3 : 로컬푸드, 4 : 전통시장, 5 : 전자관) <br />
        /// trad_yn 묶음주문여부(빈값:전체, Y:묶음주문, N:일반주문) <br />
        /// charge_gbn : 적립구분<br />
        /// mcode : 3 회계 <br />
        /// dt_div : 기간기준(1 회계기준, 2 주문시간 기준) <br />
        /// test_yn : (Y: 테스트건만, N: 테스트건 제외, 공백: 전체) <br />
        /// div : keyword 검색조건 1.주문번호, 2.가맹점명  <br />
        /// </remarks>
        [HttpGet("CcExcelExport")]
        public async Task<IActionResult> CcExcelExport(string service_gbn, string trad_yn, string charge_gbn, string mcode, string cccode, string test_yn, string dt_div, string date_begin, string date_end, string div, string keyword, string memo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string conditionSql = string.Empty;

            if (test_yn == "Y")
            {
                conditionSql = "or";
            }
            else
            {
                conditionSql = "and";
            }

            List<CcCalcExcel> items = new List<CcCalcExcel>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("service_gbn", service_gbn);
                param.Add("trad_yn", trad_yn);
                param.Add("charge_gbn", charge_gbn);
                param.Add("mcode", mcode);
                param.Add("cccode", cccode);
                param.Add("test_yn", test_yn);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("div", div);
                param.Add("keyword", keyword);
                param.Add("memo", (string.IsNullOrEmpty(memo)) ? null : "%" + memo + "%");

                string sql = string.Empty;


                if(dt_div == "2")
                {
                    sql = $@"
                                SELECT t2.*, 
                                S.SHOP_NAME,
                                C.USER_NAME AS CHARGE_NAME,
                                null AS ORDER_MCODE ,
                                (select case when t2.seqno not in (0,1) then SF_GET_CHARGE_GBN('1', t2.CHARGE_GBN) ELSE '' END from dual) AS CHARGE_GBN_NM
                                FROM(SELECT Z.SEQNO,
                                            Z.CCCODE,
                                            Z.CCNAME,
                                            Z.ORDER_DATE,
                                            Z.ORDER_TIME,
                                            Z.CHARGE_DATE,
                                            Z.CHARGE_GBN,
                                            Z.IO_GBN,
                                            Z.CHARGE_AMT,
                                            CASE WHEN Z.SEQNO IN (0,1) THEN Z.CHARGE_AMT ELSE Z.IN_AMT END IN_AMT,
                                            Z.OUT_AMT,
                                            Z.CHARGE_UCODE,
                                            Z.MEMO,
                                            Z.MCODE,
                                            Z.MNAME,
                                            Z.GROUP_ID,
                                            Z.ORDER_NO,
                                            Z.SHOP_CD,
                                            sum(z.CHARGE_AMT)
                                over(order by case when seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || seqno, 'YYYYMMDD HH24MISS') else Z.CHARGE_DATE end, z.cccode rows between unbounded preceding and current row) AS PRE_AMT
                                            FROM  ( 
                                            SELECT 
                                                0  AS SEQNO,
                                                A.CCCODE ,
                                                A.CCNAME,
                                                :in_fr_dt AS  ORDER_DATE,  
                                                null ORDER_TIME, 
                                                NULL CHARGE_DATE,   
                                                '' CHARGE_GBN,  
                                                '' as IO_GBN,
                                                (select SF_GET_PRE_REMAINAMT_MCODE_NEW(:in_fr_dt, a.CCCODE, '', a.MCODE) from dual) as CHARGE_AMT,
                                                0 AS IN_AMT,
                                                0 AS OUT_AMT,
                                                0 CHARGE_UCODE,   
                                                '이월잔액' AS  MEMO,   
                                                A.MCODE,
                                                B.MNAME,
                                                B.GROUP_ID,
                                                0  AS ORDER_NO,
                                                ''    AS SHOP_CD
                                                --A.MCODE   AS ORDER_MCODE
                                            FROM  CALLCENTER A, MEMBERSHIP B
                                            WHERE A.MCODE  =  B.MCODE
                                            AND A.MCODE = :mcode 
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            UNION ALL  
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                A.SEQNO,
                                                A.CCCODE,
                                                B.CCNAME,
                                                A.ORDER_DATE,
                                                null ORDER_TIME,
                                                A.CHARGE_DATE,
                                                A.CHARGE_GBN,
                                                A.IO_GBN,
                                                case when a.iO_gbn = 'I' then A.CHARGE_AMT else A.CHARGE_AMT * -1 end CHARGE_AMT,
                                                CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                                CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT,
                                                A.CHARGE_UCODE,
                                                A.MEMO ,
                                                D.MCODE, 
                                                D.MNAME,
                                                D.GROUP_ID,
                                                nvl(A.ORDER_NO,0) as ORDER_NO,
                                                A.SHOP_CD
                                                --NVL(OC.MCODE,A.MCODE) AS ORDER_MCODE 
                                            FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D, shop_info s, callcenter c, voucher_mst v, voucher_code_set v2, voucher_code_grp v3
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = D.MCODE
                                            AND   A.MCODE        = :mcode 
                                            AND   A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND :trad_yn is null -- 묶음주문,일반주문 구분
                                            AND ((:keyword IS NULL) or (:div = '2' and :keyword IS NOT NULL))
                                            and (a.order_no is null OR a.order_no = 0 OR a.charge_gbn = 'T') -- 주문비관련 정산내역(택시포함)
                                            and a.shop_cd = s.shop_cd (+)
                                            and s.cccode = c.cccode (+)
                                            and (nvl(to_char(c.mcode),'2') like case when :test_yn  = 'Y' then '1'   -- 테스트 회원사 구분
                                                                   when :test_yn = 'N' then '2' else '%' end
                                                {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            and :service_gbn is null
                                            and nvl(s.shop_name,'%') like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                            UNION ALL
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                A.SEQNO,
                                                A.CCCODE,
                                                B.CCNAME,
                                                A.ORDER_DATE,
                                                E.ORDER_TIME,
                                                A.CHARGE_DATE,
                                                A.CHARGE_GBN,
                                                A.IO_GBN,
                                                case when a.iO_gbn = 'I' then A.CHARGE_AMT else A.CHARGE_AMT * -1 end CHARGE_AMT,
                                                CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                                CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT,
                                                A.CHARGE_UCODE,
                                                A.MEMO ,
                                                D.MCODE, 
                                                D.MNAME,
                                                D.GROUP_ID,
                                                nvl(A.ORDER_NO,0) as ORDER_NO,
                                                A.SHOP_CD
                                                --NVL(OC.MCODE,A.MCODE) AS ORDER_MCODE 
                                            FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D, voucher_mst v, voucher_code_set v2, voucher_code_grp v3,
                                                       (SELECT  X.ORDER_NO, X.CCCODE , x.order_time, y.mcode                    
                                                        FROM    DORDER X, callcenter y, shop_info z, trad_shop t
                                                        where x.cccode = y.cccode
                                                        and x.shop_cd = z.shop_cd
                                                        and z.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                                        and x.order_time BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                                        and z.shop_name like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                                        and x.shop_cd = t.m_shop_cd (+)
                                                        and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                                           when :trad_yn = 'N' then '0'
                                                                                           else '%' end
                                                        UNION ALL
                                                        SELECT /*+ FULL(X) PARALLEL(X 4) */X.ORDER_NO, X.CCCODE, x.order_time, y.mcode
                                                        FROM   DORDER_PAST X, callcenter y, shop_info z, trad_shop t
                                                        where x.cccode = y.cccode
                                                        and x.shop_cd = z.shop_cd
                                                        and z.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                                        and x.order_time BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                                        and z.shop_name like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                                        and x.shop_cd = t.m_shop_cd (+)
                                                        and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                                           when :trad_yn = 'N' then '0'
                                                                                           else '%' end
                                                        ) e
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = D.MCODE
                                            AND   b.MCODE        = :mcode 
                                            and   a.order_no = e.order_no
                                            and   a.charge_gbn <> 'T'
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = '1' and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and (e.mcode like case when :test_yn = 'Y' then '1'
                                                                           when :test_yn = 'N' then '2'
                                                                           else '%' end
                                            {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            UNION ALL
                                            SELECT  1    AS SEQNO,
                                                    A.CCCODE ,
                                                    C.CCNAME,
                                                    :in_fr_dt AS  ORDER_DATE,  
                                                    null ORDER_TIME, 
                                                    NULL CHARGE_DATE,   
                                                    '' CHARGE_GBN, 
                                                    '' as IO_GBN,
                                                    SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END) * -1 as CHARGE_AMT,
                                                    0   AS IN_AMT,
                                                    0   AS OUT_AMT,
                                                    0   AS CHARGE_UCODE,
                                                    '마감전 입출금액 ('  || to_char(SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END),'fm999,999,999') || ')'  AS MEMO ,   
                                                    A.MCODE,
                                                    B.MNAME,
                                                    B.GROUP_ID,
                                                     0    AS ORDER_NO,
                                                    ''    AS SHOP_CD
                                                    --NVL(OC.MCODE,A.MCODE) AS ORDER_MCODE 
                                            FROM   CALLCENTERCHARGE A, MEMBERSHIP B , CALLCENTER C 
                                            WHERE  A.MCODE  = B.MCODE 
                                            AND    A.CCCODE = C.CCCODE
                                            AND    A.MCODE           = :mcode  
                                            AND    A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            GROUP BY A.CCCODE ,
                                                        C.CCNAME,
                                                        A.MCODE,
                                                        B.MNAME,
                                                        B.GROUP_ID
                                            )  Z 
                                    where Z.MEMO LIKE CASE WHEN :MEMO IS NOT NULL THEN :MEMO ELSE '%' END
                                    ORDER BY case when seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || seqno, 'YYYYMMDD HH24MISS') else Z.CHARGE_DATE end, z.cccode) t2,
                                                                USERS C, SHOP_INFO S
                                WHERE t2.CHARGE_UCODE = C.UCODE(+)
                                AND   t2.SHOP_CD  = S.SHOP_CD (+)
                                order by case when t2.seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || t2.seqno, 'YYYYMMDD HH24MISS') -1 else t2.CHARGE_DATE end, t2.CCCODE ";
                }
                else
                {
                    sql = $@"
                                SELECT t2.*, 
                                S.SHOP_NAME,
                                C.USER_NAME AS CHARGE_NAME,
                                NVL(OC.MCODE,t2.MCODE) AS ORDER_MCODE ,
                                (select case when t2.seqno not in (0,1) then SF_GET_CHARGE_GBN('1', t2.CHARGE_GBN) ELSE '' END from dual) AS CHARGE_GBN_NM
                                FROM(SELECT Z.SEQNO,
                                            Z.CCCODE,
                                            Z.CCNAME,
                                            Z.ORDER_DATE,
                                            Z.ORDER_TIME,
                                            Z.CHARGE_DATE,
                                            Z.CHARGE_GBN,
                                            Z.IO_GBN,
                                            Z.CHARGE_AMT,
                                            CASE WHEN Z.SEQNO IN (0,1) THEN Z.CHARGE_AMT ELSE Z.IN_AMT END IN_AMT,
                                            Z.OUT_AMT,
                                            Z.CHARGE_UCODE,
                                            Z.MEMO,
                                            Z.MCODE,
                                            Z.MNAME,
                                            Z.GROUP_ID,
                                            Z.ORDER_NO,
                                            Z.SHOP_CD,
                                            sum(z.CHARGE_AMT)
                                over(order by case when seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || seqno, 'YYYYMMDD HH24MISS') else Z.CHARGE_DATE end, z.cccode rows between unbounded preceding and current row) AS PRE_AMT
                                            FROM  ( 
                                            SELECT 
                                                0  AS SEQNO,
                                                A.CCCODE ,
                                                A.CCNAME,
                                                :in_fr_dt AS  ORDER_DATE,  
                                                null ORDER_TIME, 
                                                NULL CHARGE_DATE,   
                                                '' CHARGE_GBN,  
                                                '' as IO_GBN,
                                                (select SF_GET_PRE_REMAINAMT_MCODE_NEW(:in_fr_dt, a.CCCODE, '', a.MCODE) from dual) as CHARGE_AMT,
                                                0 AS IN_AMT,
                                                0 AS OUT_AMT,
                                                0 CHARGE_UCODE,   
                                                '이월잔액' AS  MEMO,   
                                                A.MCODE,
                                                B.MNAME,
                                                B.GROUP_ID,
                                                0  AS ORDER_NO,
                                                ''    AS SHOP_CD
                                                --A.MCODE   AS ORDER_MCODE
                                            FROM  CALLCENTER A, MEMBERSHIP B
                                            WHERE A.MCODE  =  B.MCODE
                                            AND A.MCODE = :mcode 
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            UNION ALL  
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                A.SEQNO,
                                                A.CCCODE,
                                                B.CCNAME,
                                                A.ORDER_DATE,
                                                null ORDER_TIME,
                                                A.CHARGE_DATE,
                                                A.CHARGE_GBN,
                                                A.IO_GBN,
                                                case when a.iO_gbn = 'I' then A.CHARGE_AMT else A.CHARGE_AMT * -1 end CHARGE_AMT,
                                                CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                                CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT,
                                                A.CHARGE_UCODE,
                                                A.MEMO ,
                                                D.MCODE, 
                                                D.MNAME,
                                                D.GROUP_ID,
                                                nvl(A.ORDER_NO,0) as ORDER_NO,
                                                A.SHOP_CD
                                                --NVL(OC.MCODE,A.MCODE) AS ORDER_MCODE 
                                            FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D, shop_info s, callcenter c, voucher_mst v, voucher_code_set v2, voucher_code_grp v3,
                                                 trad_shop t
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = D.MCODE
                                            AND   A.MCODE        = :mcode 
                                            AND   A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = '1' and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and a.shop_cd = s.shop_cd (+)
                                            and s.cccode = c.cccode (+)
                                            and (nvl(to_char(c.mcode),'2') like case when :test_yn  = 'Y' then '1'   -- 테스트 회원사 구분
                                                                   when :test_yn = 'N' then '2' else '%' end
                                            {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and nvl(s.service_gbn,'%') like case when :service_gbn is null then '%' else :service_gbn end
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            and nvl(s.shop_name,'%') like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                            and a.shop_cd = t.m_shop_cd (+)
                                            and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                               when :trad_yn = 'N' then '0'
                                                                               else '%' end
                                            and nvl(to_char(A.ORDER_NO),'%') like case when :trad_yn is null then '%'
                                                                                       else to_char(A.ORDER_NO) end
                                            UNION ALL
                                            SELECT  1    AS SEQNO,
                                                    A.CCCODE ,
                                                    C.CCNAME,
                                                    :in_fr_dt AS  ORDER_DATE,  
                                                    null ORDER_TIME, 
                                                    NULL CHARGE_DATE,   
                                                    '' CHARGE_GBN, 
                                                    '' as IO_GBN,
                                                    SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END) * -1 as CHARGE_AMT,
                                                    0   AS IN_AMT,
                                                    0   AS OUT_AMT,
                                                    0   AS CHARGE_UCODE,
                                                    '마감전 입출금액 ('  || to_char(SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END),'fm999,999,999') || ')'  AS MEMO ,   
                                                    A.MCODE,
                                                    B.MNAME,
                                                    B.GROUP_ID,
                                                     0    AS ORDER_NO,
                                                    ''    AS SHOP_CD
                                                    --NVL(OC.MCODE,A.MCODE) AS ORDER_MCODE 
                                            FROM   CALLCENTERCHARGE A, MEMBERSHIP B , CALLCENTER C 
                                            WHERE  A.MCODE  = B.MCODE 
                                            AND    A.CCCODE = C.CCCODE
                                            AND    A.MCODE           = :mcode  
                                            AND    A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            GROUP BY A.CCCODE ,
                                                        C.CCNAME,
                                                        A.MCODE,
                                                        B.MNAME,
                                                        B.GROUP_ID
                                            )  Z 
                                    where Z.MEMO LIKE CASE WHEN :MEMO IS NOT NULL THEN :MEMO ELSE '%' END
                                    ORDER BY case when seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || seqno, 'YYYYMMDD HH24MISS') -1 else Z.CHARGE_DATE end, z.cccode) t2,
                                                                USERS C, SHOP_INFO S, CALLCENTER OC, 
                                                                (   SELECT  X.ORDER_NO, X.CCCODE                              
                                                                    FROM    DORDER X
                                                                    UNION ALL
                                                                    SELECT X.ORDER_NO, X.CCCODE
                                                                    FROM   DORDER_PAST X 
                                                                            ) Y
                                WHERE t2.CHARGE_UCODE = C.UCODE(+)
                                AND   t2.SHOP_CD  = S.SHOP_CD (+)
                                AND    t2.ORDER_NO        = Y.ORDER_NO (+)
                                AND    Y.CCCODE          = OC.CCCODE (+)
                                order by case when t2.seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || t2.seqno, 'YYYYMMDD HH24MISS') - 1 else t2.CHARGE_DATE end, t2.CCCODE
                                ";
                }

                


                db.Open();

                var temp = await db.QueryAsync<CcCalcExcel>(sql, param, commandType: CommandType.Text);

                items = temp.ToList();


                db.Close();

                Rcode = "00";
                Rmsg = "성공";


                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("콜센터적립금관리");
                    var currentRow = 1;

                    worksheet.Cell(currentRow, 1).Value = "주문번호";
                    worksheet.Cell(currentRow, 2).Value = "적립일자";
                    worksheet.Cell(currentRow, 3).Value = "주문일시";
                    worksheet.Cell(currentRow, 4).Value = "적립구분";
                    worksheet.Cell(currentRow, 5).Value = "콜센터명";
                    worksheet.Cell(currentRow, 6).Value = "가맹점코드";
                    worksheet.Cell(currentRow, 7).Value = "가맹점명";
                    worksheet.Cell(currentRow, 8).Value = "적립금입금";
                    worksheet.Cell(currentRow, 9).Value = "적립금출금";
                    worksheet.Cell(currentRow, 10).Value = "적립잔액";
                    worksheet.Cell(currentRow, 11).Value = "메모";

                    foreach (CcCalcExcel cc in items)
                    {
                        currentRow++;

                        worksheet.Cell(currentRow, 1).Value = cc.order_no;
                        worksheet.Cell(currentRow, 2).Value = cc.charge_date;
                        worksheet.Cell(currentRow, 3).Value = cc.order_time;
                        worksheet.Cell(currentRow, 4).Value = cc.charge_gbn_nm;
                        worksheet.Cell(currentRow, 5).Value = cc.ccname;
                        worksheet.Cell(currentRow, 6).Value = cc.shop_cd;
                        worksheet.Cell(currentRow, 7).Value = cc.shop_name;
                        worksheet.Cell(currentRow, 8).Value = cc.in_amt;
                        worksheet.Cell(currentRow, 9).Value = cc.out_amt;
                        worksheet.Cell(currentRow, 10).Value = cc.pre_amt;
                        worksheet.Cell(currentRow, 11).Value = cc.memo;

                    }
                      


                    worksheet.Columns().AdjustToContents();
                    //worksheet.Rows().AdjustToContents();


                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        return File(content, "application/octet-stream", "callcentercharge.xlsx");
                    }
                }
                
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Calculate/CcExcelExport : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 콜센터 적립금 합계
        /// </summary>
        /// <remarks>
        /// dt_div : 기간조건 구분(1. 회계기준, 2.주문기준(주문기준은 입금,출금액에만 적용)) <br/>
        /// 잔액 : 콜센터별 조회종료일까지의 잔액(테스트여부 전체일때만 정확) <br/>
        /// 총잔액 : 회원사별 조회종료일까지의 전체 콜센터 잔액 <br/>
        /// </remarks>
        [HttpGet("getCcCalculateSum")]
        public async Task<IActionResult> getCcCalculateSum(string service_gbn, string trad_yn, string charge_gbn, string mcode, string cccode, string test_yn, string dt_div, string date_begin, string date_end, string div, string keyword, string memo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            dynamic RCount = string.Empty;
            Object RtotalCount = string.Empty;
            CcCalcSum item = new CcCalcSum();
            string conditionSql = string.Empty;

            if (test_yn == "Y")
            {
                conditionSql = "or";
            }
            else
            {
                conditionSql = "and";
            }

            try
            {

                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("service_gbn", service_gbn);
                param.Add("trad_yn", trad_yn);
                param.Add("charge_gbn", charge_gbn);
                param.Add("mcode", mcode);
                param.Add("cccode", cccode);
                param.Add("test_yn", test_yn);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("div", div);
                param.Add("keyword", keyword);
                param.Add("memo", (string.IsNullOrEmpty(memo)) ? null : "%" + memo + "%");

                var totalSql = @"
                                 SELECT nvl(sum(IN_AMT - OUT_AMT),0) as sum_pre_amt
                                            FROM  ( 
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                                a.shop_cd,
                                                                CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                                                CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT
                                                FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D
                                                WHERE A.CCCODE = B.CCCODE
                                                AND   A.MCODE        = D.MCODE
                                                AND   A.MCODE        = :mcode 
                                            )  Z , shop_info s, callcenter c
                                            where z.shop_cd = s.shop_cd (+)
                                            and s.cccode = c.cccode (+)
                                            and nvl(to_char(c.mcode),'2') like case when :test_yn  = 'Y' then '1'   -- 테스트 회원사 구분
                                                                       when :test_yn = 'N' then '2' else '%' end
                                ";

                db.Open();

                //RtotalCount = await db.ExecuteScalarAsync<Int64>(totalSql, param, commandType: CommandType.Text);

                string sql = string.Empty;

                if(dt_div == "2")
                {
                    sql = $@"
                              select a.*, b.* from(SELECT nvl(COUNT(*),0) as count, 
                                    nvl(sum(in_amt),0) as sum_in_amt, 
                                    nvl(sum(out_amt),0) as sum_out_amt, 
                                    nvl(sum(PRE_AMT + IN_AMT - OUT_AMT),0) as sum_pre_amt
                              FROM  ( SELECT  A.CCCODE,
                                            --'I' AS IO_GBN,
                                            0 AS IN_AMT,
                                            0 AS OUT_AMT,
                                            '이월잔액' AS  MEMO, 
                                            0  AS ORDER_NO,
                                            (select SF_GET_PRE_REMAINAMT_MCODE_NEW(:in_fr_dt, A.CCCODE, '', B.MCODE) from dual) AS PRE_AMT
                                            --A.REMAIN_AMT
                                    FROM  CALLCENTER A, MEMBERSHIP B
                                    WHERE A.MCODE  =  B.MCODE
                                    AND A.MCODE = :mcode 
                                    AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                    UNION ALL  
                                    SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                        A.CCCODE,
                                        --A.IO_GBN,
                                        CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                        CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT,
                                        A.MEMO ,
                                        nvl(A.ORDER_NO,0) as order_no,
                                        0 AS PRE_AMT
                                        --B.REMAIN_AMT
                                    FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D, shop_info s, callcenter c, voucher_mst v, voucher_code_set v2, voucher_code_grp v3
                                    WHERE A.CCCODE = B.CCCODE
                                    AND   A.MCODE        = D.MCODE
                                    AND   A.MCODE        = :mcode 
                                    AND   A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                    AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                    AND :trad_yn is null -- 묶음주문,일반주문 구분
                                    AND ((:keyword IS NULL) or (:div = '2' and :keyword IS NOT NULL))
                                    and (a.order_no is null OR a.order_no = 0 OR a.charge_gbn = 'T') -- 주문비관련 정산내역(택시포함)
                                    and a.shop_cd = s.shop_cd (+)
                                    and s.cccode = c.cccode (+)
                                    and (nvl(to_char(c.mcode),'2') like case when :test_yn  = 'Y' then '1'   -- 테스트 회원사 구분
                                                           when :test_yn = 'N' then '2' else '%' end
                                        {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)
                                    and a.voucher_no = v.voucher_no (+)
                                    and v.voucher_type = v2.voucher_type (+)
                                    and v2.group_cd = v3.group_cd (+)
                                    and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                    and :service_gbn is null
                                    and nvl(s.shop_name,'%') like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                    UNION ALL
                                    SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                        A.CCCODE,
                                        --A.IO_GBN,
                                        CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                        CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT,
                                        A.MEMO ,
                                        nvl(A.ORDER_NO,0) as order_no,
                                        0 AS PRE_AMT
                                        --B.REMAIN_AMT
                                    FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D, voucher_mst v, voucher_code_set v2, voucher_code_grp v3,
                                               (SELECT  X.ORDER_NO, X.CCCODE , x.order_time, y.mcode                              
                                                FROM    DORDER X, callcenter y, shop_info z, trad_shop t
                                                where x.cccode = y.cccode
                                                and x.shop_cd = z.shop_cd
                                                and z.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                                and x.order_time BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                                and z.shop_name like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                                and x.shop_cd = t.m_shop_cd (+)
                                                and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                                   when :trad_yn = 'N' then '0'
                                                                                   else '%' end
                                                UNION ALL
                                                SELECT /*+ FULL(X) PARALLEL(X 4) */X.ORDER_NO, X.CCCODE, x.order_time, y.mcode 
                                                FROM   DORDER_PAST X, callcenter y, shop_info z, trad_shop t
                                                where x.cccode = y.cccode
                                                and x.shop_cd = z.shop_cd
                                                and z.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                                and x.order_time BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                                and z.shop_name like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                                and x.shop_cd = t.m_shop_cd (+)
                                                and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                                   when :trad_yn = 'N' then '0'
                                                                                   else '%' end
                                                ) e
                                    WHERE A.CCCODE = B.CCCODE
                                    AND   A.MCODE        = D.MCODE
                                    AND   b.MCODE        = :mcode 
                                    and   a.order_no = e.order_no
                                    and   a.charge_gbn <> 'T'
                                    AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                    AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = '1' and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                    and a.voucher_no = v.voucher_no (+)
                                    and v.voucher_type = v2.voucher_type (+)
                                    and v2.group_cd = v3.group_cd (+)
                                    and (e.mcode like case when :test_yn = 'Y' then '1'
                                                                   when :test_yn = 'N' then '2'
                                                                   else '%' end
                                        {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)
                                    and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                    UNION ALL
                                    SELECT  --'I' AS IO_GBN,
                                            A.CCCODE,
                                            0   AS IN_AMT,
                                            0   AS OUT_AMT,
                                            '마감전 입출금액 ()'  AS MEMO , 
                                                0  AS   ORDER_NO,
                                            SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END) * -1 AS PRE_AMT
                                                --C.REMAIN_AMT
                                        FROM   CALLCENTERCHARGE A, MEMBERSHIP B , CALLCENTER C 
                                        WHERE  A.MCODE  = B.MCODE 
                                        AND    A.CCCODE = C.CCCODE
                                        AND    A.MCODE           = :mcode 
                                        AND    A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS') -- 8시 전날 테스트주문 취소처리 딜레이 포함
                                        AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                        --AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = '1' and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                        GROUP BY A.CCCODE ,
                                                    C.CCNAME,
                                                    A.MCODE,
                                                    B.MNAME,
                                                    B.GROUP_ID
                                    )  Z) a,
                                   (select nvl(sum(IN_AMT - OUT_AMT),0) as tot_sum_pre_amt
                                            FROM  ( 
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                                a.MCODE,
                                                                a.shop_cd,
                                                                CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                                                CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT
                                                FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D
                                                WHERE A.CCCODE = B.CCCODE
                                                AND   A.MCODE        = D.MCODE
                                                AND   A.MCODE        = :mcode 
                                                AND A.CHARGE_DATE BETWEEN TO_DATE('20210320'||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            )  Z ) b
                                    where 1 = 1
                                ";
                }
                else
                {
                    sql = $@"
                              select a.*, b.* from(SELECT nvl(COUNT(*),0) as count, 
                                    nvl(sum(in_amt),0) as sum_in_amt, 
                                    nvl(sum(out_amt),0) as sum_out_amt, 
                                    nvl(sum(PRE_AMT + IN_AMT - OUT_AMT),0) as sum_pre_amt
                              FROM  ( SELECT  A.CCCODE,
                                            --'I' AS IO_GBN,
                                            0 AS IN_AMT,
                                            0 AS OUT_AMT,
                                            '이월잔액' AS  MEMO, 
                                            0  AS ORDER_NO,
                                            (select SF_GET_PRE_REMAINAMT_MCODE_NEW(:in_fr_dt, A.CCCODE, '', B.MCODE) from dual) AS PRE_AMT
                                            --A.REMAIN_AMT
                                    FROM  CALLCENTER A, MEMBERSHIP B
                                    WHERE A.MCODE  =  B.MCODE
                                    AND A.MCODE = :mcode 
                                    AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                    UNION ALL  
                                    SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                            A.CCCODE,
                                            --A.IO_GBN,
                                            CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                            CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT,
                                            A.MEMO ,
                                            nvl(A.ORDER_NO,0) as order_no,
                                            0 AS PRE_AMT
                                            --B.REMAIN_AMT
                                        FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D,  CALLCENTER_ADD_INFO F, shop_info s, callcenter c, voucher_mst v, voucher_code_set v2, voucher_code_grp v3,
                                             trad_shop t
                                        WHERE A.CCCODE = B.CCCODE
                                        AND   A.MCODE        = D.MCODE
                                        AND   A.MCODE        = :mcode 
                                        AND   A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                        AND   A.CCCODE = F.CCCODE (+)
                                        AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                        AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = '1' and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                        and a.shop_cd = s.shop_cd (+)
                                        and s.cccode = c.cccode (+)
                                        and (nvl(to_char(c.mcode),'2') like case when :test_yn  = 'Y' then '1'   -- 테스트 회원사 구분
                                                                       when :test_yn = 'N' then '2' else '%' end
                                            {conditionSql} nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end)
                                        and a.voucher_no = v.voucher_no (+)
                                        and v.voucher_type = v2.voucher_type (+)
                                        and v2.group_cd = v3.group_cd (+)
                                        and nvl(s.service_gbn,'%') like case when :service_gbn is null then '%' else :service_gbn end
                                        and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                        and nvl(s.shop_name,'%') like case when :div = '2' then '%' || :keyword || '%' else '%' end
                                        and a.shop_cd = t.m_shop_cd (+)
                                        and nvl(t.m_shop_cd,'0') like case when :trad_yn = 'Y' then t.m_shop_cd
                                                                           when :trad_yn = 'N' then '0'
                                                                           else '%' end
                                        and nvl(to_char(A.ORDER_NO),'%') like case when :trad_yn is null then '%'
                                                                                   else to_char(A.ORDER_NO) end
                                        UNION ALL
                                        SELECT  --'I' AS IO_GBN,
                                                A.CCCODE,
                                                0   AS IN_AMT,
                                                0   AS OUT_AMT,
                                                '마감전 입출금액 ()'  AS MEMO , 
                                                    0  AS   ORDER_NO,
                                                SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END) * -1 AS PRE_AMT
                                                    --C.REMAIN_AMT
                                            FROM   CALLCENTERCHARGE A, MEMBERSHIP B , CALLCENTER C 
                                            WHERE  A.MCODE  = B.MCODE 
                                            AND    A.CCCODE = C.CCCODE
                                            AND    A.MCODE           = :mcode 
                                            AND    A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS') -- 8시 전날 테스트주문 취소처리 딜레이 포함
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            --AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = '1' and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            GROUP BY A.CCCODE ,
                                                        C.CCNAME,
                                                        A.MCODE,
                                                        B.MNAME,
                                                        B.GROUP_ID
                                    )  Z) a,
                                   (select nvl(sum(IN_AMT - OUT_AMT),0) as tot_sum_pre_amt
                                            FROM  ( 
                                            SELECT   /*+ FULL(a) PARALLEL(a 4) */
                                                                a.MCODE,
                                                                a.shop_cd,
                                                                CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                                                CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT
                                                FROM CALLCENTERCHARGE A, CALLCENTER B, MEMBERSHIP D
                                                WHERE A.CCCODE = B.CCCODE
                                                AND   A.MCODE        = D.MCODE
                                                AND   A.MCODE        = :mcode 
                                                AND A.CHARGE_DATE BETWEEN TO_DATE('20210320'||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            )  Z ) b
                                    where 1 = 1
                                ";
                }

                RCount = await db.QuerySingleAsync<dynamic>(sql, param, commandType: CommandType.Text);

                //item = RCount;

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Calculate/getCcCalculateSum : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, total = RCount.TOT_SUM_PRE_AMT, count = RCount });
        }

        //관리자계정만 사용할수 있어야하는 기능
        /// <summary>
        /// 콜센터 적립금 사입
        /// </summary>
        /// <remarks>
        /// cccode : 콜센터 코드(회계) <br/>
        /// ioGbn : 입출구분(I 입금/O 출금) <br/>
        /// amt : 금액 <br/>
        /// memo : 메모 ex) SMS 충전입금 <br/>
        /// ucode : 사입처리자 ucode
        /// </remarks>
        [HttpPost("insertCallcenterCharge")]
        public async Task<IActionResult> insertCallcenterCharge(string cccode, string ioGbn, string amt, string memo, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            if (long.Parse(amt) < 0)
            {
                return Ok(new { code = "99", msg = "금액은 0원 이상만 입력가능합니다." });
            }

            if (long.Parse(amt) > 20000000000)
            {
                return Ok(new { code = "99", msg = "금액은 2백억 까지만 가능합니다." });
            }

            if (memo.Length < 5)
            {
                return Ok(new { code = "99", msg = "메모는 5자리 이상 입력해야 됩니다." });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("mcode", 3);
                param.Add("cccode", cccode);
                param.Add("charge_amt", amt);
                param.Add("ucode", ucode);
                param.Add("memo", memo);
                param.Add("io_gbn", ioGbn);

                db.Open();

                string sql = @$"
                                select sf_get_fdia_close_time_chk from dual
                ";

                string closeTime = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                if (closeTime.Equals("Y"))
                {
                    return Ok(new { code = "99", msg = "마감시간에는 입/출금 작업이 불가능합니다." });
                }

                sql = @$"
                         select count(*) from callcenter where mcode = :mcode and cccode = :cccode
                ";

                int n = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

                if (n == 0)
                {
                    return Ok(new { code = "99", msg = "잘못된 콜센터 정보입니다." });
                }

                sql = @$"
                         select remain_amt from callcenter where mcode = :mcode and cccode = :cccode
                ";

                n = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

                if (ioGbn.Equals("O") && n < long.Parse(amt))
                {
                    return Ok(new { code = "99", msg = "콜센터에 출금할 잔액이 부족합니다. 잔액:" + n });
                }


                sql = @$"
                                insert into callcentercharge(seqno, mcode, cccode, order_date, charge_date, charge_gbn, charge_amt, charge_ucode, memo, io_gbn)
                                values(SEQ_CALLCENTERCHARGE.NEXTVAL, :mcode, :cccode, to_char(sysdate,'YYYYMMDD'), sysdate, '1', :charge_amt, :ucode, :memo, :io_gbn)
                ";

                await db.QueryAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        //관리자계정만 사용할수 있어야하는 기능
        //콜센터간 금액이동
        /// <summary>
        /// 콜센터간 금액이동
        /// </summary>
        /// <remarks>
        /// fr_cccode : 출금하는 콜센터 코드(회계) <br/>
        /// to_cccode : 입금받는 콜센터 코드(회계) <br/>
        /// amt : 금액 <br/>
        /// ucode : 사입처리자 ucode
        /// </remarks>
        [HttpPost("moveCallcenterCharge")]
        public async Task<IActionResult> moveCallcenterCharge(string fr_cccode, string to_cccode, string amt, string ucode)
        {
            if (long.Parse(amt) < 0)
            {
                return Ok(new { code = "99", msg = "금액은 0원 이상만 입력가능합니다." });
            }

            if (long.Parse(amt) > 20000000000)
            {
                return Ok(new { code = "99", msg = "금액은 2백억 까지만 가능합니다." });
            }


            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("mcode", 3);
                param.Add("fr_cccode", fr_cccode);
                param.Add("to_cccode", to_cccode);
                param.Add("charge_amt", amt);
                param.Add("ucode", ucode);

                db.Open();

                string sql = @$"
                                select sf_get_fdia_close_time_chk from dual
                ";

                string closeTime = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                if (closeTime.Equals("Y"))
                {
                    return Ok(new { code = "99", msg = "마감시간에는 입/출금 작업이 불가능합니다." });
                }

                sql = @$"
                                select ccname from callcenter where mcode = :mcode and cccode = :fr_cccode
                ";

                string fr_cname = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                sql = @$"
                                select ccname from callcenter where mcode = :mcode and cccode = :to_cccode
                ";

                string to_cname = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                if (string.IsNullOrEmpty(fr_cname) || string.IsNullOrEmpty(to_cname))
                {
                    return Ok(new { code = "99", msg = "잘못된 콜센터 정보입니다." });
                }

                sql = @$"
                                select remain_amt from callcenter where mcode = :mcode and cccode = :fr_cccode
                ";

                int n = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

                if (n < long.Parse(amt))
                {
                    return Ok(new { code = "99", msg = "콜센터에 출금할 잔액이 부족합니다. 잔액:" + n });
                }

                if (fr_cccode.Equals("14"))
                {
                    fr_cname = "*" + fr_cname;
                }

                if (to_cccode.Equals("14"))
                {
                    to_cname = "*" + to_cname;
                }

                param.Add("fr_cname", fr_cname);
                param.Add("to_cname", to_cname);

                sql = @$"
                        insert into callcentercharge(seqno, mcode, cccode, order_date, charge_date, charge_gbn, charge_amt, charge_ucode, memo, io_gbn)
                        values(SEQ_CALLCENTERCHARGE.NEXTVAL, :mcode, :fr_cccode, to_char(sysdate,'YYYYMMDD'), sysdate, '1', :charge_amt, :ucode, :to_cname || '[' || :to_cccode || ']로 출금', 'O')
                ";

                await db.QueryAsync(sql, param, commandType: CommandType.Text);

                sql = @$"
                        insert into callcentercharge(seqno, mcode, cccode, order_date, charge_date, charge_gbn, charge_amt, charge_ucode, memo, io_gbn)
                        values(SEQ_CALLCENTERCHARGE.NEXTVAL, :mcode, :to_cccode, to_char(sysdate,'YYYYMMDD'), sysdate, '1', :charge_amt, :ucode, :fr_cname || '[' || :fr_cccode || ']에서 입금', 'I')
                ";

                await db.QueryAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion[콜센터 적립금 관리]

        /// <summary>
        /// 수수료 관리(기간조건:COMP_DT 배달완료)
        /// </summary>
        /// <remarks>
        /// charge_gbn 수수료 구분 : (P: 중계수수료, K: 카드수수료) <br />
        /// divKey : 1. 가맹점명, 2. 사업자번호 3. 연락처
        /// </remarks>
        [HttpGet("getPgmCalculateList")]
        public async Task<IActionResult> getPgmCalculateList(int mcode, string date_begin, string date_end, int divKey, string keyword, string charge_gbn, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalCount = string.Empty;
            Object RCount = string.Empty;


            List<object> items = new List<object>();

            try
            {

                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_mcode", mcode);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("div_key", divKey);
                param.Add("in_charge_gbn", charge_gbn);
                //param.Add("in_prt_yn", prt_yn);
                param.Add("keyword", "%" + keyword + "%");
                param.Add("page", page);
                param.Add("row_count", rows);

                string statusSql = string.Empty;
                string chargeSql = string.Empty;
                string prtSql = string.Empty;
                string divSql = string.Empty;


                string sql = $@"
                                SELECT t2.*
                              FROM (SELECT ROWNUM AS RNUM,
                                           t1.*
                                    FROM (SELECT t2.*, 
                                        T.SUPAMT,                       -- 공급가합계
                                        T.VATAMT,                       -- 부가세합계
                                        Y.TOT_CNT,                      -- 총 주문 
                                        Y.COMP_CNT,                     -- 완료주문
                                        Y.CANCEL_CNT,                   -- 취소주문 
                                        NVL(T.PRT_YN,'N') AS PRT_YN,    -- 전자 세금계산서 발행여부,
                                        T.STATUS,                       -- 전자 계금계산서 발행상태
                                        T.ISSYMD,                       -- 처리일자
                                        T.PRT_DATE,                     -- 발행일자
                                        T.RTN_MSG                       -- 전자 세금계산서 응답결과
                                        FROM (SELECT X.YYMM,  
                                                     X.CCNAME, 
                                                     X.SHOP_CD, 
                                                     X.SHOP_NAME, 
                                                     X.TELNO,
                                                     X.REG_NO,
                                                     X.TAX_NO,
                                                     X.PGM_IN_AMT,                   -- 수수료(입)
                                                     X.PGM_OUT_AMT,                  -- 수수료(출)
                                                     ( X.PGM_IN_AMT - X.PGM_OUT_AMT )  AS PGM_AMT, -- 수수료
                                                     X.CCCODE,
                                                     X.MCODE
                                              FROM( SELECT /*+use_hash(A) full(B) */ 
                                                                TO_CHAR(A.CHARGE_DATE,'YYYYMM') AS YYMM, 
                                                                B.MCODE,
                                                                C.CCCODE,
                                                                C.CCNAME,
                                                                D.SHOP_CD,
                                                                D.SHOP_NAME,
                                                                D.TELNO,
                                                                D.REG_NO, 
                                                                A.TAX_NO,
                                                                SUM( CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END ) AS PGM_IN_AMT,
                                                                SUM( CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  ) AS PGM_OUT_AMT
                                                         FROM INSUNG_CALC A, MEMBERSHIP B, CALLCENTER  C, SHOP_INFO D
                                                        WHERE A.MCODE   = B.MCODE
                                                          AND A.MCODE   = C.MCODE
                                                          AND A.CCCODE  = C.CCCODE
                                                          AND A.CCCODE  = D.CCCODE
                                                          AND A.SHOP_CD = D.SHOP_CD
                                                          AND D.API_COM_GBN IS NULL   -- 2021/08/05
                                                          AND A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                                          AND A.CHARGE_DATE >= CASE WHEN SUBSTR(:in_fr_dt,1,6) = '202109' THEN  TO_DATE(:in_fr_dt||' 080000', 'YYYYMMDD HH24MISS') ELSE  TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') END
                                                          AND A.MCODE  = :in_mcode 
                                                          AND C.MCODE  = :in_mcode 
                                                          AND A.CHARGE_GBN IN ( 'P', 'K' )
                                                          AND B.GROUP_ID <> 'INSUNG'
                                                          AND A.MCODE = :in_mcode
                                                          AND A.CHARGE_GBN like case when :in_charge_gbn is null then '%' else :in_charge_gbn end
                                                          AND D.TELNO LIKE CASE WHEN :DIV_KEY = 0 THEN :KEYWORD ELSE '%' END
                                                          AND D.SHOP_NAME LIKE CASE WHEN :DIV_KEY = 1 THEN :KEYWORD ELSE '%' END
                                                          AND D.REG_NO LIKE CASE WHEN :DIV_KEY = 2 THEN :KEYWORD ELSE '%' END
                                                        GROUP BY  TO_CHAR(A.CHARGE_DATE,'YYYYMM'),
                                                                  B.MCODE,
                                                                  C.CCCODE, 
                                                                  C.CCNAME,
                                                                  D.SHOP_CD,
                                                                  D.SHOP_NAME,
                                                                  D.TELNO,
                                                                  D.REG_NO,
                                                                  A.TAX_NO 
                                                        ORDER BY YYMM,  SHOP_CD ) X
                                             WHERE ( X.PGM_IN_AMT - X.PGM_OUT_AMT )   <> 0  
                                                ) t2,
                                            ( SELECT      YYMM, 
                                                                MCODE,
                                                                CCCODE,
                                                                CCNAME,
                                                                SHOP_CD,
                                                                SHOP_NAME,
                                                                REG_NO,
                                                                SUM(TOT_CNT)  AS TOT_CNT,
                                                                SUM(COMP_CNT) AS COMP_CNT,
                                                                SUM(CANCEL_CNT) AS CANCEL_CNT
                                                     FROM (  
                                                            SELECT   TO_CHAR(A.COMP_DT,'YYYYMM') AS YYMM, 
                                                                     C.MCODE,
                                                                     B.CCCODE,
                                                                     B.CCNAME,
                                                                     D.SHOP_CD,
                                                                     D.SHOP_NAME,
                                                                     D.REG_NO,
                                                                     COUNT(ORDER_NO) AS TOT_CNT, 
                                                                     COUNT(CASE WHEN STATUS = '40' THEN 1 END) AS COMP_CNT, 
                                                                     COUNT(CASE WHEN STATUS = '50' THEN 1 END) AS CANCEL_CNT
                                                              FROM DORDER  A, CALLCENTER B, MEMBERSHIP C, SHOP_INFO D
                                                             WHERE A.CCCODE  = B.CCCODE
                                                                AND B.MCODE   = C.MCODE
                                                                AND A.CCCODE  = D.CCCODE
                                                                AND A.SHOP_CD = D.SHOP_CD  
                                                                AND D.API_COM_GBN IS NULL   -- 2021/08/05
                                                                AND A.COMP_DT BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                                                AND C.GROUP_ID <> 'INSUNG'
                                                                AND A.STATUS IN ('40', '50' )
                                                                AND B.MCODE  = :in_mcode 
                                                                AND  NVL(CANCEL_CODE, '00') <> '30'  
                                                                AND D.TELNO LIKE CASE WHEN :DIV_KEY = 0 THEN :KEYWORD ELSE '%' END
                                                                AND D.SHOP_NAME LIKE CASE WHEN :DIV_KEY = 1 THEN :KEYWORD ELSE '%' END
                                                                AND D.REG_NO LIKE CASE WHEN :DIV_KEY = 2 THEN :KEYWORD ELSE '%' END
                                                              GROUP BY    TO_CHAR(A.COMP_DT,'YYYYMM'),
                                                                          C.MCODE,
                                                                          B.CCCODE,
                                                                          B.CCNAME,
                                                                          D.SHOP_CD,
                                                                          D.SHOP_NAME,
                                                                          D.REG_NO
                                                               UNION ALL
                                                              SELECT TO_CHAR(A.COMP_DT,'YYYYMM') AS YYMM, 
                                                                     C.MCODE,
                                                                     B.CCCODE,
                                                                     B.CCNAME,
                                                                     D.SHOP_CD,
                                                                     D.SHOP_NAME,
                                                                     D.REG_NO,
                                                                     COUNT(A.ORDER_NO) AS TOT_CNT, 
                                                                     COUNT(CASE WHEN A.STATUS = '40' THEN 1 END) AS COMP_CNT, 
                                                                     COUNT(CASE WHEN A.STATUS = '50' THEN 1 END) AS CANCEL_CNT
                                                              FROM DORDER_PAST  A, CALLCENTER B, MEMBERSHIP C, SHOP_INFO D
                                                             WHERE A.CCCODE  = B.CCCODE
                                                                AND B.MCODE   = C.MCODE
                                                                AND A.CCCODE  = D.CCCODE
                                                                AND A.SHOP_CD = D.SHOP_CD  
                                                                AND D.API_COM_GBN IS NULL   -- 2021/08/05
                                                                AND C.GROUP_ID <> 'INSUNG'
                                                                AND A.STATUS IN ('40', '50' )
                                                                AND A.COMP_DT BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                                                AND  NVL(CANCEL_CODE, '00') <> '30' 
                                                                AND D.TELNO LIKE CASE WHEN :DIV_KEY = 0 THEN :KEYWORD ELSE '%' END
                                                                AND D.SHOP_NAME LIKE CASE WHEN :DIV_KEY = 1 THEN :KEYWORD ELSE '%' END
                                                                AND D.REG_NO LIKE CASE WHEN :DIV_KEY = 2 THEN :KEYWORD ELSE '%' END
                                                              GROUP BY    TO_CHAR(A.COMP_DT,'YYYYMM'),
                                                                          C.MCODE,
                                                                          B.CCCODE,
                                                                          B.CCNAME,
                                                                          D.SHOP_CD,
                                                                          D.SHOP_NAME,
                                                                          D.REG_NO )
                                                             GROUP BY   YYMM,
                                                                        MCODE,
                                                                        CCCODE,
                                                                        CCNAME,
                                                                        SHOP_CD,
                                                                        SHOP_NAME,
                                                                        REG_NO) Y, TAX_MAST T
                                    WHERE      T2.MCODE          = Y.MCODE         (+)
                                    AND     T2.CCCODE         = Y.CCCODE        (+)   
                                    AND     T2.SHOP_CD        = Y.SHOP_CD       (+)
                                    AND     T2.YYMM           = Y.YYMM          (+)
                                    AND     T2.MCODE          = T.MCODE         (+)
                                    AND     T2.CCCODE         = T.CCCODE        (+)   
                                    AND     T2.SHOP_CD        = T.SHOP_CD       (+)
                                    AND     T2.TAX_NO         = T.TAX_NO        (+)
                                    --and NVL(T.PRT_YN,'N') = 'N'
                                    order by t2.yymm desc, t2.shop_cd) t1
                        WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                        WHERE (( :page - 1) * :row_count) < RNUM
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                //var totalSql = @"
                //                 select nvl(COUNT(*),0) from(SELECT /*+use_hash(A) full(B) */
                //                                1
                //                            FROM INSUNG_CALC A, MEMBERSHIP B, CALLCENTER  C, SHOP_INFO D
                //                        WHERE A.MCODE   = B.MCODE
                //                            AND A.MCODE   = C.MCODE
                //                            AND A.CCCODE  = C.CCCODE
                //                            AND A.CCCODE  = D.CCCODE
                //                            AND A.SHOP_CD = D.SHOP_CD
                //                            AND D.API_COM_GBN IS NULL   -- 2021/08/05
                //                            AND A.MCODE  = :in_mcode 
                //                            AND C.MCODE  = :in_mcode 
                //                            AND A.CHARGE_GBN IN ( 'P', 'K' )
                //                            AND B.GROUP_ID <> 'INSUNG'
                //                        GROUP BY  TO_CHAR(A.CHARGE_DATE,'YYYYMM'),
                //                                    B.MCODE,
                //                                    C.CCCODE, 
                //                                    C.CCNAME,
                //                                    D.SHOP_CD,
                //                                    D.SHOP_NAME,
                //                                    D.TELNO,
                //                                    D.REG_NO,
                //                                    A.TAX_NO)
                //                ";

                //RtotalCount = await db.ExecuteScalarAsync<string>(totalSql, param, commandType: CommandType.Text);

                var countSql = @$"SELECT NVL(COUNT(1), 0)
                                FROM( SELECT /*+use_hash(A) full(B) */ 
                                                TO_CHAR(A.CHARGE_DATE,'YYYYMM') AS YYMM, 
                                                B.MCODE,
                                                C.CCCODE,
                                                C.CCNAME,
                                                D.SHOP_CD,
                                                D.SHOP_NAME,
                                                D.TELNO,
                                                D.REG_NO, 
                                                A.TAX_NO,
                                                SUM( CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END ) AS PGM_IN_AMT,
                                                SUM( CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  ) AS PGM_OUT_AMT
                                            FROM INSUNG_CALC A, MEMBERSHIP B, CALLCENTER  C, SHOP_INFO D, tax_mast t
                                        WHERE A.MCODE   = B.MCODE
                                            AND A.MCODE   = C.MCODE
                                            AND A.CCCODE  = C.CCCODE
                                            AND A.CCCODE  = D.CCCODE
                                            AND A.SHOP_CD = D.SHOP_CD
                                            AND     a.MCODE          = T.MCODE         (+)
                                            AND     a.CCCODE         = T.CCCODE        (+)   
                                            AND     a.SHOP_CD        = T.SHOP_CD       (+)
                                            AND D.API_COM_GBN IS NULL   -- 2021/08/05
                                            AND A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            AND A.CHARGE_DATE >= CASE WHEN SUBSTR(:in_fr_dt,1,6) = '202109' THEN  TO_DATE(:in_fr_dt||' 080000', 'YYYYMMDD HH24MISS') ELSE  TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') END
                                            AND A.MCODE  = :in_mcode 
                                            AND C.MCODE  = :in_mcode 
                                            AND A.CHARGE_GBN IN ( 'P', 'K' )
                                            AND B.GROUP_ID <> 'INSUNG'
                                            AND A.MCODE = :in_mcode
                                            AND A.CHARGE_GBN like case when :in_charge_gbn is null then '%' else :in_charge_gbn end
                                            AND D.TELNO LIKE CASE WHEN :DIV_KEY = 0 THEN :KEYWORD ELSE '%' END
                                            AND D.SHOP_NAME LIKE CASE WHEN :DIV_KEY = 1 THEN :KEYWORD ELSE '%' END
                                            AND D.REG_NO LIKE CASE WHEN :DIV_KEY = 2 THEN :KEYWORD ELSE '%' END
                                        GROUP BY  TO_CHAR(A.CHARGE_DATE,'YYYYMM'),
                                                    B.MCODE,
                                                    C.CCCODE, 
                                                    C.CCNAME,
                                                    D.SHOP_CD,
                                                    D.SHOP_NAME,
                                                    D.TELNO,
                                                    D.REG_NO,
                                                    A.TAX_NO ) X
                                WHERE ( X.PGM_IN_AMT - X.PGM_OUT_AMT )   <> 0
                                ";

                RCount = await db.ExecuteScalarAsync<Int64>(countSql, param, commandType: CommandType.Text);


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Calculate/getPgmCalculateList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
        }

        #region[세금계산서]
        /// <summary>
        /// 전자세금계산서 조회(기간조건:CHARGE_DATE 정산일자)
        /// </summary>
        /// <remarks>
        /// chargeGbn 수수료 구분 : (P: 중개수수료, K: 카드수수료)
        /// gbn 상태 : (P: 생성, C: 미생성, R: 발행) <br />
        /// prt_yn 국세청 발행 여부 
        /// </remarks>
        [HttpGet("searchShopTax")]
        public async Task<IActionResult> searchShopTax(string fee_ym, string mcode, string chargeGbn, string gbn, string prtYn, string shopName, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            //string TotalCount = string.Empty;

            List<Calculate> calc = new List<Calculate>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CALC.SEARCH_SHOP_TAX",
            };

            cmd.Parameters.Add("in_fr_dt", OracleDbType.Varchar2, 10).Value = fee_ym;
            cmd.Parameters.Add("mcode", OracleDbType.Int32).Value = mcode;
            cmd.Parameters.Add("charge_gbn", OracleDbType.Varchar2, 20).Value = chargeGbn;
            cmd.Parameters.Add("in_gbn", OracleDbType.Varchar2, 20).Value = gbn;
            cmd.Parameters.Add("in_prt_yn", OracleDbType.Varchar2, 20).Value = prtYn;
            cmd.Parameters.Add("in_shop_name", OracleDbType.Varchar2, 20).Value = shopName;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    Calculate c = new Calculate
                    {
                        orderYm = rd["ORDER_YM"].ToString(),
                        mcode = rd["MCODE"].ToString(),
                        cccode = rd["MAIN_CCCODE"].ToString(),
                        shopCd = rd["SHOP_CD"].ToString(),
                        shopName = rd["SHOP_NAME"].ToString(),
                        taxNo = rd["TAX_NO"].ToString(),
                        issymd = rd["ISSYMD"].ToString(),
                        supamt = rd["SUPAMT"].ToString(),
                        vatamt = rd["VATAMT"].ToString(),
                        amt = rd["PGM_AMT"].ToString(),
                        prtYn = rd["PRT_YN"].ToString(),
                        prtDate = rd["PRT_DATE"].ToString(),
                        reqDate = rd["REQ_DATE"].ToString(),
                        status = rd["STATUS"].ToString(),
                        issCdStatus = rd["ISS_CD_STATUS"].ToString(),
                        rtnMsg = rd["RTN_MSG"].ToString(),
                        rtnDate = rd["RTN_DATE"].ToString(),
                        canReason = rd["CAN_REASON"].ToString(),
                        receiptId = rd["RECEIPT_ID"].ToString(),
                        etaxSeq = rd["ETAX_SEQ"].ToString(),
                        cret_yn = rd["CRET_YN"].ToString(),
                        mName = rd["MNAME"].ToString(),
                        mainCcname = rd["MAIN_CCNAME"].ToString(),
                        regNo = rd["REG_NO"].ToString(),
                    };

                    calc.Add(c);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Calculate/searchShopTax : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = calc });
        }

        /// <summary>
        /// 생성 발행 미생성 미발행 세금계산서 갯수 조회
        /// </summary>
        /// <remarks>
        /// 미생성 기간기준: CHARGE_DATE 정산일자
        /// </remarks>
        [HttpGet("getCount")]
        public async Task<IActionResult> getCount(string jobGbn, string feeYm)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string generated = string.Empty;
            string published = string.Empty;
            string ungenerated = string.Empty;
            string unpublished = string.Empty;

            string generatedAmt = string.Empty;
            string publishedAmt = string.Empty;
            string ungeneratedAmt = string.Empty;
            string unpublishedAmt = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CALC.GET_COUNT",
            };

            try
            {
                cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 10).Value = jobGbn;
                cmd.Parameters.Add("in_fee_ym", OracleDbType.Varchar2, 10).Value = feeYm;
                cmd.Parameters.Add("out_generated", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_published", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_ungenerated", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_unpublished", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_g_amt", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_p_amt", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_ung_amt", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_unp_amt", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                generated = cmd.Parameters["out_generated"].Value.ToString();
                published = cmd.Parameters["out_published"].Value.ToString();
                ungenerated = cmd.Parameters["out_ungenerated"].Value.ToString();
                unpublished = cmd.Parameters["out_unpublished"].Value.ToString();

                generatedAmt = cmd.Parameters["out_g_amt"].Value.ToString();
                publishedAmt = cmd.Parameters["out_p_amt"].Value.ToString();
                ungeneratedAmt = cmd.Parameters["out_ung_amt"].Value.ToString();
                unpublishedAmt = cmd.Parameters["out_unp_amt"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Calculate/getCount : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, ungenerated = ungenerated, generated = generated, unpublished = unpublished, published = published, ungeneratedAmt = ungeneratedAmt, generatedAmt = generatedAmt, unpublishedAmt = unpublishedAmt, publishedAmt = publishedAmt });
        }




        [HttpGet("getTaxLog")]
        public async Task<IActionResult> getTaxLog(string div, string error_gbn, string divKey, string keyword, string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            string RtotalCount = string.Empty;

            string sDiv = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("div", div);
            param.Add("error_gbn", error_gbn);
            param.Add("divKey", divKey);
            param.Add("keyword", "%" + keyword + "%");
            param.Add("date_begin", date_begin);
            param.Add("date_end", date_end);
            param.Add("page", page);
            param.Add("row_count", rows);

            try
            {

                db.Open();

                string sql = @$"
                                SELECT COUNT(*)
                                FROM tax_error_log
                            ";
                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);


                sql = @$"
                            SELECT COUNT(*)
                            FROM tax_error_log a, users b
                            WHERE a.ins_ucode = b.ucode (+)
                            and TO_CHAR(a.ins_time,'YYYYMMDD') BETWEEN :date_begin AND :date_end
                            and a.div like case when :div is null then '%' else :div end
                            and a.error_gbn like case when :error_gbn is null then '%' else :error_gbn end
                            and case when :divkey = 1  then b.user_name
                                    when :divkey = 2  then a.error_msg
                                    when :divkey = 3  then a.position
                                end like :keyword
                            
                        ";
                Rcount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);


                sql = @$"
                            SELECT to_char(T2.seq) as seq, T2.error_gbn, T2.div, T2.ins_time , T2.position, T2.error_msg, to_char(T2.ins_ucode) as ins_ucode, T2.user_name, T2.parameter
                              FROM (SELECT ROWNUM AS RNUM,
                                           T1.*
                                      FROM (SELECT a.*, b.user_name
                                            FROM tax_error_log a, users b
                                            WHERE a.ins_ucode = b.ucode (+)
                                            and TO_CHAR(a.ins_time,'YYYYMMDD') BETWEEN :date_begin AND :date_end
                                            and a.div like case when :div is null then '%' else :div end
                                            and a.error_gbn like case when :error_gbn is null then '%' else :error_gbn end
                                            and case when :divkey = 1  then b.user_name
                                                    when :divkey = 2  then a.error_msg
                                                    when :divkey = 3  then a.position
                                                end like :keyword
                                            ORDER BY SEQ DESC) T1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) T2
                             WHERE (( :page - 1) * :row_count) < RNUM 
                        ";


                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Calculate/getTaxLog : Get", ex.Message);
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, count = Rcount, data = items });
        }



        //생성 발행 미생성 미발행 세금계산서 갯수 조회
        //[HttpGet("getCountV2")]
        //public async Task<IActionResult> getCountV2(string feeYm)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;
        //    string r = string.Empty;
        //    string c = string.Empty;
        //    string p = string.Empty;
        //    string published = string.Empty;

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
        //    OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_CALC.GET_COUNT_V2",
        //    };

        //    try
        //    {
        //        //cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 10).Value = jobGbn;
        //        cmd.Parameters.Add("in_fee_ym", OracleDbType.Varchar2, 10).Value = feeYm;
        //        cmd.Parameters.Add("out_c", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //        cmd.Parameters.Add("out_r", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //        cmd.Parameters.Add("out_p", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //        cmd.Parameters.Add("out_published", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //        cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //        cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;


        //        await conn.OpenAsync();
        //        await cmd.ExecuteNonQueryAsync();

        //        Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        Rmsg = cmd.Parameters["out_msg"].Value.ToString();
        //        r = cmd.Parameters["out_r"].Value.ToString();
        //        c = cmd.Parameters["out_c"].Value.ToString();
        //        p = cmd.Parameters["out_p"].Value.ToString();
        //        published = cmd.Parameters["out_published"].Value.ToString();

        //        await conn.CloseAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/Calculate/getCountV2 : Get", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg, ungenerated = c, publishing = r, unpublishing = p, published = published });
        //}


 
        /// <summary>
        /// 전자세금계산서 생성(only / except) 
        /// </summary>
        [HttpPost("insertTaxMast")]
        public async Task<IActionResult> insertTaxMast(string jobGbn, string div, IEnumerable<string> shopCd, string feeYm, string memo, string modUcode, string modName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string num = string.Empty;
            string err = string.Empty;

            //shopCd = new String[] { new string("1") };

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            string p = string.Empty;
            if (div == "I")
            {
                p = "PKG_IS_ADMIN_CALC.INSERT_TAX_MAST";

            }
            else if (div == "O")
            {
                p = "PKG_IS_ADMIN_CALC.INSERT_TAX_MAST_EXCEPT";
                if (shopCd?.Any() == false)
                {
                    shopCd = new String[] { "1" };
                }

            }

            if (jobGbn == "%")
            {
                div = "O";
                p = "PKG_IS_ADMIN_CALC.INSERT_TAX_MAST_ALL";
                shopCd = new String[] { "1" };
            }


            try
            {
                OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = p,

                };

                cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 10).Value = jobGbn;
                //cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 10).Value = div;
                var arrShopCd = cmd.Parameters.Add("in_shop_cd_arry", OracleDbType.Varchar2, 20);
                arrShopCd.Direction = ParameterDirection.Input;
                arrShopCd.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                arrShopCd.Value = shopCd.ToArray();
                arrShopCd.Size = shopCd.Count();
                arrShopCd.ArrayBindSize = shopCd.Select(_ => _.Length).ToArray();
                arrShopCd.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, shopCd.Count()).ToArray();
                cmd.Parameters.Add("in_fee_ym", OracleDbType.Varchar2, 10).Value = feeYm;
                cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 10).Value = memo;
                cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = modUcode;
                cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 10).Value = modName;
                cmd.Parameters.Add("in_row_count", OracleDbType.Int32).Value = shopCd.Count();
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_num", OracleDbType.Int32).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_err", OracleDbType.Int32).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                num = cmd.Parameters["out_num"].Value.ToString();
                err = cmd.Parameters["out_err"].Value.ToString();

                await conn.CloseAsync();


            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Calculate/insertTaXMast : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg , num = num, err = err});
        }


        /// <summary>
        /// 전자세금계산서 발행관리
        /// </summary>
        /// <remarks>
        /// jobGbn: 1 발행요청 /2 발행취소 /3 국세청 전송 /4 세금계산서 삭제 <br/>
        /// jobGbn2 : p/k <br/>
        /// div I/O(in 이것만/ out 이것 제외
        /// </remarks>
        [HttpPut("TaxBill")]
        public async Task<IActionResult> TaxBill(string jobGbn, string jobGbn2, string div, IEnumerable<string> shopCd, string feeYm, string modUcode, string modName, string sendType)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string num = string.Empty;
            string err = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CALC.INSERT_TAX_BILL",
            };

            if (div == "O" && shopCd?.Any() == false)
            {
                shopCd = new String[] { "1" };
            }
            
            if (jobGbn2 == "%")
            {
                div = "O";
                shopCd = new String[] { "1" };
            }

            try
            {
                cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 10).Value = jobGbn;
                cmd.Parameters.Add("in_job_gbn2", OracleDbType.Varchar2, 10).Value = jobGbn2;
                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 10).Value = div;
                var arrShopCd = cmd.Parameters.Add("in_shop_cd_arry", OracleDbType.Varchar2, 20);
                arrShopCd.Direction = ParameterDirection.Input;
                arrShopCd.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                arrShopCd.Value = shopCd.ToArray();
                arrShopCd.Size = shopCd.Count();
                arrShopCd.ArrayBindSize = shopCd.Select(_ => _.Length).ToArray();
                arrShopCd.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, shopCd.Count()).ToArray();
                cmd.Parameters.Add("in_row_count", OracleDbType.Int32).Value = shopCd.Count();
                cmd.Parameters.Add("in_fee_ym", OracleDbType.Varchar2, 10).Value = feeYm;
                cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = modUcode;
                cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 10).Value = modName;
                cmd.Parameters.Add("in_test_yn", OracleDbType.Varchar2, 10).Value = sendType;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 700).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_num", OracleDbType.Int32).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_err", OracleDbType.Int32).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                num = cmd.Parameters["out_num"].Value.ToString();
                err = cmd.Parameters["out_err"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Calculate/TaXBill : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, num = num, err = err });
        }
        #endregion[세금계산서]

        // 가맹점 적립금 사입 -- (함수 불러오기 양식)
        [HttpPost("insertShopCharge")]
        public async Task<IActionResult> insertShopCharge(string mcode, string cccode, string shopCd, string ioGbn, string amt, string memo, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);


            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.Text,
                CommandText = "SELECT PKG_IS_ADMIN_CALC.INSERT_SHOP_CHARGE_NEW(:in_mcode, :in_cccode, :in_shop_cd, '', '', :in_amt, :in_memo, '', :in_mcode, :incccode, '1', :in_io_gbn, :in_charge_ucode) FROM DUAL",
            };

            try
            {
                cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mcode;
                cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = cccode;
                cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shopCd;
                //cmd.Parameters.Add("in_bankcode", OracleDbType.Char).Value = "";  
                //cmd.Parameters.Add("in_vaccount", OracleDbType.Varchar2, 10).Value = "";  
                cmd.Parameters.Add("in_amt", OracleDbType.Int32).Value = amt;  
                cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 200).Value = memo;
                //cmd.Parameters.Add("in_charge_acc", OracleDbType.Char).Value = "";
                cmd.Parameters.Add("in_tran_mcode", OracleDbType.Int32).Value = mcode;
                cmd.Parameters.Add("in_tran_cccode", OracleDbType.Varchar2, 10).Value = cccode;
                //cmd.Parameters.Add("in_charge_gbn", OracleDbType.Varchar2, 10).Value = "1";
                cmd.Parameters.Add("in_io_gbn", OracleDbType.Varchar2, 10).Value = ioGbn;
                cmd.Parameters.Add("in_charge_ucode", OracleDbType.Int32).Value = ucode;
                //cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                //cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var re = await cmd.ExecuteScalarAsync();

                await conn.CloseAsync();

                Rcode = "00";
                Rmsg = re.ToString();

                
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Calculate/insertShopCharge : Post", ex.Message);

                Rcode = "-1";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        // 값 받아서 가맹점 적립금 충전하는 rest
        [HttpPut("chargeShopMileage")]
        public async Task<IActionResult> chargeShopMileage(string[] shop_cd, string mcode, string req_mileage, string mileage_memo, string ucode)
        {


            if (string.IsNullOrEmpty(req_mileage))
            {
                return Ok(new { code = "99", msg = "신청마일리지를 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(mileage_memo))
            {
                return Ok(new { code = "99", msg = "메모를 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(ucode))
            {
                return Ok(new { code = "99", msg = "지급자를 제대로 설정해주세요." });
            }


            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object Rdata = string.Empty;

            string sql = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            db.Open();

            try
            {

                DynamicParameters param = new DynamicParameters();
                param.Add("mcode", mcode);
                param.Add("req_mileage", req_mileage);
                param.Add("mileage_memo", mileage_memo);
                param.Add("ucode", ucode);

                string[] cccode = new string[shop_cd.Length];
                // 각 샵코드의 콜센터 구하기
                int n = 0;
                foreach (string e in shop_cd)
                {
                    sql = $@" SELECT TO_CHAR(A.cccode) FROM SHOP_INFO A, CALLCENTER B WHERE A.CCCODE = B.CCCODE AND B.mcode = :mcode and A.shop_cd = '{e}'";
                    cccode[n] = (string)await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);
                    if (string.IsNullOrEmpty(cccode[n]))
                    {
                        return Ok(new { code = "99", msg = e + " - 잘못된 가맹점 번호입니다." });
                    }

                    await insertShopCharge(mcode, cccode[n], e, "I", req_mileage, mileage_memo, ucode);

                    n++;

                }




                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            db.Close();
            return Ok(new { code = Rcode, msg = Rmsg });
        }

        #region[가맹점 적립금 관리]
        /// <summary>
        /// 가맹점 검색
        /// </summary>
        /// <remarks>
        /// mcode 회원사(1 테스트, 2 운영) <br/>
        /// service_gbn : 서비스 구분(빈값 : 전체, 0 : 주문, 1 : 특별관, 2 : 꽃배달, 3 : 로컬푸드, 4 : 전통시장, 5 : 전자관) <br />
        /// keyword 가맹점명 검색(필수) <br/>
        /// </remarks>
        [HttpGet("getShopList")]
        public async Task<IActionResult> getShopList(string mcode, string service_gbn, string cccode, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RCount = string.Empty;
            List<Object> items = new List<Object>();

            if (string.IsNullOrEmpty(keyword))
            {
                Rcode = "99";
                Rmsg = "검색어는 필수입니다.";
                return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
            }

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_mcode", mcode);
            param.Add("in_service_gbn", service_gbn);
            param.Add("in_cccode", cccode);
            param.Add("in_keyword", keyword);
            param.Add("page", page);
            param.Add("row_count", rows);

            try
            {
                db.Open();

                string countSql = $@"
                                    select count(*)
                                    from shop_info a, callcenter b
                                    where a.cccode = b.cccode
                                    and b.mcode = :in_mcode
                                    AND a.CCCODE LIKE CASE WHEN :in_cccode IS NOT NULL THEN :in_cccode ELSE '%' END
                                    and a.service_gbn like case when :in_service_gbn is not null then :in_service_gbn else '%' end
                                    and a.shop_name like '%' || :in_keyword || '%'
                               ";

                RCount = await db.ExecuteScalarAsync<string>(countSql, param, commandType: CommandType.Text);

                string sql = @$"
                                SELECT t2.*
                                    FROM (SELECT ROWNUM AS rnum, t1.*
                                        FROM(select b.mcode ""mcode"", a.cccode ""cccode"", a.shop_cd ""shop_cd"", a.shop_name ""shop_name"", a.remain_amt ""remain_amt""
                                            from shop_info a, callcenter b
                                            where a.cccode = b.cccode
                                            and b.mcode = :in_mcode
                                            AND a.CCCODE LIKE CASE WHEN :in_cccode IS NOT NULL THEN :in_cccode ELSE '%' END
                                            and a.service_gbn like case when :in_service_gbn is not null then :in_service_gbn else '%' end
                                            and a.shop_name like '%' || :in_keyword || '%'
                                            order by to_number(a.shop_cd)) t1
                                         WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                                    WHERE (( :page - 1) * :row_count) < rnum
                                    order by rnum
                            ";

            
                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
        }

        /// <summary>
        /// 가맹점 적립금 관리2(기간조건:CHARGE_DATE 정산일자)
        /// </summary>
        /// <remarks>
        /// service_gbn : 서비스 구분(빈값 : 전체, 0 : 주문, 1 : 특별관, 2 : 꽃배달, 3 : 로컬푸드, 4 : 전통시장, 5 : 전자관) <br />
        /// trad_yn 묶음주문여부(빈값:전체, Y:묶음주문, N:일반주문) <br />
        /// charge_gbn : 적립구분<br />
        /// mcode : 1.테스트 2.운영 <br />
        /// test_yn : (Y: 테스트건만, N: 테스트건 제외, 공백: 전체) <br />
        /// div : keyword 검색조건 1.주문번호, 2.가맹점명  <br />
        /// shop_cd : 특정 가맹점 선택조회시 기입 <br />
        /// </remarks>
        [HttpGet("getShopCalculateList2")]
        public async Task<IActionResult> getShopCalculateList2(string service_gbn, string trad_yn, string charge_gbn, string mcode, string cccode, string test_yn, string date_begin, string date_end, string div, string keyword, string memo, string shop_cd, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object RtotalCount = string.Empty;
            string RCount = string.Empty;


            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("service_gbn", service_gbn);
                param.Add("trad_yn", trad_yn);
                param.Add("charge_gbn", charge_gbn);
                param.Add("mcode", mcode);
                param.Add("cccode", cccode);
                param.Add("test_yn", test_yn);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("div", div);
                param.Add("keyword", (string.IsNullOrEmpty(keyword)) ? null : "%" + keyword + "%");
                param.Add("memo", (string.IsNullOrEmpty(memo)) ? null : "%" + memo + "%");
                param.Add("shop_cd", shop_cd);
                param.Add("page", page);
                param.Add("row_count", rows);

                // 가맹점명 검색시 가맹점순 정렬처리
                string orderSql = string.Empty;

                if (div == "2" && !string.IsNullOrEmpty(keyword))
                {
                    orderSql = "nvl(to_number(z.shop_cd),0),";
                }

                string hintSql = "/*+ FULL(a) PARALLEL(a 4) */";

                string shopCdSql = string.Empty;

                if (!string.IsNullOrEmpty(shop_cd))
                {
                    hintSql = string.Empty;
                    shopCdSql = "and a.shop_cd = :shop_cd";
                }



                string countSql = string.Empty;

                countSql = $@"
                                    SELECT   {hintSql}
                                                count(*)
                                            FROM SHOP_INFOCHARGE A, CALLCENTER B, shop_info s, voucher_mst v, voucher_code_set v2, voucher_code_grp v3
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = :mcode 
                                            {shopCdSql}
                                            AND   A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = 1 and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and a.shop_cd = s.shop_cd
                                            and s.shop_name LIKE CASE WHEN :div = 2 and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and s.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            and case when :trad_yn is null then NVL(a.M_SHOP_CD,'0')
                                                     when :trad_yn = 'Y' then A.M_SHOP_CD
                                                     when :trad_yn = 'N' then '0' end LIKE NVL(a.M_SHOP_CD,'0')
                                            and a.MEMO LIKE CASE WHEN :MEMO IS NOT NULL THEN :MEMO ELSE '%' END
                                    ";

                RCount = await db.ExecuteScalarAsync<string>(countSql, param, commandType: CommandType.Text);

                string sql = string.Empty;

                sql = $@"
                                SELECT t2.*, 
                                NVL(C.USER_NAME,T2.CHARGE_UCODE) AS CHARGE_NAME,
                                (SELECT SF_GET_CHARGE_GBN('1', t2.CHARGE_GBN) FROM DUAL) AS CHARGE_GBN_NM
                                FROM (SELECT ROWNUM AS rnum, t1.*
                                    FROM (SELECT Z.SEQNO,
                                                 Z.MCODE,
                                                 Z.CCCODE,
                                                 Z.CCNAME,
                                                 Z.SERVICE_GBN,
                                                 Z.SHOP_CD ,
                                                 Z.SHOP_NAME,
                                                 Z.ORDER_DATE,
                                                 Z.CHARGE_DATE,
                                                 Z.CHARGE_GBN,
                                                 Z.IO_GBN,
                                                 sum(Z.CHARGE_AMT)CHARGE_AMT,
                                                 sum(Z.IN_AMT)IN_AMT,
                                                 sum(Z.OUT_AMT)OUT_AMT,
                                                 Z.CHARGE_UCODE,
                                                 Z.MEMO,
                                                 Z.ORDER_NO,
                                                 nvl(sum(z.CHARGE_AMT)
                                over(partition by Z.shop_cd order by case when seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || seqno, 'YYYYMMDD HH24MISS') else Z.CHARGE_DATE end, z.seqno rows between unbounded preceding and current row),sum(Z.CHARGE_AMT)) AS PRE_AMT
                                            FROM  ( 
                                            SELECT 
                                                0  AS SEQNO,
                                                C.MCODE,
                                                A.CCCODE,
                                                C.CCNAME,
                                                A.SERVICE_GBN,
                                                A.SHOP_CD ,
                                                A.SHOP_NAME,
                                                :in_fr_dt AS  ORDER_DATE,  
                                                NULL CHARGE_DATE,   
                                                '' CHARGE_GBN,  
                                                '' as IO_GBN,
                                                (SELECT SF_GET_PRE_REMAINAMT_MCODE_NEW(:in_fr_dt, a.CCCODE, A.SHOP_CD, C.MCODE) FROM DUAL) as CHARGE_AMT,
                                                0 AS IN_AMT,
                                                0 AS OUT_AMT,
                                                0 CHARGE_UCODE,   
                                                '이월잔액' AS  MEMO,   
                                                0  AS ORDER_NO
                                            FROM  SHOP_INFO A, CALLCENTER C
                                            WHERE A.CCCODE = C.CCCODE
                                            AND C.MCODE = :mcode 
                                            {shopCdSql}
                                            and a.shop_name LIKE CASE WHEN :div = 2 and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            AND C.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            and a.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                            UNION ALL  
                                            SELECT   {hintSql}
                                                A.SEQNO,
                                                B.MCODE, 
                                                A.CCCODE,
                                                B.CCNAME,
                                                S.SERVICE_GBN,
                                                A.SHOP_CD ,
                                                S.SHOP_NAME,
                                                A.ORDER_DATE,
                                                A.CHARGE_DATE,
                                                A.CHARGE_GBN,
                                                A.IO_GBN,
                                                case when a.iO_gbn = 'I' then A.CHARGE_AMT else A.CHARGE_AMT * -1 end CHARGE_AMT,
                                                CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                                CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT,
                                                A.CHARGE_UCODE,
                                                A.MEMO ,
                                                nvl(A.ORDER_NO,0) as ORDER_NO
                                            FROM SHOP_INFOCHARGE A, CALLCENTER B, shop_info s, voucher_mst v, voucher_code_set v2, voucher_code_grp v3
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = :mcode 
                                            {shopCdSql}
                                            AND   A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = 1 and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and a.shop_cd = s.shop_cd
                                            and s.shop_name LIKE CASE WHEN :div = 2 and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and s.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            and case when :trad_yn is null then NVL(a.M_SHOP_CD,'0')
                                                     when :trad_yn = 'Y' then A.M_SHOP_CD
                                                     when :trad_yn = 'N' then '0' end LIKE NVL(a.M_SHOP_CD,'0')
                                            UNION ALL
                                            SELECT  {hintSql} 1    AS SEQNO,  
                                                    A.MCODE,
                                                    A.CCCODE,
                                                    C.CCNAME,
                                                    S.SERVICE_GBN,
                                                    A.SHOP_CD ,
                                                    S.SHOP_NAME,
                                                    :in_fr_dt AS  ORDER_DATE,  
                                                    NULL CHARGE_DATE,   
                                                    '' CHARGE_GBN, 
                                                    '' as IO_GBN,
                                                    SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END) * -1 as CHARGE_AMT,
                                                    0   AS IN_AMT,
                                                    0   AS OUT_AMT,
                                                    0   AS CHARGE_UCODE,
                                                    '마감전 입출금액 ('  || to_char(SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END),'fm999,999,999') || ')'  AS MEMO , 
                                                     0    AS ORDER_NO
                                            FROM   SHOP_INFOCHARGE A, CALLCENTER C, SHOP_INFO S
                                            WHERE  A.CCCODE = C.CCCODE
                                            AND    A.MCODE           = :mcode  
                                            AND    A.SHOP_CD = S.SHOP_CD
                                            {shopCdSql}
                                            and s.shop_name LIKE CASE WHEN :div = 2 and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            AND    A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            and s.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                            GROUP BY A.MCODE,
                                                     A.CCCODE,
                                                     C.CCNAME,
                                                     S.SERVICE_GBN,
                                                     A.SHOP_CD ,
                                                     S.SHOP_NAME
                                            )  Z 
                                    where Z.MEMO LIKE CASE WHEN :MEMO IS NOT NULL THEN :MEMO ELSE '%' END
                                    group by rollup((Z.SEQNO, Z.MCODE, Z.CCCODE, Z.CCNAME, Z.SERVICE_GBN, Z.SHOP_CD , Z.SHOP_NAME,
                                             Z.ORDER_DATE, Z.CHARGE_DATE, Z.CHARGE_GBN, Z.IO_GBN,
                                             Z.CHARGE_AMT,
                                             Z.CHARGE_UCODE, Z.MEMO , Z.ORDER_NO))
                                    ORDER BY {orderSql} nvl(Z.CHARGE_DATE,to_date(:in_fr_dt,'YYYYMMDD')), z.seqno
                                    ) t1
                                     WHERE nvl(T1.SEQNO,2) NOT IN (0,1)
                                     AND ROWNUM - 1 <= (( :page - 1) * :row_count) + :row_count) t2 , USERS C
                                WHERE (( :page - 1) * :row_count + case when :page = 1 then 0 else 1 end) < rnum
                                AND   t2.CHARGE_UCODE = C.UCODE(+)
                                order by rnum
                                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Calculate/getShopCalculateList2 : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
        }

        /// <summary>
        /// 가맹점 적립금 관리 엑셀출력2(기간조건:CHARGE_DATE 정산일자)
        /// </summary>
        /// <remarks>
        /// service_gbn : 서비스 구분(빈값 : 전체, 0 : 주문, 1 : 특별관, 2 : 꽃배달, 3 : 로컬푸드, 4 : 전통시장, 5 : 전자관) <br />
        /// trad_yn 묶음주문여부(빈값:전체, Y:묶음주문, N:일반주문) <br />
        /// charge_gbn : 적립구분<br />
        /// mcode : 1.테스트 2.운영 <br />
        /// test_yn : (Y: 테스트건만, N: 테스트건 제외, 공백: 전체) <br />
        /// div : keyword 검색조건 1.주문번호, 2.가맹점명  <br />
        /// shop_cd : 특정 가맹점 선택조회시 기입 <br />
        /// </remarks>
        [HttpGet("ShopExcelExport2")]
        public async Task<IActionResult> ShopExcelExport2(string service_gbn, string trad_yn, string charge_gbn, string mcode, string cccode, string test_yn, string date_begin, string date_end, string div, string keyword, string memo, string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object RtotalCount = string.Empty;
            string RCount = string.Empty;


            List<ShopCalcExcel2> items = new List<ShopCalcExcel2>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("service_gbn", service_gbn);
                param.Add("trad_yn", trad_yn);
                param.Add("charge_gbn", charge_gbn);
                param.Add("mcode", mcode);
                param.Add("cccode", cccode);
                param.Add("test_yn", test_yn);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("div", div);
                param.Add("keyword", (string.IsNullOrEmpty(keyword)) ? null : "%" + keyword + "%");
                param.Add("memo", (string.IsNullOrEmpty(memo)) ? null : "%" + memo + "%");
                param.Add("shop_cd", shop_cd);

                // 가맹점명 검색시 가맹점순 정렬처리
                string orderSql = string.Empty;

                if (div == "2" && !string.IsNullOrEmpty(keyword))
                {
                    orderSql = "nvl(to_number(z.shop_cd),0),";
                }

                string hintSql = "/*+ FULL(a) PARALLEL(a 4) */";

                string shopCdSql = string.Empty;

                if (!string.IsNullOrEmpty(shop_cd))
                {
                    hintSql = string.Empty;
                    shopCdSql = "and a.shop_cd = :shop_cd";
                }

                string sql = string.Empty;

                sql = $@"
                                SELECT t2.*, 
                                NVL(C.USER_NAME,T2.CHARGE_UCODE) AS CHARGE_NAME,
                                (SELECT SF_GET_CHARGE_GBN('1', t2.CHARGE_GBN) FROM DUAL) AS CHARGE_GBN_NM
                                FROM (SELECT ROWNUM AS rnum, t1.*
                                    FROM (SELECT Z.SEQNO,
                                                 Z.MCODE,
                                                 Z.CCNAME,
                                                 Z.SERVICE_GBN,
                                                 Z.SHOP_CD ,
                                                 Z.SHOP_NAME,
                                                 Z.ORDER_DATE,
                                                 Z.CHARGE_DATE,
                                                 Z.CHARGE_GBN,
                                                 Z.IO_GBN,
                                                 sum(Z.CHARGE_AMT)CHARGE_AMT,
                                                 sum(Z.IN_AMT)IN_AMT,
                                                 sum(Z.OUT_AMT)OUT_AMT,
                                                 Z.CHARGE_UCODE,
                                                 Z.MEMO,
                                                 Z.ORDER_NO,
                                                 nvl(sum(z.CHARGE_AMT)
                                over(partition by Z.shop_cd order by case when seqno in (0,1) then TO_DATE(:in_fr_dt||' 00000' || seqno, 'YYYYMMDD HH24MISS') else Z.CHARGE_DATE end, z.seqno rows between unbounded preceding and current row),sum(Z.CHARGE_AMT)) AS PRE_AMT
                                            FROM  ( 
                                            SELECT 
                                                0  AS SEQNO,
                                                C.MCODE,
                                                C.CCNAME,
                                                A.SERVICE_GBN,
                                                A.SHOP_CD ,
                                                A.SHOP_NAME,
                                                :in_fr_dt AS  ORDER_DATE,  
                                                NULL CHARGE_DATE,   
                                                '' CHARGE_GBN,  
                                                '' as IO_GBN,
                                                (SELECT SF_GET_PRE_REMAINAMT_MCODE_NEW(:in_fr_dt, a.CCCODE, A.SHOP_CD, C.MCODE) FROM DUAL) as CHARGE_AMT,
                                                0 AS IN_AMT,
                                                0 AS OUT_AMT,
                                                0 CHARGE_UCODE,   
                                                '이월잔액' AS  MEMO,   
                                                0  AS ORDER_NO
                                            FROM  SHOP_INFO A, CALLCENTER C
                                            WHERE A.CCCODE = C.CCCODE
                                            AND C.MCODE = :mcode 
                                            {shopCdSql}
                                            and a.shop_name LIKE CASE WHEN :div = 2 and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            AND C.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            and a.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                            UNION ALL  
                                            SELECT   {hintSql}
                                                A.SEQNO,
                                                B.MCODE, 
                                                B.CCNAME,
                                                S.SERVICE_GBN,
                                                A.SHOP_CD ,
                                                S.SHOP_NAME,
                                                A.ORDER_DATE,
                                                A.CHARGE_DATE,
                                                A.CHARGE_GBN,
                                                A.IO_GBN,
                                                case when a.iO_gbn = 'I' then A.CHARGE_AMT else A.CHARGE_AMT * -1 end CHARGE_AMT,
                                                CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE 0 END  AS IN_AMT,
                                                CASE WHEN A.IO_GBN = 'O' THEN A.CHARGE_AMT ELSE 0 END  AS OUT_AMT,
                                                A.CHARGE_UCODE,
                                                A.MEMO ,
                                                nvl(A.ORDER_NO,0) as ORDER_NO
                                            FROM SHOP_INFOCHARGE A, CALLCENTER B, shop_info s, voucher_mst v, voucher_code_set v2, voucher_code_grp v3
                                            WHERE A.CCCODE = B.CCCODE
                                            AND   A.MCODE        = :mcode 
                                            {shopCdSql}
                                            AND   A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            AND nvl(to_char(A.ORDER_NO),'%') LIKE CASE WHEN :div = 1 and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and a.shop_cd = s.shop_cd
                                            and s.shop_name LIKE CASE WHEN :div = 2 and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            and nvl(v3.test_yn,'N') like case when :test_yn is null then '%' else :test_yn end
                                            and a.voucher_no = v.voucher_no (+)
                                            and v.voucher_type = v2.voucher_type (+)
                                            and v2.group_cd = v3.group_cd (+)
                                            and s.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                            and a.charge_gbn like case when :charge_gbn is null then '%' else :charge_gbn end
                                            and case when :trad_yn is null then NVL(a.M_SHOP_CD,'0')
                                                     when :trad_yn = 'Y' then A.M_SHOP_CD
                                                     when :trad_yn = 'N' then '0' end LIKE NVL(a.M_SHOP_CD,'0')
                                            UNION ALL
                                            SELECT  {hintSql} 1    AS SEQNO,  
                                                    A.MCODE,
                                                    C.CCNAME,
                                                    S.SERVICE_GBN,
                                                    A.SHOP_CD ,
                                                    S.SHOP_NAME,
                                                    :in_fr_dt AS  ORDER_DATE,  
                                                    NULL CHARGE_DATE,   
                                                    '' CHARGE_GBN, 
                                                    '' as IO_GBN,
                                                    SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END) * -1 as CHARGE_AMT,
                                                    0   AS IN_AMT,
                                                    0   AS OUT_AMT,
                                                    0   AS CHARGE_UCODE,
                                                    '마감전 입출금액 ('  || to_char(SUM(CASE WHEN A.IO_GBN = 'I' THEN A.CHARGE_AMT ELSE A.CHARGE_AMT *-1 END),'fm999,999,999') || ')'  AS MEMO , 
                                                     0    AS ORDER_NO
                                            FROM   SHOP_INFOCHARGE A, CALLCENTER C, SHOP_INFO S
                                            WHERE  A.CCCODE = C.CCCODE
                                            AND    A.MCODE           = :mcode  
                                            AND    A.SHOP_CD = S.SHOP_CD
                                            {shopCdSql}
                                            and s.shop_name LIKE CASE WHEN :div = 2 and :keyword IS NOT NULL THEN :keyword ELSE '%' END
                                            AND    A.CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||' 080005', 'YYYYMMDD HH24MISS')
                                            AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                            and s.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                            GROUP BY A.MCODE,
                                                     C.CCNAME,
                                                     S.SERVICE_GBN,
                                                     A.SHOP_CD ,
                                                     S.SHOP_NAME
                                            )  Z 
                                    where Z.MEMO LIKE CASE WHEN :MEMO IS NOT NULL THEN :MEMO ELSE '%' END
                                    group by rollup((Z.SEQNO, Z.MCODE,Z.CCNAME, Z.SERVICE_GBN, Z.SHOP_CD , Z.SHOP_NAME,
                                             Z.ORDER_DATE, Z.CHARGE_DATE, Z.CHARGE_GBN, Z.IO_GBN,
                                             Z.CHARGE_AMT,
                                             Z.CHARGE_UCODE, Z.MEMO , Z.ORDER_NO))
                                    ORDER BY {orderSql} nvl(Z.CHARGE_DATE,to_date(:in_fr_dt,'YYYYMMDD')), z.seqno
                                    ) t1
                                     WHERE nvl(T1.SEQNO,2) NOT IN (0,1)) t2 , USERS C
                                WHERE t2.CHARGE_UCODE = C.UCODE(+)
                                order by rnum
                                ";

                db.Open();

                var temp = await db.QueryAsync<ShopCalcExcel2>(sql, param, commandType: CommandType.Text);

                items = temp.ToList();


                db.Close();

                Rcode = "00";
                Rmsg = "성공";

                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("가맹점적립금관리");
                    var currentRow = 1;
                    var col = 1;

                    worksheet.Cell(currentRow, col++).Value = "주문번호";
                    worksheet.Cell(currentRow, col++).Value = "적립일자";
                    worksheet.Cell(currentRow, col++).Value = "적립구분";
                    worksheet.Cell(currentRow, col++).Value = "콜센터명";
                    worksheet.Cell(currentRow, col++).Value = "가맹점코드";
                    worksheet.Cell(currentRow, col++).Value = "가맹점명";
                    worksheet.Cell(currentRow, col++).Value = "적립금입금";
                    worksheet.Cell(currentRow, col++).Value = "적립금출금";
                    worksheet.Cell(currentRow, col++).Value = "적립잔액";
                    worksheet.Cell(currentRow, col++).Value = "메모";

                    foreach (ShopCalcExcel2 cc in items)
                    {
                        currentRow++;
                        col = 1;

                        worksheet.Cell(currentRow, col++).Value = cc.order_no;
                        worksheet.Cell(currentRow, col++).Value = cc.charge_date;
                        worksheet.Cell(currentRow, col++).Value = cc.charge_gbn_nm;
                        worksheet.Cell(currentRow, col++).Value = cc.ccname;
                        worksheet.Cell(currentRow, col++).Value = cc.shop_cd;
                        worksheet.Cell(currentRow, col++).Value = cc.shop_name;
                        worksheet.Cell(currentRow, col++).Value = cc.in_amt;
                        worksheet.Cell(currentRow, col++).Value = cc.out_amt;
                        worksheet.Cell(currentRow, col++).Value = cc.pre_amt;
                        worksheet.Cell(currentRow, col++).Value = cc.memo;

                    }

                    worksheet.Columns().AdjustToContents();
                    //worksheet.Rows().AdjustToContents();


                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        return File(content, "application/octet-stream", "shop_infocharge.xlsx");
                    }
                }
                
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Calculate/ShopExcelExport2 : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 가맹점 적립금 합계2
        /// </summary>
        /// <remarks>
        /// service_gbn : 서비스 구분(빈값 : 전체, 0 : 주문, 1 : 특별관, 2 : 꽃배달, 3 : 로컬푸드, 4 : 전통시장, 5 : 전자관) <br />
        /// mcode : 1.테스트 2.운영 <br />
        /// div : keyword 검색조건 1.주문번호, 2.가맹점명(가맹점명 검색일때만 검색기준 합계에 적용)  <br />
        /// shop_cd : 특정 가맹점 선택조회시 기입 <br />
        /// </remarks>
        [HttpGet("getShopCalculateSum2")]
        public async Task<IActionResult> getShopCalculateSum2(string service_gbn, string mcode, string cccode, string date_begin, string date_end, string div, string keyword, string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object Rtotal = string.Empty;
            Object data = string.Empty;

            List<object> items = new List<object>();

            string hintSql = "/*+ orederd  full(A) */";

            string shopCdSql = string.Empty;

            if (!string.IsNullOrEmpty(shop_cd))
            {
                hintSql = string.Empty;
                shopCdSql = "and a.shop_cd = :shop_cd";
            }

            try
            {

                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("service_gbn", service_gbn);
                param.Add("mcode", mcode);
                param.Add("cccode", cccode);
                param.Add("in_fr_dt", date_begin);
                param.Add("in_to_dt", date_end);
                param.Add("div", div);
                param.Add("keyword", (string.IsNullOrEmpty(keyword)) ? null : "%" + keyword + "%");
                param.Add("shop_cd", shop_cd);

                var tSql = $@"
                                SELECT /*+ ORDERED full(A) full(B) full(D) use_hash(B) use_hash(D) */ sum(case when A.io_gbn = 'I' then a.charge_amt else charge_amt * -1 end) as all_amt,
                                           sum(CASE WHEN a.charge_gbn = '3' THEN A.CHARGE_AMT ELSE 0 END)  AS take_amt,
                                           sum(b.remain_amt) as remain_amt
                                    FROM IS_DAEGU.SHOP_INFOCHARGE A,  IS_DAEGU.SHOP_INFO B,  IS_DAEGU.CALLCENTER D
                                    WHERE A.CCCODE = B.CCCODE
                                    AND A.SHOP_CD = B.SHOP_CD
                                    AND B.CCCODE = D.CCCODE
                                    AND D.MCODE = :mcode
                                    AND A.CHARGE_DATE >= TO_DATE('2021080917', 'YYYYMMDDHH24')           
                                ";

                var sql = $@"
                                  SELECT {hintSql}
                                        nvl(sum(case when a.io_gbn = 'I' then a.charge_amt else a.charge_amt * -1 end),0) as all_amt_sum, 
                                        sum(CASE WHEN a.IO_GBN = 'I' and a.charge_gbn <> '3' THEN a.CHARGE_AMT ELSE 0 END)  AS IN_AMT_sum, 
                                        sum(nvl(case when a.charge_gbn = 'P' then case when a.io_gbn = 'O' then a.charge_amt else a.charge_amt * -1 end  end,0)) as p_amt_sum, 
                                        sum(nvl(case when a.charge_gbn = 'K' then case when a.io_gbn = 'O' then a.charge_amt else a.charge_amt * -1 end  end,0)) as k_amt_sum, 
                                        sum(CASE WHEN a.charge_gbn = '3' and a.charge_amt > 0 THEN -1
                                                 WHEN a.charge_gbn = '3' and a.charge_amt < 0 THEN 1 END) as take_count_sum, 
                                        sum(CASE WHEN a.charge_gbn = '3' THEN a.CHARGE_AMT ELSE 0 END)  AS take_amt_sum,
                                        sum(t2.remain_amt) as remain_amt_sum
                                FROM (SELECT ROWNUM AS rnum, t1.*
                                    FROM (select a.SHOP_CD,
                                       a.SHOP_NAME,
                                       a.REG_NO,
                                       a.REMAIN_AMT
                                from IS_DAEGU.shop_info a,IS_DAEGU.callcenter b
                                where a.cccode = b.cccode
                                and b.mcode = :mcode
                                {shopCdSql}
                                AND A.CCCODE LIKE CASE WHEN :cccode IS NOT NULL THEN :cccode ELSE '%' END
                                and a.service_gbn like case when :service_gbn is not null then :service_gbn else '%' end
                                and a.shop_name LIKE CASE WHEN :div = 2 and :keyword IS NOT NULL THEN :keyword ELSE '%' END) t1) t2, 
                                (SELECT * FROM shop_infocharge 
                                    WHERE CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt || ' 000000', 'YYYYMMDD HH24MISS') AND  
                                                            TO_DATE(:in_to_dt || ' 235959', 'YYYYMMDD HH24MISS')) a
                                WHERE t2.shop_cd = a.shop_cd
                                ";


                db.Open();

                Rtotal = await db.QuerySingleAsync<object>(tSql, param, commandType: CommandType.Text);

                data = await db.QuerySingleAsync<object>(sql, param, commandType: CommandType.Text);
                //items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Calculate/getShopCalculateSum2 : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, total = Rtotal, sum = data });
        }

        #endregion[가맹점 적립금 관리]


    }
}
