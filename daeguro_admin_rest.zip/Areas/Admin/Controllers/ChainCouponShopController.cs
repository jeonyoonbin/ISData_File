﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ChainCouponShopController : ControllerBase
    {
        /// <summary>
        /// 브랜드 쿠폰 가맹점 관리 - 목록 조회
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Get(string chainCode, string couponType, string use_yn, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object RtotalCount = string.Empty;
            object RCount = string.Empty;


            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_chain_code", chainCode);
                param.Add("in_coupon_type", couponType);
                param.Add("in_use_yn", use_yn);
                param.Add("page", page);
                param.Add("row_count", rows);


                string sql = $@"
                                  SELECT t2.*
                                  FROM (SELECT ROWNUM AS RNUM,
                                               t1.*
                                        FROM (  select b.shop_cd, b.shop_name, a.coupon_type, d.code_nm, a.use_yn, nvl(a.use_max_count, 0) use_max_count 
                                                from chain_coupon_shop a, shop_info b, callcenter c, etc_code d
                                                where a.shop_cd = b.shop_cd
                                                and b.cccode = c.cccode
                                                and a.coupon_type  = d.code
                                                and d.use_gbn = 'Y'
                                                and chain_code like case when :in_chain_code is not null then :in_chain_code else '%' end
                                                and coupon_type like case when :in_coupon_type is not null then :in_coupon_type else '%' end
                                                and a.use_yn like case when :in_use_yn is not null then :in_use_yn else '%' end
                                                order by b.shop_name) T1
                                         WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) T2
                                 WHERE (( :page - 1) * :row_count) < RNUM
                                ";

                //SELECT t2.*, c.coupon_type, c.use_yn, nvl(c.use_max_count, '') use_max_count
                //                  FROM(SELECT ROWNUM AS RNUM,
                //                               t1.*
                //                        FROM(select a.*, b.*
                //                                from(select b.shop_cd, b.shop_name
                //                                    from shop_info b, callcenter c
                //                                    where b.cccode = c.cccode
                //                                    and c.mcode = :in_mcode
                //                                    and b.franchise_cd like case when: in_chain_code is not null then: in_chain_code else '%' end) a
                //                                    ,
                //                                    (select code, code_nm from etc_code where code_grp = 'BRAND_COUPON' and use_gbn = 'Y'
                //                                    and etc_code1 like case when: in_chain_code is not null then: in_chain_code else '%' end
                //                                    and code like case when: in_coupon_type is not null then: in_coupon_type else '%' end) b
                //                                    where 1 = 1) T1
                //                         WHERE ROWNUM <= (( : page - 1) * :row_count) + :row_count) T2, chain_coupon_shop c
                //                 WHERE(( : page - 1) * :row_count) < RNUM
                //                 and t2.shop_cd = c.shop_cd(+)

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();



                var countSql = $@"
                                    select COUNT(*) from chain_coupon_shop a, shop_info b, callcenter c, etc_code d
                                    where a.shop_cd = b.shop_cd
                                    and b.cccode = c.cccode
                                    and a.coupon_type  = d.code
                                    and d.use_gbn = 'Y'
                                    and chain_code like case when :in_chain_code is not null then :in_chain_code else '%' end
                                    and coupon_type like case when :in_coupon_type is not null then :in_coupon_type else '%' end
                                    and a.use_yn like case when :in_use_yn is not null then :in_use_yn else '%' end
                                ";

                RCount = await db.ExecuteScalarAsync<Int64>(countSql, param, commandType: CommandType.Text);


                var totalSql = $@"
                                    select COUNT(*) from chain_coupon_shop a, shop_info b, callcenter c,  etc_code d
                                     where a.shop_cd = b.shop_cd
                                    and b.cccode = c.cccode
                                    and a.coupon_type  = d.code
                                    and d.use_gbn = 'Y'
                                ";

                //RtotalCount = await db.ExecuteScalarAsync<Int64>(totalSql, param, commandType: CommandType.Text);


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ChainCouponShop : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, total = "0", count = RCount.ToString(), data = items });
        }


        //프렌차이즈 쿠폰 가맹점 수정
        [HttpPut]
        public async Task<IActionResult> Put(IEnumerable<string> shopCd, string couponType, string useYn, string useMaxCount, string modUcode, string modName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            object item = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_coupon_type", couponType);
            param.Add("in_use_yn", useYn);
            param.Add("in_use_max_count", useMaxCount);
            param.Add("in_mod_ucode", modUcode);
            param.Add("in_mod_name", modName);

            try
            {
                db.Open();

                

                foreach (string e in shopCd)
                {

                    string sql = $@"
                                select shop_cd from chain_coupon_shop
                                where COUPON_TYPE = :in_coupon_type
                                and shop_cd = {e}
                                ";

                    item = await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);

                    sql = @$"
                        UPDATE CHAIN_COUPON_SHOP
                            SET USE_YN = :in_use_yn, 
                                USE_MAX_COUNT = :in_use_max_count,
                                MOD_UCODE = :in_mod_ucode,
                                MOD_NAME = :in_mod_name,
                                MOD_DATE = SYSDATE
                            WHERE SHOP_CD = {e}
                            AND COUPON_TYPE = :in_coupon_type
                    ";

                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                }

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ChainCouponShop : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg});
        }

        //프렌차이즈 쿠폰 가맹점 생성
        [HttpPost]
        public async Task<IActionResult> Post(IEnumerable<string> shopCd, string chainCode, string couponType, string couponName, string useMaxCount, string useYn, string ucode, string uname)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            object item = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_chain_code", chainCode);
            param.Add("in_coupon_type", couponType);
            param.Add("in_coupon_name", couponName);
            param.Add("in_use_max_count", useMaxCount);
            param.Add("in_use_yn", useYn);
            param.Add("in_ucode", ucode);
            param.Add("in_uname", uname);

            try
            {
                db.Open();

                //사용가능한 쿠폰타입인지 체크
                string sql = $@"
                                select count(code_nm) 
                                from etc_code 
                                where code_grp = 'BRAND_COUPON' 
                                AND use_gbn = 'Y'
                                AND code = :in_coupon_type
                                ";

                item = await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);

                if (int.Parse(item.ToString()) < 1)
                {
                    Rcode = "99";
                    Rmsg = "사용가능한 쿠폰타입이 아닙니다";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                foreach (string e in shopCd)
                {

                    sql = $@"
                                select count(shop_cd) from chain_coupon_shop
                                where COUPON_TYPE = :in_coupon_type
                                and shop_cd = {e}
                                ";

                    item = await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);

                    if (int.Parse(item.ToString()) < 1)
                    {
                        sql = @$"
                        INSERT INTO CHAIN_COUPON_SHOP(CHAIN_CODE, SHOP_CD, COUPON_TYPE, COUPON_NAME, USE_MAX_COUNT, INS_DATE, INS_UCODE, INS_NAME, USE_YN)
                            VALUES(:in_chain_code, {e}, :in_coupon_type, :in_coupon_name, :in_use_max_count, SYSDATE, :in_ucode, :in_uname, :in_use_yn) 
                    ";

                        await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                    } else
                    {
                        Rcode = "99";
                        Rmsg = "이미 해당 항목이 존재합니다";
                        return Ok(new { code = Rcode, msg = Rmsg });
                    }
                    

                }

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ChainCouponShop : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        //[HttpGet("couponCode")]
        //public async Task<IActionResult> GetCouponCode()
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_COUPON_FC.GET_COUPON_CODE",
        //    };

        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

        //    List<CouponCode> couponCodes = new List<CouponCode>();

        //    try
        //    {
        //        await conn.OpenAsync();
        //        var rd = await cmd.ExecuteReaderAsync();

        //        Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        while (await rd.ReadAsync())
        //        {
        //            CouponCode couponCode = new CouponCode
        //            {
        //                code = rd["CODE"].ToString(),
        //                codeName = rd["CODE_NM"].ToString(),
        //            };

        //            couponCodes.Add(couponCode);
        //        }
        //        await rd.CloseAsync();
        //        await conn.CloseAsync();

        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/CouponFc/couponCode : Get", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg, data = couponCodes });
        //}


        //[HttpGet("{couponNo}")]
        //public async Task<IActionResult> Get(string couponNo)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_FR_COUPON.GET_COUPON_DETAIL",
        //    };

        //    //OracleParameter op = new OracleParameter();
        //    //op.OracleDbType = OracleDbType.RefCursor;
        //    //op.Direction = ParameterDirection.Output;

        //    cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 50).Value = couponNo;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

        //    CouponList coupon = new CouponList();

        //    try
        //    {
        //        await conn.OpenAsync();
        //        var rd = await cmd.ExecuteReaderAsync();

        //        Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        await rd.ReadAsync();

        //        coupon.couponType = rd["COUPON_TYPE"].ToString();
        //        coupon.couponName = rd["COUPON_NAME"].ToString();
        //        coupon.couponNo = rd["COUPON_NO"].ToString();
        //        coupon.randomNo = rd["RANDOM_NO"].ToString();
        //        coupon.barCode = rd["BARCODE"].ToString();
        //        coupon.status = rd["STATUS"].ToString();
        //        coupon.appCustCode = rd["APP_CUST_CODE"].ToString();
        //        coupon.custName = rd["CUST_NAME"].ToString();
        //        coupon.telNo = rd["TELNO"].ToString();
        //        coupon.useAppCustCode = rd["USE_APP_CUST_CODE"].ToString();
        //        coupon.useCustName = rd["USE_CUST_NAME"].ToString();
        //        coupon.useTelNo = rd["USE_TELNO"].ToString();
        //        coupon.orderDate = rd["ORDER_DATE"].ToString();
        //        coupon.orderNo = rd["ORDER_NO"].ToString();
        //        coupon.useDate = rd["USE_DATE"].ToString();
        //        coupon.couponAmt = rd["COUPON_AMT"].ToString();
        //        coupon.linkUrl = rd["LINK_URL"].ToString();
        //        coupon.insDate = rd["INS_DATE"].ToString();
        //        coupon.insUCode = rd["INS_UCODE"].ToString();
        //        coupon.insName = rd["INS_NAME"].ToString();
        //        coupon.expDate = rd["EXP_DATE"].ToString();
        //        coupon.confYN = rd["CONF_YN"].ToString();
        //        coupon.confDate = rd["CONF_DATE"].ToString();
        //        coupon.confUCode = rd["CONF_UCODE"].ToString();
        //        coupon.confName = rd["CONF_NAME"].ToString();

        //        await rd.CloseAsync();
        //        await conn.CloseAsync();

        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/CouponFr/couponNo : Get", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg, data = coupon });
        //}


        //[HttpPost]
        //public async Task<IActionResult> Post(string couponType, int couponCount,string startDate, int insertUcode, string insertName)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    List<CouponList> coupons = new List<CouponList>();

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_COUPON_FC.SET_COUPON_MST",
        //    };

        //    cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
        //    cmd.Parameters.Add("in_coupon_cnt", OracleDbType.Int32).Value = couponCount;
        //    cmd.Parameters.Add("in_st_date", OracleDbType.Varchar2, 10).Value = startDate;
        //    cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = insertUcode;
        //    cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 50).Value = insertName;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();
        //        var rd = await cmd.ExecuteReaderAsync();
        //        Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        await conn.CloseAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/CouponFc : Post", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}


        //[HttpPut]
        //public async Task<IActionResult> Put(string couponType, int couponCount, string oldStatus, string newStatus, IEnumerable<string> couponNo, int jobUcode, string jobName)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    List<CouponList> coupons = new List<CouponList>();

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_COUPON_FC.SET_COUPON_MST_STATUS",
        //    };

        //    cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
        //    cmd.Parameters.Add("in_coupon_cnt", OracleDbType.Int32).Value = couponCount;
        //    cmd.Parameters.Add("in_old_status", OracleDbType.Varchar2, 2).Value = oldStatus;
        //    cmd.Parameters.Add("in_new_status", OracleDbType.Varchar2, 2).Value = newStatus;

        //    var arrCouponNo = cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 50);
        //    arrCouponNo.Direction = ParameterDirection.Input;
        //    arrCouponNo.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
        //    arrCouponNo.Value = couponNo.ToArray();
        //    arrCouponNo.Size = couponNo.Count();
        //    arrCouponNo.ArrayBindSize = couponNo.Select(_ => _.Length).ToArray();
        //    arrCouponNo.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, couponNo.Count()).ToArray();

        //    cmd.Parameters.Add("in_job_ucode", OracleDbType.Int32).Value = jobUcode;
        //    cmd.Parameters.Add("in_job_name", OracleDbType.Varchar2, 50).Value = jobName;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();
        //        var rd = await cmd.ExecuteReaderAsync();
        //        Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        await conn.CloseAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/CouponFc : Put", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}



    }
}
