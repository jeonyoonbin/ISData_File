﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class NoticeController : ControllerBase
    {
        string eventPath = @"\\10.10.10.100\dgnas\Files\EventImage";
        string nasPath = @"\\10.10.10.100\dgnas\Files";
        string noticePath = @"\\10.10.10.100\dgnas\Files\noticeImage";
        string noticeAspPath = @"\\10.10.10.100\dgnas\Files\DgAppEvent";
        string testImagePath = @"E:\iis\Files\TestImage";
        string testPath = @"\sy100";

        /// <summary>
        /// 공지사항목록조회
        /// </summary>
        /// <remarks>   
        /// systemGbnM : 시스템구분(D: 주문앱, F: 꽃배달)(필수) <br/>
        /// noticeGbn : 공지/이벤트 구분(1:공지, 2: 사장님 공지,  3:이벤트, 4: 사장님 이벤트,  5:메인팝업,  6: 사장님 팝업, 7: 시정홍보) <br/>
        /// dispGbn : 게시유무(Y,N) <br/>
        /// fromDate/toDate : 게시 시작일 기준으로 범위 검색(둘다 빈값일 경우 전체기간)
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string systemGbnM, string noticeGbn, string dispGbn, string fromDate, string toDate, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<Notice> itmes = new List<Notice>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_NOTICE.GET_NOTICE_LIST_V2",
            };

            cmd.Parameters.Add("in_system_gbn_m", OracleDbType.Varchar2, 1).Value = systemGbnM;
            cmd.Parameters.Add("in_notice_gbn", OracleDbType.Varchar2, 1).Value = noticeGbn;
            cmd.Parameters.Add("in_disp_gbn", OracleDbType.Varchar2, 1).Value = dispGbn;
            cmd.Parameters.Add("in_fr_date", OracleDbType.Varchar2, 8).Value = fromDate;
            cmd.Parameters.Add("in_to_date", OracleDbType.Varchar2, 8).Value = toDate;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    Notice item = new Notice
                    {
                        noticeSeq = rd["NOTICE_SEQ"].ToString(),
                        systemGbnM = rd["SYSTEM_GBN_M"].ToString(),
                        systemGbn = rd["SYSTEM_GBN"].ToString(),
                        noticeType = rd["NOTICE_TYPE"].ToString(),
                        noticeGbn = rd["NOTICE_GBN"].ToString(),
                        dispGbn = rd["DISP_GBN"].ToString(),
                        dispFromDate = rd["DISP_FR_DATE"].ToString(),
                        dispToDate = rd["DISP_TO_DATE"].ToString(),
                        noticeTitle = rd["NOTICE_TITLE"].ToString(),
                        noticeContents = rd["NOTICE_CONTENTS"].ToString(),
                        extUrlYn = rd["EXT_URL_YN"].ToString(),
                        noticeUrl_1 = rd["NOTICE_URL1"].ToString(),
                        noticeUrl_2 = rd["NOTICE_URL2"].ToString(),
                        hit = rd["HIT"].ToString(),
                        orderDate = rd["ORDER_DATE"].ToString(),
                        insDate = rd["INS_DATE"].ToString(),
                        insUCode = rd["INS_UCODE"].ToString(),
                        insName = rd["INS_NAME"].ToString(),
                        modDate = rd["MOD_DATE"].ToString(),
                        modUCode = rd["MOD_UCODE"].ToString(),
                        modName = rd["MOD_NAME"].ToString()
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Notice : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }

        /// <summary>
        /// 공지사항 상세조회
        /// </summary>
        /// <remarks>        
        /// noticeType : 공지타입 (0: 전체공지, 1: 주문앱 공지) <br/>
        /// noticeGbn : 공지/이벤트 구분(1:공지, 2: 사장님 공지,  3:이벤트, 4: 사장님 이벤트,  5:메인팝업,  6: 사장님 팝업, 7: 시정홍보) <br/>
        /// systemGbnM : 시스템 구분(D: 주문앱, F: 꽃배달) <br/> 
        /// dispGbn : 게시유무(Y,N) <br/>
        /// dispFromDate 게시시작일 <br/>
        /// dispToDate 게시종료일 <br/>
        /// dispFromTimeH 게시시작 시 <br/> 
        /// dispFromTimeM 게시시작 분 <br/>
        /// dispToTimeH 게시종료 시 <br/> 
        /// dispToTimeH 게시종료 분 <br/> 
        /// extUrlYn : 외부URL 사용 유무 <br/>
        /// noticeUrl_1 : 게시 이미지 명 <br/>
        /// noticeUrl_2 : html URL 주소 <br/>
        /// connect_gbn : (팝업)연결 구분 (0: 미연결, 1: 공지, 3: 이벤트) <br/>
        /// systemGbn : (팝업)연결 시스템 구분(D: 주문앱, T: 택시, R: 예약) <br/> 
        /// boardseq : (팝업)연결 게시글번호
        /// orderDate 영업일 기준 작성일자 <br/>
        /// insDate 작성일자
        /// </remarks>
        [HttpGet("{noticeSeq}")]
        public async Task<IActionResult> Get(int noticeSeq)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_NOTICE.GET_NOTICE_DETAIL",
            };

            //OracleParameter op = new OracleParameter();
            //op.OracleDbType = OracleDbType.RefCursor;
            //op.Direction = ParameterDirection.Output;

            cmd.Parameters.Add("in_notice_seq", OracleDbType.Int32).Value = noticeSeq;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            Notice item = new Notice();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.noticeSeq = rd["NOTICE_SEQ"].ToString();
                item.systemGbnM = rd["SYSTEM_GBN_M"].ToString();
                item.systemGbn = rd["SYSTEM_GBN"].ToString();
                item.noticeType = rd["NOTICE_TYPE"].ToString();
                item.noticeGbn = rd["NOTICE_GBN"].ToString();
                item.dispGbn = rd["DISP_GBN"].ToString();
                item.dispFromDate = rd["DISP_FR_DATE"].ToString();
                item.dispToDate = rd["DISP_TO_DATE"].ToString();
                item.dispFromTimeH = rd["DISP_FR_H"].ToString();
                item.dispFromTimeM = rd["DISP_FR_M"].ToString();
                item.dispToTimeH = rd["DISP_TO_H"].ToString();
                item.dispToTimeM = rd["DISP_TO_M"].ToString();
                item.noticeTitle = rd["NOTICE_TITLE"].ToString();
                item.noticeContents = rd["NOTICE_CONTENTS"].ToString();
                item.extUrlYn = rd["EXT_URL_YN"].ToString();
                item.noticeUrl_1 = rd["NOTICE_URL1"].ToString();
                item.noticeUrl_2 = rd["NOTICE_URL2"].ToString();
                item.connect_gbn = rd["CONNECT_GBN"].ToString();
                item.boardseq = rd["BOARDSEQ"].ToString();
                item.orderDate = rd["ORDER_DATE"].ToString();
                item.insDate = rd["INS_DATE"].ToString();
                item.insUCode = rd["INS_UCODE"].ToString();
                item.insName = rd["INS_NAME"].ToString();
                item.modDate = rd["MOD_DATE"].ToString();
                item.modUCode = rd["MOD_UCODE"].ToString();
                item.modName = rd["MOD_NAME"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Notice/noticeSeq : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 공지사항 등록
        /// </summary>
        /// <remarks>      
        /// systemGbnM : 시스템구분(D: 주문앱, F: 꽃배달)(필수) <br/>   
        /// noticeType : 공지타입 (0: 전체공지, 1: 주문앱 공지) <br/>
        /// noticeGbn : 공지/이벤트 구분(1:공지, 2: 사장님 공지,  3:이벤트, 4: 사장님 이벤트,  5:메인팝업,  6: 사장님 팝업, 7: 시정홍보) <br/>
        /// dispGbn : 게시유무(Y,N) <br/>
        /// dispFromDate 게시시작일 <br/>
        /// dispToDate 게시종료일 <br/> 
        /// dispFromTimeH 게시시작 시 <br/> 
        /// dispFromTimeM 게시시작 분 <br/>
        /// dispToTimeH 게시종료 시 <br/> 
        /// dispToTimeH 게시종료 분 <br/> 
        /// extUrlYn : 외부URL 사용 유무 <br/>
        /// noticeUrl_2 : html URL 주소(외부URL 사용 Y일때 필수) <br/>
        /// connect_gbn : (팝업)연결 구분 (0: 미연결, 1: 공지, 3: 이벤트) <br/>
        /// systemGbn : (팝업)연결 시스템 구분(D: 주문앱, T: 택시, R: 예약) <br/> 
        /// boardseq : (팝업)연결 게시글번호
        /// insUcode, insName 필수
        /// </remarks>
        [HttpPost]
        public async Task<IActionResult> Post(IFormFile formFile, [FromForm] Notice notice)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            if (notice.extUrlYn == "Y" && string.IsNullOrEmpty(notice.noticeUrl_2)) // 외부url사용인데 url이 없는 경우
            {
                Rcode = "99";
                Rmsg = "연결할 외부url이 없습니다.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            try
            {

                if (formFile != null && formFile.Length > 0)
                {
                    // 확장자 가져오기
                    int dotIdx = formFile.FileName.LastIndexOf(".");

                    int extLength = formFile.FileName.Length - dotIdx;

                    string extention = formFile.FileName.Substring(dotIdx, extLength);

                    //noticeUrl_1 확장자
                    notice.noticeUrl_1 = extention;

                    AddNotice addNotice = await AddNotice(notice);

                    if (addNotice.code.Equals("00") && Utils.serverGbn == "R") //운영서버의 경우
                    {
                        // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            string folerPath = eventPath + "\\" + addNotice.fileName;
                            using var stream = System.IO.File.Create(folerPath);

                            await formFile.CopyToAsync(stream);

                            stream.Close();
                            stream.Dispose();
                        }
                    }
                    else if (addNotice.code.Equals("00") && Utils.serverGbn == "T") //테스트서버의 경우
                    {
                        string folerPath = testImagePath + "\\" + addNotice.fileName;
                        using var stream = System.IO.File.Create(folerPath);

                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();
                    }

                    Rcode = addNotice.code;
                    Rmsg = addNotice.msg;

                    // Jpg 포맷으로 변환한다.

                    //using Image img = Image.FromFile(folerPath + "\\" + formFile.FileName);

                    //img.Save(folerPath + "\\" + fileName, System.Drawing.Imaging.ImageFormat.Jpeg);

                    //img.Dispose();

                    //System.IO.File.Delete(folerPath + "\\" + formFile.FileName);

                }
                else
                {
                    //noticeUrl_1 이 항목을 파일유무의 척도로 이용
                    notice.noticeUrl_1 = null;

                    AddNotice addNotice = await AddNotice(notice);

                    Rcode = addNotice.code;
                    Rmsg = addNotice.msg;
                }


            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/Notice : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }


        private async Task<AddNotice> AddNotice(Notice notice)
        {
            AddNotice addNotice = new AddNotice();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_NOTICE.ADD_NOTICE_V3",
            };

            cmd.Parameters.Add("in_system_gbn_m", OracleDbType.Varchar2, 1).Value = notice.systemGbnM;
            cmd.Parameters.Add("in_notice_type", OracleDbType.Varchar2, 1).Value = notice.noticeType;
            cmd.Parameters.Add("in_notice_gbn", OracleDbType.Varchar2, 1).Value = notice.noticeGbn;
            cmd.Parameters.Add("in_disp_gbn", OracleDbType.Varchar2, 1).Value = notice.dispGbn;
            cmd.Parameters.Add("in_disp_fr_date", OracleDbType.Varchar2, 8).Value = notice.dispFromDate;
            cmd.Parameters.Add("in_disp_to_date", OracleDbType.Varchar2, 8).Value = notice.dispToDate;
            cmd.Parameters.Add("in_disp_fr_h", OracleDbType.Varchar2, 2).Value = notice.dispFromTimeH;
            cmd.Parameters.Add("in_disp_fr_m", OracleDbType.Varchar2, 2).Value = notice.dispFromTimeM;
            cmd.Parameters.Add("in_disp_to_h", OracleDbType.Varchar2, 2).Value = notice.dispToTimeH;
            cmd.Parameters.Add("in_disp_to_m", OracleDbType.Varchar2, 2).Value = notice.dispToTimeM;
            cmd.Parameters.Add("in_notice_title", OracleDbType.Varchar2, 400).Value = notice.noticeTitle;
            cmd.Parameters.Add("in_notice_contents", OracleDbType.Varchar2, 4000).Value = notice.noticeContents;
            cmd.Parameters.Add("in_ext_url_yn", OracleDbType.Varchar2, 1).Value = notice.extUrlYn;
            cmd.Parameters.Add("in_notice_url1", OracleDbType.Varchar2, 200).Value = notice.noticeUrl_1;
            cmd.Parameters.Add("in_notice_url2", OracleDbType.Varchar2, 200).Value = notice.noticeUrl_2;
            cmd.Parameters.Add("in_connect_gbn", OracleDbType.Varchar2, 2).Value = notice.connect_gbn;
            cmd.Parameters.Add("in_system_gbn", OracleDbType.Varchar2, 1).Value = notice.systemGbn;
            cmd.Parameters.Add("in_boardseq", OracleDbType.Int32).Value = notice.boardseq;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = notice.insUCode;
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 50).Value = notice.insName;
            cmd.Parameters.Add("out_filename", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                addNotice.fileName = cmd.Parameters["out_filename"].Value.ToString();
                addNotice.code = cmd.Parameters["out_code"].Value.ToString();
                addNotice.msg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Notice : AddNotice", ex.Message);
            }

            return addNotice;
        }

        /// <summary>
        /// 공지사항 수정
        /// </summary>
        /// <remarks>        
        /// systemGbnM : 시스템구분(D: 주문앱, F: 꽃배달)(변경불가) <br/>      
        /// noticeType : 공지타입 (0: 전체공지, 1: 주문앱 공지) <br/>
        /// noticeGbn : 공지/이벤트 구분(1:공지, 2: 사장님 공지,  3:이벤트, 4: 사장님 이벤트,  5:메인팝업,  6: 사장님 팝업, 7: 시정홍보) <br/>
        /// dispGbn : 게시유무(Y,N) <br/>
        /// dispFromDate 게시시작일 <br/>
        /// dispToDate 게시종료일 <br/> 
        /// dispFromTimeH 게시시작 시 <br/> 
        /// dispFromTimeM 게시시작 분 <br/>
        /// dispToTimeH 게시종료 시 <br/> 
        /// dispToTimeH 게시종료 분 <br/> 
        /// extUrlYn : 외부URL 사용 유무 <br/>
        /// noticeUrl_2 : html URL 주소 <br/>
        /// systemGbn : (팝업)연결 시스템 구분(D: 주문앱, T: 택시, R: 예약) <br/> 
        /// connect_gbn : (팝업)연결 구분 (0: 미연결, 1: 공지, 3: 이벤트) <br/>
        /// systemGbn : (팝업)연결 시스템 구분(D: 주문앱, T: 택시, R: 예약) <br/> 
        /// boardseq : (팝업)연결 게시글번호
        /// </remarks>
        [HttpPut]
        public async Task<ResultBasic> Put(IFormFile formFile, [FromForm] Notice notice)
        {
            ResultBasic result = new ResultBasic();

            if (notice.extUrlYn == "Y" && string.IsNullOrEmpty(notice.noticeUrl_2)) // 외부url사용인데 url이 없는 경우
            {
                result.code = "99";
                result.msg = "연결할 외부url이 없습니다.";
                return result;
            }

            try
            {
                if (formFile != null && formFile.Length > 0)
                {
                    // 확장자 가져오기
                    int dotIdx = formFile.FileName.LastIndexOf(".");

                    int extLength = formFile.FileName.Length - dotIdx;

                    string extention = formFile.FileName.Substring(dotIdx, extLength);

                    string dt = DateTime.Now.ToString("yyyyMMddHHmmss");

                    //noticeUrl_1 파일명
                    notice.noticeUrl_1 = notice.noticeSeq + "_" + dt + extention;

                    result = await UpdateNotice(notice);

                    if (result.code.Equals("00") && Utils.serverGbn == "R") //운영서버의 경우
                    {
                        string folerPath = eventPath + "\\" + notice.noticeUrl_1;

                        // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            // 파일이 이미 존재하면 삭제한다.
                            if (System.IO.File.Exists(folerPath))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPath);
                            }

                            //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                            using var stream = new FileStream(folerPath, FileMode.Create);

                            await formFile.CopyToAsync(stream);

                            stream.Close();
                            stream.Dispose();
                        }

                    }
                    else if (result.code.Equals("00") && Utils.serverGbn == "T") //테스트서버의 경우
                    {
                        string folerPath = testImagePath + "\\" + notice.noticeUrl_1;

                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath);
                        }

                        //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                        using var stream = new FileStream(folerPath, FileMode.Create);

                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();
                    }
                }
                else
                {
                    //noticeUrl_1 이 항목을 파일유무의 척도로 이용
                    notice.noticeUrl_1 = "N";

                    result = await UpdateNotice(notice);

                }

            }
            catch (Exception ex)
            {
                result.code = "01";
                result.msg = "예외처리발생";

                await Utils.SaveErrorAsync("/Notice : Put", ex.Message);
            }


            return result;
        }

        private async Task<ResultBasic> UpdateNotice(Notice notice)
        {
            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_NOTICE.UPDATE_NOTICE",
            };

            cmd.Parameters.Add("in_notice_seq", OracleDbType.Int32).Value = notice.noticeSeq;
            cmd.Parameters.Add("in_system_gbn", OracleDbType.Varchar2, 1).Value = notice.systemGbn;
            cmd.Parameters.Add("in_notice_type", OracleDbType.Varchar2, 1).Value = notice.noticeType;
            cmd.Parameters.Add("in_notice_gbn", OracleDbType.Varchar2, 1).Value = notice.noticeGbn;
            cmd.Parameters.Add("in_disp_gbn", OracleDbType.Varchar2, 1).Value = notice.dispGbn;
            cmd.Parameters.Add("in_disp_fr_date", OracleDbType.Varchar2, 8).Value = notice.dispFromDate;
            cmd.Parameters.Add("in_disp_to_date", OracleDbType.Varchar2, 8).Value = notice.dispToDate;
            cmd.Parameters.Add("in_disp_fr_h", OracleDbType.Varchar2, 2).Value = notice.dispFromTimeH;
            cmd.Parameters.Add("in_disp_fr_m", OracleDbType.Varchar2, 2).Value = notice.dispFromTimeM;
            cmd.Parameters.Add("in_disp_to_h", OracleDbType.Varchar2, 2).Value = notice.dispToTimeH;
            cmd.Parameters.Add("in_disp_to_m", OracleDbType.Varchar2, 2).Value = notice.dispToTimeM;
            cmd.Parameters.Add("in_notice_title", OracleDbType.Varchar2, 400).Value = notice.noticeTitle;
            cmd.Parameters.Add("in_notice_contents", OracleDbType.Varchar2, 4000).Value = notice.noticeContents;
            cmd.Parameters.Add("in_ext_url_yn", OracleDbType.Varchar2, 1).Value = notice.extUrlYn;
            cmd.Parameters.Add("in_notice_url1", OracleDbType.Varchar2, 200).Value = notice.noticeUrl_1;
            cmd.Parameters.Add("in_notice_url2", OracleDbType.Varchar2, 200).Value = notice.noticeUrl_2;
            cmd.Parameters.Add("in_connect_gbn", OracleDbType.Varchar2, 2).Value = notice.connect_gbn;
            cmd.Parameters.Add("in_boardseq", OracleDbType.Int32).Value = notice.boardseq;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = notice.modUCode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 50).Value = notice.modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Notice : UpdateNotice", ex.Message);
            }

            return result;
        }

        [HttpGet("getNoticeMain")]
        public async Task<IActionResult> getNoticeMain()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();


                string sql = @"
                                select
                                notice_seq,
                                notice_gbn, 
                                decode(notice_gbn, '1', '[공지]  ', '3', '[이벤트]  ') || notice_title || '       [ ' || to_char(ins_date, 'yyyy-MM-dd') || ' ]' title 
                                from notice_event
                                where disp_gbn = 'Y'
                                order by notice_seq desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 공지사항 순서변경
        /// </summary>
        [HttpPost("updateSort")]
        public async Task<IActionResult> updateSort(IEnumerable<string> couponNo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_NOTICE.UPDATE_SORT_SEQ",
            };

            var arrCouponNo = cmd.Parameters.Add("in_cd_array", OracleDbType.Int32);
            arrCouponNo.Direction = ParameterDirection.Input;
            arrCouponNo.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrCouponNo.Value = couponNo.ToArray();
            arrCouponNo.Size = couponNo.Count();
            arrCouponNo.ArrayBindSize = couponNo.Select(_ => _.Length).ToArray();
            arrCouponNo.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, couponNo.Count()).ToArray();

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Notice/updateSort : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 공지사항 순서조회
        /// </summary>
        /// <remarks>
        /// systemGbnM : 시스템구분(D: 주문앱, F: 꽃배달) <br/>      
        /// noticeGbn : 공지/이벤트 구분(1:공지, 2: 사장님 공지,  3:이벤트, 4: 사장님 이벤트,  5:메인팝업,  6: 사장님 팝업, 7: 시정홍보) <br/>
        /// </remarks>
        [HttpGet("getNoticeSortList")]
        public async Task<IActionResult> getNoticeSortList(string systemGbnM, string noticeGbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();


                string sql = @$"
                                  SELECT notice_seq,
                                         notice_gbn,
                                         notice_title,
                                         disp_fr_date,
                                         disp_to_date
                                    FROM notice_event
                                    WHERE disp_gbn = 'Y'
                                    AND system_gbn_m = '{systemGbnM}'
                                    AND notice_gbn = '{noticeGbn}'
                                    AND disp_to_date >= to_char(sysdate,'YYYYMMDD')
                                   ORDER BY sort_seq desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 파일 업로드
        /// </summary>
        /// <remarks>
        /// div 구분 0: img, 1: html
        /// </remarks>
        [HttpPost("setNoticeFile")]
        public async Task<IActionResult> setNoticeFile(string div, IFormFile formFile)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string path = "https://notice.daeguro.co.kr:45027/event/";

            try
            {
                if (formFile != null && formFile.Length > 0)
                {

                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath)) //이부분 테스트서버에서는 주석막고 밑에 testPest 사용
                    {
                        var dir = (div == "0") ? "img" : "html";
                        string folerPath = noticePath + "\\" + dir;

                        if (Directory.Exists(folerPath) == false)
                        {
                            Directory.CreateDirectory(folerPath);
                        }


                        folerPath = folerPath + "\\" + formFile.FileName;


                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath);
                        }

                        using var stream = System.IO.File.Create(folerPath);
                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();

                        Rcode = "00";

                        Rmsg = path + dir + "/" + formFile.FileName;
                    }

                }

            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생" + ex.Message;
                await Utils.SaveErrorAsync("/Notice/setNoticeFile : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// ASP 파일 업로드
        /// </summary>
        /// <remarks>
        /// div 구분 0: img, 1: asp
        /// </remarks>
        [HttpPost("setNoticeAspFile")]
        public async Task<IActionResult> setNoticeAspFile(string div, IFormFile formFile)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string path = "https://coupon.daeguro.co.kr:45029/event/";

            try
            {
                if (formFile != null && formFile.Length > 0)
                {

                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath)) //이부분 테스트서버에서는 주석막고 밑에 testPest 사용
                    {
                        var dir = (div == "0") ? "img" : "asp";
                        string folerPath = noticeAspPath + "\\" + dir;

                        if (Directory.Exists(folerPath) == false)
                        {
                            Directory.CreateDirectory(folerPath);
                        }


                        folerPath = folerPath + "\\" + formFile.FileName;


                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath);
                        }

                        using var stream = System.IO.File.Create(folerPath);
                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();

                        Rcode = "00";

                        Rmsg = path + dir + "/" + formFile.FileName;
                    }

                }

            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생" + ex.Message;
                await Utils.SaveErrorAsync("/Notice/setNoticeAspFile : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// (팝업연결)공지사항,이벤트 목록 조회
        /// </summary>
        /// <remarks>
        /// 파라미터 <br/>
        /// * 조회종료일자가 지난 게시글 제외처리 <br/>
        /// system_gbn_m : 시스템구분(D: 주문앱, F: 꽃배달)(필수) <br/>
        /// notice_type : 공지타입 (빈값: 전체, 0: 전체공지, 1: 주문앱 공지) <br/>
        /// notice_gbn : 공지/이벤트 구분(1:공지,  3:이벤트) (필수) <br/>
        /// disp_gbn : 게시유무(Y/N) (필수) <br/>
        ///  <br/>
        /// 결과값 <br/>
        /// notice_seq : 공지글 pk값 -> boardseq값<br/>
        /// notice_type : 공지타입 <br/>
        /// notice_gbn : 공지/이벤트 구분 <br/>
        /// notice_title : 제목 <br/>
        /// disp_fr_date : 게시시작일 <br/>
        /// disp_to_date : 게시종료일 <br/>
        /// </remarks>
        [HttpGet("getNoticeList")]
        public async Task<IActionResult> getNoticeList(string system_gbn_m, string notice_type, string notice_gbn, string disp_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<NoticeList> itmes = new List<NoticeList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_NOTICE.GET_CONNECT_NOTICE_LIST",
            };

            cmd.Parameters.Add("in_system_gbn_m", OracleDbType.Varchar2, 1).Value = system_gbn_m;
            cmd.Parameters.Add("in_notice_type", OracleDbType.Varchar2, 1).Value = notice_type;
            cmd.Parameters.Add("in_notice_gbn", OracleDbType.Varchar2, 1).Value = notice_gbn;
            cmd.Parameters.Add("in_disp_gbn", OracleDbType.Varchar2, 1).Value = disp_gbn;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    NoticeList item = new NoticeList
                    {
                        notice_seq = rd["NOTICE_SEQ"].ToString(),
                        notice_type = rd["notice_type"].ToString(),
                        notice_gbn = rd["NOTICE_GBN"].ToString(),
                        notice_title = rd["NOTICE_TITLE"].ToString(),
                        disp_fr_date = rd["DISP_FR_DATE"].ToString(),
                        disp_to_date = rd["DISP_TO_DATE"].ToString(),
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Notice/getNoticeList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }
    }
}
