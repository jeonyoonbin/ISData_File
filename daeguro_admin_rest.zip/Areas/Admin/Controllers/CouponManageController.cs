﻿using Dapper;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class CouponManageController : ControllerBase
    {
        [HttpGet()]
        public async Task<IActionResult> Get(string useGbn)
        {
            List<object> items = new();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("useGbn", useGbn);

            string sqlUseGbn = string.IsNullOrEmpty(useGbn) ? "USE_GBN" : @$"'{useGbn}'";

            // 중복여부(ETC_CODE_GBN7) 값이 null일 경우 임의로 'Y' 값 출력함
            string sql = @$"
                            SELECT CODE_GRP,
                                   CODE,
                                   CODE_NM,
                                   MEMO,
                                   ETC_AMT1,
                                   ETC_AMT2,
                                   ETC_AMT3,
                                   ETC_CODE_GBN4,
                                   ETC_CODE_GBN5,
                                   ETC_CODE_GBN6,
                                   nvl(ETC_CODE_GBN7, 'Y') as ETC_CODE_GBN7,
                                   USE_GBN,
                                   INS_DATE,
                                   INS_UCODE,
                                   INS_NAME,
                                   MOD_DATE,
                                   MOD_UCODE,
                                   MOD_NAME
                              FROM ETC_CODE
                             WHERE CODE_GRP = 'COUPON_TYPE' AND USE_GBN = { sqlUseGbn }
                        ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        [HttpPost]
        public async Task<IActionResult> Post(string code, string codeName, string memo, string amt1, string amt2, string amt3, string value1, string value2, string value3, string value4, string useGbn, string insUCode, string insName)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("code", code);
            param.Add("codeName", codeName);
            param.Add("memo", memo);
            param.Add("amt1", amt1);
            param.Add("amt2", amt2);
            param.Add("amt3", amt3);
            param.Add("value1", value1);
            param.Add("value2", value2);
            param.Add("value3", value3);
            param.Add("value4", value4);
            param.Add("useGbn", useGbn);
            param.Add("insUCode", insUCode);
            param.Add("insName", insName);

            string sql = @$"
                            INSERT INTO ETC_CODE (MCODE,
                                                  PGM_GROUP,
                                                  CODE_GRP,
                                                  CODE,
                                                  CODE_NM,
                                                  MEMO,
                                                  ETC_AMT1,
                                                  ETC_AMT2,
                                                  ETC_AMT3,
                                                  ETC_CODE_GBN4,
                                                  ETC_CODE_GBN5,
                                                  ETC_CODE_GBN6,
                                                  ETC_CODE_GBN7,
                                                  USE_GBN,
                                                  INS_UCODE,
                                                  INS_NAME,
                                                  INS_DATE)
                                 VALUES (0, 'O',
                                         'COUPON_TYPE',
                                         :code,
                                         :codeName,
                                         :memo,
                                         :amt1,
                                         :amt2,
                                         :amt3,
                                         :value1,
                                         :value2,
                                         :value3,
                                         :value4,
                                         :useGbn,
                                         :insUCode,
                                         :insName,
                                         SYSDATE)
                            ";

            string Rmsg;
            string Rcode;
            try
            {
                db.Open();
                await db.ExecuteAsync(sql, param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpPut]
        public async Task<IActionResult> Put(string code, string codeName, string memo, string amt1, string amt2, string amt3, string value1, string value2, string value3, string value4, string useGbn, string modUCode, string modName)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("code", code);
            param.Add("codeName", codeName);
            param.Add("memo", memo);
            param.Add("amt1", amt1);
            param.Add("amt2", amt2);
            param.Add("amt3", amt3);
            param.Add("value1", value1);
            param.Add("value2", value2);
            param.Add("value3", value3);
            param.Add("value4", value4);
            param.Add("useGbn", useGbn);
            param.Add("modUCode", modUCode);
            param.Add("modName", modName);

            string sql = @$"
                            UPDATE ETC_CODE
                               SET CODE_NM = :codeName,
                                   MEMO = :memo,
                                   ETC_AMT1 = :amt1,
                                   ETC_AMT2 = :amt2,
                                   ETC_AMT3 = :amt3,
                                   ETC_CODE_GBN4 = :value1,
                                   ETC_CODE_GBN5 = :value2,
                                   ETC_CODE_GBN6 = :value3,
                                   ETC_CODE_GBN7 = :value4,
                                   USE_GBN = :useGbn,
                                   MOD_UCODE = :modUCode,
                                   MOD_NAME = :modName,
                                   MOD_DATE = SYSDATE
                             WHERE MCODE = 0 AND PGM_GROUP = 'O' AND CODE_GRP = 'COUPON_TYPE' AND CODE = :code                            
                            ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();
                await db.ExecuteAsync(sql, param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpDelete]
        public async Task<IActionResult> Delete(string code)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("code", code);

            string sql = @$"
                            DELETE ETC_CODE WHERE MCODE = 0 AND PGM_GROUP = 'O' AND CODE_GRP = 'COUPON_TYPE' AND CODE = :code                         
                            ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();
                await db.ExecuteAsync(sql, param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
    }
}
