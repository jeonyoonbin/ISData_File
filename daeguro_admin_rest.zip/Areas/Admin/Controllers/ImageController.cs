﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using ImageProcessor;
using ImageProcessor.Imaging.Formats;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ImageController : ControllerBase
    {
        string origianlPath = @"\\10.10.10.100\dgnas\Files\OriginalImage";
        string productPath = @"\\10.10.10.100\dgnas\Files\ProductImage";
        string eventPath = @"\\10.10.10.100\dgnas\Files\EventImage";
        string introPath = @"\\10.10.10.100\dgnas\Files\Intro";
        string testImagePath = @"E:\iis\Files\TestImage";

        string nasPath = @"\\10.10.10.100\dgnas\Files";

        [HttpGet("thumb")]
        public async Task<IActionResult> GetThumbnail(string div, string cccode, string shop_cd, string file_name, int width, int height)
        {
            MemoryStream ms = new MemoryStream();

            string Rdata = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                Image.GetThumbnailImageAbort callback = new Image.GetThumbnailImageAbort(ThumbnailCallback);

                string path = string.Empty;


                if (div.Equals("O"))
                {
                    path = origianlPath + "\\" + cccode + "\\" + shop_cd ;
                }
                else if (div.Equals("E"))
                {
                    path = Utils.serverGbn == "R"? eventPath : testImagePath;
                }
                else
                {
                    path = Utils.serverGbn == "R" ? productPath + "\\" + cccode + "\\" + shop_cd : testImagePath + "\\" + cccode + "\\" + shop_cd ;
                }

                //Rdata = path;

                if (Utils.serverGbn == "R")
                {
                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        //Rdata = path + "\\" + file_name;
                        Image image = new Bitmap(path + "\\" + file_name);
                        Image thumbnail = image.GetThumbnailImage(width, height, callback, new IntPtr());

                        thumbnail.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    }
                }
                else
                {
                    //Rdata = path + "\\" + file_name;
                    Image image = new Bitmap(path + "\\" + file_name);
                    Image thumbnail = image.GetThumbnailImage(width, height, callback, new IntPtr());

                    thumbnail.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                }
                
            }
            catch (Exception ex)
            {
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Image : GetThumbnail", $"Error Msg : {ex.Message}, div : { div }, ccCode : { cccode }, shopCd : { shop_cd }");
            }

            // NAS에 접근 장애가 있을 경우는 아래 주석을 제거 하고 결과를 본다.
            //return Ok(new {data = Rdata, msg = Rmsg });
            return File(ms.ToArray(), "image/jpeg");

        }

        [HttpGet]
        public async Task<IActionResult> Get(int shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<MenuImageList> menuImageList = new List<MenuImageList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_MENU_IMAGE_LIST",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    MenuImageList s = new MenuImageList
                    {
                        menuImageCd = rd["MENU_IMAGE_CD"].ToString(),
                        menuName = rd["MENU_NAME"].ToString(),
                        fileName = rd["FILE_NAME"].ToString(),
                        insertDate = rd["INSERT_DATE"].ToString(),
                    };

                    menuImageList.Add(s);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Image : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = menuImageList });
        }

        [HttpPost]
        public async Task<IActionResult> Post(IFormFile formFile, string div, string cccode, string shop_cd, string menu_name, string salesmanCode, string salesmanName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            string folerPath = string.Empty;
            string fileName = string.Empty;

            if (string.IsNullOrEmpty(salesmanCode) || string.IsNullOrEmpty(salesmanName))
            {
                return Ok(new { code = "99", msg = "수정자 정보가 올바르지 않습니다" });
            }


            try
            {
                if (formFile != null && formFile.Length > 0)
                {
                    // 확장자 가져오기
                    int dotIdx = formFile.FileName.LastIndexOf(".");

                    int extLength = formFile.FileName.Length - dotIdx;

                    string extention = formFile.FileName.Substring(dotIdx, extLength);

                    // 어떤 이미지를 올리는지 구분한다.
                    switch (div)
                    {
                        case "0":   // 메뉴 파일
                            {

                                folerPath = (Utils.serverGbn == "R" ? origianlPath : testImagePath) + "\\" + cccode;
                                fileName = await AddMenuImageAsync(shop_cd, menu_name, salesmanCode, salesmanName);

                                //fileName = "menu.jpg";

                                break;
                            }
                        case "1":   // 사업장 등록증
                            {
                                folerPath = (Utils.serverGbn == "R" ? productPath : testImagePath) + "\\" + cccode;
                                fileName = "buss.jpg";

                                break;
                            }
                        case "2":   // 신분증 사본
                            {
                                folerPath = (Utils.serverGbn == "R" ? productPath : testImagePath) + "\\" + cccode;
                                fileName = "idcard.jpg";
                                break;
                            }
                        case "3":   // 통장 사본
                            {
                                folerPath = (Utils.serverGbn == "R" ? productPath : testImagePath) + "\\" + cccode;
                                fileName = "bank.jpg";
                                break;
                            }
                        case "4":   // 가맹점 대표이미지
                            {
                                //10/12 업데이트 예정
                                //CodeMsg cm = await SetShopImage("c", cccode, shop_cd);

                                //if (cm.code != "00")
                                //{
                                //    return Ok(new { code = cm.code, msg = cm.msg });
                                //}


                                folerPath = (Utils.serverGbn == "R" ? productPath : testImagePath) + "\\" + cccode;
                                fileName = "shop.jpg";
                                break;
                            }
                        default:
                            break;
                    }

                    if(Utils.serverGbn == "R")
                    {
                        // 경로 맨 뒤에 역슬러쉬가 없어야 한다.
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            if (Directory.Exists(folerPath) == false)
                            {
                                Directory.CreateDirectory(folerPath);
                            }


                            folerPath = folerPath + "\\" + shop_cd;


                            if (Directory.Exists(folerPath) == false)
                            {
                                Directory.CreateDirectory(folerPath);
                            }

                            // 파일이 이미 존재하면 삭제한다.
                            if (System.IO.File.Exists(folerPath + "\\" + fileName))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPath + "\\" + fileName);
                            }

                            using var stream = new FileStream(folerPath + "\\" + fileName, FileMode.Create);

                            await formFile.CopyToAsync(stream);

                            stream.Close();
                            stream.Dispose();
                        }
                    }
                    else if(Utils.serverGbn == "T")
                    {
                        if (Directory.Exists(folerPath) == false)
                        {
                            Directory.CreateDirectory(folerPath);
                        }


                        folerPath = folerPath + "\\" + shop_cd;


                        if (Directory.Exists(folerPath) == false)
                        {
                            Directory.CreateDirectory(folerPath);
                        }

                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath + "\\" + fileName))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath + "\\" + fileName);
                        }

                        using var stream = new FileStream(folerPath + "\\" + fileName, FileMode.Create);

                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();
                    }
                    
                    string colName = string.Empty;
                    string memo = string.Empty;

                    switch (fileName)
                    {
                        case "shop.jpg":
                            colName = "SHOP_IMAGE_YN";
                            memo = $"대표이미지 업로드 : 작업자[{salesmanName}, {salesmanCode}]";
                            break;
                        case "buss.jpg":
                            colName = "BUSS_IMAGE_YN"; 
                            memo = $"사업자등록증 업로드 : 작업자[{salesmanName}, {salesmanCode}]";
                            break;
                        case "idcard.jpg":
                            colName = "IDCARD_IMAGE_YN"; 
                            memo = $"영업신고증 업로드 : 작업자[{salesmanName}, {salesmanCode}]";
                            break;
                        case "bank.jpg":
                            colName = "BANK_IMAGE_YN"; 
                            memo = $"통장사본 업로드 : 작업자[{salesmanName}, {salesmanCode}]";
                            break;
                        default:
                            break;
                    }

                    // 메뉴이미지가 아닌 경우
                    if (div != "0")
                    {
                        // SHOP_INFO 테이블에 해당 컬럼 값을 넣어준다.
                        using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                        db.Open();
                        await db.ExecuteAsync($"UPDATE SHOP_INFO SET {colName} = 'Y', MOD_DATETIME = TO_CHAR (SYSTIMESTAMP, 'YYYYMMDDHHMISSFF2'), MOD_UCODE = {salesmanCode}, MOD_NAME = '{salesmanName}' WHERE SHOP_CD = '{shop_cd}'");
                        // 내역 트리거에서 기입
                        //await db.ExecuteAsync($"INSERT INTO SHOP_INFO_HIST(CCCODE, SHOP_CD, SEQNO, HIST_DATE, MEMO) VALUES('{cccode}', '{shop_cd}', SEQ_SHOP_INFO_HIST.NEXTVAL, SYSDATE, '{memo}')");
                        db.Close();
                    }
                    


                    // Jpg 포맷으로 변환한다.

                    //using Image img = Image.FromFile(folerPath + "\\" + formFile.FileName);

                    //img.Save(folerPath + "\\" + fileName, System.Drawing.Imaging.ImageFormat.Jpeg);

                    //img.Dispose();

                    //System.IO.File.Delete(folerPath + "\\" + formFile.FileName);

                }

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = folerPath;
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Image : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        private async Task<CodeMsg> SetShopImage(string div, string cccode, string shop_cd)
        {
            CodeMsg cm = new CodeMsg();


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.SET_SHOP_IMAGE",
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                cm.code = cmd.Parameters["out_code"].Value.ToString();
                cm.msg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();

                
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Image : SetShopImage", ex.Message);
            }

            return cm;
        }

        private async Task<string> AddMenuImageAsync(string shop_cd, string menu_name, string salesmanCode, string salesmanName)
        {

            // 등록된 파일명이 있다면 정보를 가져와서 삭제한다.
            //FileName filename = await GetFileName(shop_cd, kind);

            //if (filename.fileName.Length > 0)
            //{
            //    await DeleteFile(shop_cd, kind, filename.fileName);
            //}

            string RfileName = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.ADD_MENU_IMAGE",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = shop_cd;
            cmd.Parameters.Add("in_menu_name", OracleDbType.Varchar2, 100).Value = menu_name;
            cmd.Parameters.Add("in_salesman_code", OracleDbType.Int32).Value = salesmanCode;
            cmd.Parameters.Add("in_salesman_name", OracleDbType.Varchar2, 50).Value = salesmanName;
            cmd.Parameters.Add("out_file_name", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                RfileName = cmd.Parameters["out_file_name"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Image : AddMenuImageAsync", ex.Message);
            }

            return RfileName;
        }



        private bool ThumbnailCallback()
        {
            return true;
        }




        [HttpPut("removeShopImage/{cccode}/{shop_cd}")]
        public async Task<IActionResult> removeShopImage(string cccode, string shop_cd, string salesmanCode, string salesmanName)
        {
            //10/12 업데이트 예정
            //await SetShopImage("d", cccode, shop_cd);

            //if (string.IsNullOrEmpty(salesmanCode) || string.IsNullOrEmpty(salesmanName))
            //{
            //    return Ok(new { code = "99", msg = "수정자 정보가 올바르지 않습니다" });
            //}

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            string memo = $"대표이미지 삭제 : 작업자[{salesmanName}, {salesmanCode}]";

            try
            {
                // 실제 파일을 삭제한다.
                string fileName = "shop.jpg";

                using (new ConnectToSharedFolder(nasPath))
                {
                    string folerPath = productPath + "\\" + cccode + "\\" + shop_cd;

                    // 파일이 이미 존재하면 삭제한다.
                    if (System.IO.File.Exists(folerPath + "\\" + fileName))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        System.IO.File.Delete(folerPath + "\\" + fileName);
                    }
                }

                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                await db.ExecuteAsync($"UPDATE SHOP_INFO SET SHOP_IMAGE_YN = 'N', MOD_DATETIME = TO_CHAR (SYSTIMESTAMP, 'YYYYMMDDHHMISSFF2'), MOD_UCODE = {salesmanCode}, MOD_NAME = '{salesmanName}' WHERE SHOP_CD = '{shop_cd}'");
                await db.ExecuteAsync($"INSERT INTO SHOP_INFO_HIST(CCCODE, SHOP_CD, SEQNO, HIST_DATE, MEMO) VALUES('{cccode}', '{shop_cd}', SEQ_SHOP_INFO_HIST.NEXTVAL, SYSDATE, '{memo}')");
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpPut]
        public async Task<IActionResult> Put(IFormFile formFile, string menu_cd, string cccode, string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.SET_MENU_FILENAME",
            };

            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = menu_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                if (Rcode.Equals("00") && Utils.serverGbn == "R")
                {
                    string fileName = menu_cd + ".jpg";

                    string folerPath = productPath + "\\" + cccode;

                    using (new ConnectToSharedFolder(nasPath))
                    {
                        DirectoryInfo di = new DirectoryInfo(folerPath);

                        if (di.Exists == false)
                        {
                            di.Create();
                        }

                        folerPath = productPath + "\\" + cccode + "\\" + shop_cd;

                        di = new DirectoryInfo(folerPath);

                        if (di.Exists == false)
                        {
                            di.Create();
                        }

                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath + "\\" + fileName))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath + "\\" + fileName);
                        }

                        //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                        using var stream = new FileStream(folerPath + "\\" + fileName, FileMode.Create);

                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();
                    }

                }
                else if (Rcode.Equals("00") && Utils.serverGbn == "T")
                {
                    string fileName = menu_cd + ".jpg";

                    string folerPath = testImagePath + "\\" + cccode;

                    DirectoryInfo di = new DirectoryInfo(folerPath);

                    if (di.Exists == false)
                    {
                        di.Create();
                    }

                    folerPath = testImagePath + "\\" + cccode + "\\" + shop_cd;

                    di = new DirectoryInfo(folerPath);

                    if (di.Exists == false)
                    {
                        di.Create();
                    }

                    // 파일이 이미 존재하면 삭제한다.
                    if (System.IO.File.Exists(folerPath + "\\" + fileName))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        System.IO.File.Delete(folerPath + "\\" + fileName);
                    }

                    //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                    using var stream = new FileStream(folerPath + "\\" + fileName, FileMode.Create);

                    await formFile.CopyToAsync(stream);

                    stream.Close();
                    stream.Dispose();
                }
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopCalc : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpPut("removeMenuImage")]
        public async Task<IActionResult> removeMenuImage(string menu_cd, string cccode, string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.DELETE_MENU_IMAGE",
            };

            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = menu_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        string fileName = menu_cd + ".jpg";
                        string folerPath = productPath + "\\" + cccode + "\\" + shop_cd;

                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath + "\\" + fileName))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath + "\\" + fileName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopCalc : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpPut("setShopImageInfo")]
        public async Task<IActionResult> setShopImageInfo()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<string> ccshop = new List<string>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            //string shopYn = "Y";
            //string bussYn = "N";
            //string idcardYn = "Y";
            //string bankYn = "N";
            //string shopCd = "8400";

            //db.Open();
            //await db.ExecuteAsync($"UPDATE SHOP_INFO SET SHOP_IMAGE_YN = '{shopYn}', BUSS_IMAGE_YN = '{bussYn}', IDCARD_IMAGE_YN = '{idcardYn}', BANK_IMAGE_YN = '{bankYn}' WHERE SHOP_CD = {shopCd}");
            //Debug.WriteLine($"UPDATE SHOP_INFO SET SHOP_IMAGE_YN = '{shopYn}', BUSS_IMAGE_YN = '{bussYn}', IDCARD_IMAGE_YN = '{idcardYn}', BANK_IMAGE_YN = '{bankYn}' WHERE SHOP_CD = {shopCd}");
            //db.Close();


            // 경로 맨 뒤에 역슬래쉬가 없어야 한다.
            using (new ConnectToSharedFolder(nasPath))
            {
                try
                {
                    var directories = Directory.GetDirectories(productPath).ToList();

                    string shopCd;
                    int iPos, iLength;

                    // 복사할 파일이 존재할 때만 디렉토리를 생성하고 복사를 진행한다.
                    if (directories.Count > 0)
                    {
                        foreach (string dir in directories)
                        {
                            //iPos = dir.LastIndexOf('\\') + 1;

                            //iLength = dir.Length - iPos;

                            //ccCode = dir.Substring(iPos, iLength);

                            var sub_dir = Directory.GetDirectories(dir).ToList();

                            foreach (string s_dir in sub_dir)
                            {
                                iPos = s_dir.LastIndexOf('\\') + 1;

                                iLength = s_dir.Length - iPos;

                                shopCd = s_dir.Substring(iPos, iLength);

                                //Debug.WriteLine("-----------------------------------------");
                                //Debug.WriteLine(s_dir);
                                //Debug.WriteLine("SHOP_CD : " + shopCd);
                                //Debug.WriteLine("-----------------------------------------");

                                ccshop.Add(shopCd);

                                // 이미지가 있는지 확인

                                string shopYn, bussYn, idcardYn, bankYn;

                                // shop.jpg 존재확인.
                                shopYn = System.IO.File.Exists(s_dir + "\\" + "shop.jpg") == true ? "Y" : "N";
                                // buss.jpg 존재확인.
                                bussYn = System.IO.File.Exists(s_dir + "\\" + "buss.jpg") == true ? "Y" : "N";
                                // idcard.jpg 존재확인.
                                idcardYn = System.IO.File.Exists(s_dir + "\\" + "idcard.jpg") == true ? "Y" : "N";
                                // bank.jpg 존재확인.
                                bankYn = System.IO.File.Exists(s_dir + "\\" + "bank.jpg") == true ? "Y" : "N";

                                //DB 적용
                                db.Open();
                                await db.ExecuteAsync($"UPDATE SHOP_INFO SET SHOP_IMAGE_YN = '{shopYn}', BUSS_IMAGE_YN = '{bussYn}', IDCARD_IMAGE_YN = '{idcardYn}', BANK_IMAGE_YN = '{bankYn}'   WHERE SHOP_CD = {shopCd}");
                                //Debug.WriteLine($"UPDATE SHOP_INFO SET SHOP_IMAGE_YN = '{shopYn}', BUSS_IMAGE_YN = '{bussYn}', IDCARD_IMAGE_YN = '{idcardYn}', BANK_IMAGE_YN = '{bankYn}' WHERE SHOP_CD = {shopCd}");
                                db.Close();
                            }
                        }
                    }

                    Rcode = "00";
                    Rmsg = "성공";
                }
                catch (Exception ex)
                {
                    await Utils.SaveErrorAsync("/Image/setShopImageInfo : Put", ex.Message);
                }
            }


            //try
            //{


            //    Rcode = "00";
            //    Rmsg = "성공";
            //}
            //catch (Exception)
            //{
            //    Rcode = "99";
            //    Rmsg = "실패";
            //}

            return Ok(new { code = Rcode, msg = Rmsg, data = ccshop });
        }


        //이미지 변경이력
        [HttpGet("history/{shop_cd}")]
        public async Task<IActionResult> history(string shop_cd, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT *
                                FROM (select ROWNUM as NO, T1.*
                                from(select hist_date, memo from shop_info_hist
                                where shop_cd = :shop_cd
                                and (memo like '%: 등록%' or memo like '%업로드%'
                                or memo like '%대표이미지 삭제%')
                                order by seqno desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2
                                WHERE ((:in_page - 1) * :in_rows) < NO
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = items.Count.ToString(), data = items });
        }

        /// <summary>
        /// 리뷰, 매장 알림이미지 업로드 및 삭제 rest
        /// </summary>
        /// <remarks>
        /// div : I 업로드, D: 삭제 <br/>
        /// image_gbn : I 매장 알림 이미지, R 리뷰알림 이미지 <br />
        /// sort_seq(NVL(MAX(SORT_SEQ), 0) + 1): 각 이미지는 2개까지 업로드 가능 <br />
        /// div,shop_cd,image_gbn / seqno 삭제시에만 추가로 필요 <br />
        /// 오리지날과 썸네일 이미지 생성
        /// </remarks>
        [HttpPost("setShopInfoImage")]
        public async Task<IActionResult> setShopInfoImage(IFormFile formFile, string div, string seqno, string shop_cd, string image_gbn, string ucode, string uname)
        {
            string introPath = @"\\10.10.10.100\dgnas\Files\Intro";
            string nasPath = @"\\10.10.10.100\dgnas\Files";

            //string introPath = @"\sy100";

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            string folerPath = string.Empty;
            string fileName = string.Empty;

            if (string.IsNullOrEmpty(ucode))
            {
                return Ok(new { code = "99", msg = "수정자 정보가 올바르지 않습니다" });
            }


            try
            {
                if (div.Equals("I")) //입력
                {
                    if (formFile != null && formFile.Length > 0)
                    {
                        // 어떤 이미지를 올리는지 구분한다.
                        switch (image_gbn)
                        {
                            case "I":   // 매장 알림 이미지
                                {

                                    folerPath = introPath + "\\" + "ShopImage";
                                    fileName = "Intro" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".jpg";

                                    break;
                                }
                            case "R":   // 리뷰 알림 이미지
                                {
                                    folerPath = introPath + "\\" + "ReviewImage";
                                    fileName = "Intro" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".jpg";

                                    break;
                                }
                            default:
                                break;
                        }

                        string colName = string.Empty;
                        string memo = string.Empty;

                        // SHOP_INFO 테이블에 해당 컬럼 값을 넣어준다.
                        using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                        DynamicParameters param = new DynamicParameters();
                        param.Add("in_shop_cd", shop_cd);
                        param.Add("file_name", fileName);
                        param.Add("in_image_gbn", image_gbn);
                        param.Add("in_ucode", ucode);
                        param.Add("in_uname", uname);

                        db.Open();

                        string sql = @$"
                                    SELECT count(*)
                                        FROM SHOP_INFO_IMAGE
                                        WHERE SHOP_CD = :in_shop_cd
                                        AND IMAGE_GBN = :in_image_gbn
                                    ";

                        int n = await db.ExecuteScalarAsync<int>(sql, param);

                        if (image_gbn.Equals("I") && n >= 2)
                        {
                            return Ok(new { code = "99", msg = "매장알림이미지는 2건까지만 추가할수 있습니다." });
                        }
                        else if (image_gbn.Equals("R") && n >= 2)
                        {
                            return Ok(new { code = "99", msg = "리뷰알림이미지는 2건까지만 추가할수 있습니다." });
                        }

                        sql = @$"
                                    SELECT NVL(MAX(SORT_SEQ), 0) + 1
                                        FROM SHOP_INFO_IMAGE
                                        WHERE SHOP_CD = :in_shop_cd
                                        AND IMAGE_GBN = :in_image_gbn
                                    ";

                        int seq = await db.ExecuteScalarAsync<int>(sql, param);

                        // 경로 맨 뒤에 역슬러쉬가 없어야 한다.
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            if (Directory.Exists(folerPath) == false)
                            {
                                Directory.CreateDirectory(folerPath);
                            }


                            folerPath = folerPath + "\\" + shop_cd;


                            if (Directory.Exists(folerPath) == false)
                            {
                                Directory.CreateDirectory(folerPath);
                            }

                            //썸네일 폴더
                            if (Directory.Exists(folerPath + "\\Thumb") == false)
                            {
                                Directory.CreateDirectory(folerPath + "\\Thumb");
                            }

                            // 파일이 이미 존재하면 삭제한다.
                            if (System.IO.File.Exists(folerPath + "\\" + fileName))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPath + "\\" + fileName);
                            }

                            //using var stream = new FileStream(folerPath + "\\" + fileName, FileMode.Create);

                            //await formFile.CopyToAsync(stream);

                            //stream.Close();
                            //stream.Dispose();

                            //누겟 imageProcessor 필요
                            using (ImageFactory imageFactory = new ImageFactory(preserveExifData: true))
                            {
                                var ima = imageFactory.Load(formFile.OpenReadStream()).Image;
                                int isizeW = 1280;
                                int isizeH = 720;
                                int quality = 100;

                                //오리지널 저장(w:1280/h:720/q:100)
                                if (ima.Width > ima.Height)
                                {
                                    if (ima.Width < 1280)
                                    {
                                        isizeW = ima.Width;
                                    }

                                    var ratio = (float)ima.Height / ima.Width;

                                    imageFactory.Load(formFile.OpenReadStream())
                                        .Format(new JpegFormat())
                                        .Resize(new Size(isizeW, (int)(isizeW * ratio)))
                                        .Quality(quality)
                                        .Save(folerPath + "\\" + fileName)
                                        .Quality(72)
                                        .Save(folerPath + "\\Thumb\\" + fileName);
                                }
                                else
                                {
                                    if (ima.Height < 720)
                                    {
                                        isizeH = ima.Height;
                                    }

                                    var ratio = (float)ima.Width / ima.Height;

                                    imageFactory.Load(formFile.OpenReadStream())
                                        .Format(new JpegFormat())
                                        .Resize(new Size((int)(isizeH * ratio), isizeH))
                                        .Quality(quality)
                                        .Save(folerPath + "\\" + fileName)
                                        .Quality(72)
                                        .Save(folerPath + "\\Thumb\\" + fileName);
                                }

                            }
                        }


                        sql = $@"
                            insert into shop_info_image(SHOP_CD, IMAGE_GBN, FILE_NAME, SORT_SEQ, INS_DATE, INS_UCODE, INS_NAME)
                            values(:in_shop_cd, :in_image_gbn, :file_name, {seq}, SYSDATE, :in_ucode, :in_uname)
                            ";

                        await db.ExecuteAsync(sql, param);

                        db.Close();

                    }
                    else
                    {
                        return Ok(new { code = "99", msg = "업로드할 이미지가 없습니다" });
                    }
                }
                else if (div.Equals("D")) //삭제
                {
                    if (string.IsNullOrEmpty(seqno))
                    {
                        return Ok(new { code = "99", msg = "시퀸스번호가 없습니다" });
                    }

                    string memo = string.Empty;

                    if (image_gbn.Equals("I"))
                    {
                        folerPath = introPath + "\\" + "ShopImage" + "\\" + shop_cd;
                        memo = "[사장님 매장 알림 이미지 삭제] ";
                    }
                    else if (image_gbn.Equals("R"))
                    {
                        folerPath = introPath + "\\" + "ReviewImage" + "\\" + shop_cd;
                        memo = "[사장님 리뷰 알림 이미지 삭제] ";
                    }


                    using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                    DynamicParameters param = new DynamicParameters();
                    param.Add("in_seqno", seqno);
                    param.Add("shop_cd", shop_cd);

                    db.Open();

                    string sql = @$"
                                    SELECT FILE_NAME  
                                      FROM SHOP_INFO_IMAGE
                                     WHERE SEQ = :in_seqno
                                    ";

                    fileName = await db.ExecuteScalarAsync<string>(sql, param);

                    memo = memo + "SEQ : " + seqno + ", 이미지 URL : " + fileName + "[수정자: " + uname +"(" + ucode + ")]";
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        //파일 삭제
                        if (System.IO.File.Exists(folerPath + "\\" + fileName))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath + "\\" + fileName);
                            //썸네일 삭제
                            if (System.IO.File.Exists(folerPath + "\\Thumb\\" + fileName))
                            {
                                System.IO.File.Delete(folerPath + "\\Thumb\\" + fileName);
                            }

                        }
                        else
                        {
                            //return Ok(new { code = "99", msg = "삭제할 파일이 존재하지 않습니다 (" + folerPath + "\\" + fileName + ")" });
                        }
                    }

                    //테이블에서 항목 삭제
                    sql = $@"
                            DELETE FROM SHOP_INFO_IMAGE
                            WHERE SEQ = :in_seqno
                            ";

                    await db.ExecuteAsync(sql, param);

                    //shop_info_hist에 삭제로그 남기기
                    sql = @$"
                                SELECT CCCODE
                                FROM SHOP_INFO
                                WHERE SHOP_CD = :shop_cd
                            ";

                    string cccode = await db.ExecuteScalarAsync<string>(sql, param);

                    param.Add("cccode", cccode);
                    param.Add("memo", memo);

                    sql = $@"
                            insert into shop_info_hist(seqno, cccode, shop_cd, hist_date, memo)
                            values(SEQ_SHOP_INFO_HIST.NEXTVAL,:cccode, :shop_cd, sysdate, :memo)
                            ";

                    await db.ExecuteAsync(sql, param);

                    db.Close();
                }


                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = folerPath;
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Image/setShopInfoImage : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }
  


        /// <summary>
        /// 리뷰, 매장 알림이미지 조회 rest
        /// </summary>
        /// <remarks>
        /// image_gbn : I 매장 알림 이미지, R 리뷰알림 이미지 <br />
        /// <br />
        /// seq: PK <br/>
        /// file_name:(원본) Intro + 업로드시간 + .jpg <br/>
        /// (썸네일) Thumb\\{file_name} <br/>
        /// ex)매장알림 이미지 "https://admin.daeguro.co.kr/intro-images/ShopImage/{shop_cd}/Thumb/{file_name}" <br />
        /// ex)리뷰알림 이미지 "https://admin.daeguro.co.kr/intro-images/ReviewImage/{shop_cd}/Thumb/{file_name}" <br />
        /// sort_seq: 정렬순서 각 이미지는 2개까지 업로드 가능(오름차순)
        /// </remarks>
        [HttpGet("getShopInfoImage")]
        public async Task<IActionResult> getShopInfoImage(string shop_cd, string image_gbn)
        {

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_shop_cd", shop_cd);
            param.Add("IN_image_gbn", image_gbn);

            string sql = @$"
                            SELECT to_char(SEQ) seq, FILE_NAME, to_char(SORT_SEQ) sort_seq
                            FROM SHOP_INFO_IMAGE
                            WHERE SHOP_CD = :in_shop_cd
                            AND IMAGE_GBN = :in_image_gbn
                            ORDER BY SORT_SEQ
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Image/getShopInfoImage : Get", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 이미지 업데이트
        /// </summary>
        [HttpPut("updateImg")]
        public async Task<IActionResult> updateImg(string url, IFormFile formFile)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            if (string.IsNullOrEmpty(url))
            {
                Rcode = "99";
                Rmsg = "url은 필수입니다.";

                return Ok(new { code = Rcode, msg = Rmsg });
            }

            if (formFile != null && formFile.Length > 0)
            {

                using (new ConnectToSharedFolder(nasPath))
                {
                    // 파일이 이미 존재하면 삭제한다.
                    if (System.IO.File.Exists(url))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        System.IO.File.Delete(url);
                    }
                    else
                    {
                        Rcode = "99";
                        Rmsg = "해당 파일이 존재하지 않습니다.";
                        return Ok(new { code = Rcode, msg = Rmsg });
                    }

                    using var stream = new FileStream(url, FileMode.Create);

                    await formFile.CopyToAsync(stream);

                    stream.Close();
                    stream.Dispose();
                }
            }
            else
            {
                Rcode = "99";
                Rmsg = "파일은 필수입니다.";

                return Ok(new { code = Rcode, msg = Rmsg });
            }

            Rcode = "00";
            Rmsg = "성공";

            return Ok(new { code = Rcode, msg = Rmsg });

        }

        //private async Task<FileName> GetFileName(string shop_cd, string kind)
        //{
        //    FileName filename = new FileName();

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
        //    OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_SHOP.GET_SHOP_FILE",
        //    };

        //    cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
        //    cmd.Parameters.Add("in_kind", OracleDbType.Varchar2, 2).Value = kind;
        //    cmd.Parameters.Add("out_file_name", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();
        //        await cmd.ExecuteNonQueryAsync();

        //        filename.fileName = cmd.Parameters["out_file_name"].Value.ToString();
        //        filename.code = cmd.Parameters["out_code"].Value.ToString();
        //        filename.msg = cmd.Parameters["out_msg"].Value.ToString();

        //        await conn.CloseAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        Utils.SaveError("/admin/Shop/getFileName : SetShopFile", ex.Message);
        //    }

        //    return filename;
        //}

        //private async Task<IActionResult> DeleteFile(string shop_cd, string kind, string file_name)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_SHOP.DELETE_SHOP_FILE",
        //    };

        //    cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 50).Value = shop_cd;
        //    cmd.Parameters.Add("in_kind", OracleDbType.Varchar2, 50).Value = kind;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();

        //        var rd = await cmd.ExecuteReaderAsync();

        //        Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        await rd.CloseAsync();
        //        await conn.CloseAsync();

        //        if (Rcode.Equals("00"))
        //        {
        //            System.IO.File.Delete(origianlPath + file_name);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Utils.SaveError("/admin/Shop/DeleteFile : Post", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}
    }
}
