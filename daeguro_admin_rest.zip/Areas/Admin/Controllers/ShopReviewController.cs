﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ShopReviewController : ControllerBase
    {
        string productPath = @"\\10.10.10.100\dgnas\Files\ProductImage";
        string reviewImageOPath = @"\\10.10.10.100\dgnas\Files\ReviewImage/Original";
        string reviewImageTPath = @"\\10.10.10.100\dgnas\Files\ReviewImage/Thumbnail";
        string nasPath = @"\\10.10.10.100\dgnas\Files";

        /// <summary>
        /// 리뷰관리 목록조회
        /// </summary>
        /// <remarks>
        /// tab 구분/ 1: 사장님 블라인드 요청건, 2: 전체 <br/>
        /// service_gbn : 서비스 구분(빈값 : 전체, 0 : 주문, 1 : 특별관, 2 : 꽃배달, 3 : 로컬푸드, 4 : 전통시장, 5 : 전자관) <br />
        /// status 처리상태/ 0: 전체, 1: 요청, 2: 완료, 3: 보완 <br/>
        /// ord 정렬순서/ 1: 등록일자순, 2: 신고많은순 <br/>
        /// divKey 검색조건/ 1: 리뷰내용, 2: 고객전화번호, 3: 가맹점명, 4: 주문번호, 5: 상점코드
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string mcode, string service_gbn, string tab, string status, string ord, string divKey, string keyword, string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RCount = string.Empty;
            string RTotal = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("mcode", mcode);
                param.Add("service_gbn", service_gbn);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("tab", tab);
                param.Add("div_key", divKey);
                param.Add("status", status);
                param.Add("ord", ord);
                keyword = string.IsNullOrEmpty(keyword) ? keyword : "%" + keyword + "%";
                param.Add("keyword", keyword);
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = @$"
                              SELECT t2.shop_cd, t2.shop_name, t2.service_gbn, t2.order_seqno, t2.bliend_type, t2.bliend_agree_gbn, 
                                    case when t2.bliend_type = 'R' then 'R' else t2.visble_gbn end  visble_gbn, 
                                    t2.star_rating, t2.cust_code, t2.telno, t2.cust_name, t2.report_count,
                                   t2.content, t2.insert_date, t2.blind_req_dt, t2.ANSWER_TEXT, t2.IMAGE_YN, t2.memo, t2.status
                              FROM (SELECT ROWNUM AS RNUM,
                                           t1.*
                                    FROM (select t.* from  (select /*+leading(A) full(A)*/ c.shop_cd, c.shop_name, c.service_gbn, a.order_seqno, a.bliend_type, a.bliend_agree_gbn, 
                                                   a.visble_gbn, a.star_rating, a.cust_code, e.telno, e.cust_name, nvl(b.report_count, 0) report_count,
                                                   substr(a.content_text,1,15) || replace(substr(a.content_text,15,1), substr(a.content_text,15,1), '...') as content, 
                                                   a.insert_date, a.blind_req_dt, a.ANSWER_TEXT,
                                                   case when a.file_img_1 is null AND a.file_img_2 is null AND a.file_img_3 is null then 'N' else 'Y' end as IMAGE_YN,
                                                   a.memo,
                                                   (CASE WHEN a.VISBLE_GBN = 'B' AND a.BLIEND_TYPE = 'R' AND a.ANSWER_TEXT IS NULL THEN '요청'
                                                       WHEN a.VISBLE_GBN = 'B' AND a.BLIEND_TYPE <> 'R' THEN '완료' 
                                                       WHEN a.ANSWER_TEXT IS NOT NULL AND LENGTH(TRIM(a.ANSWER_TEXT)) > 0 THEN '보완'
                                                       else '일반' END) as status
                                            from app_review a, (select review_seqno, count(review_seqno) as report_count from app_review_report group by review_seqno order by report_count desc) b, shop_info c, callcenter d, 
                                            (select telno, cust_code, cust_name from app_customer union all  select telno, cust_code, cust_name from app_customer_deleted) e
                                            where a.order_seqno = b.review_seqno (+)
                                            and a.SHOP_CD = c.SHOP_CD
                                            and c.cccode = d.cccode
                                            and c.service_gbn like case when :service_gbn is null then '%' else :service_gbn end
                                            and a.cust_code = e.cust_code
                                            and d.mcode = :mcode
                                            and :tab = 1
                                            and a.blind_req_dt is not null
                                            and a.blind_req_dt between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            and case when :keyword is not null then 
                                                    case when :div_key = 1 then a.content_text
                                                    when :div_key = 2 then e.telno
                                                    when :div_key = 3 then c.shop_name
                                                    when :div_key = 4 then to_char(a.order_seqno)
                                                    when :div_key = 5 then a.shop_cd end
                                            else '%' end like nvl(:keyword,'%')
                                            group by c.shop_cd, c.shop_name, c.service_gbn, a.order_seqno,a.bliend_type, a.bliend_agree_gbn, a.visble_gbn, a.star_rating, a.cust_code, e.telno, e.cust_name, nvl(b.report_count, 0),
                                                   substr(a.content_text,1,15) || replace(substr(a.content_text,15,1), substr(a.content_text,15,1), '...'), a.insert_date, a.blind_req_dt, a.ANSWER_TEXT,
                                                   case when a.file_img_1 is null AND a.file_img_2 is null AND a.file_img_3 is null then 'N' else 'Y' end, a.memo
                                           union all
                                           select/*+leading(A) full(A)*/  c.shop_cd, c.shop_name, c.service_gbn, a.order_seqno, a.bliend_type, a.bliend_agree_gbn, 
                                                   a.visble_gbn, a.star_rating, a.cust_code, e.telno, e.cust_name, nvl(b.report_count, 0) report_count,
                                                   substr(a.content_text,1,15) || replace(substr(a.content_text,15,1), substr(a.content_text,15,1), '...') as content, 
                                                   a.insert_date, a.blind_req_dt, a.ANSWER_TEXT,
                                                   case when a.file_img_1 is null AND a.file_img_2 is null AND a.file_img_3 is null then 'N' else 'Y' end as IMAGE_YN,
                                                   a.memo,
                                                   (CASE WHEN a.VISBLE_GBN = 'B' AND a.BLIEND_TYPE = 'R' AND a.ANSWER_TEXT IS NULL THEN '요청'
                                                       WHEN a.VISBLE_GBN = 'B' AND a.BLIEND_TYPE <> 'R' THEN '완료' 
                                                       WHEN a.ANSWER_TEXT IS NOT NULL AND LENGTH(TRIM(a.ANSWER_TEXT)) > 0 THEN '보완'
                                                       else '일반' END) as status
                                            from app_review a, (select review_seqno, count(review_seqno) as report_count from app_review_report group by review_seqno order by report_count desc) b, shop_info c, callcenter d, 
                                            (select telno, cust_code, cust_name from app_customer union all  select telno, cust_code, cust_name from app_customer_deleted) e
                                            where a.order_seqno = b.review_seqno (+)
                                            and a.SHOP_CD = c.SHOP_CD
                                            and c.cccode = d.cccode
                                            and c.service_gbn like case when :service_gbn is null then '%' else :service_gbn end
                                            and a.cust_code = e.cust_code
                                            and d.mcode = :mcode
                                            and nvl(:tab,2) = 2
                                            and a.insert_date between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            and case when :keyword is not null then 
                                                    case when :div_key = 1 then a.content_text
                                                    when :div_key = 2 then e.telno
                                                    when :div_key = 3 then c.shop_name
                                                    when :div_key = 4 then to_char(a.order_seqno)
                                                    when :div_key = 5 then a.shop_cd end
                                            else '%' end like nvl(:keyword,'%')
                                            group by c.shop_cd, c.shop_name, c.service_gbn, a.order_seqno,a.bliend_type, a.bliend_agree_gbn, a.visble_gbn, a.star_rating, a.cust_code, e.telno, e.cust_name, nvl(b.report_count, 0),
                                                   substr(a.content_text,1,15) || replace(substr(a.content_text,15,1), substr(a.content_text,15,1), '...'), a.insert_date, a.blind_req_dt, a.ANSWER_TEXT,
                                                   case when a.file_img_1 is null AND a.file_img_2 is null AND a.file_img_3 is null then 'N' else 'Y' end, a.memo) t
                            WHERE t.status like case when :status = '0' then '%'
                                                      when :status = '1' then '요청'
                                                      when :status = '2' then '완료'
                                                      when :status = '3' then '보완'
                                                      else '%' end
                          order by case when :ord = 1 then to_number(to_char(t.insert_date,'YYYYMMDDHH24MISS'))
                                          when :ord = 2 then t.report_count end desc) t1
                            where ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                            WHERE (( :page - 1) * :row_count) < RNUM
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                var totalSql = @"
                                    select count(*) from(select a.order_seqno
                                    from app_review a, shop_info c, callcenter d,
                                    (select telno, cust_code from app_customer union all  select telno, cust_code from app_customer_deleted) e
                                    where a.SHOP_CD = c.SHOP_CD
                                    and c.cccode = d.cccode
                                    and a.cust_code = e.cust_code
                                    and d.mcode = :mcode
                                    and :tab = 1
                                    and a.blind_req_dt is not null
                                    union all
                                    select a.order_seqno
                                    from app_review a, shop_info c, callcenter d,
                                    (select telno, cust_code from app_customer union all  select telno, cust_code from app_customer_deleted) e
                                    where a.SHOP_CD = c.SHOP_CD
                                    and c.cccode = d.cccode
                                    and a.cust_code = e.cust_code
                                    and d.mcode = :mcode
                                    and :tab = 2)
                                ";
                //var total = await db.ExecuteScalarAsync<Int64>(totalSql, param, commandType: CommandType.Text);
                //RTotal = total.ToString();
                RTotal = "0";

                var countSql = @"
                                    SELECT count(*)
                                    FROM (  select /*+leading(A) full(A)*/ c.shop_cd, c.shop_name, a.order_seqno, a.bliend_type, a.bliend_agree_gbn, 
                                                   a.visble_gbn, a.star_rating, a.cust_code, e.telno, e.cust_name, nvl(b.report_count, 0) report_count,
                                                   substr(a.content_text,1,15) || replace(substr(a.content_text,15,1), substr(a.content_text,15,1), '...') as content, 
                                                   a.insert_date, a.blind_req_dt, a.ANSWER_TEXT,
                                                   case when a.file_img_1 is null AND a.file_img_2 is null AND a.file_img_3 is null then 'N' else 'Y' end as IMAGE_YN,
                                                   a.memo,
                                                   (CASE WHEN a.VISBLE_GBN = 'B' AND a.BLIEND_TYPE = 'R' AND a.ANSWER_TEXT IS NULL THEN '요청'
                                                       WHEN a.VISBLE_GBN = 'B' AND a.BLIEND_TYPE <> 'R' THEN '완료' 
                                                       WHEN a.ANSWER_TEXT IS NOT NULL AND LENGTH(TRIM(a.ANSWER_TEXT)) > 0 THEN '보완'
                                                       else '일반' END) as status
                                            from app_review a, (select review_seqno, count(review_seqno) as report_count from app_review_report group by review_seqno order by report_count desc) b, shop_info c, callcenter d, 
                                            (select telno, cust_code, cust_name from app_customer union all  select telno, cust_code, cust_name from app_customer_deleted) e
                                            where a.order_seqno = b.review_seqno (+)
                                            and a.SHOP_CD = c.SHOP_CD
                                            and c.cccode = d.cccode
                                            and c.service_gbn like case when :service_gbn is null then '%' else :service_gbn end
                                            and a.cust_code = e.cust_code
                                            and d.mcode = :mcode
                                            and :tab = 1
                                            and a.blind_req_dt is not null
                                            and a.blind_req_dt between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            and case when :keyword is not null then 
                                                    case when :div_key = 1 then a.content_text
                                                    when :div_key = 2 then e.telno
                                                    when :div_key = 3 then c.shop_name
                                                    when :div_key = 4 then to_char(a.order_seqno)
                                                    when :div_key = 5 then a.shop_cd end
                                            else '%' end like nvl(:keyword,'%')
                                            group by c.shop_cd, c.shop_name, a.order_seqno,a.bliend_type, a.bliend_agree_gbn, a.visble_gbn, a.star_rating, a.cust_code, e.telno, e.cust_name, nvl(b.report_count, 0),
                                                   substr(a.content_text,1,15) || replace(substr(a.content_text,15,1), substr(a.content_text,15,1), '...'), a.insert_date, a.blind_req_dt, a.ANSWER_TEXT,
                                                   case when a.file_img_1 is null AND a.file_img_2 is null AND a.file_img_3 is null then 'N' else 'Y' end, a.memo
                                           union all
                                           select /*+leading(A) full(A)*/ c.shop_cd, c.shop_name, a.order_seqno, a.bliend_type, a.bliend_agree_gbn, 
                                                   a.visble_gbn, a.star_rating, a.cust_code, e.telno, e.cust_name, nvl(b.report_count, 0) report_count,
                                                   substr(a.content_text,1,15) || replace(substr(a.content_text,15,1), substr(a.content_text,15,1), '...') as content, 
                                                   a.insert_date, a.blind_req_dt, a.ANSWER_TEXT,
                                                   case when a.file_img_1 is null AND a.file_img_2 is null AND a.file_img_3 is null then 'N' else 'Y' end as IMAGE_YN,
                                                   a.memo,
                                                   (CASE WHEN a.VISBLE_GBN = 'B' AND a.BLIEND_TYPE = 'R' AND a.ANSWER_TEXT IS NULL THEN '요청'
                                                       WHEN a.VISBLE_GBN = 'B' AND a.BLIEND_TYPE <> 'R' THEN '완료' 
                                                       WHEN a.ANSWER_TEXT IS NOT NULL AND LENGTH(TRIM(a.ANSWER_TEXT)) > 0 THEN '보완'
                                                       else '일반' END) as status
                                            from app_review a, (select review_seqno, count(review_seqno) as report_count from app_review_report group by review_seqno order by report_count desc) b, shop_info c, callcenter d, 
                                            (select telno, cust_code, cust_name from app_customer union all  select telno, cust_code, cust_name from app_customer_deleted) e
                                            where a.order_seqno = b.review_seqno (+)
                                            and a.SHOP_CD = c.SHOP_CD
                                            and c.cccode = d.cccode
                                            and c.service_gbn like case when :service_gbn is null then '%' else :service_gbn end
                                            and a.cust_code = e.cust_code
                                            and d.mcode = :mcode
                                            and nvl(:tab,2) = 2
                                            and a.insert_date between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            and case when :keyword is not null then 
                                                    case when :div_key = 1 then a.content_text
                                                    when :div_key = 2 then e.telno
                                                    when :div_key = 3 then c.shop_name
                                                    when :div_key = 4 then to_char(a.order_seqno)
                                                    when :div_key = 5 then a.shop_cd end
                                            else '%' end like nvl(:keyword,'%')
                                            group by c.shop_cd, c.shop_name, a.order_seqno,a.bliend_type, a.bliend_agree_gbn, a.visble_gbn, a.star_rating, a.cust_code, e.telno, e.cust_name, nvl(b.report_count, 0),
                                                   substr(a.content_text,1,15) || replace(substr(a.content_text,15,1), substr(a.content_text,15,1), '...'), a.insert_date, a.blind_req_dt, a.ANSWER_TEXT,
                                                   case when a.file_img_1 is null AND a.file_img_2 is null AND a.file_img_3 is null then 'N' else 'Y' end, a.memo) t1
                            WHERE t1.status like case when :status = '0' then '%'
                                                      when :status = '1' then '요청'
                                                      when :status = '2' then '완료'
                                                      when :status = '3' then '보완'
                                                      else '%' end
                                    ";

                var count = await db.ExecuteScalarAsync<Int64>(countSql, param, commandType: CommandType.Text);
                RCount = count.ToString();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopReview : Get", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, total_count = RTotal, count = RCount, data = items });
        }


        // 리뷰 한건 조회
        [HttpGet("{seqno}")]
        public async Task<IActionResult> Get(string seqno, string ucode)
        {
            string Rposition = "/ShopReview/{seqno} : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object items = string.Empty;

            string name = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("seqno", seqno);

                param.Add("in_ucode", ucode);

                string sql = @"
                                select a.cust_code, c.cust_name, a.bliend_type, a.bliend_agree_gbn, a.visble_gbn, a.content_text, a.file_img_1, a.file_img_2, a.file_img_3, 
                                       a.blind_req_dt, a.blind_stand_dt, a.blind_end_dt, b.code_nm, a.bliend_reason, a.answer_text, a.memo, alloc_ucode, alloc_uname
                                from app_review a, (select * from etc_code where CODE_GRP = 'BLIEND_TYPE') b,
                                (select cust_name, cust_code from app_customer union all  select cust_name, cust_code from app_customer_deleted) c
                                where a.bliend_code = b.code (+)
                                and a.cust_code = c.cust_code
                                and a.order_seqno = :seqno
                ";

                items = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);
                
                var data = items as IReadOnlyDictionary<string, object>;

                db.Close();

                //조회 로그 기록
                await Utils.setPrivacyLog(ucode, "35", "10", data["CUST_NAME"] + " - 이름, 전화번호", Rposition);

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        // 리뷰 블라인드 처리 
        [HttpPut("setVisible/{seqno}")]
        public async Task<IActionResult> setVisible(string seqno, string visible, string ucode, string uname)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object items = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("seqno", seqno);
                param.Add("ucode", ucode);
                param.Add("uname", uname);

                if (visible == "B")
                {
                    param.Add("visible", "블라인드 처리");
                } else if (visible == "A")
                {
                    param.Add("visible", "전체공개 처리");
                }
                else
                {
                    Rcode = "99";
                    Rmsg = "변경할수 없는 상태입니다";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }


                string sql = string.Empty;

                string type = string.Empty;

                if (visible == "B")
                {
                    sql = @"
                            select bliend_type from app_review where order_seqno = :seqno
                    ";

                    type = await db.QuerySingleAsync<string>(sql, param, commandType: CommandType.Text);

                    sql = @$"
                            update app_review
                            set alloc_ucode = :ucode,
                                alloc_uname = :uname,
                                visble_gbn = 'B',
                                bliend_type = case when '{type}' = 'R' then 'S' else 'A' end,
                                blind_stand_dt = sysdate,
                                blind_end_dt = sysdate + (365 * 50)
                            where order_seqno = :seqno
                    ";
                } 
                else if(visible == "A")
                {
                    sql = @"
                            update app_review
                            set alloc_ucode = :ucode,
                                alloc_uname = :uname,
                                visble_gbn = 'A',
                                bliend_type = null,
                                blind_req_dt = null,
                                blind_stand_dt = null,
                                blind_end_dt = null
                            where order_seqno = :seqno
                    ";
                }

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                sql = @"
                            insert into app_review_hist(hist_date, memo, mod_ucode, order_seqno)
                            values(sysdate, '공개구분: ' || :visible, :ucode, :seqno)
                        ";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);


                //별점평균 갱신
                sql = @" select distinct shop_cd from app_review where order_seqno = :seqno ";
                string shop = await db.QuerySingleAsync<string>(sql, param, commandType: CommandType.Text);
                Object result = await setReviewStats(shop);


                db.Close();

                Rcode = "00";
                Rmsg = "성공" + result.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopReview/setVisible/{seqno} : Put", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg});
        }

        [HttpPut]
        private async Task<IActionResult> setReviewStats(string shopCd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "SP_SET_REVIEW_STATS",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shopCd;

            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Review/setReviewStats : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 리뷰 답변 작성 및 메모
        /// </summary>
        /// <remarks>
        /// 리뷰 답변 작성 및 메모 <br />
        /// 수정자 기록
        /// </remarks>
        [HttpPut("{seqno}")]
        public async Task<IActionResult> Put(string seqno, string answerText, string memo, string ucode, string uname)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object items = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("seqno", seqno);
                param.Add("answer_text", answerText);
                param.Add("memo", memo);
                param.Add("ucode", ucode);
                param.Add("uname", uname);

                string sql = @"
                                update app_review
                                set mod_ucode = :ucode,
                                 mod_name = :uname,
                                 mod_date = SYSDATE,
                                 answer_text = :answer_text,
                                 memo = :memo
                                where order_seqno = :seqno
                ";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                sql = @"
                            insert into app_review_hist(hist_date, memo, mod_ucode, order_seqno)
                            values(sysdate, '답변: ' || :answer_text || ', 메모: ' || :memo , :ucode, :seqno)
                        ";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopReview/{seqno} : Put", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }



        // 신고내역 조회
        [HttpGet("getReportList/{seqno}")]
        public async Task<IActionResult> getReportList(string seqno, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RCount = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("seqno", seqno);
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = @"
                                SELECT aa.cust_code, aa.cust_name, t2.*
                              FROM (SELECT ROWNUM AS RNUM,
                                           t1.*
                                    FROM (  select  * from app_review_report  
                                            where review_seqno = :seqno
                                            order by insert_date desc, use_yn desc) t1
                            WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2, 
                            (select cust_code, cust_name from app_customer union all  select cust_code, cust_name from app_customer_deleted) aa
                            WHERE t2.cust_code = aa.cust_code 
                            and (( :page - 1) * :row_count) < RNUM
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                var countSql = @"
                                    select  count(*) from app_review_report  
                                    where review_seqno = :seqno
                                    ";

                var count = await db.ExecuteScalarAsync<Int64>(countSql, param, commandType: CommandType.Text);
                RCount = count.ToString();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopReview/getReport/{seqno} : Get", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
        }

        /// <summary>
        /// 리뷰관리 변경이력
        /// </summary>
        /// <remarks>
        /// 블라인드상태 변경, 메모, 담당자 답변 변경시 rest에서 기록.
        /// </remarks>
        [HttpGet("history/{seqno}")]
        public async Task<IActionResult> history(string seqno, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("seqno", seqno);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT t2.*, u.user_name
                                FROM (select to_char(ROWNUM) as NO, T1.*
                                from(select hist_date, memo, to_char(mod_ucode) as mod_ucode from app_review_hist
                                where order_seqno = :seqno
                                order by hist_date desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2, 
                                (select ucode, user_name from users union all select cust_code, cust_name from app_customer) u
                                WHERE ((:in_page - 1) * :in_rows) < NO
                                and t2.mod_ucode = u.ucode
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = items.Count.ToString(), data = items });
        }




        //리뷰 이동
        [HttpPut("moveReview")]
        public async Task<IActionResult> moveReview(string from_shop_cd, string to_shop_cd, string ucode, string uname)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.MOVE_REVIEW",
            };

            cmd.Parameters.Add("in_from_shop_cd", OracleDbType.Varchar2, 20).Value = from_shop_cd;
            cmd.Parameters.Add("in_to_shop_cd", OracleDbType.Varchar2, 20).Value = to_shop_cd;
            cmd.Parameters.Add("in_ucode", OracleDbType.Varchar2, 20).Value = ucode;
            cmd.Parameters.Add("in_uname", OracleDbType.Varchar2, 20).Value = uname;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;


            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();

                #region  파일 복사
                if (Rcode.Equals("00"))
                {
                    // 경로 맨 뒤에 역슬래쉬가 없어야 한다.
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        string[] arr = { reviewImageOPath, reviewImageTPath };
                        foreach (string path in arr)
                        {
                            // 소스 이미지 경로
                            string sourcePath = $@"{path}\{from_shop_cd}";
                            string destPath = $@"{path}\{to_shop_cd}";

                            if (Directory.Exists(sourcePath))
                            {
                                var file_Files = Directory.GetFiles(sourcePath, "*.*").ToList();

                                // 복사할 파일이 존재할 때만 디렉토리를 생성하고 복사를 진행한다.
                                if (file_Files.Count > 0)
                                {
                                    if (Directory.Exists(destPath) == false)
                                    {
                                        Directory.CreateDirectory(destPath);
                                    }

                                    foreach (string list_file in file_Files)
                                    {
                                        int iPos = list_file.LastIndexOf(@"\");
                                        string file_name = list_file.Substring(iPos + 1, list_file.Length - (iPos + 1));

                                        try
                                        {
                                            // 파일이 이미 존재하면 삭제한다.
                                            if (System.IO.File.Exists($@"{destPath}\{file_name}"))
                                            {
                                                System.GC.Collect();
                                                System.GC.WaitForPendingFinalizers();
                                                System.IO.File.Delete($@"{destPath}\{file_name}");
                                            }

                                            System.IO.File.Copy(list_file, $@"{destPath}\{file_name}");
                                        }
                                        catch (Exception ex)
                                        {
                                            await Utils.SaveErrorAsync("/ShopReview/moveReview : Put - 파일존재 확인 후 카피부분", ex.Message + " " + path);
                                        }
                                    }
                                }
                            }
                        }
                        
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopReview/moveReview : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


    }

}
