﻿using Dapper;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [SwaggerTag("모바일 관리앱 메뉴 관리")]
    [ApiController]
    public class MobileAdminMenuController : ControllerBase
    {
        /// <summary>
        /// 메뉴 조회
        /// </summary>
        [HttpGet()]
        public async Task<IActionResult> Get(string menudepth, string id)
        {
            List<object> items = new();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_menudepth", menudepth);
            param.Add("in_id", id);

            string sql = @$"
                            select c.sort_seq, a.*, b.name as pname 
                            from MOBILE_program_info a, MOBILE_program_info b, MOBILE_sidebar_menu c
                            where a.pid = b.id (+)
                            and a.id = c.id (+)
                            and nvl(a.menudepth,'0') like case when :in_menudepth is null then '%' else :in_menudepth end
                            and nvl(a.id,'0') like case when :in_id is null then '%' else :in_id end
                            ORDER BY c.sort_seq
                        ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 메뉴 조회
        /// </summary>
        [HttpGet("getList")]
        public async Task<IActionResult> getList(string id)
        {
            List<object> items = new();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_id", id);

            string sql = @$"
                            select c.sort_seq, a.*
                            from MOBILE_program_info a, MOBILE_sidebar_menu c
                            where a.id = c.id
                            and a.menudepth = '1'
                            and a.pid = :in_id
                            ORDER BY c.sort_seq
                        ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 메뉴 생성
        /// </summary>
        /// <remarks>
        /// menuDepth : (사이드바메뉴 - 0:parent, 1:child / 그 외 - 2)
        /// </remarks>
        [HttpPost]
        public async Task<IActionResult> Post(string pid, string menuDepth, string name, string icon, string url, string visible )
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("pid", pid);
            param.Add("menu_depth", menuDepth);
            param.Add("name", name);
            param.Add("icon", icon);
            param.Add("url", url);
            param.Add("visible", visible);



            List<string> items = new();
            string Rmsg;
            string Rcode;
            
            db.Open();

            using var transaction = db.BeginTransaction();
            try
            {
                string sql = @$"
                            insert into MOBILE_program_info(name, icon, url, visible, pid, menudepth)
                            values (:name, :icon, :url, :visible, :pid, :menu_depth)
                            ";

                await db.ExecuteAsync(sql, param);

                //사이드바 메뉴일 경우
                if (menuDepth == "0" || menuDepth == "1")
                {
                    sql = @$"
                            insert into MOBILE_sidebar_menu(id, menudepth)
                            values (MOBILE_PROGRAM_INFO_SEQ.currval, :menu_depth)
                            ";

                    await db.ExecuteAsync(sql, param);
                }
                

                transaction.Commit();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MobileAdminMenu : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 메뉴 수정
        /// </summary>
        [HttpPut]
        public async Task<IActionResult> Put(string id, string pid, string menuDepth, string name, string icon, string url, string visible)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("id", id);
            param.Add("pid", pid);
            param.Add("menu_depth", menuDepth);
            param.Add("name", name);
            param.Add("icon", icon);
            param.Add("url", url);
            param.Add("visible", visible);

            

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();

                string sql = @$"
                             update MOBILE_program_info
                                set pid = :pid,
                                    name = :name,
                                    icon = :icon,
                                    url = :url,
                                    visible = :visible,
                                    menudepth = :menu_depth
                                where id = :id                           
                            ";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                sql = @$"
                             select count(*) from MOBILE_sidebar_menu
                                where id = :id                           
                            ";

                var num = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

                //사이드바 메뉴 조건
                if (menuDepth == "0" || menuDepth == "1")
                {

                    //기존에 사이드바 메뉴가 아니었을 경우
                    if (num == 0)
                    {
                        sql = @$"
                             insert into MOBILE_sidebar_menu(id, menudepth)
                                values (:id, :menu_depth)                          
                            ";

                        await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                    }
                    else
                    {
                        sql = @$"
                             update MOBILE_sidebar_menu
                                set menudepth = :menu_depth
                                where id = :id                           
                            ";

                        await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                    }

                }
                else
                {
                    //사이드바메뉴에서 비사이드바메뉴로 변경하는 경우
                    if (num == 1)
                    {
                        sql = @$"
                             delete MOBILE_sidebar_menu
                                where id = :id                           
                            ";

                        await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                    }
                }
                

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MobileAdminMenu : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 메뉴 삭제
        /// </summary>
        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "SP_MOBILE_PROGRAM_INFO_DELETE",
            };

            cmd.Parameters.Add("in_id", OracleDbType.Int32).Value = id;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MobileAdminMenu : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 메뉴 순서 변경
        /// </summary>
        [HttpPut("updateSort")]
        public async Task<IActionResult> updateSort(IEnumerable<string> ids)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            string Rcode;
            string Rmsg;
            int i = 0;

            try
            {
                db.Open();
                foreach (string id in ids)
                {
                    DynamicParameters param = new DynamicParameters();
                    param.Add("id", id);
                    i++;
                    param.Add("seq", i);

                    string sql = @$"
                             update MOBILE_sidebar_menu
                                set sort_seq = :seq
                                where id = :id                           
                            ";

                    await db.ExecuteAsync(sql, param);
                }
                

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/MobileAdminMenu/updateSort : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


    }
}
