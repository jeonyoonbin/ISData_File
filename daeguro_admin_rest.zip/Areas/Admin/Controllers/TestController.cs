﻿using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        string testPath = @"\sy100";
        /// <summary>
        /// 서버구분 확인
        /// </summary>
        /// <remarks>
        /// 외부연동시 테스트와 운영서버 구분을 위한 용도 <br/>
        /// T : 테스트서버, R : 운영서버
        /// </remarks>
        [HttpPost("getServerGbn")]
        public string getServerGbn()
        {
            return Utils.serverGbn;
        }

        [HttpGet("getSHA256")]
        public string getSHA256(string input)
        {
            return Utils.SHA256Hash(input);
        }

        /// <summary>
        /// 이미지 업데이트 테스트
        /// </summary>
        /// <remarks>
        /// https url로 파일 업로드 시도. <br/>
        /// 405 허용되지 않은 메서드 리턴. 서버 폴더에대한 사용자 액세스 권한문제로 보임.
        /// </remarks>
        [HttpPut("updateImg")]
        public async Task<IActionResult> uploadImg(string url, IFormFile formFile)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            if (string.IsNullOrEmpty(url))
            {
                Rcode = "99";
                Rmsg = "url은 필수입니다.";

                return Ok(new { code = Rcode, msg = Rmsg });
            }

            if (formFile != null && formFile.Length > 0)
            {
                try
                {
                    byte[] fileBytes;
                    using (var ms = new MemoryStream())
                    {
                        await formFile.CopyToAsync(ms);
                        if (ms.CanSeek)
                        {
                            ms.Seek(0, SeekOrigin.Begin);
                        }
                        fileBytes = ms.ToArray();

                        using (var content = new StreamContent(ms))
                        {
                            using (var client = new HttpClient())
                            {
                                var response = await client.PostAsync(url, content);
                                response.EnsureSuccessStatusCode();
                                var msg = await response.Content.ReadAsStringAsync();

                                return Ok(new { code = Rcode, msg = msg });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Rcode = "99";
                    Rmsg = ex.Message;
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

            }
            else
            {
                Rcode = "99";
                Rmsg = "파일은 필수입니다.";

                return Ok(new { code = Rcode, msg = Rmsg });
            }

            Rcode = "00";
            Rmsg = "성공";

            return Ok(new { code = Rcode, msg = Rmsg });

        }

        [HttpPut("testimg")]
        public async Task<string> testimg(IFormFile formFile)
        {
            string msg = string.Empty;
            try
            {
                if (formFile != null && formFile.Length > 0)
                {
                    // 확장자 가져오기
                    int dotIdx = formFile.FileName.LastIndexOf(".");

                    int extLength = formFile.FileName.Length - dotIdx;

                    string extention = formFile.FileName.Substring(dotIdx, extLength);

                    string dt = DateTime.Now.ToString("yyyyMMddHHmmss");

                    string fileName = "fileName" + "_" + dt + extention;

                    string folerPath = testPath + "\\" + fileName;

                    msg = folerPath;

                    // 파일이 이미 존재하면 삭제한다.
                    if (System.IO.File.Exists(folerPath))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        System.IO.File.Delete(folerPath);
                    }

                    //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                    using var stream = new FileStream(folerPath, FileMode.Create);

                    await formFile.CopyToAsync(stream);

                    stream.Close();
                    stream.Dispose();
                    
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

            return msg;
        }
    }
}
