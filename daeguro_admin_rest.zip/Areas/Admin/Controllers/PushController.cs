﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class PushController : ControllerBase
    {
        private static async Task<FcmResult> _sendFcm(List<FcmAndCustCode> fcm, string device_gbn, string push_gbn, string pushSeq, string title, string msg, string item1, string imageUrl, string notice_seq)
        {
            FcmResult fcmResult = new FcmResult();

            string boardSeq = string.Empty;
            string shopCode = string.Empty;
            string tabCode = string.Empty;
            string appPushGbn = push_gbn; //주문앱 푸시구분

            string project = "DELIVERY";

            if (fcm.Count > 1000)
            {
                fcmResult.code = "99";
                fcmResult.msg = "ID가 1000개를 초과할 수 없습니다.";

                return fcmResult;
            }

            FcmJson jsonData = new FcmJson();

            HttpClient client = new HttpClient();

            string channelId = string.Empty;
            string channelName = string.Empty;

            if (string.IsNullOrEmpty(push_gbn))
            {
                fcmResult.code = "99";
                fcmResult.msg = "푸시구분은 필수항목입니다.";

                return fcmResult;
            }
            else if (push_gbn == "5" || // 쿠폰발송
                     push_gbn == "9" || // 쿠폰만료
                     push_gbn == "19" || // 마일리지 만료
                     push_gbn == "29" ) // 상품권 만료
            {
                appPushGbn = "5"; // 주문앱 혜택가득 알림
                channelId = "혜택가득";
                channelName = "혜택가득";
                tabCode = item1;
            }
            else if(push_gbn == "21")
            {
                channelId = "이벤트";
                channelName = "이벤트";
                boardSeq = item1;
            }
            else if (push_gbn == "22")
            {
                channelId = "광고";
                channelName = "광고";
                shopCode = item1;
            }
            else if (push_gbn == "23")
            {
                channelId = "약관변경고지";
                channelName = "약관변경고지";
                // 푸시전송시 아이템 필요x
            }
            else if (push_gbn == "20")
            {
                channelId = "공지사항";
                channelName = "공지사항";
            }
            else 
            {
                channelId = "기본알림";
                channelName = "기본알림";
            }

            if(notice_seq == "F")
            {
                project = "FLOWER";
            }

            try
            {
                client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", $@"key={Utils.fcmKey}");

                jsonData.registration_ids = fcm.Select(x => x.fcm_id).ToList();
                jsonData.direct_boot_ok = true;

                jsonData.content_available = true;
                jsonData.priority = "high";

                if (device_gbn == "A")
                {
                    jsonData.data.defaultJ.project = project;
                    jsonData.data.defaultJ.channelId = channelId;
                    jsonData.data.defaultJ.channelName = channelName;
                    jsonData.data.defaultJ.contentTitle = title;
                    jsonData.data.defaultJ.contentText = msg;
                    jsonData.data.defaultJ.pushSeq = pushSeq;
                    if (project == "FLOWER")
                    {
                        jsonData.data.defaultJ.pushFlowerMessage.pushSeq = pushSeq;
                        jsonData.data.defaultJ.pushFlowerMessage.pushTitle = title;
                        jsonData.data.defaultJ.pushFlowerMessage.pushMsg = msg;
                        jsonData.data.defaultJ.pushFlowerMessage.boardSeq = boardSeq;
                        jsonData.data.defaultJ.pushFlowerMessage.shopCode = shopCode;
                        jsonData.data.defaultJ.pushFlowerMessage.pushGbn = appPushGbn;
                        jsonData.data.defaultJ.pushFlowerMessage.tabCode = tabCode;
                        jsonData.data.defaultJ.pushFlowerMessage.imageUrl = imageUrl;
                    }
                    else if (project == "DELIVERY")
                    {
                        jsonData.data.defaultJ.pushMessage.pushSeq = pushSeq;
                        jsonData.data.defaultJ.pushMessage.pushTitle = title;
                        jsonData.data.defaultJ.pushMessage.pushMsg = msg;
                        jsonData.data.defaultJ.pushMessage.boardSeq = boardSeq;
                        jsonData.data.defaultJ.pushMessage.shopCode = shopCode;
                        jsonData.data.defaultJ.pushMessage.pushGbn = appPushGbn;
                        jsonData.data.defaultJ.pushMessage.tabCode = tabCode;
                        jsonData.data.defaultJ.pushMessage.imageUrl = imageUrl;
                    }
                    

                }
                else if (device_gbn == "I")//아이폰일때만 notification 기입
                {
                    jsonData.data.iphone.project = project;
                    jsonData.data.iphone.channelId = channelId;
                    jsonData.data.iphone.channelName = channelName;
                    jsonData.data.iphone.contentTitle = title;
                    jsonData.data.iphone.contentText = msg;
                    jsonData.data.defaultJ.pushSeq = pushSeq;
                    if (project == "FLOWER")
                    {
                        jsonData.data.defaultJ.pushFlowerMessage.pushSeq = pushSeq;
                        jsonData.data.iphone.pushFlowerMessage.pushTitle = title;
                        jsonData.data.iphone.pushFlowerMessage.pushMsg = msg;
                        jsonData.data.iphone.pushFlowerMessage.boardSeq = boardSeq;
                        jsonData.data.iphone.pushFlowerMessage.shopCode = shopCode;
                        jsonData.data.iphone.pushFlowerMessage.pushGbn = appPushGbn;
                        jsonData.data.iphone.pushFlowerMessage.tabCode = tabCode;
                        jsonData.data.iphone.pushFlowerMessage.imageUrl = imageUrl;

                    }
                    else if (project == "DELIVERY")
                    {
                        jsonData.data.defaultJ.pushMessage.pushSeq = pushSeq;
                        jsonData.data.iphone.pushMessage.pushTitle = title;
                        jsonData.data.iphone.pushMessage.pushMsg = msg;
                        jsonData.data.iphone.pushMessage.boardSeq = boardSeq;
                        jsonData.data.iphone.pushMessage.shopCode = shopCode;
                        jsonData.data.iphone.pushMessage.pushGbn = appPushGbn;
                        jsonData.data.iphone.pushMessage.tabCode = tabCode;
                        jsonData.data.iphone.pushMessage.imageUrl = imageUrl;
                    }
                    

                    jsonData.notification.title = title;
                    jsonData.notification.body = msg;
                }

                HttpContent content = new StringContent(JsonConvert.SerializeObject(jsonData));
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                HttpResponseMessage httpResponseMessage = await client.PostAsync("https://fcm.googleapis.com/fcm/send", content);

                string resultStr = await httpResponseMessage.Content.ReadAsStringAsync();

                fcmResult = JsonConvert.DeserializeObject<FcmResult>(resultStr);

                if (push_gbn == "9" ||
                    push_gbn == "19" ||
                    push_gbn == "29" || 
                    push_gbn == "21" || 
                    push_gbn == "22" || 
                    push_gbn == "23") // 알림함에 저장되어야하는 푸시일 경우
                {
                    await setCustPushNotified(fcm.Select(x => x.cust_code), push_gbn, title, msg, item1);
                }
                string str = await content.ReadAsStringAsync();

                //리턴값 로그기록 추가
                await Utils.SaveTempLogAsync("/Push : _sendFcm", resultStr + ":" + str);

                fcmResult.code = "00";
                fcmResult.msg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Push : _sendFcm", ex.Message);
                fcmResult.code = "99";
                fcmResult.msg = ex.Message;
            }

            return fcmResult;
        }

        private static async Task<ResultBasic> setCustPushNotified(IEnumerable<string> cust_code_arr, string push_gbn, string push_title, string push_msg, string item1)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PUSH.SET_CUST_PUSH_NOTIFIED",
            };

            var arr = cmd.Parameters.Add("in_cust_code_arr", OracleDbType.Int32);
            arr.Direction = ParameterDirection.Input;
            arr.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr.Value = cust_code_arr.ToArray();
            arr.Size = cust_code_arr.Count();
            arr.ArrayBindSize = cust_code_arr.Select(_ => _.Length).ToArray();
            arr.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, cust_code_arr.Count()).ToArray();

            cmd.Parameters.Add("in_push_gbn", OracleDbType.Varchar2, 8).Value = push_gbn;
            cmd.Parameters.Add("in_push_title", OracleDbType.Varchar2, 100).Value = push_title;
            cmd.Parameters.Add("in_push_msg", OracleDbType.Varchar2, 500).Value = push_msg;
            cmd.Parameters.Add("in_item1", OracleDbType.Varchar2, 500).Value = item1;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;



            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Push/setCustPushNotified : Post", ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 푸시 단건 테스트
        /// </summary>
        /// <remarks>
        /// telno : 푸시를 테스트할 회원 전화번호 <br/>
        /// title : 푸시 제목 <br/>
        /// msg : 푸시 내용 <br/>
        /// pushGbn : 푸시 구분(혜택가득(5 쿠폰발송, 9 쿠폰만료, 19 마일리지만료, 29 상품권만료), 21 이벤트, 22 광고, 23 약관변경고지) <br/>
        /// item1 : 푸시 구분에 따라 변동(탭구분(5,9/COUPON,19/MILEAGE,29/VOUCHER), 21/이벤트공지 글번호, 22/가맹점코드, 23/변경안 코드) <br/>
        /// </remarks>
        [HttpPost("sendFcm")]
        public async Task<IActionResult> sendFcm(SendEventFCM sendFCM)
        {
            List<FcmAndCustCode> fc = new List<FcmAndCustCode>();
            List<FcmAndCustCode> fcA = new List<FcmAndCustCode>();
            List<FcmAndCustCode> fcI = new List<FcmAndCustCode>();

            string notice_system = string.Empty;

            string deviceId = string.Empty;

            if (string.IsNullOrEmpty(sendFCM.pushGbn))
            {
                return Ok(new { code = "99", msg = "푸시 구분은 필수입니다." });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("telno", sendFCM.telno);

                string sql = @$"select fcm_id, cust_code, device_gbn
                            from app_customer
                            where fcm_id is not null
                            --and test_gbn = 'R'
                            --and use_gbn = '1'
                            --and mcode = 2
                            and cust_id_gbn <> 'Z'
                            and telno = :telno";

                var temp = await db.QueryAsync<FcmAndCustCode>(sql, param, commandType: CommandType.Text);

                fc = temp.ToList();

                if (fc.Count == 0)
                {
                    return Ok(new { code = "99", msg = "해당하는 회원이 없습니다" });
                }

                foreach (var fcm in fc)
                {
                    if (fcm.device_gbn == "A")
                    {
                        fcA.Add(fcm);
                    }
                    else if (fcm.device_gbn == "I")
                    {
                        fcI.Add(fcm);
                    }
                }

                if (sendFCM.pushGbn == "21") //이벤트 및 공지
                {
                    // 음식배달인지 꽃배달인지 구분
                    param.Add("notice_seq", sendFCM.item1);

                    sql = @$"select system_gbn_m
                            from notice_event
                            where notice_seq = :notice_seq";

                    notice_system = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                }


            }
            catch(Exception ex)
            {
                return Ok(new { code = "99", msg = ex.Message });
            }

            FcmResult fcmResult = new FcmResult();

            if (fcA.Count > 0)
            {
                fcmResult = await _sendFcm(fcA, "A", sendFCM.pushGbn, sendFCM.pushSeq, sendFCM.title, sendFCM.msg, sendFCM.item1, sendFCM.imageUrl, notice_system);
            }

            if (fcI.Count > 0)
            {
                fcmResult = await _sendFcm(fcI, "I", sendFCM.pushGbn, sendFCM.pushSeq, sendFCM.title, sendFCM.msg, sendFCM.item1, sendFCM.imageUrl, notice_system);
            }


            return Ok(new { code = fcmResult.code, msg = fcmResult.msg });
        }


        /// <summary>
        /// 쿠폰지급 푸시발송
        /// </summary>
        /// <remarks>
        /// cust_code : 푸시할 회원 코드 <br/>
        /// div : 쿠폰구분 D. 대구로쿠폰, B. 제휴쿠폰, C. 브랜드쿠폰 <br/>
        /// coupon_type : 푸시할 쿠폰코드 <br/>
        /// item_cd : 푸시할 제휴쿠폰 아이템코드(제휴쿠폰의 경우만)
        /// </remarks>
        [HttpPost("sendCouponFcm")]
        public static async Task<ResultBasic> sendCouponFcm(string cust_code, string div, string coupon_type, string item_cd)
        {
            ResultBasic resultBasic = new ResultBasic();

            string succesed_yn = "N";
            string send_result = string.Empty;

            CouponPush couponPush = new CouponPush();
            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("cust_code", cust_code);
                param.Add("div", div);
                param.Add("coupon_type", coupon_type);
                param.Add("item_cd", item_cd);

                string sql = @$"select a.cust_code, a.fcm_id, a.device_gbn, a.telno, nvl(b.push_event_yn,a.push_marketing_yn) push_marketing_yn, c.code_nm as coupon_name 
                                from app_customer a, app_customer_add b,
                                    (select code_nm from etc_code where code = :coupon_type
                                    and code_grp = case when :div = 'D' then 'COUPON_TYPE'
                                                        when :div = 'C' then 'BRAND_COUPON' end)c
                                where a.cust_code = b.cust_code (+)
                                and a.mcode = 2
                                and a.test_gbn = 'R'
                                and a.use_gbn = '1'
                                and a.fcm_id is not null
                                and a.cust_id_gbn <> 'Z'
                                and a.cust_code = :cust_code
                                and :div in ('D','C')
                                union all
                                select a.cust_code, a.fcm_id, a.device_gbn, a.telno, nvl(b.push_event_yn,a.push_marketing_yn) push_marketing_yn, c.item_nm as coupon_name 
                                from app_customer a, app_customer_add b,
                                    (select b.item_nm from etc_code a, b2b_coupon_item b
                                    where a.code = b.coupon_type 
                                    and a.code = :coupon_type
                                    and a.code_grp = 'B2BCOUPON_TYPE'
                                    and b.item_cd = :item_cd)c
                                where a.cust_code = b.cust_code (+)
                                and a.mcode = 2
                                and a.test_gbn = 'R'
                                and a.use_gbn = '1'
                                and a.fcm_id is not null
                                and a.cust_id_gbn <> 'Z'
                                and a.cust_code = :cust_code
                                and :div = 'B'";

                couponPush = await db.QuerySingleAsync<CouponPush>(sql, param, commandType: CommandType.Text);

                if (string.IsNullOrEmpty(couponPush.cust_code))
                {
                    resultBasic.code = "99";
                    resultBasic.msg = "해당하는 회원이 없습니다";
                    return resultBasic;
                }

                if (couponPush.push_marketing_yn.Equals("Y"))//마케팅 푸시에 동의한 경우 전송
                {
                    string push_gbn = "5";

                    List<FcmAndCustCode> fcmIds = new List<FcmAndCustCode>();
                    FcmAndCustCode fcmAndCustCode = new FcmAndCustCode();
                    fcmAndCustCode.fcm_id = couponPush.fcm_id;
                    fcmAndCustCode.cust_code = couponPush.cust_code;
                    fcmIds.Add(fcmAndCustCode);

                    string title = couponPush.coupon_name + "이 도착하였습니다.";
                    string push_msg = "(광고)지금 대구로에서 할인받아 주문하세요~\n*수신거부: 설정에서 변경가능";
                    string tabCode = "COUPON";


                    FcmResult fcmResult = await _sendFcm(fcmIds, couponPush.device_gbn, push_gbn, null, title, push_msg, tabCode, null, null);
                    resultBasic.code = fcmResult.code;
                    resultBasic.msg = fcmResult.msg;

                    if (resultBasic.code == "00")
                    {
                        succesed_yn = "Y";
                    }
                    else
                    {
                        succesed_yn = "N";
                        send_result = resultBasic.msg;
                    }
                }
                else if (couponPush.push_marketing_yn.Equals("N"))
                {
                    succesed_yn = "N";
                    send_result = "마케팅 푸시에 동의하지 않은 고객입니다.";
                }


                param.Add("cust_telno", couponPush.telno);
                param.Add("fcm_id", couponPush.fcm_id);
                param.Add("send_result", send_result);
                param.Add("succesed_yn", succesed_yn);

                sql = @$"insert into coupon_push_log(cust_code, cust_telno, fcm_id, send_date, send_result, succesed_yn, coupon_div, coupon_type) 
                         values(:cust_code, :cust_telno, :fcm_id, sysdate, :send_result, :succesed_yn, :div, :coupon_type)
                        ";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                resultBasic.code = "00";
                resultBasic.msg = "성공";

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Push/sendCouponFcm : Post", ex.Message);

                resultBasic.code = "99";
                resultBasic.msg = ex.Message;
                return resultBasic;
            }



            return resultBasic;
        }


        /// <summary>
        /// (대량발송)쿠폰지급 푸시발송
        /// </summary>
        /// <remarks>
        /// pub_dt : 쿠폰지급 일자(YYYYMMDD) <br/>
        /// cnt : 쿠폰지급 건수 <br/>
        /// div : 쿠폰구분 D. 대구로쿠폰, B. 제휴쿠폰, C. 브랜드쿠폰 <br/>
        /// coupon_type : 푸시할 쿠폰코드 <br/>
        /// item_cd : 푸시할 제휴쿠폰 아이템코드(제휴쿠폰의 경우만)
        /// </remarks>
        [HttpPost("sendCouponFcmList")]
        public static async Task<ResultBasic> sendCouponFcmList(string pub_dt, string cnt, string div, string coupon_type, string item_cd, string title, string push_msg)
        {
            ResultBasic resultBasic = new ResultBasic();

            string succesed_a_yn = string.Empty;
            string succesed_i_yn = string.Empty;
            string send_result_a = string.Empty;
            string send_result_i = string.Empty;

            List<CouponPush> couponPush = new List<CouponPush>();

            List<FcmAndCustCode> fcmIdsA = new List<FcmAndCustCode>();
            List<FcmAndCustCode> fcmIdsI = new List<FcmAndCustCode>();

            List<CouponPush> couponPushN = new List<CouponPush>();
            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("pub_dt", pub_dt);
                param.Add("div", div);
                param.Add("coupon_type", coupon_type);
                param.Add("item_cd", item_cd);

                string sql = @$"select a.cust_code, a.fcm_id, a.device_gbn, a.telno, nvl(c.push_event_yn,a.push_marketing_yn) push_marketing_yn, b.coupon_name 
                                from app_customer a,coupon_mst b, app_customer_add c
                                where a.cust_code = b.app_cust_code
                                and a.cust_code = c.cust_code (+)
                                and b.coupon_type = :coupon_type
                                and b.status = '20'
                                and mcode = 2
                                and test_gbn = 'R'
                                and use_gbn = '1'
                                and fcm_id is not null
                                and cust_id_gbn <> 'Z'
                                and b.publish_date between to_date(:pub_dt,'YYYYMMDD') and to_date(:pub_dt || '235959','YYYYMMDDHH24MISS') 
                                and :div = 'D'
                                union all
                                select a.cust_code, a.fcm_id, a.device_gbn, a.telno, nvl(c.push_event_yn,a.push_marketing_yn) push_marketing_yn, b.coupon_name
                                from app_customer a,chain_coupon_mst b, app_customer_add c
                                where a.cust_code = b.app_cust_code
                                and a.cust_code = c.cust_code (+)
                                and b.coupon_type = :coupon_type
                                and b.status = '20'
                                and mcode = 2
                                and test_gbn = 'R'
                                and use_gbn = '1'
                                and fcm_id is not null
                                and cust_id_gbn <> 'Z'
                                and b.publish_date between to_date(:pub_dt,'YYYYMMDD') and to_date(:pub_dt || '235959','YYYYMMDDHH24MISS') 
                                and :div = 'C'
                                union all
                                select a.cust_code, a.fcm_id, a.device_gbn, a.telno, nvl(d.push_event_yn,a.push_marketing_yn) push_marketing_yn, c.item_nm as coupon_name 
                                from app_customer a, b2b_coupon_mst b, b2b_coupon_item c, app_customer_add d
                                where a.cust_code = b.app_cust_code
                                and a.cust_code = d.cust_code (+)
                                and b.status = '20'
                                and b.coupon_type = c.coupon_type
                                and b.s_etc_gbn2 = c.item_cd
                                and b.coupon_type = :coupon_type
                                and b.s_etc_gbn2 = :item_cd
                                and mcode = 2
                                and test_gbn = 'R'
                                and use_gbn = '1'
                                and fcm_id is not null
                                and cust_id_gbn <> 'Z'
                                and b.publish_date between to_date(:pub_dt,'YYYYMMDD') and to_date(:pub_dt || '235959','YYYYMMDDHH24MISS') 
                                and :div = 'B'";

                var temp = await db.QueryAsync<CouponPush>(sql, param, commandType: CommandType.Text);
                couponPush = temp.ToList();

                if (couponPush.Count == 0)
                {
                    resultBasic.code = "99";
                    resultBasic.msg = "해당하는 회원이 없습니다";
                    return resultBasic;
                }

                if (couponPush.Count != int.Parse(cnt))
                {
                    resultBasic.code = "99";
                    resultBasic.msg = "지급된 쿠폰수(" + cnt + ")와 검색된 쿠폰수(" + couponPush.Count.ToString() + ")가 다릅니다.";
                    return resultBasic;
                }

                if (string.IsNullOrEmpty(title))
                {
                    title = couponPush[0].coupon_name + "이 도착하였습니다.";
                }

                if (string.IsNullOrEmpty(push_msg))
                {
                    push_msg = "(광고)지금 대구로에서 할인받아 주문하세요~\n*수신거부: 설정에서 변경가능";
                }

                foreach (var push in couponPush)
                {
                    if (push.push_marketing_yn.Equals("Y"))
                    {
                        FcmAndCustCode fcmAndCustCode = new FcmAndCustCode();
                        fcmAndCustCode.fcm_id = push.fcm_id;
                        fcmAndCustCode.cust_code = push.cust_code;
                        fcmAndCustCode.telno = push.telno;

                        if (push.device_gbn.Equals("A"))
                        {
                            fcmIdsA.Add(fcmAndCustCode);
                        }
                        else if (push.device_gbn.Equals("I"))
                        {
                            fcmIdsI.Add(fcmAndCustCode);
                        }

                    }
                    else if (push.push_marketing_yn.Equals("N"))
                    {
                        couponPushN.Add(push);
                    }
                }

                string push_gbn = "5";
                string tabCode = "COUPON";

                if(fcmIdsA.Count > 0)
                {
                    FcmResult fcmAResult = await _sendFcm(fcmIdsA, "A", push_gbn, null, title, push_msg, tabCode, null, null);

                    succesed_a_yn = (fcmAResult.code == "00")? "Y" : "N";
                    send_result_a = fcmAResult.msg;
                }

                if (fcmIdsI.Count > 0)
                {
                    FcmResult fcmIResult = await _sendFcm(fcmIdsI, "I", push_gbn, null, title, push_msg, tabCode, null, null);

                    succesed_i_yn = (fcmIResult.code == "00") ? "Y" : "N";
                    send_result_i = fcmIResult.msg;
                }
                
                

                if (succesed_a_yn == "N" || succesed_i_yn == "N")
                {
                    resultBasic.code = "99";
                    resultBasic.msg = "A:" + send_result_a + "/I:" + send_result_i;
                }

                param.Add("title", title);
                param.Add("push_msg", push_msg);
                //마스터 로그
                sql = @$"insert into coupon_push_set(title, msg, ins_date) 
                         values(:title, :push_msg, sysdate)
                        ";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                sql = @$"select last_number - 1
                         from user_sequences
                         where sequence_name = 'COUPON_PUSH_SET_SEQ'
                        ";

                var seq = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                param.Add("seq", seq);

                sql = @$"insert into coupon_push_log(cust_code, cust_telno, fcm_id, send_date, send_result, succesed_yn, coupon_div, coupon_type, push_code) 
                         values(:cust_code, :cust_telno, :fcm_id, sysdate, :send_result, :succesed_yn, :div, :coupon_type, :seq)
                        ";

                //안드로이드 발송기록
                param.Add("send_result", send_result_a);
                param.Add("succesed_yn", succesed_a_yn);
                foreach (var p in fcmIdsA)
                {
                    param.Add("cust_code", p.cust_code);
                    param.Add("cust_telno", p.telno);
                    param.Add("fcm_id", p.fcm_id);

                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                }
                //아이폰 발송기록
                param.Add("send_result", send_result_i);
                param.Add("succesed_yn", succesed_i_yn);
                foreach (var p in fcmIdsI)
                {
                    param.Add("cust_code", p.cust_code);
                    param.Add("cust_telno", p.telno);
                    param.Add("fcm_id", p.fcm_id);

                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                }
                // 광고 마케팅 거부 기록
                param.Add("send_result", "마케팅 푸시에 동의하지 않은 고객입니다.");
                param.Add("succesed_yn", "N");
                foreach (var p in couponPushN)
                {
                    param.Add("cust_code", p.cust_code);
                    param.Add("cust_telno", p.telno);
                    param.Add("fcm_id", p.fcm_id);

                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                }

                if (string.IsNullOrEmpty(resultBasic.code))
                {
                    resultBasic.code = "00";
                    resultBasic.msg = "성공";
                }

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Push/sendCouponFcmList : Post", ex.Message);

                resultBasic.code = "99";
                resultBasic.msg = ex.Message;
                return resultBasic;
            }



            return resultBasic;
        }




        //푸시관리
        /// <summary>
        /// 푸시 목록 조회
        /// </summary>
        /// <remarks>
        /// keyword : 제목 검색 키워드 <br/>
        /// <br/>
        /// 파라미터 <br/>
        /// push_gbn : 푸시 구분 (빈값: 전체, 5: 혜택가득(5,9,19,29), 21: 이벤트, 22: 광고, 23: 약관변경고지 <br/>
        /// status : 전송 상태 (빈값: 전체, 00: 대기, 20: 완료) <br/>
        /// keyword : 제목 키워드
        ///  <br/>
        /// 결과값 <br/>
        /// rnum : 조회순서 <br/>
        /// push_cd : PK 값 <br/>
        /// push_title : 제목 <br/>
        /// push_msg : 내용 <br/>
        /// st_date : 발송일 <br/>
        /// send_gbn : 발송시간 <br/>
        /// object_gbn : 대상(DB/CSV) <br/>
        /// range_gbn : 대상범위 <br/>
        /// marketing_push_gbn : 마케팅동의 여부 <br/>
        /// status : 전송 상태 (00: 대기, 20: 완료) <br/>
        /// cnt : 대상건수
        /// </remarks>
        [HttpGet()]
        public async Task<IActionResult> Get(string push_gbn, string status, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<PushList> itmes = new List<PushList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PUSH.GET_LIST",
            };

            cmd.Parameters.Add("in_push_gbn", OracleDbType.Varchar2, 2).Value = push_gbn;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 2).Value = status;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 600).Value = string.IsNullOrEmpty(keyword) ? keyword : "%" + keyword + "%";
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    PushList item = new PushList
                    {
                        rnum = rd["RNUM"].ToString(),
                        push_gbn = rd["PUSH_gbn"].ToString(),
                        push_cd = rd["PUSH_CD"].ToString(),
                        push_title = rd["PUSH_TITLE"].ToString(),
                        push_msg = rd["PUSH_MSG"].ToString(),
                        st_date = rd["ST_DATE"].ToString(),
                        send_gbn = rd["SEND_GBN"].ToString(),
                        object_gbn = rd["OBJECT_GBN"].ToString(),
                        range_gbn = rd["RANGE_GBN"].ToString(),
                        marketing_push_gbn = rd["MARKETING_PUSH_GBN"].ToString(),
                        status = rd["STATUS"].ToString(),
                        cnt = rd["CNT"].ToString(),
                        ins_date = rd["INS_DATE"].ToString(),
                        ins_name = rd["INS_NAME"].ToString(),
                        mod_date = rd["MOD_DATE"].ToString(),
                        mod_name = rd["MOD_NAME"].ToString()
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Push : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }

        /// <summary>
        /// 푸시 상세조회
        /// </summary>
        /// <remarks>
        /// push_cd : pk값 <br/>
        /// push_title : 제목 <br/>
        /// reserve_send_dt : 발송 희망 일(YYYYMMDD) <br/>
        /// send_gbn : 발송시점구분 (A1: 9시, AA:10시[이벤트 쿠폰 지급용 시간], A: 11시,  P1: 13시, P: 17시, O1,O2,O3: 상품권 공지) <br/>
        /// push_gbn : 푸시 구분 (빈값: 전체, 5: 혜택가득, 21: 이벤트, 22: 광고, 23: 약관변경고지 <br/>
        /// boardseq : 푸시 연결 이벤트공지 글번호 <br/>
        /// notice_title : 푸시 연결 이벤트공지 글제목 <br/>
        /// shop_cd : 푸시 연결 가맹점 코드 <br/>
        /// shop_name : 푸시 연결 가맹점명 <br/>
        /// tab_gbn : (혜택가득)푸시 탭구분(COUPON, MILEAGE, VOUCHER) <br/>
        /// object_gbn : 대상 구분 (D: DB, C: CSV 파일) <br/>
        /// range_gbn : 발송 범위 구분 (M: 회원만, N: 비회원만, A: 전체) <br/>
        /// marketing_push_gbn : 마케팅 동의 구분 (Y: 마케팅 동의만, N: 구분없음[전체]) <br/>
        /// push_msg : 푸시 내용
        /// </remarks>
        [HttpGet("{push_cd}")]
        public async Task<IActionResult> getDetail(string push_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PUSH.GET_DETAIL",
            };

            //OracleParameter op = new OracleParameter();
            //op.OracleDbType = OracleDbType.RefCursor;
            //op.Direction = ParameterDirection.Output;

            cmd.Parameters.Add("in_push_cd", OracleDbType.Int32).Value = push_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            PushDetail item = new PushDetail();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.push_cd = rd["PUSH_CD"].ToString();
                item.push_title = rd["PUSH_TITLE"].ToString();
                item.send_gbn = rd["SEND_GBN"].ToString();
                item.push_gbn = rd["push_gbn"].ToString();
                item.boardseq = rd["boardseq"].ToString();
                item.notice_title = rd["notice_title"].ToString();
                item.tos_seq = rd["tos_seq"].ToString();
                item.tos_memo = rd["tos_memo"].ToString();
                item.shop_cd = rd["shop_cd"].ToString();
                item.shop_name = rd["shop_name"].ToString();
                item.tab_gbn = rd["tab_gbn"].ToString();
                item.reserve_send_dt = rd["RESERVE_SEND_DT"].ToString();
                item.object_gbn = rd["OBJECT_GBN"].ToString();
                item.range_gbn = rd["RANGE_GBN"].ToString();
                item.marketing_push_gbn = rd["MARKETING_PUSH_GBN"].ToString();
                item.push_msg = rd["PUSH_MSG"].ToString();
                item.status = rd["STATUS"].ToString();
                item.ins_date = rd["INS_DATE"].ToString();
                item.ins_name = rd["INS_NAME"].ToString();
                item.mod_date = rd["MOD_DATE"].ToString();
                item.mod_name = rd["MOD_NAME"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Push/{push_cd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// (푸시와연결할)이벤트공지 목록 조회
        /// </summary>
        /// <remarks>
        /// 파라미터 <br/>
        /// disp_gbn : 게시유무(Y/N) <br/>
        ///  <br/>
        /// 결과값 <br/>
        /// notice_seq : 공지글 pk값 -> boardseq값<br/>
        /// notice_title : 제목 <br/>
        /// disp_fr_date : 게시시작일 <br/>
        /// disp_to_date : 게시종료일 <br/>
        /// </remarks>
        [HttpGet("getEventNoticeList")]
        public async Task<IActionResult> getEventNoticeList(string disp_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<eventNoticeListForPush> itmes = new List<eventNoticeListForPush>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PUSH.GET_EVENT_NOTICE_LIST",
            };

            cmd.Parameters.Add("in_disp_gbn", OracleDbType.Varchar2, 2).Value = disp_gbn;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    eventNoticeListForPush item = new eventNoticeListForPush
                    {
                        notice_seq = rd["NOTICE_SEQ"].ToString(),
                        notice_title = rd["NOTICE_TITLE"].ToString(),
                        disp_fr_date = rd["DISP_FR_DATE"].ToString(),
                        disp_to_date = rd["DISP_TO_DATE"].ToString(),
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Push/getEventNoticeList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }

        /// <summary>
        /// 푸시 발송 등록
        /// </summary>
        /// <remarks>
        /// push_cd 불필요 <br/>
        /// 관리앱에서는 푸시 구분이 21(이벤트), 22(광고), 23(약관변경고지)인 푸시만 등록가능 <br/>
        /// 대상이 db인 경우만 추가 발송조건이 있다(range_gbn, marketing_push_gbn) <br/>
        /// <br/>
        /// push_cd : PK값 (put only) <br/>
        /// push_title : 푸시 제목 <br/>
        /// push_gbn : 푸시 구분(21,22,23) <br/>
        /// reserve_send_dt : 발송 희망 일(YYYYMMDD) <br/>
        /// send_gbn : 발송시점구분 (A1: 9시, AA:10시[이벤트 쿠폰 지급용 시간], A: 11시,  P1: 13시, P: 17시, O1,O2,O3: 상품권 공지) <br/>
        /// item1 : 푸시 구분에 따라 변동(5/탭구분(COUPON,MILEAGE,VOUCHER), 21/이벤트공지 글번호, 22/가맹점코드, 23/변경안 코드) <br/>
        /// object_gbn : 대상 구분 (D: DB, C: CSV 파일) <br/>
        /// range_gbn : 발송 범위 구분 (M: 회원만, N: 비회원만, A: 전체) <br/>
        /// marketing_push_gbn : 마케팅 동의 구분 (Y: 마케팅 동의만, N: 구분없음[전체]) <br/>
        /// push_msg : 푸시 내용 <br/>
        /// telno : 전화번호 배열
        /// </remarks>
        [HttpPost("setPush")]
        public async Task<IActionResult> setPush(Push push)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string boardSeq = string.Empty;
            string shopCode = string.Empty;
            string changeSeq = string.Empty;
            string tabGbn = string.Empty;

            if (string.IsNullOrEmpty(push.ucode))
            {
                return Ok(new { code = "99", msg = "작업자코드는 필수입니다." });
            }

            if (string.IsNullOrEmpty(push.reserve_send_dt))
            {
                return Ok(new { code = "99", msg = "발송일자는 필수입니다." });
            }

            if (string.IsNullOrEmpty(push.send_gbn))
            {
                return Ok(new { code = "99", msg = "발송시점은 필수입니다." });
            }

            if (string.IsNullOrEmpty(push.object_gbn))
            {
                return Ok(new { code = "99", msg = "대상구분은 필수입니다." });
            }

            if (push.object_gbn.Equals("C") && (push.telno == null || push.telno.Count() == 0))
            {
                //CSV인데 푸시전송할 대상이 없는 경우
                return Ok(new { code = "99", msg = "푸시를 전송할 번호가 없습니다." });
            }

            if (string.IsNullOrEmpty(push.push_gbn))
            {
                return Ok(new { code = "99", msg = "푸시구분은 필수항목입니다." });
            }
            else if (push.push_gbn == "5")
            {
                // 관리앱 입력은 안됨
                if (string.IsNullOrEmpty(push.item1))
                {
                    return Ok(new { code = "99", msg = "탭 구분은 필수입니다." });
                }

                tabGbn = push.item1;
            }
            else if (push.push_gbn == "21")
            {
                if (string.IsNullOrEmpty(push.item1))
                {
                    return Ok(new { code = "99", msg = "이벤트공지 글번호는 필수입니다." });
                }

                boardSeq = push.item1;
            }
            else if (push.push_gbn == "22")
            {
                //가맹점코드는 비울수 있다
                shopCode = push.item1;
            }
            else if (push.push_gbn == "23")
            {
                if (string.IsNullOrEmpty(push.item1))
                {
                    return Ok(new { code = "99", msg = "변경안 코드는 필수입니다." });
                }

                changeSeq = push.item1;
            }
            else
            {
                return Ok(new { code = "99", msg = "잘못된 푸시구분입니다." });
            }

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("push_title", push.push_title);
            param.Add("send_gbn", push.send_gbn);
            param.Add("reserve_send_dt", push.reserve_send_dt);
            param.Add("push_gbn", push.push_gbn);
            param.Add("boardseq", boardSeq);
            param.Add("shopCode", shopCode);
            param.Add("changeSeq", changeSeq);
            param.Add("tabGbn", tabGbn);
            param.Add("object_gbn", push.object_gbn);
            param.Add("range_gbn", push.range_gbn);
            param.Add("marketing_push_gbn", push.marketing_push_gbn);
            param.Add("push_msg", push.push_msg);
            param.Add("ins_ucode", push.ucode);

            db.Open();

            using var transaction = db.BeginTransaction();

            try
            {
                //기존 발송 예약시간과 겹치는 건이 있는지 체크(한 인터벌에 한건만 보내야함)
                string sql = @$"
                                select count(*)
                                from push_settings
                                where reserve_send_dt = :reserve_send_dt
                                AND send_gbn = :send_gbn
                                    ";

                int n = await db.ExecuteScalarAsync<int>(sql, param);

                if (n > 0)
                {
                    return Ok(new { code = "50", msg = "동일한 시간의 발송건이 이미 존재합니다." });
                }

                sql = @"
                                insert into push_settings (push_title,
                                                           send_gbn,
                                                           reserve_send_dt,
                                                           push_gbn,
                                                           boardseq,
                                                           shop_cd,
                                                           tos_seq,
                                                           tab_gbn,
                                                           object_gbn,
                                                           range_gbn,
                                                           marketing_push_gbn,
                                                           push_msg,
                                                           ins_date,
                                                           ins_ucode)
                                values(:push_title,
                                       :send_gbn,
                                       :reserve_send_dt,
                                       :push_gbn,
                                       :boardseq,
                                       :shopCode,
                                       :changeSeq,
                                       :tabGbn,
                                       :object_gbn,
                                       :range_gbn,
                                       :marketing_push_gbn,
                                       :push_msg,
                                       sysdate,
                                       :ins_ucode)
                        ";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                //발송목록 생성
                sql = $@"
                          select last_number - 1
                        from user_sequences
                        where sequence_name = 'PUSH_SETTINGS_SEQ'
                        ";

                push.push_cd = await db.ExecuteScalarAsync<string>(sql, commandType: CommandType.Text);

                param.Add("push_cd", push.push_cd);

                //db 쿼리의 경우
                //대상이 db인 경우만 추가 발송조건이 있다고 본다
                if (push.object_gbn.Equals("D"))
                {
                    sql = $@"
                          insert into push_log(cust_code, cust_telno, fcm_id, device_gbn, push_cd)
                            select cust_code, telno, fcm_id, device_gbn, :push_cd
                            from(select /*+ full(app_customer) parallel(app_customer 4)*/ distinct a.fcm_id,
                                       first_value(a.cust_code) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) cust_code, -- (범위조건이 전체일 경우 회원 우선) 마지막 로그인 시간 우선
                                       first_value(a.telno) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) telno,
                                       first_value(a.device_gbn) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) device_gbn,
                                       first_value(nvl(b.push_event_yn, a.push_marketing_yn)) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) marketing_yn
                                from app_customer a, app_customer_add b
                                                        where a.cust_code = b.cust_code (+)
                                                        and a.mcode = 2
                                                        and a.test_gbn = 'R'
                                                        and a.use_gbn = '1'
                                                        and a.device_gbn is not null
                                                        and a.fcm_id is not null
                                                        and a.last_login_time is not null
                                                        --and case when :marketing_push_gbn = 'Y' then nvl(b.push_event_yn, a.push_marketing_yn) else 'Y' end = 'Y'
                                                        and case when :range_gbn = 'M' then a.cust_id_gbn else '1' end <> 'Z'
                                                        and case when :range_gbn = 'N' then a.cust_id_gbn else 'Z' end = 'Z'
                                                        and :range_gbn = 'N' 
                                                        and a.fcm_id not in (select fcm_id from app_customer -- 범위조건이 비회원만일 경우 회원인 fcm_id가 있으면 제외
                                                                            where mcode = 2
                                                                            and test_gbn = 'R'
                                                                            and use_gbn = '1'
                                                                            and device_gbn is not null
                                                                            and fcm_id is not null
                                                                            and case when :range_gbn = 'N' then cust_id_gbn else 'Z' end <> 'Z')
                                    union all
                                    select /*+ full(app_customer) parallel(app_customer 4)*/ distinct a.fcm_id,
                                       first_value(a.cust_code) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) cust_code, -- (범위조건이 전체일 경우 회원 우선) 마지막 로그인 시간 우선
                                       first_value(a.telno) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) telno,
                                       first_value(a.device_gbn) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) device_gbn,
                                       first_value(nvl(b.push_event_yn, a.push_marketing_yn)) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) marketing_yn
                                from app_customer a, app_customer_add b
                                                        where a.cust_code = b.cust_code (+)
                                                        and a.mcode = 2
                                                        and a.test_gbn = 'R'
                                                        and a.use_gbn = '1'
                                                        and a.device_gbn is not null
                                                        and a.fcm_id is not null
                                                        and a.last_login_time is not null
                                                        --and case when :marketing_push_gbn = 'Y' then nvl(b.push_event_yn, a.push_marketing_yn) else 'Y' end = 'Y'
                                                        and case when :range_gbn = 'M' then a.cust_id_gbn else '1' end <> 'Z'
                                                        and case when :range_gbn = 'N' then a.cust_id_gbn else 'Z' end = 'Z'
                                                        and :range_gbn IN ('M','A') )
                            WHERE case when :marketing_push_gbn = 'Y' then marketing_yn else 'Y' end = 'Y'
                        ";

                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                }//CSV 파일의 경우
                else if(push.object_gbn.Equals("C"))
                {
                    foreach (var tel in push.telno)
                    {

                        sql = $@"
                                select count(*)
                                from app_customer
                                where mcode = 2
                                and test_gbn = 'R'
                                and use_gbn = '1'
                                and telno = '{tel}'
                        ";

                        int num = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

                        if (num  == 0)
                        {
                            //해당 전화번호는 회원이 아닙니다 로그 기록
                            sql = $@"
                                    insert into push_log(cust_telno, push_cd, succesed_yn, send_result)
                                    values('{tel}', :push_cd, 'N', '해당 전화번호는 회원이 아닙니다.')
                                    ";

                            await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                        }
                        else
                        {
                            //회원인경우
                            sql = $@"
                                    insert into push_log(cust_code, cust_telno, fcm_id, device_gbn, push_cd)
                                    select cust_code, telno, fcm_id, device_gbn, :push_cd
                                    from app_customer
                                    where mcode = 2
                                    and test_gbn = 'R'
                                    and use_gbn = '1'
                                    and telno = '{tel}'
                                    ";

                            await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                        }
                    }
                }

                //transaction.Commit();

                //대상건수 업데이트
                sql = $@"
                           select count(*) from push_log where push_cd = :push_cd    
                        ";
                int cnt = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

                param.Add("cnt", cnt);

                sql = $@"
                           update push_settings set target_cnt = :cnt where push_cd = :push_cd    
                        ";
                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                transaction.Commit();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Push/setPush : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 푸시 발송 수정
        /// </summary>
        /// <remarks>
        /// push_cd : PK값 (put only) <br/>
        /// push_title : 푸시 제목 <br/>
        /// push_gbn : 푸시 구분(5,21,22,23) <br/>
        /// reserve_send_dt : 발송 희망 일(YYYYMMDD) <br/>
        /// send_gbn : 발송시점구분 (A1: 9시, AA:10시[이벤트 쿠폰 지급용 시간], A: 11시,  P1: 13시, P: 17시, O1,O2,O3: 상품권 공지) <br/>
        /// item1 : 푸시 구분에 따라 변동(5/탭구분(COUPON,MILEAGE,VOUCHER), 21/이벤트공지 글번호, 22/가맹점코드, 23/변경안 코드) <br/>
        /// object_gbn : 대상 구분 (D: DB, C: CSV 파일) <br/>
        /// range_gbn : 발송 범위 구분 (M: 회원만, N: 비회원만, A: 전체) <br/>
        /// marketing_push_gbn : 마케팅 동의 구분 (Y: 마케팅 동의만, N: 구분없음[전체]) <br/>
        /// push_msg : 푸시 내용 <br/>
        /// telno : 전화번호 배열
        /// </remarks>
        [HttpPut("updatePush")]
        public async Task<IActionResult> updatePush(Push push)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string boardSeq = string.Empty;
            string shopCode = string.Empty;
            string changeSeq = string.Empty;
            string tabGbn = string.Empty;

            if (string.IsNullOrEmpty(push.ucode))
            {
                return Ok(new { code = "99", msg = "작업자코드는 필수입니다." });
            }

            if (string.IsNullOrEmpty(push.reserve_send_dt))
            {
                return Ok(new { code = "99", msg = "발송일자는 필수입니다." });
            }

            if (string.IsNullOrEmpty(push.send_gbn))
            {
                return Ok(new { code = "99", msg = "발송시점은 필수입니다." });
            }

            if (string.IsNullOrEmpty(push.object_gbn))
            {
                return Ok(new { code = "99", msg = "대상구분은 필수입니다." });
            }

            if (string.IsNullOrEmpty(push.push_gbn))
            {
                return Ok(new { code = "99", msg = "푸시구분은 필수항목입니다." });
            }
            else if (push.push_gbn == "5")
            {
                // 관리앱 입력은 안됨
                if (string.IsNullOrEmpty(push.item1))
                {
                    return Ok(new { code = "99", msg = "탭 구분은 필수입니다." });
                }

                tabGbn = push.item1;
            }
            else if (push.push_gbn == "21")
            {
                if (string.IsNullOrEmpty(push.item1))
                {
                    return Ok(new { code = "99", msg = "이벤트공지 글번호는 필수입니다." });
                }

                boardSeq = push.item1;
            }
            else if (push.push_gbn == "22")
            {
                //가맹점코드는 비울수 있다
                shopCode = push.item1;
            }
            else if (push.push_gbn == "23")
            {
                if (string.IsNullOrEmpty(push.item1))
                {
                    return Ok(new { code = "99", msg = "변경안 코드는 필수입니다." });
                }

                changeSeq = push.item1;
            }
            else if (push.push_gbn == "5")
            {
                // 관리앱 입력은 안됨
            }
            else
            {
                return Ok(new { code = "99", msg = "잘못된 푸시구분입니다." });
            }

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PUSH.SET_PUSH",
            };

            cmd.Parameters.Add("in_push_cd", OracleDbType.Int32).Value = push.push_cd;
            cmd.Parameters.Add("in_push_gbn", OracleDbType.Varchar2,2).Value = push.push_gbn;
            cmd.Parameters.Add("in_push_title", OracleDbType.Varchar2, 200).Value = push.push_title;
            cmd.Parameters.Add("in_reserve_send_dt", OracleDbType.Varchar2, 20).Value = push.reserve_send_dt;
            cmd.Parameters.Add("in_send_gbn", OracleDbType.Varchar2, 2).Value = push.send_gbn;
            cmd.Parameters.Add("in_boardseq", OracleDbType.Int32).Value = string.IsNullOrEmpty(boardSeq)? null : boardSeq;
            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 20).Value = shopCode;
            cmd.Parameters.Add("in_change_seq", OracleDbType.Int32).Value = string.IsNullOrEmpty(changeSeq) ? null : changeSeq;
            cmd.Parameters.Add("in_tab_gbn", OracleDbType.Varchar2, 10).Value = tabGbn;
            cmd.Parameters.Add("in_object_gbn", OracleDbType.Varchar2, 1).Value = push.object_gbn;
            cmd.Parameters.Add("in_range_gbn", OracleDbType.Varchar2, 1).Value = push.range_gbn;
            cmd.Parameters.Add("in_marketing_push_gbn", OracleDbType.Varchar2, 1).Value = push.marketing_push_gbn;
            cmd.Parameters.Add("in_push_msg", OracleDbType.Varchar2, 500).Value = push.push_msg;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = push.ucode;

            if (push.telno.Count() == 0)
            {
                push.telno = new[] { "" };
            }

            var telno = cmd.Parameters.Add("in_telno", OracleDbType.Varchar2, 20);
            telno.Direction = ParameterDirection.Input;
            telno.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            telno.Value = push.telno.ToArray();
            telno.Size = push.telno.Count();
            telno.ArrayBindSize = push.telno.Select(_ => _.Length).ToArray();
            telno.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, push.telno.Count()).ToArray();

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Push/updatePush : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        #region[기존 푸시수정]
        //[HttpPut("updatePush")]
        //public async Task<IActionResult> updatePush(Push push)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;
        //    string boardSeq = string.Empty;
        //    string shopCode = string.Empty;
        //    string changeSeq = string.Empty;
        //    string tabGbn = string.Empty;

        //    if (string.IsNullOrEmpty(push.ucode))
        //    {
        //        return Ok(new { code = "99", msg = "작업자코드는 필수입니다." });
        //    }

        //    if (string.IsNullOrEmpty(push.reserve_send_dt))
        //    {
        //        return Ok(new { code = "99", msg = "발송일자는 필수입니다." });
        //    }

        //    if (string.IsNullOrEmpty(push.send_gbn))
        //    {
        //        return Ok(new { code = "99", msg = "발송시점은 필수입니다." });
        //    }

        //    if (string.IsNullOrEmpty(push.object_gbn))
        //    {
        //        return Ok(new { code = "99", msg = "대상구분은 필수입니다." });
        //    }

        //    if (string.IsNullOrEmpty(push.push_gbn))
        //    {
        //        return Ok(new { code = "99", msg = "푸시구분은 필수항목입니다." });
        //    }
        //    else if (push.push_gbn == "5")
        //    {
        //        // 관리앱 입력은 안됨
        //        if (string.IsNullOrEmpty(push.item1))
        //        {
        //            return Ok(new { code = "99", msg = "탭 구분은 필수입니다." });
        //        }

        //        tabGbn = push.item1;
        //    }
        //    else if (push.push_gbn == "21")
        //    {
        //        if (string.IsNullOrEmpty(push.item1))
        //        {
        //            return Ok(new { code = "99", msg = "이벤트공지 글번호는 필수입니다." });
        //        }

        //        boardSeq = push.item1;
        //    }
        //    else if (push.push_gbn == "22")
        //    {
        //        //가맹점코드는 비울수 있다
        //        shopCode = push.item1;
        //    }
        //    else if (push.push_gbn == "23")
        //    {
        //        if (string.IsNullOrEmpty(push.item1))
        //        {
        //            return Ok(new { code = "99", msg = "변경안 코드는 필수입니다." });
        //        }

        //        changeSeq = push.item1;
        //    }
        //    else if (push.push_gbn == "5")
        //    {
        //        // 관리앱 입력은 안됨
        //    }
        //    else
        //    {
        //        return Ok(new { code = "99", msg = "잘못된 푸시구분입니다." });
        //    }


        //    using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

        //    DynamicParameters param = new DynamicParameters();
        //    param.Add("push_cd", push.push_cd);
        //    param.Add("push_title", push.push_title);
        //    param.Add("push_gbn", push.push_gbn);
        //    param.Add("reserve_send_dt", push.reserve_send_dt);
        //    param.Add("send_gbn", push.send_gbn);
        //    param.Add("push_gbn", push.push_gbn); //이벤트 및 광고
        //    param.Add("boardseq", boardSeq);
        //    param.Add("shopCode", shopCode);
        //    param.Add("changeSeq", changeSeq);
        //    param.Add("tabGbn", tabGbn);
        //    param.Add("object_gbn", push.object_gbn);
        //    param.Add("range_gbn", push.range_gbn);
        //    param.Add("marketing_push_gbn", push.marketing_push_gbn);
        //    param.Add("push_msg", push.push_msg);
        //    param.Add("mod_ucode", push.ucode);

        //    string sql = string.Empty;
        //    int num = 0;

        //    db.Open();

        //    using var transaction = db.BeginTransaction();

        //    try
        //    {
        //        //기존 발송 예약시간과 겹치는 건이 있는지 체크(한 인터벌에 한건만 보내야함) push_cd별 스레드 분기로 처리하기로 함
        //        sql = @$"
        //                select count(*)
        //                from push_settings
        //                where push_cd <> :push_cd
        //                AND reserve_send_dt = :reserve_send_dt
        //                AND send_gbn = :send_gbn
        //                ";

        //        int n = await db.ExecuteScalarAsync<int>(sql, param);

        //        if (n > 0)
        //        {
        //            return Ok(new { code = "50", msg = "동일한 시간의 발송건이 이미 존재합니다." });
        //        }

        //        //csv 파일의 telno값이 새로 들어온 경우 push_log 데이터를 지우고 다시 쓴다.
        //        if (push.object_gbn.Equals("C") && push.telno.Count() != 0)
        //        {
        //            sql = $@"
        //                    delete from push_log
        //                    where push_cd = :push_cd
        //                    ";

        //            await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

        //            // push_log_deleted에서도 지워주지 않으면 발송후 삭제건과 섞이기 때문에 완전제거 필요
        //            sql = $@"
        //                        delete from push_log_deleted
        //                        where push_cd = :push_cd
        //                    ";

        //            await db.ExecuteAsync(sql, param, commandType: CommandType.Text);


        //            foreach (var tel in push.telno)
        //            {

        //                sql = $@"
        //                        select count(*)
        //                        from app_customer
        //                        where mcode = 2
        //                        and test_gbn = 'R'
        //                        and use_gbn = '1'
        //                        and telno = '{tel}'
        //                ";

        //                num = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

        //                if (num == 0)
        //                {
        //                    //해당 전화번호는 회원이 아닙니다 로그 기록
        //                    sql = $@"
        //                        insert into push_log(cust_telno, push_cd, succesed_yn, send_result)
        //                        values('{tel}', :push_cd, 'N', '해당 전화번호는 회원이 아닙니다.')
        //                        ";

        //                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
        //                }
        //                else
        //                {
        //                    //회원인경우
        //                    sql = $@"
        //                        insert into push_log(cust_code, cust_telno, fcm_id, device_gbn, push_cd)
        //                        select cust_code, telno, fcm_id, device_gbn, :push_cd
        //                        from app_customer
        //                        where mcode = 2
        //                        and test_gbn = 'R'
        //                        and use_gbn = '1'
        //                        and telno = '{tel}'
        //                        ";

        //                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
        //                }
        //            }

        //            //대상건수 업데이트
        //            sql = $@"
        //                   select count(*) from push_log where push_cd = :push_cd    
        //                ";
        //            int cnt = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

        //            param.Add("cnt", cnt);

        //            sql = $@"
        //                   update push_settings set target_cnt = :cnt where push_cd = :push_cd    
        //                ";
        //            await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

        //        }
        //        else if (push.object_gbn.Equals("D"))
        //        {
        //            //대상이 db인 경우만 추가 발송조건이 있다고 본다
        //            //대상구분, 마케팅 동의 구분, 발송범위 구분 중 하나라도 수정된 경우 push_log 데이터를 지우고 다시 쓴다.
        //            sql = $@"
        //                select count(*)
        //                from push_settings
        //                where push_cd = :push_cd
        //                and object_gbn = :object_gbn
        //                and range_gbn = :range_gbn
        //                and marketing_push_gbn = :marketing_push_gbn
        //                ";

        //            num = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

        //            if (num == 0)
        //            {
        //                sql = $@"
        //                        delete from push_log
        //                        where push_cd = :push_cd
        //                    ";

        //                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

        //                // push_log_deleted에서도 지워주지 않으면 발송후 삭제건과 섞이기 때문에 완전제거 필요
        //                sql = $@"
        //                        delete from push_log_deleted
        //                        where push_cd = :push_cd
        //                    ";

        //                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

        //                sql = $@"
        //                  insert into push_log(cust_code, cust_telno, fcm_id, device_gbn, push_cd)
        //                    select cust_code, telno, fcm_id, device_gbn, :push_cd
        //                    from (select /*+ full(app_customer) parallel(app_customer 4)*/ distinct a.fcm_id,
        //                           first_value(a.cust_code) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) cust_code, -- (범위조건이 전체일 경우 회원 우선) 마지막 로그인 시간 우선
        //                           first_value(a.telno) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) telno,
        //                           first_value(a.device_gbn) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) device_gbn
        //                    from app_customer a, app_customer_add b
        //                                            where a.cust_code = b.cust_code (+)
        //                                            and a.mcode = 2
        //                                            and a.test_gbn = 'R'
        //                                            and a.use_gbn = '1'
        //                                            and a.device_gbn is not null
        //                                            and a.fcm_id is not null
        //                                            and a.last_login_time is not null
        //                                            and case when :marketing_push_gbn = 'Y' then nvl(b.push_event_yn, a.push_marketing_yn) else 'Y' end = 'Y'
        //                                            and case when :range_gbn = 'M' then a.cust_id_gbn else '1' end <> 'Z'
        //                                            and case when :range_gbn = 'N' then a.cust_id_gbn else 'Z' end = 'Z'
        //                                            and :range_gbn = 'N' 
        //                                            and a.fcm_id not in (select fcm_id from app_customer -- 범위조건이 비회원만일 경우 회원인 fcm_id가 있으면 제외
        //                                                                where mcode = 2
        //                                                                and test_gbn = 'R'
        //                                                                and use_gbn = '1'
        //                                                                and device_gbn is not null
        //                                                                and fcm_id is not null
        //                                                                and case when :range_gbn = 'N' then cust_id_gbn else 'Z' end <> 'Z')
        //                        union all
        //                        select /*+ full(app_customer) parallel(app_customer 4)*/ distinct a.fcm_id,
        //                           first_value(a.cust_code) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) cust_code, -- (범위조건이 전체일 경우 회원 우선) 마지막 로그인 시간 우선
        //                           first_value(a.telno) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) telno,
        //                           first_value(a.device_gbn) over (partition by a.fcm_id order by (case when a.cust_id_gbn = 'Z' then 'Z' else 'A' end), a.last_login_time desc) device_gbn
        //                    from app_customer a, app_customer_add b
        //                                            where a.cust_code = b.cust_code (+)
        //                                            and a.mcode = 2
        //                                            and a.test_gbn = 'R'
        //                                            and a.use_gbn = '1'
        //                                            and a.device_gbn is not null
        //                                            and a.fcm_id is not null
        //                                            and a.last_login_time is not null
        //                                            and case when :marketing_push_gbn = 'Y' then nvl(b.push_event_yn, a.push_marketing_yn) else 'Y' end = 'Y'
        //                                            and case when :range_gbn = 'M' then a.cust_id_gbn else '1' end <> 'Z'
        //                                            and case when :range_gbn = 'N' then a.cust_id_gbn else 'Z' end = 'Z'
        //                                            and :range_gbn IN ('M','A') )
        //                ";

        //                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

        //                //대상건수 업데이트
        //                sql = $@"
        //                   select count(*) from push_log where push_cd = :push_cd    
        //                ";
        //                int cnt = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

        //                param.Add("cnt", cnt);

        //                sql = $@"
        //                   update push_settings set target_cnt = :cnt where push_cd = :push_cd    
        //                ";
        //                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
        //            }
        //        }

        //        //마지막으로 세팅 수정
        //        sql = @"
        //                    update push_settings
        //                    set push_title = :push_title,
        //                        push_gbn = :push_gbn,
        //                        reserve_send_dt = :reserve_send_dt,
        //                        send_gbn = :send_gbn,
        //                        boardseq = :boardseq,
        //                        shop_cd = :shopCode,
        //                        tos_seq = :changeSeq,
        //                        tab_gbn = :tabGbn,
        //                        object_gbn = :object_gbn,
        //                        range_gbn = :range_gbn,
        //                        marketing_push_gbn = :marketing_push_gbn,
        //                        push_msg = :push_msg,
        //                        mod_ucode = :mod_ucode,
        //                        mod_date = sysdate
        //                    where push_cd = :push_cd
        //                ";

        //        await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

        //        transaction.Commit();

        //        db.Close();

        //        Rcode = "00";
        //        Rmsg = "성공";
        //    }
        //    catch (Exception ex)
        //    {
        //        transaction.Rollback();
        //        Rcode = "99";
        //        Rmsg = ex.Message;
        //        await Utils.SaveErrorAsync("/Push/updatePush : Put", ex.Message);
        //    }


        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}
        #endregion[기존 푸시수정]

        /// <summary>
        /// 푸시 삭제
        /// </summary>
        [HttpDelete("deletePush")]
        public async Task<IActionResult> deletePush(string push_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PUSH.DELETE_PUSH",
            };

            cmd.Parameters.Add("in_push_cd", OracleDbType.Int32).Value = push_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Push/deletePush : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 푸시 생성전 대상건수 조회(db조회의 경우)
        /// </summary>
        /// <remarks>
        /// range_gbn : 발송 범위 구분 (M: 회원만, N: 비회원만, A: 전체)
        /// marketing_push_gbn : 마케팅 동의 구분 (Y: 마케팅 동의만, N: 구분없음[전체])
        /// </remarks>
        [HttpGet("getPushCount")]
        public async Task<IActionResult> getPushCount(string range_gbn, string marketing_push_gbn )
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            int num = 0; 

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("range_gbn", range_gbn);
            param.Add("marketing_push_gbn", marketing_push_gbn);

            db.Open();

            try
            {
                
                string sql = @"
                                select count(distinct fcm_id)
                                from(select /*+ full(app_customer) parallel(app_customer 4)*/ fcm_id,
                                                nvl(b.push_event_yn, a.push_marketing_yn) marketing_yn
                                    from app_customer a, app_customer_add b
                                                    where a.cust_code = b.cust_code (+)
                                                    and a.mcode = 2
                                                    and a.test_gbn = 'R'
                                                    and a.use_gbn = '1'
                                                    and a.device_gbn is not null
                                                    and a.fcm_id is not null
                                                    and a.last_login_time is not null
                                                    --and case when :marketing_push_gbn = 'Y' then nvl(b.push_event_yn, a.push_marketing_yn) else 'Y' end = 'Y'
                                                    and case when :range_gbn = 'M' then a.cust_id_gbn else '1' end <> 'Z'
                                                    and case when :range_gbn = 'N' then a.cust_id_gbn else 'Z' end = 'Z'
                                                    and :range_gbn = 'N' 
                                                    and fcm_id not in (select fcm_id from app_customer -- 범위조건이 비회원만일 경우 회원인 fcm_id가 있으면 제외
                                                                        where mcode = 2
                                                                        and test_gbn = 'R'
                                                                        and use_gbn = '1'
                                                                        and fcm_id is not null
                                                                        and case when :range_gbn = 'N' then cust_id_gbn else 'Z' end <> 'Z')
                                    union all
                                    select /*+ full(app_customer) parallel(app_customer 4)*/ fcm_id,
                                           nvl(b.push_event_yn, a.push_marketing_yn) marketing_yn
                                    from app_customer a, app_customer_add b
                                                    where a.cust_code = b.cust_code (+)
                                                    and a.mcode = 2
                                                    and a.test_gbn = 'R'
                                                    and a.use_gbn = '1'
                                                    and a.device_gbn is not null
                                                    and a.fcm_id is not null
                                                    and a.last_login_time is not null
                                                    --and case when :marketing_push_gbn = 'Y' then nvl(b.push_event_yn, a.push_marketing_yn) else 'Y' end = 'Y'
                                                    and case when :range_gbn = 'M' then a.cust_id_gbn else '1' end <> 'Z'
                                                    and case when :range_gbn = 'N' then a.cust_id_gbn else 'Z' end = 'Z'
                                                    and :range_gbn IN ('M','A') ) 
                                WHERE case when :marketing_push_gbn = 'Y' then marketing_yn else 'Y' end = 'Y'
                        ";

                num = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Push/getPushCount : Get", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg, count = num });
        }


        /// <summary>
        /// 푸시 결과 log 출력
        /// </summary>
        [HttpGet("TxtExport")]
        public async Task<IActionResult> TxtExport(string push_cd, string ucode)
        {
            string Rposition = "/Push/TxtExport : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            string txt = string.Empty;
            List<PushLog> items = new List<PushLog>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_push_cd", push_cd);


                string sql = $@"
                                  Select to_char(to_date(b.reserve_send_dt ,'YYYYMMDDHH24MI'),'YYYY-MM-DD') as st_date, 
                                            to_char(c.hist_date,'YYYY-MM-DD HH24:MI:SS ::') || ' cust_code:' || a.cust_code || '|telno:' || a.cust_telno  || '|result:' 
                                           || case when a.succesed_yn = 'N' then 'N' 
                                                   when b.status = '20' then 'Y' end
                                           || '|msg:' || a.send_result as txt
                                    from push_log a, push_settings b, (select push_cd, hist_date from push_settings_hist where memo = '푸쉬 발송 처리 완료 [처리자 : SYSTEM]' ) c
                                    where a.push_cd = b.push_cd 
                                    and a.push_cd =  :in_push_cd
                                    and a.push_cd = c.push_cd (+)
                                    union all
                                    Select to_char(to_date(b.reserve_send_dt ,'YYYYMMDDHH24MI'),'YYYY-MM-DD') as st_date, 
                                            to_char(c.hist_date,'YYYY-MM-DD HH24:MI:SS ::') || ' cust_code:' || a.cust_code || '|telno:' || a.cust_telno  || '|result:' 
                                           || case when a.succesed_yn = 'N' then 'N' 
                                                   when b.status = '20' then 'Y' end
                                           || '|msg:' || a.send_result as txt
                                    from push_log_deleted a, push_settings b, (select push_cd, hist_date from push_settings_hist where memo = '푸쉬 발송 처리 완료 [처리자 : SYSTEM]' ) c
                                    where a.push_cd = b.push_cd 
                                    and a.push_cd =  :in_push_cd
                                    and a.push_cd = c.push_cd (+)
                                ";

                db.Open();

                var result = await db.QueryAsync<PushLog>(sql, param, commandType: CommandType.Text);
                items = result.ToList();
                List<string> items_s = items.ConvertAll<string>(x => x.txt);
                db.Close();


                //다운로드 로그 기록
                //program_info - id 241: 앱 푸시 관리 -> id 244: 앱푸시공지
                await Utils.setPrivacyLog(ucode, "244", "40", push_cd + " - 푸시로그 다운로드", Rposition);


                using (var stream = new MemoryStream())
                {
                    byte[] _data = Encoding.Default.GetBytes(String.Join(Environment.NewLine, items_s.ToArray()));
                    stream.Write(_data, 0, _data.Length);

                    //application/octet-stream
                    return File(stream.ToArray(), "text/plain", $"{items[0].st_date}.txt");
                }

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items});
        }

        /// <summary>
        /// 푸시관리 변경이력
        /// </summary>
        /// <remarks>
        /// NO : 조회순서 <br/>
        /// SEQ : PUSH_SETTINGS_HIST PK값 <br/>
        /// HIST_DATE : 변경일시 <br/>
        /// MEMO : 변경내용
        /// </remarks>
        [HttpGet("getHist")]
        public async Task<IActionResult> getHist(string push_cd, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RCount = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("push_cd", push_cd);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT *
                                FROM (select to_char(ROWNUM) as NO, T1.*
                                from(select to_char(SEQ) seq, HIST_DATE, MEMO
                                from push_settings_hist 
                                where push_cd = :push_cd
                                order by hist_date desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2
                                WHERE ((:in_page - 1) * :in_rows) < NO
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                sql = @" select count(*)
                        from push_settings_hist 
                        where push_cd = :push_cd
                ";

                RCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
        }
    }
}
