﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ChainCouponAppController : ControllerBase
    {
        /// <summary>
        /// 브랜드 쿠폰 앱설정 관리 - 목록 조회
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Get(string chainCode, string couponType, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object RtotalCount = string.Empty;
            object RCount = string.Empty;


            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_chain_code", chainCode);
                param.Add("in_coupon_type", couponType);
                //param.Add("in_coupon_status", status);
                //param.Add("in_keyword", "%" + keyword + "%");
                param.Add("page", page);
                param.Add("row_count", rows);


                string sql = $@"
                                  SELECT nvl(A.CODE_NM,' ') AS COUPON_NAME, nvl(B.CODE_NM,' ') AS CHAIN_NAME, T2.*
                                  FROM (SELECT to_char(ROWNUM) AS RNUM, T1.*
                                          FROM (select nvl(coupon_type,' ') coupon_type,
                                                nvl(chain_code,' ') chain_code,
                                                nvl(to_char(order_min_amt),' ') order_min_amt,
                                                nvl(to_char(pay_min_amt),' ') pay_min_amt,
                                                nvl(delivery_yn,' ') delivery_yn,
                                                nvl(pack_yn,' ') pack_yn,
                                                nvl(display_st_date,' ') display_st_date,
                                                nvl(display_exp_date,' ') display_exp_date,
                                                nvl(use_yn,' ') use_yn
                                                from chain_coupon_info
                                                where coupon_type like case when :in_coupon_type is null then '%' else :in_coupon_type end
                                                and chain_code like case when :in_chain_code is null then '%' else :in_chain_code end
                                                order by display_st_date desc) T1
                                         WHERE ROWNUM <= ((:page - 1) * :row_count) + :row_count) T2, 
                                         (select code, code_nm from etc_code where code_grp = 'BRAND_COUPON') A,
                                         (select code, code_nm from etc_code where code_grp = 'API' AND PGM_GROUP = 'O') B
                                 WHERE ((:page - 1) * :row_count) < RNUM
                                 AND T2.COUPON_TYPE = A.CODE(+)
                                 AND T2.CHAIN_CODE = B.CODE(+)
                                 order by t2.display_st_date desc
                                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();



                var countSql = $@"
                                    select COUNT(*)
                                    from chain_coupon_info
                                    where coupon_type like case when :in_coupon_type is null then '%' else :in_coupon_type end
                                    and chain_code like case when :in_chain_code is null then '%' else :in_chain_code end
                                ";

                RCount = await db.ExecuteScalarAsync<Int64>(countSql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ChainCouponApp : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount.ToString(), data = items });
        }


        //브랜드 쿠폰 세팅 상세 조회
        [HttpGet("{couponType}")]
        public async Task<IActionResult> getDetail(string couponType)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_CHAIN_COUPON_MNG.GET_COUPON_APP_DETAIL",
            };

            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            ChainCouponApp item = new ChainCouponApp();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.coupon_type = rd["coupon_type"].ToString();
                item.coupon_name = rd["coupon_name"].ToString();
                item.chain_code = rd["chain_code"].ToString();
                item.chain_name = rd["chain_name"].ToString();
                item.order_min_amt = rd["order_min_amt"].ToString();
                item.pay_min_amt = rd["pay_min_amt"].ToString();
                item.delivery_yn = rd["delivery_yn"].ToString();
                item.pack_yn = rd["pack_yn"].ToString();
                item.display_st_date = rd["display_st_date"].ToString();
                item.display_st_time = rd["display_st_time"].ToString();
                item.display_exp_date = rd["display_exp_date"].ToString();
                item.display_exp_time = rd["display_exp_time"].ToString();
                item.use_yn = rd["use_yn"].ToString();
                item.ins_date = rd["ins_date"].ToString();
                item.ins_ucode = rd["ins_ucode"].ToString();
                item.ins_name = rd["ins_name"].ToString();
                item.mod_date = rd["mod_date"].ToString();
                item.mod_ucode = rd["mod_ucode"].ToString();
                item.mod_name = rd["mod_name"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ChainCouponApp/{couponType} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }


        /// <summary>
        /// 브랜드 쿠폰 세팅 생성
        /// </summary>
        /// <param name="couponType">쿠폰종류</param>
        /// <param name="chainCode">브랜드코드</param>
        /// <param name="orderMinAmt">최소주문금액</param>
        /// <param name="payMinAmt">최소결제금액</param>
        /// <param name="deliveryYn">배달주문 사용여부(Y/N)</param>
        /// <param name="packYn">포장주문 사용여부(Y/N)</param>
        /// <param name="displayStDate">발급가능시작일</param>
        /// <param name="displayStTime">발급가능시작시간(HH24MISS)</param>
        /// <param name="displayExpDate">발급가능종료일</param>
        /// <param name="displayExpTime">발급가능종료시간(HH24MISS)</param>
        /// <param name="insertUcode">등록자 ucode</param>
        /// <param name="insertName">등록자명</param>
        /// <param name="useYn">사용여부(Y/N)</param>
        [HttpPost]
        public async Task<IActionResult> Post(string couponType, string chainCode,
            string orderMinAmt, string payMinAmt, string deliveryYn, string packYn, string displayStDate, string displayStTime, 
            string displayExpDate, string displayExpTime,
            string insertUcode, string insertName, string useYn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            int cnt = 0;


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_chain_code", chainCode);
                param.Add("in_coupon_type", couponType);
                param.Add("in_order_min_amt", orderMinAmt);
                param.Add("in_pay_min_amt", payMinAmt);
                param.Add("in_delivery_yn", deliveryYn);
                param.Add("in_pack_yn", packYn);
                param.Add("in_display_st_date", displayStDate);
                param.Add("in_display_st_time", displayStTime);
                param.Add("in_display_exp_date", displayExpDate);
                param.Add("in_display_exp_time", displayExpTime);
                //param.Add("in_use_month_day", useMonthDay);
                //param.Add("in_use_week_day", useWeekDay);
                //param.Add("in_qr_data_gbn", QRDataGbn);
                //param.Add("in_link_url", linkUrl);
                //param.Add("in_android_package_name", androidPackageName);
                //param.Add("in_ios_app_id", iosAppId);
                param.Add("in_insert_ucode", insertUcode);
                param.Add("in_insert_name", insertName);
                param.Add("in_use_yn", useYn);


                

                db.Open();

                string sql = $@" select count(*) from chain_coupon_info where coupon_type = :in_coupon_type
                                ";

                cnt = await db.QuerySingleAsync<Int32>(sql, param, commandType: CommandType.Text);

                if (cnt < 1)
                {
                    sql = $@" insert into chain_coupon_info( coupon_type, 
                                                                chain_code, 
                                                                order_min_amt, 
                                                                pay_min_amt, 
                                                                delivery_yn, 
                                                                pack_yn, 
                                                                display_st_date, 
                                                                display_st_time,
                                                                display_exp_date,
                                                                display_exp_time, 
                                                                --use_month_day, 
                                                                --use_week_day, 
                                                                --qr_data_gbn, 
                                                                --link_url, 
                                                                --android_package_name, 
                                                                --ios_app_id, 
                                                                ins_date, 
                                                                ins_ucode, 
                                                                ins_name, 
                                                                use_yn)
                                 values(:in_coupon_type, 
                                        :in_chain_code, 
                                        :in_order_min_amt, 
                                        :in_pay_min_amt, 
                                        :in_delivery_yn, 
                                        :in_pack_yn, 
                                        :in_display_st_date, 
                                        :in_display_st_time, 
                                        :in_display_exp_date, 
                                        :in_display_exp_time, 
                                        --:in_use_month_day, 
                                        --:in_use_week_day, 
                                        --:in_qr_data_gbn, 
                                        --:in_link_url, 
                                        --:in_android_package_name, 
                                        --:in_ios_app_id, 
                                        to_char(SYSDATE,'YYYYMMDD'), 
                                        :in_insert_ucode, 
                                        :in_insert_name, 
                                        :in_use_yn )
                                ";

                    await db.QueryAsync(sql, param, commandType: CommandType.Text);
                }
                else
                {
                    Rcode = "01";
                    Rmsg = "해당 쿠폰타입의 앱 설정은 이미 존재합니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ChainCouponApp : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 브랜드 쿠폰 세팅 수정
        /// </summary>
        /// <param name="couponType">쿠폰종류</param>
        /// <param name="orderMinAmt">최소주문금액</param>
        /// <param name="payMinAmt">최소결제금액</param>
        /// <param name="deliveryYn">배달주문 사용여부(Y/N)</param>
        /// <param name="packYn">포장주문 사용여부(Y/N)</param>
        /// <param name="displayStDate">발급가능시작일</param>
        /// <param name="displayStTime">발급가능시작시간(HH24MISS)</param>
        /// <param name="displayExpDate">발급가능종료일</param>
        /// <param name="displayExpTime">발급가능종료시간(HH24MISS)</param>
        /// <param name="modUcode">수정자 ucode</param>
        /// <param name="modName">수정자명</param>
        /// <param name="useYn">사용여부(Y/N)</param>
        [HttpPut]
        public async Task<IActionResult> Put(string couponType,
            string orderMinAmt, string payMinAmt, string deliveryYn, string packYn, string displayStDate, string displayStTime,
            string displayExpDate, string displayExpTime,
            string modUcode, string modName, string useYn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                //param.Add("in_chain_code", chainCode);
                param.Add("in_coupon_type", couponType);
                param.Add("in_order_min_amt", orderMinAmt);
                param.Add("in_pay_min_amt", payMinAmt);
                param.Add("in_delivery_yn", deliveryYn);
                param.Add("in_pack_yn", packYn);
                param.Add("in_display_st_date", displayStDate);
                param.Add("in_display_st_time", displayStTime);
                param.Add("in_display_exp_date", displayExpDate);
                param.Add("in_display_exp_time", displayExpTime);
                //param.Add("in_use_month_day", useMonthDay);
                //param.Add("in_use_week_day", useWeekDay);
                //param.Add("in_qr_data_gbn", QRDataGbn);
                //param.Add("in_link_url", linkUrl);
                //param.Add("in_android_package_name", androidPackageName);
                //param.Add("in_ios_app_id", iosAppId);
                param.Add("in_mod_ucode", modUcode);
                param.Add("in_mod_name", modName);
                param.Add("in_use_yn", useYn);


                string sql = $@" update chain_coupon_info 
                                        set order_min_amt = :in_order_min_amt, 
                                            pay_min_amt = :in_pay_min_amt, 
                                            delivery_yn = :in_delivery_yn, 
                                            pack_yn = :in_pack_yn, 
                                            display_st_date = :in_display_st_date, 
                                            display_st_time = :in_display_st_time, 
                                            display_exp_date = :in_display_exp_date, 
                                            display_exp_time = :in_display_exp_time, 
                                            --use_month_day = :in_use_month_day, 
                                            --use_week_day = :in_use_week_day, 
                                            --qr_data_gbn = :in_qr_data_gbn, 
                                            --link_url = :in_link_url, 
                                            --android_package_name = :in_android_package_name, 
                                            --ios_app_id = :in_ios_app_id, 
                                            mod_date = SYSDATE, 
                                            mod_ucode = :in_mod_ucode, 
                                            mod_name = :in_mod_name, 
                                            use_yn = :in_use_yn
                                        WHERE coupon_type = :in_coupon_type
                                ";

                db.Open();

                await db.QueryAsync(sql, param, commandType: CommandType.Text);


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ChainCouponApp : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });

        }


        //브랜드 쿠폰 세팅 삭제
        [HttpDelete]
        public async Task<IActionResult> Delete(string couponType)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_coupon_type", couponType);


                string sql = $@" delete chain_coupon_info 
                                WHERE coupon_type = :in_coupon_type
                                ";

                db.Open();

                await db.QueryAsync(sql, param, commandType: CommandType.Text);


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ChainCouponApp : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });

        }

    }
}
