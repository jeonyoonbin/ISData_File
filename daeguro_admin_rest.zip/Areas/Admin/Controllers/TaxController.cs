﻿using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [SwaggerTag("국세청 사업자 조회")]
    //[Produces("application/json")]
    [ApiController]
    public class TaxController : ControllerBase
    {
        /// <summary>
        /// 사업자등록 상태조회
        /// </summary>
        /// <remarks>
        /// 사업자 상태조회 정보 제공. <br />
        /// 국세청 API에서는 100개까지 동시에 조회 되게 되어 있고, 현 시스템에서는 한 개씩 조회하게 되어 있음
        /// <br />
        /// <br />
        /// 결과 값 <br />
        /// b_no : 사업자등록번호 <br />
        /// b_stt : 납세자상태(명칭) 01: 계속사업자, 02: 휴업자, 03: 폐업자 <br />
        /// b_stt_cd : 납세자상태(코드) 01: 계속사업자, 02: 휴업자, 03: 폐업자 <br />
        /// tax_type : 과세유형메세지(명칭) 01:부가가치세 일반과세자, 02:부가가치세 간이과세자, 03:부가가치세 과세특례자, 04:부가가치세 면세사업자, <br />
        /// 05:수익사업을 영위하지 않는 비영리법인이거나 고유번호가 부여된 단체,국가기관 등, 06:고유번호가 부여된 단체, 07:부가가치세 간이과세자(세금계산서 발급사업자), <br />
        /// 등록되지 않았거나 삭제된 경우: "국세청에 등록되지 않은 사업자등록번호입니다"<br />
        /// tax_type_cd : 과세유형메세지(코드) 01:부가가치세 일반과세자, 02:부가가치세 간이과세자, 03:부가가치세 과세특례자, 04:부가가치세 면세사업자,<br />
        /// 05:수익사업을 영위하지 않는 비영리법인이거나 고유번호가 부여된 단체,국가기관 등, 06:고유번호가 부여된 단체, 07:부가가치세 간이과세자(세금계산서 발급사업자) <br />
        /// end_dt : 폐업일 (YYYYMMDD 포맷) <br />
        /// utcc_yn : 단위과세전환폐업여부(Y,N) <br />
        /// tax_type_change_dt : 최근과세유형전환일자 (YYYYMMDD 포맷) <br />
        /// invoice_apply_dt : 세금계산서적용일자 (YYYYMMDD 포맷)
        /// </remarks>
        /// <param name="buss_reg_no">사업자등록 번호</param>
        /// <returns></returns>
        /// 
        // <response code="201">Returns the newly created item</response>
        [HttpGet]
        //[ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> Get(string buss_reg_no)
        {
            HttpClient httpClient = new HttpClient();

            BussRegNoResult bussRegNoResult = new BussRegNoResult();

            try
            {
                //HttpContent httpContent = new StringContent(@$"<map id='ATTABZAA001R08'><pubcUserNo /><mobYn>N</mobYn><inqrTrgtClCd>1</inqrTrgtClCd><txprDscmNo>{buss_reg_no}</txprDscmNo><dongCode>81</dongCode><psbSearch>Y</psbSearch><map id='userReqInfoVO' /></map>");
                //HttpResponseMessage httpResponse = await httpClient.PostAsync(@"https://teht.hometax.go.kr/wqAction.do?actionId=ATTABZAA001R08&screenId=UTEABAAA13&popupYn=false&realScreenId=", httpContent);

                var payload = new BussRegNo
                {
                    b_no = new List<string> { buss_reg_no }
                };

                var stringPayload = JsonConvert.SerializeObject(payload);

                HttpContent httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");

                HttpResponseMessage httpResponse = await httpClient.PostAsync(@$"https://api.odcloud.kr/api/nts-businessman/v1/status?serviceKey={Utils.Data_go_kr_Key}", httpContent);

                string responseStr = await httpResponse.Content.ReadAsStringAsync();

                bussRegNoResult = JsonConvert.DeserializeObject<BussRegNoResult>(responseStr);

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Tax : Get", ex.Message);

                bussRegNoResult.status_code = "99";
            }

            return Ok(bussRegNoResult);
        }
    }
}
