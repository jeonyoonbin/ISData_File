﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ChainController : ControllerBase
    {
        string nasPath = @"\\10.10.10.100\dgnas\Files";
        string logoPath = @"\\10.10.10.100\dgnas\Files\BrandImage";

        /// <summary>
        /// 브랜드명 검색
        /// </summary>
        /// <remarks>
        /// test_yn 테스트여부(Y/N)(필수) <br/>
        /// [response] <br/>
        /// code 코드 <br/>
        /// name 브랜드명 <br/>
        /// use_gbn 사용여부 <br/>
        /// </remarks>
        [HttpGet("getNameList")]
        public async Task<IActionResult> getNameList(string test_yn, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<ChainName> items = new List<ChainName>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_CHAIN_COUPON_MNG.GET_CHAIN_NAME_LIST",
            };

            cmd.Parameters.Add("in_test_yn", OracleDbType.Varchar2, 1).Value = test_yn;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 50).Value = keyword;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ChainName item = new ChainName
                    {
                        code = rd["code"].ToString(),
                        name = rd["code_nm"].ToString(),
                        use_gbn = rd["use_gbn"].ToString(),
                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Chain/getNameList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 브랜드코드 생성 및 로고 업로드
        /// </summary>
        /// <remarks>
        /// chainName : 브랜드명 <br/>
        /// chainColor : 브랜드 배경컬러 <br/>
        /// useGbn : 사용여부(Y/N) <br/>
        /// testYn : 테스트여부(Y/N)
        /// </remarks>
        [HttpPost]
        public async Task<IActionResult> Post(IFormFile formFile, [FromForm]ChainCode chainCode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            string newCode = string.Empty;

            try
            {
                newCode = await setChainCode(chainCode);

                if (newCode.Equals("99"))
                {
                    return Ok(new { code = "99", msg = "브랜드코드 생성에 실패하였습니다.", chainCode = "" });
                }

                if (formFile != null && formFile.Length > 0)
                {
                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        string folerPath = logoPath + "\\" + newCode + ".png";
                        using var stream = System.IO.File.Create(folerPath);

                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();
                    }


                    Rcode = "00";
                    Rmsg = "성공";
                }
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/Chain : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg, chainCode = newCode });
        }


        // 브랜드 코드 생성
        private async Task<string> setChainCode(ChainCode chainCode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            string newCode = string.Empty;
            string logoUrl = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_test_yn", chainCode.testYn);

            //새 브랜드 코드 생성(규칙 : FC_100부터 숫자 1씩 증가)
            //형태가 다른 테스트브랜드를 만들어버려서 제외처리 추가
            string sql = @$"
                            select case when :in_test_yn = 'N' then 'FC_' 
                                    when :in_test_yn = 'Y' then 'FC_T' end || str
                            from(select to_char(substr(max(code),4) + 1) str
                                from etc_code
                                where code_grp = 'API'
                                and pgm_group = 'O'
                                and code like 'FC_%'
                                and code not like 'FC_T%'
                                and :in_test_yn = 'N'
                                union all
                                select lpad(substr(max(code),5) + 1,2,'0') str
                                from etc_code
                                where code_grp = 'API'
                                and pgm_group = 'O'
                                and code like 'FC_T%'
                                and :in_test_yn = 'Y')
                            where str is not null
                        ";

            try
            {
                db.Open();

                newCode = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);
                //로고 경로
                logoUrl = "https://image.daeguro.co.kr:40443/brand/" + newCode + ".png";

                param.Add("in_chain_code", newCode);
                param.Add("in_chain_name", chainCode.chainName);
                param.Add("in_chain_logo", logoUrl);
                param.Add("in_chain_color", chainCode.chainColor);
                param.Add("in_use_gbn", chainCode.useGbn);
                param.Add("in_test_yn", chainCode.testYn);
                param.Add("in_ins_ucode", chainCode.UCode);
                param.Add("in_ins_name", chainCode.UName);

                sql = @$"
                            insert into etc_code(mcode, pgm_group, code_grp, code, code_nm, etc_code_gbn1, etc_code_gbn3, 
                                                use_gbn, ins_date, ins_ucode, ins_name, test_yn)
                            values (0,'O','API', :in_chain_code, :in_chain_name, :in_chain_logo, :in_chain_color,
                                    :in_use_gbn, sysdate, :in_ins_ucode, :in_ins_name, :in_test_yn)
                        ";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();
            }
            catch (Exception ex)
            {
                newCode = "99";
                await Utils.SaveErrorAsync("/Chain : setChainCode", ex.Message);
            }

            return newCode;
        }





    }
}
