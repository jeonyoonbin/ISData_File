﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class BankCodeController : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_BANK_CODE",
            };

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<BankCode> bankCode = new List<BankCode>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while(await rd.ReadAsync())
                {
                    BankCode b = new BankCode();
                    b.bankCode = rd["BANKCODE"].ToString();
                    b.bankName = rd["BANKNAME"].ToString();

                    bankCode.Add(b);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/BackCode/ : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = bankCode });
        }

        //[HttpPost("Dapper2")]
        //public async Task<IActionResult> PostDapper2(string div, string position, string msg)
        //{
        //    string Rmsg = string.Empty;

        //    Stopwatch stopWatch = new Stopwatch();

        //    stopWatch.Start();

        //    using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
        //    db.Open();
        //    DynamicParameters param = new DynamicParameters();
        //    param.Add("div", div);
        //    param.Add("position", position);
        //    param.Add("msg", msg);
        //    await db.ExecuteAsync("INSERT INTO REST_ERROR(DIV, POSITION, MSG, INSERT_TIME) VALUES (:div, :position, :msg, SYSDATE)", param);

        //    stopWatch.Stop();

        //    string Rcode = stopWatch.ElapsedMilliseconds.ToString();


        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}
    }
}
