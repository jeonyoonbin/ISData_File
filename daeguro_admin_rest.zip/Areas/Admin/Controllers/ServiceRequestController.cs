﻿using Dapper;
using ClosedXML.Excel;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Linq;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [ApiController]
    [Route("/[controller]")]
    public class ServiceRequestController : ControllerBase
    {
        string nasPath = @"\\10.10.10.100\dgnas\Files"; 
        string serviceRequestPath = @"\\10.10.10.100\dgnas\Files\RequestServiceImage\CanCellation";

        /// <summary>
        /// 요청구분 목록
        /// </summary>
        /// <remarks>
        /// [response] <br/>
        /// GBN_CODE 요청구분 코드 <br/>
        /// GBN_NAME 요청구분 이름 <br/>
        /// </remarks>
        [HttpGet("getServiceCategory")]
        public async Task<IActionResult> getServiceCategory(string use_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("use_gbn", use_gbn);

                string sql = $@" select gbn_code, gbn_name
                                 from service_req_category
                                 where use_gbn like case when :use_gbn is null then '%' else :use_gbn end
                                 order by gbn_code
                ";

                db.Open();

                Rdata = await db.QueryAsync<object>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ServiceRequest/getServiceGbn : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 요청내용 목록
        /// </summary>
        /// <remarks>
        /// [response] <br/>
        /// GBN_CODE 요청구분 코드 <br/>
        /// CODE 요청구내용 코드 <br/>
        /// CODE_NM 요청내용 이름 <br/>
        /// </remarks>
        [HttpGet("getServiceGbn")]
        public async Task<IActionResult> getServiceGbn(string category, string use_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("category", category);
                param.Add("use_gbn", use_gbn);

                string sql = $@" select gbn_code, type_code code, type_name code_nm
                                from service_req_type
                                where gbn_code like case when :category is null then '%' else :category end
                                and use_gbn like case when :use_gbn is null then '%' else :use_gbn end
                                order by gbn_code, type_code
                ";

                db.Open();

                Rdata = await db.QueryAsync<object>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ServiceRequest/getServiceGbn : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 요청관리 목록조회
        /// </summary>
        /// <remarks>
        /// [parameter] <br/>
        /// mcode 회원사명(필수) <br/>
        /// category 요청구분 <br/>
        /// type 요청내용 <br/>
        /// * 해당 상태 조회여부 <br/>
        /// status_yn_1 접수(Y/N) <br/>
        /// status_yn_2 진행중(Y/N) <br/>
        /// status_yn_3 반려(Y/N) <br/>
        /// status_yn_4 완료(Y/N) <br/>
        /// status_yn_5 취소(Y/N) <br/>
        /// div 검색구분(1. 작업자, 2. 접수자, 3.가맹점명, 4.요청번호, 5.메모) <br/>
        /// keyword 키워드 검색 <br/>
        /// date_begin 시작일(필수) <br/>
        /// date_end 종료일(필수) <br/>
        /// [response] <br/>
        /// SERVICE_GBN 요청구분 <br/>
        /// SERVICE_GBN_CODE 요청구분 코드 <br/>
        /// SERVICE_TYPE 요청내용 <br/>
        /// SERVICE_TYPE_CODE 요청내용 코드 <br/>
        /// COMP_TM 완료일시 <br/>
        /// CANCEL_TM 취소일시 <br/>
        /// ALLOC_UCODE, ALLOC_UNAME 접수자 <br/>
        /// WORKER_UCODE, WORKER_NAME 작업자 <br/>
        /// MEMO 메모 <br/>
        /// ANSWER_TEXT 답변 <br/>
        /// </remarks>
        [HttpGet("")]
        public async Task<IActionResult> Get(string mcode, string category, string type,
                                             string status_yn_1, 
                                             string status_yn_2, 
                                             string status_yn_3, 
                                             string status_yn_4, 
                                             string status_yn_5,  
                                             string div,
                                             string keyword,
                                             string date_begin, string date_end,
                                             string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = string.Empty;
            string RCount = string.Empty;

            if ((div == "3" || div == "5") && !string.IsNullOrEmpty(keyword))// 가맹점명, 메모 검색시만 일부일치검색
            {
                keyword = "%" + keyword + "%";
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("mcode", mcode);
                param.Add("category", category);
                param.Add("type", type);
                param.Add("status_yn_1", status_yn_1);
                param.Add("status_yn_2", status_yn_2);
                param.Add("status_yn_3", status_yn_3);
                param.Add("status_yn_4", status_yn_4);
                param.Add("status_yn_5", status_yn_5);
                param.Add("div", div);
                param.Add("keyword", keyword);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = $@"SELECT t2.*
                              FROM (SELECT ROWNUM AS RNUM,
                                           t1.*
                                    FROM (select to_char(a.seq) seq,
                                       a.insert_date,
                                       b.shop_cd,
                                       b.shop_name,
                                       a.status,
                                       to_char(e.gbn_code) as service_gbn_code,
                                       e.gbn_name as service_gbn,
                                      to_char(d.type_code) as service_type_code,
                                       d.type_name as service_type,
                                       a.cancel_req_yn,
                                       a.comp_tm,
                                       a.cancel_tm,
                                       a.alloc_ucode,
                                       a.alloc_uname,
                                       a.worker_ucode,
                                       a.worker_name,
                                       a.memo,
                                       a.answer_text
                                from service_request a, shop_info b, callcenter c, service_req_type d, service_req_category e
                                where a.shop_cd = b.shop_cd
                                  and b.cccode = c.cccode
                                  and a.service_gbn = d.type_code
                                  and d.gbn_code = e.gbn_code
                                  and c.mcode = :mcode
                                  and e.gbn_code like case when :category is null then '%' else :category end
                                  and a.service_gbn like case when :type is null then '%' else :type end
                                  and (:keyword is null
                                       or
                                       case when :div = '1' then a.worker_name 
                                            when :div = '2' then a.alloc_uname 
                                            when :div = '3' then b.shop_name 
                                            when :div = '4' then to_char(a.seq) 
                                            when :div = '5' then a.memo end like :keyword)
                                  and (case when :status_yn_1  = 'Y' then '10' end = a.status
                                       or
                                       case when :status_yn_2  = 'Y' then '30' end = a.status
                                       or
                                       case when :status_yn_3  = 'Y' then '35' end = a.status
                                       or
                                       case when :status_yn_4  = 'Y' then '40' end = a.status
                                       or
                                       case when :status_yn_5  = 'Y' then '50' end = a.status
                                        )
                                  AND TO_CHAR (a.insert_date, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                  order by a. insert_date desc) t1
                            WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                            WHERE (( :page - 1) * :row_count) < RNUM
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                sql = @$"select count(*)
                                from service_request a, shop_info b, callcenter c, service_req_type d, service_req_category e
                                where a.shop_cd = b.shop_cd
                                  and b.cccode = c.cccode
                                  and a.service_gbn = d.type_code
                                  and d.gbn_code = e.gbn_code
                                  and c.mcode = :mcode
                                  and e.gbn_code like case when :category is null then '%' else :category end
                                  and a.service_gbn like case when :type is null then '%' else :type end
                                  and (:keyword is null
                                       or
                                       case when :div = '1' then a.worker_name 
                                            when :div = '2' then a.alloc_uname 
                                            when :div = '3' then b.shop_name 
                                            when :div = '4' then to_char(a.seq) 
                                            when :div = '5' then a.memo end like :keyword)
                                  and (case when :status_yn_1  = 'Y' then '10' end = a.status
                                       or
                                       case when :status_yn_2  = 'Y' then '30' end = a.status
                                       or
                                       case when :status_yn_3  = 'Y' then '35' end = a.status
                                       or
                                       case when :status_yn_4  = 'Y' then '40' end = a.status
                                       or
                                       case when :status_yn_5  = 'Y' then '50' end = a.status
                                        )
                                  AND TO_CHAR (a.insert_date, 'yyyyMMdd') BETWEEN :date_begin AND :date_end";

                RCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ServiceRequest : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = Rdata });
        }

        /// <summary>
        /// 요청관리 엑셀출력
        /// </summary>
        [HttpGet("ExcelExport")]
        public async Task<IActionResult> ExcelExport(string mcode, string category, string type,
                                             string status_yn_1,
                                             string status_yn_2,
                                             string status_yn_3,
                                             string status_yn_4,
                                             string status_yn_5,
                                             string div,
                                             string keyword,
                                             string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<ServiceRequestExcel> Rdata = new List<ServiceRequestExcel>();
            string RCount = string.Empty;

            if ((div == "3" || div == "5") && !string.IsNullOrEmpty(keyword))// 가맹점명, 메모 검색시만 일부일치검색
            {
                keyword = "%" + keyword + "%";
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("mcode", mcode);
                param.Add("category", category);
                param.Add("type", type);
                param.Add("status_yn_1", status_yn_1);
                param.Add("status_yn_2", status_yn_2);
                param.Add("status_yn_3", status_yn_3);
                param.Add("status_yn_4", status_yn_4);
                param.Add("status_yn_5", status_yn_5);
                param.Add("div", div);
                param.Add("keyword", keyword);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = $@"select to_char(a.seq) seq,
                                       a.insert_date,
                                       b.shop_cd,
                                       b.shop_name,
                                       case when a.status = '10' then '접수(요청)'
                                            when a.status = '30' then '진행중(심사중)'
                                            when a.status = '35' then '보완'
                                            when a.status = '40' then '완료'
                                            when a.status = '50' then '취소' end status,
                                       to_char(e.gbn_code) as service_gbn_code,
                                       e.gbn_name as service_gbn,
                                      to_char(d.type_code) as service_type_code,
                                       d.type_name as service_type,
                                       a.cancel_req_yn,
                                       a.comp_tm,
                                       a.cancel_tm,
                                       a.alloc_ucode,
                                       a.alloc_uname,
                                       a.worker_ucode,
                                       a.worker_name,
                                       a.memo,
                                       a.answer_text
                                from service_request a, shop_info b, callcenter c, service_req_type d, service_req_category e
                                where a.shop_cd = b.shop_cd
                                  and b.cccode = c.cccode
                                  and a.service_gbn = d.type_code
                                  and d.gbn_code = e.gbn_code
                                  and c.mcode = :mcode
                                  and e.gbn_code like case when :category is null then '%' else :category end
                                  and a.service_gbn like case when :type is null then '%' else :type end
                                  and (:keyword is null
                                       or
                                       case when :div = '1' then a.worker_name 
                                            when :div = '2' then a.alloc_uname 
                                            when :div = '3' then b.shop_name 
                                            when :div = '4' then to_char(a.seq) 
                                            when :div = '5' then a.memo end like :keyword)
                                  and (case when :status_yn_1  = 'Y' then '10' end = a.status
                                       or
                                       case when :status_yn_2  = 'Y' then '30' end = a.status
                                       or
                                       case when :status_yn_3  = 'Y' then '35' end = a.status
                                       or
                                       case when :status_yn_4  = 'Y' then '40' end = a.status
                                       or
                                       case when :status_yn_5  = 'Y' then '50' end = a.status
                                        )
                                  AND TO_CHAR (a.insert_date, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                  order by a. insert_date desc
                ";

                db.Open();

                var temp = await db.QueryAsync<ServiceRequestExcel>(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("요청관리목록");
                    var currentRow = 1;
                    var col = 1;

                    worksheet.Cell(currentRow, col++).Value = "요청번호";
                    worksheet.Cell(currentRow, col++).Value = "상태";
                    worksheet.Cell(currentRow, col++).Value = "가맹점코드";
                    worksheet.Cell(currentRow, col++).Value = "가맹점명";
                    worksheet.Cell(currentRow, col++).Value = "요청시간";
                    worksheet.Cell(currentRow, col++).Value = "요청구분";
                    worksheet.Cell(currentRow, col++).Value = "요청내용";
                    worksheet.Cell(currentRow, col++).Value = "완료일시";
                    worksheet.Cell(currentRow, col++).Value = "취소일시";
                    worksheet.Cell(currentRow, col++).Value = "접수자";
                    worksheet.Cell(currentRow, col++).Value = "작업자";
                    worksheet.Cell(currentRow, col++).Value = "메모";
                    worksheet.Cell(currentRow, col++).Value = "답변";

                    foreach (ServiceRequestExcel i in Rdata)
                    {
                        currentRow++;
                        col = 1;

                        worksheet.Cell(currentRow, col++).Value = i.seq;
                        worksheet.Cell(currentRow, col++).Value = i.status;
                        worksheet.Cell(currentRow, col++).Value = i.shop_cd;
                        worksheet.Cell(currentRow, col++).Value = i.shop_name;
                        worksheet.Cell(currentRow, col++).Value = i.insert_date;
                        worksheet.Cell(currentRow, col++).Value = i.service_gbn;
                        worksheet.Cell(currentRow, col++).Value = i.service_type;
                        worksheet.Cell(currentRow, col++).Value = i.comp_tm;
                        worksheet.Cell(currentRow, col++).Value = i.cancel_tm;
                        worksheet.Cell(currentRow, col++).Value = i.alloc_uname;
                        worksheet.Cell(currentRow, col++).Value = i.worker_name;
                        worksheet.Cell(currentRow, col++).Value = i.memo;
                        worksheet.Cell(currentRow, col++).Value = i.answer_text;

                    }

                    worksheet.Columns().AdjustToContents();
                    //worksheet.Rows().AdjustToContents();

                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        return File(content, "application/octet-stream", "service_request.xlsx");
                    }
                }

                db.Close();
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ServiceRequest/ExcelExport : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg});
        }

        /// <summary>
        /// 요청관리 상세조회
        /// </summary>
        [HttpGet("{seq}")]
        public async Task<IActionResult> GetDetail(int seq)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("seq", seq);

                string sql = $@" select a.seq,
                                       a.insert_date,
                                       a.insert_name,
                                       b.shop_cd,
                                       b.shop_name,
                                       b.cccode,
                                       a.status,
                                       a.service_gbn as service_gbn_code,
                                       c.type_name as service_gbn,
                                       a.cancel_req_yn,
                                       a.alloc_ucode,
                                       a.alloc_uname,
                                       a.worker_ucode,
                                       a.worker_name,
                                       a.service_data,
                                       a.answer_text,
                                       a.memo, -- 관리자 조회용
                                       d.kind_shop_memo,
                                       a.mod_date,
                                       a.mod_ucode,
                                       a.mod_name
                                from service_request a, shop_info b, service_req_type c, shop_info_add d
                                where a.shop_cd = b.shop_cd
                                  and a.service_gbn = c.type_code
                                  and b.shop_cd = d.shop_cd
                                  and a.seq = :seq
                ";

                db.Open();

                Rdata = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ServiceRequest/{seq} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 요청처리 상세 변경
        /// </summary>
        /// <remarks>
        /// 완료나 취소로 상태변경시 완료취소일자 저장 추가 <br/>
        /// 착한매장 등록요청(600)의 경우 사용중으로 상태변경 추가 <br/>
        /// </remarks>
        [HttpPut("setDetail")]
        public async Task<IActionResult> setDetail(Request request)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            int num = 0;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SERVICE_REQUEST.SET_DETAIL",
            };

            cmd.Parameters.Add("in_seq", OracleDbType.Int32).Value = request.seq;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 2).Value = request.status;
            cmd.Parameters.Add("in_alloc_ucode", OracleDbType.Int32).Value = int.TryParse(request.alloc_ucode, out num) ? num : null;
            cmd.Parameters.Add("in_alloc_uname", OracleDbType.Varchar2, 50).Value = request.alloc_uname;
            cmd.Parameters.Add("in_worker_ucode", OracleDbType.Int32).Value = int.TryParse(request.worker_ucode, out num)? num : null;
            cmd.Parameters.Add("in_worker_name", OracleDbType.Varchar2, 50).Value = request.worker_name;
            cmd.Parameters.Add("in_answer", OracleDbType.Varchar2, 500).Value = request.answer;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 2000).Value = request.memo;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = request.mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 30).Value = request.mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ServiceRequest/setDetail/{seq} : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        
        }

        /// <summary>
        /// 요청처리 이미지 변경
        /// </summary>
        /// <remarks>
        /// seq : 요청번호 <br/>
        /// insert_dt : 요청일자(파일경로) <br/>
        /// shop_cd : 가맹점코드(파일경로) <br/>
        /// file_name : 파일명(파일경로) <br/>
        /// mod_ucode : 수정자코드 <br/>
        /// mod_name : 수정자명 <br/>
        /// formFile : 변경파일 <br/>
        /// </remarks>
        [HttpPut("updateImg")]
        public async Task<IActionResult> updateImg([FromForm]RequestImg request)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            if (string.IsNullOrEmpty(request.insert_dt) ||
                string.IsNullOrEmpty(request.shop_cd) ||
                string.IsNullOrEmpty(request.file_name))
            {
                Rcode = "99";
                Rmsg = "파일경로는 필수입니다.";

                return Ok(new { code = Rcode, msg = Rmsg });
            }

            if (request.formFile != null && request.formFile.Length > 0)
            {

                using (new ConnectToSharedFolder(nasPath))
                {
                    var url = serviceRequestPath + "\\" + request.insert_dt + "\\" + request.shop_cd + "\\" + request.file_name;
                    // 파일이 이미 존재하면 삭제한다.
                    if (System.IO.File.Exists(url))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        System.IO.File.Delete(url);
                    }
                    else
                    {
                        Rcode = "99";
                        Rmsg = "해당 파일이 존재하지 않습니다.";
                        return Ok(new { code = Rcode, msg = Rmsg });
                    }

                    using var stream = new FileStream(url, FileMode.Create);

                    await request.formFile.CopyToAsync(stream);

                    stream.Close();
                    stream.Dispose();
                }
            }
            else
            {
                Rcode = "99";
                Rmsg = "파일은 필수입니다.";

                return Ok(new { code = Rcode, msg = Rmsg });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("seq", request.seq);
                param.Add("file_name", request.file_name);
                param.Add("mod_ucode", request.mod_ucode);
                param.Add("mod_name", request.mod_name);

                db.Open();

                string sql = $@"update service_request 
                                set mod_ucode = :mod_ucode, 
                                    mod_name = :mod_name, 
                                    mod_date = sysdate
                                    where seq = :seq";

                await db.ExecuteAsync(sql, param);

                sql = $@"INSERT INTO SERVICE_REQ_HIST (SHOP_CD, SERVICE_DATA, MEMO, INS_DATE, SEQ, STATUS, SERVICE_GBN)
                        select shop_cd, service_data, '요청 이미지 교체(' || :file_name || '), 처리자: ' || mod_name || '(' || mod_ucode || ')', mod_date, seq, status, service_gbn
                        from service_request
                        where seq = :seq";

                await db.ExecuteAsync(sql, param);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ServiceRequest/updateImg : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 요청처리 상태 변경
        /// </summary>
        /// <remarks>
        /// 완료나 취소로 상태변경시 완료취소일자 저장 추가
        /// </remarks>
        [HttpPut("setStatus/{seq}")]
        public async Task<IActionResult> setStatus(string seq, string status, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SERVICE_REQUEST.SET_STATUS",
            };

            cmd.Parameters.Add("in_seq", OracleDbType.Int32).Value = seq;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 2).Value = status;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 30).Value = mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ServiceRequest/setStatus/{seq} : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 요청 변경이력 조회
        /// </summary>
        /// <remarks>
        /// [respons] <br/>
        /// no 변경이력 pk <br/>
        /// insertDate 수정일시[Date] <br/>
        /// memo 변경내용 
        /// </remarks>
        [HttpGet("getHistory/{seq}")]
        public async Task<IActionResult> getHistory(string seq)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<HistoryList> items = new List<HistoryList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_REQ.GET_REQ_HIST",
            };

            cmd.Parameters.Add("in_seq", OracleDbType.Int32).Value = seq;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    HistoryList item = new HistoryList
                    {
                        no = rd["hist_seq"].ToString(),
                        insertDate = rd["ins_date"].ToString(),
                        memo = rd["MEMO"].ToString(),

                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ServiceRequest/getHistory/{seq} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }
    }
}
