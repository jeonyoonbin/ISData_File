﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ShopCalcController : ControllerBase
    {
        /// <summary>
        /// 가맹점 정산 계좌 정보 및 자동출금 설정 조회
        /// </summary>
        /// <remarks>
        /// auto_withdraw_use_yn 자동출금 사용여부(Y 사용,N 미사용,X 설정정보 없음:관리앱 자동출금 여부 설정 불가) <br/>
        /// auto_withdraw_dt 자동출금일 설정 정보 <br/>
        /// auto_withdraw_amt 출금 설정금액 (ex: 전액출금, 10,000원)
        /// </remarks>
        [HttpGet("{shop_cd}")]
        public async Task<IActionResult> Get(string shop_cd, string ucode)
        {
            string Rposition = "/ShopCalc/{shop_cd} : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_CALC_INFO",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            ShopCalcGet shop = new ShopCalcGet();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();


                shop.shopCd = rd["SHOP_CD"].ToString();
                shop.bankCode = rd["BANKCODE"].ToString();
                shop.accountNo = rd["ACCOUNT_NO"].ToString();
                shop.accOwner = rd["ACC_OWNER"].ToString();
                shop.payConfirm = rd["PAY_CONFIRM"].ToString();
                shop.autoWithdrawYn = rd["WITHDRAW_USE_YN"].ToString();
                shop.autoWithdrawDt = rd["WITHDRAW_DT"].ToString();
                shop.autoWithdrawAmt = rd["WITHDRAW_AMT"].ToString();
                shop.remainAmt = rd["remain_amt"].ToString();


                await rd.CloseAsync();
                await conn.CloseAsync();

                //조회 로그 기록
                await Utils.setPrivacyLog(ucode, "5", "10", shop.accOwner + " - 계좌번호, 예금주명", Rposition);

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = shop });
        }

        /// <summary>
        /// 가맹점 계좌정보 수정 및 자동출금 사용여부 수정
        /// </summary>
        [HttpPut]
        public async Task<IActionResult> Put(ShopCalc shop)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.UPDATE_CALC_INFO",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop.shopCd;
            cmd.Parameters.Add("in_bank_code", OracleDbType.Varchar2, 2).Value = shop.bankCode;
            cmd.Parameters.Add("in_account_no", OracleDbType.Varchar2, 40).Value = shop.accountNo;
            cmd.Parameters.Add("in_acc_owner", OracleDbType.Varchar2, 30).Value = shop.accOwner;
            cmd.Parameters.Add("in_pay_confirm", OracleDbType.Varchar2, 1).Value = shop.payConfirm;
            cmd.Parameters.Add("in_auto_withdraw_yn", OracleDbType.Varchar2, 1).Value = shop.autoWithdrawYn;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = shop.modUCode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 50).Value = shop.modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopCalc : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 정산정보 변경이력(정산계좌 및 자동출금)
        /// </summary>
        /// <remarks>
        /// NO : 조회순서 <br/>
        /// HIST_DATE : 변경일시 <br/>
        /// MEMO : 변경내용
        /// </remarks>
        [HttpGet("getHist")]
        public async Task<IActionResult> getHist(string shop_cd, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RCount = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT *
                                FROM (select to_char(ROWNUM) as NO, T1.*
                                from(select *
                                    from(select hist_date, memo
                                        from shop_info_hist
                                        where memo like '출금%'
                                        and shop_cd = :shop_cd
                                        union all
                                        select hist_date, memo
                                        from SHOP_WITHDRAW_HIST
                                        where shop_cd = :shop_cd)
                                    ORDER BY hist_date desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2
                                WHERE ((:in_page - 1) * :in_rows) < NO
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                sql = @" select COUNT(*)
                        from(select hist_date, memo
                            from shop_info_hist
                            where memo like '출금%'
                            and shop_cd = :shop_cd
                            union all
                            select hist_date, memo
                            from SHOP_WITHDRAW_HIST
                            where shop_cd = :shop_cd)
                ";

                RCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
        }

        [HttpPost("confirm")]
        public async Task<IActionResult> confirm(BankConfirm shop)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string doznUrl = "http://dozn1.insungdata.com:9100/dozn/account/json/";
            string real_doznUrl = "http://dozn2.insungdata.com:9200/dozn/account/json";

            var responseStream = string.Empty;

            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.BaseAddress = new Uri(real_doznUrl);

                httpClient.DefaultRequestHeaders.Add("Accept", "application/json");


                var formDataContent = new MultipartFormDataContent();
                var request = new HttpRequestMessage(HttpMethod.Post, real_doznUrl);


                formDataContent.Add(new StringContent(shop.bankCode), "bankCd");
                formDataContent.Add(new StringContent(shop.accountNo), "accountNo"); //계좌번호
                formDataContent.Add(new StringContent(shop.accOwner), "accountNm"); //예금주명
                formDataContent.Add(new StringContent(shop.accountGb), "accountGb");
                formDataContent.Add(new StringContent(shop.systemGb), "systemGb");
                formDataContent.Add(new StringContent(shop.mcode), "mcode");
                formDataContent.Add(new StringContent(shop.cccode), "cccode");
                formDataContent.Add(new StringContent(shop.ucode), "ucode");

                request.Content = formDataContent;

                var response = await httpClient.PostAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    responseStream = await response.Content.ReadAsStringAsync();
                    //리턴데이터 객체 받기 ★★
                    var result = JsonConvert.DeserializeObject<Dictionary<string,string>>(responseStream);
                    result.TryGetValue("respCd", out Rcode);
                    result.TryGetValue("ret_msg", out Rmsg);
                }
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ShopCalc : Post", ex.Message + " [ mcode: " + shop.mcode +  ",ucode: " + shop.ucode + " ]");
            }

            return Ok(new { code = Rcode, msg = Rmsg});
        }

        /// <summary>
        /// 가맹점 적립금 잔액 계좌이체 출금처리
        /// </summary>
        [HttpPut("withdrawAmt")]
        public async Task<IActionResult> withdrawAmt(string shop_cd, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP_CALC.WITHDRAW_AMT",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopCalc/withdrawAmt : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpPut("Kino_Test")]
        public async Task<IActionResult> Kino_Test(string yn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.KINO_TEST",
            };

            cmd.Parameters.Add("in_yn", OracleDbType.Varchar2, 1).Value = yn;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopCalc/Kino_Test : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
    }
}
