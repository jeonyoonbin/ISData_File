﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class CongratsController : ControllerBase
    {
        //(꽃배달)경조사어 관리

        #region[경조사어 카테고리 관리]
        /// <summary>
        /// 경조사어 카테고리 리스트 조회
        /// </summary>
        /// <remarks>
        /// category_code : 카테고리 코드 <br/>
        /// category_name : 카테고리명 <br/>
        /// use_gbn : 사용유무 <br/>
        /// </remarks>
        [HttpGet("getCategoryList")]
        public async Task<IActionResult> getCategoryList()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<CongratsCategoryList> itmes = new List<CongratsCategoryList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.GET_CATEGORY_LIST",
            };

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    CongratsCategoryList item = new CongratsCategoryList
                    {
                        category_code = rd["category_code"].ToString(),
                        category_name = rd["category_name"].ToString(),
                        use_gbn = rd["use_gbn"].ToString(),
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/getCategoryList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = itmes });
        }

        /// <summary>
        /// 경조사어 카테고리 등록
        /// </summary>
        /// <remarks>
        /// category_name : 카테고리명 <br/>
        /// use_gbn : 사용여부 <br/>
        /// </remarks>
        [HttpPost("setCategory")]
        public async Task<IActionResult> setCategory(string category_name, string use_gbn, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.SET_CATEGORY",
            };

            cmd.Parameters.Add("in_category_name", OracleDbType.Varchar2, 300).Value = category_name;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/setCategory : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 경조사어 카테고리 수정
        /// </summary>
        /// <remarks>
        /// category_code : 카테고리 코드 <br/>
        /// category_name : 카테고리명 <br/>
        /// use_gbn : 사용여부 <br/>
        /// </remarks>
        [HttpPut("updateCategory")]
        public async Task<IActionResult> updateCategory(string category_code, string category_name, string use_gbn, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.UPDATE_CATEGORY",
            };

            cmd.Parameters.Add("in_category_code", OracleDbType.Int32).Value = category_code;
            cmd.Parameters.Add("in_category_name", OracleDbType.Varchar2, 300).Value = category_name;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/updateCategory : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion

        #region[자주쓰는 경조사어 관리]
        /// <summary>
        /// 자주쓰는 경조사어 목록 조회
        /// </summary>
        /// <remarks>
        /// 결과값 <br/>
        /// bookmark_cd : 북마크 코드 <br/>
        /// words_code : 경조사어 코드 <br/>
        /// contents : 경조사어 문구 <br/>
        /// </remarks>
        [HttpGet("getBookmarkList")]
        public async Task<IActionResult> getBookmarkList()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<CongratsBookmarkList> itmes = new List<CongratsBookmarkList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.GET_BOOKMARK_LIST",
            };

            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    CongratsBookmarkList item = new CongratsBookmarkList
                    {
                        category_name = rd["category_name"].ToString(),
                        bookmark_cd = rd["bookmark_cd"].ToString(),
                        words_code = rd["words_code"].ToString(),
                        contents = rd["contents"].ToString(),
                        ins_date = rd["INS_DATE"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["INS_NAME"].ToString(),
                        mod_date = rd["MOD_DATE"].ToString(),
                        mod_ucode = rd["MOD_ucode"].ToString(),
                        mod_name = rd["MOD_NAME"].ToString()
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/getBookmarkList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }

        /// <summary>
        /// 자주쓰는 경조사어 등록용 리스트 조회
        /// </summary>
        /// <remarks>
        /// category_code 카테고리코드(빈값 : 전체)
        /// </remarks>
        [HttpGet("getForBookmarkList")]
        public async Task<IActionResult> getForBookmarkList(string category_code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<CongratsForBkList> items = new List<CongratsForBkList>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_category_code", category_code);

            string sql = @$"
                            select B.category_name, A.words_code, A.contents
                            from CONGRATULATORY_WORDS a, CONGRATULATORY_CATEGORY B
                            where A.CATEGORY_CODE = B.CATEGORY_CODE
                            and a.category_code like nvl(:in_category_code,'%')
                            AND A.words_code not in (select words_code from BOOKMARK_WORDS)
                            order by A.contents
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync<CongratsForBkList>(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 자주쓰는 경조사어 등록
        /// </summary>
        [HttpPost("setBookmark")]
        public async Task<IActionResult> setBookmark(IEnumerable<string> words_code, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.SET_BOOKMARK",
            };

            var arr = cmd.Parameters.Add("in_cd_array", OracleDbType.Int32);
            arr.Direction = ParameterDirection.Input;
            arr.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr.Value = words_code.ToArray();
            arr.Size = words_code.Count();
            arr.ArrayBindSize = words_code.Select(_ => _.Length).ToArray();
            arr.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, words_code.Count()).ToArray();

            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/setBookmark : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 자주쓰는 경조사어 삭제
        /// </summary>
        /// <remarks>
        /// 경조사어코드(words_code) 리스트로 삭제처리
        /// </remarks>
        [HttpDelete("deleteBookmark")]
        public async Task<IActionResult> deleteBookmark(IEnumerable<string> words_code, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.DELETE_BOOKMARK",
            };

            var arr = cmd.Parameters.Add("in_cd_array", OracleDbType.Int32);
            arr.Direction = ParameterDirection.Input;
            arr.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr.Value = words_code.ToArray();
            arr.Size = words_code.Count();
            arr.ArrayBindSize = words_code.Select(_ => _.Length).ToArray();
            arr.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, words_code.Count()).ToArray();

            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/deleteBookmark : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 자주쓰는 경조사어 정렬 수정
        /// </summary>
        [HttpPut("updateBookmarkSort")]
        public async Task<IActionResult> updateBookmarkSort(IEnumerable<string> words_code, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.UPDATE_BOOKMARK_SORT_SEQ",
            };

            var arr = cmd.Parameters.Add("in_cd_array", OracleDbType.Int32);
            arr.Direction = ParameterDirection.Input;
            arr.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr.Value = words_code.ToArray();
            arr.Size = words_code.Count();
            arr.ArrayBindSize = words_code.Select(_ => _.Length).ToArray();
            arr.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, words_code.Count()).ToArray();

            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/updateBookmarkSort : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion

        #region[경조사어 관리]
        /// <summary>
        /// 경조사어 목록 조회
        /// </summary>
        /// <remarks>
        /// PARAMETER <br/>
        /// category_code : 카테고리 코드 <br/>
        /// <br/>
        /// 결과값 <br/>
        /// words_code : 경조사어 코드 <br/>
        /// contents : 경조사어 문구 <br/>
        /// </remarks>
        [HttpGet("getList")]
        public async Task<IActionResult> getList(string category_code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<CongratsList> itmes = new List<CongratsList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.GET_LIST",
            };

            cmd.Parameters.Add("in_category_code", OracleDbType.Int32).Value = category_code;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    CongratsList item = new CongratsList
                    {
                        words_code = rd["words_code"].ToString(),
                        contents = rd["contents"].ToString(),
                        ins_date = rd["INS_DATE"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["INS_NAME"].ToString(),
                        mod_date = rd["MOD_DATE"].ToString(),
                        mod_ucode = rd["MOD_ucode"].ToString(),
                        mod_name = rd["MOD_NAME"].ToString()
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/getList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }

        /// <summary>
        /// 경조사어 등록
        /// </summary>
        /// <remarks>
        /// category_code : 카테고리 코드 <br/>
        /// contents : 경조사어 문구 <br/>
        /// </remarks>
        [HttpPost("setWords")]
        public async Task<IActionResult> setWords(string category_code, string contents, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.SET_WORDS",
            };

            cmd.Parameters.Add("in_category_code", OracleDbType.Int32).Value = category_code;
            cmd.Parameters.Add("in_contents", OracleDbType.Varchar2, 2000).Value = contents;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/setWords : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 경조사어 수정
        /// </summary>
        /// <remarks>
        /// words_code : 경조사어 코드 <br/>
        /// contents : 경조사어 문구 <br/>
        /// </remarks>
        [HttpPut("updateWords")]
        public async Task<IActionResult> updateWords(string words_code, string contents, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.UPDATE_WORDS",
            };

            cmd.Parameters.Add("in_words_code", OracleDbType.Int32).Value = words_code;
            cmd.Parameters.Add("in_contents", OracleDbType.Varchar2, 2000).Value = contents;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/updateWords : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 경조사어 삭제
        /// </summary>
        /// <remarks>
        /// 경조사어 코드(words_code) 리스트로 삭제처리 <br/>
        /// </remarks>
        [HttpDelete("deleteWords")]
        public async Task<IActionResult> deleteWords(IEnumerable<string> words_code, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.DELETE_WORDS",
            };

            var arr = cmd.Parameters.Add("in_cd_array", OracleDbType.Int32);
            arr.Direction = ParameterDirection.Input;
            arr.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr.Value = words_code.ToArray();
            arr.Size = words_code.Count();
            arr.ArrayBindSize = words_code.Select(_ => _.Length).ToArray();
            arr.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, words_code.Count()).ToArray();

            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/deleteWords : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 경조사어 정렬
        /// </summary>
        [HttpPut("updateWordsSort")]
        public async Task<IActionResult> updateWordsSort(IEnumerable<string> words_code, string category_code, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CONGRATS.UPDATE_WORDS_SORT_SEQ",
            };

            var arr = cmd.Parameters.Add("in_cd_array", OracleDbType.Int32);
            arr.Direction = ParameterDirection.Input;
            arr.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr.Value = words_code.ToArray();
            arr.Size = words_code.Count();
            arr.ArrayBindSize = words_code.Select(_ => _.Length).ToArray();
            arr.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, words_code.Count()).ToArray();

            cmd.Parameters.Add("in_category_code", OracleDbType.Int32).Value = category_code;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Congrats/updateWordsSort : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion





    }
}
