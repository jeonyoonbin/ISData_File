﻿using Dapper;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Linq;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading.Tasks;
using System.Collections.Generic;
using DG_App_Rest.Areas.Admin.Models;
using System.IO;
using Microsoft.AspNetCore.Http;
using ImageProcessor;
using ImageProcessor.Imaging.Formats;
using ClosedXML.Excel;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class TermsOfServiceController : ControllerBase
    {
        string voucherPath = @"\\10.10.10.100\dgnas\Files\VoucherImage";
        string voucherCodePath = @"\\10.10.10.100\dgnas\Files\VoucherImage\Code";

        string nasPath = @"\\10.10.10.100\dgnas\Files";

        /// <summary>
        /// 약관변경고지 목록 조회
        /// </summary>
        /// <remarks>
        /// 파라미터 <br/>
        /// service_gbn : 서비스구분 (D: 대구로, M: 쇼핑몰) <br/>
        /// check_gbn : 조회주체구분 (C: 고객, S: 가맹점) <br/>
        ///  <br/>
        /// 결과값 <br/>
        /// change_seq : 변경안 코드 <br/>
        /// service_gbn : 서비스구분 <br/>
        /// check_gbn : 조회주체 구분 <br/>
        /// ins_date : 생성일자 <br/>
        /// change_contents : 변경안 내용(url) <br/>
        /// memo : 메모
        /// </remarks>
        [HttpGet("getTosChangeList")]
        public async Task<IActionResult> getTosChangeList(string service_gbn, string check_gbn, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<TosChangeList> itmes = new List<TosChangeList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_TERMS_OF_SERVICE.GET_TOS_CHANGE_LIST",
            };

            cmd.Parameters.Add("in_service_gbn", OracleDbType.Varchar2, 1).Value = service_gbn;
            cmd.Parameters.Add("in_check_gbn", OracleDbType.Varchar2, 1).Value = check_gbn;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    TosChangeList item = new TosChangeList
                    {
                        change_seq = rd["change_seq"].ToString(),
                        service_gbn = rd["service_gbn"].ToString(),
                        check_gbn = rd["check_gbn"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        change_contents = rd["change_contents"].ToString(),
                        memo = rd["memo"].ToString(),
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/TermsOfService/getTosChangeList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }
    }
}
