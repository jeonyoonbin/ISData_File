﻿using DG_App_Rest.Areas.Admin.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class NaverController : ControllerBase
    {
        [HttpGet]
        public async Task<ResponseNaverGeocode> Geocoding(string address)
        {
            try
            {
                UrlParams urlparams = new UrlParams();
                urlparams.AddParams("query", address);

                HttpRequestMessage header = new HttpRequestMessage()
                {
                    RequestUri = new Uri($"https://naveropenapi.apigw.ntruss.com/map-geocode/v2/geocode{urlparams.ToUrl()}"),
                    Method = HttpMethod.Get
                };
                header.Headers.Add("X-NCP-APIGW-API-KEY-ID", "e1w8riblms");
                header.Headers.Add("X-NCP-APIGW-API-KEY", "8lg43zaIiZBoXkV8CTT1x7Aw0StFKyKf8ddcW8Ul");

                using (HttpClient client = new HttpClient())
                {
                    var result = await client.SendAsync(header);

                    var json = await result.Content.ReadAsStringAsync();

                    var returnObj = JsonConvert.DeserializeObject<ResponseNaverGeocode>(json);

                    return returnObj;
                }
            }
            catch (System.Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        //내부호출용 주소조회
        static public async Task<ResponseNaverGeocode> _Geocoding(string address)
        {
            try
            {
                UrlParams urlparams = new UrlParams();
                urlparams.AddParams("query", address);

                HttpRequestMessage header = new HttpRequestMessage()
                {
                    RequestUri = new Uri($"https://naveropenapi.apigw.ntruss.com/map-geocode/v2/geocode{urlparams.ToUrl()}"),
                    Method = HttpMethod.Get
                };
                header.Headers.Add("X-NCP-APIGW-API-KEY-ID", "e1w8riblms");
                header.Headers.Add("X-NCP-APIGW-API-KEY", "8lg43zaIiZBoXkV8CTT1x7Aw0StFKyKf8ddcW8Ul");

                using (HttpClient client = new HttpClient())
                {
                    var result = await client.SendAsync(header);

                    var json = await result.Content.ReadAsStringAsync();

                    var returnObj = JsonConvert.DeserializeObject<ResponseNaverGeocode>(json);

                    return returnObj;
                }
            }
            catch (System.Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
