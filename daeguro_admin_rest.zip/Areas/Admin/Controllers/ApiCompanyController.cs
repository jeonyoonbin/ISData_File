﻿using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ApiCompanyController : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> Get(string comType, string comGbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<ApiCompanyList> items = new List<ApiCompanyList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MAPPING.GET_API_COMPANY_LIST",
            };

            cmd.Parameters.Add("in_com_type", OracleDbType.Varchar2, 20).Value = comType;
            cmd.Parameters.Add("in_com_gbn", OracleDbType.Varchar2, 20).Value = comGbn;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ApiCompanyList item = new ApiCompanyList
                    {
                        seq = rd["SEQ"].ToString(),
                        companyType = rd["COMPANY_TYPE"].ToString(),
                        companyGbn = rd["COMPANY_GBN"].ToString(),
                        companyName = rd["COMPANY_NAME"].ToString(),
                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ApiCompany : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        [HttpPost]
        public async Task<IActionResult> Post(ApiCompany param)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MAPPING.ADD_API_COMPANY",
            };

            cmd.Parameters.Add("in_com_type", OracleDbType.Varchar2, 20).Value = param.comType;
            cmd.Parameters.Add("in_com_gbn", OracleDbType.Varchar2, 20).Value = param.comGbn;
            cmd.Parameters.Add("in_com_name", OracleDbType.Varchar2, 40).Value = param.comName;
            cmd.Parameters.Add("in_com_token", OracleDbType.Varchar2, 500).Value = param.comToken;
            cmd.Parameters.Add("in_com_auth", OracleDbType.Varchar2, 500).Value = param.comAuth;
            cmd.Parameters.Add("in_user_code", OracleDbType.Varchar2, 10).Value = param.userCode;
            cmd.Parameters.Add("in_user_name", OracleDbType.Varchar2, 40).Value = param.userName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ApiCompany : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpGet("{seq}")]
        public async Task<IActionResult> Get(string seq)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MAPPING.GET_API_COMPANY_DETAIL",
            };

            cmd.Parameters.Add("in_seq", OracleDbType.Int32).Value = seq;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            ApiCompany item = new ApiCompany();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.comType = rd["COMPANY_TYPE"].ToString();
                item.comGbn = rd["COMPANY_GBN"].ToString();
                item.comName = rd["COMPANY_NAME"].ToString();
                item.comToken = rd["COMPANY_TOKEN"].ToString();
                item.comAuth = rd["COMPANY_AUTH"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ApiCompany/seq : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }


        [HttpPut]
        public async Task<IActionResult> Put(ApiCompany param)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MAPPING.UPDATE_API_COMPANY",
            };

            cmd.Parameters.Add("in_seq", OracleDbType.Int32).Value = param.seq;
            cmd.Parameters.Add("in_com_type", OracleDbType.Varchar2, 20).Value = param.comType;
            cmd.Parameters.Add("in_com_gbn", OracleDbType.Varchar2, 20).Value = param.comGbn;
            cmd.Parameters.Add("in_com_name", OracleDbType.Varchar2, 40).Value = param.comName;
            cmd.Parameters.Add("in_com_token", OracleDbType.Varchar2, 500).Value = param.comToken;
            cmd.Parameters.Add("in_com_auth", OracleDbType.Varchar2, 500).Value = param.comAuth;
            cmd.Parameters.Add("in_user_code", OracleDbType.Varchar2, 10).Value = param.userCode;
            cmd.Parameters.Add("in_user_name", OracleDbType.Varchar2, 40).Value = param.userName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ApiCompany : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
    }
}
