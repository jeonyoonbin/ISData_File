﻿using Dapper;
using ClosedXML.Excel;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Linq;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [ApiController]
    [Route("/[controller]")]
    public class ShopController : ControllerBase
    {
        private readonly ILogger<ShopController> _logger;

        //string path = @"c:\Files\";

        public ShopController(ILogger<ShopController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// 가맹점 관리 - 목록 조회
        /// </summary>
        /// <remarks>
        /// 예약여부에서 기존 reserve_yn(예약노출여부)을 shop_type(배달, 포장, 예약)으로 수정<br />
        /// shop_type : Y(shop_type에 9 포함, 예약가능 가맹점), N(shop_type에 9 미포함, 예약 미지원 가맹점)<br/>
        /// reserve_yn : 앱승인(예약) 여부: 빈값(전체)/ Y/ N)<br/>
        /// reser_req_date :(예약 신청 일시) reser_shop_info 테이블에서 조인(2022-06-30 추가) <br/>
        /// shop_cd : 검색조건 추가 <br/>
        /// service_gbn : 검색조건 추가 (빈값 : 전체, 0: 주문, 1: 특별관, 2: 꽃배달) <br/>
        /// child_meal_yn : 아동급식 여부(Y/ N) <br/>
        /// multi_shop_yn : 멀티샵 여부(Y/ N) <br/>
        /// trad_yn : 시장여부(Y:시장, N:가맹점) <br/>
        /// (시장에 속한 가맹점일때) <br/>
        /// m_shop_cd : 시장코드 <br/>
        /// bundle_yn : 장보기여부(장보기여부Y일때 상품, 메뉴 둘다 관리) <br/>
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(int mCode, string cccode, string service_gbn, string keyword, string shop_cd, 
                                             string operator_code, string image_status, string shop_status, string reg_no_yn, string use_yn, 
                                             string app_order_yn, string reserve_yn, string memo_yn, string img_yn, string shop_type, string reg_date, 
                                             string child_meal_yn, string multi_shop_yn, string trad_yn, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            string TotalCount = string.Empty;

            List<ShopList> shops = new List<ShopList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_SHOP_LIST",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mCode;
            cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = cccode;
            cmd.Parameters.Add("in_service_gbn", OracleDbType.Varchar2, 1).Value = service_gbn;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 60).Value = keyword;
            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_operator_code", OracleDbType.Int32).Value = string.IsNullOrEmpty(operator_code)?null:int.Parse(operator_code);
            cmd.Parameters.Add("in_image_status", OracleDbType.Varchar2, 1).Value = image_status;
            cmd.Parameters.Add("in_shop_status", OracleDbType.Varchar2, 2).Value = shop_status;
            cmd.Parameters.Add("in_reg_no_yn", OracleDbType.Varchar2, 1).Value = reg_no_yn;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 1).Value = use_yn;
            cmd.Parameters.Add("in_app_order_yn", OracleDbType.Varchar2, 1).Value = app_order_yn;
            cmd.Parameters.Add("in_reserve_yn", OracleDbType.Varchar2, 1).Value = reserve_yn;
            cmd.Parameters.Add("in_memo_yn", OracleDbType.Varchar2, 1).Value = memo_yn;
            cmd.Parameters.Add("in_img_yn", OracleDbType.Varchar2, 1).Value = img_yn;
            cmd.Parameters.Add("in_shop_type", OracleDbType.Varchar2, 1).Value = shop_type;
            cmd.Parameters.Add("in_reg_date", OracleDbType.Varchar2, 10).Value = reg_date;
            cmd.Parameters.Add("in_child_meal_yn", OracleDbType.Varchar2, 1).Value = child_meal_yn;
            cmd.Parameters.Add("in_multi_shop_yn", OracleDbType.Varchar2, 1).Value = multi_shop_yn;
            cmd.Parameters.Add("in_trad_yn", OracleDbType.Varchar2, 1).Value = trad_yn;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_total_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                TotalCount = cmd.Parameters["out_total_count"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopList s = new ShopList
                    {
                        ccCode = rd["CCCODE"].ToString(),
                        shopCd = rd["SHOP_CD"].ToString(),
                        shopName = rd["SHOP_NAME"].ToString(),
                        serviceGbn = rd["SERVICE_GBN"].ToString(),
                        //addr1 = rd["ADDR1"].ToString(), 모바일only
                        //addr2 = rd["ADDR2"].ToString(), 모바일only
                        regNo = rd["REG_NO"].ToString(),
                        regNoYn = rd["REG_NO_YN"].ToString(),
                        useGbn = rd["USE_GBN"].ToString(),
                        appOrderYn = rd["APP_ORDER_YN"].ToString(),
                        imageStatus = rd["IMAGE_STATUS"].ToString(),
                        shopStatus = rd["SHOP_STATUS"].ToString(),
                        openDate = rd["OPEN_DT"].ToString(),
                        salesmanCode = rd["SALESMAN_CODE"].ToString(),
                        salesmanName = rd["SALESMAN_NAME"].ToString(),
                        operatorCode = rd["OPERATOR_CODE"].ToString(),
                        operatorName = rd["OPERATOR_NAME"].ToString(),
                        absentYn = rd["ABSENT_YN"].ToString(),
                        calcYn = rd["CALC_YN"].ToString(),
                        shopInfoYn = rd["SHOPINFO_YN"].ToString(),
                        menuYn = rd["MENU_YN"].ToString(),
                        deliYn = rd["DELI_YN"].ToString(),
                        tipYn = rd["TIP_YN"].ToString(),
                        saleYn = rd["SALE_YN"].ToString(),
                        basicInfoYn = rd["BASICINFO_YN"].ToString(),
                        isCharged = rd["ISCHARGED"].ToString(),
                        isPosInstalled = rd["POS_INSTALL"].ToString(),
                        isPosLogined = rd["POS_LOGIN"].ToString(),
                        loginTime = rd["LOGIN_TIME"].ToString(),
                        apiComCode = rd["API_COM_CODE"].ToString(),
                        shopImageYn = rd["SHOP_IMAGE_YN"].ToString(),
                        menuComplete = rd["MENU_COMPLETE"].ToString(),
                        franchiseCd = rd["FRANCHISE_CD"].ToString(),
                        reserveYn = rd["RESERVE_YN"].ToString(),
                        reserReqDate = rd["RESER_REQ_DATE"].ToString(),
                        distanceYn = rd["DISTANCE_YN"].ToString(),
                        flowerYn = rd["flower_yn"].ToString(),
                        child_mealYn = rd["child_meal_yn"].ToString(),
                        multi_shop_yn = rd["multi_shop_yn"].ToString(),
                        trad_yn = rd["TRAD_YN"].ToString(),
                        m_shop_cd = rd["M_SHOP_CD"].ToString(),
                        bundle_yn = rd["BUNDLE_YN"].ToString(),
                        
                    };

                    shops.Add(s);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, total_count = TotalCount, count = Rcount, data = shops });
        }


        [HttpGet("{shop_cd}")]
        public async Task<IActionResult> Get(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_SHOP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor_file", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            Shop shop = new Shop();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();


                shop.ccCode = rd["CCCODE"].ToString();
                shop.shopCd = rd["SHOP_CD"].ToString();
                shop.shopName = rd["SHOP_NAME"].ToString();
                shop.telNo = rd["TELNO"].ToString();
                shop.owner = rd["OWNER"].ToString();
                shop.addr1 = rd["ADDR1"].ToString();
                shop.addr2 = rd["ADDR2"].ToString();
                shop.zipCode = rd["ZIP_CODE"].ToString();
                shop.regNo = rd["REG_NO"].ToString();
                shop.useGbn = rd["USE_GBN"].ToString();
                shop.openDate = rd["OPEN_DT"].ToString();
                shop.closedDate = rd["CLOSE_DT"].ToString();
                shop.vBankCd = rd["V_BANK_CD"].ToString();
                shop.vAccount = rd["V_ACCOUNT"].ToString();
                shop.bankCode = rd["BANKCODE"].ToString();
                shop.accountNo = rd["ACCOUNT_NO"].ToString();
                shop.accOwner = rd["ACC_OWNER"].ToString();
                shop.payConfirm = rd["PAY_CONFIRM"].ToString();
                shop.memo = rd["MEMO"].ToString();
                shop.shopId = rd["SHOP_ID"].ToString();
                shop.shopPass = rd["SHOP_PASS"].ToString();
                shop.mobile = rd["MOBILE"].ToString();
                shop.sidoName = rd["SIDO_NAME"].ToString();
                shop.gunguName = rd["GUNGU_NAME"].ToString();
                shop.dongName = rd["DONG_NAME"].ToString();
                shop.destJibun = rd["DEST_JIBUN"].ToString();
                shop.roadDestDong = rd["ROAD_DEST_DONG"].ToString();
                shop.roadDestAddr = rd["ROAD_DEST_ADDR"].ToString();
                shop.roadDestBuilding = rd["ROAD_DEST_BUILDING"].ToString();
                shop.loc = rd["LOC"].ToString();

                await rd.NextResultAsync();

                List<AddFile> addfiles = new List<AddFile>();

                while (await rd.ReadAsync())
                {
                    AddFile f = new AddFile
                    {
                        kind = rd["KIND"].ToString(),
                        fileName = rd["FILE_NAME"].ToString(),
                    };

                    addfiles.Add(f);
                }

                shop.files = addfiles;

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop/shop_cd : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = shop });
        }

        private bool ThumbnailCallback()
        {
            return true;
        }

        //[HttpGet("thumbnail")]
        //public IActionResult GetThumbnail()
        //{
        //    Image.GetThumbnailImageAbort callback = new Image.GetThumbnailImageAbort(ThumbnailCallback);

        //    Image image = new Bitmap("C:\\Files\\45\\1026\\1026_04_117.png");
        //    Image thumbnail = image.GetThumbnailImage(100, 100, callback, new IntPtr());

        //    MemoryStream ms = new MemoryStream();
        //    thumbnail.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);


        //    return File(ms.ToArray(), "image/jpeg");
        //}

        /// <summary>
        /// 가맹점 상태변경
        /// </summary>
        [HttpPut("updateShopStatus")]
        public async Task<IActionResult> updateShopStatus(string shop_cd, string status, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("status", status);
                param.Add("mod_ucode", mod_ucode);
                param.Add("mod_name", mod_name);

                db.Open();
                await db.ExecuteAsync("update shop_info set shop_status = :status, mod_ucode = :mod_ucode, mod_name = :mod_name, mod_date = sysdate where shop_cd = :shop_cd", param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Shop/updateShopStatus : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpPut("updateImageStatus")]
        public async Task<IActionResult> Put(string shop_cd, string status)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.UPDATE_IMAGE_STATUS",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = shop_cd;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 1).Value = status;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpGet("getImageStatus")]
        public async Task<IActionResult> GetImageStatus(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RStatus = string.Empty;


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_IMAGE_STATUS",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = shop_cd;
            cmd.Parameters.Add("out_status", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                RStatus = cmd.Parameters["out_status"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, status = RStatus });
        }

        /// <summary>
        /// 가맹점 목록 엑셀 출력
        /// </summary>
        [HttpGet("ExcelExport")]
        public async Task<IActionResult> ExcelExport(string mcode, string ucode)
        {
            string Rposition = "/Shop/ExcelExport : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            //List<ShopExcel> items = new List<ShopExcel>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.SHOP_EXCEL_EXPORT",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mcode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();


                if (Rcode.Equals("00"))
                {
                    //다운로드 로그 기록
                    await Utils.setPrivacyLog(ucode, "5", "40", "가맹점 엑셀파일 다운로드", Rposition);


                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add("가맹점리스트");
                        var currentRow = 1;
                        var col = 1;

                        //이나연 과장님만 (가맹점 비밀번호)포함 조회

                        worksheet.Cell(currentRow, col++).Value = "대리점";
                        worksheet.Cell(currentRow, col++).Value = "사용";
                        worksheet.Cell(currentRow, col++).Value = "상태";
                        worksheet.Cell(currentRow, col++).Value = "앱승인(주문)";
                        worksheet.Cell(currentRow, col++).Value = "앱승인(예약)";
                        worksheet.Cell(currentRow, col++).Value = "가맹점코드";
                        worksheet.Cell(currentRow, col++).Value = "사업자번호";
                        worksheet.Cell(currentRow, col++).Value = "가맹점명";
                        worksheet.Cell(currentRow, col++).Value = "대표명";
                        worksheet.Cell(currentRow, col++).Value = "휴대폰";
                        worksheet.Cell(currentRow, col++).Value = "전화";
                        worksheet.Cell(currentRow, col++).Value = "등록일(주문)";
                        worksheet.Cell(currentRow, col++).Value = "등록일(예약)";
                        worksheet.Cell(currentRow, col++).Value = "업종1";
                        worksheet.Cell(currentRow, col++).Value = "업종2";
                        worksheet.Cell(currentRow, col++).Value = "업종3";
                        worksheet.Cell(currentRow, col++).Value = "배달";
                        worksheet.Cell(currentRow, col++).Value = "포장";
                        worksheet.Cell(currentRow, col++).Value = "예약";
                        worksheet.Cell(currentRow, col++).Value = "적립금사용";
                        worksheet.Cell(currentRow, col++).Value = "아이디";
                        if (ucode == "28" /*|| ucode == "233"*/)
                        {
                            worksheet.Cell(currentRow, col++).Value = "비밀번호";
                        }
                        worksheet.Cell(currentRow, col++).Value = "적립금잔액";
                        worksheet.Cell(currentRow, col++).Value = "구주소";
                        worksheet.Cell(currentRow, col++).Value = "신주소";
                        worksheet.Cell(currentRow, col++).Value = "시도명";
                        worksheet.Cell(currentRow, col++).Value = "군구명";
                        worksheet.Cell(currentRow, col++).Value = "동명";
                        worksheet.Cell(currentRow, col++).Value = "영업자";
                        worksheet.Cell(currentRow, col++).Value = "오퍼레이터";
                        worksheet.Cell(currentRow, col++).Value = "사용";
                        worksheet.Cell(currentRow, col++).Value = "승인";
                        worksheet.Cell(currentRow, col++).Value = "착한매장";
                        worksheet.Cell(currentRow, col++).Value = "아동급식";
                        worksheet.Cell(currentRow, col++).Value = "POS 설치";
                        worksheet.Cell(currentRow, col++).Value = "POS 로그인";
                        worksheet.Cell(currentRow, col++).Value = "메모";
                        worksheet.Cell(currentRow, col++).Value = "휴점상태";
                        worksheet.Cell(currentRow, col++).Value = "대표이미지";
                        worksheet.Cell(currentRow, col++).Value = "사업자등록증";
                        worksheet.Cell(currentRow, col++).Value = "신분증";
                        worksheet.Cell(currentRow, col++).Value = "통장사본";
                        worksheet.Cell(currentRow, col++).Value = "메뉴등록유무";
                        worksheet.Cell(currentRow, col++).Value = "메뉴완료";
                        worksheet.Cell(currentRow, col++).Value = "이메일";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;
                            col = 1;

                            worksheet.Cell(currentRow, col++).Value = rd["CCNAME"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["USE_GBN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SHOP_STATUS"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["APP_ORDER_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["APP_RESERVE_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SHOP_CD"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["REG_NO"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SHOP_NAME"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["OWNER"].ToString();
                            // 전화번호 맨 앞에 0이 사라지는 현상이 있어서 아래처럼 처리함.
                            worksheet.Cell(currentRow, col++).Value = "'" + rd["MOBILE"].ToString();
                            worksheet.Cell(currentRow, col++).Value = "'" + rd["TELNO"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["OPEN_DT"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["RESER_REQ_DATE"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["ITEM_CD"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["ITEM_CD2"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["ITEM_CD3"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["DELI_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["PACKING_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["RESERVE_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["REMAIN_MINUS_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SHOP_ID"].ToString();
                            if (ucode == "28" /*|| ucode == "233"*/)
                            {
                                worksheet.Cell(currentRow, col++).Value = rd["SHOP_PASS"].ToString();
                            }
                            worksheet.Cell(currentRow, col++).Value = rd["REMAIN_AMT"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["ADDR1"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["ADDR2"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SIDO_NAME"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["GUNGU_NAME"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["DONG_NAME"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SALESMAN_NAME"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["OPERATOR_NAME"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["USE_GBN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["APP_ORDER_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["KIND_SHOP_STATUS"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["CHILD_MEAL_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["POS_INSTALL"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["POS_LOGIN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["MEMO"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["ABSENT_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SHOP_IMAGE_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["BUSS_IMAGE_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["IDCARD_IMAGE_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["BANK_IMAGE_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["MENU_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["MENU_COMPLETE"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["EMAIL"].ToString();

                            // 경로 맨 뒤에 역슬러쉬가 없어야 한다.
                            //using (new ConnectToSharedFolder(Utils.nasPath))
                            //{
                            //    worksheet.Cell(currentRow, 34).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\shop.jpg") ? 'O' : 'X';
                            //    worksheet.Cell(currentRow, 35).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\buss.jpg") ? 'O' : 'X';
                            //    worksheet.Cell(currentRow, 36).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\idcard.jpg") ? 'O' : 'X';
                            //    worksheet.Cell(currentRow, 37).Value = System.IO.File.Exists(Utils.productPath + "\\" + rd["CCCODE"].ToString() + "\\" + rd["SHOP_CD"].ToString() + "\\bank.jpg") ? 'O' : 'X';
                            //}

                        }
                        
                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "shop.xlsx");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpPost]
        public async Task<IActionResult> Post(Shop shop)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.SET_SHOP",
            };

            //cmd.Parameters.Add("in_cccode", OracleDbType.Int32).Value = shop.ccCode == null ? string.Empty : int.Parse(shop.ccCode);
            cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = shop.ccCode;
            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop.shopCd;
            cmd.Parameters.Add("in_shop_name", OracleDbType.Varchar2, 50).Value = shop.shopName;
            cmd.Parameters.Add("in_telno", OracleDbType.Varchar2, 20).Value = shop.telNo;
            cmd.Parameters.Add("in_owner", OracleDbType.Varchar2, 20).Value = shop.owner;
            cmd.Parameters.Add("in_addr1", OracleDbType.Varchar2, 200).Value = shop.addr1;
            cmd.Parameters.Add("in_addr2", OracleDbType.Varchar2, 200).Value = shop.addr2;
            cmd.Parameters.Add("in_zip_code", OracleDbType.Varchar2, 6).Value = shop.zipCode;
            cmd.Parameters.Add("in_reg_no", OracleDbType.Varchar2, 10).Value = shop.regNo;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Char, 1).Value = shop.useGbn;
            cmd.Parameters.Add("in_v_bank_cd", OracleDbType.Varchar2, 2).Value = shop.vBankCd;
            cmd.Parameters.Add("in_v_account", OracleDbType.Varchar2, 40).Value = shop.vAccount;
            cmd.Parameters.Add("in_bankcode", OracleDbType.Varchar2, 2).Value = shop.bankCode;
            cmd.Parameters.Add("in_account_no", OracleDbType.Varchar2, 40).Value = shop.accountNo;
            cmd.Parameters.Add("in_acc_owner", OracleDbType.Varchar2, 30).Value = shop.accOwner;
            cmd.Parameters.Add("in_pay_confirm", OracleDbType.Char, 1).Value = shop.payConfirm;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 200).Value = shop.memo;
            cmd.Parameters.Add("in_shop_id", OracleDbType.Varchar2, 20).Value = shop.shopId;
            cmd.Parameters.Add("in_shop_pass", OracleDbType.Varchar2, 20).Value = shop.shopPass;
            cmd.Parameters.Add("in_mobile", OracleDbType.Varchar2, 20).Value = shop.shopPass;
            cmd.Parameters.Add("in_sido_name", OracleDbType.Varchar2, 20).Value = shop.shopPass;
            cmd.Parameters.Add("in_gungu_name", OracleDbType.Varchar2, 30).Value = shop.shopPass;
            cmd.Parameters.Add("in_dong_name", OracleDbType.Varchar2, 50).Value = shop.shopPass;
            cmd.Parameters.Add("in_dest_jibun", OracleDbType.Varchar2, 20).Value = shop.shopPass;
            cmd.Parameters.Add("in_road_dest_dong", OracleDbType.Varchar2, 300).Value = shop.shopPass;
            cmd.Parameters.Add("in_road_dest_addr", OracleDbType.Varchar2, 300).Value = shop.shopPass;
            cmd.Parameters.Add("in_road_dest_building", OracleDbType.Varchar2, 100).Value = shop.shopPass;
            cmd.Parameters.Add("in_loc", OracleDbType.Varchar2, 200).Value = shop.shopPass;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpPost("setBankConfirm/{shop_cd}")]
        public async Task<IActionResult> setBankConfirm(string shop_cd, string confirmYn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.SET_BANK_CONFIRM",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_acc_confirm_gbn", OracleDbType.Varchar2, 1).Value = confirmYn;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop/setBankConfirm : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpGet("RegNoCheck")]
        public async Task<IActionResult> RegNoCheck(int mcode, string shop_cd, string reg_no)
        {
            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.Text,
                CommandText = "SELECT SF_SHOP_CHECK_REGNO(:in_mcode, :in_shop_cd, :in_reg_no) FROM DUAL",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mcode;
            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_reg_no", OracleDbType.Varchar2, 10).Value = reg_no;


            string Rcode, Rmsg, Rdata;

            try
            {
                await conn.OpenAsync();

                // 함수 값 반환은 여기서 한다 ★★★
                var re = await cmd.ExecuteScalarAsync();

                await conn.CloseAsync();

                Rcode = "00";
                Rmsg = "성공";
                Rdata = re.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop : Get", ex.Message);

                Rcode = "-1";
                Rmsg = ex.Message;
                Rdata = string.Empty;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        [HttpPost("ChargeJoin/{shop_cd}")]
        public async Task<IActionResult> ChargeJoin(string shop_cd, int ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_SHOP_INFOCHARGE.SET_SHOP_CHARGE_JOIN",
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 10).Value = string.Empty;
            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_charge_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop/ChargeJoin : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpGet("history/{shop_cd}")]
        public async Task<IActionResult> GetHistory(string shop_cd, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<HistoryList> items = new List<HistoryList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_SHOP_HISTORY_LIST",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    HistoryList item = new HistoryList
                    {
                        no = rd["RNUM"].ToString(),
                        insertDate = rd["HIST_DATE"].ToString(),
                        memo = rd["MEMO"].ToString(),

                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop/history/{shop_cd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }


        /// <summary>
        /// 주문취소 가맹점 - 목록 조회(기간조건: ORDER_TIME 주문시간)
        /// </summary>
        [HttpGet("getOrderCancelShopList")]
        public async Task<IActionResult> getOrderCancelShopList(string pos_yn, string gungu, string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_ORDER_CANCEL_SHOP_LIST",
            };

            cmd.Parameters.Add("in_pos_yn", OracleDbType.Varchar2, 2).Value = pos_yn;
            cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 20).Value = gungu;
            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_total_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<OrderCancelShop> items = new List<OrderCancelShop>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    OrderCancelShop item = new OrderCancelShop
                    {
                        cccode = rd["CCCODE"].ToString(),
                        shopCd = rd["SHOP_CD"].ToString(),
                        shopName = rd["SHOP_NAME"].ToString(),
                        shopStatus = rd["SHOP_STATUS"].ToString(),
                        telNo = rd["TELNO"].ToString(),
                        posInstall = rd["POS_INSTALL"].ToString(),
                        posLogin = rd["POS_LOGIN"].ToString(),
                        cancelcnt = rd["CANCELCNT"].ToString(),
                        absentYn = rd["ABSENT_YN"].ToString(),
                        totalcnt = rd["TOTALCNT"].ToString(),
                        loginTime = rd["LOGIN_TIME"].ToString(),
                        lastCancelTime = rd["LAST_CANCEL_TIME"].ToString(),
                    };
                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop/getOrderCancelShopList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 주문취소 가맹점 - 목록 엑셀출력(기간조건: ORDER_TIME 주문시간)
        /// </summary>
        [HttpGet("getOrderCancelShopExcel")]
        public async Task<IActionResult> getOrderCancelShopExcel(string pos_yn, string gungu, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_ORDER_CANCEL_SHOP_LIST",
            };

            cmd.Parameters.Add("in_pos_yn", OracleDbType.Varchar2, 2).Value = pos_yn;
            cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 20).Value = gungu;
            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = null;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = null;
            cmd.Parameters.Add("out_total_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<OrderCancelShop> items = new List<OrderCancelShop>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    OrderCancelShop item = new OrderCancelShop
                    {
                        cccode = rd["CCCODE"].ToString(),
                        shopCd = rd["SHOP_CD"].ToString(),
                        shopName = rd["SHOP_NAME"].ToString(),
                        shopStatus = rd["SHOP_STATUS"].ToString(),
                        telNo = rd["TELNO"].ToString(),
                        posInstall = rd["POS_INSTALL"].ToString(),
                        posLogin = rd["POS_LOGIN"].ToString(),
                        cancelcnt = rd["CANCELCNT"].ToString(),
                        absentYn = rd["ABSENT_YN"].ToString(),
                        totalcnt = rd["TOTALCNT"].ToString(),
                        loginTime = rd["LOGIN_TIME"].ToString(),
                        lastCancelTime = rd["LAST_CANCEL_TIME"].ToString(),
                    };
                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("주문취소 가맹점");
                    var currentRow = 1;

                    worksheet.Cell(currentRow, 1).Value = "가맹점코드";
                    worksheet.Cell(currentRow, 2).Value = "가맹점명";
                    worksheet.Cell(currentRow, 3).Value = "가맹점상태";
                    worksheet.Cell(currentRow, 4).Value = "상점전화";
                    worksheet.Cell(currentRow, 5).Value = "POS설치";
                    worksheet.Cell(currentRow, 6).Value = "POS로그인";
                    worksheet.Cell(currentRow, 7).Value = "로그인시간";
                    worksheet.Cell(currentRow, 8).Value = "최종취소시간";
                    worksheet.Cell(currentRow, 9).Value = "취소건수";
                    worksheet.Cell(currentRow, 10).Value = "휴점";
                    worksheet.Cell(currentRow, 11).Value = "총주문건수";

                    foreach (OrderCancelShop cc in items)
                    {
                        currentRow++;

                        worksheet.Cell(currentRow, 1).Value = cc.shopCd;
                        worksheet.Cell(currentRow, 2).Value = cc.shopName;
                        worksheet.Cell(currentRow, 3).Value = cc.shopStatus;
                        worksheet.Cell(currentRow, 4).Value = cc.telNo;
                        worksheet.Cell(currentRow, 5).Value = cc.posInstall;
                        worksheet.Cell(currentRow, 6).Value = cc.posLogin;
                        worksheet.Cell(currentRow, 7).Value = cc.loginTime;
                        worksheet.Cell(currentRow, 8).Value = cc.lastCancelTime;
                        worksheet.Cell(currentRow, 9).Value = cc.cancelcnt;
                        worksheet.Cell(currentRow, 10).Value = cc.absentYn;
                        worksheet.Cell(currentRow, 11).Value = cc.totalcnt;

                    }



                    worksheet.Columns().AdjustToContents();
                    //worksheet.Rows().AdjustToContents();


                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        return File(content, "application/octet-stream", "OrderCancelShop.xlsx");
                    }
                }

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop/getOrderCancelShopExcel : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        //가맹점 해지
        [HttpPut("setContractEnd/{shop_cd}")]
        public async Task<IActionResult> setContractEnd(string shop_cd, string date_end_contract)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("shop_cd", shop_cd);
            param.Add("date_end_contract", date_end_contract);

            try
            {

                db.Open();
                await db.ExecuteAsync($"UPDATE shop_info SET use_gbn = 'N', s_contract_end_dt = :date_end_contract WHERE shop_cd = :shop_cd", param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/shop/contractEnd : Put", ex.Message);

                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 폐업 및 미사용 가맹점 조회
        /// </summary>
        /// <remarks>
        /// mcode : 회원사코드(필수) <br/>
        /// use_gbn : 사용여부 조건(Y/N) <br/>
        /// shop_status : 가맹점 상태 조건(30:운영) <br/>
        /// app_order_yn : 앱승인 여부 조건(Y/N) <br/>
        /// taxpayer_status : 납세자 상태(01: 계속사업자, 02: 휴업자, 03: 폐업자) <br/>
        /// close_ym : 폐업 월(YYYYMM) <br/>
        /// days : 최근 n일전까지의 기간조건(필수) <br/>
        /// no_comp_order : 조회시점으로부터 n일전까지 완료된 주문이 없는 가맹점 여부(Y/N) <br/>
        /// not_login : 조회시점으로부터 n일전까지 접속기록이 없는 가맹점 여부(Y/N) <br/>
        /// page : 페이지 <br/>
        /// row : 갯수 <br/>
        /// <br/>
        /// return data <br/>
        /// tot_cnt 전체기간 총 주문건수 <br/>
        /// comp_cnt 전체기간 총 완료건수 <br/>
        /// cancel_cnt 전체기간 총 취소건수 <br/>
        /// service_gbn 서비스 구분 <br/>
        /// shop_type 가맹점타입(주문,포장,예약) <br/>
        /// open_dt 등록일자 <br/>
        /// absent_yn 운영휴점여부(Y: 운영/N: 휴점) <br/>
        /// </remarks>
        [HttpGet("getShopNotUseList")]
        public async Task<IActionResult> getShopNotUseList(string mcode, string use_gbn, string shop_status, string app_order_yn, string taxpayer_status, string close_st_dt, string close_to_dt, string days, string no_comp_order, string not_login, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            string RtotalCount = string.Empty;


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_DATA_SEARCH.GET_NO_USE_SHOP_LIST",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mcode;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_shop_status", OracleDbType.Varchar2, 2).Value = shop_status;
            cmd.Parameters.Add("in_app_order_yn", OracleDbType.Varchar2, 20).Value = app_order_yn;
            cmd.Parameters.Add("in_taxpayer_status", OracleDbType.Varchar2, 8).Value = taxpayer_status;
            cmd.Parameters.Add("in_close_st_dt", OracleDbType.Varchar2, 8).Value = close_st_dt;
            cmd.Parameters.Add("in_close_to_dt", OracleDbType.Varchar2, 8).Value = close_to_dt;

            cmd.Parameters.Add("in_days", OracleDbType.Varchar2, 8).Value = days;
            cmd.Parameters.Add("in_no_comp_order", OracleDbType.Varchar2, 8).Value = no_comp_order;
            cmd.Parameters.Add("in_not_login", OracleDbType.Varchar2, 8).Value = not_login;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;            
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<ShopNotUse> items = new List<ShopNotUse>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                                
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopNotUse item = new ShopNotUse
                    {
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),
                        shop_status = rd["SHOP_STATUS"].ToString(),
                        remain_amt = rd["REMAIN_AMT"].ToString(),
                        reg_no = rd["REG_NO"].ToString(),
                        taxpayer_status = rd["TAXPAYER_STATUS"].ToString(),
                        taxation_type = rd["TAXATION_TYPE"].ToString(),
                        closure_dt = rd["CLOSURE_DT"].ToString(),
                        tot_cnt = rd["tot_cnt"].ToString(),
                        comp_cnt = rd["comp_cnt"].ToString(),                        
                        cancel_cnt = rd["cancel_cnt"].ToString(),
                        service_gbn = rd["service_gbn"].ToString(),
                        shop_type = rd["shop_type"].ToString(),
                        open_dt = rd["open_dt"].ToString(),
                        absent_yn = rd["absent_yn"].ToString(),                        
                    };
                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Shop/getOrderCancelShopList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, count = Rcount, data = items });
        }

        /// <summary>
        /// 폐업 및 미사용 가맹점 조회 엑셀 출력
        /// </summary>
        [HttpGet("getShopNotUseExcel")]
        public async Task<IActionResult> getShopNotUseExcel(string mcode, string use_gbn, string shop_status, string app_order_yn, string taxpayer_status, string close_st_dt, string close_to_dt, string days, string no_comp_order, string not_login)
        {
            string Rposition = "/Shop/getShopNotUseExcel : Get";
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_DATA_SEARCH.GET_NO_USE_SHOP_LIST",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mcode;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_shop_status", OracleDbType.Varchar2, 2).Value = shop_status;
            cmd.Parameters.Add("in_app_order_yn", OracleDbType.Varchar2, 20).Value = app_order_yn;
            cmd.Parameters.Add("in_taxpayer_status", OracleDbType.Varchar2, 8).Value = taxpayer_status;
            cmd.Parameters.Add("in_close_st_dt", OracleDbType.Varchar2, 8).Value = close_st_dt;
            cmd.Parameters.Add("in_close_to_dt", OracleDbType.Varchar2, 8).Value = close_to_dt;

            cmd.Parameters.Add("in_days", OracleDbType.Varchar2, 8).Value = days;
            cmd.Parameters.Add("in_no_comp_order", OracleDbType.Varchar2, 8).Value = no_comp_order;
            cmd.Parameters.Add("in_not_login", OracleDbType.Varchar2, 8).Value = not_login;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = null;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = null;

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<ShopNotUse> items = new List<ShopNotUse>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                if (Rcode.Equals("00"))
                {

                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add("미사용가맹점리스트");
                        var currentRow = 1;
                        var col = 1;

                        //이나연 과장님만 (가맹점 비밀번호)포함 조회

                        worksheet.Cell(currentRow, col++).Value = "가맹점코드";
                        worksheet.Cell(currentRow, col++).Value = "가맹점명";
                        worksheet.Cell(currentRow, col++).Value = "가맹점 상태";
                        worksheet.Cell(currentRow, col++).Value = "서비스";
                        worksheet.Cell(currentRow, col++).Value = "배달";
                        worksheet.Cell(currentRow, col++).Value = "포장";
                        worksheet.Cell(currentRow, col++).Value = "예약";
                        worksheet.Cell(currentRow, col++).Value = "사업자번호";
                        worksheet.Cell(currentRow, col++).Value = "적립금 잔액";
                        worksheet.Cell(currentRow, col++).Value = "납세자 상태";
                        worksheet.Cell(currentRow, col++).Value = "과세유형 메세지";
                        worksheet.Cell(currentRow, col++).Value = "휴점여부";
                        worksheet.Cell(currentRow, col++).Value = "등록일자";
                        worksheet.Cell(currentRow, col++).Value = "폐업일자";
                        worksheet.Cell(currentRow, col++).Value = "전체주문";
                        worksheet.Cell(currentRow, col++).Value = "완료주문";
                        worksheet.Cell(currentRow, col++).Value = "취소주문";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;
                            col = 1;

                            worksheet.Cell(currentRow, col++).Value = rd["SHOP_CD"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SHOP_NAME"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SHOP_STATUS"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SERVICE_GBN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["DELI_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["PACK_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["RESERVE_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["REG_NO"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["REMAIN_AMT"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["TAXPAYER_STATUS"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["TAXATION_TYPE"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["ABSENT_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["OPEN_DT"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["CLOSURE_DT"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["TOT_CNT"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["COMP_CNT"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["CANCEL_CNT"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "shop.xlsx");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 서비스 목록 조회
        /// </summary>
        [HttpGet("getServiceList")]
        public async Task<IActionResult> getServiceList()
        {
            string Rcode;
            string Rmsg;
            List<ShopService> items = new List<ShopService>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            //param.Add("class_gbn", class_gbn);

            string sql = @$"
                            SELECT SERVICE_GBN,
                                   SERVICE_NAME
                            FROM SHOP_SERVICE_MST
                            ORDER BY SORT_SEQ
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync<ShopService>(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }
    }
}
