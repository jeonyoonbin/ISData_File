﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class MapsController : ControllerBase
    {

        /// <summary>
        /// 가맹점 좌표정보 목록
        /// </summary>
        /// <remarks>
        /// mcode : 회원사 정보 <br/>
        /// app_order_yn : 앱승인 여부(Y/N) <br/>
        /// use_gbn : 사용 여부(Y/N)
        /// </remarks>
        [HttpGet()]
        public async Task<IActionResult> Get(string mcode, string app_order_yn, string use_gbn, string page, string rows)
        {
            string RCount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<Maps> itmes = new List<Maps>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MAPS.GET_LIST",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Varchar2, 1).Value = mcode;
            cmd.Parameters.Add("in_app_order_yn", OracleDbType.Varchar2, 1).Value = app_order_yn;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                RCount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    Maps item = new Maps
                    {
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),
                        gungu_name = rd["GUNGU_NAME"].ToString(),
                        lon = rd["LON"].ToString(),
                        lat = rd["LAT"].ToString()
                };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

               
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Maps : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = itmes });
        }





    }

}
