﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using System.IO;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ShopBasicController : ControllerBase
    {
        string nasPath = @"\\10.10.10.100\dgnas\Files";
        string testImagePath = @"E:\iis\Files\TestImage";
        string productPath = @"\\10.10.10.100\dgnas\Files\ProductImage"; 
        string temaPath = @"\\10.10.10.100\dgnas\Files\OrderTemaImage";
        string testTemaPath = @"E:\iis\Files\TestImage\OrderTemaImage";

        //프렌차이즈 리스트 조회
        [HttpGet("getFranchiseList")]
        public async Task<IActionResult> getFranchiseList()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            string sql = @$"
                            select code, code_nm from etc_code
                            where code_grp = 'API'
                            and pgm_group = 'O'
                            and use_gbn = 'Y'
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 가맹점 기본정보 조회
        /// </summary>
        /// <remarks>
        /// licenseNo 인허가번호 <br/>
        /// sEtcGbn6 브랜드(영양,알러지정보) <br/>
        /// <br/>
        /// 수정불가 조회값 <br/>
        /// taxpayerStatus 납세자상태 <br/>
        /// taxationType 과세유형 <br/>
        /// </remarks>
        [HttpGet("{shop_cd}")]
        public async Task<IActionResult> Get(string shop_cd, string ucode)
        {
            string Rposition = "/ShopBasic/{shop_cd} : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcnt = string.Empty;
            string RcntOk = string.Empty;
            string RcntCancel = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_BASIC_INFO",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cnt", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ok_cnt", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cancel_cnt", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


            GetShopBasic shop = new GetShopBasic();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcnt = cmd.Parameters["out_cnt"].Value.ToString();
                RcntOk = cmd.Parameters["out_ok_cnt"].Value.ToString();
                RcntCancel = cmd.Parameters["out_cancel_cnt"].Value.ToString();

                await rd.ReadAsync();


                shop.ccCode = rd["CCCODE"].ToString();
                shop.shopCd = rd["SHOP_CD"].ToString();
                shop.franchiseCd = rd["FRANCHISE_CD"].ToString();
                shop.sEtcGbn6 = rd["s_etc_gbn6"].ToString();
                shop.shopName = rd["SHOP_NAME"].ToString();
                shop.telNo = rd["TELNO"].ToString();
                shop.email = rd["EMAIL"].ToString();
                shop.owner = rd["OWNER"].ToString();
                shop.bussOwner = rd["BUSS_OWNER"].ToString();
                shop.bussAddr = rd["BUSS_ADDR"].ToString();
                shop.addr1 = rd["ADDR1"].ToString();
                shop.addr2 = rd["ADDR2"].ToString();
                shop.zipCode = rd["ZIP_CODE"].ToString();
                shop.regNo = rd["REG_NO"].ToString();
                shop.sEtcGbn5 = rd["S_ETC_GBN5"].ToString(); //종사업장번호
                shop.useGbn = rd["USE_GBN"].ToString();
                shop.memo = rd["MEMO"].ToString();
                shop.shopId = rd["SHOP_ID"].ToString();
                shop.shopPass = rd["SHOP_PASS"].ToString();
                shop.mobile = rd["MOBILE"].ToString();
                shop.sidoName = rd["SIDO_NAME"].ToString();
                shop.gunguName = rd["GUNGU_NAME"].ToString();
                shop.dongName = rd["DONG_NAME"].ToString();
                shop.destJibun = rd["DEST_JIBUN"].ToString();
                shop.roadDestDong = rd["ROAD_DEST_DONG"].ToString();
                shop.roadDestAddr = rd["ROAD_DEST_ADDR"].ToString();
                shop.roadDestBuilding = rd["ROAD_DEST_BUILDING"].ToString();
                shop.loc = rd["LOC"].ToString();
                shop.apiComCode = rd["API_COM_CODE"].ToString();
                shop.bussShopname = rd["BUSS_SHOPNAME"].ToString();
                shop.bussCon = rd["BUSS_CON"].ToString();
                shop.bussType = rd["BUSS_TYPE"].ToString();
                shop.bussTaxType = rd["BUSS_TAX_TYPE"].ToString();
                shop.salesmanCode = rd["SALESMAN_CODE"].ToString();
                shop.salesmanName = rd["SALESMAN_NAME"].ToString();
                shop.operatorCode = rd["OPERATOR_CODE"].ToString();
                shop.operatorName = rd["OPERATOR_NAME"].ToString();
                shop.contractEndDt = rd["S_CONTRACT_END_DT"].ToString();
                shop.mobileChgCnt = rd["MOBILE_CHG_CNT"].ToString();
                shop.licenseNo = rd["MFDS_LCNS_NO"].ToString();
                shop.taxpayerStatus = rd["taxpayer_status"].ToString();
                shop.taxationType = rd["taxation_type"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

                //조회 로그 기록
                await Utils.setPrivacyLog(ucode, "5", "10", shop.owner + " - 이름, 전화번호, 주소, 이메일주소", Rposition);

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }

            return Ok(new { code = Rcode, msg = Rmsg, cnt = Rcnt, cntOk = RcntOk, cntCancel = RcntCancel, data = shop });
        }

        private async Task<ShopBasic> getShopBasic(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcnt = string.Empty;
            string RcntOk = string.Empty;
            string RcntCancel = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_BASIC_INFO",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cnt", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ok_cnt", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cancel_cnt", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


            ShopBasic shop = new ShopBasic();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcnt = cmd.Parameters["out_cnt"].Value.ToString();
                RcntOk = cmd.Parameters["out_ok_cnt"].Value.ToString();
                RcntCancel = cmd.Parameters["out_cancel_cnt"].Value.ToString();

                await rd.ReadAsync();


                shop.ccCode = rd["CCCODE"].ToString();
                shop.shopCd = rd["SHOP_CD"].ToString();
                shop.franchiseCd = rd["FRANCHISE_CD"].ToString();
                shop.sEtcGbn6 = rd["s_etc_gbn6"].ToString();
                shop.shopName = rd["SHOP_NAME"].ToString();
                shop.telNo = rd["TELNO"].ToString();
                shop.email = rd["EMAIL"].ToString();
                shop.owner = rd["OWNER"].ToString();
                shop.bussOwner = rd["BUSS_OWNER"].ToString();
                shop.bussAddr = rd["BUSS_ADDR"].ToString();
                shop.addr1 = rd["ADDR1"].ToString();
                shop.addr2 = rd["ADDR2"].ToString();
                shop.zipCode = rd["ZIP_CODE"].ToString();
                shop.regNo = rd["REG_NO"].ToString();
                shop.sEtcGbn5 = rd["S_ETC_GBN5"].ToString(); //종사업장번호
                shop.useGbn = rd["USE_GBN"].ToString();
                shop.memo = rd["MEMO"].ToString();
                shop.shopId = rd["SHOP_ID"].ToString();
                shop.shopPass = rd["SHOP_PASS"].ToString();
                shop.mobile = rd["MOBILE"].ToString();
                shop.sidoName = rd["SIDO_NAME"].ToString();
                shop.gunguName = rd["GUNGU_NAME"].ToString();
                shop.dongName = rd["DONG_NAME"].ToString();
                shop.destJibun = rd["DEST_JIBUN"].ToString();
                shop.roadDestDong = rd["ROAD_DEST_DONG"].ToString();
                shop.roadDestAddr = rd["ROAD_DEST_ADDR"].ToString();
                shop.roadDestBuilding = rd["ROAD_DEST_BUILDING"].ToString();
                shop.loc = rd["LOC"].ToString();
                shop.apiComCode = rd["API_COM_CODE"].ToString();
                shop.bussShopname = rd["BUSS_SHOPNAME"].ToString();
                shop.bussCon = rd["BUSS_CON"].ToString();
                shop.bussType = rd["BUSS_TYPE"].ToString();
                shop.bussTaxType = rd["BUSS_TAX_TYPE"].ToString();
                shop.salesmanCode = rd["SALESMAN_CODE"].ToString();
                shop.salesmanName = rd["SALESMAN_NAME"].ToString();
                shop.operatorCode = rd["OPERATOR_CODE"].ToString();
                shop.operatorName = rd["OPERATOR_NAME"].ToString();
                shop.contractEndDt = rd["S_CONTRACT_END_DT"].ToString();
                shop.mobileChgCnt = rd["MOBILE_CHG_CNT"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopBasic/getShopBasic : Get", ex.Message);
            }

            return shop;
        }

        /// <summary>
        /// (구)가맹점 생성
        /// </summary>
        /// <remarks>
        /// franchiseCd 설정시 CHAIN_COUPON_SHOP테이블에 쿠폰별로 값을 밀어넣음 <br/>
        /// (해당 가맹점의 브랜드 쿠폰 사용 설정 생성/default:미사용) <br/>
        /// <br/>
        /// serviceGbn : 서비스 구분(0: 주문, 1: 특별관, 2: 꽃배달) <br/>
        /// addr1(구주소) <br/>
        /// addr2(신주소) <br/>
        /// sidoName(시도) <br/>
        /// gunguName(군구) <br/>
        /// dongName(동) <br/>
        /// destJibun(번지) <br/>
        /// roadDestDong(신주소 동) <br/>
        /// roadDestAddr(신주소 동 뒤의 숫자) <br/>
        /// roadDestBuilding(신주소 건물명) <br/>
        /// loc(상세주소) <br/>
        /// lon,lat(가맹점 위치(gps)) <br/>
        /// <br/>
        /// POS ONLY PARAMETER <br/>
        /// pos_road(도로명) <br/>
        /// pos_hdong(행정동명) <br/>
        /// pos_bdong(법정동명) <br/>
        /// pos_ri(리명)
        /// </remarks>
        [HttpPost("old")]
        public async Task<IActionResult> Post(ShopBasic shop)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RshopCd = string.Empty;
            string RshopId = string.Empty;


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.ADD_BASIC_INFO",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = shop.mCode;
            cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = shop.ccCode;
            cmd.Parameters.Add("in_service_gbn", OracleDbType.Varchar2, 1).Value = shop.serviceGbn;
            cmd.Parameters.Add("in_franchise_cd", OracleDbType.Varchar2, 10).Value = shop.franchiseCd;
            cmd.Parameters.Add("in_shop_name", OracleDbType.Varchar2, 50).Value = shop.shopName;
            cmd.Parameters.Add("in_reg_no", OracleDbType.Varchar2, 10).Value = shop.regNo;
            cmd.Parameters.Add("in_s_etc_gbn5", OracleDbType.Varchar2, 100).Value = shop.sEtcGbn5; //종사업장번호
            cmd.Parameters.Add("in_email", OracleDbType.Varchar2, 40).Value = shop.email;
            cmd.Parameters.Add("in_owner", OracleDbType.Varchar2, 20).Value = shop.owner;
            cmd.Parameters.Add("in_buss_owner", OracleDbType.Varchar2, 20).Value = shop.bussOwner;
            cmd.Parameters.Add("in_buss_addr", OracleDbType.Varchar2, 200).Value = shop.bussAddr;
            cmd.Parameters.Add("in_mobile", OracleDbType.Varchar2, 20).Value = shop.mobile;
            cmd.Parameters.Add("in_addr1", OracleDbType.Varchar2, 200).Value = shop.addr1;
            cmd.Parameters.Add("in_addr2", OracleDbType.Varchar2, 200).Value = shop.addr2;
            cmd.Parameters.Add("in_zipcode", OracleDbType.Varchar2, 6).Value = shop.zipCode;
            cmd.Parameters.Add("in_lon", OracleDbType.Double).Value = shop.lon;
            cmd.Parameters.Add("in_lat", OracleDbType.Double).Value = shop.lat;
            cmd.Parameters.Add("in_sido_name", OracleDbType.Varchar2, 20).Value = shop.sidoName;
            cmd.Parameters.Add("in_gungu_name", OracleDbType.Varchar2, 30).Value = shop.gunguName;
            cmd.Parameters.Add("in_dong_name", OracleDbType.Varchar2, 50).Value = shop.dongName;
            cmd.Parameters.Add("in_dest_jibun", OracleDbType.Varchar2, 20).Value = shop.destJibun;
            cmd.Parameters.Add("in_road_dest_dong", OracleDbType.Varchar2, 300).Value = shop.roadDestDong;
            cmd.Parameters.Add("in_road_dest_addr", OracleDbType.Varchar2, 300).Value = shop.roadDestAddr;
            cmd.Parameters.Add("in_road_dest_building", OracleDbType.Varchar2, 300).Value = shop.roadDestBuilding;
            cmd.Parameters.Add("in_pos_road", OracleDbType.Varchar2, 200).Value = shop.pos_road;
            cmd.Parameters.Add("in_pos_hdong", OracleDbType.Varchar2, 200).Value = shop.pos_hdong;
            cmd.Parameters.Add("in_pos_bdong", OracleDbType.Varchar2, 200).Value = shop.pos_bdong;
            cmd.Parameters.Add("in_pos_ri", OracleDbType.Varchar2, 200).Value = shop.pos_ri;
            cmd.Parameters.Add("in_loc", OracleDbType.Varchar2, 200).Value = shop.loc;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 1000).Value = shop.memo;
            cmd.Parameters.Add("in_buss_shopname", OracleDbType.Varchar2, 100).Value = shop.bussShopname;
            cmd.Parameters.Add("in_buss_con", OracleDbType.Varchar2, 100).Value = shop.bussCon;
            cmd.Parameters.Add("in_buss_type", OracleDbType.Varchar2, 100).Value = shop.bussType;
            cmd.Parameters.Add("in_buss_tax_type", OracleDbType.Varchar2, 1).Value = shop.bussTaxType;
            cmd.Parameters.Add("in_salesman_code", OracleDbType.Int32).Value = shop.salesmanCode;
            cmd.Parameters.Add("in_salesman_name", OracleDbType.Varchar2, 50).Value = shop.salesmanName;
            cmd.Parameters.Add("in_operator_code", OracleDbType.Int32).Value = shop.operatorCode;
            cmd.Parameters.Add("in_operator_name", OracleDbType.Varchar2, 50).Value = shop.operatorName;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = shop.modUCode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 50).Value = shop.modName;
            cmd.Parameters.Add("out_shop_cd", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_shop_id", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                RshopCd = cmd.Parameters["out_shop_cd"].Value.ToString();
                RshopId = cmd.Parameters["out_shop_id"].Value.ToString();

                //폐쇄몰 데이터 연동(미사용/ 대구로몰 약관동의후 연동함)
                //if (Rcode == "00")
                //{
                    
                //    if (!string.IsNullOrEmpty(shop.shopName)
                //        && !string.IsNullOrEmpty(shop.mobile)
                //        && !string.IsNullOrEmpty(shop.addr2)
                //        && !string.IsNullOrEmpty(shop.lon)
                //        && !string.IsNullOrEmpty(shop.lat))
                //    {
                //        //가맹점 생성시 폐쇄몰정보 생성
                //        MallUser mallUser = await getShopInfoForMall(RshopCd);

                //        MallResult mallResult = await MallController.signUp(mallUser);

                //        if (!mallResult.result[0].result_info.code.Equals("1000")) //실패시 오류메시지 출력
                //        {
                //            //Rcode = "98";
                //            Rmsg = mallResult.result[0].result_info.msg;
                //            await Utils.SaveErrorAsync("/ShopBasic : Post", mallUser.user_id + "/" + Rmsg);
                //        }

                //        Rmsg = Rmsg + " 폐쇄몰 등록";
                //    }
                //}
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopBasic : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, shopCd = RshopCd, shopId = RshopId });
        }

        /// <summary>
        /// 가맹점 생성V2
        /// </summary>
        /// <remarks>
        /// franchiseCd 설정시 CHAIN_COUPON_SHOP테이블에 쿠폰별로 값을 밀어넣음 <br/>
        /// (해당 가맹점의 브랜드 쿠폰 사용 설정 생성/default:미사용) <br/>
        /// <br/>
        /// serviceGbn : 서비스 구분(0: 주문, 1: 특별관, 2: 꽃배달) <br/>
        /// addr1(구주소) <br/>
        /// addr2(신주소) <br/>
        /// sidoName(시도) <br/>
        /// gunguName(군구) <br/>
        /// dongName(동) <br/>
        /// destJibun(번지) <br/>
        /// roadDestDong(신주소 동) <br/>
        /// roadDestAddr(신주소 동 뒤의 숫자) <br/>
        /// roadDestBuilding(신주소 건물명) <br/>
        /// loc(상세주소) <br/>
        /// lon,lat(가맹점 위치(gps)) <br/>
        /// <br/>
        /// POS ONLY PARAMETER <br/>
        /// pos_road(도로명) <br/>
        /// pos_hdong(행정동명) <br/>
        /// pos_bdong(법정동명) <br/>
        /// pos_ri(리명)
        /// </remarks>
        [HttpPost()]
        public async Task<ResultShop2> Post_V2(ShopBasic shop)
        {
            string Rposition = "/ShopBasic/V2 : Post";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RshopCd = string.Empty;
            string RshopId = string.Empty;
            string RapiComCode = string.Empty;

            ResultPlus result = new ResultPlus();
            ResultPlus2 result2 = new ResultPlus2();
            PosShopResult result3 = new PosShopResult();
            ResultShop2 resultShop = new ResultShop2();

            if (string.IsNullOrEmpty(shop.shopName))
            {
                Rmsg = "매장명";
            }
            else if(string.IsNullOrEmpty(shop.owner))
            {
                Rmsg = "대표자명";
            }
            else if (string.IsNullOrEmpty(shop.mobile))
            {
                Rmsg = "휴대폰";
            }
            else if (string.IsNullOrEmpty(shop.regNo))
            {
                Rmsg = "사업자등록번호";
            }
            else if (string.IsNullOrEmpty(shop.addr1) && string.IsNullOrEmpty(shop.addr2))
            {
                result.msg = "주소";
            }

            if (!string.IsNullOrEmpty(Rmsg))
            {
                resultShop.code = "99";
                resultShop.msg = Rmsg + "이(가) 누락되었습니다.";
                return resultShop;
            }

            try
            {
                result = await setShopId();
                if (result.code != "00")
                {
                    Rcode = result.code;
                    Rmsg = "shop_id 생성에 실패하였습니다. " + result.msg;
                    await Utils.SaveErrorAsync(Rposition, Rcode + "/" + Rmsg);

                    resultShop.code = Rcode;
                    resultShop.msg = Rmsg;
                    resultShop.shopCd = RshopCd;
                    resultShop.shopId = RshopId;
                    resultShop.apiComCode = RapiComCode;
                    return resultShop;
                }

                RshopId = result.item;
                var pw = Utils.SHA256Hash("eornfh");
                PosShop posShopCopy = new PosShop();
                posShopCopy.shop_info = new PosShopInfo();
                posShopCopy.app_type = shop.mCode == "1" ? "test" : "admin-daeguroApp";
                posShopCopy.shop_info.job_gbn = "INSERT"; // 등록
                posShopCopy.shop_info.login_id = RshopId; // 새 가맹점 로그인 id
                posShopCopy.shop_info.login_pw = pw; // 새 가맹점 로그인 pw
                posShopCopy.shop_info.shop_name = shop.shopName; // 새 가맹점명
                posShopCopy.shop_info.shop_manage = pw; // 관리자 pw
                posShopCopy.shop_info.address = string.IsNullOrEmpty(shop.addr2)? shop.addr1 : shop.addr2;
                posShopCopy.shop_info.address_detail = shop.loc;
                posShopCopy.shop_info.sido = shop.sidoName.Contains("대구")? "대구광역시" : null;
                posShopCopy.shop_info.sigungu = shop.gunguName;
                posShopCopy.shop_info.bdong = shop.pos_bdong;
                posShopCopy.shop_info.hdong = shop.pos_hdong;
                posShopCopy.shop_info.ri = shop.pos_ri;
                posShopCopy.shop_info.road = shop.pos_road;
                posShopCopy.shop_info.lon = Double.Parse(shop.lon);
                posShopCopy.shop_info.lat = Double.Parse(shop.lat);
                posShopCopy.shop_info.telno = shop.telNo;
                posShopCopy.shop_info.mobile = shop.mobile;
                posShopCopy.shop_info.reg_no = shop.regNo;
                posShopCopy.shop_info.owner = shop.owner;
                posShopCopy.shop_info.zone_code = shop.zipCode;
                posShopCopy.shop_info.mod_ucode = shop.modUCode;
                posShopCopy.shop_info.account_owner = null;
                posShopCopy.shop_info.account_no = null;
                posShopCopy.shop_info.account_bankcode = null;
                posShopCopy.shop_info.is_fooddelivery = "0";
                posShopCopy.shop_info.is_reserve = "0";
                posShopCopy.shop_info.is_flower = "0";
                posShopCopy.shop_info.shop_token = "0"; //api_com_code
                posShopCopy.shop_info.shop_mac = null;
                result3 = await setPosShop(posShopCopy);

                if (result3.code != 0)
                {
                    Rcode = result3.code.ToString();
                    Rmsg = "포스 가맹점 생성에 실패하였습니다. " + result3.message;
                    await Utils.SaveErrorAsync(Rposition, Rcode + "/" + Rmsg);

                    resultShop.code = Rcode;
                    resultShop.msg = Rmsg;
                    resultShop.shopCd = RshopCd;
                    resultShop.shopId = RshopId;
                    resultShop.apiComCode = RapiComCode;
                    return resultShop;
                }

                RapiComCode = result3.shop_token; // 새 가맹점 api_com_code
                result = await addBasicInfoV2(shop, RshopId, RapiComCode);
                RshopCd = result.item;

                if (result.code != "00")
                {
                    Rcode = result.code;
                    Rmsg = "대구로 가맹점 생성에 실패하였습니다. " + result.msg;
                    await Utils.SaveErrorAsync(Rposition, Rcode + "/" + Rmsg);

                    resultShop.code = Rcode;
                    resultShop.msg = Rmsg;
                    resultShop.shopCd = RshopCd;
                    resultShop.shopId = RshopId;
                    resultShop.apiComCode = RapiComCode;
                    return resultShop;
                }

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
                Rcode = "99";
                Rmsg = ex.Message;
            }


            resultShop.code = Rcode;
            resultShop.msg = Rmsg;
            resultShop.shopCd = RshopCd;
            resultShop.shopId = RshopId;
            resultShop.apiComCode = RapiComCode;
            return resultShop;
        }

        /// <summary>
        /// shop_id 생성
        /// </summary>
        public static async Task<ResultPlus> setShopId()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            ResultPlus result = new ResultPlus();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.Text,
                CommandText = "select SF_GET_SHOP_CD () from dual",
            };

            try
            {
                await conn.OpenAsync();
                var raw = await cmd.ExecuteScalarAsync();
                result.item = raw.ToString();
                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopBasic/setShopId : Get", ex.Message);
                result.code = "99";
                result.msg = ex.Message;
            }

            return result;
        }

        // 대구로 가맹점 생성처리
        private async Task<ResultPlus> addBasicInfoV2(ShopBasic shop, string shop_id, string api_com_code)
        {
            ResultPlus result = new ResultPlus();


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.ADD_BASIC_INFO_V2",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = shop.mCode;
            cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = shop.ccCode;
            cmd.Parameters.Add("in_service_gbn", OracleDbType.Varchar2, 1).Value = shop.serviceGbn;
            cmd.Parameters.Add("in_franchise_cd", OracleDbType.Varchar2, 10).Value = shop.franchiseCd;
            cmd.Parameters.Add("in_shop_name", OracleDbType.Varchar2, 50).Value = shop.shopName;
            cmd.Parameters.Add("in_reg_no", OracleDbType.Varchar2, 10).Value = shop.regNo;
            cmd.Parameters.Add("in_s_etc_gbn5", OracleDbType.Varchar2, 100).Value = shop.sEtcGbn5; //종사업장번호
            cmd.Parameters.Add("in_shop_id", OracleDbType.Varchar2, 20).Value = shop_id; //가맹점 id
            cmd.Parameters.Add("in_api_com_code", OracleDbType.Varchar2, 30).Value = api_com_code; //POS연동 코드
            cmd.Parameters.Add("in_email", OracleDbType.Varchar2, 40).Value = shop.email;
            cmd.Parameters.Add("in_owner", OracleDbType.Varchar2, 20).Value = shop.owner;
            cmd.Parameters.Add("in_buss_owner", OracleDbType.Varchar2, 20).Value = shop.bussOwner;
            cmd.Parameters.Add("in_buss_addr", OracleDbType.Varchar2, 200).Value = shop.bussAddr;
            cmd.Parameters.Add("in_mobile", OracleDbType.Varchar2, 20).Value = shop.mobile;
            cmd.Parameters.Add("in_addr1", OracleDbType.Varchar2, 200).Value = shop.addr1;
            cmd.Parameters.Add("in_addr2", OracleDbType.Varchar2, 200).Value = shop.addr2;
            cmd.Parameters.Add("in_zipcode", OracleDbType.Varchar2, 6).Value = shop.zipCode;
            cmd.Parameters.Add("in_lon", OracleDbType.Double).Value = shop.lon;
            cmd.Parameters.Add("in_lat", OracleDbType.Double).Value = shop.lat;
            cmd.Parameters.Add("in_sido_name", OracleDbType.Varchar2, 20).Value = shop.sidoName;
            cmd.Parameters.Add("in_gungu_name", OracleDbType.Varchar2, 30).Value = shop.gunguName;
            cmd.Parameters.Add("in_dong_name", OracleDbType.Varchar2, 50).Value = shop.dongName;
            cmd.Parameters.Add("in_dest_jibun", OracleDbType.Varchar2, 20).Value = shop.destJibun;
            cmd.Parameters.Add("in_road_dest_dong", OracleDbType.Varchar2, 300).Value = shop.roadDestDong;
            cmd.Parameters.Add("in_road_dest_addr", OracleDbType.Varchar2, 300).Value = shop.roadDestAddr;
            cmd.Parameters.Add("in_road_dest_building", OracleDbType.Varchar2, 300).Value = shop.roadDestBuilding;
            cmd.Parameters.Add("in_loc", OracleDbType.Varchar2, 200).Value = shop.loc;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 1000).Value = shop.memo;
            cmd.Parameters.Add("in_buss_shopname", OracleDbType.Varchar2, 100).Value = shop.bussShopname;
            cmd.Parameters.Add("in_buss_con", OracleDbType.Varchar2, 100).Value = shop.bussCon;
            cmd.Parameters.Add("in_buss_type", OracleDbType.Varchar2, 100).Value = shop.bussType;
            cmd.Parameters.Add("in_buss_tax_type", OracleDbType.Varchar2, 1).Value = shop.bussTaxType;
            cmd.Parameters.Add("in_salesman_code", OracleDbType.Int32).Value = shop.salesmanCode;
            cmd.Parameters.Add("in_salesman_name", OracleDbType.Varchar2, 50).Value = shop.salesmanName;
            cmd.Parameters.Add("in_operator_code", OracleDbType.Int32).Value = shop.operatorCode;
            cmd.Parameters.Add("in_operator_name", OracleDbType.Varchar2, 50).Value = shop.operatorName;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = shop.modUCode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 50).Value = shop.modName;
            cmd.Parameters.Add("out_shop_cd", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();
                result.item = cmd.Parameters["out_shop_cd"].Value.ToString();

            }
            catch (Exception ex)
            {
                result.code = "98";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync("/ShopBasic/addBasicInfoV2 : Post", ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 포스 가맹점 생성,카피
        /// </summary>
        public static async Task<PosShopResult> setPosShop(PosShop posShopCopy)
        {
            string Rposition = "/ShopBasic/setPosShop : Post";
            string url = string.Empty;
            if (Utils.serverGbn == "T")
            {
                url = @$"https://postest.daeguro.co.kr:15505/posApi/POSData/DaeguroApp_Process/";//(테스트서버경로)
            }
            else if (Utils.serverGbn == "R")
            {
                url = @$"https://pos.daeguro.co.kr:15412/posApi/POSData/DaeguroApp_Process/"; //(운영서버경로)
            }

            posShopCopy.app_name = "대구로 어드민";
            //posShopCopy.app_type = "admin-daeguroApp";
            posShopCopy.shop_info.use_gbn = "Y";

            PosShopResult result = new PosShopResult();

            try
            {
                var payload = posShopCopy;

                var stringPayload = JsonConvert.SerializeObject(payload);

                HttpContent httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");

                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", Utils.posKey);

                HttpResponseMessage httpResponse = await httpClient.PostAsync(url, httpContent);

                string responseStr = await httpResponse.Content.ReadAsStringAsync();

                result = JsonConvert.DeserializeObject<PosShopResult>(responseStr);

                await Utils.SaveTempLogAsync(Rposition, Utils.serverGbn + "/" + result.code.ToString() + "/" + stringPayload);// 호출내역 기록

                if (result.code != 0)
                {
                    await Utils.SaveErrorAsync(Rposition, result.message);
                }

            }
            catch (Exception ex)
            {
                result.code = 99;
                result.message = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 가맹점 수정
        /// </summary>
        /// <remarks>
        /// franchiseCd 설정시 CHAIN_COUPON_SHOP테이블에 쿠폰별로 값을 밀어넣음 <br/>
        /// (해당 가맹점의 브랜드 쿠폰 사용 설정 생성/default:미사용) <br/>
        /// s_etc_gbn5 종사업장번호 <br/>
        /// sEtcGbn6 브랜드(영양,알러지정보) <br/>
        /// licenseNo 인허가번호 <br/>
        /// </remarks>
        [HttpPut]
        public async Task<IActionResult> Put(ShopBasic shop)
        {
            ResultBasic result = new ResultBasic();

            string err_msg = "/";

            if (string.IsNullOrEmpty(shop.shopName))
            {
                result.msg = "매장명";
            }
            else if (string.IsNullOrEmpty(shop.owner))
            {
                result.msg = "대표자명";
            }
            else if (string.IsNullOrEmpty(shop.mobile))
            {
                result.msg = "휴대폰";
            }
            else if (string.IsNullOrEmpty(shop.regNo))
            {
                result.msg = "사업자등록번호";
            }
            else if (string.IsNullOrEmpty(shop.addr1) && string.IsNullOrEmpty(shop.addr2))
            {
                result.msg = "주소";
            }

            if (!string.IsNullOrEmpty(result.msg))
            {
                result.code = "99";
                result.msg = result.msg + "이(가) 누락되었습니다.";
                return Ok(new { code = result.code, msg = result.msg });
            }

            try {
                MallUser mallUserF = await MallController.getShopInfoForMall(shop.shopCd); // 폐쇄몰 연동용 데이터 조회 rest(약관동의가 되어있지 않으면  user_id에 N 리턴)

                ShopBasic shopBasicF = new ShopBasic();

                if (mallUserF.user_id != "N")
                {
                    shopBasicF = await getShopBasic(shop.shopCd);// 가맹점 연동 실패시 롤백하기 위한 정보
                }
                
                result = await updateShopBasic(shop);

                //폐쇄몰 데이터 연동
                if (result.code == "00" && mallUserF.user_id != "N" && Utils.serverGbn == "R")
                {
                    //매장명, 휴대폰, 주소가 빈값이면 폐쇄몰 생성불가
                    //if (!string.IsNullOrEmpty(shop.shopName)
                    //    && !string.IsNullOrEmpty(shop.mobile)
                    //    && (!string.IsNullOrEmpty(shop.addr1) || !string.IsNullOrEmpty(shop.addr2)))
                    //{
                        //가맹점 수정시 폐쇄몰정보도 수정
                        //MallUser mallUserT = await getShopInfoForMall(shop.shopCd);
                        MallUser mallUserT = new MallUser();
                        mallUserT.mcode = mallUserF.mcode;
                        mallUserT.user_id = mallUserF.user_id;
                        mallUserT.password = mallUserF.password;
                        mallUserT.fk_shop_cd = shop.shopCd;
                        mallUserT.user_name = shop.shopName;
                        mallUserT.tel_no = shop.mobile;
                        mallUserT.email = shop.email;
                        mallUserT.sido = shop.sidoName;
                        mallUserT.gugun = shop.gunguName;
                        mallUserT.dong = shop.dongName;
                        mallUserT.address = (string.IsNullOrEmpty(shop.addr2)) ? shop.addr1 : shop.addr2;
                        mallUserT.address_detail = shop.loc;
                        mallUserT.memo = mallUserF.memo;

                        ResultMall mallResult = await MallController.existCheck(mallUserT.mcode, mallUserT.user_id, mallUserT.password);

                        if (mallResult.data.query_code.Equals("NO")) //회원정보가 없을경우 등록
                        {
                            mallResult = await MallController.signUp(mallUserT, "D");

                            if (!mallResult.code.Equals("1000")) //실패시 오류메시지 출력
                            {
                                foreach (ResultBasic i in mallResult.data.parameter)
                                {
                                    err_msg = err_msg + i.msg + ",";
                                }

                                result.code = "98";
                                result.msg = mallResult.msg + err_msg;
                                await Utils.SaveErrorAsync("/ShopBasic : Put", mallUserT.user_id + "/" + result.msg);
                            }

                            result.msg = result.msg + " 폐쇄몰 등록";
                        }
                        else if (mallResult.data.query_code.Equals("OK")) //회원정보가 있을경우 수정
                        {
                            // 폐쇄몰 수정사항이 있는경우만 수정 호출
                            // (레코드는 내부 값이 같으면 Equals -> true 리턴)
                            if (!mallUserF.Equals(mallUserT))
                            {
                                mallResult = await MallController.modUser(mallUserT, "D");

                                if (!mallResult.code.Equals("1000")) //실패시 롤백 후 오류메시지 출력
                                {
                                    await updateShopBasic(shopBasicF); 
                                    
                                    foreach (ResultBasic i in mallResult.data.parameter)
                                    {
                                        err_msg = err_msg + i.msg + ",";
                                    }

                                    result.code = "98";
                                    result.msg = mallResult.msg + err_msg;
                                    await Utils.SaveErrorAsync("/ShopBasic : Put", mallUserT.user_id + "/" + result.msg);
                                }

                                result.msg = result.msg + " 폐쇄몰 수정";
                            }

                        }
                    //}

                }


            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopBasic : Put", ex.Message);
                result.code = "99";
                result.msg = ex.Message;
            }

            return Ok(new { code = result.code, msg = result.msg });
        }

        private async Task<ResultBasic> updateShopBasic(ShopBasic shop)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.UPDATE_BASIC_INFO",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Varchar2, 10).Value = shop.mCode;
            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop.shopCd;
            cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = shop.ccCode;
            cmd.Parameters.Add("in_franchise_cd", OracleDbType.Varchar2, 10).Value = shop.franchiseCd;
            cmd.Parameters.Add("in_s_etc_gbn6", OracleDbType.Varchar2, 10).Value = shop.sEtcGbn6;
            cmd.Parameters.Add("in_shop_name", OracleDbType.Varchar2, 50).Value = shop.shopName;
            cmd.Parameters.Add("in_reg_no", OracleDbType.Varchar2, 10).Value = shop.regNo;
            cmd.Parameters.Add("in_s_etc_gbn5", OracleDbType.Varchar2, 10).Value = shop.sEtcGbn5; //종사업장번호
            cmd.Parameters.Add("in_email", OracleDbType.Varchar2, 40).Value = shop.email;
            cmd.Parameters.Add("in_owner", OracleDbType.Varchar2, 20).Value = shop.owner;
            cmd.Parameters.Add("in_buss_owner", OracleDbType.Varchar2, 20).Value = shop.bussOwner;
            cmd.Parameters.Add("in_buss_addr", OracleDbType.Varchar2, 200).Value = shop.bussAddr;
            cmd.Parameters.Add("in_mobile", OracleDbType.Varchar2, 20).Value = shop.mobile;
            cmd.Parameters.Add("in_addr1", OracleDbType.Varchar2, 200).Value = shop.addr1;
            cmd.Parameters.Add("in_addr2", OracleDbType.Varchar2, 200).Value = shop.addr2;
            cmd.Parameters.Add("in_zipcode", OracleDbType.Varchar2, 6).Value = shop.zipCode;
            cmd.Parameters.Add("in_lon", OracleDbType.Double).Value = string.IsNullOrEmpty(shop.lon) ? null : shop.lon;
            cmd.Parameters.Add("in_lat", OracleDbType.Double).Value = string.IsNullOrEmpty(shop.lat) ? null : shop.lat;
            cmd.Parameters.Add("in_sido_name", OracleDbType.Varchar2, 20).Value = shop.sidoName;
            cmd.Parameters.Add("in_gungu_name", OracleDbType.Varchar2, 30).Value = shop.gunguName;
            cmd.Parameters.Add("in_dong_name", OracleDbType.Varchar2, 50).Value = shop.dongName;
            cmd.Parameters.Add("in_dest_jibun", OracleDbType.Varchar2, 20).Value = shop.destJibun;
            cmd.Parameters.Add("in_road_dest_dong", OracleDbType.Varchar2, 300).Value = shop.roadDestDong;
            cmd.Parameters.Add("in_road_dest_addr", OracleDbType.Varchar2, 300).Value = shop.roadDestAddr;
            cmd.Parameters.Add("in_road_dest_building", OracleDbType.Varchar2, 300).Value = shop.roadDestBuilding;
            cmd.Parameters.Add("in_loc", OracleDbType.Varchar2, 200).Value = shop.loc;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 1000).Value = shop.memo;
            cmd.Parameters.Add("in_buss_shopname", OracleDbType.Varchar2, 100).Value = shop.bussShopname;
            cmd.Parameters.Add("in_buss_con", OracleDbType.Varchar2, 100).Value = shop.bussCon;
            cmd.Parameters.Add("in_buss_type", OracleDbType.Varchar2, 100).Value = shop.bussType;
            cmd.Parameters.Add("in_buss_tax_type", OracleDbType.Varchar2, 1).Value = shop.bussTaxType;
            cmd.Parameters.Add("in_salesman_code", OracleDbType.Int32).Value = string.IsNullOrEmpty(shop.salesmanCode) ? null : shop.salesmanCode;
            cmd.Parameters.Add("in_salesman_name", OracleDbType.Varchar2, 50).Value = shop.salesmanName;
            cmd.Parameters.Add("in_operator_code", OracleDbType.Int32).Value = string.IsNullOrEmpty(shop.operatorCode) ? null : shop.operatorCode;
            cmd.Parameters.Add("in_operator_name", OracleDbType.Varchar2, 50).Value = shop.operatorName;
            cmd.Parameters.Add("in_mfds_lcns_no", OracleDbType.Varchar2, 20).Value = shop.licenseNo;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = string.IsNullOrEmpty(shop.modUCode) ? null : shop.modUCode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 50).Value = shop.modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/updateShopBasic : Put", ex.Message);
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }

            ResultBasic result = new ResultBasic();
            result.code = Rcode;
            result.msg = Rmsg;

            return result;
        }

        //메모 변경이력
        [HttpGet("getMemoHist/{shop_cd}")]
        public async Task<IActionResult> getMemoHist(string shop_cd, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT *
                                FROM (select ROWNUM as NO, T1.*
                                from(select hist_date, memo from shop_memo_hist
                                where shop_cd = :shop_cd
                                order by seq desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2
                                WHERE ((:in_page - 1) * :in_rows) < NO
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = items.Count.ToString(), data = items });
        }

        /// <summary>
        /// 가맹점 휴대폰번호 변경횟수 초기화
        /// </summary>
        [HttpPut("initMobileChgCnt/{shop_cd}")]
        public async Task<IActionResult> initMobileChgCnt(string shop_cd, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("mod_ucode", mod_ucode);
                param.Add("mod_name", mod_name);

                string sql = @" update shop_info_add
                                set MOBILE_CHG_CNT = 0,
                                    mod_ucode = :mod_ucode,
                                    mod_name = :mod_name,
                                    mod_date = sysdate
                                where shop_cd = :shop_cd
                ";

                db.Open();

                await db.QueryAsync(sql, param, commandType: CommandType.Text);


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// item_sub_thema 데이터 가맹점으로 옮기기
        /// </summary>
        [HttpPost("moveFromItemSubThemaToShopInfo")]
        public async Task<IActionResult> moveFromItemSubThemaToShopInfo(string thema_cd, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            ShopBasic shop = new ShopBasic();
            ResultShop2 shopResult = new ResultShop2();
            ResultBasic basicResult = new ResultBasic();
            List<SubTema> items = new List<SubTema>();

            List<ShopBasic> list = new List<ShopBasic>();

            if (mod_ucode == null || mod_name == null)
            {
                Rcode = "99";
                Rmsg = "수정자는 필수입니다";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("thema_cd", thema_cd);

                string sql = @" select thema_cd temaCode,
                                       item_cd subTemaCode,
                                       thema_name temaName,
                                       use_gbn useGbn,
                                       sido,
                                       gungu,
                                       addr,
                                       lon,
                                       lat,
                                       file_img url,
                                       thema_memo temaMemo,
                                       memo,
                                       test_yn testYn,
                                       open_yn openYn
                                from item_sub_thema
                                where addr is not null
                                and thema_cd like case when :thema_cd is null then '%' else :thema_cd end
                ";

                db.Open();

                var temp = await db.QueryAsync<SubTema>(sql, param, commandType: CommandType.Text);
                items = temp.ToList();

                db.Close();
                string addrass = string.Empty;
                // 여기서 루프돌려서 호출필요
                foreach (var i in items)
                {
                    ResponseNaverGeocode geo = await NaverController._Geocoding(i.addr);
                    if (geo.meta.totalCount > 0)
                    {
                        var lon = geo.addresses[0].x;
                        var lat = geo.addresses[0].y;

                        // 네이버지도랑 다음지도의 lon,lat값이 미묘하게 다른데 네이버값으로 저장함.
                        //if (i.lon != lon || i.lat != lat)
                        //{
                        //    return Ok(new { code = "99", msg = "lon,lat값이 다릅니다" });
                        //}

                        shop.mCode = i.testYn == "N" ? "2" : "1";

                        //콜센터 지정
                        var cccode = string.Empty;
                        if (shop.mCode == "1")
                        {
                            cccode = "12";
                        }
                        else if (i.gungu.Contains("달서구"))
                        {
                            cccode = "5";
                        }
                        else if (i.gungu.Contains("수성구"))
                        {
                            cccode = "6";
                        }
                        else if (i.gungu.Contains("동구"))
                        {
                            cccode = "7";
                        }
                        else if (i.gungu.Contains("서구"))
                        {
                            cccode = "8";
                        }
                        else if (i.gungu.Contains("남구"))
                        {
                            cccode = "9";
                        }
                        else if (i.gungu.Contains("북구"))
                        {
                            cccode = "10";
                        }
                        else if (i.gungu.Contains("중구"))
                        {
                            cccode = "11";
                        }
                        else if (i.gungu.Contains("달성군"))
                        {
                            cccode = "86";
                        }
                        shop.ccCode = cccode;

                        shop.serviceGbn = "4"; //전통시장
                        shop.shopName = i.temaName;
                        shop.regNo = "5038150051"; //우선 회사 사업자번호로 대체

                        
                        shop.addr1 = geo.addresses[0].jibunAddress.Replace("대구광역시","대구");
                        shop.addr2 = geo.addresses[0].roadAddress.Replace("대구광역시", "대구");
                        // 주소단에는 건물명 제거 필요
                        if (!string.IsNullOrEmpty(geo.addresses[0].addressElements[6].longName))
                        {
                            shop.addr1 = shop.addr1.Replace(" " + geo.addresses[0].addressElements[6].longName, "");
                            shop.addr2 = shop.addr2.Replace(" " + geo.addresses[0].addressElements[6].longName, "");
                        }
                        shop.sidoName = i.sido.Replace("대구광역시", "대구");
                        shop.gunguName = i.gungu;
                        //동명
                        var ri = (string.IsNullOrEmpty(geo.addresses[0].addressElements[3].longName)) ? "" : " " + geo.addresses[0].addressElements[3].longName;
                        shop.dongName = geo.addresses[0].addressElements[2].longName + ri;
                        shop.pos_bdong = shop.dongName;
                        //지번
                        shop.destJibun = geo.addresses[0].addressElements[7].longName;
                        //도로명 동
                        shop.roadDestDong = geo.addresses[0].addressElements[4].longName;
                        shop.pos_road = shop.roadDestDong;
                        //도로명 건물번호
                        shop.roadDestAddr = geo.addresses[0].addressElements[5].longName;
                        //도로명 건물명
                        shop.roadDestBuilding = geo.addresses[0].addressElements[6].longName;
                        shop.lon = i.lon;
                        shop.lat = i.lat;
                        shop.zipCode = geo.addresses[0].addressElements[8].longName;

                        shop.memo = i.memo;
                        shop.modUCode = mod_ucode;
                        shop.modName = mod_name;

                        // 가맹점 생성
                        shopResult = await Post_V2(shop);

                        if (shopResult.code != "00")
                        {
                            return Ok(new { code = shopResult.code, msg = "가맹점생성실패" + shopResult.msg });
                        }

                        if (!string.IsNullOrEmpty(i.url))
                        {
                            //가맹점 생성후 이미지 추가
                            basicResult = await copyThemaImg(i.url, shop.ccCode, shopResult.shopCd, mod_ucode, mod_name);

                            //if (basicResult.code != "00")
                            //{
                            //    return Ok(new { code = basicResult.code, msg = "이미지복사실패" + basicResult.msg });
                            //}
                        }

                        // 시장코드 등록작업
                        basicResult = await setTradShop(shopResult.shopCd, i.temaCode, i.temaMemo, i.useGbn, i.openYn, mod_ucode, mod_name);

                        if (basicResult.code != "00")
                        {
                            return Ok(new { code = basicResult.code, msg = "시장코드설정실패" + basicResult.msg });
                        }
                    }
                    else
                    {
                        return Ok(new { code = "99", msg = "가맹점 주소가 올바르지 않습니다." });
                    }

                    
                }
                

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 이미지 복사이동
        /// </summary>
        [HttpPut("copyThemaImg")]
        public async Task<ResultBasic> copyThemaImg(string source_name, string dest_cccode, string dest_shop_cd, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            ResultBasic result = new ResultBasic();
            try
            {
                if (Utils.serverGbn == "R") //운영서버의 경우
                {
                    // 경로 맨 뒤에 역슬래쉬가 없어야 한다.
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        // 소스 이미지 경로
                        string sourcePath = $@"{temaPath}\{source_name}"; //내일 이미지링크 오리지날이랑 줄인거 어느거 쓰는지 확인
                        string destPath = $@"{productPath}\{dest_cccode}\{dest_shop_cd}";

                        if (Directory.Exists($@"{productPath}\{dest_cccode}") == false)
                        {
                            Directory.CreateDirectory($@"{productPath}\{dest_cccode}");
                        }

                        if (Directory.Exists($@"{productPath}\{dest_cccode}\{dest_shop_cd}") == false)
                        {
                            Directory.CreateDirectory($@"{productPath}\{dest_cccode}\{dest_shop_cd}");
                        }

                        string file_name = "shop.jpg";

                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists($@"{destPath}\{file_name}"))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete($@"{destPath}\{file_name}");
                        }

                        System.IO.File.Copy(sourcePath, $@"{destPath}\{file_name}");
                       
                    }
                }
                else if (Utils.serverGbn == "T") //테스트서버의 경우
                {
                    // 소스 이미지 경로
                    string sourcePath = $@"{testTemaPath}\{source_name}";
                    string destPath = $@"{testImagePath}\{dest_cccode}\{dest_shop_cd}";

                    if (Directory.Exists($@"{testImagePath}\{dest_cccode}") == false)
                    {
                        Directory.CreateDirectory($@"{testImagePath}\{dest_cccode}");
                    }

                    if (Directory.Exists($@"{testImagePath}\{dest_cccode}\{dest_shop_cd}") == false)
                    {
                        Directory.CreateDirectory($@"{testImagePath}\{dest_cccode}\{dest_shop_cd}");
                    }

                    string file_name = "shop.jpg";

                    // 파일이 이미 존재하면 삭제한다.
                    if (System.IO.File.Exists($@"{destPath}\{file_name}"))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        System.IO.File.Delete($@"{destPath}\{file_name}");
                    }

                    System.IO.File.Copy(sourcePath, $@"{destPath}\{file_name}");
                }

                // SHOP_INFO 테이블에 해당 컬럼 값을 넣어준다.
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                await db.ExecuteAsync($"UPDATE SHOP_INFO SET SHOP_IMAGE_YN = 'Y', MOD_DATETIME = TO_CHAR (SYSTIMESTAMP, 'YYYYMMDDHHMISSFF2'), MOD_UCODE = {mod_ucode}, MOD_NAME = '{mod_name}' WHERE SHOP_CD = '{dest_shop_cd}'");
                db.Close();

                result.code = "00";
                result.msg = "성공";

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopBasic/copyImg : Post", ex.Message + " || {source_name: " + source_name + ", dest_cccode: " + dest_cccode + ", dest_shop_cd: " + dest_shop_cd + ", insert_name: " + mod_name + "}");
                
                result.code = "01";
                result.msg = "이미지 복사 실패";
                return result;
            }

            return result;
        }

        /// <summary>
        /// 시장설정
        /// </summary>
        [HttpPut("setTradShop")]
        public async Task<ResultBasic> setTradShop(string shop_cd, string tema_cd, string tema_memo, string use_gbn, string open_yn, string ins_ucode, string ins_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            ResultBasic result = new ResultBasic();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("tema_cd", tema_cd);
                param.Add("tema_memo", tema_memo);
                param.Add("use_gbn", use_gbn);
                param.Add("open_yn", open_yn);
                param.Add("ins_ucode", ins_ucode);
                param.Add("ins_name", ins_name);

                db.Open();

                string sql = @" INSERT INTO TRAD_SHOP(M_SHOP_CD,
                                                      BUNDLE_YN,
                                                      DESCRIPTION,
                                                      INS_DATE,
                                                      INS_UCODE)
                                VALUES(:shop_cd, 'N', :tema_memo, sysdate, :ins_ucode)
                ";


                await db.QueryAsync(sql, param, commandType: CommandType.Text);

                sql = @" update shop_info
                         set app_order_yn = :use_gbn,
                             APP_ORDER_TIME = case when :use_gbn = 'Y' then sysdate end,
                             use_gbn = :use_gbn,
                             absent_yn = :open_yn, -- 부재유무(N: 휴무, Y: 운영)
                             item_cd = '1033', -- 기본 전통시장 카테고리 설정
                             mod_date = sysdate,
                             mod_ucode = :ins_ucode,
                             mod_name = :ins_name
                         where shop_cd = :shop_cd
                ";


                await db.QueryAsync(sql, param, commandType: CommandType.Text);

                sql = @"update shop_info_add
                        set m_shop_cd = :shop_cd,
                            mod_date = sysdate,
                            mod_ucode = :ins_ucode,
                            mod_name = :ins_name
                        where thema_cd = :tema_cd
                ";


                await db.QueryAsync(sql, param, commandType: CommandType.Text);


                db.Close();

                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception ex)
            {

                result.code = "01";
                result.msg = ex.Message;
            }

            return result;
        }


    }
}
