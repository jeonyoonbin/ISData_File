﻿import 'dart:convert';

import 'package:bubble_tab_indicator/bubble_tab_indicator.dart';
import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/Model/shop/shop_delitip.dart';
import 'package:daeguro_admin_app/Model/shop/shop_saleDaytime.dart';
import 'package:daeguro_admin_app/Model/shop/shop_saletime.dart';
import 'package:daeguro_admin_app/Model/shop/shopposupdate.dart';
import 'package:daeguro_admin_app/Provider/RestApiProvider.dart';
import 'package:daeguro_admin_app/View/CodeManager/code_controller.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopDetailNotifierData.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccount_controller.dart';
import 'package:daeguro_admin_app/Util/multi_masked_formatter.dart';
import 'package:daeguro_admin_app/Util/utils.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;

class ShopOperateInfo extends StatefulWidget {
  final Stream<ShopDetailNotifierData> stream;
  final Function callback;
  final double height;

  const ShopOperateInfo({Key key, this.stream, this.callback, this.height}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopOperateInfoState();
  }
}

class ShopOperateInfoState extends State<ShopOperateInfo> with SingleTickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  TabController _nestedTabController;

  ShopPosUpdateModel shopPosUpdate = ShopPosUpdateModel();
  List<ShopSaleDayTimeModel> dataSaleDayTimeList = <ShopSaleDayTimeModel>[];
  ShopDetailNotifierData detailData;

  ShopSaleTimeModel formSaleTimeData = ShopSaleTimeModel();
  ShopSaleTimeModel editData = ShopSaleTimeModel();

  bool chkappOrderYn = false;
  bool isInfoSaveEnabled = false;
  bool isListSaveEnabled = false;
  bool chkTimeGbn = false;

  ScrollController _scrollController;

  bool isReceiveDataEnabled = false;

  void refreshWidget(ShopDetailNotifierData element) {
    detailData = element;
    if (detailData != null) {
      //loadFoodSafetyData();
      loadSaleDayTimeData();

      isReceiveDataEnabled = true;

      setState(() {
        //_nestedTabController.index = 0;
        _scrollController.jumpTo(0.0);
      });
    }
    else {
      //print('shopOperate refreshWidget() is NULL');

      formSaleTimeData = null;
      formSaleTimeData = ShopSaleTimeModel();

      shopPosUpdate = null;
      shopPosUpdate = ShopPosUpdateModel();

      dataSaleDayTimeList = null;
      dataSaleDayTimeList = <ShopSaleDayTimeModel>[];

      chkappOrderYn = false;
      isReceiveDataEnabled = false;

      setState(() {
        //_nestedTabController.index = 0;
        _scrollController.jumpTo(0.0);
      });
    }
  }

  // loadFoodSafetyData() async {
  //   if (detailData != null && detailData.selected_franchiseCd != ''){
  //     await CodeController.to.getFoodSafetyData(detailData.selected_franchiseCd).then((value) {
  //       if (value != null){
  //         _FoodSafetyData = value['NUTRITION'];
  //         _AllergyData = value['ALLERGY'];
  //       }
  //     });
  //   }
  // }

  loadSaleDayTimeData() async {
    await ShopController.to.getSaleTimeData(detailData.selected_shopCode.toString());

    if (ShopController.to.qDataSaleTime != null) {
      editData = ShopSaleTimeModel.fromJson(ShopController.to.qDataSaleTime);

      if (editData != null) {
        if (editData.appOrderYn == 'Y') {
          chkappOrderYn = true;
        } else {
          chkappOrderYn = false;
        }
        formSaleTimeData = editData;
      } else {
        formSaleTimeData = ShopSaleTimeModel();
        formSaleTimeData.useGbn = 'Y';
      }
    }

    dataSaleDayTimeList.clear();

    dataSaleDayTimeList.add(new ShopSaleDayTimeModel(tipdayName: '일요일', tipDay: '1'));
    dataSaleDayTimeList.add(new ShopSaleDayTimeModel(tipdayName: '월요일', tipDay: '2'));
    dataSaleDayTimeList.add(new ShopSaleDayTimeModel(tipdayName: '화요일', tipDay: '3'));
    dataSaleDayTimeList.add(new ShopSaleDayTimeModel(tipdayName: '수요일', tipDay: '4'));
    dataSaleDayTimeList.add(new ShopSaleDayTimeModel(tipdayName: '목요일', tipDay: '5'));
    dataSaleDayTimeList.add(new ShopSaleDayTimeModel(tipdayName: '금요일', tipDay: '6'));
    dataSaleDayTimeList.add(new ShopSaleDayTimeModel(tipdayName: '토요일', tipDay: '7'));

    await ShopController.to.getSaleDayTimeData(detailData.selected_shopCode, '100');

    setState(() {
      ShopController.to.qDataSaleDayTimeList.forEach((element) {
        ShopDeliTipModel tempData = ShopDeliTipModel.fromJson(element);
        setSaleDayTimeData(tempData);
      });
    });
  }

  void setSaleDayTimeData(ShopDeliTipModel data) {
    dataSaleDayTimeList.forEach((element) {
      if (element.tipDay == data.tipDay) {
        element.tipFrStand = data.tipFromStand;
        element.tipToStand = data.tipToStand;
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _nestedTabController.dispose();

    dataSaleDayTimeList.clear();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    Get.put(CodeController());

    _scrollController = ScrollController();
    _nestedTabController = new TabController(length: 2, vsync: this);

    // WidgetsBinding.instance.addPostFrameCallback((c) {
    //   loadSaleDayTimeData();
    // });

    //if (widget.streamIsInit == false){
      widget.stream.listen((element) {
        refreshWidget(element);
      });
    //}
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          // getOperateInfoTabView(),
          // Divider(
          //   height: 40,
          // ),
          // getWeeklyTimeTableTabView(),
        ],
      ),
    );

    return Container(
      child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 10.0, bottom: 10.0, left: 16.0, right: 16.0),
              child: Container(
                height: 30.0,
                decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade200, width: 2.0), borderRadius: BorderRadius.circular(5), color: Colors.grey.shade200,),
                child: TabBar(
                  controller: _nestedTabController,
                  unselectedLabelColor: Colors.black45,
                  indicatorSize: TabBarIndicatorSize.tab,
                  labelStyle: TextStyle(fontSize: 12, fontFamily: 'NotoSansKR'),
                  indicator: BubbleTabIndicator(
                    indicatorRadius: 5.0,
                    indicatorHeight: 25.0,
                    indicatorColor: Colors.blue,
                    tabBarIndicatorSize: TabBarIndicatorSize.tab,
                  ),
                  tabs: [
                    Tab(text: '운영정보',),
                    Tab(text: '요일별 영업시간',)
                  ],
                ),
              ),
            ),
            //_nestedTabController.index == 0 ? buttonBar() : Container(height: 32,),
            Container(
              width: double.infinity,
              height: widget.height,
              child: TabBarView(
                physics: NeverScrollableScrollPhysics(),
                controller: _nestedTabController,
                children: [
                  Container(
                    //padding: EdgeInsets.all(8.0),
                      padding: EdgeInsets.symmetric(horizontal: 16.0),
                      child: getOperateInfoTabView()
                  ),
                  Container(
                      padding: EdgeInsets.symmetric(horizontal: 16.0),
                      child: getWeeklyTimeTableTabView()
                  ),
                ],
              ),
            )
          ]),
    );

    // return Scrollbar(
    //   isAlwaysShown: false,
    //   controller: _scrollController,
    //   child: ListView(
    //     controller: _scrollController,
    //     children: <Widget>[
    //     ],
    //   ),
    // );
  }

  Widget getOperateInfoTabView(){
    return Scrollbar(
        isAlwaysShown: false,
        controller: _scrollController,
        child: ListView(
          controller: _scrollController,
          children: <Widget>[
            Form(
              key: formKey,
              child: Wrap(
                children: <Widget>[
                  Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            //padding: const EdgeInsets.only(left: 10),
                            child: Text('- POS약관 동의', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                          ),
                          Row(
                            children: [
                              AnimatedOpacity(
                                opacity: isInfoSaveEnabled ? 1.0 : 0.0,
                                duration: Duration(milliseconds: 700),
                                child: Row(
                                  children: [
                                    Icon(Icons.info_outline, color: Colors.red, size: 18,),
                                    Text('저장 완료', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),),
                                  ],
                                ),
                                onEnd: (){
                                  setState(() {
                                    isInfoSaveEnabled = false;
                                  });
                                },
                              ),
                              SizedBox(width: 10,),
                              ISButton(
                                iconData: Icons.refresh,
                                iconColor: Colors.white,
                                tip: '갱신',
                                onPressed: (){
                                  if (isReceiveDataEnabled == true){
                                    //loadFoodSafetyData();
                                    loadSaleDayTimeData();

                                    setState(() {
                                      _nestedTabController.index = 0;
                                      _scrollController.jumpTo(0.0);
                                    });
                                  }
                                },
                              ),
                              SizedBox(width: 10,),
                              ISButton(
                                label: '저장',
                                iconData: Icons.save,
                                iconColor: Colors.white,
                                textStyle: TextStyle(color: Colors.white),
                                onPressed: () async {
                                  FormState form = formKey.currentState;
                                  if (!form.validate()) {
                                    return;
                                  }

                                  form.save();

                                  ShopDeliTipModel sendData = ShopDeliTipModel();
                                  sendData.shopCd = detailData.selected_shopCode;
                                  sendData.tipFromStand = formSaleTimeData.saleFromTime;
                                  sendData.tipToStand = formSaleTimeData.saleToTime;
                                  sendData.useGbn = formSaleTimeData.useGbn;
                                  sendData.happyPayUseGbn = formSaleTimeData.happyPayUseGbn;
                                  sendData.closedLogin = formSaleTimeData.closedLogin;
                                  sendData.supportFund = formSaleTimeData.supportFund;

                                  if (chkappOrderYn == true) {
                                    sendData.appOrderyn = 'Y';
                                  } else {
                                    sendData.appOrderyn = 'N';
                                  }

                                  sendData.tipGbn = '100';
                                  sendData.modUCode = GetStorage().read('logininfo')['uCode'];
                                  sendData.modName = GetStorage().read('logininfo')['name'];

                                  //print('formData--> '+sendData.toJson().toString());

                                  ShopController.to.postSaleTimeData(sendData.toJson(), context);

                                  shopPosUpdate.job_gbn = 'STOREUSE_UPDATE';
                                  shopPosUpdate.shop_token = detailData.selected_apiComCode;
                                  shopPosUpdate.use_gbn = sendData.useGbn;
                                  shopPosUpdate.mod_ucode = GetStorage().read('logininfo')['uCode'];

                                  var headerData = {
                                "Access-Control-Allow-Origin": "*",
                                // Required for CORS support to work
                                "Access-Control-Allow-Headers": "*",
                                "Access-Control-Allow-Credentials": "true",
                                "Access-Control-Allow-Methods": "*",
                                "Content-Type": "application/json",
                                "Authorization":
                                    "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6Im9yZGVyX2NvbXAiLCJhcHBfdHlwZSI6Im9yZGVyIiwiYXBwX25hbWUiOiJkYWd1cm9hcHAiLCJuYmYiOjE2NDExODcwMDAsImV4cCI6MTY3NTIwNjAwMCwiaWF0IjoxNjQxMTg3MDAwLCJpc3MiOiJodHRwczovL2xvY2FsaG9zdDoxNTQwOSIsImF1ZCI6Ikluc3VuZ1BPUyJ9.hVaYELqN7i9IQ3o00LRcF--sCv6up7slUq1i94WDw78",
                                //"Accept": "application/json",
                                  };

                                  var bodyData = {'"app_name"': '"대구로 어드민"',
                                                  '"app_type"': '"admin-daeguroApp"',
                                                  '"shop_info"': '{"job_gbn" :"STOREUSE_UPDATE", "use_gbn" : "' + sendData.useGbn +
                                                  '", "shop_token" : "' + detailData.selected_apiComCode +
                                                  '", "mod_ucode" : "' + GetStorage().read('logininfo')['uCode'] + '"}'
                                  };

                              await RestApiProvider.to.postRestError('0', '/admin/shopOperate : postSaleTimeData', '[POS 가맹점 정보 저장] ' + bodyData.toString() + '|| ucode : ' + GetStorage().read('logininfo')['uCode'].toString() + ', name : ' + GetStorage().read('logininfo')['name'].toString());


                              await http.post(Uri.parse('https://pos.daeguro.co.kr:15412/posApi/POSData/DaeguroApp_Process'), headers: headerData, body: bodyData.toString()).then((http.Response response) {
                                    if (response.statusCode == 200) {
                                      var decodeBody = jsonDecode(response.body);
                                    } else {
                                      var decodeBody = jsonDecode(response.body);
                                    }
                                  });

                                  setState(() {
                                    isInfoSaveEnabled = true;
                                  });

                                  widget.callback();

                                  //ISAlert(context, '운영 상태가 정상 업데이트되었습니다.');
                                },
                              )
                            ],
                          )
                        ],
                      ),
                      Container(
                        //padding: EdgeInsets.symmetric(horizontal: 16.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Row(
                              children: [
                                Container(
                                  width: 150,
                                  height: 40,
                                  decoration: new BoxDecoration(
                                      color: formSaleTimeData.confirmYn == 'Y' ? Colors.blue[200] : Colors.red[200],
                                      borderRadius: new BorderRadius.only(topRight: Radius.circular(15.0), bottomRight: Radius.circular(15.0), topLeft: Radius.circular(15.0), bottomLeft: Radius.circular(15.0))),
                                  child: SwitchListTile(
                                    dense: true,
                                    value: formSaleTimeData.confirmYn == 'Y' ? true : false,
                                    title: Text('동의 여부', style: TextStyle(fontSize: 12, color: Colors.white),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(width: 10),
                            Row(
                              children: [
                                Icon(Icons.timer_outlined, color: Colors.blue, size: 18,),
                                SizedBox(width: 5),
                                Container(
                                  width: 240,
                                  child: Text(
                                    formSaleTimeData.confirmDate == null ? '동의일시 : --' : '동의일시 : '  + formSaleTimeData.confirmDate.toString(),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Divider(height: 40),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Row(
                            children: [
                              Text('- 운영 상태', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(height: 10,),
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Flexible(
                              child: Container(
                                //width: 150,
                                height: 40,
                                decoration: new BoxDecoration(
                                    color: chkappOrderYn == true ? Colors.blue[200] : Colors.red[200],
                                    borderRadius: new BorderRadius.only(topLeft: Radius.circular(15.0), bottomLeft: Radius.circular(15.0))),
                                child: SwitchListTile(
                                  dense: true,
                                  value: chkappOrderYn,
                                  title: Text( '앱 승인', style: TextStyle(fontSize: 12, color: Colors.white),
                                  ),
                                  onChanged: (v) {
                                    setState(() {
                                      chkappOrderYn = v;
                                      formKey.currentState.save();
                                    });
                                  },
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                //width: 150,
                                height: 40,
                                decoration: new BoxDecoration(
                                    color: formSaleTimeData.useGbn == 'Y' ? Colors.blue[200] : Colors.red[200], borderRadius: new BorderRadius.circular(0)),
                                child: SwitchListTile(
                                  dense: true,
                                  value: formSaleTimeData.useGbn == 'Y' ? true : false,
                                  title: Text('해지 처리', style: TextStyle(fontSize: 12, color: Colors.white),
                                  ),
                                  onChanged: (v) {
                                    setState(() {
                                      formSaleTimeData.useGbn = v ? 'Y' : 'N';
                                      formKey.currentState.save();
                                    });
                                  },
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                //width: 150,
                                height: 40,
                                decoration: new BoxDecoration(
                                    color: formSaleTimeData.happyPayUseGbn == 'Y' ? Colors.blue[200] : Colors.red[200],
                                    borderRadius: new BorderRadius.only(topRight: Radius.circular(15.0), bottomRight: Radius.circular(15.0))),
                                child: SwitchListTile(
                                  dense: true,
                                  value: formSaleTimeData.happyPayUseGbn == 'Y' ? true : false,
                                  title: Text('행복페이', style: TextStyle(fontSize: 12, color: Colors.white),
                                  ),
                                  onChanged: (v) {
                                    setState(() {
                                      formSaleTimeData.happyPayUseGbn = v ? 'Y' : 'N';
                                      formKey.currentState.save();
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 10,),
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Flexible(
                              child: Container(
                                //width: 150,
                                height: 40,
                                decoration: new BoxDecoration(
                                    color: formSaleTimeData.closedLogin == 'Y' ? Colors.blue[200] : Colors.red[200],
                                    borderRadius: new BorderRadius.only(topLeft: Radius.circular(15.0), bottomLeft: Radius.circular(15.0))),
                                child: SwitchListTile(
                                  dense: true,
                                  value: formSaleTimeData.closedLogin == 'Y' ? true : false,
                                  title: Text( '해지후 로그인 가능', style: TextStyle(fontSize: 12, color: Colors.white),
                                  ),
                                  onChanged: (v) {
                                    setState(() {
                                      formSaleTimeData.closedLogin = v ? 'Y' : 'N';
                                      formKey.currentState.save();
                                    });
                                  },
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                //width: 150,
                                height: 40,
                                decoration: new BoxDecoration(
                                    color: formSaleTimeData.supportFund == 'Y' ? Colors.blue[200] : Colors.red[200],
                                    borderRadius: new BorderRadius.only(topRight: Radius.circular(15.0), bottomRight: Radius.circular(15.0))),
                                child: SwitchListTile(
                                  dense: true,
                                  value: formSaleTimeData.supportFund == 'Y' ? true : false,
                                  title: Text('입점지원금 출금', style: TextStyle(fontSize: 12, color: Colors.white),
                                  ),
                                  onChanged: (v) {
                                    setState(() {
                                      formSaleTimeData.supportFund = v ? 'Y' : 'N';
                                      formKey.currentState.save();
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Divider(height: 40),
                    ],
                  )
                ]),
            ),
          ],
        ),
      );
  }

  Widget getWeeklyTimeTableTabView(){
    return ListView(
      controller: _scrollController,
      children: <Widget>[
        Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.only(left: 10),
                  child: Row(
                    children: [
                      Text('- 요일별 영업시간', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                      SizedBox(width: 10,),
                      AnimatedOpacity(
                        opacity: isListSaveEnabled ? 1.0 : 0.0,
                        duration: Duration(seconds: 1),
                        child: Row(
                          children: [
                            Icon(Icons.info_outline, color: Colors.red, size: 18,),
                            Text('저장 완료', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),),
                          ],
                        ),
                        onEnd: (){
                          setState(() {
                            isListSaveEnabled = false;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                Row(
                  children: [
                    ISButton(
                        label: '일괄 입력',
                        textStyle: TextStyle(color: Colors.white),
                        onPressed: () {
                          setState(() {
                            int idx = 0;
                            String tempFrStand, tempToStand;
                            dataSaleDayTimeList.forEach((element) {
                              if (idx == 0) {
                                if (element.tipFrStand == null || element.tipFrStand == '' || element.tipToStand == null || element.tipToStand == '') {
                                  tempFrStand = '0900';
                                  tempToStand = '2359';
                                } else {
                                  tempFrStand = element.tipFrStand;
                                  tempToStand = element.tipToStand;
                                }
                              }

                              element.tipFrStand = tempFrStand;
                              element.tipToStand = tempToStand;

                              idx++;
                            });
                          });
                        }
                    ),
                    SizedBox(width: 10,),
                    ISButton(
                      label: '저장',
                      iconData: Icons.save,
                      iconColor: Colors.white,
                      textStyle: TextStyle(color: Colors.white),
                      onPressed: () async {
                        List<ShopSaleDayTimeModel> saveListdata = <ShopSaleDayTimeModel>[];

                        chkTimeGbn = false;

                        dataSaleDayTimeList.forEach((element) {
                          if (element.tipFrStand != '') {
                            if (chkTimeGbn == true) return;

                            if (element.tipFrStand.length != 4) {
                              ISAlert(context, '[오픈시간] 잘못된 시간형식 입니다.');
                              chkTimeGbn = true;
                              return;
                            }

                            if (int.parse(element.tipFrStand) > 2359) {
                              ISAlert(context, '오픈 시간은 최대 23:59 입니다.');
                              chkTimeGbn = true;
                              return;
                            }

                            if (int.parse(element.tipFrStand.substring(2, 4)) > 59) {
                              ISAlert(context, '[오픈시간] 잘못된 시간형식 입니다.');
                              chkTimeGbn = true;
                              return;
                            }
                          }

                          if (element.tipToStand != '') {
                            if (element.tipToStand.length != 4) {
                              ISAlert(context, '[마감시간] 잘못된 시간형식 입니다.');
                              chkTimeGbn = true;
                              return;
                            }

                            if (int.parse(element.tipToStand) > 2359) {
                              ISAlert(context, '마감시간은 최대 23:59 입니다.');
                              chkTimeGbn = true;
                              return;
                            }

                            if (int.parse(element.tipToStand.substring(2, 4)) > 59) {
                              ISAlert(context, '[마감시간] 잘못된 시간형식 입니다.');
                              chkTimeGbn = true;
                              return;
                            }
                          }

                          if (element.tipFrStand == null || element.tipFrStand == '' || element.tipToStand == null || element.tipToStand == '') {
                          } else {
                            if (int.parse(element.tipFrStand) >= int.parse(element.tipToStand)) {
                              element.tipNextDay = 'Y';
                            } else {
                              element.tipNextDay = 'N';
                            }

                            saveListdata.add(element);
                          }
                        });

                        if (saveListdata.length == 0) return;

                        String jsonData = jsonEncode(saveListdata);
                        //print('data set->'+jsonData);

                        await ShopController.to.putDayTimeData(detailData.selected_shopCode, jsonData, context);

                        setState(()  {
                          isListSaveEnabled = true;
                        });
                        //ISAlert(context, '요일별 영업시간이 정상 업데이트되었습니다.');

                        widget.callback();
                      },
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 8,),
            Container(
                height: 360,
                child: ListView(
                  //physics: NeverScrollableScrollPhysics(),
                  //padding: const EdgeInsets.only(left: 16, right: 16),
                  children: <Widget>[
                    DataTable(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                        ],
                      ),
                      headingRowColor: MaterialStateColor.resolveWith((states) => Colors.blue[50]),
                      headingTextStyle: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'NotoSansKR', color: Colors.black54, fontSize: 12),
                      headingRowHeight: 30,
                      dataRowHeight: 40,
                      dataRowColor: MaterialStateColor.resolveWith((states) => Colors.white),
                      dataTextStyle: TextStyle(fontWeight: FontWeight.normal, fontFamily: 'NotoSansKR', fontSize: 14),
                      columnSpacing: 0,
                      columns: <DataColumn>[
                        DataColumn(label: Expanded(child: Text('요일', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text('영업시작시간', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text('영업종료시간', textAlign: TextAlign.center)),),
                      ],
                      //source: listDS,
                      rows: dataSaleDayTimeList.map((item) {
                        return DataRow(cells: [
                          DataCell(Center(child: Text(Utils.getDay(item.tipDay) ?? '--', style: TextStyle(color: Colors.black)))),
                          DataCell(Center(
                              child: Container(
                                width: 80,
                                height: 30,
                                child: TextFormField(
                                  textAlign: TextAlign.center,
                                  style: TextStyle(fontWeight: FontWeight.normal, fontFamily: 'NotoSansKR', fontSize: 14),
                                  keyboardType: TextInputType.number,
                                  inputFormatters: <TextInputFormatter>[
                                    MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')
                                  ],
                                  expands: false,
                                  maxLines: 1,
                                  controller: TextEditingController(text: Utils.getTimeFormat(item.tipFrStand) ?? '--'),//Utils.getTimeSet(value)),
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.zero, borderSide: BorderSide(color: Colors.white, width: 1)),
                                    contentPadding: EdgeInsets.all(5),
                                    counterText: '',
                                  ),
                                  onChanged: (v){
                                    //item.tipFrStand = v;
                                    item.tipFrStand = v.toString().replaceAll(':', '');
                                  },
                                ),
                              )
                          )),
                          DataCell(Center(
                            //child: getTimesetData(item.tipToStand)
                            child: Container(
                              width: 80,
                              height: 30,
                              child: TextFormField(
                                textAlign: TextAlign.center,
                                style: TextStyle(fontWeight: FontWeight.normal, fontFamily: 'NotoSansKR', fontSize: 14),
                                keyboardType: TextInputType.number,
                                inputFormatters: <TextInputFormatter>[
                                  MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')
                                ],
                                expands: false,
                                maxLines: 1,
                                controller: TextEditingController(text: Utils.getTimeFormat(item.tipToStand) ?? '--'),//Utils.getTimeSet(value)),
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.zero, borderSide: BorderSide(color: Colors.white, width: 1)),
                                  contentPadding: EdgeInsets.all(5),
                                  counterText: '',
                                ),
                                onChanged: (v){
                                  //item.tipToStand = v;
                                  item.tipToStand = v.toString().replaceAll(':', '');
                                },
                              ),
                            ),
                          )),
                        ]);
                      }).toList(),
                    ),
                  ],
                )
            ),
          ],
        )
      ],
    );
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
