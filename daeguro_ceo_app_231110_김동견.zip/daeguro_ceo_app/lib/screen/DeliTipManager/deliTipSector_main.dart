import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipSectorEditModel.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipSectorListModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/deliTipSectorEdit.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/delitipController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class DeliTipSectorMain extends StatefulWidget {

  const DeliTipSectorMain({Key? key}) : super(key: key);

  @override
  State<DeliTipSectorMain> createState() => _DeliTipSectorMainState();
}

class _DeliTipSectorMainState extends State<DeliTipSectorMain> {

  final ScrollController _scrollController = ScrollController();

  List<DeliTipSectorListModel> dataList = [];

  List<ISOptionModel> selectBox_Gungu = [];
  List<ISOptionModel> selectBox_EditGungu = [];
  List<String> gunguNameList = ['남구', '동구', '서구', '북구', '중구', '달서구', '수성구', '달성군'];

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(DeliTipController.to.getDeliTipSectorList())
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      List<DeliTipSectorListModel> tempListData = [];
      List<String> tempGungu = [];

      value.forEach((element) {
        DeliTipSectorListModel temp = DeliTipSectorListModel();
        temp.ccCode = element['ccCode'] as String;
        temp.shopCd = element['shopCd'] as String;
        temp.sidoName = element['sidoName'] as String;
        temp.sidoCode = element['sidoCode'] as String;
        temp.gunguName = element['gunguName'] as String;
        temp.gunguCode = element['gunguCode'] as String;
        temp.dongName = element['dongName'] as String;

        tempGungu.add(temp.gunguName!);
        tempListData.add(temp);

        int result = dataList.indexWhere((element) => element.gunguName == temp.gunguName);

        if (result == -1) {
          DeliTipSectorListModel tempMainList = DeliTipSectorListModel();
          tempMainList.gunguName = temp.gunguName;
          tempMainList.dongRiName = [];
          dataList.add(tempMainList);
        }
      });

      selectBox_Gungu.clear();
      selectBox_Gungu.add(ISOptionModel(value: '%', label: '군구 선택'));
      for (var element in gunguNameList) {
        if (tempGungu.contains(element) == false){
          selectBox_Gungu.add(ISOptionModel(value: element, label: element));
        }
      }

      dataList.forEach((element) {
        tempListData.forEach((menuElement) {
          if (element.gunguName == menuElement.gunguName){
            element.dongRiName!.add(menuElement.dongName!);
          }
        });
      });
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(DeliTipController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
      //setGunguSelectBox();
    });
  }

  @override
  void dispose() {

    Get.delete();

    _scrollController.dispose();
    dataList.clear();
    selectBox_Gungu.clear();
    selectBox_EditGungu.clear();

    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          if (AuthService.ShopServiceGbn != AuthService.SHOPGBN_FLOWER){
            requestAPIData();
          }
          else{
            router.go('/');
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return currentModeView();
  }

  Widget currentModeView(){
    return SingleChildScrollView(
        controller: _scrollController,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ISLabelBarMain(
              leading: const Text('배달 지역', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
              underLine: false,
              trailing: ISButton(
                child: const Text('추가'),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => DeliTipSectorEdit(jobGbn: '1', gungu: '%', gunguList: selectBox_Gungu),
                  ).then((value) async {
                    requestAPIData();
                  });
                  // sendData = DeliTipSectorEditModel();
                  // sendData.sido = '대구광역시';
                  // sendData.gungu = '%';
                  //
                  // originalDongList.clear();
                  // selectedDongList.clear();
                  //
                  // setState(() {
                  //   currentMode = MODE_DELITIPLOCAL_ADD_VIEW;
                  //
                  //   _scrollController!.jumpTo(0.0);
                  // });
                },
              ),
            ),
            Column(
              children: [
                ...dataList.map((member) =>
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ISLabelBarSub(
                          title: '대구광역시 ${member.gunguName}',
                          titleStyle: const TextStyle(color: Colors.black, fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
                          body: Text(member.dongRiName!.join(', '), style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                          trailing: Row(
                            children: [
                              ISButton(
                                child: const Text('수정'),
                                onPressed: () {
                                  showDialog(
                                    context: context,
                                    barrierDismissible: true,
                                    builder: (context) => DeliTipSectorEdit(jobGbn: '3', gungu: member.gunguName, matchDong: member.dongRiName!),
                                  ).then((value) async {
                                    requestAPIData();
                                  });
                                  // sendData = DeliTipSectorEditModel();
                                  // sendData.sido = '대구광역시';
                                  // sendData.gungu = member.gunguName!;
                                  //
                                  // selectBox_EditGungu.clear();
                                  // selectBox_EditGungu.add(ISOptionModel(value: member.gunguName!, label: member.gunguName!));
                                  //
                                  // loadDongData(sendData.sido, sendData.gungu, member.dongRiName!);
                                  //
                                  // setState(() {
                                  //   currentMode = MODE_DELITIPLOCAL_EDIT_VIEW;
                                  //
                                  //   _scrollController!.jumpTo(0.0);
                                  // });
                                },
                              ),
                              const SizedBox(width: 6),
                              ISButton(
                                isReverseColor: true,
                                child: const Text('삭제'),
                                onPressed: () {
                                  ISConfirm(context, '삭제', '[${member.gunguName!}] 지역을 삭제합니다. 계속 진행하시겠습니까?', (context, isOK) async {
                                    Navigator.pop(context);

                                    if (isOK){
                                      DeliTipSectorEditModel sendData = DeliTipSectorEditModel();
                                      sendData.jobGbn = '3';
                                      sendData.shopCd = AuthService.SHOPCD;
                                      sendData.sido = '대구광역시';
                                      sendData.gungu = member.gunguName;
                                      sendData.dong = [];
                                      sendData.uCode = AuthService.uCode;
                                      sendData.uName = AuthService.uName;

                                      var value = await showDialog(
                                          context: context,
                                          barrierColor: Colors.transparent,
                                          builder: (context) => FutureProgressDialog(DeliTipController.to.setDeliTipSectorInfo(sendData.toJson()))
                                      );

                                      if (value == null) {
                                        ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                      }
                                      else {
                                        if (value == '00') {
                                          requestAPIData();
                                        }
                                        else{
                                          ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                        }
                                      }
                                    }
                                  });
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                ).toList(),
              ],
            ),
            const Divider(height: 1),
          ],
        )
    );
  }
}