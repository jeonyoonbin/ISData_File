import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productListEditModel.dart';
import 'package:daeguro_ceo_app/models/RequestManager/requestShopInfoEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/network/ImageUploadController.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import 'package:http/http.dart' as http;

class RequestShopInfoEdit extends StatefulWidget {
  final ShopInfoModel? sData;
  const RequestShopInfoEdit({Key? key, this.sData})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return RequestShopInfoEditState();
  }
}

enum RadioRequestGbn { requestGbnShopName, requestGbnShopTelno,  requestGbnShopLogo}

class RequestShopInfoEditState extends State<RequestShopInfoEdit> {

  final ScrollController _scrollController = ScrollController();

  List<PickedFile>? imageFileList = <PickedFile>[];

  RadioRequestGbn? _radioRequestGbn;

  ShopInfoModel formData = ShopInfoModel();

  String? inputTextData;

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
    imageFileList?.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ImageUploadController());
    Get.put(RequestController());

    formData = (widget.sData == null) ? ShopInfoModel() : widget.sData!;

    //widget.sData?.useYn = 'Y';
    _radioRequestGbn = RadioRequestGbn.requestGbnShopName;
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 800),
        contentPadding: const EdgeInsets.all(0.0),
        //const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            const Text('매장 정보 변경 요청', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12,),
                  const Text('요청 구분', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Radio(
                          value: RadioRequestGbn.requestGbnShopName,
                          groupValue: _radioRequestGbn,
                          onChanged: (v) async {
                            _radioRequestGbn = v as RadioRequestGbn?;
                            inputTextData = '';
                            imageFileList = [];

                            setState(() {});
                          }),
                      const Text('가맹점명', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      SizedBox(width: Responsive.isMobile(context) ? 20 : 40),
                      Radio(
                          value: RadioRequestGbn.requestGbnShopTelno,
                          groupValue: _radioRequestGbn,
                          onChanged: (v) async {
                            _radioRequestGbn = v as RadioRequestGbn?;
                            inputTextData = '';
                            imageFileList = [];

                            setState(() {});
                          }),
                      const Text('휴대전화 번호', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      SizedBox(width: Responsive.isMobile(context) ? 20 : 40),
                      Radio(
                          value: RadioRequestGbn.requestGbnShopLogo,
                          groupValue: _radioRequestGbn,
                          onChanged: (v) async {
                            _radioRequestGbn = v as RadioRequestGbn?;
                            inputTextData = '';
                            imageFileList = [];

                            setState(() {});
                          }),
                      const Text('로고 이미지', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (_radioRequestGbn != RadioRequestGbn.requestGbnShopLogo)
                    displayInputBoxUse(),

                  Text(imageFileList!.isEmpty ? '첨부 서류' : '첨부 서류(총 ${imageFileList!.length}개)', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  if (imageFileList!.isNotEmpty)...[
                    const SizedBox(height: 8),
                    // SizedBox(// Vertical View
                    //   height: 200,
                    //   child: SingleChildScrollView(
                    //     child: GridView.count(
                    //       shrinkWrap: true,
                    //       crossAxisCount: 4,
                    //       mainAxisSpacing: 4,
                    //       children: List.generate(imageFileList!.length, (idx) {
                    //         return SizedBox(
                    //           width: 100,
                    //           height: 100,
                    //           child: (imageFileList![idx] == null) ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                    //               : Padding(
                    //             padding: const EdgeInsets.symmetric(horizontal: 6),
                    //             child: Image.network('${imageFileList![idx].path}', fit: BoxFit.cover, gaplessPlayback: true,
                    //               errorBuilder: (context, error, stackTrace) {
                    //                 return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                    //               },
                    //             ),
                    //           ),
                    //         );
                    //       }),
                    //     ),
                    //   ),
                    // )
                    SizedBox(
                      height: 120,
                      child: Scrollbar(
                        //isAlwaysShown: true,
                        thumbVisibility: true,
                        trackVisibility: true,
                        controller: _scrollController,
                        radius: const Radius.circular(0.0),
                        showTrackOnHover: true,
                        thickness: 8,
                        child: ListView.builder(
                            controller: _scrollController,
                            itemCount: imageFileList!.length,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, idx) {
                              return Stack(
                                alignment: AlignmentDirectional.topEnd,
                                children: [
                                  (imageFileList![idx] == null) ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                      : Padding(
                                    padding: const EdgeInsets.fromLTRB(4, 0, 4, 20),//symmetric(horizontal: 4, vertical: 20),
                                    child: Image.network(imageFileList![idx].path, fit: BoxFit.cover, gaplessPlayback: true, width: 100, height: 100,
                                      loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                        if (loadingProgress == null) return child;
                                        return const Center(
                                          child: CircularProgressIndicator(
                                            valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                          ),
                                        );
                                      },
                                      errorBuilder: (context, error, stackTrace) {
                                        return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);
                                      },
                                    ),
                                  ),
                                  Positioned(
                                    top: 2,
                                    right: 6,
                                    child: InkWell(
                                      child: const Image(image: AssetImage('images/image_remove_small.png'), width: 20, height: 20,),
                                      onTap: () {
                                        imageFileList!.removeAt(idx);

                                        setState(() {

                                        });
                                      },
                                    ),
                                  )
                                ],
                              );
                            }),
                      ),
                    ),
                  ],
                  Container(
                    constraints: const BoxConstraints(minWidth: 210),
                    width: double.infinity,
                    alignment: Alignment.center,
                    margin: const EdgeInsets.only(top: 10.0),
                    child: InkWell(
                      child: DottedBorder(padding:const EdgeInsets.only(top: 6, bottom: 6,),
                        color: const Color(0xffDDDDDD),
                        strokeWidth: 1,
                        radius: const Radius.circular(10.0),
                        child: const ClipRRect(borderRadius: BorderRadius.all(Radius.circular(10.0)),
                          child: Row(
                            mainAxisAlignment:MainAxisAlignment.center,
                            children: [
                              Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                              SizedBox(width: 8,),
                              Text('이미지 파일 선택', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, color: Color(0xff999999),),),
                            ],
                          ),
                        ),
                      ),
                      onTap: () async {
                        // 이미지 등록
                        ImagePicker imagePicker = ImagePicker();
                        Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                        imageFile.then((file) async {
                          imageFileList!.add(file!);

                          // imageFileList!.forEach((element) {
                          // });

                          setState(() {

                          });
                        });
                      },
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (_radioRequestGbn != RadioRequestGbn.requestGbnShopLogo)
                    Container(
                      //width: MediaQuery.of(context).size.width - 500,//double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                      decoration: const BoxDecoration(
                          color: Color.fromARGB(255, 240, 240, 240),
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      // height: 35,
                      child: const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('수정 요청 시 첨부 서류 : 영업신고증(대체 서류 : 마스킹 처리된 신분증)', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                          SizedBox(height: 8,),
                          Text('※ 마스킹 처리된 신분증 ex)', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                          SizedBox(height: 8,),
                          Align(alignment: Alignment.center, child: Image(image: AssetImage('images/invalid-name@2x.png'), fit: BoxFit.cover, height: 80,)),
                          SizedBox(height: 8,),
                          Text('· 내용을 충분히 확인할 수 있도록 선명하게 촬영된 이미지를 첨부 부탁드리며 정보 확인이 어려울 경우 승인이 지연될 수 있다는 점 양해 바랍니다.', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                          Text('· 로고, 첨부 서류 이미지는 5MB 이하, JPG/PNG 파일만 올릴 수 있습니다.', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                        ],
                      ),
                    ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () {
                if (_radioRequestGbn == RadioRequestGbn.requestGbnShopName) {
                  if (inputTextData == null || inputTextData == ''){
                    ISAlert(context, content: '가맹점명을 확인해 주세요.');
                    return;
                  }else if(inputTextData == formData.shopName){
                    ISAlert(context, content: '기존 가맹점명과 동일합니다.');
                    return;
                  }

                }

                if (_radioRequestGbn == RadioRequestGbn.requestGbnShopTelno){
                  if (inputTextData == null || inputTextData == ''){
                    ISAlert(context, content: '휴대전화 번호를 확인해 주세요.');
                    return;
                  }else if(inputTextData == formData.mobile || inputTextData == Utils.getPhoneNumFormat(formData.mobile!, false)){
                    ISAlert(context, content: '기존 휴대전화 번호와 동일합니다.');
                    return;
                  }
                }

                if (_radioRequestGbn == RadioRequestGbn.requestGbnShopLogo){
                  if (imageFileList == null || imageFileList!.isEmpty){
                    ISAlert(context, content: '선택된 이미지가 없습니다.\n이미지를 선택해 주세요.');
                    return;
                  }
                }

                if (_radioRequestGbn != RadioRequestGbn.requestGbnShopLogo){
                  if (imageFileList == null || imageFileList!.isEmpty){
                    ISAlert(context, content: '첨부 서류가 존재하지 않습니다.\n파일 첨부 후 이용바랍니다.');
                    return;
                  }
                }

                //ISAlert(context, content: '변경 요청 내용을 확인해주세요.');
                BuildContext dialogContext = context;

                ISConfirm(context, '매장 정보 변경', '매장 정보를 변경 요청하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (constraintsContext, isOK) async {
                  Navigator.of(constraintsContext).pop();

                  if (isOK){
                    RequestShopInfoEditModel sendData = RequestShopInfoEditModel();
                    if (_radioRequestGbn == RadioRequestGbn.requestGbnShopName){
                      sendData.serviceGbn = '200';

                      sendData.beforeShopName = AuthService.SHOPNAME;
                      sendData.afterShopName = inputTextData;
                      sendData.beforeMobile = formData.mobile;
                      sendData.afterMobile = formData.mobile;
                    }
                    else if (_radioRequestGbn == RadioRequestGbn.requestGbnShopTelno){
                      sendData.serviceGbn = '201';

                      sendData.beforeShopName = formData.shopName;
                      sendData.afterShopName = formData.shopName;
                      sendData.beforeMobile = formData.mobile;
                      sendData.afterMobile = inputTextData;
                    }
                    else if (_radioRequestGbn == RadioRequestGbn.requestGbnShopLogo){
                      sendData.serviceGbn = '202';

                      sendData.beforeShopName = formData.shopName;
                      sendData.afterShopName = formData.shopName;
                      sendData.beforeMobile = formData.mobile;
                      sendData.afterMobile = formData.mobile;
                    }
                    else{
                      ISAlert(constraintsContext, content: '정상 처리가 되지 않았습니다. \n\n정보 확인 후, 다시 시도해 주세요.');
                    }

                    sendData.shopCd = AuthService.SHOPCD;
                    sendData.status = '10';
                    sendData.uCode = AuthService.uCode;
                    sendData.uName = AuthService.uName;

                    await showDialog(
                        context: constraintsContext,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(RequestController.to.setRequireMultiImageService(sendData, imageFileList!))
                    ).then((value) async {
                      if (value == null) {
                        ISAlert(constraintsContext, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                      }
                      else {
                        http.Response.fromStream(value).asStream().listen((event) {
                          if (event.statusCode == 200) {
                            var result = jsonDecode(event.body);

                            String code = result['code'].toString();
                            String msg = result['msg'].toString();

                            if (code == '00'){
                              Navigator.of(context).pop(true);
                            }
                            else{
                              ISAlert(dialogContext, content: '정상 처리가 되지 않았습니다.\n→ ${msg} ');
                            }
                          }
                          else{
                            Navigator.of(context).pop(true);
                          }
                        });
                      }
                    });
                  }
                });
              },
              child: const Text('변경 요청', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }

  Widget displayInputBoxUse(){
    Widget tempList;

    tempList = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(_radioRequestGbn == RadioRequestGbn.requestGbnShopName ? '가맹점명' : '휴대전화 번호', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
        const SizedBox(height: 8),
        _radioRequestGbn == RadioRequestGbn.requestGbnShopName ?
        ISInput(
          autofocus: true,
          height: 64,
          value: inputTextData,
          context: context,
          label: _radioRequestGbn == RadioRequestGbn.requestGbnShopName ? AuthService.SHOPNAME : Utils.getPhoneNumFormat(formData.mobile!, false),
          maxLength: 50,
          onChange: (v) {
            setState(() {
              if(v.length <= 50){
                inputTextData = v.toString();
              }
            });
          },
        )
        :
        ISInput(
          inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9]'))],
          autofocus: true,
          height: 64,
          value: Utils.getPhoneNumFormat(inputTextData!, false),
          context: context,
          label: _radioRequestGbn == RadioRequestGbn.requestGbnShopName ? AuthService.SHOPNAME : Utils.getPhoneNumFormat(formData.mobile!, false),
          maxLength: 11,
          counterText: '${inputTextData!.length}/11',
          onChange: (v) {
            setState(() {
              if(v.length <= 11){
              inputTextData = v.toString();
              }
            });
          },
        ),
        const SizedBox(height: 8),
      ],
    );

    return tempList;
  }
}

