import 'dart:convert';
import 'dart:typed_data';

import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/models/RequestManager/requestShopInfoEditModel.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class RequestController extends GetxController{
  static RequestController get to => Get.find();

  int total_count = 0;
  int total_page = 0;

  Future<List<dynamic>?> getRequireType() async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_REQUIRETYPE}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }


  Future<dynamic> getRequireList(String status, String serviceGbn, String startdate, String enddate, String page) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_REQUIRELIST}?jobGbn=1&shopCd=${AuthService.SHOPCD}&status=${status}&serviceGbn=${serviceGbn}&frDate=${startdate}&toDate=${enddate}&rows=10&page=${page}');

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['totalCnt'].toString());
      total_page = int.parse(response.data['pageCnt'].toString());

      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  // Future<dynamic> setRequireService(dynamic data) async {
  //   final response = await DioClient().post(ServerInfo.RESTURL_REQUIRESERVICE_SET, data: data);
  //
  //   if (response.data['code'] != '00') {
  //     return response.data['msg'];
  //   } else
  //     return response.data['code'];
  // }

  // Future<dynamic> setRequireServiceV2(dynamic data) async {
  //   final response = await DioClient().post(ServerInfo.RESTURL_REQUIRESERVICEV2_SET, data: data);
  //
  //   if (response.data['code'] != '00') {
  //     return response.data['msg'];
  //   } else
  //     return response.data['code'];
  // }

  Future<dynamic> setRequireMultiImageService(RequestShopInfoEditModel data, List<PickedFile> fileResArr) async {
    var retResult;

    final accessToken = await AuthService.to.userStorage.read(key: '@user_token');

    // String baseURL = ServerInfo.jobMode == 'dev' ?  ServerInfo.REST_BASEURL_DEV : ServerInfo.REST_BASEURL_REAL;

    var request = http.MultipartRequest('POST', Uri.parse(ServerInfo.RESTURL_REQUIRESERVICE_SETMULTI));

    request.headers.addAll({
      'Content-Type' : 'multipart/form-data',
      'Authorization' : 'Bearer $accessToken'
    });

    //request.fields.addAll(data.toJson());

    request.fields['seq'] = data.seq!;
    request.fields['shopCd'] = data.shopCd!;
    request.fields['status']  = data.status!;
    request.fields['serviceGbn'] = data.serviceGbn!;
    request.fields['filter'] = data.filter!;
    request.fields['AfterShopName'] = data.afterShopName!;
    request.fields['BeforeShopName'] = data.beforeShopName!;
    request.fields['AfterMobile'] = data.afterMobile!;
    request.fields['BeforeMobile'] = data.beforeMobile!;
    request.fields['groupCd'] = data.groupCd!;
    request.fields['menuCd'] = data.menuCd!;
    request.fields['menuName'] = data.menuName!;
    request.fields['image_url'] = data.image_url!;
    request.fields['beforeImageUrl'] = data.beforeImageUrl!;
    request.fields['a_reg_no'] = data.a_reg_no!;
    request.fields['a_buss_owner'] = data.a_buss_owner!;
    request.fields['a_buss_con'] = data.a_buss_con!;
    request.fields['a_buss_type'] = data.a_buss_type!;
    request.fields['a_buss_addr'] = data.a_buss_addr!;
    request.fields['a_buss_tax_type'] = data.a_buss_tax_type!;
    request.fields['a_owner'] = data.a_owner!;
    request.fields['b_reg_no'] = data.b_reg_no!;
    request.fields['b_buss_owner'] = data.b_buss_owner!;
    request.fields['b_buss_con'] = data.b_buss_con!;
    request.fields['b_buss_type'] = data.b_buss_type!;
    request.fields['b_buss_addr'] = data.b_buss_addr!;
    request.fields['b_buss_tax_type'] = data.b_buss_tax_type!;
    request.fields['b_owner'] = data.b_owner!;
    request.fields['reason'] = data.reason!;
    request.fields['first'] = data.first!;
    request.fields['second'] = data.second!;
    request.fields['third'] = data.third!;
    request.fields['prodCd'] = data.prodCd!;
    request.fields['prodName'] = data.prodName!;
    request.fields['uCode'] = data.uCode!;
    request.fields['uName'] = data.uName!;

    if (fileResArr.isNotEmpty){
      for (var imageFile in fileResArr) {
        Uint8List data = await imageFile.readAsBytes();
        List<int> filebytes = data.cast();

        request.files.add(http.MultipartFile.fromBytes('formFiles', filebytes, filename: 'upload_temp.png'));
      }
    }
    else{
      List<int> filebytes = [];
      request.files.add(http.MultipartFile.fromBytes('formFiles', filebytes, filename: 'upload_temp.png'));
    }

    retResult = await request.send();

    return retResult;
  }

  Future<dynamic> setRequireSingleImageService(RequestShopInfoEditModel data, List<PickedFile> fileResArr) async {
    var retResult;

    final accessToken = await AuthService.to.userStorage.read(key: '@user_token');

    // String baseURL = ServerInfo.jobMode == 'dev' ?  ServerInfo.REST_BASEURL_DEV : ServerInfo.REST_BASEURL_REAL;

    var request = http.MultipartRequest('POST', Uri.parse(ServerInfo.RESTURL_REQUIRESERVICE_SETSINGLE));

    request.headers.addAll({
      'Content-Type' : 'multipart/form-data',
      'Authorization' : 'Bearer $accessToken'
    });

    //request.fields.addAll(data.toJson());

    request.fields['seq'] = data.seq!;
    request.fields['shopCd'] = data.shopCd!;
    request.fields['status']  = data.status!;
    request.fields['serviceGbn'] = data.serviceGbn!;
    request.fields['filter'] = data.filter!;
    request.fields['groupCd'] = data.groupCd!;
    request.fields['menuCd'] = data.menuCd!;
    request.fields['menuName'] = data.menuName!;
    request.fields['uCode'] = data.uCode!;
    request.fields['uName'] = data.uName!;


    if (fileResArr.isNotEmpty){
      for (var imageFile in fileResArr) {
        Uint8List data = await imageFile.readAsBytes();
        List<int> filebytes = data.cast();

        request.files.add(http.MultipartFile.fromBytes('formFile', filebytes, filename: 'upload_temp.png'));
      }
    }
    else{
      List<int> filebytes = [];
      request.files.add(http.MultipartFile.fromBytes('formFile', filebytes, filename: 'upload_temp.png'));
    }

    retResult = await request.send();

    return retResult;
  }


  Future<dynamic> getGoodShopReqDetail() async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_REQUIRESERVICE_GETGOODSHOP}?jobGbn=1&shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    }
    else {
      return null;
    }

    return qData;
  }

}