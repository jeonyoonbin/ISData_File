import 'package:flutter/material.dart';

class UserNotifier extends ChangeNotifier {
  bool _userStatus = false;

  bool get userStatus => _userStatus;
  void changeStatus(bool status) {
    _userStatus = status;
    notifyListeners();
  }
}