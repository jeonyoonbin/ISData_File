import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_singleToggleButton.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/multiShopAbsentEditModel.dart';
import 'package:daeguro_ceo_app/models/multiShopStatusListModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class MultiShopDashboardInfo extends StatefulWidget {
  const MultiShopDashboardInfo({Key? key}) : super(key: key);

  @override
  State<MultiShopDashboardInfo> createState() => _MultiShopDashboardInfoState();
}

class _MultiShopDashboardInfoState extends State<MultiShopDashboardInfo> with PageMixin {

  List<MultiShopStatusListModel> dataList = <MultiShopStatusListModel>[];

  String? switchValue = 'Y';

  requestAPIData() async {

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ShopController.to.getMultiShopStatusList())
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        MultiShopStatusListModel temp = MultiShopStatusListModel();
        temp.shopCd = element['shopCd'] as String;
        temp.shopName = element['shopName'] as String;
        temp.itemCd = element['itemCd'] as String;
        temp.itemCd2 = element['itemCd2'] as String;
        temp.itemCd3 = element['itemCd3'] as String;
        temp.absentYn = element['absentYn'] as String;
        temp.repYn = element['repYn'] as String;

        if (temp.itemCd != '')         temp.itemList!.add(getDivName(temp.itemCd!));
        if (temp.itemCd2 != '')        temp.itemList!.add(getDivName(temp.itemCd2!));
        if (temp.itemCd3 != '')        temp.itemList!.add(getDivName(temp.itemCd3!));

        dataList.add(temp);
      });
    }

    setState(() {});
  }

  requestMultiShopAllAbsent(String absent) async {
    MultiShopAbsentEditModel formData = MultiShopAbsentEditModel();

    dataList.forEach((element) {
      formData.shopCd!.add(element.shopCd!);
      formData.absentYn!.add(absent);
    });

    formData.uCode = AuthService.uCode;
    formData.uName = AuthService.uName;

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ShopController.to.updateMultiShopAbsent(formData.toJson()))
    );

    if (value == null) {
      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
    }
    else {
      if (value == '00') {
        requestAPIData();
      }
      else{
        ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
      }
    }
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    // dataList.clear();
    // paginatedDataList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return fluentUI.ScaffoldPage.scrollable(
      //scrollController: AppTheme.mainScrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      children: <Widget>[
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ISLabelBarMain(
              leading: const Text('전체 매장 현황', style: TextStyle(color: Colors.black, fontSize: 22, fontWeight: FontWeight.bold),),
              trailing: Responsive.isMobile(context) ? Container() : Row(
                children: [
                  ISButton(
                    child: const Text('전체 영업중지'),
                    buttonColor: Colors.black54,
                    onPressed: () {
                      ISConfirm(context, '전체 매장 영업 중지', '전체 매장에 대한 영업 중지 처리를 진행하시겠습니까?', (context, isOK) async {
                        Navigator.of(context).pop();

                        if (isOK){
                          requestMultiShopAllAbsent('N');

                          int retValue = dataList.indexWhere((element) => element.shopCd == AuthService.SHOPCD);
                          if (retValue != -1){
                            AuthService.ShopStatus = 'N';
                            appTheme.currentShopStatusGbn = 'N';
                          }
                        }
                      });
                    },
                  ),
                  const SizedBox(width: 8,),
                  ISButton(
                    child: const Text('전체 영업 재개'),
                    onPressed: () {
                      ISConfirm(context, '전체 매장 영업 재개', '전체 매장에 대한 영업 재개 처리를 진행하시겠습니까?', (context, isOK) async {
                        Navigator.of(context).pop();

                        if (isOK){
                          requestMultiShopAllAbsent('Y');

                          int retValue = dataList.indexWhere((element) => element.shopCd == AuthService.SHOPCD);
                          if (retValue != -1){
                            AuthService.ShopStatus = 'Y';
                            appTheme.currentShopStatusGbn = 'Y';
                          }
                        }
                      });
                    },
                  )
                ],
              ),
            ),
            const SizedBox(height: 8),
            Responsive.isMobile(context) ? Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  Expanded(
                    child: ISButton(
                      child: const Text('전체 영업중지'),
                      buttonColor: Colors.black54,
                      onPressed: () {
                        ISConfirm(context, '전체 매장 영업 중지', '전체 매장에 대한 영업 중지 처리를 진행하시겠습니까?', (context, isOK) async {
                          Navigator.of(context).pop();

                          if (isOK){
                            requestMultiShopAllAbsent('N');

                            int retValue = dataList.indexWhere((element) => element.shopCd == AuthService.SHOPCD);
                            if (retValue != -1){
                              AuthService.ShopStatus = 'N';
                              appTheme.currentShopStatusGbn = 'N';
                            }
                          }
                        });
                      },
                    ),
                  ),
                  const SizedBox(width: 8,),
                  Expanded(
                    child: ISButton(
                      child: const Text('전체 영업 재개'),
                      onPressed: () {
                        ISConfirm(context, '전체 매장 영업 재개', '전체 매장에 대한 영업 재개 처리를 진행하시겠습니까?', (context, isOK) async {
                          Navigator.of(context).pop();

                          if (isOK){
                            requestMultiShopAllAbsent('Y');

                            int retValue = dataList.indexWhere((element) => element.shopCd == AuthService.SHOPCD);
                            if (retValue != -1){
                              AuthService.ShopStatus = 'Y';
                              appTheme.currentShopStatusGbn = 'Y';
                            }
                          }
                        });
                      },
                    ),
                  )
                ],
              ),
            ) : Container(),
            const Card(
              elevation: 0,
              color: Color(0xFFf3f3f3),
              child: Padding(
                padding: EdgeInsets.all(12),
                child: SizedBox(
                    width: double.infinity,
                    child: Text('* 전체 매장 영업현황입니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: Colors.black54),)
                ),
              ),
            ),
            itemListView()
          ],
        )
      ],
    );
  }

  Widget itemListView() {
    final appTheme = context.watch<AppTheme>();

    return ListView.builder(
        shrinkWrap: true,
        padding: EdgeInsets.zero,
        physics: const NeverScrollableScrollPhysics(),
        itemBuilder: (ctx, index){
          return Card(
            key: Key('$index'),
            elevation: 1,
            shape: appTheme.cardShapStyle,
            margin: const EdgeInsets.all(4),
            //color: dataMenuList[index].selected == true ? const Color.fromRGBO(165, 216, 252, 1.0) : Colors.white,
            child: InkWell(
              splashColor: const Color.fromRGBO(165, 216, 252, 1.0),
              onTap: () {
                // for (var element in dataItemList) {
                //   element.selected = false;
                // }
                // // _menuGroupCd = dataGroupList[index].menuGroupCd;
                // //
                // // ShopController.to.MainCount.value = int.parse(dataGroupList[index].mainCount);
                // //
                // dataItemList[index].selected = true;
                // //
                // // loadMenuListData(dataGroupList[index].menuGroupCd, menuGroupName: dataGroupList[index].menuGroupName);
                // setState(() {});
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: SingleChildScrollView(
                  scrollDirection: Responsive.isMobile(context) ? Axis.horizontal : Axis.vertical,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    const SizedBox(width: 8,),
                    Flexible(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            const SizedBox(height: 5),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Text(dataList[index].shopName ?? '--', style: const TextStyle(fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                                    if (dataList[index].repYn == 'Y')...[
                                      const SizedBox(width: 8),
                                      OutlinedButton(
                                        style: ButtonStyle(side: MaterialStateProperty.all(const BorderSide(color: Color(0xff01CAFF)))),
                                        onPressed: () {
                                        },
                                        child: const Text('대표', style: TextStyle(color: Color(0xff01CAFF), fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      )
                                    ]
                                  ],
                                ),
                                Material(
                                  color: Colors.transparent,
                                  child: SizedBox(
                                    //color: Colors.transparent,
                                    width: 160,
                                    child: SwitchListTile(
                                      dense: true,
                                      value: dataList[index].absentYn == 'Y' ? true : false,
                                      hoverColor: Colors.transparent,
                                      //tileColor: Colors.transparent,
                                      title: dataList[index].absentYn == 'Y'
                                          ? const Text( '영업 중', style: TextStyle(color: Colors.blueAccent, fontSize: 14, fontFamily: FONT_FAMILY),)
                                          : const Text( '휴점 중', style: TextStyle(color: Colors.redAccent, fontSize: 14, fontFamily: FONT_FAMILY),),
                                      onChanged: (v) {
                                        String oldAbsentYn = dataList[index].absentYn!;

                                        ISConfirm(context, '가맹점 ${v ? '재개' : '휴점'}', '${dataList[index].shopName} 매장을 영업 ${v ? '재개' : '휴점'} 처리하시겠습니까?', (context, isOK) async {
                                          if (isOK){
                                            dataList[index].absentYn = v ? 'Y' : 'N';
                                            Navigator.of(context).pop();
                                            MultiShopAbsentEditModel formData = MultiShopAbsentEditModel();

                                            formData.shopCd!.add(dataList[index].shopCd!);
                                            formData.absentYn!.add(dataList[index].absentYn!);
                                            formData.uCode = AuthService.uCode;
                                            formData.uName = AuthService.uName;

                                            var value = await showDialog(
                                                context: context,
                                                barrierColor: Colors.transparent,
                                                builder: (context) => FutureProgressDialog(ShopController.to.updateMultiShopAbsent(formData.toJson()))
                                            );

                                            if (value == null) {
                                              ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                                            }
                                            else {
                                              if (value == '00') {
                                                if (dataList[index].shopCd == AuthService.SHOPCD ){
                                                  AuthService.ShopStatus = dataList[index].absentYn;
                                                  appTheme.currentShopStatusGbn = dataList[index].absentYn;
                                                }

                                                requestAPIData();
                                              }
                                              else{
                                                ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                              }
                                            }
                                          }
                                          else{
                                            Navigator.of(context).pop();
                                            setState(() {
                                              dataList[index].absentYn = oldAbsentYn;
                                            });
                                          }
                                        });
                                        setState(() {
                                          // selected = oldSelected!;
                                        });
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const Divider(),
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8.0),
                              child: Row(
                                children: [
                                  const Text('업종 카테고리', style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                                  const SizedBox(width: 16),
                                  Text(dataList[index].itemList!.join(' | ').toString(), style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                                ],
                              ),
                                ),
                            )
                            //Text('${Utils.getCashComma(dataItemList[index].menuCost!)} 원', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            ),
          );
        },
        itemCount: dataList.length
    );
  }

  String getDivName(String code){
    if (code == "1000")    return  "1인분";
    else if (code == "1001")    return "치킨/찜닭";
    else if (code == "1003")    return "피자";
    else if (code == "1004")    return "중식";
    else if (code == "1005")    return "분식";
    else if (code == "1006")    return "족발/보쌈";
    else if (code == "1007")    return "야식";
    else if (code == "1008")    return "한식";
    else if (code == "1013")    return "돈까스/일식";
    else if (code == "1014")    return "아시안/양식";
    else if (code == "1024")    return "패스트푸드";
    else if (code == "1025")    return "도시락/죽" ;
    else if (code == "1026")    return "카페/디저트";
    else if (code == "1027")    return "반찬";
    else if (code == "1028")    return "찜/탕";
    else if (code == "1029")    return "정육";
    else if (code == "1030")    return "펫";
    else if (code == "1031")    return "로컬푸드";
    else if (code == "1032")    return "특별관";
    else if (code == "1033")    return "전통시장";
    else if (code == "1034")    return "꽃배달";
    else if (code == "1035")    return "밀키트";
    else if (code == "1036")    return "장보기";
    else if (code == "2000")    return "블랙데이";
    else if (code == "2001")    return "착한 매장";
    else if (code == "2003")    return "떡볶이ZONE";
    else if (code == "9000")    return "기타";

    return '';
  }
}