import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/calendarView/calendar_event_data.dart';
import 'package:daeguro_ceo_app/iswidgets/calendarView/enumerations.dart';
import 'package:daeguro_ceo_app/iswidgets/calendarView/event_controller.dart';
import 'package:daeguro_ceo_app/iswidgets/calendarView/month_view.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveDateStatusModel.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveMagamModel.dart';
import 'package:daeguro_ceo_app/models/event.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ReserveManager30 extends StatefulWidget {
  final double? tabviewHeight;

  const ReserveManager30({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ReserveManager30> createState() => _ReserveManager30State();
}

class _ReserveManager30State extends State<ReserveManager30> {
  List<ReserveDateStatusModel> dataList = <ReserveDateStatusModel>[];


  EventController _controller = EventController();

  String magamGbn = 'N';
  String dateBegin = formatDate(DateTime.now(), [yyyy, mm, dd]);
  // 해당 월의 마지막 일 계산 (28일, 30일, 31일)
  String dateEnd = formatDate(DateTime.now(), [yyyy, mm,  DateTime(DateTime.now().year, DateTime.now().month + 1, 0).day.toString()]);

  DateTime initDate = DateTime.now();

  int sumStatus10 = 0; // 예약대기 합계
  int sumStatus12 = 0; // 방문예정 합계
  int sumStatus30 = 0; // 방문완료 합계
  int sumStatus40 = 0; // 취소 합계
  int sumStatus90 = 0; // 미방문 합계

  String absentYn = '';

  var _selectedDate;

  requestReserveManageInfo() async {
    await ReserveController.to.getShopInfoReserveManageInfo(AuthService.SHOPCD).then((value) {
      if (value == null) {
      } else {
        value.forEach((element) {
          if(element['absentYn'] == 'Y') {
            absentYn = '영업 중';
          } else {
            absentYn = '휴점 중';
          }
        });
      }
    });

    setState(() {});
  }

  requestAPIshopMagamData() async {
    await ReserveController.to.getReserveShopMagam(AuthService.SHOPCD).then((value) {
      if (value == null) {
        ISAlert(context, title: '마감 여부 조회 실패', content: '마감 여부 조회에 실패하였습니다.');
      } else {
        value.forEach((element) {
          magamGbn = element['reserMagamGbn'].toString();
        });
      }
    });

    setState(() {});
  }

  requestAPIData() async {
    await ReserveController.to.getReserveDateStatus(AuthService.SHOPCD, dateBegin, dateEnd).then((value) {
      if (value == null) {
        ISAlert(context, title: '예약 현황 조회 실패', content: '예약 현황 조회에 실패하였습니다.');
      } else {
        dataList.clear();

        value.forEach((element) {
          ReserveDateStatusModel temp = ReserveDateStatusModel();

          temp.reserDate = element['reserDate'] as String;
          temp.status10 = element['status10'] as int;
          temp.status12 = element['status12'] as int;
          temp.status30 = element['status30'] as int;
          temp.status40 = element['status40'] as int;
          temp.status90 = element['status90'] as int;

          dataList.add(temp);
        });

        _controller.addAll(setCalendarEventList());
      }
    });

    _controller.notifyListeners();

    setState(() {});
  }

  List<CalendarEventData> setCalendarEventList(){
    final List<CalendarEventData> status = <CalendarEventData>[];

    TextStyle eventStyle = const TextStyle(fontSize: 12, color: Colors.white, fontFamily: FONT_FAMILY);

    for (var element in dataList) {
      if(element.reserDate == null || element.reserDate.toString() == '') {
        return status;
      }

      if (element.status10 != 0) {
        status.add(CalendarEventData(
          title: Responsive.isMobile(context) ? '예약(${element.status10}) ' : '예약 대기(${element.status10}) ',
          date: DateTime.parse(element.reserDate.toString()),
          startTime: DateTime.parse(element.reserDate.toString()),
          endTime: DateTime.parse(element.reserDate.toString()),
          color: const Color(0xFFFBC02D),
          titleStyle: eventStyle,
        ));
      }

      if (element.status12 != 0) {
        status.add(CalendarEventData(
          event: Event(title: "${element.status12}"),
          title: Responsive.isMobile(context) ? '예정(${element.status12}) ' : '방문 예정(${element.status12}) ',
          date: DateTime.parse(element.reserDate.toString()),
          startTime: DateTime.parse(element.reserDate.toString()),
          endTime: DateTime.parse(element.reserDate.toString()),
          color: const Color(0xFF00E676),
          titleStyle: eventStyle,
        ));
      }

      if (element.status30 != 0) {
        status.add(CalendarEventData(
          event: Event(title: "${element.status30}"),
          title: Responsive.isMobile(context) ? '완료(${element.status30}) ' : '방문 완료(${element.status30}) ',
          date: DateTime.parse(element.reserDate.toString()),
          startTime: DateTime.parse(element.reserDate.toString()),
          endTime: DateTime.parse(element.reserDate.toString()),
          color: const Color(0xFF40C4FF),
          titleStyle: eventStyle,
        ));
      }

      if (element.status40 != 0) {
        status.add(CalendarEventData(
          event: Event(title: "${element.status40}"),
          title: Responsive.isMobile(context) ? '취소(${element.status40}) ' : '예약취소(${element.status40}) ',
          date: DateTime.parse(element.reserDate.toString()),
          startTime: DateTime.parse(element.reserDate.toString()),
          endTime: DateTime.parse(element.reserDate.toString()),
          color: const Color(0xFFFF5252),
          titleStyle: eventStyle,
        ));
      }

      if (element.status90 != 0) {
        status.add(CalendarEventData(
          event: Event(title: "${element.status90}"),
          title: '미방문 (${element.status90})',
          date: DateTime.parse(element.reserDate.toString()),
          startTime: DateTime.parse(element.reserDate.toString()),
          endTime: DateTime.parse(element.reserDate.toString()),
          color: const Color(0xFF9E9E9E),
          titleStyle: eventStyle,
        ));
      }
    }

    return status;
  }

  requestAPISumData() async {
    sumStatus10 = 0;
    sumStatus12 = 0;
    sumStatus30 = 0;
    sumStatus40 = 0;
    sumStatus90 = 0;

    await ReserveController.to.getReserveDateStatusTotal(AuthService.SHOPCD).then((value) {
      if (value == null) {
        ISAlert(context, title: '예약 현황 조회 실패', content: '예약 현황 조회에 실패하였습니다.');
      } else {
        dataList.clear();

        value.forEach((element) {
          ReserveDateStatusModel temp = ReserveDateStatusModel();

          sumStatus10 = element['status10'] as int;
          sumStatus12 = element['status12'] as int;
          sumStatus30 = element['status30'] as int;
          sumStatus40 = element['status40'] as int;
          sumStatus90 = element['status90'] as int;

          dataList.add(temp);
        });
      }
    });

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());

    requestReserveManageInfo();
    requestAPIData();
    requestAPISumData();
    requestAPIshopMagamData();


  }

  @override
  void dispose() {
    dataList.clear();

    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
          requestAPISumData();
          requestAPIshopMagamData();
          requestReserveManageInfo();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    var mobileContent = SingleChildScrollView(
      child: Material(
        child: Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                      alignment: Alignment.center,
                      height: 40,
                      width: 100,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), color: absentYn.toString() == '영업 중' ? const Color(0xff01CAFF) : Colors.grey,),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(absentYn.toString(), style: TextStyle(color: Colors.white, fontSize: 17)),
                          SizedBox(width: 5),
                          Icon(absentYn.toString() == '영업 중' ? fluentUI.FluentIcons.sunny : Icons.cloud_outlined, color: Colors.white, size: 30),
                        ],
                      )),
                  const SizedBox(width: 20),
                  const Text('당일 예약 마감', style: TextStyle(fontSize: 17, fontFamily: FONT_FAMILY_NEXON)),
                  const SizedBox(width: 10),
                  Transform.scale(
                    scale: 1.2,
                    child: Switch(
                        value: magamGbn == 'Y' ? true : false,
                        splashRadius: 1,
                        onChanged: (v) {
                          ISConfirm(context, magamGbn == 'N' ? '당일 예약 마감' : '당일 예약 마감 해지', magamGbn == 'N' ? '당일 예약 마감 처리를 하시겠습니까?' : '당일 예약 마감 처리를 해지하시겠습니까?', (context, isOK) async {
                            Navigator.of(context).pop();

                            if (isOK) {
                              ReserveMagamModel sendData = ReserveMagamModel();
                              sendData.shopCode = AuthService.SHOPCD;
                              sendData.userId = AuthService.uCode;
                              sendData.reserMagamGbn = v ? 'Y' : 'N';

                              var value = await showDialog(
                                  context: context,
                                  builder: (context) => FutureProgressDialog(ReserveController.to.updateReserveShopMagam(sendData.toJson()))
                              );

                              if (value == null) {
                                ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                              }
                              else {
                                if (value == '00') {
                                  ISAlert(context, title: magamGbn == 'N' ? '당일 예약 마감' : '당일 예약 마감 해지', content: '정상적으로 당일 예약 마감 처리가 되었습니다.');
                                }
                              }

                              setState(() {
                                magamGbn = v ? 'Y' : 'N';
                              });
                            }
                          });
                        }),
                  )
                ],
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  const Text('안녕하세요, ', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON)),
                  Text(AuthService.SHOPNAME.toString(), style: const TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON, color: Color(0xff01CAFF), fontWeight: FONT_BOLD)),
                  const Text(' 사장님.', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON)),
                ],
              ),
              const SizedBox(height: 10),
              const Text('오늘도 행복한 하루 보내시길 바랍니다.', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON)),
              const SizedBox(height: 20),
              const Text('월간 예약 현황 >', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
              const SizedBox(height: 10),
              Wrap(
                children: [
                  Container(
                    margin: const EdgeInsets.all(5),
                    alignment: Alignment.center,
                    height: 35,
                    width: 120,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: const Color(0xFFFDD835)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Text('예약 대기', style: TextStyle(color: Colors.white, fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                        const SizedBox(width: 5),
                        Text(sumStatus10.toString(), style: const TextStyle(color: Colors.white, fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                      ],
                    )),
                  Container(
                      margin: const EdgeInsets.all(5),
                      alignment: Alignment.center,
                      height: 35,
                      width: 120,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: const Color(0xFF00E676)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text('방문 예정', style: TextStyle(color: Colors.white, fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                          const SizedBox(width: 5),
                          Text(sumStatus12.toString(), style: const TextStyle(color: Colors.white, fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                        ],
                      )),
                  Container(
                      margin: const EdgeInsets.all(5),
                      alignment: Alignment.center,
                      height: 35,
                      width: 120,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: const Color(0xFF40C4FF)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text('방문 완료', style: TextStyle(color: Colors.white, fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                          const SizedBox(width: 5),
                          Text(sumStatus30.toString(), style: const TextStyle(color: Colors.white, fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                        ],
                      )),
                  Container(
                      margin: const EdgeInsets.all(5),
                      alignment: Alignment.center,
                      height: 35,
                      width: 120,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: const Color(0xFF9E9E9E)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text('미방문', style: TextStyle(color: Colors.white, fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                          const SizedBox(width: 5),
                          Text(sumStatus90.toString(), style: const TextStyle(color: Colors.white, fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                        ],
                      )),
                  Container(
                      margin: const EdgeInsets.all(5),
                      alignment: Alignment.center,
                      height: 35,
                      width: 120,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: const Color(0xFFFF5252)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text('취소', style: TextStyle(color: Colors.white, fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                          const SizedBox(width: 5),
                          Text(sumStatus40.toString(), style: const TextStyle(color: Colors.white, fontSize: 15, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                        ],
                      )),
                ],
              ),
              const SizedBox(height: 10),
              Container(
                width: 850,
                height: 800,
                child: MonthView(
                  controller: _controller,
                  cellBuilder: (date, events, isToday, isInMonth) {
                    // Return your widget to display as month cell.
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: const EdgeInsets.only(left: 5, top: 5),
                          child: Text('${date.day} 일', style: _todayTextStyle(isToday, isInMonth),),
                        ),
                        SingleChildScrollView(
                          physics: BouncingScrollPhysics(),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: List.generate(
                              events.length,
                                  (index) => GestureDetector(
                                onTap: () {
                                  //onTileTap?.call(events[index], events[index].date),
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: events[index].color,
                                    borderRadius: BorderRadius.circular(4.0),
                                  ),
                                  margin: const EdgeInsets.symmetric(vertical: 2.0, horizontal: 3.0),
                                  padding: const EdgeInsets.all(2.0),
                                  alignment: Alignment.center,
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          events[index].title,
                                          overflow: TextOverflow.clip,
                                          maxLines: 1,
                                          style: events[0].titleStyle ?? TextStyle(color: events[index].color, fontSize: 12,),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    );
                  },
                  weekDayBuilder: (weekDay) {
                    String dayStr = '';
                    switch (weekDay) {
                      case 0:           dayStr = '월';                        break;
                      case 1:           dayStr = '화';                        break;
                      case 2:           dayStr = '수';                        break;
                      case 3:           dayStr = '목';                        break;
                      case 4:           dayStr = '금';                        break;
                      case 5:           dayStr = '토';                        break;
                      case 6:           dayStr = '일';                        break;
                    }
                    return Container(
                      padding: const EdgeInsets.symmetric(vertical: 4.0),
                      decoration: BoxDecoration(color: Colors.white, border: Border.all(color: Colors.black12, width: 1)),
                      child: Align(
                          alignment: Alignment.center,
                          child: Text(dayStr, style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))
                      ),
                    );
                  },
                  minMonth: DateTime(2020),
                  maxMonth: DateTime(2050),
                  initialMonth: initDate,
                  cellAspectRatio: 1,
                  onPageChange: (date, pageIndex){
                    //=> print("$date, $pageIndex"),
                    dateBegin = formatDate(date, [yyyy, mm, dd]);
                    dateEnd = formatDate(date, [yyyy, mm,  DateTime(DateTime.now().year, DateTime.now().month + 1, 0).day.toString()]);
                    requestAPIData();
                  },
                  onCellTap: (events, date) {
                    // Implement callback when user taps on a cell.
                  },
                  startDay: WeekDays.sunday, // To change the first day of the week.
                  // This callback will only work if cellBuilder is null.
                  onEventTap: (event, date) {
                  },
                ),
              )
            ],
          ),
        ),
      ),
    );

    var desktopContent = SingleChildScrollView(
      child: Material(
        child: Container(
          margin: const EdgeInsets.only(left: 20, top: 30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                      alignment: Alignment.center,
                      height: 50,
                      width: 120,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), color: absentYn.toString() == '영업 중' ? const Color(0xff01CAFF) : Colors.grey,),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(absentYn.toString(), style: TextStyle(color: Colors.white, fontSize: 20)),
                          SizedBox(width: 5),
                          Icon(absentYn.toString() == '영업 중' ? fluentUI.FluentIcons.sunny : Icons.cloud_outlined, color: Colors.white, size: 30),
                        ],
                      )),
                  const SizedBox(width: 30),
                  const Text('당일 예약 마감', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON)),
                  const SizedBox(width: 10),
                  Transform.scale(
                    scale: 1.5,
                    child: Switch(
                        value: magamGbn == 'Y' ? true : false,
                        splashRadius: 1,
                        onChanged: (v) {
                          ISConfirm(context, magamGbn == 'N' ? '당일 예약 마감' : '당일 예약 마감 해지', magamGbn == 'N' ? '당일 예약 마감 처리를 하시겠습니까?' : '당일 예약 마감 처리를 해지하시겠습니까?', (context, isOK) async {
                            Navigator.of(context).pop();

                            if (isOK) {
                              ReserveMagamModel sendData = ReserveMagamModel();
                              sendData.shopCode = AuthService.SHOPCD;
                              sendData.userId = AuthService.uCode;
                              sendData.reserMagamGbn = v ? 'Y' : 'N';

                              var value = await showDialog(
                                  context: context,
                                  builder: (context) => FutureProgressDialog(ReserveController.to.updateReserveShopMagam(sendData.toJson()))
                              );

                              if (value == null) {
                                ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                              }
                              else {
                                if (value == '00') {
                                  ISAlert(context, title: magamGbn == 'N' ? '당일 예약 마감' : '당일 예약 마감 해지', content: '정상적으로 당일 예약 마감 처리가 되었습니다.');
                                }
                              }

                              setState(() {
                                magamGbn = v ? 'Y' : 'N';
                              });
                            }
                          });
                        }),
                  )
                ],
              ),
              const SizedBox(height: 30),
              Row(
                children: [
                  const Text('안녕하세요, ', style: TextStyle(fontSize: 35, fontFamily: FONT_FAMILY_NEXON)),
                  Text(AuthService.SHOPNAME.toString(), style: const TextStyle(fontSize: 35, fontFamily: FONT_FAMILY_NEXON, color: Color(0xff01CAFF), fontWeight: FONT_BOLD)),
                  const Text(' 사장님.', style: TextStyle(fontSize: 35, fontFamily: FONT_FAMILY_NEXON)),
                ],
              ),
              const SizedBox(height: 10),
              const Text('오늘도 행복한 하루 보내시길 바랍니다.', style: TextStyle(fontSize: 35, fontFamily: FONT_FAMILY_NEXON)),
              const SizedBox(height: 30),
              Container(
                width: 850,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                child: Container(
                  margin: const EdgeInsets.all(30),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('월간 예약 현황 >', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                      const SizedBox(height: 15),
                      Row(
                        children: [
                          Text(sumStatus10.toString(), style: const TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON, color: Color(0xff01CAFF), fontWeight: FONT_BOLD)),
                          const Text(' 건의 예약 대기 중인 오더가 있습니다.', style: TextStyle(fontSize: 20, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                        ],
                      ),
                      const SizedBox(height: 5),
                      const Text('POS에서 예약 확정을 해주세요!', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON)),
                      const SizedBox(height: 15),
                      Wrap(
                        children: [
                          Container(
                              alignment: Alignment.center,
                              height: 45,
                              width: 150,
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: const Color(0xFFFDD835)),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text('예약 대기', style: TextStyle(color: Colors.white, fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                                  const SizedBox(width: 5),
                                  Text(sumStatus10.toString(), style: const TextStyle(color: Colors.white, fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                                ],
                              )),
                          const SizedBox(width: 10),
                          Container(
                              alignment: Alignment.center,
                              height: 45,
                              width: 150,
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: const Color(0xFF00E676)),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text('방문 예정', style: TextStyle(color: Colors.white, fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                                  const SizedBox(width: 5),
                                  Text(sumStatus12.toString(), style: const TextStyle(color: Colors.white, fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                                ],
                              )),
                          const SizedBox(width: 10),
                          Container(
                              alignment: Alignment.center,
                              height: 45,
                              width: 150,
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: const Color(0xFF40C4FF)),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text('방문 완료', style: TextStyle(color: Colors.white, fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                                  const SizedBox(width: 5),
                                  Text(sumStatus30.toString(), style: const TextStyle(color: Colors.white, fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                                ],
                              )),
                          const SizedBox(width: 10),
                          Container(
                              alignment: Alignment.center,
                              height: 45,
                              width: 150,
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: const Color(0xFF9E9E9E)),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text('미방문', style: TextStyle(color: Colors.white, fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                                  const SizedBox(width: 5),
                                  Text(sumStatus90.toString(), style: const TextStyle(color: Colors.white, fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                                ],
                              )),
                          const SizedBox(width: 10),
                          Container(
                              alignment: Alignment.center,
                              height: 45,
                              width: 150,
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: const Color(0xFFFF5252)),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text('취소', style: TextStyle(color: Colors.white, fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                                  const SizedBox(width: 5),
                                  Text(sumStatus40.toString(), style: const TextStyle(color: Colors.white, fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                                ],
                              )),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 30),
              Container(
                width: 850,
                height: 800,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                child: MonthView(
                  controller: _controller,
                  cellBuilder: (date, events, isToday, isInMonth) {
                    // Return your widget to display as month cell.
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: const EdgeInsets.only(left: 5, top: 5),
                          child: Text('${date.day} 일', style: _todayTextStyle(isToday, isInMonth),),
                        ),
                        SingleChildScrollView(
                          physics: BouncingScrollPhysics(),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: List.generate(
                                events.length,
                                (index) => GestureDetector(
                                onTap: () {
                                  //onTileTap?.call(events[index], events[index].date),
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: events[index].color,
                                    borderRadius: BorderRadius.circular(4.0),
                                  ),
                                  margin: const EdgeInsets.symmetric(vertical: 2.0, horizontal: 3.0),
                                  padding: const EdgeInsets.all(2.0),
                                  alignment: Alignment.center,
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          events[index].title,
                                          overflow: TextOverflow.clip,
                                          maxLines: 1,
                                          style: events[0].titleStyle ?? TextStyle(color: events[index].color, fontSize: 12,),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    );
                  },
                  weekDayBuilder: (weekDay) {
                    String dayStr = '';
                    switch (weekDay) {
                      case 0:           dayStr = '월';                        break;
                      case 1:           dayStr = '화';                        break;
                      case 2:           dayStr = '수';                        break;
                      case 3:           dayStr = '목';                        break;
                      case 4:           dayStr = '금';                        break;
                      case 5:           dayStr = '토';                        break;
                      case 6:           dayStr = '일';                        break;
                    }
                    return Container(
                      padding: const EdgeInsets.symmetric(vertical: 4.0),
                      decoration: BoxDecoration(color: Colors.white, border: Border.all(color: Colors.black12, width: 1)),
                      child: Align(
                          alignment: Alignment.center,
                          child: Text(dayStr, style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))
                      ),
                    );
                  },
                  minMonth: DateTime(2020),
                  maxMonth: DateTime(2050),
                  initialMonth: initDate,
                  cellAspectRatio: 1,
                  onPageChange: (date, pageIndex){
                    //=> print("$date, $pageIndex"),
                    dateBegin = formatDate(date, [yyyy, mm, dd]);
                    dateEnd = formatDate(date, [yyyy, mm,  DateTime(DateTime.now().year, DateTime.now().month + 1, 0).day.toString()]);
                    requestAPIData();
                  },
                  onCellTap: (events, date) {
                    // Implement callback when user taps on a cell.
                  },
                  startDay: WeekDays.sunday, // To change the first day of the week.
                  // This callback will only work if cellBuilder is null.
                  onEventTap: (event, date) {
                  },
                )
              ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );

    return Container(
      // header: const LayoutHeader(titleName: '사장님사이트 현황'),//SizedBox(width: double.infinity, height: 100,),//
      // bottomBar: const LayoutBottom(),
      child: Responsive.isMobile(context) ? mobileContent : desktopContent,
    );
  }

  // 달력 날짜 스타일
  TextStyle _todayTextStyle(bool isToday, bool isInMonth) {
    TextStyle textStyle = const TextStyle(color: Colors.black, fontFamily: FONT_FAMILY);

    // 오늘 날짜 색상 표시
    if (isToday){
      textStyle = const TextStyle(color: Colors.blueAccent, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD);
    }
    else{
      textStyle = TextStyle(color: isInMonth == true ?  Colors.black : Colors.black26, fontFamily: FONT_FAMILY);
    }

    return textStyle;
  }
}


