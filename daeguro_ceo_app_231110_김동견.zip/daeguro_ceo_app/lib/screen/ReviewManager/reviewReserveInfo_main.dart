import 'dart:ui';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ReviewManager/reviewAnswerModel.dart';
import 'package:daeguro_ceo_app/models/ReviewManager/reviewinfoListModel.dart';
import 'package:daeguro_ceo_app/screen/Common/CommonImageHorizontalPreviewMain.dart';
import 'package:daeguro_ceo_app/screen/ReviewManager/reviewBlindRequest.dart';
import 'package:daeguro_ceo_app/screen/ReviewManager/reviewManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter_rating_stars/flutter_rating_stars.dart';
import 'package:get/get.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:provider/provider.dart';

class ReviewReserveInfoMain extends StatefulWidget {
  final double? tabviewHeight;

  const ReviewReserveInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ReviewReserveInfoMain> createState() => _ReviewReserveInfoMainState();
}

class _ReviewReserveInfoMainState extends State<ReviewReserveInfoMain> {
  List<ReviewinfoListModel> dataList = [];

  // 별점
  int stat_score1 = 0;
  int stat_score2 = 0;
  int stat_score3 = 0;
  int stat_score4 = 0;
  int stat_score5 = 0;

  double reviewAverage = 0;

  // 리뷰 구분별 수
  double review_totalCount = 0;
  int review_answeredCount = 0;
  int review_unansweredCount = 0;

  // 전체:10/답변:11/미답변:12
  String jobGbn = '10';

  // 블라인드 남은 일수 계산에 사용
  String now = DateTime.now().toString();

  int selectedPageNumber = 1;
  int totalPage = 0;

  /*
    url: https://review.daeguro.co.kr:45008

    1. 리뷰 목록 조회 ("{url}/v2//review/ceo") GET
     - PKG_IS_APP_REVIEW_V2.GET_SHOP_REVIEW_V2
     - jobGbn: 10(전체), 11(답변O), 12(답변X)

    2. 상점 리뷰 카운트 조회 ("{url}/review/count") GET
     - PKG_IS_APP_REVIEW_V2.GET_SHOP_STAR_RATING_COUNT

    3. 상점 리뷰 상세 ("{url}/v2/review/ceo/{orderNo}") GET
     - PKG_IS_APP_REVIEW_V2.GET_SHOP_REVIEW_DETAIL

    4. 사장님 답글 입력 ("{url}/review/answer") POST
     - PKG_IS_APP_REVIEW_V2.INSERT_REVIEW_ANSWER

    5. 사장님 답글 수정 ("{url}/review/answer") PUT
     - PKG_IS_APP_REVIEW_V2.UPDATE_REVIEW_ANSWER

    6. 사장님 답글 삭제 ("{url}/review/answer") DELETE
     - PKG_IS_APP_REVIEW_V2.UPDATE_REVIEW_ANSWER

    7. 사장님 블라인드 처리 ("{url}/review/blind") POST
     - PKG_IS_APP_REVIEW_V2.SET_BLIEND_REVIEW_V2
   */

  requestStatisticsData() async {
    ReviewController.to.getReviewStatistics(reserveGbn: 'R').then((value) {
      if (value == null) {
        ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      } else {
        review_totalCount = value['total'] as double;
        review_answeredCount = value['answered'] as int;
        review_unansweredCount = value['unanswered'] as int;
        stat_score1 = value['score1'] as int;
        stat_score2 = value['score2'] as int;
        stat_score3 = value['score3'] as int;
        stat_score4 = value['score4'] as int;
        stat_score5 = value['score5'] as int;

        if(jobGbn == '10') {
          totalPage = (value['total']/10).ceil();
        } else if(jobGbn == '11') {
          totalPage = (value['answered']/10).ceil();
        } else if(jobGbn == '12') {
          totalPage = (value['unanswered']/10).ceil();
        }

        double totalScore = (stat_score1 * 1) + (stat_score2 * 2) + (stat_score3 * 3) + (stat_score4 * 4) + (stat_score5 * 5);
        double averageTotal = review_totalCount;

        int checkValue = 0;
        if (totalScore > 0 && averageTotal > 0) {
          checkValue = ((totalScore / averageTotal) * 10).round();
        }
        setState(() {
        reviewAverage = checkValue / 10.0;
        });
      }
    });

  }

  requestAPIData({bool? isShowAlertPopup = false}) async {
    // jobGbn 10:전체, 11:답변O, 12:답변X
    var value = await showDialog(context: context, barrierColor: Colors.transparent,builder: (context) => FutureProgressDialog(ReviewController.to.getReviewList(jobGbn, selectedPageNumber.toString(), reserveGbn: 'R')));

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    } else {
      dataList.clear();

      value.forEach((element) {
        ReviewinfoListModel temp = ReviewinfoListModel();

        temp.custNickName = element['custNickName'] as String;
        temp.orderNo = element['orderNo'] as String;
        temp.insertDate = element['insertDate'] as String;
        temp.starScore = element['starScore'] as int;
        temp.content = element['content'] as String;
        temp.orderMenu = element['orderMenu'] as String;
        temp.answerContent = element['answerContent'] as String;
        temp.answerInsertDate = element['answerInsertDate'] as String;
        temp.blindStandDt = element['blindStandDt'] as String;
        temp.blindEndDt = element['blindEndDt'] as String;
        temp.images = element['images'];
        temp.visibleGbn = element['visibleGbn'] as String; //리뷰보임구분 A:전체, B:블라인드
        temp.answerVisibleGbn = element['answerVisibleGbn'] as String; //답글보임구분 A:전체, O:리뷰작성자+상점주, M:답글작성자(고객못봄)
        temp.blindType = element['blindType'] as String; //블라인드타입 S:가맹점요청, A:어드민홈페이지
        //temp.isBlind = false;
        temp.isShown = temp.visibleGbn == 'B' ? true : false;
        temp.reOrderCount = element['reOrderCount'] as int;

        temp.blindRemain = (temp.blindStandDt != '' && temp.blindEndDt != '') ? DateFormat('yyyy-MM-dd').parse(temp.blindEndDt!).difference(DateFormat('yyyy-MM-dd').parse(now)).inDays.toString() : '0';

        dataList.add(temp);
      });
    }

    setState(() {});

    if (isShowAlertPopup == true) ISAlert(context, content: '저장되었습니다.', constraints: const BoxConstraints(maxWidth: 240.0));
  }

  @override
  void initState() {
    super.initState();


    Get.put(ReviewController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestStatisticsData();
      requestAPIData(isShowAlertPopup: false);
    });
  }

  @override
  void dispose() {
    super.dispose();

    dataList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestStatisticsData();
          requestAPIData(isShowAlertPopup: false);
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
      child: SizedBox(
        height: MediaQuery.of(context).size.height, //(widget.tabviewHeight! - (Responsive.isMobile(context) == true ? 104 : 10)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 20),
          statisticsView(),
          const SizedBox(height: 20),
          reviewSearchView(),
          const SizedBox(height: 10),
          const Divider(height: 1),
          Expanded(
            child: ListView.separated(
                separatorBuilder: (context, index) => const Divider(height: 1),
                itemCount: dataList.length,
                itemBuilder: (BuildContext context, int index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Responsive.isMobile(context) ? mobileReviewInfoListView(index, context) : reviewInfoListView(index, context),
                  );
                }),
          ),
          const Divider(height: 1),
          ISNumberPagination(
            threshold: 5,
            controlButton: const SizedBox(width: 10, height: 10),
            onPageChanged: (int pageNumber) {
              //do somthing for selected page
              setState(() {
                selectedPageNumber = pageNumber;
              });

              requestAPIData();
            },
            fontSize: 12,
            pageTotal: totalPage,
            pageInit: selectedPageNumber,
            // picked number when init page
            colorPrimary: Colors.black,
            colorSub: Colors.white,
          ),
        ]),
      ),
    );
  }

  Widget mobileReviewInfoListView(int index, fluentUI.BuildContext context) {
    return fluentUI.Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${dataList[index].custNickName} (${dataList[index].orderNo!})',
                style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
              ),
            ],
          ),
          RatingStars(
            value: dataList[index].starScore as double,
            starBuilder: (index, color) => Icon(Icons.star, color: color),
            starCount: 5,
            starSize: 15,
            maxValue: 5,
            starSpacing: 2,
            maxValueVisibility: false,
            valueLabelVisibility: false,
            valueLabelPadding: const EdgeInsets.symmetric(vertical: 1, horizontal: 8),
            valueLabelMargin: const EdgeInsets.only(right: 8),
            starOffColor: const Color(0xffe7e8ea),
            starColor: Colors.orange,
          ),
          const SizedBox(
              height: 10
          ),
          Text('${dataList[index].reOrderCount} 번째 방문', style: const TextStyle(fontSize: 14, color: Colors.grey)),
          const SizedBox(
              height: 10
          ),
          ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: dataList[index].visibleGbn == 'B' && dataList[index].isShown! ? 5 : 0, sigmaY: dataList[index].visibleGbn == 'B' && dataList[index].isShown! ? 5 : 0),
            child: Text(dataList[index].visibleGbn == 'B' ? '블라인드 처리된 리뷰입니다.' : dataList[index].content.toString(), style: const TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
          ),
          const SizedBox(height: 10),
          (dataList[index].images!.isEmpty == true || dataList[index].visibleGbn == 'B')
              ? const SizedBox.shrink()
              : SizedBox(
            height: 200,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: List.generate(dataList[index].images!.length, (idx) {
                return (dataList[index].images![idx] == null)
                    ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100)
                    : InkWell(
                  onTap: (){
                    List<String>? imageList = List<String>.from(dataList[index].images ?? []);
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => CommonImageHorizontalPreviewMain(title: '리뷰 이미지', imageList: imageList, index: idx,),
                    );
                  },
                      child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Image.network(
                      '${dataList[index].images.toString().replaceAll('https://reser-review.daeguro.co.kr:20001/review-images/', '/reservereview-images/')![idx]}?tm=${Utils.getTimeStamp()}',
                      fit: BoxFit.fill,
                      gaplessPlayback: true,
                      loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                        if (loadingProgress == null) return child;
                        return const Center(
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                          ),
                        );
                      },
                      errorBuilder: (context, error, stackTrace) {
                        return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100);
                      },
                  ),
                ),
                    );
              }),
            ),
          ),
          const SizedBox(height: 8),
          ImageFiltered(
              imageFilter: ImageFilter.blur(sigmaX: dataList[index].visibleGbn == 'B' && dataList[index].isShown! ? 5 : 0, sigmaY: dataList[index].visibleGbn == 'B' && dataList[index].isShown! ? 5 : 0),
              child: Text(dataList[index].orderMenu.toString(), style: TextStyle(color: Colors.blue[300], fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
          const SizedBox(height: 10),
          TextFormField(
            style: const TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
            keyboardType: TextInputType.multiline,
            maxLines: 4,
            //initialValue: dataList[index].answerContent,
            controller: TextEditingController(text: dataList[index].answerContent),
            maxLength: 1000,
            onChanged: (v) {
              dataList[index].answerContent = v;
              // setState(() {
              //   dataList[index].answerContent = '${dataList[index].custNickName }님 \n\n${v.toString()}';
              //
              // });
            },
            // onTap: () => dataList[index].reviewReply == null ? {dataList[index].reviewReply = dataList[index].reviewUserId.toString()} : null,
            decoration: const InputDecoration(
              labelText: '사장님 답변',
              fillColor: Colors.white,
              filled: true,
              enabled: true,
              hintStyle: TextStyle(color: Colors.black54, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
              enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.black12, width: 1.0)),
              focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.lightBlueAccent, width: 1.0)),
              isDense: true,
            ),
          ),
          (dataList[index].answerInsertDate == null || dataList[index].answerInsertDate == '')
              ? fluentUI.Center(
            child: ISButton(
              child: const Text('등록', style: TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
              onPressed: () {
                ISConfirm(context, '리뷰 답변 등록', '리뷰 답변을 저장하시겠습니까?', (context, isOK) async {
                  Navigator.of(context).pop();

                  if (isOK) {
                    ReviewAnswerModel sendData = ReviewAnswerModel();
                    sendData.orderNo = dataList[index].orderNo;
                    sendData.shopCode = AuthService.SHOPCD;
                    sendData.content = dataList[index].answerContent;
                    sendData.modUcode = AuthService.uCode;
                    sendData.modName = AuthService.uName;
                    sendData.answerVisibleGbn = 'A';

                    var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(ReviewController.to.setReviewAnswer(sendData.toJson(), reserveGbn: 'R')));

                    if (value == null) {
                      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                    } else {
                      if (value == '00') {
                        requestStatisticsData();
                        requestAPIData(isShowAlertPopup: true);
                      } else {
                        ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                      }
                    }
                  }
                });
              },
            ),
          )
              : Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ISButton(
                child: const Text('수정', style: TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                onPressed: () {
                  ISConfirm(context, '리뷰 답변 수정', '리뷰 답변을 수정하시겠습니까?', (context, isOK) async {
                    Navigator.of(context).pop();

                    if (isOK) {
                      ReviewAnswerModel sendData = ReviewAnswerModel();
                      sendData.orderNo = dataList[index].orderNo;
                      sendData.shopCode = AuthService.SHOPCD;
                      sendData.content = dataList[index].answerContent;
                      sendData.modUcode = AuthService.uCode;
                      sendData.modName = AuthService.uName;
                      sendData.answerVisibleGbn = 'A';

                      var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(ReviewController.to.updateReviewAnswer(sendData.toJson(), reserveGbn: 'R')));

                      if (value == null) {
                        ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                      } else {
                        if (value == '00') {
                          requestAPIData(isShowAlertPopup: true);
                        } else {
                          ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                        }
                      }
                    }
                  });
                },
              ),
              const SizedBox(width: 10),
              ISButton(
                isReverseColor: true,
                child: const Text('삭제', style: TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                onPressed: () {
                  ISConfirm(context, '리뷰 답변 삭제', '리뷰 답변을 삭제하시겠습니까?', (context, isOK) async {
                    Navigator.of(context).pop();

                    if (isOK) {
                      ReviewAnswerModel sendData = ReviewAnswerModel();
                      sendData.orderNo = dataList[index].orderNo;
                      sendData.shopCode = AuthService.SHOPCD;
                      sendData.modUcode = AuthService.uCode;
                      sendData.modName = AuthService.uName;

                      var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(ReviewController.to.deleteReviewAnswer(sendData.toJson(), reserveGbn: 'R')));

                      if (value == null) {
                        ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                      } else {
                        if (value == '00') {
                          requestStatisticsData();
                          requestAPIData(isShowAlertPopup: true);
                        } else {
                          ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                        }
                      }
                    }
                  });
                },
              ),
            ],
          )
        ],
      ),
    );
  }

  Widget reviewInfoListView(int index, fluentUI.BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 230,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${dataList[index].custNickName} (${dataList[index].orderNo!})', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                const SizedBox(height: 5),
                Text(dataList[index].insertDate!, style: const TextStyle(fontSize: 13, color: Colors.grey, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                const SizedBox(height: 5),
                RatingStars(
                  value: dataList[index].starScore as double,
                  starBuilder: (index, color) => Icon(
                    Icons.star,
                    color: color,
                  ),
                  starCount: 5,
                  starSize: 20,
                  maxValue: 5,
                  starSpacing: 2,
                  maxValueVisibility: false,
                  valueLabelVisibility: false,
                  valueLabelPadding: const EdgeInsets.symmetric(vertical: 1, horizontal: 8),
                  valueLabelMargin: const EdgeInsets.only(right: 8),
                  starOffColor: const Color(0xffe7e8ea),
                  starColor: Colors.orange,
                ),
                Text('${dataList[index].reOrderCount} 번째 방문', style: const TextStyle(fontSize: 14, color: Colors.grey)),
                const SizedBox(
                    height: 10
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ImageFiltered(
                imageFilter: ImageFilter.blur(sigmaX: dataList[index].visibleGbn == 'B' && dataList[index].isShown! ? 5 : 0, sigmaY: dataList[index].visibleGbn == 'B' && dataList[index].isShown! ? 5 : 0),
                child: Text(dataList[index].visibleGbn == 'B' ? '블라인드 처리된 리뷰입니다.' : dataList[index].content.toString(), style: const TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
              ),
              // InkWell(
              //   // onTap: () => ,
              //   child: Image.network(dataList[index].reviewImage!, width: 100, height: 100, fit: BoxFit.fill,),
              // ),
              const SizedBox(height: 8),
              (dataList[index].images!.isEmpty == true || dataList[index].visibleGbn == 'B')
                  ? const SizedBox.shrink()
                  : SizedBox(
                height: 100,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: List.generate(dataList[index].images!.length, (idx) {
                    return (dataList[index].images![idx] == null)
                        ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100)
                        : InkWell(
                      onTap: (){
                        List<String>? imageList = List<String>.from(dataList[index].images ?? []);
                        showDialog(
                          context: context,
                          barrierDismissible: true,
                          builder: (context) => CommonImageHorizontalPreviewMain(title: '리뷰 이미지', imageList: imageList, index: idx,),
                        );
                      },
                          child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Image.network(
                          '${dataList[index].images.toString().replaceAll('https://reser-review.daeguro.co.kr:20001/review-images/', '/reservereview-images/')![idx]}?tm=${Utils.getTimeStamp()}',
                          fit: BoxFit.fill,
                          gaplessPlayback: true,
                          loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                            if (loadingProgress == null) return child;
                            return const Center(
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                              ),
                            );
                          },
                          errorBuilder: (context, error, stackTrace) {
                            return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100);
                          },
                      ),
                    ),
                        );
                  }),
                ),
              ),
              const SizedBox(height: 8),
              ImageFiltered(
                imageFilter: ImageFilter.blur(sigmaX: dataList[index].visibleGbn == 'B' && dataList[index].isShown! ? 5 : 0, sigmaY: dataList[index].visibleGbn == 'B' && dataList[index].isShown! ? 5 : 0),
                child: Text(dataList[index].orderMenu.toString(), style: TextStyle(color: Colors.blue[300], fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: TextFormField(
                      style: const TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                      keyboardType: TextInputType.multiline,
                      maxLines: 4,
                      //initialValue: dataList[index].answerContent,
                      controller: TextEditingController(text: dataList[index].answerContent),
                      maxLength: 1000,
                      onChanged: (v) {
                        dataList[index].answerContent = v;
                        // setState(() {
                        //   dataList[index].answerContent = '${dataList[index].custNickName }님 \n\n${v.toString()}';
                        //
                        // });
                      },
                      // onTap: () => dataList[index].reviewReply == null ? {dataList[index].reviewReply = dataList[index].reviewUserId.toString()} : null,
                      decoration: const InputDecoration(
                        labelText: '사장님 답변',
                        fillColor: Colors.white,
                        filled: true,
                        enabled: true,
                        hintStyle: TextStyle(color: Colors.black54, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                        enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.black12, width: 1.0)),
                        focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.lightBlueAccent, width: 1.0)),
                        isDense: true,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12.0, 0.0, 12.0, 20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: (dataList[index].answerInsertDate == null || dataList[index].answerInsertDate == '')
                          ? [
                        ISButton(
                          child: const Text(
                            '등록',
                            style: TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                          ),
                          onPressed: () {
                            ISConfirm(context, '리뷰 답변 등록', '리뷰 답변을 저장하시겠습니까?', (context, isOK) async {
                              Navigator.of(context).pop();

                              if (isOK) {
                                ReviewAnswerModel sendData = ReviewAnswerModel();
                                sendData.orderNo = dataList[index].orderNo;
                                sendData.shopCode = AuthService.SHOPCD;
                                sendData.content = dataList[index].answerContent;
                                sendData.modUcode = AuthService.uCode;
                                sendData.modName = AuthService.uName;
                                sendData.answerVisibleGbn = 'A';

                                var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(ReviewController.to.setReviewAnswer(sendData.toJson(), reserveGbn: 'R')));

                                if (value == null) {
                                  ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                } else {
                                  if (value == '00') {
                                    requestStatisticsData();
                                    requestAPIData(isShowAlertPopup: true);
                                  } else {
                                    ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                  }
                                }
                              }
                            });
                          },
                        )
                      ]
                          : [
                        ISButton(
                          child: const Text('수정', style: TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                          onPressed: () {
                            ISConfirm(context, '리뷰 답변 수정', '리뷰 답변을 수정하시겠습니까?', (context, isOK) async {
                              Navigator.of(context).pop();

                              if (isOK) {
                                ReviewAnswerModel sendData = ReviewAnswerModel();
                                sendData.orderNo = dataList[index].orderNo;
                                sendData.shopCode = AuthService.SHOPCD;
                                sendData.content = dataList[index].answerContent;
                                sendData.modUcode = AuthService.uCode;
                                sendData.modName = AuthService.uName;
                                sendData.answerVisibleGbn = 'A';

                                var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(ReviewController.to.updateReviewAnswer(sendData.toJson(), reserveGbn: 'R')));

                                if (value == null) {
                                  ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                } else {
                                  if (value == '00') {
                                    requestAPIData(isShowAlertPopup: true);
                                  } else {
                                    ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                  }
                                }
                              }
                            });
                          },
                        ),
                        const SizedBox(height: 10),
                        ISButton(
                          isReverseColor: true,
                          child: const Text('삭제', style: TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                          onPressed: () {
                            ISConfirm(context, '리뷰 답변 삭제', '리뷰 답변을 삭제하시겠습니까?', (context, isOK) async {
                              Navigator.of(context).pop();

                              if (isOK) {
                                ReviewAnswerModel sendData = ReviewAnswerModel();
                                sendData.orderNo = dataList[index].orderNo;
                                sendData.shopCode = AuthService.SHOPCD;
                                sendData.modUcode = AuthService.uCode;
                                sendData.modName = AuthService.uName;

                                var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(ReviewController.to.deleteReviewAnswer(sendData.toJson(), reserveGbn: 'R')));

                                if (value == null) {
                                  ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                } else {
                                  if (value == '00') {
                                    requestStatisticsData();
                                    requestAPIData(isShowAlertPopup: true);
                                  } else {
                                    ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                  }
                                }
                              }
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget statisticsView() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Column(
          children: [
            Row(
              children: [
                Text('$reviewAverage', style: TextStyle(fontSize: Responsive.isMobile(context) ? 35 : 56, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                Text('/5', style: TextStyle(fontSize: Responsive.isMobile(context) ? 35 : 56, color: Colors.grey.shade400, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
              ],
            ),
            RatingStars(
              value: reviewAverage,
              starBuilder: (index, color) => Icon(Icons.star, color: color),
              starCount: 5,
              starSize: Responsive.isMobile(context) ? 16 : 20,
              maxValue: 5,
              starSpacing: 2,
              maxValueVisibility: false,
              valueLabelVisibility: false,
              valueLabelPadding: const EdgeInsets.symmetric(vertical: 1, horizontal: 8),
              valueLabelMargin: const EdgeInsets.only(right: 8),
              starOffColor: const Color(0xffe7e8ea),
              starColor: Colors.orange,
            ),
            const SizedBox(
              height: 5,
            ),
            Responsive.isMobile(context)
                ? Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text('총 $review_totalCount개의 리뷰', style: const TextStyle(fontSize: 12, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                const SizedBox(width: 3),
                const Tooltip(
                  message: '블라인드 처리된 리뷰는 별점에 포함되어 있지만,\n고객 앱에서는 별점이 포함되지 않고 표시됩니다.',
                  child: SizedBox(
                    child: Icon(Icons.help_outline, color: Colors.grey),
                  ),
                )
              ],
            )
                : Column(
              children: [
                Text('총 $review_totalCount개의 리뷰', style: const TextStyle(color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                const Tooltip(
                  message: '블라인드 처리된 리뷰는 별점에 포함되어 있지만,\n고객 앱에서는 별점이 포함되지 않고 표시됩니다.',
                  child: Icon(Icons.help_outline, color: Colors.grey),
                )
              ],
            ),
          ],
        ),
        const SizedBox(width: 20),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            scoreBarWidget('5', stat_score5, review_totalCount),
            const SizedBox(height: 10),
            scoreBarWidget('4', stat_score4, review_totalCount),
            const SizedBox(height: 10),
            scoreBarWidget('3', stat_score3, review_totalCount),
            const SizedBox(height: 10),
            scoreBarWidget('2', stat_score2, review_totalCount),
            const SizedBox(height: 10),
            scoreBarWidget('1', stat_score1, review_totalCount),
            const SizedBox(height: 10)
          ],
        ),
      ],
    );
  }

  Widget scoreBarWidget(String header, int score, double totalCnt) {
    return Row(
      children: [
        Text(header, style: const TextStyle(fontSize: 14, color: Colors.black54, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
        const Icon((Icons.star), size: 13, color: Colors.black54),
        const SizedBox(width: 10),
        LinearPercentIndicator(
          addAutomaticKeepAlive: false,
          barRadius: const Radius.circular(10),
          padding: EdgeInsets.zero,
          percent: (score / totalCnt).isNaN ? 0.0 : (score / totalCnt),
          lineHeight: 10,
          backgroundColor: Colors.grey[200],
          progressColor: const Color(0xff01CAFF),
          width: Responsive.isMobile(context) ? 130 : 200,
        ),
        const SizedBox(width: 10),
        Text('$score', style: const TextStyle(fontSize: 14, color: Color(0xff01CAFF), fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
        Text('/$totalCnt', style: const TextStyle(fontSize: 14, color: Colors.black54, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
      ],
    );
  }

  Widget reviewSearchView() {
    Color selectedColor = const Color.fromARGB(255, 116, 210, 253);
    Color unselectedColor = Colors.grey;

    return Row(
      children: [
        InkWell(
          child: Chip(padding: const EdgeInsets.all(5), backgroundColor: jobGbn == '10' ? selectedColor : unselectedColor, label: Text('전체($review_totalCount)', style: const TextStyle(fontSize: 11, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL))),
          onTap: () {
            setState(() {
              jobGbn = '10';
              selectedPageNumber = 1;
            });

            requestStatisticsData();
            requestAPIData(isShowAlertPopup: false);
          },
        ),
        const SizedBox(width: 8),
        InkWell(
          child: Chip(padding: const EdgeInsets.all(5), backgroundColor: jobGbn == '11' ? selectedColor : unselectedColor, label: Text('답변($review_answeredCount)', style: const TextStyle(fontSize: 11, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL))),
          onTap: () {
            setState(() {
              jobGbn = '11';
              selectedPageNumber = 1;
            });

            requestStatisticsData();
            requestAPIData(isShowAlertPopup: false);
          },
        ),
        const SizedBox(width: 8),
        InkWell(
          child: Chip(padding: const EdgeInsets.all(5), backgroundColor: jobGbn == '12' ? selectedColor : unselectedColor, label: Text('미답변($review_unansweredCount)', style: const TextStyle(fontSize: 11, color: Colors.white, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL))),
          onTap: () {
            setState(() {
              jobGbn = '12';
              selectedPageNumber = 1;
            });

            requestStatisticsData();
            requestAPIData(isShowAlertPopup: false);
          },
        ),
      ],
    );
  }
}