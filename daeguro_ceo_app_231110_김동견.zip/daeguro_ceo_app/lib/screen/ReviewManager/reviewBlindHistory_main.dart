import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown_v2.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ReviewManager/reviewBlindHistoryListModel.dart';
import 'package:daeguro_ceo_app/models/ReviewManager/reviewBlindRequestModel.dart';
import 'package:daeguro_ceo_app/screen/ReviewManager/reviewManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:data_table_2/data_table_2.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter_expandable_text/flutter_expandable_text.dart';
import 'package:flutter_rating_stars/flutter_rating_stars.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ReviewBlindHistoryMain extends StatefulWidget {
  final double? tabviewHeight;

  const ReviewBlindHistoryMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ReviewBlindHistoryMain> createState() => _ReviewBlindHistoryMainState();
}

class _ReviewBlindHistoryMainState extends State<ReviewBlindHistoryMain> {
  List<ReviewBlindHistoryListModel> dataList = <ReviewBlindHistoryListModel>[];

  //late ReviewBlindHistorySource reviewBlindHistoryDataSource;
  bool _initialized = false;

  String? startdate = '';
  String? enddate = '';
  String? tempStr;
  String? selectedType = '1000';

  String? selectedStatus = '%';
  String? selectedOrderType = ' ';

  bool hasRowTaps = true;//false;
  // Override height values for certain rows
  bool hasRowHeightOverrides = true;
  // Color each Row by index's parity
  bool hasZebraStripes = false;

  int _selectedCount = 0;

  bool pickDate = false;

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ReviewController.to.getReviewBlindList(startdate!.replaceAll('-', '')+'000000', enddate!.replaceAll('-', '')+'235959'))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        ReviewBlindHistoryListModel temp = ReviewBlindHistoryListModel();

        temp.answerContent = element['answerContent'] as String;
        temp.blindCode = element['blindCode'] as String;
        temp.blindName = element['blindName'] as String;
        temp.blindReason = element['blindReason'] as String;
        temp.blindReqCancelYn = element['blindReqCancelYn'] as String;
        temp.blindReqDt = element['blindReqDt'] as String;
        temp.blindType = element['blindType'] as String;
        temp.content = element['content'] as String;
        temp.custNickName = element['custNickName'] as String;
        temp.insertDate = element['insertDate'] as String;
        temp.orderNo = element['orderNo'] as String;
        temp.requestGbn = element['requestGbn'] as String;
        temp.starScore = element['starScore'] as double;
        temp.status = element['status'] as String;

        temp.blindReason = temp.blindReason!.replaceAll('\r\n','');

        String? selectedStatusStr = '';
        if (selectedStatus == '10')          selectedStatusStr = '요청';
        else if (selectedStatus == '35')     selectedStatusStr = '보완';
        else if (selectedStatus == '40')    selectedStatusStr = '완료';
        else if (selectedStatus == '99') selectedStatusStr = '기타';

        if (selectedStatus == '%' || (temp.status == selectedStatusStr))
          dataList.add(temp);
      });

      dataList.sort((b, a) => a.blindReqDt!.compareTo(b.blindReqDt!));
    }

    setState(() {});
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      //reviewBlindHistoryDataSource = ReviewBlindHistorySource(context, dataList, false, true, true, false);

      // Default sorting sample. Set __sortColumnIndex to 0 and uncoment the lines below
      // if (_sortColumnIndex == 0) {
      //   _sort<String>((d) => d.name, _sortColumnIndex!, _sortAscending);
      // }
      _initialized = true;
      // reviewBlindHistoryDataSource.addListener(() {
      //   setState(() {
      //
      //   });
      // });
    }
  }

  @override
  void dispose() {
    //reviewBlindHistoryDataSource.dispose();
    dataList.clear();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReviewController());

    startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
      //loadData();
    });
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return Responsive.isMobile(context) ? mobileReviewBlindHistoryWidget() : ReviewBlindHistoryWidget();
  }

  Widget ReviewBlindHistoryWidget() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const ISLabelBarMain(
            leading: Text('* 최대 1년 이내 이력만 조회 가능합니다.', style: TextStyle(color: Colors.grey, fontSize: 14),),
            trailing: SizedBox(height: 36,),
          ),
          const SizedBox(height: 8),
          Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
          const SizedBox(height: 8),
          SizedBox(
            height: 400,
            child: DataTable2(
              // dataRowHeight: 30,
                headingRowHeight: 40,
                headingTextStyle: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54),
                columnSpacing: 0,
                horizontalMargin: 0,
                headingRowColor: MaterialStateProperty.all(
                  Colors.grey[100],
                ),
                // MaterialStateProperty.resolveWith((states) =>
                //     _fixedRows > 0 ? Colors.grey[200] : Colors.transparent),
                border: TableBorder(
                  borderRadius: BorderRadius.circular(10),
                  top: BorderSide(color: Colors.grey[300]!),
                  right: BorderSide(color: Colors.grey[300]!),
                  bottom: BorderSide(color: Colors.grey[300]!),
                  left: BorderSide(color: Colors.grey[300]!),
                  horizontalInside: BorderSide.none,
                ),

                dividerThickness: 0, // this one will be ignored if [border] is set above
                bottomMargin: 10,
                minWidth: 900,
                // sortColumnIndex: _sortColus
                // sortArrowIcon: Icons.keyboard_arrow_up, // custom arrow
                // sortArrowAnimationDuration:
                //     const Duration(milliseconds: 500), // custom animation duration
                // onSelectAll: (val) =>
                //     setState(() => _dessertsDataSource.selectAll(val)),
                columns: [
                  DataColumn2(
                    fixedWidth: 150,
                    label: Center(
                      child: ISSearchDropdownV2(
                        // label: '업체타입',
                        value: selectedStatus,
                        onChange: (value) {
                          selectedStatus = value;

                          requestAPIData();
                        },
                        item: [
                          const DropdownMenuItem(value: '%', child: Text('상태 전체'),),
                          const DropdownMenuItem(value: '10', child: Text('요청'),),
                          const DropdownMenuItem(value: '40', child: Text('완료'),),
                          const DropdownMenuItem(value: '35', child: Text('보완'),),
                          const DropdownMenuItem(value: '99', child: Text('기타'),),
                        ].cast<DropdownMenuItem<String>>(),
                      ),
                    ),
                    size: ColumnSize.S,
                    numeric: true,
                  ),
                  DataColumn2(
                    label: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          alignment: Alignment.centerLeft,
                          child: const Text('요청 내용', textAlign: TextAlign.left,),
                        ),
                        const Icon(Icons.keyboard_arrow_down, color: Colors.black, size: 20),
                      ],
                    ),
                    size: ColumnSize.S,
                    numeric: true,
                  ),
                  DataColumn2(
                    fixedWidth: 150,
                    label: Container(alignment: Alignment.centerRight, child: const Text('요청 일시')),
                    size: ColumnSize.S,
                    numeric: true,
                  ),
                  const DataColumn2(
                    fixedWidth: 150,
                    label: Center(child: Text('')),
                    size: ColumnSize.S,
                    numeric: true,
                  ),
                ],
                empty: Center(
                    child: Container(
                        padding: const EdgeInsets.all(20),
                        child: const Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)))),
                //rows: List<DataRow>.generate(reviewBlindHistoryDataSource.rowCount, (index) => reviewBlindHistoryDataSource.getRow(index)),
                rows: List<DataRow>.generate(
                  dataList.length,
                      (index) => DataRow2.byIndex(
                    index: index,
                    //color: MaterialStateProperty.all(color),
                    // (hasZebraStripes && index.isEven
                    //     ? MaterialStateProperty.all(Theme.of(context).highlightColor)
                    //     : null),
                    onTap: hasRowTaps ? () => {
                      dataList[index].isChild
                          ? null
                          : dataList[index].isOpened
                          ? {dataList.removeRange(index + 1, index + 2), dataList[index].isOpened = false}
                          : {
                        dataList.insert(index + 1, ReviewBlindHistoryListModel(
                          custNickName: dataList[index].custNickName,
                          orderNo: dataList[index].orderNo,
                          starScore: dataList[index].starScore,
                          content: dataList[index].content,
                          insertDate: dataList[index].insertDate,
                          blindName: dataList[index].blindName,
                          blindReason: dataList[index].blindReason,
                          answerContent: dataList[index].answerContent,
                          /*replyContent: data.replyContent, replyDate: data.replyDate,*/
                          isChild: true,
                        ),
                        ),
                        dataList[index].isOpened = true
                      },
                      //notifyListeners()
                      setState(() {
                      })
                    } : () => {
                    },
                    specificRowHeight: hasRowHeightOverrides && (dataList[index].isChild) ? 340 : null,
                    cells: [
                      DataCell(
                        Container(
                            padding: EdgeInsets.zero,
                            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !dataList[index].isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
                            alignment: Alignment.center,
                            child: Container(
                              alignment: Alignment.center,
                              width: 60,
                              height: 26,
                              decoration: dataList[index].status == null
                                  ? null
                                  : BoxDecoration(
                                  color: getStatusColor(dataList[index].status!),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: Colors.transparent)
                              ),
                              child: Text(dataList[index].status ?? '', style: TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY_NEXON),),
                            )
                        ),
                      ),
                      DataCell(
                        dataList[index].isChild ? requestDetailWidget(dataList[index]) : Container(
                            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !dataList[index].isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
                            alignment: Alignment.centerLeft,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(dataList[index].requestGbn ?? '', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY),),
                                Icon(dataList[index].isOpened ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, color: Colors.black, size: 20),
                              ],
                            )
                        ),
                      ),
                      DataCell(
                        Container(
                            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !dataList[index].isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
                            alignment: Alignment.centerRight,
                            child: Text(dataList[index].blindReqDt ?? '', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY),
                            )
                        ),
                      ),
                      DataCell(
                        Container(
                          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !dataList[index].isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
                          alignment: Alignment.center,
                          child: (dataList[index].isChild == true)
                              ? const SizedBox.shrink()
                              : Visibility(
                                visible: dataList[index].status == '요청' ? true : false,
                                child: ISButton(
                            isReverseColor: true,
                            child: const Text('취소하기'),
                            onPressed: () {
                                ISConfirm(context, '리뷰 블라인드 취소', '${dataList[index].custNickName}님의 리뷰 블라인드 요청을 취소하시겠습니까?', (context, isOK) async {
                                  Navigator.of(context).pop();

                                  if (isOK){
                                    ReviewBlindRequestModel sendData = ReviewBlindRequestModel();
                                    sendData.shop_cd = AuthService.SHOPCD;
                                    sendData.modUcode = AuthService.uCode;
                                    sendData.modUName = AuthService.uName;
                                    sendData.job_gbn = "1";
                                    sendData.visibleGbn = "C"; // r-> 요청 , c -> 취소
                                    sendData.blindEndDt = formatDate(DateTime.now(), [yyyy, mm, dd]);
                                    sendData.orderNo = dataList[index].orderNo;

                                    var value = await showDialog(
                                        context: context,
                                        builder: (context) => FutureProgressDialog(ReviewController.to.setReviewBlind(sendData.toJson()))
                                    );

                                    if (value == null) {
                                      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                    }
                                    else {
                                      if (value == '00') {
                                        requestAPIData();
                                      }
                                      else {
                                        ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                      }
                                    }
                                  }
                                });
                            },
                          ),
                              ),
                        ),
                      ),
                    ],
                  ),
                )
            ),
          ),
          // ISNumberPagination(
          //   threshold: 5,
          //   controlButton: const SizedBox(width: 10, height: 10,),
          //   onPageChanged: (int pageNumber) {
          //     //do somthing for selected page
          //     setState(() {
          //       selectedPageNumber = pageNumber;
          //     });
          //   },
          //   fontSize: 12,
          //   pageTotal: totalPage,
          //   pageInit: selectedPageNumber, // picked number when init page
          //   colorPrimary: Colors.black,
          //   colorSub: Colors.white,
          // ),
        ],
      ),
    );
  }

  Widget mobileReviewBlindHistoryWidget() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const ISLabelBarMain(
            leading: Text('* 최대 1년 이내 이력만 조회 가능합니다.', style: TextStyle(color: Colors.grey, fontSize: 14),),
            trailing: SizedBox(height: 36,),
          ),
          const SizedBox(height: 8),
          Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
          const SizedBox(height: 8),
          ISSearchDropdown(
            label: '주문 유형',
            width: double.infinity,
            height: 50,
            value: selectedStatus,
            onChange: (value) {
              setState(() {
                selectedStatus = value;
                requestAPIData();
              });
            },
            item: [
              ISOptionModel(value: '%', label: '상태 전체'),
              ISOptionModel(value: '10', label: '요청'),
              ISOptionModel(value: '40', label: '완료'),
              ISOptionModel(value: '35', label: '보완'),
              ISOptionModel(value: '99', label: '기타'),
            ].cast<ISOptionModel>(),
          ),
          const SizedBox(height: 8),
          (dataList.length! == 0)
              ? SizedBox(
            height: (widget.tabviewHeight! - 220),
            child: const Align(
                alignment: Alignment.center,
                child: Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
          ) :
          ListView(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: List.generate(dataList.length, (index) {
              return fluentUI.Expander(
                  contentBackgroundColor: Colors.grey[200],
                  headerHeight: 80,
                  header: Padding(
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              alignment: Alignment.center,
                              width: 60,
                              height: 24,
                              decoration: BoxDecoration(
                                color: dataList[index].status != null ? getStatusColor(dataList[index].status!) : null,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.transparent),
                              ),
                              child: Text(dataList[index].status ?? '', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FONT_BOLD, fontSize: 14, fontFamily: FONT_FAMILY,),),
                            ),
                            const SizedBox(width: 10),
                            Padding(
                              padding: const EdgeInsets.only(top: 2),
                              child: Text(dataList[index].requestGbn ?? '', style: const TextStyle(color: Colors.black, fontWeight: FONT_BOLD, fontSize: 16, fontFamily: FONT_FAMILY,),),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(left: 3),
                              child: Text('요청일시 : ', style: TextStyle( fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY,),),
                            ),
                            Text('${dataList[index].blindReqDt}', style: const TextStyle(fontWeight: FONT_NORMAL, fontSize: 16, fontFamily: FONT_FAMILY,),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                  content: Padding(
                    padding: const EdgeInsets.only(top: 8, bottom: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('요청 리뷰', style: TextStyle(color: Color(0xff01CAFF), fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY,),),
                            Container(
                              decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !dataList[index].isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
                              alignment: Alignment.center,
                              child: (dataList[index].isChild == true)
                                  ? const SizedBox.shrink()
                                  : Visibility(
                                    visible: dataList[index].status == '요청' ? true : false,
                                    child: ISButton(
                                        isReverseColor: true,
                                        child: const Text('취소하기'),
                                        onPressed: () {
                                          ISConfirm(context, '리뷰 블라인드 취소', '${dataList[index].custNickName}님의 리뷰 블라인드 요청을 취소하시겠습니까?', (context, isOK) async {
                                            Navigator.of(context).pop();

                                            if (isOK) {
                                              ReviewBlindRequestModel sendData = ReviewBlindRequestModel();
                                              sendData.shop_cd = AuthService.SHOPCD;
                                              sendData.modUcode = AuthService.uCode;
                                              sendData.modUName = AuthService.uName;
                                              sendData.job_gbn = "1";
                                              sendData.visibleGbn = "C"; // r-> 요청 , c -> 취소
                                              sendData.blindEndDt = formatDate(DateTime.now(), [yyyy, mm, dd]);
                                              sendData.orderNo = dataList[index].orderNo;

                                              var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(ReviewController.to.setReviewBlind(sendData.toJson())));

                                              if (value == null) {
                                                ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                              }
                                              else {
                                                if (value == '00') {
                                                  requestAPIData();
                                                }
                                                else {
                                                  ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                                }
                                              }
                                            }
                                          });
                                        },
                                    ),
                                  ),
                            ),
                          ],
                        ),
                        RatingStars(
                          value: dataList[index].starScore as double,
                          starBuilder: (index, color) => Icon(Icons.star, color: color,),
                          starCount: 5,
                          starSize: 20,
                          maxValue: 5,
                          starSpacing: 2,
                          maxValueVisibility: false,
                          valueLabelVisibility: false,
                          valueLabelPadding: const EdgeInsets.symmetric(vertical: 1, horizontal: 8),
                          valueLabelMargin: const EdgeInsets.only(right: 8),
                          starOffColor: const Color(0xffe7e8ea),
                          starColor: Colors.orange,
                        ),
                        const SizedBox(height: 8,),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(width: 80, child: const Text('아이디', style: TextStyle(fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY),)),
                              ],
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('${dataList[index].custNickName!} (${dataList[index].orderNo!})', style: const TextStyle(fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY),),
                                  const SizedBox(height: 8),
                                  ExpandableText(
                                    dataList[index].content == '' ? '내용 없음' : dataList[index].content!,
                                    readLessText: '접기',
                                    readMoreText: '더보기',
                                    style: TextStyle(fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY, color: dataList[index].content == '' ? Colors.grey : Colors.black),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8,),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(width: 80, child: Text('등록 일시', style: TextStyle(fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY),)),
                              ],
                            ),
                            Text(dataList[index].insertDate!, style: TextStyle(fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY),),
                          ],
                        ),
                        const SizedBox(height: 20,),
                        const Text('블라인드 요청 내용', style: TextStyle(color: Color(0xff01CAFF), fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY,),),
                        const SizedBox(height: 10,),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(width: 80, child: const Text('분류', style: TextStyle(fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY))),
                                SizedBox(height: 8,),
                                Container(width: 80, child: const Text('요청사유', style: TextStyle(fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY))),
                              ],
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(dataList[index].blindName!, style: const TextStyle(fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY)),
                                  const SizedBox(height: 8),
                                  ExpandableText(
                                    '${dataList[index].blindReason}',
                                    readLessText: '접기',
                                    readMoreText: '더보기',
                                    style: const TextStyle(fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY, color: Colors.black),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        dataList[index].answerContent != '' && dataList[index].answerContent != null ? Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(width: 80, child: const Text('답변 내용', style: TextStyle(color: Colors.red, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY),)),
                                ],
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    ExpandableText(
                                      dataList[index].answerContent ?? '',
                                      readLessText: '접기',
                                      readMoreText: '더보기',
                                      style: const TextStyle(fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY, color: Colors.black),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ) : Container(),
                      ],
                    ),
                  ));
            }),
          )
        ],
      ),
    );
  }

  List<Widget> searchBarView() {
    return [
      ISSearchSelectDate(
        label: '기간 선택',
        width: Responsive.isMobile(context) == true ? double.infinity : 230,
        value: '${startdate.toString()} ~ ${enddate.toString()}',
        onTap: () async {
          showGeneralDialog(
              context: context,
              barrierDismissible: true,
              barrierLabel: '',
              barrierColor: Colors.black54,
              pageBuilder: (context, animation, secondaryAnimation) {
                return Dialog(
                    insetPadding: EdgeInsets.zero,
                    elevation: 0,
                    backgroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                    child: MultipleViewDateRangePicker(
                      startDate: DateTime.parse(startdate!),
                      endDate: DateTime.parse(enddate!),
                      setDateActionCallback: ({startDate, endDate}) {
                        Navigator.of(context).pop();

                        startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                        enddate = DateFormat('yyyy-MM-dd').format(endDate!);

                        pickDate = true;

                        requestAPIData();
                      },
                    ));
              });
        },
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8,) : const SizedBox(width: 8,),
      ISToggleButtons(
        [
          ISOptionModel(value: '1000', label: '오늘'),
          ISOptionModel(value: '1001', label: '7일'),
          ISOptionModel(value: '1002', label: '1개월'),
          ISOptionModel(value: '1003', label: '3개월'),
          ISOptionModel(value: '1004', label: '6개월'),
        ],
        buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 5) - 6) : 60,
        defaultValue: selectedType,
        pickDate: pickDate,
        afterOnPress: (v) {
          if (v == '1000') {
            startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          } else if (v == '1001') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 7)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          } else if (v == '1002') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 30)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          } else if (v == '1003') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 90)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          } else if (v == '1004') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 180)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }

          setState(() {
            selectedType = v.toString();
            pickDate = false;
          });

          requestAPIData();
        },
      ),
    ];
  }

  Widget requestDetailWidget(ReviewBlindHistoryListModel data) {
    Widget tempWidget;

    tempWidget = Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('요청 리뷰', style: TextStyle(color: Color(0xff01CAFF), fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY),),
            const SizedBox(height: 8,),
            Row(
              children: [
                const SizedBox(width: 60, child: Text('아이디', style: TextStyle(fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY),
                )),
                Expanded(
                    child: Text('${data.custNickName!} (${data.orderNo!})', style: const TextStyle(color: Colors.grey, fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY),
                    )),
                RatingStars(
                  value: data.starScore!,
                  starBuilder: (index, color) => Icon(Icons.star, color: color,),
                  starCount: 5,
                  starSize: 20,
                  maxValue: 5,
                  starSpacing: 2,
                  maxValueVisibility: false,
                  valueLabelVisibility: false,
                  valueLabelPadding: const EdgeInsets.symmetric(vertical: 1, horizontal: 8),
                  valueLabelMargin: const EdgeInsets.only(right: 8),
                  starOffColor: const Color(0xffe7e8ea),
                  starColor: Colors.orange,
                ),
              ],
            ),
            const SizedBox(height: 8,),
            Row(
              children: [
                const SizedBox(width: 60, child: Text('내용', style: TextStyle(fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY),
                )),
                Expanded(
                  child: ISInput(
                    //contentPadding: 16.0,
                    value: data.content!,
                    context: context,
                    height: 100,
                    readOnly: true,
                    maxLines: 20,
                    keyboardType: TextInputType.multiline,
                  ),
                ),
                // Expanded(
                //     child: Text(data.content!, style: const TextStyle(fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY))
                // ),
              ],
            ),
            const SizedBox(height: 8,),
            Row(
              children: [
                const SizedBox(width: 60, child: Text('등록 일시', style: TextStyle(fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY),
                )),
                Expanded(child: Text(data.insertDate!, style: const TextStyle(fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY))),
              ],
            ),
          ],
        ),
        const SizedBox(height: 20,),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('블라인드 요청 내용', style: TextStyle(color: Color(0xff01CAFF), fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY),),
            const SizedBox(height: 8,),
            Row(
              children: [
                const SizedBox(width: 60, child: Text('분류', style: TextStyle(fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY),
                )),
                Expanded(child: Text(data.blindName!, style: const TextStyle(fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY))),
              ],
            ),
            const SizedBox(height: 8,),
            Row(
              children: [
                const SizedBox(width: 60, child: Text('요청사유', style: TextStyle(fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY),
                )),
                Expanded(child: Text(data.blindReason!, style: const TextStyle(fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY))),
              ],
            ),
            data.answerContent != '' && data.answerContent != null ? Padding(
              padding: const EdgeInsets.only(top: 15),
              child: Row(
                children: [
                  const SizedBox(width: 60, child: Text('답변 내용', style: TextStyle(color: Colors.red, fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY),
                  )),
                  Expanded(child: Text(data.answerContent ?? '', style: const TextStyle(fontWeight: FONT_NORMAL, fontSize: 13, fontFamily: FONT_FAMILY))),
                ],
              ),
            ) : Container(),
          ],
        ),
      ],
    );

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Column(
        children: [
          tempWidget!,
        ],
      ),
    );
  }

  Color getStatusColor(String status) {
    Color tempColor;

    if (status == '요청') {
      tempColor = const Color(0xffFFCC34);
    } else if (status == '보완') {
      tempColor = Colors.red;
    } else if (status == '완료') {
      tempColor = const Color(0xff01CAFF);
    } else if (status == '기타') {
      tempColor = Colors.grey;
    } else {
      tempColor = Colors.grey;
    }

    return tempColor;
  }
}

// class ReviewBlindHistorySource extends DataTableSource {
//   final BuildContext context;
//   late List<ReviewBlindHistoryListModel> dataSource;
//   // Add row tap handlers and show snackbar
//   bool hasRowTaps = false;
//   // Override height values for certain rows
//   bool hasRowHeightOverrides = false;
//   // Color each Row by index's parity
//   bool hasZebraStripes = false;
//
//   int _selectedCount = 0;
//
//   ReviewBlindHistorySource.empty(this.context) {
//     dataSource = [];
//   }
//
//   ReviewBlindHistorySource(this.context, this.dataSource, [sortedByValue = false, this.hasRowTaps = false, this.hasRowHeightOverrides = false, this.hasZebraStripes = false]) {
//     //dataSource = dataList;
//     // if (sortedByValue) {
//     //   sort((d) => d., true);
//     // }
//   }
//
//   // sort
//   // void sort<T>(
//   //     Comparable<T> Function(SaleInfoModel d) getField, bool ascending) {
//   //   dataSource.sort((a, b) {
//   //     final aValue = getField(a);
//   //     final bValue = getField(b);
//   //     return ascending
//   //         ? Comparable.compare(aValue, bValue)
//   //         : Comparable.compare(bValue, aValue);
//   //   });
//   //   notifyListeners();
//   // }
//
//   // void updateSelectedValues(RestorableDessertSelections selectedRows) {
//   //   _selectedCount = 0;
//   //   for (var i = 0; i < dataSource.length; i += 1) {
//   //     var data = dataSource[i];
//   //     if (selectedRows.isSelected(i)) {
//   //       data.selected = true;
//   //       _selectedCount += 1;
//   //     } else {
//   //       data.selected = false;
//   //     }
//   //   }
//   //   notifyListeners();
//   // }
//
//   @override
//   DataRow getRow(int index, [Color? color, double fontSize = 14.0, FontWeight? fontWeight]) {
//     assert(index >= 0);
//     if (index >= dataSource.length) throw 'index > dataList.length';
//     final data = dataSource[index];
//
//     return ;
//   }
//
//
//
//   @override
//   int get rowCount => dataSource.length;
//
//   @override
//   bool get isRowCountApproximate => false;
//
//   @override
//   int get selectedRowCount => _selectedCount;
//
//   void selectAll(bool? checked) {
//     for (final data in dataSource) {
//       data.selected = checked ?? false;
//     }
//     _selectedCount = (checked ?? false) ? dataSource.length : 0;
//     notifyListeners();
//   }
// }