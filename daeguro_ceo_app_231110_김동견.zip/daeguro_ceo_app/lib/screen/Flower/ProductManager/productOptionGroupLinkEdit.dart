import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionGroupLinEditkModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductOptionGroupLinkEdit extends StatefulWidget {
  final String? optionGroupName;
  final String? optionGrouCd;
  const ProductOptionGroupLinkEdit({Key? key, this.optionGroupName, this.optionGrouCd})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ProductOptionGroupLinkEditState();
  }
}

class ProductOptionGroupLinkEditState extends State<ProductOptionGroupLinkEdit> {
  late List<fluentUI.TreeViewItem> treeProductList = [];

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getProductLinkList(widget.optionGrouCd!))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      treeProductList.clear();

      value.forEach((element) {
        treeProductList.add(
            fluentUI.TreeViewItem(
              content: Text('${element['name'].toString()} : ${Utils.getCashComma(element['cost'].toString())}원'),
              selected: element['selected'].toString() == 'Y' ? true : false,
              value: element['prodCode'].toString()
            )
        );
      });
    }

    setState(() {});
  }
  @override
  void dispose() {
    super.dispose();
    treeProductList.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();//.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('상품 연결', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 20, right: 16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //const Divider(color: Colors.grey, height: 0.0,),
                const SizedBox(height: 16,),
                const Text('연결 상품 선택', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                Text('[${widget.optionGroupName}]에 연결할 상품을 선택해 주세요.', style: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                const Divider(),
                const SizedBox(height: 8),
                if (treeProductList.isNotEmpty)...[
                  fluentUI.TreeView(
                    selectionMode: fluentUI.TreeViewSelectionMode.multiple,
                    shrinkWrap: true,
                    items: treeProductList,
                    onSelectionChanged: (selectedItems) async {
                      //selectedItems.map((i) => i.value);
                      // selectedItems.map((element) {
                      //   //print('element:${element.value}');
                      // });
                    },
                    // onSecondaryTap: (item, details) async {
                    // },
                    //onItemInvoked: (item) async => debugPrint('onItemInvoked: \$item'),
                    // onSelectionChanged: (selectedItems) async => debugPrint(
                    //     'onSelectionChanged: \${selectedItems.map((i) => i.value)}'),
                    //
                    // onSecondaryTap: (item, details) async {
                    // },
                  ),
                  const Divider(),
                ]
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              List<String> selectedCheckList = [];
              treeProductList.forEach((element) {
                if (element.selected == true){
                  selectedCheckList.add(element.value);
                }
              });

              if (selectedCheckList.isEmpty){
                ISAlert(context, content: '선택된 상품이 없습니다.\n확인 후, 다시 시도해 주세요.');
                return;
              }

              BuildContext oldContext = context;

              ISConfirm(context, '상품 연결', '상품연결 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  ProductOptionGroupLinkEditModel sendData = ProductOptionGroupLinkEditModel();
                  sendData.shopCd = AuthService.SHOPCD;
                  sendData.optGrpCd = widget.optionGrouCd;
                  sendData.prodCd = selectedCheckList;
                  sendData.uCode = AuthService.uCode;
                  sendData.uName = AuthService.uName;

                  var value = await showDialog(
                      context: context,
                      barrierColor: Colors.transparent,
                      builder: (context) => FutureProgressDialog(ProductInfoController.to.updateProductLink(sendData.toJson()))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(oldContext).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


