
import 'dart:convert';
import 'dart:html';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOriginLocalListModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateEditModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productOriginLocalEdit.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuGroupEdit.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class OriginLocalInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const OriginLocalInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<OriginLocalInfoMain> createState() => _OriginLocalInfoMainState();
}

class _OriginLocalInfoMainState extends State<OriginLocalInfoMain> {

  String? shop_origin_mark = '';

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(MenuInfoController.to.getOriginData())
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      shop_origin_mark = value as String;
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(MenuInfoController());
    Get.put(ShopController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {

    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          if (AuthService.ShopServiceGbn != AuthService.SHOPGBN_FLOWER){
            requestAPIData();
          }
          else{
            router.go('/');
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            elevation: 1,
            shape: appTheme.cardShapStyle,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('원산지 정보', style: TextStyle(fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                  ISButton(
                    child: const Text('저장'),
                    onPressed: () {
                      ISConfirm(context, '원산지 정보', '저장하시겠습니까?', (context, isOK) async {
                        Navigator.of(context).pop();

                        if (isOK){
                          ShopOperateEditModel sendData = ShopOperateEditModel();
                          sendData.shopCd = AuthService.SHOPCD;
                          sendData.modUcode = AuthService.uCode;
                          sendData.modName = AuthService.uName;
                          sendData.jobGbn = '2';
                          sendData.originMark = shop_origin_mark;

                          var value = await showDialog(
                              context: context,
                              barrierColor: Colors.transparent,
                              builder: (context) => FutureProgressDialog(ShopController.to.updateOperateInfo(sendData.toJson()))
                          );

                          if (value == null) {
                            ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                          }
                          else {
                            if (value == '00') {
                              ISAlert(context, title: '알림', content: '저장이 완료되었습니다.');
                              requestAPIData();
                            }
                            else{
                              ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                            }
                          }
                        }
                      });
                    },
                  )
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8.0, bottom: 8.0, left: 3, right: 2),
            child: TextFormField(
              style: const TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
              keyboardType: TextInputType.multiline,
              maxLines: 8,
              controller: TextEditingController(text: shop_origin_mark),
              maxLengthEnforcement: MaxLengthEnforcement.enforced,
              maxLength: 4000,
              buildCounter: (context, { required currentLength, required isFocused, maxLength }) {

                int utf8Length = utf8.encode(TextEditingController(text: shop_origin_mark).text).length;
                String counterText = '$utf8Length/4000 byte';

                TextStyle counterStyle;

                if(utf8Length > maxLength!){
                  counterStyle = const TextStyle(color: Colors.red, fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);
                }else{
                  counterStyle = const TextStyle(color: Colors.black54, fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);
                }

                return Container(
                  child: Text(
                    counterText,
                    style: counterStyle,
                  ),
                );
              },
              onChanged: (v) {
                  shop_origin_mark = v.toString();
              },
              decoration: const InputDecoration(
                hintText: '원산지 설명',
                fillColor: Colors.white,
                filled: true,
                enabled: true,
                hintStyle: TextStyle(color: Colors.black54, fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.black12, width: 1.0)),
                focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.lightBlueAccent, width: 1.0)),
                isDense: true,
                contentPadding: const EdgeInsets.fromLTRB(10, 10, 4, 10),
              ),
              inputFormatters: [
                TextInputFormatter.withFunction((oldValue, newValue) {
                  if(newValue.text.isEmpty) {
                    return newValue;
                  }
                  try{
                    int inputUtfLength = utf8.encode(newValue.text).length;
                    if(inputUtfLength > 4000){
                      String encodeText = utf8.encode(newValue.text) as String;
                      var decodeText = utf8.decode(encodeText.substring(0,3996) as List<int>);

                      final cursorPosition = newValue.selection.baseOffset;
                      final newCursorPosition = cursorPosition + (decodeText.length - newValue.text.length);

                      return TextEditingValue(
                        text: decodeText,
                        selection: TextSelection.collapsed(offset: newCursorPosition),
                      );
                    }
                    else{
                      return newValue;
                    }
                  }catch (_) {
                    return oldValue;
                  }

                },)
              ],
            ),

            // ISInput(
            //   value: shop_origin_mark,
            //   context: context,
            //   height: 200,
            //   //padding: 0,
            //   label: '원산지 설명',
            //   keyboardType: TextInputType.multiline,
            //   maxLines: 8,
            //   maxLength: 4000,
            //   counterText: '${utf8.encode(shop_origin_mark.toString()).length}/4000 byte',
            //   onChange: (v) {
            //     // setState(() {
            //       shop_origin_mark = v.toString();
            //     // });
            //   },
            //   inputFormatters: [Utf8LengthLimitingTextInputFormatter(4000)],
            // ),
          )

          //const Divider(height: 1)
        ],
      ),
    );
  }

  
}

