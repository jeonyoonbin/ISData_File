import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveApplyModel {
  ReserveApplyModel();

  bool? selected = false;
  String? shopCd;
  String? uCode;
  String? userName;
  String? gbn;

  factory ReserveApplyModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveApplyModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveApplyModel()
    ..shopCd = json['shopCd'] as String
    ..uCode = json['uCode'] as String
    ..userName = json['userName'] as String
    ..gbn = json['gbn'] as String;

}

Map<String, dynamic> _$ModelToJson(ReserveApplyModel instance) => <String, dynamic>{
  'shopCd': instance.shopCd,
  'uCode': instance.uCode,
  'userName': instance.userName,
  'gbn': instance.gbn,
};