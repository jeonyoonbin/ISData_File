import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class MultiShopAbsentEditModel {
  MultiShopAbsentEditModel();

  List<String>? shopCd = [];
  List<String>? absentYn= [];
  String? uCode;
  String? uName;

  factory MultiShopAbsentEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

MultiShopAbsentEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return MultiShopAbsentEditModel()
    ..shopCd = json['shopCd'].cast<String>()
    ..absentYn = json['absentYn'].cast<String>()
    ..uCode = json['uCode'] as String
    ..uName = json['uName'] as String;
}

Map<String, dynamic> _$ModelToJson(MultiShopAbsentEditModel instance) => <String, dynamic>{
  'shopCd': instance.shopCd,
  'absentYn': instance.absentYn,
  'uCode': instance.uCode,
  'uName': instance.uName
};