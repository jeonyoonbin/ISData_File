import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReviewBlindRequestModel {
  ReviewBlindRequestModel();

  String? shop_cd;
  String? modUcode;
  String? modUName;
  String? job_gbn; // 1 고정
  String? visibleGbn; // R: 요청, C: 취소
  String? blindEndDt;
  String? orderNo;
  String? blindCode;
  String? blindReason;


  factory ReviewBlindRequestModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReviewBlindRequestModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReviewBlindRequestModel()
    ..shop_cd = json['shop_cd']
    ..modUcode = json['modUcode']
    ..modUName = json['modUName']
    ..job_gbn = json['job_gbn']
    ..visibleGbn = json['visibleGbn']
    ..blindEndDt = json['blindEndDt']
    ..orderNo = json['orderNo']
    ..blindCode = json['blindCode']
    ..blindReason = json['blindReason']
  ;
}

Map<String, dynamic> _$ModelToJson(ReviewBlindRequestModel instance) =>
    <String, dynamic>{
      'shop_cd': instance.shop_cd,
      'modUcode': instance.modUcode,
      'modUName': instance.modUName,
      'job_gbn': instance.job_gbn,
      'visibleGbn': instance.visibleGbn,
      'blindEndDt': instance.blindEndDt,
      'orderNo': instance.orderNo,
      'blindCode': instance.blindCode,
      'blindReason': instance.blindReason
    };
