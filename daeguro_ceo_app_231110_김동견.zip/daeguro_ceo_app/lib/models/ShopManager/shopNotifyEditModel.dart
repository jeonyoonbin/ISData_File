import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopNotifyEditModel {
  ShopNotifyEditModel();

  bool selected = false;
  String? jobGbn;
  String? introCd;
  String? shopCd;
  String? introGbn;
  String? introContents;
  String? useGbn;
  String? modUcode;
  String? modName;

  factory ShopNotifyEditModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopNotifyEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopNotifyEditModel()
  // ..selected = json['selected'] as bool
    ..jobGbn = json['jobGbn'] as String
    ..introCd = json['introCd'] as String
    ..shopCd = json['shopCd'] as String
    ..introGbn = json['introGbn'] as String
    ..introContents = json['introContents'] as String
    ..useGbn = json['useGbn'] as String
    ..modUcode = json['modUcode'] as String
    ..modName = json['modName'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopNotifyEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'jobGbn': instance.jobGbn,
      'introCd': instance.introCd,
      'shopCd': instance.shopCd,
      'introGbn': instance.introGbn,
      'introContents': instance.introContents,
      'useGbn': instance.useGbn,
      'modUcode': instance.modUcode,
      'modName': instance.modName
};
