class LiveeEventMenuListEditModel {
  LiveeEventMenuListEditModel();

  bool selected = false;
  // String? menuGroupName;
  // String? menuName;
  // String? menuPrice;

  String? ccCode;
  String? shopCd;
  String? menuGrpCd;
  String? menuGrpName;
  String? menuCd;
  String? menuName;
  String? noFlag;
  String? menuCost;
}
