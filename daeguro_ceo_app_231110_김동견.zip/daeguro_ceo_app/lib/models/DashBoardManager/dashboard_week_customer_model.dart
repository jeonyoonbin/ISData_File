class DashboardWeekCustomerModel {
  DashboardWeekCustomerModel();

  String? INSERT_DATE;
  int? INSTALL_COUNT;
  int? NEW_COSTOMER_COUNT;
}
