class AccountInfoModel {
  String? bankName = '';
  String? bankCode = '';
  String? accountNo = '';
  String? accOwner = '';
  String? realRemainAmt = '';
  String? remainAmt = '';
  String? withdrawAmt = '';
  String? accConfirmGbn = '';
  String? amtTransSmsGbn = '';
}
