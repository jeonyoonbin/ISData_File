
import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
//import 'package:get/get.dart';

class DioReserveClient {
  //static DioClient get to => Get.find();
  //static String default_ContentType = 'text/plain';

  static Map<String, dynamic> Header_Reserve = {
    'Authorization' : 'bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb2RlIjoiMTQwIiwiSWQiOiJ0ZXN0Y3VzdDAxQG5hdmVyLmNvbSIsIklkR2JuIjoiQSIsImp0aSI6Ijg0NTU2YTJjLTA5NTgtNGM0MS04YzdmLTk5NzZhMTZjNTU3OSIsIm5iZiI6MTYyMTkzNzc0OSwiZXhwIjoxNjIxOTM3OTI5LCJpYXQiOjE2MjE5Mzc3NDl9.LXMrAEn0nFeA12-ALUPouwVHJ2DxXN_eRUCnFxSjGsU',
    'Content-Type' : 'application/json'
  };

  final Dio _dio = Dio(
      BaseOptions(
        baseUrl: ServerInfo.REST_RESERVE_URL,
        connectTimeout: const Duration(milliseconds: 5000),
        receiveTimeout: const Duration(milliseconds: 5000),
        sendTimeout: const Duration(milliseconds: 5000),
        headers: Header_Reserve
      )
  );

  Future<dynamic> get(String value) async {
    Response? result;
    try{
      result = await _dio.get(value);
    } on DioError catch (e){
      // if (e.response != null) {
      //   await DioClient().postRestLog('0', '/DioClient/get', '[Dio Error] response is Not NULL \n\nError Msg: Status:${e.response?.statusCode}  DATA: ${e.response?.data} HEADERS: ${e.response?.headers} \n\nParam: ${value} ');
      // }
      // else {
      //   await DioClient().postRestLog('0', '/DioClient/get', '[Dio Error] response is NULL \n\nError Msg: ${e.message} \n\nParam: ${value} ');


      // }
    }

    //_dio.clear();
    _dio.close();

    return result;
  }

  Future<dynamic> post(String value, {dynamic data}) async {
    Response? result;

    try {
      result = await _dio.post(value, data: data);

    }
    on DioError catch (e) {
      // await DioClient().postRestLog('0', '/DioClient/post', '[Dio Error] Error Msg: ${e}');
    }

    //_dio.clear();
    _dio.close();

    return result;
  }

  Future<dynamic> put(String value, {dynamic data}) async {
    Response? result;

    try {
      result = await _dio.put(value, data: data);
    }
    on DioError catch (e) {
      // await DioClient().postRestLog('0', '/DioClient/put', '[Dio Error] Error Msg: ${e}');
    }

    //_dio.clear();
    _dio.close();

    return result;
  }

  Future<dynamic> delete(String value , {dynamic data}) async {
    Response? result;

    try {
      result = await _dio.delete(value, data: data);
    }
    on DioError catch (e) {
      // await DioClient().postRestLog('0', '/DioClient/delete', '[Dio Error] Error Msg: ${e}');
    }

    //_dio.clear();
    _dio.close();

    return result;
  }

  Future<dynamic> postRestLog(String div, String position, String msg) async {
    Response? result;

    try {
      //result = await _dio.post(ServerInfo.REST_URL_LOG_ERROR + '?div=$div&position=$position&msg=$msg');

    }
    on DioError catch (e) {
    }

    //_dio.clear();
    _dio.close();

    return result;
  }
}