import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class LayoutBottom extends StatefulWidget {
  final String? titleName;

  const LayoutBottom({Key? key, this.titleName}) : super(key: key);

  @override
  _LayoutBottomState createState() => _LayoutBottomState();
}

class _LayoutBottomState extends State<LayoutBottom> {
  //final String? titleName;
  bool noticeService = false;

  @override
  void initState() {
    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.transparent,//const Color(0xFFf3f3f3),//const Color(0xff2d3341),
      width: double.infinity,
      //height: 50,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 300,
              child: fluentUI.Expander(
                  isContentBorder: false,
                  headerHeight : 30,
                  headerBackgroundColor: fluentUI.ButtonState.resolveWith((states) => fluentUI.Colors.transparent),
                  contentBackgroundColor: Colors.transparent,
                  contentPadding: const EdgeInsets.all(16.0),
                  header: const Text('인성데이타(주) 자세히 보기', style: TextStyle(fontSize: 11, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                  content: const SingleChildScrollView(
                    child: Text("주소 : 대구광역시 서구 북비산로 369 2층\n\n대표자 : 최현환\n사업자등록번호 : 577-86-02725\n통신판매업신고 : 제 2005-대구서구-0304호\n개인정보관리책임자 : 최현환(choi4016@isdata.kr)\n고객센터 : 1661-3773  팩스번호 : 070-8220-5229\n운영시간 : 09:00 ~ 18:00",
                        style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))
                )
              ),
            ),
            if (Responsive.isMobile(context) == false)...[
              const SizedBox(width: 20,),
              SizedBox(
                height: 30,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    TextButton(
                      style: ButtonStyle(
                        animationDuration: const Duration(microseconds: 100),
                        overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
                        foregroundColor: MaterialStateProperty.resolveWith<Color>(
                                (Set<MaterialState> states) {
                              if (states.contains(MaterialState.hovered))
                                return Color(0xff01CAFF);
                              return Colors.black;//Colors.white;
                            }),
                      ),
                      onPressed: () {
                        Utils.launchURL('https://terms.daeguro.co.kr:45028/agreement/agreement1-1.htm');
                      },
                      child: const Text('서비스 이용약관', style: TextStyle(fontSize: 11, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                    ),
                    TextButton(
                      style: ButtonStyle(
                        animationDuration: const Duration(microseconds: 100),
                        overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
                        foregroundColor: MaterialStateProperty.resolveWith<Color>(
                                (Set<MaterialState> states) {
                              if (states.contains(MaterialState.hovered))
                                return Color(0xff01CAFF);
                              return Colors.black;//Colors.white;
                            }),
                      ),
                      onPressed: () {
                        Utils.launchURL('https://terms.daeguro.co.kr:45028/agreement/agreement9.htm');
                      },
                      child: const Text('개인정보 이용 동의서', style: TextStyle(fontSize: 11, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                    ),
                    TextButton(
                      style: ButtonStyle(
                        animationDuration: const Duration(microseconds: 100),
                        overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
                        foregroundColor: MaterialStateProperty.resolveWith<Color>(
                                (Set<MaterialState> states) {
                              if (states.contains(MaterialState.hovered))
                                return Color(0xff01CAFF);
                              return Colors.black;//Colors.white;
                            }),
                      ),
                      onPressed: () {
                        Utils.launchURL('https://terms.daeguro.co.kr:45028/agreement/agreement3.htm');
                      },
                      child: const Text('개인정보처리방침', style: TextStyle(fontSize: 11, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                    ),
                    TextButton(
                      style: ButtonStyle(
                        animationDuration: const Duration(microseconds: 100),
                        overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
                        foregroundColor: MaterialStateProperty.resolveWith<Color>(
                                (Set<MaterialState> states) {
                              if (states.contains(MaterialState.hovered))
                                return Color(0xff01CAFF);
                              return Colors.black;//Colors.white;
                            }),
                      ),
                      onPressed: () {
                        Utils.launchURL('https://terms.daeguro.co.kr:45028/agreement/agreement2.htm');
                      },
                      child: const Text('위치기반서비스', style: TextStyle(fontSize: 11, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                    ),
                  ],
                ),
              ),
            ]
          ],
        ),
      )
    );
  }
}