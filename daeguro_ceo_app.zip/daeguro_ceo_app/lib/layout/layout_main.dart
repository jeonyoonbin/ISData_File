import 'dart:js_util';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/LogInManager/loginController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopStatusEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:get/instance_manager.dart';
import 'package:go_router/go_router.dart';
import 'package:fluent_ui/fluent_ui.dart';
import 'package:flutter/material.dart' as material;
import 'package:provider/provider.dart';
import 'dart:convert';

class LayoutMain extends StatefulWidget {
  const LayoutMain({Key? key, required this.child, required this.shellContext, required this.state,}) : super(key: key);

  final Widget child;
  final BuildContext? shellContext;
  final GoRouterState state;

  @override
  State<LayoutMain> createState() => _LayoutMainState();
}

class _LayoutMainState extends State<LayoutMain> {
  bool value = false;

  final viewKey = GlobalKey(debugLabel: 'Navigation View Key');
  final searchKey = GlobalKey(debugLabel: 'Search Bar Key');
  final searchFocusNode = FocusNode();
  final menuFocusNode = FocusNode();
  final searchController = TextEditingController();

  late List<NavigationPaneItem> baseNaviItem;

  String? selMultiShop= '';
  List<ISOptionModel> selectMultiShopList = [];

  requestAPIData() async {
    selectMultiShopList.clear();

    await ShopController.to.getMultiShopListData(AuthService.MultiShopCd).then((value) {
      if (value == null) {
        ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        value.forEach((element) {
          if(AuthService.SHOPCD == element['shopCd'].toString()) {
            selMultiShop = element['shopCd'].toString();
          }

          selectMultiShopList.add(ISOptionModel(value: element['shopCd'].toString(), label: element['shopName'].toString(), id: element['shopId'].toString(), pass: element['shopPass'].toString()));
        });
      }
    });
    setState(() {});
  }

  Future<String> _requestMoveAPIData(String mvShopCd) async {
    String rtn = '99';
    await ShopController.to.getMultiShopCheck(mvShopCd).then((value) {
      if (value == null) {
        ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
        rtn = '99';
      }
      else {
        if(value == '00') {
          rtn = '00';
        } else {
          ISAlert(context, content: '연결 멀티샵 검증에 실패 했습니다. \n\n관리자에게 문의 바랍니다');
          rtn ='99';
        }
      }
    });

    return rtn;
  }

  final List<NavigationPaneItem> deliverylItems = [
    PaneItem(
      key: const Key('/'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_daeguro.png'))),//const Icon(FluentIcons.home),
      title: const Text('우리 매장 현황', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
        if (router.location != '/') {
          router.go('/');
        }
      },
    ),
    //PaneItemSeparator(),
    PaneItem(
      key: const Key('/shop/kindInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_crown_left_24_dp.png'))),//const Icon(FluentIcons.home),
      title: const Text('착한 매장', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
        if (router.location != '/shop/kindInfo') {
          router.go('/shop/kindInfo');
        }
      },
    ),
    //PaneItemSeparator(),
    if (AuthService.MultiShopYn == 'Y')
      PaneItem(
        key: const Key('/multiShopDashboard'),
        icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_new.png'))),//const Icon(FluentIcons.home),
        title: const Text('전체 매장 현황', style: naviItemTextStyle),
        body: const SizedBox.shrink(),
        isChild: true,
        onTap: () {
          //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
          if (router.location != '/multiShopDashboard') {
            router.go('/multiShopDashboard');
          }
        },
      ),
    PaneItemSeparator(),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
          child: Text('이벤트/할인 관리', style: naviHeaderTextStyle),
        )
    ),
    if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD)
      PaneItem(
        height: naviPaneItemChildHeight,
        key: const Key('/liveEvent/info'),
        icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_category_event_hall.png'))),//const Icon(FluentIcons.special_event),
        title: const Text('라이브 이벤트', style: naviItemTextStyle,),
        body: const SizedBox.shrink(),
        isChild: true,
        onTap: () {
          if (router.location != '/liveEvent/info') {
            router.go('/liveEvent/info');
            //router.pop();
          }
        },
      ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/sale/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/delivery_shop_coupon_enable.png'))),//const Icon(material.Icons.payments),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('우리 매장 쿠폰', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/sale/info') {
          router.go('/sale/info');
          //router.pop();
        }
      },
    ),
    if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD)
      PaneItem(
        height: naviPaneItemChildHeight,
        key: const Key('/sale/packDiscount'),
        icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_discount_sticker_32.png'))),//const Icon(material.Icons.payments),//const SizedBox(width: 0,),//const Icon(FluentIcons.bulleted_tree_list, color: Colors.white),
        title: const Text('포장 할인', style: naviItemTextStyle),
        body: const SizedBox.shrink(),
        isChild: true,
        onTap: () {
          if (router.location != '/sale/packDiscount') {
            router.go('/sale/packDiscount');
            //router.pop();
          }
        },
      ),

    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
          child: Text('매장 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_project_reserve_on.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //debugPrint('[운영]router.location:${router.location}');
        if (router.location != '/shop/info') {
          router.go('/shop/info');
          //router.pop();
        }
      },
    ),
    if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD)
      PaneItem(
        height: naviPaneItemChildHeight,
        key: const Key('/order/deliTip'),
        icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_project_delivery_on.png'))),//const Icon(material.Icons.receipt),//const SizedBox(width: 0,),//const Icon(FluentIcons.table_header_row, color: Colors.white),
        title: const Text('배달지역 및 배달팁', style: naviItemTextStyle),
        body: const SizedBox.shrink(),
        isChild: true,
        onTap: () {
          if (router.location != '/order/deliTip') {
            router.go('/order/deliTip');
            //router.pop();
          }
        },
      ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/notifyInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/reserve_shop_notice_23.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장·리뷰 알림', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/shop/notifyInfo') {
          router.go('/shop/notifyInfo');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: Padding(
          padding: const EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text((AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD ? '메뉴 관리' : '상품 관리'), style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: Key(AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD ? '/menu/menuInfo' : '/menu/productInfo'),
      icon: SizedBox(width: 30, height: 30, child: Image(image: AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD ? const AssetImage('images/delivery_category_korean_food.png') : const AssetImage('images/delivery_category_flower.png'))), //AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD ? const Icon(material.Icons.room_service) : ,// const Icon(material.Icons.room_service),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: Text((AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD ? '메뉴 관리' : '상품 관리'), style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD ? '/menu/menuInfo' : '/menu/productInfo')) {
          router.go(AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD ? '/menu/menuInfo' : '/menu/productInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/menu/soldOutInfo'),//Key(ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_out_of_stock.png'))),//const Icon(material.Icons.room_service),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('품절 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/menu/soldOutInfo') {
          router.go('/menu/soldOutInfo');
          //router.pop();
        }
        // if (router.location != (ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo')) {
        //   router.go(ShopUseState.currentShopGbn == ShopUseState.SHOPGBN_FOOD ? '/menu/soldOutInfo' : '/menu/productSoldOutInfo');
        //   //router.pop();
        // }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('주문/매출 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/order/orderInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_card_list.png'))),//const Icon(material.Icons.receipt),//const SizedBox(width: 0,),//const Icon(FluentIcons.navigation_flipper, color: Colors.white),
      title: const Text('주문 정보', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/order/orderInfo') {
          router.go('/order/orderInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/account/info'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_pay_type_account_sel_32.png'))),//const Icon(material.Icons.calculate),//const SizedBox(width: 0,),//const Icon(FluentIcons.text_field),
      title: const Text('매출 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/account/info') {
          router.go('/account/info');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('리뷰 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      key: const Key('/review/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_review.png'))),//const Icon(material.Icons.rate_review),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('리뷰 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/review/info') {
          router.go('/review/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      key: const Key('/request/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_alert_notice.png'))),//const Icon(material.Icons.info),
      title: const Text('변경 요청 이력', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //print('[변경]router.location:${router.location}');
        if (router.location != '/request/info') {
          router.go('/request/info');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('이용 가이드', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/noticeInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_board.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('공지사항', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/noticeInfo') {
          router.go('/guide/noticeInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/faqInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/taxi_alert_safe_message.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('FAQ', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/faqInfo') {
          router.go('/guide/faqInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/userGuide'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_help.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('이용자가이드', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/userGuide') {
          router.go('/guide/userGuide');
          //router.pop();
        }
      },
    ),
  ];

  final List<NavigationPaneItem> reserveItems = [
    PaneItem(
      key: const Key('/'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_daeguro.png'))),//const Icon(FluentIcons.home),
      title: const Text('우리 매장 현황', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginScreen()), (Route<dynamic> route) => false),
        if (router.location != '/') {
          router.go('/');
        }
      },
    ),
    PaneItemSeparator(),
    PaneItemHeader(
        header: GestureDetector(
          child: const Padding(
            padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
            child: Text('매장 관리', style: naviHeaderTextStyle),
          ),
          onTap: () {
            // isOpen = !isOpen;
            // debugPrint('isOpen:${isOpen}');
          },
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/shop/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_project_reserve_on.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //debugPrint('[운영]router.location:${router.location}');
        if (router.location != '/shop/info') {
          router.go('/shop/info');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/reserve/notifyInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_new_sticker_more_padding_26.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 소식', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/reserve/notifyInfo') {
          router.go('/reserve/notifyInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/reserve/notifyImageInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/delivery_good_shop.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('매장 사진', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/reserve/notifyImageInfo') {
          router.go('/reserve/notifyImageInfo');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: GestureDetector(
          child: const Padding(
            padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//all(10.0),
            child: Text('예약 관리', style: naviHeaderTextStyle),
          ),
          onTap: () {
            // isOpen = !isOpen;
            // debugPrint('isOpen:${isOpen}');
          },
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/reserve/timeSchedule'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_mypage_notice.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('시간별 예약 설정', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //debugPrint('[운영]router.location:${router.location}');
        if (router.location != '/reserve/timeSchedule') {
          router.go('/reserve/timeSchedule');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/reserve/infoDashboard'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_mypage_customer_center.png'))),//const Icon(material.Icons.storefront),//const SizedBox(width: 0,),//icon: const Icon(FluentIcons.button_control, color: Colors.white),//Container(padding: EdgeInsets.only(left: 20), child: const Icon(FluentIcons.button_control)),
      title: const Text('예약 현황', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //debugPrint('[운영]router.location:${router.location}');
        if (router.location != '/reserve/infoDashboard') {
          router.go('/reserve/infoDashboard');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('리뷰 관리', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      key: const Key('/reserve/review'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/common_mypage_review.png'))),//const Icon(material.Icons.rate_review),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('리뷰 관리', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/reserve/review') {
          router.go('/reserve/review');
          //router.pop();
        }
      },
    ),
    PaneItem(
      key: const Key('/request/info'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_alert_notice.png'))),//const Icon(material.Icons.info),
      title: const Text('변경 요청 이력', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        //print('[변경]router.location:${router.location}');
        if (router.location != '/request/info') {
          router.go('/request/info');
          //router.pop();
        }
      },
    ),
    PaneItemHeader(
        header: const Padding(
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),//EdgeInsets.all(10.0),
          child: Text('이용 가이드', style: naviHeaderTextStyle),
        )
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/noticeInfo'),
      icon: const SizedBox(width: 30, height: 30, child: Image(image: AssetImage('images/taxi_category_board.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.un_set_color, color: Colors.white),
      title: const Text('공지사항', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/noticeInfo') {
          router.go('/guide/noticeInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/faqInfo'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/taxi_alert_safe_message.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('FAQ', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/faqInfo') {
          router.go('/guide/faqInfo');
          //router.pop();
        }
      },
    ),
    PaneItem(
      height: naviPaneItemChildHeight,
      key: const Key('/guide/userGuide'),
      icon: const SizedBox(width: 30, height: 24, child: Image(image: AssetImage('images/common_help.png'))),//const Icon(material.Icons.help),//const SizedBox(width: 0,),//const Icon(FluentIcons.customize_toolbar, color: Colors.white),
      title: const Text('이용자가이드', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      isChild: true,
      onTap: () {
        if (router.location != '/guide/userGuide') {
          router.go('/guide/userGuide');
          //router.pop();
        }
      },
    ),
  ];



  /// Footer Item 리스트
  final List<NavigationPaneItem> footerItems = [
    PaneItemSeparator(),
    PaneItem(
      key: const Key('/privateInfo'),
      icon: const Icon(FluentIcons.settings),
      title: const Text('개인정보변경', style: naviItemTextStyle),
      body: const SizedBox.shrink(),
      onTap: () {
        if (router.location != '/privateInfo') {
          router.go('/privateInfo');
        }
      },
    ),
    // PaneItem(
    //   key: const Key('/settings'),
    //   icon: const Icon(FluentIcons.settings),
    //   title: const Text('개인정보변경', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
    //   body: const SizedBox.shrink(),
    //   onTap: () {
    //     if (router.location != '/settings') {
    //       router.go('settings');
    //       //router.pop();
    //     }
    //   },
    // ),
  ];

  bool isMetric = true;
  bool isImperial = false;
  late List<bool> isSelected;

  void bindingMultiShopListInfo() async {
    await AuthService().userStorage.write(key: 'key', value: '');

    //Get.offAllNamed('/login');
  }

  @override
  void initState() {
    super.initState();

    debugPrint('initState layoutMain');
    Get.put(ShopController());

    isSelected = [isMetric, isImperial];

    baseNaviItem = deliverylItems;

    // if (AppUseState.currentShopMode == AppUseState.MODE_FOOD) {
    //   baseNaviItem = foodNaviItems;
    // }
    // else if (AppUseState.currentShopMode == AppUseState.MODE_FLOWER) {
    //   baseNaviItem = flowerNaviItems;
    // }
    //
    // baseNaviItem.forEach((element) {
    //   debugPrint('key: ${element.key}');
    // });

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    baseNaviItem.clear();
    debugPrint('dispose layoutMain');

    deliverylItems.clear();
    footerItems.clear();

    menuFocusNode.dispose();

    searchController.dispose();
    searchFocusNode.dispose();
    super.dispose();
  }

  int _calculateSelectedIndex(BuildContext context) {
    final location = router.location;
    int indexOriginal = baseNaviItem.where((element) => element.key != null).toList().indexWhere((element) => element.key == Key(location));

    if (indexOriginal == -1) {
      int indexFooter = footerItems.where((element) => element.key != null).toList().indexWhere((element) => element.key == Key(location));
      if (indexFooter == -1) {
        return 0;
      }

      return baseNaviItem.where((element) => element.key != null).toList().length + indexFooter;
    }
    else {
      return indexOriginal;
    }
  }

  @override
  Widget build(BuildContext context) {
    //final localizations = FluentLocalizations.of(context);
    final appTheme = context.watch<AppTheme>();
    //final theme = FluentTheme.of(context);

    //print('appTheme.displayMode:${appTheme.displayMode}');

    //appTheme.currentShopStatusGbn = AuthService.ShopStatus;

    //debugPrint('appTheme.currentShopStatusGbn:${AuthService.ShopStatus.toString()}');

    if (widget.shellContext != null) {
      if (router.canPop() == false) {
        setState(() {});
      }
    }

    return NavigationView(
      key: viewKey,
      appBar: NavigationAppBar(
        height: 60,
        automaticallyImplyLeading: false,
        // leading: () {
        //   final enabled = widget.shellContext != null && router.canPop();
        //   final onPressed = enabled
        //       ? () {
        //     if (router.canPop()) {
        //       context.pop();
        //       setState(() {});
        //     }
        //   }
        //       : null;
        //   return NavigationPaneTheme(
        //     data: NavigationPaneTheme.of(context).merge(NavigationPaneThemeData(
        //       unselectedIconColor: ButtonState.resolveWith((states) {
        //         if (states.isDisabled) {
        //           return ButtonThemeData.buttonColor(context, states);
        //         }
        //         return ButtonThemeData.uncheckedInputColor(FluentTheme.of(context), states,).basedOnLuminance();
        //       }),
        //     )),
        //     child: Builder(
        //       builder: (context) => PaneItem(
        //         icon: const Center(child: Icon(FluentIcons.back, size: 14.0)),
        //         title: Text("Back"),
        //         body: const SizedBox.shrink(),
        //         enabled: enabled,
        //       ).build(context, false, onPressed, displayMode: PaneDisplayMode.compact,),
        //     ),
        //   );
        // }(),
        title: () {
          return GestureDetector(
            onTap: () {

              // if (widget.shellContext != null && router.canPop()){
              //   if (router.canPop()) {
              //     context.pop();
              //     setState(() {});
              //   }
              // }

              if (router.location != '/') router.go('/');
            },
            child: const SizedBox(height: 50, child: Image(image: AssetImage('images/img_aside_logo.png')),),
          );
        }(),
        actions: SizedBox(
          height: 60,
          child: Responsive.isMobile(context) == true ? const SizedBox.shrink() : Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children:  [
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsetsDirectional.only(start: naviPaneOpenWidth+8),
                      child: GestureDetector(
                        child: Container(
                            alignment: Alignment.center,
                            //padding: const EdgeInsets.symmetric(horizontal: 10),
                            height: 40,
                            width: 120,
                            decoration: BoxDecoration(
                                color: appTheme.currentShopStatusGbn == 'Y' ? const material.Color(0xff01CAFF) : material.Colors.grey,
                                borderRadius: BorderRadius.circular(10)
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(appTheme.currentShopStatusGbn == 'Y' ? '영업중' : '휴무중', style: const TextStyle(color: material.Colors.white, fontSize: 22, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON),),
                                const SizedBox(width: 8,),
                                Icon(appTheme.currentShopStatusGbn == 'Y' ? material.Icons.wb_sunny_outlined : material.Icons.cloud_outlined, color: material.Colors.white, size: 22,)
                              ],
                            )
                        ),
                        onTap: () {
                          showDialog(
                            context: context,
                            barrierDismissible: true,
                            builder: (context) => const ShopStatusEdit(),
                          );
                        }
                      ),
                    ),
                    const SizedBox(width: 10),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Row(
                        children: [
                          material.Material(
                            child: ISSearchDropdown(
                              width: 250,
                              label: '',
                              value: selMultiShop,
                              onChange: (value) {
                                if(selMultiShop == value) {
                                  return;
                                }

                                selMultiShop = value;
                                _requestMoveAPIData(value).then((v) {
                                  if(v.toString() == '00'){
                                    // 멀티샵 여부 체크 검증
                                    var tt = selectMultiShopList.where((element) => element.value == value);
                                    final str2 = utf8.decode(base64.decode(tt.first.pass.toString()));

                                    setLogin(tt.first.value.toString(), tt.first.id.toString(), str2, context, appTheme);
                                  }
                                });},
                              item: selectMultiShopList,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 8.0),
                  //child: Text('안녕하세요 XXX 사장님', style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY_NEXON),),
                  child: material.TextButton(
                    style: material.ButtonStyle(
                      animationDuration: const Duration(microseconds: 100),
                      overlayColor: material.MaterialStateProperty.resolveWith<Color>((Set<material.MaterialState> states) => Colors.transparent),
                      foregroundColor: material.MaterialStateProperty.resolveWith<Color>(
                              (Set<material.MaterialState> states) {
                            if (states.contains(material.MaterialState.hovered)) {
                              return const Color(0xff01CAFF);
                            }
                            return Colors.black;//Colors.white;
                          }),
                    ),
                    onPressed: () {
                      Utils.launchURL('https://m.daeguromall.com');
                    },
                    child: const Text('> 대구로몰 이동하기', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
                  ),
                ),
              ]),
        ),
      ),
      transitionBuilder: (child, animation) {
        return SuppressPageTransition(
          //animation: animation,
          child: child,
        );
      },
      pane: NavigationPane(
        size: const NavigationPaneSize(openWidth: naviPaneOpenWidth, compactWidth: naviPaneCompactWidth),
        selected: _calculateSelectedIndex(context),
        displayMode: PaneDisplayMode.auto,
        items: baseNaviItem,
        menuButton: Container(
          //color: Colors.yellow,
          width: double.infinity,
          alignment: Alignment.center,
          child: Column(
            children: [
              const Divider(),
              material.ToggleButtons(
                //constraints: BoxConstraints(maxWidth: Responsive.isMobile(context) ? naviPaneCompactWidth : naviPaneOpenWidth, maxHeight: 160),
                isSelected: isSelected,
                onPressed: (v) {
                  if (v == 0) {
                    isMetric = true;
                    isImperial = false;
                  } else {
                    isMetric = false;
                    isImperial = true;
                  }

                  setState(() {
                    isSelected = [isMetric, isImperial];
                  });

                  if (isImperial == true) {
                    baseNaviItem = reserveItems;
                    AuthService.ShopMode = AuthService.SHOPMODE_RESERVE;

                    router.go('/reserve/info');
                  }
                  else {
                    baseNaviItem = deliverylItems;
                    AuthService.ShopMode = AuthService.SHOPMODE_DELIVERY;

                    router.go('/');
                  }
                },
                borderColor: Colors.transparent,//Colors.black,
                fillColor: const Color(0xff01CAFF),//Colors.grey,
                borderWidth: 2,
                selectedBorderColor: Colors.transparent,//Colors.black,
                selectedColor: Colors.white,
                borderRadius: BorderRadius.circular(0),
                children: [

                  Container(
                    width: (naviPaneOpenWidth/2)-3,
                    height: 32,
                    alignment: Alignment.center,
                    child: const Text('배달/포장', style: TextStyle(fontSize: 18,  fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                  ),
                  Container(
                    width: naviPaneOpenWidth/2-3,
                    height: 32,
                    alignment: Alignment.center,
                    child: const Text('예약', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
                  ),
                ],
              ),
              const Divider(),
            ],
          ),
        ),
        // header: GestureDetector(
        //   onTap: () {
        //     if (router.location != '/') router.go('home');
        //   },
        //   child: SizedBox(
        //     height: 70,
        //     child: Image.asset('assets/img_aside_logo.png'),
        //   ),
        // ),
        // indicator: () {
        //   switch (appTheme.indicator) {
        //     case NavigationIndicators.end:
        //       return const EndNavigationIndicator();
        //     case NavigationIndicators.sticky:
        //     default:
        //       return const StickyNavigationIndicator();
        //   }
        // }(),
        autoSuggestBox: AutoSuggestBox(
          key: searchKey,
          focusNode: searchFocusNode,
          controller: searchController,
          unfocusedColor: Colors.transparent,
          items: baseNaviItem.whereType<PaneItem>().map((item) {
            assert(item.title is Text);
            final text = (item.title as Text).data!;
            return AutoSuggestBoxItem(
              label: text,
              value: text,
              onSelected: () {
                item.onTap?.call();
                searchController.clear();
              },
            );
          }).toList(),
          trailingIcon: IgnorePointer(
            child: IconButton(
              onPressed: () {},
              icon: const Icon(FluentIcons.search),
            ),
          ),
          placeholder: '검색',
        ),
        autoSuggestBoxReplacement: const Icon(FluentIcons.search),
        footerItems: footerItems,
      ),
      paneBodyBuilder: (item, child) {
        final name = item?.key is ValueKey ? (item!.key as ValueKey).value : null;

        return FocusTraversalGroup(
          key: ValueKey('body$name'),
          child: widget.child,//Container(color: Colors.teal, child: widget.child),//컨텐츠 영역
        );
      },
      onOpenSearch: () {
        searchFocusNode.requestFocus();
      },
    );
  }

  setLogin(String shopCd, String id, String pass, BuildContext context, AppTheme appTheme) async {
    await LoginController.to.connectedlogIn(shopcd: shopCd, loginid: id, loginpass: pass).then((value) {
      if (value == '') {
        ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
        //Navigator.of(context).pop;
      }
      else{
        String code = value.toString().split('|').first;
        String msg = value.toString().split('|').last;

        if (code == '00') {
          appTheme.currentShopStatusGbn = AuthService.ShopStatus;
          appTheme.ShopRefresh = true;
        }
        else{
          ISAlert(context, content: '멀티샵 변경 실패\n→ ${msg} ');
        }
      }
    });
  }
}

class _NavigationBodyItem extends StatelessWidget {
  const _NavigationBodyItem({
    this.header,
    this.content,
  });

  final String? header;
  final Widget? content;

  @override
  Widget build(BuildContext context) {
    return ScaffoldPage.withPadding(
      header: PageHeader(title: Text(header ?? 'This is a header text')),
      content: content ?? const SizedBox.shrink(),
    );
  }
}