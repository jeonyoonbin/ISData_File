
import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:flutter/material.dart';

class Responsive extends StatelessWidget {
  final Widget? mobile;
  final Widget? tablet;
  final Widget? desktop;

  const Responsive({Key? key, this.mobile, this.tablet, this.desktop,}) : super(key: key);

  //default : 1100
  static bool isMobile(BuildContext context) => MediaQuery.of(context).size.width <= 640;
  static bool isTablet(BuildContext context) => MediaQuery.of(context).size.width < 1008 && MediaQuery.of(context).size.width > 640;
  static bool isDesktop(BuildContext context) => MediaQuery.of(context).size.width >= 1008;

  /*
  if (width <= 640) {
          _autoDisplayMode = PaneDisplayMode.top;//PaneDisplayMode.minimal;
        } else if (width >= 1008) {
          _autoDisplayMode = PaneDisplayMode.open;
        } else if (width > 640) {
          _autoDisplayMode = PaneDisplayMode.compact;
        }
   */

  @override
  Widget build(BuildContext context) {
    final Size _size = MediaQuery.of(context).size;

    if (_size.width >= 1008) {
      return desktop!;
    }
    else if (_size.width >= 640 && tablet != null) {
      return tablet!;
    }
    else {
      return mobile!;
    }
  }

  static getResponsiveWidth(BuildContext context, {int? mobileInfiniteWidth}){
    double retValue = 0.0;

    double addWidthMargin = 48;//defaultWidthPadding*2;

    if (isMobile(context))           retValue = MediaQuery.of(context).size.width;
    else if (isTablet(context))      retValue = MediaQuery.of(context).size.width - 100;
    else                             retValue = MediaQuery.of(context).size.width-(naviPaneOpenWidth+addWidthMargin);

    return retValue;

    //return (isTablet(context) || isMobile(context)) ? MediaQuery.of(context).size.width : MediaQuery.of(context).size.width-(naviPaneOpenWidth+addWidthMargin);

    // return isTablet(context) ? MediaQuery.of(context).size.width//-addWidthMargin
    //     : (isMobile(context) ? MediaQuery.of(context).size.width : MediaQuery.of(context).size.width-(naviPaneOpenWidth+addWidthMargin));
  }
}
