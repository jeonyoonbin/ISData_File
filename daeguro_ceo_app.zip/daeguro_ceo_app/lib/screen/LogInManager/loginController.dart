import 'dart:convert';
import 'package:daeguro_ceo_app/common/js_function.dart';
import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListModel.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListRequestModel.dart';
import 'package:daeguro_ceo_app/models/loginLinkToModel.dart';
import 'package:daeguro_ceo_app/models/loginModel.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:encrypt/encrypt.dart' as EncryptPack;
import 'package:crypto/crypto.dart' as CryptoPack;

// import 'dart:html'; // apk 빌드 시 주석 처리

enum RadioRequireGbn { requireFood, requireFlower }

class LoginController extends GetxController {
  static LoginController get to => Get.find();

  final ScrollController scrollController = ScrollController();
  final TextEditingController idTextController = TextEditingController();

  late String loginID = '';
  late String loginPW = '';

  //late String code;
  //late String message;

  bool submitError1 = false;
  bool submitError2 = false;

  bool isIdSaved = false;

  late RadioRequireGbn radioRequireGbn = RadioRequireGbn.requireFood;

  final _dio = Dio(
    BaseOptions(
      //baseUrl: ServerInfo.jobMode == 'dev' ? ServerInfo.REST_TESTURL : ServerInfo.REST_BASEURL,
      baseUrl: ServerInfo.jobMode == 'dev' ? 'https://dgpub.282.co.kr:8501' : 'https://ceoflower.daeguro.co.kr',
      connectTimeout: const Duration(milliseconds: 5000),
      receiveTimeout: const Duration(milliseconds: 5000),
      sendTimeout: const Duration(milliseconds: 5000),
    ),
  );

  LoginController() {
    // checkIP();
  }

  // 아래 onReady() 함수 apk 빌드 시 주석 처리
  @override
  void onReady() {
    pwaGuide();
    // if (GetPlatform.isIOS &&
    //     !window.matchMedia('(display-mode: standalone)').matches) {
    //   AuthService.to.userStorage.read(key: '@pwaGuideOff').then(
    //         (value) => value != ServerInfo.APP_VERSION
    //             ? {
    //                 Future.delayed(const Duration(milliseconds: 700))
    //                     .then((value) => iosPwaGuidePopup())
    //               }
    //             : null,
    //       );
    // } else if (GetPlatform.isAndroid &&
    //     !window.matchMedia('(display-mode: standalone)').matches) {
    //   AuthService.to.userStorage.read(key: '@pwaGuideOff').then(
    //         (value) => value != ServerInfo.APP_VERSION
    //             ? {
    //                 Future.delayed(const Duration(milliseconds: 700))
    //                     .then((value) => androidPwaGuidePopup())
    //               }
    //             : null,
    //       );
    // }
    super.onReady();
  }

  Future keyboardVisible() async {
    keyboardVisibleFunction(scrollController);
  }

  // void checkIP() async {
  //   await AuthService.to.userStorage.read(key: '@clientIP').then((value) =>
  //       value == 'fail' || value == null
  //           ? Get.offAllNamed('/failGetIP')
  //           : null);
  // }

  // 아래 keyboardVisible() 함수는 apk web 구분되어있음 apk 빌드 시 web용함수 주석 처리
  // <WEB용 함수>
  // Future keyboardVisible() async {
  //   if (GetPlatform.isIOS &&
  //       !window.matchMedia('(display-mode: standalone)').matches) {
  //     Future.delayed(const Duration(milliseconds: 500)).then((value) =>
  //         scrollController.animateTo(180,
  //             duration: const Duration(milliseconds: 100),
  //             curve: Curves.easeIn));
  //   } else {
  //     Future.delayed(const Duration(milliseconds: 330)).then((value) =>
  //         scrollController.animateTo(180,
  //             duration: const Duration(milliseconds: 100),
  //             curve: Curves.easeIn));
  //   }
  // }

  // web 빌드 시 web용 함수 주석해제 apk용 함수 주석처리
  // <APK용 함수>
  // Future keyboardVisible() async {
  //   Future.delayed(const Duration(milliseconds: 330)).then((value) =>
  //       scrollController.animateTo(180,
  //           duration: const Duration(milliseconds: 100), curve: Curves.easeIn));
  // }

  @override
  void onInit() {
    //print('LoginController onInit()');
    AuthService().userStorage.read(key: '@saveID').then((value) {
      if (value != null) {
        idTextController.text = value;
        //debugPrint('onInit() text:${idTextController.text}');
        loginID = value;
        isIdSaved = true;
        update();
      }
      else {
        idTextController.text = '';
        loginID = '';
        isIdSaved = false;
        update();
      }
    });
    super.onInit();
  }

  // saveID() {}

  // androidPwaGuidePopup() {
  //   Get.dialog(Dialog(
  //     insetPadding: EdgeInsets.zero,
  //     alignment: Alignment.topCenter,
  //     child: Container(
  //       color: const Color(0xff01CAFF),
  //       height: 400,
  //       width: Get.width,
  //       padding: const EdgeInsets.all(20),
  //       child: Center(
  //           child: Column(
  //         crossAxisAlignment: CrossAxisAlignment.center,
  //         mainAxisAlignment: MainAxisAlignment.center,
  //         children: [
  //           const Text('<크롬 브라우저>', style: TextStyle(fontFamily: 'NotoSansKR', fontWeight: FontWeight.bold, fontSize: 19, color: Color(0xffFFFFFF),),),
  //           const Wrap(
  //             alignment: WrapAlignment.center,
  //             children: [
  //               Icon(Icons.more_vert, color: Color(0xffFFFFFF),),
  //               Text('을 누른 후', style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 18, color: Color(0xffFFFFFF),),),
  //               Icon(Icons.add_to_home_screen, color: Color(0xffFFFFFF),),
  //               Text('\'앱 설치\'를 눌러 앱을', style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 18, color: Color(0xffFFFFFF),),),
  //               Text('설치하세요', style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 18, color: Color(0xffFFFFFF),),),
  //             ],
  //           ),
  //           const Divider(),
  //           const Text('<삼성 인터넷 브라우저>', style: TextStyle(fontFamily: 'NotoSansKR', fontWeight: FontWeight.bold, fontSize: 19, color: Color(0xffFFFFFF),),),
  //           const Wrap(
  //             alignment: WrapAlignment.center,
  //             children: [
  //               Text('상단 주소창 우측', style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 18, color: Color(0xffFFFFFF),),),
  //               Icon(Icons.arrow_circle_down, color: Color(0xffFFFFFF),),
  //               Text('을 눌러 앱을', style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 18, color: Color(0xffFFFFFF),),),
  //               Text('설치하세요', style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 18, color: Color(0xffFFFFFF),),),
  //             ],
  //           ),
  //           const Divider(),
  //           const SizedBox(
  //             height: 90,
  //             child: Text('최적의 사용자 경험을 위해 앱을 설치해 주세요\n앱을 설치하면 앱 아이콘이 생성되고 일반 앱과 같이 사용할 수 있습니다',
  //               textAlign: TextAlign.center,
  //               style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 16, color: Color(0xffFFFFFF),),
  //             ),
  //           ),
  //           Container(
  //             margin: const EdgeInsets.only(top: 15, bottom: 5),
  //             height: 30,
  //             child: ElevatedButton(
  //               style: TextButton.styleFrom(
  //                   backgroundColor: const Color.fromARGB(255, 95, 153, 198)),
  //               child: const Text("다시 표시 안함", style: TextStyle(fontFamily: 'NotoSansKR', fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xffFFFFFF)),),
  //               onPressed: () {
  //                 AuthService.to.userStorage.write(key: '@pwaGuideOff', value: ServerInfo.APP_VERSION).then((value) => Get.back());
  //               },
  //             ),
  //           ),
  //         ],
  //       )),
  //     ),
  //   ));
  // }
  //
  // iosPwaGuidePopup() {
  //   Get.bottomSheet(Container(
  //     color: const Color(0xff01CAFF),
  //     height: 400,
  //     width: Get.width,
  //     padding: const EdgeInsets.all(20),
  //     child: Center(
  //         child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.center,
  //       mainAxisAlignment: MainAxisAlignment.center,
  //       children: [
  //         const Row(
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           crossAxisAlignment: CrossAxisAlignment.center,
  //           children: [
  //             Icon(Icons.ios_share, color: Color(0xffFFFFFF),),
  //             Text(' 을 누른 후 \'홈 화면에 추가\'를', style: TextStyle(fontFamily: 'NotoSansKR', fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xffFFFFFF),),
  //             ),
  //           ],
  //         ),
  //         const Text('눌러 앱을 설치하세요', style: TextStyle(fontFamily: 'NotoSansKR', fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xffFFFFFF),),),
  //         const Text('<Safari(사파리) 브라우저에서 지원>', style: TextStyle(fontFamily: 'NotoSansKR', fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xffFFFFFF),),),
  //         const Divider(),
  //         // Wrap(
  //         //   alignment: WrapAlignment.center,
  //         //   children: const [
  //         const SizedBox(
  //           height: 90,
  //           child: Text('최적의 사용자 경험을 위해 앱을 설치해 주세요\n앱을 설치하면 홈 화면에 앱 아이콘이 생성되고 일반 앱과 같이 사용할 수 있습니다',
  //             textAlign: TextAlign.center,
  //             style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 16, color: Color(0xffFFFFFF),),
  //           ),
  //         ),
  //         Container(
  //           margin: const EdgeInsets.symmetric(vertical: 5),
  //           height: 30,
  //           width: Get.width - 40,
  //           child: ElevatedButton(
  //             style: TextButton.styleFrom(
  //                 backgroundColor: const Color.fromARGB(255, 95, 153, 198)),
  //             child: const Text("다시 표시 안함", style: TextStyle(fontFamily: 'NotoSansKR', fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xffFFFFFF)),),
  //             onPressed: () {
  //               AuthService.to.userStorage.write(key: '@pwaGuideOff', value: ServerInfo.APP_VERSION).then((value) => Get.back());
  //               // Get.back();
  //             },
  //           ),
  //         ),
  //       ],
  //     )),
  //   ));
  // }

  Future<String> getLoginData(String encryptPassword, {String shopcd = '', String loginid = '', String loginpass = ''}) async {
    String retValue = '';

    LoginModel sendData = LoginModel();
    if(loginid != '' && loginpass != '') {  // 멀티샵 선택시 멀티샵 간 로그인으로 설정
        sendData.jobGbn = '4';
        sendData.shopCd = shopcd;
        sendData.id = loginID;
        sendData.pwd = encryptPassword.toString();
        sendData.key = 'dlstjdepdlxj!23212';
      } else {
        sendData.jobGbn = '1';
        sendData.shopCd = '';
        sendData.id = loginID;
        sendData.pwd = encryptPassword.toString();
        sendData.key = '1';
      }

    final Dio _dio = Dio(
      BaseOptions(
        baseUrl: ServerInfo.jobMode == 'dev' ?  ServerInfo.REST_BASEURL_DEV : ServerInfo.REST_BASEURL_REAL,
        connectTimeout: const Duration(milliseconds: 5000),
        receiveTimeout: const Duration(milliseconds: 5000),
        sendTimeout: const Duration(milliseconds: 5000),
      ),
    );

    var res = await _dio.post(ServerInfo.RESTURL_LOGIN, data: sendData.toJson());
    _dio.close();

    debugPrint('login response: ${res.toString()}');

    if (res.data['code'] == '00') {
      dynamic qData = res.data['data'];

      AuthService.SHOPCD = qData['shopCd'] as String;
      AuthService.SHOPNAME = qData['shopName'] as String;
      AuthService.ShopStatus = qData['absentYn'] as String;
      AuthService.ShopServiceGbn = qData['serviceGbn'] as String;
      AuthService.ShopType = qData['shopType'] as String;
      AuthService.MultiShopYn = qData['multiShopYn'] as String;
      AuthService.MultiShopCd = qData['multiShopCd'] as String;
      AuthService.RepYn = qData['repYn'] as String;
      AuthService.GoodShopYn = qData['goodShopYn'] as String;

      AuthService.to.login(loginID, res.data['token']);

      loginID = '';
      loginPW = '';

      retValue = '${res.data['code']}|${res.data['msg']}';
    }
    else {
      debugPrint('login error: ${res.data['msg']}');

      retValue = '${res.data['code']}|${res.data['msg']}';
    }

    return retValue;
  }

  Future<String> getNoticeList() async {
    String retValue = '';

    NoticeListRequestModel requestData = NoticeListRequestModel();
    requestData.jobGbn = '11';
    requestData.osGbn = '11';
    requestData.noticeGbn = '4';
    requestData.dispGbn = 'Y';
    requestData.frDate = '';
    requestData.toDate = '';
    requestData.rows = '999';
    requestData.page = '1';

    var res = await DioClient().post('${ServerInfo.RESTURL_NOTICELIST}', data: requestData.toJson());

    if (res.data['code'] == '00') {
      List<String> imgBannerList = [];

      List<dynamic> qData = [];
      qData.assignAll(res.data['data']);
      qData.forEach((element) {
        NoticeListModel temp = NoticeListModel();
        temp.noticeSeq = element['noticeSeq'] as String;
        temp.noticeGbn = element['noticeGbn'] as String;
        temp.dispGbn = element['dispGbn'] as String;
        temp.dispFrDate = element['dispFrDate'] as String;
        temp.dispToDate = element['dispToDate'] as String;
        temp.noticeTitle = element['noticeTitle'] as String;
        temp.noticeContents = element['noticeContents'] as String;
        temp.noticeUrl1 = element['noticeUrl1'] as String;
        temp.noticeUrl2 = element['noticeUrl2'] as String;
        temp.noticeUrl3 = element['noticeUrl3'] as String;
        temp.orderDate = element['orderDate'] as String;
        temp.insDate = element['insDate'] as String;
        temp.sortSeq = element['sortSeq'] as String;
        temp.extUrlYn = element['extUrlYn'] as String;

        imgBannerList.add(temp.noticeUrl1!);
      });
      AuthService.bannerImageList = imgBannerList;

      retValue = '${res.data['code']}|${res.data['msg']}';
    }
    else {
      debugPrint('login Notice error: ${res.data['msg']}');

      retValue = '${res.data['code']}|${res.data['msg']}';
    }

    return retValue;
  }

  Future<String> connectedlogIn({String shopcd = '', String loginid = '', String loginpass = ''}) async {
    // id, pass 넘겨받을경우 해당값 적용(멀티샵 로그인에 사용)
    if(loginid != '' && loginpass != '') {
      loginID = loginid;
      loginPW = loginpass;
    } else {
      if (AuthService.to.isLoggedIn == true || loginID == '' || loginPW == '') {
        return '';
      }
    }
    debugPrint('------ connectedlogIn call');
    //message = '';

    var password = utf8.encode(loginPW);
    var encryptPassword = CryptoPack.sha256.convert(password);

    debugPrint('encryptPassword:${encryptPassword}');
    debugPrint('isIdSaved:${isIdSaved}');

    (isIdSaved == false) ? await AuthService().userStorage.delete(key: '@saveID') : await AuthService().userStorage.write(key: '@saveID', value: loginID);

    try {
      String retValue;
      if(loginid != '' && loginpass != '') {
        retValue = await getLoginData(encryptPassword.toString(), shopcd: shopcd, loginid: loginid, loginpass: loginpass);
      }
      else {
        retValue = await getLoginData(encryptPassword.toString());
      }

      String code = retValue.split('|').first;
      String msg = retValue.split('|').last;

      if (code != '00') {
        submitError1 = true;
        update();
        return '${code}|${msg}';
      }

      retValue = await getNoticeList();
      code = retValue.split('|').first;
      msg = retValue.split('|').last;

      if (code != '00') {
        submitError1 = true;
        update();
        return '${code}|${msg}';
      }
    }
    catch (e) {
      debugPrint(e.toString());

      submitError1 = true;
      update();
      return '99|정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다.';
    }

    update();

    return '00|성공';
  }

  Future<String> linkTologIn() async {
    debugPrint('------ linkTologIn call');

    try {
      NoticeListRequestModel requestData = NoticeListRequestModel();
      requestData.jobGbn = '11';
      requestData.osGbn = '11';
      requestData.noticeGbn = '4';
      requestData.dispGbn = 'Y';
      requestData.frDate = '';
      requestData.toDate = '';
      requestData.rows = '999';
      requestData.page = '1';

      var resBanner = await DioClient().post('${ServerInfo.RESTURL_NOTICELIST}', data: requestData.toJson());

      if (resBanner.data['code'] == '00') {
        List<String> imgBannerList = [];

        List<dynamic> qData = [];
        qData.assignAll(resBanner.data['data']);
        qData.forEach((element) {
          NoticeListModel temp = NoticeListModel();
          temp.noticeSeq = element['noticeSeq'] as String;
          temp.noticeGbn = element['noticeGbn'] as String;
          temp.dispGbn = element['dispGbn'] as String;
          temp.dispFrDate = element['dispFrDate'] as String;
          temp.dispToDate = element['dispToDate'] as String;
          temp.noticeTitle = element['noticeTitle'] as String;
          temp.noticeContents = element['noticeContents'] as String;
          temp.noticeUrl1 = element['noticeUrl1'] as String;
          temp.noticeUrl2 = element['noticeUrl2'] as String;
          temp.noticeUrl3 = element['noticeUrl3'] as String;
          temp.orderDate = element['orderDate'] as String;
          temp.insDate = element['insDate'] as String;
          temp.sortSeq = element['sortSeq'] as String;
          temp.extUrlYn = element['extUrlYn'] as String;

          imgBannerList.add(temp.noticeUrl1!);
        });
        AuthService.bannerImageList = imgBannerList;
      }
      else {
      }
      ///////////////////////////////////////////////////////////////////
      LoginLinkToModel sendData = LoginLinkToModel();
      sendData.jobGbn = '1';
      sendData.mappType = AuthService.linkToModel!.type;
      sendData.mappGbn = AuthService.linkToModel!.mapp;
      sendData.mappCode = AuthService.linkToModel!.code;

      var res = await DioClient().post(ServerInfo.RESTURL_LOGIN_LINKTO, data: sendData.toJson());
      //_dio.close();

      debugPrint('linkTologIn response: ${res.toString()}');

      if (res.data['code'] == '00') {
        dynamic qData = res.data['data'];

        AuthService.SHOPCD = qData['shopCd'] as String;
        AuthService.SHOPNAME = qData['shopName'] as String;
        AuthService.ShopStatus = qData['absentYn'] as String;
        AuthService.ShopServiceGbn = qData['serviceGbn'] as String;

        AppTheme().currentShopStatusGbn = AuthService.ShopStatus;

        AuthService.to.login(loginID, res.data['token']);
        loginID = '';
        loginPW = '';

        return '${res.data['code']}|${res.data['msg']}';
      }
      else {
        debugPrint(res.data['msg']);
        submitError1 = true;

        return '${res.data['code']}|${res.data['msg']}';
      }
    }
    catch (e) {
      debugPrint(e.toString());
      update();

      return '';
    }

    debugPrint('error check3333');
    update();

    return '';
  }
}
