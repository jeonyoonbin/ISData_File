import 'package:flutter/material.dart';

class UserNotifier extends ChangeNotifier {
  // User? _user;//User Model
  //
  // User? get user => _user;

  UserNotifier() {
    initStatus();
  }

  void initStatus(){
    // FirebaseAuth.instance.authStateChanges().listen((User? user) async {
    //   await _serUser(user);
    //   notifyListeners();
    // });
  }
}