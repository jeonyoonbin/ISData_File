import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/models/ReviewManager/reviewBlindRequestModel.dart';
import 'package:daeguro_ceo_app/screen/ReviewManager/reviewManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ReviewBlindRequest extends StatefulWidget {
  final String? orderNo;

  const ReviewBlindRequest({Key? key, this.orderNo}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ReviewBlindRequestState();
  }
}

class ReviewBlindRequestState extends State<ReviewBlindRequest> {
  //String? selectedValue = '%';

  List<ISOptionModel> blindTypeList = <ISOptionModel>[];

  ReviewBlindRequestModel formData = ReviewBlindRequestModel();

  requestBlindTypeData() async {
    var value = await showDialog(context: context, barrierColor: Colors.transparent,builder: (context) => FutureProgressDialog(ReviewController.to.getReviewBlindType()));

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      //Navigator.of(context).pop;
    } else {
      blindTypeList.add(ISOptionModel(value: '%', label: '분류를 선택해 주세요.'));
      value.forEach((element) {
        blindTypeList.add(ISOptionModel(value: element['blindCode'].toString(), label: element['blindReason'].toString()));
      });
    }

    formData.blindCode = '%';

    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    blindTypeList.clear();
    formData = ReviewBlindRequestModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReviewController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestBlindTypeData();
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 460, maxHeight: 630),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text(
            '리뷰 블라인드 요청',
            style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),
          ),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: ScrollConfiguration(
        behavior: ScrollConfiguration.of(context).copyWith(scrollbars: false),
        child: SingleChildScrollView(
          child: Material(
            color: Colors.transparent,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12),
                const Text('분류', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                const SizedBox(height: 8),
                ISSearchDropdown(
                  width: 250,
                  label: '분류를 선택해 주세요.',
                  value: formData.blindCode,
                  onChange: (value) {
                    setState(() {
                      formData.blindCode = value;
                    });
                  },
                  item: blindTypeList,
                ),
                const SizedBox(height: 8),
                const Text('사유', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                const SizedBox(height: 8),
                ISInput(
                  value: formData.blindReason,
                  context: context,
                  height: 200,
                  label: '최대 500자까지 입력 가능',
                  keyboardType: TextInputType.multiline,
                  maxLines: 20,
                  maxLength: 500,
                  onChange: (v) {
                    formData.blindReason = v;
                  },
                ),
                const SizedBox(height: 16),
                const Column(
                  children: [
                    Text(
                        '· 운영사의 승인 시 평점도 함께 30일간 블라인드 임시 조치됩니다.\n· 운영사의 승인 시 고객에게 해당 리뷰에 대한 블라인드 안내톡이 전송됩니다.\n· 30일 이내에 운영사는 고객에게 리뷰 삭제에 대한 동의여부를 확인합니다.\n· 고객이 리뷰 삭제 동의 시, 해당 리뷰는 블라인드 조치 후 영구 삭제됩니다.\n단, 리뷰 삭제 미동의 시 블라인드 조치 후 앱에 재 게시됩니다.\n·전자상거래법 소비자보호 지침에 따라 고객의 동의 없이 사업자에게 불리한 이용 후기를 임의로 삭제 할 수 없습니다.\n· 1개의 리뷰당 1회만 요청 가능합니다.',
                        style: TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                    const SizedBox(height: 16),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (formData.blindCode == '%' || formData.blindCode == '') {
                ISAlert(context, content: '분류 구분을 선택해주세요.');
                return;
              }

              if (formData.blindReason == null || formData.blindReason == '') {
                ISAlert(context, content: '사유가 존재하지않습니다.\n 작성 후 다시 눌러주세요.');
                return;
              }

              ISConfirm(context, '리뷰 블라인드 요청', '해당 리뷰를 블라인드 요청 하시겠습니까?', (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK) {
                  ReviewBlindRequestModel sendData = ReviewBlindRequestModel();
                  sendData.shop_cd = AuthService.SHOPCD;
                  sendData.modUcode = AuthService.uCode;
                  sendData.modUName = AuthService.uName;
                  sendData.job_gbn = "1";
                  sendData.visibleGbn = "R"; // r-> 요청 , c -> 취소
                  sendData.blindEndDt = formatDate(DateTime.now(), [yyyy, mm, dd]);
                  sendData.blindCode = formData.blindCode;
                  sendData.blindReason = formData.blindReason;
                  sendData.orderNo = widget.orderNo;

                  var value = await showDialog(context: context, barrierColor: Colors.transparent,builder: (context) => FutureProgressDialog(ReviewController.to.setReviewBlind(sendData.toJson())));

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                  } else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                      //requestAPIData();
                    } else {
                      ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: const Text('블라인드 요청', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}