import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopPaymentGbnEdit extends StatefulWidget {
  final ShopInfoModel? sData;
  const ShopPaymentGbnEdit({Key? key, this.sData})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopPaymentGbnEditState();
  }
}

class ShopPaymentGbnEditState extends State<ShopPaymentGbnEdit> {
  ShopInfoModel formData = ShopInfoModel();

  @override
  void dispose() {
    super.dispose();
    formData = ShopInfoModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    formData = widget.sData!;

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 260),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('결제 수단', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 12,),
              const Text('결제 수단', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
              const Text('결제 수단을 선택해주세요.', style: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
              const SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ISCheckbox(
                      label: '만나서 결제(현금)',
                      value: formData.meetToPay,
                      onChanged: (v) => setState(() => formData.meetToPay = v!)
                  ),
                  ISCheckbox(
                      label: '만나서 결제(카드)',
                      value: formData.meetToCard,
                      onChanged: (v) => setState(() => formData.meetToCard = v!)
                  ),
                ],
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              ISConfirm(context, '결제 수단 변경', '결제 수단 정보를 변경합니다. \n\n계속 진행 하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  List<String> sendDataParam = [];
                  if (formData.meetToPay == true)    sendDataParam.add('1');
                  if (formData.appType == true)      sendDataParam.add('3');
                  if (formData.meetToCard == true)   sendDataParam.add('5');

                  String sendData = sendDataParam.join(',');

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ShopController.to.updateShopInfo('3', sendData.toString(), '', ''))
                  );

                  if (value == '00') {
                    Navigator.of(context).pop(true);
                  }
                  else {
                    ISAlert(context, content: '정상 등록 되지 않았습니다.\n[관리자에게 문의 바랍니다]\n→ ${value}');
                  }
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


