import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:daeguro_ceo_app/network/DioReserveClient.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ShopController extends GetxController{
  static ShopController get to => Get.find();
  RxString ccCode = ''.obs;

  Future<dynamic> getShopInfo() async {
    dynamic qData;

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPINFO}?shop_cd=${AuthService.SHOPCD}&service_gbn=${AuthService.ShopServiceGbn}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateShopInfo(String jobGbn, String data1, String data2, String data3) async {

    final response = await DioClient().put('${ServerInfo.RESTURL_SHOPINFO_SET}?job_gbn=${jobGbn}&shop_cd=${AuthService.SHOPCD}&data_1=${data1}&data_2=${data2}&data_3=${data3}&mod_ucode=${AuthService.uCode}&mod_name=${AuthService.uName}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
  }
  }

  Future<dynamic> getOperateInfo() async {
    dynamic qData;

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPOPERATEINFO}?shop_cd=${AuthService.SHOPCD}&service_gbn=${AuthService.ShopServiceGbn}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateOperateInfo(dynamic data) async {

    final response = await DioClient().put(ServerInfo.RESTURL_SHOPOPERATEINFO_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
    }
  }

  Future<List<dynamic>?> getOperateHourInfo() async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPOPENINGHOURSINFO}?shop_cd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> deleteOperateHourInfo(String day, String tipSeq) async {

    final response = await DioClient().put('${ServerInfo.RESTURL_SHOPOPERATEHOURINFO_REMOVE}?shopCd=${AuthService.SHOPCD}&day=${day}&tipSeq=${tipSeq}&uCode=${AuthService.uCode}&uName=${AuthService.uName}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
  }
  }

  Future<List<dynamic>?> getOperateDeliInfo() async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPDELIINFO}?shop_cd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> setOperateDeliInfo(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_SHOPDELIINFO_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else {
      return response.data['code'];
  }
  }

  Future<dynamic> getRegistInfo() async {
    dynamic qData;

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPREGISTINFO}?shop_cd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateRegistInfo(dynamic data) async {

    final response = await DioClient().put(ServerInfo.RESTURL_SHOPREGISTINFO_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
  }
  }

  Future<List<dynamic>?> getShopIntroInfo(String intro_gbn) async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPINTROLIST}?shop_cd=${AuthService.SHOPCD}&intro_gbn=${intro_gbn}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getShopIntroDetailInfo(String intro_code) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPINTRODETAILINFO}?shop_cd=${AuthService.SHOPCD}&intro_code=${intro_code}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateShopIntroInfo(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_SHOPINTRO_SET, data: data);

    return '${response.data['code']}|${response.data['msg']}';
  }

  Future<List<dynamic>?> getShopInfoReserveTime(String shopCode) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_TIME}/$shopCode');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getShopInfoReserveCasePeople(String shopCode) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_CASEPEOPLE}?shopCode=$shopCode');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateReserveCasesPeople(dynamic data) async {

    final response = await DioReserveClient().put(ServerInfo.RESTURL_RESERVE_CASEPEOPLE, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else
      return response.data['code'];
  }

  Future<dynamic> setReserTime(dynamic data) async {
    final response = await DioReserveClient().post(ServerInfo.RESTURL_RESERVE_TIME, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<dynamic> setReserTimeCancel(dynamic data) async {
    final response = await DioReserveClient().post(ServerInfo.RESTURL_RESERVE_TIME_CANCEL, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<List<dynamic>?> getMultiShopListData(String multiShopCd) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_MULTISHOP_LIST}?multiShopCd=$multiShopCd');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getMultiShopCheck(String mvShopCd) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_MULTISHOP_CHECK}?mvShopCd=$mvShopCd');

    if (response.data['code'] == '00') {
      qData = response.data['code'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getShopInfoReserveManageInfo(String shopCode) async {
    dynamic qData;

    final response = await DioReserveClient().get('${ServerInfo.RESTURL_RESERVE_SHOPINFO_MANAGE}?shopCd=$shopCode');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }
    return qData;
  }


  Future<dynamic> updateReserveReviewUse(String shopCd, String ccCode, String reviewUseGbn, String userId) async {

    final response = await DioReserveClient().put(ServerInfo.RESTURL_RESERVE_REVIEW_USE + '?shopCd=$shopCd&ccCode=$ccCode&reviewUseGbn=$reviewUseGbn&userId=$userId');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
    }
  }

  Future<dynamic> updateReserveFacilities(dynamic data) async {

    final response = await DioReserveClient().post(ServerInfo.RESTURL_RESERVE_FACILITIES, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
    }
  }

  // Future<dynamic> setShopNotifyImageInfo(String div, String introCd, String sort, dynamic data) async {
  //
  //   final response = await DioImageClient().put('${ServerInfo.RESTURL_SHOPNOTIFYIMAGE_SET}?div=${div}&intro_cd=${introCd}&sort=${sort}&ucode=${AuthService.uCode}&uname=${AuthService.uName}', data: data);
  //
  //   if (response.data['code'] != '00') {
  //     return response.data['msg'];
  //   }
  //   else
  //     return response.data['code'];
  // }
}