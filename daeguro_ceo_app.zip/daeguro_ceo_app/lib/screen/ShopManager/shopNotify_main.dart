import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopNotifyEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopNotifyInfoModel.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopNotifyEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter_expandable_text/flutter_expandable_text.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopNotifyInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  final String? introGbn;

  const ShopNotifyInfoMain({Key? key, this.tabviewHeight, this.introGbn}) : super(key: key);

  @override
  State<ShopNotifyInfoMain> createState() => _ShopNotifyInfoMainState();
}

class _ShopNotifyInfoMainState extends State<ShopNotifyInfoMain> {
  List<ShopNotifyInfoModel> dataList = <ShopNotifyInfoModel>[];
  int selected = 0;

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ShopController.to.getShopIntroInfo(widget.introGbn!))
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
    else {
      dataList.clear();

      value.forEach((element) {
        ShopNotifyInfoModel temp = ShopNotifyInfoModel();

        temp.introCd = element['introCd'] as String;
        temp.shopCd = element['shopCd'] as String;
        temp.introGbn = element['introGbn'] as String;
        temp.introContents = element['introContents'] as String;
        temp.modDate = element['modDate'] as String;
        temp.introImage = element['introImage'] as String;
        temp.introImage2 = element['introImage2'] as String;
        temp.useGbn = element['useGbn'] as String;

        String pathName = widget.introGbn == 'I' ? 'shopImage' : 'ReviewImage';

        temp.introImageFullPath = temp.introImage == '' ? '' : 'https://image.daeguro.co.kr:40443/intro/${pathName}/${AuthService.SHOPCD}/thumb/${temp.introImage!}';
        temp.introImageFullPath2 = temp.introImage2 == '' ? '' : 'https://image.daeguro.co.kr:40443/intro/${pathName}/${AuthService.SHOPCD}/thumb/${temp.introImage2!}';

        dataList.add(temp);
      });

      selected = dataList.indexWhere((element) => element.useGbn == 'Y');
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    dataList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.introGbn == 'I' ? '*선택한 매장알림은 상점 매장정보에 보여집니다.' : '*선택한 리뷰알림은 상점 리뷰에 보여집니다.', style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                    const Text('*최대 3개 까지 작성가능합니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                  ],
                ),
                (Responsive.isMobile(context) == false && dataList.length < 3) ? ISButton(
                  child: const Text('새로 등록'),
                  onPressed: () {
                    showDialog(
                        context: context,
                        barrierDismissible: true,
                        builder: (context) => ShopNotifyEdit(introGbn: widget.introGbn!, jobGbn: 'I',)).then((v) async {
                      if (v == true) {
                        await Future.delayed(const Duration(milliseconds: 500), () {
                          debugPrint('widget.introGbn:${widget.introGbn}');
                          requestAPIData();
                        });
                      }
                    },
                    );
                  },
                ) : const SizedBox.shrink(),
              ],
            ),
          ),
          const Divider(height: 20,),
          (Responsive.isMobile(context) && dataList.length < 3)
              ? Align(
            alignment: Alignment.centerRight,
            child: ISButton(
              child: const Text('새로 등록'),
              onPressed: () {
                showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => ShopNotifyEdit(
                      introGbn: widget.introGbn!,
                      jobGbn: 'I',
                    )).then(
                      (v) async {
                    if (v == true) {
                      await Future.delayed(const Duration(milliseconds: 500), () {
                        debugPrint('widget.introGbn:${widget.introGbn}');
                        requestAPIData();
                      });
                    }
                  },
                );
              },
            ),
          )
              : Container(),
          ListView.builder(
            shrinkWrap: true,
            itemCount: dataList.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(
                title: Card(
                  elevation: 1,
                  shape: selected == index
                      ? RoundedRectangleBorder(side: const BorderSide(color: Color(0xff01CAFF), width: 2), borderRadius: BorderRadius.circular(10),)
                      : RoundedRectangleBorder(side: BorderSide(color: Colors.grey.shade300, width: 1.0,), borderRadius: BorderRadius.circular(10),
                  ),
                  child: Responsive.isMobile(context)
                      ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      RadioListTile(
                              title: Padding(padding: EdgeInsets.only(top: selected == index ? 14 : 18),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Visibility(visible: selected == index, child: Text(widget.introGbn == 'I' ? '현재 대구로 앱에 등록된 매장 알림이에요.' : '현재 대구로 앱에 등록된 리뷰 알림이에요.', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 15, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
                                    Text(dataList[index].modDate!, style: const TextStyle(fontSize: 16, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                            ],
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 5),
                              child: Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(8.0),
                                    child: (dataList[index].introImage == null || dataList[index].introImage == '')
                                        ? const Image(
                                      image: AssetImage('images/thumbnail-empty.png'),
                                      width: 100,
                                      height: 100,
                                    )
                                        : Image.network(
                                      '${dataList[index].introImageFullPath}?tm=${Utils.getTimeStamp()}',
                                      gaplessPlayback: true,
                                      fit: BoxFit.fill,
                                      width: 100,
                                      height: 100,
                                      errorBuilder: (context, error, stackTrace) {
                                        debugPrint('image load error -> ${dataList[index].introImage}\nerror:${error.toString()}\nstackTrace:${stackTrace.toString()}');
                                        return const Image(
                                          image: AssetImage('images/thumbnail-empty.png'),
                                          width: 100,
                                          height: 100,
                                        );
                                      },
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 8.0,
                                  ),
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(8.0),
                                    child: (dataList[index].introImage2 == null || dataList[index].introImage2 == '')
                                        ? const Image(
                                      image: AssetImage('images/thumbnail-empty.png'),
                                      width: 100,
                                      height: 100,
                                    )
                                        : Image.network(
                                      '${dataList[index].introImageFullPath2}?tm=${Utils.getTimeStamp()}',
                                      gaplessPlayback: true,
                                      fit: BoxFit.fill,
                                      width: 100,
                                      height: 100,
                                      errorBuilder: (context, error, stackTrace) {
                                        debugPrint('image load error -> ${dataList[index].introImage2}\nerror:${error.toString()}\nstackTrace:${stackTrace.toString()}');
                                        return const Image(
                                          image: AssetImage('images/thumbnail-empty.png'),
                                          width: 100,
                                          height: 100,
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            ExpandableText(
                              dataList[index].introContents.toString(),
                              readLessText: '접기',
                              readMoreText: '더보기',
                              style: const TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                ISButton(
                                  isReverseColor: true,
                                  child: const Text('삭제'),
                                  onPressed: () {
                                    ISConfirm(context, widget.introGbn == 'I' ? '매장 알림 삭제' : '리뷰 알림 삭제', '등록하신 알림이 삭제됩니다.', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                                      Navigator.of(context).pop();

                                      if (isOK) {
                                        ShopNotifyEditModel sendData = ShopNotifyEditModel();
                                        sendData.jobGbn = 'D';
                                        sendData.introCd = dataList[index].introCd;
                                        sendData.shopCd = AuthService.SHOPCD;
                                        sendData.introGbn = dataList[index].introGbn;
                                        sendData.introContents = dataList[index].introContents;
                                        sendData.useGbn = dataList[index].useGbn;
                                        sendData.modUcode = AuthService.uCode;
                                        sendData.modName = AuthService.uName;

                                        var value = await showDialog(context: context, barrierColor: Colors.transparent,builder: (context) => FutureProgressDialog(ShopController.to.updateShopIntroInfo(sendData.toJson())));

                                        if (value == null) {
                                          ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                                        } else {
                                          String code = value.split('|').first;
                                          String msg = value.split('|').last;
                                          if (code == '00') {
                                            requestAPIData();
                                          } else {
                                            ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${msg} ');
                                          }
                                        }
                                      }
                                    });
                                  },
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                ISButton(
                                  child: const Text('수정'),
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      barrierDismissible: true,
                                      builder: (context) => ShopNotifyEdit(
                                        introGbn: widget.introGbn!,
                                        introCode: dataList[index].introCd,
                                        jobGbn: 'U',
                                      ),
                                    ).then((v) async {
                                      await Future.delayed(const Duration(milliseconds: 500), () {
                                        requestAPIData();
                                      });
                                    });
                                  },
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                          ],
                        ),
                        value: index,
                        groupValue: selected,
                        onChanged: (value) {
                          int oldSelected = selected;
                          selected = value!;
                          debugPrint('selected:$selected');

                          ISConfirm(context, widget.introGbn == 'I' ? '매장 알림 변경' : '리뷰 알림 변경', '해당 알림으로 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                            if (isOK == false) {
                              Navigator.of(context).pop();
                              setState(() {
                                selected = oldSelected!;
                                debugPrint('rollback:$selected');
                              });
                            } else if (isOK == true) {
                              Navigator.of(context).pop();

                              int idx = 0;
                              dataList.forEach((element) {
                                element.useGbn = (idx == selected) ? 'Y' : 'N';
                                idx++;
                              });

                              ShopNotifyEditModel sendData = ShopNotifyEditModel();
                              sendData.jobGbn = 'U';
                              sendData.introCd = dataList[selected].introCd;
                              sendData.shopCd = AuthService.SHOPCD;
                              sendData.introGbn = dataList[selected].introGbn;
                              sendData.introContents = dataList[selected].introContents;
                              sendData.useGbn = dataList[selected].useGbn;
                              sendData.modUcode = AuthService.uCode;
                              sendData.modName = AuthService.uName;

                              debugPrint('selected:$selected, useGbn:${sendData.useGbn}');

                              var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(ShopController.to.updateShopIntroInfo(sendData.toJson())));

                              if (value == null) {
                                ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                              } else {
                                String code = value.split('|').first;
                                String msg = value.split('|').last;

                                if (code == '00') {
                                  requestAPIData();
                                  return;
                                } else {
                                  ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ $msg');
                                }
                              }
                            }
                          });

                          setState(() {
                            // selected = oldSelected!;
                            // debugPrint('rollback:$selected');
                          });
                        },
                      )
                    ],
                  ) : RadioListTile(
                    title: Padding(
                      padding: const EdgeInsets.only(top: 12.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(dataList[index].modDate!, style: const TextStyle(fontSize: 16, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                          const SizedBox(width: 16,),
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Visibility(visible: selected == index, child: Text(widget.introGbn == 'I' ? '현재 대구로 앱에 등록된 매장 알림이에요.' : '현재 대구로 앱에 등록된 리뷰 알림이에요.', style: TextStyle(color: Color(0xff01CAFF), fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    ISButton(
                                      isReverseColor: true,
                                      child: const Text('삭제'),
                                      onPressed: () {
                                        ISConfirm(context, widget.introGbn == 'I' ? '매장 알림 삭제' : '리뷰 알림 삭제', '등록하신 알림이 삭제됩니다.', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                                          Navigator.of(context).pop();
                                          if (isOK){
                                            ShopNotifyEditModel sendData = ShopNotifyEditModel();
                                            sendData.jobGbn = 'D';
                                            sendData.introCd = dataList[index].introCd;
                                            sendData.shopCd = AuthService.SHOPCD;
                                            sendData.introGbn = dataList[index].introGbn;
                                            sendData.introContents = dataList[index].introContents;
                                            sendData.useGbn = dataList[index].useGbn;
                                            sendData.modUcode = AuthService.uCode;
                                            sendData.modName = AuthService.uName;

                                            var value = await showDialog(
                                                context: context,
                                                builder: (context) => FutureProgressDialog(ShopController.to.updateShopIntroInfo(sendData.toJson()))
                                            );

                                            if (value == null) {
                                              ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                                            }
                                            else {
                                              String code = value.split('|').first;
                                              String msg = value.split('|').last;
                                              if (code == '00') {
                                                requestAPIData();
                                              }
                                              else{
                                                ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${msg} ');
                                              }
                                            }
                                          }
                                        });
                                      },
                                    ),
                                    const SizedBox(width: 10,),
                                    ISButton(
                                      child: const Text('수정'),
                                      onPressed: () {
                                        showDialog(
                                          context: context,
                                          barrierDismissible: true,
                                          builder: (context) => ShopNotifyEdit(introGbn: widget.introGbn!, introCode: dataList[index].introCd, jobGbn: 'U',),
                                        ).then((v) async {
                                          await Future.delayed(const Duration(milliseconds: 500), () {
                                            requestAPIData();
                                          });
                                        });
                                      },
                                    ),
                                  ],
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                    subtitle: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8.0),
                            //child: Image.network(dataList[index].introImage.toString(), width: 100, height: 100,)
                            child: (dataList[index].introImage == null || dataList[index].introImage == '') ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                : Image.network('${dataList[index].introImageFullPath}?tm=${Utils.getTimeStamp()}', gaplessPlayback: true, fit: BoxFit.fill, width: 100, height: 100,
                              errorBuilder: (context, error, stackTrace) {
                                debugPrint('image load error -> ${dataList[index].introImage}\nerror:${error.toString()}\nstackTrace:${stackTrace.toString()}');
                                return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);//Image.asset('assets/thumbnail-empty.png', width: 150, height: 150,);
                              },
                            ),
                          ),
                          const SizedBox(width: 8.0,),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8.0),
                            //child: Image.network(dataList[index].introImage2.toString(), width: 100, height: 100,)
                            child: (dataList[index].introImage2 == null || dataList[index].introImage2 == '') ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,)
                                : Image.network('${dataList[index].introImageFullPath2}?tm=${Utils.getTimeStamp()}', gaplessPlayback: true, fit: BoxFit.fill, width: 100, height: 100,
                              errorBuilder: (context, error, stackTrace) {
                                debugPrint('image load error -> ${dataList[index].introImage2}\nerror:${error.toString()}\nstackTrace:${stackTrace.toString()}');
                                return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 100, height: 100,);//Image.asset('assets/thumbnail-empty.png', width: 150, height: 150,);
                              },
                            ),
                          ),
                          const SizedBox(width: 8.0,),
                          Expanded(
                            child: Container(
                              height: 100,
                              padding: const EdgeInsets.only(left: 12.0, top: 12.0, bottom: 12.0),
                              decoration: BoxDecoration(
                                //color: Colors.white,
                                  borderRadius: BorderRadius.circular(8.0),
                                  border: const Border(
                                      top: BorderSide(color: Colors.black12, width: 1.0),
                                      left: BorderSide(color: Colors.black12, width: 1.0),
                                      right: BorderSide(color: Colors.black12, width: 1.0),
                                      bottom: BorderSide(color: Colors.black12, width: 1.0)
                                  )
                              ),
                              child: ScrollConfiguration(
                                behavior: ScrollConfiguration.of(context).copyWith(scrollbars: true),
                                child: SingleChildScrollView(
                                  child: Text(dataList[index].introContents.toString(), style: const TextStyle(fontSize: 13, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    value: index,
                    groupValue: selected,
                    onChanged: (value) {
                      int oldSelected = selected;
                      selected = value!;

                      debugPrint('selected:${selected}');

                      ISConfirm(context, widget.introGbn == 'I' ? '매장 알림 변경' : '리뷰 알림 변경', '해당 알림으로 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                        if (isOK == false){
                          Navigator.of(context).pop();
                          setState(() {
                            selected = oldSelected!;
                            debugPrint('rollback:${selected}');
                          });

                        }
                        else if (isOK == true){
                          Navigator.of(context).pop();

                          int idx = 0;
                          dataList.forEach((element) {
                            element.useGbn = (idx == selected) ? 'Y' : 'N';
                            idx++;
                          });

                          ShopNotifyEditModel sendData = ShopNotifyEditModel();
                          sendData.jobGbn = 'U';
                          sendData.introCd = dataList[selected].introCd;
                          sendData.shopCd = AuthService.SHOPCD;
                          sendData.introGbn = dataList[selected].introGbn;
                          sendData.introContents = dataList[selected].introContents;
                          sendData.useGbn = dataList[selected].useGbn;
                          sendData.modUcode = AuthService.uCode;
                          sendData.modName = AuthService.uName;

                          debugPrint('selected:${selected}, useGbn:${sendData.useGbn}');

                          var value = await showDialog(
                              context: context,
                              builder: (context) => FutureProgressDialog(ShopController.to.updateShopIntroInfo(sendData.toJson()))
                          );

                          if (value == null) {
                            ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                          }
                          else {
                            String code = value.split('|').first;
                            String msg = value.split('|').last;
                            if (code == '00') {
                              requestAPIData();
                              return;
                            }
                            else{
                              ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${msg} ');
                            }
                          }
                        }
                      });

                      setState(() {
                        // selected = oldSelected!;
                        // debugPrint('rollback:${selected}');
                      });
                    },
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}