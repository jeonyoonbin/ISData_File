

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopHolidayInfoMain.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopInfo_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopOperateInfoReserve_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopOperateInfo_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopRegistInfo_main.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';

class ShopManagerMain extends StatefulWidget {
  const ShopManagerMain({Key? key}) : super(key: key);

  @override
  State<ShopManagerMain> createState() => _ShopManagerMainState();
}

class _ShopManagerMainState extends State<ShopManagerMain> with PageMixin {
  List<Tab> currTabs = <Tab>[
    const Tab(height: 60, text: '     매장 정보     '),
    const Tab(height: 60, text: '     운영 정보     '),
    //Tab(height: 60, text: '     휴점 설정     '),
    const Tab(height: 60, text: '     사업자 정보     '),
    //Tab(height: 60, text: '     매장/리뷰 알림     '),
  ];

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    double tapviewContentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 280 : 330);//330);

    return fluentUI.ScaffoldPage.withPadding(
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),//Responsive.isMobile(context) == true ? const LayoutBottom() : null,
      content: SizedBox(
        height: tapviewContentHeight,//560,
        child: DefaultTabController(
          initialIndex: 0,
          length: currTabs.length,
          child: Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              elevation: 0.0,
              backgroundColor: Colors.transparent,
              title: TabBar(
                indicatorColor: Colors.black,
                labelStyle: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
                unselectedLabelStyle: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                indicatorWeight: 10,
                indicatorSize: TabBarIndicatorSize.label,
                labelColor: Colors.black,
                isScrollable: true,
                padding: const EdgeInsets.all(0),
                labelPadding: const EdgeInsets.all(0),
                tabs: currTabs,
              ),
            ),
            body: Padding(
              padding: const EdgeInsets.only(top: 22),// .symmetric(vertical: 22),
              child: TabBarView(
                physics: const NeverScrollableScrollPhysics(),
                children: <Widget>[
                  ShopInfoMain(tabviewHeight: tapviewContentHeight),
                  AuthService.ShopType.toString().contains('9') ?  ShopOperateInfoReserveMain(tabviewHeight: tapviewContentHeight): ShopOperateInfoMain(tabviewHeight: tapviewContentHeight),
                  //const ShopHolidayInfoMain(),
                  const ShopRegistInfoMain(),
                  //ShopNotifyInfoMain(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  requestAPIData() async {
  }
}