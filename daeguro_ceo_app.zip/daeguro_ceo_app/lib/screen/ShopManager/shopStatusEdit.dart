import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/models/Common/commonNoFlagModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionSoldOutEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateEditModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopStatusEdit extends StatefulWidget {
  const ShopStatusEdit({Key? key})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopStatusEditState();
  }
}

enum RadioStatusGbn { statusGbnY, statusGbnN }

class ShopStatusEditState extends State<ShopStatusEdit> {

  RadioStatusGbn? _radioStatusGbn;

  String? shopStatus;

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    shopStatus = AuthService.ShopStatus;

    _radioStatusGbn = (shopStatus == 'Y') ? RadioStatusGbn.statusGbnY : RadioStatusGbn.statusGbnN;
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 220),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text('매장 상태 변경', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //const Divider(color: Colors.grey, height: 0.0,),
              const SizedBox(height: 12,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('매장 상태', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                  Row(
                    children: [
                      Radio(
                          value: RadioStatusGbn.statusGbnY,
                          groupValue: _radioStatusGbn,
                          onChanged: (v) async {
                            setState(() {
                              _radioStatusGbn = v as RadioStatusGbn?;

                              shopStatus = 'Y';
                            });
                          }),
                      const Text('영업중', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      const SizedBox(width: 20,),
                      Radio(
                          value: RadioStatusGbn.statusGbnN,
                          groupValue: _radioStatusGbn,
                          onChanged: (v) async {


                            setState(() {
                              _radioStatusGbn = v as RadioStatusGbn?;

                              shopStatus = 'N';
                            });
                          }),
                      const Text('휴점중', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      const SizedBox(width: 16,),
                    ],
                  )
                ],
              ),
              const SizedBox(height: 10,),
            ],
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              ISConfirm(context, '매장 상태 변경', '매장 상태를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  ShopOperateEditModel sendData = ShopOperateEditModel();
                  sendData.shopCd = AuthService.SHOPCD;
                  sendData.modUcode = AuthService.uCode;
                  sendData.modName = AuthService.uName;
                  sendData.jobGbn = '1';
                  sendData.absentYn = shopStatus;

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ShopController.to.updateOperateInfo(sendData.toJson()))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                  }
                  else {
                    if (value == '00') {
                      setState(() {
                        AuthService.ShopStatus = shopStatus;
                        appTheme.currentShopStatusGbn = shopStatus;
                      });

                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


