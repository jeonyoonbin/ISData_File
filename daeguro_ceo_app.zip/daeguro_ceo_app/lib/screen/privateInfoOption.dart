

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_datatable.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListModel.dart';
import 'package:daeguro_ceo_app/models/OrderManager/orderListModel.dart';
import 'package:daeguro_ceo_app/screen/OrderManager/orderDetailInfo.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeDetailInfo.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';


class PrivateInfoOption extends StatefulWidget {
  const PrivateInfoOption({Key? key}) : super(key: key);

  @override
  State<PrivateInfoOption> createState() => _PrivateInfoOptionState();
}

class _PrivateInfoOptionState extends State<PrivateInfoOption> with PageMixin{
  static const int MODE_MAIN_VIEW = 1000;
  static const int MODE_SHOPCLOSE_VIEW = 1001;

  int currentMode = MODE_MAIN_VIEW;

  bool checkState_closeConfirm = false;

  String? tempStr;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {
    debugPrint('dispose NoticeManagerMain');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    double contentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 398 : 370);

    return fluentUI.ScaffoldPage.withPadding(
      //scrollController: AppTheme.mainScrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: (currentMode == MODE_MAIN_VIEW) ? mainInfoView(context) : shopCloseView(context),
        ),
      ),
    );
  }

  List<Widget> mainInfoView(BuildContext context){
    return [
      const SizedBox(height: 12.0),
      ISLabelBarSub(
        title: '비밀번호 변경',
        bodyPadding: const EdgeInsets.only(top: 15, bottom: 15, right: 32, left: 0),
        trailing: ISButton(
          child: const Text('비밀번호 변경'),
          onPressed: () {
            // currentMode = MODE_SHOPSTATUS_VIEW;
            //
            // setState(() {
            //   _scrollController!.jumpTo(0.0);
            // });
          },
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('현재 비밀번호', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                  const SizedBox(width: 10.0),
                  Material(
                    child: ISInput(
                      value: tempStr,
                      //label: '제목',
                      width: Responsive.isMobile(context) == true ? MediaQuery.of(context).size.width - 180 : 200,
                      onSaved: (v) {
                        tempStr = v;

                        debugPrint('tempStr:${tempStr}');
                      },
                    ),
                  )
                ],
              ),
              const SizedBox(height: 12.0),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('변경 비밀번호', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                  const SizedBox(width: 10.0),
                  Material(
                    child: ISInput(
                      value: tempStr,
                      //label: '제목',
                      width: Responsive.isMobile(context) == true ? MediaQuery.of(context).size.width - 180 : 200,
                      onSaved: (v) {
                        tempStr = v;

                        debugPrint('tempStr:${tempStr}');
                      },
                    ),
                  )
                ],
              ),
              const SizedBox(height: 12.0),
              Row(
                children: [
                  const Text('비밀번호 확인', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                  const SizedBox(width: 10.0),
                  Material(
                    child: ISInput(
                      value: tempStr,
                      //label: '제목',
                      width: Responsive.isMobile(context) == true ? MediaQuery.of(context).size.width - 180 : 200,
                      onSaved: (v) {
                        tempStr = v;

                        debugPrint('tempStr:${tempStr}');
                      },
                    ),
                  )
                ],
              ),

            ],
          ),
        ),
      ),
      ISLabelBarSub(
        title: '입점 해지 요청',
        bodyPadding: const EdgeInsets.only(top: 15, bottom: 15, right: 32, left: 0),
        trailing: Material(
          child: ISButton(
            child: const Text('입점 해지 요청'),
            onPressed: () {
              currentMode = MODE_SHOPCLOSE_VIEW;

              debugPrint('currentMode:${currentMode}');

              setState(() {

                //_scrollController!.jumpTo(0.0);
              });
            },
          ),
        ),
      )
    ];
  }

  List<Widget> shopCloseView(BuildContext context){
    return [
      const ISLabelBarMain(
        leading: Text('입점 해지 요청', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
      ),
      ISLabelBarSub(
        title: '입점 해지 유의사항',
        titleStyle: const TextStyle(color: Colors.red, fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
        prefixIcon: const Icon(Icons.info, color: Colors.red, size: 24),
        bodyPadding: const EdgeInsets.only(top: 15, bottom: 15, right: 32, left: 0),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('※ 해지 주의사항', style: TextStyle(color: Colors.blueAccent, fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
              SizedBox(height: 12,),
              Text('- 해지 처리는 접수일 기준 익일에 처리됩니다. (주말, 공휴일 제외)', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
              SizedBox(height: 4,),
              Text('- 해지 신청 후 자료조회(주문내역, 적립금)는 7일 동안 가능합니다.', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
              SizedBox(height: 4,),
              Text('- 남은 적립금은 전액 출금 해주셔야 합니다.\n  (단, 매출이 없었던 가맹점일 경우 지급 불가)', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
              SizedBox(height: 4,),
              Text('- 입점지원금은 지급된 가맹점은 재가입시 입점지원금이 지급 되지 않습니다.', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),

              SizedBox(height: 22,),

              Text('※ 개인정보 수집 및 이용에 대한 안내', style: TextStyle(color: Colors.blueAccent, fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
              SizedBox(height: 12,),
              Text('- 개인정보 및 이용 목적 : 본인 접수 및 처리 결과 회신', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
              SizedBox(height: 4,),
              Text('- 수집하는 개인항목 : 성명, 연락처, 마스킹된 신청자의 신분증사본', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
              SizedBox(height: 4,),
              Text('- 그 외 신고서와 신고 내용은 관계법령 및 민·형사상 소성 대응을 위해 보관하며,\n 그 밖의 사항은 개인정보처리방침을 준수합니다. 위 개인정보 수집 및 이용에 동의합니다.', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
              SizedBox(height: 4,),
              Text('- 개인정보의 수집 이용에 관한동의를 거부할 권리가 있으며, 동의를 거부할 경우 권리침해\n 업무 절차상 처리에 제한이 있을수 있습니다.', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),

              SizedBox(height: 22,),

              Text('※ 위 내용에 동의 하실 경우 하단 동의여부를 체크해주세요.', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
            ],
          ),
        ),
      ),
      const Divider(),
      Padding(
        padding: const EdgeInsets.all(16.0),
        child: Responsive.isMobile(context) == true ? Column(children: confirmView(),) : Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: confirmView()),
        // child: Row(
        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //   children: confirmView(),
        // ),
      )
    ];
  }

  List<Widget> confirmView(){
    return [
      Material(child: ISCheckbox(label: '위 내용을 모두 확인하였으며, 입점해지 요청에 동의합니다.', value: checkState_closeConfirm, onChanged: (v) => setState(() => checkState_closeConfirm = v!))),
      Responsive.isMobile(context) == true ? const SizedBox(height: 16) : const SizedBox.shrink(),
      Material(
        child: ISButton(
          width: Responsive.isMobile(context) == true ? double.infinity : 64,
          child: const Text('입점 해지 요청', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
          onPressed: () {
          },
        ),
      )
    ];
  }

  requestAPIData() async {
  }
}