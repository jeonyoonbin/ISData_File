import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown_v2.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/AccountManager/accountHistoryModel.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:data_table_2/data_table_2.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';


class AccountHistoryMain extends StatefulWidget {
  final double? tabviewHeight;
  const AccountHistoryMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<AccountHistoryMain> createState() => _AccountHistoryMainState();
}

class _AccountHistoryMainState extends State<AccountHistoryMain> {
  late AccountHistorySource accountHistoryDataSource;
  final ScrollController _scrollController = ScrollController();

  List<AccountHistoryModel> dataList = <AccountHistoryModel>[];

  bool _initialized = false;

  String? startdate = '';
  String? enddate = '';
  String? tempStr;
  String? selectedType = '1000';

  int totaldeposit = 0;
  int totalwithdraw = 0;
  int moneySum = 0;

  String? selectedPayType = '%';
  String? selectedPackOrderType = '%';
  String? selectedMemoGbn = '%';

  int selectedPageNumber = 1;
  int totalPage = 0;

  int remainAmt = 0;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      accountHistoryDataSource = AccountHistorySource(context, dataList, false, true, true, false);
      // Default sorting sample. Set __sortColumnIndex to 0 and uncoment the lines below
      // if (_sortColumnIndex == 0) {
      //   _sort<String>((d) => d.name, _sortColumnIndex!, _sortAscending);
      // }
      _initialized = true;
      accountHistoryDataSource.addListener(() {
        setState(() {});
      });
    }
  }

  @override
  void dispose() {
    dataList.clear();
    accountHistoryDataSource.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  requestAPIData() async {
    String packOrderYn = selectedPackOrderType!;
    String appOrderGbn = '%';
    String payGbn = '%';
    String chargeGbn = '1,3,K,P';

    if (selectedPayType == "%"){
      appOrderGbn = "%";
      payGbn = "%";
      chargeGbn = "1,3,K,P";
    }
    else if (selectedPayType == "1"){
      appOrderGbn = "1";
      payGbn = "%";
      chargeGbn = "K,P";
    }
    else if (selectedPayType == "5"){
      appOrderGbn = "5";
      payGbn = "%";
      chargeGbn = "K,P";
    }
    else if (selectedPayType == "3"){
      appOrderGbn = "3";
      payGbn = "%";
      chargeGbn = "K,P";
    }
    else if (selectedPayType == "7"){
      appOrderGbn = "3";
      payGbn = "7";
      chargeGbn = "K,P";
    }
    else if (selectedPayType == "10"){
      chargeGbn = "3";
    }
    else if (selectedPayType == "11"){
      appOrderGbn = "";
      payGbn = "";
      chargeGbn = "1";
    }

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(AccountController.to.getShopAccountHistoryList(packOrderYn, appOrderGbn, payGbn, chargeGbn, startdate!.replaceAll('-', ''), enddate!.replaceAll('-', ''), selectedPageNumber.toString()))
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      List<AccountHistoryModel> resultList = <AccountHistoryModel>[];
      value.forEach((element) {
        AccountHistoryModel temp = AccountHistoryModel();

        temp.orderNo = element['orderNo'] as String;
        temp.orderDate = element['orderDate'] as String;
        temp.status = element['status'] as String;
        temp.packOrderYn = element['packOrderYn'] as String;
        temp.packOrderYnName = element['packOrderYnName'] as String;
        temp.totAmt = element['totAmt'] as String;
        temp.menuAmt = element['menuAmt'] as String;
        temp.deliTipAmt = element['deliTipAmt'] as String;
        temp.totalDiscAmt = element['totalDiscAmt'] as String;
        temp.shopDiscAmt = element['shopDiscAmt'] as String;
        temp.totalFeeAmt = element['totalFeeAmt'] as String;
        temp.appFeeAmt = element['appFeeAmt'] as String;
        temp.pgFeeAmt = element['pgFeeAmt'] as String;
        temp.deliTotAmt = element['deliTotAmt'] as String;
        temp.totalAmt = element['totalAmt'] as String;
        temp.deliCashAmt = element['deliCashAmt'] as String;
        temp.deliCardAmt = element['deliCardAmt'] as String;
        temp.memo = element['memo'] as String;
        temp.appPayGbnName = element['appPayGbnName'] as String;
        temp.transferAmt = element['transferAmt'] as String;
        temp.liveDiscAmt = element['liveDiscAmt'] as String;
        temp.adminAmt = element['adminAmt'] as String;
        temp.packDiscAmt = element['packDiscAmt'] as String;
        temp.shopCouponAmt = element['shopCouponAmt'] as String;
        temp.rNum = element['rNum'] as String;
        temp.chargeDate = element['chargeDate'] as String;
        temp.inAmt = element['inAmt'] as String;
        temp.outAmt = element['outAmt'] as String;
        temp.chargeAmt = element['chargeAmt'] as String;
        temp.shopCd = element['shopCd'] as String;
        temp.appMenuAmt = element['appMenuAmt'] as String;
        temp.appTipAmt = element['appTipAmt'] as String;
        temp.meetMenuAmt = element['meetMenuAmt'] as String;
        temp.meetTipAmt = element['meetTipAmt'] as String;

        resultList.add(temp);
      });

      // resultList.forEach((element) {
      //   debugPrint('before orderNo:${element.orderNo}, memo:${element.memo}');
      // });

      if (selectedPackOrderType == 'Y'){
        dataList = resultList.where((element) => element.packOrderYn == 'Y').toList();
      }
      else if (selectedPackOrderType == 'N'){
        dataList = resultList.where((element) => element.packOrderYn == 'N').toList();
      }
      else {
        dataList = resultList;
      }

      // resultList.forEach((element) {
      //   debugPrint('after orderNo:${element.orderNo}, memo:${element.memo}');
      // });

      //debugPrint('selectedMemoGbn:${selectedMemoGbn}');
      if (selectedMemoGbn == 'N'){
        //debugPrint('check1111 resultList length:${resultList.length}');
        dataList.clear();

        // resultList.forEach((element) {
        //   debugPrint('orderNo:${element.orderNo}, memo:${element.memo}');
        // });

        resultList.where((element) => element.memo! != null).forEach((element) {
          //print('orderNo:${element.orderNo}, memo:${element.memo}');
        });
        dataList = resultList.where((element) => element.memo!.contains("완료=>취소")).toList();

        //debugPrint('check1111 data length:${dataList.length}');
      }
      else if (selectedMemoGbn == 'Y'){
        //debugPrint('check2222');
        dataList.clear();
        dataList = resultList.where((element) => element.memo!.contains('') == true).toList();
        //debugPrint('check2222 data length:${dataList.length}');
      }
      else{
        //debugPrint('check3333');
      }

      totalPage = AccountController.to.total_page;
      remainAmt = AccountController.to.remainAmt;

      totaldeposit = AccountController.to.totaldeposit;
      totalwithdraw = AccountController.to.totalwithdraw;
      moneySum = AccountController.to.moneySum;

      accountHistoryDataSource = AccountHistorySource(context, dataList, false, true, true, false);

      accountHistoryDataSource.addListener(() {
        setState(() {});
      });

      //accountHistoryDataSource = AccountHistorySource(context, dataList, false, true, true, false);

      //print('requestAPIData selectedPageNumber:${selectedPageNumber}, total_page:${totalPage}');
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(AccountController());

    // 날짜필터
    startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);//formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
    enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);//formatDate(DateTime(int.parse(DateTime.now().year.toString()), int.parse(DateTime.now().month.toString()) + 1, 0), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefreshChild == true ) {
        _appTheme.ShopRefreshChild = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Responsive.isMobile(context) == true
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                          Text.rich(
                              style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, fontSize: 24),
                              textAlign: Responsive.isMobile(context) == true ? TextAlign.end : TextAlign.start,
                              TextSpan(children: [
                                const TextSpan(text: '현재 적립금 '),
                                TextSpan(text: Utils.getCashComma(remainAmt.toString()), style: const TextStyle(color: Colors.lightBlue,)),
                                const TextSpan(text: '원'),
                              ])),
                          const SizedBox(width: 6,),
                          const Text('(입점 지원금 10,000원 포함)', style: TextStyle(color: Colors.grey, fontSize: 14),),
                      ]
                  ) : Row(
                        children: [
                          const Text('(입점 지원금 10,000원 포함)', style: TextStyle(color: Colors.grey, fontSize: 14),),
                          const SizedBox(width: 6,),
                          Text.rich(
                              style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, fontSize: 24),
                              textAlign: Responsive.isMobile(context) == true ? TextAlign.end : TextAlign.start,
                              TextSpan(
                                  children: [
                                    const TextSpan(text: '현재 적립금 '),
                                    TextSpan(text: Utils.getCashComma(remainAmt.toString()), style: const TextStyle(color: Colors.lightBlue,)),
                                    const TextSpan(text: '원'),
                                  ]
                              )
                          )
                        ],
                  ),
            ],
          ),
          const Divider(thickness: 1, color: Colors.black),
          Responsive.isMobile(context) ? Column(
            children: [
              ISSearchDropdown(
                label: '결제 구분',
                width: double.infinity,
                height: 50,
                value: '%',
                onChange: (value) {
                  setState(() {
                    selectedPayType = value;
                  });
                  selectedPageNumber = 1;

                  requestAPIData();
                },
                item: [
                  ISOptionModel(value: '%', label: '결제 구분 전체'),
                  ISOptionModel(value: '1', label: '만나서결제(현금)'),
                  ISOptionModel(value: '5', label: '만나서결제(카드)'),
                  ISOptionModel(value: '3', label: '앱결제'),
                  ISOptionModel(value: '7', label: '행복페이'),
                  ISOptionModel(value: '10', label: '출금 계좌이체'),
                  ISOptionModel(value: '11', label: '사입'),
                ].cast<ISOptionModel>(),
              ),
              const SizedBox(height: 8),
              ISSearchDropdown(
                label: '주문 구분',
                width: double.infinity,
                height: 50,
                value: selectedPackOrderType,
                onChange: (value) {
                  setState(() {
                     selectedPackOrderType = value;
                  });
                   selectedPageNumber = 1;
                   requestAPIData();
                },
                item: [
                  ISOptionModel(value: '%', label: '주문 전체'),
                  ISOptionModel(value: 'N', label: '배달'),
                  ISOptionModel(value: 'Y', label: '포장'),
                ].cast<ISOptionModel>(),
              ),
              const SizedBox(height: 8),
            ],
          ) : Container(),
          Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
          const SizedBox(height: 8),
          Container(
              alignment: Responsive.isMobile(context) == true ? Alignment.centerRight : Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              //height: 40,
              width: double.infinity,
              decoration: BoxDecoration(color: Colors.grey[200],),
              child: Text.rich(
                  style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                  textAlign: Responsive.isMobile(context) == true ? TextAlign.end : TextAlign.start,
                  TextSpan(children: [
                    const TextSpan(text: '조회된 기간의 총 입금액은 '),
                    TextSpan(text: Utils.getCashComma(totaldeposit.toString()), style: const TextStyle(color: Colors.lightBlue, )),
                    const TextSpan(text: '원, '),
                    const TextSpan(text: '총 출금액은 '),
                    TextSpan(text: Utils.getCashComma(totalwithdraw.toString()), style: const TextStyle(color: Colors.lightBlue)),
                    const TextSpan(text: '원, '),
                    TextSpan(text: Responsive.isMobile(context) == true ? '\n' : ''),
                    const TextSpan(text: '총 적립금액은 '),
                    TextSpan(text: Utils.getCashComma((totaldeposit - totalwithdraw * -1).toString()), style: const TextStyle(color: Colors.lightBlue)),
                    const TextSpan(text: '원 입니다.'),
                  ]))),
          const SizedBox(height: 10,),
          Responsive.isMobile(context) == true ? mobileAccountHistoryData() : AccountHistoryData(),
          if (dataList != null && dataList.isNotEmpty)...[
            ISNumberPagination(
              threshold: 5,
              controlButton: const SizedBox(width: 10, height: 10,),
              onPageChanged: (int pageNumber) {
                setState(() {
                  selectedPageNumber = pageNumber;
                });

                requestAPIData();
              },
              fontSize: 12,
              pageTotal: totalPage,
              pageInit: selectedPageNumber,
              // picked number when init page
              colorPrimary: Colors.black,
              colorSub: Colors.white,
            ),
          ]
        ],
      ),
    );
  }

  // ignore: non_constant_identifier_names
  Widget AccountHistoryData() {
    return SizedBox(
      height: (widget.tabviewHeight! - 138.0),
      child: DataTable2(
        // dataRowHeight: 30,
        headingRowHeight: 40,
        columnSpacing: 0,
        horizontalMargin: 0,
        headingRowColor: MaterialStateProperty.all(Colors.grey[100],),
        headingTextStyle: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54),
        // MaterialStateProperty.resolveWith((states) =>
        //     _fixedRows > 0 ? Colors.grey[200] : Colors.transparent),
        border: TableBorder(
          borderRadius: BorderRadius.circular(10),
          top: BorderSide(color: Colors.grey[300]!),
          right: BorderSide(color: Colors.grey[300]!),
          bottom: BorderSide(color: Colors.grey[300]!),
          left: BorderSide(color: Colors.grey[300]!),
          horizontalInside: BorderSide.none,
        ),

        dividerThickness: 0, // this one will be ignored if [border] is set above
        bottomMargin: 10,
        minWidth: 1000,
        // sortColumnIndex: _sortColus
        // sortArrowIcon: Icons.keyboard_arrow_up, // custom arrow
        // sortArrowAnimationDuration:
        //     const Duration(milliseconds: 500), // custom animation duration
        // onSelectAll: (val) =>
        //     setState(() => _dessertsDataSource.selectAll(val)),
        columns: [
          const DataColumn2(label: Center(child: Text('영업 일자')), size: ColumnSize.S),
          const DataColumn2(label: Center(child: Text('주문 번호')), size: ColumnSize.S, numeric: true),
          DataColumn2(
              label: Center(
                child: ISSearchDropdownV2(
                  // label: '업체타입',
                  value: selectedPayType,
                  onChange: (value) {
                    setState(() {
                      selectedPayType = value;
                    });
                    selectedPageNumber = 1;

                    requestAPIData();
                  },
                  item: [
                    const DropdownMenuItem(value: '%', child: Text('결제 구분 전체',),),
                    const DropdownMenuItem(value: '1', child: Text('만나서결제(현금)',),),
                    const DropdownMenuItem(value: '5', child: Text('만나서결제(카드)',),),
                    const DropdownMenuItem(value: '3', child: Text('앱결제',),),
                    const DropdownMenuItem(value: '7', child: Text('행복페이',),),
                    const DropdownMenuItem(value: '10', child: Text('출금 계좌이체',),),
                    const DropdownMenuItem(value: '11', child: Text('사입',),),
                  ].cast<DropdownMenuItem<String>>(),
                ),
                // child: Text('결제 구분 전체'),
              ),
              size: ColumnSize.S,
              numeric: true,
              fixedWidth: 180
            // onSort: (columnIndex, ascending) =>
            //     _sort<num>((d) => d.fat, columnIndex, ascending),
          ),
          DataColumn2(
            label: Center(
              child: ISSearchDropdownV2(
                // label: '업체타입',
                value: selectedPackOrderType,
                onChange: (value) {
                  setState(() {
                    selectedPackOrderType = value;
                  });

                  selectedPageNumber = 1;

                  requestAPIData();
                },
                item: [
                  const DropdownMenuItem(value: '%', child: Text('주문 전체'),),
                  const DropdownMenuItem(value: 'N', child: Text('배달'),),
                  const DropdownMenuItem(value: 'Y', child: Text('포장'),),
                ].cast<DropdownMenuItem<String>>(),
              ),
            ),
            size: ColumnSize.S,
            numeric: true,
            fixedWidth: 130,
            // onSort: (columnIndex, ascending) =>
            //     _sort<num>((d) => d.carbs, columnIndex, ascending),
          ),
          const DataColumn2(label: Align(alignment: Alignment.centerRight, child: Text('입금')), size: ColumnSize.S, numeric: true),
          const DataColumn2(label: Align(alignment: Alignment.centerRight, child: Text('출금')), size: ColumnSize.S, numeric: true),
          const DataColumn2(label: Align(alignment: Alignment.centerRight, child: Text('금액')), size: ColumnSize.S, numeric: true),
          DataColumn2(
            label: Center(
              child: ISSearchDropdownV2(
                // label: '업체타입',
                value: selectedMemoGbn,
                onChange: (value) {
                  setState(() {
                    selectedMemoGbn = value;
                    //_query();
                  });

                  selectedPageNumber = 1;

                  requestAPIData();
                },
                item: [
                  const DropdownMenuItem(value: '%', child: Text('상태 전체'),),
                  const DropdownMenuItem(value: 'N', child: Text('운영사 취소'),),
                  const DropdownMenuItem(value: 'Y', child: Text('완료'),),
                ].cast<DropdownMenuItem<String>>(),
              ),
            ),
            size: ColumnSize.S,
            numeric: true,
            fixedWidth: 140,
            // onSort: (columnIndex, ascending) =>
            //     _sort<num>((d) => d.iron, columnIndex, ascending),
          ),
          const DataColumn2(label: Center(child: Text('상세 보기')), size: ColumnSize.S, numeric: true),
        ],
        empty: Center(child: Container(padding: const EdgeInsets.all(20), child: const Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)))),
        rows: List<DataRow>.generate(accountHistoryDataSource.rowCount, (index) => accountHistoryDataSource.getRow(index)),
      ),
    );
  }

  Widget mobileAccountHistoryData() {
    return (dataList.length! == 0)
          ? SizedBox(
            height: (widget.tabviewHeight! - 220),
            child: const Align(
                alignment: Alignment.center,
                child: Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
          )
        : ListView(
        controller: _scrollController,
        shrinkWrap: true,
        children: List.generate(
          dataList.length, (index) {
            return fluentUI.Expander(
                headerHeight: 120,
                shapeRadius: 0.0,
                contentPadding: EdgeInsets.zero,
                header: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 6),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('영업일', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                        Text(dataList[index].orderDate! ?? '', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('주문 번호', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                        Text(dataList[index].orderNo! ?? '', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('결제 구분', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                        Text(dataList[index].appPayGbnName! ?? '', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('주문 유형', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                        Text(dataList[index].packOrderYnName! ?? '', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('적립 금액', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                        Row(
                          children: [
                            Text(dataList[index].menuAmt == '--' ? '' : '${Utils.getCashComma((int.parse(dataList[index].totAmt.toString()) - int.parse(dataList[index].totalAmt.toString())).toString() ?? '')} 원',
                                style:  TextStyle(color: dataList[index].status != '40' ? Colors.black : Colors.blue, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            dataList[index].status != '40' ? Text('(운영사 취소)',style:  TextStyle(color: Colors.red,fontWeight: FONT_NORMAL,fontSize: 14,fontFamily: FONT_FAMILY),) : Container()
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                  ],
                ),
                content: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                        height: dataList[index].packOrderYn == 'Y' ? 100 : 75, // 포장할인 여부에 따라 높이 값 변경
                        color: Colors.red[50],
                        padding: const EdgeInsets.only(left: 16, right: 56),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('입금', style: TextStyle(color: Colors.red, fontSize: 14, fontWeight: FONT_BOLD)),
                            const SizedBox(height: 4,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('주문금액', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                Text('${Utils.getCashComma(dataList[index].menuAmt! ?? '')} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                              ],
                            ),
                            const SizedBox(height: 4,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('배달팁', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                Text('${Utils.getCashComma(dataList[index].deliTipAmt! ?? '')} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                              ],
                            ),
                            if (dataList[index].packOrderYn == 'Y')...[
                                const SizedBox(height: 4,),
                                Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('포장할인', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                  Text('${Utils.getCashComma(dataList[index].packDiscAmt! ?? '')} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                ],
                              )
                            ]
                          ],
                        )),
                    Container(
                        height: dataList[index].deliTotAmt != '0' ? 100 : 75,  // 만나서 결제 여부에 따라 높이 값 변경
                        color: Colors.blue[50],
                        padding: const EdgeInsets.only(left: 16, right: 56),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 5),
                            Row(
                              children: [
                                const Text('출금', style: TextStyle(color: Colors.blue, fontSize: 14, fontWeight: FONT_BOLD)),
                                const Tooltip(
                                  message: '중개 수수료 : 주문 금액의 2% (부가세 별도)\n\nPG 수수료 : 결제 금액의 2.2% (부가세 별도)',
                                  child: Icon(Icons.help_outline, color: Colors.blue,),
                                )
                              ],
                            ),
                            const SizedBox(height: 4,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('중개이용료', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                Text('${Utils.getCashComma(dataList[index].appFeeAmt! ?? '')} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                              ],
                            ),
                            const SizedBox(height: 4,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('PG 수수료', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                Text('${Utils.getCashComma(dataList[index].pgFeeAmt! ?? '')} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                              ],
                            ),
                            const SizedBox(height: 4,),
                            if (dataList[index].deliTotAmt != '0')...[
                              const SizedBox(height: 4,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('만나서 결제', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                  Text('${Utils.getCashComma(dataList[index].deliTotAmt! ?? '')} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                ],
                              )
                            ]
                          ],
                        )),
                  ],
                ));
          },
        ));
  }

  List<Widget> searchBarView() {
    return [
      ISSearchSelectDate(
        label: '기간 선택',
        width: Responsive.isMobile(context) == true ? double.infinity : 230,
        value: '${startdate.toString()} ~ ${enddate.toString()}',
        onTap: () async {
          showGeneralDialog(
              context: context,
              barrierDismissible: true,
              barrierLabel: '',
              barrierColor: Colors.black54,
              pageBuilder: (context, animation, secondaryAnimation) {
                return Dialog(
                    elevation: 0,
                    backgroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                    child: MultipleViewDateRangePicker(
                      startDate: DateTime.parse(startdate!),
                      endDate: DateTime.parse(enddate!),
                      setDateActionCallback: ({startDate, endDate}) {
                        Navigator.of(context).pop();

                        startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                        enddate = DateFormat('yyyy-MM-dd').format(endDate!);

                        selectedPageNumber = 1;

                        requestAPIData();
                      },
                    ));
              });
        },
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8,) : const SizedBox(width: 8,),
      ISToggleButtons(
        [
          ISOptionModel(value: '1000', label: '오늘'),
          ISOptionModel(value: '1001', label: '5일'),
          ISOptionModel(value: '1002', label: '7일'),
          ISOptionModel(value: '1003', label: '1개월'),
          ISOptionModel(value: '1004', label: '3개월'),
        ],
        buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 5) - 6) : 60,
        defaultValue: selectedType,
        afterOnPress: (v) {
          if (v == '1000') {
            startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1001') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 5)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1002') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 7)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1003') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 30)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1004') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 90)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }

          setState(() {
            selectedType = v.toString();
          });

          selectedPageNumber = 1;

          requestAPIData();
        },
      ),
    ];
  }
}

class AccountHistorySource extends DataTableSource {
  final BuildContext context;
  late List<AccountHistoryModel> dataSource = [];
  // Add row tap handlers and show snackbar
  bool hasRowTaps = false;
  // Override height values for certain rows
  bool hasRowHeightOverrides = false;
  // Color each Row by index's parity
  bool hasZebraStripes = false;

  int _selectedCount = 0;

  AccountHistorySource.empty(this.context, this.dataSource) {
    dataSource = [];
  }

  AccountHistorySource(this.context, this.dataSource, [sortedByValue = false, this.hasRowTaps = false, this.hasRowHeightOverrides = false, this.hasZebraStripes = false]) {
    //dataSource = dataList!;
    // if (sortedByValue) {
    //   sort((d) => d., true);
    // }
  }

  @override
  DataRow getRow(int index, [Color? color, double fontSize = 14.0, FontWeight? fontWeight = FONT_NORMAL]) {
    assert(index >= 0);
    if (index >= dataSource.length) throw 'index > dataList.length';
    final data = dataSource[index];

    // 포장할인, 만나서 결제는 조건에 따라 보이기 때문에 index 카운트를 동적으로 변경 시켜줘야함
    int _indexAdd = 0;

    if(data.packOrderYn == 'Y') {
      _indexAdd++;
    }

    if(data.deliTotAmt != '0') {
      _indexAdd++;
    }

    final cellDecoration = BoxDecoration(border: Border(bottom: BorderSide(color: !data.isChild && !data.isChild2 ? Colors.grey[200]! : Colors.transparent, width: 1)));

    return DataRow2.byIndex(
      index: index,
      // selected: data.selected,
      color: color != null
          ? MaterialStateProperty.all(color)
          : data.isChild
          ? MaterialStateProperty.all(Colors.red[50])
          : data.isChild2
          ? MaterialStateProperty.all(Colors.blue[50])
          : MaterialStateProperty.all(Colors.transparent)
      // (hasZebraStripes && index.isEven
      //     ? MaterialStateProperty.all(Theme.of(context).highlightColor)
      //     : null),
      ,
      // onSelectChanged: (value) {
      //   if (data.selected != value) {
      //     _selectedCount += value! ? 1 : -1;
      //     assert(_selectedCount >= 0);
      //     data.selected = value;
      //     notifyListeners();
      //   }
      // },

      onTap: hasRowTaps ? () => {
        data.isChild || data.isChild2
            ? null
            : data.isOpened
            ? {
              dataSource.removeRange(index + 1, index + 5 + _indexAdd),
              dataSource[index].isOpened = false
            } : {
              dataSource.insert(index + 1, AccountHistoryModel(orderDate: '입금', appPayGbnName: '주문금액', totAmt: data.menuAmt, totalAmt: '--', menuAmt: '--', isChild: true,),),
              data.packOrderYn == 'Y' ? dataSource.insert(index + 2, AccountHistoryModel(appPayGbnName: '포장할인', totAmt: data.deliTipAmt, totalAmt: '--', menuAmt: '--', isChild: true,
            ),) : const SizedBox.shrink(),
          dataSource.insert(data.packOrderYn == 'Y' ? index + 3 : index + 2, AccountHistoryModel(appPayGbnName: '배달팁', totAmt: data.deliTipAmt, totalAmt: '--', menuAmt: '--', isChild: true,),),
          dataSource.insert(data.packOrderYn == 'Y' ? index + 4 : index + 3, AccountHistoryModel(orderDate: '출금', appPayGbnName: '중개이용료', totAmt: '--', totalAmt: data.appFeeAmt, menuAmt: '--', isChild2: true,),),
          dataSource.insert(data.packOrderYn == 'Y' ? index + 5 : index + 4, AccountHistoryModel(appPayGbnName: 'PG수수료', totAmt: '--', totalAmt: data.pgFeeAmt, menuAmt: '--', isChild2: true,),),
          data.deliTotAmt != '0'
              ? dataSource.insert(data.packOrderYn == 'Y' ? index + 6 : index + 5, AccountHistoryModel(appPayGbnName: '만나서 결제', totAmt: '--', totalAmt: data.deliTotAmt, menuAmt: '--', isChild2: true,),)
              : SizedBox.shrink(),
          dataSource[index].isOpened = true
        },
        notifyListeners()
      } : null,
      specificRowHeight: hasRowHeightOverrides && (data.isChild || data.isChild2) ? 40 : null,
      cells: [
        DataCell(Container(
            padding: EdgeInsets.zero,
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  data.orderDate ?? '',
                  style: TextStyle(
                      color: !data.isChild && !data.isChild2
                          ? Colors.black
                          : data.isChild
                          ? Colors.red
                          : Colors.blue,
                      fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
                ),
                data.isChild2 && data.orderDate != null
                    ? const Tooltip(message: '중개 수수료 : 주문 금액의 2% (부가세 별도)\n\nPG 수수료 : 결제 금액의 2.2% (부가세 별도)', child: Icon(Icons.help_outline, color: Colors.blue,),)
                    : const SizedBox.shrink()
              ],
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text(data.orderNo ?? '', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text(data.appPayGbnName ?? '', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text(data.packOrderYnName ?? '', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.centerRight,
            child: Text(data.totAmt == '--' ? '' : '${Utils.getCashComma(data.totAmt ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.centerRight,
            child: Text(data.totalAmt == '--' ? '' : '${Utils.getCashComma(data.totalAmt.toString().toString() ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.centerRight,
            child: Text(data.menuAmt == '--' ? '' : '${Utils.getCashComma((int.parse(data.totAmt.toString()) - int.parse(data.totalAmt.toString())).toString() ?? '')} 원',
              style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
          decoration: cellDecoration,
          alignment: Alignment.center,
          child: !data.isChild && !data.isChild2 ? Text(data.status == '40' ? '완료' : '운영사 취소', style: TextStyle(color: data.status == '40' ? Colors.black : Colors.red, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY)) : SizedBox.shrink(),
        )),
        DataCell(
          Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: (data.isChild == true)
                ? const SizedBox.shrink()
                : Icon(
                data.isOpened == true
                    ? Icons.keyboard_arrow_up
                    : data.orderNo == null
                    ? null
                    : Icons.keyboard_arrow_down, color: Colors.black, size: 20
                ),
          ),
          // onTap: () {
          //   if (data.isOpened == true) {
          //     data.isOpened = false;
          //   } else {
          //     data.isOpened = true;
          //   }
          // },
        ),
      ],
    );
  }

  @override
  int get rowCount => dataSource.length;

  @override
  bool get isRowCountApproximate => false;

  @override
  int get selectedRowCount => _selectedCount;

  void selectAll(bool? checked) {
    for (final data in dataSource) {
      data.selected = checked ?? false;
    }
    _selectedCount = (checked ?? false) ? dataSource.length : 0;
    notifyListeners();
  }
}