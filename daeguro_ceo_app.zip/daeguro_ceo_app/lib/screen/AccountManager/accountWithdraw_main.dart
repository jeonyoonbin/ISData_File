import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/AccountManager/accountInfoModel.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class AccountWithdrawMain extends StatefulWidget {
  final double? tabviewHeight;
  const AccountWithdrawMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<AccountWithdrawMain> createState() => _AccountWithdrawMainState();
}

class _AccountWithdrawMainState extends State<AccountWithdrawMain> {

  final ScrollController _scrollController = ScrollController();

  AccountInfoModel accInfoModel = AccountInfoModel();

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(AccountController.to.getAccountInfo())
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
    else {
      accInfoModel.bankName = value['bankName'] as String;
      accInfoModel.bankCode = value['bankCode'] as String;
      accInfoModel.accountNo = value['accountNo'] as String;
      accInfoModel.accOwner = value['accOwner'] as String;
      accInfoModel.realRemainAmt = value['realRemainAmt'] as String;
      accInfoModel.remainAmt = value['remainAmt'] as String;
      accInfoModel.withdrawAmt = value['withdrawAmt'] as String;
      accInfoModel.accConfirmGbn = value['accConfirmGbn'] as String;
      accInfoModel.amtTransSmsGbn = value['amtTransSmsGbn'] as String;
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(AccountController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    accInfoModel = AccountInfoModel();

    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefreshChild == true ) {
        _appTheme.ShopRefreshChild = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
      controller: _scrollController,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 22),
        child: ISLabelBarSub(
          title: accInfoModel.bankCode =='' ? '계좌 정보를 확인하지 못했습니다.' : '출금 가능 금액이 부족합니다.',
          backgroundColor: Color(0xfff8d7da),
          titleStyle: const TextStyle(color: Color(0xff721c24), fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [

              Container(
                padding: EdgeInsets.symmetric(horizontal: Responsive.isMobile(context) == true ? 0 : 40),
                height: 320,
                child: Row(
                    children: [
                      SizedBox(
                        width: Responsive.isMobile(context) == true ? 120 : 200,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '은행명', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '계좌번호', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '예금주', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '적립금', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '입점 지원금', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '출금 가능 금액', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: const Text(textAlign: TextAlign.left, '출금 가능 시간', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                          ],
                        ),
                      ),
                      Flexible(
                        fit: FlexFit.tight,
                        flex: 3,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, getBankName(accInfoModel.bankCode!, accInfoModel.bankName!), style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, Utils.getAccountNoFormat(accInfoModel.accountNo!, false), style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, accInfoModel.accOwner ?? '', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, '${Utils.getCashComma(accInfoModel.realRemainAmt!)}원', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, '10,000원 (퇴점 시 출금 가능합니다.)', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, '${Utils.getCashComma(accInfoModel.remainAmt!)}원 (이체 수수료 200원)', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.centerLeft, height: 40, child: Text(textAlign: TextAlign.left, '01:00 ~ 22:30', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL))),
                            Container(alignment: Alignment.topLeft, height: 26, child: const Text('(22:30 ~ 01:00 은행 점검 시간입니다.)', style: TextStyle(color: Colors.redAccent, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)),
                          ],
                        ),
                      ),
                    ]
                ),
              ),
              const Divider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ISButton(
                    child: const Text('직접 출금'),
                    onPressed: () {},
                  ),
                  const SizedBox(width: 10,),
                  ISButton(
                    child: const Text('자동출금설정'),
                    onPressed: () {},
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  // "02" : "산업";
  // "03" : "기업";
  // "04" : "국민";
  // "05" : "외환";
  // "07" : "수협";
  // "08" : "수출";
  // "11" : "농협";
  // "12" : "단협";
  // "20" : "우리";
  // "23" : "SC은행";
  // "27" : "씨티";
  // "32" : "부산";
  // "34" : "광주";
  // "35" : "제주";
  // "37" : "전북";
  // "39" : "경남";
  // "71" : "우체국";
  // "81" : "KEB하나";
  // "88" : "신한";
  // "31" : "대구";
  // "50" : "상호저축";
  // "48" : "신협";
  // "45" : "새마을";
  // "89" : "K,뱅크";
  // "90" : "카카오뱅크";

  String getBankName(String bankCode, String bankName){
    String? bankNameStr;

    if (bankCode =='' || bankName == '') {
      return '';
    }

    if (bankCode == "07" || bankCode == "11" || bankCode == "12" || bankCode == "23" || bankCode == "71" || bankCode == "48" || bankCode == "89" || bankCode == "90" ) {
      return bankName;
    }
    else if (bankCode == "45") {
      return '${bankName!}금고';
    }
    else {
      return '${bankName!}은행';
    }
  }
}