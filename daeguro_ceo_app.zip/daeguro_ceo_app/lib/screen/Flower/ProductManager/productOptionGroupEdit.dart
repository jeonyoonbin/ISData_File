import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionGroupEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionGroupListModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductOptionGroupEdit extends StatefulWidget {
  final ProductOptionGroupListModel? sData;

  const ProductOptionGroupEdit({Key? key, this.sData}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ProductOptionGroupEditState();
  }
}

enum RadioUseGbn { useGbnY, useGbnN }

class ProductOptionGroupEditState extends State<ProductOptionGroupEdit> {

  ProductOptionGroupEditModel formData = ProductOptionGroupEditModel();

  bool? requireOptionState = false;

  RadioUseGbn? _radioUseGbn;

  @override
  void dispose() {
    super.dispose();
    formData = ProductOptionGroupEditModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    if (widget.sData == null){
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');

      Navigator.of(context).pop;
    }
    else{
      formData.shopCd = AuthService.SHOPCD;
      formData.optGrpCd = widget.sData!.optionGroupCd;
      formData.name = widget.sData!.name;
      formData.minCnt = widget.sData!.minCount;
      formData.multiCnt = widget.sData!.multiCount;
      formData.useGbn = widget.sData!.useGbn;
      formData.uCode = AuthService.uCode;
      formData.uName = AuthService.uName;

      _radioUseGbn = formData.useGbn == 'Y' ? RadioUseGbn.useGbnY : RadioUseGbn.useGbnN;

      if (formData.minCnt == '1' && formData.multiCnt == '1'){
        requireOptionState = true;
      }
      else if (formData.minCnt == '0' && formData.multiCnt == '99'){
        requireOptionState = false;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();//.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 360),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('옵션그룹 정보 수정', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            //const Divider(color: Colors.grey, height: 0.0,),
            const SizedBox(height: 16,),
            const Text('옵션그룹명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            const SizedBox(height: 8),
            ISInput(
              autofocus: true,
              value: formData.name ?? '',
              context: context,
              height: 64,
              //padding: 0,
              label: '옵션그룹명',
              maxLength: 25,
              onChange: (v) {
                setState(() {
                  formData.name = v;
                });
              },
            ),
            const SizedBox(height: 16),
            //const Text('옵션그룹설명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            ISLabelBarSub(
              title: '옵션 정보',
              height: 30,
              titlePadding: const EdgeInsets.only(left: 12, right: 4),
              bodyPadding: EdgeInsets.zero,
              body: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 16.0),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('사용여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                        Row(
                          children: [
                            Radio(
                                value: RadioUseGbn.useGbnY,
                                groupValue: _radioUseGbn,
                                onChanged: (v) async {
                                  _radioUseGbn = v as RadioUseGbn?;

                                  formData.useGbn = 'Y';

                                  setState(() {});
                                }),
                            const Text('사용', style: TextStyle(fontSize: 12)),
                            const SizedBox(width: 40,),
                            Radio(
                                value: RadioUseGbn.useGbnN,
                                groupValue: _radioUseGbn,
                                onChanged: (v) async {
                                  _radioUseGbn = v as RadioUseGbn?;

                                  formData.useGbn = 'N';

                                  setState(() {});
                                }),
                            const Text('미사용', style: TextStyle(fontSize: 12)),
                          ],
                        )
                      ],
                    ),
                  ],
                ),
              ),
              trailing: ISCheckbox(label: '필수 옵션', value: requireOptionState, onChanged: (v) => setState(() => requireOptionState = v!)),
            ),
          ],
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (formData.name == '' || formData.name == null) {
                ISAlert(context, content: '옵션그룹명을 확인해주세요.');
                return;
              }

              ISConfirm(context, '옵션그룹 정보 수정', '옵션그룹 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  formData.minCnt = (requireOptionState == true) ? '1' : '0';
                  formData.multiCnt = (requireOptionState == true) ? '1' : '99';

                  var value = await showDialog(
                      context: context,
                      barrierColor: Colors.transparent,
                      builder: (context) => FutureProgressDialog(ProductInfoController.to.updateProductOptionGroup(formData.toJson()))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


