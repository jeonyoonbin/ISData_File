import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionGroupNewItemModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionGroupAddModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionGroupNewItemModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionGroupNewModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductOptionGroupNew extends StatefulWidget {
  final String? optionCnt;
  const ProductOptionGroupNew({Key? key, this.optionCnt})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ProductOptionGroupNewState();
  }
}

//enum RadioRequireGbn { requireGbnY, requireGbnN }

class ProductOptionGroupNewState extends State<ProductOptionGroupNew> {

  ProductOptionGroupNewModel formData = ProductOptionGroupNewModel();

  //RadioRequireGbn? _radioRequireGbn;

  String? tempStr = '';

  bool? requireOptionState = false;

  //List<ISOptionModel> selectBox_Value = [];

  List<ProductOptionGroupNewItemModel> mOptionList = <ProductOptionGroupNewItemModel>[];

  @override
  void dispose() {
    super.dispose();
    formData = ProductOptionGroupNewModel();
    mOptionList.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    //formData.minCount = '0';
    //formData.maxCount = '0';

    // selectBox_Value = List.generate(100, (index) {
    //   return ISOptionModel(value: index.toString(), label: '${index}개');
    // });


    //_radioRequireGbn = RadioRequireGbn.requireGbnY;
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();//.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('옵션그룹 신규 등록', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //const Divider(color: Colors.grey, height: 0.0,),
                const SizedBox(height: 16,),
                const Text('옵션그룹명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                const SizedBox(height: 8),
                ISInput(
                  autofocus: true,
                  value: formData.name,
                  height: 64,
                  //padding: 0,
                  context: context,
                  label: '옵션그룹명',
                  maxLength: 25,
                  onChange: (v) {
                    setState(() {
                      formData.name = v;
                    });
                  },
                ),
                const SizedBox(height: 8),
                ISLabelBarSub(
                  title: '옵션 정보',
                  height: 30,
                  titlePadding: const EdgeInsets.only(left: 12, right: 4),
                  bodyPadding: EdgeInsets.zero,
                  body: Column(
                    children: [
                      SizedBox(
                        width: double.infinity,
                        child: DataTable(
                          headingRowHeight: 34,
                          dataRowHeight: 56.0,
                          columnSpacing: 0,
                          horizontalMargin: 8,
                          columns: const [
                            DataColumn(label: Expanded(child: Text('옵션', textAlign: TextAlign.left))),
                            DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.left))),
                            DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.right))),
                          ],
                          rows: mOptionList.map((item){
                            return DataRow(
                                cells: [
                                  DataCell(Align(alignment: Alignment.centerLeft,
                                      child: ISInput(
                                        value: item.name,
                                        textAlign: TextAlign.start,
                                        width: 160,
                                        maxLines: 1,
                                        label: AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD ? '예) 보통맛' : '예) 풍성도(대)',
                                        onChange: (v) {
                                          setState(() {
                                            item.name = v.toString();
                                          });
                                        },
                                      )
                                  )
                                  ),
                                  DataCell(Align(alignment: Alignment.centerLeft,
                                      child: Row(
                                        children: [
                                          ISInput(
                                            value: item.cost,
                                            textAlign: TextAlign.end,
                                            width: 80,
                                            maxLines: 1,
                                            label: '금액',
                                            onChange: (v) {
                                              setState(() {
                                                item.cost = v.toString();
                                              });
                                            },
                                          ),
                                          const SizedBox(width: 8,),
                                          const Text('원')
                                        ],
                                      )
                                  )
                                  ),
                                  DataCell(Align(alignment: Alignment.centerRight,
                                      child: InkWell(
                                        child: const Icon(Icons.cancel, color: Color(0xff01CAFF), size: 21),
                                        onTap: (){
                                          mOptionList.remove(item);
                                          setState(() {

                                          });
                                        },
                                      )
                                  )
                                  ),
                                ]
                            );
                          }).toList(),
                        ),
                      ),
                      const Divider(height: 0.0,),
                      ISButton(
                          width: double.infinity,
                          child: const Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.add),
                              Text('옵션 추가')
                            ],
                          ),
                          //onPressed: () => _addOptionGroup()
                          onPressed: () {
                            mOptionList.add(ProductOptionGroupNewItemModel());
                            setState(() {

                            });
                          }
                      ),
                      // SizedBox(
                      //   height: 40,
                      //   child: InkWell(
                      //     hoverColor: Colors.transparent,
                      //     highlightColor: Colors.transparent,
                      //     splashColor: Colors.transparent,
                      //     child: const Icon(Icons.add_circle_rounded, color: Color(0xff01CAFF), size: 30),
                      //     onTap: () {
                      //       mDetailList.add(OptionGroupCreateDetailModel());
                      //       setState(() {
                      //
                      //       });
                      //     },
                      //   ),
                      // ),
                    ],
                  ),
                  trailing: ISCheckbox(label: '필수 옵션', value: requireOptionState, onChanged: (v) => setState(() => requireOptionState = v!)),
                ),
                // const SizedBox(height: 8),
                // ISLabelBarSub(
                //   title: '선택 가능한 옵션 수',
                //   bodyPadding: const EdgeInsets.all(4),
                //   height: 30,
                //   body: Column(
                //     children: [
                //       Row(
                //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //         children: [
                //           const Text('필수여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                //           Row(
                //             children: [
                //               Radio(
                //                   value: RadioRequireGbn.requireGbnY,
                //                   groupValue: _radioRequireGbn,
                //                   onChanged: (v) async {
                //                     _radioRequireGbn = v as RadioRequireGbn?;
                //
                //                     setState(() {});
                //                   }),
                //               const Text('선택옵션', style: TextStyle(fontSize: 12)),
                //               const SizedBox(width: 20,),
                //               Radio(
                //                   value: RadioRequireGbn.requireGbnN,
                //                   groupValue: _radioRequireGbn,
                //                   onChanged: (v) async {
                //                     _radioRequireGbn = v as RadioRequireGbn?;
                //
                //                     setState(() {});
                //                   }),
                //               const Text('필수옵션', style: TextStyle(fontSize: 12)),
                //             ],
                //           )
                //
                //         ],
                //       ),
                //       const SizedBox(height: 8,),
                //       Row(
                //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //         children: [
                //           Text('선택 가능 수량', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                //           Row(
                //             mainAxisAlignment: MainAxisAlignment.spaceAround,
                //             crossAxisAlignment: CrossAxisAlignment.start,
                //             children: <Widget>[
                //               Row(
                //                 children: [
                //                   const Text('최소', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                //                   const SizedBox(width: 4),
                //                   ISSearchDropdown(
                //                     width: 70,
                //                     height: 40,
                //                     label: '최소 수량',
                //                     value: formData.minCount.toString(),
                //                     onChange: (value) {
                //                       setState(() {
                //                         formData.minCount = value;
                //                         //_query();
                //                       });
                //                     },
                //                     item: selectBox_Value,
                //                   ),
                //                 ],
                //               ),
                //               const SizedBox(width: 8),
                //               Row(
                //                 children: [
                //                   const Text('최대', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                //                   const SizedBox(width: 4),
                //                   ISSearchDropdown(
                //                     width: 70,
                //                     height: 40,
                //                     label: '최대 수량',
                //                     value: formData.maxCount.toString(),
                //                     onChange: (value) {
                //                       setState(() {
                //                         formData.maxCount = value;
                //                         //_query();
                //                       });
                //                     },
                //                     item: selectBox_Value,
                //                   ),
                //                 ],
                //               )
                //             ],
                //           )
                //
                //         ],
                //       ),
                //     ],
                //   ),
                //   //trailing: ,
                // ),
                const SizedBox(height: 8),
                ISLabelBarSub(title: '이 옵션그룹에는 옵션이 총 ${widget.optionCnt}개 있습니다.'),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (formData.name == '' || formData.name == null) {
                ISAlert(context, content: '옵션그룹명을 확인해주세요.');
                return;
              }

              ISConfirm(context, '옵션그룹 신규 등록', '신규 옵션그룹 정보를 등록하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  List<String> optionNameArr = [];
                  List<String> optionCostArr = [];

                  mOptionList!.forEach((element) {
                    optionNameArr.add(element.name!);
                    optionCostArr.add(element.cost!);
                  });

                  formData.shopCd = AuthService.SHOPCD;
                  formData.optionName = optionNameArr;
                  formData.optionCost = optionCostArr;
                  formData.useGbn = 'Y';

                  formData.minCnt = (requireOptionState == true) ? '1' : '0';
                  formData.multiCnt = (requireOptionState == true) ? '1' : '99';

                  formData.uCode = AuthService.uCode;
                  formData.uName = AuthService.uName;

                  var value = await showDialog(
                      context: context,
                      barrierColor: Colors.transparent,
                      builder: (context) => FutureProgressDialog(ProductInfoController.to.addProductOptionGroup(formData.toJson()))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });


            },
            child: const Text('등록', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


