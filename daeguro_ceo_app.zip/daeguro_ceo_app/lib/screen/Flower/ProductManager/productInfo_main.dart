

import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productGroupListModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productListModel.dart';
import 'package:daeguro_ceo_app/screen/Common/commonNoFlagEdit.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productListLegalEdit.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productListEdit.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productOptionLinkAdd.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestImageInfoEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const ProductInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ProductInfoMain> createState() => _ProductInfoMainState();
}

class _ProductInfoMainState extends State<ProductInfoMain> {

  static const int MODE_GROUPVIEW = 1000;
  static const int MODE_ITEMVIEW = 1001;

  int currentMode = MODE_GROUPVIEW;

  bool isGroupCategory = true;
  bool isGroupTheme = false;
  late List<bool> isGroupSelected;

  int groupCntCategory = 0;
  int groupCntTheme = 0;

  String? selectedItemName;
  String? selectedGroupGbn;
  String? selectedCatCode;

  final List<ProductGroupListModel> dataGroupList = <ProductGroupListModel>[];
  final List<ProductListModel> dataProductList = <ProductListModel>[];

  requestAPI_GroupData(String jobGbn) async {

    selectedGroupGbn = jobGbn;

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getGroupList(jobGbn))
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      //Navigator.of(context).pop;
    }
    else {
      dataGroupList.clear();

      value.forEach((element) {
        ProductGroupListModel temp = ProductGroupListModel();

        temp.code = element['code'] as String;
        temp.name = element['name'] as String;
        temp.memo = element['memo'] as String;
        temp.useGbn = element['useGbn'] as String;
        temp.sortSeq = element['sortSeq'] as String;

        dataGroupList.add(temp);
      });

      groupCntCategory = ProductInfoController.to.catogoryGroupCnt;
      groupCntTheme = ProductInfoController.to.themeGroupCnt;
    }

    setState(() {});
  }

  requestAPI_ProductData(String code) async {

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getProductList(selectedGroupGbn!, code))
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      //Navigator.of(context).pop;
    }
    else {
      dataProductList.clear();

      value.forEach((element) {
        ProductListModel temp = ProductListModel();

        temp.divName = element['divName'] as String;
        temp.prodCode = element['prodCode'] as String;
        temp.prodName = element['prodName'] as String;
        temp.cost = element['cost'] as String;
        temp.useGbn = element['useGbn'] as String;
        temp.noFlag = element['noFlag'] as String;
        temp.mainYn = element['mainYn'] as String;
        temp.discStDt = element['discStDt'] as String;
        temp.discToDt = element['discToDt'] as String;
        temp.amount = element['amount'] as String;
        temp.discAmt = element['discAmt'] as String;
        temp.discRatio = element['discRatio'] as String;
        temp.ribbonCardYn = element['ribbonCardYn'] as String;
        temp.fileName = element['fileName'] as String;
        temp.categorys = element['categorys'] as String;
        temp.thems = element['thems'] as String;
        temp.discMarkGbn = element['discMarkGbn'] as String;
        temp.catCodes = element['catCodes'] as String;
        temp.themCodes = element['themCodes'] as String;

        temp.alwaysDiscountYn = (temp.discToDt == '29991231') ? 'Y' : 'N';

        dataProductList.add(temp);
      });

      selectedCatCode = code;
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    isGroupSelected = [isGroupCategory, isGroupTheme];

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPI_GroupData('C');
    });
  }

  @override
  void dispose() {
    super.dispose();
    isGroupSelected.clear();
    dataGroupList.clear();
    dataProductList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPI_GroupData('C');
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          elevation: 1,
          shape: appTheme.cardShapStyle,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: currentMode == MODE_GROUPVIEW ? groupInfoView() : groupItemView(),
          ),
        ),
        const SizedBox(height: 4),
        currentMode == MODE_GROUPVIEW ? groupListView() : itemListView(),
      ],
    );
  }

  void _onItemListReorder(int oldIndex, int newIndex) {
    // 라이브 이벤트 진행중일때 리턴
    //if (widget.eventYn == 'Y') return;

    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final ProductListModel item = dataProductList.removeAt(oldIndex);
      dataProductList.insert(newIndex, item);

      List<String> sortDataList = [];
      dataProductList.forEach((element) {
        sortDataList.add(element.prodCode!);
      });

      _editItemListSort(sortDataList);
    });
  }

  _editItemListSort(List<String> sortDataList) async {
    String jsonData = jsonEncode(sortDataList);

    String div = isGroupCategory == true ? '5' : '6';

    await ProductInfoController.to.updateListSort(div, jsonData);

    await Future.delayed(Duration(milliseconds: 500), () {
      requestAPI_ProductData(selectedCatCode!);
    });
  }

  Widget groupInfoView(){
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
      height: 42,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              const Icon(Icons.feed_outlined, size: 20),
              const SizedBox(width: 8,),
              ToggleButtons(
                constraints: const BoxConstraints(minWidth: 160, minHeight: 40),
                borderRadius: const BorderRadius.all(Radius.circular(4)),
                isSelected: isGroupSelected,
                onPressed: (value) {
                  if (value == 0) {
                    isGroupCategory = true;
                    isGroupTheme = false;

                    requestAPI_GroupData('C');
                  } else {
                    isGroupCategory = false;
                    isGroupTheme = true;

                    requestAPI_GroupData('T');
                  }

                  setState(() {
                    isGroupSelected = [isGroupCategory, isGroupTheme];
                  });
                },
                children: [
                  Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text('카테고리 그룹 (${groupCntCategory}개)', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY))
                  ),
                  Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text('테마 그룹 (${groupCntTheme}개)', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY))
                  ),
                ],
              ),
            ],
          ),
          const SizedBox.shrink()
          // ISButton(
          //   child: const Text('그룹 추가'),
          //   onPressed: () {
          //     showDialog(
          //       context: context,
          //       barrierDismissible: true,
          //       builder: (context) => const MenuGroupEdit(),
          //     );
          //   },
          // )
        ],
      ),
      ),
    );
  }

  Widget groupItemView(){
    return SizedBox(
      height: 42,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              const Icon(Icons.feed_outlined, size: 20),
              TextButton(
                style: ButtonStyle(
                  animationDuration: const Duration(microseconds: 100),
                  overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
                  foregroundColor: MaterialStateProperty.resolveWith<Color>(
                          (Set<MaterialState> states) {
                        if (states.contains(MaterialState.hovered))
                          return Color(0xff01CAFF);

                        return Colors.grey;
                      }),
                ),
                onPressed: () {
                  currentMode = MODE_GROUPVIEW;

                  setState(() {});
                },
                child: Text(isGroupCategory == true ? '카테고리 그룹' : '테마 그룹', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
              ),
              const Text('>', style: TextStyle(fontSize: 14, color: Colors.grey, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
              Text('  ${selectedItemName!}', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
            ],
          ),
          ISButton(
            child: const Text('상품 추가'),
            onPressed: () {
              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => ProductListEdit(sData: null, catCode: selectedCatCode),
              ).then((value) async {
                if (value == true) {
                  await Future.delayed(Duration(milliseconds: 500), () {
                    requestAPI_ProductData(selectedCatCode!);
                  });
                }
              });
            },
          )
        ],
      ),
    );
  }

  Widget groupListView() {
    final appTheme = context.watch<AppTheme>();//context.watch<AppTheme>();

    return SizedBox(
      height: (widget.tabviewHeight! - (Responsive.isMobile(context) == true ? 104 : 74)),
      child: ListView(
          shrinkWrap: true,
          children: List.generate(dataGroupList.length, (index) {
            return Card(
                key: Key('$index'),
                elevation: 1,
                shape: appTheme.cardShapStyle,
                margin: const EdgeInsets.all(4),
                //color: dataGroupList[index].selected == true ? const Color.fromRGBO(165, 216, 252, 1.0) : Colors.white,
                child: InkWell(
                  //splashColor: const Color.fromRGBO(165, 216, 252, 1.0),
                  onTap: () {
                    for (var element in dataGroupList) {
                      element.selected = false;
                    }

                    dataGroupList[index].selected = true;
                    selectedItemName = dataGroupList[index].name;
                    currentMode = MODE_ITEMVIEW;

                    requestAPI_ProductData(dataGroupList[index].code!);

                    //setState(() {});
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        const SizedBox(width: 8,),
                        Flexible(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Container(
                                alignment: Alignment.topLeft,
                                child: Container(
                                    margin: const EdgeInsets.fromLTRB(10, 8, 0, 0),
                                    width: 34,
                                    height: 16,
                                    alignment: Alignment.center,
                                    decoration: AppTheme.getListBadgeDecoration(dataGroupList[index].useGbn == 'Y' ? const Color.fromRGBO(87, 170, 58, 0.8431372549019608) : const Color.fromRGBO(253, 74, 95, 0.7843137254901961)),
                                    child: Text(dataGroupList[index].useGbn == 'Y' ? '사용중' : '미사용', style: const TextStyle(fontSize: 8, color: Colors.white),)),
                              ),
                              Container(
                                padding: const EdgeInsets.only(left: 10, right: 10, top: 5),
                                alignment: Alignment.topLeft,
                                child: Text(dataGroupList[index].name ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY ),),
                              ),
                              Container(
                                padding: const EdgeInsets.only(left: 10, right: 10, top: 2, bottom: 8),
                                alignment: Alignment.topLeft,
                                child: Text(dataGroupList[index].memo ?? '--', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
          },
        )
      ),
    );
  }

  Widget itemListView() {
    final appTheme = context.watch<AppTheme>();

    return SizedBox(
      height: (widget.tabviewHeight! - (Responsive.isMobile(context) == true ? 104 : 74)),
      child: ReorderableListView(
        buildDefaultDragHandles: false,
        //scrollController: _itemListScrollController,
        //physics: const NeverScrollableScrollPhysics(),
        onReorder: _onItemListReorder,
        scrollDirection: Axis.vertical,
        padding: const EdgeInsets.only(bottom: 8.0),

        children: List.generate(dataProductList.length, (index) {
          return Card(
            key: Key('$index'),
            elevation: 1,
            shape: appTheme.cardShapStyle,
            margin: const EdgeInsets.all(4),
            //color: dataMenuList[index].selected == true ? const Color.fromRGBO(165, 216, 252, 1.0) : Colors.white,
            child: InkWell(
              //splashColor: const Color.fromRGBO(165, 216, 252, 1.0),
              onTap: () {
                showProductSelectList(index);
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: ReorderableDragStartListener(
                          index: index,
                          child: Icon(Icons.reorder, color: Colors.grey, size: 24.0,)
                      ),
                    ),
                    const SizedBox(width: 8,),
                    Card(
                      color: Colors.grey.shade200,
                      clipBehavior: Clip.antiAlias,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6.0),),
                      //elevation: 4.0, //그림자 깊이
                      //margin: const EdgeInsets.all(4),
                      child: Container(
                        //margin: const EdgeInsets.all(4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(
                              width: 104,
                              height: 80,
                              child: InkWell(
                                child: dataProductList[index].fileName == null
                                    ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 80)
                                    : Image.network('${dataProductList[index].fileName!}?tm=${Utils.getTimeStamp()}', fit: BoxFit.fitWidth, gaplessPlayback: true,
                                  errorBuilder: (context, error, stackTrace) {
                                    return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 80);
                                  },
                                ),
                                onTap: () {

                                },
                              ),
                            ),
                            Row(
                              children: [
                                SizedBox(
                                  height: 20,
                                  child: FilledButton(
                                    style: appTheme.imageButtonStyleLeft,
                                    onPressed: () {
                                      ISConfirm(context, '상품 이미지 삭제', '현재 등록되어 있는 상품 이미지를 삭제하시겠습니까?\n이미지를 변경하시려면 취소 후, [변경]버튼을 클릭해주세요.', constraints: const BoxConstraints(maxWidth: 440.0, maxHeight: 280), (context, isOK) async {
                                        Navigator.of(context).pop();

                                        if (isOK){
                                          // var value = await showDialog(
                                          //     context: context,
                                          //     builder: (context) => FutureProgressDialog(ProductController.to.updateNoFlag(formData.toJson()))
                                          // );
                                          //
                                          // if (value == null) {
                                          //   ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                                          // }
                                          // else {
                                          //   if (value == '00') {
                                          //     Navigator.of(context).pop(true);
                                          //   }
                                          //   else{
                                          //     ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                                          //   }
                                          // }
                                        }
                                      });
                                    },
                                    child: const Text('삭제', style: TextStyle(fontSize: 10, fontFamily: FONT_FAMILY)),
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                  child: FilledButton(
                                    style: appTheme.imageButtonStyleRight,
                                    onPressed: () {
                                      showDialog(
                                        context: context,
                                        barrierDismissible: true,
                                        builder: (context) => RequestImageInfoEdit(jobGbn: '3', beforeImageURL: dataProductList[index].fileName, code: dataProductList[index].prodCode, name: dataProductList[index].prodName,),
                                      ).then((value) async {
                                        if (value == true) {
                                          await Future.delayed(Duration(milliseconds: 500), () {
                                            ISAlert(context, title: '상품 이미지 정보 변경요청 완료', content: '상품 이미지 정보 변경요청이 접수되었습니다.\n\n운영사 확인 후, 2~3일내로 처리될 예정입니다.\n결과는 [변경 요청 이력]메뉴에서 확인해 주세요.', constraints: BoxConstraints(maxWidth: 360.0));
                                          });
                                        }
                                      });
                                    },
                                    child: const Text('변경', style: TextStyle(fontSize: 10, fontFamily: FONT_FAMILY)),
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 8,),
                    Flexible(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              children: [
                                dataProductList[index].useGbn == 'Y'
                                    ? Container(
                                    width: 36,
                                    height: 18,
                                    alignment: Alignment.center,
                                    decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                    child: const Center(
                                        child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                        ))
                                ) : Container(
                                    width: 36,
                                    height: 18,
                                    alignment: Alignment.center,
                                    decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                    child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                ),
                                dataProductList[index].ribbonCardYn == 'Y'
                                    ? Container(
                                  width: 44,
                                  height: 18,
                                  margin: const EdgeInsets.only(left: 2.0),
                                  alignment: Alignment.center,
                                  decoration: AppTheme.getListBadgeDecoration(Colors.blueAccent.shade100),
                                  child: const Center(child: Text('리본/카드', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                  ),
                                ) : const SizedBox.shrink(),
                                dataProductList[index].alwaysDiscountYn == 'Y'
                                    ? Container(
                                    width: 42,
                                    height: 18,
                                    margin: const EdgeInsets.only(left: 2.0),
                                    alignment: Alignment.center,
                                    decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(219, 203, 58, 1.0)),
                                    child: const Center(child: Text('계속할인', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                ) : const SizedBox.shrink(),

                                dataProductList[index].noFlag == 'Y'
                                    ? Container(
                                    width: 26,
                                    height: 18,
                                    margin: const EdgeInsets.only(left: 2.0),
                                    alignment: Alignment.center,
                                    decoration: AppTheme.getListBadgeDecoration(Colors.redAccent.shade100),
                                    child: const Center(child: Text('품절', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                ) : const SizedBox.shrink(),
                              ],
                            ),
                            const SizedBox(height: 5),
                            Text(dataProductList[index].prodName ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                            Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0),
                                  child: Text('${Utils.getCashComma(dataProductList[index].cost!)} 원', style: const TextStyle(decoration: TextDecoration.lineThrough, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0),
                                  child: Text('${Utils.getCashComma(dataProductList[index].amount!)} 원', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                                ),

                                Container(
                                    width: 36,
                                    height: 18,
                                    alignment: Alignment.center,
                                    color: Colors.red,
                                    child: Center(child: Text(dataProductList[index].discMarkGbn == '0' ? '할인' : '${dataProductList[index].discRatio}%', style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FONT_NORMAL, ),)),
                                  ),
                              ],
                            ),
                            Text('연결 카테고리: ${dataProductList[index].categorys ?? '--'}', style: const TextStyle(color: Colors.black54, fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                            Text('연결 테마: ${dataProductList[index].thems ?? '--'}', style: const TextStyle(color: Colors.black54, fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                        padding: const EdgeInsets.fromLTRB(0, 0, 16, 0),
                        child: IconButton(
                          icon: const Icon(Icons.more_horiz, size: 20),
                          color: Colors.black,
                          tooltip: '수정',
                          onPressed: () {
                            showProductSelectList(index);
                          },
                        )
                    ),
                  ],
                ),
              ),
            ),
          );
        },
        ),
      ),
    );
  }

  showProductSelectList(int index)
  {
    List<String> values = ['상품 수정', '옵션 연결', '상세 정보', '상품 품절'];//, '상품 삭제'];

    ISOptionDialog(context, const BoxConstraints(maxWidth: 260.0, maxHeight: 290/*348*/), dataProductList[index].prodName!, values, (context, selectIdx) async {
      Navigator.of(context).pop();
      if (selectIdx == 0){
        showDialog(
          context: context,
          barrierDismissible: true,
          builder: (context) => ProductListEdit(sData: dataProductList.elementAt(index), catCode: selectedCatCode),
        ).then((value) async {
          if (value == true) {
            await Future.delayed(const Duration(milliseconds: 500), () {
              requestAPI_ProductData(selectedCatCode!);
            });
          }
        });
      }
      else if (selectIdx == 1){
        showDialog(
          context: context,
          barrierDismissible: true,
          builder: (context) => ProductOptionLinkAdd(productName: dataProductList[index].prodName, productCode: dataProductList[index].prodCode),
        ).then((value) async {
          // await Future.delayed(const Duration(milliseconds: 500), () {
          //   requestAPI_ProductData(selectedCatCode!);
          // });
        });
      }
      else if (selectIdx == 2){
        showDialog(
          context: context,
          barrierDismissible: true,
          builder: (context) => ProductListLegalEdit(productCode: dataProductList[index].prodCode),
        );
      }
      else if (selectIdx == 3){
        showDialog(
          context: context,
          barrierDismissible: true,
          builder: (context) => CommonNoFlagEdit(jobGbn: 'F', subGbn: 'M', targetCd: dataProductList[index].prodCode, noFlag: dataProductList[index].noFlag),
        ).then((value) async {
          if (value == true){
            await Future.delayed(const Duration(milliseconds: 500), () {
              requestAPI_ProductData(selectedCatCode!);
            });
          }
        });
      }
      // else if (selectIdx == 4){
      //   ISConfirm(context, '삭제', '[${dataProductList[index].prodName!}]상품을 삭제합니다. \n\n계속 진행 하시겠습니까?', (context) async {
      //     Navigator.pop(context);
      //   });
      // }

    });
  }


}