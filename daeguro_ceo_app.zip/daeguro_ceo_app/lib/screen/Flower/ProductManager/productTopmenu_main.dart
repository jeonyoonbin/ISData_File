import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productListModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productTopMenuAdd.dart';
import 'package:daeguro_ceo_app/theme.dart';

import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductTopMenuInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const ProductTopMenuInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ProductTopMenuInfoMain> createState() => _ProductTopMenuInfoMainState();
}

class _ProductTopMenuInfoMainState extends State<ProductTopMenuInfoMain> {

  final List<ProductListModel> dataItemList = <ProductListModel>[];

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getProductTopMenuList())
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      //Navigator.of(context).pop;
    }
    else {
      dataItemList.clear();

      value.forEach((element) {
        ProductListModel temp = ProductListModel();

        temp.prodCode = element['prodCd'] as String;
        temp.prodName = element['prodName'] as String;
        temp.cost = element['cost'] as String;
        temp.useGbn = element['useGbn'] as String;
        temp.noFlag = element['noFlag'] as String;
        temp.mainYn = element['mainYn'] as String;
        temp.discStDt = element['discStDt'] as String;
        temp.discToDt = element['discToDt'] as String;
        temp.amount = element['amount'] as String;
        temp.discAmt = element['discAmt'] as String;
        temp.discRatio = element['discRatio'] as String;
        temp.ribbonCardYn = element['ribbonCardYn'] as String;
        temp.fileName = element['fileName'] as String;
        temp.categorys = element['categorys'] as String;
        temp.thems = element['thems'] as String;

        dataItemList.add(temp);
      });
    }

    setState(() {});
  }

  requestTopMenuRemove(String prodCd) async {
    //debugPrint('requestTopMenuRemove call');

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.removeProductTopMenu(prodCd))
    );

    if (value != '00') {
      ISAlert(context, content: '정상 등록 되지 않았습니다.\n${value} \n\n관리자에게 문의 바랍니다');
      //Navigator.of(context).pop;
    }
    else {
      requestAPIData();
    }
  }

  @override
  void initState() {
    super.initState();

    //debugPrint('initState TopMenuInfoMain');

    Get.put(ProductInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    //debugPrint('dispose TopMenuInfoMain');
    super.dispose();
    dataItemList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(Responsive.isMobile(context) ? 4 : 18),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('* 최대 6개까지 등록 가능', style: TextStyle(color: Colors.grey, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                ISButton(
                  child: const Text('대표 상품 추가'),
                  onPressed: () {
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => const ProductTopMenuAdd(),
                    ).then((v) async {
                      if (v == true) {
                        await Future.delayed(const Duration(milliseconds: 500), () {
                          requestAPIData();
                        });
                      }
                    });
                  },
                )
              ],
            ),
          ),
          //const SizedBox(height: 4),
          //const Divider(color: Colors.black,),//fluentUI.Divider(style: fluentUI.DividerThemeData(horizontalMargin: EdgeInsets.zero)),
          itemListView(),

          const Divider(height: 1)
        ],
      ),
    );
  }

  void _onItemListReorder(int oldIndex, int newIndex) {
    // 라이브 이벤트 진행중일때 리턴
    //if (widget.eventYn == 'Y') return;

    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final ProductListModel item = dataItemList.removeAt(oldIndex);
      dataItemList.insert(newIndex, item);

      List<String> sortDataList = [];
      dataItemList.forEach((element) {
        sortDataList.add(element.prodCode!);
      });

      _editItemListSort('0', sortDataList);
    });
  }

  _editItemListSort(String div, List<String> sortDataList) async {
    String jsonData = jsonEncode(sortDataList);

    //print('data set->'+jsonData);
    // await ShopController.to.updateMenuSort(div, jsonData, context);
    //
    // await Future.delayed(Duration(milliseconds: 500), () {
    //   if (div == '0')
    //     loadMenuGroupData();
    //   else if (div == '1') loadMenuListData(selectedGroupCode);
    // });
  }

  Widget itemListView() {
    final appTheme = context.watch<AppTheme>();

    return SizedBox(
        height: widget.tabviewHeight,
        child: ListView.builder(
            shrinkWrap: true,
            padding: EdgeInsets.zero,
            itemBuilder: (ctx, index){
              return Card(
                key: Key('$index'),
                elevation: 1,
                shape: appTheme.cardShapStyle,
                margin: const EdgeInsets.all(4),
                //color: dataMenuList[index].selected == true ? const Color.fromRGBO(165, 216, 252, 1.0) : Colors.white,
                child: InkWell(
                  splashColor: const Color.fromRGBO(165, 216, 252, 1.0),
                  onTap: () {
                    for (var element in dataItemList) {
                      element.selected = false;
                    }
                    // _menuGroupCd = dataGroupList[index].menuGroupCd;
                    //
                    // ShopController.to.MainCount.value = int.parse(dataGroupList[index].mainCount);
                    //
                    dataItemList[index].selected = true;
                    //
                    // loadMenuListData(dataGroupList[index].menuGroupCd, menuGroupName: dataGroupList[index].menuGroupName);
                    setState(() {});
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Responsive.isMobile(context) ? Column(children: [Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        const SizedBox(width: 8,),
                        Card(
                          color: Colors.grey.shade200,
                          clipBehavior: Clip.antiAlias,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6.0),),
                          //elevation: 4.0, //그림자 깊이
                          //margin: const EdgeInsets.all(4),
                          child: SizedBox(
                            width: 104,
                            height: 104,
                            child: dataItemList[index].fileName == null
                                ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 104)
                                : Image.network('${dataItemList[index].fileName!}?tm=${Utils.getTimeStamp()}', fit: BoxFit.fitWidth, gaplessPlayback: true,
                              errorBuilder: (context, error, stackTrace) {
                                return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 104);
                              },
                            ),
                          ),
                        ),
                        const SizedBox(width: 8,),
                        Flexible(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Row(
                                  children: [
                                    dataItemList[index].useGbn == 'Y'
                                        ? Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                        child: const Center(
                                            child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                            ))
                                    ) : Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                        child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                    ),
                                    dataItemList[index].ribbonCardYn == 'Y'
                                        ? Container(
                                        width: 44,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.blueAccent.shade100),
                                        child: const Center(child: Text('리본/카드', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                    dataItemList[index].alwaysDiscountYn == 'Y'
                                        ? Container(
                                        width: 42,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(219, 203, 58, 1.0)),
                                        child: const Center(child: Text('계속할인', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                    dataItemList[index].noFlag == 'Y'
                                        ? Container(
                                        width: 26,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.redAccent.shade100),
                                        child: const Center(child: Text('품절', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Text(dataItemList[index].prodName ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                                Row(
                                  children: [
                                    dataItemList[index].alwaysDiscountYn == 'Y'
                                        ? Padding(
                                      padding: const EdgeInsets.only(right: 8.0),
                                      child: Text('${Utils.getCashComma(dataItemList[index].cost!)} 원', style: const TextStyle(decoration: TextDecoration.lineThrough, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                    ) : const SizedBox.shrink(),

                                    Padding(
                                      padding: const EdgeInsets.only(right: 8.0),
                                      child: Text('${Utils.getCashComma(dataItemList[index].cost!)} 원', style: TextStyle(fontSize: 14, fontWeight: dataItemList[index].alwaysDiscountYn == 'Y' ? FONT_BOLD : FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                    ),

                                    dataItemList[index].alwaysDiscountYn == 'Y' ? Container(
                                      width: 36,
                                      height: 18,
                                      alignment: Alignment.center,
                                      color: Colors.red,
                                      child: Center(child: Text('${dataItemList[index].discRatio}%', style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FONT_NORMAL, ),)),
                                    ) : const SizedBox.shrink(),
                                  ],
                                ),
                                Text('연결 카테고리: ${dataItemList[index].categorys ?? '--'}', style: const TextStyle(color: Colors.black54, fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                                Text('연결 테마: ${dataItemList[index].thems ?? '--'}', style: const TextStyle(color: Colors.black54, fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),

                                const SizedBox(height: 5),
                                OutlinedButton(
                                  style: ButtonStyle(side: MaterialStateProperty.all(const BorderSide(color: Colors.red))),
                                  onPressed: () {
                                    ISConfirm(context, '대표 매뉴 해제', '해당 대표 메뉴를 해제 하시겠습니까?', (context, isOK) async {
                                      Navigator.of(context).pop();

                                      if (isOK) {
                                        requestTopMenuRemove(dataItemList[index].prodCode!);
                                      }
                                    });
                                  },
                                  child: const Text('대표 상품 해제', style: TextStyle(color: Colors.red,fontSize: 13),),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    ],
                    )
                        : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        const SizedBox(
                          width: 8,
                        ),
                        Card(
                          color: Colors.grey.shade200,
                          clipBehavior: Clip.antiAlias,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6.0),),
                          //elevation: 4.0, //그림자 깊이
                          //margin: const EdgeInsets.all(4),
                          child: SizedBox(
                            width: 104,
                            height: 104,
                            child: dataItemList[index].fileName == null
                                ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 104)
                                : Image.network(
                              '${dataItemList[index].fileName!}?tm=${Utils.getTimeStamp()}',
                              fit: BoxFit.fitWidth,
                              gaplessPlayback: true,
                              errorBuilder: (context, error, stackTrace) {
                                return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 104);
                              },
                            ),
                          ),
                        ),
                        const SizedBox(width: 8,),
                        Flexible(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Row(
                                  children: [
                                    dataItemList[index].useGbn == 'Y'
                                        ? Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                        child: const Center(
                                            child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                            ))
                                    ) : Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                        child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                    ),
                                    dataItemList[index].ribbonCardYn == 'Y'
                                        ? Container(
                                        width: 44,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.blueAccent.shade100),
                                        child: const Center(child: Text('리본/카드', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                    dataItemList[index].alwaysDiscountYn == 'Y'
                                        ? Container(
                                        width: 42,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(219, 203, 58, 1.0)),
                                        child: const Center(child: Text('계속할인', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                    dataItemList[index].noFlag == 'Y'
                                        ? Container(
                                        width: 26,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.redAccent.shade100),
                                        child: const Center(child: Text('품절', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Text(dataItemList[index].prodName ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                                Row(
                                  children: [
                                    dataItemList[index].alwaysDiscountYn == 'Y'
                                        ? Padding(
                                      padding: const EdgeInsets.only(right: 8.0),
                                      child: Text('${Utils.getCashComma(dataItemList[index].cost!)} 원', style: const TextStyle(decoration: TextDecoration.lineThrough, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                    )
                                        : const SizedBox.shrink(),
                                    Padding(
                                      padding: const EdgeInsets.only(right: 8.0),
                                      child: Text('${Utils.getCashComma(dataItemList[index].cost!)} 원', style: TextStyle(fontSize: 14, fontWeight: dataItemList[index].alwaysDiscountYn == 'Y' ? FONT_BOLD : FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                    ),
                                    dataItemList[index].alwaysDiscountYn == 'Y'
                                        ? Container(
                                      width: 36,
                                      height: 18,
                                      alignment: Alignment.center,
                                      color: Colors.red,
                                      child: Center(
                                          child: Text('${dataItemList[index].discRatio}%', style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FONT_NORMAL,),)),
                                    )
                                        : const SizedBox.shrink(),],),
                                Text('연결 카테고리: ${dataItemList[index].categorys ?? '--'}', style: const TextStyle(color: Colors.black54, fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                                Text('연결 테마: ${dataItemList[index].thems ?? '--'}', style: const TextStyle(color: Colors.black54, fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(0, 0, 30, 0),
                          child: OutlinedButton(
                            style: ButtonStyle(side: MaterialStateProperty.all(const BorderSide(color: Colors.red))),
                            onPressed: () {
                              ISConfirm(context, '대표 매뉴 해제', '해당 대표 메뉴를 해제 하시겠습니까?', (context, isOK) async {
                                Navigator.of(context).pop();

                                if (isOK){
                                  requestTopMenuRemove(dataItemList[index].prodCode!);
                                }
                              });
                            },
                            child: const Text('대표 상품 해제', style: TextStyle(color: Colors.red),),
                          ),
                        ),
                        // Padding(
                        //     padding: const EdgeInsets.fromLTRB(0, 0, 30, 0),
                        //     child: IconButton(
                        //       icon: const Icon(Icons.more_horiz, size: 20),
                        //       color: Colors.black,
                        //       tooltip: '수정',
                        //       onPressed: () {
                        //         List<String> values = ['메뉴 수정', '옵션 설정', '메뉴 품절', '메뉴 삭제'];
                        //
                        //         ISOptionDialog(context, const BoxConstraints(maxWidth: 360.0, maxHeight: 290), dataItemList[index].name!, values, (context, selectIdx) async {
                        //           debugPrint('selectIdx:${selectIdx}');
                        //           Navigator.of(context).pop();
                        //         });
                        //       },
                        //
                        //     )
                        // ),
                      ],
                    ),
                  ),
                ),
              );
            },
            itemCount: dataItemList.length
        )
    );
  }
}