import 'dart:typed_data';

import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/models/RequestManager/requestShopInfoEditModel.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class RequestController extends GetxController{
  static RequestController get to => Get.find();

  int total_count = 0;
  int total_page = 0;

  Future<List<dynamic>?> getRequireType() async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_REQUIRETYPE}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }


  Future<dynamic> getRequireList(String status, String serviceGbn, String startdate, String enddate, String page) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_REQUIRELIST}?jobGbn=1&shopCd=${AuthService.SHOPCD}&status=${status}&serviceGbn=${serviceGbn}&frDate=${startdate}&toDate=${enddate}&rows=10&page=${page}');

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['totalCnt'].toString());
      total_page = int.parse(response.data['pageCnt'].toString());

      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> setRequireService(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_REQUIRESERVICE_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  // Future<dynamic> setRequireServiceV2(dynamic data) async {
  //   final response = await DioClient().post(ServerInfo.RESTURL_REQUIRESERVICEV2_SET, data: data);
  //
  //   if (response.data['code'] != '00') {
  //     return response.data['msg'];
  //   } else
  //     return response.data['code'];
  // }

  Future<dynamic> setRequireServiceV2(RequestShopInfoEditModel data, List<PickedFile> fileResArr) async {
    var retResult;

    final accessToken = await AuthService.to.userStorage.read(key: '@user_token');

    var request = http.MultipartRequest('POST', Uri.parse('${ServerInfo.RESTURL_REQUIRESERVICEV2_SET}'));
    request.headers.addAll({
      'Content-Type' : 'multipart/form-data',
      'Authorization' : 'Bearer $accessToken'
    });
    request.fields['seq'] = data.seq!;
    request.fields['shopCd'] = data.shopCd!;
    request.fields['status'] = data.status!;
    request.fields['serviceGbn'] = data.serviceGbn!;
    request.fields['filter'] = data.filter!;
    request.fields['afterShopName'] = data.afterShopName!;
    request.fields['beforeShopName'] = data.beforeShopName!;
    request.fields['afterMobile'] = data.afterMobile!;
    request.fields['beforeMobile'] = data.beforeMobile!;
    request.fields['groupCd'] = data.groupCd!;
    request.fields['menuCd'] = data.menuCd!;
    request.fields['menuName'] = data.menuName!;
    request.fields['beforeImageUrl'] = data.beforeImageUrl!;
    request.fields['uCode'] = data.uCode!;
    request.fields['uName'] = data.uName!;

    if (fileResArr.isNotEmpty){
      for (var imageFile in fileResArr) {
        Uint8List data = await imageFile.readAsBytes();
        List<int> filebytes = data.cast();

        request.files.add(http.MultipartFile.fromBytes('formFiles', filebytes, filename: 'upload_temp.png'));
      }
    }
    else{
      List<int> filebytes = [];
      request.files.add(http.MultipartFile.fromBytes('formFiles', filebytes, filename: 'upload_temp.png'));
    }

    debugPrint('setRequireServiceV2 call check3333');

    //request.files.add(http.MultipartFile.fromBytes('formFile', data, filename: 'upload_temp.png'));

    retResult = await request.send();


    debugPrint('setRequireServiceV2 call check4444');

    return retResult;


    return null;
  }


}