import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productListEditModel.dart';
import 'package:daeguro_ceo_app/models/RequestManager/requestShopInfoEditModel.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import 'package:http/http.dart' as http;

class RequestImageInfoEdit extends StatefulWidget {
  final String? jobGbn;//1:메뉴, 3://상품
  final String? name;
  final String? code;
  final String? beforeImageURL;
  const RequestImageInfoEdit({Key? key, this.jobGbn, this.name, this.code, this.beforeImageURL})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _RequestImageInfoEditState();
  }
}

class _RequestImageInfoEditState extends State<RequestImageInfoEdit> {
  final ScrollController _scrollController = ScrollController();

  PickedFile? afterImageFile;

  String? jobTitle;

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }

  @override
  void initState() {
    super.initState();

    Get.put(RequestController());
    
    if (widget.jobGbn == '1'){
      jobTitle = '메뉴 이미지';
    }
    else if (widget.jobGbn == '3'){
      jobTitle = '상품 이미지';
    }
    else{
      jobTitle = '알수없음';
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 480.0, maxHeight: 800),
      contentPadding: const EdgeInsets.all(0.0),
      //const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text('${jobTitle} 변경', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                  const SizedBox(height: 12,),
                  Text('${jobTitle}', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Column(
                          children: [
                            const SizedBox(width: 50, child: Text('변경 전')),
                            (widget.beforeImageURL == null) ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 160, height: 160,)
                                : Image.network('${widget.beforeImageURL!}?tm=${Utils.getTimeStamp()}', fit: BoxFit.cover, gaplessPlayback: true, width: 160, height: 160,
                              errorBuilder: (context, error, stackTrace) {
                                return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 160, height: 160,);
                              },
                            )
                          ],
                        ),
                        const Icon(Icons.arrow_right, size: 70,),
                        Column(
                          children: [
                            const SizedBox(width: 50, child: Text('변경 후')),
                            (afterImageFile == null) ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 160, height: 160,)
                                : Image.network('${afterImageFile!.path}', fit: BoxFit.cover, gaplessPlayback: true, width: 160, height: 160,
                              errorBuilder: (context, error, stackTrace) {
                                return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 160, height: 160,);
                              },
                            )
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
                Container(
                  constraints: const BoxConstraints(minWidth: 210),
                  width: double.infinity,
                  alignment: Alignment.center,
                  margin: const EdgeInsets.only(top: 10.0),
                  child: InkWell(
                    child: DottedBorder(padding:const EdgeInsets.only(top: 6, bottom: 6,),
                      color: const Color(0xffDDDDDD),
                      strokeWidth: 1,
                      radius: const Radius.circular(10.0),
                      child: const ClipRRect(borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        child: Row(
                          mainAxisAlignment:MainAxisAlignment.center,
                          children: [
                            Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                            SizedBox(width: 8,),
                            Text('이미지 파일 선택', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, color: Color(0xff999999),),),
                          ],
                        ),
                      ),
                    ),
                    onTap: () async {
                      // 이미지 등록
                      ImagePicker imagePicker = ImagePicker();
                      Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                      imageFile.then((file) async {
                        afterImageFile = file;

                        setState(() {

                        });
                      });
                    },
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  //width: MediaQuery.of(context).size.width - 500,//double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  decoration: const BoxDecoration(
                      color: Color.fromARGB(255, 240, 240, 240),
                      borderRadius: BorderRadius.all(Radius.circular(10))),
                  // height: 35,
                  child: Text.rich(
                      style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, height: 2.0),
                      textAlign: TextAlign.start,
                      TextSpan(children: [
                        const TextSpan(text: '- 접수건이 폭등할 경우, 처리일이 다소 지연될 수 있습니다. (주말 제외)\n'),
                        const TextSpan(text: '- 이미지 설정은 화질 및 저작권으로 인해 운영사 심사 후 등록 처리됩니다.\n'),
                        const TextSpan(
                            text: '- ',
                            children: [
                              const TextSpan(text: '15MB ', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                              const TextSpan(text: '이하, '),
                              const TextSpan(text: 'JPG/PNG ', style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                              const TextSpan(text: '파일만 올릴 수 있습니다.\n'),
                            ]
                        ),
                        const TextSpan(
                            text: '- 대용량 파일인 경우 압축하여 대구로 고객센터 ',
                            children: [
                              const TextSpan(text: '채널톡', style: TextStyle(color: Colors.lightBlue, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                              const TextSpan(text: '으로 전송하면 됩니다.\n'),
                            ]
                        ),
                        const TextSpan(
                            text: '- SNS(네어버/인스타그램 등)에서 무단으로 캡쳐한 이미지는 ',
                            children: [
                              const TextSpan(text: '사용 불가', style: TextStyle(color: Colors.red, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                              const TextSpan(text: '합니다.\n'),
                            ]
                        ),
                        const TextSpan(
                            text: '- 그외 메뉴판 전체이미지, 음식, 이미지에 텍스트가 있으면 ',
                            children: [
                              const TextSpan(text: '사용 불가', style: TextStyle(color: Colors.red, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                              const TextSpan(text: '합니다.\n'),
                            ]
                        ),
                        const TextSpan(
                            text: '- 대구로 운영사 제공 이미지에서 다른 이미지로 변경 후 다시 기존 이미지로 ',
                            children: [
                              const TextSpan(text: '변경 불가', style: TextStyle(color: Colors.red, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                              const TextSpan(text: '합니다.'),
                            ]
                        ),
                      ]
                      )
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (afterImageFile == null){
                ISAlert(context, content: '선택된 이미지가 없습니다.\n 이미지를 선택해주세요.');
                return;
              }

              ISConfirm(context, '${jobTitle} 변경', '${jobTitle} 정보를 변경 요청하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  RequestShopInfoEditModel sendData = RequestShopInfoEditModel();
                  sendData.serviceGbn = '300';
                  sendData.shopCd = AuthService.SHOPCD;
                  sendData.status = '10';
                  sendData.menuCd = widget.code;
                  sendData.uCode = AuthService.uCode;
                  sendData.uName = AuthService.uName;

                  List<PickedFile>? imageFileList = <PickedFile>[];
                  imageFileList.add(afterImageFile!);

                  await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(RequestController.to.setRequireServiceV2(sendData, imageFileList!))
                  ).then((value) async {
                    if (value == null) {
                      ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                    }
                    else {
                      await http.Response.fromStream(value).asStream().listen((event) {
                        final result = jsonDecode(event.body) as Map<String, dynamic>;

                        String code = result['code'].toString();
                        String msg = result['msg'].toString();

                        if (code == '00'){
                          Navigator.of(context).pop(true);
                        }
                        else{
                          ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${msg} ');
                        }
                      });
                    }
                  });
                }
              });
            },
            child: const Text('변경요청', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


