import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class DashBoardController extends GetxController {
  static DashBoardController get to => Get.find();

  Future<List<dynamic>?> getShopWeeklyStat(String packOrderYn, String frDate, String toDate) async {
    dynamic qData;

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPWEEKLYSTAT}?jobGbn=120&shop_cd=${AuthService.SHOPCD}&packOrderYn=${packOrderYn}&frDate=${frDate}&toDate=${toDate}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }
}
