import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/DashBoardManager/dashboard_week_order_model.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListModel.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListRequestModel.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/screen/Common/commonPopup_main.dart';
import 'package:daeguro_ceo_app/screen/DashBoardManager/dashboardManagerController.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeDetailInfo.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/instance_manager.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class DashBoardMain extends StatefulWidget {
  const DashBoardMain({Key? key}) : super(key: key);

  @override
  State<DashBoardMain> createState() => _DashBoardMainState();
}

class _DashBoardMainState extends State<DashBoardMain> with PageMixin {
  List<DashboardWeekOrderModel> dataWeekOrderList = <DashboardWeekOrderModel>[];
  final List<NoticeListModel> dataList = <NoticeListModel>[];
  final ScrollController _scrollController = ScrollController();

  List<NoticeListModel> popupList = <NoticeListModel>[];

  static String? shopRemainAmt = '0';

  // 예약 상태 조회
  Future<bool?> requestReserAPIData() async {
    bool retValue = false;
    await ReserveController.to.getShopReserveStatus(AuthService.SHOPCD).then((value) {
      if (value == null) {
        //ISAlert(context, title: '예약 정보 조회 실패', content: '예약 정보 조회에 실패하였습니다.');
        retValue = false;
      } else {
        ReserveController.to.reserveApplyDate.value = value[0]['applyDate'];
        ReserveController.to.reservePageGbn.value = value[0]['status'];
        retValue = true;
      }
    });

    //setState(() {});

    return retValue;
  }

  Future<bool?> requestAccountAPIData() async {
    bool retValue = false;

    await AccountController.to.getAccountInfo().then((value) {

      if (value == null) {
        //ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
        retValue = false;
      }
      else {
        shopRemainAmt = value['realRemainAmt'] as String;
        //print('shopRemainAmt:${shopRemainAmt}');

        retValue = true;
      }
    });

    //setState(() {});

    return retValue;
  }

  requestNoticePopupAPIData() async {
    bool retValue = false;

    popupList.clear();

    NoticeListRequestModel requestData = NoticeListRequestModel();
    requestData.jobGbn = '11';
    requestData.osGbn = '11';
    requestData.noticeGbn = '6';
    requestData.dispGbn = 'Y';
    requestData.frDate = '';
    requestData.toDate = '';
    requestData.rows = '10';
    requestData.page = '1';

    await NoticeController.to.getNoticeList(requestData.toJson()).then((value) {
      if (value == null) {
        retValue = false;
      }
      else {
        int index = 1;
        value.forEach((element) {
          NoticeListModel temp = NoticeListModel();
          temp.rnum = index.toString();
          temp.noticeSeq = element['noticeSeq'] as String;
          temp.noticeGbn = element['noticeGbn'] as String;
          temp.dispGbn = element['dispGbn'] as String;
          temp.dispFrDate = element['dispFrDate'] as String;
          temp.dispToDate = element['dispToDate'] as String;
          temp.noticeTitle = element['noticeTitle'] as String;
          temp.noticeContents = element['noticeContents'] as String;
          temp.noticeUrl1 = element['noticeUrl1'] as String;
          temp.noticeUrl2 = element['noticeUrl2'] as String;
          temp.noticeUrl3 = element['noticeUrl3'] as String;
          temp.orderDate = element['orderDate'] as String;
          temp.insDate = element['insDate'] as String;
          temp.sortSeq = element['sortSeq'] as String;
          temp.extUrlYn = element['extUrlYn'] as String;

          //GetStorage().erase();

          String retValue = GetStorage().read('popupEnabled${temp.noticeSeq}').toString();
          String todayValue = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

          //debugPrint('[${temp.noticeSeq}]retValue:${retValue.toString()}');
          if ((retValue == null || retValue == ''  || retValue == 'null') && retValue != todayValue){
            popupList.add(temp);
          }
          else{
            if (retValue != todayValue)
              GetStorage().remove('popupEnabled${temp.noticeSeq}');
          }

          index++;
        });

        debugPrint('add popupList.length:${popupList.length}');

        retValue = true;
      }
    });

    return retValue;
    //setState(() {});
  }

  Future<bool?> requestNoticeAPIData() async {
    bool retValue = false;

    NoticeListRequestModel requestData = NoticeListRequestModel();
    requestData.jobGbn = '11';
    requestData.osGbn = '11';
    requestData.noticeGbn = '2';
    requestData.dispGbn = 'Y';
    requestData.frDate = '';
    requestData.toDate = '';
    requestData.rows = '6';
    requestData.page = '1';

    await NoticeController.to.getNoticeList(requestData.toJson()).then((value) {
      if (value == null) {
        //ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
        retValue = false;
      }
      else {
        dataList.clear();

        int index = 1;
        value.forEach((element) {
          NoticeListModel temp = NoticeListModel();
          temp.rnum = index.toString();
          temp.noticeSeq = element['noticeSeq'] as String;
          temp.noticeTitle = element['noticeTitle'] as String;
          temp.dispFrDate = element['dispFrDate'] as String;
          dataList.add(temp);

          index++;
        });

        // if (dataList.length >= 6) {
        //   dataList.removeRange(6, dataList.length);
        // }

        retValue = true;
      }
    });

    setState(() {});

    return retValue;
  }

  Future<bool?> requestDashBoardAPIData() async {
    bool retValue = false;
    dataWeekOrderList = <DashboardWeekOrderModel>[];
    dataWeekOrderList.clear();

    // 통계 합계 날짜 구분을 위한 값
    String _chkDt = '';

    DashboardWeekOrderModel tempData = DashboardWeekOrderModel();

    var date = new DateTime.now();

    await DashBoardController.to.getShopWeeklyStat('%', formatDate(DateTime(date.year, date.month, date.day - 6), [yyyy, mm, dd]), formatDate(DateTime.now(), [yyyy, mm, dd])).then((value) {
      if (value == null) {
        //ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
        retValue = false;
      } else {
        value.forEach((element) {
          // 최초 조회 데이터 tempData에 적재
          if (_chkDt == '') {
            _chkDt = element['orderDate'].toString();

            tempData.orderDate = element['orderDate'].toString();
            tempData.totCnt = int.parse(element['totCnt'].toString());
            tempData.totAmt = int.parse(element['totAmt'].toString());
            tempData.okCnt = int.parse(element['okCnt'].toString());
            tempData.okAmt = int.parse(element['okAmt'].toString());
            tempData.cancelCnt = int.parse(element['cancelCnt'].toString());
            tempData.cancelAmt = int.parse(element['cancelAmt'].toString());

            dataWeekOrderList.add(tempData);
            return;
          }

          if (element['orderDate'] != _chkDt) {
            // 이전 데이터와 날짜가 다를경우 적재 후 _tempData 갱신
            _chkDt = element['orderDate'].toString();

            dataWeekOrderList.add(tempData);
            tempData = DashboardWeekOrderModel();

            tempData.orderDate = element['orderDate'].toString();
            tempData.totCnt = int.parse(element['totCnt'].toString());
            tempData.totAmt = int.parse(element['totAmt'].toString());
            tempData.okCnt = int.parse(element['okCnt'].toString());
            tempData.okAmt = int.parse(element['okAmt'].toString());
            tempData.cancelCnt = int.parse(element['cancelCnt'].toString());
            tempData.cancelAmt = int.parse(element['cancelAmt'].toString());
          } else {
            // 이전 데이터와 날짜가 같은경우 cnt, amt 합쳐서 다음에 적재
            _chkDt = element['orderDate'].toString();

            tempData.orderDate = element['orderDate'].toString();
            tempData.totCnt = (tempData.totCnt! + int.parse(element['totCnt']));
            tempData.totAmt = (tempData.totAmt! + int.parse(element['totAmt']));
            tempData.okCnt = (tempData.okCnt! + int.parse(element['okCnt']));
            tempData.okAmt = (tempData.okAmt! + int.parse(element['okAmt']));
            tempData.cancelCnt = (tempData.cancelCnt! + int.parse(element['cancelCnt']));
            tempData.cancelAmt = (tempData.cancelAmt! + int.parse(element['cancelAmt']));
          }
        });

        // _tempData 에 마지막 값이 들어있다면 데이터 적재
        if (tempData.orderDate != null) {
          dataWeekOrderList.add(tempData);
          tempData = DashboardWeekOrderModel();
        }

        retValue = true;
      }
    });

    setState(() {});

    return retValue;
  }

  Future<bool?> getDashBoardData() async {
    var ret1 = await requestAccountAPIData();
    var ret2 = await requestNoticeAPIData();
    var ret3 = await requestDashBoardAPIData();
    var ret4 = await requestNoticePopupAPIData();
    var ret5 = await requestReserAPIData();

    debugPrint('ret1:${ret1}, ret2:${ret2}, ret3:${ret3}, ret4:${ret4}, ret5:${ret5}');

    if (ret1 == false || ret2 == false || ret3 == false || ret4 == false || ret5 == false) {
      return false;
    }

    return true;
  }

  Future<bool?> requestAPIData() async {
    bool retValue = false;


    await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(getDashBoardData())
    ).then((value) {
      if (value == true){
        retValue = true;
        setState(() {
        });
      }
      else{
        retValue = false;

      }
    });

    return retValue;
  }

  @override
  void initState() {
    super.initState();

    Get.put(AccountController());
    Get.put(DashBoardController());
    Get.put(NoticeController());
    Get.put(ReserveController());

    debugPrint('initState HomePage');

    WidgetsBinding.instance.addPostFrameCallback((c) async {
      await requestAPIData().then((value) {
        if (value == true){
          if (popupList.isNotEmpty){
            showDialog(
              context: context,
              barrierDismissible: true,
              builder: (context) => CommonPopupMain(sData: popupList),
            );
          }
        }
        else{
          ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
        }
      });
    });
  }

  @override
  void dispose() {
    debugPrint('dispose HomePage');
    dataWeekOrderList.clear();
    dataList.clear();
    _scrollController.dispose();
    popupList.clear();
    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((c) async {
          await requestAPIData().then((value) {
            if (value == true){
              if (popupList.isNotEmpty){
                showDialog(
                  context: context,
                  barrierDismissible: true,
                  builder: (context) => CommonPopupMain(sData: popupList),
                );
              }
            }
            else{
              ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
            }
          });
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    var mobileOrderContent = SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        children: [
          Container(height: 10,),
          Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  // margin: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow: [
                      BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                    ],
                  ),
                  height: 150,
                  child: _buildPanelContainer('',
                      memoGbn: false,
                      verticalCenterAlign: false,
                      horizontalStartAlign: true,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Row(
                          //   children: const [
                          //     Text('안녕하세요', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          //     Text('테스트', style: TextStyle(color: Color(0xff01CAFF), fontSize: 22, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                          //     Text('사장님.', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          //   ],
                          // ),
                          Text.rich(TextSpan(children: [
                            const TextSpan(text: '안녕하세요', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                            TextSpan(text: ' ${AuthService.SHOPNAME}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 20, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                            const TextSpan(text: ' 사장님', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          ])),
                          const SizedBox(height: 8,),
                          const Text('오늘도 행복한 하루 되시길 바랍니다.', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                        ],
                      )),
                ),
                const SizedBox(height: 10),
                Container(
                  // margin: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow: [BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),],
                  ),
                  height: 300,
                  child: _buildPanelContainer('공지 사항 >', memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: Expanded(child: getNoticeListView())),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
          Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  // margin: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow: [BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),],
                  ),
                  height: 300,
                  child: _buildPanelContainer('주간 주문 건 >', memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: _WeeklyOrderChart(300),),
                ),
                const SizedBox(height: 10),
                Container(
                  // margin: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow: [BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),],
                  ),
                  height: 300,
                  child: _buildPanelContainer('주간 매출 >', memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: _WeeklyOrderChartAmt(300),),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
          const SizedBox(height: 10,),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                // padding: const EdgeInsets.only(right: 10),
                // margin: const EdgeInsets.symmetric(horizontal: 10),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                height: 300,
                child: _buildPanelContainer('리뷰 현황 >', memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: const SizedBox.shrink()),
              ),
              const SizedBox(height: 10,),
              Container(
                // padding: const EdgeInsets.only(right: 10),
                // margin: const EdgeInsets.symmetric(horizontal: 10),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                height: 300,
                child: _buildPanelContainer('라이브 이벤트 >',
                    memoGbn: false,
                    verticalCenterAlign: true,
                    horizontalStartAlign: true,
                    child: const Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        // <p class="event-msg">금일 이벤트가 <span class="red-color">종료</span> 되었습니다.</p>
                        // <p class="event-msg2">내일 다시 만나요!</p>
                        // <div class="conbox event-going">
                        // <p class="event-tit">이벤트 시간</p>
                        // <p class="event-msg">@item.start_time.Insert(2, ":") ~ @item.end_time.Insert(2,":")</p>
                        // <p class="event-msg2">현재 이벤트가 <span class="primary-color">진행</span> 중입니다.</p>
                        SizedBox(height: 40),
                        // Row(
                        //   mainAxisAlignment: MainAxisAlignment.end,
                        //   children: const [
                        //     Text('현재 이벤트가 ', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                        //     Text('대기', style: TextStyle(color: Colors.green, fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                        //     Text(' 중입니다.', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                        //   ],
                        // ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text.rich(TextSpan(children: [
                            // TextSpan(text: '꽃배달테스트', style: TextStyle(color: Color(0xff01CAFF), fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                            // TextSpan(text: ' 사장님', style: TextStyle(fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                            TextSpan(text: '현재 이벤트가 ', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                            TextSpan(text: '대기', style: TextStyle(color: Colors.green, fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                            TextSpan(text: ' 중입니다.', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          ])),
                        ),
                        SizedBox(height: 8,),
                        Text('1일 1회 무료로 진행 가능합니다.', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                      ],
                    )),
              ),
            ],
          ),
          const SizedBox(height: 20,),
        ],
      ),
    );

    var orderContent = Column(
      children: <Widget>[
        Container(height: 20,),
        Container(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer('',
                        memoGbn: false,
                        horizontalStartAlign: false,
                        verticalCenterAlign: true,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            const Text('안녕하세요', style: TextStyle(fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                            const SizedBox(height: 8,),
                            Text.rich(TextSpan(children: [
                              TextSpan(text: '${AuthService.SHOPNAME}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                              const TextSpan(text: ' 사장님', style: TextStyle(fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                            ])),
                            const SizedBox(height: 8,),
                            const Text('오늘도 행복한 하루 되시길 바랍니다.', style: TextStyle(fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          ],
                        )),
                  ),
                  const SizedBox(width: 20,),
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer('공지 사항 >', memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: Expanded(child: getNoticeListView())),
                  ),
                ],
              ),
              const SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer('주간 주문 건 >', memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: _WeeklyOrderChart(300),),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer('주간 매출 >', memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: _WeeklyOrderChartAmt(300),),
                  ),
                ],
              ),
              const SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    // padding: const EdgeInsets.only(right: 10),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer('리뷰 현황 >', memoGbn: false, verticalCenterAlign: false, horizontalStartAlign: true, child: const SizedBox.shrink()),
                  ),
                  const SizedBox(width: 20,),
                  Container(
                    // padding: const EdgeInsets.only(right: 10),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                      ],
                    ),
                    height: 300,
                    child: _buildPanelContainer('라이브 이벤트 >', memoGbn: false, horizontalStartAlign: true, verticalCenterAlign: true,
                        child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            // <p class="event-msg">금일 이벤트가 <span class="red-color">종료</span> 되었습니다.</p>
                            // <p class="event-msg2">내일 다시 만나요!</p>
                            // <div class="conbox event-going">
                            // <p class="event-tit">이벤트 시간</p>
                            // <p class="event-msg">@item.start_time.Insert(2, ":") ~ @item.end_time.Insert(2,":")</p>
                            // <p class="event-msg2">현재 이벤트가 <span class="primary-color">진행</span> 중입니다.</p>
                            SizedBox(height: 40),
                            // Row(
                            //   mainAxisAlignment: MainAxisAlignment.end,
                            //   children: const [
                            //     Text('현재 이벤트가 ', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                            //     Text('대기', style: TextStyle(color: Colors.green, fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                            //     Text(' 중입니다.', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                            //   ],
                            // ),
                            Align(
                              alignment: Alignment.centerRight,
                              child: Text.rich(TextSpan(children: [
                                // TextSpan(text: '꽃배달테스트', style: TextStyle(color: Color(0xff01CAFF), fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                                // TextSpan(text: ' 사장님', style: TextStyle(fontSize: 32, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                                TextSpan(text: '현재 이벤트가 ', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                                TextSpan(text: '대기', style: TextStyle(color: Colors.green, fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                                TextSpan(text: ' 중입니다.', style: TextStyle(fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                              ])),
                            ),
                            SizedBox(height: 8,),
                            Text('1일 1회 무료로 진행 가능합니다.', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL),),
                          ],
                        )),
                  ),
                ],
              ),
              const SizedBox(height: 20,),
            ],
          ),
        ),
      ],
    );

    return fluentUI.ScaffoldPage.scrollable(
      header: const LayoutHeader(titleName: '사장님사이트 현황'),//SizedBox(width: double.infinity, height: 100,),//
      bottomBar: const LayoutBottom(),
      children: [
        const SizedBox(height: 16,),
        Responsive.isMobile(context) ? Column(children: shopInfoBarView(),) : Row(children: shopInfoBarView(),),
        Responsive.isMobile(context) ? mobileOrderContent : orderContent,
      ],
    );
  }

  Widget getNoticeListView() {
    return ListView.separated(
      controller: _scrollController,
      shrinkWrap: true,
      padding: EdgeInsets.zero,
      separatorBuilder: (BuildContext context, int index) { return const Divider(thickness: 1, height: 0.0,); },
      itemCount: dataList.length,
      itemBuilder: (ctx, index) {
        return Material(
          child: InkWell(
            onTap: () {
              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => NoticeDetailInfo(noticeSeq: dataList[index].noticeSeq),
              );
            },
            child: Container(
              height: 40,
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(child: Text(dataList[index].noticeTitle ?? '--', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY), overflow: TextOverflow.ellipsis,)),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Text(dataList[index].dispFrDate.toString() == null ? '--' : dataList[index].dispFrDate.toString(), style: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  List<Widget> shopInfoBarView() {
    return [
      Responsive.isMobile(context) == true ? const SizedBox(height: 8) : const SizedBox(width: 8),
      Responsive.isMobile(context) == true
          ? Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.center, children: [
        Container(
            alignment: Alignment.center,
            //padding: const EdgeInsets.symmetric(horizontal: 10),
            height: 40,
            width: 120,
            decoration: BoxDecoration(color: Color(0xff01CAFF), borderRadius: BorderRadius.circular(10)),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('영업중', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON),),
                SizedBox(width: 8,),
                Icon(Icons.wb_sunny_outlined, color: Colors.white, size: 22,)
              ],
            )),
        TextButton(
          style: ButtonStyle(
            animationDuration: const Duration(microseconds: 100),
            overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
            foregroundColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) {
              if (states.contains(MaterialState.hovered)) {
                return const Color(0xff01CAFF);
              }
              return Colors.black; //Colors.white;
            }),
          ),
          onPressed: () {
            Utils.launchURL('https://m.daeguromall.com');
          },
          child: const Text('> 대구로몰 이동하기', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
        ),
      ])
          : const SizedBox.shrink(),
      Responsive.isMobile(context) == true ? const SizedBox(height: 22) : const SizedBox.shrink(),
      Row(
        children: [
          const Text('현재 적립된 금액은 ', style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
          Text('${Utils.getCashComma(shopRemainAmt!)}', style: const TextStyle(color: Color(0xff01CAFF), fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
          const Text('원 입니다.', style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
        ],
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 12) : const SizedBox(width: 12),
      // ISButton(
      //   //buttonColor: Colors.black,
      //   isReverseColor: true,
      //   width: Responsive.isMobile(context) == true ? double.infinity : 64,
      //   child: const Text(
      //     '적립내역',
      //     style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON),
      //   ),
      //   onPressed: () {},
      // ),
      // Responsive.isMobile(context) == true ? const SizedBox(height: 8) : const SizedBox(width: 8),
      // ISButton(
      //   width: Responsive.isMobile(context) == true ? double.infinity : 64,
      //   child: const Text(
      //     '출금하기',
      //     style: TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON),
      //   ),
      //   onPressed: () {},
      // ),
    ];
  }

  // double getPanelWidth(){
  //   double nWidth = 0.0;
  //
  //   final _media = MediaQuery.of(context).size;
  //
  //   if (Responsive.isDesktop(context) == true)        nWidth = 400;
  //   else if (Responsive.isTablet(context) == true)    nWidth = 210;
  //   else if (Responsive.isMobile(context) == true)    nWidth = 130;
  //
  //   return nWidth;
  // }

  // Container _buildShopTitlePanelContainer(String title, {Widget? child, double? width, double? height, bool? memoGbn, bool? centerAlignEnable,})
  // {
  //   double nWidth = 0.0;
  //
  //   if (Responsive.isDesktop(context) == true) {
  //     nWidth = (MediaQuery.of(context).size.width - 308) / 2;
  //   } else if (Responsive.isTablet(context) == true) {
  //     nWidth = (MediaQuery.of(context).size.width - 118) / 2;
  //   } else if (Responsive.isMobile(context) == true) {
  //     nWidth = MediaQuery.of(context).size.width - 30;
  //   }
  //
  //   return Container(
  //     padding: const EdgeInsets.only(left: 16.0, right: 16.0, top: 16.0),
  //     width: nWidth,
  //     height: height ?? (MediaQuery.of(context).size != null ? MediaQuery.of(context).size.height / 4.4 : height),
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.end,
  //       children: <Widget>[
  //         Padding(
  //           padding: const EdgeInsets.only(left: 5),
  //           child: Column(
  //             crossAxisAlignment: CrossAxisAlignment.start,
  //             children: [
  //               Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY, fontSize: 17.0,),),
  //               if (memoGbn == true) const Text('※ 전일 자정까지의 집계 데이터입니다.', style: TextStyle(color: Color(0xff666666), fontSize: 12)),
  //             ],
  //           ),
  //         ),
  //         if (child != null) ...[
  //           SizedBox(height: centerAlignEnable == true ? 40.0 : 10.0),
  //           child
  //           //Responsive.isMobile(context) ? SizedBox(height: height ?? 250, child: child) : child,
  //         ]
  //       ],
  //     ),
  //   );
  // }

  Container _buildPanelContainer(String title, {Widget? child, double? width, double? height, bool? memoGbn, bool? verticalCenterAlign, bool? horizontalStartAlign})
  {
    double nWidth = 0.0;

    if (Responsive.isDesktop(context) == true) {
      nWidth = (MediaQuery.of(context).size.width - 308) / 2;
    } else if (Responsive.isTablet(context) == true) {
      nWidth = (MediaQuery.of(context).size.width - 118) / 2;
    } else if (Responsive.isMobile(context) == true) {
      nWidth = MediaQuery.of(context).size.width - 30;
    }

    return Container(
      padding: const EdgeInsets.only(left: 16.0, right: 16.0, top: 16.0),
      width: nWidth,
      height: height ?? (MediaQuery.of(context).size != null ? MediaQuery.of(context).size.height / 4.4 : height),
      child: Column(
        crossAxisAlignment: horizontalStartAlign == true ? CrossAxisAlignment.start : CrossAxisAlignment.end,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left: 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontFamily: FONT_FAMILY,
                    fontSize: 17.0,
                  ),
                ),
                if (memoGbn == true) const Text('※ 전일 자정까지의 집계 데이터입니다.', style: TextStyle(color: Color(0xff666666), fontSize: 12)),
              ],
            ),
          ),
          if (child != null) ...[
            SizedBox(height: verticalCenterAlign == true ? 40.0 : 10.0),
            child
            //Responsive.isMobile(context) ? SizedBox(height: height ?? 250, child: child) : child,
          ]
        ],
      ),
    );
  }

  Widget _WeeklyOrderChart(double height) {
    return SizedBox(
      height: height - 55,
      //color: Colors.yellow,
      child: SfCartesianChart(
          selectionType: SelectionType.series,
          isTransposed: false,
          selectionGesture: ActivationMode.none,
          //.singleTap,
          primaryXAxis: CategoryAxis(
            isVisible: true,
            opposedPosition: false,
            isInversed: false,
            // labelStyle: TextStyle(fontFamily: 'Roboto'),
          ),
          primaryYAxis: NumericAxis(
            decimalPlaces: 0,
            numberFormat: NumberFormat("#,###", "en_US"),
            title: AxisTitle(
              text: '건수',
              textStyle: const TextStyle(fontFamily: FONT_FAMILY, color: Colors.black87, fontSize: 10),
            ),
          ),
          axes: <ChartAxis>[
            NumericAxis(
                name: 'xAxis',
                opposedPosition: true,
                interval: 1,
                minimum: 0,
                maximum: 5,
                labelStyle: const TextStyle(
                  fontFamily: FONT_FAMILY,
                )),
            NumericAxis(name: 'yAxis', opposedPosition: true, labelStyle: const TextStyle(fontFamily: FONT_FAMILY))
          ],
          legend: Legend(
            isVisible: true,
            toggleSeriesVisibility: true,
            position: LegendPosition.bottom,
            overflowMode: LegendItemOverflowMode.wrap,
            alignment: ChartAlignment.center,
            // legendItemBuilder: (String name, dynamic series, dynamic point, int index) {
            //   debugPrint(series.isVisible);
            //
            //   return SizedBox(
            //       width: 87,
            //       child: Row(children: <Widget>[
            //         SizedBox(
            //             child: Icon(
            //               Icons.bar_chart,
            //               color: series.color,
            //             )),
            //         const SizedBox(
            //           width: 1,
            //         ),
            //         Text(series.name),
            //       ]));
            // },
            textStyle: const TextStyle(
              fontFamily: FONT_FAMILY,
              fontSize: 10,
            ),
          ),
          crosshairBehavior: CrosshairBehavior(
            lineType: CrosshairLineType.horizontal,
            enable: true,
            shouldAlwaysShow: false,
            activationMode: ActivationMode.singleTap, //.singleTap,
          ),
          tooltipBehavior: TooltipBehavior(
            enable: true,
            shared: true,
            activationMode: ActivationMode.singleTap,
            textStyle: TextStyle(fontSize: 12, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
          ),
          series: <CartesianSeries>[
            SplineSeries<DashboardWeekOrderModel, String>(
              color: const Color(0xff49A4ED),
              name: '총 건수',
              splineType: SplineType.natural,
              dataSource: dataWeekOrderList,
              legendIconType: LegendIconType.horizontalLine,
              xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
              yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.totCnt.toString()),
              dataLabelSettings: const DataLabelSettings(
                  isVisible: false,
                  labelPosition: ChartDataLabelPosition.outside,
                  textStyle: TextStyle(
                    fontFamily: FONT_FAMILY,
                    fontSize: 11,
                    color: Colors.white,
                  ),
                  color: Color(0xff49A4ED),
                  labelAlignment: ChartDataLabelAlignment.outer),
              //Modify data points (show circles)
              markerSettings: const MarkerSettings(isVisible: true),
              //yAxisName: 'yAxis'
            ),
            SplineSeries<DashboardWeekOrderModel, String>(
              color: const Color(0xff8146e7),
              name: '취소건수',
              splineType: SplineType.natural,
              dataSource: dataWeekOrderList,
              legendIconType: LegendIconType.horizontalLine,
              xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
              yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.cancelCnt.toString()),
              dataLabelSettings: const DataLabelSettings(
                  isVisible: false,
                  labelPosition: ChartDataLabelPosition.outside,
                  textStyle: TextStyle(
                    fontFamily: FONT_FAMILY,
                    fontSize: 11,
                    color: Colors.white,
                  ),
                  color: Color(0xffFFA00E),
                  labelAlignment: ChartDataLabelAlignment.bottom),
              //Modify data points (show circles)
              markerSettings: const MarkerSettings(isVisible: true),
              //yAxisName: 'yAxis'
            ),
            SplineSeries<DashboardWeekOrderModel, String>(
              color: const Color(0xffFFA00E),
              name: '완료건수',
              splineType: SplineType.natural,
              dataSource: dataWeekOrderList,
              legendIconType: LegendIconType.horizontalLine,
              xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
              yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.okCnt.toString()),
              dataLabelSettings: const DataLabelSettings(
                  isVisible: false,
                  labelPosition: ChartDataLabelPosition.outside,
                  textStyle: TextStyle(
                    fontFamily: FONT_FAMILY,
                    fontSize: 11,
                    color: Colors.white,
                  ),
                  color: Color(0xffFFA00E),
                  labelAlignment: ChartDataLabelAlignment.bottom),
              //Modify data points (show circles)
              markerSettings: const MarkerSettings(isVisible: true),
              //yAxisName: 'yAxis'
            )
          ]),
    );
  }

  Widget _WeeklyOrderChartAmt(double height) {
    return SizedBox(
      height: height - 55,
      //color: Colors.yellow,
      child: SfCartesianChart(
          selectionType: SelectionType.series,
          isTransposed: false,
          selectionGesture: ActivationMode.none,
          //.singleTap,
          primaryXAxis: CategoryAxis(
            isVisible: true,
            opposedPosition: false,
            isInversed: false,
            // labelStyle: TextStyle(fontFamily: 'Roboto'),
          ),
          primaryYAxis: NumericAxis(
            decimalPlaces: 0,
            numberFormat: NumberFormat("#,###", "en_US"),
            title: AxisTitle(
              text: '건수',
              textStyle: const TextStyle(fontFamily: FONT_FAMILY, color: Colors.black87, fontSize: 10),
            ),
          ),
          axes: <ChartAxis>[
            NumericAxis(
                name: 'xAxis',
                opposedPosition: true,
                interval: 1,
                minimum: 0,
                maximum: 5,
                labelStyle: const TextStyle(
                  fontFamily: FONT_FAMILY,
                )),
            NumericAxis(name: 'yAxis', opposedPosition: true, labelStyle: const TextStyle(fontFamily: FONT_FAMILY))
          ],
          legend: Legend(
            isVisible: true,
            toggleSeriesVisibility: true,
            position: LegendPosition.bottom,
            overflowMode: LegendItemOverflowMode.wrap,
            alignment: ChartAlignment.center,
            textStyle: const TextStyle(
              fontFamily: FONT_FAMILY,
              fontSize: 10,
            ),
          ),
          crosshairBehavior: CrosshairBehavior(
            lineType: CrosshairLineType.horizontal,
            enable: true,
            shouldAlwaysShow: false,
            activationMode: ActivationMode.singleTap, //.singleTap,
          ),
          tooltipBehavior: TooltipBehavior(
            enable: true,
            shared: true,
            activationMode: ActivationMode.singleTap,
            textStyle: TextStyle(fontSize: 12, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
          ),
          series: <CartesianSeries>[
            SplineSeries<DashboardWeekOrderModel, String>(
              color: const Color(0xff49A4ED),
              name: '총 매출액',
              splineType: SplineType.natural,
              dataSource: dataWeekOrderList,
              legendIconType: LegendIconType.horizontalLine,
              xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
              yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.totAmt.toString()),
              dataLabelSettings: const DataLabelSettings(
                  isVisible: false,
                  labelPosition: ChartDataLabelPosition.outside,
                  textStyle: TextStyle(
                    fontFamily: FONT_FAMILY,
                    fontSize: 11,
                    color: Colors.white,
                  ),
                  color: Color(0xff49A4ED),
                  labelAlignment: ChartDataLabelAlignment.outer),
              //Modify data points (show circles)
              markerSettings: const MarkerSettings(isVisible: true),
              //yAxisName: 'yAxis'
            ),
            SplineSeries<DashboardWeekOrderModel, String>(
              color: const Color(0xff8146e7),
              name: '취소 금액',
              splineType: SplineType.natural,
              dataSource: dataWeekOrderList,
              legendIconType: LegendIconType.horizontalLine,
              xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
              yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.cancelAmt.toString()),
              dataLabelSettings: const DataLabelSettings(
                  isVisible: false,
                  labelPosition: ChartDataLabelPosition.outside,
                  textStyle: TextStyle(
                    fontFamily: FONT_FAMILY,
                    fontSize: 11,
                    color: Colors.white,
                  ),
                  color: Color(0xffFFA00E),
                  labelAlignment: ChartDataLabelAlignment.bottom),
              //Modify data points (show circles)
              markerSettings: const MarkerSettings(isVisible: true),
              //yAxisName: 'yAxis'
            ),
            SplineSeries<DashboardWeekOrderModel, String>(
              color: const Color(0xffFFA00E),
              name: '실 매출액',
              splineType: SplineType.natural,
              dataSource: dataWeekOrderList,
              legendIconType: LegendIconType.horizontalLine,
              xValueMapper: (DashboardWeekOrderModel charts, _) => '${charts.orderDate.toString().substring(4, 6)}-${charts.orderDate.toString().substring(6, 8)}',
              yValueMapper: (DashboardWeekOrderModel charts, _) => int.parse(charts.okAmt.toString()),
              dataLabelSettings: const DataLabelSettings(
                  isVisible: false,
                  labelPosition: ChartDataLabelPosition.outside,
                  textStyle: TextStyle(
                    fontFamily: FONT_FAMILY,
                    fontSize: 11,
                    color: Colors.white,
                  ),
                  color: Color(0xffFFA00E),
                  labelAlignment: ChartDataLabelAlignment.bottom),
              //Modify data points (show circles)
              markerSettings: const MarkerSettings(isVisible: true),
              //yAxisName: 'yAxis'
            )
          ]),
    );
  }
}