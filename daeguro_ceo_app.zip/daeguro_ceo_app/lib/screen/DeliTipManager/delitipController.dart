import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:get/get.dart';

class DeliTipController extends GetxController{
  static DeliTipController get to => Get.find();

  Future<List<dynamic>?> getDongData(String sido, String gungu) async {
    List<dynamic> qDataAddrDongList = [];

    qDataAddrDongList.clear();

    final response = await DioClient().get('${ServerInfo.REST_URL_DONG_CODE}/$sido/$gungu');

    if (response.data['code'] == '00') {
      qDataAddrDongList.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qDataAddrDongList;
  }

  Future<List<dynamic>?> getDeliTipSectorList() async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_DELITIPSECTORLIST}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> setDeliTipSectorInfo(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_DELITIPSECTOR_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }

  Future<List<dynamic>?> getShopTipAmt(String jobGbn, String tipGbn) async {
    List<dynamic> qDataAddrDongList = [];

    qDataAddrDongList.clear();

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPTIPAMT}?jobGbn=${jobGbn}&shopCd=${AuthService.SHOPCD}&tipGbn=${tipGbn}');

    if (response.data['code'] == '00') {
      qDataAddrDongList.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qDataAddrDongList;
  }

  Future<dynamic> setShopTipAmt(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_SHOPTIPAMT_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return response.data['code'];
  }
}