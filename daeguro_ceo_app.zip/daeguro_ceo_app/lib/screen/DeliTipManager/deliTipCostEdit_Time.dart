import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipAmtEditModel.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/delitipController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class DeliTipCost_TimeEdit extends StatefulWidget {
  final String? jobGbn;
  final String? tipSeq;
  final String? tipDay;
  final String? tipFrStand;
  final String? tipToStand;
  final String? tipAmt;

  const DeliTipCost_TimeEdit({Key? key, this.jobGbn, this.tipSeq, this.tipDay, this.tipFrStand, this.tipToStand, this.tipAmt}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return DeliTipCost_TimeEditState();
  }
}

class DeliTipCost_TimeEditState extends State<DeliTipCost_TimeEdit> {

  List<bool> tipAmtTime_DayState = [false, false, false, false, false, false, false, false, false, false];

  DateTime? tipAmtTime_startDate;
  DateTime? tipAmtTime_endDate;
  String? tipAmtTime_tipNextDay = 'N';

  String? inputTipAmt = '0';

  requestAPIData() async {
    setState(() {});
  }

  requestAPI_SetData(DeliTipAmtEditModel sendData) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(DeliTipController.to.setShopTipAmt(sendData.toJson()))
    );

    if (value == null) {
      ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
    else {
      if (value == '00') {
        Navigator.of(context).pop(true);
      }
      else{
        ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
      }
    }
  }

  @override
  void initState() {
    super.initState();

    Get.put(DeliTipController());

    if (widget.jobGbn == '1') {
      DateTime tempDateTime = DateTime.now();
      tipAmtTime_startDate = DateTime(tempDateTime.year, tempDateTime.month, tempDateTime.day, 13, 0);
      tipAmtTime_endDate = DateTime(tempDateTime.year, tempDateTime.month, tempDateTime.day, 15, 0);
    }
    else{
      int dayIndex = int.parse(widget.tipDay!);
      if (dayIndex == 1)           tipAmtTime_DayState[6] = true;
      else                         tipAmtTime_DayState[dayIndex-2] = true;

      DateTime tempDateTime = DateTime.now();
      int tempHour = 0;
      int tempMin = 0;

      tempHour = int.parse(widget.tipFrStand!.substring(0,2));
      tempMin = int.parse(widget.tipFrStand!.substring(2,4));
      tipAmtTime_startDate = DateTime(tempDateTime.year, tempDateTime.month, tempDateTime.day, tempHour, tempMin);

      tempHour = int.parse(widget.tipToStand!.substring(0,2));
      tempMin = int.parse(widget.tipToStand!.substring(2,4));
      tipAmtTime_endDate = DateTime(tempDateTime.year, tempDateTime.month, tempDateTime.day, tempHour, tempMin);

      inputTipAmt = widget.tipAmt;
    }

    WidgetsBinding.instance.addPostFrameCallback((c) {

    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 460),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text(widget.jobGbn == '1' ? '주문 시간대별 배달팁 추가' : '주문 시간대별 배달팁 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ISLabelBarSub(
                title: '요일',
                bodyPadding: EdgeInsets.zero,
                body: Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 8.0,
                  children: [
                    ISCheckbox(label: '월', value: tipAmtTime_DayState[0], onChanged: (v) => setState(() => tipAmtTime_DayState[0] = v!)),
                    ISCheckbox(label: '화', value: tipAmtTime_DayState[1], onChanged: (v) => setState(() => tipAmtTime_DayState[1] = v!)),
                    ISCheckbox(label: '수', value: tipAmtTime_DayState[2], onChanged: (v) => setState(() => tipAmtTime_DayState[2] = v!)),
                    ISCheckbox(label: '목', value: tipAmtTime_DayState[3], onChanged: (v) => setState(() => tipAmtTime_DayState[3] = v!)),
                    ISCheckbox(label: '금', value: tipAmtTime_DayState[4], onChanged: (v) => setState(() => tipAmtTime_DayState[4] = v!)),
                    ISCheckbox(label: '토', value: tipAmtTime_DayState[5], onChanged: (v) => setState(() => tipAmtTime_DayState[5] = v!)),
                    ISCheckbox(label: '일', value: tipAmtTime_DayState[6], onChanged: (v) => setState(() => tipAmtTime_DayState[6] = v!)),
                  ],
                ),
                trailing: null,
              ),
              const Divider(height: 1),

              ISLabelBarSub(
                title: '적용 시간',
                body: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('   시작시간', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                        const SizedBox(height: 4,),
                        SizedBox(
                          width: 190,
                          child: fluentUI.TimePicker(
                            selected: tipAmtTime_startDate,
                            onChanged: (time) {
                              setState(() {
                                tipAmtTime_startDate = time;

                                tipAmtTime_tipNextDay = (tipAmtTime_startDate!.hour > tipAmtTime_endDate!.hour) ? 'Y' : 'N';
                              });
                            },
                            hourFormat: HourFormat.HH,
                            minuteIncrement: 5,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Text('   종료시간', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                            if (tipAmtTime_tipNextDay == 'Y')
                              const Text('  [다음날]', style: TextStyle(fontSize: 12, color: Colors.blueAccent, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                          ],
                        ),
                        const SizedBox(height: 4,),
                        SizedBox(
                          width: 190,
                          child: fluentUI.TimePicker(
                            selected: tipAmtTime_endDate,
                            onChanged: (time) {
                              setState(() {
                                tipAmtTime_endDate = time;

                                tipAmtTime_tipNextDay = (tipAmtTime_startDate!.hour > tipAmtTime_endDate!.hour) ? 'Y' : 'N';
                              });
                            },
                            hourFormat: HourFormat.HH,
                            minuteIncrement: 5,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                trailing: null,
              ),
              ISLabelBarSub(
                title: '배달팁',
                bodyPadding: const EdgeInsets.only(top: 15, left: 15, right: 15),
                body: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Material(
                      color: Colors.transparent,
                      child: ISInput(
                        value: Utils.getCashComma(inputTipAmt!),
                        width: 120,
                        textAlign: TextAlign.end,
                        label: '금액',
                        keyboardType: TextInputType.number,
                        inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                        onChange: (v) {
                          setState(() {
                            inputTipAmt = v.toString().replaceAll(',', '');
                          });
                        },
                      ),
                    ),
                    const SizedBox(width: 8,),
                    const Text('원', style: TextStyle(fontSize:16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                  ],
                ),
                trailing: null,
              ),
            ],
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              if (tipAmtTime_tipNextDay == '' || tipAmtTime_tipNextDay == '0'){
                ISAlert(context, content: '배달팁을 확인해주세요.');
                return;
              }

              int ret = tipAmtTime_DayState.indexWhere((element) => element == true);
              if (ret == -1){
                ISAlert(context, content: '요일을 선택해주세요.');
                return;
              }

              DeliTipAmtEditModel sendData = DeliTipAmtEditModel();
              sendData.shopCd = AuthService.SHOPCD;

              List<String> sendjobGbn = [];
              List<String> sendtipSeq = [];
              List<String> sendtipGbn= [];
              List<String> sendtipDay = [];
              List<String> sendtipFrStand = [];
              List<String> sendtipToStand = [];
              List<String> sendtipAmt = [];
              List<String> sendtipNextDay = [];

              String tempStartDate = formatDate(tipAmtTime_startDate!, [HH, ':', nn]).replaceAll(':', '');
              String tempEndDate = formatDate(tipAmtTime_endDate!, [HH, ':', nn]).replaceAll(':', '');

              int index = 0;
              tipAmtTime_DayState.forEach((element) {
                if (element == true){
                  sendjobGbn.add(widget.jobGbn == '1' ? 'I' : 'U');
                  sendtipSeq.add(widget.jobGbn == '1' ? '' : widget.tipSeq!);
                  sendtipGbn.add('7');

                  int tempTipDay = index+2;
                  if (index == 6) {
                    tempTipDay = 1;
                  }

                  sendtipDay.add(tempTipDay.toString());
                  sendtipFrStand.add(tempStartDate);
                  sendtipToStand.add(tempEndDate);
                  sendtipAmt.add(inputTipAmt!);
                  sendtipNextDay.add(tipAmtTime_tipNextDay!);
                }

                index++;
              });              

              sendData.jobGbn = sendjobGbn;
              sendData.tipSeq = sendtipSeq;
              sendData.tipGbn = sendtipGbn;
              sendData.tipDay = sendtipDay;
              sendData.tipFrStand = sendtipFrStand;
              sendData.tipToStand = sendtipToStand;
              sendData.tipAmt = sendtipAmt;

              sendData.uCode = AuthService.uCode;
              sendData.uName = AuthService.uName;

              requestAPI_SetData(sendData);
            },
            child: Text(widget.jobGbn == '1' ? '등록' : '적용', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


