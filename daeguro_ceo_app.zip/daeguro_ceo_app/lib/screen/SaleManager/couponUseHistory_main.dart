import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown_v2.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/AccountManager/accountHistoryModel.dart';
import 'package:daeguro_ceo_app/models/SaleManager/couponUseHistoryListModel.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:data_table_2/data_table_2.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class CouponUseHistoryMain extends StatefulWidget {
  final double? tabviewHeight;
  const CouponUseHistoryMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<CouponUseHistoryMain> createState() => _CouponUseHistoryMainState();
}

class _CouponUseHistoryMainState extends State<CouponUseHistoryMain> {
  List<CouponUseHistoryListModel> dataList = <CouponUseHistoryListModel>[];
  final ScrollController _scrollController = ScrollController();

  late CouponUseHistorySource couponUseHistoryDataSource;
  bool _initialized = false;

  String? searchDate = '30';
  String? searchOrderNo = '';
  String? searchPackOrderGbn = '%';

  String? startdate = '';
  String? enddate = '';

  int selectedPageNumber = 1;
  int totalPage = 0;

  int? totalDeposit;
  int? totalWithdraw;
  int? totalReward;

  requestAPIData() async {
    debugPrint('requestAPIData call!!!');

    debugPrint('searchPackOrderGbn:${searchPackOrderGbn!}, searchOrderNo:${searchOrderNo!}, startdate:${startdate!.replaceAll('-', '')}, enddate:${enddate!.replaceAll('-', '')}, selectedPageNumber:${selectedPageNumber.toString()}');

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(CouponController.to.getCouponUseList(searchPackOrderGbn!, searchOrderNo!, startdate!.replaceAll('-', ''), enddate!.replaceAll('-', ''), selectedPageNumber.toString()))
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        CouponUseHistoryListModel temp = CouponUseHistoryListModel();

        temp.rNum = element['rNum'] as String;
        temp.couponName = element['couponName'] as String;
        temp.applyGbn = element['applyGbn'] as String;
        temp.applyGbnName = element['applyGbnName'] as String;
        temp.couponAmt = element['couponAmt'] as String;
        temp.useDate = element['useDate'] as String;
        temp.orderNo = element['orderNo'] as String;
        temp.custNickName = element['custNickName'] as String;

        dataList.add(temp);
      });

      totalPage = CouponController.to.total_page;

      totalDeposit = CouponController.to.totalDeposit;
      totalWithdraw = CouponController.to.totalWithdraw;
      totalReward = CouponController.to.totalReward;

      debugPrint('requestAPIData selectedPageNumber:${selectedPageNumber}, total_page:${totalPage}');
    }

    setState(() {});
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      couponUseHistoryDataSource = CouponUseHistorySource(context, dataList, false, true, true, false);
      // Default sorting sample. Set __sortColumnIndex to 0 and uncoment the lines below
      // if (_sortColumnIndex == 0) {
      //   _sort<String>((d) => d.name, _sortColumnIndex!, _sortAscending);
      // }
      _initialized = true;
      couponUseHistoryDataSource.addListener(() {
        setState(() {});
      });
    }
  }

  @override
  void dispose() {
    dataList.clear();
    _scrollController.dispose();
    couponUseHistoryDataSource.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    debugPrint('initState couponUseHistory');

    Get.put(CouponController());

    // 날짜필터
    startdate = formatDate(DateTime.now().subtract(const Duration(days: 30)), [yyyy, '-', mm, '-', dd]);
    enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    //return Responsive.isMobile(context) ? mobileCouponUseHistoryWidget() : CouponUseHistoryWidget();
    return SingleChildScrollView(
      child: Column(
        children: [
          const ISLabelBarMain(
            leading: Text('* 최대 1년 이내 이력만 조회 가능합니다.', style: TextStyle(color: Colors.grey, fontSize: 14),),
            trailing: SizedBox(height: 36,),
          ),
          const SizedBox(height: 8,),
          Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
          const SizedBox(height: 8,),
          Container(
              alignment: Responsive.isMobile(context) == true ? Alignment.centerRight : Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              //height: 40,
              width: double.infinity,
              decoration: BoxDecoration(color: Colors.grey[200],),
              child: Text.rich(
                  style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                  textAlign: Responsive.isMobile(context) == true ? TextAlign.end : TextAlign.start,
                  TextSpan(children: [
                    const TextSpan(text: '조회된 기간의 쿠폰 사용건은 '),
                    TextSpan(text: Utils.getCashComma(totalDeposit.toString()), style: const TextStyle(color: Colors.lightBlue, )),
                    const TextSpan(text: '건 이며, '),
                    const TextSpan(text: '총 사용된 금액은 '),
                    TextSpan(text: Utils.getCashComma(totalWithdraw.toString()), style: const TextStyle(color: Colors.lightBlue)),
                    const TextSpan(text: '원 입니다.'),
                  ]
                  )
              )
          ),
          const SizedBox(height: 10,),
          SizedBox(
            height: Responsive.isMobile(context) ? (widget.tabviewHeight!-93) : (widget.tabviewHeight!-93),
            child: Responsive.isMobile(context) ? mobileCouponUseHistoryWidget() : CouponUseHistoryWidget(),
          ),
          if (dataList != null && dataList.isNotEmpty)...[
            ISNumberPagination(
              threshold: 5,
              controlButton: const SizedBox(width: 10, height: 10,),
              onPageChanged: (int pageNumber) {
                setState(() {
                  selectedPageNumber = pageNumber;
                });

                requestAPIData();
              },
              fontSize: 12,
              pageTotal: totalPage,
              pageInit: selectedPageNumber, // picked number when init page
              colorPrimary: Colors.black,
              colorSub: Colors.white,
            ),
          ]
        ],
      ),
    );

  }

  List<Widget> searchBarView() {
    return [
      ISInput(
        value: searchOrderNo,
        width: Responsive.isMobile(context) == true ? double.infinity : 160,
        label: '주문 번호 검색',
        prefixIcon: const Icon(
          Icons.search,
          color: Colors.black54,
        ),
        onChange: (v) {
          searchOrderNo = v;

          debugPrint('tempStr:${searchOrderNo}');
        },
      ),
      Responsive.isMobile(context) == true
          ? const SizedBox(
        height: 8,
      )
          : const SizedBox(
        width: 8,
      ),
      Material(
        child: ISSearchSelectDate(
          label: '기간 선택',
          width: Responsive.isMobile(context) == true ? double.infinity : 230,
          value: '${startdate.toString()} ~ ${enddate.toString()}',
          onTap: () async {
            showGeneralDialog(
                context: context,
                barrierDismissible: true,
                barrierLabel: '',
                barrierColor: Colors.black54,
                pageBuilder: (context, animation, secondaryAnimation) {
                  return Dialog(
                      elevation: 0,
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                      child: MultipleViewDateRangePicker(
                        startDate: DateTime.parse(startdate!),
                        endDate: DateTime.parse(enddate!),
                        setDateActionCallback: ({startDate, endDate}) {
                          Navigator.of(context).pop();

                          startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                          enddate = DateFormat('yyyy-MM-dd').format(endDate!);

                          selectedPageNumber = 1;

                          requestAPIData();
                        },
                      ));
                });
          },
        ),
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8,) : const SizedBox(width: 8,),
      ISToggleButtons(
        [
          ISOptionModel(value: '30', label: '1개월'),
          ISOptionModel(value: '90', label: '3개월'),
          ISOptionModel(value: '180', label: '6개월'),
          ISOptionModel(value: '365', label: '1년'),
        ],
        buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 4) - 8) : 60,
        defaultValue: searchDate,
        afterOnPress: (v) {
          enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          startdate = formatDate(DateTime.now().subtract(Duration(days: int.parse(v.toString()))), [yyyy, '-', mm, '-', dd]);

          selectedPageNumber = 1;

          requestAPIData();
        },
      ),
    ];
  }

  Widget CouponUseHistoryWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: DataTable2(
            headingRowHeight: 40,
            columnSpacing: 0,
            horizontalMargin: 0,

            headingRowColor: MaterialStateProperty.all(Colors.grey[100],),
            headingTextStyle: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54),
            // MaterialStateProperty.resolveWith((states) =>
            //     _fixedRows > 0 ? Colors.grey[200] : Colors.transparent),
            border: TableBorder(
              borderRadius: BorderRadius.circular(10),
              top: BorderSide(color: Colors.grey[300]!),
              right: BorderSide(color: Colors.grey[300]!),
              bottom: BorderSide(color: Colors.grey[300]!),
              left: BorderSide(color: Colors.grey[300]!),
              horizontalInside: BorderSide.none,
            ),

            dividerThickness: 0, // this one will be ignored if [border] is set above
            bottomMargin: 10,
            minWidth: 900,
            // sortColumnIndex: _sortColus
            // sortArrowIcon: Icons.keyboard_arrow_up, // custom arrow
            // sortArrowAnimationDuration:
            //     const Duration(milliseconds: 500), // custom animation duration
            // onSelectAll: (val) =>
            //     setState(() => _dessertsDataSource.selectAll(val)),
            columns: [
              const DataColumn2(label: Center(child: Text('쿠폰 이름')), size: ColumnSize.S,),
              DataColumn2(
                label: Center(
                  child: ISSearchDropdownV2(
                    // label: '업체타입',
                    value: searchPackOrderGbn,
                    onChange: (value) {
                      searchPackOrderGbn = value;
                      selectedPageNumber = 1;

                      requestAPIData();
                    },
                    item: [
                      const DropdownMenuItem(value: '%', child: Text('주문 전체'),),
                      const DropdownMenuItem(value: 'D', child: Text('배달'),),
                      const DropdownMenuItem(value: 'T', child: Text('포장'),),
                    ].cast<DropdownMenuItem<String>>(),
                  ),
                ),
                size: ColumnSize.S,
                numeric: true,
                fixedWidth: 130,
                // onSort: (columnIndex, ascending) =>
                //     _sort<num>((d) => d.carbs, columnIndex, ascending),
              ),
              const DataColumn2(label: Center(child: Text('할인금액')), size: ColumnSize.S, numeric: true,),
              const DataColumn2(label: Center(child: Text('사용일시')), size: ColumnSize.S, numeric: true,),
              const DataColumn2(label: Center(child: Text('주문번호')), size: ColumnSize.S, numeric: true,),
              const DataColumn2(label: Center(child: Text('고객(닉네임)')), size: ColumnSize.S, numeric: true,),
            ],
            empty: Center(child: Container(padding: const EdgeInsets.all(20), child: const Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)))),
            rows: List<DataRow>.generate(couponUseHistoryDataSource.rowCount, (index) => couponUseHistoryDataSource.getRow(index)),
          ),
        ),
      ],
    );
  }

  Widget mobileCouponUseHistoryWidget() {
    return SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ISSearchDropdown(
            label: '주문유형',
            width: double.infinity,
            height: 50,
            value: searchPackOrderGbn,
            onChange: (value) {
              setState(() {
                searchPackOrderGbn = value;
                selectedPageNumber = 1;

                requestAPIData();
              });
            },
            item: [
              ISOptionModel(value: '%', label: '주문 전체'),
              ISOptionModel(value: 'D', label: '배달'),
              ISOptionModel(value: 'T', label: '포장'),
            ].cast<ISOptionModel>(),
          ),
          const Divider(),
          (dataList.length! == 0)
              ? SizedBox(
            height: (widget.tabviewHeight! - 220),
            child: const Align(
                alignment: Alignment.center,
                child: Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
          ) :
          ListView(
              controller: _scrollController,
              shrinkWrap: true,
              children: List.generate(dataList.length, (index) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                  decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.black.withOpacity(0.1)))),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('쿠폰이름', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                          Text(
                            '${dataList[index].couponName}' ?? '',
                            style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('주문유형', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                          Text(
                            '${dataList[index].applyGbnName}' ?? '',
                            style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('할인금액', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                          Text(
                            '${dataList[index].couponAmt ?? ''}원'  '',
                            style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('사용일시', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                          Text(
                            Utils.getDateFormat('${dataList[index].useDate}') ?? '',
                            style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('주문번호', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                          Text(
                            '${dataList[index].orderNo}' ?? '',
                            style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('고객(닉네임)', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                          Text(
                            '${dataList[index].custNickName}' ?? '',
                            style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              })),
        ],
      ),
    );
  }
}

class CouponUseHistorySource extends DataTableSource {
  final BuildContext context;
  late List<CouponUseHistoryListModel> dataSource = [];
  // Add row tap handlers and show snackbar
  bool hasRowTaps = false;
  // Override height values for certain rows
  bool hasRowHeightOverrides = false;
  // Color each Row by index's parity
  bool hasZebraStripes = false;

  int _selectedCount = 0;

  CouponUseHistorySource.empty(this.context, this.dataSource) {
    dataSource = [];
  }

  CouponUseHistorySource(this.context, this.dataSource, [sortedByValue = false, this.hasRowTaps = false, this.hasRowHeightOverrides = false, this.hasZebraStripes = false]) {
    //dataSource = dataList;
    // if (sortedByValue) {
    //   sort((d) => d., true);
    // }
  }

  @override
  DataRow getRow(int index, [Color? color, double fontSize = 14.0, FontWeight? fontWeight = FONT_NORMAL]) {
    assert(index >= 0);
    if (index >= dataSource.length) throw 'index > dataList.length';
    final data = dataSource[index];

    final cellDecoration = BoxDecoration(border: Border(bottom: BorderSide(color: !data.isChild && !data.isChild2 ? Colors.grey[200]! : Colors.transparent, width: 1)));


    return DataRow2.byIndex(
      index: index,
      // selected: data.selected,
      color: color != null
          ? MaterialStateProperty.all(color)
          : data.isChild
          ? MaterialStateProperty.all(Colors.red[50])
          : data.isChild2
          ? MaterialStateProperty.all(Colors.blue[50])
          : MaterialStateProperty.all(Colors.transparent),
      specificRowHeight: hasRowHeightOverrides && (data.isChild || data.isChild2) ? 70 : null,
      cells: [
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text(data.couponName ?? '', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text(data.applyGbnName ?? '', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text('${data.couponAmt ?? ''}원', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text('${data.useDate ?? ''}', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text('${data.orderNo ?? ''}', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text('${data.custNickName ?? ''}', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
      ],
    );
  }

  @override
  int get rowCount => dataSource.length;

  @override
  bool get isRowCountApproximate => false;

  @override
  int get selectedRowCount => _selectedCount;

  void selectAll(bool? checked) {
    for (final data in dataSource) {
      data.selected = checked ?? false;
    }
    _selectedCount = (checked ?? false) ? dataSource.length : 0;
    notifyListeners();
  }
}