import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/AccountManager/accountSaleInfoModel.dart';
import 'package:daeguro_ceo_app/models/SaleManager/couponUseStatusListModel.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:data_table_2/data_table_2.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class CouponUseStatusMain extends StatefulWidget {
  final double? tabviewHeight;

  const CouponUseStatusMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<CouponUseStatusMain> createState() => _CouponUseStatusMainState();
}

class _CouponUseStatusMainState extends State<CouponUseStatusMain> {
  List<CouponUseStatusListModel> dataList = <CouponUseStatusListModel>[];
  List<CouponUseStatusListModel> mobileDataDetailSource = <CouponUseStatusListModel>[];
  Map<int, List<CouponUseStatusListModel>> mobileDataDetailSourceMap = {};
  final ScrollController _scrollController = ScrollController();

  late CouponUseInfoSource saleInfoDataSource;
  bool _initialized = false;

  String? searchDate = '30';

  String? startdate = '';
  String? enddate = '';

  int? totIssueCnt;
  int? totAmt;
  int? totUseCnt;

  int selectedPageNumber = 1;
  int totalPage = 0;

  requestAPIData(String jobGbn) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(CouponController.to.getCouponStatusList(jobGbn, startdate!.replaceAll('-', ''), enddate!.replaceAll('-', ''), selectedPageNumber.toString()))
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        CouponUseStatusListModel temp = CouponUseStatusListModel();
        temp.rNum = element['rNum'] as String;
        temp.couponDate = element['couponDate'] as String;
        temp.couponName = element['couponName'] as String;
        temp.totalCount = element['totalCount'] as String;
        temp.totalUseCnt = element['totalUseCnt'] as String;
        temp.totalUseAmt = element['totalUseAmt'] as String;
        temp.couponTypeCnt = element['couponTypeCnt'] as String;

        temp.couponName = temp.couponName!.replaceAll('\n', '');

        dataList.add(temp);
      });

      totalPage = CouponController.to.total_page;

      totIssueCnt = CouponController.to.totIssueCnt;
      totAmt = CouponController.to.totAmt;
      totUseCnt = CouponController.to.totUseCnt;
    }

    setState(() {});
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      saleInfoDataSource = CouponUseInfoSource(context, dataList, false, true, true, false);
      // Default sorting sample. Set __sortColumnIndex to 0 and uncoment the lines below
      // if (_sortColumnIndex == 0) {
      //   _sort<String>((d) => d.name, _sortColumnIndex!, _sortAscending);
      // }
      _initialized = true;
      saleInfoDataSource.addListener(() {
        setState(() {});
      });
    }
  }

  @override
  void dispose() {
    dataList.clear();
    mobileDataDetailSource.clear();
    mobileDataDetailSourceMap.clear();
    _scrollController.dispose();
    saleInfoDataSource.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    Get.put(CouponController());

    startdate = formatDate(DateTime.now().subtract(const Duration(days: 30)), [yyyy, '-', mm, '-', dd]);
    enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData('1');
    });
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData('1');
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    //return Responsive.isMobile(context) ? mobileCouponUseStatusWidget() : CouponUseStatusWidget();

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const ISLabelBarMain(
            leading: Text('* 최대 1년 이내 이력만 조회 가능합니다.', style: TextStyle(color: Colors.grey, fontSize: 14),),
            trailing: SizedBox(height: 36,),
          ),
          const SizedBox(height: 8,),
          Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
          const SizedBox(height: 8,),
          Container(
              alignment: Responsive.isMobile(context) == true ? Alignment.centerRight : Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              //height: 40,
              width: double.infinity,
              decoration: BoxDecoration(color: Colors.grey[200],),
              child: Text.rich(
                  style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                  textAlign: Responsive.isMobile(context) == true ? TextAlign.end : TextAlign.start,
                  TextSpan(
                      children: [
                        const TextSpan(text: '조회된 기간의 쿠폰 발급 건은 '),
                        TextSpan(text: Utils.getCashComma(totIssueCnt.toString()), style: const TextStyle(color: Colors.lightBlue)),
                        const TextSpan(text: '건, 사용건은 '),
                        TextSpan(text: Utils.getCashComma(totUseCnt.toString()), style: const TextStyle(color: Colors.lightBlue)),
                        const TextSpan(text: '건, '),
                        TextSpan(text: Responsive.isMobile(context) == true ? '\n' : ''),
                        const TextSpan(text: '총 사용된 금액은 '),
                        TextSpan(text: Utils.getCashComma(totAmt.toString()), style: const TextStyle(color: Colors.lightBlue)),
                        const TextSpan(text: '원입니다.'),
                      ]
                  )
              )
          ),
          const SizedBox(height: 10,),
          Responsive.isMobile(context) ? mobileCouponUseStatusWidget() : CouponUseStatusWidget(),
          ISNumberPagination(
            threshold: 5,
            controlButton: const SizedBox(width: 10, height: 10,),
            onPageChanged: (int pageNumber) {
              setState(() {
                selectedPageNumber = pageNumber;
              });

              requestAPIData('1');
            },
            fontSize: 12,
            pageTotal: totalPage,
            pageInit: selectedPageNumber, // picked number when init page
            colorPrimary: Colors.black,
            colorSub: Colors.white,
          ),
        ],
      ),
    );
  }

  Widget CouponUseStatusWidget() {
    return Container(
      height: widget.tabviewHeight!-88,
      child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: DataTable2(
            // dataRowHeight: 30,
            headingRowHeight: 40,
            headingTextStyle: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54),
            columnSpacing: 0,
            horizontalMargin: 0,
            headingRowColor: MaterialStateProperty.all(Colors.grey[100],),
            // MaterialStateProperty.resolveWith((states) =>
            //     _fixedRows > 0 ? Colors.grey[200] : Colors.transparent),
            border: TableBorder(
              borderRadius: BorderRadius.circular(10),
              top: BorderSide(color: Colors.grey[300]!),
              right: BorderSide(color: Colors.grey[300]!),
              bottom: BorderSide(color: Colors.grey[300]!),
              left: BorderSide(color: Colors.grey[300]!),
              horizontalInside: BorderSide.none,
            ),

            dividerThickness: 0, // this one will be ignored if [border] is set above
            bottomMargin: 10,
            minWidth: 900,
            // sortColumnIndex: _sortColus
            // sortArrowIcon: Icons.keyboard_arrow_up, // custom arrow
            // sortArrowAnimationDuration:
            //     const Duration(milliseconds: 500), // custom animation duration
            // onSelectAll: (val) =>
            //     setState(() => _dessertsDataSource.selectAll(val)),
            columns: const [
              DataColumn2(label: Center(child: Text('일자')), size: ColumnSize.S, fixedWidth: 120),
              DataColumn2(label: Align(alignment: Alignment.centerLeft, child: Text('쿠폰이름')), size: ColumnSize.S, numeric: true,),
              DataColumn2(label: Align(alignment: Alignment.center, child: Text('발급건')), size: ColumnSize.S, numeric: true, fixedWidth: 140),
              DataColumn2(label: Align(alignment: Alignment.center, child: Text('사용건')), size: ColumnSize.S, numeric: true, fixedWidth: 140),
              DataColumn2(label: Align(alignment: Alignment.centerRight, child: Text('총 사용 금액')), size: ColumnSize.S, numeric: true, fixedWidth: 140),
              DataColumn2(label: Center(child: Text('')), size: ColumnSize.S, numeric: true, fixedWidth: 140),
            ],
            empty: Center(
                child: Container(
                    padding: const EdgeInsets.all(20),
                    child: const Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)))),
            rows: List<DataRow>.generate(saleInfoDataSource.rowCount,
                    (index) => saleInfoDataSource.getRow(index)),
          ),
        ),

      ],
      ),
    );
  }

  Widget mobileCouponUseStatusWidget() {
    return SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListView.separated(
              controller: _scrollController,
              shrinkWrap: true,
              padding: EdgeInsets.zero,
              itemBuilder: (ctx, index) {
                return fluentUI.Expander(
                  contentBackgroundColor: Colors.grey[200],
                  onStateChanged: (val) async {
                    if (val == true) {
                      var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(CouponController.to.getCouponStatusList('2', dataList[index].couponDate!, '', '1')));

                      if (value == null) {
                        ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                      } else {
                        List<CouponUseStatusListModel> tempList = value.map<CouponUseStatusListModel>((element) {
                          CouponUseStatusListModel temp = CouponUseStatusListModel();

                          temp.couponName = element['couponName'] as String;
                          temp.couponAmt = element['couponAmt'] as String;

                          temp.totalUseCnt = element['totalUseCnt'] as String;
                          temp.totalUseAmt = element['totalUseAmt'] as String;

                          temp.totalPubCnt = element['totalPubCnt'] as String;
                          temp.totalPubAmt = element['totalPubAmt'] as String;
                          return temp;
                        }).toList();

                        setState(() {
                          mobileDataDetailSourceMap[index] = tempList;
                        });
                      }
                    } else {
                      setState(() {
                        mobileDataDetailSourceMap.remove(index);
                      });
                    }
                  },
                  headerHeight: 150,
                  header: Padding(
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('일자', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                            Text(
                              Utils.getDateFormat('${dataList[index].couponDate}'),
                              style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('쿠폰이름', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                            Text(
                              dataList[index].couponName ?? '',
                              style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('발급건', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                            Text(
                              '${Utils.getCashComma(dataList[index].totalCount ?? '')} 건',
                              style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('사용건', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                            Text(
                              '${Utils.getCashComma(dataList[index].totalUseCnt ?? '')} 건',
                              style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('총 사용 금액', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                            Text(
                              '${Utils.getCashComma(dataList[index].totalUseAmt ?? '')} 원',
                              style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                  content: mobileDataDetailSourceMap.containsKey(index)
                        ? ListView.separated(
                          controller: _scrollController,
                          shrinkWrap: true,
                          padding: EdgeInsets.zero,
                          itemBuilder: (ctx, idx) {
                            CouponUseStatusListModel detail = mobileDataDetailSourceMap[index]![idx];
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8.0),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text('쿠폰이름', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                                      Text(detail.couponName!, style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text('발급건', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                                      Text('${Utils.getCashComma(detail.totalPubAmt ?? '')} 원 x ${detail.totalPubCnt} 장', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),)
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text('사용건', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                                      Text('${Utils.getCashComma(detail.totalUseAmt ?? '')} 원 x ${detail.totalUseCnt} 장', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),)
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text('총 사용 금액', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                                      Text('${Utils.getCashComma(detail.totalUseAmt ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),)
                                    ],
                                  ),
                                ],
                              ),
                            );
                          },
                          separatorBuilder: (BuildContext context, int index) { return const Divider(thickness: 1, height: 0.0,); },
                          itemCount: mobileDataDetailSourceMap[index]!.length
                  ) : const SizedBox.shrink(),
                );
              },
              separatorBuilder: (BuildContext context, int index) {
                return const Divider(thickness: 1, height: 0.0,);
                },
              itemCount: dataList.length
          ),
          // ListView(
          //     shrinkWrap: true,
          //     children: List.generate(dataList.length, (index) {
          //       return ;
          //     })),

        ],
      ),
    );
  }

  List<Widget> searchBarView(){
    return [
      Material(
        child: ISSearchSelectDate(
          label: '기간 선택',
          width: Responsive.isMobile(context) == true ? double.infinity : 230,
          value: '${startdate.toString()} ~ ${enddate.toString()}',
          onTap: () async {
            showGeneralDialog(
                context: context,
                barrierDismissible: true,
                barrierLabel: '',
                barrierColor: Colors.black54,
                pageBuilder: (context, animation, secondaryAnimation) {
                  return Dialog(
                      elevation: 0,
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                      child: MultipleViewDateRangePicker(
                        startDate: DateTime.parse(startdate!),
                        endDate: DateTime.parse(enddate!),
                        setDateActionCallback: ({startDate, endDate}) {
                          Navigator.of(context).pop();

                          startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                          enddate = DateFormat('yyyy-MM-dd').format(endDate!);

                          selectedPageNumber = 1;

                          requestAPIData('1');
                        },
                      ));
                });
          },
        ),
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8,) : const SizedBox(width: 8,),
      ISToggleButtons(
        [
          ISOptionModel(value: '30', label: '1개월'),
          ISOptionModel(value: '90', label: '3개월'),
          ISOptionModel(value: '180', label: '6개월'),
          ISOptionModel(value: '365', label: '1년'),
        ],
        buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 4) - 8) : 60,
        defaultValue: searchDate,
        afterOnPress: (v) {
          startdate = formatDate(DateTime.now().subtract(Duration(days: int.parse(v.toString()))), [yyyy, '-', mm, '-', dd]);
          enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);


          selectedPageNumber = 1;

          requestAPIData('1');
        },
      ),
    ];
  }
}

class CouponUseInfoSource extends DataTableSource {
  final BuildContext context;
  late List<CouponUseStatusListModel> dataSource = [];
  // Add row tap handlers and show snackbar
  bool hasRowTaps = false;
  // Override height values for certain rows
  bool hasRowHeightOverrides = false;
  // Color each Row by index's parity
  bool hasZebraStripes = false;

  int _selectedCount = 0;

  List<CouponUseStatusListModel> dataDetailSource = [];

  CouponUseInfoSource.empty(this.context, this.dataSource) {
    dataSource = [];
  }

  CouponUseInfoSource(this.context, this.dataSource, [sortedByValue = false, this.hasRowTaps = false, this.hasRowHeightOverrides = false, this.hasZebraStripes = false]) {
    //dataSource = dataList;
    // if (sortedByValue) {
    //   sort((d) => d., true);
    // }
  }

  @override
  DataRow getRow(int index, [Color? color, double fontSize = 14.0, FontWeight? fontWeight]) {
    assert(index >= 0);
    if (index >= dataSource.length) throw 'index > dataList.length';
    final data = dataSource[index];
    return DataRow2.byIndex(
      index: index,
      color: color != null
          ? MaterialStateProperty.all(color)
          : data.isChild
          ? MaterialStateProperty.all(Colors.grey.shade200)
          : MaterialStateProperty.all(Colors.transparent),
      onTap: hasRowTaps ? () async {
        if (hasRowTaps){
          if (data.isChild){
            null;

            return;
          }
          else{
            if (data.isOpened){
              dataSource.removeRange(index + 1, index + (dataDetailSource.length+1));
              dataSource[index].isOpened = false;
            }
            else{
              var value = await showDialog(
                  context: context,
                  builder: (context) => FutureProgressDialog(CouponController.to.getCouponStatusList('2', dataSource[index].couponDate!, '', '1'))
              );

              if (value == null) {
                ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                //Navigator.of(context).pop;
              }
              else {
                dataDetailSource.clear();
                int subIndex = 1;
                value.forEach((element) {
                  CouponUseStatusListModel temp = CouponUseStatusListModel();

                  temp.couponName = element['couponName'] as String;
                  temp.couponAmt = element['couponAmt'] as String;

                  temp.totalUseCnt = element['totalUseCnt'] as String;
                  temp.totalUseAmt = element['totalUseAmt'] as String;

                  temp.totalPubCnt = element['totalPubCnt'] as String;
                  temp.totalPubAmt = element['totalPubAmt'] as String;

                  dataSource.insert(index + subIndex, CouponUseStatusListModel(
                      couponName: temp.couponName, couponAmt: temp.couponAmt,
                      totalUseCnt: temp.totalUseCnt, totalUseAmt: temp.totalUseAmt,
                      totalPubCnt: temp.totalPubCnt, totalPubAmt: temp.totalPubAmt, isChild: true)
                  );

                  dataSource[index].isOpened = true;

                  dataDetailSource.add(temp);

                  subIndex++;
                });
              }
            }
          }
          notifyListeners();
        }
      } : null,
      specificRowHeight: hasRowHeightOverrides && (data.isChild) ? 40 : null,
      cells: [
        DataCell(Container(
            padding: EdgeInsets.zero,
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !data.isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
            alignment: Alignment.center,
            child: Text(data.isChild ? '' : Utils.getDateFormat(data.couponDate!), style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !data.isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
            alignment: Alignment.centerLeft,
            child: Text(data.couponName ?? '', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !data.isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
            alignment: Alignment.center,
            child: Text(data.isChild ? '${Utils.getCashComma(data.totalPubAmt ?? '')} 원 x ${data.totalPubCnt} 장' : '${Utils.getCashComma(data.totalCount ?? '')} 건',
              style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !data.isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
            alignment: Alignment.center,
            child: Text(data.isChild ? '${Utils.getCashComma(data.totalUseAmt ?? '')} 원 x ${data.totalUseCnt} 장' : '${Utils.getCashComma(data.totalUseCnt ?? '')} 건',
              style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !data.isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
            alignment: Alignment.centerRight,
            child: Text('${Utils.getCashComma(data.totalUseAmt ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(
          Container(
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: !data.isChild ? Colors.grey[200]! : Colors.transparent, width: 1))),
            alignment: Alignment.center,
            child: (data.isChild == true)
                ? const SizedBox.shrink()
                : Icon(data.isOpened == true
                ? Icons.keyboard_arrow_up
                : data.couponDate == null
                ? null
                : Icons.keyboard_arrow_down, color: Colors.black, size: 20),
          ),
          // onTap: () {
          //   if (data.isOpened == true) {
          //     data.isOpened = false;
          //   } else {
          //     data.isOpened = true;
          //   }
          // },
        ),
      ],
    );
  }

  @override
  int get rowCount => dataSource.length;

  @override
  bool get isRowCountApproximate => false;

  @override
  int get selectedRowCount => _selectedCount;

  void selectAll(bool? checked) {
    for (final data in dataSource) {
      data.selected = checked ?? false;
    }
    _selectedCount = (checked ?? false) ? dataSource.length : 0;
    notifyListeners();
  }
}