import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/models/SaleManager/packingDiscountModel.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class PackDiscountMain extends StatefulWidget {
  const PackDiscountMain({Key? key}) : super(key: key);

  @override
  State<PackDiscountMain> createState() => _PackDiscountMainState();
}

class _PackDiscountMainState extends State<PackDiscountMain> with PageMixin{

  final ScrollController _scrollController = ScrollController();

  static const int MODE_MAIN_VIEW = 1000;
  static const int MODE_PACKMINCOST_VIEW = 1001;
  static const int MODE_PACKDISCOUNT_VIEW = 1002;

  int currentMode = MODE_MAIN_VIEW;

  String? toGoDiscAmt = '0';//[포장할인금액]
  String? toGoMinAmt = '0';// [최소주문금액]
  String? toGoMinDiscAmt = '0';// [포장할인 최소 적용 금액]

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(CouponController.to.getPackDiscountInfo())
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      //Navigator.of(context).pop;
    }
    else {
      toGoDiscAmt = value['toGoDiscAmt'] as String;//[포장할인금액]
      toGoMinAmt = value['toGoMinAmt'] as String;// [최소주문금액]
      toGoMinDiscAmt = value['toGoMinDiscAmt'] as String;// [포장할인 최소 적용 금액]
    }

    setState(() {});
  }

  requestPackDataUpdate() async {
    ISConfirm(context, currentMode == MODE_PACKMINCOST_VIEW ? '포장 설정' : '포장 할인', '${getTitleStr()} 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
      Navigator.of(context).pop();

      if (isOK){
        var value = await showDialog(
            context: context,
            barrierColor: Colors.transparent,
            builder: (context) => FutureProgressDialog(ShopController.to.updateShopInfo('7', toGoDiscAmt!, toGoMinAmt!, toGoMinDiscAmt!))
        );

        if (value == null) {
          ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
        }
        else {
          if (value == '00') {
            currentMode = MODE_MAIN_VIEW;
            _scrollController!.jumpTo(0.0);

            requestAPIData();
          }
          else{
            ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
          }
        }
      }
    });
  }

  @override
  void initState() {
    super.initState();

    debugPrint('initState PackDiscountMain');

    Get.put(CouponController());
    Get.put(ShopController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {

    debugPrint('dispose PackDiscountMain');

    super.dispose();
    _scrollController.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return fluentUI.ScaffoldPage.scrollable(
      scrollController: _scrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      children: <Widget>[
        currentModeView(),
        //const SizedBox(height: 22.0),
      ],
    );
  }

  Widget currentModeView(){
    Widget? tempWidget;
    if (currentMode == MODE_MAIN_VIEW)                  {       tempWidget = mainInfoView();      }
    else if (currentMode == MODE_PACKMINCOST_VIEW)     {       tempWidget = packMinCostView();    }
    else if (currentMode == MODE_PACKDISCOUNT_VIEW)     {       tempWidget = packDiscountView();    }

    return tempWidget!;
  }

  Widget mainInfoView(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const ISLabelBarMain(
            leading: Text('포장 할인', style: TextStyle( color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
            underLine: false
        ),
        ISLabelBarSub(
          title: '포장 설정',
          body: Text('[최소 주문금액]  ${Utils.getCashComma(toGoMinAmt!)} 원'),
          trailing: ISButton(
            child: const Text('변경'),
            onPressed: () {
              currentMode = MODE_PACKMINCOST_VIEW;

              setState(() {
                _scrollController.jumpTo(0.0);
              });
            },
          ),
        ),
        ISLabelBarSub(
          title: '포장 할인',
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('[할인 최소 적용금액]  ${Utils.getCashComma(toGoMinDiscAmt !)} 원'),
              const SizedBox(height: 8,),
              Text('[할인 금액]  ${Utils.getCashComma(toGoDiscAmt !)} 원'),

            ],
          ),
          trailing: ISButton(
            child: const Text('변경'),
            onPressed: () {
              currentMode = MODE_PACKDISCOUNT_VIEW;

              setState(() {
                _scrollController.jumpTo(0.0);
              });
            },
          ),
        ),
        const Divider(height: 1),
      ],
    );
  }

  Widget packMinCostView(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ISLabelBarMain(
            leading: Text('포장 설정', style: TextStyle(color: Colors.black,fontSize: 24, fontWeight: FontWeight.bold),),
            underLine: false,
            trailing: Row(
              children: [
                ISButton(
                  child: const Text('취소'),
                  isReverseColor: true,
                  onPressed: () {
                    currentMode = MODE_MAIN_VIEW;

                    setState(() {
                      _scrollController.jumpTo(0.0);
                    });
                  },
                ),
                const SizedBox(width: 8),
                ISButton(
                  child: const Text('적용'),
                  onPressed: () async {
                    requestPackDataUpdate();

                  },
                ),
              ],
            ),
        ),
        ISLabelBarSub(
          title: '최소 주문금액',
          body: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Material(
                color: Colors.transparent,
                child: ISInput(
                  context: context,
                  value: Utils.getCashComma(toGoMinAmt!),
                  textAlign: TextAlign.end,
                  width: 120,
                  label: '최소 주문금액',
                  onChange: (v) {
                    toGoMinAmt = v.toString().replaceAll(',', '');
                  },
                ),
              ),
              const SizedBox(width: 8,),
              const Text('원', style: TextStyle(fontSize:16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
            ],
          ),
        ),
        const Divider(height: 1),
      ],
    );
  }

  Widget packDiscountView(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ISLabelBarMain(
            leading: const Text('포장 할인', style: TextStyle(color: Colors.black,fontSize: 24, fontWeight: FontWeight.bold),),
            underLine: false,
            trailing: Row(
              children: [
                ISButton(
                  child: const Text('취소'),
                  isReverseColor: true,
                  onPressed: () {
                    currentMode = MODE_MAIN_VIEW;

                    setState(() {
                      _scrollController.jumpTo(0.0);
                    });
                  },
                ),
                const SizedBox(width: 8),
                ISButton(
                  child: const Text('적용'),
                  onPressed: () {
                    requestPackDataUpdate();
                  },
                ),
              ],
            ),
        ),
        ISLabelBarSub(
          title: '할인 최소 적용금액',
          body: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Material(
                color: Colors.transparent,
                child: ISInput(
                  context: context,
                  value: Utils.getCashComma(toGoMinDiscAmt!),
                  width: 120,
                  textAlign: TextAlign.end,
                  label: '할인 최소 적용금액',
                  onChange: (v) {
                    toGoMinDiscAmt = v.toString().replaceAll(',', '');
                  },
                ),
              ),
              const SizedBox(width: 8,),
              const Text('원', style: TextStyle(fontSize:16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),

            ],
          ),
        ),
        const Divider(height: 1),

        ISLabelBarSub(
          title: '할인 금액',
          body: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Material(
                color: Colors.transparent,
                child: ISInput(
                  context: context,
                  value: Utils.getCashComma(toGoDiscAmt!),
                  width: 120,
                  textAlign: TextAlign.end,
                  label: '할인 금액',
                  onChange: (v) {
                    toGoDiscAmt = v.toString().replaceAll(',', '');
                  },
                ),
              ),
              const SizedBox(width: 8,),
              const Text('원', style: TextStyle(fontSize:16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),

            ],
          ),
        ),
        const Divider(height: 1),

      ],
    );
  }

  String getTitleStr(){
    String? tempStr;

    if (currentMode == MODE_PACKMINCOST_VIEW){
      tempStr = '최소 주문금액';
    }
    else if (currentMode == MODE_PACKDISCOUNT_VIEW){
      tempStr = '할인 최소 적용금액, 할인 금액';
    }
    else{
      tempStr = '';
    }

    return tempStr;
  }
}