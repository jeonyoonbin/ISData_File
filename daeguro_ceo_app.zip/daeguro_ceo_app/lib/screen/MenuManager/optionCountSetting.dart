import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionCountSettingModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class OptionCountSetting extends StatefulWidget {
  final String? optGrpCd;
  final String? optionCnt;
  final String? minCnt;
  final String? maxCnt;
  final String? multiYn;
  final String? reqYn;
  const OptionCountSetting({Key? key, this.optGrpCd, this.optionCnt, this.minCnt, this.maxCnt, this.multiYn, this.reqYn})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return OptionCountSettingState();
  }
}

enum RadioRequireGbn { requireGbnY, requireGbnN }

class OptionCountSettingState extends State<OptionCountSetting> {

  OptionCountSettingModel formData = OptionCountSettingModel();

  RadioRequireGbn? _radioRequireGbn;

  List<ISOptionModel> selectBox_Value = [];

  @override
  void dispose() {
    super.dispose();
    formData = OptionCountSettingModel();
    selectBox_Value.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(MenuInfoController());

    formData.minCount = widget.minCnt!;
    formData.multiCount = widget.maxCnt!;
    formData.multiYn = widget.multiYn!;
    formData.reqYn = widget.reqYn!;

    _radioRequireGbn = formData.reqYn == 'Y' ? RadioRequireGbn.requireGbnY : RadioRequireGbn.requireGbnN;

    // if (formData.minCount == '1' && formData.multiCount == '1')       {      _radioRequireGbn = RadioRequireGbn.requireGbnLock;       }
    // else if (formData.minCount == '0' && formData.multiCount == '99')  {    _radioRequireGbn = RadioRequireGbn.requireGbnChoice;      }
    // else                                                              {    _radioRequireGbn = RadioRequireGbn.requireGbnChoice;     }

    selectBox_Value = List.generate(100, (index) {
      return ISOptionModel(value: index.toString(), label: '${index}개');
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();//.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 320),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('옵션 수 설정', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            //const Divider(color: Colors.grey, height: 0.0,),
            const SizedBox(height: 16,),
            ISLabelBarSub(
              title: '선택 가능한 옵션 수',
              bodyPadding: const EdgeInsets.all(4),
              height: 30,
              body: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('필수여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                      Row(
                        children: [
                          Radio(
                              value: RadioRequireGbn.requireGbnN,
                              groupValue: _radioRequireGbn,
                              onChanged: (v) async {
                                setState(() {
                                  _radioRequireGbn = v as RadioRequireGbn?;
                                });
                              }),
                          const Text('선택옵션', style: TextStyle(fontSize: 12)),
                          const SizedBox(width: 20,),
                          Radio(
                              value: RadioRequireGbn.requireGbnY,
                              groupValue: _radioRequireGbn,
                              onChanged: (v) async {
                                setState(() {
                                  _radioRequireGbn = v as RadioRequireGbn?;
                                });
                              }),
                          const Text('필수옵션', style: TextStyle(fontSize: 12)),
                        ],
                      )

                    ],
                  ),
                  const SizedBox(height: 8,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('선택 가능 수량', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: [
                              const Text('최소', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                              const SizedBox(width: 4),
                              ISSearchDropdown(
                                width: 70,
                                height: 40,
                                label: '최소 수량',
                                value: formData.minCount.toString(),
                                onChange: (value) {
                                  setState(() {
                                    formData.minCount = value;
                                    //_query();
                                  });
                                },
                                item: selectBox_Value,
                              ),
                            ],
                          ),
                          const SizedBox(width: 8),
                          Row(
                            children: [
                              const Text('최대', style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                              const SizedBox(width: 4),
                              ISSearchDropdown(
                                width: 70,
                                height: 40,
                                label: '최대 수량',
                                value: formData.multiCount.toString(),
                                onChange: (value) {
                                  setState(() {
                                    formData.multiCount = value;
                                    //_query();
                                  });
                                },
                                item: selectBox_Value,
                              ),
                            ],
                          )
                        ],
                      )

                    ],
                  ),
                ],
              ),
              //trailing: ,
            ),
            const SizedBox(height: 8),
            ISLabelBarSub(title: '이 옵션그룹에는 옵션이 총 ${widget.optionCnt}개 있습니다.'),
            const SizedBox(height: 8),
          ],
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              ISConfirm(context, '옵션 수 설정 변경', '옵션 수 설정을 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){

                  formData.reqYn = _radioRequireGbn == RadioRequireGbn.requireGbnY ? 'Y': 'N';

                  var value = await showDialog(
                      context: context,
                      barrierColor: Colors.transparent,
                      builder: (context) => FutureProgressDialog(MenuInfoController.to.setOptioGroupCount(widget.optGrpCd!, formData.minCount!, formData.multiCount!, formData.multiYn!, formData.reqYn!))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


