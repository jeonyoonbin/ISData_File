import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/models/MenuManager/menuGroupEditModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/menuGroupListModel.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class MenuGroupEdit extends StatefulWidget {
  final MenuGroupListModel? sData;
  const MenuGroupEdit({Key? key, this.sData})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return MenuGroupEditState();
  }
}

enum RadioUseGbn { useGbnY, useGbnN }

class MenuGroupEditState extends State<MenuGroupEdit> {
  MenuGroupEditModel formData = MenuGroupEditModel();

  RadioUseGbn? _radioUseGbn;

  @override
  void dispose() {
    super.dispose();
    formData = MenuGroupEditModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(MenuInfoController());

    formData.shopCd = AuthService.SHOPCD;
    formData.groupCd = (widget.sData == null) ? '' : widget.sData!.menuGroupCd;
    formData.groupName = (widget.sData == null) ? '' : widget.sData!.menuGroupName;
    formData.groupMemo = (widget.sData == null) ? '' : widget.sData!.menuGroupMemo;
    formData.useYn = (widget.sData == null) ? 'Y' : widget.sData!.useYn;
    formData.uName = AuthService.uName;

    _radioUseGbn = formData.useYn == 'Y' ? RadioUseGbn.useGbnY : RadioUseGbn.useGbnN;
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 465),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text(widget.sData == null ? '메뉴그룹 신규 등록' : '메뉴그룹 정보 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            //const Divider(color: Colors.grey, height: 0.0,),
            const SizedBox(height: 12,),
            const Text('메뉴그룹명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            const SizedBox(height: 8),
            ISInput(
              autofocus: true,
              value: formData.groupName ?? '',
              context: context,
              height: 64,
              //padding: 0,
              label: '메뉴그룹명',
              maxLength: 25,
              onChange: (v) {
                formData.groupName = v;
              },
            ),
            const Text('메뉴그룹설명(선택)', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            const SizedBox(height: 8),
            ISInput(
              value: formData.groupMemo ?? '',
              context: context,
              height: 120,
              //padding: 0,
              label: '메뉴그룹설명',
              keyboardType: TextInputType.multiline,
              maxLines: 8,
              maxLength: 250,
              onChange: (v) {
                formData.groupMemo = v;
              },
            ),
            const SizedBox(height: 8,),
            const Divider(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('사용여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                      Row(
                        children: [
                          Radio(
                              value: RadioUseGbn.useGbnY,
                              groupValue: _radioUseGbn,
                              onChanged: (v) async {
                                _radioUseGbn = v as RadioUseGbn?;

                                setState(() {});
                              }),
                          const Text('사용', style: TextStyle(fontSize: 12)),
                          const SizedBox(width: 40,),
                          Radio(
                              value: RadioUseGbn.useGbnN,
                              groupValue: _radioUseGbn,
                              onChanged: (v) async {
                                _radioUseGbn = v as RadioUseGbn?;

                                setState(() {});
                              }),
                          const Text('미사용', style: TextStyle(fontSize: 12)),
                        ],
                      )

                    ],
                  ),
                  // Container(
                  //   decoration: BoxDecoration(color: widget.sData?.useYn == 'Y' ? Colors.blue[200] : Colors.red[200], borderRadius: BorderRadius.circular(6.0)),
                  //   child: SwitchListTile(
                  //     inactiveTrackColor: Colors.red[300],
                  //     dense: true,
                  //     value: widget.sData?.useYn == 'Y' ? true : false,
                  //     title: const Text('사용', style: TextStyle(fontSize: 12, color: Colors.white),),
                  //     onChanged: (v) {
                  //       setState(() {
                  //         widget.sData?.useYn = v ? 'Y' : 'N';
                  //         //formKey.currentState!.save();
                  //       });
                  //     },
                  //   ),
                  // ),


                ],
              ),
            ),
            const Divider(),
            const SizedBox(height: 12,),
          ],
        ),
      ),
      actions: [
        // SizedBox(//싱글 버튼 처리
        //   width: double.infinity,
        //   child: FilledButton(
        //     style: ButtonStyle(
        //         backgroundColor: const MaterialStatePropertyAll(Colors.blueAccent),
        //       shape: MaterialStatePropertyAll(
        //           RoundedRectangleBorder(
        //               borderRadius: BorderRadius.circular(4.0))
        //       ),
        //     ),
        //     onPressed: () {
        //
        //     },
        //     child: const Text('적용'),
        //   ),
        // ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (formData.groupName == '' || formData.groupName == null) {
                ISAlert(context, content: '메뉴그룹명을 확인해주세요.');
                return;
              }

              formData.useYn = _radioUseGbn == RadioUseGbn.useGbnY ? 'Y': 'N';

              ISConfirm(context, widget.sData == null ? '메뉴그룹 등록' : '메뉴그룹 수정', widget.sData == null ? '신규 메뉴그룹을 등록하시겠습니까?' : '메뉴그룹 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  var value = null;

                  if (widget.sData == null){
                    value = await showDialog(
                        context: context,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(MenuInfoController.to.addMenuGroup(formData.toJson()))
                    );
                  }
                  else{
                    value = await showDialog(
                        context: context,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(MenuInfoController.to.updateMenuGroup(formData.toJson()))
                    );
                  }

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: Text(widget.sData == null ? '등록' : '수정', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


