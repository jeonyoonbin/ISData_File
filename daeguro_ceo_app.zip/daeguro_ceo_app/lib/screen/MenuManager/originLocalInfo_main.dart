
import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOriginLocalListModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateEditModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productOriginLocalEdit.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuGroupEdit.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class OriginLocalInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const OriginLocalInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<OriginLocalInfoMain> createState() => _OriginLocalInfoMainState();
}

class _OriginLocalInfoMainState extends State<OriginLocalInfoMain> {

  String? shop_origin_mark = '';

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(MenuInfoController.to.getOriginData())
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      //Navigator.of(context).pop;
    }
    else {
      shop_origin_mark = value['shop_origin_mark'] as String;
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(MenuInfoController());
    Get.put(ShopController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {

    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            elevation: 1,
            shape: appTheme.cardShapStyle,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('원산지 정보', style: TextStyle(fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                  ISButton(
                    child: const Text('저장'),
                    onPressed: () {
                      ISConfirm(context, '원산지 정보', '저장 하시겠습니까?', (context, isOK) async {
                        Navigator.of(context).pop();

                        if (isOK){
                          ShopOperateEditModel sendData = ShopOperateEditModel();
                          sendData.shopCd = AuthService.SHOPCD;
                          sendData.modUcode = AuthService.uCode;
                          sendData.modName = AuthService.uName;
                          sendData.jobGbn = '2';
                          sendData.originMark = shop_origin_mark;

                          var value = await showDialog(
                              context: context,
                              barrierColor: Colors.transparent,
                              builder: (context) => FutureProgressDialog(ShopController.to.updateOperateInfo(sendData.toJson()))
                          );

                          if (value == null) {
                            ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                          }
                          else {
                            if (value == '00') {
                              //Navigator.of(context).pop(true);
                              requestAPIData();
                            }
                            else{
                              ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                            }
                          }
                        }
                      });
                    },
                  )
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8.0, bottom: 8.0, left: 3, right: 2),
            child: ISInput(
              value: shop_origin_mark,
              context: context,
              height: 200,
              //padding: 0,
              label: '원산지 설명',
              keyboardType: TextInputType.multiline,
              maxLines: 8,
              maxLength: 4000,
              onChange: (v) {
                shop_origin_mark = v.toString();
              },
            ),
          )

          //const Divider(height: 1)
        ],
      ),
    );
  }

  
}

