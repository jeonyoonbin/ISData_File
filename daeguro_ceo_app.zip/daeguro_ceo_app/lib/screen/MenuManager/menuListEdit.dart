import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/models/MenuManager/menuGroupEditModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/menuListEditModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/menuListModel.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class MenuListEdit extends StatefulWidget {
  final MenuListModel? sData;
  final String? menuGroupCd;
  const MenuListEdit({Key? key, this.sData, this.menuGroupCd})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return MenuListEditState();
  }
}

enum RadioUseGbn { useGbnY, useGbnN }
enum RadioSingleOrderGbn { singleOrderGbnY, singleOrderGbnN }
enum RadioAdultGbn { adultGbnY, adultGbnN }

class MenuListEditState extends State<MenuListEdit> {
  MenuListEditModel formData = MenuListEditModel();

  bool menuTopState = false;
  bool menuAloneState = false;

  RadioUseGbn? _radioUseGbn;
  RadioAdultGbn? _radioAdultGbn;
  RadioSingleOrderGbn? _radioSingleOrderGbn;

  @override
  void initState() {
    super.initState();

    // widget.sData?.useYn = 'Y';
    // _radioUseGbn = RadioUseGbn.useGbnY;
    // _radioAdultGbn = RadioAdultGbn.adultGbnY;
    // _radioSoldOutGbn = RadioSoldOutGbn.soldOutGbnY;

    Get.put(MenuInfoController());

    formData.shopCd = AuthService.SHOPCD;
    formData.groupCd = widget.menuGroupCd;
    formData.menuCd = (widget.sData == null) ? '' : widget.sData!.menuCd;
    formData.menuName = (widget.sData == null) ? '' : widget.sData!.menuName;
    formData.menuCost = (widget.sData == null) ? '' : widget.sData!.menuCost;
    formData.menuDesc = (widget.sData == null) ? '' : widget.sData!.menuDesc;
    formData.useGbn = (widget.sData == null) ? 'Y' : widget.sData!.useGbn;
    formData.noFlag = (widget.sData == null) ? 'N' : widget.sData!.noFlag;
    formData.mAloneOrder = (widget.sData == null) ? 'N' : widget.sData!.mAloneOrder;
    formData.mMainYn = (widget.sData == null) ? 'N' : widget.sData!.mMainYn;
    formData.adultOnly = (widget.sData == null) ? 'N' : widget.sData!.adultOnly;
    formData.singleOrderYn = (widget.sData == null) ? 'N' : widget.sData!.singleOrderYn;
    formData.orderLimitYn = (widget.sData == null) ? '' : widget.sData!.orderLimitYn;
    formData.orderLimitQnt = (widget.sData == null) ? '0' : widget.sData!.orderLimitQnt;
    formData.uName = AuthService.uName;

    menuTopState =  formData.mMainYn == 'Y' ? true : false;
    menuAloneState = formData.mAloneOrder == 'Y' ? true : false;

    _radioUseGbn = formData.useGbn == 'Y' ? RadioUseGbn.useGbnY : RadioUseGbn.useGbnN;
    _radioAdultGbn = formData.adultOnly == 'Y' ? RadioAdultGbn.adultGbnY : RadioAdultGbn.adultGbnN;
    _radioSingleOrderGbn = formData.singleOrderYn == 'Y' ? RadioSingleOrderGbn.singleOrderGbnY : RadioSingleOrderGbn.singleOrderGbnN;
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 420.0, maxHeight: 700),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text(widget.sData == null ? '메뉴 신규 등록' : '메뉴 정보 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            //const Divider(color: Colors.grey, height: 0.0,),
            const SizedBox(height: 12,),
            const Text('메뉴그룹', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                ISCheckbox(label: '대표메뉴', value: menuTopState, onChanged: (v) => setState(() => menuTopState = v!)),
                ISCheckbox(label: '1인메뉴', value: menuAloneState, onChanged: (v) => setState(() => menuAloneState = v!)),
              ],
            ),
            const SizedBox(height: 12,),
            const Text('메뉴명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            const SizedBox(height: 8),
            ISInput(
              autofocus: true,
              height: 64,
              value: formData.menuName,
              context: context,
              label: '예) 대표메뉴',
              maxLength: 50,
              onChange: (v) {
                formData.menuName = v;
              },
            ),

            const Text('메뉴금액(필수)', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            const SizedBox(height: 8),
            ISInput(
              value: formData.menuCost == null ? '' : Utils.getCashComma(formData.menuCost!),
              // : Utils.getCashComma(formData.menuCost!) ?? '',
              context: context,
              label: '금액(필수)',
              textAlign: TextAlign.end,
              maxLines: 1,
              suffixText: '원',
              keyboardType: TextInputType.number,
              inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
              onChange: (v) {
                setState(() {
                  formData.menuCost = v.toString().replaceAll(',', '');
                });
              },
            ),
            const SizedBox(height: 12,),
            const Text('메뉴설명(선택)', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            const SizedBox(height: 8),
            ISInput(
              value: formData.menuDesc,
              context: context,
              height: 120,
              maxLength: 75,
              maxLines: 8,
              keyboardType: TextInputType.multiline,
              label: '예) 쫄깃한 면발, 단짠 양념의 대표메뉴',
              onChange: (v) {
                formData.menuDesc = v;
              },
            ),
            const SizedBox(height: 8,),
            const Divider(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('사용여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                      Row(
                        children: [
                          Radio(
                              value: RadioUseGbn.useGbnY,
                              groupValue: _radioUseGbn,
                              onChanged: (v) async {
                                _radioUseGbn = v as RadioUseGbn?;

                                setState(() {});
                              }),
                          const Text('사용', style: TextStyle(fontSize: 12)),
                          const SizedBox(width: 40,),
                          Radio(
                              value: RadioUseGbn.useGbnN,
                              groupValue: _radioUseGbn,
                              onChanged: (v) async {
                                _radioUseGbn = v as RadioUseGbn?;

                                setState(() {});
                              }),
                          const Text('미사용', style: TextStyle(fontSize: 12)),
                        ],
                      )

                    ],
                  ),
                  const SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                      const Text('성인인증 여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                          SizedBox(width: 3,),
                          Tooltip(
                            message: '주류 등록시 [해당]에 필수',
                            child:  Image(image: AssetImage('images/adult40px.png'), width: 22, height: 22,)
                          )
                        ],
                      ),
                      Row(
                        children: [
                          Radio(
                              value: RadioAdultGbn.adultGbnY,
                              groupValue: _radioAdultGbn,
                              onChanged: (v) async {
                                _radioAdultGbn = v as RadioAdultGbn?;

                                setState(() {});
                              }),
                          const Text('해당', style: TextStyle(fontSize: 12)),
                          const SizedBox(width: 40,),
                          Radio(
                              value: RadioAdultGbn.adultGbnN,
                              groupValue: _radioAdultGbn,
                              onChanged: (v) async {
                                _radioAdultGbn = v as RadioAdultGbn?;

                                setState(() {});
                              }),
                          const Text('비해당', style: TextStyle(fontSize: 12)),
                        ],
                      )

                    ],
                  ),
                  const SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('단독주문', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                      Row(
                        children: [
                          Radio(
                              value: RadioSingleOrderGbn.singleOrderGbnY,
                              groupValue: _radioSingleOrderGbn,
                              onChanged: (v) async {
                                _radioSingleOrderGbn = v as RadioSingleOrderGbn?;

                                setState(() {});
                              }),
                          const Text('해당', style: TextStyle(fontSize: 12)),
                          const SizedBox(width: 40,),
                          Radio(
                              value: RadioSingleOrderGbn.singleOrderGbnN,
                              groupValue: _radioSingleOrderGbn,
                              onChanged: (v) async {
                                _radioSingleOrderGbn = v as RadioSingleOrderGbn?;

                                setState(() {});
                              }),
                          const Text('비해당', style: TextStyle(fontSize: 12)),
                        ],
                      )
                    ],
                  ),
                ],
              ),
            ),
            const Divider(),
          ],
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (formData.menuName == '' || formData.menuName == null) {
                ISAlert(context, content: '메뉴명을 확인해주세요.');
                return;
              }

              if (formData.menuCost == '' || formData.menuCost == null) {
                ISAlert(context, content: '메뉴금액을 확인해주세요.');
                return;
              }

              formData.mMainYn = menuTopState == true ? 'Y' : 'N';
              formData.mAloneOrder = menuAloneState == true ? 'Y' : 'N';

              formData.useGbn = _radioUseGbn == RadioUseGbn.useGbnY ? 'Y' : 'N';
              formData.adultOnly = _radioAdultGbn == RadioAdultGbn.adultGbnY ? 'Y' : 'N';
              formData.singleOrderYn = _radioSingleOrderGbn == RadioSingleOrderGbn.singleOrderGbnY ? 'Y' : 'N';


              ISConfirm(context, widget.sData == null ? '메뉴 등록' : '메뉴 수정', widget.sData == null ? '신규 메뉴를 등록하시겠습니까?' : '메뉴 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  var value = null;

                  if (widget.sData == null){
                    value = await showDialog(
                        context: context,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(MenuInfoController.to.addMenu(formData.toJson()))
                    );
                  }
                  else{
                    value = await showDialog(
                        context: context,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(MenuInfoController.to.updateMenu(formData.toJson()))
                    );
                  }

                  if (value == null) {
                    ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: Text(widget.sData == null ? '등록' : '수정', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


