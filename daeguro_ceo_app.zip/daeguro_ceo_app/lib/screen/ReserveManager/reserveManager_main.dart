import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/DashBoardManager/dashboard_week_order_model.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListModel.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListRequestModel.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/screen/Common/commonPopup_main.dart';
import 'package:daeguro_ceo_app/screen/DashBoardManager/dashboardManagerController.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeDetailInfo.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManager_00.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManager_20.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManager_30.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:get/instance_manager.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class ReserveMain extends StatefulWidget {
  const ReserveMain({Key? key}) : super(key: key);

  @override
  State<ReserveMain> createState() => _ReserveMainState();
}
    
class _ReserveMainState extends State<ReserveMain> with PageMixin {
  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());

    debugPrint('initState HomePage');
  }

  @override
  void dispose() {
    debugPrint('dispose HomePage');

    super.dispose();
  }

  Widget _content(){
    // Obx 사용 하려면 OBX 안에 obs로 값이 변했을때 알려주는 Rx값을 사용해야함.
    return Obx(() => Container(child: _rtnReserMenu(ReserveController.to.reservePageGbn.toString())));

    if(ReserveController.to.reservePageGbn.toString() == '00') {
      return const ReserveManager00();
    }
    else if(ReserveController.to.reservePageGbn.toString() == '20') {
      return ReserveManager20();
    } else {
      return const ReserveManager30();
    }
  }

  Widget _rtnReserMenu (String _pageGbn) {
    if (_pageGbn == '20') {
      return const ReserveManager20();
    } else if (_pageGbn == '30') {
      return const ReserveManager30();
    } else if (_pageGbn == '00') {
      return const ReserveManager00();
    } else {
      return const SizedBox.shrink();
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    return fluentUI.ScaffoldPage.withPadding(
      header: const LayoutHeader(titleName: '사장님사이트 현황'),//SizedBox(width: double.infinity, height: 100,),//
      bottomBar: const LayoutBottom(),
      content: Container(
        child: _content()) // 00:신청가능, 20:신청중, 30:심사완료
    );
  }
}