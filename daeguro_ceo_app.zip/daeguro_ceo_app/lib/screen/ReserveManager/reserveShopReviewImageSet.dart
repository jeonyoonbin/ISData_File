import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productListEditModel.dart';
import 'package:daeguro_ceo_app/models/RequestManager/requestShopInfoEditModel.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveReviewImageInsertModel.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import 'package:http/http.dart' as http;

class ReserveShopReviewImageSet extends StatefulWidget {
  final String? ccCode;

  const ReserveShopReviewImageSet({Key? key, this.ccCode}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _ReserveShopReviewImageSetState();
  }
}

class _ReserveShopReviewImageSetState extends State<ReserveShopReviewImageSet> {
  final ScrollController _scrollController = ScrollController();

  PickedFile? afterImageFile;
  var _fileImage = null;

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 480.0, maxHeight: 800),
      contentPadding: const EdgeInsets.all(0.0),
      //const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text(
            '리뷰 알림 이미지 등록',
            style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),
          ),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 10),
                (afterImageFile == null) ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 160, height: 160,)
                    : Image.network('${afterImageFile!.path}', fit: BoxFit.cover, gaplessPlayback: true, width: 160, height: 160,
                  errorBuilder: (context, error, stackTrace) {
                    return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 160, height: 160,);
                  },
                ),
                SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  alignment: Alignment.center,
                  child: InkWell(
                    child: DottedBorder(
                      padding: const EdgeInsets.only(
                        top: 6,
                        bottom: 6,
                      ),
                      color: const Color(0xffDDDDDD),
                      strokeWidth: 1,
                      radius: const Radius.circular(10.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        child: Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                              SizedBox(
                                width: 8,
                              ),
                              Text(
                                '이미지 파일 선택',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: FONT_FAMILY,
                                  color: Color(0xff999999),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    onTap: () async {
                      // 이미지 등록
                      ImagePicker imagePicker = ImagePicker();
                      Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                      imageFile.then((file) async {
                        afterImageFile = file;

                        _fileImage = file;
                        setState(() {});
                      });
                    },
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  decoration: const BoxDecoration(color: Color.fromARGB(255, 240, 240, 240), borderRadius: BorderRadius.all(Radius.circular(10))),
                  // height: 35,
                  child: Text.rich(
                      style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, height: 2.0),
                      textAlign: TextAlign.start,
                      TextSpan(children: [
                        const TextSpan(text: '- 16:9 비율의 가로로 넓은 직사각형의 고화질 사진을 올려 주세요.\n'),
                        const TextSpan(text: '- 15MB 이하, JPG/PNG 파일만 올릴 수 있습니다.\n'),
                        const TextSpan(text: '- 접수건이 폭등할 경우, 처리일이 다소 지연될 수 있습니다.'),
                      ])),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (afterImageFile == null) {
                ISAlert(context, content: '선택된 이미지가 없습니다.\n 이미지를 선택해주세요.');
                return;
              }

              ISConfirm(context, '리뷰 알림 이미지 등록', '리뷰 알림 이미지를 등록 하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK) {
                  ReserveReviewImageInsertModel sendData = ReserveReviewImageInsertModel();
                  sendData.ccCode = widget.ccCode;
                  sendData.shopCode = AuthService.SHOPCD;

                  List<PickedFile>? imageFileList = <PickedFile>[];
                  imageFileList.add(afterImageFile!);

                  await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ReserveController.to.setReviewImage(sendData, _fileImage))
                  ).then((value) async {
                    if (value != 200) {
                      ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                    }
                    else {
                      Navigator.of(context).pop(true);
                    }
                  });
                }
              });
            },
            child: const Text('등록', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}
