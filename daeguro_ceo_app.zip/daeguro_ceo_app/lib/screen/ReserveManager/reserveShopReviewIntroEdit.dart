import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveReviewIntroModel.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveShopInfoModel.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveShopUpdateNoticeModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveShopReviewImageSet.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ReserveShopReviewIntroEdit extends StatefulWidget {
  final String? shopReviewIntro;
  final String? ccCode;
  final List<dynamic>? ssReviewImage;

  const ReserveShopReviewIntroEdit({Key? key, this.shopReviewIntro, this.ccCode, this.ssReviewImage}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ReserveShopReviewIntroEditState();
  }
}

class ReserveShopReviewIntroEditState extends State<ReserveShopReviewIntroEdit> {
  String? setShopReviewIntro;
  List<dynamic>? setssReviewImage;

  ReserveShopInfoModel reserveShopInfoModel = ReserveShopInfoModel();

  requestReserveAPIData() async {
    var value = await ReserveController.to.getReserveShopInfo();

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
    else {
      setssReviewImage = value[0]['ssReviewImage'] as List<dynamic>;
    }

    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    setShopReviewIntro = widget.shopReviewIntro!;
    setssReviewImage = widget.ssReviewImage;

    Get.put(ShopController());
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 410.0, maxHeight: 700),
      contentPadding: const EdgeInsets.all(0.0),
      //const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text(
            '리뷰 알림',
            style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),
          ),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10),
                ISLabelBarSub(
                  title: '소개  사진 (최소 1개 ~ 최대 2개)',
                  trailing: setssReviewImage!.length < 2 ? ISButton(
                    child: Text('이미지 등록'),
                    onPressed: () {
                      showDialog(
                        context: context,
                        barrierDismissible: true,
                        builder: (context) => ReserveShopReviewImageSet(ccCode: widget.ccCode.toString()),
                      ).then((value) async {
                        if (value == true) {
                          requestReserveAPIData();
                        }
                      });

                    },
                  ) : SizedBox.shrink(),
                  body: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('리뷰 이벤트, 혜택 등 관련 사진을 첨부해 주세요.', style: TextStyle(fontSize: 13)),
                      const SizedBox(height: 5),
                      Container(
                        height: 140,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: List.generate(setssReviewImage!.length, (index) {
                            return Column(
                              children: [
                                Container(height: 100, width: 100, margin: EdgeInsets.all(5), child: Image.network('${setssReviewImage![index]['fileName']!}?tm=${Utils.getTimeStamp()}', fit: BoxFit.fill, gaplessPlayback: true)),
                                SizedBox(
                                  height: 20,
                                  width: 100,
                                  child: InkWell(
                                    onTap: () {
                                      ISConfirm(context, '소개 사진 삭제', '현재 등록되어 있는 소개 사진을 삭제하시겠습니까?', constraints: const BoxConstraints(maxWidth: 440.0, maxHeight: 280), (context, isOK) async {
                                        Navigator.of(context).pop();

                                        if (isOK) {
                                          var _delData = {
                                            '"ccCode"' : '"' + widget.ccCode.toString() + '"',
                                            '"shopCode"' : '"' + AuthService.SHOPCD + '"',
                                            '"seq"' : setssReviewImage![index]['seq']
                                          };

                                          print(_delData.toString());

                                          var value = await showDialog(
                                              context: context,
                                              builder: (context) => FutureProgressDialog(ReserveController.to.deleteReviewImage(_delData.toString()))
                                          );

                                          if (value == null) {
                                            ISAlert(context, content: '정상처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                                          } else {
                                            requestReserveAPIData();
                                          }
                                        }
                                      });
                                    },
                                    child: Container(
                                        decoration: BoxDecoration(
                                            color: Color(0xff333333),
                                            borderRadius: BorderRadius.circular(5)
                                        ), alignment: Alignment.center,
                                        child: const Text('삭제',
                                          style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                          textAlign: TextAlign.center,
                                        ),
                                    ),
                                  ),
                                )
                              ],
                            );
                          }),
                        ),
                      ),
                    ],
                  ),
                ),
                ISLabelBarSub(
                  title: '소개글',
                  body: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('매장을 소개할 소개글을 입력해 주세요.(매장소개, 혜택 등)', style: TextStyle(fontSize: 13)),
                      SizedBox(height: 5),
                      ISInput(
                        autofocus: true,
                        value: setShopReviewIntro == 'null' ? '' : setShopReviewIntro,
                        //padding: 0,
                        height: 200,
                        maxLines: 10,
                        label: '소개글',
                        maxLength: 2000,
                        keyboardType: TextInputType.multiline,
                        onChange: (v) {
                          setShopReviewIntro = v;
                        },
                      ),
                      SizedBox(height: 10)
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              ISConfirm(context, '리뷰 알림 소개글 변경', '리뷰 알림 소개글 정보를 변경합니다. \n\n계속 진행 하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                if (isOK) {
                  Navigator.of(context).pop();

                  ReserveReviewIntroModel sendData = ReserveReviewIntroModel();

                  sendData.shopCd = AuthService.SHOPCD;
                  sendData.ccCode = widget.ccCode.toString();
                  sendData.shopReviewIntro = setShopReviewIntro.toString();
                  sendData.userID = AuthService.uCode;

                  var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(ReserveController.to.updateReserveShopReviewIntro(sendData.toJson())));

                  if (value == null) {
                    // ignore: use_build_context_synchronously
                    ISAlert(context, content: '리뷰 알림 소개글 수정에 실패했습니다. \n\n관리자에게 문의 바랍니다');
                    return;
                  }

                  Navigator.of(context).pop();
                } else {
                  Navigator.of(context).pop();
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}
