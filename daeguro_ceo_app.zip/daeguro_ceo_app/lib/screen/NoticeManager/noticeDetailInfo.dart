import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionGroupAddModel.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeDetailModel.dart';
import 'package:daeguro_ceo_app/models/OrderManager/orderDetailModel.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class NoticeDetailInfo extends StatefulWidget {
  final String? noticeSeq;
  const NoticeDetailInfo({Key? key, this.noticeSeq})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return NoticeDetailInfoState();
  }
}

class NoticeDetailInfoState extends State<NoticeDetailInfo> {
  String? tempStr = '';

  NoticeDetailModel formData = NoticeDetailModel();

  requestAPIData() async {

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(NoticeController.to.getNoticeDetail('1', widget.noticeSeq!))
    );

    if (value == null) {
      ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      //Navigator.of(context).pop;
    }
    else {
      formData.noticeSeq = value['noticeSeq'] as String;
      formData.noticeGbn = value['noticeGbn'] as String;
      formData.dispGbn = value['dispGbn'] as String;
      formData.dispFrDate = value['dispFrDate'] as String;
      formData.dispToDate = value['dispToDate'] as String;
      formData.noticeTitle = value['noticeTitle'] as String;
      formData.noticeContents = value['noticeContents'] as String;
      formData.noticeUrl1 = value['noticeUrl1'] as String;
      formData.noticeUrl2 = value['noticeUrl2'] as String;
      formData.noticeUrl3 = value['noticeUrl3'] as String;
      formData.orderDate = value['orderDate'] as String;
      formData.insUcode = value['insUcode'] as String;
      formData.insName = value['insName'] as String;
      formData.insDate = value['insDate'] as String;
      formData.modUcode = value['modUcode'] as String;
      formData.modName = value['modName'] as String;
      formData.modDate = value['modDate'] as String;

      if (formData.noticeUrl1 != null && formData.noticeUrl1 != '') {
        formData.noticeUrl1 = 'https://image.daeguro.co.kr:40443/event-images/${formData.noticeUrl1}?tm=${Utils.getTimeStamp()}';
      }

      //debugPrint('formData.notice_fileName:${formData.notice_fileName}');
    }

    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    formData = NoticeDetailModel();
  }


  @override
  void initState() {
    super.initState();

    Get.put(NoticeController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();//.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('공지 사항', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12),
                Text('${formData.noticeTitle}', style: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                Text('${formData.dispFrDate}', style: const TextStyle(color: Colors.black45, fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                const Divider(color: Colors.black,),
                Text("${formData.noticeContents}", style: const TextStyle(fontSize:14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                const SizedBox(height: 8),
                (formData.noticeUrl1 == null || formData.noticeUrl1 == '') ? const SizedBox.shrink()
                  : InkWell(
                    child: Image.network('${formData.noticeUrl1!}?tm=${Utils.getTimeStamp()}', gaplessPlayback: true, fit: BoxFit.fill,// width: 440, height: 150,
                                errorBuilder: (context, error, stackTrace) {
                                  debugPrint('image load error -> ${formData.noticeUrl1}\nerror:${error.toString()}\nstackTrace:${stackTrace.toString()}');
                                  return const Image(image: AssetImage('images/thumbnail-empty.png'));//Image.asset('assets/thumbnail-empty.png', width: 150, height: 150,);
                                },
                           ),
                            onTap: () {
                              // ImagePicker imagePicker = ImagePicker();
                              // Future<PickedFile> _imageFile = imagePicker.getImage(source: ImageSource.gallery);
                              // _imageFile.then((file) async {
                              //   editData.url1 = file.path;
                              //   //dataMenuList[index].fileSrc = file;
                              //
                              //   _file = file;
                              //
                              //   await Future.delayed(Duration(milliseconds: 500), () {
                              //     setState(() {
                              //       _deleteImageFromCache();
                              //     });
                              //   });
                              //
                              //   formKey.currentState.save();
                              //   setState(() {});
                              // });
                            },
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            style: ButtonStyle(
              backgroundColor: const MaterialStatePropertyAll(Colors.blueAccent),
              shape: MaterialStatePropertyAll(
                  RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4.0))
              ),
            ),
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('닫기'),
          ),
        ),
      ],
    );
  }
}


