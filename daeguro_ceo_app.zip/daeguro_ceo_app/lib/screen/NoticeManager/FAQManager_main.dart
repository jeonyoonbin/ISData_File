

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/faqCEOInfo_main.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/faqEvetInfo_main.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/faqOperateInfo_main.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/faqPOSInfo_main.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/faqShopInfo_main.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';

class FAQManagerMain extends StatefulWidget {
  const FAQManagerMain({Key? key}) : super(key: key);

  @override
  State<FAQManagerMain> createState() => _FAQManagerMainState();
}

class _FAQManagerMainState extends State<FAQManagerMain> with PageMixin{
  List<Tab> currTabs = <Tab>[
    const Tab(height: 60, text: '     입점 관련     '),
    const Tab(height: 60, text: '     운영 기준     '),
    const Tab(height: 60, text: '     이벤트        '),
    const Tab(height: 60, text: '     사장님사이트   '),
    const Tab(height: 60, text: '     POS           '),
  ];

  @override
  void initState() {
    super.initState();
    //debugPrint('initState FAQManagerMain');
    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {
    //debugPrint('dispose FAQManagerMain');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    double tapviewContentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 280 : 330);

    return fluentUI.ScaffoldPage.withPadding(
      //scrollController: AppTheme.mainScrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: SizedBox(
        //width: double.infinity,
        height: tapviewContentHeight,
        child: DefaultTabController(
          initialIndex: 0,
          length: currTabs.length,
          child: Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              backgroundColor: Colors.transparent,
              elevation: 0.0,
              title: TabBar(
                indicatorColor: Colors.black,
                labelStyle: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
                unselectedLabelStyle: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                indicatorWeight: 10,
                indicatorSize: TabBarIndicatorSize.label,
                labelColor: Colors.black,
                isScrollable: true,
                padding: const EdgeInsets.all(0),
                labelPadding: const EdgeInsets.all(0),
                tabs: currTabs,
              ),
            ),
            body: Padding(
              padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
              child: TabBarView(
                physics: const NeverScrollableScrollPhysics(),
                children: <Widget>[
                  FAQShopInfoMain(tabviewHeight: tapviewContentHeight),
                  FAQOperateInfoMain(tabviewHeight: tapviewContentHeight),
                  FAQEventInfoMain(tabviewHeight: tapviewContentHeight),
                  FAQCEOInfoMain(tabviewHeight: tapviewContentHeight),
                  FAQPOSInfoMain(tabviewHeight: tapviewContentHeight),
                ],
              ),
            ),
          ),
        ),
      ),
    );


  }

  requestAPIData() async {
  }
}