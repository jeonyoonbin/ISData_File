


import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';

class FAQEventInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const FAQEventInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<FAQEventInfoMain> createState() => _FAQEventInfoMainState();
}

class _FAQEventInfoMainState extends State<FAQEventInfoMain> {

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    fluentUI.ButtonState<Color> headerColor = fluentUI.ButtonState.resolveWith((states) => Colors.grey.shade200);
    const headerTextStyle = TextStyle(fontSize: 16, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);
    const contentTextStyle = TextStyle(fontSize: 15, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);//letterSpacing: 0.6,

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[행복페이 할인] 행복페이로 결제 하면 최대 15% 할인?','대구행복페이 카드는 현재 대구시 정책상, 한달에 최대 50만원까지 사용가능하며 충전시 10% 할인혜택을 받을 수 있습니다. 추가적으로, 대구로는 지역화폐 사용을 독려하기 위해 대구시와 협의하여, 행복페이로 앱바로결제 시, 자체적으로 5% 추가할인을 제공합니다.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[수수료 면제] 책자에 매출 약 50만원까지 중개수수료 면제라고 되어 있는데 무슨 말이에요?','현재 대구로에 입점하시는 사장님들에게 ‘대구로’는 10,000원의 입점 축하금을 지급하고 있습니다. 이에 따라 매출 50만원의 2%의 금액이 10,000원이며, 매출 50만원까지는 중개수수료를 부담하지 않더라도, 입점축하금으로 제공한 10,000원으로 수수료로서 사용가능하다는 광고입니다.',Responsive.isMobile(context) ? 100 : 56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[행복페이 할인] 적립금 출금 시에, 출금가능액이 적립금액보다 10,000원 적어요.','입점축하금으로 드린 10,000원은 수수료로서 사용하실 수 있게 제공해 드리고 있습니다. 이에 따라 적립금 출금 시에는 10,000원 이상 보존하도록 시스템화 되어있습니다. 또한 현재 입점축하금의 단독적인 출금은 불가능합니다.',Responsive.isMobile(context) ? 100 : 56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[쿠폰] 첫주문 할인쿠폰은 어떻게 지급하나요?','대구로 어플 회원가입 시 제공되며, 발행 계정 당 1회 지급을 합니다.\n(회원탈퇴 후, 재가입시는 지급불가)',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[쿠폰] 할인쿠폰은 중복으로 사용가능 한가요?','저희가 제공하는 첫 주문 할인쿠폰, 재주문 쿠폰, 옥의티를 찾아라 이벤트 쿠폰은 모두 재사용 및 쿠폰중복사용이 불가합니다.',56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[쿠폰] 대구로 SNS 팔로워 이벤트를 하려고 하는데, 인스타그램과 블로그 두 곳 다 올리고 싶어요. 가능한가요?','네. 인스타그램과 블로그 중복참여 가능합니다. 포스팅은 1인 1개씩만 참여가능하며, 복수당첨은 1개 당첨으로 처리됩니다.',Responsive.isMobile(context) ? 100 : 56),
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[쿠폰] (재주문 쿠폰문의) 제가 어제 2회 이상 주문을 했는데, 재주문 쿠폰 2개 주시는 건가요?','아닙니다. 전일 2회이상을 주문하더라도 무조건 1개의 쿠폰을 제공해드립니다.',Responsive.isMobile(context) ? 100 : 56),
        ],
          ),
    );
  }
  fluentUI.Expander FAQform(fluentUI.ButtonState<fluentUI.Color> headerColor, fluentUI.TextStyle headerTextStyle, fluentUI.TextStyle contentTextStyle, headerText, contentText, headerHeight) {
    return fluentUI.Expander(
        headerHeight: headerHeight,
        contentPadding: EdgeInsets.symmetric(vertical: 15,horizontal: 10),
              headerBackgroundColor: headerColor,
              shapeRadius: 0.0,
              contentBackgroundColor: Colors.transparent,
        header: Text(headerText, style: headerTextStyle),
        content: SingleChildScrollView(
            child: Text(contentText,
                      style: contentTextStyle)
              )
    );
  }
  requestAPIData() async {
  }
}