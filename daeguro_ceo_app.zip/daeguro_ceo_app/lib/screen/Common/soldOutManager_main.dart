

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/screen/Common/soldOutMenuInfo_main.dart';
import 'package:daeguro_ceo_app/screen/Common/soldOutOptionInfo.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';

class SoldOutManagerMain extends StatefulWidget {
  const SoldOutManagerMain({Key? key}) : super(key: key);

  @override
  State<SoldOutManagerMain> createState() => _SoldOutManagerMainState();
}

class _SoldOutManagerMainState extends State<SoldOutManagerMain> with PageMixin{
  List<Tab> currTabs = <Tab>[
    Tab(height: 60, text: AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD ? '     메뉴 품절     ' : '     상품 품절     '),
    const Tab(height: 60, text: '     옵션 품절     '),
  ];

  @override
  void initState() {
    super.initState();
    //debugPrint('initState SoldOutManagerMain');
    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {
    //debugPrint('dispose SoldOutManagerMain');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    double tapviewContentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 280 : 330);

    return fluentUI.ScaffoldPage.withPadding(
      //scrollController: AppTheme.mainScrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: SizedBox(
        //width: double.infinity,
        height: tapviewContentHeight,
        child: DefaultTabController(
          initialIndex: 0,
          length: currTabs.length,
          child: Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              backgroundColor: Colors.transparent,
              elevation: 0.0,
              title: TabBar(
                indicatorColor: Colors.black,
                labelStyle: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
                unselectedLabelStyle: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                indicatorWeight: 10,
                indicatorSize: TabBarIndicatorSize.label,
                labelColor: Colors.black,
                isScrollable: true,
                padding: const EdgeInsets.all(0),
                labelPadding: const EdgeInsets.all(0),
                tabs: currTabs,
              ),
            ),
            body: Padding(
              padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
              child: TabBarView(
                physics: const NeverScrollableScrollPhysics(),
                children: <Widget>[
                  SoldOutMenuInfoMain(tabviewHeight: tapviewContentHeight),
                  SoldOutOptionInfoMain(tabviewHeight: tapviewContentHeight),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}