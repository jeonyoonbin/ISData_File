import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListModel.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:provider/provider.dart';

class CommonPopupMain extends StatefulWidget {
  final List<NoticeListModel>? sData;

  const CommonPopupMain({Key? key, this.sData})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CommonPopupMainState();
  }
}

class CommonPopupMainState extends State<CommonPopupMain> {
  int totalCnt = 0;
  int currentIdx = 0;

  List<NoticeListModel> listData = [];

  @override
  void initState() {
    super.initState();

    //debugPrint('initState CommonPopupMain');

    listData = widget.sData!;

    totalCnt = widget.sData!.length;
  }
  @override
  void dispose() {
    super.dispose();
    listData.clear();
    widget.sData?.clear();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 500.0, maxHeight: 720),
      //contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      isPopupNotice: true,
      title: null,
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Card(
          clipBehavior: Clip.antiAlias,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(12))),
          margin: EdgeInsets.zero,
          child: listData[currentIdx].noticeUrl1 == null
              ? const Image(image: AssetImage('images/thumbnail-empty.png'))
              : Image.network('${listData[currentIdx].noticeUrl1!}?tm=${Utils.getTimeStamp()}', fit: BoxFit.fill, gaplessPlayback: true,
            errorBuilder: (context, error, stackTrace) {
              return const Image(image: AssetImage('images/thumbnail-empty.png'));
            },
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              String disabledDate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
              GetStorage().write('popupEnabled${listData[currentIdx].noticeSeq}', disabledDate);
              debugPrint('popupEnabled${listData[currentIdx].noticeSeq} :: ${disabledDate}');

              if (currentIdx < (totalCnt-1)) {
                currentIdx++;

                setState(() {});
              }
              else{
                Navigator.pop(context);
              }
            },
            child: const Text('오늘 하루 열지 않기', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (currentIdx < (totalCnt-1)) {
                currentIdx++;

                setState(() {});
              }
              else{
                Navigator.pop(context);
              }
            },
            child: const Text('닫기', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


