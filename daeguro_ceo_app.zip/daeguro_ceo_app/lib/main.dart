
import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/models/Common/linkToModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/LogInManager/UserNotifier.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/deferred_widget.dart';
import 'package:fluent_ui/fluent_ui.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' as material;
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:url_strategy/url_strategy.dart';
import 'package:provider/provider.dart';

import 'package:encrypt/encrypt.dart' as EncryptPack;
import 'package:crypto/crypto.dart' as CryptoPack;
import 'dart:convert' as ConvertPack;

const String appTitle = '대구로 사장님사이트';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await GetStorage.init();

  Get.put(AuthService());

  try{
    debugPrint('url: ${Uri.base}');
    //debugPrint('query: ${Uri.base.queryParameters['url']}');

    //final baseUri = Uri.parse(Uri.parse("https://dgpub.282.co.kr:8501/#/LinkTo?url=egu1VX%2fYl%2fiqCZ0xcMIjV8km%2f2MBReAR1yPy27jNaLSITEFpMDL%2fAMzBKcBd0E9TompTI1MXa6xf1qMPP8LUMq4aSZ5SuOVL0BKmHGU%2fglr8Xj6dSBhkn2a%2fgOPMlU5sDfS6Qe2xFzwkbsVcdsqdg0lqgnYU8Lex6WR9SU1X%2bKY%3d").fragment);
    final baseUri = Uri.parse(Uri.base.fragment);
    //print('baseUri.queryParameters: ${baseUri.queryParameters}');

    if (baseUri.queryParameters['url'] != null){
      String? linkToUrl = baseUri.queryParameters['url'];
      //debugPrint('linkToUrl: ${linkToUrl}');

      if (linkToUrl != null ||  linkToUrl != ''){
        dynamic result = Utils.requestAESDecrypt(linkToUrl!);

        //debugPrint('requestAESDecrypt after result:${result.toString()}');

        Map<String, dynamic> value = json.decode(result);
        LinkToModel tempLinkData = LinkToModel.fromJson(value);
        AuthService.linkToModel = tempLinkData;
        AuthService.initLocation = '/LinkTo';
      }
    }
  } catch (ex){
    debugPrint('LinkTo Exception:${ex.toString()}');
  }

  setPathUrlStrategy();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  // private navigators

  @override
  Widget build(BuildContext context) {
    return MultiProvider ( //ChangeNotifierProvider(//
          //create: (_) => AppTheme(),
          providers: [
            ChangeNotifierProvider<UserNotifier>.value(value: userStatus),
            ChangeNotifierProvider<AppTheme>(create: (_) => AppTheme()),
          ],
          builder: (context, _) {
            final appTheme = context.watch<AppTheme>();

            return FluentApp.router(
              showSemanticsDebugger: false,
              debugShowCheckedModeBanner: false,
              title: appTitle,
              themeMode: ThemeMode.light,
              color: const Color(0xff01CAFF),//appTheme.color,
              // darkTheme: FluentThemeData(
              //   fontFamily: 'NotoSansKR',
              //   brightness: Brightness.dark,
              //   //accentColor: appTheme.color,
              //   visualDensity: VisualDensity.standard,
              //   focusTheme: FocusThemeData(glowFactor: is10footScreen(context) ? 2.0 : 0.0,),
              // ),
              theme: FluentThemeData(
                fontFamily: 'HanSansNeo',
                //accentColor: appTheme.color,
                visualDensity: VisualDensity.standard,
                brightness: Brightness.light,
                focusTheme: FocusThemeData(glowFactor: is10footScreen(context) ? 2.0 : 0.0,),
                scrollbarTheme: const ScrollbarThemeData(
                    thickness: 6.0, hoveringThickness: 6.0,
                    radius: Radius.zero, hoveringRadius: Radius.zero,
                    scrollbarColor: Color(0xFFc1c1c1),//Color(0xFFf3f3f3),
                    // backgroundColor:

                ),
                toggleButtonTheme: ToggleButtonThemeData(
                  checkedButtonStyle: ButtonStyle(
                      backgroundColor: ButtonState.resolveWith((states) {
                        return Colors.blue.withOpacity(0.12);
                        //theme.colorScheme.onSurface.withOpacity(0.87)
                      }),
                      textStyle: ButtonState.resolveWith((states) {
                        return TextStyle(color: Colors.blue.withOpacity(0.12), fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD);
                        //theme.colorScheme.onSurface.withOpacity(0.87)
                      })
                      // backgroundColor: ButtonState.resolveWith((states) {
                      //   return Color(0xff01CAFF);
                      //   //theme.colorScheme.onSurface.withOpacity(0.87)
                      // }),
                  ),
                  uncheckedButtonStyle: ButtonStyle(
                      backgroundColor: ButtonState.resolveWith((states) {
                        return Colors.white;
                      }),
                      textStyle: ButtonState.resolveWith((states) {
                        return const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD);
                        //theme.colorScheme.onSurface.withOpacity(0.87)
                      })
                  )
                ),
                scaffoldBackgroundColor: Colors.white,//백그라운드 테마 변경
                //dividerTheme: const DividerThemeData(decoration: BoxDecoration(color: Colors.black,),),

                // navigationPaneTheme: NavigationPaneThemeData(
                //     backgroundColor: Color(0xff2d3341),//Colors.teal
                //     itemHeaderTextStyle: TextStyle(color: Colors.white),
                //     highlightColor: Color(0xfff9f9f9),//Colors.white,
                // ),
              ),
              localizationsDelegates: const [
                GlobalCupertinoLocalizations.delegate,
                GlobalMaterialLocalizations.delegate,
                GlobalWidgetsLocalizations.delegate,
              ],
              locale: const Locale('ko', 'KR'),//appTheme.locale,
              supportedLocales: const [Locale('ko', 'KR'),],
              builder: (context, child) {
                return NavigationPaneTheme(
                  data: NavigationPaneThemeData(
                    backgroundColor: Colors.white,//백그라운드 테마 변경 //Color(0xff2d3341),//사장님사이트 원본 색상
                    selectedTextStyle: ButtonState.resolveWith((states) {
                      return const TextStyle(color: Color(0xff01CAFF));
                    }),
                    // unselectedTextStyle: ButtonState.resolveWith((states) {
                    //   return const TextStyle(color: Color(0x00000000));//const TextStyle(color: Color(0xffffffff));
                    // }),
                  ),
                  child: child!,
                );
              },
              backButtonDispatcher: router.backButtonDispatcher,
              routeInformationParser: router.routeInformationParser,
              routerDelegate: router.routerDelegate,
              routeInformationProvider: router.routeInformationProvider,
            );
          },
          // child: FittedBox(
          //   child: material.FloatingActionButton(
          //     onPressed: onPressed,
          //     child: Icon(material.Icons.edit, color: Colors.red,),
          //   ),
          // ),
        );
  }
}







