import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOptionGroupNewItemModel {
  ProductOptionGroupNewItemModel();

  String? name;
  String? cost;
}