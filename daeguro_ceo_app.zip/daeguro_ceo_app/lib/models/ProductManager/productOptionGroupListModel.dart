import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOptionGroupListModel {
  ProductOptionGroupListModel();

  bool selected = false;

  String? optionGroupCd;
  String? name;
  String? useGbn;
  String? minCount;
  String? multiCount;
  String? optNames;
  String? optCode;
  String? connectProd;
}