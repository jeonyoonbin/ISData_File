import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOptionLinkDeleteModel {
  String? shopCd;
  String? prodCd;
  String? optGrpCd;
  String? prodOptGrpCd;
  String? uCode;
  String? uName;

  ProductOptionLinkDeleteModel({this.shopCd, this.prodCd, this.uCode, this.uName});

  ProductOptionLinkDeleteModel.fromJson(Map<String, dynamic> json) {
    shopCd = json['shopCd'];
    prodCd = json['prodCd'];
    optGrpCd = json['optGrpCd'];
    prodOptGrpCd = json['prodOptGrpCd'];
    uCode = json['uCode'];
    uName = json['uName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['shopCd'] = shopCd;
    data['prodCd'] = prodCd;
    data['optGrpCd'] = optGrpCd;
    data['prodOptGrpCd'] = prodOptGrpCd;
    data['uCode'] = uCode;
    data['uName'] = uName;
    return data;
  }
}