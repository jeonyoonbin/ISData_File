import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductTopMenuAddModel {
  String? shopCd;
  List<String>? prodCd;
  String? uCode;
  String? uName;

  ProductTopMenuAddModel({this.shopCd, this.prodCd, this.uCode, this.uName});

  ProductTopMenuAddModel.fromJson(Map<String, dynamic> json) {
    shopCd = json['shopCd'];
    prodCd = json['prodCd'].cast<String>();
    uCode = json['uCode'];
    uName = json['uName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['shopCd'] = shopCd;
    data['prodCd'] = prodCd;
    data['uCode'] = uCode;
    data['uName'] = uName;
    return data;
  }
}