import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOptionGroupEditModel {
  ProductOptionGroupEditModel();

  bool selected = false;
  String? shopCd;
  String? optGrpCd;
  String? name;
  String? minCnt;
  String? multiCnt;
  String? useGbn;
  String? uCode;
  String? uName;

  factory ProductOptionGroupEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ProductOptionGroupEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ProductOptionGroupEditModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd']
    ..optGrpCd = json['optGrpCd']
    ..name = json['name']
    ..minCnt = json['minCnt']
    ..multiCnt = json['multiCnt']
    ..useGbn = json['useGbn']
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(ProductOptionGroupEditModel instance) => <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'optGrpCd': instance.optGrpCd,
      'name': instance.name,
      'minCnt': instance.minCnt,
      'multiCnt': instance.multiCnt,
      'useGbn': instance.useGbn,
      'uCode': instance.uCode,
      'uName': instance.uName
    };
