import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductListEditModel {
  ProductListEditModel();

  bool selected = false;
  String? shopCd;
  String? prodCd;
  List<String>? catCode;
  List<String>? themaCode;
  String? name;
  String? cost;
  String? amount;
  String? discAmt;
  String? discRatio;
  String? discStDt;
  String? discToDt;
  String? ribbonCardYn;
  String? useGbn;
  String? noFlag;
  String? mainYn;
  String? discMarkGbn;
  String? uCode;
  String? uName;

  factory ProductListEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ProductListEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ProductListEditModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd']
    ..prodCd = json['prodCd']
    ..catCode = json['catCode'].cast<String>()
    ..themaCode = json['themaCode'].cast<String>()
    ..name = json['name']
    ..cost = json['cost']
    ..amount = json['amount']
    ..discAmt = json['discAmt']
    ..discRatio = json['discRatio']
    ..discStDt = json['discStDt']
    ..discToDt = json['discToDt']
    ..ribbonCardYn = json['ribbonCardYn']
    ..useGbn = json['useGbn']
    ..noFlag = json['noFlag']
    ..mainYn = json['mainYn']
    ..discMarkGbn = json['discMarkGbn']
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(ProductListEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'prodCd': instance.prodCd,
      'catCode': instance.catCode,
      'themaCode': instance.themaCode,
      'name': instance.name,
      'cost': instance.cost,
      'amount': instance.amount,
      'discAmt': instance.discAmt,
      'discRatio': instance.discRatio,
      'discStDt': instance.discStDt,
      'discToDt': instance.discToDt,
      'ribbonCardYn': instance.ribbonCardYn,
      'useGbn': instance.useGbn,
      'noFlag': instance.noFlag,
      'mainYn': instance.mainYn,
      'discMarkGbn': instance.discMarkGbn,
      'uCode': instance.uCode,
      'uName': instance.uName
    };
