

import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductLegalInfoModel {
  ProductLegalInfoModel();

  bool selected = false;
  String? jobGbn;
  String? shopCd;
  String? prodCd;
  //String? lAuth;
  //String? lTel;
  String? lName;
  String? lModel;
  String? lMarker;
  //String? lSeller;
  String? uCode;
  String? uName;

  factory ProductLegalInfoModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ProductLegalInfoModel _$ModelFromJson(Map<String, dynamic> json) {
  return ProductLegalInfoModel()
  // ..selected = json['selected'] as bool
    ..jobGbn = json['jobGbn']
    ..shopCd = json['shopCd']
    ..prodCd = json['prodCd']
    //..lAuth = json['lAuth']
    //..lTel = json['lTel']
    ..lName = json['lName']
    ..lModel = json['lModel']
    ..lMarker = json['lMarker']
    //..lSeller = json['lSeller']
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(ProductLegalInfoModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'jobGbn': instance.jobGbn,
      'shopCd': instance.shopCd,
      'prodCd': instance.prodCd,
      //'lAuth': instance.lAuth,
      //'lTel': instance.lTel,
      'lName': instance.lName,
      'lModel': instance.lModel,
      'lMarker': instance.lMarker,
      //'lSeller': instance.lSeller,
      'uCode': instance.uCode,
      'uName': instance.uName
    };