import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveReviewImageInsertModel {
  ReserveReviewImageInsertModel();

  String? ccCode = '';
  String? shopCode = '';
  List<dynamic>? file = [];


  factory ReserveReviewImageInsertModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveReviewImageInsertModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveReviewImageInsertModel()
    ..ccCode = json['ccCode']
    ..shopCode = json['shopCode']
    ..file = json['file'];
}

Map<String, dynamic> _$ModelToJson(ReserveReviewImageInsertModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'ccCode': instance.ccCode,
      'shopCode': instance.shopCode,
      'file': instance.file
    };
