import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveReviewIntroModel {
  ReserveReviewIntroModel();

  String? shopCd;
  String? ccCode;
  String? shopReviewIntro;
  String? userID;

  factory ReserveReviewIntroModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveReviewIntroModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveReviewIntroModel()
    ..shopCd = json['shopCd'] as String
    ..ccCode = json['ccCode'] as String
    ..shopReviewIntro = json['shopReviewIntro'] as String
    ..userID = json['userID'] as String;
}

Map<String, dynamic> _$ModelToJson(ReserveReviewIntroModel instance) => <String, dynamic>{
  'shopCd': instance.shopCd,
  'ccCode': instance.ccCode,
  'shopReviewIntro': instance.shopReviewIntro,
  'userID': instance.userID
};