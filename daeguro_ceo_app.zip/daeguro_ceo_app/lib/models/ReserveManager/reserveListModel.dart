import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveListModel {
  ReserveListModel();

  int? orderNo;
  String? reserDate;
  String? reserTime;
  int? custCode;
  String? custId;
  String? custName;
  String? custTelno;
  String? mobileNo;
  String? mobileNo1;
  String? injengGbn;
  int? personCnt;
  String? status;
  String? allocDate;
  String? compDate;
  String? cancelDate;
  String? payGbn;
  int? orderNoCard;
  String? location = '';
  String? memo = '';
  String? isrtDate = '';
  String? modDate = '';
  String? modId = '';
  String? modGbn = '';
  String? myNumber = '';
}
