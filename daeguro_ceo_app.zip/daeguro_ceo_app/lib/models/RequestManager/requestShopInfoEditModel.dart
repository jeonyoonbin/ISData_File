import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class RequestShopInfoEditModel {
  RequestShopInfoEditModel();

  String? seq = '';
  String? shopCd = '';
  String? status = '';
  String? serviceGbn = '';
  String? filter = '';
  String? afterShopName = '';
  String? beforeShopName = '';
  String? afterMobile = '';
  String? beforeMobile = '';
  String? groupCd = '';
  String? menuCd = '';
  String? menuName = '';
  String? beforeImageUrl = '';
  String? uCode = '';
  String? uName = '';
  List<dynamic>? formFiles = [];


  factory RequestShopInfoEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

RequestShopInfoEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return RequestShopInfoEditModel()
    ..seq = json['seq']
    ..shopCd = json['shopCd']
    ..status = json['status']
    ..serviceGbn = json['serviceGbn']
    ..filter = json['filter']
    ..afterShopName = json['afterShopName']
    ..beforeShopName = json['beforeShopName']
    ..afterMobile = json['afterMobile']
    ..beforeMobile = json['beforeMobile']
    ..groupCd = json['groupCd']
    ..menuCd = json['menuCd']
    ..menuName = json['menuName']
    ..beforeImageUrl = json['beforeImageUrl']
    ..uCode = json['uCode']
    ..uName = json['uName']
    ..formFiles = json['formFiles'].cast<String>();
}

Map<String, dynamic> _$ModelToJson(RequestShopInfoEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'seq': instance.seq,
      'shopCd': instance.shopCd,
      'status': instance.status,
      'serviceGbn': instance.serviceGbn,
      'filter': instance.filter,
      'afterShopName': instance.afterShopName,
      'beforeShopName': instance.beforeShopName,
      'afterMobile': instance.afterMobile,
      'beforeMobile': instance.beforeMobile,
      'groupCd': instance.groupCd,
      'menuCd': instance.menuCd,
      'menuName': instance.menuName,
      'beforeImageUrl': instance.beforeImageUrl,
      'uCode': instance.uCode,
      'uName': instance.uName,
      'formFiles': instance.formFiles
    };
