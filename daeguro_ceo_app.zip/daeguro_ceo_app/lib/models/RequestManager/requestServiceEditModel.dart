import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class RequestServiceEditModel {
  RequestServiceEditModel();

  String? seq;
  String? shopCd;
  String? status;
  String? serviceGbn;
  String? uCode;
  String? uName;
  String? serviceData;
  String? filter;
  String? fileName;

  factory RequestServiceEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

RequestServiceEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return RequestServiceEditModel()
    ..seq = json['seq']
    ..shopCd = json['shopCd']
    ..status = json['status']
    ..serviceGbn = json['serviceGbn']
    ..uCode = json['uCode']
    ..uName = json['uName']
    ..serviceData = json['serviceData']
    ..filter = json['filter']
    ..fileName = json['fileName'];
}

Map<String, dynamic> _$ModelToJson(RequestServiceEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'seq': instance.seq,
      'shopCd': instance.shopCd,
      'status': instance.status,
      'serviceGbn': instance.serviceGbn,
      'uCode': instance.uCode,
      'uName': instance.uName,
      'serviceData': instance.serviceData,
      'filter': instance.filter,
      'fileName': instance.fileName
    };
