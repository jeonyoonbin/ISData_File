import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class NoticeListModel {
  NoticeListModel();

  bool? selected = false;
  //int? rNum = 0;
  String? rnum;
  String? noticeSeq;
  String? noticeGbn;
  String? dispGbn;
  String? dispFrDate;
  String? dispToDate;
  String? noticeTitle;
  String? noticeContents;
  String? noticeUrl1;
  String? noticeUrl2;
  String? noticeUrl3;
  String? orderDate;
  String? insDate;
  String? sortSeq;
  String? extUrlYn;
}