import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopNotifyInfoDetailModel {
  ShopNotifyInfoDetailModel();

  String? introCd = '';
  String? shopCd = '';
  String? introGbn = '';
  String? introContents = '';
  String? modDate = '';
  String? introImage = '';
  String? introImage2 = '';
  String? useGbn = '';
}