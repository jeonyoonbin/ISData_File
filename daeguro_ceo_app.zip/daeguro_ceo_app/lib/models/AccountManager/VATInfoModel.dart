class VATInfoModel {
  VATInfoModel({
    this.outComeTitle,
    this.outComeAmt,
    this.outComeVat,
    this.outComeTotal,
    this.inComeTitle,
    this.inComeCnt,
    this.inComeAmt,
    this.inComeVat,
    this.inComeTotal,
  });


  String? outComeTitle = '';
  String? outComeAmt = '';
  String? outComeVat = '';
  String? outComeTotal = '';
  String? inComeTitle = '';
  String? inComeCnt = '';
  String? inComeAmt = '';
  String? inComeVat = '';
  String? inComeTotal = '';

  // "totalCardAmt": "103400",//카드 매출(합계)
  // "cardAmt": "93995", //카드 매출(매출)
  // "cardVatAmt": "9405",//카드 매출(부가세)
  // "cashAmt": "0",//현금영수증 매출(매출)
  // "cashVatAmt": "0",//현금영수증 매출(부가세)
  // "totalCashAmt": "0",//현금영수증 매출(합계)
  // "totalCashIngAmt": "0",//현금영수증 처리중인건(합계)
  // "cashIngAmt": "0",//현금영수증 처리중인건(매출)
  // "cashIngVatAmt": "0",//현금영수증 처리중인건(부가세)
  // "totalEtcAmt": "4500", //기타(합계)
  // "etcAmt": "1638",    //기타(매출)
  // "etcVatAmt": "2862", //기타(부가세)
  // "totalMeetCashAmt": "0",//만나서 현금(합계)
  // "meetCashAmt": "0",  //만나서 현금 (매출)
  // "meetCashVatAmt": "0",//만나서 현금(부가세)
  // "totalMeetCardAmt": "0",//만나서 카드(합계)
  // "meetCardAmt": "0", // 만나서 카드(매출)
  // "meetCardVatAmt": "0", // 만나서 카드(부가세)
}
