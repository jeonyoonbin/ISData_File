import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class LiveEventTargetMenuListModel {
  LiveEventTargetMenuListModel();

  bool? selected = false;
  String? menuCd = '';
  String? menuIdx = '';
  String? menuName = '';
  String? menuPrice = '';
  String? menuDiscCost = '';
  String? menuDiscPer = '';
  String? totalPrice = '';
  String? eventAmt = '';
  String? eventGbn = '1'; //1:정액(할인금액), 3:정율(할인율)
  String? menuSeq = '';
  String? shopCd = '';
  String? uName = '';
}