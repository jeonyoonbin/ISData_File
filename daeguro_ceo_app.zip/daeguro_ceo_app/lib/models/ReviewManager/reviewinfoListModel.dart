class ReviewinfoListModel {
  ReviewinfoListModel({
    this.custNickName,
    this.orderNo,
    this.insertDate,
    this.starScore,
    this.reviewImage,
    this.blindStandDt,
    this.blindEndDt,
    this.orderMenu,
    this.content,
    this.answerContent,
    //this.isBlind,
    this.isShown,
    this.blindRemain,
    this.visibleGbn,
    this.answerVisibleGbn,
    this.blindType,
    this.images
  });
  bool selected = false;
  //bool? isBlind = false;
  bool? isShown = false;

  String? custNickName;
  String? orderNo;
  String? insertDate;
  int? starScore;
  String? reviewImage;
  String? blindStandDt;
  String? blindEndDt;
  String? orderMenu;
  String? content;
  String? answerContent;
  String? answerInsertDate;
  String? blindRemain;
  String? visibleGbn;
  String? answerVisibleGbn;
  String? blindType;
  List<dynamic>? images = [];

  factory ReviewinfoListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);

}

ReviewinfoListModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReviewinfoListModel()
    ..custNickName = json['custNickName']
    ..orderNo = json['orderNo']
    ..insertDate = json['insertDate']
    ..starScore = json['starScore'] as int
    ..reviewImage = json['reviewImage']
    ..blindStandDt = json['blindStandDt']
    ..blindEndDt = json['blindEndDt']
    ..orderMenu = json['orderMenu']
    ..content = json['content']
    ..answerContent = json['answerContent']
    ..answerInsertDate = json['answerInsertDate']
    ..blindRemain = json['blindRemain']
    ..visibleGbn = json['visibleGbn']
    ..answerVisibleGbn = json['answerVisibleGbn']
    ..blindType = json['blindType']
    ..images = json['images'].cast<String>()
  ;
}

Map<String, dynamic> _$ModelToJson(ReviewinfoListModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'custNickName': instance.custNickName,
      'orderNo': instance.orderNo,
      'insertDate': instance.insertDate,
      'starScore': instance.starScore,
      'reviewImage': instance.reviewImage,
      'blindStandDt': instance.blindStandDt,
      'blindEndDt': instance.blindEndDt,
      'orderMenu': instance.orderMenu,
      'content': instance.content,
      'answerContent': instance.answerContent,
      'answerInsertDate': instance.answerInsertDate,
      'blindRemain': instance.blindRemain,
      'visibleGbn': instance.visibleGbn,
      'answerVisibleGbn': instance.answerVisibleGbn,
      'blindType': instance.blindType,
      'images': instance.images
    };
