class DashboardWeekOrderModel {
  DashboardWeekOrderModel();

  String? orderDate;
  String? appPayGbn;
  String? appYn;
  String? packOrderName;
  String? payGbn;
  String? payGbnName;
  int? totCnt;
  int? totAmt;
  int? okCnt;
  int? okAmt;
  int? cancelCnt;
  int? cancelAmt;
  String? discAmt;
  String? amount;
}
