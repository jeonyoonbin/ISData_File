import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionCountSettingModel {
  OptionCountSettingModel();

  bool selected = false;
  String? shopCd;
  String? optGrpCd;
  String? minCount;
  String? multiCount;
  String? multiYn;
  String? reqYn;
  String? uName;

  factory OptionCountSettingModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

OptionCountSettingModel _$ModelFromJson(Map<String, dynamic> json) {
  return OptionCountSettingModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd']
    ..optGrpCd = json['optGrpCd']
    ..minCount = json['minCount']
    ..multiCount = json['multiCount']
    ..multiYn = json['multiYn']
    ..reqYn = json['reqYn']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(OptionCountSettingModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'optGrpCd': instance.optGrpCd,
      'minCount': instance.minCount,
      'multiCount': instance.multiCount,
      'multiYn': instance.multiYn,
      'reqYn': instance.reqYn,
      'uName': instance.uName
    };
