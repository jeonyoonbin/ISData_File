import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class MenuTopListEditModel {
  MenuTopListEditModel();

  bool selected = false;
  String? shopCd;
  String? mainYn;
  String? menuCd;
  String? uCode;
  String? uName;

  factory MenuTopListEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

MenuTopListEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return MenuTopListEditModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd'] as String
    ..mainYn = json['mainYn'] as String
    ..menuCd = json['menuCd'] as String
    ..uCode = json['uCode'] as String
    ..uName = json['uName'] as String;
}

Map<String, dynamic> _$ModelToJson(MenuTopListEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'mainYn': instance.mainYn,
      'menuCd': instance.menuCd,
      'uCode': instance.uCode,
      'uName': instance.uName
    };
