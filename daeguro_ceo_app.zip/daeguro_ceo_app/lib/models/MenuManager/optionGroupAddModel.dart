import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionGroupAddModel {
  OptionGroupAddModel();

  bool selected = false;
  String? shopCd;
  String? groupName;
  String? groupMemo;
  List<String>? optionName;
  List<String>? optionCost;
  String? minCount;
  String? maxCount;
  String? multiYn;
  String? useYn;
  String? reqYn;
  String? uName;

  factory OptionGroupAddModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

OptionGroupAddModel _$ModelFromJson(Map<String, dynamic> json) {
  return OptionGroupAddModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd']
    ..groupName = json['groupName']
    ..groupMemo = json['groupMemo']
    ..optionName = json['optionName'].cast<String>()
    ..optionCost = json['optionCost'].cast<String>()
    ..minCount = json['minCount']
    ..maxCount = json['maxCount']
    ..multiYn = json['multiYn']
    ..useYn = json['useYn']
    ..reqYn = json['reqYn']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(OptionGroupAddModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'groupName': instance.groupName,
      'groupMemo': instance.groupMemo,
      'optionName': instance.optionName,
      'optionCost': instance.optionCost,
      'minCount': instance.minCount,
      'maxCount': instance.maxCount,
      'multiYn': instance.multiYn,
      'useYn': instance.useYn,
      'reqYn': instance.reqYn,
      'uName': instance.uName
    };
