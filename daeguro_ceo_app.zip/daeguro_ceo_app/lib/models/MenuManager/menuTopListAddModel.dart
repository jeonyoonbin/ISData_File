import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class MenuTopListAddModel {
  MenuTopListAddModel();

  bool selected = false;
  String? shopCd;
  List<String>? menuCd;
  String? uCode;
  String? uName;

  factory MenuTopListAddModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

MenuTopListAddModel _$ModelFromJson(Map<String, dynamic> json) {
  return MenuTopListAddModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd']
    ..menuCd = json['menuCd'].cast<String>()
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(MenuTopListAddModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'menuCd': instance.menuCd,
      'uCode': instance.uCode,
      'uName': instance.uName
    };
