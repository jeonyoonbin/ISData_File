import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class MenuGroupEditModel {
  MenuGroupEditModel();

  String? shopCd;
  String? groupCd;
  String? groupName;
  String? groupMemo;
  String? useYn;
  String? uName;

  factory MenuGroupEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

MenuGroupEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return MenuGroupEditModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd']
    ..groupCd = json['groupCd']
    ..groupName = json['groupName']
    ..groupMemo = json['groupMemo']
    ..useYn = json['useYn']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(MenuGroupEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'groupCd': instance.groupCd,
      'groupName': instance.groupName,
      'groupMemo': instance.groupMemo,
      'useYn': instance.useYn,
      'uName': instance.uName
    };
