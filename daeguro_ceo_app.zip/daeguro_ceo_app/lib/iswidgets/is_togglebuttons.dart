
import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:flutter/material.dart';


class ISToggleButtons extends StatefulWidget {
  final List<ISOptionModel> options;
  final Object? defaultValue;
  final double? fontSize;
  final double? buttonWidth;
  final double? buttonHeight;
  final Color? borderColor;
  final ValueChanged? afterOnPress;

  const ISToggleButtons(this.options, {this.defaultValue, this.fontSize, this.buttonWidth, this.buttonHeight, this.borderColor, this.afterOnPress});

  @override
  ISToggleButtonsState createState() => ISToggleButtonsState();
}

class ISToggleButtonsState extends State<ISToggleButtons> {
  List<bool>? isSelected;

  @override
  void initState() {
    super.initState();

    isSelected = widget.options.map((e) => widget.defaultValue == e.value).toList();
  }

  @override
  Widget build(BuildContext context) {
    var list = widget.options.map((e) => SizedBox(
        width: widget.buttonWidth ?? 60,
        child: Text(e.label!, textAlign: TextAlign.center, /*, style: TextStyle(fontSize: widget.fontSize ?? 13, fontFamily: FONT_FAMILY, color: Colors.black54),*/))).toList();

    return SizedBox(
      height: widget.buttonHeight ?? 40,
      child: ToggleButtons(
        fillColor: widget.borderColor ?? Colors.lightBlueAccent,
        selectedColor: Colors.white,
        textStyle: TextStyle(fontSize: widget.fontSize ?? 13, fontFamily: FONT_FAMILY),
        borderRadius: const BorderRadius.all(Radius.circular(2)),
        selectedBorderColor: widget.borderColor ?? Colors.lightBlueAccent,
        //disabledBorderColor: ,
        isSelected: isSelected!,
        onPressed: (index) {
          setState(() {
            for (int i = 0; i < isSelected!.length; i++) {
              setState(() {
                isSelected![i] = i == index;
              });
            }
            widget.afterOnPress!(widget.options[index].value);
          });
        },
        children: list,
      ),
    );
  }
}
