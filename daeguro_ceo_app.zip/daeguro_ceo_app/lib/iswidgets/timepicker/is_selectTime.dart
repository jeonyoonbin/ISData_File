
import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class ISSelectDate extends StatelessWidget {
  final String? value;
  final String? label;
  final double? width;
  final double? padding;
  final bool? enable;
  final ValueChanged? onChange;
  final FormFieldSetter? onSaved;
  final GestureTapCallback? onTap;

  const ISSelectDate({Key? key, this.value, this.label, this.width, this.padding, this.enable = true, this.onChange, this.onSaved, this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      child: TextFormField(
        enabled: enable,
        readOnly: true,
        style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY),
        textAlign: TextAlign.center,
        textAlignVertical: TextAlignVertical.center,
        decoration: InputDecoration(
          isDense: true,
          fillColor: Colors.white,
          //Color(0xffdefcfc),
          filled: true,
          hintText: label,
          hintStyle: const TextStyle(color: Colors.black54, fontSize: 13, fontFamily: FONT_FAMILY),
          enabledBorder: const OutlineInputBorder(
            //borderRadius: BorderRadius.all(Radius.circular(12.0)),
            borderSide: BorderSide(color: Colors.black12, width: 1.0),
          ),
          focusedBorder: const OutlineInputBorder(
            //borderRadius: BorderRadius.all(Radius.circular(10.0)),
            borderSide: BorderSide(color: Colors.lightBlueAccent, width: 1.0),
          ),
        ),

        //style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY),
        controller: TextEditingController(text: value),
        onChanged: (v) {
          if (onChange != null) {
            onChange!(v);
          }
        },
        onTap: onTap,
        onSaved: onSaved,
        // onSaved: (v) {
        //   if (onSaved != null) {
        //     onSaved(v);
        //   }
        // },
      ),
    );
  }
}

///////////// Example
// ISSelectDate(
//   label: '시작시간',
//   value: TimeOfDay.now().toString(),
//   onTap: () async {
//     TimeOfDay? ret = await showTimePicker(
//       context: context,
//       helpText: '시작시간',
//       initialEntryMode:  TimePickerEntryMode.inputOnly,
//       initialTime: const TimeOfDay(hour: 7, minute: 15),
//       builder: (BuildContext context, Widget? child) {
//         return MediaQuery(
//           data: MediaQuery.of(context).copyWith(
//             alwaysUse24HourFormat: true,
//             boldText: true,
//           ),
//           child: child!,
//         );
//       },
//     );
//
//     setState(() {
//       debugPrint('hour:${ret!.hour.toString()}, min:${ret.minute.toString()}');
//       // if (picked != null) {
//       //   formData.display_st_date = formatDate(picked, [yyyy, '-', mm, '-', dd]);
//       //   _startDate = formatDate(picked, [yyyy, '', mm, '', dd]);
//       // }
//     });
//   },
// ),

