import 'package:daeguro_ceo_app/iswidgets/is_tier.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:url_launcher/link.dart';
import 'package:flutter/material.dart';

class SponsorDialog extends StatelessWidget {
  const SponsorDialog({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    return fluentUI.ContentDialog(
      constraints: const BoxConstraints(maxWidth: 600),
      title: Row(
        children: [
          const Icon(fluentUI.FluentIcons.diamond_user, size: 24.0),
          const SizedBox(width: 8.0),
          const Expanded(child: Text('Benefits')),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          Expanded(
            child: ISTier(
              name: 'Royal Secretary',
              price: r'US$6 per month',
              benefits: [
                'General support',
                'Priority on issues fix',
                'Sponsor role on Discord',
                'Be the first to know when a new update rolls out',
              ],
            ),
          ),
          SizedBox(width: 10.0),
          Expanded(
            child: ISTier(
              name: 'Royal Executor',
              price: r'US$15 per month',
              //benifitsColorIndex: 2,
              //benifitsColor: Colors.red,//Color.fromARGB(0, 255, 255, 0),
              benefits: [
                'General support',
                'Priority on issues fix',
                'Sponsor role on Discord',
                'Showcasing in the "Sponsors" section',
                'Be the first to know when a new update rolls out',
                'Private channel on Discord with dedicated help',
              ],
            ),
          )
        ],
      ),
      actions: [
        fluentUI.Button(
          child: const Text('Delete'),
          onPressed: () {
            Navigator.pop(context, 'User deleted file');
            // Delete file here
          },
        ),
        FilledButton(
          child: const Text('Cancel'),
          onPressed: () => Navigator.pop(context, 'User canceled dialog'),
        ),
        // Link(
        //   uri: Uri.parse('https://www.patreon.com/bdlukaa'),
        //   builder: (context, open) => FilledButton(
        //     child: const Text('Become a Sponsor'),
        //     onPressed: open,
        //   ),
        // ),
      ],
    );
  }
}


