import 'dart:convert';

import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class ImageUploadController extends GetxController{
  static ImageUploadController get to => Get.find();



  Future<dynamic> addShopNotifyImageInfo(String introCd, List<int> fileRes1, List<int> fileRes2) async {
    // Dio처리용 예제
    // final formData = dio.FormData.fromMap({
    //   'formFile': dio.MultipartFile.fromBytes(pickedImage1.files.first.bytes)
    // });
    final accessToken = await AuthService.to.userStorage.read(key: '@user_token');

    if (fileRes1 != null){
      await Future.delayed(const Duration(milliseconds: 500), () {
        var request = http.MultipartRequest('PUT', Uri.parse('${ServerInfo.RESTURL_SHOPNOTIFYIMAGE_SET}?div=I&intro_cd=${introCd}&sort=1&ucode=${AuthService.uCode}&uname=${AuthService.uName}'));
        request.headers.addAll({
              'Content-Type' : 'multipart/form-data',
              'Authorization' : 'Bearer $accessToken'
        });

        request.files.add(http.MultipartFile.fromBytes('formFile', fileRes1, filename: 'upload_temp.png'));

        request.send().then((response) async {
          if (response.statusCode == 200) {
          }
          else{
          }
        });
      });
    }

    if (fileRes2 != null) {
      await Future.delayed(const Duration(milliseconds: 500), () {
        var request = http.MultipartRequest('PUT', Uri.parse('${ServerInfo.RESTURL_SHOPNOTIFYIMAGE_SET}?div=I&intro_cd=${introCd}&sort=2&ucode=${AuthService.uCode}&uname=${AuthService.uName}'));
        request.headers.addAll({
          'Content-Type' : 'multipart/form-data',
          'Authorization' : 'Bearer $accessToken'
        });
        request.files.add(http.MultipartFile.fromBytes('formFile', fileRes2, filename: 'upload_temp.png'));

        request.send().then((response) async {
          if (response.statusCode == 200) {
          }
          else{
          }
        });
      });
    }
  }

  Future<dynamic> updateShopNotifyImageInfo(String introCd, String sort, List<int> fileRes) async {
    final accessToken = await AuthService.to.userStorage.read(key: '@user_token');

    var retResult;
    if (fileRes != null){
      var request = http.MultipartRequest('PUT', Uri.parse('${ServerInfo.RESTURL_SHOPNOTIFYIMAGE_SET}?div=I&intro_cd=${introCd}&sort=${sort}&ucode=${AuthService.uCode}&uname=${AuthService.uName}'));
      request.headers.addAll({
        'Content-Type' : 'multipart/form-data',
        'Authorization' : 'Bearer $accessToken'
      });
      request.files.add(http.MultipartFile.fromBytes('formFile', fileRes, filename: 'upload_temp.png'));

      retResult = await request.send();

      return retResult;
    }

    return null;
  }

  Future<dynamic> deleteShopNotifyImageInfo(String introCd, String sort) async {
    final accessToken = await AuthService.to.userStorage.read(key: '@user_token');

    var retResult;

    var request = http.MultipartRequest('PUT', Uri.parse('${ServerInfo.RESTURL_SHOPNOTIFYIMAGE_SET}?div=D&intro_cd=${introCd}&sort=${sort}&ucode=${AuthService.uCode}&uname=${AuthService.uName}'));
    request.headers.addAll({
      'Content-Type' : 'multipart/form-data',
      'Authorization' : 'Bearer $accessToken'
    });

    retResult = await request.send();

    return retResult;
  }

  Future<dynamic> updateRequestSingleImage(String serviceGbn, List<int> fileRes) async {
    final accessToken = await AuthService.to.userStorage.read(key: '@user_token');

    var retResult;

    if (fileRes != null){
      var request = http.MultipartRequest('PUT', Uri.parse('${ServerInfo.RESTURL_IMAGESINGLE_SET}?serviceGbn=${serviceGbn}&shopCd=${AuthService.SHOPCD}'));
      request.headers.addAll({
        'Content-Type' : 'multipart/form-data',
        'Authorization' : 'Bearer $accessToken'
      });
      request.files.add(http.MultipartFile.fromBytes('formFile', fileRes, filename: 'upload_temp.png'));

      retResult = await request.send();

      return retResult;
    }

    return null;
  }

  Future<dynamic> updateRequestMultiImage(String serviceGbn, String seq, List<PickedFile> fileResArr) async {
    final accessToken = await AuthService.to.userStorage.read(key: '@user_token');

    var retResult;

    if (fileResArr != null){
      var request = http.MultipartRequest('PUT', Uri.parse('${ServerInfo.RESTURL_IMAGESINGLE_SET}?serviceGbn=${serviceGbn}&shopCd=${AuthService.SHOPCD}&seq=${seq}'));
      request.headers.addAll({
        'Content-Type' : 'multipart/form-data',
        'Authorization' : 'Bearer $accessToken'
      });

      for (var imageFile in fileResArr) {
        Uint8List data = await imageFile.readAsBytes();
        List<int> filebytes = data.cast();

        request.files.add(http.MultipartFile.fromBytes('formFile', filebytes, filename: 'upload_temp.png'));
      }

      retResult = await request.send();

      return retResult;
    }

    return null;
  }
}