import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

Dio AuthDio() {
  var dio = Dio(
    BaseOptions(
        baseUrl: ServerInfo.jobMode == 'dev' ?  ServerInfo.REST_BASEURL_DEV : ServerInfo.REST_BASEURL_REAL,
        connectTimeout: const Duration(milliseconds: 5000),
        receiveTimeout: const Duration(milliseconds: 5000),
        sendTimeout: const Duration(milliseconds: 5000),
        contentType: 'application/json'
    ),
  );

  dio.interceptors.clear();

  dio.interceptors.add(
    InterceptorsWrapper(
      onRequest: (options, handler) async {
        // 기기에 저장된 AccessToken 로드
        final accessToken = await AuthService.to.userStorage.read(key: '@user_token');
        // debugPrint(accessToken);

        // 매 요청마다 헤더에 AccessToken을 포함
        options.headers['Authorization'] = 'Bearer $accessToken';

        return handler.next(options);
      },
      onError: (error, handler) async {
        // 인증 오류가 발생했을 경우: AccessToken의 만료
        if (error.response?.statusCode == 401) {
          AuthService.to.logout();
          debugPrint(error.toString());
        }
        return handler.next(error);
      },
    ),
  );
  return dio;
}