
class ISOptionModel {
  ISOptionModel({this.value, this.label, this.label2, this.id, this.pass});

  Object? value;
  String? label;
  String? label2;
  String? id;
  String? pass;
}