import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_datatable.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListModel.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListRequestModel.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeDetailInfo.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class NoticeManagerMain extends StatefulWidget {
  const NoticeManagerMain({Key? key}) : super(key: key);

  @override
  State<NoticeManagerMain> createState() => _NoticeManagerMainState();
}

class _NoticeManagerMainState extends State<NoticeManagerMain> with PageMixin {
  int selectedPageNumber = 1;
  int totalPage = 0;
  int totalCnt = 0;
  int itemsPerPage = 10;

  String? div = '%';
  String? keyword = '';

  List<NoticeListModel> dataList = <NoticeListModel>[];
  List<NoticeListModel> paginatedDataList = [];

  paginateDataList() {
    int startIndex = (selectedPageNumber - 1) * itemsPerPage;
    int endIndex = startIndex + itemsPerPage;

    if (startIndex < dataList.length) {
      if (endIndex > dataList.length) {
        endIndex = dataList.length;
      }
      paginatedDataList = dataList.sublist(startIndex, endIndex);
    } else {
      paginatedDataList = [];
    }
  }

  requestAPIData() async {
    NoticeListRequestModel requestData = NoticeListRequestModel();
    requestData.jobGbn = '11';
    requestData.osGbn = '11';
    requestData.noticeGbn = '2';
    requestData.dispGbn = 'Y';
    requestData.frDate = '';
    requestData.toDate = '';
    requestData.rows = '1000';
    requestData.page = '1';

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(NoticeController.to.getNoticeList(requestData.toJson()))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();
      int index = 0;
      selectedPageNumber = 1;

      value.forEach((element) {
        NoticeListModel temp = NoticeListModel();
        //temp.rnum = index.toString();
        temp.rnum = element['rnum'] as String;
        temp.noticeSeq = element['noticeSeq'] as String;
        temp.noticeTitle = element['noticeTitle'] as String;
        temp.dispFrDate = element['dispFrDate'] as String;
        temp.noticeContents = element['noticeContents'] as String;

        dataList.add(temp);

        //index++;

      });
      totalCnt = NoticeController.to.total_count;
      if (keyword != '' && div == '%') {
        dataList = dataList.where((item) => (item.noticeTitle.toString().contains(keyword!) ||
            item.noticeContents.toString().contains(keyword!)) && item.noticeTitle != item.noticeContents).toList();
        totalCnt = dataList.length;
        dataList.forEach((element) {
          dataList[index].rnum = (index+1).toString();
          index++;
        });
      } else if (keyword != '' && div == 'T') {
        dataList = dataList.where((item) => item.noticeTitle.toString().contains(keyword!) && item.noticeTitle != item.noticeContents).toList();
        totalCnt = dataList.length;
        dataList.forEach((element) {
          dataList[index].rnum = (index+1).toString();
        index++;
      });
      } else if (keyword != '' && div == 'C') {
        dataList = dataList.where((item) => item.noticeContents.toString().contains(keyword!) && item.noticeTitle != item.noticeContents).toList();
        totalCnt = dataList.length;
        dataList.forEach((element) {
          dataList[index].rnum = (index+1).toString();
          index++;
        });
      }
      totalPage = ((dataList.length / 10).ceil());
      paginateDataList();
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(NoticeController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    dataList.clear();
    paginatedDataList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    double contentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 398 : 370);

    return fluentUI.ScaffoldPage.withPadding(
      resizeToAvoidBottomInset: false,
      //scrollController: AppTheme.mainScrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: ScrollConfiguration(
        behavior: ScrollConfiguration.of(context).copyWith(scrollbars: Responsive.isMobile(context) ? false : true),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ISLabelBarMain(
                leading: const Text('공지사항', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
                trailing: Text.rich(
                    style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                    textAlign: TextAlign.end,
                    TextSpan(children: [const TextSpan(text: '전체 '), TextSpan(text: Utils.getCashComma(totalCnt.toString()), style: const TextStyle(color: Colors.lightBlue)), const TextSpan(text: ' 건')])),
              ),
              const SizedBox(height: 8),
              Responsive.isMobile(context) == true ? Column(children: searchBarView()) : Row(children: searchBarView()),
              const SizedBox(height: 8),
              Material(child: Responsive.isMobile(context) ? mobileNoticeListView(context, contentHeight) : noticeListTable(context, contentHeight)),
              Material(
                child: ISNumberPagination(
                    threshold: 5,
                    controlButton: const SizedBox(width: 10, height: 10),
                    onPageChanged: (int pageNumber) {
                      //do somthing for selected page
                      setState(() {
                        selectedPageNumber = pageNumber;
                      });
                      paginateDataList();
                    },
                    fontSize: 12,
                    pageTotal: totalPage,
                    pageInit: selectedPageNumber,
                    // picked number when init page
                    colorPrimary: Colors.black,
                    colorSub: Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget noticeListTable(fluentUI.BuildContext context, double contentHeight) {
    return ISDatatable(
      listWidth: Responsive.getResponsiveWidth(context),
      //MediaQuery.of(context).size.width,
      listHeight: contentHeight > 350 ? contentHeight : 350,
      headingRowHeight: 40,
      dataRowHeight: 40,
      minWidth: 400,
      rows: paginatedDataList.map((item) {
        return DataRow(
            selected: item.selected!,
            color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
              if (item.selected == true) {
                return Colors.grey.shade200;
                //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
              }

              return Theme.of(context).colorScheme.primary.withOpacity(0.00);
            }),
            onSelectChanged: (bool? value) {
              dataList.forEach((element) {
                element.selected = false;
              });

              item.selected = true;

              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => NoticeDetailInfo(noticeSeq: item.noticeSeq),
              );

              //setState(() {});
            },
            cells: [
              DataCell(SizedBox(width: 60, child: Align(alignment: Alignment.center, child: Text(item.rnum.toString() == null ? '--' : item.rnum.toString(), style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))))),
              DataCell(SizedBox(width: Responsive.getResponsiveWidth(context) - 200, child: Align(alignment: Alignment.centerLeft, child: Text(item.noticeTitle.toString() == null ? '--' : item.noticeTitle.toString(), style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))))),
              DataCell(SizedBox(width: 100, child: Align(alignment: Alignment.center, child: Text(item.dispFrDate.toString() == null ? '--' : item.dispFrDate.toString(), style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))))),
            ]);
      }).toList(),
      columns: <DataColumn>[
        const DataColumn(label: SizedBox(width: 60, child: Text('번호', textAlign: TextAlign.center)),),
        DataColumn(label: SizedBox(width: Responsive.getResponsiveWidth(context) - 200, child: const Text('제목', textAlign: TextAlign.left)),),
        const DataColumn(label: SizedBox(width: 100, child: Text('등록일', textAlign: TextAlign.center)), ),
      ],
    );
  }

  Widget mobileNoticeListView(fluentUI.BuildContext context, double contentHeight) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Divider(),
        ListView(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: List.generate(paginatedDataList.length, (index) {
              return GestureDetector(
                onTap: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => NoticeDetailInfo(noticeSeq: paginatedDataList[index].noticeSeq),
                  );
                },
                child: fluentUI.Container(
                  padding: const EdgeInsets.only(top: 10, bottom: 10),
                  decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.black.withOpacity(0.1)))),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            alignment: Alignment.center,
                            width: 30,
                            height: 24,
                            decoration: BoxDecoration(
                              color: Colors.lightBlueAccent,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.transparent),
                            ),
                            child: Text(
                              paginatedDataList[index].rnum!,
                              textAlign: TextAlign.center,
                              style: const TextStyle(color: Colors.white, fontWeight: FONT_BOLD, fontSize: 14, fontFamily: FONT_FAMILY),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Flexible(
                            child: Text(paginatedDataList[index].noticeTitle!, style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 15.0, fontFamily: FONT_FAMILY)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const SizedBox(width: 40),
                          Text(paginatedDataList[index].dispFrDate!, style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 15.0, fontFamily: FONT_FAMILY)),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            })),
      ],
    );
  }

  List<Widget> searchBarView() {
    return [
      Material(
        child: ISSearchDropdown(
          label: '업체타입',
          width: Responsive.isMobile(context) == true ? double.infinity : 100,
          value: div,
          onChange: (value) {
            setState(() {
              div = value;
              //_query();
            });
          },
          item: [
            ISOptionModel(value: '%', label: '전체'),
            ISOptionModel(value: 'T', label: '제목'),
            ISOptionModel(value: 'C', label: '내용'),
          ].cast<ISOptionModel>(),
        ),
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8) : const SizedBox(width: 8),
      Material(
        child: ISInput(
          value: keyword,
          label: '제목',
          width: Responsive.isMobile(context) == true ? double.infinity : 240,
          prefixIcon: const Icon(Icons.search, color: Colors.black54,),
          suffixIcon: MaterialButton(
            color: Colors.lightBlueAccent,
            minWidth: 60,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
            onPressed: () async {
              requestAPIData();
            },
            child: const Text('조회', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
          ),
          onChange: (v) {
            keyword = v;

          },
        ),
      ),
    ];
  }
}