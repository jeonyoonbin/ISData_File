
import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';

class FAQCEOInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const FAQCEOInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<FAQCEOInfoMain> createState() => _FAQCEOInfoMainState();
}

class _FAQCEOInfoMainState extends State<FAQCEOInfoMain> {

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    fluentUI.ButtonState<Color> headerColor = fluentUI.ButtonState.resolveWith((states) => Colors.grey.shade200);
    const headerTextStyle = TextStyle(fontSize: 16, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);
    const contentTextStyle = TextStyle(fontSize: 15, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);//letterSpacing: 0.6,
    const contentTitleTextStyle = TextStyle(fontSize: 15, color: Colors.black, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD);

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FAQform(headerColor, headerTextStyle, contentTextStyle,'[정보 관리] 저희 가게에 올라와 있는 (음식 이미지 or 음식 메뉴)를 바꾸고 싶은데요. 어떻게 해야 하나요?','[‘대구로’ 음식 이미지 or 메뉴 간편 변경 안내]\n* 카카오톡 실행\n* 카카오톡 첫 화면에 오른쪽 위에 있는 돋보기 내용 클릭\n* ‘검색’창에 ‘대구로 고객센터’ 채널 검색 → 채널 추가\n* ‘상담원 연결’ 클릭 → 고객 프로필 입력\n* 채팅창에 변경하고 싶은 음식 이미지 or 메뉴 전송',Responsive.isMobile(context) ? 100 : 56),
        ],
      ),
    );
  }
  fluentUI.Expander FAQform(fluentUI.ButtonState<fluentUI.Color> headerColor, fluentUI.TextStyle headerTextStyle, fluentUI.TextStyle contentTextStyle, headerText, contentText, headerHeight) {
    return fluentUI.Expander(
        headerHeight: headerHeight,
        contentPadding: EdgeInsets.symmetric(vertical: 10,horizontal: 10),
              headerBackgroundColor: headerColor,
              shapeRadius: 0.0,
              contentBackgroundColor: Colors.transparent,
        header: Text(headerText, style: headerTextStyle),
              content: SingleChildScrollView(
            child: Text(contentText,
                style: contentTextStyle)
              )
    );
  }

  requestAPIData() async {
  }
}