import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionLinkAddEditModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionLinkAddListModel.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class MenuOptionLinkAdd extends StatefulWidget {
  final String? menuCd;
  const MenuOptionLinkAdd({Key? key, this.menuCd})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return MenuOptionLinkAddState();
  }
}

class MenuOptionLinkAddState extends State<MenuOptionLinkAdd> {

  final List<OptionLinkAddListModel> dataList = <OptionLinkAddListModel>[];
  final List tempList = [];

  requestAPIData({bool? isShowAlertPopup = false}) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(MenuInfoController.to.getOptionLinkAddList(widget.menuCd!))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        OptionLinkAddListModel temp = OptionLinkAddListModel();
        temp.selectYn = element['selectYn'] as String;
        temp.optGrpCd = element['optGrpCd'] as String;
        temp.optGrpName = element['optGrpName'] as String;
        temp.minCount = element['minCount'] as String;
        temp.multiCount = element['multiCount'] as String;
        temp.multiYn = element['multiYn'] as String;
        temp.optNames = element['optNames'] as String;
        dataList.add(temp);
        tempList.add(temp.selectYn);
      });
    }

    setState(() {});

    // if (isShowAlertPopup == true)
    //   ISAlert(context, content: '저장되었습니다.', constraints: BoxConstraints(maxWidth: 240.0));
  }

  requestOptionLinkEditAdd(OptionLinkAddEditModel sendData) async {

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(MenuInfoController.to.addOptionLink(sendData.toJson()))
    );

    if (value != '00') {
      ISAlert(context, content: '정상 등록되지 않았습니다\n[다시 시도해 주세요]\n→ ${value}');
    }
    else {
    }
  }

  requestOptionLinkDelete(String menuCd, String menuOptGrpCd) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(MenuInfoController.to.deleteOptionLink(menuCd, menuOptGrpCd))
    );

    if (value != '00') {
      ISAlert(context, content: '정상 등록되지 않았습니다\n[다시 시도해 주세요]\n→ ${value}');
      //Navigator.of(context).pop;
    }
    else {
      //Navigator.of(context).pop(true);
      requestAPIData(isShowAlertPopup: true);
    }

    //setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    dataList.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(MenuInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData(isShowAlertPopup: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 320.0, maxHeight: 400),
      contentPadding: const EdgeInsets.symmetric(horizontal: 8),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('옵션 그룹 추가', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //const Divider(color: Colors.grey, height: 0.0,),
              const SizedBox(height: 12,),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.only(right: 16),
                  itemCount: dataList.length,
                  itemBuilder: (BuildContext context, int index) {
                    return dataList == null ?
                    const Text('Data is Empty')
                    :dataList[index].selectYn != 'Y'
                        ? Card(
                      color: Colors.white,
                      elevation: 1,
                      shape: appTheme.cardShapStyle,
                      margin: const EdgeInsets.all(4),
                      child: CheckboxListTile(
                        contentPadding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                        activeColor: Colors.blue,
                        controlAffinity: ListTileControlAffinity.leading,
                        value: tempList[index] == 'Y' ? true : false,
                        title: Text(dataList[index].optGrpName ?? '--', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(dataList[index].optNames ?? '--', style: const TextStyle(fontSize: 12, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                            const SizedBox(height: 8,),
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.only(left: 10, top: 10, bottom: 16),
                              decoration: BoxDecoration(
                                color: Colors.grey.shade200,
                                borderRadius: BorderRadius.circular(4.0),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                      width: 46,
                                      height: 20,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        border: Border.all(color: Colors.black, width: 0.1),
                                      ),
                                      child: const Text('연결 메뉴', style: TextStyle(fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54),)
                                  ),
                                  const SizedBox(height: 4,),
                                  const Text('짜장면, 짬뽕, 볶음밥', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54))
                                ],
                              ),
                            )
                          ],
                        ),
                        onChanged: (val){
                          setState(() {
                            tempList[index] = val == true ? 'Y' : 'N';
                          });
                        },
                      ),
                    ): Container();
                  },
                ),
              )
            ],
          ),
        ),
      ),
      // actions: null,
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.of(context).pop(true);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: (){
              BuildContext oldContext = context;

              ISConfirm(context, '옵션 그룹 추가', '선택한 옵션 그룹을 추가하시겠습니까?', constraints: const BoxConstraints(maxWidth: 420), (context, isOK) async {
                Navigator.pop(context);

                if (isOK){
                  OptionLinkAddEditModel sendData = OptionLinkAddEditModel();
                  for (int index = 0; index < dataList.length; index++) {
                    final element = dataList[index];
                    if (tempList[index] == 'Y' && element.selectYn == 'N' || element.selectYn == 'Y') {
                      sendData.menuCd = widget.menuCd;
                      sendData.optGrpCd!.add(element.optGrpCd!);
                    }
                  }

                      await requestOptionLinkEditAdd(sendData);

                  Navigator.pop(oldContext);
                }
              });

              

              // dataList.asMap().forEach((index, element) async {
              //   if(tempList[index] == 'Y' && element.selectYn == 'N'){
              //     OptionLinkAddEditModel sendData = OptionLinkAddEditModel();
              //     sendData.shopCd = AuthService.SHOPCD;
              //     sendData.menuCd = widget.menuCd;
              //     sendData.count = '1';
              //     sendData.optGrpCd!.add(element.optGrpCd!);
              //
              //     // Future.delayed(const Duration(milliseconds: 1000), () {
              //         print(index);
              //         await requestOptionLinkEditAdd(sendData);
              //
              //     // });
              //   }
              // });
            },
            child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


