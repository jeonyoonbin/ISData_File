import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/AccountManager/VATInfoModel.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/printing.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'dart:html';
import 'package:http/http.dart' as http;

class VATInfoMain extends StatefulWidget {
  const VATInfoMain({Key? key}) : super(key: key);

  @override
  State<VATInfoMain> createState() => _VATInfoMainState();
}

class _VATInfoMainState extends State<VATInfoMain> {
  List<VATInfoModel> outcomeDataList = <VATInfoModel>[];
  List<VATInfoModel> incomeDataList = <VATInfoModel>[];
  List<VATInfoModel> insungDataList = <VATInfoModel>[];

  String? startdate = '';
  String? enddate = '';
  String? tempStr;
  String? selectedType = '1000';
  String? selectedViewGbn = '%';
  bool pickDate = false;

  // 체크박스(만나서결제, 현금영수증처리중) 상태
  bool cbMeetPayment = false;
  bool cbReceiptProcessing = false;

  @override
  void initState() {
    super.initState();

    Get.put(AccountController());

    // 날짜필터
    startdate = formatDate(DateTime.now().subtract(const Duration(days: 7)), [yyyy, '-', mm, '-', dd]);
    enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    outcomeDataList.clear();
    incomeDataList.clear();
    insungDataList.clear();

    super.dispose();
  }

  requestAPIData() async {
    String viewGbn = (selectedViewGbn == '%') ? '' : selectedViewGbn!;

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(AccountController.to.getShopAccountVATReport('1', viewGbn, cbMeetPayment == true ? 'Y' : 'N', cbReceiptProcessing == true ? 'Y' : 'N', startdate!.replaceAll('-', ''), enddate!.replaceAll('-', '')))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      outcomeDataList.clear();
      incomeDataList.clear();
      insungDataList.clear();

      VATInfoModel tempCardData = VATInfoModel();
      tempCardData.outComeTitle = '앱 바로 결제 카드 매출';
      tempCardData.outComeAmt = value['cardAmt'] == '' ? '0' : value['cardAmt'] as String;          //카드 매출(매출)
      tempCardData.outComeVat = value['cardVatAmt'] == '' ? '0' : value['cardVatAmt'] as String;       //카드 매출(부가세)
      tempCardData.outComeTotal = value['totalCardAmt'] == '' ? '0' : value['totalCardAmt'] as String;   //카드 매출(합계)
      outcomeDataList.add(tempCardData);

      VATInfoModel tempCashData = VATInfoModel();
      tempCashData.outComeTitle = '현금영수증 매출';
      tempCashData.outComeAmt = value['cashAmt'] == '' ? '0' : value['cashAmt'].toString();//현금영수증 매출(매출)
      tempCashData.outComeVat = value['cashVatAmt'] == '' ? '0' : value['cashVatAmt'].toString();//현금영수증 매출(부가세)
      tempCashData.outComeTotal = value['totalCashAmt'] == '' ? '0' : value['totalCashAmt'].toString();//현금영수증 매출(합계)
      outcomeDataList.add(tempCashData);

      VATInfoModel tempEtcData = VATInfoModel();
      tempEtcData.outComeTitle = '기타 매출';
      tempEtcData.outComeAmt = value['etcAmt'] == '' ? '0' : value['etcAmt'].toString();//기타(매출)
      tempEtcData.outComeVat = value['etcVatAmt'] == '' ? '0' : value['etcVatAmt'].toString();//기타(부가세)
      tempEtcData.outComeTotal = value['totalEtcAmt'] == '' ? '0' : value['totalEtcAmt'].toString();//기타(합계)
      outcomeDataList.add(tempEtcData);

      if (cbMeetPayment){
        VATInfoModel tempMeetCardData = VATInfoModel();
        tempMeetCardData.outComeTitle = '만나서 카드 매출';
        tempMeetCardData.outComeAmt = value['meetCardAmt'] == '' ? '0' : value['meetCardAmt'].toString();//만나서 카드(합계)
        tempMeetCardData.outComeVat = value['meetCardVatAmt'] == '' ? '0' : value['meetCardVatAmt'].toString();//만나서 카드(합계)
        tempMeetCardData.outComeTotal = value['totalMeetCardAmt'] == '' ? '0' : value['totalMeetCardAmt'].toString();//만나서 카드(합계)
        outcomeDataList.add(tempMeetCardData);

        VATInfoModel tempMeetCashData = VATInfoModel();
        tempMeetCashData.outComeTitle = '만나서 현금 매출';
        tempMeetCashData.outComeAmt = value['meetCashAmt'] == '' ? '0' : value['meetCashAmt'].toString();//만나서 현금 (매출)
        tempMeetCashData.outComeVat = value['meetCashVatAmt'] == '' ? '0' : value['meetCashVatAmt'].toString();//만나서 현금(부가세)
        tempMeetCashData.outComeTotal = value['totalMeetCashAmt'] == '' ? '0' : value['totalMeetCashAmt'].toString();//만나서 현금(합계)
        outcomeDataList.add(tempMeetCashData);
      }

      if (cbReceiptProcessing){
        VATInfoModel tempCashingData = VATInfoModel();
        tempCashingData.outComeTitle = '처리 중인 건';
        tempCashingData.outComeAmt = value['cashIngAmt'] == '' ? '0' : value['cashIngAmt'].toString();//현금영수증 처리중인건(매출)
        tempCashingData.outComeVat = value['cashIngVatAmt'] == '' ? '0' : value['cashIngVatAmt'].toString();//현금영수증 처리중인건(부가세)
        tempCashingData.outComeTotal = value['totalCashIngAmt'] == '' ? '0' : value['totalCashIngAmt'].toString();//현금영수증 처리중인건(합계)
        outcomeDataList.add(tempCashingData);
      }

      int outAmtTotal = 0;
      int outVatTotal = 0;
      int outSumTotal = 0;

      outcomeDataList.forEach((element) {
        outAmtTotal += int.parse(element.outComeAmt!);
        outVatTotal += int.parse(element.outComeVat!);
        outSumTotal += int.parse(element.outComeTotal!);
      });

      VATInfoModel tempOutTotalData = VATInfoModel();
      tempOutTotalData.outComeTitle = '합계';
      tempOutTotalData.outComeAmt = outAmtTotal.toString();//기타(매출)
      tempOutTotalData.outComeVat = outVatTotal.toString();//기타(부가세)
      tempOutTotalData.outComeTotal = outSumTotal.toString();//기타(합계)
      outcomeDataList.add(tempOutTotalData);
      ///////////////////////////////////////////////////////////////////////////////////////////////////

      VATInfoModel tempIncomeData0 = VATInfoModel();
      tempIncomeData0.inComeTitle = '카드 결제 수수료';
      tempIncomeData0.inComeCnt = value['pgFeeCnt'] == '' ? '0' : value['pgFeeCnt'].toString();//카드 결제 수수료(건수)
      tempIncomeData0.inComeAmt = value['pgFeeAmt'] == '' ? '0' : value['pgFeeAmt'].toString();//카드 결제 수수료(수수료)
      tempIncomeData0.inComeVat = value['pgFeeVatAmt'] == '' ? '0' : value['pgFeeVatAmt'].toString();//카드 결제 수수료(부가세)
      tempIncomeData0.inComeTotal = value['totalPgFeeAmt'] == '' ? '0' : value['totalPgFeeAmt'].toString();//카드 결제 수수료(합계)
      incomeDataList.add(tempIncomeData0);

      VATInfoModel tempIncomeData1 = VATInfoModel();
      tempIncomeData1.inComeTitle = '중개 수수료 매출';
      tempIncomeData1.inComeCnt = value['appFeeCnt'] == '' ? '0' : value['appFeeCnt'].toString();//중개 수수료(건수)
      tempIncomeData1.inComeAmt = value['appFeeAmt'] == '' ? '0' : value['appFeeAmt'].toString();//중개 수수료(수수료)
      tempIncomeData1.inComeVat = value['appFeeVatAmt'] == '' ? '0' : value['appFeeVatAmt'].toString();//중개 수수료(부가세)
      tempIncomeData1.inComeTotal = value['totalAppFeeAmt'] == '' ? '0' : value['totalAppFeeAmt'].toString();//중개 수수료(합계)
      incomeDataList.add(tempIncomeData1);

      int inCntTotal = 0;
      int inAmtTotal = 0;
      int inVatTotal = 0;
      int inSumTotal = 0;

      incomeDataList.forEach((element) {
        inCntTotal += int.parse(element.inComeCnt!);
        inAmtTotal += int.parse(element.inComeAmt!);
        inVatTotal += int.parse(element.inComeVat!);
        inSumTotal += int.parse(element.inComeTotal!);
      });

      VATInfoModel tempInTotalData = VATInfoModel();
      tempInTotalData.inComeTitle = '합계';
      tempInTotalData.inComeCnt = inCntTotal.toString();
      tempInTotalData.inComeAmt = inAmtTotal.toString();
      tempInTotalData.inComeVat = inVatTotal.toString();
      tempInTotalData.inComeTotal = inSumTotal.toString();
      incomeDataList.add(tempInTotalData);

      VATInfoModel tempInsungData = VATInfoModel();
      tempInsungData.fromDate = value['fromDate'] == '' ? '0' : value['fromDate'].toString();//검색시작날짜
      tempInsungData.toDate = value['toDate'] == '' ? '0' : value['toDate'].toString();//검색종료날짜
      tempInsungData.bussName = value['bussName'] == '' ? '0' : value['bussName'].toString();//상호명
      tempInsungData.bussOwner = value['bussOwner'] == '' ? '0' : value['bussOwner'].toString();//사업자명
      tempInsungData.regNo = value['regNo'] == '' ? '0' : Utils.getStoreRegNumberFormat(value['regNo'].toString(), false);//사업자등록번호
      tempInsungData.insungName = value['insungName'] == '' ? '0' : value['insungName'].toString();//가맹점명
      tempInsungData.insungOwner = value['insungOwner'] == '' ? '0' : value['insungOwner'].toString();//대표자명
      tempInsungData.insungRegNo = value['insungRegNo'] == '' ? '0' : Utils.getStoreRegNumberFormat(value['insungRegNo'].toString(), false);//사업자등록번호
      tempInsungData.insungTelno = value['insungTelno'] == '' ? '0' : value['insungTelno'].toString();//전화번호
      insungDataList.add(tempInsungData);
    }

    setState(() {});
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefreshChild == true ) {
        _appTheme.ShopRefreshChild = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    const headerTextStyle = TextStyle(fontSize: 14, color: Colors.black54, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY);
    const contentTextStyle = TextStyle(fontSize: 14, color: Colors.black, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY);

    return Responsive.isMobile(context) ? mobileVATInfoMainWidget(headerTextStyle, contentTextStyle) : VATInfoMainWidget(headerTextStyle, contentTextStyle);
  }

  Widget VATInfoMainWidget(TextStyle headerTextStyle, TextStyle contentTextStyle) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            //const Divider(color: Colors.black,),//fluentUI.Divider(style: fluentUI.DividerThemeData(horizontalMargin: EdgeInsets.zero)),
            ISLabelBarMain(
                leading: Text('※ 현금영수증 처리 중인 건이 있을 경우, 최소 3일 전 내역으로 신고해 주세요.', style: TextStyle(color: Colors.red, fontSize: Responsive.isMobile(context) == true ? 12 : 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),)
            ),
            const SizedBox(height: 8),
            Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
            const SizedBox(height: 8),
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text('매출', style: TextStyle(fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                        SizedBox(width: 4,),
                        Tooltip(
                          message: '카드 매출: 앱 바로 결제 시 카드 결제된 매출\n현금영수증 매출: 사장님 명의로 발행된 현금영수증 매출\n기타 매출: 카드 매출, 현금 매출에 해당하지 않는 매출\nex) 마일리지, 쿠폰, 현금영수증, 발행되지 않은 상품권 등\n만나서 카드 결제: 만나서 카드 결제로 결제된 매출\n만나서 현금 결제: 만나서 현금 결제로 결제된 매출',
                            child: Icon(Icons.help_outline, color: Colors.blue,),
                        )
                      ],
                    ),
                    Row(
                      children: [
                        Checkbox(
                          value: cbReceiptProcessing,
                          onChanged: (onChanged) {
                            cbReceiptProcessing = onChanged!;
                            requestAPIData();
                          },
                        ),
                        const Text('현금영수증 처리 중인 건 포함'),
                        const SizedBox(width: 10,),
                        Checkbox(
                          value: cbMeetPayment,
                          onChanged: (onChanged) {
                            cbMeetPayment = onChanged!;
                            requestAPIData();
                          },
                        ),
                        const Text('만나서 결제 포함'),
                        const SizedBox(width: 10,),
                        ISButton(
                          buttonColor: Colors.black54,
                          child: const Text('인쇄'),
                          onPressed: () {
                            showDialog(
                              context: context,
                              barrierDismissible: true,
                              builder: (context) => printing(incomeData: incomeDataList, outcomeData: outcomeDataList, insungData: insungDataList,),
                            );
                          },
                        ),
                        const SizedBox(width: 10,),
                        ISButton(
                          buttonColor: Colors.green.shade400,
                          child: const Text('엑셀 다운'),
                          onPressed: () async {
                            String baseURL = ServerInfo.jobMode == 'dev' ?  ServerInfo.REST_BASEURL_DEV : ServerInfo.REST_BASEURL_REAL;
                            String viewGbn = (selectedViewGbn == '%') ? '' : selectedViewGbn!;

                            final accessToken = await AuthService.to.userStorage.read(key: '@user_token');
                            var headerData = {
                              "Authorization": 'Bearer $accessToken',
                            };

                            await http.post(Uri.parse('${ ServerInfo.RESTURL_EXCEL_VATSALES}?shopCd=${AuthService.SHOPCD}&viewGbn=${viewGbn}&frDate=${startdate!.replaceAll('-', '')}&toDate=${enddate!.replaceAll('-', '')}'),headers: headerData,).then((http.Response response) {
                              var bytes = response.bodyBytes;

                              var dateName = DateFormat('yyyyMMddHHmmss').format(DateTime.now());

                              AnchorElement(href: 'data:application/octet-stream;charset=utf-16le;base64,${base64.encode(bytes)}')
                                ..setAttribute('download', '부가세신고자료(매출)_${dateName}.xlsx')
                                ..click();
                            });
                          },
                        ),
                      ],
                    )
                  ],
                ),
                const SizedBox(height: 10,),
                Table(
                  border: TableBorder.symmetric(
                    inside: BorderSide(color: Colors.grey[300]!, width: 1),
                    outside: BorderSide(color: Colors.grey[300]!, width: 1),
                  ),
                  children: [
                    TableRow(
                        decoration: BoxDecoration(color: Colors.grey[200]!),
                        children: [
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerLeft, height: 40, child: Text('매출 구분', style: headerTextStyle)),
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('매출', style: headerTextStyle)),
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('부가세', style: headerTextStyle)),
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('합계', style: headerTextStyle)),
                        ]
                    ),
                    ...outcomeDataList.map((e) => TableRow(
                        decoration: e.outComeTitle == '합계' ? BoxDecoration(color: Colors.grey[200]!) : null,
                        children: [
                          Container(
                              padding: const EdgeInsets.all(10),
                              alignment: Alignment.centerLeft,
                              height: 40,
                              child: e.outComeTitle == '처리 중인 건'
                                  ? Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(e.outComeTitle!, style: const TextStyle(fontSize: 14, color: Colors.red, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                                  SizedBox(width: 2,),
                                  const Tooltip(
                                    message: '현금영수증 신청된 상품권 매출 건으로 국세청 처리까지 약 3일이 소요될 수 있습니다.\n정확한 매출 정보는 3일 이내 \'부가세 신고 자료\'에서 확인하실 수 있습니다.',
                                    child: Icon(Icons.help_outline, color: Colors.blue,),
                                  )
                                ],
                              ) : Text(e.outComeTitle!, style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD))
                          ),
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('${Utils.getCashComma(e.outComeAmt!)} 원', style: contentTextStyle)),
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('${Utils.getCashComma(e.outComeVat!)} 원', style: contentTextStyle)),
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('${Utils.getCashComma(e.outComeTotal!)} 원', style: contentTextStyle)),
                        ]
                    ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 35,),
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text('매입', style: TextStyle(fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                        SizedBox(width: 4,),
                        Tooltip(
                            message: '· 카드 결제 수수료: 카드 결제 수수료 2.42% (2.2% + 0.22% vat)\n· 중개 수수료: 중개 수수료 2.2% (2.0% + 0.2% vat)',
                            child: Icon(Icons.help_outline, color: Colors.blue,),
                        )
                      ],
                    ),
                    Row(
                      children: [
                        ISButton(
                          buttonColor: Colors.black54,
                          child: const Text('인쇄'),
                          onPressed: () {
                            showDialog(
                              context: context,
                              barrierDismissible: true,
                              builder: (context) => printing(incomeData: incomeDataList, outcomeData: outcomeDataList, insungData: insungDataList,),
                            );
                          },
                        ),
                        const SizedBox(width: 10,),
                        ISButton(
                          buttonColor: Colors.green.shade400,
                          child: const Text('엑셀 다운'),
                          onPressed: () async {
                            // String baseURL = ServerInfo.jobMode == 'dev' ?  ServerInfo.REST_BASEURL_DEV : ServerInfo.REST_BASEURL_REAL;
                            String viewGbn = (selectedViewGbn == '%') ? '' : selectedViewGbn!;

                            final accessToken = await AuthService.to.userStorage.read(key: '@user_token');
                            var headerData = {
                              "Authorization": 'Bearer $accessToken',
                            };

                            await http.post(Uri.parse('${ ServerInfo.RESTURL_EXCEL_VATPURCHASE}?shopCd=${AuthService.SHOPCD}&viewGbn=${viewGbn}&frDate=${startdate!.replaceAll('-', '')}&toDate=${enddate!.replaceAll('-', '')}'), headers: headerData,).then((http.Response response) {
                              var bytes = response.bodyBytes;

                              var dateName = DateFormat('yyyyMMddHHmmss').format(DateTime.now());

                              AnchorElement(href: 'data:application/octet-stream;charset=utf-16le;base64,${base64.encode(bytes)}')
                                ..setAttribute('download', '부가세신고자료(매입)_${dateName}.xlsx')
                                ..click();
                            });
                          },
                        ),
                      ],
                    )
                  ],
                ),
                const SizedBox(height: 10,),
                Table(
                  border: TableBorder.symmetric(
                    inside: BorderSide(color: Colors.grey[300]!, width: 1),
                    outside: BorderSide(color: Colors.grey[300]!, width: 1),
                  ),
                  children: [
                    TableRow(
                        decoration: BoxDecoration(color: Colors.grey[200]!),
                        children: [
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerLeft, height: 40, child: Text('매입 구분', style: headerTextStyle)),
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('건수', style: headerTextStyle)),
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('수수료', style: headerTextStyle)),
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('부가세', style: headerTextStyle)),
                          Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('합계', style: headerTextStyle)),
                        ]),
                    ...incomeDataList.map(
                          (e) => TableRow(decoration: e.inComeTitle == '합계' ? BoxDecoration(color: Colors.grey[200]!) : null, children: [
                        Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerLeft, height: 40, child: Text(e.inComeTitle!, style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY))),
                        Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('${Utils.getCashComma(e.inComeCnt!)} 건', style: contentTextStyle)),
                        Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('${Utils.getCashComma(e.inComeAmt!)} 원', style: contentTextStyle)),
                        Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('${Utils.getCashComma(e.inComeVat!)} 원', style: contentTextStyle)),
                        Container(padding: const EdgeInsets.all(10), alignment: Alignment.centerRight, height: 40, child: Text('${Utils.getCashComma(e.inComeTotal!)} 원', style: contentTextStyle)),
                      ]),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 30,),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(30),
              decoration: const BoxDecoration(color: Color.fromARGB(255, 240, 240, 240), borderRadius: BorderRadius.all(Radius.circular(10))),
              // height: 35,
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.tips_and_updates, color: Colors.yellow, size: 22,),
                      Text('  꼭 확인해 주세요!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                    ],
                  ),
                  SizedBox(height: 15,),
                  Text('· 해당 자료는 부가세 신고를 위한 참고용 자료입니다. 각 매출 구분을 참고해 주세요.\n· 현금매출은 사장님 명의로 발행된 현금영수증을 국세청에서 수집하고 있습니다.\n· 현금매출은 현금영수증 발행이 완료된 건이라 부가세 신고 시 중복 신고되지 않도록 주의해 주세요.\n· 만나서 카드 결제 내역은 카드사가 국세청에 제공하고 있습니다.')
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget mobileVATInfoMainWidget(TextStyle headerTextStyle, TextStyle contentTextStyle) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ISLabelBarMain(
                leading: Flexible(
                  child: Text('※ 현금영수증 처리 중인 건이 있을 경우, 최소 3일 전 내역으로 신고해 주세요.', style: TextStyle(color: Colors.red, fontSize: 13, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                )),
            const SizedBox(height: 8),
            Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
            const SizedBox(height: 12),
            Column(
              children: [
                Container(
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  height: 40,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    border: Border(top: BorderSide(color: Colors.grey.shade200)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text('매출', style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                          Tooltip(
                            message: '카드 매출: 앱 바로 결제 시 카드 결제된 매출\n 현금 매출: 사장님 명의로 발행된 현금영수증 매출\n 기타 매출: 카드 매출, 현금 매출에 해당하지 않는 매출 ex) 마일리지, 쿠폰, 현금영수증 발행되지 않은 상품권 등\n 만나서 카드 결제: 만나서 카드 결제로 결제된 매출\n 만나서 현금 결제: 만나서 현금 결제로 결제된 매출',
                            child: Icon(Icons.help_outline, color: Colors.blue,),
                          )
                        ],
                      ),
                          ISButton(
                            buttonColor: Colors.green.shade400,
                            child: const Text('엑셀 다운'),
                            onPressed: () async {
                              // String baseURL = ServerInfo.jobMode == 'dev' ?  ServerInfo.REST_BASEURL_DEV : ServerInfo.REST_BASEURL_REAL;

                              final accessToken = await AuthService.to.userStorage.read(key: '@user_token');
                              var headerData = {
                                "Authorization": 'Bearer $accessToken',
                              };

                              await http.post(Uri.parse('${ ServerInfo.RESTURL_EXCEL_VATSALES}?shopCd=${AuthService.SHOPCD}&frDate=${startdate!.replaceAll('-', '')}&toDate=${enddate!.replaceAll('-', '')}'), headers: headerData,).then((http.Response response) {
                                var bytes = response.bodyBytes;

                                var dateName = DateFormat('yyyyMMddHHmmss').format(DateTime.now());

                                AnchorElement(href: 'data:application/octet-stream;charset=utf-16le;base64,${base64.encode(bytes)}')
                                  ..setAttribute('download', '부가세신고자료(매출)_${dateName}.xlsx')
                                  ..click();
                              });
                            },
                      )
                    ],
                  ),
                ),
                const SizedBox(height: 20,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Row(
                      children: [
                        SizedBox(
                          width: 15,
                          height: 15,
                          child: Checkbox(
                            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            value: cbReceiptProcessing,
                            onChanged: (onChanged) {
                              cbReceiptProcessing = onChanged!;
                              requestAPIData();
                            },
                          ),
                        ),
                        const SizedBox(width: 8,),
                        const Text('현금영수증 처리 중인 건 포함', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 12.0, fontFamily: FONT_FAMILY),),
                      ],
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: 15,
                          height: 15,
                          child: Checkbox(
                            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            value: cbMeetPayment,
                            onChanged: (onChanged) {
                              cbMeetPayment = onChanged!;
                              requestAPIData();
                            },
                          ),
                        ),
                        const SizedBox(width: 8,),
                        const Text('만나서 결제 포함', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 12.0, fontFamily: FONT_FAMILY),),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 12,),
                ListView(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  children: List.generate(outcomeDataList.length, (index) {
                    return Container(
                      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.black.withOpacity(0.1)))),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('매출 구분', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              outcomeDataList[index].outComeTitle! == '처리 중인 건' ?
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                              Text(
                                outcomeDataList[index].outComeTitle!,
                                style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                              ),
                                  SizedBox(width: 2,),
                                  const Tooltip(
                                    message: '현금영수증 신청된 상품권 매출 건으로 국세청 처리까지 약 3일이 소요될 수 있습니다.\n정확한 매출 정보는 3일 이내 \'부가세 신고 자료\'에서 확인하실 수 있습니다.',
                                    child: Icon(Icons.help_outline, color: Colors.blue,),
                                  ),
                                ],
                              ) : Text(
                                outcomeDataList[index].outComeTitle!,
                                style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('매출', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text(
                                '${Utils.getCashComma(outcomeDataList[index].outComeAmt!)} 원',
                                style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('부가세', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text(
                                '${Utils.getCashComma(outcomeDataList[index].outComeVat!)} 원',
                                style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('합계', style: TextStyle(color: Colors.black, fontWeight: FONT_BOLD, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text(
                                '${Utils.getCashComma(outcomeDataList[index].outComeTotal!)} 원',
                                style: const TextStyle(color: Colors.black, fontWeight: FONT_BOLD, fontSize: 14.0, fontFamily: FONT_FAMILY),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  }),
                ),
              ],
            ),
            const SizedBox(height: 15,),
            Column(
              children: [
                Container(
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  height: 40,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    border: Border(top: BorderSide(color: Colors.grey.shade200)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text('매입', style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                          Tooltip(
                            message: '· 카드 결제 수수료: 카드 결제 수수료 2.42% (2.2% + 0.22% vat)\n· 중개 수수료: 중개 수수료 2.2% (2.0% + 0.2% vat)',
                            child: Icon(Icons.help_outline, color: Colors.blue,),
                          )
                        ],
                      ),
                          ISButton(
                            buttonColor: Colors.green.shade400,
                            child: const Text('엑셀 다운'),
                            onPressed: () async {
                              // String baseURL = ServerInfo.jobMode == 'dev' ?  ServerInfo.REST_BASEURL_DEV : ServerInfo.REST_BASEURL_REAL;

                              final accessToken = await AuthService.to.userStorage.read(key: '@user_token');
                              var headerData = {
                                "Authorization": 'Bearer $accessToken',
                              };

                              await http.post(Uri.parse('${ ServerInfo.RESTURL_EXCEL_VATPURCHASE}?shopCd=${AuthService.SHOPCD}&frDate=${startdate!.replaceAll('-', '')}&toDate=${enddate!.replaceAll('-', '')}'), headers: headerData,).then((http.Response response) {
                                var bytes = response.bodyBytes;

                                var dateName = DateFormat('yyyyMMddHHmmss').format(DateTime.now());

                                AnchorElement(href: 'data:application/octet-stream;charset=utf-16le;base64,${base64.encode(bytes)}')
                                  ..setAttribute('download', '부가세신고자료(매입)_${dateName}.xlsx')
                                  ..click();
                              });
                            },
                      )
                    ],
                  ),
                ),
                ListView(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  children: List.generate(incomeDataList.length, (index) {
                    return Container(
                      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.black.withOpacity(0.1)))),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('매입', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text(incomeDataList[index].inComeTitle!, style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('건수', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text('${Utils.getCashComma(incomeDataList[index].inComeCnt!)} 건', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('수수료', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text('${Utils.getCashComma(incomeDataList[index].inComeAmt!)} 원', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('부가세', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text('${Utils.getCashComma(incomeDataList[index].inComeVat!)} 원', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('합계', style: TextStyle(color: Colors.black, fontWeight: FONT_BOLD, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text('${Utils.getCashComma(incomeDataList[index].inComeTotal!)} 원', style: const TextStyle(color: Colors.black, fontWeight: FONT_BOLD, fontSize: 14.0, fontFamily: FONT_FAMILY),),
                            ],
                          ),
                        ],
                      ),
                    );
                  }),
                ),
              ],
            ),
            const SizedBox(height: 30,),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(30),
              decoration: const BoxDecoration(color: Color.fromARGB(255, 240, 240, 240), borderRadius: BorderRadius.all(Radius.circular(10))),
              // height: 35,
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.tips_and_updates, color: Colors.yellow, size: 22,),
                      Text('  꼭 확인해 주세요!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                    ],
                  ),
                  SizedBox(height: 15,),
                  Text('· 해당 자료는 부가세 신고를 위한 참고용 자료입니다. 각 매출 구분을 참고해 주세요.\n· 현금매출은 사장님 명의로 발행된 현금영수증을 국세청에서 수집하고 있습니다.\n· 현금매출은 현금영수증 발행이 완료된 건이라 부가세 신고 시 중복 신고되지 않도록 주의해 주세요.\n· 만나서 카드 결제 내역은 카드사가 국세청에 제공하고 있습니다.')
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> searchBarView() {
    return [
      if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET)...[
        ISSearchDropdown(
          width: Responsive.isMobile(context) == true ? double.infinity : 120,
          label: '주문 정보 구분',
          value: selectedViewGbn,
          onChange: (value) {
            selectedViewGbn = value;

            requestAPIData();
          },
          item: [
            ISOptionModel(value: '%', label: '전체'),
            ISOptionModel(value: 'DELIVERY', label: '일반 메뉴'),
            ISOptionModel(value: 'BUNDLE', label: '장보기 상품'),
          ].cast<ISOptionModel>(),
        ),
        Responsive.isMobile(context) == true ? const SizedBox(height: 8,) : const SizedBox(width: 8,),
      ],
      ISSearchSelectDate(
        label: '기간 선택',
        width: Responsive.isMobile(context) == true ? double.infinity : 230,
        value: '${startdate.toString()} ~ ${enddate.toString()}',
        onTap: () async {
          showGeneralDialog(
              context: context,
              barrierDismissible: true,
              barrierLabel: '',
              barrierColor: Colors.black54,
              pageBuilder: (context, animation, secondaryAnimation) {
                return Dialog(
                    insetPadding: EdgeInsets.zero,
                    elevation: 0,
                    backgroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                    child: MultipleViewDateRangePicker(
                      startDate: DateTime.parse(startdate!),
                      endDate: DateTime.parse(enddate!),
                      setDateActionCallback: ({startDate, endDate}) {
                        Navigator.of(context).pop();

                        startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                        enddate = DateFormat('yyyy-MM-dd').format(endDate!);
                        pickDate = true;
                        //selectedPageNumber = 1;

                        requestAPIData();
                      },
                    ));
              });
        },
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8,) : const SizedBox(width: 8,),
      ISToggleButtons(
        [
          ISOptionModel(value: '1000', label: '7일'),
          ISOptionModel(value: '1001', label: '1분기'),
          ISOptionModel(value: '1002', label: '2분기'),
          ISOptionModel(value: '1003', label: '3분기'),
          ISOptionModel(value: '1004', label: '4분기'),
        ],
        buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 5) - 13) : 60,
        defaultValue: selectedType,
        pickDate: pickDate,
        afterOnPress: (v) {
          if (v == '1000') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 7)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          } else if (v == '1001') {
            startdate = formatDate(DateTime.now(), [yyyy, '-', '01', '-', '01']);
            enddate = formatDate(DateTime.now(), [yyyy, '-', '03', '-', '31']);
          } else if (v == '1002') {
            startdate = formatDate(DateTime.now(), [yyyy, '-', '04', '-', '01']);
            enddate = formatDate(DateTime.now(), [yyyy, '-', '06', '-', '30']);
          } else if (v == '1003') {
            startdate = formatDate(DateTime.now(), [yyyy, '-', '07', '-', '01']);
            enddate = formatDate(DateTime.now(), [yyyy, '-', '09', '-', '30']);
          } else if (v == '1004') {
            startdate = formatDate(DateTime.now(), [yyyy, '-', '10', '-', '01']);
            enddate = formatDate(DateTime.now(), [yyyy, '-', '12', '-', '31']);
          }

          setState(() {
            pickDate = false;
          });

          requestAPIData();
        },
      ),
    ];
  }
}