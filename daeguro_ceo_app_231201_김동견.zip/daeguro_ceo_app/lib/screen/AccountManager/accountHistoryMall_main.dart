import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/AccountManager/accountHistoryModel.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:data_table_2/data_table_2.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';


class AccountHistoryMallMain extends StatefulWidget {
  final double? tabviewHeight;

  const AccountHistoryMallMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<AccountHistoryMallMain> createState() => _AccountHistoryMallMainState();
}

class _AccountHistoryMallMainState extends State<AccountHistoryMallMain> {
  final ScrollController _scrollController = ScrollController();

  String? startdate = '';
  String? enddate = '';
  String? tempStr;
  String? selectedType = '1000';

  int totaldeposit = 0;
  int totalwithdraw = 0;
  int moneySum = 0;

  String? selectedPayType = ' ';
  String? selectedOrderType = ' ';
  String? selectedStatus = ' ';

  int selectedPageNumber = 1;
  int totalPage = 0;
  bool pickDate = false;

  int remainAmt = 0;

  late AccountHistoryMallSource accountHistoryMallDataSource;
  bool _initialized = false;

  List<AccountHistoryModel> dataList = <AccountHistoryModel>[];

  Map<int, List<AccountHistoryModel>> mobileDataDetailSourceMap = {};

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      accountHistoryMallDataSource = AccountHistoryMallSource(context, dataList, false, true, true, false);
      // Default sorting sample. Set __sortColumnIndex to 0 and uncoment the lines below
      // if (_sortColumnIndex == 0) {
      //   _sort<String>((d) => d.name, _sortColumnIndex!, _sortAscending);
      // }
      _initialized = true;
      accountHistoryMallDataSource.addListener(() {
        setState(() {});
      });
    }
  }

  @override
  void dispose() {
    dataList.clear();
    accountHistoryMallDataSource.dispose();
    _scrollController.dispose();
    mobileDataDetailSourceMap.clear();
    super.dispose();
  }

  requestAPIData() async {

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(AccountController.to.getShopAccountHistoryMallList(startdate!.replaceAll('-', ''), enddate!.replaceAll('-', ''), selectedPageNumber.toString()))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        AccountHistoryModel temp = AccountHistoryModel();

        temp.orderNo = element['orderNo'] as String;
        temp.orderDate = element['orderDate'] as String;
        temp.status = element['status'] as String;
        temp.packOrderYn = element['packOrderYn'] as String;
        temp.packOrderYnName = element['packOrderYnName'] as String;
        temp.totAmt = element['totAmt'] as String;
        temp.menuAmt = element['menuAmt'] as String;
        temp.deliTipAmt = element['deliTipAmt'] as String;
        temp.totalDiscAmt = element['totalDiscAmt'] as String;
        temp.shopDiscAmt = element['shopDiscAmt'] as String;
        temp.totalFeeAmt = element['totalFeeAmt'] as String;
        temp.appFeeAmt = element['appFeeAmt'] as String;
        temp.pgFeeAmt = element['pgFeeAmt'] as String;
        temp.deliTotAmt = element['deliTotAmt'] as String;
        temp.totalAmt = element['totalAmt'] as String;
        temp.deliCashAmt = element['deliCashAmt'] as String;
        temp.deliCardAmt = element['deliCardAmt'] as String;
        temp.memo = element['memo'] as String;
        temp.appPayGbnName = element['appPayGbnName'] as String;
        temp.transferAmt = element['transferAmt'] as String;
        temp.liveDiscAmt = element['liveDiscAmt'] as String;
        temp.adminAmt = element['adminAmt'] as String;
        temp.packDiscAmt = element['packDiscAmt'] as String;
        temp.shopCouponAmt = element['shopCouponAmt'] as String;
        temp.rNum = element['rNum'] as String;
        temp.chargeDate = element['chargeDate'] as String;
        temp.inAmt = element['inAmt'] as String;
        temp.outAmt = element['outAmt'] as String;
        temp.chargeAmt = element['chargeAmt'] as String;
        temp.shopCd = element['shopCd'] as String;
        temp.appMenuAmt = element['appMenuAmt'] as String;
        temp.appTipAmt = element['appTipAmt'] as String;
        temp.meetMenuAmt = element['meetMenuAmt'] as String;
        temp.meetTipAmt = element['meetTipAmt'] as String;

        temp.accumulationClassification = '쇼핑몰';
        temp.orderProductInformation = '대구로몰';

        dataList.add(temp);
      });

      totalPage = AccountController.to.total_page;
      remainAmt = AccountController.to.remainAmt;

      totaldeposit = AccountController.to.totaldeposit;
      totalwithdraw = AccountController.to.totalwithdraw;
      moneySum = AccountController.to.moneySum;

    }

    setState(() {});
  }

  // loadData() async {
  //   // 날짜필터
  //   startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
  //   enddate = formatDate(DateTime(int.parse(DateTime.now().year.toString()), int.parse(DateTime.now().month.toString()) + 1, 0), [yyyy, '-', mm, '-', dd]);
  //
  //   // 테이블 데이터
  //   for (int i = 10; i < 20; i++) {
  //     AccountHistoryMallModel temp = AccountHistoryMallModel();
  //     temp.selected = false;
  //
  //     temp.orderDate = '2023-04-$i';
  //     temp.accumulationClassification = '쇼핑몰';
  //     temp.orderProductInformation = '대구로몰';
  //     temp.deposit = (i * 7510).toString();
  //     temp.withdraw = (-i * 15570).toString();
  //     temp.finalAmount = (i * 7510 + -i * 1570).toString();
  //     temp.depositDetail = (i * 7510).toString();
  //     temp.withdrawDetail = (-i * 15700).toString();
  //
  //     // totalDeposit += int.parse(temp.deposit!);
  //     // totalWithdraw += int.parse(temp.withdraw!);
  //     dataList.add(temp);
  //   }
  //
  //   totalDeposit = 248000;
  //   totalWithdraw = -756;
  //   totalReward = 24044;
  //
  //   totalPage = 100;
  //
  //   setState(() {});
  // }

  @override
  void initState() {
    super.initState();

    Get.put(AccountController());

    // 날짜필터
    startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefreshChild == true ) {
        _appTheme.ShopRefreshChild = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Responsive.isMobile(context) == true
                  ? Column(mainAxisAlignment: MainAxisAlignment.end, crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text.rich(
                    style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, fontSize: 24),
                    textAlign: Responsive.isMobile(context) == true ? TextAlign.end : TextAlign.start,
                    TextSpan(children: [
                      const TextSpan(text: '현재 적립금 '),
                      TextSpan(
                          text: Utils.getCashComma(remainAmt.toString()),
                          style: const TextStyle(
                            color: Colors.lightBlue,
                          )),
                      const TextSpan(text: '원'),
                    ])),
                const SizedBox(
                  width: 6,
                ),
                const Text(
                  '(입점 지원금 10,000원 포함)',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                ),
              ])
                  : Row(
                children: [
                  const Text(
                    '(입점 지원금 10,000원 포함)',
                    style: TextStyle(color: Colors.grey, fontSize: 14),
                  ),
                  const SizedBox(
                    width: 6,
                  ),
                  Text.rich(
                      style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, fontSize: 24),
                      textAlign: Responsive.isMobile(context) == true ? TextAlign.end : TextAlign.start,
                      TextSpan(children: [
                        const TextSpan(text: '현재 적립금 '),
                        TextSpan(
                            text: Utils.getCashComma(remainAmt.toString()),
                            style: const TextStyle(
                              color: Colors.lightBlue,
                            )),
                        const TextSpan(text: '원'),
                      ]))
                ],
              ),
            ],
          ),
          const Divider(thickness: 1, color: Colors.black),
          Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
          const SizedBox(height: 8),
          Container(
              alignment: Responsive.isMobile(context) == true ? Alignment.centerRight : Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              //height: 40,
              width: double.infinity,
              decoration: BoxDecoration(color: Colors.grey[200],),
              child: Text.rich(
                  style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                  textAlign: Responsive.isMobile(context) == true ? TextAlign.end : TextAlign.start,
                  TextSpan(children: [
                    const TextSpan(text: '조회된 기간의 총 입금액은 '),
                    TextSpan(text: Utils.getCashComma(totaldeposit.toString()), style: const TextStyle(color: Colors.lightBlue,)),
                    const TextSpan(text: '원, '),
                    const TextSpan(text: '총 출금액은 '),
                    TextSpan(text: Utils.getCashComma(totalwithdraw.toString()), style: const TextStyle(color: Colors.lightBlue)),
                    const TextSpan(text: '원, '),
                    TextSpan(text: Responsive.isMobile(context) == true ? '\n' : ''),
                    const TextSpan(text: '총 적립 금액은 '),
                    TextSpan(text: Utils.getCashComma(moneySum.toString()), style: const TextStyle(color: Colors.lightBlue)),
                    const TextSpan(text: '원입니다.'),
                  ]))),
          const SizedBox(
            height: 10,
          ),
          Responsive.isMobile(context) == true ? MobileAccountHistoryMallData() : AccountHistoryMallData(),
          if (dataList != null && dataList.isNotEmpty)...[
            ISNumberPagination(
              threshold: 5,
              controlButton: const SizedBox(
                width: 10,
                height: 10,
              ),
              onPageChanged: (int pageNumber) {
                //do somthing for selected page
                setState(() {
                  selectedPageNumber = pageNumber;
                });
              },
              fontSize: 12,
              pageTotal: totalPage,
              pageInit: selectedPageNumber,
              // picked number when init page
              colorPrimary: Colors.black,
              colorSub: Colors.white,
            ),
          ]
        ],
      ),
    );
  }

  Widget AccountHistoryMallData() {
    return SizedBox(
      height: widget.tabviewHeight! - 138.0 > 350 ? widget.tabviewHeight! - 138.0 : 350,
      child: DataTable2(
        // dataRowHeight: 30,
        headingRowHeight: 40,
        columnSpacing: 0,
        horizontalMargin: 0,
        headingRowColor: MaterialStateProperty.all(Colors.grey[100],),
        headingTextStyle: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54),
        // MaterialStateProperty.resolveWith((states) =>
        //     _fixedRows > 0 ? Colors.grey[200] : Colors.transparent),
        border: TableBorder(
          borderRadius: BorderRadius.circular(10),
          top: BorderSide(color: Colors.grey[300]!),
          right: BorderSide(color: Colors.grey[300]!),
          bottom: BorderSide(color: Colors.grey[300]!),
          left: BorderSide(color: Colors.grey[300]!),
          horizontalInside: BorderSide.none,
        ),

        dividerThickness: 0, // this one will be ignored if [border] is set above
        bottomMargin: 10,
        minWidth: 900,
        // sortColumnIndex: _sortColus
        // sortArrowIcon: Icons.keyboard_arrow_up, // custom arrow
        // sortArrowAnimationDuration:
        //     const Duration(milliseconds: 500), // custom animation duration
        // onSelectAll: (val) =>
        //     setState(() => _dessertsDataSource.selectAll(val)),
        columns: const [
          DataColumn2(label: Center(child: Text('주문일자')), size: ColumnSize.S,),
          DataColumn2(label: Center(child: Text('적립구분')), size: ColumnSize.S, numeric: true,),
          DataColumn2(label: Center(child: Text('주문상품 정보')), size: ColumnSize.S, numeric: true,),
          DataColumn2(label: Align(alignment: Alignment.centerRight, child: Text('입금')), size: ColumnSize.S,numeric: true,),
          DataColumn2(label: Align(alignment: Alignment.centerRight, child: Text('출금')), size: ColumnSize.S, numeric: true,),
          DataColumn2(label: Align(alignment: Alignment.centerRight, child: Text('총 금액')), size: ColumnSize.S, numeric: true,),
          DataColumn2(label: Center(child: Text('상세 보기')), size: ColumnSize.S, numeric: true,),
        ],
        empty: Center(
            child: Container(
                padding: const EdgeInsets.all(20),
                child: const Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)))),
        rows: List<DataRow>.generate(accountHistoryMallDataSource.rowCount, (index) => accountHistoryMallDataSource.getRow(index)),
      ),
    );
  }

  Widget MobileAccountHistoryMallData() {
    return (dataList.length! == 0)
        ? SizedBox(
      height: (widget.tabviewHeight! - 220),
      child: const Align(
          alignment: Alignment.center,
          child: Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
    ) : ListView(
        controller: _scrollController,
        shrinkWrap: true,
        children: List.generate(
          dataList.length, (index) {
            return fluentUI.Expander(
                headerHeight: 130,
                shapeRadius: 0.0,
                onStateChanged: (val) async {
                  if (val == true) {
                    var value = await showDialog(context: context, builder: (context) => FutureProgressDialog((AccountController.to.getShopAccountHistoryMallDetail((dataList[index].chargeDate!.replaceAll('-', ''))))));

                    if (value == null) {
                      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
                    } else {
                      List<AccountHistoryModel> tempList = value.map<AccountHistoryModel>((element) {
                        AccountHistoryModel temp = AccountHistoryModel();

                        temp.chargeDate = element['chargeDate'] as String;
                        temp.chargeAmt = element['chargeAmt'] as String;
                        temp.inAmt = element['inAmt'] as String;
                        temp.outAmt = element['outAmt'] as String;
                        temp.ioGbn = element['ioGbn'] as String;
                        temp.memo = element['memo'] as String;

                        return temp;
                      }).toList();

                      setState(() {
                        mobileDataDetailSourceMap[index] = tempList;
                      });
                    }
                  } else {
                    setState(() {
                      mobileDataDetailSourceMap.remove(index);
                    });
                  }
                },
                header: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 5),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('주문일자', style: TextStyle(color: Colors.black, fontSize: 14)),
                        Text(dataList[index].chargeDate! , style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('적립구분', style: TextStyle(color: Colors.black, fontSize: 14)),
                        Text(dataList[index].accumulationClassification!, style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('주문상품 정보', style: TextStyle(color: Colors.black, fontSize: 14)),
                        Text(dataList[index].orderProductInformation!, style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('입금', style: TextStyle(color: Colors.black, fontSize: 14)),
                        Text('${Utils.getCashComma(dataList[index].inAmt ?? '')} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('출금', style: TextStyle(color: Colors.black, fontSize: 14)),
                        Text('${Utils.getCashComma(dataList[index].outAmt ?? '')} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('총 출금', style: TextStyle(color: Colors.black, fontSize: 14)),
                        Text('${Utils.getCashComma(dataList[index].chargeAmt ?? '')} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                  ],
                ),
              content: mobileDataDetailSourceMap.containsKey(index)
                  ? ListView.separated(
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (ctx, idx) {
                    AccountHistoryModel detail = mobileDataDetailSourceMap[index]![idx];
                    return Padding(
                      padding: const EdgeInsets.only(top: 8.0, bottom: 8.0, left: 8.0, right: 40),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('적립사유', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              const SizedBox(height: 8),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                                child: Text('- ${detail.memo!}', style: TextStyle(color: Colors.black54, fontWeight: FONT_NORMAL, fontSize: 13.0, fontFamily: FONT_FAMILY),),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('입금', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text('${Utils.getCashComma(detail.inAmt ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),)
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('출금', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text('${Utils.getCashComma(detail.outAmt ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),)
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('총 출금', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text('${Utils.getCashComma(detail.chargeAmt ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY),)
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                  separatorBuilder: (BuildContext context, int index) { return const Divider(thickness: 1, height: 0.0,); },
                  itemCount: mobileDataDetailSourceMap[index]!.length
              ) : const SizedBox.shrink(),
            );
          },
        ));
  }

  List<Widget> searchBarView() {
    return [
      ISSearchSelectDate(
        label: '기간 선택',
        width: Responsive.isMobile(context) == true ? double.infinity : 230,
        value: '${startdate.toString()} ~ ${enddate.toString()}',
        onTap: () async {
          showGeneralDialog(
              context: context,
              barrierDismissible: true,
              barrierLabel: '',
              barrierColor: Colors.black54,
              pageBuilder: (context, animation, secondaryAnimation) {
                return Dialog(
                    insetPadding: EdgeInsets.zero,
                    elevation: 0,
                    backgroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                    child: MultipleViewDateRangePicker(
                      startDate: DateTime.parse(startdate!),
                      endDate: DateTime.parse(enddate!),
                      setDateActionCallback: ({startDate, endDate}) {
                        Navigator.of(context).pop();

                          startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                          enddate = DateFormat('yyyy-MM-dd').format(endDate!);
                          selectedPageNumber = 1;
                          pickDate = true;
                          requestAPIData();
                      },
                    ));
              });
        },
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8,) : const SizedBox(width: 8,),
      ISToggleButtons(
        [
          ISOptionModel(value: '1000', label: '오늘'),
          ISOptionModel(value: '1001', label: '5일'),
          ISOptionModel(value: '1002', label: '7일'),
          ISOptionModel(value: '1003', label: '1개월'),
          ISOptionModel(value: '1004', label: '3개월'),
        ],
        buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 5) - 6) : 60,
        defaultValue: selectedType,
        pickDate: pickDate,
        afterOnPress: (v) {
          if (v == '1000'){
            startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1001'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 5)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1002'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 7)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1003'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 30)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1004'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 90)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }

          setState(() {
            selectedType = v.toString();
            pickDate = false;
          });

          selectedPageNumber = 1;

          requestAPIData();
        },
      ),
    ];
  }
}

class AccountHistoryMallSource extends DataTableSource {
  final BuildContext context;
  late List<AccountHistoryModel> dataSource = [];
  // Add row tap handlers and show snackbar
  bool hasRowTaps = false;
  // Override height values for certain rows
  bool hasRowHeightOverrides = false;
  // Color each Row by index's parity
  bool hasZebraStripes = false;

  int _selectedCount = 0;

  List<AccountHistoryModel> dataDetailSource = [];

  AccountHistoryMallSource.empty(this.context, this.dataSource) {
    dataSource = [];
  }

  AccountHistoryMallSource(this.context, this.dataSource, [sortedByValue = false, this.hasRowTaps = false, this.hasRowHeightOverrides = false, this.hasZebraStripes = false]) {
    //dataSource = dataList;
    // if (sortedByValue) {
    //   sort((d) => d., true);
    // }
  }

  @override
  DataRow getRow(int index, [Color? color, double fontSize = 14.0, FontWeight? fontWeight = FONT_NORMAL]) {

    assert(index >= 0);
    if (index >= dataSource.length) throw 'index > dataList.length';
    final data = dataSource[index];

    final cellDecoration = BoxDecoration(border: Border(bottom: BorderSide(color: !data.isChild ? Colors.grey[200]! : Colors.transparent, width: 1)));

    return DataRow2.byIndex(
        index: index,
        // selected: data.selected,
        color: color != null
            ? MaterialStateProperty.all(color)
            : data.isChild
            ? MaterialStateProperty.all(Colors.grey.shade200)
            : MaterialStateProperty.all(Colors.transparent),
        onTap: hasRowTaps ? () async {
          if (data.isChild){
            null;

            return;
          }
          else{
            if (data.isOpened){
              dataSource.removeRange(index + 1, index + (dataDetailSource.length+1));
              dataSource[index].isOpened = false;
            }
            else{
              var value = await showDialog(
                  context: context,
                  builder: (context) => FutureProgressDialog(AccountController.to.getShopAccountHistoryMallDetail(dataSource[index].chargeDate!.replaceAll('-', '')))
              );

              if (value == null) {
                ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
                //Navigator.of(context).pop;
              }
              else {
                dataDetailSource.clear();
                int subIndex = 1;
                value.forEach((element) {
                  AccountHistoryModel temp = AccountHistoryModel();

                  temp.chargeDate = element['chargeDate'] as String;
                  temp.chargeAmt = element['chargeAmt'] as String;
                  temp.inAmt = element['inAmt'] as String;
                  temp.outAmt = element['outAmt'] as String;

                  temp.ioGbn = element['ioGbn'] as String;
                  temp.memo = element['memo'] as String;

                  dataSource.insert(index + subIndex, AccountHistoryModel(chargeDate: '', orderProductInformation: temp.memo, inAmt: temp.inAmt, outAmt: temp.outAmt, chargeAmt: temp.chargeAmt, isChild: true,));

                  dataSource[index].isOpened = true;

                  dataDetailSource.add(temp);

                  subIndex++;
                });
              }
            }
            notifyListeners();
          }
        } : null,
      // onTap: hasRowTaps ? () => {
      //   // _showSnackbar(context, 'Tapped on row ${data.orderNumber}'),
      //   data.isChild || data.isChild2
      //       ? null
      //       : data.isOpened
      //       ? {
      //     dataSource.removeRange(index + 1, index + 3),
      //     dataSource[index].isOpened = false
      //   } : {
      //     dataSource.insert(index + 1,
      //       AccountHistoryModel(
      //         orderDate: '사유',
      //         orderProductInformation: '구매상품([무료배송] 삼겹살 수입산 3kg (구이용/수육용)[삼겹살 수입산 3kg 수육용]) 주문취소로 인한 상품대금 입금',
      //         inAmt: data.inAmt,
      //         outAmt: data.outAmt,
      //         isChild: true,
      //       ),
      //     ),
      //     dataSource.insert(index + 2,
      //       AccountHistoryModel(
      //         orderDate: '사유',
      //         orderProductInformation: '[무료배송] 삼겹살 수입산 3kg (구이용/수육용) 상품대금 출금',
      //         inAmt: data.inAmt,
      //         outAmt: '-${data.outAmt}',
      //         isChild: true,
      //       ),
      //     ),
      //     dataSource[index].isOpened = true
      //   },
      //   notifyListeners()
      // } : null,
      specificRowHeight: hasRowHeightOverrides && (data.isChild) ? 70 : null,
      cells: [
        DataCell(Container(
            padding: EdgeInsets.zero,
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text(data.chargeDate ?? '', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),))
        ),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text(data.accumulationClassification ?? '', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),))
        ),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text(data.orderProductInformation ?? '', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),))
        ),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.centerRight,
            child: Text('${Utils.getCashComma(data.inAmt ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),))
        ),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.centerRight,
            child: Text('${Utils.getCashComma(data.outAmt ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),))
        ),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.centerRight,
            child: Text('${Utils.getCashComma(data.chargeAmt ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),))
        ),
        DataCell(
          Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: (data.isChild == true)
                ? const SizedBox.shrink()
                : Icon(data.isOpened == true
                    ? Icons.keyboard_arrow_up
                    : data.chargeDate == null
                      ? null : Icons.keyboard_arrow_down,
                color: Colors.black,
                size: 20),
          ),
          // onTap: () {
          //   if (data.isOpened == true) {
          //     data.isOpened = false;
          //   } else {
          //     data.isOpened = true;
          //   }
          // },
        ),
      ],
    );
  }

  @override
  int get rowCount => dataSource.length;

  @override
  bool get isRowCountApproximate => false;

  @override
  int get selectedRowCount => _selectedCount;

  void selectAll(bool? checked) {
    for (final data in dataSource) {
      data.selected = checked ?? false;
    }
    _selectedCount = (checked ?? false) ? dataSource.length : 0;
    notifyListeners();
  }
}





// import 'package:daeguro_ceo_app/common/constant.dart';
// import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
// import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
// import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
// import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
// import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
// import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
// import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
// import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
// import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
// import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
// import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
// import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown_v2.dart';
// import 'package:daeguro_ceo_app/layout/responsive.dart';
// import 'package:daeguro_ceo_app/models/AccountManager/accountHistoryMallModel.dart';
// import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
// import 'package:daeguro_ceo_app/util/utils.dart';
// import 'package:data_table_2/data_table_2.dart';
// import 'package:date_format/date_format.dart';
// import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
//
// class AccountHistoryMallMain extends StatefulWidget {
//   const AccountHistoryMallMain({Key? key}) : super(key: key);
//
//   @override
//   State<AccountHistoryMallMain> createState() => _AccountHistoryMallMainState();
// }
//
// class _AccountHistoryMallMainState extends State<AccountHistoryMallMain> {
//
//   String? startdate = '';
//   String? enddate = '';
//   String? tempStr;
//   String? selectedType = '1000';
//
//   int totaldeposit = 0;
//   int totalwithdraw = 0;
//   int moneySum = 0;
//
//   String? selectedPayType = ' ';
//   String? selectedOrderType = ' ';
//   String? selectedStatus = ' ';
//
//   int selectedPageNumber = 1;
//   int totalPage = 0;
//
//   int remainAmt = 0;
//
//   late AccountHistoryMallSource accountHistoryMallDataSource;
//   bool _initialized = false;
//
//   List<AccountHistoryMallModel> dataList = <AccountHistoryMallModel>[];
//
//   @override
//   void didChangeDependencies() {
//     super.didChangeDependencies();
//     if (!_initialized) {
//       accountHistoryMallDataSource = AccountHistoryMallSource(context, dataList, false, true, true, false);
//       // Default sorting sample. Set __sortColumnIndex to 0 and uncoment the lines below
//       // if (_sortColumnIndex == 0) {
//       //   _sort<String>((d) => d.name, _sortColumnIndex!, _sortAscending);
//       // }
//       _initialized = true;
//       accountHistoryMallDataSource.addListener(() {
//         setState(() {});
//       });
//     }
//   }
//
//   @override
//   void dispose() {
//     dataList.clear();
//     accountHistoryMallDataSource.dispose();
//     super.dispose();
//   }
//
//   requestAPIData() async {
//
//     var value = await showDialog(
//         context: context,
//         builder: (context) => FutureProgressDialog(AccountController.to.getShopAccountHistoryMallList(startdate!.replaceAll('-', ''), enddate!.replaceAll('-', ''), selectedPageNumber.toString()))
//     );
//
//     if (value == null) {
//       ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
//       //Navigator.of(context).pop;
//     }
//     else {
//       dataList.clear();
//
//       value.forEach((element) {
//         AccountHistoryMallModel temp = AccountHistoryMallModel();
//
//         // temp.orderDate = element['orderDate'] as String;
//         // temp.orderNo = element['orderNo'] as String;
//         // temp.appPayGbnName = element['appPayGbnName'] as String;
//         // temp.packOrderYnName = element['packOrderYnName'] as String;
//         // temp.status = element['status'] as String;
//
//         dataList.add(temp);
//       });
//
//       totalPage = AccountController.to.total_page;
//       remainAmt = AccountController.to.remainAmt;
//
//       totaldeposit = AccountController.to.totaldeposit;
//       totalwithdraw = AccountController.to.totalwithdraw;
//       moneySum = AccountController.to.moneySum;
//
//     }
//
//     setState(() {});
//   }
//
//   // loadData() async {
//   //   // 날짜필터
//   //   startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
//   //   enddate = formatDate(DateTime(int.parse(DateTime.now().year.toString()), int.parse(DateTime.now().month.toString()) + 1, 0), [yyyy, '-', mm, '-', dd]);
//   //
//   //   // 테이블 데이터
//   //   for (int i = 10; i < 20; i++) {
//   //     AccountHistoryMallModel temp = AccountHistoryMallModel();
//   //     temp.selected = false;
//   //
//   //     temp.orderDate = '2023-04-$i';
//   //     temp.accumulationClassification = '쇼핑몰';
//   //     temp.orderProductInformation = '대구로몰';
//   //     temp.deposit = (i * 7510).toString();
//   //     temp.withdraw = (-i * 15570).toString();
//   //     temp.finalAmount = (i * 7510 + -i * 1570).toString();
//   //     temp.depositDetail = (i * 7510).toString();
//   //     temp.withdrawDetail = (-i * 15700).toString();
//   //
//   //     // totalDeposit += int.parse(temp.deposit!);
//   //     // totalWithdraw += int.parse(temp.withdraw!);
//   //     dataList.add(temp);
//   //   }
//   //
//   //   totalDeposit = 248000;
//   //   totalWithdraw = -756;
//   //   totalReward = 24044;
//   //
//   //   totalPage = 100;
//   //
//   //   setState(() {});
//   // }
//
//   @override
//   void initState() {
//     super.initState();
//
//     Get.put(AccountController());
//
//     // 날짜필터
//     startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
//     enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
//
//     WidgetsBinding.instance.addPostFrameCallback((c) {
//       requestAPIData();
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     assert(fluentUI.debugCheckHasFluentTheme(context));
//
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         ISLabelBarMain(
//           trailing: Row(
//             mainAxisAlignment: MainAxisAlignment.end,
//             crossAxisAlignment: CrossAxisAlignment.end,
//             children: const [
//               Text('(입점 지원금 10,000원 포함)', style: TextStyle(color: Colors.grey, fontSize: 14),),
//               SizedBox(width: 6,),
//               Text('현재 적립금 25,487원', style: TextStyle(color: Colors.black, fontSize: 24),),
//             ],
//           ),
//         ),
//         const SizedBox(height: 8),
//         Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
//         const SizedBox(height: 8),
//         Container(
//             alignment: Responsive.isMobile(context) == true ? Alignment.centerRight : Alignment.centerLeft,
//             padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
//             //height: 40,
//             width: double.infinity,
//             decoration: BoxDecoration(color: Colors.grey[200],),
//             child: Text.rich(
//                 style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
//                 textAlign: Responsive.isMobile(context) == true ? TextAlign.end : TextAlign.start,
//                 TextSpan(children: [
//                   const TextSpan(text: '조회된 기간의 총 입금액은 '),
//                   TextSpan(text: Utils.getCashComma(totaldeposit.toString()), style: const TextStyle(color: Colors.lightBlue, )),
//                   const TextSpan(text: '원, '),
//                   const TextSpan(text: '총 출금액은 '),
//                   TextSpan(text: Utils.getCashComma(totalwithdraw.toString()), style: const TextStyle(color: Colors.lightBlue)),
//                   const TextSpan(text: '원, '),
//                   TextSpan(text: Responsive.isMobile(context) == true ? '\n' : ''),
//                   const TextSpan(text: '총 적립금액은 '),
//                   TextSpan(text: Utils.getCashComma(moneySum.toString()), style: const TextStyle(color: Colors.lightBlue)),
//                   const TextSpan(text: '원 입니다.'),
//                 ]
//                 )
//             )
//         ),
//         const SizedBox(height: 10,),
//         Expanded(
//           child: DataTable2(
//             // dataRowHeight: 30,
//             headingRowHeight: 40,
//             columnSpacing: 0,
//             horizontalMargin: 0,
//             headingRowColor: MaterialStateProperty.all(Colors.grey[100],),
//             headingTextStyle: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54),
//             // MaterialStateProperty.resolveWith((states) =>
//             //     _fixedRows > 0 ? Colors.grey[200] : Colors.transparent),
//             border: TableBorder(
//               borderRadius: BorderRadius.circular(10),
//               top: BorderSide(color: Colors.grey[300]!),
//               right: BorderSide(color: Colors.grey[300]!),
//               bottom: BorderSide(color: Colors.grey[300]!),
//               left: BorderSide(color: Colors.grey[300]!),
//               horizontalInside: BorderSide.none,
//             ),
//
//             dividerThickness: 0, // this one will be ignored if [border] is set above
//             bottomMargin: 10,
//             minWidth: 900,
//             // sortColumnIndex: _sortColus
//             // sortArrowIcon: Icons.keyboard_arrow_up, // custom arrow
//             // sortArrowAnimationDuration:
//             //     const Duration(milliseconds: 500), // custom animation duration
//             // onSelectAll: (val) =>
//             //     setState(() => _dessertsDataSource.selectAll(val)),
//             columns: const [
//               DataColumn2(label: Center(child: Text('주문일자')), size: ColumnSize.S,),
//               DataColumn2(label: Center(child: Text('적립구분')), size: ColumnSize.S, numeric: true,),
//               DataColumn2(label: Center(child: Text('주문상품 정보')), size: ColumnSize.S, numeric: true,),
//               DataColumn2(label: Align(alignment: Alignment.centerRight, child: Text('입금')), size: ColumnSize.S, numeric: true,),
//               DataColumn2(label: Align(alignment: Alignment.centerRight, child: Text('출금')), size: ColumnSize.S, numeric: true,),
//               DataColumn2(label: Align(alignment: Alignment.centerRight, child: Text('총 금액')), size: ColumnSize.S, numeric: true,),
//               DataColumn2(label: Center(child: Text('상세 보기')), size: ColumnSize.S, numeric: true,),
//             ],
//             empty: Center(
//                 child: Container(
//                     padding: const EdgeInsets.all(20),
//                     child: const Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)))),
//             rows: List<DataRow>.generate(accountHistoryMallDataSource.rowCount, (index) => accountHistoryMallDataSource.getRow(index)),
//           ),
//         ),
//         ISNumberPagination(
//           threshold: 5,
//           controlButton: const SizedBox(width: 10, height: 10,),
//           onPageChanged: (int pageNumber) {
//             //do somthing for selected page
//             setState(() {
//               selectedPageNumber = pageNumber;
//             });
//           },
//           fontSize: 12,
//           pageTotal: totalPage,
//           pageInit: selectedPageNumber, // picked number when init page
//           colorPrimary: Colors.black,
//           colorSub: Colors.white,
//         ),
//       ],
//     );
//   }
//
//   List<Widget> searchBarView() {
//     return [
//       ISSearchSelectDate(
//         label: '기간 선택',
//         width: Responsive.isMobile(context) == true ? double.infinity : 230,
//         value: '${startdate.toString()} ~ ${enddate.toString()}',
//         onTap: () async {
//           showGeneralDialog(
//               context: context,
//               barrierDismissible: true,
//               barrierLabel: '',
//               barrierColor: Colors.black54,
//               pageBuilder: (context, animation, secondaryAnimation) {
//                 return Dialog(
//                     elevation: 0,
//                     backgroundColor: Colors.white,
//                     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
//                     child: MultipleViewDateRangePicker(
//                       startDate: DateTime.parse(startdate!),
//                       endDate: DateTime.parse(enddate!),
//                       setDateActionCallback: ({startDate, endDate}) {
//                         setState(() {
//                           startdate = DateFormat('yyyy-MM-dd').format(startDate!);
//                           enddate = DateFormat('yyyy-MM-dd').format(endDate!);
//
//                         });
//                         Navigator.of(context).pop();
//                       },
//                     ));
//               });
//         },
//       ),
//       Responsive.isMobile(context) == true ?  const SizedBox(height: 8,) :  const SizedBox(width: 8,),
//       ISToggleButtons(
//         [
//           ISOptionModel(value: '1000', label: '오늘'),
//           ISOptionModel(value: '1001', label: '5일'),
//           ISOptionModel(value: '1002', label: '7일'),
//           ISOptionModel(value: '1003', label: '1개월'),
//           ISOptionModel(value: '1004', label: '3개월'),
//         ],
//         buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 5) - 6) : 60,
//         defaultValue: selectedType,
//         afterOnPress: (v) {
//           if (v == '1000'){
//             startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
//             enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
//           }
//           else if (v == '1001'){
//             startdate = formatDate(DateTime.now().subtract(const Duration(days: 5)), [yyyy, '-', mm, '-', dd]);
//             enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
//           }
//           else if (v == '1002'){
//             startdate = formatDate(DateTime.now().subtract(const Duration(days: 7)), [yyyy, '-', mm, '-', dd]);
//             enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
//           }
//           else if (v == '1003'){
//             startdate = formatDate(DateTime.now().subtract(const Duration(days: 30)), [yyyy, '-', mm, '-', dd]);
//             enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
//           }
//           else if (v == '1004'){
//             startdate = formatDate(DateTime.now().subtract(const Duration(days: 90)), [yyyy, '-', mm, '-', dd]);
//             enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
//           }
//
//
//           selectedPageNumber = 1;
//
//           requestAPIData();
//         },
//       ),
//     ];
//   }
// }
//
// class AccountHistoryMallSource extends DataTableSource {
//   final BuildContext context;
//   late List<AccountHistoryMallModel> dataSource = [];
//   // Add row tap handlers and show snackbar
//   bool hasRowTaps = false;
//   // Override height values for certain rows
//   bool hasRowHeightOverrides = false;
//   // Color each Row by index's parity
//   bool hasZebraStripes = false;
//
//   int _selectedCount = 0;
//
//   AccountHistoryMallSource.empty(this.context, this.dataSource) {
//     dataSource = [];
//   }
//
//   AccountHistoryMallSource(this.context, this.dataSource, [sortedByValue = false, this.hasRowTaps = false, this.hasRowHeightOverrides = false, this.hasZebraStripes = false]) {
//     //dataSource = dataList;
//     // if (sortedByValue) {
//     //   sort((d) => d., true);
//     // }
//   }
//
//   @override
//   DataRow getRow(int index, [Color? color, double fontSize = 14.0, FontWeight? fontWeight = FONT_NORMAL]) {
//
//
//     assert(index >= 0);
//     if (index >= dataSource.length) throw 'index > dataList.length';
//     final data = dataSource[index];
//
//     final cellDecoration = BoxDecoration(border: Border(bottom: BorderSide(color: !data.isChild && !data.isChild2 ? Colors.grey[200]! : Colors.transparent, width: 1)));
//
//     return DataRow2.byIndex(
//       index: index,
//       // selected: data.selected,
//       color: color != null
//           ? MaterialStateProperty.all(color)
//           : data.isChild
//           ? MaterialStateProperty.all(Colors.grey[200])
//           : data.isChild2
//           ? MaterialStateProperty.all(Colors.blue[50])
//           : MaterialStateProperty.all(Colors.transparent)
//       // (hasZebraStripes && index.isEven
//       //     ? MaterialStateProperty.all(Theme.of(context).highlightColor)
//       //     : null),
//       ,
//       // onSelectChanged: (value) {
//       //   if (data.selected != value) {
//       //     _selectedCount += value! ? 1 : -1;
//       //     assert(_selectedCount >= 0);
//       //     data.selected = value;
//       //     notifyListeners();
//       //   }
//       // },
//
//       onTap: hasRowTaps ? () => {
//         // _showSnackbar(context, 'Tapped on row ${data.orderNumber}'),
//         data.isChild || data.isChild2
//             ? null
//             : data.isOpened
//             ? {
//           dataSource.removeRange(index + 1, index + 3),
//           dataSource[index].isOpened = false
//         } : {
//           dataSource.insert(index + 1,
//             AccountHistoryMallModel(orderDate: '사유', orderProductInformation: '구매상품([무료배송] 삼겹살 수입산 3kg (구이용/수육용)[삼겹살 수입산 3kg 수육용]) 주문취소로 인한 상품대금 입금',
//               deposit: data.depositDetail,
//               finalAmount: data.depositDetail,
//               isChild: true,
//             ),
//           ),
//           dataSource.insert(index + 2,
//             AccountHistoryMallModel(orderDate: '사유', orderProductInformation: '[무료배송] 삼겹살 수입산 3kg (구이용/수육용) 상품대금 출금',
//               withdraw: data.withdrawDetail,
//               finalAmount: '-${data.withdrawDetail}',
//               isChild: true,
//             ),
//           ),
//           dataSource[index].isOpened = true
//         },
//         notifyListeners()
//       } : null,
//       specificRowHeight: hasRowHeightOverrides && (data.isChild || data.isChild2) ? 70 : null,
//       cells: [
//         DataCell(Container(padding: EdgeInsets.zero, decoration: cellDecoration, alignment: Alignment.center,
//             child: Text(data.orderDate ?? '', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),)
//         )),
//         DataCell(Container(decoration: cellDecoration, alignment: Alignment.center,
//             child: Text(data.accumulationClassification ?? '', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),)
//         )),
//         DataCell(Container(decoration: cellDecoration, alignment: Alignment.center,
//             child: Text(data.orderProductInformation ?? '', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),)
//         )),
//         DataCell(Container(decoration: cellDecoration, alignment: Alignment.centerRight,
//             child: Text('${Utils.getCashComma(data.deposit ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),)
//         )),
//         DataCell(Container(decoration: cellDecoration, alignment: Alignment.centerRight,
//             child: Text('${Utils.getCashComma(data.withdraw ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),)
//         )),
//         DataCell(Container(decoration: cellDecoration, alignment: Alignment.centerRight,
//             child: Text('${Utils.getCashComma(data.finalAmount ?? '')} 원', style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),)
//         )),
//         DataCell(Container(decoration: cellDecoration, alignment: Alignment.center,
//             child: (data.isChild == true)
//                 ? const SizedBox.shrink()
//                 : Icon(
//                 data.isOpened == true
//                     ? Icons.keyboard_arrow_up
//                     : data.accumulationClassification == null
//                     ? null
//                     : Icons.keyboard_arrow_down,
//                 color: Colors.black,
//                 size: 20),
//           ),
//           // onTap: () {
//           //   if (data.isOpened == true) {
//           //     data.isOpened = false;
//           //   } else {
//           //     data.isOpened = true;
//           //   }
//           // },
//         ),
//       ],
//     );
//   }
//
//   @override
//   int get rowCount => dataSource.length;
//
//   @override
//   bool get isRowCountApproximate => false;
//
//   @override
//   int get selectedRowCount => _selectedCount;
//
//   void selectAll(bool? checked) {
//     for (final data in dataSource) {
//       data.selected = checked ?? false;
//     }
//     _selectedCount = (checked ?? false) ? dataSource.length : 0;
//     notifyListeners();
//   }
// }
