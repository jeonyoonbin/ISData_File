import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionGroupListModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productSearchListModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productTopMenuAddModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductTopMenuAdd extends StatefulWidget {
  final String? shopCode;
  final String? menuCode;
  const ProductTopMenuAdd({Key? key, this.shopCode, this.menuCode})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ProductTopMenuAddState();
  }
}

class ProductTopMenuAddState extends State<ProductTopMenuAdd> {

  final List<ProductSearchListModel> dataList = <ProductSearchListModel>[];

  String? inputKeyword = '';

  requestAPIData(String? keyword) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getProductSearchList(keyword!))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        //if (element['mainYn'] as String == 'N'){
          ProductSearchListModel temp = ProductSearchListModel();
          temp.prodCd = element['prodCd'] as String;
          temp.name = element['name'] as String;
          temp.cost = element['cost'] as String;
          temp.useGbn = element['useGbn'] as String;
          temp.noFlag = element['noFlag'] as String;
          temp.mainYn = element['mainYn'] as String;

          temp.isFlag = (temp.mainYn == 'Y') ? true : false;

          dataList.add(temp);
        //}
      });
    }
    setState(() {});
  }
  
  requestTopMenuAdd(ProductTopMenuAddModel data) async {

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.addProductTopMenu(data.toJson()))
    );

    if (value != '00') {
      ISAlert(context, content: '정상 등록되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
      //Navigator.of(context).pop;
    }
    else {
      Navigator.of(context).pop(true);
    }
  }

  @override
  void dispose() {
    super.dispose();
    dataList.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData('');
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 540),
        contentPadding: const EdgeInsets.symmetric(horizontal: 8),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            const Text('대표상품 추가', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //const Divider(color: Colors.grey, height: 0.0,),
                //const SizedBox(height: 12,),
                const Text('* 최대 6개까지 등록 가능합니다.', style: TextStyle(color: Colors.grey, fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                const SizedBox(height: 8,),
                ISInput(
                  value: inputKeyword,
                  label: '상품명으로 검색해 보세요.',
                  prefixIcon: const Icon(Icons.search, color: Colors.black54,),
                  suffixIcon: MaterialButton(
                    color: Colors.lightBlueAccent,
                    minWidth: 60,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                    onPressed: () async {
                      requestAPIData(inputKeyword);
                    },
                    child: const Text('조회', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                  ),
                  onChange: (v) {
                    setState(() {
                      inputKeyword = v;
                    });
                  },
                ),
                const Divider(),
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.only(right: 16),
                    itemCount: dataList.length,
                    itemBuilder: (BuildContext context, int index) {
                      return dataList == null ?
                      const Text('Data is Empty')
                          : dataList[index].mainYn == 'Y' ? SizedBox.shrink() : Card(
                              color: /*dataList[index].mainYn == 'Y' ? Colors.grey.shade200 : */Colors.white,
                              elevation: 1,
                              shape: appTheme.cardShapStyle,
                              margin: const EdgeInsets.all(4),
                              child: CheckboxListTile(
                                contentPadding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                                activeColor: Colors.blue,
                                controlAffinity: ListTileControlAffinity.leading,
                                value: dataList[index].isFlag,
                                title: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Row(
                                      children: [
                                        dataList[index].useGbn == 'Y'
                                            ? Container(
                                            width: 36,
                                            height: 18,
                                            alignment: Alignment.center,
                                            decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                            child: const Center(
                                                child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                                ))
                                        ) : Container(
                                            width: 36,
                                            height: 18,
                                            alignment: Alignment.center,
                                            decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                            child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                        ),
                                        dataList[index].noFlag == 'Y'
                                            ? Container(
                                            width: 26,
                                            height: 18,
                                            margin: const EdgeInsets.only(left: 2.0),
                                            alignment: Alignment.center,
                                            decoration: AppTheme.getListBadgeDecoration(Colors.redAccent.shade100),
                                            child: const Center(child: Text('품절', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                        ) : const SizedBox.shrink(),
                                      ],
                                    ),
                                    const SizedBox(height: 5),
                                  ],
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(dataList[index].name ?? '--', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                                    Text('${Utils.getCashComma(dataList[index].cost!)}원', style: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                  ],
                                ),
                                onChanged: (val){
                                  // if (dataList[index].mainYn == 'Y')
                                  //   return;

                                  setState(() {
                                    dataList[index].isFlag = val!;
                                  });
                                },
                              ),
                          );
                    },
                  ),
                ),
                const Divider(),
              ],
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () {
                int mainYnCnt = 0;
                dataList.forEach((element) {
                  if (element.isFlag){
                    mainYnCnt++;
                  }
                });

                if (mainYnCnt > 6) {
                  ISAlert(context, content: '선택 상품수: [${mainYnCnt}개]\n대표상품 등록은 최대 6개까지 가능합니다.');
                  //Navigator.of(context).pop();
                  return;
                }

                ISConfirm(context, '대표상품 추가', '선택된 상품을 대표상품으로 추가합니다. \n\n계속 진행하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                  Navigator.of(context).pop();

                  if (isOK){
                    ProductTopMenuAddModel sendData = ProductTopMenuAddModel();
                    sendData.shopCd = AuthService.SHOPCD;

                    List<String> productCdList = [];

                    dataList.forEach((element) {
                      if (element.isFlag){
                        productCdList.add(element.prodCd!);
                      }
                    });
                    sendData.prodCd = productCdList;
                    sendData.uCode = AuthService.uCode;
                    sendData.uName = AuthService.uName;

                    requestTopMenuAdd(sendData);
                  }

                });
              },
              child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }
}


