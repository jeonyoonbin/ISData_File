import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/screen/ReviewManager/ReviewSuccessionEdit.dart';
import 'package:flutter/material.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:provider/provider.dart';

import '../../common/constant.dart';
import '../../iswidgets/is_alertdialog.dart';
import '../../theme.dart';


class ReviewSuccessionInfo extends StatefulWidget {
  const ReviewSuccessionInfo({Key? key, required this.actionsMode})
      : super(key: key);

  final bool actionsMode;
  @override
  State<ReviewSuccessionInfo> createState() => _ReviewSuccessionInfoState();
}

class _ReviewSuccessionInfoState extends State<ReviewSuccessionInfo> {
  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      backgroundColor: Colors.transparent,
      resizeToAvoidBottomInset: true,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 650.0, maxHeight: 850),
        contentPadding: const EdgeInsets.all(0),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            const Text('리뷰 승계 조건', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('* 양도,양수 등의 이유로 해지 후 재 입점 시 리뷰 승계가 가능합니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                    const Text('* 가게명 또는 메뉴가 변경되는 경우에는 리뷰 승계가 불가합니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),

                    const SizedBox(height: 20,),
                    const Text('* 본인 승계 방법', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                    Wrap(
                      direction: Axis.horizontal,
                      children: [
                        const SizedBox(width: 10,),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                                padding: EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: Colors.grey,
                                  borderRadius: BorderRadius.all(Radius.circular(5)),
                                ),
                              child: Text('필요 서류: 사업자등록증, 통장사본, 마스킹 처리 된 신분증 사본', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),)
                            ),
                            const Text('승계 가능 조건: 사업자 번호를 바꿨는데 가게 이름이나 메뉴는 그대로인 경우 리뷰 승계가 가능합니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('* 사업자 등록증은 사업자 번호 변경 이전 사업자 등록증이 필요합니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('* 신분증 사본의 경우 마스킹 처리된 신분증이 아니면 리뷰승계가 반려 될 수 있습니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                          ],
                        ),
                      ],
                    ),

                    const SizedBox(height: 20,),
                    const Text('* 가족간 승계 방법', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                    Wrap(
                      direction: Axis.horizontal,
                      children: [
                        const SizedBox(width: 10,),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                                padding: const EdgeInsets.all(8.0),
                                decoration: const BoxDecoration(
                                  color: Colors.grey,
                                  borderRadius: BorderRadius.all(Radius.circular(5)),
                                ),
                                child: Text('필요 서류: 신분증 사본, 가족관계증명서', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),)
                            ),
                            const Text('승계 가능 조건: 가게 명 또는 메뉴가 변경되지 않는다면 리뷰 승계가 가능합니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                          ],
                        ),
                      ],
                    ),

                    const SizedBox(height: 20,),
                    const Text('* 직원간 승계 방법', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                    Wrap(
                      direction: Axis.horizontal,
                      children: [
                        const SizedBox(width: 10,),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                                padding: const EdgeInsets.all(8.0),
                                decoration: const BoxDecoration(
                                  color: Colors.grey,
                                  borderRadius: BorderRadius.all(Radius.circular(5)),
                                ),
                                child: Text('필요 서류: 재직증명서, 급여명세서, 건강보험증명서 또는 국민연금가입증명서(택 1)', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),)
                            ),
                            const Text('승계 가능 조건:  3개월 이상 4대 보험을 넣고 해당 매장에 근무를 한 경우, 직원에게 리뷰 승계가 가능합니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('서류는 최근 3개월 이내에 발급한 서류만 가능하며 일정 급여가 일정 날짜에 지급이 되어 있어야 합니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                          ],
                        )
                      ],
                    ),

                    const SizedBox(height: 20,),
                    const Text('* 공동사업자에서 개인사업자 변경 시 승계 방법', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                    Wrap(
                      direction: Axis.horizontal,
                      children: [
                        const SizedBox(width: 10,),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                                padding: const EdgeInsets.all(8.0),
                                decoration: const BoxDecoration(
                                  color: Colors.grey,
                                  borderRadius: BorderRadius.all(Radius.circular(5)),
                                ),
                                child: const Text('필요 서류: 사업자 등록증, 마스킹 처리 된 신분증 사본', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),)
                            ),
                            const Text('승계 가능 조건: 사업자 번호를 바꿨는데 가게 이름이나 메뉴는 그대로인 경우 리뷰 승계가 가능합니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('30일 이상 공동사업자로 유지가 되어있어야 리뷰 승계가 가능합니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('* 사업자등록증은 사업자 번호 변경 이전의 공동사업자등록증이 필요합니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('* 신분증 사본의 경우 마스킹 처리 된 신분증이 아니면 리뷰승계가 반려 될 수 있습니다.', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const SizedBox(height: 10,),
                            const Text('승계방법:', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('1. 관할구청에서 공동사업자로 영업 신고증 변경', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('2. 영업 신고증 지참해 세무서에 공동사업자등록증 신청(양도인 지분 1%와 양수인 지분 99%로 작성)', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('3. 공동사업자등록증으로 대구로에서 변경', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('4. 30일 이상 공동사업자로 유지 ', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('5. 30일 지난 후 관할구청 세무서에 개인사업자로 변경', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                            const Text('6. 절차대로 진행 후 대구로 고객센터로 접수하여 신규 가맹점 생성 후 리뷰 승계 진행', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                          ],
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        actions: [
          widget.actionsMode
              ?
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          )
              :
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleSingle,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('닫기', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          widget.actionsMode
              ?
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () {
                Navigator.pop(context);

                showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => const ReviewSuccessionEdit(),
                );
              },
              child: const Text('변경 요청', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ) : SizedBox.shrink()
          ,
        ],
      ),
    );

  }
}
