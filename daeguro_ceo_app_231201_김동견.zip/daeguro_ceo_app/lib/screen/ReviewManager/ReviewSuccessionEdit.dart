import 'dart:convert';

import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import 'package:http/http.dart' as http;

import '../../common/constant.dart';
import '../../config/auth_service.dart';
import '../../iswidgets/datepicker/flutter_date_range_picker.dart';
import '../../iswidgets/is_alertdialog.dart';
import '../../iswidgets/is_optionModel.dart';
import '../../iswidgets/is_progressDialog.dart';
import '../../iswidgets/isd_input.dart';
import '../../iswidgets/isd_search_dropdown.dart';
import '../../models/RequestManager/requestShopInfoEditModel.dart';
import '../../network/ImageUploadController.dart';
import '../../theme.dart';
import '../RequestManager/requestManagerController.dart';
import '../ShopManager/shopManagerController.dart';
import 'ReviewSuccessionInfo.dart';

enum Type { agree, disagree }

class ReviewSuccessionEdit extends StatefulWidget {
  const ReviewSuccessionEdit({Key? key})
      : super(key: key);

  @override
  State<ReviewSuccessionEdit> createState() => _ReviewSuccessionEditState();
}

class _ReviewSuccessionEditState extends State<ReviewSuccessionEdit> {

  final ScrollController image1Controller = ScrollController();
  final ScrollController image2Controller = ScrollController();
  final ScrollController image3Controller = ScrollController();

  List<PickedFile>? image1List = <PickedFile>[];
  List<PickedFile>? image2List = <PickedFile>[];
  List<PickedFile>? image3List = <PickedFile>[];

  Type agreeOrNot = Type.agree;

  RequestShopInfoEditModel transferReviewInfoData = RequestShopInfoEditModel();

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ShopController.to.getRegistInfo())
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
    }
    else {
      transferReviewInfoData.b_shop_name = AuthService.SHOPNAME;
      transferReviewInfoData.b_reg_no = value['regNo'] as String;
      transferReviewInfoData.b_owner = value['bussOwner'] as String;
      transferReviewInfoData.b_telno = value['telNo'] as String;
    }

    setState(() {});
  }


  @override
  void dispose() {
    super.dispose();

    image1List?.clear();
    image2List?.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());
    Get.put(ImageUploadController());
    Get.put(RequestController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    const EdgeInsetsGeometry InputPadding = const EdgeInsets.fromLTRB(10, 13, 4, 13);

    return Scaffold(
      backgroundColor: Colors.transparent,
      resizeToAvoidBottomInset: true,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 650.0, maxHeight: 850),
        contentPadding: const EdgeInsets.all(0),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            const Text('리뷰 이관 신청', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      clipBehavior: Clip.hardEdge,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                        boxShadow: [
                          BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                        ],
                      ),
                      height: 390,
                      child: Container(
                        padding: const EdgeInsets.all(16.0),
                        width: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('이전 가맹점', style: TextStyle(fontSize: 17, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                            const SizedBox(height: 20,),
                            const Divider(height: 2,),
                            const SizedBox(height: 20,),
                            const Text('가맹점 명', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                            ISInput(
                              label: '',
                              contentPadding: InputPadding,
                              width: 800,
                              height: 50,
                              value: transferReviewInfoData.a_shop_name,
                              counterText: '',
                              onChange: (v) {
                                transferReviewInfoData.a_shop_name = v;
                                setState(() {
                                });
                              },
                            ),
                            const Text('사업자번호', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                            ISInput(
                              label: '하이픈 (-)은 제외하고 입력해주세요',
                              contentPadding: InputPadding,
                              width: 800,
                              height: 50,
                              value: transferReviewInfoData.a_reg_no,
                              counterText: '',
                              onChange: (v) {
                                transferReviewInfoData.a_reg_no = v;
                                setState(() {
                                });
                              },
                            ),
                            const Text('대표자명(성명)', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                            ISInput(
                              label: '',
                              contentPadding: InputPadding,
                              width: 800,
                              height: 50,
                              value: transferReviewInfoData.a_owner,
                              counterText: '',
                              onChange: (v) {
                                transferReviewInfoData.a_owner = v;
                                setState(() {
                                });
                              },
                            ),
                            const Text('연락처', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                            ISInput(
                              label: '하이픈 (-)은 제외하고 입력해주세요',
                              contentPadding: InputPadding,
                              width: 800,
                              height: 50,
                              value: transferReviewInfoData.a_telno,
                              counterText: '',
                              onChange: (v) {
                                transferReviewInfoData.a_telno = v;
                                setState(() {
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20,),
                    Container(
                      clipBehavior: Clip.hardEdge,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                        boxShadow: [
                          BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                        ],
                      ),
                      height: 430,
                      child: Container(
                        padding: const EdgeInsets.all(16.0),
                        width: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('승계 받을 가맹점', style: TextStyle(fontSize: 17, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                            const SizedBox(height: 20,),
                            const Divider(height: 2,),
                            const SizedBox(height: 20,),
                            const Text('가맹점 명', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                            Text('${transferReviewInfoData.b_shop_name}', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                            const SizedBox(height: 10,),
                            const Text('사업자번호', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                            Text('${transferReviewInfoData.b_reg_no}', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                            const SizedBox(height: 10,),
                            const Text('대표자명(성명)', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                            Text('${transferReviewInfoData.b_owner}', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                            const SizedBox(height: 10,),
                            const Text('연락처', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                            Text('${transferReviewInfoData.b_telno}', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                            const SizedBox(height: 10,),
                            const Text('사유', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                            const SizedBox(height: 5,),
                            ISSearchDropdown(
                              label: '선택하세요',
                              width: 420,
                              height: 50,
                              value: transferReviewInfoData.reason == '' ? '0' : transferReviewInfoData.reason,
                              onChange: (value) {
                                transferReviewInfoData.reason = value.toString();

                                setState(() {
                                });
                              },
                              item: [
                                ISOptionModel(value: '0', label: '사유를 선택해주세요'),
                                ISOptionModel(value: '1', label: '본인 승계'),
                                ISOptionModel(value: '2', label: '가족간 승계'),
                                ISOptionModel(value: '3', label: '직원간 승계'),
                                ISOptionModel(value: '4', label: '공동 사업자에서 개인 사업자 변경시 승계'),
                              ].cast<ISOptionModel>(),
                            ),
                            const SizedBox(height: 10,),
                            ISButton(
                              child: const Text('신청 가능 조건 보기'),
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  barrierDismissible: true,
                                  builder: (context) => const ReviewSuccessionInfo(actionsMode: false,),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20,),
                    Container(
                      //width: MediaQuery.of(context).size.width - 500,//double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                      decoration: const BoxDecoration(
                          color: Color.fromARGB(255, 240, 240, 240),
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      // height: 35,
                      child: const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('요청 시 첨부 서류 : 마스킹 처리된 신분증 사본', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                          SizedBox(height: 8,),
                          Text('※ 마스킹 처리된 신분증 ex)', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                          SizedBox(height: 8,),
                          Align(alignment: Alignment.center, child: Image(image: AssetImage('images/invalid-name@2x.png'), fit: BoxFit.cover, height: 80,)),
                          SizedBox(height: 8,),
                          Text('· 신분증에 마스킹 처리가 되어있지 않을 경우 리뷰 승계가 반려될 수 있습니다.', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                          Text('· 내용을 충분히 확인할 수 있도록 선명하게 촬영된 이미지를 첨부 부탁드리며 정보 확인이 어려울 경우 승인이 지연될 수 있다는 점 양해 바랍니다.', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                          Text('· 로고, 첨부 서류 이미지는 5MB 이하, JPG/PNG 파일만 올릴 수 있습니다.', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10,),

                    transferReviewInfoData.reason == '1'
                        ?
                    Text(
                      image1List!.isEmpty ? '사업자등록증' : '사업자등록증(총 ${image1List!.length}개)',
                      style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                    )
                        :
                    Text(
                      image1List!.isEmpty ? '신분증사본' : '신분증사본(총 ${image1List!.length}개)',
                      style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                    ),
                    if (image1List!.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 120,
                        child: Scrollbar(
                          thumbVisibility: true,
                          trackVisibility: true,
                          controller: image1Controller,
                          radius: const Radius.circular(0.0),
                          showTrackOnHover: true,
                          thickness: 8,
                          child: ListView.builder(
                              controller: image1Controller,
                              itemCount: image1List!.length,
                              scrollDirection: Axis.horizontal,
                              itemBuilder: (context, idx) {
                                return Stack(
                                  alignment: AlignmentDirectional.topEnd,
                                  children: [
                                    (image1List![idx] == null)
                                        ? const Image(
                                      image: AssetImage('images/thumbnail-empty.png'),
                                      width: 100,
                                      height: 100,
                                    )
                                        : Padding(
                                      padding: const EdgeInsets.fromLTRB(4, 0, 4, 20), //symmetric(horizontal: 4, vertical: 20),
                                      child: Image.network(
                                        image1List![idx].path,
                                        fit: BoxFit.cover,
                                        gaplessPlayback: true,
                                        width: 100,
                                        height: 100,
                                        loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                          if (loadingProgress == null) return child;
                                          return const Center(
                                            child: CircularProgressIndicator(
                                              valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                            ),
                                          );
                                        },
                                        errorBuilder: (context, error, stackTrace) {
                                          return const Image(
                                            image: AssetImage('images/thumbnail-empty.png'),
                                            width: 100,
                                            height: 100,
                                          );
                                        },
                                      ),
                                    ),
                                    Positioned(
                                      top: 2,
                                      right: 6,
                                      child: InkWell(
                                        child: const Image(
                                          image: AssetImage('images/image_remove_small.png'),
                                          width: 20,
                                          height: 20,
                                        ),
                                        onTap: () {
                                          image1List!.removeAt(idx);
                                          setState(() {});
                                        },
                                      ),
                                    )
                                  ],
                                );
                              }),
                        ),
                      ),
                    ],
                    Container(
                      constraints: const BoxConstraints(minWidth: 210),
                      width: double.infinity,
                      alignment: Alignment.center,
                      margin: const EdgeInsets.only(top: 10.0),
                      child: InkWell(
                        child: DottedBorder(
                          padding: const EdgeInsets.only(
                            top: 6,
                            bottom: 6,
                          ),
                          color: const Color(0xffDDDDDD),
                          strokeWidth: 1,
                          radius: const Radius.circular(10.0),
                          child: const ClipRRect(
                            borderRadius: BorderRadius.all(Radius.circular(10.0)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                                SizedBox(
                                  width: 8,
                                ),
                                Text(
                                  '이미지 파일 선택',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontFamily: FONT_FAMILY,
                                    color: Color(0xff999999),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        onTap: () async {
                          // 이미지 등록
                          ImagePicker imagePicker = ImagePicker();
                          Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                          imageFile.then((file) async {
                            image1List!.add(file!);
                            setState(() {});
                          });
                        },
                      ),
                    ),
                    const SizedBox(height: 8),
                    transferReviewInfoData.reason == '1'
                        ?
                    Text(
                      image2List!.isEmpty ? '통장사본' : '통장사본(총 ${image1List!.length}개)',
                      style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                    )
                        : transferReviewInfoData.reason == '2'
                        ?
                    Text(
                      image2List!.isEmpty ? '가족관계증명서' : '가족관계증명서(총 ${image1List!.length}개)',
                      style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                    )
                        : transferReviewInfoData.reason == '3'
                        ?
                    Text(
                      image2List!.isEmpty ? '재직증명서' : '재직증명서(총 ${image2List!.length}개)',
                      style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                    )
                        :
                    Text(
                      image2List!.isEmpty ? '사업자등록증' : '사업자등록증(총 ${image2List!.length}개)',
                      style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                    ),
                    if (image2List!.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 120,
                        child: Scrollbar(
                          thumbVisibility: true,
                          trackVisibility: true,
                          controller: image2Controller,
                          radius: const Radius.circular(0.0),
                          showTrackOnHover: true,
                          thickness: 8,
                          child: ListView.builder(
                              controller: image2Controller,
                              itemCount: image2List!.length,
                              scrollDirection: Axis.horizontal,
                              itemBuilder: (context, idx) {
                                return Stack(
                                  alignment: AlignmentDirectional.topEnd,
                                  children: [
                                    (image2List![idx] == null)
                                        ? const Image(
                                      image: AssetImage('images/thumbnail-empty.png'),
                                      width: 100,
                                      height: 100,
                                    )
                                        : Padding(
                                      padding: const EdgeInsets.fromLTRB(4, 0, 4, 20),
                                      child: Image.network(
                                        image2List![idx].path,
                                        fit: BoxFit.cover,
                                        gaplessPlayback: true,
                                        width: 100,
                                        height: 100,
                                        loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                          if (loadingProgress == null) return child;
                                          return const Center(
                                            child: CircularProgressIndicator(
                                              valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                            ),
                                          );
                                        },
                                        errorBuilder: (context, error, stackTrace) {
                                          return const Image(
                                            image: AssetImage('images/thumbnail-empty.png'),
                                            width: 100,
                                            height: 100,
                                          );
                                        },
                                      ),
                                    ),
                                    Positioned(
                                      top: 2,
                                      right: 6,
                                      child: InkWell(
                                        child: const Image(
                                          image: AssetImage('images/image_remove_small.png'),
                                          width: 20,
                                          height: 20,
                                        ),
                                        onTap: () {
                                          image2List!.removeAt(idx);
                                          setState(() {});
                                        },
                                      ),
                                    )
                                  ],
                                );
                              }),
                        ),
                      ),
                    ],
                    Container(
                      constraints: const BoxConstraints(minWidth: 210),
                      width: double.infinity,
                      alignment: Alignment.center,
                      margin: const EdgeInsets.only(top: 10.0),
                      child: InkWell(
                        child: DottedBorder(
                          padding: const EdgeInsets.only(
                            top: 6,
                            bottom: 6,
                          ),
                          color: const Color(0xffDDDDDD),
                          strokeWidth: 1,
                          radius: const Radius.circular(10.0),
                          child: const ClipRRect(
                            borderRadius: BorderRadius.all(Radius.circular(10.0)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                                SizedBox(
                                  width: 8,
                                ),
                                Text(
                                  '이미지 파일 선택',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontFamily: FONT_FAMILY,
                                    color: Color(0xff999999),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        onTap: () async {
                          // 이미지 등록
                          ImagePicker imagePicker = ImagePicker();
                          Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                          imageFile.then((file) async {
                            image2List!.add(file!);
                            setState(() {});
                          });
                        },
                      ),
                    ),
                    const SizedBox(height: 20,),

                    Visibility(
                      visible: transferReviewInfoData.reason == '1' || transferReviewInfoData.reason == '3' ? true : false,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          transferReviewInfoData.reason == '1'
                              ?
                          Text(
                            image3List!.isEmpty ? '신분증사본' : '신분증사본(총 ${image3List!.length}개)',
                            style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                          )
                              :
                          Text(
                            image3List!.isEmpty ? '급여명세서 or 국민연금가입증명서' : '급여명세서 or 국민연금가입증명서(총 ${image3List!.length}개)',
                            style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                          ),
                          if (image3List!.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            SizedBox(
                              height: 120,
                              child: Scrollbar(
                                thumbVisibility: true,
                                trackVisibility: true,
                                controller: image3Controller,
                                radius: const Radius.circular(0.0),
                                showTrackOnHover: true,
                                thickness: 8,
                                child: ListView.builder(
                                    controller: image3Controller,
                                    itemCount: image3List!.length,
                                    scrollDirection: Axis.horizontal,
                                    itemBuilder: (context, idx) {
                                      return Stack(
                                        alignment: AlignmentDirectional.topEnd,
                                        children: [
                                          (image3List![idx] == null)
                                              ? const Image(
                                            image: AssetImage('images/thumbnail-empty.png'),
                                            width: 100,
                                            height: 100,
                                          )
                                              : Padding(
                                            padding: const EdgeInsets.fromLTRB(4, 0, 4, 20),
                                            child: Image.network(
                                              image3List![idx].path,
                                              fit: BoxFit.cover,
                                              gaplessPlayback: true,
                                              width: 100,
                                              height: 100,
                                              loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                                if (loadingProgress == null) return child;
                                                return const Center(
                                                  child: CircularProgressIndicator(
                                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                                  ),
                                                );
                                              },
                                              errorBuilder: (context, error, stackTrace) {
                                                return const Image(
                                                  image: AssetImage('images/thumbnail-empty.png'),
                                                  width: 100,
                                                  height: 100,
                                                );
                                              },
                                            ),
                                          ),
                                          Positioned(
                                            top: 2,
                                            right: 6,
                                            child: InkWell(
                                              child: const Image(
                                                image: AssetImage('images/image_remove_small.png'),
                                                width: 20,
                                                height: 20,
                                              ),
                                              onTap: () {
                                                image3List!.removeAt(idx);
                                                setState(() {});
                                              },
                                            ),
                                          )
                                        ],
                                      );
                                    }),
                              ),
                            ),
                          ],
                          Container(
                            constraints: const BoxConstraints(minWidth: 210),
                            width: double.infinity,
                            alignment: Alignment.center,
                            margin: const EdgeInsets.only(top: 10.0),
                            child: InkWell(
                              child: DottedBorder(
                                padding: const EdgeInsets.only(
                                  top: 6,
                                  bottom: 6,
                                ),
                                color: const Color(0xffDDDDDD),
                                strokeWidth: 1,
                                radius: const Radius.circular(10.0),
                                child: const ClipRRect(
                                  borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                                      SizedBox(
                                        width: 8,
                                      ),
                                      Text(
                                        '이미지 파일 선택',
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontFamily: FONT_FAMILY,
                                          color: Color(0xff999999),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              onTap: () async {
                                // 이미지 등록
                                ImagePicker imagePicker = ImagePicker();
                                Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                                imageFile.then((file) async {
                                  image3List!.add(file!);
                                  setState(() {});
                                });
                              },
                            ),
                          ),
                          const SizedBox(height: 20,),
                        ],
                      ),
                    ),


                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('※ 개인정보 수집 및 이용에 대한 안내', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                        Text('- 개인정보 수집 및 이용 목적 : 본인 접수 및 처리 결과 회신', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                        Text('- 수집하는 개인정보 항목 : 성명, 연락처, 마스킹 된 신청자의 신분증 사본', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                        Text('- 그 외 신고서와 신고 내용은 관계법령 및 민·형사상 소송 대응을 위해 보관하며, 그 밖의 사항은 개인정보처리방침을 준수합니다. 위 개인정보 수집 및 이용에 동의 합니다.', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                        Text('- 개인정보의 수집, 이용에 관한 동의를 거부할 권리가 있으며, 동의를 거부할 경우 권리침해 업무 절차상 처리에 제한이 있을 수 있습니다.', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                        Text('- 위 내용에 동의 하실 경우 하단 동의 여부를 작성해주세요', style: TextStyle(fontSize: 13, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                      ],
                    ),
                    const SizedBox(height: 20,),
                    Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('신청인(성명)', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                          ISInput(
                            label: '홍길동',
                            contentPadding: InputPadding,
                            width: 800,
                            height: 50,
                            value: transferReviewInfoData.applicant,
                            counterText: '',
                            onChange: (v) {
                              transferReviewInfoData.applicant = v;
                              setState(() {
                              });
                            },
                          ),
                          const Text('접수일자', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                          ISInput(
                            label: DateFormat('yyyy-MM-dd').format(DateTime.now()),
                            contentPadding: InputPadding,
                            width: 800,
                            height: 50,
                            value: transferReviewInfoData.date_consent,
                            counterText: '',
                            onChange: (v) {
                              transferReviewInfoData.date_consent = v;
                              setState(() {
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                    Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('동의 여부', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                          SizedBox(
                            height: 46,
                            child: Row(
                              children: [
                                Radio(
                                    visualDensity: const VisualDensity(horizontal: VisualDensity.minimumDensity, vertical: VisualDensity.minimumDensity),
                                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                    value: Type.agree,
                                    groupValue: agreeOrNot,
                                    onChanged: (Type? value){
                                      setState(() {
                                        agreeOrNot = value!;
                                      });
                                    }
                                ),
                                const Text("동의", style: TextStyle(fontSize: 13),),
                                const SizedBox(width: 20,),
                                Radio(
                                    visualDensity: const VisualDensity(horizontal: VisualDensity.minimumDensity, vertical: VisualDensity.minimumDensity),
                                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                    value: Type.disagree,
                                    groupValue: agreeOrNot,
                                    onChanged: (Type? value){
                                      setState(() {
                                        agreeOrNot = value!;
                                        print(agreeOrNot);
                                      });
                                    }
                                ),
                                const Text("미동의", style: TextStyle(fontSize: 13),),
                                const SizedBox(width: 8,),
                              ],
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,

              onPressed: () async {

                List<PickedFile> imageList;

                if(transferReviewInfoData.reason == '1' || transferReviewInfoData.reason == '3'){
                  imageList = List<PickedFile>.from(image1List!)..addAll(image2List!)..addAll(image3List!);
                }else{
                  imageList = List<PickedFile>.from(image1List!)..addAll(image2List!);
                }

                if(transferReviewInfoData.a_shop_name == '' || transferReviewInfoData.a_reg_no == '' || transferReviewInfoData.a_owner == '' || transferReviewInfoData.a_telno == '' || transferReviewInfoData.applicant == '' || transferReviewInfoData.date_consent == '' ) {
                  ISAlert(context, content: '모든 정보를 입력해주세요.');
                  return;
                }
                else if(transferReviewInfoData.reason == '0'){
                  ISAlert(context, content: '승계 사유를 선택해주세요.');
                  return;
                }
                else if(transferReviewInfoData.reason == '1' || transferReviewInfoData.reason == '3'){
                  if(image1List!.isEmpty || image2List!.isEmpty || image3List!.isEmpty){
                    ISAlert(context, content: '첨부자료를 모두 등록해주세요.');
                    return;
                  }
                }
                else if(transferReviewInfoData.reason == '2' || transferReviewInfoData.reason == '4'){
                  if(image1List!.isEmpty || image2List!.isEmpty){
                    ISAlert(context, content: '첨부자료를 모두 등록해주세요.');
                    return;
                  }
                }

                if(agreeOrNot == Type.disagree){
                  ISAlert(context, content: '이관 동의 여부를 다시 확인해주세요.');
                  return;
                }

                transferReviewInfoData.consent_yn = 'Y';
                transferReviewInfoData.shopCd = AuthService.SHOPCD;
                transferReviewInfoData.serviceGbn = '800';
                transferReviewInfoData.status = '10';

                await showDialog(
                context: context,
                barrierColor: Colors.transparent,
                builder: (context) => FutureProgressDialog(RequestController.to.setRequireMultiImageService(transferReviewInfoData, imageList))
                ).then((value) async {
                  if (value == null) {
                    ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                  }
                  else {
                    http.Response.fromStream(value).asStream().listen((event) {
                      if (event.statusCode == 200) {
                        var result = jsonDecode(event.body);

                        String code = result['code'].toString();
                        String msg = result['msg'].toString();

                        if (code == '00'){
                          Navigator.of(context).pop(true);
                          ISAlert(context, title: '리뷰 이관 신청 완료', content: '리뷰 이관 신청이 접수되었습니다.\n\n결과는 [변경 요청 내역] 메뉴에서 확인해 주세요.', constraints: BoxConstraints(maxWidth: 360.0));
                        }
                        else{
                          ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${msg} ');
                        }
                      }
                      else{
                        Navigator.of(context).pop(true);
                      }
                    });
                  }
                });
              },
              child: const Text('신청', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );

  }
}
