import 'dart:convert';
import 'dart:js' as js;
import 'dart:js';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/models/RequestManager/requestShopInfoEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/network/ImageUploadController.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import 'package:http/http.dart' as http;

import '../../iswidgets/is_optionModel.dart';
import '../../iswidgets/is_progressDialog.dart';
import '../../iswidgets/isd_button.dart';
import '../../iswidgets/isd_input.dart';
import '../../iswidgets/isd_search_dropdown.dart';
import '../../layout/responsive.dart';
import '../../models/ShopManager/shopRegistInfoModel.dart';

class RequestShopRegistInfoEdit extends StatefulWidget {
  final ShopRegistInfoModel shopRegistInfoData;
  const RequestShopRegistInfoEdit(this.shopRegistInfoData, {Key? key})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return RequestShopRegistInfoEditState();
  }
}

class RequestShopRegistInfoEditState extends State<RequestShopRegistInfoEdit> {

  final ScrollController _registrationScrollController = ScrollController();
  final ScrollController _reportCertificateScrollController = ScrollController();
  final ScrollController _scrollController = ScrollController();

  List<PickedFile>? attachedImage1 = <PickedFile>[];
  List<PickedFile>? attachedImage2 = <PickedFile>[];
  List<PickedFile>? attachedImage3 = <PickedFile>[];
  List<PickedFile>? attachedImage4 = <PickedFile>[];

  String jibunAddress = '';
  String newAddress = '';
  String zoneCode = '';
  String detailAddr = '';

  RequestShopInfoEditModel modRegistInfoData = RequestShopInfoEditModel();

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
    attachedImage1?.clear();
    attachedImage2?.clear();
    attachedImage3?.clear();
    attachedImage4?.clear();
  }

  @override
  void initState() {
    super.initState();

    modRegistInfoData.b_reg_no = widget.shopRegistInfoData.regNo;
    modRegistInfoData.b_owner = widget.shopRegistInfoData.bussOwner;
    modRegistInfoData.b_buss_con = widget.shopRegistInfoData.bussCon;
    modRegistInfoData.b_buss_type = widget.shopRegistInfoData.bussType;
    modRegistInfoData.b_buss_addr = widget.shopRegistInfoData.bussAddr;
    modRegistInfoData.b_buss_tax_type = widget.shopRegistInfoData.bussTaxType;
    // modRegistInfoData.serviceGbn = '0';
    // modRegistInfoData.a_buss_tax_type = '0';

    Get.put(ImageUploadController());
    Get.put(RequestController());
  }

  void getAddressFromJavaScript() {
    // JavaScript의 daumAddr 함수 호출
    JsFunction daumAddr = context['daumAddr'];
    daumAddr.callMethod('call');
  }

  void handleAddressFromJavaScript(js.JsObject data){
    String roadAddr = data['address'];
    String jibunAddr = data['jibunAddress'];
    String zCode = data['zonecode'];

    setState(() {
      newAddress = roadAddr;
      jibunAddress = jibunAddr;
      zoneCode = zCode;
    });
  }

  void setupJsCallbacks(){
    context['add']['handleAddress'] = js.allowInterop(handleAddressFromJavaScript);
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    const TextStyle elementStyle = TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY);
    const EdgeInsetsGeometry InputPadding = const EdgeInsets.fromLTRB(10, 13, 4, 13);

    final appTheme = context.watch<AppTheme>();

    setupJsCallbacks();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 800),
        contentPadding: const EdgeInsets.all(0.0),
        //const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            const Text('사업자 정보 변경 요청', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 10,),
                    const Text(textAlign: TextAlign.left, '변경유형', style: elementStyle),
                    Container( // 변경 유형
                      alignment: Alignment.centerLeft,
                      height: 50,
                      child: ISSearchDropdown(
                        label: '선택하세요',
                        width: 420,
                        height: 50,
                        value: modRegistInfoData.serviceGbn == '' ? '0' : modRegistInfoData.serviceGbn,
                        onChange: (v) {
                          modRegistInfoData.serviceGbn = v;
                          setState(() {
                          });
                        },
                        item: [
                          ISOptionModel(value: '0', label: '변경 유형을 선택해주세요'),
                          ISOptionModel(value: '100', label: '단순 변경(주소, 업태, 사업자 유형 등)'),
                          ISOptionModel(value: '101', label: '대표자 변경(사업자 정보 동일)'),
                          ISOptionModel(value: '102', label: '가족간 승계'),
                          ISOptionModel(value: '103', label: '개인 -> 법인 변경'),
                        ].cast<ISOptionModel>(),
                      ),
                    ),

                    const SizedBox(height: 10,),
                    const Text(textAlign: TextAlign.left, '상호명', style: elementStyle),
                    Container( // 상호명
                      // 231129 상호명 변경하는 부분이 없어서 그냥 SHOPNAME 넣어둠.
                      alignment: Alignment.centerLeft,
                      height: 50,
                      child: ISInput(
                        readOnly: true,
                        label: '',
                        contentPadding: InputPadding,
                        width: 800,
                        height: 50,
                        value: AuthService.SHOPNAME,
                      ),
                    ),

                    const SizedBox(height: 10,),

                    Visibility(  // 사업자 등록번호
                      visible: modRegistInfoData.serviceGbn == '103' ? true : false,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(textAlign: TextAlign.left, '사업자등록번호', style: elementStyle),
                          Container(
                            alignment: Alignment.centerLeft,
                            height: 50,
                            child: ISInput(
                              label: '사업자 등록 번호',
                              contentPadding: InputPadding,
                              width: 800,
                              height: 50,
                              value: modRegistInfoData.a_reg_no,
                              onChange: (v) {
                                modRegistInfoData.a_reg_no = v;
                                setState(() {
                                });
                              },
                            ),
                          ),
                          const Text('* - 제외하고 입력해 주세요',style: TextStyle(color: Colors.red, fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                          const SizedBox(height: 10,),
                        ],
                      ),
                    ),

                    Visibility(
                      visible: modRegistInfoData.serviceGbn == '101' || modRegistInfoData.serviceGbn == '102' || modRegistInfoData.serviceGbn == '103' ? true : false,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(textAlign: TextAlign.left, '대표자명', style: elementStyle),
                          Container( // 대표자 명
                            alignment: Alignment.centerLeft,
                            height: 50,
                            child: ISInput(
                              label: '대표자명',
                              contentPadding: InputPadding,
                              width: 800,
                              height: 50,
                              value: modRegistInfoData.a_owner,
                              counterText: '',
                              onChange: (v) {
                                modRegistInfoData.a_owner = v;
                                setState(() {
                                });
                              },
                            ),
                          ),
                          const SizedBox(height: 10,),
                        ],
                      ),
                    ),

                    Visibility(
                      visible: modRegistInfoData.serviceGbn == '103' || modRegistInfoData.serviceGbn == '100' ? true : false,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(textAlign: TextAlign.left, '업태', style: elementStyle),
                          Container( // 업태
                            alignment: Alignment.centerLeft,
                            height: 50,
                            child: ISInput(
                              label: '업태',
                              contentPadding: InputPadding,
                              width: 800,
                              height: 50,
                              value: modRegistInfoData.a_buss_con,
                              counterText: '',
                              onChange: (v) {
                                modRegistInfoData.a_buss_con = v;
                                setState(() {
                                });
                              },
                            ),
                          ),

                          const SizedBox(height: 10,),
                        ],
                      ),
                    ),

                    Visibility(
                      visible: modRegistInfoData.serviceGbn == '103' ? true : false,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(textAlign: TextAlign.left, '업종', style: elementStyle),
                          Container( // 업종
                            alignment: Alignment.centerLeft,
                            height: 50,
                            child: ISInput(
                              label: '업종',
                              contentPadding: InputPadding,
                              width: 800,
                              height: 50,
                              value: modRegistInfoData.a_buss_type,
                              counterText: '',
                              onChange: (v) {
                                modRegistInfoData.a_buss_type = v;
                                setState(() {
                                });
                              },
                            ),
                          ),

                          const SizedBox(height: 10,),
                        ],
                      ),
                    ),

                    Visibility(
                      visible: modRegistInfoData.serviceGbn == '103' || modRegistInfoData.serviceGbn == '100' ? true : false,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(textAlign: TextAlign.left, '사업자유형', style: elementStyle),
                          Container( // 사업자 유형
                            alignment: Alignment.centerLeft,
                            height: 50,
                            child: Wrap(
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                ISSearchDropdown(
                                  label: '선택하세요',
                                  width: 420,
                                  height: 50,
                                  value: modRegistInfoData.a_buss_tax_type == '' ? '0' : modRegistInfoData.a_buss_tax_type,
                                  onChange: (v) {
                                    modRegistInfoData.a_buss_tax_type = v;
                                    setState(() {});
                                  },
                                  item: [
                                    ISOptionModel(value: '0', label: '변경 유형을 선택해주세요'),
                                    ISOptionModel(value: '1', label: '일반사업자'),
                                    ISOptionModel(value: '5', label: '법인사업자'),
                                    ISOptionModel(value: '3', label: '간이사업자'),
                                    ISOptionModel(value: '7', label: '면세사업자'),
                                  ].cast<ISOptionModel>(),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 10,),
                        ],
                      ),
                    ),

                    Visibility(
                      visible: modRegistInfoData.serviceGbn == '103' || modRegistInfoData.serviceGbn == '100' ? true : false,
                      child: Column( // 사업장 주소
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(textAlign: TextAlign.left, '사업장 주소', style: elementStyle),
                          Row(
                            children: [
                              Flexible(
                                flex: 4,
                                child: ISInput(
                                    label: '우편번호',
                                    contentPadding: InputPadding,
                                    width: 800,
                                    height: 50,
                                    value: zoneCode != '' ? zoneCode : '',
                                    counterText: '',
                                    onChange: (v) {
                                      setState(() {});
                                    },
                                    onTap: (){
                                      getAddressFromJavaScript();
                                    }
                                ),
                              ),
                              const SizedBox(width: 5),
                              Flexible(
                                flex: 1,
                                child: ISButton(
                                  height: 44,
                                  onPressed: (){
                                    getAddressFromJavaScript();
                                  },
                                  child: const Text('검색'),
                                ),
                              )
                            ],
                          ),
                          ISInput(
                            label: '주소',
                            contentPadding: InputPadding,
                            width: 800,
                            height: 50,
                            value: newAddress != '' ? newAddress : '',
                            counterText: '',
                            onChange: (v) {
                              setState(() {});
                            },
                            onTap: (){
                              getAddressFromJavaScript();
                            },
                          ),
                          ISInput(
                            label: '상세주소',
                            contentPadding: InputPadding,
                            width: 800,
                            height: 50,
                            value: detailAddr,
                            counterText: '',
                            onChange: (v) {
                              detailAddr = v;
                              modRegistInfoData.a_buss_addr = '$newAddress $detailAddr';
                              setState(() {
                              });
                            },
                          ),

                          const SizedBox(height: 10,),
                        ],
                      ),
                    ),


                    Visibility( // attachedImage1
                      visible: modRegistInfoData.serviceGbn == '100' || modRegistInfoData.serviceGbn == '101' || modRegistInfoData.serviceGbn == '102' || modRegistInfoData.serviceGbn == '103' ? true : false,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          modRegistInfoData.serviceGbn == '100'
                              ?
                          Text(
                            attachedImage1!.isEmpty ? '사업자등록증' : '사업자등록증(총 ${attachedImage1!.length}개)',
                            style: elementStyle,
                          )
                              : modRegistInfoData.serviceGbn == '101'
                              ?
                          Text(
                            attachedImage1!.isEmpty ? '사업자등록증(기존, 변경)' : '사업자등록증(총 ${attachedImage1!.length}개)',
                            style: elementStyle,
                          )
                              : modRegistInfoData.serviceGbn == '103'
                              ?
                          Text(
                            attachedImage1!.isEmpty ? '사업자등록증(기존)' : '사업자등록증(총 ${attachedImage1!.length}개)',
                            style: elementStyle,
                          )
                              :
                          Text(
                            attachedImage1!.isEmpty ? '가족관계증명서' : '사업자등록증(총 ${attachedImage1!.length}개)',
                            style: elementStyle,
                          ),
                          if (attachedImage1!.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            SizedBox(
                              height: 120,
                              child: Scrollbar(
                                thumbVisibility: true,
                                trackVisibility: true,
                                controller: _registrationScrollController,
                                radius: const Radius.circular(0.0),
                                showTrackOnHover: true,
                                thickness: 8,
                                child: ListView.builder(
                                    controller: _registrationScrollController,
                                    itemCount: attachedImage1!.length,
                                    scrollDirection: Axis.horizontal,
                                    itemBuilder: (context, idx) {
                                      return Stack(
                                        alignment: AlignmentDirectional.topEnd,
                                        children: [
                                          (attachedImage1![idx] == null)
                                              ? const Image(
                                            image: AssetImage('images/thumbnail-empty.png'),
                                            width: 100,
                                            height: 100,
                                          )
                                              : Padding(
                                            padding: const EdgeInsets.fromLTRB(4, 0, 4, 20), //symmetric(horizontal: 4, vertical: 20),
                                            child: Image.network(
                                              attachedImage1![idx].path,
                                              fit: BoxFit.cover,
                                              gaplessPlayback: true,
                                              width: 100,
                                              height: 100,
                                              loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                                if (loadingProgress == null) return child;
                                                return const Center(
                                                  child: CircularProgressIndicator(
                                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                                  ),
                                                );
                                              },
                                              errorBuilder: (context, error, stackTrace) {
                                                return const Image(
                                                  image: AssetImage('images/thumbnail-empty.png'),
                                                  width: 100,
                                                  height: 100,
                                                );
                                              },
                                            ),
                                          ),
                                          Positioned(
                                            top: 2,
                                            right: 6,
                                            child: InkWell(
                                              child: const Image(
                                                image: AssetImage('images/image_remove_small.png'),
                                                width: 20,
                                                height: 20,
                                              ),
                                              onTap: () {
                                                attachedImage1!.removeAt(idx);
                                                setState(() {});
                                              },
                                            ),
                                          )
                                        ],
                                      );
                                    }),
                              ),
                            ),
                          ],
                          Container(
                            constraints: const BoxConstraints(minWidth: 210),
                            width: double.infinity,
                            alignment: Alignment.center,
                            margin: const EdgeInsets.only(top: 10.0),
                            child: InkWell(
                              child: DottedBorder(
                                padding: const EdgeInsets.only(
                                  top: 6,
                                  bottom: 6,
                                ),
                                color: const Color(0xffDDDDDD),
                                strokeWidth: 1,
                                radius: const Radius.circular(10.0),
                                child: const ClipRRect(
                                  borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                                      SizedBox(
                                        width: 8,
                                      ),
                                      Text(
                                        '이미지 파일 선택',
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontFamily: FONT_FAMILY,
                                          color: Color(0xff999999),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              onTap: () async {
                                // 이미지 등록
                                ImagePicker imagePicker = ImagePicker();
                                Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                                imageFile.then((file) async {
                                  attachedImage1!.add(file!);
                                  setState(() {});
                                });
                              },
                            ),
                          ),
                          const SizedBox(height: 20,),
                        ],
                      ),
                    ),

                    Visibility( // attachedImage2
                      visible: modRegistInfoData.serviceGbn == '100' || modRegistInfoData.serviceGbn == '101' || modRegistInfoData.serviceGbn == '103' ? true : false,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          modRegistInfoData.serviceGbn == '103'
                              ?
                          Text(
                            attachedImage2!.isEmpty ? '영업신고증(기존,변경)' : '영업신고증(총 ${attachedImage2!.length}개)',
                            style: elementStyle,
                          )
                              :
                          Text(
                            attachedImage2!.isEmpty ? '영업신고증' : '영업신고증(총 ${attachedImage2!.length}개)',
                            style: elementStyle,
                          ),
                          if (attachedImage2!.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            SizedBox(
                              height: 120,
                              child: Scrollbar(
                                thumbVisibility: true,
                                trackVisibility: true,
                                controller: _reportCertificateScrollController,
                                radius: const Radius.circular(0.0),
                                showTrackOnHover: true,
                                thickness: 8,
                                child: ListView.builder(
                                    controller: _reportCertificateScrollController,
                                    itemCount: attachedImage2!.length,
                                    scrollDirection: Axis.horizontal,
                                    itemBuilder: (context, idx) {
                                      return Stack(
                                        alignment: AlignmentDirectional.topEnd,
                                        children: [
                                          (attachedImage2![idx] == null)
                                              ? const Image(
                                            image: AssetImage('images/thumbnail-empty.png'),
                                            width: 100,
                                            height: 100,
                                          )
                                              : Padding(
                                            padding: const EdgeInsets.fromLTRB(4, 0, 4, 20),
                                            child: Image.network(
                                              attachedImage2![idx].path,
                                              fit: BoxFit.cover,
                                              gaplessPlayback: true,
                                              width: 100,
                                              height: 100,
                                              loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                                if (loadingProgress == null) return child;
                                                return const Center(
                                                  child: CircularProgressIndicator(
                                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                                  ),
                                                );
                                              },
                                              errorBuilder: (context, error, stackTrace) {
                                                return const Image(
                                                  image: AssetImage('images/thumbnail-empty.png'),
                                                  width: 100,
                                                  height: 100,
                                                );
                                              },
                                            ),
                                          ),
                                          Positioned(
                                            top: 2,
                                            right: 6,
                                            child: InkWell(
                                              child: const Image(
                                                image: AssetImage('images/image_remove_small.png'),
                                                width: 20,
                                                height: 20,
                                              ),
                                              onTap: () {
                                                attachedImage2!.removeAt(idx);
                                                setState(() {});
                                              },
                                            ),
                                          )
                                        ],
                                      );
                                    }),
                              ),
                            ),
                          ],
                          Container(
                            constraints: const BoxConstraints(minWidth: 210),
                            width: double.infinity,
                            alignment: Alignment.center,
                            margin: const EdgeInsets.only(top: 10.0),
                            child: InkWell(
                              child: DottedBorder(
                                padding: const EdgeInsets.only(
                                  top: 6,
                                  bottom: 6,
                                ),
                                color: const Color(0xffDDDDDD),
                                strokeWidth: 1,
                                radius: const Radius.circular(10.0),
                                child: const ClipRRect(
                                  borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                                      SizedBox(
                                        width: 8,
                                      ),
                                      Text(
                                        '이미지 파일 선택',
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontFamily: FONT_FAMILY,
                                          color: Color(0xff999999),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              onTap: () async {
                                // 이미지 등록
                                ImagePicker imagePicker = ImagePicker();
                                Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                                imageFile.then((file) async {
                                  attachedImage2!.add(file!);
                                  setState(() {});
                                });
                              },
                            ),
                          ),
                          const SizedBox(height: 20,),
                        ],
                      ),
                    ),


                    Visibility( // attachedImage3
                      visible: modRegistInfoData.serviceGbn == '101' || modRegistInfoData.serviceGbn == '103' ? true : false,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          modRegistInfoData.serviceGbn == '101'
                              ?
                          Text(
                            attachedImage3!.isEmpty ? '마스킹 된 신분증' : '마스킹 된 신분증(총 ${attachedImage3!.length}개)',
                            style: elementStyle,
                          )
                              :
                          Text(
                            attachedImage3!.isEmpty ? '법인사업자' : '법인사업자(총 ${attachedImage3!.length}개)',
                            style: elementStyle,
                          ),
                          if (attachedImage3!.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            SizedBox(
                              height: 120,
                              child: Scrollbar(
                                thumbVisibility: true,
                                trackVisibility: true,
                                controller: _reportCertificateScrollController,
                                radius: const Radius.circular(0.0),
                                showTrackOnHover: true,
                                thickness: 8,
                                child: ListView.builder(
                                    controller: _reportCertificateScrollController,
                                    itemCount: attachedImage3!.length,
                                    scrollDirection: Axis.horizontal,
                                    itemBuilder: (context, idx) {
                                      return Stack(
                                        alignment: AlignmentDirectional.topEnd,
                                        children: [
                                          (attachedImage3![idx] == null)
                                              ? const Image(
                                            image: AssetImage('images/thumbnail-empty.png'),
                                            width: 100,
                                            height: 100,
                                          )
                                              : Padding(
                                            padding: const EdgeInsets.fromLTRB(4, 0, 4, 20),
                                            child: Image.network(
                                              attachedImage3![idx].path,
                                              fit: BoxFit.cover,
                                              gaplessPlayback: true,
                                              width: 100,
                                              height: 100,
                                              loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                                if (loadingProgress == null) return child;
                                                return const Center(
                                                  child: CircularProgressIndicator(
                                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                                  ),
                                                );
                                              },
                                              errorBuilder: (context, error, stackTrace) {
                                                return const Image(
                                                  image: AssetImage('images/thumbnail-empty.png'),
                                                  width: 100,
                                                  height: 100,
                                                );
                                              },
                                            ),
                                          ),
                                          Positioned(
                                            top: 2,
                                            right: 6,
                                            child: InkWell(
                                              child: const Image(
                                                image: AssetImage('images/image_remove_small.png'),
                                                width: 20,
                                                height: 20,
                                              ),
                                              onTap: () {
                                                attachedImage3!.removeAt(idx);
                                                setState(() {});
                                              },
                                            ),
                                          )
                                        ],
                                      );
                                    }),
                              ),
                            ),
                          ],
                          Container(
                            constraints: const BoxConstraints(minWidth: 210),
                            width: double.infinity,
                            alignment: Alignment.center,
                            margin: const EdgeInsets.only(top: 10.0),
                            child: InkWell(
                              child: DottedBorder(
                                padding: const EdgeInsets.only(
                                  top: 6,
                                  bottom: 6,
                                ),
                                color: const Color(0xffDDDDDD),
                                strokeWidth: 1,
                                radius: const Radius.circular(10.0),
                                child: const ClipRRect(
                                  borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                                      SizedBox(
                                        width: 8,
                                      ),
                                      Text(
                                        '이미지 파일 선택',
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontFamily: FONT_FAMILY,
                                          color: Color(0xff999999),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              onTap: () async {
                                // 이미지 등록
                                ImagePicker imagePicker = ImagePicker();
                                Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                                imageFile.then((file) async {
                                  attachedImage3!.add(file!);
                                  setState(() {});
                                });
                              },
                            ),
                          ),
                          const SizedBox(height: 20,),
                        ],
                      ),
                    ),

                    Visibility( // attachedImage4
                      visible: modRegistInfoData.serviceGbn == '101' || modRegistInfoData.serviceGbn == '103' ? true : false,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          modRegistInfoData.serviceGbn == '101'
                              ?
                          Text(
                            attachedImage4!.isEmpty ? '통장사본' : '통장사본(총 ${attachedImage4!.length}개)',
                            style: elementStyle,
                          )
                              :
                          Text(
                            attachedImage4!.isEmpty ? '법인통장' : '법인통장(총 ${attachedImage4!.length}개)',
                            style: elementStyle,
                          ),
                          if (attachedImage4!.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            SizedBox(
                              height: 120,
                              child: Scrollbar(
                                thumbVisibility: true,
                                trackVisibility: true,
                                controller: _reportCertificateScrollController,
                                radius: const Radius.circular(0.0),
                                showTrackOnHover: true,
                                thickness: 8,
                                child: ListView.builder(
                                    controller: _reportCertificateScrollController,
                                    itemCount: attachedImage4!.length,
                                    scrollDirection: Axis.horizontal,
                                    itemBuilder: (context, idx) {
                                      return Stack(
                                        alignment: AlignmentDirectional.topEnd,
                                        children: [
                                          (attachedImage4![idx] == null)
                                              ? const Image(
                                            image: AssetImage('images/thumbnail-empty.png'),
                                            width: 100,
                                            height: 100,
                                          )
                                              : Padding(
                                            padding: const EdgeInsets.fromLTRB(4, 0, 4, 20),
                                            child: Image.network(
                                              attachedImage4![idx].path,
                                              fit: BoxFit.cover,
                                              gaplessPlayback: true,
                                              width: 100,
                                              height: 100,
                                              loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                                if (loadingProgress == null) return child;
                                                return const Center(
                                                  child: CircularProgressIndicator(
                                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                                  ),
                                                );
                                              },
                                              errorBuilder: (context, error, stackTrace) {
                                                return const Image(
                                                  image: AssetImage('images/thumbnail-empty.png'),
                                                  width: 100,
                                                  height: 100,
                                                );
                                              },
                                            ),
                                          ),
                                          Positioned(
                                            top: 2,
                                            right: 6,
                                            child: InkWell(
                                              child: const Image(
                                                image: AssetImage('images/image_remove_small.png'),
                                                width: 20,
                                                height: 20,
                                              ),
                                              onTap: () {
                                                attachedImage4!.removeAt(idx);
                                                setState(() {});
                                              },
                                            ),
                                          )
                                        ],
                                      );
                                    }),
                              ),
                            ),
                          ],
                          Container(
                            constraints: const BoxConstraints(minWidth: 210),
                            width: double.infinity,
                            alignment: Alignment.center,
                            margin: const EdgeInsets.only(top: 10.0),
                            child: InkWell(
                              child: DottedBorder(
                                padding: const EdgeInsets.only(
                                  top: 6,
                                  bottom: 6,
                                ),
                                color: const Color(0xffDDDDDD),
                                strokeWidth: 1,
                                radius: const Radius.circular(10.0),
                                child: const ClipRRect(
                                  borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                                      SizedBox(
                                        width: 8,
                                      ),
                                      Text(
                                        '이미지 파일 선택',
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontFamily: FONT_FAMILY,
                                          color: Color(0xff999999),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              onTap: () async {
                                // 이미지 등록
                                ImagePicker imagePicker = ImagePicker();
                                Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                                imageFile.then((file) async {
                                  attachedImage4!.add(file!);
                                  setState(() {});
                                });
                              },
                            ),
                          ),
                          const SizedBox(height: 20,),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () {
                BuildContext dialogContext = context;

                List<PickedFile> ImageList;

                if(modRegistInfoData.serviceGbn == '100'){
                  ImageList = List<PickedFile>.from(attachedImage1!)..addAll(attachedImage2!);
                }else if(modRegistInfoData.serviceGbn == '101' || modRegistInfoData.serviceGbn == '103'){
                  ImageList = List<PickedFile>.from(attachedImage1!)..addAll(attachedImage2!)..addAll(attachedImage3!)..addAll(attachedImage4!);
                }else{
                  ImageList = attachedImage1!;
                }

                modRegistInfoData.shopCd = AuthService.SHOPCD;
                modRegistInfoData.status = '10';

                showDialog(
                  context: context,
                  barrierDismissible: true,
                  builder: (context) => Responsive.isMobile(context) ? mobileChangeInfoCheck(context,dialogContext,appTheme, modRegistInfoData, ImageList) : desktopChangeInfoCheck(context,dialogContext,appTheme, modRegistInfoData, ImageList)
                );

              },
              child: const Text('변경 요청', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }
}

Widget desktopChangeInfoCheck(context, dialogContext, appTheme,RequestShopInfoEditModel modRegistInfoData, List<PickedFile> imageList){


  return ContentDialog(
    constraints: BoxConstraints(maxWidth: 700.0, maxHeight: 450),
    contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
    isFillActions: true,
    title: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const SizedBox(width: 20),
        const Text('사업자 정보 변경 요청', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
        fluentUI.SmallIconButton(
          child: fluentUI.Tooltip(
            message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
            child: fluentUI.IconButton(
              icon: const Icon(fluentUI.FluentIcons.chrome_close),
              onPressed: Navigator.of(context).pop,
            ),
          ),
        ),
      ],
    ),
    content: Material(
      color: Colors.transparent,
      borderOnForeground: false,
      child: Column(
        children: [
          const SizedBox(height: 20,),
          const Text('기존 사업자 정보에서 해당 사업자 정보로 변경 하시겠습니까?', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
          const SizedBox(height: 20,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                clipBehavior: Clip.hardEdge,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                height: 230,
                child: Container(
                  padding: const EdgeInsets.all(16.0),
                  width: 300,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('기존 사업자 정보', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                      SizedBox(height: 10,),
                      Text('사업자 번호 : ${modRegistInfoData.b_reg_no}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자명 : ${modRegistInfoData.b_owner}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업태 : ${modRegistInfoData.b_buss_con}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업종 : ${modRegistInfoData.b_buss_type}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자 유형 : ${getBussTypeStr(modRegistInfoData.b_buss_tax_type!)}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업장 주소 : ${modRegistInfoData.b_buss_addr}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                    ],
                  ),
                ),
              ),
              SizedBox(width: 20,),
              Icon(Icons.arrow_forward_ios_outlined),
              SizedBox(width: 20,),
              Container(
                clipBehavior: Clip.hardEdge,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                height: 230,
                child: Container(
                  padding: const EdgeInsets.all(16.0),
                  width: 300,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('변경 사업자 정보', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                      SizedBox(height: 10,),
                      Text('사업자 번호 : ${modRegistInfoData.a_reg_no}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자명 : ${modRegistInfoData.a_owner}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업태 : ${modRegistInfoData.a_buss_con}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업종 : ${modRegistInfoData.a_buss_type}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자 유형 : ${getBussTypeStr(modRegistInfoData.a_buss_tax_type!)}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업장 주소 : ${modRegistInfoData.a_buss_addr}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                    ],
                  ),
                ),
              )
            ],
          ),
        ],
      ),
    ),
    actions: [
      SizedBox(
        child: FilledButton(
          style: appTheme.popupButtonStyleLeft,
          onPressed: () {
            Navigator.pop(context);
          },
          child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
        ),
      ),
      SizedBox(
        child: FilledButton(
          style: appTheme.popupButtonStyleRight,
          onPressed: () async {
            // Navigator.pop(dialogContext);

            await showDialog(
            context: dialogContext,
            barrierColor: Colors.transparent,
            builder: (context) => FutureProgressDialog(RequestController.to.setRequireMultiImageService(modRegistInfoData, imageList))
            ).then((value) async {
              if (value == null) {
                ISAlert(dialogContext, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
              }
              else {
                http.Response.fromStream(value).asStream().listen((event) {
                  if (event.statusCode == 200) {
                    var result = jsonDecode(event.body);

                    String code = result['code'].toString();
                    String msg = result['msg'].toString();

                    if (code == '00'){
                      Navigator.of(dialogContext).pop(true);
                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(dialogContext, content: '정상 처리가 되지 않았습니다.\n→ ${msg} ');
                    }
                  }
                  else{
                    Navigator.of(dialogContext).pop(true);
                  }
                });
              }
            });


          },
          child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
        ),
      ),
    ],
  );
}

Widget mobileChangeInfoCheck(context, dialogContext, appTheme, modRegistInfoData, List<PickedFile> imageList){
  return ContentDialog(
    constraints: BoxConstraints(maxWidth: double.infinity, maxHeight: 800),
    contentPadding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.1, vertical: 15),
    isFillActions: true,
    title: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const SizedBox(width: 20),
        const Text('사업자 정보 변경 요청', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
        fluentUI.SmallIconButton(
          child: fluentUI.Tooltip(
            message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
            child: fluentUI.IconButton(
              icon: const Icon(fluentUI.FluentIcons.chrome_close),
              onPressed: Navigator.of(context).pop,
            ),
          ),
        ),
      ],
    ),
    content: SingleChildScrollView(
      child: Scrollbar(
        isAlwaysShown: false,
        child: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text('기존 사업자 정보에서\n해당 사업자 정보로 변경하시겠습니까?', style: TextStyle(fontSize: 17, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
              const SizedBox(height: 10,),
              Container(
                clipBehavior: Clip.hardEdge,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                height: 220,
                child: Container(
                  padding: const EdgeInsets.all(16.0),
                  width: 340,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('기존 사업자 정보', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                      SizedBox(height: 10,),
                      Text('사업자 번호 : ${modRegistInfoData.b_reg_no}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자명 : ${modRegistInfoData.b_owner}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업태 : ${modRegistInfoData.b_buss_con}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업종 : ${modRegistInfoData.b_buss_type}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자 유형 : ${getBussTypeStr(modRegistInfoData.b_buss_tax_type)}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업장 주소 : ${modRegistInfoData.b_buss_addr}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20,),
              Icon(Icons.arrow_downward_outlined),
              SizedBox(height: 20,),
              Container(
                clipBehavior: Clip.hardEdge,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                height: 220,
                child: Container(
                  padding: const EdgeInsets.all(16.0),
                  width: 340,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('변경 사업자 정보', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                      SizedBox(height: 10,),
                      Text('사업자 번호 : ${modRegistInfoData.a_reg_no}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자명 : ${modRegistInfoData.a_owner}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업태 : ${modRegistInfoData.a_buss_con}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업종 : ${modRegistInfoData.a_buss_type}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자 유형 : ${getBussTypeStr(modRegistInfoData.a_buss_tax_type)}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업장 주소 : ${modRegistInfoData.a_buss_addr}', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                    ],
                  ),
                ),
              )
            ],
          )
        ),
      ),
    ),
    actions: [
      SizedBox(
        child: FilledButton(
          style: appTheme.popupButtonStyleLeft,
          onPressed: () {
            Navigator.pop(context);
          },
          child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
        ),
      ),
      SizedBox(
        child: FilledButton(
          style: appTheme.popupButtonStyleRight,
          onPressed: () async {
            // Navigator.pop(dialogContext);

            await showDialog(
            context: dialogContext,
            barrierColor: Colors.transparent,
            builder: (context) => FutureProgressDialog(RequestController.to.setRequireMultiImageService(modRegistInfoData, imageList))
            ).then((value) async {
              if (value == null) {
                ISAlert(dialogContext, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
              }
              else {
                http.Response.fromStream(value).asStream().listen((event) {
                  if (event.statusCode == 200) {
                    var result = jsonDecode(event.body);

                    String code = result['code'].toString();
                    String msg = result['msg'].toString();

                    if (code == '00'){
                      Navigator.of(dialogContext).pop(true);
                      Navigator.of(context).pop(true);
                    }
                    else{
                      ISAlert(dialogContext, content: '정상 처리가 되지 않았습니다.\n→ ${msg} ');
                    }
                  }
                  else{
                    Navigator.of(dialogContext).pop(true);
                  }
                });
              }
            });


          },
          child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
        ),
      ),
    ],
  );
}

String getBussTypeStr(String type){
  String? tempStr = '';

  if (type == '1')         tempStr = '일반';
  else if (type == '3')    tempStr = '간이';
  else if (type == '5')    tempStr = '법인';
  else if (type == '7')    tempStr = '면세';
  else {
    return '';
  }

  return '${tempStr} 사업자';
}