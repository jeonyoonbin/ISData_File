import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/Common/commonNoFlagModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionSoldOutEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopReserveSbTimeEditModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopReserveBTimeEdit extends StatefulWidget {
  final dynamic? b_time;
  const ShopReserveBTimeEdit({Key? key, this.b_time})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopReserveBTimeEditState();
  }
}

class ShopReserveBTimeEditState extends State<ShopReserveBTimeEdit> {
  final ScrollController _scrollController = ScrollController();
  dynamic? setB_time;
  List<dynamic> tempSetB_time = [];

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());

    // b_time 데이터가 null 일경우 임시 데이터 적용
    if(widget.b_time.toString() == '[]') {
      for(int i = 0; i < 7; i++) {
        var addData = {
          'dayGbn': (i+1).toString(),
          'openTime': '0900',
          'closeTime': '2200',
          'closeGbn': 'N',
        };

        tempSetB_time.add(addData);
      }

      setB_time = tempSetB_time;
    } else {
      setB_time = widget.b_time;
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 680),
        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('브레이크타임 설정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            SizedBox(width: 10),
            Text('*일괄 적용은 월요일 기준으로 적용됩니다.', style: const TextStyle(fontSize: 14, color: Colors.grey),),
          ],
        ),
        content: Material(
            color: Colors.transparent,
            borderOnForeground: false,
            child: SingleChildScrollView(
              controller: _scrollController,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 10),
                  ISLabelBarSub(
                    title: '브레이크타임',
                    trailing: ISButton(
                      child: const Text('일괄 적용'),
                      onPressed: () {
                        print(setB_time[0]);

                        setB_time.forEach((element) { // 월요일 기준이라서 index 0 아니고 1
                          element['openTime'] = setB_time[1]['openTime'];
                          element['closeTime'] = setB_time[1]['closeTime'];
                          element['closeGbn'] = setB_time[1]['closeGbn'];
                        });

                        setState(() {});
                      },
                    ),
                    body: Container(
                      alignment: Alignment.centerLeft,
                      width: double.infinity,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('월요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[1]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[1]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[1]['openTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게종료', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[1]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[1]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[1]['closeTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              ISCheckbox(
                                  label: '없음',
                                  value: setB_time[1]['closeGbn'] == 'Y' ? true : false,
                                  onChanged: (v) {
                                    setState(() {
                                      if (v == true) {
                                        setB_time[1]['closeGbn'] = 'Y';
                                      } else {
                                        setB_time[1]['closeGbn'] = 'N';
                                      }
                                    });
                                  }
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('화요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[2]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[2]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[2]['openTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게종료', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[2]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[2]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[2]['closeTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              ISCheckbox(
                                  label: '없음',
                                  value: setB_time[2]['closeGbn'] == 'Y' ? true : false,
                                  onChanged: (v) {
                                    setState(() {
                                      if (v == true) {
                                        setB_time[2]['closeGbn'] = 'Y';
                                      } else {
                                        setB_time[2]['closeGbn'] = 'N';
                                      }
                                    });
                                  }
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('수요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[3]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[3]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[3]['openTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게종료', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[3]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[3]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[3]['closeTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              ISCheckbox(
                                  label: '없음',
                                  value: setB_time[3]['closeGbn'] == 'Y' ? true : false,
                                  onChanged: (v) {
                                    setState(() {
                                      if (v == true) {
                                        setB_time[3]['closeGbn'] = 'Y';
                                      } else {
                                        setB_time[3]['closeGbn'] = 'N';
                                      }
                                    });
                                  }
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('목요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[4]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[4]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[4]['openTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게종료', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[4]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[4]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[4]['closeTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              ISCheckbox(
                                  label: '없음',
                                  value: setB_time[4]['closeGbn'] == 'Y' ? true : false,
                                  onChanged: (v) {
                                    setState(() {
                                      if (v == true) {
                                        setB_time[4]['closeGbn'] = 'Y';
                                      } else {
                                        setB_time[4]['closeGbn'] = 'N';
                                      }
                                    });
                                  }
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('금요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[5]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[5]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[5]['openTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게종료', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[5]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[5]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[5]['closeTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              ISCheckbox(
                                  label: '없음',
                                  value: setB_time[5]['closeGbn'] == 'Y' ? true : false,
                                  onChanged: (v) {
                                    setState(() {
                                      if (v == true) {
                                        setB_time[5]['closeGbn'] = 'Y';
                                      } else {
                                        setB_time[5]['closeGbn'] = 'N';
                                      }
                                    });
                                  }
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('토요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[6]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[6]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[6]['openTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게종료', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[6]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[6]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[6]['closeTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              ISCheckbox(
                                  label: '없음',
                                  value: setB_time[6]['closeGbn'] == 'Y' ? true : false,
                                  onChanged: (v) {
                                    setState(() {
                                      if (v == true) {
                                        setB_time[6]['closeGbn'] = 'Y';
                                      } else {
                                        setB_time[6]['closeGbn'] = 'N';
                                      }
                                    });
                                  }
                              ),
                            ],
                          ),
                          Divider(),
                          // 231115 월요일 기준 일괄적용 되는데 일요일이 가장 위에 있어서 아래쪽으로 이동
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('일요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[0]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[0]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[0]['openTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   휴게종료', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setB_time[0]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(4), FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                                          label: '시작 시간',
                                          onChange: (v) {
                                            if(int.parse(v.toString()) > 2359){
                                              setState(() {
                                                setB_time[0]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '휴게 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setB_time[0]['closeTime'] = v;
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              ISCheckbox(
                                  label: '없음',
                                  value: setB_time[0]['closeGbn'] == 'Y' ? true : false,
                                  onChanged: (v) {
                                    setState(() {
                                      if (v == true) {
                                        setB_time[0]['closeGbn'] = 'Y';
                                      } else {
                                        setB_time[0]['closeGbn'] = 'N';
                                      }
                                    });
                                  }
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () {ISConfirm(context, '브레이크타임 변경', '브레이크타임 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 250), (context, isOK) async {
                Navigator.of(context).pop();

                int _daySeq = 0;

                // 시간입력값 4자리 유효성 검사
                setB_time.forEach((v) {
                  if((v['openTime'].length != 4 || v['closeTime'].length != 4) && isOK == true) {
                    ISAlert(context, content: '${_dayGbn(_daySeq.toString())} 시간을 정확히 입력 바랍니다.');
                    isOK = false;
                  }
                  _daySeq++;
                });

                _daySeq = 0;
                // 시작시간, 종료시간 확인(종료시간이 빠를 수 없음)
                setB_time.forEach((v) {
                  if((int.parse(v['openTime']) > int.parse(v['closeTime'])) && isOK == true) {
                    ISAlert(context, content: '${_dayGbn(_daySeq.toString())} 시작 시간이 종료 시간 보다 늦습니다.');
                    isOK = false;
                  }
                  _daySeq++;
                });

                if (isOK){
                  List<dynamic> _sendSbTime = [];
                  ShopReserveSbTimeEditModel temp = ShopReserveSbTimeEditModel();

                  setB_time.forEach((element) {
                    temp.dayGbn = element['dayGbn'].toString();
                    temp.openTime = element['openTime'].toString();
                    temp.closeTime = element['closeTime'].toString();
                    temp.closeGbn = element['closeGbn'].toString();

                    _sendSbTime.add(temp.toJson());
                  });

                  var sendData = {
                    '"shopCode"': '"' + AuthService.SHOPCD + '"',
                    '"sbGbn"': '"B"',
                    '"sbTimeUnit"': _sendSbTime
                  };

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ReserveController.to.updateReserveShopSbTime(sendData.toString()))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(context).pop(true);
                      ISAlert(context, title: '알림', content: '변경이 완료되었습니다.');
                    }
                    else {
                      ISAlert(context, content: '정상 등록되지 않았습니다.\n[관리자에게 문의 바랍니다]\n→ ${value}');
                    }
                  }
                }
              });
              },
              child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }

  String _dayGbn(String gbn) {
    if(gbn == '0')        {      return '일요일';    }
    else if (gbn == '1')  {      return '월요일';    }
    else if (gbn == '2')  {      return '화요일';    }
    else if (gbn == '3')  {      return '수요일';    }
    else if (gbn == '4')  {      return '목요일';    }
    else if (gbn == '5')  {      return '금요일';    }
    else                  {      return '토요일';    }
  }
}

