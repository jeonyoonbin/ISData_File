import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/multi_masked_formatter.dart';
import 'package:daeguro_ceo_app/models/ShopManager/ShopBreakTimeHourListEditModel.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:provider/provider.dart';

class ShopOperateSTimeEdit extends StatefulWidget {
  final dynamic? s_time;
  const ShopOperateSTimeEdit({Key? key, this.s_time})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopOperateSTimeEditState();
  }
}

class ShopOperateSTimeEditState extends State<ShopOperateSTimeEdit> {
  final ScrollController _scrollController = ScrollController();
  dynamic? setS_time;
  List<dynamic> tempSetS_time = [];

  ShopBreakTimeHourListEditModel sendData = ShopBreakTimeHourListEditModel();

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    // s_time 데이터가 null 일경우 임시 데이터 적용
    if(widget.s_time.toString() == '[]') {
      for(int i = 0; i < 7; i++) {
        var addData = {
          'dayGbn': (i+1).toString(),
          'openTime': '0000',
          'closeTime': '0000',
          'useGbn': 'N',
          'nextDayYn': 'N',
        };
        tempSetS_time.add(addData);
      }
      setS_time = tempSetS_time;
    }else if(widget.s_time.length < 7){ // 데이터 7개 다 안들어와있을 경우
      List necessityVal = []; // 이미 들어와있는 값 체크용 배열
      var addData;

      for(int i = 0; i < widget.s_time.length; i++) {
          addData = {
            'dayGbn': widget.s_time[i]['tipDay'],
            'openTime': widget.s_time[i]['tipFrStand'],
            'closeTime': widget.s_time[i]['tipToStand'],
            'useGbn': 'Y',
            'nextDayYn': widget.s_time[i]['tipNextDay'],
          };

          necessityVal.add(widget.s_time[i]['tipDay']);

        tempSetS_time.add(addData);
      }

      for(int i = 1; i <= 7 ; i++ ){
        if(necessityVal.contains(i.toString())){
        }else{ // 안 들어와있는값에는 이거 집어넣어준다.
          addData = {
            'dayGbn': i.toString(),
            'openTime': '',
            'closeTime': '',
            'useGbn': 'N',
            'nextDayYn': 'N',
          };

          tempSetS_time.add(addData);
        }
      }

      setS_time = tempSetS_time;
      setS_time.sort((a,b) => int.parse(a['dayGbn']).compareTo(int.parse(b['dayGbn']))); // dayGbn 순서로 정렬

    }else { // 멀쩡할때
      for(int i = 0; i < 7; i++) {
        var addData = {
          'dayGbn': widget.s_time[i]['tipDay'],
          'openTime': widget.s_time[i]['tipFrStand'],
          'closeTime': widget.s_time[i]['tipToStand'],
          'useGbn': 'Y',
          'nextDayYn': widget.s_time[i]['tipNextDay'],
        };

        tempSetS_time.add(addData);
      }
      setS_time = tempSetS_time;
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 680),
        contentPadding: const EdgeInsets.symmetric(horizontal: 10),
        isFillActions: true,
        title: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('영업시간 설정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            SizedBox(width: 10),
            Text('*일괄 적용은 월요일 기준으로 적용됩니다.', style: const TextStyle(fontSize: 14, color: Colors.grey),),
          ],
        ),
        content: Material(
            color: Colors.transparent,
            borderOnForeground: false,
            child: SingleChildScrollView(
              controller: _scrollController,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 10),
                  ISLabelBarSub(
                    title: '영업시간',
                    trailing: Row(
                      children: [
                        ISButton(
                          child: const Text('초기화'),
                          onPressed: () {
                            setS_time.forEach((element) { // 월요일 기준이라서 index 0 아니고 1
                              element['openTime'] = '0900';
                              element['closeTime'] = '2359';
                              element['useGbn'] = 'N';
                            });

                            setState(() {});
                          },
                        ),
                        const SizedBox(width: 5,),
                        ISButton(
                          child: const Text('일괄 적용'),
                          onPressed: () {
                            setS_time.forEach((element) { // 월요일 기준이라서 index 0 아니고 1
                              element['openTime'] = setS_time[1]['openTime'];
                              element['closeTime'] = setS_time[1]['closeTime'];
                              element['useGbn'] = setS_time[1]['useGbn'];
                            });

                            setState(() {});
                          },
                        ),
                      ],
                    ),
                    body: Container(
                      alignment: Alignment.centerLeft,
                      width: double.infinity,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('월요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),

                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column( // 시작
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[1]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5),MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[1]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {

                                              setS_time[1]['openTime'] = value;

                                              if(int.parse(setS_time[1]['closeTime']) < int.parse(setS_time[1]['openTime'])){
                                                setS_time[1]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle1?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[1]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle1?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(width: 10),
                                  Column( // 종료
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Obx(() {
                                        return Text(Get.find<ShopController>().endTimeTitle1!.value, style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY));
                                      }),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[1]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[1]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[1]['closeTime'] = value;


                                              if(int.parse(setS_time[1]['closeTime']) < int.parse(setS_time[1]['openTime'])){
                                                 setS_time[1]['nextDayYn'] = 'Y';
                                                 Get.put(ShopController()).endTimeTitle1?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[1]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle1?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('24시간', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY) ),
                                  Switch(
                                      value: setS_time[1]['openTime'] == '0000' && setS_time[1]['closeTime'] == '2359' ? true : false,
                                      onChanged: (v){
                                        setState(() {
                                          if (v == true) {
                                            setS_time[1]['openTime'] = '0000';
                                            setS_time[1]['closeTime'] = '2359';
                                            setS_time[1]['nextDayYn'] = 'N';
                                            Get.put(ShopController()).endTimeTitle1?.value = ' 종료';
                                          } else {
                                            setS_time[1]['openTime'] = '';
                                            setS_time[1]['closeTime'] = '';
                                          }
                                        });
                                      }
                                  ),
                                ],
                              ),

                            ],
                          ),
                          Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('화요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[2]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[2]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[2]['openTime'] = value;

                                              if(int.parse(setS_time[2]['closeTime']) < int.parse(setS_time[2]['openTime'])){
                                                setS_time[2]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle2?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[2]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle2?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(width: 10),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Obx(() {
                                        return Text(Get.find<ShopController>().endTimeTitle2!.value, style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY));
                                      }),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[2]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[2]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[2]['closeTime'] = value;

                                              if(int.parse(setS_time[2]['closeTime']) < int.parse(setS_time[2]['openTime'])){
                                                setS_time[2]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle2?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[2]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle2?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('24시간', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY) ),
                                  Switch(
                                      value: setS_time[2]['openTime'] == '0000' && setS_time[2]['closeTime'] == '2359' ? true : false,
                                      onChanged: (v){
                                        setState(() {
                                          if (v == true) {
                                            setS_time[2]['openTime'] = '0000';
                                            setS_time[2]['closeTime'] = '2359';
                                            setS_time[2]['nextDayYn'] = 'N';
                                            Get.put(ShopController()).endTimeTitle2?.value = ' 종료';
                                          } else {
                                            setS_time[2]['openTime'] = '';
                                            setS_time[2]['closeTime'] = '';
                                          }
                                        });
                                      }
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('수요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[3]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[3]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[3]['openTime'] = value;

                                              if(int.parse(setS_time[3]['closeTime']) < int.parse(setS_time[3]['openTime'])){
                                                setS_time[3]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle3?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[3]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle3?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(width: 10),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Obx(() {
                                        return Text(Get.find<ShopController>().endTimeTitle3!.value, style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY));
                                      }),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[3]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[3]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[3]['closeTime'] = value;

                                              if(int.parse(setS_time[3]['closeTime']) < int.parse(setS_time[3]['openTime'])){
                                                setS_time[3]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle3?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[3]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle3?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('24시간', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY) ),
                                  Switch(
                                      value: setS_time[3]['openTime'] == '0000' && setS_time[3]['closeTime'] == '2359' ? true : false,
                                      onChanged: (v){
                                        setState(() {
                                          if (v == true) {
                                            setS_time[3]['openTime'] = '0000';
                                            setS_time[3]['closeTime'] = '2359';
                                            setS_time[3]['nextDayYn'] = 'N';
                                            Get.put(ShopController()).endTimeTitle3?.value = ' 종료';
                                          } else {
                                            setS_time[3]['openTime'] = '';
                                            setS_time[3]['closeTime'] = '';
                                          }
                                        });
                                      }
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('목요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[4]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[4]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[4]['openTime'] = value;

                                              if(int.parse(setS_time[4]['closeTime']) < int.parse(setS_time[4]['openTime'])){
                                                setS_time[4]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle4?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[4]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle4?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(width: 10),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Obx(() {
                                        return Text(Get.find<ShopController>().endTimeTitle4!.value, style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY));
                                      }),  const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[4]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[4]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[4]['closeTime'] = value;

                                              if(int.parse(setS_time[4]['closeTime']) < int.parse(setS_time[4]['openTime'])){
                                                setS_time[4]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle4?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[4]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle4?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('24시간', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY) ),
                                  Switch(
                                      value: setS_time[4]['openTime'] == '0000' && setS_time[4]['closeTime'] == '2359' ? true : false,
                                      onChanged: (v){
                                        setState(() {
                                          if (v == true) {
                                            setS_time[4]['openTime'] = '0000';
                                            setS_time[4]['closeTime'] = '2359';
                                            setS_time[4]['nextDayYn'] = 'N';
                                            Get.put(ShopController()).endTimeTitle4?.value = ' 종료';
                                          } else {
                                            setS_time[4]['openTime'] = '';
                                            setS_time[4]['closeTime'] = '';
                                          }
                                        });
                                      }
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('금요일', style: TextStyle(fontWeight: FONT_BOLD)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[5]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[5]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[5]['openTime'] = value;

                                              if(int.parse(setS_time[5]['closeTime']) < int.parse(setS_time[5]['openTime'])){
                                                setS_time[5]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle5?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[5]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle5?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(width: 10),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Obx(() {
                                        return Text(Get.find<ShopController>().endTimeTitle5!.value, style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY));
                                      }), const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[5]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');
                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[5]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[5]['closeTime'] = value;

                                              if(int.parse(setS_time[5]['closeTime']) < int.parse(setS_time[5]['openTime'])){
                                                setS_time[5]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle5?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[5]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle5?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('24시간', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY) ),
                                  Switch(
                                      value: setS_time[5]['openTime'] == '0000' && setS_time[5]['closeTime'] == '2359' ? true : false,
                                      onChanged: (v){
                                        setState(() {
                                          if (v == true) {
                                            setS_time[5]['openTime'] = '0000';
                                            setS_time[5]['closeTime'] = '2359';
                                            setS_time[5]['nextDayYn'] = 'N';
                                            Get.put(ShopController()).endTimeTitle5?.value = ' 종료';
                                          } else {
                                            setS_time[5]['openTime'] = '';
                                            setS_time[5]['closeTime'] = '';
                                          }
                                        });
                                      }
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('토요일', style: TextStyle(fontWeight: FONT_BOLD, color: Colors.blue)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[6]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[6]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[6]['openTime'] = value;

                                              if(int.parse(setS_time[6]['closeTime']) < int.parse(setS_time[6]['openTime'])){
                                                setS_time[6]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle6?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[6]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle6?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(width: 10),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Obx(() {
                                        return Text(Get.find<ShopController>().endTimeTitle6!.value, style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY));
                                      }),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[6]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[6]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[6]['closeTime'] = value;

                                              if(int.parse(setS_time[6]['closeTime']) < int.parse(setS_time[6]['openTime'])){
                                                setS_time[6]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle6?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[6]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle6?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('24시간', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY) ),
                                  Switch(
                                      value: setS_time[6]['openTime'] == '0000' && setS_time[6]['closeTime'] == '2359' ? true : false,
                                      onChanged: (v){
                                        setState(() {
                                          if (v == true) {
                                            setS_time[6]['openTime'] = '0000';
                                            setS_time[6]['closeTime'] = '2359';
                                            setS_time[6]['nextDayYn'] = 'N';
                                            Get.put(ShopController()).endTimeTitle6?.value = ' 종료';
                                          } else {
                                            setS_time[6]['openTime'] = '';
                                            setS_time[6]['closeTime'] = '';
                                          }
                                        });
                                      }
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Divider(),
                          // 231115 월요일 기준 일괄적용 되는데 일요일이 가장 위에 있어서 아래쪽으로 이동
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('일요일', style: TextStyle(fontWeight: FONT_BOLD, color: Colors.red)),
                              SizedBox(width: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('   시작', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[0]['openTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[0]['openTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 시작 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[0]['openTime'] = value;

                                              if(int.parse(setS_time[0]['closeTime']) < int.parse(setS_time[0]['openTime'])){
                                                setS_time[0]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle0?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[0]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle0?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(width: 10),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Obx(() {
                                        return Text(Get.find<ShopController>().endTimeTitle0!.value, style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY));
                                      }),
                                      const SizedBox(height: 4,),
                                      SizedBox(
                                        width: 65,
                                        child: ISInput(
                                          autofocus: true,
                                          value: Utils.getTimeFormat(setS_time[0]['closeTime'].toString()),
                                          height: 30,
                                          //padding: 0,
                                          context: context,
                                          keyboardType: TextInputType.number,
                                          inputFormatters: <TextInputFormatter>[LengthLimitingTextInputFormatter(5), MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')],
                                          label: '00:00',
                                          onChange: (v) {
                                            String value = v.toString().replaceAll(':', '');

                                            if(int.parse(value) > 2359){
                                              setState(() {
                                                setS_time[0]['closeTime'] = '2359';
                                              });

                                              ISAlert(context, content: '영업 종료 시간을 23:59 이상 입력 하실 수 없습니다.');

                                            } else {
                                              setS_time[0]['closeTime'] = value;

                                              if(int.parse(setS_time[0]['closeTime']) < int.parse(setS_time[0]['openTime'])){
                                                setS_time[0]['nextDayYn'] = 'Y';
                                                Get.put(ShopController()).endTimeTitle0?.value = '종료 [다음날]';
                                              }else{
                                                setS_time[0]['nextDayYn'] = 'N';
                                                Get.put(ShopController()).endTimeTitle0?.value = ' 종료';
                                              }
                                            }
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(width: 10),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('24시간', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY) ),
                                  Switch(
                                      value: setS_time[0]['openTime'] == '0000' && setS_time[0]['closeTime'] == '2359' ? true : false,
                                      onChanged: (v){
                                        setState(() {
                                          if (v == true) {
                                            setS_time[0]['openTime'] = '0000';
                                            setS_time[0]['closeTime'] = '2359';
                                            setS_time[0]['nextDayYn'] = 'N';
                                            Get.put(ShopController()).endTimeTitle0?.value = ' 종료';
                                          } else {
                                            setS_time[0]['openTime'] = '';
                                            setS_time[0]['closeTime'] = '';
                                          }
                                        });
                                      }
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,

              onPressed: () {
                BuildContext oldContext = context;

                ISConfirm(context, '영업시간 변경', '영업시간 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 250), (context, isOK) async {
                Navigator.of(context).pop();

                // int _daySeq = 0;
                //
                // 시간입력값 4자리 유효성 검사
                // setS_time.forEach((v) {
                //   if((v['openTime'].length != 4 || v['closeTime'].length != 4) && isOK == true && (v['openTime'] != '' || v['closeTime'] != '')) {
                //     ISAlert(context, content: '${_dayGbn(_daySeq.toString())} 시간을 정확히 입력 바랍니다.');
                //     isOK = false;
                //   }
                //   _daySeq++;
                // });
                //
                // _daySeq = 0;
                // // 시작시간, 종료시간 확인(종료시간이 빠를 수 없음)
                // setS_time.forEach((v) {
                //   if((int.parse(v['openTime']) > int.parse(v['closeTime'])) && isOK == true) {
                //     ISAlert(context, content: '${_dayGbn(_daySeq.toString())} 시작 시간이 종료 시간 보다 늦습니다.');
                //     isOK = false;
                //   }
                //   _daySeq++;
                // });

                if (isOK){
                  List<String> dayGbnArr = [];
                  List<String> openTimeArr = [];
                  List<String> closeTimeArr = [];
                  List<String> useGbnArr = [];
                  List<String> nextDayYnArr = [];

                  setS_time.forEach((element){
                    if(element['openTime'] != '' || element['closeTime'] != ''){
                      dayGbnArr.add(element['dayGbn']);
                      openTimeArr.add(element['openTime']);
                      closeTimeArr.add(element['closeTime']);
                      useGbnArr.add(element['useGbn']);
                      nextDayYnArr.add(element['nextDayYn']);
                    }
                  });

                  Map<String, dynamic> jsonData = {
                    "shopCd": AuthService.SHOPCD,
                    "sbGbn": 'S',
                    "dayGbn": dayGbnArr,
                    "openTime": openTimeArr,
                    "closeTime": closeTimeArr,
                    "useGbn": useGbnArr,
                    "nextDayYn": nextDayYnArr,
                    "uCode": AuthService.uCode,
                    "uName": AuthService.uName,
                  };

                  String jsonString = jsonEncode(jsonData);

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ShopController.to.setShopSbTime(jsonString))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(oldContext).pop(true);
                      ISAlert(oldContext, title: '알림', content: '변경이 완료되었습니다.');
                    }
                    else if(value == '01'){
                      Navigator.of(oldContext).pop(true);
                      ISAlert(oldContext, title: '알림', content: '변경이 완료되었습니다.\n→ ${value}');
                    }
                    else {
                      ISAlert(context, content: '정상 등록되지 않았습니다.\n→ ${value}');
                    }
                  }
                }
              });
              },
              child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }

//   String _dayGbn(String gbn) {
//     if(gbn == '0')        {      return '일요일';    }
//     else if (gbn == '1')  {      return '월요일';    }
//     else if (gbn == '2')  {      return '화요일';    }
//     else if (gbn == '3')  {      return '수요일';    }
//     else if (gbn == '4')  {      return '목요일';    }
//     else if (gbn == '5')  {      return '금요일';    }
//     else                  {      return '토요일';    }
//   }
}


