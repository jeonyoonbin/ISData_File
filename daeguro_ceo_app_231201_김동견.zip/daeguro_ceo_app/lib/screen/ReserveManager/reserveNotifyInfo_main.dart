import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_datatable.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/shopNewsListModel.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/shopNewsEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ReserveNotifyInfoMain extends StatefulWidget {
  const ReserveNotifyInfoMain({Key? key}) : super(key: key);

  @override
  State<ReserveNotifyInfoMain> createState() => _ReserveNotifyInfoMainState();
}

class _ReserveNotifyInfoMainState extends State<ReserveNotifyInfoMain> with PageMixin {
  int selectedPageNumber = 1;
  int totalPage = 0;
  int totalCnt = 0;

  String? jobGbn = '1';
  String? searchInfo = '';

  List<ShopNewsListModel> dataList = <ShopNewsListModel>[];

  requestAPIData() async {

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ReserveController.to.getShopNews(jobGbn!, searchInfo!, selectedPageNumber.toString()))
    );
    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
    }
    else {
      dataList.clear();

      value.forEach((element) {
        ShopNewsListModel temp = ShopNewsListModel();
        temp.rNum = element['rNum'].toString();
        temp.shopCd = element['shopCd'].toString();
        temp.seq = element['seq'].toString();
        temp.title = element['title'].toString();
        temp.contents = element['contents'].toString();
        temp.insertDate = element['insertDate'].toString();
        temp.useGbn = element['useGbn'].toString();
        temp.sortSeq = element['sortSeq'].toString();

        dataList.add(temp);

      });
      totalCnt = ReserveController.to.total_count;
      totalPage = ((totalCnt / 10).ceil());
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();


    Get.put(ReserveController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    dataList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    double contentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 398 : 370);

    return fluentUI.ScaffoldPage.withPadding(
      resizeToAvoidBottomInset: false,
      //scrollController: AppTheme.mainScrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: ScrollConfiguration(
        behavior: ScrollConfiguration.of(context).copyWith(scrollbars: Responsive.isMobile(context) ? false : true),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ISLabelBarMain(
                leading: const Text('매장 소식', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
                trailing: Text.rich(
                    style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                    textAlign: TextAlign.end,
                    TextSpan(children: [const TextSpan(text: '전체 '), TextSpan(text: Utils.getCashComma(totalCnt.toString()), style: const TextStyle(color: Colors.lightBlue)), const TextSpan(text: ' 건')])),
              ),
              const SizedBox(height: 8),
              Responsive.isMobile(context) == true ? Column(children: searchBarView()) : Row(children: searchBarView()),
              const SizedBox(height: 8),
              Material(child: Responsive.isMobile(context) ? mobileShopNewsView(context, contentHeight) : shopNewsTable(context, contentHeight)),
              Material(
                child: ISNumberPagination(
                    threshold: 5,
                    controlButton: const SizedBox(width: 10, height: 10),
                    onPageChanged: (int pageNumber) {
                      setState(() {
                        selectedPageNumber = pageNumber;
                      });
                      requestAPIData();
                    },
                    fontSize: 12,
                    pageTotal: totalPage,
                    pageInit: selectedPageNumber,
                    // picked number when init page
                    colorPrimary: Colors.black,
                    colorSub: Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget shopNewsTable(fluentUI.BuildContext context, double contentHeight) {
    return ISDatatable(
      listWidth: Responsive.getResponsiveWidth(context),
      listHeight: contentHeight > 350 ? contentHeight : 350,
      headingRowHeight: 40,
      dataRowHeight: 40,
      minWidth: 400,
      rows: dataList.map((item) {
        return DataRow(
            color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
              return Theme.of(context).colorScheme.primary.withOpacity(0.00);
            }),
            cells: [
              DataCell(SizedBox(width: 100, child: Align(alignment: Alignment.center, child: Text(item.rNum ?? '--', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))))),
              DataCell(SizedBox(width: Responsive.getResponsiveWidth(context) - 600, child: Align(alignment: Alignment.centerLeft, child: Text(item.title ?? '--', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))))),
              DataCell(SizedBox(width: 200, child: Align(alignment: Alignment.center, child: Text(Utils.getDateFormat(item.insertDate!) ?? '--', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))))),
              DataCell(SizedBox(width: 200, child: Align(alignment: Alignment.center, child:  Row(mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ISButton(
                    child: const Text('수정'),
                    onPressed: () {
                      showDialog(
                        context: context,
                        barrierDismissible: true,
                        builder: (context) => ShopNewsEdit(seq: item.seq!,),
                      ).then((v) async {
                        if (v == true) {
                          await Future.delayed(Duration(milliseconds: 500), () {
                            requestAPIData();
                          });
                        }
                      });
                    },
                  ),
                  const SizedBox(width: 6),
                  ISButton(
                    isReverseColor: true,
                    child: const Text('삭제'),
                    onPressed: () async {
                      ISConfirm(context, '매장 소식 삭제', '[${item.title}]을(를) 삭제하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                        Navigator.of(context).pop();
                        if (isOK){
                          ShopNewsListModel sendData = ShopNewsListModel();
                          sendData.shopCd = AuthService.SHOPCD;
                          sendData.seq = item.seq;
                          sendData.userId = AuthService.uName;
                          var value = await showDialog(
                              context: context,
                              barrierColor: Colors.transparent,
                              builder: (context) => FutureProgressDialog(ReserveController.to.delShopNews(sendData.toJson()))
                          );
                          if (value == null) {
                            ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                          }
                          else {
                            if (value == '00') {
                                requestAPIData();
                            }
                            else{
                              ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                            }
                          }
                        }
                      });
                    },
                  ),
                ],
              )))),
            ]);
      }).toList(),
      columns: <DataColumn>[
        const DataColumn(label: SizedBox(width: 100, child: Text('번호', textAlign: TextAlign.center)),),
        DataColumn(label: SizedBox(width: Responsive.getResponsiveWidth(context) - 600, child: const Text('제목', textAlign: TextAlign.left)),),
        const DataColumn(label: SizedBox(width: 200, child: Text('등록일', textAlign: TextAlign.center)), ),
        const DataColumn(label: SizedBox(width: 200, child: Text('관리', textAlign: TextAlign.center)), ),
      ],
    );
  }

  Widget mobileShopNewsView(fluentUI.BuildContext context, double contentHeight) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Divider(),
        ListView(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: List.generate(dataList.length, (index) {
            return Container(
              padding: const EdgeInsets.only(top: 10, bottom: 10),
              decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.black.withOpacity(0.1)))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        alignment: Alignment.center,
                        width: 30,
                        height: 24,
                        decoration: BoxDecoration(
                          color: Colors.lightBlueAccent,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.transparent),
                        ),
                        child: Text(
                          dataList[index].rNum!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white, fontWeight: FONT_BOLD, fontSize: 14, fontFamily: FONT_FAMILY),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              dataList[index].title!,
                              style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 15.0, fontFamily: FONT_FAMILY),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              Utils.getDateFormat(dataList[index].insertDate!),
                              style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 15.0, fontFamily: FONT_FAMILY),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ISButton(child: const Text('수정'), onPressed: () {
                            showDialog(
                              context: context,
                              barrierDismissible: true,
                              builder: (context) => ShopNewsEdit(seq: dataList[index].seq!,),
                            ).then((v) async {
                              if (v == true) {
                                await Future.delayed(Duration(milliseconds: 500), () {
                                  requestAPIData();
                                });
                              }
                            });
                          }),
                          const SizedBox(height: 6),
                          ISButton(isReverseColor: true, child: const Text('삭제'), onPressed: () {
                            ISConfirm(context, '매장 소식 삭제', '[${dataList[index].title}]을(를) 삭제하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                              Navigator.of(context).pop();
                              if (isOK){
                                ShopNewsListModel sendData = ShopNewsListModel();
                                sendData.shopCd = AuthService.SHOPCD;
                                sendData.seq = dataList[index].seq;
                                sendData.userId = AuthService.uName;
                                var value = await showDialog(
                                    context: context,
                                    barrierColor: Colors.transparent,
                                    builder: (context) => FutureProgressDialog(ReserveController.to.delShopNews(sendData.toJson()))
                                );
                                if (value == null) {
                                  ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                }
                                else {
                                  if (value == '00') {
                                    requestAPIData();
                                  }
                                  else{
                                    ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                  }
                                }
                              }
                            });
                          }),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            );
          }),
        ),
      ],
    );
  }

  List<Widget> searchBarView() {
    return [
      Material(
        child: ISSearchDropdown(
          label: '업체타입',
          width: Responsive.isMobile(context) == true ? double.infinity : 100,
          value: jobGbn,
          onChange: (value) {
            setState(() {
              jobGbn = value;
              //_query();
            });
          },
          item: [
            ISOptionModel(value: '1', label: '제목'),
            ISOptionModel(value: '2', label: '내용'),
          ].cast<ISOptionModel>(),
        ),
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8) : const SizedBox(width: 8),
      Material(
        child: ISInput(
          value: searchInfo,
          label: jobGbn == '1' ? '제목' : '내용',
          width: Responsive.isMobile(context) == true ? double.infinity : 240,
          prefixIcon: const Icon(Icons.search, color: Colors.black54,),
          suffixIcon: MaterialButton(
            color: Colors.lightBlueAccent,
            minWidth: 60,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
            onPressed: () async {
              selectedPageNumber = 1;
              requestAPIData();
            },
            child: const Text('조회', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
          ),
          onChange: (v) {
            setState(() {
            searchInfo = v;
            });
          },
        ),
      ),
      Responsive.isMobile(context) ? Container() : Expanded(child: Container()),
      Padding(
        padding: EdgeInsets.only(top: Responsive.isMobile(context) ? 8.0 : 0, right: Responsive.isMobile(context) ? 0 : 15),
        child: ISButton(
          width: Responsive.isMobile(context) ? double.infinity : 64,
          height: 48,
          child: const Text('소식 추가'),
          onPressed: () {
            showDialog(
              context: context,
              barrierDismissible: true,
              builder: (context) => ShopNewsEdit(),
            ).then((v) async {
              if (v == true) {
                await Future.delayed(Duration(milliseconds: 500), () {
                  requestAPIData();
                });
              }
            });
          },
        ),
      ),
    ];
  }
}