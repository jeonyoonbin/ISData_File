class ReserveDateStatusModel {
  ReserveDateStatusModel({
    this.reserDate,
    this.status10,
    this.status12,
    this.status30,
    this.status40,
    this.status90
  });

  String? reserDate;
  int? status10;
  int? status12;
  int? status30;
  int? status40;
  int? status90;
}
