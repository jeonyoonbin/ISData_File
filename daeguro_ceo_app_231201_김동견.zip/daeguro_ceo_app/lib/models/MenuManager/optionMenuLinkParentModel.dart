import 'package:daeguro_ceo_app/models/MenuManager/optionMenuLinkChildModel.dart';
import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionMenuLinkParentModel {
  OptionMenuLinkParentModel({
    required this.menuGroupName,
    required this.menu,
  });

  bool selected = false;
  String? menuGroupName;
  List<OptionMenuLinkChildModel>? menu;
}

