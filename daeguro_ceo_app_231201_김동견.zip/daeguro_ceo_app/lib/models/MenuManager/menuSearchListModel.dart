import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class MenuSearchListModel {
  MenuSearchListModel();

  bool selected = false;
  bool isFlag = false;

  String? menuCd;
  String? menuName;
  String? menuCost;
  String? useGbn;
  String? noFlag;
  String? optGrpNames;
  String? mainYn;
}