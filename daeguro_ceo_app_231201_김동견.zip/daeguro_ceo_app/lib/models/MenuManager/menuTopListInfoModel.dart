import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class MenuTopListInfoModel {
  MenuTopListInfoModel();

  bool selected = false;
  String? menuCd;
  String? menuName;
  String? mMainYn;
  String? fileName;
  //
  String? menuCost;
  String? useGbn;
  String? noFlag;
  // String? mainYn = 'Y';

  factory MenuTopListInfoModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

MenuTopListInfoModel _$ModelFromJson(Map<String, dynamic> json) {
  return MenuTopListInfoModel()
  // ..selected = json['selected'] as bool
    ..menuCd = json['menuCd'] as String
    ..menuName = json['menuName'] as String
    ..mMainYn = json['mMainYn'] as String
    ..fileName = json['fileName'] as String
    ..menuCost = json['menuCost'] as String
    ..useGbn = json['useGbn'] as String
    ..noFlag = json['noFlag'] as String;
}

Map<String, dynamic> _$ModelToJson(MenuTopListInfoModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'menuCd': instance.menuCd,
      'menuName': instance.menuName,
      'mMainYn': instance.mMainYn,
      'fileName': instance.fileName,
      'menuCost': instance.menuCost,
      'useGbn': instance.useGbn,
      'noFlag': instance.noFlag
    };
