import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class RequestShopInfoEditModel {

  RequestShopInfoEditModel();

  String? seq = '';
  String? shopCd = '';
  String? status = '';
  String? serviceGbn = '';
  String? filter = '';
  String? afterShopName = '';
  String? beforeShopName = '';
  String? afterMobile = '';
  String? beforeMobile = '';
  String? groupCd = '';
  String? menuCd = '';
  String? menuName = '';
  String? image_url = '';
  String? beforeImageUrl = '';
  String? a_reg_no = '';
  String? a_buss_owner = '';
  String? a_buss_con = '';
  String? a_buss_type = '';
  String? a_buss_addr = '';
  String? a_buss_tax_type = '';
  String? a_owner = '';
  String? b_reg_no = '';
  String? b_buss_owner = '';
  String? b_buss_con = '';
  String? b_buss_type = '';
  String? b_buss_addr = '';
  String? b_buss_tax_type = '';
  String? b_owner = '';
  String? reason = '';
  String? first = '';
  String? second = '';
  String? third = '';
  String? prodCd = '';
  String? prodName = '';
  String? uCode = '';
  String? uName = '';

  String? b_shop_name = '';
  String? b_telno = '';
  String? a_shop_name = '';
  String? a_telno = '';
  String? applicant = '';
  String? date_consent = '';
  String? consent_yn = '';


  // factory RequestShopInfoEditModel.fromJson(Map<String, dynamic> json) =>
  //     _$ModelFromJson(json);
  //
  // Map<String, dynamic> toJson() => _$ModelToJson(this);
}

// RequestShopInfoEditModel _$ModelFromJson(Map<String, dynamic> json) {
//   return RequestShopInfoEditModel()
//     ..seq = json['seq']
//     ..shopCd = json['shopCd']
//     ..status = json['status']
//     ..serviceGbn = json['serviceGbn']
//     ..filter = json['filter']
//     ..afterShopName = json['afterShopName']
//     ..beforeShopName = json['beforeShopName']
//     ..afterMobile = json['afterMobile']
//     ..beforeMobile = json['beforeMobile']
//     ..groupCd = json['groupCd']
//     ..menuCd = json['menuCd']
//     ..menuName = json['menuName']
//     ..beforeImageUrl = json['beforeImageUrl']
//     ..uCode = json['uCode']
//     ..uName = json['uName']
//     ..formFiles = json['formFiles'].cast<String>();
// }
//
// Map<String, dynamic> _$ModelToJson(RequestShopInfoEditModel instance) =>
//     <String, dynamic>{
//       // 'selected': instance.selected,
//       'seq': instance.seq,
//       'shopCd': instance.shopCd,
//       'status': instance.status,
//       'serviceGbn': instance.serviceGbn,
//       'filter': instance.filter,
//       'afterShopName': instance.afterShopName,
//       'beforeShopName': instance.beforeShopName,
//       'afterMobile': instance.afterMobile,
//       'beforeMobile': instance.beforeMobile,
//       'groupCd': instance.groupCd,
//       'menuCd': instance.menuCd,
//       'menuName': instance.menuName,
//       'beforeImageUrl': instance.beforeImageUrl,
//       'uCode': instance.uCode,
//       'uName': instance.uName,
//       'formFiles': instance.formFiles
//     };
