import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOriginLocalEditModel {
  ProductOriginLocalEditModel();

  bool selected = false;
  String? seq;
  String? jobGbn;
  String? shopCd;
  String? title;
  String? contents;
  String? useGbn;
  String? uCode;
  String? uName;


  factory ProductOriginLocalEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ProductOriginLocalEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ProductOriginLocalEditModel()
  // ..selected = json['selected'] as bool
    ..seq = json['seq']
    ..jobGbn = json['jobGbn']
    ..shopCd = json['shopCd']
    ..title = json['title']
    ..contents = json['contents']
    ..useGbn = json['useGbn']
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(ProductOriginLocalEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'seq': instance.seq,
      'jobGbn': instance.jobGbn,
      'shopCd': instance.shopCd,
      'title': instance.title,
      'contents': instance.contents,
      'useGbn': instance.useGbn,
      'uCode': instance.uCode,
      'uName': instance.uName
    };
