import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOptionEditModel {
  ProductOptionEditModel();

  String? shopCd;
  String? optGrpCd;
  String? optionCd;
  String? optName;
  String? optCost;
  String? optUseGbn;
  String? optNoFlag;
  String? optionMemo;
  String? uCode;
  String? uName;

  factory ProductOptionEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ProductOptionEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ProductOptionEditModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd']
    ..optGrpCd = json['optGrpCd']
    ..optionCd = json['optionCd']
    ..optName = json['optName']
    ..optCost = json['optCost']
    ..optUseGbn = json['optUseGbn']
    ..optNoFlag = json['optNoFlag']
    ..optionMemo = json['optionMemo']
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(ProductOptionEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'optGrpCd': instance.optGrpCd,
      'optionCd': instance.optionCd,
      'optName': instance.optName,
      'optCost': instance.optCost,
      'optUseGbn': instance.optUseGbn,
      'optNoFlag': instance.optNoFlag,
      'optionMemo': instance.optionMemo,
      'uCode': instance.uCode,
      'uName': instance.uName
    };
