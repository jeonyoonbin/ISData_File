import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CouponDetailModel {
  CouponDetailModel();

  String? itemCd;
  String? couponType;
  String? couponAmt;
  String? applyMinAmt;
}


