import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class NoticeListRequestModel {
  NoticeListRequestModel();

  bool? selected = false;
  String? jobGbn;
  String? osGbn;
  String? noticeGbn;
  String? dispGbn;
  String? frDate;
  String? toDate;
  String? rows;
  String? page;

  factory NoticeListRequestModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

NoticeListRequestModel _$ModelFromJson(Map<String, dynamic> json) {
  return NoticeListRequestModel()
    ..selected = json['selected'] as bool
    ..jobGbn = json['jobGbn'] as String
    ..osGbn = json['osGbn'] as String
    ..noticeGbn = json['noticeGbn'] as String
    ..dispGbn = json['dispGbn'] as String
    ..frDate = json['frDate'] as String
    ..toDate = json['toDate'] as String
    ..rows = json['rows'] as String
    ..page = json['page'] as String;

}

Map<String, dynamic> _$ModelToJson(NoticeListRequestModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'jobGbn': instance.jobGbn,
  'osGbn': instance.osGbn,
  'noticeGbn': instance.noticeGbn,
  'dispGbn': instance.dispGbn,
  'frDate': instance.frDate,
  'toDate': instance.toDate,
  'rows': instance.rows,
  'page': instance.page
};