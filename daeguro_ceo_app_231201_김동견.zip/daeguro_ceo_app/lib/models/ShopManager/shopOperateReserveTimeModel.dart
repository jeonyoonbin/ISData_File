import 'package:daeguro_ceo_app/models/ShopManager/shopOperateReserveTimeModel.dart';
import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopOperateReserveTimeModel {
  ShopOperateReserveTimeModel();

  bool? selected = false;
  String? time = '';
  String? gbn = '';

  factory ShopOperateReserveTimeModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopOperateReserveTimeModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopOperateReserveTimeModel()
    ..time = json['time'] as String
    ..gbn = json['gbn'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopOperateReserveTimeModel instance) => <String, dynamic>{
  'time': instance.time,
  'dayGbn': instance.gbn
};
