import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopOperateHourListModel {
  ShopOperateHourListModel();

  bool? selected = false;
  String? jobGbn = 'I'; //I: 추가, U: 수정
  
  String? tipSeq = '';
  String? tipDay = '';
  String? tipFrStand = '';
  String? tipToStand = '';
  String? tipNextDay = '';
}