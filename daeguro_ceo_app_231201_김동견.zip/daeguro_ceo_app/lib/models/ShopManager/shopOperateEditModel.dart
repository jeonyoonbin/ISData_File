import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopOperateEditModel {
  ShopOperateEditModel();

  bool? selected = false;
  String? jobGbn = '';
  String? shopCd = '';
  String? absentYn = '';
  String? originMark = '';
  String? reviewUseGbn = '';
  String? day = '';
  String? frTime = '';
  String? toTime = '';
  String? nextDay = '';
  String? exchangeNotice = '';
  String? returnNotice = '';
  String? rejectNotice = '';
  String? reserveTerm = '';
  String? minAmtPass = '';
  String? lAuth = '';
  String? lTel = '';
  String? lSeller = '';
  String? modUcode = '';
  String? modName = '';

  factory ShopOperateEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopOperateEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopOperateEditModel()
    ..jobGbn = json['jobGbn'] as String
    ..shopCd = json['shopCd'] as String
    ..absentYn = json['absentYn'] as String
    ..originMark = json['originMark'] as String
    ..reviewUseGbn = json['reviewUseGbn'] as String
    ..day = json['day'] as String
    ..frTime = json['frTime'] as String
    ..toTime = json['toTime'] as String
    ..nextDay = json['nextDay'] as String
    ..exchangeNotice = json['exchangeNotice'] as String
    ..returnNotice = json['returnNotice'] as String
    ..rejectNotice = json['rejectNotice'] as String
    ..reserveTerm = json['reserveTerm'] as String
    ..minAmtPass = json['minAmtPass'] as String
    ..lAuth = json['lAuth'] as String
    ..lTel = json['lTel'] as String
    ..lSeller = json['lSeller'] as String
    ..modUcode = json['modUcode'] as String
    ..modName = json['modName'] as String;

}

Map<String, dynamic> _$ModelToJson(ShopOperateEditModel instance) => <String, dynamic>{
  'jobGbn': instance.jobGbn,
  'shopCd': instance.shopCd,
  'absentYn': instance.absentYn,
  'originMark': instance.originMark,
  'reviewUseGbn': instance.reviewUseGbn,
  'day': instance.day,
  'frTime': instance.frTime,
  'toTime': instance.toTime,
  'nextDay': instance.nextDay,
  'exchangeNotice': instance.exchangeNotice,
  'returnNotice': instance.returnNotice,
  'rejectNotice': instance.rejectNotice,
  'reserveTerm': instance.reserveTerm,
  'minAmtPass': instance.minAmtPass,
  'lAuth': instance.lAuth,
  'lTel': instance.lTel,
  'lSeller': instance.lSeller,
  'modUcode': instance.modUcode,
  'modName': instance.modName
};