import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopBreakTimeHourListEditModel {
  ShopBreakTimeHourListEditModel();

  bool? selected = false;
  String? jobGbn = 'I'; //I: 추가, U: 수정

  String? shopCd = '';
  String? sbGbn = '';
  List<String>? dayGbn ;
  List<String>? openTime;
  List<String>? closeTime;
  List<String>? useGbn;
  List<String>? nextDayYn;
  String? uCode = '';
  String? uName = '';

  factory ShopBreakTimeHourListEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopBreakTimeHourListEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopBreakTimeHourListEditModel()
    ..shopCd = json['shopCd']
    ..sbGbn = json['sbGbn']
    ..dayGbn = json['dayGbn'].cast<String>()
    ..openTime = json['openTime'].cast<String>()
    ..closeTime = json['closeTime'].cast<String>()
    ..useGbn = json['closeGbn'].cast<String>()
    ..nextDayYn = json['nextDayYn'].cast<String>()
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(ShopBreakTimeHourListEditModel instance) => <String, dynamic>{
  'shopCd': '${instance.shopCd}',
  'sbGbn': '${instance.sbGbn}',
  'dayGbn': '${instance.dayGbn}',
  'openTime': '${instance.openTime}',
  'closeTime': '${instance.closeTime}',
  'useGbn': '${instance.useGbn}',
  'nextDayYn': '${instance.nextDayYn}',
  'uCode': '${instance.uCode}',
  'uName': '${instance.uName}',
};