import 'package:daeguro_ceo_app/models/ShopManager/shopOperateReserveTimeModel.dart';
import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopOperateSetReserveTimeModel {
  ShopOperateSetReserveTimeModel();

  bool? selected = false;
  String? shopCode = '';
  String? userId = '';
  List<ShopOperateReserveTimeModel> reserTimePostUnits = <ShopOperateReserveTimeModel>[];

  factory ShopOperateSetReserveTimeModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopOperateSetReserveTimeModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopOperateSetReserveTimeModel()
    ..shopCode = json['shopCode'] as String
    ..userId = json['userId'] as String
    ..reserTimePostUnits = json['reserTimePostUnits'];
}

Map<String, dynamic> _$ModelToJson(ShopOperateSetReserveTimeModel instance) => <String, dynamic>{
  'shopCode': instance.shopCode,
  'userId': instance.userId,
  'reserTimePostUnits': instance.reserTimePostUnits
};
