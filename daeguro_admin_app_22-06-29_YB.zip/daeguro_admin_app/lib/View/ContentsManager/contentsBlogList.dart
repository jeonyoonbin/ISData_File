import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsListModel.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsBlogEdit.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsBlogRegist.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsNotifierData.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsWebtoonEdit.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsWebtoonRegist.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsWebtoonSub.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsWebtoonUpdateSort.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contents_controller.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/NoticeManager/Reser/reserNoticeUpdateSort.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_input.dart';
import 'package:daeguro_admin_app/Model/search_items.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:async';

class ContentsBlogList extends StatefulWidget {
  const ContentsBlogList({key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ContentsBlogListState();
  }
}

class ContentsBlogListState extends State<ContentsBlogList> with SingleTickerProviderStateMixin {
  get secureStorage => null;

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  bool excelEnable = true;

  TabController _nestedTabController;

  StreamController<ContentsNotifierData> streamControllerContents = StreamController<ContentsNotifierData>();

  List<ContentsListModel> dataList = <ContentsListModel>[];

  List MCodeListitems = List();

  SearchItems _searchItems = new SearchItems();

  bool isCheckAll = false;

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  String _selectedViewSeq = '';
  String _selectedTitle = '';

  String _dispCbo = '%';

  int _currentPage = 1;
  int _totalPages = 0;

  ContentsNotifierData mDetailData = ContentsNotifierData();

  final ScrollController _scrollController = ScrollController();

  void _pageMove(int _page) {
    _query();
  }

  _regist() async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: ContentsBlogRegist(),
      ),
    ).then((v) async {
      if (v == true) {
        await Future.delayed(Duration(milliseconds: 500), () {
          loadData();
        });
      }
    });
  }

  _updateSort() async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: ContentsWebtoonUpdateSort(cartegory_gbn:'R'),
      ),
    ).then((v) async {
      await Future.delayed(Duration(milliseconds: 500), () {
        loadData();
        setState(() {});
      });
    });
  }

  _reset() {
    dataList.clear();

    _searchItems = null;
    _searchItems = new SearchItems();
  }

  _query() {
    _selectedTitle = '';
    setDetailViewData('');
    loadData();
  }

  loadData() async {
    await ISProgressDialog(context).show(status: 'Loading...');

    dataList.clear();

    await ContentsController.to.getContentsData('R', _dispCbo, _searchItems.name, _currentPage.toString(), _selectedpagerows.toString()).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((e) {
          ContentsListModel temp = ContentsListModel.fromJson(e);
          dataList.add(temp);
        });
        _totalRowCnt = ContentsController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
      }
    });

    await ISProgressDialog(context).dismiss();

    setState(() {});
  }

  void setDetailViewData(String contents_cd) {
    mDetailData = null;
    mDetailData = ContentsNotifierData();
    mDetailData.contents_cd = contents_cd;

    callStreamBroadcast();
  }

  void setDetailViewNullData() {
    mDetailData = null;

    streamControllerContents.add(null);
    setState(() {});
  }

  void callStreamBroadcast() {
    if (_nestedTabController.index == 0) {
      streamControllerContents.add(mDetailData);
    }
  }

  void detailCallback() {
    _query();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ContentsController());

    _nestedTabController = new TabController(length: 1, vsync: this);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      _query();
    });
  }

  @override
  void dispose() {
    dataList.clear();
    //MCodeListitems.clear();

    _nestedTabController.dispose();
    _scrollController.dispose();

    streamControllerContents.close();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //testSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.end, children: <Widget>[
        Row(
          children: [
            Text(
              '총: ${Utils.getCashComma(ContentsController.to.totalRowCnt.toString())}건',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        Row(
          children: [
            Column(
              children: [
                Row(
                  children: [
                    ISSearchDropdown(
                      label: '게시유무',
                      width: 100,
                      value: _dispCbo,
                      onChange: (value) {
                        _dispCbo = value;
                        setState(() {});
                      },
                      item: [
                        DropdownMenuItem(
                          value: '%',
                          child: Text('전체'),
                        ),
                        DropdownMenuItem(
                          value: 'Y',
                          child: Text('게시'),
                        ),
                        DropdownMenuItem(
                          value: 'N',
                          child: Text('미 게시'),
                        ),
                      ].cast<DropdownMenuItem<String>>(),
                    ),
                    Container(
                      child: Stack(
                        alignment: Alignment.centerRight,
                        children: [
                          ISSearchInput(
                            width: 250,
                            label: '제목',
                            value: _searchItems.name,
                            onChange: (v) {
                              _searchItems.name = v;
                            },
                            onFieldSubmitted: (v) {
                              _currentPage = 1;
                              _query();
                            },
                          ),
                        ],
                      ),
                    ),
                    if (AuthUtil.isAuthReadEnabled('237') == true)
                    ISSearchButton(
                        label: '조회',
                        iconData: Icons.search,
                        onPressed: () => {
                              _currentPage = 1,
                              //_query(),
                              _query()
                            }),
                    SizedBox(width: 8),
                    if (AuthUtil.isAuthCreateEnabled('237') == true)
                    ISSearchButton(label: '등록', iconData: Icons.add, onPressed: () => {_regist()}),
                    SizedBox(width: 8),
                    ISSearchButton(width: 130, label: '노출 순서', iconData: Icons.autorenew, onPressed: () => _updateSort()),
                  ],
                ),
              ],
            ),
          ],
        ),
      ]),
    );

    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          form,
          buttonBar,
          Divider(),
          ISDatatable(
            panelHeight: (MediaQuery.of(context).size.height - defaultContentsHeight),
            listWidth: Responsive.getResponsiveWidth(context, 720),
            //showCheckboxColumn: (widget.shopName == null) ? true : false,
            rows: dataList.map((item) {
              return DataRow(
                  selected: item.viewSelected ?? false,
                  color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
                    if (item.viewSelected == true) {
                      return Colors.grey.shade200;
                      //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
                    }

                    return Theme.of(context).colorScheme.primary.withOpacity(0.00);
                  }),
                  onSelectChanged: (bool value) async {
                    //_nestedTabController.index = 0;

                    setDetailViewData(item.CONTENTS_CD.toString());

                    dataList.forEach((element) {
                      element.viewSelected = false;
                    });

                    item.viewSelected = true;
                    _selectedViewSeq = item.CONTENTS_CD.toString();
                    _selectedTitle = item.CONTENTS_TITLE;

                    await Future.delayed(Duration(milliseconds: 600), () {});

                    _scrollController.jumpTo(0.0);

                    setState(() {});
                  },
                  cells: [
                    DataCell(Align(
                      child: SelectableText(item.CONTENTS_CD.toString(), showCursor: true),
                      alignment: Alignment.center,
                    )),
                    DataCell(Container(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Align(
                            child: Text(
                              item.CONTENTS_TITLE.toString() ?? '--',
                              style: TextStyle(color: Colors.black),
                            ),
                            alignment: Alignment.centerLeft))),
                    DataCell(Center(
                        child: item.DISP_GBN.toString() == 'Y'
                            ? Icon(Icons.radio_button_unchecked, color: Colors.blue, size: 16)
                            : Icon(Icons.clear, color: Colors.red, size: 16))),
                    DataCell(Container(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Align(
                            child: Text(
                              item.DISP_SEQ.toString() ?? '--',
                              style: TextStyle(color: Colors.black),
                            ),
                            alignment: Alignment.center))),
                    DataCell(Container(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Align(
                            child: Text(
                              item.INS_DATE.replaceAll('T', ' ') ?? '--',
                              style: TextStyle(color: Colors.black),
                            ),
                            alignment: Alignment.center))),
                    DataCell(
                      Center(
                        child: InkWell(
                          child: Icon(Icons.edit, size: 20),
                          onTap: () {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) => Dialog(
                                child: ContentsBlogEdit(contents_cd: item.CONTENTS_CD.toString()),
                              ),
                            ).then((v) async {
                              if (v != null) {
                                await Future.delayed(Duration(milliseconds: 500), () {
                                  loadData();
                                });
                              }
                            });
                          },
                        ),
                      ),
                    ),
                  ]);
            }).toList(),
            columns: <DataColumn>[
             DataColumn(
                  label: Expanded(child: Text('순번', textAlign: TextAlign.center)),
                ),
              DataColumn(
                label: Expanded(child: SelectableText('제목', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('게시유무', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('메인노출\n순서', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('등록일', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('관리', textAlign: TextAlign.center)),
              )
            ],
          ),
          Divider(),
          showPagerBar(),
        ],
      ),
    );
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                //Text('row1'),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(),
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context)
                ? Container(height: 48)
                : Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      //Text('조회 데이터 : ', style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),),
                      //Text(UserController.to.totalRowCnt.toString() + ' / ' + UserController.to.total_count.toString(), style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                      //SizedBox(width: 20,),
                      Text(
                        '페이지당 행 수',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),
                      ),
                      Container(
                        width: 70,
                        child: DropdownButton(
                            value: _selectedpagerows,
                            isExpanded: true,
                            style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: 'NotoSansKR'),
                            items: Utils.getPageRowList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedpagerows = value;
                                _currentPage = 1;
                                _query();
                              });
                            }),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  double getListMainPanelWidth() {
    double nWidth = MediaQuery.of(context).size.width - 1000;
    if (Responsive.isTablet(context) == true)
      nWidth = nWidth + sidebarWidth;
    else if (Responsive.isMobile(context) == true) nWidth = MediaQuery.of(context).size.width;

    return nWidth;
  }
}
