import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiFAQRegistModel {
  TaxiFAQRegistModel();

  bool selected = false;
  String idUsrIns;
  String nmUsrIns;
  String divSubBoard;
  String ynOpen;
  String subject;
  String contText;

  factory TaxiFAQRegistModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiFAQRegistModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiFAQRegistModel()

    ..selected = json['selected'] as bool
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..divSubBoard = json['divSubBoard'] as String
    ..ynOpen = json['ynOpen'] as String
    ..subject = json['subject'] as String
    ..contText = json['contText'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiFAQRegistModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'idUsrIns': instance.idUsrIns,
  'nmUsrIns': instance.nmUsrIns,
  'divSubBoard': instance.divSubBoard,
  'ynOpen': instance.ynOpen,
  'subject': instance.subject,
  'contText': instance.contText
};