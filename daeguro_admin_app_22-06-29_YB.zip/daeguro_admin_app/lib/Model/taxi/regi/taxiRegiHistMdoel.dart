import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiRegiHistModel {
  TaxiRegiHistModel();

  bool selected = false;
  String noBusi;
  String dtmIns;
  String idUsrIns;
  String nmUsrIns;
  String statusCol;
  String colComments;
  String statusDesc;

  factory TaxiRegiHistModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiRegiHistModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiRegiHistModel()
    ..selected = json['selected'] as bool
    ..noBusi = json['noBusi'] as String
    ..dtmIns = json['dtmIns'] as String
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..statusCol = json['statusCol'] as String
    ..colComments = json['colComments'] as String
    ..statusDesc = json['statusDesc'] as String;

}

Map<String, dynamic> _$ModelToJson(TaxiRegiHistModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'noBusi': instance.noBusi,
  'dtmIns': instance.dtmIns,
  'idUsrIns': instance.idUsrIns,
  'nmUsrIns': instance.nmUsrIns,
  'statusCol': instance.statusCol,
  'colComments': instance.colComments,
  'statusDesc': instance.statusDesc,
};