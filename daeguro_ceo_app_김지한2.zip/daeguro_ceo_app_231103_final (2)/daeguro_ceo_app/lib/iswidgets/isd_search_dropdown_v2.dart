﻿import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';

class ISSearchDropdownV2 extends StatelessWidget {
  final double? width;
  final String? label;
  final String? value;
  final ValueChanged? onChange;
  final EdgeInsets? padding;
  final List<DropdownMenuItem<String>>? item;
  final bool ignoring = false;

  const ISSearchDropdownV2(
      {Key? key,
      this.width,
      this.label,
      this.value,
      this.onChange,
      this.padding,
      this.item,
      ignoring})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return (value == '' || value == null)
        ? SizedBox(
            width: width,
            child: IgnorePointer(
              ignoring: ignoring!,
              child: DropdownButtonHideUnderline(
                child: DropdownButtonFormField2(
                  value: value,
                  items: item,
                  style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: ignoring == false ? Colors.black54 : Colors.black38, overflow: TextOverflow.ellipsis),
                  decoration: const InputDecoration(
                      isDense: true,
                      fillColor: Colors.transparent,
                      filled: false,
                      // hintText: '    ${label!}',
                      hintStyle: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, color: Colors.black54),
                      contentPadding: EdgeInsets.zero,
                      enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.transparent, width: 0))
                  ),
                  isExpanded: true,
                  buttonStyleData: ButtonStyleData(
                      width: width,
                      height: 48,
                      overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
                      padding: const EdgeInsets.symmetric(horizontal: 8.0,)
                  ),
                  dropdownStyleData: DropdownStyleData(
                    width: width,
                    padding: EdgeInsets.zero,
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4.0),),
                  ),
                  menuItemStyleData: const MenuItemStyleData(
                    height: 36,
                    padding: EdgeInsets.symmetric(horizontal: 16),
                  ),
                ),
              ),
            ),
          )
        : SizedBox(
            width: width,
            child: IgnorePointer(
              ignoring: ignoring!,
              child: DropdownButtonHideUnderline(
                child: DropdownButtonFormField2(
                  value: value,
                  items: item,
                  alignment: AlignmentDirectional.centerEnd,
                  style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: ignoring == false ? Colors.black54 : Colors.black38, overflow: TextOverflow.ellipsis),
                  decoration: const InputDecoration(
                    isDense: true,
                    fillColor: Colors.transparent,
                    filled: false,
                    // hintText: '    ${label!}',
                    hintStyle: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, color: Colors.black54),
                    contentPadding: EdgeInsets.zero,
                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.transparent, width: 0)),
                  ),
                  isExpanded: true,
                  buttonStyleData: ButtonStyleData(
                      width: width,
                      height: 48,
                      overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
                      padding: const EdgeInsets.symmetric(horizontal: 8.0,)
                  ),
                  iconStyleData: IconStyleData(icon: Icon(Icons.arrow_drop_down, color: ignoring == false ? Colors.black54 : Colors.black38), iconSize: 24,),
                  dropdownStyleData: DropdownStyleData(
                    width: width,
                    maxHeight: 180,
                    openInterval: const Interval(0.0, 0.0),
                    padding: EdgeInsets.zero,
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4.0),),
                    scrollbarTheme: ScrollbarThemeData(
                        thickness: MaterialStateProperty.all(6.0),
                        //thumbColor: MaterialStateProperty.all(const Color(0xFFc1c1c1)),
                        thumbVisibility: MaterialStateProperty.all((item!.length > 5) ? true : false)
                    ),
                  ),
                  menuItemStyleData: const MenuItemStyleData(
                    height: 36,
                    padding: EdgeInsets.symmetric(horizontal: 16),
                  ),
                  onChanged: (value) {
                    if (onChange != null) {
                      onChange!(value);
                    }
                  },
                ),
              ),
            ),
          );
    }
}
