
import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:flutter/material.dart';

class ISLabelBarSub extends StatelessWidget {
  final String? title;
  final double? height;
  final Widget? body;
  final TextStyle? titleStyle;
  final Color? backgroundColor;
  final EdgeInsetsGeometry? titlePadding;
  final EdgeInsetsGeometry? bodyPadding;
  final Widget? trailing;
  final bool? underLine;
  final Widget? prefixIcon;

  const ISLabelBarSub({
    Key? key,
    this.title,
    this.height,
    this.body,
    this.titleStyle,
    this.backgroundColor,
    this.titlePadding = const EdgeInsets.symmetric(horizontal: 20),
    this.bodyPadding = const EdgeInsets.all(15),
    this.trailing,
    this.underLine = true,
    this.prefixIcon
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          alignment: Alignment.centerLeft,
          padding: titlePadding,
          height: height ?? 40,
          width: double.infinity,
          decoration: underLine == true ? BoxDecoration(
            color: backgroundColor ?? Colors.grey.shade200,//Color(0x1F000000),//
            border: Border(top: BorderSide(color: backgroundColor ?? Colors.grey.shade200)),
          ) : null,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  prefixIcon ?? const SizedBox.shrink(),
                  prefixIcon == null ? const SizedBox.shrink() : const SizedBox(width: 4,),
                  Text(title!, style: titleStyle ?? const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                ],
              ),
              trailing == null ? const SizedBox.shrink() : trailing!,
            ],
          ),
        ),
        if (body != null)
          Padding(
            padding: bodyPadding!,
            child: body!,
          ),

      ],
    );
  }}