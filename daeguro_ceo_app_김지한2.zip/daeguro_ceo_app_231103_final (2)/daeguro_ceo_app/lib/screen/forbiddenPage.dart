
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart';
import 'package:flutter/material.dart' as material;

class ForbiddenPage extends StatefulWidget {
  const ForbiddenPage({Key? key}) : super(key: key);

  @override
  State<ForbiddenPage> createState() => _ForbiddenPageState();
}

class _ForbiddenPageState extends State<ForbiddenPage> with PageMixin {

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(debugCheckHasFluentTheme(context));

    return ScaffoldPage.scrollable(
      header: const LayoutHeader(titleName: '사장님 사이트 현황'),
      bottomBar: const LayoutBottom(),
      children: [
      ],
    );
  }
}