import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_datatable.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveListModel.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/instance_manager.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class ReserveInfoDashboardMain extends StatefulWidget {
  const ReserveInfoDashboardMain({Key? key}) : super(key: key);

  @override
  State<ReserveInfoDashboardMain> createState() => _ReserveInfoDashboardMainState();
}

class _ReserveInfoDashboardMainState extends State<ReserveInfoDashboardMain> with PageMixin {
  String? startdate = '';
  String? enddate = '';
  String? selectedType = '1000';
  String? status = '';
  int selectedPageNumber = 1;
  int totalPage = 0;
  int itemsPerPage = 10;
  String? div = '%';
  String? searchText = '';
  int totalCount = 0;
  int status10 = 0;
  int status12 = 0;
  int status30 = 0;
  int status40 = 0;
  int status90 = 0;
  bool pickDate = false;

  List<ReserveListModel> dataList = <ReserveListModel>[];
  List<ReserveListModel> paginatedDataList = [];
  List<String> searchStatusOptions = [
    '전체',
    '예약 대기',
    '방문 예정',
    '방문 완료',
    '미방문',
    '취소',
  ];
  List<String> searchStatus = ['0', '0', '0', '0', '0', '0'];
  String? selectedOption = '전체';

  paginateDataList() {
    int startIndex = (selectedPageNumber - 1) * itemsPerPage;
    int endIndex = startIndex + itemsPerPage;

    if (startIndex < dataList.length) {
      if (endIndex > dataList.length) {
        endIndex = dataList.length;
      }
      paginatedDataList = dataList.sublist(startIndex, endIndex);
    } else {
      paginatedDataList = [];
    }
  }

  requestAPIData() async {
    var value = await showDialog(context: context, builder: (context) => FutureProgressDialog(ReserveController.to.getReserveList(startdate!.replaceAll('-', ''), enddate!.replaceAll('-', ''), status!, searchText!)));
    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
    } else {
      dataList.clear();
      searchStatus.clear();

      value.forEach((element) {
        ReserveListModel temp = ReserveListModel();
        temp.orderNo = element['orderNo'];
        temp.reserDate = element['reserDate'] as String;
        if (int.parse(element['reserTime'].toString().substring(0, 2)) < 12) {
          temp.reserTime = '오전 ${Utils.getTimeFormat(element['reserTime'].toString())}';
        } else {
          temp.reserTime = '오후 ${Utils.getTimeFormat(element['reserTime'].toString())}';
        }
        temp.custCode = element['custCode'];
        temp.custId = element['custId'] as String;
        temp.custName = element['custName'] as String;
        temp.custTelno = element['custTelno'] as String;
        temp.mobileNo = element['mobileNo'] as String;
        temp.mobileNo1 = element['mobileNo1'] as String;
        temp.injengGbn = element['injengGbn'] as String;
        temp.personCnt = element['personCnt'];
        temp.status = element['status'] as String;
        temp.allocDate = element['allocDate'] as String;
        temp.compDate = element['compDate'] as String;
        temp.cancelDate = element['cancelDate'] as String;
        temp.payGbn = element['payGbn'] as String;
        temp.orderNoCard = element['orderNoCard'];
        temp.location = element['location'] as String;
        temp.memo = element['memo'] as String;
        temp.isrtDate = element['isrtDate'] as String;
        temp.modDate = element['modDate'] as String;
        temp.modId = element['modId'] as String;
        temp.modGbn = element['modGbn'] as String;
        temp.myNumber = element['myNumber'] as String;

        dataList.add(temp);
      });

      if (searchText == '0') {
        dataList = dataList.where((item) => item.orderNo.toString().contains('0')).toList();
        statusLength();
      } else if (searchText == '1') {
        dataList = dataList.where((item) => item.orderNo.toString().contains('1')).toList();
        statusLength();
      } else if (searchText == '2') {
        dataList = dataList.where((item) => item.orderNo.toString().contains('2')).toList();
        statusLength();
      } else if (searchText == '3') {
        dataList = dataList.where((item) => item.orderNo.toString().contains('3')).toList();
        statusLength();
      } else if (searchText == '4') {
        dataList = dataList.where((item) => item.orderNo.toString().contains('4')).toList();
        statusLength();
      } else if (searchText == '5') {
        dataList = dataList.where((item) => item.orderNo.toString().contains('5')).toList();
        statusLength();
      } else if (searchText == '6') {
        dataList = dataList.where((item) => item.orderNo.toString().contains('6')).toList();
        statusLength();
      } else if (searchText == '7') {
        dataList = dataList.where((item) => item.orderNo.toString().contains('7')).toList();
        statusLength();
      } else if (searchText == '8') {
        dataList = dataList.where((item) => item.orderNo.toString().contains('8')).toList();
        statusLength();
      } else if (searchText == '9') {
        dataList = dataList.where((item) => item.orderNo.toString().contains('9')).toList();
        statusLength();
      } else {
        searchStatus.add('${ReserveController.to.total_count}');
        searchStatus.add('${ReserveController.to.statuS10}');
        searchStatus.add('${ReserveController.to.statuS12}');
        searchStatus.add('${ReserveController.to.statuS30}');
        searchStatus.add('${ReserveController.to.statuS90}');
        searchStatus.add('${ReserveController.to.statuS40}');
      }
      selectedPageNumber = 1;

      totalPage = ((dataList.length / 10).ceil());

      paginateDataList();
    }

    setState(() {});
  }

  void statusLength() {
    if (status == '') {
      totalCount = dataList.length;
      status10 = dataList.where((item) => item.status == '10').toList().length;
      status12 = dataList.where((item) => item.status == '12').toList().length;
      status30 = dataList.where((item) => item.status == '30').toList().length;
      status40 = dataList.where((item) => item.status == '40').toList().length;
      status90 = dataList.where((item) => item.status == '90').toList().length;
      searchStatus.add('$totalCount');
      searchStatus.add('$status10');
      searchStatus.add('$status12');
      searchStatus.add('$status30');
      searchStatus.add('$status90');
      searchStatus.add('$status40');
    } else {
      searchStatus.add('$totalCount');
      searchStatus.add('$status10');
      searchStatus.add('$status12');
      searchStatus.add('$status30');
      searchStatus.add('$status90');
      searchStatus.add('$status40');
    }
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());

    startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    dataList.clear();
    paginatedDataList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }
  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    double contentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 398 : 400);
    TextStyle columnTextStyle = const TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY);

    return fluentUI.ScaffoldPage.withPadding(
      resizeToAvoidBottomInset: false,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ISLabelBarMain(
              leading: Text('예약 현황', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 8),
            Responsive.isMobile(context) == true ? Column(children: searchBarView()) : Row(children: searchBarView()),
            const SizedBox(height: 8),
            Responsive.isMobile(context) == true
                ? SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                        children: searchStatusOptions.asMap().entries.map((entry) {
                      int index = entry.key;
                      String option = entry.value;
                      return searchStatusView(option, index);
                    }).toList()),
                  )
                : Row(
                    children: searchStatusOptions.asMap().entries.map((entry) {
                      int index = entry.key;
                      String option = entry.value;
                      return searchStatusView(option, index);
                    }).toList(),
                  ),
            const SizedBox(height: 8),
            Material(child: Responsive.isMobile(context) ? mobileReservationInfoListView(context, contentHeight, columnTextStyle) : reservationInfoDataTable(context, contentHeight, columnTextStyle)),
            Material(
              child: ISNumberPagination(
                threshold: 5,
                controlButton: const SizedBox(width: 10, height: 10),
                onPageChanged: (int pageNumber) {
                  setState(() {
                    selectedPageNumber = pageNumber;
                  });
                  paginateDataList();
                },
                fontSize: 12,
                pageTotal: totalPage,
                pageInit: selectedPageNumber,
                colorPrimary: Colors.black,
                colorSub: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget mobileReservationInfoListView(fluentUI.BuildContext context, double contentHeight, fluentUI.TextStyle columnTextStyle) {
    return Material(
      child: Column(
        children: [
          ListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: List.generate(paginatedDataList.length, (index) {
                return fluentUI.Expander(
                    contentBackgroundColor: Colors.grey[200],
                    headerHeight: 80,
                    header: Padding(
                      padding: const EdgeInsets.only(top: 10, bottom: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                  padding: EdgeInsets.zero,
                                  alignment: Alignment.center,
                                  child: Container(
                                    alignment: Alignment.center,
                                    width: 45,
                                    height: 23,
                                    decoration: paginatedDataList[index].status == null ? null : BoxDecoration(color: getStatusColor(paginatedDataList[index].status!), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.transparent)),
                                    child: Text(paginatedDataList[index].status == null ? '' : ('${mobileGetStatus(paginatedDataList[index].status!)}' ?? ''), style: const TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY_NEXON)),
                                  )),
                              const SizedBox(width: 8),
                              Text('주문 번호 ${paginatedDataList[index].orderNo}', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY)),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              const SizedBox(width: 54),
                              Text(Utils.getYearMonthDayTimeFormat(paginatedDataList[index].isrtDate as String) ?? '', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14, fontFamily: FONT_FAMILY)),
                            ],
                          ),
                        ],
                      ),
                    ),
                    content: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('예약자 정보', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text('${paginatedDataList[index].custName!.toString()} / ${Utils.getPhoneNumFormat(paginatedDataList[index].myNumber as String, false)} ', style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('예약 정보', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text('${DateFormat('yyyy-MM-dd').format(DateTime.parse(paginatedDataList[index].reserDate.toString()))} (${paginatedDataList[index].personCnt}명) ${paginatedDataList[index].reserTime}',
                                  style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY))
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('요청사항', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY)),
                              Text(paginatedDataList[index].location.toString().replaceAll('\n', ' '), style: const TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 14.0, fontFamily: FONT_FAMILY))
                            ],
                          ),
                        ],
                      ),
                    ));
              }))
        ],
      ),
    );
  }

  Widget reservationInfoDataTable(fluentUI.BuildContext context, double contentHeight, fluentUI.TextStyle columnTextStyle) {
    return ISDatatable(
      headingRowHeight: 40,
      dataRowHeight: 40,
      listWidth: Responsive.getResponsiveWidth(context),
      listHeight: contentHeight,
      minWidth: 800,
      rows: paginatedDataList.map((item) {
        return DataRow(cells: [
          DataCell(Align(alignment: Alignment.center, child: Text(item.orderNo!.toString() == null ? '--' : item.orderNo.toString(), style: columnTextStyle))),
          DataCell(Align(alignment: Alignment.center, child: Text(item.reserDate!.toString() == null ? '--' : '${DateFormat('yyyy-MM-dd').format(DateTime.parse(item.reserDate.toString()))} ${item.reserTime}', style: columnTextStyle))),
          DataCell(Align(alignment: Alignment.center, child: Text(item.status!.toString() == null ? '--' : getStatus(item.status.toString()), style: columnTextStyle))),
          DataCell(Align(alignment: Alignment.center, child: Text(item.custName!.toString() == null ? '--' : '${item.custName.toString()} ${Utils.getPhoneNumFormat(item.myNumber as String, false)}', style: columnTextStyle))),
          DataCell(Align(alignment: Alignment.center, child: Text(item.isrtDate!.toString() == null ? '--' : Utils.getYearMonthDayTimeFormat(item.isrtDate as String), style: columnTextStyle))),
          DataCell(Align(alignment: Alignment.center, child: Text(item.location!.toString() == null ? '--' : item.location.toString().replaceAll('\n', ' '), style: columnTextStyle))),
        ]);
      }).toList(),
      columns: const <DataColumn>[
        DataColumn(label: Expanded(child: Text('주문 번호', textAlign: TextAlign.center))),
        DataColumn(label: Expanded(child: Text('예약 정보', textAlign: TextAlign.center))),
        DataColumn(label: Expanded(child: Text('상태', textAlign: TextAlign.center))),
        DataColumn(label: Expanded(child: Text('예약자 정보', textAlign: TextAlign.center))),
        DataColumn(label: Expanded(child: Text('신청 일시', textAlign: TextAlign.center))),
        DataColumn(label: Expanded(child: Text('요청사항', textAlign: TextAlign.center))),
      ],
    );
  }

  List<Widget> searchBarView() {
    return [
      Material(
        child: ISSearchSelectDate(
          label: '기간 선택',
          width: Responsive.isMobile(context) == true ? double.infinity : 230,
          value: '${startdate.toString()} ~ ${enddate.toString()}',
          onTap: () async {
            showGeneralDialog(
                context: context,
                barrierDismissible: true,
                barrierLabel: '',
                barrierColor: Colors.black54,
                pageBuilder: (context, animation, secondaryAnimation) {
                  return Dialog(
                      insetPadding: EdgeInsets.zero,
                      elevation: 0,
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                      child: MultipleViewDateRangePicker(
                        startDate: DateTime.parse(startdate!),
                        endDate: DateTime.parse(enddate!),
                        setDateActionCallback: ({startDate, endDate}) {
                          Navigator.of(context).pop();

                          startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                          enddate = DateFormat('yyyy-MM-dd').format(endDate!);
                          selectedPageNumber = 1;
                          status = '';
                          selectedOption = '전체';
                          pickDate = true;
                          requestAPIData();
                        },
                      ));
                });
          },
        ),
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8) : const SizedBox(width: 8),
      ISToggleButtons(
        [
          ISOptionModel(value: '1000', label: '오늘'),
          ISOptionModel(value: '1001', label: '5일'),
          ISOptionModel(value: '1002', label: '7일'),
          ISOptionModel(value: '1003', label: '1개월'),
          ISOptionModel(value: '1004', label: '3개월'),
        ],
        buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 5) - 6) : 60,
        defaultValue: selectedType,
        pickDate: pickDate,
        afterOnPress: (v) {
          if (v == '1000') {
            startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          } else if (v == '1001') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 5)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          } else if (v == '1002') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 7)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          } else if (v == '1003') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 30)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          } else if (v == '1004') {
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 90)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }

          setState(() {
            selectedType = v.toString();
            status = '';
            selectedOption = '전체';
            selectedPageNumber = 1;
            searchText = '';
            pickDate = false;
          });
          requestAPIData();
        },
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8) : Expanded(child: Container()),
      Material(
        child: ISSearchDropdown(
          label: '업체타입',
          width: Responsive.isMobile(context) == true ? double.infinity : 100,
          value: div,
          onChange: (value) {
            setState(() {});
          },
          item: [
            ISOptionModel(value: '%', label: '주문 번호'),
          ].cast<ISOptionModel>(),
        ),
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8) : const SizedBox(width: 8),
      Material(
        child: ISInput(
          value: searchText,
          label: '입력 후 검색',
          width: Responsive.isMobile(context) == true ? double.infinity : 240,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9]'))],
          prefixIcon: const Icon(
            Icons.search,
            color: Colors.black54,
          ),
          suffixIcon: MaterialButton(
            color: Colors.lightBlueAccent,
            minWidth: 60,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
            onPressed: () async {
              selectedOption = '전체';
              status = '';
              requestAPIData();
            },
            child: const Text('조회', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
          ),
          onChange: (v) {
            setState(() {
              searchText = v;
            });
          },
        ),
      )
    ];
  }

  Widget searchStatusView(String option, int index) {
    bool isSelected = selectedOption == option;

    return TextButton(
      onPressed: () {
        if (option == '전체') {
          status = '';
        } else if (option == '예약 대기') {
          status = '10';
        } else if (option == '방문 예정') {
          status = '12';
        } else if (option == '방문 완료') {
          status = '30';
        } else if (option == '취소') {
          status = '40';
        } else {
          status = '90';
        }
        setState(() {
          selectedOption = option;
        });
        requestAPIData();
      },
      child: Row(
        children: [
          Text('$option(${searchStatus[index]})', style: TextStyle(fontSize: 13, color: isSelected ? Colors.blue : Colors.black)),
        ],
      ),
    );
  }

  Color getStatusColor(String status) {
    Color tempColor;

    if (status == '10') {
      tempColor = Colors.yellow;
    } // 예약대기
    else if (status == '12') {
      tempColor = Colors.green;
    } // 방문예정
    else if (status == '30') {
      tempColor = Colors.grey;
    } // 방문완료
    else if (status == '40') {
      tempColor = Colors.red;
    } // 취소
    else {
      tempColor = Colors.yellow;
    } // 미방문

    return tempColor;
  }

  getStatus(String status) {
    String temp;

    if (status == '10') {
      temp = '예약 대기';
    } else if (status == '12') {
      temp = '방문 예정';
    } else if (status == '30') {
      temp = '방문 완료';
    } else if (status == '40') {
      temp = '취소';
    } else {
      temp = '미방문';
    }

    return temp;
  }

  mobileGetStatus(String status) {
    String temp;

    if (status == '10') {
      temp = '대기';
    } else if (status == '12') {
      temp = '확정';
    } else if (status == '30') {
      temp = '종료';
    } else if (status == '40') {
      temp = '취소';
    } else {
      temp = '미방';
    }

    return temp;
  }
}