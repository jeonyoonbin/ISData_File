

import 'dart:math';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_datatable.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/OrderManager/orderListModel.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/screen/OrderManager/orderDetailInfo.dart';
import 'package:daeguro_ceo_app/screen/OrderManager/orderDetailInfo_bundle.dart';
import 'package:daeguro_ceo_app/screen/OrderManager/orderDetailInfo_flower.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class OrderInfoMain extends StatefulWidget {
  const OrderInfoMain({Key? key}) : super(key: key);

  @override
  State<OrderInfoMain> createState() => _OrderInfoMainState();
}

class _OrderInfoMainState extends State<OrderInfoMain> with PageMixin{

  String? startdate = '';
  String? enddate = '';
  String? selectedType = '1000';
  int selectedPageNumber = 1;
  int totalPage = 0;
  bool pickDate = false;

  final List<OrderListModel> dataList = <OrderListModel>[];
  final ScrollController _scrollController = ScrollController();

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(AccountController.to.getShopOrderList(startdate!.replaceAll('-', ''), enddate!.replaceAll('-', ''), selectedPageNumber.toString()))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        OrderListModel temp = OrderListModel();
        temp.rNum = element['rNum'] as String;
        temp.orderNo = element['orderNo'] as String;
        temp.orderTime = element['orderTime'] as String;
        temp.statusName = element['statusName'] as String;
        temp.packOrderName = element['packOrderName'] as String;
        temp.totAmt = element['totAmt'] as String;
        temp.appPayGbn = element['appPayGbn'] as String;
        temp.payGbn = element['payGbn'] as String;
        temp.custDongAddr = element['custDongAddr'] as String;

        dataList.add(temp);
      });

      totalPage = AccountController.to.total_page;

    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(AccountController());

    startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);//formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
    enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);//formatDate(DateTime(int.parse(DateTime.now().year.toString()), int.parse(DateTime.now().month.toString()) + 1, 0), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    dataList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    double contentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 398 : 370);
    TextStyle columnTextStyle = const TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY);

    return fluentUI.ScaffoldPage.withPadding(
      resizeToAvoidBottomInset: false,
      //scrollController: AppTheme.mainScrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ISLabelBarMain(
              leading: Text('주문 정보', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
            ),
            const SizedBox(height: 8,),
            Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
            const SizedBox(height: 8,),
            Material(
              child: Responsive.isMobile(context) ? mobileOrderInfoListView(context, contentHeight, columnTextStyle) : orderInfoDataTable(context, contentHeight, columnTextStyle),
            ),
            Material(
              child: ISNumberPagination(
                threshold: 5,
                controlButton: const SizedBox(
                  width: 10,
                  height: 10,
                ),
                onPageChanged: (int pageNumber) {
                  setState(() {
                    selectedPageNumber = pageNumber;
                  });

                  requestAPIData();
                },
                fontSize: 12,
                pageTotal: totalPage,
                pageInit: selectedPageNumber,
                // picked number when init page
                colorPrimary: Colors.black,
                colorSub: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget orderInfoDataTable(fluentUI.BuildContext context, double contentHeight, fluentUI.TextStyle columnTextStyle) {
    return ISDatatable(
      headingRowHeight: 40,
      dataRowHeight: 40,
      listWidth: Responsive.getResponsiveWidth(context),//MediaQuery.of(context).size.width,
      listHeight: contentHeight,//contentHeight,
      minWidth: 800,
      rows: dataList.map((item) {
        return DataRow(
            selected: item.selected!,
            color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
              if (item.selected == true) {
                return Colors.grey.shade200;
                //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
              }

              return Theme.of(context).colorScheme.primary.withOpacity(0.00);
            }),
            onSelectChanged: (bool? value) {
              dataList.forEach((element) {
                element.selected = false;
              });

              item.selected = true;

              String _orderNo = item.orderNo.toString();

              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER ? OrderDetailInfoFlower(orderNo: _orderNo.toString())
                    : item.packOrderName == '장보기' || AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET ? OrderDetailInfoBundle(orderNo: _orderNo.toString()) : OrderDetailInfo(orderNo: _orderNo.toString()),
              );

              //setState(() {});
            },
            cells: [
              DataCell(Align(alignment: Alignment.center, child: Text(item.orderNo!.toString() == null ? '--' : item.orderNo.toString(), style: columnTextStyle))),
              DataCell(Align(alignment: Alignment.center, child: Text(item.orderTime!.toString() == null ? '--' : item.orderTime.toString(), style: columnTextStyle))),
              DataCell(Align(alignment: Alignment.center, child: Text(item.statusName!.toString() == null ? '--' : item.statusName.toString(), style: columnTextStyle))),
              DataCell(Align(alignment: Alignment.center, child: Text(item.packOrderName!.toString() == null ? '--' : item.packOrderName.toString(), style: columnTextStyle))),
              DataCell(Align(alignment: Alignment.center, child: Text('${item.totAmt!.toString() == null ? '--' : item.totAmt.toString()}원', style: columnTextStyle))),
              DataCell(Align(alignment: Alignment.center, child: Text(item.appPayGbn!.toString() == null ? '--' : item.appPayGbn.toString(), style: columnTextStyle))),
              DataCell(Align(alignment: Alignment.center, child: Text(item.payGbn!.toString() == null ? '--' : item.payGbn.toString(), style: columnTextStyle))),
              DataCell(Align(alignment: Alignment.center, child: Text(item.custDongAddr!.toString() == null ? '--' : item.custDongAddr.toString(), style: columnTextStyle))),
            ]);
      }).toList(),
      columns: const <DataColumn>[
        DataColumn(label: Expanded(child: Text('주문 번호',  textAlign: TextAlign.center)),),
        DataColumn(label: Expanded(child: Text('주문 일자', textAlign: TextAlign.center)),),
        DataColumn(label: Expanded(child: Text('주문 상태', textAlign: TextAlign.center)),),
        DataColumn(label: Expanded(child: Text('주문 유형', textAlign: TextAlign.center)),),
        DataColumn(label: Expanded(child: Text('주문 금액', textAlign: TextAlign.center)),),
        DataColumn(label: Expanded(child: Text('지급 구분', textAlign: TextAlign.center)),),
        DataColumn(label: Expanded(child: Text('결제 수단', textAlign: TextAlign.center)),),
        DataColumn(label: Expanded(child: Text('주소', textAlign: TextAlign.center)),),
      ],
    );
  }

  Widget mobileOrderInfoListView(fluentUI.BuildContext context, double contentHeight, fluentUI.TextStyle columnTextStyle) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 3),
      child: ListView.builder(
          controller: _scrollController,
          shrinkWrap: true,
          itemBuilder: (ctx, index) {
            return GestureDetector(
              onTap: () {
                showDialog(
                  context: ctx,
                  barrierDismissible: true,
                  builder: (context) => AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER ? OrderDetailInfoFlower(orderNo: dataList[index].orderNo.toString())
                      : dataList[index].packOrderName == '장보기'? OrderDetailInfoBundle(orderNo: dataList[index].orderNo.toString()): OrderDetailInfo(orderNo: dataList[index].orderNo.toString()),
                );
              },
              child: Card(
                elevation: 1,
                child: Padding(
                  padding: EdgeInsets.all(10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [Text('주문 번호', style: columnTextStyle), Text(dataList[index].orderNo!.toString() == null ? '--' : dataList[index].orderNo.toString(), style: columnTextStyle)],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [Text('주문 일자', style: columnTextStyle), Text(dataList[index].orderTime!.toString() == null ? '--' : dataList[index].orderTime.toString(), style: columnTextStyle)],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [Text('주문 상태', style: columnTextStyle), Text(dataList[index].statusName!.toString() == null ? '--' : dataList[index].statusName.toString(), style: columnTextStyle)],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [Text('주문 유형', style: columnTextStyle), Text(dataList[index].packOrderName!.toString() == null ? '--' : dataList[index].packOrderName.toString(), style: columnTextStyle)],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [Text('주문 금액', style: columnTextStyle), Text('${dataList[index].totAmt!.toString() == null ? '--' : dataList[index].totAmt.toString()}원', style: columnTextStyle)],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [Text('지급 구분', style: columnTextStyle), Text(dataList[index].appPayGbn!.toString() == null ? '--' : dataList[index].appPayGbn.toString(), style: columnTextStyle)],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [Text('현장 결제', style: columnTextStyle), Text(dataList[index].payGbn!.toString() == null ? '--' : dataList[index].payGbn.toString(), style: columnTextStyle)],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('주소', style: columnTextStyle),
                          Flexible(child: Text(dataList[index].custDongAddr!.toString() == null ? '--' : dataList[index].custDongAddr.toString(), style: columnTextStyle)),
                        ],
                      ),
                      const SizedBox(height: 6),
                    ],
                  ),
                ),
              ),
            );
          },
          itemCount: dataList.length),
    );
  }

  List<Widget> searchBarView(){
    return [
      Material(
        child: ISSearchSelectDate(
          label: '기간 선택',
          width: Responsive.isMobile(context) == true ? double.infinity : 230,
          value: '${startdate.toString()} ~ ${enddate.toString()}',
          onTap: () async {
            showGeneralDialog(
                context: context,
                barrierDismissible: true,
                barrierLabel: '',
                barrierColor: Colors.black54,
                pageBuilder: (context, animation, secondaryAnimation) {
                  return Dialog(
                      insetPadding: EdgeInsets.zero,
                      elevation: 0,
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                      child: MultipleViewDateRangePicker(
                        startDate: DateTime.parse(startdate!),
                        endDate: DateTime.parse(enddate!),
                        setDateActionCallback: ({startDate, endDate}) {
                          Navigator.of(context).pop();

                          startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                          enddate = DateFormat('yyyy-MM-dd').format(endDate!);

                          selectedPageNumber = 1;
                          pickDate = true;

                          requestAPIData();
                        },
                      ));
                });
          },
        ),
      ),
      Responsive.isMobile(context) == true ?  const SizedBox(height: 8,) :  const SizedBox(width: 8,),
      ISToggleButtons(
        [
          ISOptionModel(value: '1000', label: '오늘'),
          ISOptionModel(value: '1001', label: '5일'),
          ISOptionModel(value: '1002', label: '7일'),
          ISOptionModel(value: '1003', label: '1개월'),
          ISOptionModel(value: '1004', label: '3개월'),
        ],
        buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 5) - 6) : 60,
        defaultValue: selectedType,
        pickDate: pickDate,
        afterOnPress: (v) {
          if (v == '1000'){
            startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1001'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 5)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1002'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 7)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1003'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 30)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1004'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 90)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }

          setState(() {
            selectedType = v.toString();
            pickDate = false;
          });

          selectedPageNumber = 1;

          requestAPIData();

          // setState(() {
          //   this.selectedImageType = v;
          // });

          // loadData();
        },
      ),
    ];
  }

}