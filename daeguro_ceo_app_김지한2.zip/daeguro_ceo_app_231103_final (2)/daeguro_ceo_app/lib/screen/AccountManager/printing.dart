import 'dart:typed_data';

import 'package:daeguro_ceo_app/models/AccountManager/VATInfoModel.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class printing extends StatefulWidget {
  final List<VATInfoModel>? incomeData;
  final List<VATInfoModel>? outcomeData;
  final List<VATInfoModel>? insungData;

  const printing({Key? key, this.incomeData, this.outcomeData, this.insungData}) : super(key: key);

  @override
  State<printing> createState() => _printingState();
}

class _printingState extends State<printing> {
  List<VATInfoModel>? incomeData = [];
  List<VATInfoModel>? outcomeData = [];
  List<VATInfoModel>? insungData = [];

  @override
  void initState() {
    super.initState();
    incomeData = widget.incomeData;
    outcomeData = widget.outcomeData;
    insungData = widget.insungData;
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: 1000,
        height: 900,
        child: MaterialApp(
          theme: ThemeData(
            primaryIconTheme: const IconThemeData(color: Colors.white),
          ),
          debugShowCheckedModeBanner: false,
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: const [
            Locale('ko', 'KR'),
          ],
          home: Scaffold(
            body: PdfPreview(
              build: (format) => generatePdf(format, incomeData!, outcomeData!, insungData!),
            ),
          ),
        ),
      ),
    );
  }
}

Future<Uint8List> generatePdf(
    PdfPageFormat format,
    List<VATInfoModel> incomeData,
    List<VATInfoModel> outcomeData,
    List<VATInfoModel> insungData,
    ) async {
  final pdf = pw.Document(version: PdfVersion.pdf_1_5, compress: true);
  final ttf = await PdfGoogleFonts.nanumGothicRegular();
  final ttf_bold = await PdfGoogleFonts.nanumGothicBold();

  pdf.addPage(
    pw.Page(
      pageFormat: format,
      build: (context) {
        return pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.start,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.SizedBox(
                width: double.infinity,
                height: 25,
                child: pw.TextField(
                    name: 'test',
                    value: '부가세 신고 자료',
                    textStyle: pw.TextStyle(font: ttf_bold, fontSize: 15, fontWeight: pw.FontWeight.bold))),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.SizedBox(
                  width: 100,
                  height: 13,
                  child: pw.TextField(
                      name: 'test', value: '조회일 : ${DateTime.now()}', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 250,
                  height: 13,
                  child: pw.TextField(
                      name: 'test',
                      value: '조회 기간 : ${insungData[0].fromDate} ~ ${insungData[0].toDate}',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
            ]),
            pw.Divider(),
            pw.SizedBox(height: 5),
            pw.Table(
                columnWidths: const {
                  0: pw.FlexColumnWidth(1),
                  1: pw.FlexColumnWidth(2),
                  2: pw.FlexColumnWidth(1),
                  3: pw.FlexColumnWidth(2),
                },
                defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
                //border: TableBorder.all(width: 0.8, color: Colors.black),
                children: [
                  pw.TableRow(children: [
                    pw.Container(
                        padding: const pw.EdgeInsets.all(5),
                        alignment: pw.Alignment.center,
                        child: pw.TextField(name: 'test222', value: '상호명', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.TextField(
                          name: 'test222', value: insungData[0].bussName, textStyle: pw.TextStyle(font: ttf, fontSize: 10)),
                    ),
                    pw.Container(
                        padding: const pw.EdgeInsets.all(5),
                        alignment: pw.Alignment.center,
                        child: pw.TextField(name: 'test222', value: '가맹점명', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.TextField(
                          name: 'test222', value: insungData[0].insungName, textStyle: pw.TextStyle(font: ttf, fontSize: 10)),
                    ),
                  ]),
                  pw.TableRow(children: [
                    pw.Container(
                        padding: const pw.EdgeInsets.all(5),
                        alignment: pw.Alignment.center,
                        child: pw.TextField(name: 'test222', value: '사업자명', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.TextField(
                          name: 'test222', value: insungData[0].bussOwner, textStyle: pw.TextStyle(font: ttf, fontSize: 10)),
                    ),
                    pw.Container(
                        padding: const pw.EdgeInsets.all(5),
                        alignment: pw.Alignment.center,
                        child: pw.TextField(name: 'test222', value: '대표자명', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.TextField(
                          name: 'test222', value: insungData[0].insungOwner, textStyle: pw.TextStyle(font: ttf, fontSize: 10)),
                    ),
                  ]),
                  pw.TableRow(children: [
                    pw.Container(
                        padding: const pw.EdgeInsets.all(5),
                        alignment: pw.Alignment.center,
                        child: pw.TextField(name: 'test222', value: '사업자등록번호', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.TextField(
                          name: 'test222', value: insungData[0].regNo, textStyle: pw.TextStyle(font: ttf, fontSize: 10)),
                    ),
                    pw.Container(
                        padding: const pw.EdgeInsets.all(5),
                        alignment: pw.Alignment.center,
                        child: pw.TextField(name: 'test222', value: '사업자등록번호', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.TextField(
                          name: 'test222', value: insungData[0].insungRegNo, textStyle: pw.TextStyle(font: ttf, fontSize: 10)),
                    ),
                  ]),
                  pw.TableRow(children: [
                    pw.SizedBox.shrink(),
                    pw.SizedBox.shrink(),
                    pw.Container(
                        padding: const pw.EdgeInsets.all(5),
                        alignment: pw.Alignment.center,
                        child: pw.TextField(name: 'test222', value: '전화번호', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.TextField(
                          name: 'test222', value: insungData[0].insungTelno, textStyle: pw.TextStyle(font: ttf, fontSize: 10)),
                    ),
                  ]),
                ]),
            pw.SizedBox(height: 20),
            pw.SizedBox(
                width: double.infinity,
                height: 20,
                child: pw.TextField(
                    name: 'test',
                    value: '매출',
                    textStyle: pw.TextStyle(font: ttf_bold, fontSize: 12, fontWeight: pw.FontWeight.bold))),
            pw.Divider(),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '매출구분', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '공급가액', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '부가세', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '합계', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
            ]),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '카드매출', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[0].outComeAmt!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[0].outComeVat!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[0].outComeTotal!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
            ]),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '기타매출', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[2].outComeAmt!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[2].outComeVat!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[2].outComeTotal!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
            ]),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '현금매출', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[1].outComeAmt!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[1].outComeVat!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[1].outComeTotal!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
            ]),
            if (outcomeData.length > 5)
              pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                pw.SizedBox(
                    width: 100,
                    height: 20,
                    child: pw.TextField(name: 'test', value: '만나서 결제 카드', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                pw.SizedBox(
                    width: 100,
                    height: 20,
                    child: pw.TextField(
                        name: 'test',
                        value: '${Utils.getCashComma(outcomeData[3].outComeAmt!)}원',
                        textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                pw.SizedBox(
                    width: 100,
                    height: 20,
                    child: pw.TextField(
                        name: 'test',
                        value: '${Utils.getCashComma(outcomeData[3].outComeVat!)}원',
                        textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                pw.SizedBox(
                    width: 100,
                    height: 20,
                    child: pw.TextField(
                        name: 'test',
                        value: '${Utils.getCashComma(outcomeData[3].outComeTotal!)}원',
                        textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              ]),
            if (outcomeData.length > 5)
              pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                pw.SizedBox(
                    width: 100,
                    height: 20,
                    child: pw.TextField(name: 'test', value: '만나서 결제 현금', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                pw.SizedBox(
                    width: 100,
                    height: 20,
                    child: pw.TextField(
                        name: 'test',
                        value: '${Utils.getCashComma(outcomeData[4].outComeAmt!)}원',
                        textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                pw.SizedBox(
                    width: 100,
                    height: 20,
                    child: pw.TextField(
                        name: 'test',
                        value: '${Utils.getCashComma(outcomeData[4].outComeVat!)}원',
                        textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
                pw.SizedBox(
                    width: 100,
                    height: 20,
                    child: pw.TextField(
                        name: 'test',
                        value: '${Utils.getCashComma(outcomeData[4].outComeTotal!)}원',
                        textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              ]),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '합계', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[outcomeData.length - 1].outComeAmt!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[outcomeData.length - 1].outComeVat!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(outcomeData[outcomeData.length - 1].outComeTotal!)}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
            ]),
            pw.SizedBox(height: 20),
            pw.SizedBox(
                width: double.infinity,
                height: 20,
                child: pw.TextField(
                    name: 'test',
                    value: '매입',
                    textStyle: pw.TextStyle(font: ttf_bold, fontSize: 12, fontWeight: pw.FontWeight.bold))),
            pw.Divider(),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '매입구분', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '건수', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '수수료', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '부가세', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '합계', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
            ]),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '카드 수수료', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(incomeData[0].inComeCnt!)}건',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(int.parse(incomeData[0].inComeAmt!).abs().toString())}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(int.parse(incomeData[0].inComeVat!).abs().toString())}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(int.parse(incomeData[0].inComeTotal!).abs().toString())}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
            ]),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '중개 수수료', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(incomeData[1].inComeCnt!)}건',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(int.parse(incomeData[1].inComeAmt!).abs().toString())}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(int.parse(incomeData[1].inComeVat!).abs().toString())}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(int.parse(incomeData[1].inComeTotal!).abs().toString())}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
            ]),
            pw.Row(mainAxisAlignment: pw.MainAxisAlignment.start, crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(name: 'test', value: '합계', textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(incomeData[2].inComeCnt!)}건',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(int.parse(incomeData[2].inComeAmt!).abs().toString())}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(int.parse(incomeData[2].inComeVat!).abs().toString())}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
              pw.SizedBox(
                  width: 100,
                  height: 20,
                  child: pw.TextField(
                      name: 'test',
                      value: '${Utils.getCashComma(int.parse(incomeData[2].inComeTotal!).abs().toString())}원',
                      textStyle: pw.TextStyle(font: ttf, fontSize: 10))),
            ]),
          ],
        );
      },
    ),
  );

  return pdf.save();
}
