import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionMenuLinkChildModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionMenuLinkEditModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionMenuLinkParentModel.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class OptionGroupMenuLinkEdit extends StatefulWidget {
  final String? optGrpName;
  final String? optGrpCd;
  const OptionGroupMenuLinkEdit({Key? key, this.optGrpName, this.optGrpCd})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return OptionGroupMenuLinkEditState();
  }
}

class OptionGroupMenuLinkEditState extends State<OptionGroupMenuLinkEdit> {
  List<OptionMenuLinkParentModel> dataList = [];

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(MenuInfoController.to.getMenuLinkList(widget.optGrpCd!))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      List<OptionMenuLinkChildModel> tempListData = [];
      value.forEach((element) {
        OptionMenuLinkChildModel temp = OptionMenuLinkChildModel();

        temp.selectYn = element['selectYn'] as String;
        temp.menuGrpCd = element['menuGrpCd'] as String;
        temp.menuGrpName = element['menuGrpName'] as String;
        temp.menuCd = element['menuCd'] as String;
        temp.menuName = element['menuName'] as String;
        temp.menuCost = element['menuCost'] as String;

        tempListData.add(temp);

        int result = dataList.indexWhere((element) => element.menuGroupName == temp.menuGrpName);

        if (result == -1){
          OptionMenuLinkParentModel tempMainList = OptionMenuLinkParentModel(
            menuGroupName: temp.menuGrpName, menu: []
          );

          dataList.add(tempMainList);
        }
      });

      dataList.forEach((element) {
        tempListData.forEach((menuElement) {
          if (element.menuGroupName == menuElement.menuGrpName){
            OptionMenuLinkChildModel childMenu = OptionMenuLinkChildModel();
            childMenu.selectYn = menuElement.selectYn;
            childMenu.menuGrpCd = menuElement.menuGrpCd;
            childMenu.menuGrpName = menuElement.menuGrpName;
            childMenu.menuCd = menuElement.menuCd;
            childMenu.menuName = menuElement.menuName;
            childMenu.menuCost = menuElement.menuCost;

            element.menu!.add(childMenu);
          }
        });
      });

      dataList.forEach((element) {
        var checkList = element.menu!.where((element) => element.selectYn == 'Y').toList();
        element.selected = (element.menu!.length == checkList.length) ? true : false;
      });
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(MenuInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    dataList.clear();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();//.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 640),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('메뉴 연결', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //const Divider(color: Colors.grey, height: 0.0,),
                const SizedBox(height: 16,),
                const Text('연결 메뉴 선택', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                Text('[${widget.optGrpName}]에 연결할 메뉴를 선택해 주세요.', style: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                const Divider(),
                const SizedBox(height: 8),
                Column(
                  children: [
                    ...dataList.map((parentItem) =>
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10),
                                width: double.infinity,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: Colors.black12,
                                  border: Border.all(width: 1.0, color: Colors.black26),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    fluentUI.Checkbox(
                                      content: SizedBox(width: Responsive.isMobile(context) ? 260 : 300, child: Text(parentItem.menuGroupName!, style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, overflow: TextOverflow.ellipsis),)),
                                      checked: parentItem.selected,
                                      onChanged: (v){
                                        parentItem.selected = v!;

                                        parentItem.menu!.forEach((element) {
                                          element.selectYn = parentItem.selected == true ? 'Y' : 'N';
                                        });

                                        setState(() {
                                        });
                                      },
                                    ),
                                  ],
                                )
                            ),
                            ...parentItem.menu!.map((childItem) =>
                                Container(
                                  padding: const EdgeInsets.only(left: 10, right: 20),
                                  width: double.infinity,
                                  height: 40,
                                  decoration: BoxDecoration(color: Colors.white, border: Border.all(width: 1.0, color: Colors.black26),),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      fluentUI.Checkbox(
                                          content: SizedBox(
                                              width: Responsive.isMobile(context) ? 205 : 220,
                                              child: Text(childItem.menuName!, style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, overflow: TextOverflow.ellipsis))
                                          ),
                                        checked: childItem.selectYn == 'Y' ? true : false,
                                          onChanged: (v){
                                            childItem.selectYn = v == true ? 'Y' : 'N';

                                            var dataList = parentItem.menu!.where((element) => element.selectYn == 'Y').toList();

                                            parentItem.selected = (parentItem.menu!.length == dataList.length) ? true : false;

                                            setState(() {
                                            });
                                          },
                                      ),
                                      Text('${Utils.getCashComma(childItem.menuCost!)}원', style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                                    ],
                                  ),
                                )
                            ).toList(),
                          ],
                        ),
                    ).toList(),
                  ],
                ),
                const SizedBox(height: 20,),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              List<String> selectedCheckList = [];
              dataList.forEach((element) {
                element.menu!.forEach((chileElement) {
                  if (chileElement.selectYn == 'Y'){
                    selectedCheckList.add(chileElement.menuCd!);
                  }
                });
              });


              if (selectedCheckList.isEmpty){
                ISAlert(context, content: '선택된 메뉴가 없습니다.\n확인 후, 다시 시도해 주세요.');
                return;
              }

              BuildContext baseContext = context;
              ISConfirm(context, '메뉴 연결', '메뉴 연결 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  OptionMenuLinkEditModel sendData = OptionMenuLinkEditModel();
                  sendData.shopCd = AuthService.SHOPCD;
                  sendData.optGrpCd = widget.optGrpCd;
                  sendData.menuCd = selectedCheckList;

                  var value = await showDialog(
                      context: context,
                      barrierColor: Colors.transparent,
                      builder: (context) => FutureProgressDialog(MenuInfoController.to.updateMenuLink(sendData.toJson()))
                  );

                  if (value == null) {
                    ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(baseContext).pop(true);
                    }
                    else{
                      ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


