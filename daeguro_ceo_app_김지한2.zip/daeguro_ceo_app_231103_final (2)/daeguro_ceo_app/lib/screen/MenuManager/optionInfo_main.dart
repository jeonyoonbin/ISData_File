

import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionEditModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionGroupListModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionListModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/Common/commonNoFlagEdit.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManagerController.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/optionCountSetting.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/optionGroupEdit.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/optionGroupMenuLinkEdit.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/optionGroupAdd.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/optionListEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class OptionInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const OptionInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<OptionInfoMain> createState() => _OptionInfoMainState();
}

class _OptionInfoMainState extends State<OptionInfoMain> {

  static const int MODE_GROUPVIEW = 1000;
  static const int MODE_ITEMVIEW = 1001;

  int currentMode = MODE_GROUPVIEW;

  String liveEventYn = '';

  String? selectedGroupName;
  String? selectedGroupCd;

  String optionTotalCnt = '0';
  // String optionMultiCnt = '';
  // String optionMinCnt = '';
  // String optionMenuList = '';
  // String optionMultiYn = '';
  // String optionReqYn = '';

  OptionGroupListModel? selectOptionGroup;

  final List<OptionGroupListModel> dataGroupList =  <OptionGroupListModel>[];
  final List<OptionListModel> dataItemList = <OptionListModel>[];

  requestAPI_OptionGroupData() async {

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(MenuInfoController.to.getOptionGroupList())
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataGroupList.clear();

      value.forEach((element) {
        OptionGroupListModel temp = OptionGroupListModel();

        temp.optGrpCd = element['optGrpCd'] as String;
        temp.optGrpName = element['optGrpName'] as String;
        temp.optGrpMemo = element['optGrpMemo'] as String;
        temp.optNames = element['optNames'] as String;
        temp.menuNames = element['menuNames'] as String;
        temp.minCount = element['minCount'] as String;
        temp.multiCount = element['multiCount'] as String;
        temp.multiYn = element['multiYn'] as String;
        temp.useYn = element['useYn'] as String;
        temp.reqYn = element['reqYn'] as String;

        if (temp.minCount == '') {
          temp.minCount = '0';
        }

        if (temp.multiCount == '') {
          temp.multiCount = '0';
        }

        dataGroupList.add(temp);
      });

      liveEventYn = MenuInfoController.to.eventYn;

      if (selectOptionGroup != null){
        int retIndex = dataGroupList.indexWhere((element) => element.optGrpCd == selectOptionGroup!.optGrpCd);
        selectOptionGroup = dataGroupList.elementAt(retIndex);
      }
    }

    setState(() {});
  }

  requestAPI_OptionData(String optionGroupCd) async {

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(MenuInfoController.to.getOptionList(optionGroupCd))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataItemList.clear();

      value.forEach((element) {
        OptionListModel temp = OptionListModel();
        temp.optionCd = element['optionCd'] as String;
        temp.optionName = element['optionName'] as String;
        temp.optionMemo = element['optionMemo'] as String;
        temp.menuFileName = element['menuFileName'] as String;
        temp.cost = element['cost'] as String;
        temp.useYn = element['useYn'] as String;
        temp.noFlag = element['noFlag'] as String;
        temp.adultOnly = element['adultOnly'] as String;

        dataItemList.add(temp);
      });

      liveEventYn = MenuInfoController.to.eventYn;

      optionTotalCnt = dataItemList.length.toString();

      // optionMultiCnt = MenuInfoController.to.optionMultiCnt;
      // optionMinCnt = MenuInfoController.to.optionMinCnt;
      // optionMenuList = MenuInfoController.to.optionMenuList;
      // optionMultiYn = MenuInfoController.to.optionMultiYn;
      // optionReqYn = MenuInfoController.to.optionReqYn;
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(MenuInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPI_OptionGroupData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    selectOptionGroup = OptionGroupListModel();
    dataGroupList.clear();
    dataItemList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          if (AuthService.ShopServiceGbn != AuthService.SHOPGBN_FLOWER){
             currentMode = MODE_GROUPVIEW;
             selectOptionGroup = null;
             requestAPI_OptionGroupData();
          }
          else{
            router.go('/');
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          elevation: 1,
          shape: appTheme.cardShapStyle,
          child: Container(
            constraints: const BoxConstraints(minWidth: double.infinity),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: currentMode == MODE_GROUPVIEW
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.feed_outlined, size: 20),
                            const SizedBox(width: 8,),
                            Text('옵션 그룹 (${dataGroupList.length}개)', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),)
                          ],
                        ),
                        ISButton(
                          child: const Text('옵션 그룹 추가'),
                          onPressed: () {
                            liveEventYn== 'Y'
                                ?
                            ISAlert(context, content: '라이브 이벤트 중에는 수정이 불가능합니다.')
                                :
                            showDialog(
                              context: context,
                              barrierDismissible: true,
                              builder: (context) => const OptionGroupAdd(),
                            ).then((value) async {
                              if (value == true){
                                await Future.delayed(const Duration(milliseconds: 500), () {
                                  requestAPI_OptionGroupData();
                                });
                              }
                            });
                          },
                        )
                      ],
                    )
                  : SingleChildScrollView(
                 scrollDirection: Responsive.isMobile(context) ? Axis.horizontal : Axis.vertical,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.feed_outlined, size: 20),
                            TextButton(
                              style: ButtonStyle(
                                animationDuration: const Duration(microseconds: 100),
                                overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
                                foregroundColor: MaterialStateProperty.resolveWith<Color>(
                                        (Set<MaterialState> states) {
                                      if (states.contains(MaterialState.hovered))
                                        return Color(0xff01CAFF);

                                      return Colors.grey;
                                    }),
                              ),
                              onPressed: () {
                                currentMode = MODE_GROUPVIEW;

                                setState(() {});
                              },
                              child: const Text('옵션 그룹', style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                            ),
                            const Text('>', style: TextStyle(fontSize: 14, color: Colors.grey, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                            Text('  ${selectedGroupName}', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                          ],
                        ),
                        Responsive.isMobile(context) ? const SizedBox(width: 18,) : Container(),
                        ISButton(
                          child: const Text('옵션 추가'),
                          onPressed: () {
                            liveEventYn== 'Y'
                                ?
                            ISAlert(context, content: '라이브 이벤트 중에는 수정이 불가능합니다.')
                                :
                            showDialog(
                              context: context,
                              barrierDismissible: true,
                              builder: (context) => OptionListEdit(optionGroupCd: selectedGroupCd),
                            ).then((value) async {
                              if (value == true){
                                await Future.delayed(const Duration(milliseconds: 500), () {
                                  requestAPI_OptionData(selectedGroupCd!);
                                });
                              }
                            });
                          },
                        )
                      ],
                    ),
            ),
        ),
          ),
        ),
        const SizedBox(height: 4),
        if (currentMode == MODE_ITEMVIEW)
          Column(
            children: [
              Card(
              elevation: 0,
              color: const Color(0xFFf3f3f3),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                child: SingleChildScrollView(
                  scrollDirection: Responsive.isMobile(context) ? Axis.horizontal : Axis.vertical,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          width: 70,
                          height: 26,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4.0),
                              border: Border.all(color: Colors.cyan),
                          ),
                          child: const Text('옵션 수', textAlign: TextAlign.center, style: TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, fontSize: 12, color: Colors.cyan),)
                      ),
                      const SizedBox(width: 10,),
                      Text('최소 ${selectOptionGroup!.minCount}개, 최대 ${selectOptionGroup!.multiCount}개 선택 가능', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY),),
                      const SizedBox(width: 10,),
                      ISButton(
                        child: const Text('변경'),
                        onPressed: () {
                          liveEventYn== 'Y'
                              ?
                          ISAlert(context, content: '라이브 이벤트 중에는 수정이 불가능합니다.')
                              :
                          showDialog(
                            context: context,
                            barrierDismissible: true,
                            builder: (context) => OptionCountSetting(optGrpCd: selectedGroupCd, optionCnt: optionTotalCnt, minCnt: selectOptionGroup!.minCount, maxCnt: selectOptionGroup!.multiCount, multiYn: selectOptionGroup!.multiYn, reqYn: selectOptionGroup!.reqYn),
                          ).then((value) async {
                            if (value == true){
                              await Future.delayed(const Duration(milliseconds: 500), () {
                                //requestAPI_OptionData(selectedGroupCd!);
                                requestAPI_OptionGroupData();
                              });
                            }
                          });
                        },
                      )
                    ],
                  ),
                ),
              ),
              ),
              Card(
                elevation: 0,
                color: const Color(0xFFf3f3f3),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SingleChildScrollView(
                        scrollDirection: Responsive.isMobile(context) ? Axis.horizontal : Axis.vertical,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                                width: 70,
                                height: 26,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.0),
                                  border: Border.all(color: Colors.cyan),
                                ),
                                child: const Text('연결 메뉴', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: Colors.cyan),)
                            ),
                            const SizedBox(width: 10,),
                            const Text('수정 시 동시 적용됩니다.', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY),),
                              const SizedBox(width: 10,),
                              ISButton(
                                child: const Text('메뉴 연결'),
                                onPressed: () {
                                  liveEventYn== 'Y'
                                      ?
                                  ISAlert(context, content: '라이브 이벤트 중에는 수정이 불가능합니다.')
                                      :
                                  showDialog(
                                    context: context,
                                    barrierDismissible: true,
                                    builder: (context) => OptionGroupMenuLinkEdit(optGrpName: selectOptionGroup!.optGrpName, optGrpCd: selectOptionGroup!.optGrpCd),
                                  ).then((value) async {
                                    if (value == true){
                                      await Future.delayed(const Duration(milliseconds: 500), () {
                                        requestAPI_OptionGroupData();
                                      });
                                    }
                                  });
                                },
                              ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(selectOptionGroup!.menuNames!, style: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD, color: Colors.black54),),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 4),
            ],
          ),

        currentMode == MODE_GROUPVIEW ? groupListView() : itemListView(),

        const Divider(height: 1)
      ],
    );
  }

  void _onGroupListReorder(int oldIndex, int newIndex) {
    // 라이브 이벤트 진행중일때 리턴
    //if (widget.eventYn == 'Y') return;

    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final OptionGroupListModel item = dataGroupList.removeAt(oldIndex);
      dataGroupList.insert(newIndex, item);

      List<String> sortDataList = [];
      dataGroupList.forEach((element) {
        sortDataList.add(element.optGrpCd!);
      });

      _editListSort('1', sortDataList);
    });
  }

  _editListSort(String div, List<String> sortDataList) async {
    String jsonData = jsonEncode(sortDataList);

    await MenuInfoController.to.updateListSort(div, jsonData);

    await Future.delayed(const Duration(milliseconds: 500), () {
      if (div == '1')
        requestAPI_OptionGroupData();
      else if (div == '3')
        requestAPI_OptionData(selectedGroupCd!);
    });
  }

  void _onItemListReorder(int oldIndex, int newIndex) {
    // 라이브 이벤트 진행중일때 리턴
    //if (widget.eventYn == 'Y') return;

    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final OptionListModel item = dataItemList.removeAt(oldIndex);
      dataItemList.insert(newIndex, item);

      List<String> sortDataList = [];
      dataItemList.forEach((element) {
        sortDataList.add(element.optionCd!);
      });

      _editListSort('3', sortDataList);
    });
  }

  Widget groupListView() {
    final appTheme = context.watch<AppTheme>();

    return SizedBox(
      height: widget.tabviewHeight! - 91,
      child: ReorderableListView(
        buildDefaultDragHandles: false,
        scrollController: ScrollController(),
        onReorder: _onGroupListReorder,
        scrollDirection: Axis.vertical,
        padding: const EdgeInsets.only(bottom: 8.0),

        children: List.generate(dataGroupList.length, (index) {
          return Card(
            key: Key('$index'),
            elevation: 1,
            shape: appTheme.cardShapStyle,
            margin: const EdgeInsets.all(4),
            //color: dataGroupList[index].selected == true ? const Color.fromRGBO(165, 216, 252, 1.0) : Colors.white,
            child: InkWell(
              splashColor: const Color.fromRGBO(165, 216, 252, 1.0),
              onTap: () {
                for (var element in dataGroupList) {
                  element.selected = false;
                }

                dataGroupList[index].selected = true;
                selectedGroupName = dataGroupList[index].optGrpName!;
                selectedGroupCd = dataGroupList[index].optGrpCd!;

                selectOptionGroup = dataGroupList.elementAt(index);

                currentMode = MODE_ITEMVIEW;

                requestAPI_OptionData(dataGroupList[index].optGrpCd!);
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: ReorderableDragStartListener(
                          index: index,
                          child: const Icon(Icons.reorder, color: Colors.grey, size: 24.0,)
                      ),
                    ),
                    const SizedBox(width: 8,),
                    Flexible(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              children: [
                                dataGroupList[index].useYn == 'Y'
                                    ? Container(
                                    width: 36,
                                    height: 18,
                                    alignment: Alignment.center,
                                    decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                    child: const Center(
                                        child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                        ))
                                ) : Container(
                                    width: 36,
                                    height: 18,
                                    alignment: Alignment.center,
                                    decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                    child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                ),
                                dataGroupList[index].reqYn == 'Y'
                                    ? Container(
                                  width: 26,
                                  height: 18,
                                  margin: const EdgeInsets.only(left: 2.0),
                                  alignment: Alignment.center,
                                  decoration: AppTheme.getListBadgeDecoration(Colors.blueAccent.shade100),
                                  child: const Center(child: Text('필수', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                  ),
                                ) : const SizedBox.shrink(),
                              ],
                            ),
                            const SizedBox(height: 5),
                            Text(dataGroupList[index].optGrpName ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY ),),
                            Text(dataGroupList[index].optNames ?? '--', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                            const SizedBox(height: 8,),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    width: 48,
                                    height: 16,
                                    alignment: Alignment.center,
                                    padding: const EdgeInsets.only(bottom: 1),
                                    decoration: BoxDecoration(
                                        border: Border.all(color: Colors.black54, width: 0.5),
                                        borderRadius: BorderRadius.circular(6)
                                    ),
                                    child: const Text('옵션 수', style: TextStyle(fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54),)
                                ),
                                const SizedBox(width: 8,),
                                Expanded(
                                    child: Text('(최소) ${dataGroupList[index].minCount} ~ (최대) ${dataGroupList[index].multiCount}', style: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54)))
                              ],
                            ),
                            const SizedBox(height: 4,),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    width: 48,
                                    height: 18,
                                    alignment: Alignment.center,
                                    padding: const EdgeInsets.only(bottom: 1),
                                    decoration: BoxDecoration(
                                      border: Border.all(color: Colors.black45, width: 0.5),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: const Text('연결 메뉴', style: TextStyle(fontSize: 10, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54),)
                                ),
                                const SizedBox(width: 8,),
                                Expanded(child: Text('${dataGroupList[index].menuNames}', style: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, color: Colors.black54)))
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(0, 0, Responsive.isMobile(context) ? 10 :  30 , 0),
                      child: IconButton(
                        icon: const Icon(Icons.more_horiz, size: 20),
                        color: Colors.black,
                        tooltip: '수정',
                        onPressed: () {
                          List<String> values = ['옵션 그룹 수정', '메뉴 연결', '옵션 그룹 삭제'];

                          liveEventYn== 'Y'
                              ?
                          ISAlert(context, content: '라이브 이벤트 중에는 수정이 불가능합니다.')
                              :
                          ISOptionDialog(context, const BoxConstraints(maxWidth: 360.0, maxHeight: 232), dataGroupList[index].optGrpName!, values, (context, selectIdx) async {
                            Navigator.of(context).pop();

                            if (selectIdx == 0){
                              showDialog(
                                context: context,
                                barrierDismissible: true,
                                builder: (context) => OptionGroupEdit(sData: dataGroupList.elementAt(index)),
                              ).then((value) async {
                                if (value == true){
                                  await Future.delayed(const Duration(milliseconds: 500), () {
                                    requestAPI_OptionGroupData();
                                  });
                                }
                              });
                            }
                            else if (selectIdx == 1){
                              showDialog(
                                context: context,
                                barrierDismissible: true,
                                builder: (context) => OptionGroupMenuLinkEdit(optGrpName: dataGroupList[index].optGrpName!, optGrpCd: dataGroupList[index].optGrpCd),
                              ).then((value) async {
                                if (value == true){
                                  await Future.delayed(const Duration(milliseconds: 500), () {
                                    requestAPI_OptionGroupData();
                                  });
                                }
                              });
                            }
                            else if (selectIdx == 2){
                              ISConfirm(context, '삭제', '[${dataGroupList[index].optGrpName!}] 옵션 그룹을 삭제합니다. \n\n계속 진행하시겠습니까?', (context, isOK) async {
                                Navigator.pop(context);

                                if (isOK){
                                  var value = await showDialog(
                                      context: context,
                                      builder: (context) => FutureProgressDialog(MenuInfoController.to.deleteOptionGroup(dataGroupList[index].optGrpCd!))
                                  );

                                  if (value == null) {
                                    ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                  }
                                  else {
                                    if (value == '00') {
                                      requestAPI_OptionGroupData();
                                    }
                                    else{
                                      ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                    }
                                  }
                                }
                              });
                            }
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
        ),
      ),
    );
  }

  Widget itemListView() {
    final appTheme = context.watch<AppTheme>();

    return SizedBox(
      height: Responsive.isMobile(context) ? widget.tabviewHeight! - 304 : widget.tabviewHeight! - 221,
      child: ReorderableListView(
        buildDefaultDragHandles: false,
        scrollController: ScrollController(),
        onReorder: _onItemListReorder,
        scrollDirection: Axis.vertical,
        padding: const EdgeInsets.only(bottom: 8.0),

        children: List.generate(dataItemList.length, (index) {
          return Card(
            key: Key('$index'),
            elevation: 1,
            shape: appTheme.cardShapStyle,
            margin: const EdgeInsets.all(4),
            //color: dataMenuList[index].selected == true ? const Color.fromRGBO(165, 216, 252, 1.0) : Colors.white,
            child: InkWell(
              splashColor: const Color.fromRGBO(165, 216, 252, 1.0),
              onTap: () {
                for (var element in dataItemList) {
                  element.selected = false;
                }

                // _menuGroupCd = dataGroupList[index].menuGroupCd;
                //
                // ShopController.to.MainCount.value = int.parse(dataGroupList[index].mainCount);
                //
                dataItemList[index].selected = true;
                //
                // loadMenuListData(dataGroupList[index].menuGroupCd, menuGroupName: dataGroupList[index].menuGroupName);
                setState(() {});
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: ReorderableDragStartListener(
                          index: index,
                          child: Icon(Icons.reorder, color: Colors.grey, size: 24.0,)
                      ),
                    ),
                    const SizedBox(width: 4,),
                    Flexible(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                Row(
                                  children: [
                                    dataItemList[index].useYn == 'Y'
                                        ? Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                        child: const Center(
                                            child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                            ))
                                    ) : Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                        child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                    ),
                                    dataItemList[index].noFlag == 'Y'
                                        ? Container(
                                        width: 26,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.redAccent.shade100),
                                        child: const Center(child: Text('품절', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                    dataItemList[index].adultOnly == 'Y'
                                        ? Container(
                                      width: 26,
                                      height: 18,
                                      margin: const EdgeInsets.only(left: 2.0),
                                      alignment: Alignment.center,
                                      decoration: AppTheme.getListBadgeDecoration(Colors.red),
                                      child: const Center(child: Text('성인', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)),
                                    ) : const SizedBox.shrink(),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: Text(dataItemList[index].optionName ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY)),
                                ),
                              ],
                            ),
                            Text('${Utils.getCashComma(dataItemList[index].cost!)} 원', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                        padding: EdgeInsets.fromLTRB(0, 0, Responsive.isMobile(context) ? 10 :  30 , 0),
                        child: IconButton(
                          icon: const Icon(Icons.more_horiz, size: 20),
                          color: Colors.black,
                          tooltip: '수정',
                          onPressed: () {
                            List<String> values = ['옵션 및 가격 변경', '옵션 품절', '옵션 삭제'];

                            liveEventYn== 'Y'
                                ?
                            ISAlert(context, content: '라이브 이벤트 중에는 수정이 불가능합니다.')
                                :
                            ISOptionDialog(context, const BoxConstraints(maxWidth: 360.0, maxHeight: 232), dataItemList[index].optionName!, values, (context, selectIdx) async {
                              Navigator.of(context).pop();

                              if (selectIdx == 0){
                                showDialog(
                                  context: context,
                                  barrierDismissible: true,
                                  builder: (context) => OptionListEdit(sData: dataItemList.elementAt(index)),
                                ).then((value) async {
                                  if (value == true){
                                    await Future.delayed(const Duration(milliseconds: 500), () {
                                      requestAPI_OptionData(selectedGroupCd!);
                                    });
                                  }
                                });
                              }
                              else if (selectIdx == 1){
                                showDialog(
                                  context: context,
                                  barrierDismissible: true,
                                  builder: (context) => CommonNoFlagEdit(jobGbn: 'D', subGbn: 'O', targetCd: dataItemList[index].optionCd, noFlag: dataItemList[index].noFlag),
                                ).then((value) async {
                                  if (value == true){
                                    await Future.delayed(const Duration(milliseconds: 500), () {
                                      requestAPI_OptionData(selectedGroupCd!);
                                    });
                                  }
                                });
                              }
                              else if (selectIdx == 2){
                                ISConfirm(context, '삭제', '[${dataItemList[index].optionName!}] 옵션을 삭제합니다. \n\n계속 진행하시겠습니까?', (context, isOK) async {
                                  Navigator.pop(context);

                                  if (isOK){
                                    var value = await showDialog(
                                        context: context,
                                        builder: (context) => FutureProgressDialog(MenuInfoController.to.deleteOption(dataItemList[index].optionCd!))
                                    );

                                    if (value == null) {
                                      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                    }
                                    else {
                                      if (value == '00') {
                                        requestAPI_OptionData(selectedGroupCd!);
                                      }
                                      else{
                                        ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                      }
                                    }
                                  }
                                });
                              }
                            });
                          },

                        )
                    ),
                  ],
                ),
              ),
            ),
          );
        },
        ),
      ),
    );
  }
}