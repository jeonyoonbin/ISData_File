import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';

class UserGuideInfoMain extends StatefulWidget {
  const UserGuideInfoMain({Key? key}) : super(key: key);

  @override
  State<UserGuideInfoMain> createState() => _UserGuideInfoMainState();
}

class _UserGuideInfoMainState extends State<UserGuideInfoMain> with PageMixin{

  String youtubeIcon = '1';
  String pdfIcon = '2';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    return fluentUI.ScaffoldPage.scrollable(
      //scrollController: AppTheme.mainScrollController,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      children: <Widget>[
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ISLabelBarMain(
              leading: Text('이용자 가이드', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
            ),

            Padding(
              padding: EdgeInsets.symmetric(vertical: 40.0, horizontal: Responsive.isMobile(context) ? 10 : 40),
              child: Responsive.isMobile(context) ?Column(
                children: [
                  userGuideForm('대구로 사장님사이트', '대구로에서 제공하는 사장님 사이트 가이드를 안내합니다.','https://owner.daeguro.co.kr/down/신사싸매뉴얼_세로 버전_자주묻는질문.pdf','- 사장님 사이트 자주 묻는 질문 TOP6', pdfIcon, 'https://owner.daeguro.co.kr/down/신사싸매뉴얼_세로 버전_통합본.pdf', '- 사장님 사이트 가이드(통합 VER)', pdfIcon ),
                  Divider(height: 25,),
                  userGuideForm('대구로 POS', '대구로에서 제공하는 POS 가이드를 안내합니다.','https://youtu.be/l-FGza-kTbA', '- POS 가이드(유튜브)', pdfIcon, 'https://pos.daeguro.co.kr:15421/filedown/Support/대구로 POS 메뉴얼.pdf', '- POS 가이드(문서)', youtubeIcon ),
                ],
              ) : Row(
                children: [
                  Flexible(flex: 3, child: userGuideForm('대구로 사장님사이트', '대구로에서 제공하는 사장님 사이트 가이드를 안내합니다.','https://owner.daeguro.co.kr/down/신사싸매뉴얼_세로 버전_자주묻는질문.pdf', '- 사장님 사이트 자주 묻는 질문 TOP6', pdfIcon, 'https://owner.daeguro.co.kr/down/신사싸매뉴얼_세로 버전_통합본.pdf', '- 사장님 사이트 가이드(통합 VER)', pdfIcon )),
                  Flexible(flex: 3, child: userGuideForm('대구로 POS', '대구로에서 제공하는 POS 가이드를 안내합니다.','https://youtu.be/l-FGza-kTbA', '- POS 가이드(유튜브)', youtubeIcon, 'https://pos.daeguro.co.kr:15421/filedown/Support/대구로 POS 메뉴얼.pdf', '- POS 가이드(문서)', pdfIcon )),
                ],
              ),
            ),


            //const Divider(height: 1)
          ],
        ),
        //const SizedBox(height: 22.0),
      ],
    );
  }

  Widget userGuideForm(title1, subTitle, url, urlTitle, icon1, url2, urlTitle2, icon2 ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title1, style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
        const SizedBox(height: 8,),
        Text(subTitle, style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_NORMAL)),
        const SizedBox(height: 20,),
        TextButton(
          style: ButtonStyle(
            animationDuration: const Duration(microseconds: 100),
            overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
            foregroundColor: MaterialStateProperty.resolveWith<Color>(
                    (Set<MaterialState> states) {
                  if (states.contains(MaterialState.hovered))
                    return Color(0xff01CAFF);
                  return Colors.black;//Colors.white;
                }),
          ),
          onPressed: () {
            Utils.launchURL(url);
          },
          child: Row(
            children: [
              Text(urlTitle, style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
              SizedBox(width: 8,),
              icon1 == '1'
                  ?
              Image(image: AssetImage('images/youtube_icon.png'), width: 22, height: 22,)
                  :
              Image(image: AssetImage('images/pdf_icon.png'), width: 28, height: 28,),
              //Image.asset('images/youtube_icon.png', width: 22, height: 22,),
            ],
          ),
        ),
        TextButton(
          style: ButtonStyle(
            animationDuration: const Duration(microseconds: 100),
            overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
            foregroundColor: MaterialStateProperty.resolveWith<Color>(
                    (Set<MaterialState> states) {
                  if (states.contains(MaterialState.hovered))
                    return Color(0xff01CAFF);
                  return Colors.black;//Colors.white;
                }),
          ),
          onPressed: () {
            Utils.launchURL(url2);
          },
          child: Row(
            children: [
              Text(urlTitle2, style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD)),
              SizedBox(width: 8,),
              icon2 == '1'
                  ?
              Image(image: AssetImage('images/youtube_icon.png'), width: 22, height: 22,)
                  :
              Image(image: AssetImage('images/pdf_icon.png'), width: 28, height: 28,),
            ],
          ),
        ),
      ],
    );
  }

  requestAPIData() async {
  }
}