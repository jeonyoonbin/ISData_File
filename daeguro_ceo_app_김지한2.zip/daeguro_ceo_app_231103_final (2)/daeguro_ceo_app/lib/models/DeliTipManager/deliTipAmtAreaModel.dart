import 'package:daeguro_ceo_app/models/LiveEventManager/liveeventMenuListEditModel.dart';

class DeliTipAmtAreaModel {
  DeliTipAmtAreaModel();

  String? gungu = '';
  String? dong = '';
}
