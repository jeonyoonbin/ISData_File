import 'package:json_annotation/json_annotation.dart';

import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class DeliTipSectorEditModel {
  DeliTipSectorEditModel();

  String? jobGbn;
  String? shopCd;
  String? sido;
  String? gungu;
  List<String>? dong;
  String? uCode;
  String? uName;

  factory DeliTipSectorEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

DeliTipSectorEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return DeliTipSectorEditModel()
    ..jobGbn = json['jobGbn']
    ..shopCd = json['shopCd']
    ..sido = json['sido']
    ..gungu = json['gungu']
    ..dong = json['dong'].cast<String>()
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(DeliTipSectorEditModel instance) =>
    <String, dynamic>{
      'jobGbn': instance.jobGbn,
      'shopCd': instance.shopCd,
      'sido': instance.sido,
      'gungu': instance.gungu,
      'dong': instance.dong,
      'uCode': instance.uCode,
      'uName': instance.uName
    };