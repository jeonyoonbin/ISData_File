import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveMagamModel {
  ReserveMagamModel();

  bool? selected = false;
  String? shopCode;
  String? userId;
  String? reserMagamGbn;

  factory ReserveMagamModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveMagamModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveMagamModel()
    ..shopCode = json['shopCode'] as String
    ..userId = json['userId'] as String
    ..reserMagamGbn = json['reserMagamGbn'] as String;

}

Map<String, dynamic> _$ModelToJson(ReserveMagamModel instance) => <String, dynamic>{
  'shopCode': instance.shopCode,
  'userId': instance.userId,
  'reserMagamGbn': instance.reserMagamGbn
};