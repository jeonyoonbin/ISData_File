import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class MultiShopStatusListModel {
  MultiShopStatusListModel();

  String? shopCd;
  String? shopName;
  String? itemCd;
  String? itemCd2;
  String? itemCd3;
  String? absentYn;
  String? repYn;

  List<String>? itemList = [];
}
