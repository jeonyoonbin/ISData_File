import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OrderListModel {
  OrderListModel();

  bool? selected = false;
  String? rNum = '';
  String? orderNo = '';
  String? orderTime = '';
  String? statusName = '';
  String? packOrderName = '';
  String? totAmt = '';
  String? appPayGbn = '';
  String? payGbn = '';
  String? custDongAddr = '';

}