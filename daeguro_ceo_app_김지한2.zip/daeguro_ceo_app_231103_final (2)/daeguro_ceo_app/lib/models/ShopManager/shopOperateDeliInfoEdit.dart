import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopOperateDeliInfoEditModel {
  ShopOperateDeliInfoEditModel();

  bool? selected = false;
  String? jobGbn;
  String? shopCd;
  List<String>? deliNoticeCd;
  List<String>? title;
  List<String>? content;
  String? uCode;
  String? uName;

  factory ShopOperateDeliInfoEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopOperateDeliInfoEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopOperateDeliInfoEditModel()
    ..jobGbn = json['jobGbn'] as String
    ..shopCd = json['shopCd'] as String
    ..deliNoticeCd = json['deliNoticeCd'].cast<String>()
    ..title = json['title'].cast<String>()
    ..content = json['content'].cast<String>()
    ..uCode = json['uCode'] as String
    ..uName = json['uName'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopOperateDeliInfoEditModel instance) => <String, dynamic>{
  'jobGbn': instance.jobGbn,
  'shopCd': instance.shopCd,
  'deliNoticeCd': instance.deliNoticeCd,
  'title': instance.title,
  'content': instance.content,
  'uCode': instance.uCode,
  'uName': instance.uName
};