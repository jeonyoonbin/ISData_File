import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopProductDeliInfoModel {
  ShopProductDeliInfoModel();

  bool? selected = false;
  String? deliNoticeCode;
  String? title = '';
  String? content = '';
  String? sortSeq;
}