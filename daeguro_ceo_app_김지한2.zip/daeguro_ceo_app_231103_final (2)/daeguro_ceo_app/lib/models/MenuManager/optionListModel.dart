import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionListModel {
  OptionListModel();

  bool selected = false;
  String? optionCd;
  String? optionName;
  String? optionMemo;
  String? menuFileName;
  String? cost;
  String? useYn;
  String? noFlag;
  String? adultOnly;

  factory OptionListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

OptionListModel _$ModelFromJson(Map<String, dynamic> json) {
  return OptionListModel()
  // ..selected = json['selected'] as bool
    ..optionCd = json['optionCd'] as String
    ..optionName = json['optionName'] as String
    ..optionMemo = json['optionMemo'] as String
    ..menuFileName = json['menuFileName'] as String
    ..cost = json['cost'] as String
    ..useYn = json['useYn'] as String
    ..noFlag = json['noFlag'] as String
    ..adultOnly = json['adultOnly'] as String? ?? '';
}

Map<String, dynamic> _$ModelToJson(OptionListModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'optionCd': instance.optionCd,
      'optionName': instance.optionName,
      'optionMemo': instance.optionMemo,
      'menuFileName': instance.menuFileName,
      'cost': instance.cost,
      'useYn': instance.useYn,
      'noFlag': instance.noFlag,
      'adultOnly': instance.adultOnly
    };
