import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOptionCountSettingModel {
  ProductOptionCountSettingModel();

  bool selected = false;
  String? shopCd;
  String? optionGroupCd;
  String? optionGroupName;
  String? optionGroupMemo;
  String? useYn;
  String? insertName;
  String minCount = '0';
  String maxCount = '0';
  String? multiYn;

  factory ProductOptionCountSettingModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ProductOptionCountSettingModel _$ModelFromJson(Map<String, dynamic> json) {
  return ProductOptionCountSettingModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd']
    ..optionGroupCd = json['optionGroupCd']
    ..optionGroupName = json['optionGroupName']
    ..optionGroupMemo = json['optionGroupMemo']
    ..useYn = json['useYn']
    ..insertName = json['insertName']
    ..minCount = json['minCount']
    ..maxCount = json['maxCount']
    ..multiYn = json['multiYn'];
}

Map<String, dynamic> _$ModelToJson(ProductOptionCountSettingModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'optionGroupCd': instance.optionGroupCd,
      'optionGroupName': instance.optionGroupName,
      'optionGroupMemo': instance.optionGroupMemo,
      'useYn': instance.useYn,
      'insertName': instance.insertName,
      'minCount': instance.minCount,
      'maxCount': instance.maxCount,
      'multiYn': instance.multiYn
    };
