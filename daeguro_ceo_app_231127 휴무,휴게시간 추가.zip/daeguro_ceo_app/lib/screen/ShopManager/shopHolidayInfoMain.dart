import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';

class ShopHolidayInfoMain extends StatefulWidget {
  final ScrollController? scrollController;
  const ShopHolidayInfoMain({Key? key, this.scrollController}) : super(key: key);

  @override
  State<ShopHolidayInfoMain> createState() => _ShopHolidayInfoMainState();
}

class _ShopHolidayInfoMainState extends State<ShopHolidayInfoMain> {

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {
    super.dispose();
    widget.scrollController?.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        //const Divider(color: Colors.black,),//fluentUI.Divider(style: fluentUI.DividerThemeData(horizontalMargin: EdgeInsets.zero)),
        Container(
          height: 300,
        ),
        const Divider(height: 1)
      ],
    );
  }

  requestAPIData() async {
  }
}

