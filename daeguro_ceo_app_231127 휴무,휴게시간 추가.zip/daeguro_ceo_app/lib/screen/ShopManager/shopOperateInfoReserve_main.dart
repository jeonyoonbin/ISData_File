import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateInfoReserveModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateInfoReserveTimeModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateReserveTimeModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateSetReserveTimeModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopReserveCasesPeopleModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopReserveDayOffModel.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopReserveBTimeEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopReserveCasePeopleEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopReserveDayOffEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopReserveFacilitiesEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopReserveSTimeEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopReviewUseEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopReviewUseEdit_reserve.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopOperateInfoReserveMain extends StatefulWidget {
  final double? tabviewHeight;

  const ShopOperateInfoReserveMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ShopOperateInfoReserveMain> createState() => _ShopOperateInfoMainState();
}

class _ShopOperateInfoMainState extends State<ShopOperateInfoReserveMain> {
  final ScrollController _scrollController = ScrollController();
  final ScrollController _scrollController2 = ScrollController();

  String _caseCnt = '0';
  String _peopleCnt = '0';

  List<ShopOperateReserveTimeModel> _setData = <ShopOperateReserveTimeModel>[];
  List<ShopOperateReserveTimeModel> _setCancelData = <ShopOperateReserveTimeModel>[];

  // 예약 가능 시간 바인딩
  List<ShopOperateReserveTimeModel> timeData_1_A = <ShopOperateReserveTimeModel>[]; // 일요일 오전
  List<ShopOperateReserveTimeModel> timeData_1_P = <ShopOperateReserveTimeModel>[]; // 일요일 오후
  List<ShopOperateReserveTimeModel> timeData_2_A = <ShopOperateReserveTimeModel>[]; // 월요일 오전
  List<ShopOperateReserveTimeModel> timeData_2_P = <ShopOperateReserveTimeModel>[]; // 월요일 오후
  List<ShopOperateReserveTimeModel> timeData_3_A = <ShopOperateReserveTimeModel>[]; // 화요일 오전
  List<ShopOperateReserveTimeModel> timeData_3_P = <ShopOperateReserveTimeModel>[]; // 화요일 오후
  List<ShopOperateReserveTimeModel> timeData_4_A = <ShopOperateReserveTimeModel>[]; // 수요일 오전
  List<ShopOperateReserveTimeModel> timeData_4_P = <ShopOperateReserveTimeModel>[]; // 수요일 오후
  List<ShopOperateReserveTimeModel> timeData_5_A = <ShopOperateReserveTimeModel>[]; // 목요일 오전
  List<ShopOperateReserveTimeModel> timeData_5_P = <ShopOperateReserveTimeModel>[]; // 목요일 오후
  List<ShopOperateReserveTimeModel> timeData_6_A = <ShopOperateReserveTimeModel>[]; // 금요일 오전
  List<ShopOperateReserveTimeModel> timeData_6_P = <ShopOperateReserveTimeModel>[]; // 금요일 오후
  List<ShopOperateReserveTimeModel> timeData_7_A = <ShopOperateReserveTimeModel>[]; // 토요일 오전
  List<ShopOperateReserveTimeModel> timeData_7_P = <ShopOperateReserveTimeModel>[]; // 토요일 오후

  static const int MODE_MAIN_VIEW = 1000;
  static const int MODE_RESERTIMESETTING_VIEW = 1010;

  int currentMode = MODE_MAIN_VIEW;

  List<ShopOperateInfoReserveTimeModel> shopOperateReserveTimeData = <ShopOperateInfoReserveTimeModel>[];

  ShopOperateInfoReserveModel reserveManageInfoData = ShopOperateInfoReserveModel();

  // 예약 영업시간, 휴게시간 리스트
  List<dynamic> s_time = [];
  List<dynamic> b_time = [];

  // 휴무일 리스트
  ShopReserveDayOffModel dayOff_1 = ShopReserveDayOffModel();
  String dayOff_1_foDay = '미적용';

  ShopReserveDayOffModel dayOff_3 = ShopReserveDayOffModel();
  List<dynamic> dayOff_3_data = [];

  ShopReserveDayOffModel dayOff_5 = ShopReserveDayOffModel();
  List<dynamic> dayOff_5_data = [];

  requestReserveManageInfo() async {
    await ReserveController.to.getShopInfoReserveManageInfo(AuthService.SHOPCD).then((value) {
      if (value == null) {
      } else {
        value.forEach((element) {
          ShopOperateInfoReserveModel temp = ShopOperateInfoReserveModel();

          temp.useGbn = element['useGbn'] as String;
          temp.reserveYn = element['reserveYn'] as String;
          temp.absentYn = element['absentYn'] as String;
          temp.shopFileName = element['shopFileName'] as String;
          temp.facilities_1 = element['facilities_1'] as String;
          temp.facilities_2 = element['facilities_2'] as String;
          temp.facilities_3 = element['facilities_3'] as String;
          temp.facilities_4 = element['facilities_4'] as String;
          temp.facilities_5 = element['facilities_5'] as String;
          temp.facilities_6 = element['facilities_6'] as String;
          temp.facilities_7 = element['facilities_7'] as String;
          temp.facilities_8 = element['facilities_8'] as String;
          temp.facilities_9 = element['facilities_9'] as String;
          temp.facilities_10 = element['facilities_10'] as String;
          temp.reviewUseGbn = element['reviewUseGbn'] as String;
          temp.sbTimeLists = element['sbTimeLists'] as List<dynamic>;

          reserveManageInfoData = temp;
        });

        s_time.clear();
        b_time.clear();

        // 영업시간, 휴게시간 바인딩
        reserveManageInfoData.sbTimeLists?.forEach((element) {
          if (element['sbGbn'] == 'S') {
            s_time.add(element);
          } else if (element['sbGbn'] == 'B') {
            b_time.add(element);
          }
        });
      }
    });

    setState(() {});
  }

  requestReserveTimeAPIData({bool? isRefresh = false}) async {
    await ReserveController.to.getShopInfoReserveTime(AuthService.SHOPCD).then((value) {
      if (value == null) {
      } else {
        shopOperateReserveTimeData.clear();

        value.forEach((element) {
          ShopOperateInfoReserveTimeModel temp = ShopOperateInfoReserveTimeModel();

          temp.dayGbn = element['dayGbn'] as String;
          temp.closeGbn = element['closeGbn'] as String;
          temp.reserTime?.add(element['reserTime']);

          shopOperateReserveTimeData.add(temp);
        });
      }
    });

    reserveTimeBinding('A');

    setState(() {});
  }

  // allGbn = 전체요일 조회 구분 ( A: 전체요일, 1:일요일, 2:월요일 .... 7:금요일 )
  reserveTimeBinding(String allGbn) {
    for (var element in shopOperateReserveTimeData) {
      // 일요일 오전, 오후 리스트 담기
      if (element.dayGbn == '1' && (allGbn == 'A' || allGbn == '1')) {
        timeData_1_A.clear();
        timeData_1_P.clear();

        for (var element2 in element.reserTime![0]) {
          ShopOperateReserveTimeModel tempData = ShopOperateReserveTimeModel();

          tempData.time = element2['time'] as String;
          tempData.gbn = element2['gbn'] as String;

          if (int.parse(element2['time']) < 1200) {
            timeData_1_A.add(tempData);
          } else {
            timeData_1_P.add(tempData);
          }
        }
      }

      if (element.dayGbn == '2' && (allGbn == 'A' || allGbn == '2')) {
        timeData_2_A.clear();
        timeData_2_P.clear();

        element.reserTime![0].forEach((element2) {
          ShopOperateReserveTimeModel tempData = ShopOperateReserveTimeModel();

          tempData.time = element2['time'] as String;
          tempData.gbn = element2['gbn'] as String;

          if (int.parse(element2['time']) < 1200) {
            timeData_2_A.add(tempData);
          } else {
            timeData_2_P.add(tempData);
          }
        });
      }

      if (element.dayGbn == '3' && (allGbn == 'A' || allGbn == '3')) {
        timeData_3_A.clear();
        timeData_3_P.clear();

        element.reserTime![0].forEach((element2) {
          ShopOperateReserveTimeModel tempData = ShopOperateReserveTimeModel();

          tempData.time = element2['time'] as String;
          tempData.gbn = element2['gbn'] as String;

          if (int.parse(element2['time']) < 1200) {
            timeData_3_A.add(tempData);
          } else {
            timeData_3_P.add(tempData);
          }
        });
      }

      if (element.dayGbn == '4' && (allGbn == 'A' || allGbn == '4')) {
        timeData_4_A.clear();
        timeData_4_P.clear();

        element.reserTime![0].forEach((element2) {
          ShopOperateReserveTimeModel tempData = ShopOperateReserveTimeModel();

          tempData.time = element2['time'] as String;
          tempData.gbn = element2['gbn'] as String;

          if (int.parse(element2['time']) < 1200) {
            timeData_4_A.add(tempData);
          } else {
            timeData_4_P.add(tempData);
          }
        });
      }

      if (element.dayGbn == '5' && (allGbn == 'A' || allGbn == '5')) {
        timeData_5_A.clear();
        timeData_5_P.clear();

        element.reserTime![0].forEach((element2) {
          ShopOperateReserveTimeModel tempData = ShopOperateReserveTimeModel();

          tempData.time = element2['time'] as String;
          tempData.gbn = element2['gbn'] as String;

          if (int.parse(element2['time']) < 1200) {
            timeData_5_A.add(tempData);
          } else {
            timeData_5_P.add(tempData);
          }
        });
      }

      if (element.dayGbn == '6' && (allGbn == 'A' || allGbn == '6')) {
        timeData_6_A.clear();
        timeData_6_P.clear();

        element.reserTime![0].forEach((element2) {
          ShopOperateReserveTimeModel tempData = ShopOperateReserveTimeModel();

          tempData.time = element2['time'] as String;
          tempData.gbn = element2['gbn'] as String;

          if (int.parse(element2['time']) < 1200) {
            timeData_6_A.add(tempData);
          } else {
            timeData_6_P.add(tempData);
          }
        });
      }

      if (element.dayGbn == '7' && (allGbn == 'A' || allGbn == '7')) {
        timeData_7_A.clear();
        timeData_7_P.clear();

        element.reserTime![0].forEach((element2) {
          ShopOperateReserveTimeModel tempData = ShopOperateReserveTimeModel();

          tempData.time = element2['time'] as String;
          tempData.gbn = element2['gbn'] as String;

          if (int.parse(element2['time']) < 1200) {
            timeData_7_A.add(tempData);
          } else {
            timeData_7_P.add(tempData);
          }
        });
      }
    }
  }

  requestReserveCasesPeopleAPIData({bool? isRefresh = false}) async {
    await ReserveController.to.getShopInfoReserveCasePeople(AuthService.SHOPCD).then((value) {
      if (value == null) {
      } else {
        _caseCnt = value[0]['casesCnt'].toString();
        _peopleCnt = value[0]['peopleCnt'].toString();
      }
    });

    setState(() {});
  }

  postReserveTime(List<ShopOperateReserveTimeModel> setData) async {
    if (setData.length == 0) return;

    ShopOperateSetReserveTimeModel sendData = ShopOperateSetReserveTimeModel();
    sendData.shopCode = AuthService.SHOPCD;
    sendData.userId = AuthService.uCode;
    sendData.reserTimePostUnits = setData;

    var value = await showDialog(context: context, barrierColor: Colors.transparent, builder: (context) => FutureProgressDialog(ReserveController.to.setReserTime(sendData.toJson())));

    if (value == null) {
      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    } else {
      if (value == '00') {
      } else {
        ISAlert(context, content: '정상 등록되지 않았습니다.\n→ $value ');
      }
    }
  }

  postReserveTimeCancel(List<ShopOperateReserveTimeModel> setData) async {
    if (setData.length == 0) return;

    ShopOperateSetReserveTimeModel sendData = ShopOperateSetReserveTimeModel();
    sendData.shopCode = AuthService.SHOPCD;
    sendData.userId = AuthService.uCode;
    sendData.reserTimePostUnits = setData;

    var value = await showDialog(context: context, barrierColor: Colors.transparent, builder: (context) => FutureProgressDialog(ReserveController.to.setReserTimeCancel(sendData.toJson())));

    if (value == null) {
      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    } else {
      if (value == '00') {
      } else {
        ISAlert(context, content: '정상 등록되지 않았습니다.\n→ $value ');
      }
    }
  }

  requestReservedayOffAPIData(String gbn) async {
    await ReserveController.to.getShopInfoReserveDayOff(AuthService.SHOPCD, gbn).then((value) {
      if (value == null) {
      } else {
        if (gbn == '1') {
          dayOff_1.list = value['list'];

          dayOff_1.list?.forEach((element) {
            if(element['foDay'] == 'Y') {
              dayOff_1_foDay = '적용';
            } else {
              dayOff_1_foDay = '미적용';
            }
          });
        } else if (gbn == '3') {
          dayOff_3.list = value['list'];
          dayOff_3.list?.forEach((element) {
            dayOff_3_data.add(element);
          });
        } else if (gbn == '5') {
          dayOff_5.list = value['list'];
          dayOff_5.list?.forEach((element) {
            dayOff_5_data.add(element);
          });
        }
      }
    });

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());
    Get.put(ReserveController());
    Get.put(RequestController());

    WidgetsBinding.instance.addPostFrameCallback((c) async {
      requestReservedayOffAPIData('1');
      requestReservedayOffAPIData('3');
      requestReservedayOffAPIData('5');
      requestReserveManageInfo();
      requestReserveTimeAPIData();
      requestReserveCasesPeopleAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
    _scrollController2.dispose();

    _setData.clear();
    _setCancelData.clear();
    timeData_1_A.clear();
    timeData_1_P.clear();
    timeData_2_A.clear();
    timeData_2_P.clear();
    timeData_3_A.clear();
    timeData_3_P.clear();
    timeData_4_A.clear();
    timeData_4_P.clear();
    timeData_5_A.clear();
    timeData_5_P.clear();
    timeData_6_A.clear();
    timeData_6_P.clear();
    timeData_7_A.clear();
    timeData_7_P.clear();
    shopOperateReserveTimeData.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefreshChild == true) {
        _appTheme.ShopRefreshChild = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestReserveManageInfo();
          requestReserveTimeAPIData();
          requestReserveCasesPeopleAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(controller: _scrollController, child: currentModeView());
  }

  Widget currentModeView() {
    Widget? tempWidget;
    if (currentMode == MODE_MAIN_VIEW) {
      tempWidget = mainInfoView();
    }
    else if (currentMode == MODE_RESERTIMESETTING_VIEW) {
      tempWidget = reserveTimeSetWidget();
    }
    //else if (currentMode == MODE_KINDSHOP_VIEW)          {       tempWidget = KindShopView();   }

    return tempWidget!;
  }

  Widget mainInfoView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ISLabelBarSub(
          title: '영업 상태(예약)',
          bodyPadding: const EdgeInsets.only(top: 15, bottom: 15, right: 32, left: 0),
          body: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                flex: 1,
                fit: FlexFit.tight,
                child: Container(
                  //color: Colors.yellow,
                    alignment: Alignment.center,
                    child: Text(
                      getShopStatusStr(reserveManageInfoData.absentYn),
                      style: TextStyle(color: reserveManageInfoData.absentYn == 'Y' ? Colors.blue : Colors.red, fontSize: 26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),
                    )),
              ),
              Flexible(
                flex: 2,
                child: Container(
                  //width: MediaQuery.of(context).size.width - 500,//double.infinity,
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: Responsive.isMobile(context) ? 10 : 30),
                  decoration: const BoxDecoration(color: Color.fromARGB(255, 240, 240, 240), borderRadius: BorderRadius.all(Radius.circular(10))),
                  // height: 35,
                  child: const Text(
                    '· 영업 상태가 휴점 중일 경우와 요일별 정기 영업시간에 해당하는 시간이 아닐 경우,\n    “지금은 운영시간이 아니에요.“라는 문구 고객에게 안내.\n· 고객이 상품을 장바구니까지 담는 건 가능함.\n· 장바구니에서 “지금은 배달이 어려워요. 운영 시간에 다시 찾아주세요” 문구 고객에게 안내.',
                    style: TextStyle(fontSize: 12, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                  ),
                ),
              )
            ],
          ),
        ),
        ISLabelBarSub(
          title: '영업시간',
          body: Container(
            alignment: Alignment.centerLeft,
            width: double.infinity,
            child: Column(
                children: List.generate(s_time.length, (index) {
                  return s_time[index]['closeGbn'].toString() == 'Y'
                      ? const SizedBox.shrink()
                      : Container(
                      margin: EdgeInsets.only(bottom: 5),
                      child: Text('[' + _dayGbn(s_time[index]['dayGbn']) + '] ' + _timeSet(s_time[index]['openTime']) + ' ~ ' + _timeSet(s_time[index]['closeTime']),
                        style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: _dayColor(s_time[index]['dayGbn'])),
                      ));
                })),
          ),
          trailing: ISButton(
            child: const Text('변경'),
            onPressed: () {
              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => ShopReserveSTimeEdit(s_time: s_time),
              ).then((value) async {
                //if (value == true) {
                await Future.delayed(const Duration(milliseconds: 500), () {
                  requestReserveManageInfo();
                });
                //}
              });
              // currentMode = MODE_REVIEWUSE_VIEW;
              //
              // setState(() {
              //   _scrollController!.jumpTo(0.0);
              // });
            },
          ),
        ),
        ISLabelBarSub(
          title: '휴게시간(브레이크 타임)',
          body: Container(
            alignment: Alignment.centerLeft,
            width: double.infinity,
            child: Column(
                children: List.generate(b_time.length, (index) {
                  return b_time[index]['closeGbn'].toString() == 'Y'
                      ? const SizedBox.shrink()
                      : Container(
                      margin: EdgeInsets.only(bottom: 5),
                      child: Text('[' + _dayGbn(b_time[index]['dayGbn']) + '] ' + _timeSet(b_time[index]['openTime']) + ' ~ ' + _timeSet(b_time[index]['closeTime']), style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: _dayColor(b_time[index]['dayGbn']))));
                })),
          ),
          trailing: ISButton(
            child: const Text('변경'),
            onPressed: () {
              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => ShopReserveBTimeEdit(b_time: b_time),
              ).then((value) async {
                //if (value == true) {
                await Future.delayed(const Duration(milliseconds: 500), () {
                  requestReserveManageInfo();
                });
                //}
              });
              // currentMode = MODE_REVIEWUSE_VIEW;
              //
              // setState(() {
              //   _scrollController!.jumpTo(0.0);
              // });
            },
          ),
        ),
        ISLabelBarSub(
          title: '휴무일',
          body: Container(
            alignment: Alignment.centerLeft,
            width: double.infinity,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('공휴일', style: TextStyle(fontWeight: FONT_BOLD)),
                SizedBox(height: 5),
                Text(dayOff_1_foDay, style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,),),
                Divider(),
                Text('정기 휴무일', style: TextStyle(fontWeight: FONT_BOLD)),
                SizedBox(height: 5),
                Column(
                    children: List.generate(dayOff_3.list!.length, (index) {
                      return Row(
                        children: [
                          SizedBox(width: 100, child: Text(convertFoDay(dayOff_3.list![index]['foDay'].toString()), style: TextStyle(fontWeight: FONT_BOLD))),
                          SizedBox(width: 10),
                          Text(convertToDay(dayOff_3.list![index]['toDay'].toString()), style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,),),
                        ],
                      );
                    })),
                Divider(),
                Text('임시 휴무일', style: TextStyle(fontWeight: FONT_BOLD)),
                SizedBox(height: 5),
                Column(
                    children: List.generate(dayOff_5.list!.length, (index) {
                      return Row(
                        children: [
                          Text(Utils.getYearMonthDayFormat(dayOff_5.list![index]['foDay'].toString()), style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,),),
                          Text(' ~ '),
                          Text(Utils.getYearMonthDayFormat(dayOff_5.list![index]['toDay'].toString()), style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,),),
                        ],
                      );
                    })),
              ],
            ),
          ),
          trailing: ISButton(
            child: const Text('변경'),
            onPressed: () {
              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => ShopReserveDayOffEdit(sData_1: dayOff_1, sData_3: dayOff_3, sData_5: dayOff_5),
              ).then((value) async {
                requestReservedayOffAPIData('1');
                requestReservedayOffAPIData('3');
                requestReservedayOffAPIData('5');
              });
            },
          ),
        ),
        ISLabelBarSub(
          title: '편의시설',
          body: Container(
            alignment: Alignment.centerLeft,
            width: double.infinity,
            child: Wrap(
              children: [
                Container(margin: EdgeInsets.only(right: 15), child: Text('#주차가능', style: TextStyle(color: reserveManageInfoData.facilities_1.toString() == 'Y' ? Colors.black : Colors.grey, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,))),
                Container(margin: EdgeInsets.only(right: 15), child: Text('#발렛가능', style: TextStyle(color: reserveManageInfoData.facilities_2.toString() == 'Y' ? Colors.black : Colors.grey, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,))),
                Container(margin: EdgeInsets.only(right: 15), child: Text('#단체석', style: TextStyle(color: reserveManageInfoData.facilities_3.toString() == 'Y' ? Colors.black : Colors.grey, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,))),
                Container(margin: EdgeInsets.only(right: 15), child: Text('#프라이빗룸', style: TextStyle(color: reserveManageInfoData.facilities_4.toString() == 'Y' ? Colors.black : Colors.grey, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,))),
                Container(margin: EdgeInsets.only(right: 15), child: Text('#테라스', style: TextStyle(color: reserveManageInfoData.facilities_5.toString() == 'Y' ? Colors.black : Colors.grey, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,))),
                Container(margin: EdgeInsets.only(right: 15), child: Text('#콜키지', style: TextStyle(color: reserveManageInfoData.facilities_6.toString() == 'Y' ? Colors.black : Colors.grey, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,))),
                Container(margin: EdgeInsets.only(right: 15), child: Text('#아기의자', style: TextStyle(color: reserveManageInfoData.facilities_7.toString() == 'Y' ? Colors.black : Colors.grey, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,))),
                Container(margin: EdgeInsets.only(right: 15), child: Text('#놀이방', style: TextStyle(color: reserveManageInfoData.facilities_8.toString() == 'Y' ? Colors.black : Colors.grey, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,))),
                Container(margin: EdgeInsets.only(right: 15), child: Text('#노키즈존', style: TextStyle(color: reserveManageInfoData.facilities_9.toString() == 'Y' ? Colors.black : Colors.grey, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,))),
                Container(margin: EdgeInsets.only(right: 15), child: Text('#반려동물', style: TextStyle(color: reserveManageInfoData.facilities_10.toString() == 'Y' ? Colors.black : Colors.grey, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,))),
              ],
            ),
          ),
          trailing: ISButton(
            child: const Text('변경'),
            onPressed: () {
              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => ShopReserveFacilitiesEdit(sData: reserveManageInfoData, ccCode: ShopController.to.ccCode.toString()),
              ).then((value) async {
                //if (value == true) {
                await Future.delayed(const Duration(milliseconds: 500), () {
                  requestReserveManageInfo();
                });
                //}
              });
            },
          ),
        ),
        ISLabelBarSub(
          title: '예약 가능 시간 설정',
          body: Container(
            alignment: Alignment.centerLeft,
            width: double.infinity,
            child: _reserveTimeWidget(),
          ),
          trailing: ISButton(
            child: const Text('수정'),
            onPressed: () {
              currentMode = MODE_RESERTIMESETTING_VIEW;

              setState(() {
                _scrollController!.jumpTo(0.0);
              });
            },
          ),
        ),
        ISLabelBarSub(
          title: '매시간 최대 예약 건수 및 인원 제한 설정',
          body: Container(
            alignment: Alignment.centerLeft,
            width: double.infinity,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('[매시간 최대 예약 건수]  $_caseCnt 건', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                Text('[인원 제한]  $_peopleCnt 명', style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
              ],
            ),
          ),
          trailing: ISButton(
            child: const Text('수정'),
            onPressed: () {
              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => ShopReserveCasePeopleEdit(sCaseCnt: _caseCnt, sPeopleCnt: _peopleCnt),
              ).then((value) async {
                //if (value == true) {
                await Future.delayed(const Duration(milliseconds: 250), () async {
                  requestReserveCasesPeopleAPIData();
                  await Future.delayed(const Duration(milliseconds: 250), () {
                    setState(() { });
                  });
                });
                //}
              });
            },
          ),
        ),
        ISLabelBarSub(
          title: '고객 리뷰',
          body: Container(
            alignment: Alignment.centerLeft,
            width: double.infinity,
            child: _buildPanelContainer(
                width: 60,
                color: reserveManageInfoData.reviewUseGbn == 'Y' ? Colors.green.shade300 : Colors.red.shade300 ,
                child: Text(reserveManageInfoData.reviewUseGbn == 'Y' ? '사용중' : '미사용', style: const TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON))
            ),
          ),
          trailing: ISButton(
            child: const Text('변경'),
            onPressed: () {
              showDialog(
                context: context,
                barrierDismissible: true,
                builder: (context) => ShopReviewUseEditReserve(sReviewUseGbn: reserveManageInfoData.reviewUseGbn, ccCode: ShopController.to.ccCode.toString()),
              ).then((value) async {
                //if (value == true) {
                await Future.delayed(const Duration(milliseconds: 500), () {
                  requestReserveManageInfo();
                });
                //}
              });
              // currentMode = MODE_REVIEWUSE_VIEW;
              //
              // setState(() {
              //   _scrollController!.jumpTo(0.0);
              // });
            },
          ),
        ),
      ],
    );
  }

  Widget reserveTimeSetWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('예약 가능 시간 설정', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
        const Text('※ 설정하신 영업시간, 브레이크 타임, 휴무일을 뺀 나머지 시간이 자동으로 표시됩니다.', style: TextStyle(color: Colors.black54, fontSize: 13)),
        const Text('※ 저장 탭 시 월~일 동안의 예약 가능 시간을 설정하여 반복적으로 일괄 적용됩니다.', style: TextStyle(color: Colors.black54, fontSize: 13)),
        const Wrap(
          children: [
            Text('※ 예약 가능 시간은', style: TextStyle(color: Colors.black54, fontSize: 13)),
            Text(' 하늘색', style: TextStyle(color: Colors.blueAccent, fontSize: 13)),
            Text(' 예약 불가능 시간은', style: TextStyle(color: Colors.black54, fontSize: 13)),
            Text(' 빨간색', style: TextStyle(color: Colors.redAccent, fontSize: 13)),
            Text(' 으로 표시되며, 선택 후 저장을 클릭하시면 예약 가능 시간에서 반영됩니다.', style: TextStyle(color: Colors.black54, fontSize: 13)),
          ],
        ),
        const SizedBox(height: 5),
        Row(
          children: [
            ISButton(
              isReverseColor: true,
              onPressed: () {
                currentMode = MODE_MAIN_VIEW;
                _scrollController!.jumpTo(0.0);

                requestReserveTimeAPIData();
                setState(() {});
              },
              child: const Text('취소'),
            ),
            const SizedBox(width: 8),
            ISButton(
              buttonColor: Colors.grey,
              onPressed: () {
                reserveTimeBinding('A');
                setState(() {});
              },
              child: const Text('전체 초기화'),
            ),
            const SizedBox(width: 8),
            ISButton(
              child: const Text('저장'),
              onPressed: () async {
                _setData.clear();
                _setCancelData.clear();

                timeData_1_A.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '1';
                    _setData.add(element);
                  } else {
                    element.gbn = '1';
                    _setCancelData.add(element);
                  }
                });

                timeData_1_P.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '1';
                    _setData.add(element);
                  } else {
                    element.gbn = '1';
                    _setCancelData.add(element);
                  }
                });

                timeData_2_A.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '2';
                    _setData.add(element);
                  } else {
                    element.gbn = '2';
                    _setCancelData.add(element);
                  }
                });

                timeData_2_P.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '2';
                    _setData.add(element);
                  } else {
                    element.gbn = '2';
                    _setCancelData.add(element);
                  }
                });

                timeData_3_A.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '3';
                    _setData.add(element);
                  } else {
                    element.gbn = '3';
                    _setCancelData.add(element);
                  }
                });

                timeData_3_P.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '3';
                    _setData.add(element);
                  } else {
                    element.gbn = '3';
                    _setCancelData.add(element);
                  }
                });

                timeData_4_A.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '4';
                    _setData.add(element);
                  } else {
                    element.gbn = '4';
                    _setCancelData.add(element);
                  }
                });

                timeData_4_P.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '4';
                    _setData.add(element);
                  } else {
                    element.gbn = '4';
                    _setCancelData.add(element);
                  }
                });

                timeData_5_A.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '5';
                    _setData.add(element);
                  } else {
                    element.gbn = '5';
                    _setCancelData.add(element);
                  }
                });

                timeData_5_P.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '5';
                    _setData.add(element);
                  } else {
                    element.gbn = '5';
                    _setCancelData.add(element);
                  }
                });

                timeData_6_A.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '6';
                    _setData.add(element);
                  } else {
                    element.gbn = '6';
                    _setCancelData.add(element);
                  }
                });

                timeData_6_P.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '6';
                    _setData.add(element);
                  } else {
                    element.gbn = '6';
                    _setCancelData.add(element);
                  }
                });

                timeData_7_A.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '7';
                    _setData.add(element);
                  } else {
                    element.gbn = '7';
                    _setCancelData.add(element);
                  }
                });

                timeData_7_P.forEach((element) {
                  if (element.gbn == 'N' || element.gbn == 'B') return;

                  if (element.gbn == 'S') {
                    element.gbn = '7';
                    _setData.add(element);
                  } else {
                    element.gbn = '7';
                    _setCancelData.add(element);
                  }
                });

                postReserveTime(_setCancelData);
                postReserveTimeCancel(_setData);

                await Future.delayed(const Duration(milliseconds: 300), () {
                  requestReserveTimeAPIData();
                });

                setState(() {});
              },
            ),
          ],
        ),
        const SizedBox(height: 10),
        ListView(
            controller: _scrollController2,
            shrinkWrap: true,
            children: List.generate(7, (index) {
              return ISLabelBarSub(
                title: _dayGbn((index + 1).toString()),
                trailing: ISButton(
                  child: const Text('초기화'),
                  onPressed: () {
                    reserveTimeBinding((index + 1).toString());

                    setState(() {});
                  },
                ),
                body: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(margin: const EdgeInsets.only(top: 3, right: 5), child: const Text('오전', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                    _timeSetDataA(index),
                    Container(margin: const EdgeInsets.only(top: 3, right: 5), child: const Text('오후', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                    _timeSetDataP(index)
                  ],
                ),
              );
            })),
      ],
    );
  }

  Widget _reserveTimeWidget() {
    return ListView.builder(
      controller: _scrollController2,
      shrinkWrap: true,
      //controller: _scrollController,
      itemCount: shopOperateReserveTimeData.length,
      itemBuilder: (BuildContext context, int index) {
        return shopOperateReserveTimeData == null
            ? const SizedBox.shrink()
            : SizedBox(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Responsive.isMobile(context) == false
                  ? Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(margin: const EdgeInsets.only(top: 3, right: 10), child: Text(_dayGbn(shopOperateReserveTimeData[index].dayGbn.toString()), style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(margin: const EdgeInsets.only(top: 3, right: 5), child: const Text('오전', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                      _timeDataA(index),
                      Container(margin: const EdgeInsets.only(top: 3, right: 5), child: const Text('오후', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                      _timeDataP(index)
                    ],
                  ),
                ],
              )
                  : Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(margin: const EdgeInsets.only(top: 3, right: 10, bottom: 10), child: Text(_dayGbn(shopOperateReserveTimeData[index].dayGbn.toString()), style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(margin: const EdgeInsets.only(top: 3, right: 5), child: const Text('오전', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                      _timeDataA(index),
                      Container(margin: const EdgeInsets.only(top: 3, right: 5), child: const Text('오후', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD))),
                      _timeDataP(index)
                    ],
                  ),
                ],
              ),
              const Divider()
            ],
          ),
        );
      },
    );
  }

  // 예약가능 시간 오전 데이타
  Container _timeDataA(int index) {
    List<ShopOperateReserveTimeModel> _temp = <ShopOperateReserveTimeModel>[];

    if (index == 0) {
      _temp = timeData_1_A;
    } else if (index == 1) {
      _temp = timeData_2_A;
    } else if (index == 2) {
      _temp = timeData_3_A;
    } else if (index == 3) {
      _temp = timeData_4_A;
    } else if (index == 4) {
      _temp = timeData_5_A;
    } else if (index == 5) {
      _temp = timeData_6_A;
    } else if (index == 6) {
      _temp = timeData_7_A;
    }

    return Container(
      width: Responsive.isMobile(context) == true ? MediaQuery.of(context).size.width / 3 : 330,
      child: Wrap(
        direction: Axis.horizontal,
        children: [
          // A,S : 예약 가능 시간 설정 가능(O)
          for (var i in _temp)
            i.gbn == 'A'
                ? Container(margin: const EdgeInsets.only(left: 5, right: 5, bottom: 5), child: Text('${i.time.toString().substring(0, 2)}:${i.time.toString().substring(2, 4)}', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,),))
                : const SizedBox.shrink()
        ],
      ),
    );
  }

  // 예약가능 시간 오후 데이타
  Container _timeDataP(int index) {
    List<ShopOperateReserveTimeModel> _temp = <ShopOperateReserveTimeModel>[];

    if (index == 0) {
      _temp = timeData_1_P;
    } else if (index == 1) {
      _temp = timeData_2_P;
    } else if (index == 2) {
      _temp = timeData_3_P;
    } else if (index == 3) {
      _temp = timeData_4_P;
    } else if (index == 4) {
      _temp = timeData_5_P;
    } else if (index == 5) {
      _temp = timeData_6_P;
    } else if (index == 6) {
      _temp = timeData_7_P;
    }

    return Container(
      width: Responsive.isMobile(context) == true ? MediaQuery.of(context).size.width / 3 : 330,
      child: Wrap(
        direction: Axis.horizontal,
        children: [
          for (var i in _temp)
            i.gbn == 'A'
                ? // A,S : 예약 가능 시간 설정 가능(O)
            Container(margin: const EdgeInsets.only(left: 10, right: 10, bottom: 5), child: Text('${i.time.toString().substring(0, 2)}:${i.time.toString().substring(2, 4)}', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL,),))
                : const SizedBox.shrink()
        ],
      ),
    );
  }

  // 예약가능 시간 오전 데이타 수정
  Container _timeSetDataA(int index) {
    List<ShopOperateReserveTimeModel> _temp = <ShopOperateReserveTimeModel>[];

    if (index == 0) {
      _temp = timeData_1_A;
    } else if (index == 1) {
      _temp = timeData_2_A;
    } else if (index == 2) {
      _temp = timeData_3_A;
    } else if (index == 3) {
      _temp = timeData_4_A;
    } else if (index == 4) {
      _temp = timeData_5_A;
    } else if (index == 5) {
      _temp = timeData_6_A;
    } else if (index == 6) {
      _temp = timeData_7_A;
    }

    return Container(
      width: Responsive.isMobile(context) == true ? MediaQuery.of(context).size.width / 3 : 300,
      child: Wrap(
        direction: Axis.horizontal,
        children: [
          for (var i in _temp)
            InkWell(
                child: Container(
                  alignment: Alignment.center,
                  width: Responsive.isMobile(context) ? 50 : 70,
                  height: 30,
                  decoration: BoxDecoration(
                    color: i.gbn == 'N' || i.gbn == 'B' || i.gbn == 'H' ? Colors.grey.shade300 : Colors.white,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _borderColor(i.gbn.toString())),
                  ),
                  margin: const EdgeInsets.only(left: 5, right: 5, bottom: 5),
                  child: Text('${i.time.toString().substring(0, 2)}:${i.time.toString().substring(2, 4)}'),
                ),
                onTap: () async {
                  if (i.gbn == 'N' || i.gbn == 'B') {
                    return;
                  }

                  if (i.gbn == 'A') {
                    i.gbn = 'S';
                  } else {
                    i.gbn = 'A';
                  }

                  setState(() {});
                }),
        ],
      ),
    );
  }

  // 예약가능 시간 오후 데이타 수정
  Container _timeSetDataP(int index) {
    List<ShopOperateReserveTimeModel> _temp = <ShopOperateReserveTimeModel>[];

    if (index == 0) {
      _temp = timeData_1_P;
    } else if (index == 1) {
      _temp = timeData_2_P;
    } else if (index == 2) {
      _temp = timeData_3_P;
    } else if (index == 3) {
      _temp = timeData_4_P;
    } else if (index == 4) {
      _temp = timeData_5_P;
    } else if (index == 5) {
      _temp = timeData_6_P;
    } else if (index == 6) {
      _temp = timeData_7_P;
    }

    return Container(
      width: Responsive.isMobile(context) == true ? MediaQuery.of(context).size.width / 3 : 300,
      child: Wrap(
        direction: Axis.horizontal,
        children: [
          for (var i in _temp)
            InkWell(
                child: Container(
                  alignment: Alignment.center,
                  width: Responsive.isMobile(context) ? 50 : 70,
                  height: 30,
                  decoration: BoxDecoration(
                    color: i.gbn == 'N' || i.gbn == 'B' || i.gbn == 'H' ? Colors.grey.shade300 : Colors.white,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _borderColor(i.gbn.toString())),
                  ),
                  margin: const EdgeInsets.only(left: 5, right: 5, bottom: 5),
                  child: Text('${i.time.toString().substring(0, 2)}:${i.time.toString().substring(2, 4)}'),
                ),
                onTap: () {
                  if (i.gbn == 'N' || i.gbn == 'B') {
                    return;
                  }

                  if (i.gbn == 'A') {
                    i.gbn = 'S';
                  } else {
                    i.gbn = 'A';
                  }

                  setState(() {});
                }),
        ],
      ),
    );
  }

  String _dayGbn(String gbn) {
    if (gbn == '1') {
      return '일요일';
    } else if (gbn == '2') {
      return '월요일';
    } else if (gbn == '3') {
      return '화요일';
    } else if (gbn == '4') {
      return '수요일';
    } else if (gbn == '5') {
      return '목요일';
    } else if (gbn == '6') {
      return '금요일';
    } else if (gbn == '7') {
      return '토요일';
    } else {
      return '';
    }
  }

  Color _dayColor(String gbn) {
    if (gbn == '1') {
      return Colors.redAccent;
    } else if (gbn == '7') {
      return Colors.blueAccent;
    } else {
      return Colors.black;
    }
  }

  String _timeSet(String time) {
    String temp;

    temp = time.substring(0, 2) + ':' + time.substring(2, 4);

    return temp;
  }

  Color _borderColor(String gbn) {
    if (gbn == 'A') {
      return const Color(0xff01CAFF);
    } else if (gbn == 'S') {
      return Colors.redAccent;
    } else {
      return Colors.black38;
    }
  }

  String getShopStatusStr(String? absentYn) {
    String? tempStr = '';
    if (absentYn == 'Y')
      tempStr = '영업 중';
    else if (absentYn == 'N')
      tempStr = '휴점 중';
    else
      tempStr = '';

    return tempStr;
  }

  String convertFoDay(String? absentYn) {
    String? tempStr = '';

    if (absentYn == '1')
      tempStr = '매주';
    else if (absentYn == '2')
      tempStr = '매월 첫째 주';
    else if (absentYn == '3')
      tempStr = '매월 둘째 주';
    else if (absentYn == '4')
      tempStr = '매월 셋째 주';
    else if (absentYn == '5')
      tempStr = '매월 넷째 주';
    else if (absentYn == '6')
      tempStr = '매월 다섯째 주';
    else if (absentYn == '7')
      tempStr = '매월 마지막 주';
    else
      tempStr = '';

    return tempStr;
  }

  String convertToDay(String? absentYn) {
    String? tempStr = '';

    if (absentYn == '1')
      tempStr = '일요일';
    else if (absentYn == '2')
      tempStr = '월요일';
    else if (absentYn == '3')
      tempStr = '화요일';
    else if (absentYn == '4')
      tempStr = '수요일';
    else if (absentYn == '5')
      tempStr = '목요일';
    else if (absentYn == '6')
      tempStr = '금요일';
    else if (absentYn == '7')
      tempStr = '토요일';
    else
      tempStr = '';

    return tempStr;
  }

  Widget _buildPanelContainer({Widget? child, double? width, double? height, Color? color}){
    return Container(
        alignment: Alignment.center,
        //margin: const EdgeInsets.symmetric(horizontal: 4),
        //padding: const EdgeInsets.symmetric(horizontal: 10),
        width: width ?? 120,
        height: height ?? 34,
        decoration: BoxDecoration(
            color: color ?? Colors.grey.shade400,
            borderRadius: BorderRadius.circular(6)
        ),
        child: child
    );
  }
}