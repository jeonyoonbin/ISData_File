import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:provider/provider.dart';

import '../../iswidgets/isd_search_dropdown.dart';
import '../../models/SaleManager/couponNewItemModel.dart';

class ShopOperateHolidayEdit extends StatefulWidget {
  const ShopOperateHolidayEdit({super.key});

  @override
  State<ShopOperateHolidayEdit> createState() => _ShopOperateHolidayEditState();
}

class _ShopOperateHolidayEditState extends State<ShopOperateHolidayEdit> {
  List regularHoliday = [1, 2, 3, 4];
  List tempHoliday = [];

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 640),
        contentPadding: const EdgeInsets.all(0.0),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            Text(
              '휴무일 설정',
              style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),
            ),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 16),
                  ISLabelBarSub(
                    title: '정기 휴무일',
                    body: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            ISCheckbox(label: '법정공휴일 휴무 적용', value: true, onChanged: (v) => setState(() => v!)),
                            const SizedBox(
                              width: 3,
                            ),
                            Container(
                              padding: const EdgeInsets.only(bottom: 1.9),
                              child: const Tooltip(
                                message: '법정공휴일을 휴무로 설정을 할 시, 모든 법정 공휴일이 정기 휴무로 등록 됩니다.\n'
                                    '\n[설정되는 공휴일]'
                                    '\n- 국경일 중 3•1절, 광복절, 개천절 및 한글날'
                                    '\n- 1월 1일'
                                    '\n- 설날 전날, 설날, 설날 다음날(음력 12월 말일, 1월 1일, 2일)'
                                    '\n- 석가탄신일 (음력 4월 8일)'
                                    '\n- 어린이날 (5월 5일)'
                                    '\n- 현충일 (6월 6일)'
                                    '\n- 추석 전날, 추석, 추석 다음날(음력 8월 14일, 15일, 16일)'
                                    '\n- 성탄절 (12월 25일)'
                                    '\n- 공직 선거법 제34조 따른 임기 만료에 의한 선거의 선거일'
                                    '\n- 기타 정부에서 수시 지정하는 날',
                                child: Icon(
                                  Icons.help_outline,
                                  color: Colors.blue,
                                ),
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: DataTable(
                                headingRowHeight: 0.01,
                                dataRowHeight: 46.0,
                                columnSpacing: 0,
                                horizontalMargin: 0,
                                dividerThickness: 0.01,
                                columns: [
                                  DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.left))),
                                  DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.left))),
                                  DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.center))),
                                  DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.center))),
                                ],
                                rows: regularHoliday.map((item) {
                                  return DataRow(cells: [
                                    DataCell(ISSearchDropdown(
                                      label: '선택하세요',
                                      height: 40,
                                      width: 130,
                                    )),
                                    DataCell(ISSearchDropdown(
                                      label: '선택하세요',
                                      height: 40,
                                      width: 130,
                                    )),
                                    DataCell(ISButton(
                                      isReverseColor: true,
                                      child: const Text('삭제'),
                                      onPressed: () {},
                                    )),
                                    DataCell(item == regularHoliday.last
                                        ? ISButton(
                                            child: const Text('추가'),
                                            onPressed: () {},
                                          )
                                        : Container())
                                  ]);
                                }).toList(),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                  ISLabelBarSub(
                    title: '임시 휴무일',
                    body: Column(

                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: DataTable(
                            headingRowHeight: 0.01,
                            dataRowHeight: 46.0,
                            columnSpacing: 0,
                            horizontalMargin: 0,
                            dividerThickness: 0.01,
                            columns: [
                              DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.left))),
                              DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.left))),
                              DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.center))),
                              DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.center))),
                            ],
                            rows: regularHoliday.map((item) {
                              return DataRow(cells: [
                                DataCell(ISSearchDropdown(
                                  label: '선택하세요',
                                  height: 40,
                                  width: 130,
                                )),
                                DataCell(ISSearchDropdown(
                                  label: '선택하세요',
                                  height: 40,
                                  width: 130,
                                )),
                                DataCell(ISButton(
                                  isReverseColor: true,
                                  child: const Text('삭제'),
                                  onPressed: () {},
                                )),
                                DataCell(item == regularHoliday.last
                                    ? ISButton(
                                  child: const Text('추가'),
                                  onPressed: () {},
                                )
                                    : Container())
                              ]);
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () {
                BuildContext oldContext = context;

                ISConfirm(context, '고객 리뷰 사용 변경', '고객 리뷰 사용 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                  Navigator.of(context).pop();

                  if (isOK) {}
                });
              },
              child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }
}
