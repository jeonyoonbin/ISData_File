import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopReserveDayOffModel.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopOperateDayOffEdit extends StatefulWidget {
  final ShopReserveDayOffModel? sData_1;
  final ShopReserveDayOffModel? sData_3;
  final ShopReserveDayOffModel? sData_5;

  const ShopOperateDayOffEdit({Key? key, this.sData_1, this.sData_3, this.sData_5}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopOperateDayOffEditState();
  }
}

class ShopOperateDayOffEditState extends State<ShopOperateDayOffEdit> {
  ShopReserveDayOffModel? setSData_1 = ShopReserveDayOffModel();
  ShopReserveDayOffModel? setSData_3 = ShopReserveDayOffModel();
  ShopReserveDayOffModel? setSData_5 = ShopReserveDayOffModel();
  String dayOff_1_foDay = 'N';
  List<dynamic> dayOff_3_data = [];
  List<dynamic> dayOff_5_data = [];

  requestAPIData() async {
    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());

    setSData_1 = widget.sData_1;
    setSData_3 = widget.sData_3;
    setSData_5 = widget.sData_5;

    setSData_1?.list?.forEach((element) {
      dayOff_1_foDay = element['foDay'];
    });

    setSData_3?.list?.forEach((element) {
      dayOff_3_data.add(element);
    });

    setSData_5?.list?.forEach((element) {
      dayOff_5_data.add(element);
    });

    if (setSData_3?.list!.length == 0){
      var addData = {
        'seq' : '0',
        'foDay' : '0',
        'toDay' : '0'
      };

      dayOff_3_data.add(addData); // ShopDeliTipCostModel());
    }

    if (setSData_5?.list!.length == 0){
      var addData = {
        'seq' : '0',
        'foDay' : null,
        'toDay' : null,
      };

      dayOff_5_data.add(addData); // ShopDeliTipCostModel());
    }


  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 420.0, maxHeight: 750),
      contentPadding: const EdgeInsets.all(0.0),
      //const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text(
            '휴무일 설정',
            style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),
          ),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Column(
              children: [
                ISLabelBarSub(
                  title: '공휴일',
                  bodyPadding: const EdgeInsets.all(0.0),
                  body: SizedBox(
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        ISCheckbox(
                            label: '공휴일 설정하기',
                            value: dayOff_1_foDay == 'Y' ? true : false,
                            onChanged: (v) {
                              setState(() {
                                if (v == true) {
                                  dayOff_1_foDay = 'Y';
                                } else {
                                  dayOff_1_foDay = 'N';
                                }
                              });
                            }),
                        const Tooltip(
                          richMessage: TextSpan(
                            text: '* ',
                            children: [
                              TextSpan(
                                text: '주말(토,일)',
                                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.lightBlueAccent),
                              ),
                              TextSpan(
                                text: "은 별도로 ",
                              ),
                              TextSpan(
                                text: '휴무일을 설정',
                                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.lightBlueAccent),
                              ),
                              TextSpan(
                                text: " 해주세요",
                              ),
                              TextSpan(
                                text: "\n\n",
                              ),
                              TextSpan(text: "[설정되는 공휴일]", style: TextStyle(fontWeight: FONT_BOLD)),
                              TextSpan(
                                text: "\n",
                              ),
                              TextSpan(
                                text: "- 국경일 중 3.1절, 광복절, 개천절 및 한글날\n- 1월 1일\n- 설날 전날, 설날, 설날 다음날(음력 12월 말일, 1월 1일, 2일)\n",
                              ),
                              TextSpan(
                                text: "- 석가탄신일(음력 4월 8일)\n- 어린이날(5월 5일)\n- 현충일(6월 6일)\n- 추석 전날, 추석, 추석 다음날(음력 8월 14일, 15일, 16일)\n",
                              ),
                              TextSpan(
                                text: "- 성탄절(12월 25일)\n- 「공직선거법」 제34조 따른 임기 만료에 의한 선거의 선거일\n- 기타 정부에서 수시 지정하는 날",
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: EdgeInsets.only(left: 5.0, top: 2, right: 5.0),
                            child: Icon(
                              Icons.help_outline,
                              color: Colors.blue,
                              size: 20,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                ISLabelBarSub(
                  title: '정기 휴무일 (최대 20개)',
                  bodyPadding: const EdgeInsets.all(0.0),
                  body: SizedBox(
                    width: double.infinity,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: DataTable(
                        headingRowHeight: 34,
                        dataRowHeight: 50.0,
                        columnSpacing: 0.0,
                        columns: const [
                          DataColumn(label: SizedBox(width: 160, child: Text('주기', textAlign: TextAlign.center))),
                          DataColumn(label: SizedBox(width: 140, child: Text('요일', textAlign: TextAlign.center))),
                          DataColumn(label: SizedBox(width: 40, child: Text('', textAlign: TextAlign.center))),
                        ],
                        rows: dayOff_3_data.map((item) {
                          return DataRow(cells: [
                            DataCell(Align(alignment: Alignment.center,
                              child: ISSearchDropdown(
                                width: Responsive.isMobile(context) == true ? double.infinity : 150,
                                label: '',
                                value: item['foDay'].toString(),
                                onChange: (value) {
                                  item['foDay'] = value;
                                },
                                item: [
                                  ISOptionModel(value: '0', label: '선택'),
                                  ISOptionModel(value: '1', label: '매주'),
                                  ISOptionModel(value: '2', label: '매월 첫째 주'),
                                  ISOptionModel(value: '3', label: '매월 둘째 주'),
                                  ISOptionModel(value: '4', label: '매월 셋째 주'),
                                  ISOptionModel(value: '5', label: '매월 넷째 주'),
                                  ISOptionModel(value: '6', label: '매월 다섯째 주'),
                                  ISOptionModel(value: '7', label: '매월 마지막 주'),
                                ].cast<ISOptionModel>(),
                              ),
                            )),
                            DataCell(Align(alignment: Alignment.center,
                              child: ISSearchDropdown(
                                width: Responsive.isMobile(context) == true ? double.infinity : 120,
                                label: '',
                                value: item['toDay'].toString(),
                                onChange: (value) {
                                  item['toDay'] = value;
                                },
                                item: [
                                  ISOptionModel(value: '0', label: '선택'),
                                  ISOptionModel(value: '1', label: '일요일'),
                                  ISOptionModel(value: '2', label: '월요일'),
                                  ISOptionModel(value: '3', label: '화요일'),
                                  ISOptionModel(value: '4', label: '수요일'),
                                  ISOptionModel(value: '5', label: '목요일'),
                                  ISOptionModel(value: '6', label: '금요일'),
                                  ISOptionModel(value: '7', label: '토요일'),
                                ].cast<ISOptionModel>(),
                              ),
                            )),
                            DataCell(Align(
                                alignment: Alignment.center,
                                child: InkWell(
                                  child: const Icon(Icons.cancel, color: Color(0xff01CAFF), size: 21),
                                  onTap: () async {
                                    // 추가 된 값 리스트에서만 삭제
                                    if(item['seq'].toString() == '0') {
                                      dayOff_3_data.remove(item);
                                    } else {
                                      List<dynamic> tempData3 = [];

                                      dayOff_3_data.forEach((element) {
                                        if(element['foDay'].toString() == '0' || element['toDay'].toString() == '0') {
                                          return;
                                        } else {
                                          tempData3.add(element);
                                        }
                                      });

                                      var _deleteData = {
                                        '"shopCode"': '"${AuthService.SHOPCD}"',
                                        '"gbn"': '"3"',
                                        '"seq"': '"${item['seq']}"',
                                        '"foDay"': '"${item['foDay']}"',
                                        '"toDay"': '"${item['toDay']}"'
                                      };

                                      await ReserveController.to.deleteReserveShopDayOff(_deleteData.toString()).then((value) {
                                        if(value == '00') {
                                          dayOff_3_data.remove(item);
                                        }
                                      });
                                    }

                                    setState(() {});
                                  },
                                ))),
                          ]);
                        }).toList(),
                      ),
                    ),
                  ),
                  trailing: ISButton(
                    child: const Text('항목 추가'),
                    onPressed: () {
                      if(dayOff_3_data.length > 19) {
                        ISAlert(context, content: '20개 이상 등록 할 수 없습니다.');
                        return;
                      }

                      var addData = {
                        'seq' : '0',
                        'foDay' : '0',
                        'toDay' : '0'
                      };

                      dayOff_3_data.add(addData); // ShopDeliTipCostModel());

                      setState(() {});
                    },
                  ),
                ),
                ISLabelBarSub(
                  title: '임시 휴무일 (최대 20개)',
                  bodyPadding: const EdgeInsets.all(0.0),
                  body: SizedBox(
                    width: double.infinity,
                    child: DataTable(
                      headingRowHeight: 0,
                      dataRowHeight: 50.0,
                      columnSpacing: 0.0,
                      columns: const [
                        DataColumn(label: SizedBox(width: 160, child: Text('기간', textAlign: TextAlign.center))),
                        DataColumn(label: SizedBox(width: 40, child: Text('', textAlign: TextAlign.center))),
                      ],
                      rows: dayOff_5_data.map((item) {
                        return DataRow(cells: [
                          DataCell(Align(
                            alignment: Alignment.center,
                            child: Material(
                              child: ISSearchSelectDate(
                                label: '기간 선택',
                                width: Responsive.isMobile(context) == true ? double.infinity : 230,
                                value: item['foDay'] == null ? '시작 날짜 ~ 종료 날짜' : '${Utils.getYearMonthDayFormat(item['foDay'].toString())} ~ ${Utils.getYearMonthDayFormat(item['toDay'].toString())}',
                                onTap: () async {
                                  showGeneralDialog(
                                      context: context,
                                      barrierDismissible: true,
                                      barrierLabel: '',
                                      barrierColor: Colors.black54,
                                      pageBuilder: (context, animation, secondaryAnimation) {
                                        return Dialog(
                                            insetPadding: EdgeInsets.zero,
                                            elevation: 0,
                                            backgroundColor: Colors.white,
                                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                                            child: MultipleViewDateRangePicker(
                                              startDate: item['foDay'] == null ? DateTime.now() : DateTime.parse(item['foDay'].toString()!),
                                              endDate:  item['toDay'] == null ? DateTime.now() : DateTime.parse(item['toDay'].toString()!),
                                              setDateActionCallback: ({startDate, endDate}) {
                                                Navigator.of(context).pop();
                                                item['foDay'] = DateFormat('yyyy-MM-dd').format(startDate!);
                                                item['toDay'] = DateFormat('yyyy-MM-dd').format(endDate!);

                                                requestAPIData();
                                              },
                                            ));
                                      });
                                },
                              ),
                            ),
                          )),
                          DataCell(Align(
                              alignment: Alignment.center,
                              child: InkWell(
                                child: const Icon(Icons.cancel, color: Color(0xff01CAFF), size: 21),
                                onTap: () async {
                                  // 추가 된 값 리스트에서만 삭제
                                  if(item['seq'].toString() == '0') {
                                    dayOff_5_data.remove(item);
                                  } else {
                                    List<dynamic> tempData3 = [];

                                    dayOff_5_data.forEach((element) {
                                      if(element['foDay'].toString() == '0' || element['toDay'].toString() == '0') {
                                        return;
                                      } else {
                                        tempData3.add(element);
                                      }
                                    });

                                    var _deleteData = {
                                      '"shopCode"': '"${AuthService.SHOPCD}"',
                                      '"gbn"': '"5"',
                                      '"seq"': '"${item['seq']}"',
                                      '"foDay"': '"${item['foDay']}"',
                                      '"toDay"': '"${item['toDay']}"'
                                    };

                                    await ReserveController.to.deleteReserveShopDayOff(_deleteData.toString()).then((value) {
                                      if(value == '00') {
                                        dayOff_5_data.remove(item);
                                      }
                                    });
                                  }

                                  setState(() {});
                                },
                              ))),
                        ]);
                      }).toList(),
                    ),
                  ),
                  trailing: ISButton(
                    child: const Text('항목 추가'),
                    onPressed: () {
                      if(dayOff_5_data.length > 19) {
                        ISAlert(context, content: '20개 이상 등록 할 수 없습니다.');
                        return;
                      }

                      var addData = {
                        'seq' : '0',
                        'foDay' : null,
                        'toDay' : null,
                      };


                      dayOff_5_data.add(addData); // ShopDeliTipCostModel());

                      setState(() {});
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              // 공휴일 업데이트
              var sendData = {
                '"shopCode"': '"' + AuthService.SHOPCD + '"',
                '"gbn"' : '"1"',
                '"list"' : [
                  {
                    '"seq"': '"0"',
                    '"foDay"' : '"' + dayOff_1_foDay + '"',
                    '"toDay"' : '"' + dayOff_1_foDay + '"'
                  }
                ]
              };

              await ReserveController.to.updateReserveShopDayOff(sendData.toString());

              // 정기 휴무일 업데이트
              // 구분값 선택 안된거 제외 하여 저장
              List<dynamic> tempData3 = [];

              dayOff_3_data.forEach((element) {
                if(element['foDay'].toString() == '0' || element['toDay'].toString() == '0') {
                  return;
                } else {
                  tempData3.add(element);
                }
              });

              setSData_3!.shopCode = AuthService.SHOPCD;
              setSData_3!.gbn = '3';
              setSData_3!.list = tempData3;

              await ReserveController.to.updateReserveShopDayOff(setSData_3!.toJson());

              // 임시 휴무일 업데이트
              // 날짜 선택 안된거 제외 하여 저장
              List<dynamic> tempData5 = [];

              dayOff_5_data.forEach((element) {
                if(element['foDay'].toString() == 'null' || element['toDay'].toString() == 'null') {
                  return;
                } else {
                  element['foDay'] = element['foDay'].toString().replaceAll('-', '');
                  element['toDay'] = element['toDay'].toString().replaceAll('-', '');

                  tempData5.add(element);
                }
              });

              setSData_5!.shopCode = AuthService.SHOPCD;
              setSData_5!.gbn = '5';
              setSData_5!.list = tempData5;

              await ReserveController.to.updateReserveShopDayOff(setSData_5!.toJson());

              Navigator.of(context).pop(true);
              ISAlert(context, title: '알림', content: '저장이 완료되었습니다.');
            },
            child: Text('저장', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}
