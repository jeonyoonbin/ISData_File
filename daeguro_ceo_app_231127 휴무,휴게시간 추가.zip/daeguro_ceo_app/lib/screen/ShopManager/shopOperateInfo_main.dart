
import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopBreakTimeHourListModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateDayOffModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateHourListModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopProductDeliInfoModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateInfoModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateInfoReserveTimeModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateReserveTimeModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateSetReserveTimeModel.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopExchangeInfoEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopLegalInfoEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopOperateHourEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopOperateBTimeEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopOperateSTimeEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopProductDeliInfo.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopReserveDayOffEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopReserveTimeEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopReviewUseEdit.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopStatusEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import '../../iswidgets/calendarView/event_controller.dart';
import '../../models/ShopManager/shopReserveDayOffModel.dart';

class ShopOperateInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const ShopOperateInfoMain({Key? key, this.tabviewHeight}) : super(key: key);


  @override
  State<ShopOperateInfoMain> createState() => _ShopOperateInfoMainState();
}

class _ShopOperateInfoMainState extends State<ShopOperateInfoMain> {

  final ScrollController _scrollController = ScrollController();
  final ScrollController _scrollController2 = ScrollController();

  final ShopOperateInfoModel shopOperatorInfoData = ShopOperateInfoModel();

  EventController _controller = EventController();

  DateTime initDate = DateTime.now();

  String dateBegin = formatDate(DateTime.now(), [yyyy, mm, dd]);
  // 해당 월의 마지막 일 계산 (28일, 30일, 31일)
  String dateEnd = formatDate(DateTime.now(), [yyyy, mm,  DateTime(DateTime.now().year, DateTime.now().month + 1, 0).day.toString()]);
  String calMonth = formatDate(DateTime.now(), [yyyy, mm]);

  String _caseCnt = '0';
  String _peopleCnt = '0';

  // 예약 영업시간, 휴게시간 리스트
  List<dynamic> s_time = [];
  List<dynamic> b_time = [];

  // 휴무일 리스트
  ShopReserveDayOffModel dayOff_1 = ShopReserveDayOffModel();
  String dayOff_1_foDay = '미적용';

  ShopReserveDayOffModel dayOff_3 = ShopReserveDayOffModel();
  List<dynamic> dayOff_3_data = [];

  ShopReserveDayOffModel dayOff_5 = ShopReserveDayOffModel();
  List<dynamic> dayOff_5_data = [];

  List<ShopOperateReserveTimeModel> _setData = <ShopOperateReserveTimeModel>[];
  List<ShopOperateReserveTimeModel> _setCancelData = <ShopOperateReserveTimeModel>[];

  List<ShopOperateHourListModel> mOperateHourList = <ShopOperateHourListModel>[];
  List<ShopProductDeliInfoModel> mProductDeliInfoList = <ShopProductDeliInfoModel>[];

  List<ShopBreakTimeHourListModel> breakTimeHourList = <ShopBreakTimeHourListModel>[];

  List<ShopOperateDayOffModel> holidayList = <ShopOperateDayOffModel>[]; // 공휴일
  List<ShopOperateDayOffModel> regularDayOffList = <ShopOperateDayOffModel>[]; // 정기 휴무
  List<ShopOperateDayOffModel> tempDayOffList = <ShopOperateDayOffModel>[]; // 임시 휴무


  List<ShopOperateInfoReserveTimeModel> shopOperateReserveTimeData = <ShopOperateInfoReserveTimeModel>[];

  Future<String?> requestProductDeliInfo({bool? isRefresh = false}) async {
    String retValue = '';
    await ShopController.to.getOperateDeliInfo().then((value) {
      if (value == null) {
        retValue = 'requestProductDeliInfo() fail';
      }
      else {
        mProductDeliInfoList.clear();

        value.forEach((element) {
          ShopProductDeliInfoModel temp = ShopProductDeliInfoModel();

          temp.deliNoticeCode = element['deliNoticeCode'] as String;
          temp.title = element['title'] as String;
          temp.content = element['content'] as String;
          temp.sortSeq = element['sortSeq'] as String;

          mProductDeliInfoList.add(temp);
        });

        retValue = '00';
      }
    });

    if (isRefresh == true) {
      setState(() {});
    }

    return retValue;
  }

  Future<String?> requestOperateHourInfo({bool? isRefresh = false}) async {
    String retValue = '';
    await ShopController.to.getOperateHourInfo().then((value) {
      if (value == null) {
        retValue = '조회 오류';
      }
      else {
        mOperateHourList.clear();

        s_time.clear();

        value.forEach((element) {
          ShopOperateHourListModel temp = ShopOperateHourListModel();

          temp.tipSeq = element['tipSeq'] as String;
          temp.tipDay = element['tipDay'] as String;
          temp.tipFrStand = element['tipFrStand'] as String;
          temp.tipToStand = element['tipToStand'] as String;
          temp.tipNextDay = element['tipNextDay'] as String;

          mOperateHourList.add(temp);

          s_time.add(element);

        });

        retValue = '00';
      }
    });

    if (isRefresh == true) {
      setState(() {});
    }

    return retValue;
  }

  Future<String?> requestBreakTimeHourInfo({bool? isRefresh = false}) async {
    String retValue = '';
    await ShopController.to.getShopSbTime().then((value) {
      if (value == null) {
        retValue = '조회 오류';
      }
      else {
        breakTimeHourList.clear();

        b_time.clear();

        value.forEach((element) {
          ShopBreakTimeHourListModel temp = ShopBreakTimeHourListModel();

          temp.shopCd = element['shopCd'] as String;
          temp.sbGbn = element['sbGbn'] as String;
          temp.dayGbn = element['dayGbn'] as String;
          temp.openTime = element['openTime'] as String;
          temp.closeTime = element['closeTime'] as String;
          temp.useGbn = element['useGbn'] as String;
          temp.nextDayYn = element['nextDayYn'] as String;

          temp.useGbn == 'Y' ? breakTimeHourList.add(temp) : null;

          if (element['sbGbn'] == 'B') {
            b_time.add(element);
          }

        });

        retValue = '00';
      }
    });

    if (isRefresh == true) {
      setState(() {});
    }

    return retValue;
  }


  Future<String?> requestReserveCasesPeopleAPIData({bool? isRefresh = false}) async {
    String retValue = '';
    await ReserveController.to.getShopInfoReserveCasePeople(AuthService.SHOPCD).then((value) {
      if (value == null) {
        retValue = '${ShopController.to.msg})';
      } else {
        _caseCnt = value[0]['casesCnt'].toString();
        _peopleCnt = value[0]['peopleCnt'].toString();

        retValue = '00';
      }
    });

    if (isRefresh == true) {
      setState(() {});
    }
    return retValue;
  }

  requestReservedayOffAPIData(String gbn) async {
    await ReserveController.to.getShopInfoReserveDayOff(AuthService.SHOPCD, gbn).then((value) {
      if (value == null) {
      } else {
        if (gbn == '1') {
          dayOff_1.list = value['list'];

          dayOff_1.list?.forEach((element) {
            if(element['foDay'] == 'Y') {
              dayOff_1_foDay = '적용';
            } else {
              dayOff_1_foDay = '미적용';
            }
          });
        } else if (gbn == '3') {
          dayOff_3.list = value['list'];
          dayOff_3.list?.forEach((element) {
            dayOff_3_data.add(element);
          });
        } else if (gbn == '5') {
          dayOff_5.list = value['list'];
          dayOff_5.list?.forEach((element) {
            dayOff_5_data.add(element);
          });
        }
      }
    });

    setState(() {});
  }

  String convertFoDay(String? absentYn) {
    String? tempStr = '';

    if (absentYn == '1')
      tempStr = '매주';
    else if (absentYn == '2')
      tempStr = '매월 첫째 주';
    else if (absentYn == '3')
      tempStr = '매월 둘째 주';
    else if (absentYn == '4')
      tempStr = '매월 셋째 주';
    else if (absentYn == '5')
      tempStr = '매월 넷째 주';
    else if (absentYn == '6')
      tempStr = '매월 다섯째 주';
    else if (absentYn == '7')
      tempStr = '매월 마지막 주';
    else
      tempStr = '';

    return tempStr;
  }

  String convertToDay(String? absentYn) {
    String? tempStr = '';

    if (absentYn == '1')
      tempStr = '일요일';
    else if (absentYn == '2')
      tempStr = '월요일';
    else if (absentYn == '3')
      tempStr = '화요일';
    else if (absentYn == '4')
      tempStr = '수요일';
    else if (absentYn == '5')
      tempStr = '목요일';
    else if (absentYn == '6')
      tempStr = '금요일';
    else if (absentYn == '7')
      tempStr = '토요일';
    else
      tempStr = '';

    return tempStr;
  }

  Future<String?> requestOperateInfo({bool? isRefresh = false}) async {
    String retValue = '';
    await ShopController.to.getOperateInfo().then((value) {
      if (value == null) {
        retValue = '조회 오류';
      }
      else {
        shopOperatorInfoData.absentYn = value['absentYn'] as String;
        shopOperatorInfoData.reviewUseGbn = value['reviewUseGbn'] as String;
        shopOperatorInfoData.holiDayTerm = value['holiDayTerm'] as String;
        shopOperatorInfoData.kindShopStatus = value['kindShopStatus'] as String;
        shopOperatorInfoData.childMealYn = value['childMealYn'] as String;
        shopOperatorInfoData.minAmtPass = value['minAmtPass'] as String;
        shopOperatorInfoData.answerText = value['answerText'] as String;
        shopOperatorInfoData.kindShopCancelDt = value['kindShopCancelDt'] as String;
        shopOperatorInfoData.exchangeNotice = value['exchangeNotice'] as String;
        shopOperatorInfoData.returnNotice = value['returnNotice'] as String;
        shopOperatorInfoData.rejectNotice = value['rejectNotice'] as String;
        shopOperatorInfoData.reserveTerm = value['reserveTerm'] as String;
        shopOperatorInfoData.lAuth = value['lAuth'] as String;
        shopOperatorInfoData.lTel = value['lTel'] as String;
        shopOperatorInfoData.lSeller = value['lSeller'] as String;

        AuthService.ShopStatus = shopOperatorInfoData.absentYn;

        retValue = '00';
      }
    });

    if (isRefresh == true) {
      setState(() {});
    }

    return retValue;
  }

  postReserveTime(List<ShopOperateReserveTimeModel> setData) async {
    if(setData.length == 0)
      return;

    ShopOperateSetReserveTimeModel sendData = ShopOperateSetReserveTimeModel();
    sendData.shopCode = AuthService.SHOPCD;
    sendData.userId = AuthService.uCode;
    sendData.reserTimePostUnits = setData;

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ReserveController.to.setReserTime(sendData.toJson()))
    );

    if (value == null) {
      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
    }
    else {
      if (value == '00') {

      }
      else{
        ISAlert(context, content: '정상 등록되지 않았습니다.\n→ $value ');
      }
    }
  }

  postReserveTimeCancel(List<ShopOperateReserveTimeModel> setData) async {
    if(setData.length == 0)
      return;

    ShopOperateSetReserveTimeModel sendData = ShopOperateSetReserveTimeModel();
    sendData.shopCode = AuthService.SHOPCD;
    sendData.userId = AuthService.uCode;
    sendData.reserTimePostUnits = setData;

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ReserveController.to.setReserTimeCancel(sendData.toJson()))
    );

    if (value == null) {
      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
    }
    else {
      if (value == '00') {

      }
      else{
        ISAlert(context, content: '정상 등록되지 않았습니다.\n→ $value ');
      }
    }
  }

  Future<String?> requestAPIData() async {
    String? ret1 = '00';
    String? ret4 = '00';
    String? ret5 = '00';
    String? ret6 = '00';
    String? ret7 = '00';

    if (showCategoryEnabled() == false){
      ret1 = await requestProductDeliInfo();
    }

    ret4 = await requestOperateHourInfo();
    ret5 = await requestOperateInfo();
    ret6 = await requestBreakTimeHourInfo();
    // ret7 = await requestOperateDayOffData();

    if (ret1 != '00') {      return ret1.toString();    }
    else              {      setState(() { });          }

    if (ret4 != '00') {      return ret4.toString();    }
    else              {      setState(() { });          }

    if (ret5 != '00') {      return ret5.toString();    }
    else              {      setState(() { });          }

    if (ret6 != '00') {      return ret6.toString();    }
    else              {      setState(() { });          }

    if (ret7 != '00') {      return ret7.toString();    }
    else              {      setState(() { });          }

    return '00';
  }

  bool showCategoryEnabled() {
    if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER){
      return false;
    }
    else if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET){
      return AuthService.TradShopMainYn == 'Y' ? false : true;
    }
    else if(AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET){
      return false;
    }
    else {
      return true;
    }
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());
    Get.put(RequestController());
    Get.put(ReserveController());

    WidgetsBinding.instance.addPostFrameCallback((c) async {
      requestReservedayOffAPIData('1');
      requestReservedayOffAPIData('3');
      requestReservedayOffAPIData('5');

      // if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER){
      //   requestProductDeliInfo();
      // }
      //
      // if(AuthService.ShopType.toString().contains('9')){
      //   requestReserveTimeAPIData();
      //   requestReserveCasesPeopleAPIData();
      // }
      //
      // requestOperateHourInfo();
      // requestAPIData();

      var value = await showDialog(
          context: context,
          barrierColor: Colors.transparent,
          builder: (context) => FutureProgressDialog(requestAPIData())
      );

      if (value == '00') {
        //Navigator.of(context).pop(true);
        setState(() {

        });
      }
      else {
        ISAlert(context, content: '정상 등록되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
    _scrollController2.dispose();


    _setData.clear();
    _setCancelData.clear();
    mOperateHourList.clear();
    mProductDeliInfoList.clear();
    shopOperateReserveTimeData.clear();

  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
          var value = await showDialog(
              context: context,
              barrierColor: Colors.transparent,
              builder: (context) => FutureProgressDialog(requestAPIData())
          );

          if (value == '00') {
            //Navigator.of(context).pop(true);
            setState(() {

            });
          }
          else {
            ISAlert(context, content: '정상 등록되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
          }
        });
      }
    }
  }

  bool? checkboxVal = false;

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    const TextStyle elementStyle = TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY);

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
        controller: _scrollController,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ISLabelBarSub(
              title: '영업 상태',
              bodyPadding: const EdgeInsets.only(top: 15, bottom: 15, right: 32, left: 0),
              trailing: (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET && AuthService.TradShopMainYn == 'Y') ? const SizedBox.shrink() : ISButton(
                child: const Text('변경'),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => const ShopStatusEdit(),
                  ).then((value) async {
                    //if (value == true) {
                    await Future.delayed(const Duration(milliseconds: 500), () {
                      requestOperateInfo(isRefresh: true);
                    });
                    //}
                  });
                  // currentMode = MODE_SHOPSTATUS_VIEW;
                  //
                  // setState(() {
                  //   _scrollController!.jumpTo(0.0);
                  // });
                },
              ),
              body: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Flexible(
                    flex: 1,
                    fit: FlexFit.tight,
                    child: Container(
                        margin: const EdgeInsets.only(left: 20),
                      //color: Colors.yellow,
                        alignment: Alignment.centerLeft,
                        child: Text(getShopStatusStr(shopOperatorInfoData.absentYn), style: TextStyle(color: shopOperatorInfoData.absentYn == 'Y'? Colors.blue : Colors.red, fontSize:26, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),)
                    ),
                  ),
                  // Flexible(
                  //   flex: 2,
                  //   child: Container(
                  //     //width: MediaQuery.of(context).size.width - 500,//double.infinity,
                  //     padding: EdgeInsets.symmetric(vertical: 10, horizontal: Responsive.isMobile(context) ? 10 : 30),
                  //     decoration: const BoxDecoration(
                  //         color: Color.fromARGB(255, 240, 240, 240),
                  //         borderRadius: BorderRadius.all(Radius.circular(10))),
                  //     // height: 35,
                  //     child: const Text('· 영업 상태가 휴점 중일 경우와 정기 요일별 영업시간에 해당하는 시간이 아닐 경우,\n    “지금은 운영시간이 아니예요.“라는 문구 고객에게 안내.\n· 고객이 상품을 장바구니까지 담는 건 가능함.\n· 장바구니에서 “지금은 배달이 어려워요. 운영 시간에 다시 칮아주세요” 문구 고객에게 안내.',
                  //       style: TextStyle(fontSize:12, color: Colors.black87, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),),
                  //   ),
                  // )
                ],
              ),
            ),
            ISLabelBarSub(
              title: '요일별 정기 영업시간',
              bodyPadding: EdgeInsets.zero,//const EdgeInsets.symmetric(vertical: 10),
              body: SizedBox(
                width: double.infinity,
                child: DataTable(
                  headingRowHeight: 0.01,
                  dataRowHeight: 40.0,
                  columnSpacing: 0,
                  horizontalMargin: Responsive.isMobile(context) ? 5 : 8,
                  showCheckboxColumn: false,
                  columns: const [
                    DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.left))),
                    DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.right))),
                  ],
                  rows: mOperateHourList.map((item){
                    return DataRow(
                        onSelectChanged: (bool? value) {
                          ShopOperateHourListModel shopOperateHourFormData = ShopOperateHourListModel();
                          shopOperateHourFormData.jobGbn = 'U';
                          shopOperateHourFormData.tipDay = item.tipDay;
                          shopOperateHourFormData.tipFrStand = item.tipFrStand;
                          shopOperateHourFormData.tipToStand = item.tipToStand;
                          shopOperateHourFormData.tipNextDay = item.tipNextDay;

                          showDialog(
                            context: context,
                            barrierDismissible: true,
                            builder: (context) => ShopOperateHourEdit(sData: shopOperateHourFormData),
                          ).then((value) async {
                            await Future.delayed(const Duration(milliseconds: 500), () {
                              requestOperateHourInfo();
                              setState(() {

                              });
                            });
                          });

                        },
                        cells: [
                          DataCell(Align(alignment: Alignment.centerLeft,
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                                child: Text('${Utils.getDay(item.tipDay!) ?? '--'} ${Utils.getTimeFormat(item.tipFrStand!)} ~ ${Utils.getTimeFormat(item.tipToStand!)}', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                              ))
                          ),
                          DataCell(Align(alignment: Alignment.centerRight,
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    // ISButton(
                                    //   child: const Text('변경'),
                                    //   onPressed: () {
                                    //     ShopOperateHourListModel shopOperateHourFormData = ShopOperateHourListModel();
                                    //     shopOperateHourFormData.jobGbn = 'U';
                                    //     shopOperateHourFormData.tipDay = item.tipDay;
                                    //     shopOperateHourFormData.tipFrStand = item.tipFrStand;
                                    //     shopOperateHourFormData.tipToStand = item.tipToStand;
                                    //     shopOperateHourFormData.tipNextDay = item.tipNextDay;
                                    //
                                    //     showDialog(
                                    //       context: context,
                                    //       barrierDismissible: true,
                                    //       builder: (context) => ShopOperateHourEdit(sData: shopOperateHourFormData),
                                    //     ).then((value) async {
                                    //       //if (value == true) {
                                    //       await Future.delayed(const Duration(milliseconds: 500), () async {
                                    //         requestOperateHourInfo();
                                    //         await Future.delayed(const Duration(milliseconds: 500), () {
                                    //           setState(() {
                                    //           });
                                    //         });
                                    //       });
                                    //       //}
                                    //     });
                                    //     // currentMode = MODE_OPENDAYTIME_VIEW;
                                    //     //
                                    //     // setState(() {
                                    //     //   _scrollController!.jumpTo(0.0);
                                    //     // });
                                    //   },
                                    // ),
                                    // const SizedBox(width: 8,),
                                    // ISButton(
                                    //   isReverseColor: true,
                                    //   child: const Text('삭제'),
                                    //   onPressed: () {
                                    //     ISConfirm(context, '영업시간 삭제', '[${Utils.getDay(item.tipDay!) ?? '--'}] 영업시간을(를) 삭제하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0), (context, isOK) async {
                                    //       Navigator.of(context).pop();
                                    //
                                    //       if (isOK){
                                    //         var value = await showDialog(
                                    //             context: context,
                                    //             barrierColor: Colors.transparent,
                                    //             builder: (context) => FutureProgressDialog(ShopController.to.deleteOperateHourInfo(item.tipDay!, item.tipSeq!))
                                    //         );
                                    //
                                    //         if (value == null) {
                                    //           ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                    //         }
                                    //         else {
                                    //           if (value == '00') {
                                    //             requestOperateHourInfo(isRefresh: true);
                                    //           }
                                    //           else{
                                    //             ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ $value ');
                                    //           }
                                    //         }
                                    //       }
                                    //     });
                                    //   },
                                    // ),
                                  ],
                                ),
                              )
                          )
                          ),
                        ]
                    );
                  }).toList(),
                ),
              ),
              trailing: ISButton(
                child: const Text('변경'),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => ShopOperateSTimeEdit(s_time: s_time),
                  ).then((value) async {
                    await Future.delayed(const Duration(milliseconds: 500), () {
                      requestOperateHourInfo(isRefresh: true);
                    });
                  });
                },
              ),
            ),
            ISLabelBarSub(
              title: '휴무일',
              bodyPadding: const EdgeInsets.only(top: 10, bottom: 15, right: 32, left: 20),
              body: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: EdgeInsets.only(left: 5, top: 10, bottom: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 5,),
                        const Row(
                          children: [
                            Text('공휴일', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                            Tooltip(
                              richMessage: TextSpan(
                                text: '* ',
                                children: [
                                  TextSpan(
                                    text: '주말(토,일)',
                                    style: TextStyle(fontWeight: FontWeight.bold, color: Colors.lightBlueAccent),
                                  ),
                                  TextSpan(
                                    text: "은 별도로 ",
                                  ),
                                  TextSpan(
                                    text: '휴무일을 설정',
                                    style: TextStyle(fontWeight: FontWeight.bold, color: Colors.lightBlueAccent),
                                  ),
                                  TextSpan(
                                    text: " 해주세요",
                                  ),
                                  TextSpan(
                                    text: "\n\n",
                                  ),
                                  TextSpan(text: "[설정되는 공휴일]", style: TextStyle(fontWeight: FONT_BOLD)),
                                  TextSpan(
                                    text: "\n",
                                  ),
                                  TextSpan(
                                    text: "- 국경일 중 3.1절, 광복절, 개천절 및 한글날\n- 1월 1일\n- 설날 전날, 설날, 설날 다음날(음력 12월 말일, 1월 1일, 2일)\n",
                                  ),
                                  TextSpan(
                                    text: "- 석가탄신일(음력 4월 8일)\n- 어린이날(5월 5일)\n- 현충일(6월 6일)\n- 추석 전날, 추석, 추석 다음날(음력 8월 14일, 15일, 16일)\n",
                                  ),
                                  TextSpan(
                                    text: "- 성탄절(12월 25일)\n- 「공직선거법」 제34조 따른 임기 만료에 의한 선거의 선거일\n- 기타 정부에서 수시 지정하는 날",
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding: EdgeInsets.only(left: 5.0, top: 2, right: 5.0),
                                child: Icon(
                                  Icons.help_outline,
                                  color: Colors.blue,
                                  size: 20,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 5,),
                        Text(dayOff_1_foDay, style: elementStyle),
                      ],
                    ),
                  ),
                  Divider(height: 1,),
                  Container(
                    padding: EdgeInsets.only(left: 5, top: 10, bottom: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 5,),
                        const Row(
                          children: [
                            Text('정기 휴무일', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                            Tooltip(
                              richMessage: TextSpan(
                                children: [
                                  TextSpan(text: "[정기 휴무일 주기 안내]", style: TextStyle(fontWeight: FONT_BOLD)),
                                  TextSpan(
                                    text: "\n\n",
                                  ),
                                  TextSpan(
                                    text: "매월 첫째\n- 매월 1일부터 7일 사이에 위치한 요일에 휴무일이 설정 됩니다.\n",
                                  ),
                                  TextSpan(
                                    text: "매월 둘째\n- 매월 8일부터 14일 사이에 위치한 요일에 휴무일이 설정 됩니다.\n",
                                  ),
                                  TextSpan(
                                    text: "매월 셋째\n- 매월 15일부터 21일 사이에 위치한 요일에 휴무일이 설정 됩니다.\n",
                                  ),
                                  TextSpan(
                                    text: "매월 넷째\n- 매월 22일부터 28일 사이에 위치한 요일에 휴무일이 설정 됩니다.\n",
                                  ),
                                  TextSpan(
                                    text: "매월 다섯째\n- 매월 28일 이후에 위치한 요일에 휴무일이 설정 됩니다.\n",
                                  ),
                                  TextSpan(
                                    text: "매월 마지막\n- 매월 마지막날에서 6일전부터 말일 사이에 위치한 요일에 휴무일이 설정 됩니다.\n",
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding: EdgeInsets.only(left: 5.0, top: 2, right: 5.0),
                                child: Icon(
                                  Icons.help_outline,
                                  color: Colors.blue,
                                  size: 20,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 5,),
                        Column(
                            children: List.generate(dayOff_3.list!.length, (index) {
                              return Row(
                                children: [
                                  SizedBox(width: 100, child: Text(convertFoDay(dayOff_3.list![index]['foDay'].toString()), style: elementStyle)),
                                  const SizedBox(width: 10),
                                  Text(convertToDay(dayOff_3.list![index]['toDay'].toString()), style: elementStyle),
                                ],
                              );
                            })),
                      ],
                    ),
                  ),
                  Divider(height: 1,),
                  Container(
                    padding: EdgeInsets.only(left: 5, top: 10, bottom: 15),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('임시 휴무일', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                        SizedBox(height: 5,),
                        Column(
                            children: List.generate(dayOff_5.list!.length, (index) {
                              return Row(
                                children: [
                                  Text(Utils.getYearMonthDayFormat(dayOff_5.list![index]['foDay'].toString()), style: elementStyle),
                                  Text(' ~ '),
                                  Text(Utils.getYearMonthDayFormat(dayOff_5.list![index]['toDay'].toString()), style: elementStyle),
                                ],
                              );
                            })),
                      ],
                    ),
                  ),
                ],
              ),
              trailing: ISButton(
                child: const Text('변경'),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => ShopReserveDayOffEdit(sData_1: dayOff_1, sData_3: dayOff_3, sData_5: dayOff_5),
                  ).then((value) async {
                    //if (value == true) {
                    await Future.delayed(const Duration(milliseconds: 500), () async {
                      requestOperateHourInfo();
                      await Future.delayed(const Duration(milliseconds: 500), () {
                        setState(() {
                        });
                      });
                    });
                    //}
                  });
                },
              ),
            ),
            ISLabelBarSub(
              title: '휴게시간(브레이크 타임)',
              bodyPadding: EdgeInsets.zero,//const EdgeInsets.symmetric(vertical: 10),
              body: SizedBox(
                width: double.infinity,
                child: DataTable(
                  headingRowHeight: 0.01,
                  dataRowHeight: 40.0,
                  columnSpacing: 0,
                  horizontalMargin: Responsive.isMobile(context) ? 5 : 8,
                  showCheckboxColumn: false,
                  columns: const [
                    DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.left))),
                  ],
                  rows: breakTimeHourList.map((item) {
                    return DataRow(
                        onSelectChanged: (bool? value) {
                          ShopBreakTimeHourListModel shopBreakTimeHourFormData = ShopBreakTimeHourListModel();
                          shopBreakTimeHourFormData.shopCd = AuthService.uCode;
                          shopBreakTimeHourFormData.sbGbn = item.sbGbn;
                          shopBreakTimeHourFormData.dayGbn = item.dayGbn;
                          shopBreakTimeHourFormData.openTime = item.openTime;
                          shopBreakTimeHourFormData.closeTime = item.closeTime;
                          shopBreakTimeHourFormData.useGbn = item.useGbn;
                          shopBreakTimeHourFormData.nextDayYn = item.nextDayYn;
                        },
                        cells: [
                          DataCell(Align(alignment: Alignment.centerLeft,
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                                child: Row(
                                  children: [
                                    item.dayGbn! == '1'
                                        ? Text('${Utils.getDay(item.dayGbn!) ?? '--'}', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: Colors.red),)
                                        : item.dayGbn! == '7'
                                        ? Text('${Utils.getDay(item.dayGbn!) ?? '--'}', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: Colors.blue),)
                                        : Text('${Utils.getDay(item.dayGbn!) ?? '--'}', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                                    const SizedBox(width: 5,),
                                    Text('${Utils.getTimeFormat(item.openTime!)} ~ ${Utils.getTimeFormat(item.closeTime!)}', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                                  ],
                                ),
                              ))
                          ),
                        ]
                    );
                  }).toList(),
                ),
              ),
              trailing: ISButton(
                child: const Text('변경'),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => ShopOperateBTimeEdit(b_time: b_time),
                  ).then((value) async {
                    //if (value == true) {
                    await Future.delayed(const Duration(milliseconds: 500), () {
                      requestBreakTimeHourInfo(isRefresh: true);
                    });
                    //}
                  });
                },
              ),
            ),
            ISLabelBarSub(
              title: AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET && AuthService.TradShopMainYn == 'Y'  ? '시장 리뷰' : '고객 리뷰',
              body: Container(
                alignment: Alignment.centerLeft,
                width: double.infinity,
                child: _buildPanelContainer(
                    width: 60,
                    color: shopOperatorInfoData.reviewUseGbn == 'Y' ? Colors.green.shade300 : Colors.red.shade300 ,
                    child: Text(shopOperatorInfoData.reviewUseGbn == 'Y' ? '사용중' : '미사용', style: const TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON))
                ),
              ),
              trailing: ISButton(
                child: const Text('변경'),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => ShopReviewUseEdit(sReviewUseGbn: shopOperatorInfoData.reviewUseGbn),
                  ).then((value) async {
                    //if (value == true) {
                    await Future.delayed(const Duration(milliseconds: 500), () {
                      requestOperateInfo(isRefresh: true);
                    });
                    //}
                  });
                  // currentMode = MODE_REVIEWUSE_VIEW;
                  //
                  // setState(() {
                  //   _scrollController!.jumpTo(0.0);
                  // });
                },
              ),
            ),
            if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FOOD || (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET && AuthService.TradShopMainYn != 'Y'))
              ISLabelBarSub(
                title: '아동 급식',
                body: _buildPanelContainer(color: shopOperatorInfoData.childMealYn == 'Y' ? Colors.green.shade300 : Colors.red.shade300 , width: 80, child: Text(shopOperatorInfoData.childMealYn == 'Y' ? '사용 가능' : '사용 불가', style: TextStyle(color: Colors.white, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON))),
                trailing: Row(
                  children: [
                    ISCheckbox(
                        label: Responsive.isMobile(context) ? '아동급식카드 사용 시\n최소 주문 금액 미적용' : '아동급식카드 사용 시 최소 주문 금액 미적용',
                        value: shopOperatorInfoData.minAmtPass == 'Y' ? true : false,
                        onChanged: (v) async {
                          shopOperatorInfoData.minAmtPass = (v == true) ? 'Y' : 'N';

                          ShopOperateEditModel sendData = ShopOperateEditModel();
                          sendData.jobGbn = '8';
                          sendData.shopCd = AuthService.SHOPCD;
                          sendData.minAmtPass = shopOperatorInfoData.minAmtPass;
                          sendData.modUcode = AuthService.uCode;
                          sendData.modName = AuthService.uName;

                          var value = await showDialog(
                              context: context,
                              builder: (context) => FutureProgressDialog(ShopController.to.updateOperateInfo(sendData.toJson()))
                          );

                          if (value == null) {
                            ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                          }
                          else {
                            if (value == '00') {
                              await Future.delayed(const Duration(milliseconds: 500), () {
                                requestOperateInfo(isRefresh: true);

                                if (shopOperatorInfoData.minAmtPass == 'Y'){
                                  ISAlert(context, title: '아동 급식', constraints: const BoxConstraints(maxWidth: 460.0),
                                      content: '아동급식카드 사용 [최소 주문 금액 미적용]이 설정되었습니다. \n\n최소 주문 금액 미만의 주문도 받습니다.\n(해당 주문은 최소 주문 금액의 배달팁이 적용됩니다.)');
                                }
                                else{
                                  ISAlert(context, title: '아동 급식', constraints: const BoxConstraints(maxWidth: 460.0),  content: '아동급식카드 사용 [최소 주문 금액 미적용]이 해제되었습니다. \n\n최소 주문 금액 미만의 주문은 받지 않습니다.');
                                }
                              });
                            }
                            else {
                              ISAlert(context, content: '정상 등록되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
                            }
                          }
                        }
                    ),
                    const SizedBox(width: 4,),
                    Tooltip(
                      decoration: BoxDecoration(
                          color: Colors.white,
                          border: const Border.fromBorderSide(BorderSide(width: 1, color: Color(0xff01CAFF))),
                          borderRadius: BorderRadius.circular(4.0),
                      ),
                      textStyle: const TextStyle(fontSize: 13, color: Colors.black54, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                      triggerMode: TooltipTriggerMode.tap,
                      message: '해당 항목 체크 시, 앱 내 아동급식을 통한 주문 시, 최소 주문 금액 조건 없이 주문이 가능합니다.\n* 아동급식카드 외 다른 결제 수단으로 결제 시, 해당되지 않습니다.',
                      child: const Icon(Icons.help_outline, color: Colors.blue,),
                    )
                  ],
                ),
              ),
            if (showCategoryEnabled() == false)...[
              ISLabelBarSub(
                title: '배송 안내',
                bodyPadding: EdgeInsets.zero,//const EdgeInsets.symmetric(vertical: 10),
                body: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      padding: EdgeInsets.zero,
                      itemBuilder: (ctx, index) {
                        return SizedBox(
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 8,),
                              Text(mProductDeliInfoList[index].title!, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                              const SizedBox(height: 4,),
                              Text(mProductDeliInfoList[index].content!, style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                              const SizedBox(height: 8,),
                            ],
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) { return const Divider(thickness: 1, height: 0.0,); },
                      itemCount: mProductDeliInfoList.length
                  ),
                ),
                trailing: ISButton(
                  child: const Text('변경'),
                  onPressed: () {
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => ShopProductDeliInfoEdit(sData: mProductDeliInfoList),
                    ).then((value) async {
                      //if (value == true) {
                      await Future.delayed(const Duration(milliseconds: 250), () async {
                        requestProductDeliInfo();
                        await Future.delayed(const Duration(milliseconds: 250), () {
                          setState(() { });
                        });
                      });
                      //}
                    });
                    // currentMode = MODE_DELIVERYINFO_VIEW;
                    //
                    // setState(() {
                    //   _scrollController!.jumpTo(0.0);
                    // });
                  },
                ),
              ),
              ISLabelBarSub(
                title: '반품/교환 안내',
                body: Container(
                  alignment: Alignment.centerLeft,
                  width: double.infinity,
                  //padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 4,),
                          _buildPanelContainer(width: 70, height: 26, child: const Text('교환 안내', style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)),
                          const SizedBox(height: 8,),
                          Text(shopOperatorInfoData.exchangeNotice!, style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                          //const SizedBox(height: 4,),
                        ],
                      ),
                      const Divider(),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 4,),
                          _buildPanelContainer(width: 70, height: 26, child: const Text('반품 안내', style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)),
                          const SizedBox(height: 8,),
                          Text(shopOperatorInfoData.returnNotice!, style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                          //const SizedBox(height: 4,),
                        ],
                      ),
                      const Divider(),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 4,),
                          _buildPanelContainer(width: 136, height: 26, child: const Text('교환 및 환불 불가 안내', style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)),
                          const SizedBox(height: 8,),
                          Text(shopOperatorInfoData.rejectNotice!, style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                          //const SizedBox(height: 4,),
                        ],
                      )
                    ],
                  ),
                ),
                trailing: ISButton(
                  child: const Text('변경'),
                  onPressed: () {
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => ShopExchangeInfoEdit(sData: shopOperatorInfoData),
                    ).then((value) async {
                      //if (value == true) {
                      await Future.delayed(const Duration(milliseconds: 250), () async {
                        requestOperateInfo();
                        await Future.delayed(const Duration(milliseconds: 250), () {
                          setState(() { });
                        });
                      });
                      //}
                    });
                  },
                ),
              ),
            ],
            if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER)...[
              ISLabelBarSub(
                title: '법적 고지 안내',
                body: Container(
                  alignment: Alignment.centerLeft,
                  width: double.infinity,
                  //padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 4,),
                          Wrap(
                            children:
                            [_buildPanelContainer(width: 390, height: Responsive.isMobile(context) ? 55 : 26, child: Padding(padding: Responsive.isMobile(context) ? const EdgeInsets.all(8.0) : EdgeInsets.zero, child: const Text('법에 의한 인증 허가 등을 받았음을 확인할 수 있는 경우 그에 대한 사항', style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),)),],),
                          const SizedBox(height: 8,),
                          Text(shopOperatorInfoData.lAuth!, style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                          //const SizedBox(height: 4,),
                        ],
                      ),
                      const Divider(),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 4,),
                          _buildPanelContainer(width: 310, height: 26, child: const Text('A/S 책임자와 전화번호 또는 소비자 상담 관련 전화번호', style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)),
                          const SizedBox(height: 8,),
                          Text(shopOperatorInfoData.lTel!, style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                          //const SizedBox(height: 4,),
                        ],
                      ),
                      const Divider(),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 4,),
                          _buildPanelContainer(width: 60, height: 26, child: const Text('판매자', style: TextStyle(fontSize: 13, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)),
                          const SizedBox(height: 8,),
                          Text(shopOperatorInfoData.lSeller!, style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                          //const SizedBox(height: 4,),
                        ],
                      )
                    ],
                  ),
                ),
                trailing: ISButton(
                  child: const Text('변경'),
                  onPressed: () {
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => ShopLegalInfoEdit(sData: shopOperatorInfoData),
                    ).then((value) async {
                      //if (value == true) {
                      await Future.delayed(const Duration(milliseconds: 250), () async {
                        requestOperateInfo();
                        await Future.delayed(const Duration(milliseconds: 250), () {
                          setState(() { });
                        });
                      });
                      //}
                    });


                    // currentMode = MODE_LEGALINFO_VIEW;
                    //
                    // setState(() {
                    //   _scrollController!.jumpTo(0.0);
                    // });
                  },
                ),
              ),
              ISLabelBarSub(
                title: '배송 예약 가능 시간 안내',
                body: Container(
                  alignment: Alignment.centerLeft,
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  // child: Text('당일의 경우 예약가능 시간인 (${getReserveHourStr(shopOperatorInfoData.reserveTerm)})시간 이후부터 ${getReserveMinStr(shopOperatorInfoData.reserveTerm)} 간격으로 30일동안 희망 배송 일시를 고객이 선택 가능 합니다.',
                  //   style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                  child: Text.rich(
                      style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                      textAlign: TextAlign.start,
                      TextSpan(children: [
                        const TextSpan(text: '당일의 경우 예약 가능 시간인 ('),
                        TextSpan(text: '${getReserveHourStr(shopOperatorInfoData.reserveTerm)}', style: const TextStyle(color: Colors.lightBlue, )),
                        const TextSpan(text: ')시간 이후부터 '),
                        TextSpan(text: '${getReserveMinStr(shopOperatorInfoData.reserveTerm)}', style: const TextStyle(color: Colors.lightBlue)),
                        const TextSpan(text: ' 간격으로 30일 동안 희망 배송 일시를 고객이 선택 가능합니다.'),
                      ]
                      )
                  ),
                ),
                trailing: ISButton(
                  child: const Text('변경'),
                  onPressed: () {
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => ShopReserveTimeEdit(sData: shopOperatorInfoData),
                    ).then((value) async {
                      //if (value == true) {
                      await Future.delayed(const Duration(milliseconds: 250), () async {
                        requestOperateInfo();
                        await Future.delayed(const Duration(milliseconds: 250), () {
                          setState(() { });
                        });
                      });
                      //}
                    });
                    // currentMode = MODE_RESERVETIMEINFO_VIEW;
                    //
                    // setState(() {
                    //   _scrollController!.jumpTo(0.0);
                    // });
                  },
                ),
              ),
            ],
          ],
        )
    );

  }


  ///////////////// UI Util View

  String getReserveHourStr(String? reserveTerm){
    String? tempStr = '';

    if (shopOperatorInfoData.reserveTerm == '' || shopOperatorInfoData.reserveTerm!.length != 4) {
      return '00';
    }
    else{
      int tempHour = int.parse(shopOperatorInfoData.reserveTerm!.substring(0,2));

      return tempHour.toString();
    }

    return '';
  }

  String getReserveMinStr(String? reserveTerm){
    if (shopOperatorInfoData.reserveTerm == '' || shopOperatorInfoData.reserveTerm!.length != 4) {
      return '00분';
    }
    else{
      String tempMin = shopOperatorInfoData.reserveTerm!.substring(2,4);

      if (tempMin == '30'){
        return '30분';
      }
      else if (tempMin == '00'){
        return '1시간';
      }
      else {
        return '00분';
      }
    }
  }

  Widget _buildPanelContainer({Widget? child, double? width, double? height, Color? color}){
    return Container(
        alignment: Alignment.center,
        //margin: const EdgeInsets.symmetric(horizontal: 4),
        //padding: const EdgeInsets.symmetric(horizontal: 10),
        width: width ?? 120,
        height: height ?? 34,
        decoration: BoxDecoration(
            color: color ?? Colors.grey.shade400,
            borderRadius: BorderRadius.circular(6)
        ),
        child: child
    );
  }

  String getShopStatusStr(String? absentYn) {
    String? tempStr = '';
    if (absentYn == 'Y')        tempStr = '영업 중';
    else if (absentYn == 'N')   tempStr = '휴점 중';
    else                        tempStr = '';

    return tempStr;
  }


}

