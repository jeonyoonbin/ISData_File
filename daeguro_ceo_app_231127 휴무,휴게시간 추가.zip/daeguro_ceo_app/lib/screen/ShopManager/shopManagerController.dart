import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:daeguro_ceo_app/network/DioReserveClient.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ShopController extends GetxController{
  static ShopController get to => Get.find();
  RxString ccCode = ''.obs;
  String msg = '';

  RxString? packMinCostError = ''.obs;

  RxString? packMinDiscError = ''.obs;
  RxString? packDiscError = ''.obs;

  String dayOff = '0';
  String closure = '0';
  String holiday = '0';

  RxString? endTimeTitle0 = ' 종료'.obs;
  RxString? endTimeTitle1 = ' 종료'.obs;
  RxString? endTimeTitle2 = ' 종료'.obs;
  RxString? endTimeTitle3 = ' 종료'.obs;
  RxString? endTimeTitle4 = ' 종료'.obs;
  RxString? endTimeTitle5 = ' 종료'.obs;
  RxString? endTimeTitle6 = ' 종료'.obs;

  Future<dynamic> getShopInfo() async {
    dynamic qData;

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPINFO}?shop_cd=${AuthService.SHOPCD}&service_gbn=${AuthService.ShopServiceGbn}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateShopInfo(String jobGbn, String data1, String data2, String data3) async {

    final response = await DioClient().put('${ServerInfo.RESTURL_SHOPINFO_SET}?job_gbn=${jobGbn}&shop_cd=${AuthService.SHOPCD}&data_1=${data1}&data_2=${data2}&data_3=${data3}&mod_ucode=${AuthService.uCode}&mod_name=${AuthService.uName}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
  }
  }

  Future<dynamic> getOperateInfo() async {
    dynamic qData;

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPOPERATEINFO}?shop_cd=${AuthService.SHOPCD}&service_gbn=${AuthService.ShopServiceGbn}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateOperateInfo(dynamic data) async {

    final response = await DioClient().put(ServerInfo.RESTURL_SHOPOPERATEINFO_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
  }
  }

  Future<List<dynamic>?> getOperateHourInfo() async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPOPENINGHOURSINFO}?shop_cd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getShopSbTime() async {
    List<dynamic> qData = [];

    final response = await DioClient().get('${ServerInfo.RESTURL_GETSHOP_SBTIME}?shopCd=${AuthService.SHOPCD}&sbGbn=B');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> setShopSbTime(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_SETSHOP_SBTIME, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
    }
  }

  Future<dynamic> deleteOperateHourInfo(String day, String tipSeq) async {

    final response = await DioClient().put('${ServerInfo.RESTURL_SHOPOPERATEHOURINFO_REMOVE}?shopCd=${AuthService.SHOPCD}&day=${day}&tipSeq=${tipSeq}&uCode=${AuthService.uCode}&uName=${AuthService.uName}');

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
  }
  }

  Future<List<dynamic>?> getOperateDeliInfo() async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPDELIINFO}?shop_cd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> setOperateDeliInfo(dynamic data) async {
    final response = await DioClient().post(ServerInfo.RESTURL_SHOPDELIINFO_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else {
      return response.data['code'];
  }
  }

  Future<dynamic> getRegistInfo() async {
    dynamic qData;

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPREGISTINFO}?shop_cd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateRegistInfo(dynamic data) async {

    final response = await DioClient().put(ServerInfo.RESTURL_SHOPREGISTINFO_SET, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
  }
  }

  Future<List<dynamic>?> getShopIntroInfo(String intro_gbn) async {
    List<dynamic> qData = [];

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPINTROLIST}?shop_cd=${AuthService.SHOPCD}&intro_gbn=${intro_gbn}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getShopIntroDetailInfo(String intro_code) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPINTRODETAILINFO}?shop_cd=${AuthService.SHOPCD}&intro_code=${intro_code}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    }
    else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateShopIntroInfo(dynamic data) async {
    final response = await DioClient().put(ServerInfo.RESTURL_SHOPINTRO_SET, data: data);

    return '${response.data['code']}|${response.data['msg']}';
  }

  Future<List<dynamic>?> getMultiShopListData(String multiShopCd) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_MULTISHOP_LIST}?multiShopCd=$multiShopCd');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> getMultiShopCheck(String mvShopCd) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_MULTISHOP_CHECK}?mvShopCd=$mvShopCd');

    if (response.data['code'] == '00') {
      qData = response.data['code'];
    } else {
      return null;
    }

    return qData;
  }

  Future<List<dynamic>?> getMultiShopStatusList() async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_MULTISHOP_STATUS}?shopCd=${AuthService.SHOPCD}&multiShopCd=${AuthService.MultiShopCd}');

    if (response.data['code'] == '00') {
      qData = response.data['data'];
    } else {
      return null;
    }

    return qData;
  }

  Future<dynamic> updateMultiShopAbsent(dynamic data) async {

    final response = await DioClient().put(ServerInfo.RESTURL_MULTISHOP_ABSENT, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    }
    else {
      return response.data['code'];
    }
  }

  Future<dynamic> getDayOffInfo(String calMonth) async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_GETSHOP_DAYOFFINFO}?shopCd=${AuthService.SHOPCD}&month=$calMonth');

    if (response.data['code'] == '00') {
      qData = response.data['data'];

      dayOff = response.data['dayOff'].toString();
      closure = response.data['closure'].toString();
      holiday = response.data['holiday'].toString();

    } else {
      return null;
    }

    return qData;
  }

  // Future<dynamic> setShopNotifyImageInfo(String div, String introCd, String sort, dynamic data) async {
  //
  //   final response = await DioImageClient().put('${ServerInfo.RESTURL_SHOPNOTIFYIMAGE_SET}?div=${div}&intro_cd=${introCd}&sort=${sort}&ucode=${AuthService.uCode}&uname=${AuthService.uName}', data: data);
  //
  //   if (response.data['code'] != '00') {
  //     return response.data['msg'];
  //   }
  //   else
  //     return response.data['code'];
  // }
}