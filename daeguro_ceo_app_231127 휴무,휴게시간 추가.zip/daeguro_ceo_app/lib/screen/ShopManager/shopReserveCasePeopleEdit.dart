import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopReserveCasesPeopleModel.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopReserveCasePeopleEdit extends StatefulWidget {
  final String? sCaseCnt;
  final String? sPeopleCnt;

  const ShopReserveCasePeopleEdit({Key? key, this.sCaseCnt, this.sPeopleCnt})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopReserveCasePeopleEditState();
  }
}

class ShopReserveCasePeopleEditState extends State<ShopReserveCasePeopleEdit> {

  String _caseCnt = '0';
  String _peopleCnt = '0';

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());
    Get.put(ReserveController());

    _caseCnt = widget.sCaseCnt!;
    _peopleCnt = widget.sPeopleCnt!;
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 362),
        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            const Text('최대 예약 건수, 인원 제한 설정', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //const Divider(color: Colors.grey, height: 0.0,),
              const SizedBox(height: 16,),
              ISLabelBarSub(
                title: '매시간 최대 예약 건수',
                body: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ISInput(
                      value: _caseCnt,
                      context: context,
                      height: 35,
                      width: 120,
                      //padding: 0,
                      onChange: (v) {
                        _caseCnt = v;
                        setState(() {
                        });
                      },
                    ),
                    const SizedBox(width: 10),
                    const Text('건')
                  ],
                ),
              ),
              ISLabelBarSub(
                title: '인원 제한 설정',
                body: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ISInput(
                      value: _peopleCnt,
                      context: context,
                      height: 35,
                      width: 120,
                      //padding: 0,
                      onChange: (v) {
                        _peopleCnt = v;
                        setState(() {
                        });
                      },
                    ),
                    const SizedBox(width: 10),
                    const Text('명')
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () {
                ISConfirm(context, '최대 예약 건수 ', '최대 예약 건수 및 인원 제한 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                  Navigator.of(context).pop();

                  if (isOK){
                    ShopReserveCasesPeopleModel sendData = ShopReserveCasesPeopleModel();
                    sendData.shopCd = AuthService.SHOPCD;
                    sendData.ccCode = ShopController.to.ccCode.toString();
                    sendData.casesCnt = _caseCnt;
                    sendData.peopleCnt = _peopleCnt;
                    sendData.userID = AuthService.uCode;

                    var value = await showDialog(
                        context: context,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(ReserveController.to.updateReserveCasesPeople(sendData.toJson()))
                    );

                    if (value == null) {
                      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                    }
                    else {
                      if (value == '00') {
                        Navigator.of(context).pop(true);
                        ISAlert(context, title: '알림', content: '변경이 완료되었습니다.');
                      }
                      else{
                        ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                      }
                    }
                  }
                });
              },
              child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }
}


