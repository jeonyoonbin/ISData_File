import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/network/ImageUploadController.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import 'package:http/http.dart' as http;

import '../../iswidgets/is_optionModel.dart';
import '../../iswidgets/isd_button.dart';
import '../../iswidgets/isd_input.dart';
import '../../iswidgets/isd_search_dropdown.dart';
import '../../layout/responsive.dart';

class RequestShopRegistInfoEdit extends StatefulWidget {
  const RequestShopRegistInfoEdit({Key? key})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return RequestShopRegistInfoEditState();
  }
}

class RequestShopRegistInfoEditState extends State<RequestShopRegistInfoEdit> {

  final ScrollController _registrationScrollController = ScrollController();
  final ScrollController _reportCertificateScrollController = ScrollController();
  final ScrollController _scrollController = ScrollController();

  List<PickedFile>? registrationImageFileList = <PickedFile>[];
  List<PickedFile>? reportCertificateImageFileList = <PickedFile>[];

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
    registrationImageFileList?.clear();
    reportCertificateImageFileList?.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ImageUploadController());
    Get.put(RequestController());
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    const TextStyle elementStyle = TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY);
    const EdgeInsetsGeometry InputPadding = const EdgeInsets.fromLTRB(10, 13, 4, 13);


    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 800),
        contentPadding: const EdgeInsets.all(0.0),
        //const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            const Text('사업자 정보 변경 요청', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 10,),
                    const Text(textAlign: TextAlign.left, '변경유형', style: elementStyle),
                    Container( // 변경 유형
                      alignment: Alignment.centerLeft,
                      height: 50,
                      child: ISSearchDropdown(
                        label: '선택하세요',
                        width: 800,
                        height: 50,
                        value: 'test',
                        onChange: (value) {
                          setState(() {
                          });
                        },
                      ),
                    ),

                    const SizedBox(height: 10,),
                    const Text(textAlign: TextAlign.left, '상호명', style: elementStyle),
                    Container( // 상호명
                      alignment: Alignment.centerLeft,
                      height: 50,
                      child: ISInput(
                        label: '상호명',
                        contentPadding: InputPadding,
                        width: 800,
                        height: 50,
                        value: null,
                        onChange: (v) {
                          setState(() {
                          });
                        },
                      ),
                    ),

                    const SizedBox(height: 10,),
                    const Text(textAlign: TextAlign.left, '사업자등록번호', style: elementStyle),
                    Container( // 사업자 등록번호
                      alignment: Alignment.centerLeft,
                      height: 50,
                      child: ISInput(
                        label: '사업자 등록 번호',
                        contentPadding: InputPadding,
                        width: 800,
                        height: 50,
                        value: null,
                        onChange: (v) {
                          setState(() {
                          });
                        },
                      ),
                    ),
                    const Text('* - 제외하고 입력해 주세요',style: TextStyle(color: Colors.red, fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),

                    const SizedBox(height: 10,),
                    const Text(textAlign: TextAlign.left, '대표자명', style: elementStyle),
                    Container( // 대표자 명
                      alignment: Alignment.centerLeft,
                      height: 50,
                      child: ISInput(
                        label: '대표자명',
                        contentPadding: InputPadding,
                        width: 800,
                        height: 50,
                        value: null,
                        counterText: '',
                        onChange: (v) {
                          setState(() {
                          });
                        },
                      ),
                    ),

                    const SizedBox(height: 10,),
                    const Text(textAlign: TextAlign.left, '업태', style: elementStyle),
                    Container( // 업태
                      alignment: Alignment.centerLeft,
                      height: 50,
                      child: ISInput(
                        label: '업태',
                        contentPadding: InputPadding,
                        width: 800,
                        height: 50,
                        value: null,
                        counterText: '',
                        onChange: (v) {
                          setState(() {
                          });
                        },
                      ),
                    ),

                    const SizedBox(height: 10,),
                    const Text(textAlign: TextAlign.left, '업종', style: elementStyle),
                    Container( // 업종
                      alignment: Alignment.centerLeft,
                      height: 50,
                      child: ISInput(
                        label: '업종',
                        contentPadding: InputPadding,
                        width: 800,
                        height: 50,
                        value: null,
                        counterText: '',
                        onChange: (v) {
                          setState(() {
                          });
                        },
                      ),
                    ),

                    const SizedBox(height: 10,),
                    const Text(textAlign: TextAlign.left, '사업자유형', style: elementStyle),
                    Container( // 사업자 유형
                      alignment: Alignment.centerLeft,
                      height: 50,
                      child: Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          ISSearchDropdown(
                            label: '선택하세요',
                            width: 800,
                            height: 50,
                            value: 'test',
                            onChange: (value) {
                              setState(() {
                              });
                            },
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 10,),
                    const Text(textAlign: TextAlign.left, '사업장 주소', style: elementStyle),
                    Row(
                      children: [
                        Flexible(
                          child: ISInput(
                            label: '우편번호',
                            contentPadding: InputPadding,
                            width: 800,
                            height: 50,
                            value: null,
                            counterText: '',
                            onChange: (v) {
                              setState(() {
                              });
                            },
                          ),
                          flex: 4,
                        ),
                        SizedBox(width: 5),
                        Flexible(
                          child: ISButton(
                            child: const Text('검색'),
                            height: 44,
                            onPressed: (){

                            },
                          ),
                          flex: 1,
                        )
                      ],
                    ),
                    ISInput(
                      label: '주소',
                      contentPadding: InputPadding,
                      width: 800,
                      height: 50,
                      value: null,
                      counterText: '',
                      onChange: (v) {
                        setState(() {
                        });
                      },
                    ),
                    ISInput(
                      label: '상세주소',
                      contentPadding: InputPadding,
                      width: 800,
                      height: 50,
                      value: null,
                      counterText: '',
                      onChange: (v) {
                        setState(() {
                        });
                      },
                    ),

                    const SizedBox(height: 10,),
                    Text(
                      registrationImageFileList!.isEmpty ? '통장사본' : '통장사본(총 ${registrationImageFileList!.length}개)',
                      style: elementStyle,
                    ),
                    if (registrationImageFileList!.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 120,
                        child: Scrollbar(
                          thumbVisibility: true,
                          trackVisibility: true,
                          controller: _registrationScrollController,
                          radius: const Radius.circular(0.0),
                          showTrackOnHover: true,
                          thickness: 8,
                          child: ListView.builder(
                              controller: _registrationScrollController,
                              itemCount: registrationImageFileList!.length,
                              scrollDirection: Axis.horizontal,
                              itemBuilder: (context, idx) {
                                return Stack(
                                  alignment: AlignmentDirectional.topEnd,
                                  children: [
                                    (registrationImageFileList![idx] == null)
                                        ? const Image(
                                      image: AssetImage('images/thumbnail-empty.png'),
                                      width: 100,
                                      height: 100,
                                    )
                                        : Padding(
                                      padding: const EdgeInsets.fromLTRB(4, 0, 4, 20), //symmetric(horizontal: 4, vertical: 20),
                                      child: Image.network(
                                        registrationImageFileList![idx].path,
                                        fit: BoxFit.cover,
                                        gaplessPlayback: true,
                                        width: 100,
                                        height: 100,
                                        loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                          if (loadingProgress == null) return child;
                                          return const Center(
                                            child: CircularProgressIndicator(
                                              valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                            ),
                                          );
                                        },
                                        errorBuilder: (context, error, stackTrace) {
                                          return const Image(
                                            image: AssetImage('images/thumbnail-empty.png'),
                                            width: 100,
                                            height: 100,
                                          );
                                        },
                                      ),
                                    ),
                                    Positioned(
                                      top: 2,
                                      right: 6,
                                      child: InkWell(
                                        child: const Image(
                                          image: AssetImage('images/image_remove_small.png'),
                                          width: 20,
                                          height: 20,
                                        ),
                                        onTap: () {
                                          registrationImageFileList!.removeAt(idx);
                                          setState(() {});
                                        },
                                      ),
                                    )
                                  ],
                                );
                              }),
                        ),
                      ),
                    ],
                    Container(
                      constraints: const BoxConstraints(minWidth: 210),
                      width: double.infinity,
                      alignment: Alignment.center,
                      margin: const EdgeInsets.only(top: 10.0),
                      child: InkWell(
                        child: DottedBorder(
                          padding: const EdgeInsets.only(
                            top: 6,
                            bottom: 6,
                          ),
                          color: const Color(0xffDDDDDD),
                          strokeWidth: 1,
                          radius: const Radius.circular(10.0),
                          child: const ClipRRect(
                            borderRadius: BorderRadius.all(Radius.circular(10.0)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                                SizedBox(
                                  width: 8,
                                ),
                                Text(
                                  '이미지 파일 선택',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontFamily: FONT_FAMILY,
                                    color: Color(0xff999999),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        onTap: () async {
                          // 이미지 등록
                          ImagePicker imagePicker = ImagePicker();
                          Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                          imageFile.then((file) async {
                            registrationImageFileList!.add(file!);
                            setState(() {});
                          });
                        },
                      ),
                    ),

                    const SizedBox(height: 20,),
                    Text(
                      reportCertificateImageFileList!.isEmpty ? '영업신고증' : '영업신고증(총 ${reportCertificateImageFileList!.length}개)',
                      style: elementStyle,
                    ),
                    if (reportCertificateImageFileList!.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 120,
                        child: Scrollbar(
                          thumbVisibility: true,
                          trackVisibility: true,
                          controller: _reportCertificateScrollController,
                          radius: const Radius.circular(0.0),
                          showTrackOnHover: true,
                          thickness: 8,
                          child: ListView.builder(
                              controller: _reportCertificateScrollController,
                              itemCount: reportCertificateImageFileList!.length,
                              scrollDirection: Axis.horizontal,
                              itemBuilder: (context, idx) {
                                return Stack(
                                  alignment: AlignmentDirectional.topEnd,
                                  children: [
                                    (reportCertificateImageFileList![idx] == null)
                                        ? const Image(
                                      image: AssetImage('images/thumbnail-empty.png'),
                                      width: 100,
                                      height: 100,
                                    )
                                        : Padding(
                                      padding: const EdgeInsets.fromLTRB(4, 0, 4, 20),
                                      child: Image.network(
                                        reportCertificateImageFileList![idx].path,
                                        fit: BoxFit.cover,
                                        gaplessPlayback: true,
                                        width: 100,
                                        height: 100,
                                        loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                          if (loadingProgress == null) return child;
                                          return const Center(
                                            child: CircularProgressIndicator(
                                              valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                            ),
                                          );
                                        },
                                        errorBuilder: (context, error, stackTrace) {
                                          return const Image(
                                            image: AssetImage('images/thumbnail-empty.png'),
                                            width: 100,
                                            height: 100,
                                          );
                                        },
                                      ),
                                    ),
                                    Positioned(
                                      top: 2,
                                      right: 6,
                                      child: InkWell(
                                        child: const Image(
                                          image: AssetImage('images/image_remove_small.png'),
                                          width: 20,
                                          height: 20,
                                        ),
                                        onTap: () {
                                          reportCertificateImageFileList!.removeAt(idx);
                                          setState(() {});
                                        },
                                      ),
                                    )
                                  ],
                                );
                              }),
                        ),
                      ),
                    ],
                    Container(
                      constraints: const BoxConstraints(minWidth: 210),
                      width: double.infinity,
                      alignment: Alignment.center,
                      margin: const EdgeInsets.only(top: 10.0),
                      child: InkWell(
                        child: DottedBorder(
                          padding: const EdgeInsets.only(
                            top: 6,
                            bottom: 6,
                          ),
                          color: const Color(0xffDDDDDD),
                          strokeWidth: 1,
                          radius: const Radius.circular(10.0),
                          child: const ClipRRect(
                            borderRadius: BorderRadius.all(Radius.circular(10.0)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add_circle_rounded, color: Color(0xff999999), size: 30),
                                SizedBox(
                                  width: 8,
                                ),
                                Text(
                                  '이미지 파일 선택',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontFamily: FONT_FAMILY,
                                    color: Color(0xff999999),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        onTap: () async {
                          // 이미지 등록
                          ImagePicker imagePicker = ImagePicker();
                          Future<PickedFile?> imageFile = imagePicker.getImage(source: ImageSource.gallery);
                          imageFile.then((file) async {
                            reportCertificateImageFileList!.add(file!);
                            setState(() {});
                          });
                        },
                      ),
                    ),
                    const SizedBox(height: 20,),
                  ],
                ),
              ),
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () {
                BuildContext dialogContext = context;

                showDialog(
                  context: context,
                  barrierDismissible: true,
                  builder: (context) => Responsive.isMobile(context) ? mobileChangeInfoCheck(context,dialogContext,appTheme) : desktopChangeInfoCheck(context,dialogContext,appTheme)
                );

              },
              child: const Text('변경 요청', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }
}

Widget desktopChangeInfoCheck(context, dialogContext, appTheme){
  return ContentDialog(
    constraints: BoxConstraints(maxWidth: 700.0, maxHeight: 450),
    contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
    isFillActions: true,
    title: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const SizedBox(width: 20),
        const Text('사업자 정보 변경 요청', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
        fluentUI.SmallIconButton(
          child: fluentUI.Tooltip(
            message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
            child: fluentUI.IconButton(
              icon: const Icon(fluentUI.FluentIcons.chrome_close),
              onPressed: Navigator.of(context).pop,
            ),
          ),
        ),
      ],
    ),
    content: Material(
      color: Colors.transparent,
      borderOnForeground: false,
      child: Column(
        children: [
          const SizedBox(height: 20,),
          const Text('기존 사업자 정보에서 해당 사업자 정보로 변경 하시겠습니까?', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
          const SizedBox(height: 20,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                clipBehavior: Clip.hardEdge,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                height: 230,
                child: Container(
                  padding: const EdgeInsets.all(16.0),
                  width: 300,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('기존 사업자 정보', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                      SizedBox(height: 10,),
                      Text('사업자 번호 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자명 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업태 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업종 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자 유형 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업장 주소 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                    ],
                  ),
                ),
              ),
              SizedBox(width: 20,),
              Icon(Icons.arrow_forward_ios_outlined),
              SizedBox(width: 20,),
              Container(
                clipBehavior: Clip.hardEdge,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                ),
                height: 230,
                child: Container(
                  padding: const EdgeInsets.all(16.0),
                  width: 300,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('변경 사업자 정보', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                      SizedBox(height: 10,),
                      Text('사업자 번호 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자명 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업태 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('업종 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업자 유형 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                      Text('사업장 주소 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),),
                    ],
                  ),
                ),
              )
            ],
          ),
        ],
      ),
    ),
    actions: [
      SizedBox(
        child: FilledButton(
          style: appTheme.popupButtonStyleLeft,
          onPressed: () {
            Navigator.pop(context);
          },
          child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
        ),
      ),
      SizedBox(
        child: FilledButton(
          style: appTheme.popupButtonStyleRight,
          onPressed: () {
            Navigator.pop(context);
            Navigator.pop(dialogContext);
            ISAlert(context,title: '사업자 정보 변경 요청 완료', content: '사업자 정보 변경 요청이 접수되었습니다.\n\n운영사 확인 후, 2~3일 내로 처리될 예정입니다.\n결과는 [변경 요청 내역] 메뉴에서 확인해 주세요.');
          },
          child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
        ),
      ),
    ],
  );
}

Widget mobileChangeInfoCheck(context, dialogContext, appTheme){
  return ContentDialog(
    constraints: BoxConstraints(maxWidth: double.infinity, maxHeight: 800),
    contentPadding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.1, vertical: 15),
    isFillActions: true,
    title: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const SizedBox(width: 20),
        const Text('사업자 정보 변경 요청', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
        fluentUI.SmallIconButton(
          child: fluentUI.Tooltip(
            message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
            child: fluentUI.IconButton(
              icon: const Icon(fluentUI.FluentIcons.chrome_close),
              onPressed: Navigator.of(context).pop,
            ),
          ),
        ),
      ],
    ),
    content: Material(
      color: Colors.transparent,
      borderOnForeground: false,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Text('기존 사업자 정보에서\n해당 사업자 정보로 변경하시겠습니까?', style: TextStyle(fontSize: 17, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
          const SizedBox(height: 10,),
          Container(
            clipBehavior: Clip.hardEdge,
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(10)),
              boxShadow: [
                BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
              ],
            ),
            height: 200,
            child: Container(
              padding: const EdgeInsets.all(16.0),
              width: 330,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('기존 사업자 정보', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                  SizedBox(height: 10,),
                  Text('사업자 번호 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),overflow: TextOverflow.fade,),
                  Text('사업자명 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),overflow: TextOverflow.fade,),
                  Text('업태 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),overflow: TextOverflow.fade,),
                  Text('업종 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),overflow: TextOverflow.fade,),
                  Text('사업자 유형 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),overflow: TextOverflow.fade,),
                  Text('사업장 주소 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY), overflow: TextOverflow.fade,),
                ],
              ),
            ),
          ),
          SizedBox(height: 20,),
          Icon(Icons.arrow_downward_outlined),
          SizedBox(height: 20,),
          Container(
            clipBehavior: Clip.hardEdge,
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(10)),
              boxShadow: [
                BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
              ],
            ),
            height: 200,
            child: Container(
              padding: const EdgeInsets.all(16.0),
              width: 330,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('변경 사업자 정보', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY_NEXON, fontWeight: FONT_BOLD),),
                  SizedBox(height: 10,),
                  Text('사업자 번호 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),overflow: TextOverflow.fade,),
                  Text('사업자명 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),overflow: TextOverflow.fade,),
                  Text('업태 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),overflow: TextOverflow.fade,),
                  Text('업종 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),overflow: TextOverflow.fade,),
                  Text('사업자 유형 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),overflow: TextOverflow.fade,),
                  Text('사업장 주소 : ', style: TextStyle(fontSize: 15, fontFamily: FONT_FAMILY),overflow: TextOverflow.fade,),
                ],
              ),
            ),
          )
        ],
      )
    ),
    actions: [
      SizedBox(
        child: FilledButton(
          style: appTheme.popupButtonStyleLeft,
          onPressed: () {
            Navigator.pop(context);
          },
          child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
        ),
      ),
      SizedBox(
        child: FilledButton(
          style: appTheme.popupButtonStyleRight,
          onPressed: () {
            Navigator.pop(context);
            Navigator.pop(dialogContext);
            ISAlert(context,title: '사업자 정보 변경 요청 완료', content: '사업자 정보 변경 요청이 접수되었습니다.\n\n운영사 확인 후, 2~3일 내로 처리될 예정입니다.\n결과는 [변경 요청 내역] 메뉴에서 확인해 주세요.');
          },
          child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
        ),
      ),
    ],
  );
}