import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/MenuManager/menuGroupListModel.dart';
import 'package:daeguro_ceo_app/models/ReserveManager/reserveShopPictureModel.dart';
import 'package:daeguro_ceo_app/screen/DashBoardManager/dashboardManagerController.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManagerController.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/instance_manager.dart';
import 'package:provider/provider.dart';

class ReserveNotifyImageInfoMain extends StatefulWidget {
  const ReserveNotifyImageInfoMain({Key? key}) : super(key: key);

  @override
  State<ReserveNotifyImageInfoMain> createState() => _ReserveNotifyImageInfoMainState();
}

class _ReserveNotifyImageInfoMainState extends State<ReserveNotifyImageInfoMain> with PageMixin {
  final ScrollController _scrollController = ScrollController();
  final List<ReserveShopPictureModel> dataImageList = <ReserveShopPictureModel>[];

  String? selectedType = '';

  String? selectedItemName;
  String? selectedGroupCd;

  requestAPIData() async {
    var value = await showDialog(context: context, barrierColor: Colors.transparent, builder: (context) => FutureProgressDialog(ReserveController.to.getShopPicture(AuthService.SHOPCD, selectedType.toString(), '1', '1000')));

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다.');
      //Navigator.of(context).pop;
    } else {
      dataImageList.clear();

      value.forEach((element) {
        ReserveShopPictureModel temp = ReserveShopPictureModel();
        temp.seq = element['seq'] as int;
        temp.noticeName = element['noticeName'] as String;
        temp.fileName = element['fileName'] as String;
        temp.fileUrl = element['fileUrl'] as String;
        temp.sortSeq = element['sortSeq'] as int;
        temp.temaName = element['temaName'] as String;
        temp.temaCode = element['temaCode'] as String;

        if(ServerInfo.jobMode == 'real')
          temp.fileUrl = temp.fileUrl.toString().replaceAll('https://image.daeguro.co.kr:40443/', '/');

        dataImageList.add(temp);
      });
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReserveController());


    WidgetsBinding.instance.addPostFrameCallback((c) async {
      requestAPIData();
    });

    //setState(() {});
  }

  @override
  void dispose() {

    super.dispose();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    double contentHeight = MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 398 : 400);
    TextStyle columnTextStyle = const TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY);

    return fluentUI.ScaffoldPage.withPadding(
      resizeToAvoidBottomInset: false,
      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: SingleChildScrollView(
        controller: ScrollController(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ISLabelBarMain(
              leading: Text('매장 사진', style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold)),
            ),
            SizedBox(height: 10),
            ISToggleButtons(
              [
                ISOptionModel(value: '', label: '전체'),
                ISOptionModel(value: '0001', label: '음식'),
                ISOptionModel(value: '0002', label: '내부'),
                ISOptionModel(value: '0003', label: '외부'),
                ISOptionModel(value: '0004', label: '주차장'),
              ],
              buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 5) - 6) : 60,
              defaultValue: selectedType,
              afterOnPress: (v) {
                setState(() {
                  selectedType = v.toString();
                });

                requestAPIData();
              },
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Text('전체 '),
                Text(dataImageList.length.toString(), style: TextStyle(color: Color(0xff01CAFF))),
                Text(' 건 '),
                Tooltip(
                  message: '매장 사진은 최대 100장까지 등록 가능합니다.\n이미지 등록/변경은 대표번호 또는 카카오 "대구로 고객센터"로 접수 부탁드립니다.',
                  child: Icon(
                    Icons.help_outline,
                    color: Colors.blue,
                  ),
                )
              ],
            ),
            SizedBox(height: 15),
            imageListView()
          ],
        ),
      ),
    );
  }

  void _onGroupListReorder(int oldIndex, int newIndex) {
    // 라이브 이벤트 진행중일때 리턴
    //if (widget.eventYn == 'Y') return;

    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final ReserveShopPictureModel item = dataImageList.removeAt(oldIndex);
      dataImageList.insert(newIndex, item);

      List<String> sortDataList = [];
      dataImageList.forEach((element) {
        sortDataList.add(element.seq.toString());
      });

      _editListSort(sortDataList);
    });
  }

  _editListSort(List<String> sortDataList) async {
    String jsonData = jsonEncode(sortDataList);

    var sendData = {
      '"shopCode"': '"' + AuthService.SHOPCD + '"',
      '"temaCode"': '"' + selectedType.toString() + '"',
      '"seq"': jsonData.replaceAll('"', '')
    };

    await ReserveController.to.updateShopPictureListSort(sendData.toString());
  }

  Widget imageListView() {
    final appTheme = context.watch<AppTheme>(); //context.watch<AppTheme>();

    return SizedBox(
      height: 400,
      child: ReorderableListView(
        buildDefaultDragHandles: false,
        scrollController: ScrollController(),
        onReorder: _onGroupListReorder,
        scrollDirection: Axis.vertical,
        padding: const EdgeInsets.only(bottom: 8.0),
        children: List.generate(
          dataImageList.length,
              (index) {
            return Card(
                key: Key('$index'),
                elevation: 1,
                shape: appTheme.cardShapStyle,
                margin: const EdgeInsets.all(4),
                //color: dataGroupList[index].selected == true ? const Color.fromRGBO(165, 216, 252, 1.0) : Colors.white,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                        child: ReorderableDragStartListener(
                            index: index,
                            child: Icon(
                              Icons.reorder,
                              color: Colors.grey,
                              size: 24.0,
                            )),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        alignment: Alignment.center,
                        child: Text(
                          dataImageList[index].temaName ?? '--',
                          style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Container(
                        margin: EdgeInsets.all(5),
                        width: 120,
                        height: 120,
                        child: dataImageList[index].fileName == null
                            ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 80)
                            : Image.network(
                          '${dataImageList[index].fileUrl!}?tm=${Utils.getTimeStamp()}',
                          fit: BoxFit.fitWidth,
                          gaplessPlayback: true,
                          loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                            if (loadingProgress == null) return child;
                            return const Center(
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                              ),
                            );
                          },
                          errorBuilder: (context, error, stackTrace) {
                            return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 80);
                          },
                        ),
                      ),
                    ],
                  ),
                ));
          },
        ),
      ),
    );
  }
}