import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOptionListModel.dart';
import 'package:daeguro_ceo_app/screen/DashBoardManager/dashboardManagerController.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManagerController.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class PackingDiscountEdit extends StatefulWidget {
  final String? discAmt;
  final String? minAmt;
  final String? minDiscAmt;

  const PackingDiscountEdit({Key? key, this.discAmt, this.minAmt, this.minDiscAmt})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return PackingDiscountEditState();
  }
}

class PackingDiscountEditState extends State<PackingDiscountEdit> {

  String? toGoDiscAmt = '0';//[포장할인금액]
  String? toGoMinAmt = '0';// [최소주문금액]
  String? toGoMinDiscAmt = '0';// [포장할인 최소 적용 금액]

  String? couponYN = '';
  String? liveEventYN = '';

  String? sendValiText1;
  String? sendValiText2;

  requestAPIData() async {
      var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(CouponController.to.getCouponSetList('1', '2', DateTime.now().toString(), DateTime.now().toString(), '1')),
      );

      couponYN = value.any((item) => item['status'] == 'Y') ? '사용' : '미사용';
      liveEventYN = DashBoardController().mEventYn == 'Y' ? '사용' : '미사용';
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    toGoDiscAmt = widget.discAmt;
    toGoMinAmt = widget.minAmt;
    toGoMinDiscAmt = widget.minDiscAmt;

    WidgetsBinding.instance.addPostFrameCallback((c) {
        requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();

    Get.put(ShopController()).packMinDiscError?.value = '';
    Get.put(ShopController()).packDiscError?.value = '';
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 417),
        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            Text('포장 할인', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //const Divider(color: Colors.grey, height: 0.0,),
              const SizedBox(height: 16,),
              ISLabelBarSub(
                title: '할인 최소 적용금액',
                body: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Material(
                      color: Colors.transparent,
                      child: ISInput(
                        context: context,
                        value: Utils.getCashComma(toGoMinDiscAmt!),
                        width: 120,
                        textAlign: TextAlign.end,
                        label: '할인 최소 적용금액',
                        // keyboardType: TextInputType.number,
                        inputFormatters: [
                          // FilteringTextInputFormatter.digitsOnly,
                          TextInputFormatter.withFunction(
                                (oldValue, newValue) {
                                  if(newValue.text.isEmpty){
                                    return newValue;
                                  }
                                  try {
                                    final parsedValue = int.parse(newValue.text);
                                    if (parsedValue <= 100000) {
                                      return newValue;
                                    }
                                  } catch (_) {}
                              return oldValue;
                            },
                          ),
                        ],
                        onChange: (v) {
                          toGoMinDiscAmt = v.toString().replaceAll(',', '');

                          try{
                            if(int.parse(v!.toString().replaceAll(',', '')) % 100 != 0){
                              Get.put(ShopController()).packMinDiscError?.value = '100원 단위 이상의 금액만 입력 가능합니다.' ;
                            }
                            else{
                              Get.put(ShopController()).packMinDiscError?.value = '';
                            }
                          }
                          catch(_){
                            Get.put(ShopController()).packMinDiscError?.value = '';
                          }
                        },
                        validator: (v){
                          return sendValiText1;
                        },
                      ),
                    ),
                    const SizedBox(width: 8,),
                    const Text('원', style: TextStyle(fontSize:16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),

                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Obx(() {
                      if(Get.find<ShopController>().packMinDiscError!.value != ''){
                        sendValiText1 = Get.find<ShopController>().packMinDiscError!.value;
                        return Text(sendValiText1!, style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: Colors.redAccent));
                      }
                      else {
                        sendValiText1 = null;
                        return Container();
                      }
                    }),
                  ],
                ),
              ),
              ISLabelBarSub(
                title: '할인금액',
                body: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Material(
                      color: Colors.transparent,
                      child: ISInput(
                        context: context,
                        value: Utils.getCashComma(toGoDiscAmt!),
                        width: 120,
                        textAlign: TextAlign.end,
                        label: '할인금액',
                        // keyboardType: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                          TextInputFormatter.withFunction(
                                (oldValue, newValue) {
                                  if(newValue.text.isEmpty){
                                    return newValue;
                                  }
                                  try {
                                    final parsedValue = int.parse(newValue.text);
                                    if (parsedValue <= 100000) {
                                      return newValue;
                                    }
                                  } catch (_) {}
                              return oldValue;
                            },
                          ),
                        ],
                        onChange: (v) {
                          toGoDiscAmt = v.toString().replaceAll(',', '');

                          try{
                            if(int.parse(v!.toString().replaceAll(',', '')) % 100 != 0){
                              Get.put(ShopController()).packDiscError?.value = '100원 단위 이상의 금액만 입력 가능합니다.' ;
                            }
                            else{
                              Get.put(ShopController()).packDiscError?.value = '';
                            }
                          }
                          catch(_){
                            Get.put(ShopController()).packDiscError?.value = '';
                          }
                        },
                        validator: (v){
                          return sendValiText2;
                        },
                      ),
                    ),
                    const SizedBox(width: 8,),
                    const Text('원', style: TextStyle(fontSize:16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),

                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Obx(() {
                      if(Get.find<ShopController>().packDiscError!.value != ''){
                        sendValiText2 = Get.find<ShopController>().packDiscError!.value;
                        return Text(sendValiText2!, style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: Colors.redAccent));
                      }
                      else {
                        sendValiText2 = null;
                        return Container();
                      }
                    }),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () {
                if(sendValiText1 != null || sendValiText2 != null){
                  ISAlert(context, content: '입력 금액이 올바르지 않습니다.');
                  return;
                }

                BuildContext oldContext = context;

                showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return ContentDialog(
                        constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 720),
                        isFillActions: true,
                        title: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('포장 할인을 등록하시겠습니까?', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY),),
                            fluentUI.SmallIconButton(
                              child: fluentUI.Tooltip(
                                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                                child: fluentUI.IconButton(
                                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                                  onPressed: Navigator.of(context).pop,
                                ),
                              ),
                            ),
                          ],
                        ),
                        content: Material(
                          color: Colors.transparent,
                          child: SingleChildScrollView(
                            child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const SizedBox(height: 10,),
                                    const Text('※ 주의 해당 쿠폰은 다른 혜택과 중복 적용 가능합니다.', style: TextStyle(color: Colors.red, fontSize: 18, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                                    const SizedBox(height: 5,),
                                    const Text( '* 현재 사용 중인 혜택', style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD),),
                                    const SizedBox(height: 5,),
                                    Text('우리 가게 쿠폰 : $couponYN', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL),),
                                    const SizedBox(height: 5,),
                                    Text('라이브 이벤트 : $liveEventYN', style: const TextStyle(fontSize: 14, fontWeight: FONT_NORMAL),),
                                    const SizedBox(height: 18,),
                                  ],
                                )
                            ),
                          ),
                        ),
                        actions: [
                          SizedBox(
                            //width: double.infinity,
                            child: FilledButton(
                              style: ButtonStyle(
                                minimumSize: MaterialStateProperty.all(const Size(60, 70)), //Size.fromHeight(60),
                                backgroundColor: const MaterialStatePropertyAll(Color(0xff333333)),
                                shape: const MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.only(bottomLeft: Radius.circular(11.0)) //.circular(4.0)
                                )),
                              ),
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
                            ),
                          ),
                          SizedBox(
                            //width: double.infinity,
                            child: FilledButton(
                              style: ButtonStyle(
                                minimumSize: MaterialStateProperty.all(const Size(60, 70)), //Size.fromHeight(60),
                                backgroundColor: const MaterialStatePropertyAll(Color(0xff01CAFF)),
                                shape: const MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.only(bottomRight: Radius.circular(11.0)) //BorderRadius.circular(4.0))
                                )),
                              ),
                              onPressed: () async {
                                Navigator.of(context).pop();

                                var value = await showDialog(
                                    context: context,
                                    barrierColor: Colors.transparent,
                                    builder: (context) => FutureProgressDialog(ShopController.to.updateShopInfo('7', toGoDiscAmt!, toGoMinAmt!, toGoMinDiscAmt!))
                                );

                                if (value == null) {
                                  ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
                                }
                                else {
                                  if (value == '00') {
                                    Navigator.of(oldContext).pop(true);
                                    ISAlert(oldContext, title: '알림', content: '변경이 완료되었습니다.');
                                  }
                                  else{
                                    ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                                  }
                                }
                              },
                              child: const Text('등록', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
                            ),
                          ),
                        ],
                      );
                    }
                );
              },
              child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }
}


