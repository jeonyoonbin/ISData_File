import 'dart:js_interop';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListModel.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:provider/provider.dart';

class CommonImageHorizontalPreviewMain extends StatefulWidget {
  final String? title;
  final List<String>? imageList;
  final int? index;

  const CommonImageHorizontalPreviewMain({Key? key, this.title, this.imageList, this.index})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CommonImageHorizontalPreviewMainState();
  }
}

class CommonImageHorizontalPreviewMainState extends State<CommonImageHorizontalPreviewMain> {
  int totalCnt = 0;
  int currentIdx = 0;

  List<String> listData = [];

  @override
  void initState() {
    super.initState();

    listData = widget.imageList!;

    totalCnt = widget.imageList!.length;
    if(widget.index != null){
      currentIdx = widget.index!;
    }

  }
  @override
  void dispose() {
    super.dispose();
    listData.clear();
    widget.imageList?.clear();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 500.0, maxHeight: 720),
      //contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      //isPopupNotice: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text('${widget.title} (${(currentIdx+1)} / ${totalCnt})', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Card(
          clipBehavior: Clip.antiAlias,
          margin: EdgeInsets.zero,
          child: listData[currentIdx] == null
              ? const SizedBox(
              width: double.infinity,
              child: Image(image: AssetImage('images/thumbnail-empty.png'), fit: BoxFit.fill))
              : SizedBox(
                width: double.infinity,
                child: Image.network('${listData[currentIdx].toString().replaceAll('https://review.daeguro.co.kr:45008/', '/')!}?tm=${Utils.getTimeStamp()}', fit: BoxFit.fill, gaplessPlayback: true,
            // loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
            //   if (loadingProgress == null) return child;
            //   return const Center(
            //     child: CircularProgressIndicator(
            //       valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
            //     ),
            //   );
            // },
            errorBuilder: (context, error, stackTrace) {
                return const SizedBox(
                    width: double.infinity,
                    child: Image(image: AssetImage('images/thumbnail-empty.png'), fit: BoxFit.fill));
            },
          ),
              ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              if (currentIdx > 0) {
                currentIdx--;

                setState(() {});
              }
              else{
                //Navigator.pop(context);
              }
            },
            child: const Text('이전', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (currentIdx < (totalCnt-1)) {
                currentIdx++;

                setState(() {});
              }
              else{
                //Navigator.pop(context);
              }
            },
            child: const Text('다음', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}


