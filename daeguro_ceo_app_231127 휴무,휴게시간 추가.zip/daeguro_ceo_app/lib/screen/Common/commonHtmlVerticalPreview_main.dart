import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:webviewx_plus/webviewx_plus.dart';

class CommonHtmlVerticalPreviewMain extends StatefulWidget {
  final String? htmlUri;

  const CommonHtmlVerticalPreviewMain({Key? key, this.htmlUri})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CommonHtmlVerticalPreviewMainState();
  }
}

class CommonHtmlVerticalPreviewMainState extends State<CommonHtmlVerticalPreviewMain> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  late WebViewXController webviewController;

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 700.0, maxHeight: 800),
      //contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      //isPopupNotice: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('설명 이미지(HTML)', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: WebViewX(
          width: 700,
          height: 800,
          onWebViewCreated: (controller) {
            webviewController = controller;
            webviewController.loadContent(widget.htmlUri!.replaceAll('https://image.daeguro.co.kr:40443/', 'https://owner.daeguro.co.kr/'),sourceType: SourceType.url);
          }
        ),
      ),
      actions: [
        // SizedBox(
        //   child: FilledButton(
        //     style: appTheme.popupButtonStyleLeft,
        //     onPressed: () {
        //     },
        //     child: const Text('새 탭에서 보기', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
        //   ),
        // ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleSingle,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('닫기', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}

// Future<String?> fetchHtml(htmlUri) async{
//   var response = await http.get(Uri.parse('${htmlUri.replaceAll('https://image.daeguro.co.kr:40443/', '/')}'));
//   //If the http request is successful the statusCode will be 200
//   if(response.statusCode == 200){
//     String htmlToParse = response.body.toString();
//     return htmlToParse;
//   }
// }
