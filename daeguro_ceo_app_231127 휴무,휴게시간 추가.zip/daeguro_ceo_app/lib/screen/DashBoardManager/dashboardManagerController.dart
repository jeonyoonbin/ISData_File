import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/models/DashBoardManager/dashboard_week_order_model.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListModel.dart';
import 'package:daeguro_ceo_app/models/NoticeManager/noticeListRequestModel.dart';
import 'package:daeguro_ceo_app/network/DioClient.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:provider/provider.dart';

class DashBoardController extends GetxController {
  static DashBoardController get to => Get.find();

  RxList<DashboardWeekOrderModel> dataWeekOrderList = <DashboardWeekOrderModel>[].obs;
  RxList<NoticeListModel> dataNoticeList = <NoticeListModel>[].obs;

  RxString shopRemainAmt = ''.obs;

  RxString mEventYn = ''.obs;
  RxString mFrTime = ''.obs;
  RxString mToTime = ''.obs;

  RxBool isPopupEnabled = false.obs;

  Future<dynamic> getShopWeeklyStat(String packOrderYn, String frDate, String toDate) async {
    List<dynamic> qData = [];

    dataWeekOrderList.value.clear();

    // 통계 합계 날짜 구분을 위한 값
    String _chkDt = '';

    DashboardWeekOrderModel tempData = DashboardWeekOrderModel();

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPWEEKLYSTAT}?jobGbn=120&shop_cd=${AuthService.SHOPCD}&packOrderYn=${packOrderYn}&frDate=${frDate}&toDate=${toDate}');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    }
    else {
      return '조회 오류';
    }

    if (qData.isNotEmpty){
      qData.forEach((element) {
        // 최초 조회 데이터 tempData에 적재
        if (_chkDt == '') {
          _chkDt = element['orderDate'].toString();

          tempData.orderDate = element['orderDate'].toString();
          tempData.totCnt = int.parse(element['totCnt'].toString());
          tempData.totAmt = int.parse(element['totAmt'].toString());
          tempData.okCnt = int.parse(element['okCnt'].toString());
          tempData.okAmt = int.parse(element['okAmt'].toString());
          tempData.cancelCnt = int.parse(element['cancelCnt'].toString());
          tempData.cancelAmt = int.parse(element['cancelAmt'].toString());

          dataWeekOrderList.value.add(tempData);
          return;
        }

        if (element['orderDate'] != _chkDt) {
          // 이전 데이터와 날짜가 다를경우 적재 후 _tempData 갱신
          _chkDt = element['orderDate'].toString();

          dataWeekOrderList.value.add(tempData);
          tempData = DashboardWeekOrderModel();

          tempData.orderDate = element['orderDate'].toString();
          tempData.totCnt = int.parse(element['totCnt'].toString());
          tempData.totAmt = int.parse(element['totAmt'].toString());
          tempData.okCnt = int.parse(element['okCnt'].toString());
          tempData.okAmt = int.parse(element['okAmt'].toString());
          tempData.cancelCnt = int.parse(element['cancelCnt'].toString());
          tempData.cancelAmt = int.parse(element['cancelAmt'].toString());
        } else {
          // 이전 데이터와 날짜가 같은경우 cnt, amt 합쳐서 다음에 적재
          _chkDt = element['orderDate'].toString();

          tempData.orderDate = element['orderDate'].toString();
          tempData.totCnt = (tempData.totCnt! + int.parse(element['totCnt']));
          tempData.totAmt = (tempData.totAmt! + int.parse(element['totAmt']));
          tempData.okCnt = (tempData.okCnt! + int.parse(element['okCnt']));
          tempData.okAmt = (tempData.okAmt! + int.parse(element['okAmt']));
          tempData.cancelCnt = (tempData.cancelCnt! + int.parse(element['cancelCnt']));
          tempData.cancelAmt = (tempData.cancelAmt! + int.parse(element['cancelAmt']));
        }
      });

      // _tempData 에 마지막 값이 들어있다면 데이터 적재
      if (tempData.orderDate != null) {
        dataWeekOrderList.value.add(tempData);
        tempData = DashboardWeekOrderModel();
      }
    }

    return '00';
  }

  Future<dynamic> getAccountInfo() async {
    dynamic qData;

    //String shopCd = GetStorage().read('shopCd');

    final response = await DioClient().get('${ServerInfo.RESTURL_SHOPACCOUNTINFO}?shopCd=${AuthService.SHOPCD}');

    //if (response.data['code'] == '00') {
      //qData = response.data['data'];
      shopRemainAmt.value = response.data['data']['realRemainAmt'].toString();
    // }
    // else {
    //    //msg = response.data['msg'];
    //   return '99';
    // }

    return '00';
  }

  Future<dynamic> getLiveEventInfo() async {
    dynamic qData;

    final response = await DioClient().get('${ServerInfo.RESTURL_LIVEEVENTINFO}?shopCd=${AuthService.SHOPCD}');

    if (response.data['code'] == '00') {
      mEventYn.value = response.data['eventYn'].toString();
      mFrTime.value = response.data['frTime'].toString();
      mToTime.value = response.data['toTime'].toString();

      return '00';
    }
    else {
      return '99';//response.data['code'];
    }

    return qData;
  }

  Future<List<dynamic>?> getNoticeList(String noticeGbn, String rows) async {
    List<dynamic> qData = [];
    List<String> imgBannerList = [];
    List<String> urlList = [];

    if (noticeGbn == '2'){
      dataNoticeList.value.clear();
    }
    else if (noticeGbn == '4'){
      //dataNoticeList.value.clear();
    }

    NoticeListRequestModel requestData = NoticeListRequestModel();
    requestData.jobGbn = '11';
    requestData.osGbn = '11';
    requestData.noticeGbn = noticeGbn;
    requestData.dispGbn = 'Y';
    requestData.frDate = '';
    requestData.toDate = '';
    requestData.rows = rows;
    requestData.page = '1';

    final response = await DioClient().post('${ServerInfo.RESTURL_NOTICELIST}', data: requestData.toJson());

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);

      int index = 1;
      qData.forEach((element) {
        NoticeListModel temp = NoticeListModel();
        temp.rnum = index.toString();
        temp.noticeSeq = element['noticeSeq'] as String;
        temp.noticeGbn = element['noticeGbn'] as String;
        temp.dispGbn = element['dispGbn'] as String;
        temp.dispFrDate = element['dispFrDate'] as String;
        temp.dispToDate = element['dispToDate'] as String;
        temp.noticeTitle = element['noticeTitle'] as String;
        temp.noticeContents = element['noticeContents'] as String;
        temp.noticeUrl1 = element['noticeUrl1'] as String;
        temp.noticeUrl2 = element['noticeUrl2'] as String;
        temp.noticeUrl3 = element['noticeUrl3'] as String;
        temp.orderDate = element['orderDate'] as String;
        temp.insDate = element['insDate'] as String;
        temp.sortSeq = element['sortSeq'] as String;
        temp.extUrlYn = element['extUrlYn'] as String;

        if (noticeGbn == '2'){
          dataNoticeList.value.add(temp);
        }
        else if (noticeGbn == '4'){
          if(ServerInfo.jobMode == 'real')
            temp.noticeUrl1 = temp.noticeUrl1.toString().replaceAll('https://image.daeguro.co.kr:40443/', '/');

          imgBannerList.add(temp.noticeUrl1!);
          urlList.add(temp.noticeUrl2!);
        }

        index++;
      });
    }
    else {
      return null;
    }

    if (noticeGbn == '4'){
      AuthService.bannerImageList = imgBannerList;
      AuthService.urlList = urlList;
    }

    return qData;
  }
}
