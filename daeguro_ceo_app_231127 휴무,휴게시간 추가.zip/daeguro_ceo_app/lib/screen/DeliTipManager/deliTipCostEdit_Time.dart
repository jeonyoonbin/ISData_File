import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/timepicker/is_selectTime.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipAmtEditModel.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/delitipController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class DeliTipCost_TimeEdit extends StatefulWidget {
  final String? jobGbn;
  final String? tipSeq;
  final String? tipDay;
  final String? tipFrStand;
  final String? tipToStand;
  final String? tipAmt;

  const DeliTipCost_TimeEdit({Key? key, this.jobGbn, this.tipSeq, this.tipDay, this.tipFrStand, this.tipToStand, this.tipAmt}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return DeliTipCost_TimeEditState();
  }
}

class DeliTipCost_TimeEditState extends State<DeliTipCost_TimeEdit> {

  List<bool> tipAmtTime_DayState = [false, false, false, false, false, false, false, false, false, false];

  String? tipAmtTime_startDate;
  String? tipAmtTime_endDate;
  String? tipAmtTime_tipNextDay = 'N';

  String? inputTipAmt = '0';

  String? sendValiText;

  List<String> msg = [];

  bool allCheck = false;

  requestAPI_SetData(DeliTipAmtEditModel sendData) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(DeliTipController.to.setShopTipAmt(sendData.toJson()))
    );

    if (value == null) {
      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
    }
    else {
      if (value != '00') {
        msg.add(value.toString().replaceAll('동일한 시간에 등록된 배달팁이 있습니다.(', '').replaceAll(')', ''));
      }
    }
  }

  @override
  void initState() {
    super.initState();

    Get.put(DeliTipController());

    if (widget.jobGbn == '1') {
      tipAmtTime_startDate = '1300';
      tipAmtTime_endDate = '1500';
    } else {
      int dayIndex = int.parse(widget.tipDay!);
      if (dayIndex == 1) {
        tipAmtTime_DayState[6] = true;
      } else {
        tipAmtTime_DayState[dayIndex - 2] = true;
      }
      tipAmtTime_startDate = widget.tipFrStand;
      tipAmtTime_endDate = widget.tipToStand;

      inputTipAmt = widget.tipAmt;
    }
  }

  @override
  void dispose() {
    super.dispose();
    Get.put(DeliTipController()).deliTipError?.value = '';
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: BoxConstraints(maxWidth: 460.0, maxHeight: Responsive.isMobile(context) ? 515 : 475),
        contentPadding: const EdgeInsets.all(0.0),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            Text(widget.jobGbn == '1' ? '주문 시간대별 배달팁 추가' : '주문 시간대별 배달팁 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY)),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Material(
            color: Colors.transparent,
            borderOnForeground: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ISLabelBarSub(
                    title: '요일',
                    bodyPadding: EdgeInsets.zero,
                    titlePadding: const EdgeInsets.fromLTRB(20, 0, 10, 3),
                    body: Wrap(
                      alignment: WrapAlignment.center,
                      spacing: 8.0,
                      children: [
                        ISCheckbox(label: '월', value: tipAmtTime_DayState[0], onChanged: (v) => setState(() => widget.jobGbn == '1' ? tipAmtTime_DayState[0] = v! : false)),
                        ISCheckbox(label: '화', value: tipAmtTime_DayState[1], onChanged: (v) => setState(() => widget.jobGbn == '1' ? tipAmtTime_DayState[1] = v! : false)),
                        ISCheckbox(label: '수', value: tipAmtTime_DayState[2], onChanged: (v) => setState(() => widget.jobGbn == '1' ? tipAmtTime_DayState[2] = v! : false)),
                        ISCheckbox(label: '목', value: tipAmtTime_DayState[3], onChanged: (v) => setState(() => widget.jobGbn == '1' ? tipAmtTime_DayState[3] = v! : false)),
                        ISCheckbox(label: '금', value: tipAmtTime_DayState[4], onChanged: (v) => setState(() => widget.jobGbn == '1' ? tipAmtTime_DayState[4] = v! : false)),
                        ISCheckbox(label: '토', value: tipAmtTime_DayState[5], onChanged: (v) => setState(() => widget.jobGbn == '1' ? tipAmtTime_DayState[5] = v! : false)),
                        ISCheckbox(label: '일', value: tipAmtTime_DayState[6], onChanged: (v) => setState(() => widget.jobGbn == '1' ? tipAmtTime_DayState[6] = v! : false)),
                      ],
                    ),
                    trailing: widget.jobGbn == '1'
                        ? ISButton(
                            child: const Text('전체 선택'),
                            onPressed: () {
                              for (int i = 0; i < 7; i++) {
                                if (allCheck == false) {
                                  tipAmtTime_DayState[i] = true;
                                } else {
                                  tipAmtTime_DayState[i] = false;
                                }
                              }
                              setState(() {
                                allCheck = !allCheck;
                              });
                            },
                          )
                        : null,
                  ),
                  const Divider(height: 1),

                  ISLabelBarSub(
                    title: '적용 시간',
                    body: SingleChildScrollView(
                      scrollDirection: Responsive.isMobile(context) ? Axis.horizontal : Axis.vertical,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          ISSelectTime(
                            title: '시작 시간',
                            hour: tipAmtTime_startDate!.substring(0, 2),
                            minute: tipAmtTime_startDate!.substring(2, 4),
                            onTimeSelected: (time) {
                              setState(() {
                                tipAmtTime_startDate = time;
                                tipAmtTime_tipNextDay = (int.parse(tipAmtTime_startDate!) > int.parse(tipAmtTime_endDate!)) ? 'Y' : 'N';
                              });
                            },
                          ),
                          const SizedBox(width: 5,),
                          ISSelectTime(
                            title: tipAmtTime_tipNextDay == 'Y' ? '종료 시간  [다음날]' : '종료 시간',
                            hour: tipAmtTime_endDate!.substring(0, 2),
                            minute: tipAmtTime_endDate!.substring(2, 4),
                            onTimeSelected: (time) {
                              setState(() {
                                tipAmtTime_endDate = time;
                                tipAmtTime_tipNextDay = (int.parse(tipAmtTime_startDate!) > int.parse(tipAmtTime_endDate!)) ? 'Y' : 'N';
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                    trailing: null,
                  ),
                  ISLabelBarSub(
                    title: '배달팁',
                    bodyPadding: const EdgeInsets.only(top: 15, left: 15, right: 15),
                    body: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Material(
                          color: Colors.transparent,
                          child: ISInput(
                            value: Utils.getCashComma(inputTipAmt!),
                            width: 120,
                            textAlign: TextAlign.end,
                            label: '금액',
                            keyboardType: TextInputType.number,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                                TextInputFormatter.withFunction(
                                      (oldValue, newValue) {
                                    if (newValue.text.isEmpty) {
                                      return newValue;
                                    }
                                    try {
                                      final parsedValue = int.parse(newValue.text);
                                      if (parsedValue <= 999990) {
                                        final formattedValue = Utils.getCashComma(parsedValue.toString());

                                        // 커서 위치 계산
                                        final cursorPosition = newValue.selection.baseOffset;
                                        final newCursorPosition = cursorPosition + (formattedValue.length - newValue.text.length);

                                        return TextEditingValue(
                                          text: formattedValue,
                                          selection: TextSelection.collapsed(offset: newCursorPosition),
                                        );
                                      }
                                    } catch (_) {}
                                    return oldValue;
                                  },
                                ),
                              ],
                            // keyboardType: TextInputType.number,
                            // inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                            onChange: (v) {
                                inputTipAmt = v.toString().replaceAll(',', '');

                                try{
                                  if(int.parse(v!.toString().replaceAll(',', '')) % 100 != 0){
                                    Get.put(DeliTipController()).deliTipError?.value = '100원 단위 이상의 금액만 입력 가능합니다.' ;
                                  }
                                  else{
                                    Get.put(DeliTipController()).deliTipError?.value = '';
                                  }
                                }
                                catch(_){
                                  Get.put(DeliTipController()).deliTipError?.value = '';
                                }
                            },
                          ),
                        ),
                        const SizedBox(width: 8,),
                        const Text('원', style: TextStyle(fontSize:16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                      ],
                    ),
                    trailing: null,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Obx(() {
                        if(Get.find<DeliTipController>().deliTipError!.value != ''){
                          sendValiText = Get.find<DeliTipController>().deliTipError!.value;
                          return Text(sendValiText!, style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: Colors.redAccent));
                        }
                        else {
                          sendValiText = null;
                          return Container();
                        }
                      }),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () async {
                if (tipAmtTime_tipNextDay == '' || tipAmtTime_tipNextDay == '0' || sendValiText != null){
                  ISAlert(context, content: '배달팁을 확인해 주세요.');
                  return;
                }

                int ret = tipAmtTime_DayState.indexWhere((element) => element == true);
                if (ret == -1){
                  ISAlert(context, content: '요일을 선택해 주세요.');
                  return;
                }

                DeliTipAmtEditModel sendData = DeliTipAmtEditModel();
                DeliTipAmtEditModel sendDataIndex = DeliTipAmtEditModel();

                List<String> sendjobGbn = [];
                List<String> sendtipSeq = [];
                List<String> sendtipGbn= [];
                List<String> sendtipDay = [];
                List<String> sendtipFrStand = [];
                List<String> sendtipToStand = [];
                List<String> sendtipAmt = [];
                List<String> sendtipNextDay = [];

                String tempStartDate = tipAmtTime_startDate!;
                String tempEndDate = tipAmtTime_endDate!;

                int index = 0;
                tipAmtTime_DayState.forEach((element) {
                  if (element == true){
                    sendjobGbn.add(widget.jobGbn == '1' ? 'I' : 'U');
                    sendtipSeq.add(widget.jobGbn == '1' ? '' : widget.tipSeq!);
                    sendtipGbn.add('7');

                    int tempTipDay = index+2;
                    if (index == 6) {
                      tempTipDay = 1;
                    }

                    sendtipDay.add(tempTipDay.toString());
                    sendtipFrStand.add(tempStartDate);
                    sendtipToStand.add(tempEndDate);
                    sendtipAmt.add(inputTipAmt!);
                    sendtipNextDay.add(tipAmtTime_tipNextDay!);
                  }

                  index++;
                });

                sendData.jobGbn = sendjobGbn;
                sendData.tipSeq = sendtipSeq;
                sendData.tipGbn = sendtipGbn;
                sendData.tipDay = sendtipDay;
                sendData.tipFrStand = sendtipFrStand;
                sendData.tipToStand = sendtipToStand;
                sendData.tipAmt = sendtipAmt;

                msg.clear();
                for(int i = 0; i < sendData.jobGbn!.length; i++){
                  sendDataIndex = DeliTipAmtEditModel();
                  sendDataIndex.shopCd = AuthService.SHOPCD;
                  sendDataIndex.uCode = AuthService.uCode;
                  sendDataIndex.uName = AuthService.uName;
                  sendDataIndex.jobGbn = sendData.jobGbn!.isNotEmpty ? [sendData.jobGbn![i]] : [];
                  sendDataIndex.tipSeq = sendData.tipSeq!.isNotEmpty ? [sendData.tipSeq![i]] : [];
                  sendDataIndex.tipGbn = sendData.tipGbn!.isNotEmpty ? [sendData.tipGbn![i]] : [];
                  sendDataIndex.tipDay = sendData.tipDay!.isNotEmpty ? [sendData.tipDay![i]] : [];
                  sendDataIndex.tipFrStand = sendData.tipFrStand!.isNotEmpty ? [sendData.tipFrStand![i]] : [];
                  sendDataIndex.tipToStand = sendData.tipToStand!.isNotEmpty ? [sendData.tipToStand![i]] : [];
                  sendDataIndex.tipAmt = sendData.tipAmt!.isNotEmpty ? [sendData.tipAmt![i]] : [];
                  sendDataIndex.tipAmtRate = sendData.tipAmtRate!.isNotEmpty ? [sendData.tipAmtRate![i]] : [];
                  sendDataIndex.tipNextDay = sendData.tipNextDay!.isNotEmpty ? [sendData.tipNextDay![i]] : [];

                  await requestAPI_SetData(sendDataIndex);
                }
                Navigator.of(context).pop(true);

                if(msg.isNotEmpty) {
                  ISAlert(context, content: '동일 시간대에 배달팁 설정이 되어있는\n(${msg.toString().replaceAll('[', '').replaceAll(']', '')})을 제외한 요일에 배달팁이 설정됩니다.');
                }
              },
              child: Text(widget.jobGbn == '1' ? '등록' : '적용', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }
}


