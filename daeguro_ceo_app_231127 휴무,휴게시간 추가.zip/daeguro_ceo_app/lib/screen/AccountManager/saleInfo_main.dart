import 'dart:convert';
import 'dart:html';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:http/http.dart' as http;

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_numberPagination.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_togglebuttons.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/AccountManager/accountSaleInfoModel.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:data_table_2/data_table_2.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;

class SaleInfoMain extends StatefulWidget {
  final double? tabviewHeight;

  const SaleInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<SaleInfoMain> createState() => _SaleInfoMainState();
}

class _SaleInfoMainState extends State<SaleInfoMain> {
  final ScrollController _scrollController = ScrollController();

  String? startdate = '';
  String? enddate = '';
  String? tempStr;
  String? selectedType = '1000';

  int totalSaleAmount = 0;
  int totalSettlementAmount = 0;

  String? selectedPayType = ' ';
  String? selectedOrderType = ' ';
  String? selectedStatus = ' ';
  String? selectedViewGbn = '%';

  int selectedPageNumber = 1;
  int totalPage = 0;
  bool pickDate = false;

  List<AccountSaleInfoModel> dataList = <AccountSaleInfoModel>[];

  late SaleInfoSource saleInfoDataSource;
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      saleInfoDataSource = SaleInfoSource(context, dataList, false, true, true, false);
      // Default sorting sample. Set __sortColumnIndex to 0 and uncoment the lines below
      // if (_sortColumnIndex == 0) {
      //   _sort<String>((d) => d.name, _sortColumnIndex!, _sortAscending);
      // }
      _initialized = true;
      saleInfoDataSource.addListener(() {
        setState(() {});
      });
    }
  }

  requestAPIData() async {

    String viewGbn = (selectedViewGbn == '%') ? '' : selectedViewGbn!;

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(AccountController.to.getShopAccountSaleList(viewGbn, startdate!.replaceAll('-', ''), enddate!.replaceAll('-', ''), selectedPageNumber.toString()))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        AccountSaleInfoModel temp = AccountSaleInfoModel();

        temp.orderDate = element['orderDate'] as String;
        temp.packOrderYnName = element['packOrderYnName'] as String;
        temp.totAmt = element['totAmt'] as String;
        temp.pgFeeAmt = element['pgFeeAmt'] as String;
        temp.appMenuAmt = element['appMenuAmt'] as String;
        temp.appTipAmt = element['appTipAmt'] as String;
        temp.meetMenuAmt = element['meetMenuAmt'] as String;
        temp.meetTipAmt = element['meetTipAmt'] as String;
        temp.packDiscAmt = element['packDiscAmt'] as String;
        temp.totalFeeAmt = element['totalFeeAmt'] as String;
        temp.appFeeAmt = element['appFeeAmt'] as String;
        temp.totalDiscAmt = element['totalDiscAmt'] as String;
        temp.totalAmt = element['totalAmt'] as String;
        temp.shopCouponAmt = element['shopCouponAmt'] as String;


        dataList.add(temp);
      });

      totalPage = AccountController.to.total_page;
      print(totalPage);

      totalSaleAmount = AccountController.to.salesAmt;
      totalSettlementAmount = AccountController.to.settlementAmt;

    }

    setState(() {});
  }

  @override
  void dispose() {

    dataList.clear();
    saleInfoDataSource.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // loadData() async {
  //   // 날짜필터
  //
  //
  //   // 테이블 데이터
  //   for (int i = 10; i < 20; i++) {
  //     SaleInfoModel temp = SaleInfoModel();
  //     temp.selected = false;
  //
  //     temp.saleDate = '2023-04-$i';
  //     temp.mallInfo = '대구로';
  //     temp.saleAmount = (i * 75100).toString();
  //     temp.a = (-i * 157).toString();
  //     temp.b = (i * 751 + -i * 157).toString();
  //     temp.c = (i * 751).toString();
  //     temp.d = (-i * 157).toString();
  //
  //     // totalDeposit += int.parse(temp.deposit!);
  //     // totalWithdraw += int.parse(temp.withdraw!);
  //     dataList.add(temp);
  //   }
  //
  //   totalSaleAmount = 20800;
  //   totalSettlementAmount = 20132;
  //
  //   totalPage = 100;
  //
  //   setState(() {});
  // }

  @override
  void initState() {
    super.initState();

    Get.put(AccountController());


    startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefreshChild == true ) {
        _appTheme.ShopRefreshChild = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          requestAPIData();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));
    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return SingleChildScrollView(
      controller: _scrollController,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ISLabelBarMain(
            trailing: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const SizedBox.shrink(),
                ISButton(
                  buttonColor: Colors.green.shade400,
                  child: const Text('엑셀 다운'),
                  onPressed: () async {
                    // String baseURL = ServerInfo.jobMode == 'dev' ?  ServerInfo.REST_BASEURL_DEV : ServerInfo.REST_BASEURL_REAL;
                    String viewGbn = (selectedViewGbn == '%') ? '' : selectedViewGbn!;

                    final accessToken = await AuthService.to.userStorage.read(key: '@user_token');
                    var headerData = {
                      "Authorization": 'Bearer $accessToken',
                    };

                    await http.post(Uri.parse('${ ServerInfo.RESTURL_EXCEL_SALES}?shopCd=${AuthService.SHOPCD}&viewGbn=${viewGbn}&frDate=${startdate!.replaceAll('-', '')}&toDate=${enddate!.replaceAll('-', '')}'), headers: headerData).then((http.Response response) {
                      var bytes = response.bodyBytes;

                      var dateName = DateFormat('yyyyMMddHHmmss').format(DateTime.now());

                      AnchorElement(href: 'data:application/octet-stream;charset=utf-16le;base64,${base64.encode(bytes)}')
                        ..setAttribute('download', '매출현황_${dateName}.xlsx')
                        ..click();
                    });
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Responsive.isMobile(context) == true ? Column(children: searchBarView(),) : Row(children: searchBarView(),),
          const SizedBox(height: 8),
          Container(
              alignment: Responsive.isMobile(context) == true ? Alignment.centerRight : Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              //height: 40,
              width: double.infinity,
              decoration: BoxDecoration(color: Colors.grey[200],),
              child: Text.rich(
                  style: const TextStyle(fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                  textAlign: Responsive.isMobile(context) == true ? TextAlign.end : TextAlign.start,
                  TextSpan(children: [
                    const TextSpan(text: '조회된 기간의 총매출 금액은 '),
                    TextSpan(text: Utils.getCashComma(totalSaleAmount.toString()), style: const TextStyle(color: Colors.lightBlue)),
                    const TextSpan(text: '원, '),
                    TextSpan(text: Responsive.isMobile(context) == true ? '\n' : ''),
                    const TextSpan(text: '총 정산 금액은 '),
                    TextSpan(text: Utils.getCashComma(totalSettlementAmount.toString()), style: const TextStyle(color: Colors.lightBlue)),
                    const TextSpan(text: '원입니다.'),
                  ]))),
          const SizedBox(height: 10,),
          Responsive.isMobile(context) == true ? MobileSaleInfoData() : SaleInfoData(),
          if (dataList != null && dataList.isNotEmpty)...[
            ISNumberPagination(
              threshold: 5,
              controlButton: const SizedBox(width: 10, height: 10,),
              onPageChanged: (int pageNumber) {
                setState(() {
                  selectedPageNumber = pageNumber;
                });

                requestAPIData();
              },
              fontSize: 12,
              pageTotal: totalPage,
              pageInit: selectedPageNumber,
              // picked number when init page
              colorPrimary: Colors.black,
              colorSub: Colors.white,
            ),
          ]
        ],
      ),
    );
  }

  Widget SaleInfoData() {
    return SizedBox(
      height: 400,
      child: DataTable2(
        headingRowHeight: 40,
        // dataRowHeight: 30,
        columnSpacing: 0,
        horizontalMargin: 0,
        headingRowColor: MaterialStateProperty.all(Colors.grey[100],),
        headingTextStyle: const TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54),
        // MaterialStateProperty.resolveWith((states) =>
        //     _fixedRows > 0 ? Colors.grey[200] : Colors.transparent),
        border: TableBorder(
          borderRadius: BorderRadius.circular(10),
          top: BorderSide(color: Colors.grey[300]!),
          right: BorderSide(color: Colors.grey[300]!),
          bottom: BorderSide(color: Colors.grey[300]!),
          left: BorderSide(color: Colors.grey[300]!),
          horizontalInside: BorderSide.none,
        ),

        dividerThickness: 0,        // this one will be ignored if [border] is set above
        bottomMargin: 10,
        minWidth: 800,
        // sortColumnIndex: _sortColus
        // sortArrowIcon: Icons.keyboard_arrow_up, // custom arrow
        // sortArrowAnimationDuration:
        //     const Duration(milliseconds: 500), // custom animation duration
        // onSelectAll: (val) =>
        //     setState(() => _dessertsDataSource.selectAll(val)),
        columns: const [
          DataColumn2(label: Center(child: Text('매출일')), size: ColumnSize.S, fixedWidth: 120),
          DataColumn2(label: Center(child: Text(' ')), size: ColumnSize.S, numeric: true),
          DataColumn2(label: Center(child: Text(' ')), size: ColumnSize.S, numeric: true, fixedWidth: 200),
          DataColumn2(label: Align(alignment: Alignment.centerRight, child: Text('매출 금액')), size: ColumnSize.S, numeric: true, fixedWidth: 160),
          DataColumn2(label: Center(child: Text('상세 보기')), size: ColumnSize.S, numeric: true, fixedWidth: 200),
        ],
        empty: Center(child: Container(
            padding: const EdgeInsets.all(20),
            child: const Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)))),
        rows:
        // getCurrentRouteOption(context) == noData
        //     ? []
        //     :
        List<DataRow>.generate(saleInfoDataSource.rowCount, (index) => saleInfoDataSource.getRow(index)),
      ),
    );
  }

  Widget MobileSaleInfoData() {
    return (dataList.length! == 0)
        ? SizedBox(
          height: (widget.tabviewHeight! - 220),
          child: const Align(
            alignment: Alignment.center,
            child: Text('조회 기간 내 결과가 없습니다.', style: TextStyle(fontSize: 17, color: Colors.black54, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY))),
        )
        : ListView(
        controller: _scrollController,
        shrinkWrap: true,
        children: List.generate(
          dataList.length,
              (index) {
            return fluentUI.Expander(
                headerHeight: 60,
                shapeRadius: 0.0,
                contentPadding: const EdgeInsets.only(left: 16, right: 56),
                header: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('매출일', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                        Text('매출 금액', style: TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                      ],
                    ),
                    const SizedBox(height: 4,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('${Utils.getYearMonthDayFormat(dataList[index].orderDate.toString())}  ${dataList[index].packOrderYnName}', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                        Text('${Utils.getCashComma(dataList[index].totalAmt.toString())} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                  ],
                ),
                content: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 12,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('A) 매출 금액', style: TextStyle(color: Colors.black, fontSize: 14)),
                        Text('${Utils.getCashComma(dataList[index].totAmt.toString())} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('   - 주문 금액', style: TextStyle(color: Colors.black38, fontSize: 14)),
                        Text('${Utils.getCashComma(dataList[index].appMenuAmt.toString())} 원', style: const TextStyle(color: Colors.black38, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('   - 배달팁', style: TextStyle(color: Colors.black38, fontSize: 14)),
                        Text('${Utils.getCashComma(dataList[index].appTipAmt.toString())} 원', style: const TextStyle(color: Colors.black38, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    const SizedBox(height: 4,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text('B) 고객 할인 비용', style: TextStyle(color: Colors.black, fontSize: 14)),
                            Tooltip(
                              message: '사장님이 고객에게 제공한 할인쿠폰 금액과 포장 할인금액입니다.',
                              child: Icon(
                                Icons.help_outline,
                                color: Colors.lightBlue,
                              ),
                            )
                          ],
                        ),
                        Text('${Utils.getCashComma((int.parse(dataList[index].packDiscAmt!) + int.parse(dataList[index].shopCouponAmt!)).toString())} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('   - 가맹점 쿠폰', style: TextStyle(color: Colors.black38, fontSize: 14)),
                        Text('${Utils.getCashComma(dataList[index].shopCouponAmt.toString())} 원', style: const TextStyle(color: Colors.black38, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    if(dataList[index].packOrderYnName != '대구로')
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('   - 포장 할인', style: TextStyle(color: Colors.black38, fontSize: 14)),
                        Text('${Utils.getCashComma(dataList[index].packDiscAmt.toString())} 원', style: const TextStyle(color: Colors.black38, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    const SizedBox(height: 4,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text('C) 차감 금액', style: TextStyle(color: Colors.black, fontSize: 14)),
                            Tooltip(
                              message: '중개 수수료 또는 카드 결제 시 발생하는 수수료입니다.\n1.중개 수수료:주문 금액의 2%(부가세별도)\n2.PG 수수료:결제 금액의 2.2%(부가세별도)',
                              child: Icon(
                                Icons.help_outline,
                                color: Colors.lightBlue,
                              ),
                            )
                          ],
                        ),
                        Text('${Utils.getCashComma(dataList[index].totalFeeAmt.toString())} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('   - 중계 이용료', style: TextStyle(color: Colors.black38, fontSize: 14)),
                        Text('${Utils.getCashComma(dataList[index].appFeeAmt.toString())} 원', style: const TextStyle(color: Colors.black38, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('   - PG 수수료', style: TextStyle(color: Colors.black38, fontSize: 14)),
                        Text('${Utils.getCashComma(dataList[index].pgFeeAmt.toString())} 원', style: const TextStyle(color: Colors.black38, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    const SizedBox(height: 4,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('D) 만나서 결제 금액', style: TextStyle(color: Colors.black, fontSize: 14)),
                        Text('${Utils.getCashComma(dataList[index].meetMenuAmt.toString())} 원', style: const TextStyle(color: Colors.black, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    const SizedBox(height: 12,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('정산 금액(A+B+C+D)', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FONT_BOLD)),
                        Text('${Utils.getCashComma(dataList[index].totalAmt.toString())} 원', style: const TextStyle(color: Colors.lightBlue, fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      ],
                    ),
                    const SizedBox(height: 12,),
                  ],
                ));
          },
        ));
  }

  List<Widget> searchBarView() {
    return [
      if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET)...[
        ISSearchDropdown(
          width: Responsive.isMobile(context) == true ? double.infinity : 120,
          label: '주문 정보 구분',
          value: selectedViewGbn,
          onChange: (value) {
            selectedViewGbn = value;

            selectedPageNumber = 1;
            requestAPIData();
          },
          item: [
            ISOptionModel(value: '%', label: '전체'),
            ISOptionModel(value: 'DELIVERY', label: '일반 메뉴'),
            ISOptionModel(value: 'BUNDLE', label: '장보기 상품'),
          ].cast<ISOptionModel>(),
        ),
        Responsive.isMobile(context) == true ? const SizedBox(height: 8,) : const SizedBox(width: 8,),
      ],
      ISSearchSelectDate(
        label: '기간 선택',
        width: Responsive.isMobile(context) == true ? double.infinity : 230,
        value: '${startdate.toString()} ~ ${enddate.toString()}',
        onTap: () async {
          showGeneralDialog(
              context: context,
              barrierDismissible: true,
              barrierLabel: '',
              barrierColor: Colors.black54,
              pageBuilder: (context, animation, secondaryAnimation) {
                return Dialog(
                  insetPadding: EdgeInsets.zero,
                    elevation: 0,
                    backgroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                    child: MultipleViewDateRangePicker(
                      startDate: DateTime.parse(startdate!),
                      endDate: DateTime.parse(enddate!),
                      setDateActionCallback: ({startDate, endDate}) {
                        Navigator.of(context).pop();

                        startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                        enddate = DateFormat('yyyy-MM-dd').format(endDate!);

                        selectedPageNumber = 1;
                        pickDate = true;

                        requestAPIData();
                      },
                    ));
              });
        },
      ),
      Responsive.isMobile(context) == true ? const SizedBox(height: 8,) : const SizedBox(width: 8,),
      ISToggleButtons(
        [
          ISOptionModel(value: '1000', label: '오늘'),
          ISOptionModel(value: '1001', label: '5일'),
          ISOptionModel(value: '1002', label: '7일'),
          ISOptionModel(value: '1003', label: '1개월'),
          ISOptionModel(value: '1004', label: '3개월'),
        ],
        buttonWidth: Responsive.isMobile(context) == true ? ((Responsive.getResponsiveWidth(context) / 5) - 6) : 60,
        defaultValue: selectedType,
        pickDate: pickDate,
        afterOnPress: (v) {
          if (v == '1000'){
            startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1001'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 5)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1002'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 7)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1003'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 30)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }
          else if (v == '1004'){
            startdate = formatDate(DateTime.now().subtract(const Duration(days: 90)), [yyyy, '-', mm, '-', dd]);
            enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
          }

          setState(() {
            selectedType = v.toString();
            pickDate = false;
          });

          selectedPageNumber = 1;

          requestAPIData();
        },
      ),
    ];
  }
}

class SaleInfoSource extends DataTableSource {
  final BuildContext context;
  late List<AccountSaleInfoModel> dataSource = [];

  // Add row tap handlers and show snackbar
  bool hasRowTaps = false;

  // Override height values for certain rows
  bool hasRowHeightOverrides = false;

  // Color each Row by index's parity
  bool hasZebraStripes = false;

  int _selectedCount = 0;

  SaleInfoSource.empty(this.context, this.dataSource) {
    dataSource = [];
  }

  SaleInfoSource(this.context, this.dataSource, [sortedByValue = false, this.hasRowTaps = false, this.hasRowHeightOverrides = false, this.hasZebraStripes = false]) {
    //dataSource = dataList;
    // if (sortedByValue) {
    //   sort((d) => d., true);
    // }
  }

  // sort
  // void sort<T>(
  //     Comparable<T> Function(SaleInfoModel d) getField, bool ascending) {
  //   dataSource.sort((a, b) {
  //     final aValue = getField(a);
  //     final bValue = getField(b);
  //     return ascending
  //         ? Comparable.compare(aValue, bValue)
  //         : Comparable.compare(bValue, aValue);
  //   });
  //   notifyListeners();
  // }

  // void updateSelectedValues(RestorableDessertSelections selectedRows) {
  //   _selectedCount = 0;
  //   for (var i = 0; i < dataSource.length; i += 1) {
  //     var data = dataSource[i];
  //     if (selectedRows.isSelected(i)) {
  //       data.selected = true;
  //       _selectedCount += 1;
  //     } else {
  //       data.selected = false;
  //     }
  //   }
  //   notifyListeners();
  // }

  @override
  DataRow getRow(int index, [Color? color, double fontSize = 14.0, FontWeight? fontWeight = FONT_NORMAL]) {
    // final format = NumberFormat.decimalPercentPattern(
    //   locale: 'en',
    //   decimalDigits: 0,
    // );
    assert(index >= 0);
    if (index >= dataSource.length) throw 'index > dataList.length';
    final data = dataSource[index];

    final cellDecoration = BoxDecoration(border: Border(bottom: BorderSide(color: !data.isChild && !data.isChild2 ? Colors.grey[200]! : Colors.transparent, width: 1)));

    return DataRow2.byIndex(
      index: index,
      // selected: data.selected,
      color: MaterialStateProperty.all(color)
      // (hasZebraStripes && index.isEven
      //     ? MaterialStateProperty.all(Theme.of(context).highlightColor)
      //     : null),
      ,
      // onSelectChanged: (value) {
      //   if (data.selected != value) {
      //     _selectedCount += value! ? 1 : -1;
      //     assert(_selectedCount >= 0);
      //     data.selected = value;
      //     notifyListeners();
      //   }
      // },

      onTap: hasRowTaps
          ? () => {
        // _showSnackbar(context, 'Tapped on row ${data.orderNumber}'),
        data.isChild || data.isChild2
            ? null
            : data.isOpened
            ? {dataSource.removeRange(index + 1, index + (data.packOrderYnName != '대구로' ? 12 : 11)), dataSource[index].isOpened = false}
            : {
          dataSource.insert(
            index + 1,
            AccountSaleInfoModel(
              body: 'A) 매출 금액',
              totAmt: data.totAmt,
              isChild: true,
            ),
          ),
          dataSource.insert(
            index + 2,
            AccountSaleInfoModel(
              body: '     - 주문 금액',
              totAmt: data.appMenuAmt,
              isChild: true,
            ),
          ),
          dataSource.insert(
            index + 3,
            AccountSaleInfoModel(
              body: '     - 배달팁',
              totAmt: data.appTipAmt,
              isChild: true,
            ),
          ),
          dataSource.insert(
            index + 4,
            AccountSaleInfoModel(
              body: 'B) 고객 할인 비용',
              tooltip: 'totalDiscAmt',
              totAmt: (int.parse(data.shopCouponAmt!) + int.parse(data.packDiscAmt!)).toString(),
              isChild: true,
            ),
          ),
          dataSource.insert(
            index + 5,
            AccountSaleInfoModel(
              body: '     - 가맹점 쿠폰',
              totAmt: data.shopCouponAmt,
              isChild: true,
            ),
          ),
          if(data.packOrderYnName != '대구로')
          dataSource.insert(
            index + 6,
            AccountSaleInfoModel(
              body: '     - 포장 할인',
              totAmt: data.packDiscAmt,
              isChild: true,
            ),
          ), //if (item.pack_order_yn == "Y")
          dataSource.insert(
            data.packOrderYnName != '대구로' ? index + 7 : index + 6,
            AccountSaleInfoModel(
              body: 'C) 차감 금액',
              tooltip: 'totalFeeAmt',
              totAmt: data.totalFeeAmt,
              isChild: true,
            ),
          ),
          dataSource.insert(
            data.packOrderYnName != '대구로' ? index + 8 : index + 7,
            AccountSaleInfoModel(
              body: '     - 중계 이용료',
              totAmt: data.appFeeAmt,
              isChild: true,
            ),
          ),
          dataSource.insert(
            data.packOrderYnName != '대구로' ? index + 9 : index + 8,
            AccountSaleInfoModel(
              body: '     - PG 수수료',
              totAmt: data.pgFeeAmt,
              isChild: true,
            ),
          ),
          dataSource.insert(
            data.packOrderYnName != '대구로' ? index + 10 :  index + 9,
            AccountSaleInfoModel(
              body: 'D) 만나서 결제 금액',
              totAmt: data.meetMenuAmt,
              isChild: true,
            ),
          ),
          dataSource.insert(
            data.packOrderYnName != '대구로' ? index + 11 :  index + 10,
            AccountSaleInfoModel(
              body: '정산 금액 (A+B+C+D)',
              totAmt: data.totalAmt,
              isChild: true,
            ),
          ), //if (!string.IsNullOrEmpty(item.delivery_total_amount))
          dataSource[index].isOpened = true
        },
        notifyListeners()
      }
          : null,
      // onDoubleTap: hasRowTaps
      //     ? () => _showSnackbar(context, 'Double Tapped on row ${data.name}')
      //     : null,
      // onLongPress: hasRowTaps
      //     ? () => _showSnackbar(context, 'Long pressed on row ${data.name}')
      //     : null,
      // onSecondaryTap: hasRowTaps
      //     ? () => _showSnackbar(context, 'Right clicked on row ${data.name}')
      //     : null,
      // onSecondaryTapDown: hasRowTaps
      //     ? (d) =>
      //         _showSnackbar(context, 'Right button down on row ${data.name}')
      //     : null,
      specificRowHeight: hasRowHeightOverrides && (data.isChild || data.isChild2) ? 28 : null,
      cells: [
        DataCell(Container(
            padding: EdgeInsets.zero,
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text(
              data.orderDate == null ? '' : Utils.getYearMonthDayFormat(data.orderDate.toString()),
              style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: Text(
              data.packOrderYnName ?? '',
              style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: Responsive.isMobile(context) == true ? 16.0 : 40.0),
              child: Row(
                children: [
                  Text(
                data.body ?? '',
                style: TextStyle(
                    color: ((data.isChild == true) && (data.body!.contains('- ') == true)) ? Colors.black45 : Colors.black87,
                    fontWeight: ((data.isChild == true) && (data.body!.contains('정산 금액') == true)) ? FONT_BOLD : fontWeight,
                    fontSize: ((data.isChild == true) && (data.body!.contains('정산 금액') == true)) ? 15 : fontSize,
                    fontFamily: FONT_FAMILY),
              ),
                  const SizedBox(width: 4,),
                  data.tooltip == 'totalFeeAmt' ? const Padding(
                    padding: EdgeInsets.only(bottom: 2),
                    child: Tooltip(
                      richMessage: TextSpan(
                        children: [
                          TextSpan(
                            text: '중개 수수료',
                            style: TextStyle(fontWeight: FontWeight.bold,color: Colors.lightBlueAccent),
                          ),
                          TextSpan(
                            text: " 또는 ",
                          ),
                          TextSpan(
                            text: '카드 결제 ',
                            style: TextStyle(fontWeight: FontWeight.bold,color: Colors.lightBlueAccent),
                          ),
                          TextSpan(
                            text: "시 발생하는 수수료입니다.\n1. 중개 수수료 : 주문 금액의 2%(부가세 별도)\n2. PG 수수료 : 결제 금액의 2.2%(부가세 별도)",
                          ),
                        ],
                      ),
                      child: Icon(Icons.help_outline, color: Colors.blue,),
                    ),
                  ) : Container(),
                  data.tooltip == 'totalDiscAmt' ? const Padding(
                    padding: EdgeInsets.only(bottom: 2),
                    child: Tooltip(
                      richMessage: TextSpan(
                        text: '사장님이 고객에게 제공한',
                        children: [
                          TextSpan(
                            text: '할인쿠폰 금액',
                            style: TextStyle(fontWeight: FontWeight.bold,color: Colors.lightBlueAccent),
                          ),
                          TextSpan(
                            text: "과",
                          ),
                          TextSpan(
                            text: '포장 할인금액입니다.',
                            style: TextStyle(fontWeight: FontWeight.bold,color: Colors.lightBlueAccent),
                          ),
                        ],
                      ),
                      child: Icon(Icons.help_outline, color: Colors.blue,),
                    ),
                  ) : Container()
                ],
              ),
            ))),
        DataCell(Container(
            decoration: cellDecoration,
            alignment: Alignment.centerRight,
            child: Text(
              '${(data.isChild == true) ? Utils.getCashComma(data.totAmt ?? '') : Utils.getCashComma(data.totalAmt ?? '')} 원',
              style: TextStyle(color: Colors.black, fontWeight: fontWeight, fontSize: fontSize, fontFamily: FONT_FAMILY),
            ))),
        DataCell(
          Container(
            decoration: cellDecoration,
            alignment: Alignment.center,
            child: (data.isChild == true)
                ? const SizedBox.shrink()
                : Icon(
                data.isOpened == true
                    ? Icons.keyboard_arrow_up
                    : data.orderDate == null
                    ? null
                    : Icons.keyboard_arrow_down,
                color: Colors.black,
                size: 20),
          ),
          // onTap: () {
          //   if (data.isOpened == true) {
          //     data.isOpened = false;
          //   } else {
          //     data.isOpened = true;
          //   }
          // },
        ),
      ],
    );
  }

  @override
  int get rowCount => dataSource.length;

  @override
  bool get isRowCountApproximate => false;

  @override
  int get selectedRowCount => _selectedCount;

  void selectAll(bool? checked) {
    for (final data in dataSource) {
      data.selected = checked ?? false;
    }
    _selectedCount = (checked ?? false) ? dataSource.length : 0;
    notifyListeners();
  }
}