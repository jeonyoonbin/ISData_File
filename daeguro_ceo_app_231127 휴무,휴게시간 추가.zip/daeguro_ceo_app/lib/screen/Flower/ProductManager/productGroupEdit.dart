import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productGroupEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productGroupListModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../../common/constant.dart';


class ProductGroupEdit extends StatefulWidget {
  final ProductGroupListModel? sData;
  const ProductGroupEdit({Key? key, this.sData})
      : super(key: key);

  @override
  State<ProductGroupEdit> createState() => _ProductGroupEditState();
}

enum RadioUseGbn { useGbnY, useGbnN }

class _ProductGroupEditState extends State<ProductGroupEdit> {

  ProductGroupEditModel formData = ProductGroupEditModel();

  RadioUseGbn? _radioUseGbn;

  @override
  void initState() {
    super.initState();
    Get.put(ProductInfoController());

    formData.shopCd = AuthService.SHOPCD;
    formData.grpCode = (widget.sData == null) ? '' : widget.sData!.code;
    formData.grpName = (widget.sData == null) ? '' : widget.sData!.name;
    formData.grpMemo = (widget.sData == null) ? '' : widget.sData!.memo;
    formData.useYn = (widget.sData == null) ? 'Y' : widget.sData!.useGbn;
    formData.uCode = AuthService.uCode;
    formData.uName = AuthService.uName;

    _radioUseGbn = formData.useYn == 'Y' ? RadioUseGbn.useGbnY : RadioUseGbn.useGbnN;
  }

  @override
  void dispose() {
    super.dispose();
    formData = ProductGroupEditModel();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 465),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,

      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          Text(widget.sData == null ? '상품 그룹 신규 등록' : '상품 그룹 정보 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 12,),
            const Text('상품 그룹명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            const SizedBox(height: 8),
            ISInput(
              autofocus: true,
              value: formData.grpName ?? '',
              context: context,
              height: 64,
              //padding: 0,
              label: '상품 그룹명',
              onChange: (v) {
                formData.grpName = v;
              },
            ),
            const Text('상품 그룹 설명(선택)', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
            const SizedBox(height: 8),
            ISInput(
              value: formData.grpMemo ?? '',
              context: context,
              height: 120,
              //padding: 0,
              label: '메뉴 그룹 설명',
              keyboardType: TextInputType.multiline,
              maxLines: 8,
              maxLength: 250,
              onChange: (v) {
                formData.grpMemo = v;
              },
            ),
            const SizedBox(height: 8,),
            const Divider(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('사용 여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                      Row(
                        children: [
                          Radio(
                              value: RadioUseGbn.useGbnY,
                              groupValue: _radioUseGbn,
                              onChanged: (v) async {
                                _radioUseGbn = v as RadioUseGbn?;

                                setState(() {});
                              }),
                          const Text('사용', style: TextStyle(fontSize: 12)),
                          const SizedBox(width: 40,),
                          Radio(
                              value: RadioUseGbn.useGbnN,
                              groupValue: _radioUseGbn,
                              onChanged: (v) async {
                                _radioUseGbn = v as RadioUseGbn?;

                                setState(() {});
                              }),
                          const Text('미사용', style: TextStyle(fontSize: 12)),
                        ],
                      )

                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () {
              if (formData.grpName == '' || formData.grpName == null) {
                ISAlert(context, content: '상품 그룹명을 확인해 주세요.');
                return;
              }else if(formData.grpName == '대표상품' || formData.grpName == '대표 상품'){
                ISAlert(context, content: '생성 불가능한 상품 그룹명 입니다.');
                return;
              }

              formData.useYn = _radioUseGbn == RadioUseGbn.useGbnY ? 'Y': 'N';

              BuildContext oldContext = context;

              ISConfirm(context, widget.sData == null ? '상품 그룹 등록' : '상품 그룹 수정', widget.sData == null ? '신규 상품 그룹을 등록하시겠습니까?' : '상품 그룹 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  var value = null;

                  if (widget.sData == null){
                    value = await showDialog(
                        context: context,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(ProductInfoController.to.addProductGroup(formData.toJson()))
                    );
                  }
                  else{
                    value = await showDialog(
                        context: context,
                        barrierColor: Colors.transparent,
                        builder: (context) => FutureProgressDialog(ProductInfoController.to.updateProductGroup(formData.toJson()))
                    );
                  }

                  if (value == null) {
                    ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                  }
                  else {
                    if (value == '00') {
                      Navigator.of(oldContext).pop(true);
                    }else{
                      ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                    }
                  }
                }
              });
            },
            child: Text(widget.sData == null ? '등록' : '수정', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }
}
