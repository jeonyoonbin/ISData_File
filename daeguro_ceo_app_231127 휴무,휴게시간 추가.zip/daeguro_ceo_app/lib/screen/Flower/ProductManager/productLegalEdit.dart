import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productLegalInfoModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductLegalEdit extends StatefulWidget {
  final String? productCode;
  const ProductLegalEdit({Key? key, this.productCode})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ProductLegalEditState();
  }
}

class ProductLegalEditState extends State<ProductLegalEdit> {
  ProductLegalInfoModel formData = ProductLegalInfoModel();

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getProductLegal(widget.productCode!))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      formData = ProductLegalInfoModel.fromJson(value);

      formData.jobGbn = 'I';
      formData.shopCd = AuthService.SHOPCD;
      formData.prodCd = widget.productCode;
      //formData.lAuth = value['lAuth'] as String;
      //formData.lTel = value['lTel'] as String;
      formData.lName = value['lName'] as String;
      formData.lModel = value['lModel'] as String;
      formData.lMarker = value['lMarker'] as String;
      //formData.lSeller = value['lSeller'] as String;
      formData.uCode = AuthService.uCode;
      formData.uName = AuthService.uName;
    }

    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    formData = ProductLegalInfoModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 640),
        contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            const Text('상품 상세 정보', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12,),
                  // const Text('1. 법에 의한 인증 허가등을 받았음을 확인할 수 있는 경우 그에 대한 사항', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  // const SizedBox(height: 8),
                  // ISInput(
                  //   autofocus: true,
                  //   height: 120,
                  //   keyboardType: TextInputType.multiline,
                  //   maxLines: 8,
                  //   value: formData.lAuth,
                  //   context: context,
                  //   label: '기본출력) "상품 상세 참조"',
                  //   maxLength: 4000,
                  //   onChange: (v) {
                  //     setState(() {
                  //       formData.lAuth = v;
                  //     });
                  //   },
                  // ),
                  // const SizedBox(height: 8),
                  // const Text('2. A/S책임자와 전화번호 또는 소비자상담 관련 전화번호', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  // const SizedBox(height: 8),
                  // ISInput(
                  //   autofocus: true,
                  //   height: 120,
                  //   keyboardType: TextInputType.multiline,
                  //   maxLines: 8,
                  //   value: formData.lTel,
                  //   context: context,
                  //   label: '기본출력) "상품 상세 참조"',
                  //   maxLength: 4000,
                  //   onChange: (v) {
                  //     setState(() {
                  //       formData.lTel = v;
                  //     });
                  //   },
                  // ),
                  // const SizedBox(height: 8),
                  const Text('1. 품명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  const SizedBox(height: 8),
                  ISInput(
                    autofocus: true,
                    height: 120,
                    keyboardType: TextInputType.multiline,
                    maxLines: 8,
                    value: formData.lName,
                    context: context,
                    label: '기본출력) "상품 상세 참조"',
                    maxLength: 4000,
                    onChange: (v) {
                      setState(() {
                        formData.lName = v;
                      });
                    },
                  ),
                  const SizedBox(height: 8),
                  const Text('2. 모델명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  const SizedBox(height: 8),
                  ISInput(
                    autofocus: true,
                    height: 120,
                    keyboardType: TextInputType.multiline,
                    maxLines: 8,
                    value: formData.lModel,
                    context: context,
                    label: '기본출력) "상품 상세 참조"',
                    maxLength: 4000,
                    onChange: (v) {
                      setState(() {
                        formData.lModel = v;
                      });
                    },
                  ),
                  const SizedBox(height: 8),
                  const Text('3. 제조자(사)', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  const SizedBox(height: 8),
                  ISInput(
                    autofocus: true,
                    height: 120,
                    keyboardType: TextInputType.multiline,
                    maxLines: 8,
                    value: formData.lMarker,
                    context: context,
                    label: '기본출력) "상품 상세 참조"',
                    maxLength: 4000,
                    onChange: (v) {
                      setState(() {
                        formData.lMarker = v;
                      });
                    },
                  ),
                  // const SizedBox(height: 8),
                  // const Text('6. 판매자', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  // const SizedBox(height: 8),
                  // ISInput(
                  //   autofocus: true,
                  //   height: 120,
                  //   keyboardType: TextInputType.multiline,
                  //   maxLines: 8,
                  //   value: formData.lSeller,
                  //   context: context,
                  //   label: '기본출력) "상품 상세 참조"',
                  //   maxLength: 4000,
                  //   onChange: (v) {
                  //     setState(() {
                  //       formData.lSeller = v;
                  //     });
                  //   },
                  // ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () async {
                var value = await showDialog(
                    context: context,
                    barrierColor: Colors.transparent,
                    builder: (context) => FutureProgressDialog(ProductInfoController.to.updateProductLegal(formData.toJson()))
                );

                if (value != '00') {
                  ISAlert(context, content: '정상 등록되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
                  //Navigator.of(context).pop;
                }
                else {
                  Navigator.of(context).pop(true);
                }
                // ISConfirm(context, '상품 상세 정보 변경', '상품 상세 정보를 변경합니다. \n\n계속 진행 하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                //   Navigator.of(context).pop();
                //
                //   if (isOK){
                //     // formData.jobGbn = 'I';
                //     // formData.shopCd = ShopUseState.SHOPCD;
                //     // formData.prodCd = widget.productCode;
                //     // formData.uCode = ShopUseState.uCode;
                //     // formData.uName = ShopUseState.uName;
                //
                //
                //   }
                // });
              },
              child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }
}


