import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/screen/AccountManager/accountManager_main.dart';
import 'package:daeguro_ceo_app/screen/Common/multiShopDashboardMain.dart';
import 'package:daeguro_ceo_app/screen/DashBoardManager/dashboardManager_main.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/deliTipManager_main.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManager_main.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveInfoDashboard_main.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveManager_main.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveNotifyImageInfo_main.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveNotifyInfo_main.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveReviewInfo_main.dart';
import 'package:daeguro_ceo_app/screen/ReserveManager/reserveTimeSchedule_main.dart';
import 'package:daeguro_ceo_app/screen/ReviewManager/reviewReserveManager_main.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/liveeventmanager_main.dart';
import 'package:daeguro_ceo_app/screen/LogInManager/UserNotifier.dart';
import 'package:daeguro_ceo_app/screen/LogInManager/loginLinkTo.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManager_main.dart';
import 'package:daeguro_ceo_app/screen/Common/soldOutManager_main.dart';
import 'package:daeguro_ceo_app/screen/OrderManager/orderInfo_main.dart';
import 'package:daeguro_ceo_app/screen/RequestManager/requestmanager_main.dart';
import 'package:daeguro_ceo_app/screen/ReviewManager/reviewManager_main.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/couponManager_main.dart';
import 'package:daeguro_ceo_app/screen/SaleManager/packingDiscount_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopKindManager_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopNotifyManager_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManager_main.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/FAQManager_main.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/noticeManager_main.dart';
import 'package:daeguro_ceo_app/screen/NoticeManager/userGuideInfo_main.dart';
import 'package:daeguro_ceo_app/screen/forbiddenPage.dart';
import 'package:daeguro_ceo_app/screen/privateInfoOption.dart';
import 'package:go_router/go_router.dart';

import 'package:daeguro_ceo_app/screen/LogInManager/login.dart';
import 'package:daeguro_ceo_app/layout/layout_main.dart';
import 'package:fluent_ui/fluent_ui.dart';

import '../screen/ShopManager/shopOperateInfo_main.dart';


final _rootNavigatorKey = GlobalKey<NavigatorState>();
final _shellNavigatorKey = GlobalKey<NavigatorState>();

final userNotifier = UserNotifier();

final router = GoRouter(
  navigatorKey: _rootNavigatorKey,
  initialLocation: AuthService.initLocation,//'/'
  // redirect: (context, state) {
  //   final loggedIn = userNotifier.userStatus;
  //   final loggingIn = state.location == '/forbidden';
  //
  //   if (!loggedIn){
  //     return loggingIn ? null : '/forbidden';
  //   }
  //
  //   if (loggingIn){
  //     return '/';
  //   }
  //
  //   return null;
  // },
  // refreshListenable: userNotifier,
  routes: [
    GoRoute(
      path: '/login',
      pageBuilder: (context, state) => const NoTransitionPage(child: LoginPage()),
    ),
    GoRoute(
      path: '/LinkTo',
      pageBuilder: (context, state) => const NoTransitionPage(child: LoginLinkToPage()),
    ),
    GoRoute(
      path: '/forbidden',
      pageBuilder: (context, state) => const NoTransitionPage(child: ForbiddenPage()),
    ),
    ShellRoute(
      navigatorKey: _shellNavigatorKey,
      builder: (context, state, child) {
        return LayoutMain(shellContext: _shellNavigatorKey.currentContext, state: state, child: child);
      },
      routes: [
        GoRoute(path: '/', name: 'home', builder: (context, state) => const DashBoardMain(),),/// Home
        //GoRoute(path: '/settings', name: 'settings', builder: (context, state) => Settings(),),/// Settings
        GoRoute(path: '/privateInfo', name: 'privateInfo', builder: (context, state) => const PrivateInfoOption(),),/// 개인정보변경

        /// 착한매장
        GoRoute(path: '/shop/kindInfo', name: '/shop/kindInfo', builder: (context, state) => const ShopKindManagerMain()),

        /// 전체 매장 현황
        GoRoute(path: '/multiShopDashboard/info', name: '/multiShopDashboard/info', builder: (context, state) => const MultiShopDashboardInfo()),

        /// 라이브이벤트
        GoRoute(path: '/liveEvent/info', name: '/liveEvent/info', builder: (context, state) => const LiveEventManagerMain()),

        /// 매장 정보
        GoRoute(path: '/shop/info', name: '/shop/info', builder: (context, state) => const ShopManagerMain()),
        GoRoute(path: '/shop/notifyInfo', name: '/shop/notifyInfo', builder: (context, state) => const ShopNotifyManagerMain()),

        /// 메뉴 관리
        GoRoute(path: '/menu/menuInfo', name: '/menu/menuInfo', builder: (context, state) => const MenuManagerMain()),
        GoRoute(path: '/menu/soldOutInfo', name: '/menu/soldOutInfo', builder: (context, state) => const SoldOutManagerMain()),

        /// 상품 관리(꽃배달용)
        GoRoute(path: '/menu/productInfo', name: '/menu/productInfo', builder: (context, state) => const ProductManagerMain()),
        //GoRoute(path: '/menu/productSoldOutInfo', name: '/menu/productSoldOutInfo', builder: (context, state) => const ProductSoldOutManagerMain()),

        /// 할인 관리
        GoRoute(path: '/sale/info', name: '/sale/info', builder: (context, state) => const CouponManagerMain()),
        GoRoute(path: '/sale/packDiscount', name: '/sale/packDiscount', builder: (context, state) => const PackDiscountMain()),

        /// 주문 관리
        GoRoute(path: '/order/orderInfo', name: '/order/orderInfo', builder: (context, state) => const OrderInfoMain()),
        GoRoute(path: '/order/deliTip', name: '/order/deliTip', builder: (context, state) => const DelipTipManagerMain()),

        /// 매출 관리
        GoRoute(path: '/account/info', name: '/account/info',
            //builder: (context, state) => AccountManagerMain(initTabIndex: state.extra,)
            builder: (context, state) {
              int tabIndex = 0;
              if (state.extra != null){
                tabIndex = state.extra as int;
              }

              return AccountManagerMain(initTabIndex: state.extra == null ? 0 : tabIndex);
            }
        ),

        /// 리뷰 관리
        GoRoute(path: '/review/info', name: '/review/info', builder: (context, state) => const ReviewManagerMain()),

        /// 이용 가이드
        GoRoute(path: '/guide/noticeInfo', name: '/guide/noticeInfo', builder: (context, state) => const NoticeManagerMain()),
        GoRoute(path: '/guide/faqInfo', name: '/guide/faqInfo', builder: (context, state) => const FAQManagerMain()),
        GoRoute(path: '/guide/userGuide', name: '/guide/userGuide', builder: (context, state) => const UserGuideInfoMain()),

        /// 변경 요청 이력
        GoRoute(path: '/request/info', name: '/request/info', builder: (context, state) => const RequestInfoMain()),

        /// 예약
        GoRoute(path: '/reserve/info', name: '/reserve/info', builder: (context, state) => const ReserveMain()),

        GoRoute(path: '/reserve/notifyInfo', name: '/reserve/notifyInfo', builder: (context, state) => const ReserveNotifyInfoMain()),
        GoRoute(path: '/reserve/notifyImageInfo', name: '/reserve/notifyImageInfo', builder: (context, state) => const ReserveNotifyImageInfoMain()),

        GoRoute(path: '/reserve/timeSchedule', name: '/reserve/timeSchedule', builder: (context, state) => const ReserveTimeScheduleMain()),
        GoRoute(path: '/reserve/infoDashboard', name: '/reserve/infoDashboard', builder: (context, state) => const ReserveInfoDashboardMain()),

        // 예약 리뷰 관리
        GoRoute(path: '/reserve/review', name: '/reserve/review', builder: (context, state) => const ReviewReserveManagerMain()),
      ],
    ),
  ],
);