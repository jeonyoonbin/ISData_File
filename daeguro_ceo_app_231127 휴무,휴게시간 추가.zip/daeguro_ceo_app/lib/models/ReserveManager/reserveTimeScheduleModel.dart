import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveTimeScheduleModel {
  ReserveTimeScheduleModel();

  String? orderDate;
  String? time;
  String? reserYN;
  int? cnt;
  int? personCnt;
  String? shopCode;
  String? dayTime;
  String? userId;

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}




Map<String, dynamic> _$ModelToJson(ReserveTimeScheduleModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCode': instance.shopCode,
      'orderDate': instance.orderDate,
      'dayTime': instance.dayTime,
      'reserYN': instance.reserYN,
      'userId': instance.userId,
    };

