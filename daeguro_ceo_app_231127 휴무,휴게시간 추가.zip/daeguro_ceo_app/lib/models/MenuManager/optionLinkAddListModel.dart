import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionLinkAddListModel {
  OptionLinkAddListModel();

  bool selected = false;
  String? selectYn;
  String? optGrpCd;
  String? optGrpName;
  String? minCount;
  String? multiCount;
  String? multiYn;
  String? optNames;

  factory OptionLinkAddListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

OptionLinkAddListModel _$ModelFromJson(Map<String, dynamic> json) {
  return OptionLinkAddListModel()
  // ..selected = json['selected'] as bool
    ..selectYn = json['selectYn'] as String
    ..optGrpCd = json['optGrpCd'] as String
    ..optGrpName = json['optGrpName'] as String
    ..minCount = json['minCount'] as String
    ..multiCount = json['multiCount'] as String
    ..multiYn = json['multiYn'] as String
    ..optNames = json['optNames'] as String;
}

Map<String, dynamic> _$ModelToJson(OptionLinkAddListModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'selectYn': instance.selectYn,
      'optGrpCd': instance.optGrpCd,
      'optGrpName': instance.optGrpName,
      'minCount': instance.minCount,
      'multiCount': instance.multiCount,
      'multiYn': instance.multiYn,
      'optNames': instance.optNames
    };
