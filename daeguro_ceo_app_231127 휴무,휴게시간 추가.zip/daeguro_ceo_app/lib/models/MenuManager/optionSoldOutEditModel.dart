import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionSoldOutEditModel {
  OptionSoldOutEditModel();

  bool? selected = false;
  String? cost = '';
  String? deliTip = '';
}