import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CommonNoFlagModel {
  CommonNoFlagModel();

  bool selected = false;
  String? jobGbn;
  String? subGbn;
  String? shopCd;
  String? targetCd;
  String? noFlag;
  String? uCode;
  String? uName;

  factory CommonNoFlagModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

CommonNoFlagModel _$ModelFromJson(Map<String, dynamic> json) {
  return CommonNoFlagModel()
  // ..selected = json['selected'] as bool
    ..jobGbn = json['jobGbn']
    ..subGbn = json['subGbn']
    ..shopCd = json['shopCd']
    ..targetCd = json['targetCd']
    ..noFlag = json['noFlag']
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(CommonNoFlagModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'jobGbn': instance.jobGbn,
      'subGbn': instance.subGbn,
      'shopCd': instance.shopCd,
      'targetCd': instance.targetCd,
      'noFlag': instance.noFlag,
      'uCode': instance.uCode,
      'uName': instance.uName
    };
