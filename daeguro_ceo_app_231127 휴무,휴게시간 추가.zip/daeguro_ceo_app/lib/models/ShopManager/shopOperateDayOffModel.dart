class ShopOperateDayOffModel {
  ShopOperateDayOffModel();

  String? gbn;
  String? foDay;
  String? toDay;
}