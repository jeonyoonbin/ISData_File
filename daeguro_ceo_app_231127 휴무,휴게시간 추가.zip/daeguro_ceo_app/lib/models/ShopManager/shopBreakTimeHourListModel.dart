import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopBreakTimeHourListModel {
  ShopBreakTimeHourListModel();

  bool? selected = false;
  String? jobGbn = 'I'; //I: 추가, U: 수정

  String? shopCd = "";
  String? sbGbn = "";
  String? dayGbn = "";
  String? openTime = "";
  String? closeTime = "";
  String? useGbn = "";
  String? nextDayYn = "";
}