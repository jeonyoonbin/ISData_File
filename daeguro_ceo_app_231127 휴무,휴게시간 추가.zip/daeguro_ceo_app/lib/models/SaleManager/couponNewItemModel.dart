import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CouponItemModel {
  CouponItemModel(
      this.frCost,
      this.discCost,
      );

  String? frCost = '';
  String? discCost = '';
}