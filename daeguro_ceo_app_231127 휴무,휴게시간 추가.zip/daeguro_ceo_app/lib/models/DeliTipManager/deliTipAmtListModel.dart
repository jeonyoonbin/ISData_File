import 'package:daeguro_ceo_app/models/LiveEventManager/liveeventMenuListEditModel.dart';

class DeliTipAmtListModel {
  DeliTipAmtListModel();

  String? jobGbn = '';
  String? shopCd = '';
  String? shopName = '';
  String? tipSeq = '';
  String? tipGbn = '';
  String? tipDay = '';
  String? tipFrStand = '';
  String? tipToStand = '';
  String? tipAmt = '';
  String? tipAmtRate = '';
  String? tipNextDay = '';
  String? insUcode = '';
  String? insName = '';
  String? insDate = '';
  String? modUcode = '';
  String? modName = '';
  String? modDate = '';

  List<String?> mTipAmt_SectorNameList = [];
}
