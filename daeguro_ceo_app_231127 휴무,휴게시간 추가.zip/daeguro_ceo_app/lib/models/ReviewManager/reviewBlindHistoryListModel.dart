class ReviewBlindHistoryListModel {
  ReviewBlindHistoryListModel({
    this.isChild = false,
    this.answerContent,
    this.blindCode,
    this.blindName,
    this.blindReason,
    this.blindReqCancelYn,
    this.blindReqDt,
    this.blindType,
    this.content,
    this.custNickName,
    this.insertDate,
    this.orderNo,
    this.requestGbn,
    this.starScore,
    this.status,
  });
  bool selected = false;
  bool viewSelected = false;
  bool isChild = false;
  bool isOpened = false;

  String? answerContent;
  String? blindCode;
  String? blindName;
  String? blindReason;
  String? blindReqCancelYn;
  String? blindReqDt;
  String? blindType;
  String? content;
  String? custNickName;
  String? insertDate;
  String? orderNo;
  String? requestGbn;
  double? starScore;
  String? status;
}
