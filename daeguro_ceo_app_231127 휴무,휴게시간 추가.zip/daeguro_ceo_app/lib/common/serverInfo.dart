

class ServerInfo {

  static const String APP_VERSION = "v1.1.2"; //"[검수중]";//

  //API경로
  // static const String jobMode = 'real';// 운영 배포
  static const String jobMode = 'dev';

  // 운영 배포용
  // static const String REST_PATH = '/api'; //'https://owner.daeguro.co.kr/api';// 운영 배포 (owner)
  // static const String REST_IMG_BASEURL = "";  // 운영 배포

  // 개발 테스트용
  static const String REST_PATH = 'https://dgpub.282.co.kr:8501/api';// 개발API경로 //'https://ceoflower.daeguro.co.kr/api';// 운영API경로
  static const String REST_IMG_BASEURL = "https://image.daeguro.co.kr:40443";//"";  // 개발시 직접 경로

  static const String REST_BASEURL_REAL = 'https://ceoflower.daeguro.co.kr'; // ''; //
  static const String REST_BASEURL_DEV = 'https://dgpub.282.co.kr:8501';

  static const String REST_REVIEW_URL = "https://review.daeguro.co.kr:45008";
  static const String REST_RESERVE_REVIEW_URL = "https://reser.daeguro.co.kr:20001";

  static const String REST_RESERVE_URL = 'https://reser.daeguro.co.kr:10018';

  //static const String REST_URL_SIDO_CODE = REST_PATH + "/Address/sido";
  static const String REST_URL_GUNGU_CODE = REST_PATH + "/Address/gungu";
  static const String REST_URL_DONG_CODE = REST_PATH + "/Address/dong";
  static const String REST_URL_RI_CODE = REST_PATH + "/Address/ri";

  // 로그인
  static const String RESTURL_LOGIN = REST_PATH + "/Login";
  static const String RESTURL_LOGIN_LINKTO = REST_PATH + "/Login/posLink";

  // 비밀번호 변경
  static const String RESTURL_MYPASS_UPDATE = REST_PATH + "/MyPass/updateMyPass";

  // 이벤트/할인 관리(Event)
  static const String RESTURL_COUPONSETLIST = REST_PATH + "/Event/getShopCouponSetList";
  static const String RESTURL_COUPONSETDETAIL = REST_PATH + "/Event/getShopCouponSetDetail";

  static const String RESTURL_COUPONSETDETAIL_SET = REST_PATH + "/Event/setShopCouponSet";

  static const String RESTURL_COUPONUSELIST = REST_PATH + "/Event/getCustShopCoupon";
  static const String RESTURL_COUPONSTATUSLIST = REST_PATH + "/Event/getShopCouponStatus";

  static const String RESTURL_PACKDISCOUNTINFO = REST_PATH + "/Event/getShopTogoDisc";

  static const String RESTURL_LIVEEVENTINFO = REST_PATH + "/Event/getShopLiveEvent";

  static const String RESTURL_LIVEEVENTMENULIST = REST_PATH + "/Event/getShopMenuList";
  static const String RESTURL_SHOPLIVEEVENT_SET = REST_PATH + "/Event/setShopLiveEvent_V2";
  static const String RESTURL_SHOPLIVEMENU_DEL = REST_PATH + "/Event/setShopLiveMenuDel";
  static const String RESTURL_SHOPLIVEEVENTPUSHALARM = REST_PATH + "/Event/SendEventPush";


  // 메인화면 통계(dashboard)
  static const String RESTURL_SHOPWEEKLYSTAT = REST_PATH + "/Main/getShopWeeklyStat";


  // 매장 관리(ShopInfo)
  static const String RESTURL_SHOPINFO = REST_PATH + "/ShopInfo/getShopInfo";
  static const String RESTURL_SHOPOPERATEINFO = REST_PATH + "/ShopInfo/getOperateInfo";

  static const String RESTURL_SHOPOPENINGHOURSINFO = REST_PATH + "/ShopInfo/getOpeningHoursInfo";
  static const String RESTURL_GETSHOP_SBTIME = REST_PATH + "/ShopInfo/getShopSbTime";
  static const String RESTURL_SETSHOP_SBTIME = REST_PATH + "/ShopInfo/setShopSbTime";
  static const String RESTURL_GETSHOP_DAYOFFINFO = REST_PATH + "/ShopInfo/getShopDayOff";


  static const String RESTURL_SHOPDELIINFO = REST_PATH + "/ShopInfo/getDeliInfo";
  static const String RESTURL_SHOPDELIINFO_SET = REST_PATH + "/ShopInfo/setShopDeliInfo";

  static const String RESTURL_SHOPREGISTINFO = REST_PATH + "/ShopInfo/getBizInfo";
  static const String RESTURL_SHOPINTRO = REST_PATH + "/ShopInfo/getShopIntro";
  static const String RESTURL_SHOPINTRODETAIL = REST_PATH + "/ShopInfo/getShopIntroDetail";

  static const String RESTURL_SHOPINFO_SET = REST_PATH + "/ShopInfo/updateShopInfo";
  static const String RESTURL_SHOPOPERATEINFO_SET = REST_PATH + "/ShopInfo/updateOperateInfo";
  static const String RESTURL_SHOPREGISTINFO_SET = REST_PATH + "/ShopInfo/updateBizInfo";
  static const String RESTURL_SHOPINTRO_SET = REST_PATH + "/ShopInfo/setShopIntro";

  // static const String RESTURL_SHOPNOTIFYIMAGE_SET = '${ServerInfo.REST_BASEURL_REAL}'+ REST_PATH + "/ShopInfo/setShopInfoImage";
  static const String RESTURL_SHOPNOTIFYIMAGE_SET = REST_PATH + "/ShopInfo/setShopInfoImage";

  static const String RESTURL_SHOPINTROLIST = REST_PATH + "/ShopInfo/getShopIntro";
  static const String RESTURL_SHOPINTRODETAILINFO = REST_PATH + "/ShopInfo/getShopIntroDetail";

  static const String RESTURL_SHOPOPERATEHOURINFO_REMOVE = REST_PATH + "/ShopInfo/deleteOpeningHoursInfo";

  // 메뉴 관리(Menu)
  static const String RESTURL_MENUGROUPLIST = REST_PATH + "/Menu/getMenuGroupList";
  static const String RESTURL_MENULIST = REST_PATH + "/Menu/getMenuList";

  static const String RESTURL_MENUGROUP_ADD = REST_PATH + "/Menu/addMenuGroup";
  static const String RESTURL_MENUGROUP_SET = REST_PATH + "/Menu/updateMenuGroup";

  static const String RESTURL_MENU_ADD = REST_PATH + "/Menu/addMenu";
  static const String RESTURL_MENU_SET = REST_PATH + "/Menu/updateMenu";

  static const String RESTURL_OPTIONLINKLIST = REST_PATH + "/Menu/getOptionGroupList";
  static const String RESTURL_OPTIONLINK_SET = REST_PATH + "/Menu/setMenuOptionGroup";
  static const String RESTURL_OPTIONLINK_DEL = REST_PATH + "/Menu/deleteMenuOptionGroup";

  static const String RESTURL_OPTIONGROUPLIST = REST_PATH + "/Menu/getMenuOptionGroup";
  static const String RESTURL_OPTIONLIST = REST_PATH + "/Menu/getMenuOptionList";

  static const String RESTURL_OPTIONGROUP_ADD = REST_PATH + "/Menu/addOptionGroup";
  static const String RESTURL_OPTIONGROUP_SET = REST_PATH + "/Menu/updateOptionGroup";
  static const String RESTURL_OPTIONGROUP_DEL = REST_PATH + "/Menu/deleteOptionGroup";

  static const String RESTURL_OPTION_ADD = REST_PATH + "/Menu/addMenuOption";
  static const String RESTURL_OPTION_SET = REST_PATH + "/Menu/updateMenuOption";
  static const String RESTURL_OPTION_DEL = REST_PATH + "/Menu/deleteMenuOption";

  static const String RESTURL_MENUTOPMENULIST = REST_PATH + "/Menu/getMajorMenuList";
  static const String RESTURL_TOPMENU_ADD = REST_PATH + "/Menu/addMajorMenu";
  static const String RESTURL_TOPMENU_DEL = REST_PATH + "/Menu/setMajorMenu";

  static const String RESTURL_MENUSEARCHLIST = REST_PATH + "/Menu/getMajorSearchList";

  static const String RESTURL_OPTIONGROUPCOUNT_SET = REST_PATH + "/Menu/updateOptGroupCnt";

  static const String RESTURL_OPTIONGROUPMENULINKLIST = REST_PATH + "/Menu/getOptionToMenuList";
  static const String RESTURL_OPTIONGROUPMENULINK_SET = REST_PATH + "/Menu/setOptionToMenu";

  static const String RESTURL_MENUORIGIN = REST_PATH + "/Menu/getOriginMark";

  static const String RESTURL_MENUSORT_SET = REST_PATH + "/Menu/updateMenuSort";

  static const String RESTURL_MULTIIMAGELIST = REST_PATH + "/Menu/getMultiImageList";


  // 상품 관리(Product)
  static const String RESTURL_PRODUCTTYPELIST = REST_PATH + "/Product/getProdGroupNameList";
  static const String RESTURL_PRODUCTTYPELIST_V2 = REST_PATH + "/Product/getProdGroupNameList_V2";

  static const String RESTURL_PRODUCTGROUPLIST = REST_PATH + "/Product/getProdGroupList";//"/Product/getFlowerProdGroupList";
  static const String RESTURL_PRODUCTLIST = REST_PATH + "/Product/getFlowerProdList";

  static const String RESTURL_PRODUCT_ADD = REST_PATH + "/Product/addFlowerProd";
  static const String RESTURL_PRODUCT_SET = REST_PATH + "/Product/setFlowerProd";

  static const String RESTURL_PRODUCTGROUP_ADD = REST_PATH + "/Product/addProdGroup";
  static const String RESTURL_PRODUCTGROUP_SET = REST_PATH + "/Product/updateProdGroup";

  static const String RESTURL_PRODUCTOPTIONGROUPLIST = REST_PATH + "/Product/getFlowerProdOptGroup";
  static const String RESTURL_PRODUCTOPTIONLIST = REST_PATH + "/Product/getFlowerProdOptList";

  static const String RESTURL_PRODUCTOPTIONGROUPLINKLIST = REST_PATH + "/Product/getProdSelected";
  static const String RESTURL_PRODUCTOPTIONGROUPLINK_SET = REST_PATH + "/Product/setOptionConnect";

  static const String RESTURL_PRODUCTOPTIONGROUP_ADD = REST_PATH + "/Product/addFlowerOptionGroup";
  static const String RESTURL_PRODUCTOPTIONGROUP_SET = REST_PATH + "/Product/setFlowerOptionGroup";
  static const String RESTURL_PRODUCTOPTIONGROUP_DEL = REST_PATH + "/Product/deleteFlowerOptGrp";

  static const String RESTURL_PRODUCTOPTION_ADD = REST_PATH + "/Product/addFlowerOption";
  static const String RESTURL_PRODUCTOPTION_SET = REST_PATH + "/Product/setFlowerOption";
  static const String RESTURL_PRODUCTOPTION_DEL = REST_PATH + "/Product/deleteFlowerOpt";

  static const String RESTURL_PRODUCTOPTIONGROUPCOUNT_SET = REST_PATH + "/Product/setOptGrpCount";


  static const String RESTURL_PRODUCTOPTIONLINKLIST = REST_PATH + "/Product/getOptGrpSelected";
  static const String RESTURL_PRODUCTOPTIONLINK_SET = REST_PATH + "/Product/setFlowerProdOption";
  static const String RESTURL_PRODUCTOPTIONGROUPLINK_DELETE = REST_PATH + "/Product/disconnectFlowerOption";

  static const String RESTURL_PRODUCTLEGAL = REST_PATH + "/Product/getFlowerProdLegal";
  static const String RESTURL_PRODUCTLEGAL_SET = REST_PATH + "/Product/setFlowerProdLegal";

  static const String RESTURL_PRODUCTBUNDLELEGAL = REST_PATH + "/Product/getBundleProdLegal";
  static const String RESTURL_PRODUCTBUNDLELEGAL_SET = REST_PATH + "/Product/setBundleProdLegal";

  static const String RESTURL_PRODUCTTOPMENULIST = REST_PATH + "/Product/getFlowerMajorProdList";
  static const String RESTURL_PRODUCTTOPMENU_SET = REST_PATH + "/Product/addFlowerMajorProd";
  static const String RESTURL_PRODUCTTOPMENUREMOVE = REST_PATH + "/Product/setFlowerMajorProd";
  static const String RESTURL_PRODUCTSEARCHLIST = REST_PATH + "/Product/getFlowerProdSearch";

  static const String RESTURL_PRODUCTORIGINLIST = REST_PATH + "/Product/getFlowerOriginInfo";
  static const String RESTURL_PRODUCTORIGIN_SET = REST_PATH + "/Product/setFlowerOringinInfo";

  static const String RESTURL_PRODUCTNOFLAGLIST = REST_PATH + "/Product/getNoFlagList";

  static const String RESTURL_NOFLAG_SET = REST_PATH + "/Product/setNoFlag";

  static const String RESTURL_PRODUCTSORT_SET = REST_PATH + "/Product/updateSort";


  // 주문/매출 관리(Order)
  static const String RESTURL_SHOPACCOUNTINFO = REST_PATH + "/Order/getShopAccountInfo";
  static const String RESTURL_WITHDRAWINFO = REST_PATH + "/Order/getWithdrawInfo";
  static const String RESTURL_SHOPORDERLIST = REST_PATH + "/Order/getShopOrderList";
  static const String RESTURL_SHOPORDER_DETAIL = REST_PATH + "/Order/getShopOrderDetail";
  static const String RESTURL_SHOPACCOUNTHISTORYLIST = REST_PATH + "/Order/getShopAccumList";

  static const String RESTURL_SHOPACCOUNTHISTORYMALL_DETAIL = REST_PATH + "/Order/getShopAccumDetail";

  static const String RESTURL_SHOPACCOUNTSALELIST = REST_PATH + "/Order/getShopSalesManagement";

  static const String RESTURL_SHOPACCOUNTVATINFO = REST_PATH + "/Order/getShopVatReport";

  static const String RESTURL_SHOPTRANSSMSCHECK = REST_PATH + "/Order/shopTransSmsCheck";
  static const String RESTURL_SHOPAUTOWITHDRAWSET = REST_PATH + "/Order/getAutoWithdrawSet";
  static const String RESTURL_SHOPAUTOWITHDRAWSET_SET = REST_PATH + "/Order/setAutoWithdrawSet";
  static const String RESTURL_SHOPINFOTRAN_SET = REST_PATH + "/Order/setShopInfoTran";


  // 요청 관리(ServiceReq)
  static const String RESTURL_REQUIRELIST = REST_PATH + "/ServiceReq/getServiceReqList";
  static const String RESTURL_REQUIRETYPE = REST_PATH + "/ServiceReq/getServiceReqType";
  //static const String RESTURL_REQUIRESERVICE_SET = REST_PATH + "/ServiceReq/setServiceRequest";
  static const String RESTURL_REQUIRESERVICE_SETMULTI = REST_PATH + "/ServiceReq/setMultiImageServiceRequest";
  static const String RESTURL_REQUIRESERVICE_SETSINGLE = REST_PATH + "/ServiceReq/setSingleImageServiceRequest";
  static const String RESTURL_REQUIRESERVICE_GETGOODSHOP = REST_PATH + "/ServiceReq/getGoodShopReqDetail";


  // 이용 가이드(Notice)
  static const String RESTURL_NOTICELIST = REST_PATH + "/Notice/getNoticeList";
  static const String RESTURL_NOTICELISTDETAIL = REST_PATH + "/Notice/getNoticeDetail";


  // 리뷰 관리(Review)
  static const String RESTURL_REVIEWSTATISTICS = "/review/count";
  static const String RESTURL_REVIEWLIST = "/v2/review/ceo";
  static const String RESTURL_REVIEWBLINDLIST = "/review/blindRequest";

  static const String RESTURL_REVIEWBLINDREQUEST = "/v2/review/blind";

  static const String RESTURL_REVIEWBLINDTYPE = "/review/blindType";

  static const String RESTURL_REVIEWANSWER_SET = "/review/answer";

  // 이미지 관리(Image)
  static const String RESTURL_IMAGEMULTI_SET = '${ServerInfo.REST_BASEURL_REAL}'+ REST_PATH + "/Image/setImageList";
  static const String RESTURL_IMAGESINGLE_SET = '${ServerInfo.REST_BASEURL_REAL}'+ REST_PATH + "/Image/setSingleImage";

  // 예약 관리(Reservation)
  static const String RESTURL_RESERVESTATUS = "/apply/statusDate";
  static const String RESTURL_RESERVEDATESTATUS_TOTAL = "/reser";
  static const String RESTURL_RESERVEDATESTATUS = "/reser-date";
  static const String RESTURL_RESERVE_SHOPMAGAM = "/shopMagam";
  static const String RESTURL_RESERVATIONLIST =  "/reser-list";
  static const String RESTURL_RESERVETIMESCHEDULELIST =  "/daytimeOrderCeo";
  static const String RESTURL_RESERVETIMESCHEDULESET =  "/SetShopTimeOffCeo";
  static const String RESTURL_RESERVE_APPLY = "/apply";
  static const String RESTURL_RESERVE_TIME = "/reserTime";
  static const String RESTURL_RESERVE_TIME_CANCEL = "/reserTime/cancel";
  static const String RESTURL_RESERVE_CASEPEOPLE = "/casesPeople";
  static const String RESTURL_RESERVE_SHOPNEWS = "/shopNews";
  static const String RESTURL_RESERVE_SHOP_PICTURE = "/shopPicture";
  static const String RESTURL_SHOPPICTURE_SORT_SET = "/shopPicture-sort";
  static const String RESTURL_RESERVE_SHOPINFO = "/shopInfo-ss";
  static const String RESTURL_RESERVE_SHOPINFO_INTRODUCE = "/introduce";
  static const String RESTURL_RESERVE_SHOPINFO_NOTICE = "/updateNotice";
  static const String RESTURL_RESERVE_REVIEW_INTRO = "/reviewIntro";
  static const String RESTURL_RESERVE_DELETE_REVIEWIMAGE = "/reviewImage/delete";
  static const String RESTURL_RESERVE_INSERT_REVIEWIMAGE = "/reviewImage/insert";
  static const String RESTURL_RESERVE_SHOPINFO_MANAGE = "/manage";
  static const String RESTURL_RESERVE_REVIEW_USE = "/review-use";
  static const String RESTURL_RESERVE_FACILITIES = "/facilities";
  static const String RESTURL_RESERVE_SBTIME = "/sbTime";
  static const String RESTURL_RESERVE_DAYOFF = "/dayOff";

  // 배달지(Shop)
  static const String RESTURL_DELITIPSECTORLIST = REST_PATH + "/ShopInfo/getShopSector";
  static const String RESTURL_DELITIPSECTOR_SET = REST_PATH + "/ShopInfo/setShopSector_V2";

  static const String RESTURL_SHOPTIPAMT = REST_PATH + "/ShopInfo/getShopTipAmt";
  static const String RESTURL_SHOPTIPAMT_SET = REST_PATH + "/ShopInfo/setShopTipAmt";

  // 멀티샵
  static const String RESTURL_MULTISHOP_LIST = REST_PATH + "/MultiShop/getMultiShopList";
  static const String RESTURL_MULTISHOP_CHECK = REST_PATH + "/MultiShop/getMultiShopCheck";

  static const String RESTURL_MULTISHOP_STATUS = REST_PATH + "/MultiShop/getOverallShopStatus";
  static const String RESTURL_MULTISHOP_ABSENT = REST_PATH + "/MultiShop/setMultiShopAbsent";

  // 엑셀출력
  static const String RESTURL_EXCEL_SALES = REST_PATH + "/Order/getExcelSales";
  static const String RESTURL_EXCEL_VATSALES = REST_PATH + "/Order/getExcelVatSales";
  static const String RESTURL_EXCEL_VATPURCHASE = REST_PATH + "/Order/getExcelVatPurchase";
}