import 'dart:convert';
import 'dart:math';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ISInput extends StatefulWidget {

  final double? width;
  final double? height;
  final double? padding;
  final EdgeInsetsGeometry? contentPadding;
  final int? maxLines;
  final String? label;
  final String? value;
  final TextAlign? textAlign;
  final TextStyle? textStyle;
  final ValueChanged? onChange;
  final FormFieldSetter<String>? onSaved;
  final FormFieldValidator<String>? validator;
  final ValueChanged<String>? onFieldSubmitted;
  final TextInputType? keyboardType;
  final int? maxLength;

  final bool? readOnly;
  final bool? required;
  final bool? autofocus;
  final bool? obscureText;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final BuildContext? context;
  final List<TextInputFormatter>? inputFormatters;
  final GestureTapCallback? onTap;

  final String? prefixText;
  final String? suffixText;
  final String? counterText;

  final AutovalidateMode? autovalidateMode;


  const ISInput({
    Key? key,
    this.width,
    this.height,
    this.padding,
    this.contentPadding,
    this.maxLines,
    this.label,
    this.value,
    this.textAlign,
    this.textStyle,
    this.onChange,
    this.onSaved,
    this.validator,
    this.onFieldSubmitted,
    this.keyboardType,
    this.maxLength,
    this.readOnly = false,
    this.required = false,
    this.autofocus = false,
    this.obscureText = false,
    this.prefixIcon,
    this.suffixIcon,
    this.context,
    this.inputFormatters,
    this.onTap,
    this.prefixText,
    this.suffixText,
    this.counterText,
    this.autovalidateMode
  }) : super(key: key);

  @override
  State<ISInput> createState() => _ISInputState();
}

class _ISInputState extends State<ISInput> {
  int cursorPosition = 0;

  @override
  void initState() {
    super.initState();
    if (widget.value != null) {
      cursorPosition = widget.value!.length;
    }
  }

  @override
  Widget build(BuildContext context) {
    TextEditingController _textEditingController = TextEditingController(text: widget.value);
    if (widget.value != null){
      _textEditingController.value = _textEditingController.value.copyWith(
        selection: TextSelection.fromPosition(TextPosition(offset: cursorPosition)),
      );
    }

    return Container(
      //padding: EdgeInsets.symmetric(horizontal: 8.0),
      alignment: Alignment.center,
      width: widget.width ?? double.infinity,//200,
      height: widget.height ?? 40,
      child: TextFormField(
        maxLengthEnforcement: MaxLengthEnforcement.enforced,
        maxLength: widget.maxLength,
        autofocus: widget.autofocus ?? false,
        readOnly: widget.readOnly ?? false,
        textAlign: widget.textAlign ?? TextAlign.start,
        textAlignVertical: widget.prefixIcon == null ? TextAlignVertical.top : TextAlignVertical.center,
        maxLines: widget.maxLines ?? 1,
        keyboardType: widget.keyboardType ?? TextInputType.text,
        style: widget.textStyle ?? const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
        obscureText: widget.obscureText ?? false,
        decoration: InputDecoration(
          errorText: null,
          fillColor: widget.readOnly == false ? /*Colors.grey[300]*/Colors.white : Colors.grey[200],
          //Color(0xffdefcfc),
          filled: true,
          prefixIcon: widget.prefixIcon,
          suffixIcon: widget.suffixIcon,// ?? const Icon(Icons.search, color: Colors.black54,),
          enabled: true,//enabled: readOnly == false ? true : false,//enable ?? true,
          hintText: widget.label,
          hintStyle: const TextStyle(color: Colors.black54, fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
          prefixText: widget.prefixText,
          prefixStyle: const TextStyle(color: Colors.black54, fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
          suffixText: widget.suffixText,
          suffixStyle: const TextStyle(color: Colors.black54, fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
          // labelText: label,
          // labelStyle: const TextStyle(color: Colors.black54, fontSize: 10),
          //border: const OutlineInputBorder(),
          // border: OutlineInputBorder(
          //   borderSide: BorderSide.none,
          //   borderRadius: const BorderRadius.all(Radius.circular(6)),
          // ),
          //border: const OutlineInputBorder(),
          enabledBorder: const OutlineInputBorder(
            //borderRadius: BorderRadius.all(Radius.circular(12.0)),
            borderSide: BorderSide(color: Colors.black12, width: 1.0),
          ),
          focusedBorder: const OutlineInputBorder(
            //borderRadius: BorderRadius.all(Radius.circular(10.0)),
            borderSide: BorderSide(color: Colors.lightBlueAccent, width: 1.0),
          ),
          errorBorder: const OutlineInputBorder(
            //borderRadius: BorderRadius.all(Radius.circular(10.0)),
            borderSide: BorderSide(color: Colors.red, width: 1.0),
          ),
          focusedErrorBorder: const OutlineInputBorder(
            //borderRadius: BorderRadius.all(Radius.circular(10.0)),
            borderSide: BorderSide(color: Colors.red, width: 1.0),
          ),
          //hintText: label,
          isDense: true,

          contentPadding: widget.contentPadding ?? const EdgeInsets.fromLTRB(10, 8, 4, 8),
          counterText: widget.counterText
          //contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),

        ),
        //scrollPadding: const EdgeInsets.symmetric(horizontal: 20),
        controller: _textEditingController,//TextEditingController(text: value),
        inputFormatters: widget.inputFormatters ?? [],
        onEditingComplete: () => context == null ? null : FocusScope.of(context).nextFocus(),
        onFieldSubmitted: widget.onFieldSubmitted,
        onChanged: (v) {
          cursorPosition = _textEditingController.selection.baseOffset;
          if (widget.onChange != null) {
            widget.onChange!(v);
          }
        },
        onSaved: (v) {
          if (widget.onSaved != null) {
            widget.onSaved!(v);
          }
        },
        onTap: widget.onTap,
        autovalidateMode: widget.autovalidateMode ?? AutovalidateMode.disabled,
        validator: (v) {
          // if (required! && v!.isEmpty) {
          //   return '필수입력항목';
          // }
          // List<int> bytes = utf8.encode(v!)

          if (widget.validator != null) {
            return widget.validator!(v);
          }
          return null;
        },
      ),
    );
  }
}