enum DateRangeType { last90days, last30days, thisMonth, nowDay }

extension DateRangeTypeReturn on DateRangeType {
  String getTitle({
    last90daysTitle,
    last30daysTitle,
    thisMonthTitle,
    nowDayTitle,
  }) {
    switch (this) {
      case DateRangeType.last90days:
        return last90daysTitle ?? '3개월';
      case DateRangeType.last30days:
        return last30daysTitle ?? '1개월';
      case DateRangeType.thisMonth:
        return thisMonthTitle ?? '이번 달';
      case DateRangeType.nowDay:
        return nowDayTitle ?? '오늘';
    }
  }
}
