import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ISSelectTime extends StatefulWidget {
  final double? width;
  final double? height;
  final String? hour;
  final String? minute;
  final String? title;
  final ValueChanged<String>? onTimeSelected;
  bool? chk;

  ISSelectTime({
    Key? key,
    this.width,
    this.height,
    this.hour,
    this.minute,
    this.title,
    this.onTimeSelected,
    this.chk,
  }) : super(key: key);

  @override
  _ISSelectTimeState createState() => _ISSelectTimeState();
}

class _ISSelectTimeState extends State<ISSelectTime> {
  late TextEditingController _hourController;
  late TextEditingController _minuteController;
  late FocusNode _hourFocusNode;
  late FocusNode _minuteFocusNode;

  @override
  void didUpdateWidget(ISSelectTime oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.chk == true) {
      if (oldWidget.hour != widget.hour) {
        _hourController.text = widget.hour ?? '';
      }
      if (oldWidget.minute != widget.minute) {
        _minuteController.text = widget.minute ?? '';
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _hourController = TextEditingController(text: widget.hour);
    _minuteController = TextEditingController(text: widget.minute);
    _hourFocusNode = FocusNode();
    _minuteFocusNode = FocusNode();
  }

  @override
  void dispose() {
    _hourController.dispose();
    _minuteController.dispose();
    _hourFocusNode.dispose();
    _minuteFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _buildTimeColumn(_hourController, _minuteController, widget.title),
      ],
    );
  }

  Widget _buildTimeColumn(TextEditingController hourController, TextEditingController minuteController, String? title) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        title != null ? Container(padding: const EdgeInsets.only(top: 4), child: Text('   $title', style: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),)) : Container(),
        Row(
          children: [
            _buildTimeInput(hourController, _hourFocusNode),
            const SizedBox(
              width: 3,
            ),
            _buildTimeInput(minuteController, _minuteFocusNode),
          ],
        ),
      ],
    );
  }

  Widget _buildTimeInput(TextEditingController controller, FocusNode focusNode) {
    focusNode.addListener(() {
      if (focusNode.hasFocus) {
        controller.selection = TextSelection(
          baseOffset: 0,
          extentOffset: controller.text.length,
        );
      } else {
        controller.text = controller.text.padLeft(2, '0');
        if (controller.text != '00' && controller.text.startsWith('00')) {
          controller.text = controller.text.substring(2);
          final hour = _hourController.text.padLeft(2, '0');
          final minute = _minuteController.text.padLeft(2, '0');
          final selectedTime = hour + minute;

          widget.onTimeSelected?.call(selectedTime);
        }
      }
    });

    return Container(
      color: Colors.white,
      width: widget.width ?? 95,
      height: widget.height ?? 33,
      child: Row(
        children: [
          Expanded(
            child: TextFormField(
              controller: controller,
              focusNode: focusNode,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.only(bottom: 2, left: 3),
                border: const OutlineInputBorder(),
                enabledBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xffDCDCDC)),
                ),
                counterText: '',
                suffixIcon: _buildUpDownButtons(controller),
                //suffixText: controller == _hourController ? '시' : '분',
              ),
              textAlign: TextAlign.end,
              textAlignVertical: TextAlignVertical.center,
              style: const TextStyle(
                fontFamily: FONT_FAMILY,
                fontSize: 14,
                fontWeight: FONT_NORMAL,
                color: Color(0xff000000),
              ),
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
              ],
              onChanged: (text) {
                _onTimeChanged(controller);
              },
              showCursor: focusNode.hasFocus,
            ),
          ),
        ],
      ),
    );
  }

  void _onTimeChanged(controller) {
    int currentValue = int.tryParse(controller.text) ?? 0;

    if (controller.text.isEmpty) {
      controller.text = '00';
    }

    if (controller == _hourController) {
      if (currentValue > 23) {
        controller.text = '00';
        ISAlert(context, content: '23시 까지 입력 가능합니다.');
        return;
      }
    }
    if (controller == _minuteController) {
      if (currentValue > 59) {
        controller.text = '00';
        ISAlert(context, content: '59분 까지 입력 가능합니다.');
        return;
      }
    }

    final hour = _hourController.text.padLeft(2, '0');
    final minute = _minuteController.text.padLeft(2, '0');
    final selectedTime = hour + minute;

    widget.onTimeSelected?.call(selectedTime);
  }

  Widget _buildUpDownButtons(TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.all(1.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            child: IconButton(
              iconSize: 15,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
              icon: const Icon(Icons.arrow_drop_up),
              hoverColor: Colors.transparent,
              splashColor: Colors.transparent,
              onPressed: () {
                int currentValue = int.tryParse(controller.text) ?? 0;
                if (controller == _hourController) {
                  if (currentValue < 23) {
                    controller.text = (currentValue + 1).toString().padLeft(2, '0');
                  } else {
                    controller.text = '00';
                  }
                }
                if (controller == _minuteController) {
                  if (currentValue < 59) {
                    controller.text = (currentValue + 1).toString().padLeft(2, '0');
                  } else {
                    controller.text = '00';
                  }
                }
                _onTimeChanged(controller); // 시간 변경 후 호출
              },
            ),
          ),
          InkWell(
            child: IconButton(
              iconSize: 15,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
              icon: const Icon(Icons.arrow_drop_down),
              hoverColor: Colors.transparent,
              splashColor: Colors.transparent,
              onPressed: () {
                int currentValue = int.tryParse(controller.text) ?? 0;
                if (controller == _hourController) {
                  if (currentValue > 0) {
                    controller.text = (currentValue - 1).toString().padLeft(2, '0');
                  } else {
                    controller.text = '23';
                  }
                } else if (controller == _minuteController) {
                  if (currentValue > 0) {
                    controller.text = (currentValue - 1).toString().padLeft(2, '0');
                  } else {
                    controller.text = '59';
                  }
                }
                _onTimeChanged(controller); // 시간 변경 후 호출
              },
            ),
          ),
        ],
      ),
    );
  }
}
