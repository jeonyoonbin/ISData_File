import 'package:daeguro_admin_app/Provider/RestApiProvider.dart';
import 'package:daeguro_admin_app/constants/serverInfo.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class StatController extends GetxController with SingleGetTickerProviderMixin {
  static StatController get to => Get.find();
  BuildContext context;

  List<dynamic> qData = [];
  List<dynamic> qDetailData = [];

  List<dynamic> qDataSales = [];

  RxString fromDate = ''.obs;
  RxString toDate = ''.obs;

  @override
  void onInit() {
    Get.put(RestApiProvider());

    //getData(context);

    super.onInit();
  }

  Future<List<dynamic>> getShopTotalOrderData(String gungu) async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getStatShopTotalOrder(gungu, fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }

  getShopTypeData(String startDate, String endDate) async {
    qData.clear();
    //print('===== getTypeStatisticsData() startDate: '+startDate+', endDate: '+endDate);
    var result = await RestApiProvider.to.getStatShopType(startDate, endDate);

    //print('===== getTypeStatisticsData()-> '+ result.bodyString.toString());

    qData.assignAll(result.body['data']);

    // if (result.body['code'] != '00') {
    //   ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    // }
  }

  getShopSalesData(String startDate, String endDate) async {
    qDataSales.clear();
    //print('===== getTypeStatisticsData() startDate: '+startDate+', endDate: '+endDate);
    var result = await RestApiProvider.to.getStatShopSales(startDate, endDate);

    //print('===== getSalesStatisticsData()-> '+ result.bodyString.toString());

    qDataSales.assignAll(result.body['data']);

    // if (result.body['code'] != '00') {
    //   ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    // }
  }

  Future<List<dynamic>> getShopGunguData(String divKey) async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getShopGungu(divKey, fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getShopCategoryData() async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getShopCategory(fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getCustomerDailyData() async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getStatCustomerDaily(fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getNonCustomerDailyData() async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getStatNonCustomerDaily(fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getCustomerOrderData() async {
    List<dynamic> retData = [];

    //var result = await RestApiProvider.to.getStatCustomerOrder(fromDate.value.toString(), toDate.value.toString());

    // dio 패키지 조회
    var dio = Dio();
    final response =
        await dio.get(ServerInfo.REST_URL_STAT_CUSTOMERORDER + '?date_begin=' + fromDate.value.toString() + '&date_end=' + toDate.value.toString());

    if (response.data['code'] == '00')
      retData.assignAll(response.data['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getCustomerRankOrderData() async {
    List<dynamic> retData = [];

    //var result = await RestApiProvider.to.getStatCustomerRankOrder(fromDate.value.toString(), toDate.value.toString());

    // dio 패키지
    var dio = Dio();
    final response =
        await dio.get(ServerInfo.REST_URL_STAT_CUSTOMERRANKORDER + '?date_begin=' + fromDate.value.toString() + '&date_end=' + toDate.value.toString());

    if (response.data['code'] == '00')
      retData.assignAll(response.data['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getOrderCategoryData() async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getStatOrderCategory(fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getOrderTimeData() async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getStatOrderTime(fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getOrderPayData() async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getStatOrderPay(fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getOrderGunguData() async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getStatOrderGungu(fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getDailyOrderCompletedCanceled() async {
    List<dynamic> retData = [];

    //var result = await RestApiProvider.to.getStatOrderDailyCompletedCanceled(fromDate.value.toString(), toDate.value.toString());

    // dio 패키지
    var dio = Dio();
    final response = await dio
        .get(ServerInfo.REST_URL_STAT_DAILYORDER_COMPLETEDCANCELED + '?date_begin=' + fromDate.value.toString() + '&date_end=' + toDate.value.toString());

    if (response.data['code'] == '00')
      retData.assignAll(response.data['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getDailyOrderPayGbn() async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getStatOrderDailyPayGbn(fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getDailyOrderCancelReason() async {
    List<dynamic> retData = [];

    //var result = await RestApiProvider.to.getStatOrderDailyCancelReason(fromDate.value.toString(), toDate.value.toString());

    // dio 패키지
    var dio = Dio();
    final response =
        await dio.get(ServerInfo.REST_URL_STAT_DAILYORDER_CANCELREASON + '?date_begin=' + fromDate.value.toString() + '&date_end=' + toDate.value.toString());

    if (response.data['code'] == '00')
      retData.assignAll(response.data['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getShopTypeDetailData(String gungu, String startDate, String endDate) async {
    List<dynamic> tempRetData = [];
    //print('===== getTypeStatisticsData() startDate: '+startDate+', endDate: '+endDate);
    var result = await RestApiProvider.to.getStatShopTypeDetail(gungu, startDate, endDate);

    //print('===== getTypeStatisticsData()-> '+ result.bodyString.toString());

    tempRetData.assignAll(result.body['data']);

    return tempRetData;
    // if (result.body['code'] != '00') {
    //   ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    // }
  }

  Future<List<dynamic>> getShopSalesDetailData(String gungu, String startDate, String endDate) async {
    List<dynamic> tempRetData = [];
    //print('===== getTypeStatisticsData() startDate: '+startDate+', endDate: '+endDate);
    var result = await RestApiProvider.to.getStatShopSalesDetail(gungu, startDate, endDate);

    //print('===== getSalesStatisticsDetailData()-> '+ result.bodyString.toString());

    tempRetData.assignAll(result.body['data']);

    return tempRetData;
    // if (result.body['code'] != '00') {
    //   ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    // }
  }

  Future<List<dynamic>> getDailyAgeToOrderData() async {
    List<dynamic> retData = [];

    //var result = await RestApiProvider.to.getDailyAgeToOrder(fromDate.value.toString(), toDate.value.toString());

    // dio 패키지
    var dio = Dio();
    final response =
    await dio.get(ServerInfo.REST_URL_STAT_DAILYAGE_TO_ORDER + '?date_begin=' + fromDate.value.toString() +'&date_end=' + toDate.value.toString());

    if (response.data['code'] == '00')
      retData.assignAll(response.data['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getDailyEventCountData() async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getDailyEventCount(fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }

  Future<List<dynamic>> getDrgCouponData(String couponName) async {
    //qData.clear();

    var result = await RestApiProvider.to.getStatCouponDrgCoupon(couponName);

    //print('===== getDrgCoupon()-> '+ result.bodyString.toString());

    //qData.assignAll(result.body['data']);

    return result.body['data'];

    // if (result.body['code'] != '00') {
    //   ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    // }
  }

  Future<List<dynamic>> getDrgCouponDetailData(String mon, String couponName) async {
    qData.clear();
    //print('===== getTypeStatisticsData() startDate: '+startDate+', endDate: '+endDate);
    var result = await RestApiProvider.to.getStatCouponDrgCouponDetail(mon, couponName);

    //print('===== getDrgCouponDetail()-> '+ result.bodyString.toString());

    return  result.body['data'];

    // if (result.body['code'] != '00') {
    //   ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    // }
  }

  Future<List<dynamic>> getDailyDrgCouponData(String type, String coupon_name) async {
    List<dynamic> retData = [];

    var result = await RestApiProvider.to.getStatCouponDailyDrgCoupon(type, coupon_name, fromDate.value.toString(), toDate.value.toString());

    if (result.body['code'] == '00')
      retData.assignAll(result.body['data']);
    else
      return null;

    return retData;
  }
}
