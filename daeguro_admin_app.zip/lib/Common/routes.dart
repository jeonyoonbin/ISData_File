﻿import 'package:daeguro_admin_app/View/AdvertisementManager/AD_VideoUploadMain.dart';
import 'package:daeguro_admin_app/View/AgentManager/agentAccount_main.dart';
import 'package:daeguro_admin_app/View/ApiCompanyManager/apiCompany_main.dart';
import 'package:daeguro_admin_app/View/AuthMobileManager/AuthMobileManager_main.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculateCcMileage_main.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculateCommision_main.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculateInsertTaxMast_main.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculateOrderPayMentSearch_main.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculateSearchShopTax_main.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculateShopMileage_main.dart';
import 'package:daeguro_admin_app/View/CategoryManager/productCategory_main.dart';
import 'package:daeguro_admin_app/View/CodeManager/codeB2BCouponListMain.dart';
import 'package:daeguro_admin_app/View/CodeManager/codeBrandCouponListMain.dart';
import 'package:daeguro_admin_app/View/CodeManager/codeCouponListMain.dart';
import 'package:daeguro_admin_app/View/CodeManager/codeListMain.dart';
import 'package:daeguro_admin_app/View/CodeManager/codeTotalListMain.dart';
import 'package:daeguro_admin_app/View/CodeManager/codeVoucherMain.dart';
import 'package:daeguro_admin_app/View/Common/page_AuthFail.dart';
import 'package:daeguro_admin_app/View/Common/page_IPGetFail.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsBlogMain.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsWebtoonMain.dart';
import 'package:daeguro_admin_app/View/CouponManager/B2BUsercoupon_main.dart';
import 'package:daeguro_admin_app/View/CouponManager/B2Bcoupon_main.dart';
import 'package:daeguro_admin_app/View/CouponManager/BrandcouponApp_main.dart';
import 'package:daeguro_admin_app/View/CouponManager/BrandcouponList_main.dart';
import 'package:daeguro_admin_app/View/CouponManager/BrandcouponShop_main.dart';
import 'package:daeguro_admin_app/View/CouponManager/coupon_main.dart';
import 'package:daeguro_admin_app/View/CustomerManager/customer_main.dart';
import 'package:daeguro_admin_app/View/LogManager/logAuthMain.dart';
import 'package:daeguro_admin_app/View/LogManager/logCouponMain.dart';
import 'package:daeguro_admin_app/View/LogManager/logPrivacyMain.dart';
import 'package:daeguro_admin_app/View/LogManager/logTaxMain.dart';
import 'package:daeguro_admin_app/View/HistoryManager/history_B2BCouponmain.dart';
import 'package:daeguro_admin_app/View/HistoryManager/history_Mileagemain.dart';
import 'package:daeguro_admin_app/View/NoticeManager/Flower/flowerNotice_main.dart';
import 'package:daeguro_admin_app/View/NoticeManager/Reser/reserNotice_main.dart';
import 'package:daeguro_admin_app/View/NoticeManager/noticeEm_main.dart';
import 'package:daeguro_admin_app/View/OrderManager/congrats_main.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderCancelListmain.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderShopCancelListmain.dart';
import 'package:daeguro_admin_app/View/LogManager/logErrorMain.dart';
import 'package:daeguro_admin_app/View/LoginSMS.dart';
import 'package:daeguro_admin_app/View/MappingManager/mapping_main.dart';
import 'package:daeguro_admin_app/View/MileageManager/mileageSale_main.dart';
import 'package:daeguro_admin_app/View/MileageManager/mileage_main.dart';
import 'package:daeguro_admin_app/View/NoticeManager/notice_main.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderTheme_main.dart';
import 'package:daeguro_admin_app/View/OrderManager/order_main.dart';
import 'package:daeguro_admin_app/View/PushManager/push_main.dart';
import 'package:daeguro_admin_app/View/RequestManager/requestList_main.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reserveFAQ_main.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reserveThemeSetting_main.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reserveTheme_main.dart';
import 'package:daeguro_admin_app/View/ReviewManager/reserve/reviewReserve_main.dart';
import 'package:daeguro_admin_app/View/ReviewManager/review_main.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopFoodSafety_main.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopNotUseList.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopNotUseList_main.dart';
import 'package:daeguro_admin_app/View/ShopManager/Coupon/shopEventCoupon_main.dart';
import 'package:daeguro_admin_app/View/ShopManager/Event/shopEvent_main.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopRegNoList_main.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccount_main.dart';
import 'package:daeguro_admin_app/View/ShopManager/Kind/kindShop_main.dart';
import 'package:daeguro_admin_app/View/ShopManager/Reservation/shopReservation_main.dart';
import 'package:daeguro_admin_app/View/ShopManager/childMeal/shopChildMeal_main.dart';
import 'package:daeguro_admin_app/View/StatManager/Coupon/stat_Couponmain.dart';
import 'package:daeguro_admin_app/View/StatManager/Customer/stat_Customermain.dart';
import 'package:daeguro_admin_app/View/StatManager/Mileage/stat_Mileagemain.dart';
import 'package:daeguro_admin_app/View/StatManager/Order/stat_Ordermain.dart';
import 'package:daeguro_admin_app/View/StatManager/SECoupon/stat_SECouponmain.dart';
import 'package:daeguro_admin_app/View/StatManager/Shop/stat_Shopmain.dart';
import 'package:daeguro_admin_app/View/StatManager/Taxi/stat_TaxiMain.dart';
import 'package:daeguro_admin_app/View/ThemeManager/productTheme_main.dart';
import 'package:daeguro_admin_app/View/Today/dashboard_screen.dart';
import 'package:daeguro_admin_app/View/AuthManager/AuthManager_main.dart';
import 'package:daeguro_admin_app/View/UserManager/user_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherCancel_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherCardImageCategory_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherCardImage_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherCodeGroup_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherCode_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/Statvoucher_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherExp_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherRefund_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherCalc_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherBuy_Main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherSend_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherTotalCode_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherUse_main.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucher_main.dart';
import 'package:daeguro_admin_app/View/common/page_401.dart';
import 'package:daeguro_admin_app/View/common/page_404.dart';
import 'package:daeguro_admin_app/View/common/page_empty.dart';
import 'package:daeguro_admin_app/View/payInfoManager/payInfo_main.dart';
import 'package:daeguro_admin_app/View/userInfo/user_info_mine.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/Layout/layout.dart';
import 'package:daeguro_admin_app/constants/serverInfo.dart';
import 'package:dart_ipify/dart_ipify.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';

Map<String, Widget> layoutRoutesData = {
  '/': DashboardScreen(),//MainToday(),//DailyStatusInfo(),//

  '/userManager': UserMain(),

  '/agentAccountManager': AgentAccountMain(),

  '/shopAccountManager': ShopAccountMain(),
  '/shopAccountModificationRegNo': ShopRegNoListMain(),
  //'/shopImageManager': ShopImageMain(),
  '/ShopEventList': ShopEventMain(),
  '/ShopFoodSafety': ShopFoodSafetyMain(),
  '/ShopReservationMain': ShopReservationMain(),
  '/shopEventCoupon': ShopEventCouponMain(),
  '/shopNotUseList': ShopNotUseListMain(),
  '/kindShopManager': KindShopManager(),
  '/shopChildMealList': ShopChildMealListMain(),

  '/ReservThemeManager': ReserveThemeMain(),
  '/ReservThemeSettingManager': ReserveThemeSettingMain(),

  '/orderManager': OrderMain(),
  '/orderCompleteToCancel': OrderCancelListMain(),
  '/orderShopCancelList': OrderShopCancelListMain(),
  '/OrderThemeManager': OrderThemeMain(),

  '/CongratsManager': CongratsMain(),

  '/RequestList': RequestManager(),

  '/ApiCompanyList': APICompanyMain(),

  '/CouponListManager': CouponMain(),
  '/B2BCouponListManager': B2BCouponMain(),
  '/BrandCouponAppListManager': BrandCouponAppMain(),
  '/BrandCouponShopListManager': BrandCouponShopMain(),

  '/B2BCouponUserListManager': B2BUserCouponMain(),
  '/BrandCouponListManager': BrandCouponMain(),

  '/savingsManager': PageEmpty(),

  '/NoticeListManager': NoticeMain(),
  '/ReserNoticeListManager': ReserNoticeMain(),
  '/NoticeEmManager': NoticeEmMain(),
  '/FlowerNoticeListManager': FlowerNoticeMain(),

  '/customerListManager': CustomerMain(),

  //'/historyCouponList': HistoryCouponMain(),
  '/historyB2BCouponList': HistoryB2BCouponMain(),
  //'/historyBrandCouponList': HistoryBrandCouponMain(),
  '/historyMileageList': HistoryMileageMain(),

  '/MileageInOut': MileageMain(),
  '/MileageSaleInOut': MileageSaleMain(),

  '/statShopManager': StatShopMain(),
  '/statCustomerManager': StatCustomerMain(),
  '/statOrderManager': StatOrderMain(),
  '/statCouponManager': StatCouponMain(),
  '/statMileageManager': StatMileageMain(),
  '/statSECouponManager': StatSECouponMain(),
  '/statTaxiManager': StatTaxiMain(),

  '/MappingList': MappingMain(),//ImageUpload(),

  '/userInfoMine': UserInfoMine(),

  '/userAuthManager' : AuthManagerMain(),
  '/userAuthMobileManager' : AuthMobileManagerMain(),

  '/CalculateShopMileage': CalculateShopMileageManager(),
  '/CalculateCcMileage': CalculateCcMileageManager(),
  '/CalculateCommission': CalculateCommissionManager(),
  '/CalculateOrderPayMentSearch': CalculateOrderPayMentSearchManager(),
  '/CalculateInsertTaxMast': CalculateInsertTaxMastMain(),
  '/CalculateSearchShopTax': calculateSearchShopTaxMain(),

  //'/CalculateOutstandingAmount': CalculateOutstandingAmountManager(),

  '/LogPrivacyListManager': LogPrivacyMain(),
  '/LogErrorListManager': LogErrorMain(),
  '/LogTaxListManager': LogTaxMain(),
  '/LogCouponListManager': LogCouponMain(),
  '/LogAuthListManager': LogAuthMain(),

  '/codeListManager': CodeListMain(),
  '/codeCouponListManager': CodeCouponListMain(),
  '/codeB2BCouponListManager': CodeB2BCouponListMain(),
  '/codeBrandCouponListManager': CodeBrandCouponListMain(),
  '/codeVoucherManager': CodeVoucherMain(),
  '/codeTotalManager': CodeTotalListMain(),

  '/ReviewListManager': ReviewMain(),
  '/ReviewReserveListManager': ReviewReserveMain(),

  '/VoucherListManager': VoucherMain(),
  '/VoucherCodeGroupManager': VoucherCodeGroupMain(),
  '/VoucherCodeManager': VoucherCodeMain(),
  '/VoucherCardImageManager': VoucherCardImageMain(),
  '/VoucherCardImageCategoryManager': VoucherCardImageCategoryMain(),
  '/VoucherSalesManager': VoucherBuyMain(),
  '/VoucherUseManager': VoucherUseMain(),
  '/VoucherCalcManager': VoucherCalcsMain(),
  '/VoucherSendManager': VoucherSendMain(),
  '/VoucherExpManager': VoucherExpMain(),
  '/VoucherCancelManager': VoucherCancelMain(),
  '/VoucherDailyManager': StatVoucherMain(),
  '/VoucherRefundManager': VoucherRefundMain(),
  '/VoucherTotalCodeManager': VoucherTotalCodeMain(),

  '/contentsWebtoonMain': ContentsWebtoonMain(),
  '/contentsBlogMain': ContentsBlogMain(),

  '/ReserveFAQMain': ReserveFaqMain(),
  '/pushManager' : PushMain(),

  '/Ad_VideoUploadManager' : AD_VideoUploadMain(),

  '/PayInfoManager': PayInfoMain(),

  '/ProductCategoryManager': ProductCategoryMain(),
  '/ProductThemeManager': ProductThemeMain(),

  '/layout401': Page401(),
  '/layout404': Page404(),
};

Map<String, Widget> routesData = {
  '/login': LoginSMS(),
  // '/register': Register(),
  '/': Layout(),
  '/401': Page401(),
  '/404': Page404(),
  '/authFail': PageAuthFail(),
  '/ipGetFail': PageIPGetFail(),
};
List<String> whiteRouters = ['/register'];

Map<String, WidgetBuilder> routes = routesData.map((key, value) {
  return MapEntry(key, (context) => value);
});

class Routes {
  static onGenerateRoute(RouteSettings settings)  {
    String name = settings.name;
    //print('before name-> '+name);

    String clientIP = GetStorage().read('clientIP');

    print('clientIP:${clientIP}');

    if (clientIP == '' || clientIP == null){
      name = '/ipGetFail';

      return MaterialPageRoute(builder: routes[name], settings: settings);
    }

    if (clientIP != '' && ServerInfo.DAEGURO_PUBLIC_IP != clientIP){
      name = '/authFail';

      return MaterialPageRoute(builder: routes[name], settings: settings);
    }

    if (!routes.containsKey(name)) {
      name = '/404';
    }
    else if (!Utils.isLogin() && !whiteRouters.contains(name)) {
      name = '/login';
    }

    // if (!Utils.isLogin() && !whiteRouters.contains(name)) {
    //   name = '/login';
    // }

    // print('page move-> '+name);

    return MaterialPageRoute(builder: routes[name], settings: settings);
  }
}
