import 'dart:math';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:html/parser.dart';
import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:flutter/material.dart';
import 'package:universal_html/html.dart' as html;
import 'package:universal_html/js.dart' as js;
import 'fake_ui.dart' if (dart.library.html) 'real_ui.dart' as ui;

class IsEditor extends StatefulWidget {
  final String htmlText;

  const IsEditor({Key key, this.htmlText}) : super(key: key);

  @override
  _IsEditorState createState() => _IsEditorState();
}

class _IsEditorState extends State<IsEditor> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String _setHtml;

  js.JsObject connector;

  String createdViewId = Random().nextInt(1000).toString();
  html.IFrameElement element;

  String parseHtmlString(String htmlString) {
    try {
      final document = parse(htmlString);
      final String parsedString =
          parse(document.body.text).documentElement.text;

      return parsedString;
    } catch (e) {
      return htmlString;
    }
  }

  @override
  void initState() {
    js.context["connect_content_to_flutter"] = (js.JsObject content) {
      connector = content;
    };

    element = html.IFrameElement()
      ..src = "assets/editor.html"
      ..style.border = 'none'
      ..style.width = '100%'
      ..style.height = '100%';

    ui.platformViewRegistry
        .registerViewFactory(createdViewId, (int viewId) => element);

    WidgetsBinding.instance.addPostFrameCallback((c) async {
      await ISProgressDialog(context).show(status: 'Loading...');

      await Future.delayed(Duration(milliseconds: 1500), () async{
        setState(() {
          sendMessageToEditor(widget.htmlText);
        });

        await ISProgressDialog(context).dismiss();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '편집',
          iconData: Icons.edit,
          onPressed: () async {
            List<String> _result = [];
            _result.clear();

            _result.add(getMessageFromEditor());

            String _contText = parseHtmlString(_setHtml);
            _result.add(_contText);

            Navigator.of(context, rootNavigator: true).pop(_result);
          },
        ),
        ISButton(
          label: '닫기',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('HTML 텍스트 편집기'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20),
            Container(
                padding: EdgeInsets.symmetric(horizontal: 8.0),
                child: SizedBox(
                    height: 750,
                    width: 1100,
                    child: HtmlElementView(viewType: createdViewId))),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );

    return SizedBox(
      height: 900,
      width: 1100,
      child: result,
    );
  }

  getMessageFromEditor() {
    final String str = connector.callMethod(
      'getValue',
    ) as String;

    _setHtml = str;
    return str;
  }

  sendMessageToEditor(String data) async {
    await element.contentWindow.postMessage({
      'id': 'value',
      'msg': data,
    }, "*");
  }
}