// ignore: camel_case_types
class platformViewRegistry {
  static void registerViewFactory(String viewId, dynamic cb) {}
}