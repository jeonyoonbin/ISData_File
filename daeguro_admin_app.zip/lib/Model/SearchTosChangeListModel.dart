import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class SearchTosChangeListModel {
  SearchTosChangeListModel();

  String change_seq;
  String service_gbn;
  String check_gbn;
  String ins_date;
  String change_contents;
  String memo;
}