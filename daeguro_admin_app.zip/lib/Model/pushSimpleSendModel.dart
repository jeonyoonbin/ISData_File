import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class pushSimpleSendModel {
  pushSimpleSendModel();

  String title;
  String telno;
  String msg;
  String pushGbn;
  String item1;

  factory pushSimpleSendModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

pushSimpleSendModel _$ModelFromJson(Map<String, dynamic> json) {
  return pushSimpleSendModel()
    ..title = json['push_cd'] as String
    ..telno = json['push_title'] as String
    ..msg = json['send_gbn'] as String
    ..pushGbn = json['pushGbn'] as String
    ..item1 = json['item1'] as String;
}

Map<String, dynamic> _$ModelToJson(pushSimpleSendModel instance) => <String, dynamic>{
  'title': instance.title,
  'telno': instance.telno,
  'msg': instance.msg,
  'pushGbn': instance.pushGbn,
  'item1': instance.item1
};
