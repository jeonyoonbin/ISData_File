import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class pushSimpleSendModel {
  pushSimpleSendModel();

  String title;
  String telno;
  String msg;

  factory pushSimpleSendModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

pushSimpleSendModel _$ModelFromJson(Map<String, dynamic> json) {
  return pushSimpleSendModel()
    ..title = json['push_cd'] as String
    ..telno = json['push_title'] as String
    ..msg = json['send_gbn'] as String;
}

Map<String, dynamic> _$ModelToJson(pushSimpleSendModel instance) => <String, dynamic>{
  'title': instance.title,
  'telno': instance.telno,
  'msg': instance.msg,
};
