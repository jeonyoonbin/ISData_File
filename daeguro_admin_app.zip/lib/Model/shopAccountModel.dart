﻿import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopAccountModel {
  ShopAccountModel();

  bool selected = false;
  bool viewSelected = false;
  String ccCode;
  String shopCd;
  String shopName;
  String regNo;
  String regNoYn;
  String useGbn;
  String openDate;
  String salesmanCode;
  String salesmanName;
  String operatorCode;
  String operatorName;
  //String imageStatus;
  String shopStatus;
  String absentYn;
  String calcYn;
  String shopInfoYn;
  String menuYn;
  String deliYn;
  String tipYn;
  String saleYn;
  String basicInfoYn;
  String appOrderYn;
  String isCharged;
  String isPosInstalled;
  String isPosLogined;
  String loginTime;
  String apiComCode;
  String shopImageYn;
  String menuComplete;
  String franchiseCd;
  String reserveYn;
  String reserReqDate;
  String distanceYn;
}


