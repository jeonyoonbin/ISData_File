import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class KidsMealdrLinkYnModel {
  KidsMealdrLinkYnModel();

  String reg_no;
  String shop_cd;
  String shop_name;
  String child_meal_yn;
  String child_meal_cd;
  String mod_ucode;

  factory KidsMealdrLinkYnModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

KidsMealdrLinkYnModel _$ModelFromJson(Map<String, dynamic> json) {
  return KidsMealdrLinkYnModel()
    ..reg_no = json['reg_no'] as String
    ..shop_cd = json['shop_cd'] as String
    ..shop_name = json['shop_name'] as String
    ..child_meal_yn = json['child_meal_yn'] as String
    ..child_meal_cd = json['child_meal_cd'] as String
    ..mod_ucode = json['mod_ucode'] as String;
}

Map<String, dynamic> _$ModelToJson(KidsMealdrLinkYnModel instance) => <String, dynamic>{
  '"reg_no"': '"' + instance.reg_no + '"',
  '"shop_cd"': '"' + instance.shop_cd + '"',
  '"shop_name"': '"' + instance.shop_name + '"',
  '"child_meal_yn"': '"' + instance.child_meal_yn + '"',
  '"child_meal_cd"': '"' + instance.child_meal_cd + '"',
  '"mod_ucode"': '"' + instance.mod_ucode + '"'
};