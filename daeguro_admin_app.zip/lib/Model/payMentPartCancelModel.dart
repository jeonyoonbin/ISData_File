import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class PaymentPartCancel {
  PaymentPartCancel();

  int server_type;
  String order_no;
  int refund_amount;
  String cancel_type;
  String pay_type;
  int mod_mny;
  int rem_mny;

  factory PaymentPartCancel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

PaymentPartCancel _$ModelFromJson(Map<String, dynamic> json) {
  return PaymentPartCancel()
    ..server_type = json['server_type'] as int
    ..order_no = json['order_no'] as String
    ..refund_amount = json['refund_amount'] as int
    ..cancel_type = json['cancel_type'] as String
    ..pay_type = json['pay_type'] as String
    ..mod_mny = json['mod_mny'] as int
    ..rem_mny = json['rem_mny'] as int;
}

Map<String, dynamic> _$ModelToJson(PaymentPartCancel instance) => <String, dynamic>{
  'server_type': instance.server_type,
  'order_no': instance.order_no,
  'refund_amount': instance.refund_amount,
  'cancel_type': instance.cancel_type,
  'pay_type': instance.pay_type,
  'mod_mny': instance.mod_mny,
  'rem_mny': instance.rem_mny,
};