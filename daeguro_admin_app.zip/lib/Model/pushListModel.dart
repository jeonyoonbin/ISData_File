
class pushListModel {
  pushListModel();

  bool selected = false;
  String rnum;
  String push_gbn;
  String push_cd;
  String push_title;
  String push_msg;
  String send_gbn;
  String st_date;
  String object_gbn;
  String range_gbn;
  String marketing_push_gbn;
  String status;
  String s_cnt;
  String cnt;
  String ins_date;
  String ins_name;
  String mod_date;
  String mod_name;
}


