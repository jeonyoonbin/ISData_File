import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CustomGetLoginOtherIdModel {
  CustomGetLoginOtherIdModel();

  String userId;

  factory CustomGetLoginOtherIdModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

CustomGetLoginOtherIdModel _$ModelFromJson(Map<String, dynamic> json) {
  return CustomGetLoginOtherIdModel()
    ..userId = json['userId'] as String;
}

Map<String, dynamic> _$ModelToJson(CustomGetLoginOtherIdModel instance) => <String, dynamic>{
  'userId': instance.userId,
};