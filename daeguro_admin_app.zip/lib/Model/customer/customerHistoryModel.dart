class CustomerHistoryModel {
  CustomerHistoryModel();

  bool selected = false;
  String no;
  String insertDate;
  String memo;
}