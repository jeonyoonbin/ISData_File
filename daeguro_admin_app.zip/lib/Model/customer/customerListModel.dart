
class CustomerListModel {
  CustomerListModel();

  bool selected = false;
  String REFERRAL_CODE;
  int CUST_CODE;
  String CUST_NAME;
  String TELNO;
  String CUST_ID;
  String CUST_PASSWORD;
  String INSERT_DATE;
  String DEL_DATE;
  int ORDER_COUNT;
  int ORDER_AMT;
  int MILEAGE_AMT;
  String CUST_ID_GBN;
  String MEMO;
}
