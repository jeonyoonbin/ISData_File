
class VoucherCardImageCategoryDetailModel {
  VoucherCardImageCategoryDetailModel();

  bool selected = false;
  String app_visible_yn = '';
  String category_cd = '';
  String category_name = '';
  String memo = '';
  String ins_date = '';
  String ins_ucode = '';
  String ins_name = '';
  String mod_date = '';
  String mod_ucode = '';
  String mod_name = '';
}