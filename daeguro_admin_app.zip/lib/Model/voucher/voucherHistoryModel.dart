
class VoucherHistoryModel {
  VoucherHistoryModel();

  bool selected = false;
  int NO;
  String HIST_DATE;
  String MEMO;
}