
class VoucherCodeDetailModel {
  VoucherCodeDetailModel();

  bool selected = false;
  String seqno;
  String group_cd;
  String use_yn;
  String voucher_type;
  String voucher_name;
  String promotion_yn;
  String budget;
  String disc_gbn;
  String disc_range;
  String voucher_amt;
  String voucher_notice;
  String memo;
  String thumb_url;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
}