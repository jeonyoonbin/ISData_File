
class VoucherExpListModel {
  VoucherExpListModel();

  bool selected = false;
  String prsc_gbn;
  String reg_date;
  String use_exp_date;
  String cust_code;
  String cust_name;
  String voucher_type;
  String voucher_name;
  String voucher_amt;
  String voucher_remain_amt;
  String voucher_no;
  String send_yn;
}