
class VoucherTypeListModel {
  VoucherTypeListModel();

  bool selected = false;
  String CODE;
  String CODE_NM;
  int ETC_AMT1;

}