
class VoucherBuyDetailListModel {
  VoucherBuyDetailListModel();

  bool selected = false;
  String sale_no;
  String tuid;
  String org_app_ymd;
  String pay_gbn;
  String payment_amt;
  String cancel_amt;
  String voucher_type;
  String voucher_name;
  String cnt;
  String voucher_amt;
  String voucher_no;
  String purchase_price;
  String disc_amt;
  String card_reciever;
  String cust_telno;
  String use_amt;
  String refund_amt;
  String status;
}