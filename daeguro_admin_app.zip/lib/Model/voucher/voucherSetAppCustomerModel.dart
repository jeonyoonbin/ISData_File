import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class VoucherSetAppCustomerModel {
  VoucherSetAppCustomerModel();

  bool selected = false;
  String voucher_type;
  String card_img;
  String card_msg;
  String ucode;
  List<String> reciever;
  List<String> telno;

  factory VoucherSetAppCustomerModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

VoucherSetAppCustomerModel _$ModelFromJson(Map<String, dynamic> json) {
  return VoucherSetAppCustomerModel()
    ..selected = json['selected'] as bool
    ..voucher_type = json['voucher_type'] as String
    ..card_img = json['card_img'] as String
    ..card_msg = json['card_msg'] as String
    ..ucode = json['ucode'] as String
    ..reciever = json['reciever'] as List<String>
    ..telno = json['telno'] as List<String>;
}

Map<String, dynamic> _$ModelToJson(VoucherSetAppCustomerModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'voucher_type': instance.voucher_type,
  'card_img': instance.card_img,
  'card_msg': instance.card_msg,
  'ucode': instance.ucode,
  'reciever': instance.reciever,
  'telno': instance.telno
};
