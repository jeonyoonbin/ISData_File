
class VoucherBuyListModel {
  VoucherBuyListModel();

  bool selected = false;
  String sale_date;
  String cust_code;
  String cust_name;
  String telno;
  String cnt;
  String amt;
  String disc_amt;
}