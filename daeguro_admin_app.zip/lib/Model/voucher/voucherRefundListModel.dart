
class VoucherRefundListModel {
  VoucherRefundListModel();

  bool selected = false;
  String refund_seq;
  String cust_code;
  String cust_name ;
  String voucher_no;
  String r_req_dt;
  String r_comp_dt;
  String r_amt;
  String acc_owner;
  String bankcode;
  String bankname;
  String r_account;
  String status;
  String r_req_gbn;
  String result_msg;
}