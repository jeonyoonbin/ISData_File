import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class VoucherSetCancelWaitModel {
  VoucherSetCancelWaitModel();

  String job_gbn;
  String sale_no;
  List<String> voucher_no;
  String ucode;
  String uname;

  factory VoucherSetCancelWaitModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

VoucherSetCancelWaitModel _$ModelFromJson(Map<String, dynamic> json) {
  return VoucherSetCancelWaitModel()
    ..job_gbn = json['job_gbn'] as String
    ..sale_no = json['sale_no'] as String
    ..voucher_no = json['voucher_no'] as List<String>
    ..ucode = json['ucode'] as String
    ..uname = json['uname'] as String;
}

Map<String, dynamic> _$ModelToJson(VoucherSetCancelWaitModel instance) => <String, dynamic>{
  'job_gbn': instance.job_gbn,
  'sale_no': instance.sale_no,
  'voucher_no': instance.voucher_no,
  'ucode': instance.ucode,
  'uname': instance.uname
};