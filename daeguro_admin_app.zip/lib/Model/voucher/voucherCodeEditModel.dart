import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class VoucherCodeEditModel {
  VoucherCodeEditModel();

  bool selected = false;
  String seqno;
  String group_cd;
  String use_yn;
  String voucher_type;
  String voucher_name;
  String promotion_yn;
  String budget;
  String disc_gbn;
  String disc_range;
  String voucher_amt;
  String voucher_notice;
  String memo;
  String ucode;
  String thumb_url;

  factory VoucherCodeEditModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

VoucherCodeEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return VoucherCodeEditModel()
    ..selected = json['selected'] as bool
    ..seqno = json['seqno'] as String
    ..group_cd = json['group_cd'] as String
    ..use_yn = json['use_yn'] as String
    ..voucher_type = json['voucher_type'] as String
    ..voucher_name = json['voucher_name'] as String
    ..promotion_yn = json['promotion_yn'] as String
    ..budget = json['budget'] as String
    ..disc_gbn = json['disc_gbn'] as String
    ..disc_range = json['disc_range'] as String
    ..voucher_amt = json['voucher_amt'] as String
    ..voucher_notice = json['voucher_notice'] as String
    ..memo = json['memo'] as String
    ..ucode = json['ucode'] as String
    ..thumb_url = json['thumb_url'] as String;
}

Map<String, dynamic> _$ModelToJson(VoucherCodeEditModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'seqno': instance.seqno,
  'group_cd': instance.group_cd,
  'use_yn': instance.use_yn,
  'voucher_type': instance.voucher_type,
  'voucher_name': instance.voucher_name,
  'promotion_yn': instance.promotion_yn,
  'budget': instance.budget,
  'disc_gbn': instance.disc_gbn,
  'disc_range': instance.disc_range,
  'voucher_amt': instance.voucher_amt,
  'voucher_notice': instance.voucher_notice,
  'memo': instance.memo,
  'ucode': instance.ucode,
  'thumb_url': instance.thumb_url,
};
