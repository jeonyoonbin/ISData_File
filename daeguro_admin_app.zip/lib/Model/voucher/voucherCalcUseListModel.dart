import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class voucherCalcUseListModel {
  voucherCalcUseListModel();

  bool selected = false;
  String charge_date;
  String order_no;
  String charge_amt;
}