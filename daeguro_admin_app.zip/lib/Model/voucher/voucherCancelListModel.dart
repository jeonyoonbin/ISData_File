
class VoucherCancelListModel {
  VoucherCancelListModel();

  bool selected = false;
  String cust_code;
  String cust_name;
  String telno;
  String sale_no;
  String voucher_type;
  String voucher_name;
  String voucher_amt;
  String voucher_no;
  String after_exp_dt;
  String partial_cancel_dt;
  String status;
  String fail_reason;
}