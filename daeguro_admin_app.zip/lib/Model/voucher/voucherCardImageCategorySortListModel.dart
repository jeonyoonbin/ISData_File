import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class VoucherCardImageCategorySortListModel {
  VoucherCardImageCategorySortListModel();

  bool selected = false;
  String sort_seq;
  String category_cd;
  String category_name;

  factory VoucherCardImageCategorySortListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

VoucherCardImageCategorySortListModel _$ModelFromJson(Map<String, dynamic> json) {
  return VoucherCardImageCategorySortListModel()
    ..selected = json['selected'] as bool
    ..sort_seq = json['sort_seq'] as String
    ..category_cd = json['category_cd'] as String
    ..category_name = json['category_name'] as String;
}

Map<String, dynamic> _$ModelToJson(VoucherCardImageCategorySortListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'sort_seq': instance.sort_seq,
  'category_cd': instance.category_cd,
  'category_name': instance.category_name,
};
