
class VoucherCardImageListModel {
  VoucherCardImageListModel();

  bool selected = false;
  String img_code;
  String type_gbn;
  String app_visible_yn;
  String use_gbn;
  String category_cd;
  String img_url;
  String memo;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
}