
class VoucherCalcDetailListModel {
  VoucherCalcDetailListModel();

  bool selected = false;
  String group_cd;
  String group_name;
  String voucher_type;
  String voucher_name;
  String voucher_no;
  String cust_code;
  String cust_name;
  String ins_date;
  String reg_date;
  String use_exp_date;
  String remain_amt;
  String reg_amt;
  String payment_amt;
  String disc_amt;
  String use_amt;
  String cancel_amt;
  String refund_amt;
  String refund_fee;
  String date_begin;
  String date_end;
  String reuse_amt;
  String re_cancel_amt;
}