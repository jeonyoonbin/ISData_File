class StatVoucherDailyDataModel {
  StatVoucherDailyDataModel();

  String DAY_CHECK;
  String DAILY;
  String VOUCHER_TYPE;
  String VOUCHER_NAME;
  int VOUCHER_AMT;
  int NO_CNT;
  int NO_AMT;
  int US_CNT;
  int US_AMT;
  int CC_CNT;
  int CC_AMT;
  int UD_CNT;
  int UD_AMT;
  int RR_CNT;
  int RR_AMT;
  int RC_CNT;
  int RC_AMT;
  int ER_CNT;
  int ER_AMT;
  int EP_CNT;
  int EP_AMT;
  int DU_CNT;
  int DU_AMT;
}