
class VoucherGroupCodeDetailModel {
  VoucherGroupCodeDetailModel();

  bool selected = false;
  String seq;
  String use_yn;
  String test_yn;
  String group_cd;
  String group_name;
  String prsc_gbn;
  String memo;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
}