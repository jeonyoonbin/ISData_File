
class VoucherCodeModel {
  VoucherCodeModel();

  bool selected = false;
  String seqno;
  String group_cd;
  String group_name;
  String voucher_type;
  String voucher_name;
  String memo;
  String use_yn;
  String voucher_amt;
  String voucher_notice;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
}