
class VoucherCalcListModel {
  VoucherCalcListModel();

  bool selected = false;
  String prsc_gbn;
  String group_cd;
  String group_name;
  String dt;
  String remain_amt;
  String reg_amt;
  String reg_cnt;
  String payment_amt;
  String disc_amt;
  String use_amt;
  String cancel_amt;
  String comp_cnt;
  String reuse_amt;
  String re_cancel_amt;
  String r_comp_cnt;
  String refund_amt;
  String refund_fee;
  String refund_cnt;
}