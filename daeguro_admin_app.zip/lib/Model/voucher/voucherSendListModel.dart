
class VoucherSendListModel {
  VoucherSendListModel();

  bool selected = false;
  String cust_code;
  String cust_name;
  String voucher_type;
  String voucher_name;
  String voucher_no;
  String voucher_amt;
  String send_gbn;
  String result_msg;
  String send_date;
  String status;
}