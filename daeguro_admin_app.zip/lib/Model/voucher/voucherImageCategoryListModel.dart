
class VoucherImageCategoryListModel {
  VoucherImageCategoryListModel();

  bool selected = false;
  String category_cd;
  String category_name;
  String memo;
  String use_gbn;
  String app_visible_yn;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
}