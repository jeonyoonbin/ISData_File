
class VoucherListDetailModel {
  VoucherListDetailModel();

  bool selected = false;
  String voucher_name = '';
  String voucher_no = '';
  String voucher_amt = '';
  String voucher_remain_amt = '';
  String refund_amt = '';
  String use_amt = '';
  String reg_date = '';
  String reg_exp_date = '';
  String use_exp_date = '';
  String send_date = '';
  String cust_code = '';
  String cust_name = '';
  String cust_telno = '';
  String bankname  = '';
  String r_account = '';
}