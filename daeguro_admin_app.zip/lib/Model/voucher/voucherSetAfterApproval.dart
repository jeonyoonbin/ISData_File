import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class VoucherSetAfterApproval {
  VoucherSetAfterApproval();

  String job_gbn;
  String sale_no;
  List<String> voucher_no;
  String tuid;
  String cancel_amt;
  String cancel_code;
  String card_cancel_time;
  String cancel_reason;
  String ucode;
  String uname;

  factory VoucherSetAfterApproval.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

VoucherSetAfterApproval _$ModelFromJson(Map<String, dynamic> json) {
  return VoucherSetAfterApproval()
    ..job_gbn = json['job_gbn'] as String
    ..sale_no = json['sale_no'] as String
    ..voucher_no = json['voucher_no'] as List<String>
    ..tuid = json['tuid'] as String
    ..cancel_amt = json['cancel_amt'] as String
    ..cancel_code = json['cancel_code'] as String
    ..card_cancel_time = json['card_cancel_time'] as String
    ..cancel_reason = json['cancel_reason'] as String
    ..ucode = json['ucode'] as String
    ..uname = json['uname'] as String;
}

Map<String, dynamic> _$ModelToJson(VoucherSetAfterApproval instance) => <String, dynamic>{
  'job_gbn': instance.job_gbn,
  'sale_no': instance.sale_no,
  'voucher_no': instance.voucher_no,
  'tuid': instance.tuid,
  'cancel_amt': instance.cancel_amt,
  'cancel_code': instance.cancel_code,
  'card_cancel_time': instance.card_cancel_time,
  'cancel_reason': instance.cancel_reason,
  'ucode': instance.ucode,
  'uname': instance.uname
};