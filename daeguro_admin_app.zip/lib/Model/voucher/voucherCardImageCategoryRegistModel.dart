
class VoucherCardImageCategoryRegistModel {
  VoucherCardImageCategoryRegistModel();

  String category_cd = '';
  String category_name = '';
  String app_visible_yn = '';
  String memo = '';
  String ucode = '';

  factory VoucherCardImageCategoryRegistModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

VoucherCardImageCategoryRegistModel _$ModelFromJson(Map<String, dynamic> json) {
  return VoucherCardImageCategoryRegistModel()
    ..category_cd = json['category_cd'] as String
    ..category_name = json['category_name'] as String
    ..app_visible_yn = json['app_visible_yn'] as String
    ..memo = json['memo'] as String
    ..ucode = json['ucode'] as String;
}

Map<String, dynamic> _$ModelToJson(VoucherCardImageCategoryRegistModel instance) => <String, dynamic>{
  'category_cd': instance.category_cd,
  'category_name': instance.category_name,
  'app_visible_yn': instance.app_visible_yn,
  'memo': instance.memo,
  'ucode': instance.ucode,
};
