import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class VoucherRefundReqModel {
  VoucherRefundReqModel();

  bool selected = false;
  String voucher_no;
  String refund_amt;
  String account;
  String bankcode;
  String acc_owner;
  String ucode;
  String uname;

  factory VoucherRefundReqModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

VoucherRefundReqModel _$ModelFromJson(Map<String, dynamic> json) {
  return VoucherRefundReqModel()
    ..selected = json['selected'] as bool
    ..voucher_no = json['voucher_no'] as String
    ..refund_amt = json['refund_amt'] as String
    ..account = json['account'] as String
    ..bankcode = json['bankcode'] as String
    ..acc_owner = json['acc_owner'] as String
    ..ucode = json['ucode'] as String
    ..uname = json['uname'] as String;
}

Map<String, dynamic> _$ModelToJson(VoucherRefundReqModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'voucher_no': instance.voucher_no,
  'refund_amt': instance.refund_amt,
  'account': instance.account,
  'bankcode': instance.bankcode,
  'acc_owner': instance.acc_owner,
  'ucode': instance.ucode,
  'uname': instance.uname
};
