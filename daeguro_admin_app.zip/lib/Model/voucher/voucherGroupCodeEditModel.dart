import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class VoucherUpdateGroupCodeModel {
  VoucherUpdateGroupCodeModel();

  bool selected = false;
  String seq;
  String prsc_gbn;
  String use_yn;
  String test_yn;
  //String group_cd;
  String group_name;
  String memo;
  String ucode;

  factory VoucherUpdateGroupCodeModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

VoucherUpdateGroupCodeModel _$ModelFromJson(Map<String, dynamic> json) {
  return VoucherUpdateGroupCodeModel()
    ..selected = json['selected'] as bool
    ..seq = json['seq'] as String
    ..prsc_gbn = json['prsc_gbn'] as String
    ..use_yn = json['use_yn'] as String
    ..test_yn = json['test_yn'] as String
    //..group_cd = json['group_cd'] as String
    ..group_name = json['group_name'] as String
    ..memo = json['memo'] as String
    ..ucode = json['ucode'] as String;
}

Map<String, dynamic> _$ModelToJson(VoucherUpdateGroupCodeModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'seq': instance.seq,
  'prsc_gbn': instance.prsc_gbn,
  'use_yn': instance.use_yn,
  'test_yn': instance.test_yn,
  //'group_cd': instance.group_cd,
  'group_name': instance.group_name,
  'memo': instance.memo,
  'ucode': instance.ucode,
};
