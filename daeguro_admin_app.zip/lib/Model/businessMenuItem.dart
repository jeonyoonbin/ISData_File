class BusinessMenuItem {
  BusinessMenuItem({this.isOpened, this.isChildItem, this.title, this.ptitle});

  bool isOpened = false;
  bool isChildItem = false;
  String title;
  String ptitle;
}