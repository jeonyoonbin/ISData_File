import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class PayMentCancelModel {
  PayMentCancelModel();

  int server_type;
  String order_no;
  String cancel_type;
  String pay_type;

  factory PayMentCancelModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

PayMentCancelModel _$ModelFromJson(Map<String, dynamic> json) {
  return PayMentCancelModel()
    ..server_type = json['server_type'] as int
    ..order_no = json['order_no'] as String
    ..cancel_type = json['cancel_type'] as String
    ..pay_type = json['pay_type'] as String;
}

Map<String, dynamic> _$ModelToJson(PayMentCancelModel instance) => <String, dynamic>{
  'server_type': instance.server_type,
  'order_no': instance.order_no,
  'cancel_type': instance.cancel_type,
  'pay_type': instance.pay_type,
};