import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveThemeSubDetailModel {
  ReserveThemeSubDetailModel();

  bool selected = false;
  String temaName;
  String sido;
  String gungu;
  String temaMemo;
  String useGbn;
  String lon;
  String lat;
  String addr;

  factory ReserveThemeSubDetailModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveThemeSubDetailModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveThemeSubDetailModel()
  //..selected = json['selected'] as bool
    ..temaName = json['temaName'] as String
    ..sido = json['sido'] as String
    ..gungu = json['gungu'] as String
    ..temaMemo = json['temaMemo'] as String
    ..useGbn = json['useGbn'] as String
    ..lon = json['lon'] as String
    ..lat = json['lat'] as String
    ..addr = json['addr'] as String;
}

Map<String, dynamic> _$ModelToJson(ReserveThemeSubDetailModel instance) => <String, dynamic>{
  //'selected': instance.selected,
  'temaName': instance.temaName,
  'sido': instance.sido,
  'gungu': instance.gungu,
  'temaMemo': instance.temaMemo,
  'useGbn': instance.useGbn,
  'lon': instance.lon,
  'lat': instance.lat,
  'addr': instance.addr
};
