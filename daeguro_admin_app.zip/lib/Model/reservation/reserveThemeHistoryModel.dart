import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveThemeHistoryModel {
  ReserveThemeHistoryModel();

  bool selected = false;
  String memo;
  String userId;
  String histDate;

  factory ReserveThemeHistoryModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveThemeHistoryModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveThemeHistoryModel()
    ..selected = json['selected'] as bool
    ..memo = json['memo'] as String
    ..userId = json['userId'] as String
    ..histDate = json['histDate'] as String;

}

Map<String, dynamic> _$ModelToJson(ReserveThemeHistoryModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'memo': instance.memo,
  'userId': instance.userId,
  'histDate': instance.histDate
};