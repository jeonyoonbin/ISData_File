import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveFAQListModel {
  ReserveFAQListModel();

  int seq;
  String gbn;
  String question;
  String answer;
  int sortSeq;
  String insertId;
  String insertDate;
  String modId;
  String modDate;

  factory ReserveFAQListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveFAQListModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveFAQListModel()
  //..selected = json['selected'] as bool
    ..seq = json['seq'] as int
    ..gbn = json['gbn'] as String
    ..question = json['question'] as String
    ..answer = json['answer'] as String
    ..sortSeq = json['sortSeq'] as int
    ..insertId = json['insertId'] as String
    ..insertDate = json['insertDate'] as String
    ..modId = json['modId'] as String
    ..modDate = json['modDate'] as String;
}

Map<String, dynamic> _$ModelToJson(ReserveFAQListModel instance) => <String, dynamic>{
  //'selected': instance.selected,
  'seq': instance.seq,
  'gbn': instance.gbn,
  'question': instance.question,
  'answer': instance.answer,
  'sortSeq': instance.sortSeq,
  'insertId': instance.insertId,
  'insertDate': instance.insertDate,
  'modId': instance.modId,
  'modDate': instance.modDate
};
