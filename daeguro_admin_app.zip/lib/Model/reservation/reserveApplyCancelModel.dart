import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveApplyCancelModel {
  ReserveApplyCancelModel();

  String shopCd;
  String uCode;
  String userName;
  String gbn;

  factory ReserveApplyCancelModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveApplyCancelModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveApplyCancelModel()
    ..shopCd = json['shopCd'] as String
    ..uCode = json['uCode'] as String
    ..userName = json['userName'] as String
    ..gbn = json['gbn'] as String;
}

Map<String, dynamic> _$ModelToJson(ReserveApplyCancelModel instance) => <String, dynamic>{
  'shopCd': instance.shopCd,
  'uCode': instance.uCode,
  'userName': instance.userName,
  'gbn': instance.gbn
};
