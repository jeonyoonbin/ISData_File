import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveFAQEditModel {
  ReserveFAQEditModel();

  String gbn;
  String question;
  String answer;
  String userId;
  int seq;

  factory ReserveFAQEditModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveFAQEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveFAQEditModel()
  //..selected = json['selected'] as bool
    ..gbn = json['gbn'] as String
    ..question = json['question'] as String
    ..answer = json['answer'] as String
    ..userId = json['userId'] as String
    ..seq = json['seq'] as int;
}

Map<String, dynamic> _$ModelToJson(ReserveFAQEditModel   instance) => <String, dynamic>{
  //'selected': instance.selected,
  'gbn': instance.gbn,
  'question': instance.question,
  'answer': instance.answer,
  'userId': instance.userId,
  'seq': instance.seq
};
