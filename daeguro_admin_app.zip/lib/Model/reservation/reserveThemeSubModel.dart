import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveThemeSubModel {
  ReserveThemeSubModel();

  bool selected;
  String temaCode;
  int subTemaCode;
  String temaName;
  String sido;
  String gungu;
  String temaMemo;
  String useGbn;
  int sortSeq;
  String url;
  int lon;
  int lat;
  String addr;

  factory ReserveThemeSubModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveThemeSubModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveThemeSubModel()
    ..selected = json['selected'] as bool
    ..temaCode = json['temaCode'] as String
    ..subTemaCode = json['subTemaCode'] as int
    ..temaName = json['temaName'] as String
    ..sido = json['sido'] as String
    ..gungu = json['gungu'] as String
    ..temaMemo = json['temaMemo'] as String
    ..useGbn = json['useGbn'] as String
    ..sortSeq = json['sortSeq'] as int
    ..url = json['url'] as String
    ..lon = json['lon'] as int
    ..lat = json['lat'] as int
    ..addr = json['addr'] as String;
}

Map<String, dynamic> _$ModelToJson(ReserveThemeSubModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'temaCode': instance.temaCode,
  'subTemaCode': instance.subTemaCode,
  'temaName': instance.temaName,
  'sido': instance.sido,
  'gungu': instance.gungu,
  'temaMemo': instance.temaMemo,
  'useGbn': instance.useGbn,
  'sortSeq': instance.sortSeq,
  'url': instance.url,
  'lon': instance.lon,
  'lat': instance.lat,
  'addr': instance.addr
};
