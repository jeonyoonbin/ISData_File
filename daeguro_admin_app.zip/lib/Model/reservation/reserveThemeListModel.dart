import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReserveThemeListModel {
  ReserveThemeListModel();

  bool selected = false;
  bool isOpened = false;
  bool isChild = false;
  String code;
  int subcode;
  String nameMain;
  String useGbn;

  factory ReserveThemeListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ReserveThemeListModel _$ModelFromJson(Map<String, dynamic> json) {
  return ReserveThemeListModel()
    //..selected = json['selected'] as bool
    ..code = json['code'] as String
    ..nameMain = json['nameMain'] as String
    ..useGbn = json['useGbn'] as String;
}

Map<String, dynamic> _$ModelToJson(ReserveThemeListModel instance) => <String, dynamic>{
  //'selected': instance.selected,
  'code': instance.code,
  'nameMain': instance.nameMain,
  'useGbn': instance.useGbn,
};
