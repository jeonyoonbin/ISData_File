import 'package:json_annotation/json_annotation.dart';

class ShopEventCouponDetailModel {
  ShopEventCouponDetailModel();

  bool selected = false;
  String coupon_type;
  String coupon_name;
  String display_st_date;
  String display_end_date;
  String exp_set_date;
  String ins_date;
  String ins_name;
  String mod_date;
  String mod_name;
}


