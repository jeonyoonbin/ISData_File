
class ShopReservationHistoryModel {
  ShopReservationHistoryModel();

  bool selected = false;
  int history_seq;
  String historyTime;
  String status;
  String gbn;
  String modUser;
  String modDesc;
}