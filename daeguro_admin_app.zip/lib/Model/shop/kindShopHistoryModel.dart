
class KindShopHistoryModel {
  KindShopHistoryModel();

  bool selected = false;
  String hist_date;
  String memo;
}