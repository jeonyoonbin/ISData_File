
class ShopReserListModel {
  ShopReserListModel();

  bool selected = false;
  String shopCd;
  int seqNo;
  String reserDate;
  String reserTime;
  int custCode;
  String custId;
  String custName;
  String custTelno;
  String mobileNo;
  String mobileNo1;
  String injengGbn;
  int personCnt;
  String status;
  String allocDate;
  String compDate;
  String cancelDate;
  String payGbn;
  int orderNo;
  String location;
  String memo;
  String isrtDate;
  String modDate;
  String modId;
  String modGbn;
  String posSendGbn;
  String posSendDate;
  String shopName;
  String cancelSayou;
  String cancelSayouMemo;
  String posLogin;
  String loginTime;
}

