import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopInfoSbTimeModel {
  ShopInfoSbTimeModel({this.day_gbn});

  // String shopCode;
  // String sbGbn;
  String shop_cd;
  String sb_gbn;
  String day_gbn;
  String open_time = '';
  String close_time = '';
  String next_day_yn = '';
  String use_gbn = '';

  factory ShopInfoSbTimeModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopInfoSbTimeModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopInfoSbTimeModel()
  // ..shopCode = json['shopCode'] as String
  // ..sbGbn = json['sbGbn'] as String
    ..shop_cd = json['shop_cd'] as String
    ..sb_gbn = json['sb_gbn'] as String
    ..day_gbn = json['day_gbn'] as String
    ..open_time = json['open_time'] as String
    ..close_time = json['close_time'] as String
    ..next_day_yn = json['next_day_yn'] as String
    ..use_gbn = json['use_gbn'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopInfoSbTimeModel instance) => <String, dynamic>{
  // 'shopCode': instance.shopCode,
  // 'sbGbn': instance.sbGbn,
  'shop_cd': instance.shop_cd,
  'sb_gbn': instance.sb_gbn,
  'day_gbn': instance.day_gbn,
  'open_time': instance.open_time,
  'close_time': instance.close_time,
  'next_day_yn': instance.next_day_yn,
  'use_gbn': instance.use_gbn,
};