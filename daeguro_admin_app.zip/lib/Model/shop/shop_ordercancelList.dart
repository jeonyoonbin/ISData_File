
class ShopOrderCancelListModel {
  ShopOrderCancelListModel();

  bool selected = false;
  String ccCode;
  String shopCd;
  String shopName;
  String telNo;
  String posInstall;
  String posLogin;
  String cancelCnt;
  String absentYn;
  String totalCnt;
  String loginTime;
  String lastCancelTime;
  String shopStatus;
}
