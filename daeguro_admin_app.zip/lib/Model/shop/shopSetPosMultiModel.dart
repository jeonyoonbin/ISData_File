import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopSetPosMultiModel {
  ShopSetPosMultiModel();

  String login_id;
  String login_pw;
  String use_gbn;
  String bigo;
  List<String> b2b_mapping_list;

  factory ShopSetPosMultiModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopSetPosMultiModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopSetPosMultiModel()
    ..login_id = json['login_id'] as String
    ..login_pw = json['login_pw'] as String
    ..use_gbn = json['use_gbn'] as String
    ..bigo = json['bigo'] as String
    ..b2b_mapping_list = json['b2b_mapping_list'] as List<String>;

}

Map<String, dynamic> _$ModelToJson(ShopSetPosMultiModel instance) => <String, dynamic>{
  '"login_id"': '"' + instance.login_id + '"',
  '"login_pw"': '"' + instance.login_pw + '"',
  '"use_gbn"': '"' + instance.use_gbn + '"',
  '"bigo"': '"' + instance.bigo + '"',
  '"b2b_mapping_list"': instance.b2b_mapping_list
};