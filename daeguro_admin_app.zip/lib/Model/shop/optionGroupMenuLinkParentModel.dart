import 'package:daeguro_admin_app/Model/shop/optionMenuLinkChildModel.dart';
import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionMenuLinkParentModel {
  OptionMenuLinkParentModel({
    this.menuGroupName,
    this.menu,
  });

  bool selected = false;
  String menuGroupName;
  List<OptionMenuLinkChildModel> menu;
}

