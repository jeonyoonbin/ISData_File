
class ShopImageHistoryModel {
  ShopImageHistoryModel();

  bool selected = false;
  String no;
  String histDate;
  String memo;

}