
class ShopImageHistoryModel {
  ShopImageHistoryModel();

  bool selected = false;
  int no;
  String histDate;
  String memo;

}