class ShopFlowerProdOptionGroupSelModel {
  ShopFlowerProdOptionGroupSelModel();

  bool boolselected = false;
  String selected;
  String optGrpCd;
  String name;
  String minCount;
  String multiCount;
  String useGbn;
  String optNames;
  bool isFlag = false;

  factory ShopFlowerProdOptionGroupSelModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopFlowerProdOptionGroupSelModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopFlowerProdOptionGroupSelModel()
    ..selected = json['selected'] as String
    ..optGrpCd = json['optGrpCd'] as String
    ..name = json['name'] as String
    ..minCount = json['minCount'] as String
    ..multiCount = json['multiCount'] as String
    ..useGbn = json['useGbn'] as String
    ..optNames = json['optNames'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopFlowerProdOptionGroupSelModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'optGrpCd': instance.optGrpCd,
  'name': instance.name,
  'minCount': instance.minCount,
  'multiCount': instance.multiCount,
  'useGbn': instance.useGbn,
  'optNames': instance.optNames,
};