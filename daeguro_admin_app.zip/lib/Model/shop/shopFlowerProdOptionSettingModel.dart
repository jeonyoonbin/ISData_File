import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopFlowerProdOptionSettingModel {
  ShopFlowerProdOptionSettingModel();

  String selected;
  String prodOptGrpCd;
  String optGrpCd;
  String optGrpName;
  String prodCd;
  String sortNo;
  String optNames;
  bool isFlag = false;

  factory ShopFlowerProdOptionSettingModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopFlowerProdOptionSettingModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopFlowerProdOptionSettingModel()
    ..selected = json['selected'] as String
    ..prodOptGrpCd = json['prodOptGrpCd'] as String
    ..optGrpCd = json['optGrpCd'] as String
    ..optGrpName = json['optGrpName'] as String
    ..prodCd = json['prodCd'] as String
    ..sortNo = json['sortNo'] as String
    ..optNames = json['optNames'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopFlowerProdOptionSettingModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'prodOptGrpCd': instance.prodOptGrpCd,
  'optGrpCd': instance.optGrpCd,
  'optGrpName': instance.optGrpName,
  'prodCd': instance.prodCd,
  'sortNo': instance.sortNo,
  'optNames': instance.optNames,
};