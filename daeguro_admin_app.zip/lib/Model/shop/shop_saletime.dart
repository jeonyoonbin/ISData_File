﻿import 'package:json_annotation/json_annotation.dart';

class ShopSaleTimeModel {
  ShopSaleTimeModel();

  bool selected = false;
  String saleFromTime;
  String saleToTime;
  String saleNextDay;
  String appOrderYn;
  String useGbn;
  String happyPayUseGbn;
  String confirmYn;
  String confirmDate;
  String closedLogin;
  String supportFund;
  String reserveYn;
  String shopType;
  String reserveApprovalDt;
  String autoCancelGbn;
  String pushGbn;
  String kakaoBiztalkGbn;
  String mall_use_gbn;
  String mall_tos_agre;
  String mall_tos_agre_dt;
}
