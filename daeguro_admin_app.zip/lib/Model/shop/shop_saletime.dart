﻿import 'package:json_annotation/json_annotation.dart';

class ShopSaleTimeModel {
  ShopSaleTimeModel();

  bool selected = false;
  String saleFromTime;
  String saleToTime;
  String saleNextDay;
  String appOrderYn;
  String useGbn;
  String happyPayUseGbn;
  String confirmYn;
  String confirmDate;
  String closedLogin;
  String supportFund;
  String reserveYn;
  String shopType;
  String reserveApprovalDt;
  String autoCancelGbn;
  String autoCompType;
  String autoCompTerm;
  String autoCancelType;
  String autoCancelTerm;
  String autoCompTypeC;
  String autoCompTermC;
  String autoCancelTypeC;
  String autoCancelTermC;
  String pushGbn;
  String kakaoBiztalkGbn;
  String mall_use_gbn;
  String mall_tos_agre;
  String mall_tos_agre_dt;
  String kind_shop_status;
  String kind_shop_set_date;
  String kind_shop_pause_dt;
  String kind_shop_cancel_dt;
  String kind_shop_answer;
  String kind_shop_memo;
  String youtube_url;
  String child_meal_yn;
  String child_meal_cd;
  String min_amt_pass;
  String reg_no;
  String exchange_notice;
  String return_notice;
  String reject_notice;
}