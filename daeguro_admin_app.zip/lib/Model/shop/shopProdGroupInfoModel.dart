import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopProdGroupInfoModel {
  ShopProdGroupInfoModel();

  bool selected = false;
  String prod_group_cd;
  String prod_group_name;
  String prod_names;
  String use_yn;
  String main_count;

  factory ShopProdGroupInfoModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopProdGroupInfoModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopProdGroupInfoModel()
    ..selected = json['selected'] as bool
    ..prod_group_cd = json['prod_group_cd'] as String
    ..prod_group_name = json['prod_group_name'] as String
    ..prod_names = json['prod_names'] as String
    ..use_yn = json['use_yn'] as String
    ..main_count = json['main_count'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopProdGroupInfoModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'prod_group_cd': instance.prod_group_cd,
  'prod_group_name': instance.prod_group_name,
  'prod_names': instance.prod_names,
  'use_yn': instance.use_yn,
  'main_count': instance.main_count,
};
