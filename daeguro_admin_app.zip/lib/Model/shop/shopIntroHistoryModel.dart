
class ShopIntroHistoryModel {
  ShopIntroHistoryModel();

  bool selected = false;
  int NO;
  int SEQNO;
  String HIST_DATE;
  String MEMO;
}