import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class SubThemeListModel {
  SubThemeListModel();

  bool selected;
  String class_gbn;
  String thema_code;
  String name;
  String use_gbn;
  String sort_seq;

  factory SubThemeListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

SubThemeListModel _$ModelFromJson(Map<String, dynamic> json) {
  return SubThemeListModel()
    ..selected = json['selected'] as bool
    ..class_gbn = json['class_gbn'] as String
    ..thema_code = json['thema_code'] as String
    ..name = json['name'] as String
    ..use_gbn = json['use_gbn'] as String
    ..sort_seq = json['sort_seq'] as String;

}

Map<String, dynamic> _$ModelToJson(SubThemeListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'class_gbn': instance.class_gbn,
  'thema_code': instance.thema_code,
  'name': instance.name,
  'use_gbn': instance.use_gbn,
  'sort_seq': instance.sort_seq
};