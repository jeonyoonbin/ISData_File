import 'package:json_annotation/json_annotation.dart';

class ShopEventCouponItemModel {
  ShopEventCouponItemModel();

  String apply_min_amt;
  String coupon_amt;
  String pub;
  String use;
}


