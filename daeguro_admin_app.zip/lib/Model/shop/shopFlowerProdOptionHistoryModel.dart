import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopFlowerProdOptionHistoryModel {
  ShopFlowerProdOptionHistoryModel();

  bool selected = false;
  String seq;
  String optGrpCd;
  String optionCd;
  String histGbn;
  String histDate;
  String memo;


  factory ShopFlowerProdOptionHistoryModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopFlowerProdOptionHistoryModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopFlowerProdOptionHistoryModel()
    ..selected = json['selected'] as bool
    ..seq = json['seq'] as String
    ..optGrpCd = json['optGrpCd'] as String
    ..optionCd = json['optionCd'] as String
    ..histGbn = json['histGbn'] as String
    ..histDate = json['histDate'] as String
    ..memo = json['memo'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopFlowerProdOptionHistoryModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'seq': instance.seq,
  'optGrpCd': instance.optGrpCd,
  'optionCd': instance.optionCd,
  'histGbn': instance.histGbn,
  'histDate': instance.histDate,
  'memo': instance.memo,
};