
class ShopEventMenuModel {
  ShopEventMenuModel();

  bool selected = false;
  int RNUM;
  String MENU_NAME;
  int MENU_COST;
  String EVENT_AMT_GBN;
  int EVENT_AMT;
  int DISC_COST;
  String FROM_TIME;
  String TO_TIME;
  String STATE;
  int SALE_LIMIT_QNT;
  int ORDER_QNT;
  int LEFT_QNT;
}