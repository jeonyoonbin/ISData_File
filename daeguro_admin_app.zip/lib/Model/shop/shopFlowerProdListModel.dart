class ShopFlowerProdListModel {
  ShopFlowerProdListModel();

  bool selected = false;
  String cat_code;
  String cat_name;
  String prod_code;
  String prod_group_cd;
  String name;
  String cost;
  String disc_yn;
  String disc_ratio;
  String amount;
  String file_name;
  String html;
  String multi_cnt;
  String main_yn;
  String use_gbn;
  String no_flag;
}

