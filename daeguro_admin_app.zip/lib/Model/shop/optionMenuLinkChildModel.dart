class OptionMenuLinkChildModel {
  OptionMenuLinkChildModel();

  String initSelectYn;
  String selectYn;
  String menuGroupCd;
  String menuGroupName;
  String menuCd;
  String menuName;
  String menuDesc;
  String menuCost;
}
