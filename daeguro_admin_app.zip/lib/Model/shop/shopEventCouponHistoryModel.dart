
class ShopEventCouponHistoryModel {
  ShopEventCouponHistoryModel();

  bool selected = false;
  String no;
  String insertDate;
  String memo;
}