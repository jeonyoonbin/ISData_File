
class ShopMultiListModel {
  ShopMultiListModel();

  bool selected = false;
  String shop_cd;
  String shop_name;
  String reg_no;
  String owner;
  String open_dt;
  String reser_req_date;
  String multi_shop_yn;
  String representative_yn;
}