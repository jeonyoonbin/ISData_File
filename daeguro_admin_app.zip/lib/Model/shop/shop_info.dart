import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopInfoModel {
  ShopInfoModel();

  bool selected = false;
  String shopCd;
  String shopName;
  String telNo;
  String itemCd1 = null;
  String itemCd2 = null;
  String itemCd3 = null;
  String appMinAmt;
  String shopType;
  String modUCode;
  String modName;
  String shopId;
  String current;  // 현재 비밀번호
  String shopPass;
  String shopImg;
  String bussImg;
  String idcardImg;
  String bankImg;
  String reserveYn;
  String useGbn;
  String deliTypeGbn;
  String serviceGbn;
  String multi_shop_yn;
  String multishop_cd;
  String representative_yn;
  String rep_shop_cd;
  String rep_shop_name;
  String multishop_login_id;
  String trad_yn;
  String bundle_yn;
  String trad_desc;
  String bundle_login_id;
  String m_shop_cd;
  String trad_name;

  factory ShopInfoModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopInfoModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopInfoModel()
    ..selected = json['selected'] as bool
    ..shopCd = json['shopCd'] as String
    ..shopName = json['shopName'] as String
    ..telNo = json['telNo'] as String
    ..itemCd1 = json['itemCd1'] as String
    ..itemCd2 = json['itemCd2'] as String
    ..itemCd3 = json['itemCd3'] as String
    ..appMinAmt = json['appMinAmt'] as String
    ..shopType = json['shopType'] as String
    ..modUCode = json['modUCode'] as String
    ..modName = json['modName'] as String
    ..shopId = json['shopId'] as String
    ..current = json['current'] as String
    ..shopPass = json['shopPass'] as String
    ..shopImg = json['shopImg'] as String
    ..bussImg = json['bussImg'] as String
    ..idcardImg = json['idcardImg'] as String
    ..bankImg = json['bankImg'] as String
    ..reserveYn = json['reserveYn'] as String
    ..useGbn = json['useGbn'] as String
    ..deliTypeGbn = json['deliTypeGbn'] as String
    ..serviceGbn = json['serviceGbn'] as String
    ..multi_shop_yn = json['multi_shop_yn'] as String
    ..multishop_cd = json['multishop_cd'] as String
    ..representative_yn = json['representative_yn'] as String
    ..rep_shop_cd = json['rep_shop_cd'] as String
    ..rep_shop_name = json['rep_shop_name'] as String
    ..multishop_login_id = json['multishop_login_id'] as String
    ..trad_yn = json['trad_yn'] as String
    ..bundle_yn = json['bundle_yn'] as String
    ..trad_desc = json['trad_desc'] as String
    ..bundle_login_id = json['bundle_login_id'] as String
    ..m_shop_cd = json['m_shop_cd'] as String
    ..trad_name = json['trad_name'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopInfoModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'shopCd': instance.shopCd,
  'shopName': instance.shopName,
  'telNo': instance.telNo,
  'itemCd1': instance.itemCd1,
  'itemCd2': instance.itemCd2,
  'itemCd3': instance.itemCd3,
  'appMinAmt': instance.appMinAmt,
  'shopType': instance.shopType,
  'modUCode': instance.modUCode,
  'modName': instance.modName,
  'shopId': instance.shopId,
  'current': instance.current,
  'shopPass': instance.shopPass,
  'shopImg': instance.shopImg,
  'bussImg': instance.bussImg,
  'idcardImg': instance.idcardImg,
  'bankImg': instance.bankImg,
  'reserveYn': instance.reserveYn,
  'useGbn': instance.useGbn,
  'deliTypeGbn': instance.deliTypeGbn,
  'serviceGbn': instance.serviceGbn,
  'multi_shop_yn': instance.multi_shop_yn,
  'multishop_cd': instance.multishop_cd,
  'representative_yn': instance.representative_yn,
  'rep_shop_cd': instance.rep_shop_cd,
  'rep_shop_name': instance.rep_shop_name,
  'multishop_login_id': instance.multishop_login_id,
  'trad_yn': instance.trad_yn,
  'bundle_yn': instance.bundle_yn,
  'trad_desc': instance.trad_desc,
  'bundle_login_id': instance.bundle_login_id,
  'm_shop_cd': instance.m_shop_cd,
  'trad_name': instance.trad_name,
};