import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopFlowerProdDetailModel {
  ShopFlowerProdDetailModel();

  bool selected = false;
  String prod_code;
  String shop_cd;
  String name;
  String ribbon_card_yn;
  String cost;
  String amount;
  String disc_ratio;
  String disc_st_dt;
  String disc_to_dt;
  String disc_mark_gbn;
  String memo;
  String cat_code1;
  String cat_code2;
  String cat_code3;
  String thema_code1;
  String thema_code2;
  String thema_code3;
  String use_gbn;
  String no_flag;
  String main_yn;
  String description;
  String mark1_yn;
  String mark2_yn;
  String mark2_txt;
  String prod_group_cd;
  String mod_ucode;
  String mod_name;
  String ins_ucode;
  String ins_name;

  factory ShopFlowerProdDetailModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopFlowerProdDetailModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopFlowerProdDetailModel()
    ..selected = json['selected'] as bool
    ..prod_code = json['prod_code'] as String
    ..shop_cd = json['shop_cd'] as String
    ..name = json['name'] as String
    ..ribbon_card_yn = json['ribbon_card_yn'] as String
    ..cost = json['cost'] as String
    ..amount = json['amount'] as String
    ..disc_ratio = json['disc_ratio'] as String
    ..disc_mark_gbn = json['disc_mark_gbn'] as String
    ..disc_st_dt = json['disc_st_dt'] as String
    ..disc_to_dt = json['disc_to_dt'] as String
    ..memo = json['memo'] as String
    ..cat_code1 = json['cat_code1'] as String
    ..cat_code2 = json['cat_code2'] as String
    ..cat_code3 = json['cat_code3'] as String
    ..thema_code1 = json['thema_code1'] as String
    ..thema_code2 = json['thema_code2'] as String
    ..thema_code3 = json['thema_code3'] as String
    ..use_gbn = json['use_gbn'] as String
    ..no_flag = json['no_flag'] as String
    ..main_yn = json['main_yn'] as String
    ..description = json['description'] as String
    ..mark1_yn = json['mark1_yn'] as String
    ..mark2_yn = json['mark2_yn'] as String
    ..mark2_txt = json['mark2_txt'] as String
    ..prod_group_cd = json['prod_group_cd'] as String
    ..mod_ucode = json['mod_ucode'] as String
    ..mod_name = json['mod_name'] as String
    ..ins_ucode = json['ins_ucode'] as String
    ..ins_name = json['ins_name'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopFlowerProdDetailModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'prod_code': instance.prod_code,
  'shop_cd': instance.shop_cd,
  'name': instance.name,
  'ribbon_card_yn': instance.ribbon_card_yn,
  'cost': instance.cost,
  'amount': instance.amount,
  'disc_ratio': instance.disc_ratio,
  'disc_mark_gbn': instance.disc_mark_gbn,
  'disc_st_dt': instance.disc_st_dt,
  'disc_to_dt': instance.disc_to_dt,
  'memo': instance.memo,
  'cat_code1': instance.cat_code1,
  'cat_code2': instance.cat_code2,
  'cat_code3': instance.cat_code3,
  'thema_code1': instance.thema_code1,
  'thema_code2': instance.thema_code2,
  'thema_code3': instance.thema_code3,
  'use_gbn': instance.use_gbn,
  'no_flag': instance.no_flag,
  'main_yn': instance.main_yn,
  'description': instance.description,
  'mark1_yn': instance.mark1_yn,
  'mark2_yn': instance.mark2_yn,
  'mark2_txt': instance.mark2_txt,
  'prod_group_cd': instance.prod_group_cd,
  'mod_ucode': instance.mod_ucode,
  'mod_name': instance.mod_name,
  'ins_ucode': instance.ins_ucode,
  'ins_name': instance.ins_name,
};