import 'package:json_annotation/json_annotation.dart';

class ShopEventCouponListModel {
  ShopEventCouponListModel();

  bool selected = false;
  String rnum ;
  String shop_cd ;
  String shop_name ;
  String apply_gbn;
  String display_st_date;
  String display_end_date;
  String status;
  String use_gbn;
  String coupon_type;
  String coupon_name;
  String ins_date;
  String ins_name;
  String mod_date;
  String mod_name;
}