
class ShopKindListModel {
  ShopKindListModel();

  String shop_name;
  String shop_cd;
  String kind_shop_status;
  String kind_shop_cancel_dt;
  String kind_shop_memo;
  String use_gbn;
  String absent_yn;
  String insert_date;
  String comp_date;
  String pos_install;
  String pos_login;
  String alloc_ucode;
  String alloc_uname;
}