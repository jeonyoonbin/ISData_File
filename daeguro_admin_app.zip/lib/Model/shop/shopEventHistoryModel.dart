
class ShopEventHistoryModel {
  ShopEventHistoryModel();

  bool selected = false;
  int NO;
  int HIST_SEQ;
  String HIST_DATE;
  String MEMO;
}