import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopReserveInfoModel {
  ShopReserveInfoModel();

  bool selected = false;
  String shopCd;
  String ccCode;
  String itemCd;
  String itemCd1;
  String facilities_1;
  String facilities_2;
  String facilities_3;
  String facilities_4;
  String facilities_5;
  String facilities_6;
  String facilities_7;
  String facilities_8;
  String facilities_9;
  String facilities_10;
  String userId;
  String introduce;
  String notice;
  String reveiwUseGbn;
  String shopReviewInrto;
  String shopName;

  factory ShopReserveInfoModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopReserveInfoModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopReserveInfoModel()
    ..selected = json['selected'] as bool
    ..shopCd = json['shopCd'] as String
    ..ccCode = json['ccCode'] as String
    ..itemCd = json['itemCd'] as String
    ..itemCd1 = json['itemCd1'] as String
    ..facilities_1 = json['facilities_1'] as String
    ..facilities_2 = json['facilities_2'] as String
    ..facilities_3 = json['facilities_3'] as String
    ..facilities_4 = json['facilities_4'] as String
    ..facilities_5 = json['facilities_5'] as String
    ..facilities_6 = json['facilities_6'] as String
    ..facilities_7 = json['facilities_7'] as String
    ..facilities_8 = json['facilities_8'] as String
    ..facilities_9 = json['facilities_9'] as String
    ..facilities_10 = json['facilities_10'] as String
    ..userId = json['userId'] as String
    ..introduce = json['introduce'] as String
    ..notice = json['notice'] as String
    ..reveiwUseGbn = json['reveiwUseGbn'] as String
    ..shopReviewInrto = json['shopReviewInrto'] as String
    ..shopName = json['shopName'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopReserveInfoModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'shopCd': instance.shopCd,
  'ccCode': instance.ccCode,
  'itemCd': instance.itemCd,
  'itemCd1': instance.itemCd1,
  'facilities_1': instance.facilities_1,
  'facilities_2': instance.facilities_2,
  'facilities_3': instance.facilities_3,
  'facilities_4': instance.facilities_4,
  'facilities_5': instance.facilities_5,
  'facilities_6': instance.facilities_6,
  'facilities_7': instance.facilities_7,
  'facilities_8': instance.facilities_8,
  'facilities_9': instance.facilities_9,
  'facilities_10': instance.facilities_10,
  'userId': instance.userId,
  'introduce': instance.introduce,
  'notice': instance.notice,
  'reveiwUseGbn': instance.reveiwUseGbn,
  'shopReviewInrto': instance.shopReviewInrto,
  'shopName': instance.shopName
};
