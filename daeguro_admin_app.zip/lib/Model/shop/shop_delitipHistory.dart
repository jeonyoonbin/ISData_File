
class ShopDeliTipHistoryModel {
  ShopDeliTipHistoryModel();

  bool selected = false;
  int no;
  String modTime;
  String modDesc;
}