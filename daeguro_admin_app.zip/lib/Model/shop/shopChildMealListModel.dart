
class ShopChildMealListModel {
  ShopChildMealListModel();

  bool selected = false;
  String seq;
  String ins_date;
  String reg_no;
  String shop_cd;
  String shop_name;
  String child_meal_yn;
  String child_meal_cd;
  String sh_child_meal_cd;
  String mod_date;
  String mod_ucode;
  String mod_name;
}