import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopReserveUpdateReviewIntroModel {
  ShopReserveUpdateReviewIntroModel();

  String shopCd = '';
  String ccCode = '';
  String shopReviewIntro = '';
  String userID = '';

  factory ShopReserveUpdateReviewIntroModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopReserveUpdateReviewIntroModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopReserveUpdateReviewIntroModel()
    ..shopCd = json['shopCd'] as String
    ..ccCode = json['ccCode'] as String
    ..shopReviewIntro = json['shopReviewIntro'] as String
    ..userID = json['userID'] as String;

}

Map<String, dynamic> _$ModelToJson(ShopReserveUpdateReviewIntroModel instance) => <String, dynamic>{
  'shopCd': instance.shopCd,
  'ccCode': instance.ccCode,
  'shopReviewIntro': instance.shopReviewIntro,
  'userID': instance.userID
};