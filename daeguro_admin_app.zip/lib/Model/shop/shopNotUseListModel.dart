
class ShopNotUseListModel {
  ShopNotUseListModel();

  bool selected = false;
  String shop_cd;
  String shop_name;
  String reg_no;
  String remain_amt;
  String taxpayer_status;
  String taxation_type;
  String closure_dt;
}