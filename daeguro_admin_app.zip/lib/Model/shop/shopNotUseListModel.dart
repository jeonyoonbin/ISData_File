
class ShopNotUseListModel {
  ShopNotUseListModel();

  bool selected = false;
  String shop_cd;
  String shop_name;
  String shop_status;
  String reg_no;
  String remain_amt;
  String taxpayer_status;
  String taxation_type;
  String closure_dt;
  String tot_cnt;
  String comp_cnt;
  String cancel_cnt;
  String absent_yn;
  String open_dt;
  String shop_type;
  String service_gbn;
}