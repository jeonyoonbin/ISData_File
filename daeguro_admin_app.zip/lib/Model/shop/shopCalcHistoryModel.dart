
class ShopCalcHistoryModel {
  ShopCalcHistoryModel();

  String NO;
  String HIST_DATE;
  String MEMO;

}