import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopBasicInfoModel {
  ShopBasicInfoModel();

  bool selected = false;
  String mCode;
  String ccCode;
  String franchiseCd = '';
  String sEtcGbn6 = '';
  String shopId;
  String shopCd;
  String shopName;
  String regNo;
  String email;
  String owner;
  String mobile;
  String addr1;
  String addr2;
  String lon;
  String lat;
  String zipCode;
  String modUCode;
  String modName;
  String memo;
  String bussShopname;
  String bussCon;
  String bussType;
  String bussTaxType;
  String bussOwner;
  String bussAddr;
  String salesmanCode = '';
  String salesmanName = '';
  String operatorCode = '';
  String operatorName = '';
  String sidoName = '';
  String gunguName = '';
  String dongName = '';
  String destJibun = '';
  String roadDestDong = '';
  String roadDestAddr = '';
  String roadDestBuilding = '';
  String loc = '';
  String useGbn = '';
  String telNo = '';
  String apiComCode = '';
  String contractEndDt = '';
  String mobileChgCnt = '';
  String sEtcGbn5 = '';
  String licenseNo = '';
  String taxpayerStatus = '';
  String taxationType = '';

  // POS 정보 저장
  String pos_road = '';
  String pos_hdong = '';
  String pos_bdong = '';
  String pos_ri = '';

  //서서비스 구분(0: 주문, 1: 특별관, 2: 꽃배달)
  String serviceGbn;

  factory ShopBasicInfoModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopBasicInfoModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopBasicInfoModel()
    ..selected = json['selected'] as bool
    ..mCode = json['mCode'] as String
    ..ccCode = json['ccCode'] as String
    ..franchiseCd = json['franchiseCd'] as String
    ..sEtcGbn6 = json['sEtcGbn6'] as String
    ..shopId = json['shopId'] as String
    ..shopCd = json['shopCd'] as String
    ..shopName = json['shopName'] as String
    ..regNo = json['regNo'] as String
    ..email = json['email'] as String
    ..owner = json['owner'] as String
    ..mobile = json['mobile'] as String
    ..addr1 = json['addr1'] as String
    ..addr2 = json['addr2'] as String
    ..lon = json['lon'] as String
    ..lat = json['lat'] as String
    ..zipCode = json['zipCode'] as String
    ..modUCode = json['modUCode'] as String
    ..modName = json['modName'] as String
    ..memo = json['memo'] as String
    ..bussShopname = json['bussShopname'] as String
    ..bussCon = json['bussCon'] as String
    ..bussType = json['bussType'] as String
    ..bussTaxType = json['bussTaxType'] as String
    ..bussOwner = json['bussOwner'] as String
    ..bussAddr = json['bussAddr'] as String
    ..salesmanCode = json['salesmanCode'] as String
    ..salesmanName = json['salesmanName'] as String
    ..operatorCode = json['operatorCode'] as String
    ..operatorName = json['operatorName'] as String
    ..sidoName = json['sidoName'] as String
    ..gunguName = json['gunguName'] as String
    ..dongName = json['dongName'] as String
    ..destJibun = json['destJibun'] as String
    ..roadDestDong = json['roadDestDong'] as String
    ..roadDestAddr = json['roadDestAddr'] as String
    ..roadDestBuilding = json['roadDestBuilding'] as String
    ..loc = json['loc'] as String
    ..useGbn = json['useGbn'] as String
    ..telNo = json['telNo'] as String
    ..apiComCode = json['apiComCode'] as String
    ..contractEndDt = json['contractEndDt'] as String
    ..pos_road = json['pos_road'] as String
    ..pos_hdong = json['pos_hdong'] as String
    ..pos_bdong = json['pos_bdong'] as String
    ..pos_ri = json['pos_ri'] as String
    ..mobileChgCnt = json['mobileChgCnt'] as String
    ..sEtcGbn5 = json['sEtcGbn5'] as String
    ..serviceGbn = json['serviceGbn'] as String
    ..licenseNo = json['licenseNo'] as String
    ..taxpayerStatus = json['taxpayerStatus'] as String
    ..taxationType = json['taxationType'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopBasicInfoModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'mCode': instance.mCode,
  'ccCode': instance.ccCode,
  'franchiseCd': instance.franchiseCd,
  'sEtcGbn6': instance.sEtcGbn6,
  'shopId': instance.shopId,
  'shopCd': instance.shopCd,
  'shopName': instance.shopName,
  'regNo': instance.regNo,
  'email': instance.email,
  'owner': instance.owner,
  'mobile': instance.mobile,
  'addr1': instance.addr1,
  'addr2': instance.addr2,
  'lon': instance.lon,
  'lat': instance.lat,
  'zipCode': instance.zipCode,
  'modUCode': instance.modUCode,
  'modName': instance.modName,
  'memo': instance.memo,
  'bussShopname': instance.bussShopname,
  'bussCon': instance.bussCon,
  'bussType': instance.bussType,
  'bussTaxType': instance.bussTaxType,
  'bussOwner': instance.bussOwner,
  'bussAddr': instance.bussAddr,
  'salesmanCode': instance.salesmanCode,
  'salesmanName': instance.salesmanName,
  'operatorCode': instance.operatorCode,
  'operatorName': instance.operatorName,
  'sidoName': instance.sidoName,
  'gunguName': instance.gunguName,
  'dongName': instance.dongName,
  'destJibun': instance.destJibun,
  'roadDestDong': instance.roadDestDong,
  'roadDestAddr': instance.roadDestAddr,
  'roadDestBuilding': instance.roadDestBuilding,
  'loc': instance.loc,
  'useGbn': instance.useGbn,
  'telNo': instance.telNo,
  'apiComCode': instance.apiComCode,
  'contractEndDt': instance.contractEndDt,
  'pos_road': instance.pos_road,
  'pos_hdong': instance.pos_hdong,
  'pos_bdong': instance.pos_bdong,
  'pos_ri': instance.pos_ri,
  'mobileChgCnt': instance.mobileChgCnt,
  'sEtcGbn5': instance.sEtcGbn5,
  'serviceGbn': instance.serviceGbn,
  'licenseNo': instance.licenseNo,
  'taxpayerStatus': instance.taxpayerStatus,
  'taxationType': instance.taxationType,
};