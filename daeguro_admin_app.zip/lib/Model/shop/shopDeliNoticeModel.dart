class shopDelinoticeModel {
  shopDelinoticeModel();

  String deli_notice_code;
  String title;
  String content;
  String sort_seq;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
}
