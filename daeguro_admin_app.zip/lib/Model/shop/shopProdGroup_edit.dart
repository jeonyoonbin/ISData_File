import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopProdGroupEditModel {
  ShopProdGroupEditModel();

  bool selected = false;
  String shop_cd;
  String prod_group_cd;
  String prod_group_name;
  String prod_group_memo;
  String use_yn;
  String optionYn;
  String mainImageYn;
  String sortSeq;
  String groupFileName;
  String ins_ucode;
  String ins_name;
  String mod_ucode;
  String mod_name;

  factory ShopProdGroupEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopProdGroupEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopProdGroupEditModel()
    ..selected = json['selected'] as bool
    ..shop_cd = json['shop_cd'] as String
    ..prod_group_cd = json['prod_group_cd'] as String
    ..prod_group_name = json['prod_group_name'] as String
    ..prod_group_memo = json['prod_group_memo'] as String
    ..use_yn = json['use_yn'] as String
    ..optionYn = json['optionYn'] as String
    ..mainImageYn = json['mainImageYn'] as String
    ..sortSeq = json['sortSeq'] as String
    ..groupFileName = json['groupFileName'] as String
    ..ins_ucode = json['ins_ucode'] as String
    ..ins_name = json['ins_name'] as String
    ..mod_ucode = json['mod_ucode'] as String
    ..mod_name = json['mod_name'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopProdGroupEditModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'shop_cd': instance.shop_cd,
  'prod_group_cd': instance.prod_group_cd,
  'prod_group_name': instance.prod_group_name,
  'prod_group_memo': instance.prod_group_memo,
  'use_yn': instance.use_yn,
  'optionYn': instance.optionYn,
  'mainImageYn': instance.mainImageYn,
  'sortSeq': instance.sortSeq,
  'groupFileName': instance.groupFileName,
  'ins_ucode': instance.ins_ucode,
  'ins_name': instance.ins_name,
  'mod_ucode': instance.mod_ucode,
  'mod_name': instance.mod_name,
};