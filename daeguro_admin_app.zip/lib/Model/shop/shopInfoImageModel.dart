import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopInfoImageModel {
  ShopInfoImageModel();

  bool selected = false;
  String SEQ;
  String FILE_NAME;
  String SORT_SEQ;

  factory ShopInfoImageModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopInfoImageModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopInfoImageModel()
    ..selected = json['selected'] as bool
    ..SEQ = json['SEQ'] as String
    ..FILE_NAME = json['FILE_NAME'] as String
    ..SORT_SEQ = json['SORT_SEQ'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopInfoImageModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'SEQ': instance.SEQ,
  'FILE_NAME': instance.FILE_NAME,
  'SORT_SEQ': instance.SORT_SEQ
};
