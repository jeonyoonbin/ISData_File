import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopReserveModifyClosedayModel {
  ShopReserveModifyClosedayModel({this.seq});

  int seq;
  String foDay = '0';
  String toDay = '0';

  factory ShopReserveModifyClosedayModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopReserveModifyClosedayModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopReserveModifyClosedayModel()
    ..seq = json['seq'] as int
    ..foDay = json['foDay'] as String
    ..toDay = json['toDay'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopReserveModifyClosedayModel instance) => <String, dynamic>{
  'seq': instance.seq,
  'foDay': instance.foDay,
  'toDay': instance.toDay
};