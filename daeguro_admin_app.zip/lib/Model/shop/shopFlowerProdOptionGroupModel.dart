import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopProdOptionGroupModel {
  ShopProdOptionGroupModel();

  bool boolselected = false;
  String selected;
  String shopCd;
  String optionGroupCd;
  String optionGroupName;
  String minCount;
  String maxCount;
  String optionNames;
  String useGbn;
  String insUcode;
  String insName;
  String modUcode;
  String modName;
  bool isFlag = false;

  factory ShopProdOptionGroupModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopProdOptionGroupModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopProdOptionGroupModel()
    ..selected = json['selected'] as String
    ..shopCd = json['shopCd'] as String
    ..optionGroupCd = json['optionGroupCd'] as String
    ..optionGroupName = json['optionGroupName'] as String
    ..minCount = json['minCount'] as String
    ..maxCount = json['maxCount'] as String
    ..useGbn = json['useGbn'] as String
    ..optionNames = json['optionNames'] as String
    ..insUcode = json['insUcode'] as String
    ..insName = json['insName'] as String
    ..modUcode = json['modUcode'] as String
    ..modName = json['modName'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopProdOptionGroupModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'shopCd': instance.shopCd,
  'optionGroupCd': instance.optionGroupCd,
  'optionGroupName': instance.optionGroupName,
  'minCount': instance.minCount,
  'maxCount': instance.maxCount,
  'useGbn': instance.useGbn,
  'optionNames': instance.optionNames,
  'insUcode': instance.insUcode,
  'insName': instance.insName,
  'modUcode': instance.modUcode,
  'modName': instance.modName,
};