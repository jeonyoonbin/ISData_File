
class ShopIntroModel {
  ShopIntroModel();

  String intro_cd;
  String shop_cd;
  String intro_gbn;
  String use_gbn;
  String file_name_1;
  String file_name_2;
  String intro_contents;
}