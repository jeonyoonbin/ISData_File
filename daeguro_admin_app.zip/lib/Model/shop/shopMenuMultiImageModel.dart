
class ShopMenuMultiImageModel {
  ShopMenuMultiImageModel();

  bool selected = false;
  String seq;
  String file_name;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
}