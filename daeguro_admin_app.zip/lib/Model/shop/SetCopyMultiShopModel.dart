import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class SetCopyMultiShopModel {
  SetCopyMultiShopModel();

  bool selected = false;
  String mcode;
  String rep_shop_cd;
  String shop_name;
  String api_com_code;
  String copy_calc;
  String copy_info;
  String copy_sector;
  String copy_deli_tip;
  String copy_day_time;
  String copy_menu;
  String ucode;

  factory SetCopyMultiShopModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

SetCopyMultiShopModel _$ModelFromJson(Map<String, dynamic> json) {
  return SetCopyMultiShopModel()
    ..selected = json['selected'] as bool
    ..mcode = json['mcode'] as String
    ..rep_shop_cd = json['rep_shop_cd'] as String
    ..shop_name = json['shop_name'] as String
    ..api_com_code = json['api_com_code'] as String
    ..copy_calc = json['copy_calc'] as String
    ..copy_info = json['copy_info'] as String
    ..copy_sector = json['copy_sector'] as String
    ..copy_deli_tip = json['copy_deli_tip'] as String
    ..copy_day_time = json['copy_day_time'] as String
    ..copy_menu = json['copy_menu'] as String
    ..ucode = json['ucode'] as String;
}

Map<String, dynamic> _$ModelToJson(SetCopyMultiShopModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'mcode': instance.mcode,
  'rep_shop_cd': instance.rep_shop_cd,
  'shop_name': instance.shop_name,
  'api_com_code': instance.api_com_code,
  'copy_calc': instance.copy_calc,
  'copy_info': instance.copy_info,
  'copy_sector': instance.copy_sector,
  'copy_deli_tip': instance.copy_deli_tip,
  'copy_day_time': instance.copy_day_time,
  'copy_menu': instance.copy_menu,
  'ucode': instance.ucode
};