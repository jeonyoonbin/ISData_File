
class ShopEventListModel {
  ShopEventListModel();

  bool selected = false;
  int RNUM;
  String SHOP_CD;
  String SHOP_NAME;
  String INS_DATE;
  String INS_NAME;
  String FROM_TIME;
  String TO_TIME;
  String STATE;
  String EVENT_TITLE_M;
}
