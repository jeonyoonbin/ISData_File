
class codeListModel {
  codeListModel();

  bool selected = false;
  String CODE_GRP;
  String CODE;
  String CODE_NM;
  String MEMO = '';
  double ETC_AMT1 = 0.0;
  double ETC_AMT2 = 0.0;
  double ETC_AMT3 = 0.0;
  double ETC_AMT4 = 0.0;
  String ETC_CODE_GBN1 = '';//쿠폰 이미지로고
  String ETC_CODE_GBN2 = '';//쿠폰 폰트색
  String ETC_CODE_GBN3 = '';//쿠폰 배경색
  String ETC_CODE_GBN4 = '';
  String ETC_CODE_GBN5 = '';
  String ETC_CODE_GBN6 = '';
  String ETC_CODE_GBN7 = '';
  String ETC_CODE_GBN8 = '';
  String ETC_CODE_GBN9 = '';
  String ETC_CODE_GBN10 = '';
  String ETC_CODE1; // QR 코드 사용날짜 기한
  String ETC_CODE2 = ''; // QR 여부
  String ETC_CODE3 = ''; // 대구로, 택시 쿠폰 구분
  String PUB_GBN = '';
  String USE_GBN;
  String TEST_YN;
  String INS_DATE;
  int INS_UCODE;
  String INS_NAME;
  String MOD_DATE;
  int MOD_UCODE;
  String MOD_NAME;
}
