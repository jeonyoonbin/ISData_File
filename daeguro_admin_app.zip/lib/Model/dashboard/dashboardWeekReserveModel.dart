
class DashBoardWeekReserveModel {
  DashBoardWeekReserveModel();

  String RESER_DATE;
  String RESER_DAY;
  int COUNT;
  int COMPLETE_COUNT;
}