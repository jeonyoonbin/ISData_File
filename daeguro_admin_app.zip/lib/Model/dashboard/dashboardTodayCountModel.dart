import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class DashBoardTodayCountModel {
  DashBoardTodayCountModel();

  int TOTAL_MEMBER_D = 0;
  int TODAY_APP_INSTALL_D = 0;
  int TODAY_MEMBER_D = 0;
  int TODAY_ORDER = 0;
  int TODAY_SHOP_CONFIRM = 0;
  int TODAY_COMPLETE_COUNT = 0;
  int RESER_INS = 0;
  int RESER_SHOP_CONFIRM = 0;
  int TODAY_RESER = 0;
  int RESER_COMPLETE_COUNT = 0;
  int TOTAL_MEMBER_T = 0;
  int TODAY_APP_INSTALL_T = 0;
  int TODAY_MEMBER_T = 0;

  factory DashBoardTodayCountModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

DashBoardTodayCountModel _$ModelFromJson(Map<String, dynamic> json) {
  return DashBoardTodayCountModel()
    ..TOTAL_MEMBER_D = json['TOTAL_MEMBER_D'] as int
    ..TODAY_APP_INSTALL_D = json['TODAY_APP_INSTALL_D'] as int
    ..TODAY_MEMBER_D = json['TODAY_MEMBER_D'] as int
    ..TODAY_ORDER = json['TODAY_ORDER'] as int
    ..TODAY_SHOP_CONFIRM = json['TODAY_SHOP_CONFIRM'] as int
    ..TODAY_COMPLETE_COUNT = json['TODAY_COMPLETE_COUNT'] as int
    ..RESER_INS = json['RESER_INS'] as int
    ..RESER_SHOP_CONFIRM = json['RESER_SHOP_CONFIRM'] as int
    ..TODAY_RESER = json['TODAY_RESER'] as int
    ..RESER_COMPLETE_COUNT = json['RESER_COMPLETE_COUNT'] as int
    ..TOTAL_MEMBER_T = json['TOTAL_MEMBER_T'] as int
    ..TODAY_APP_INSTALL_T = json['TODAY_APP_INSTALL_T'] as int
    ..TODAY_MEMBER_T = json['TODAY_MEMBER_T'] as int;
}

Map<String, dynamic> _$ModelToJson(DashBoardTodayCountModel instance) => <String, dynamic>{
  'TOTAL_MEMBER_D': instance.TOTAL_MEMBER_D,
  'TODAY_APP_INSTALL_D': instance.TODAY_APP_INSTALL_D,
  'TODAY_MEMBER_D': instance.TODAY_MEMBER_D,
  'TODAY_ORDER': instance.TODAY_ORDER,
  'TODAY_SHOP_CONFIRM': instance.TODAY_SHOP_CONFIRM,
  'TODAY_COMPLETE_COUNT': instance.TODAY_COMPLETE_COUNT,
  'RESER_INS': instance.RESER_INS,
  'RESER_SHOP_CONFIRM': instance.RESER_SHOP_CONFIRM,
  'TODAY_RESER': instance.TODAY_RESER,
  'RESER_COMPLETE_COUNT': instance.RESER_COMPLETE_COUNT,
  'TOTAL_MEMBER_T': instance.TOTAL_MEMBER_T,
  'TODAY_APP_INSTALL_T': instance.TODAY_APP_INSTALL_T,
  'TODAY_MEMBER_T': instance.TODAY_MEMBER_T,
};
