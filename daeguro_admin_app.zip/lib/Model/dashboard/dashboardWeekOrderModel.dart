
class DashBoardWeekOrderModel {
  DashBoardWeekOrderModel();

  String ORDER_DATE;
  int COUNT;
  int COMPLETE_COUNT;
  int R_COUNT;
  int R_COMPLETE_COUNT;
}