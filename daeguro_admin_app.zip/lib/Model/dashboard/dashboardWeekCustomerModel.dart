
class DashBoardWeekCustomerModel {
  DashBoardWeekCustomerModel();

  String INSERT_DATE;
  int INSTALL_COUNT;
  int NEW_COSTOMER_COUNT;
}