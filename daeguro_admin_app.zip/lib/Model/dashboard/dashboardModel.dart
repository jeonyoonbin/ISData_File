
class DashBoardModel {
  DashBoardModel();

  String totalShopCount = '0';
  String newShopCount = '0';
  String useShopCount = '0';
  String stopShopCount = '0';
  String totalShopCountR = '0';
  String newShopCountR = '0';
  String useShopCountR = '0';
  String stopShopCountR = '0';
}