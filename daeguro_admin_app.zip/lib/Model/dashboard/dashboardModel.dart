
class DashBoardModel {
  DashBoardModel();

  String totalShopCount = '0';
  String newShopCount = '0';
  String useShopCount = '0';
  String stopShopCount = '0';
}