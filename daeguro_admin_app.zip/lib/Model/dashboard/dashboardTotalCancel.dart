
class DashBoardTotalCancel {
  DashBoardTotalCancel();

  String cancel_code = '';
  int count = 0;
}