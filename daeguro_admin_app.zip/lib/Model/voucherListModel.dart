
class voucherListModel {
  voucherListModel();

  bool selected = false;
  String RNUM;
  String VOUCHER_TYPE;
  String VOUCHER_NAME;
  int VOUCHER_AMT;
  int VOUCHER_REMAIN_AMT;
  String VOUCHER_NO;
  String STATUS;
  String REG_DATE;
  String REG_EXP_DATE;
  String INS_DATE;
  String USE_EXP_DATE;
  String INS_UCODE;
  String INS_NAME;
  String EXTENSION_YN;
  String CUST_CODE;
  String CUST_TELNO;
  String CUST_NAME;
}
