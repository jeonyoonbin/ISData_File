
class voucherListModel {
  voucherListModel();

  bool selected = false;
  String wt;
  String no;
  String us;
  String ud;
  String ep;
  String rr;
  String rc;
  String voucher_seq;
  String group_cd;
  String group_name;
  String prsc_gbn;
  String voucher_type;
  String voucher_name;
  String voucher_no;
  String voucher_amt;
  String voucher_remain_amt;
  String status;
  String reg_date;
  String reg_exp_date;
  String use_exp_date;
  String cust_code;
  String cust_telno;
  String cust_name;
  String receive_telno;
  String card_reciever;
  String buy_ccode;
  String buy_telno ;
  String buy_name ;
  String refund_acc_yn;
  String ins_date;
  String ins_ucode;
  String ins_name;
}
