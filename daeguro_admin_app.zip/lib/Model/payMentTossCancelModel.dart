import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class PayMentTossCancelModel {
  PayMentTossCancelModel();

  String server_type;
  String order_no;

  factory PayMentTossCancelModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

PayMentTossCancelModel _$ModelFromJson(Map<String, dynamic> json) {
  return PayMentTossCancelModel()
    ..server_type = json['server_type'] as String
    ..order_no = json['order_no'] as String;
}

Map<String, dynamic> _$ModelToJson(PayMentTossCancelModel instance) => <String, dynamic>{
  'server_type': instance.server_type,
  'order_no': instance.order_no,
};