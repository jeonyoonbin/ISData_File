
class reviewReserveListModel {
  reviewReserveListModel();

  bool selected = false;
  int RNUM;
  String shopCd;
  String shopName;
  int orderSeqno;
  String bliendType;
  String bliendAgreeGbn;
  String visublGbn;
  int starRating;
  int custCode;
  String telNo;
  String custName;
  int reportCount;
  String content;
  String insertDate;
  String blindReqDt;
  String answerText;
  String imageYn;
  String memo;
  String status;
}
