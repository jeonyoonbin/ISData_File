
class reviewReportListModel {
  reviewReportListModel();

  bool selected = false;
  int CUST_CODE;
  String CUST_NAME;
  int RNUM;
  int REVIEW_SEQNO;
  String REPORT_REASON;
  String INSERT_DATE;
  String USE_YN;
}

