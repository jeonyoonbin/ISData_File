import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ReviewReserveHistoryModel {
  ReviewReserveHistoryModel();

  bool selected = false;
  String userName;
  int modUcode;
  String histDate;
  String memo;
}