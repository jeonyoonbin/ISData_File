
class reviewListModel {
  reviewListModel();

  bool selected = false;
  int RNUM;
  String SHOP_CD;
  String SHOP_NAME;
  int ORDER_SEQNO;
  String BLIEND_TYPE;
  String BLIEND_AGREE_GBN;
  String VISBLE_GBN;
  int STAR_RATING;
  int CUST_CODE;
  String TELNO;
  String CUST_NAME;
  int REPORT_COUNT;
  String CONTENT;
  String INSERT_DATE;
  String BLIND_REQ_DT;
  String IMAGE_YN;
  String STATUS;
  String SERVICE_GBN;
}
