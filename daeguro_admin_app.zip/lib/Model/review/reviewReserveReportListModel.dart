
class ReviewReserveReportListModel {
  ReviewReserveReportListModel();

  bool selected = false;
  int custCode;
  String custName;
  int reviewSeqno;
  String reportReason;
  String insertDate;
  String useYn;
}

