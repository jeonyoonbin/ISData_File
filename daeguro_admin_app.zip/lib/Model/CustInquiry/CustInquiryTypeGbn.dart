import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CustInquiryTypeGbn {
  CustInquiryTypeGbn();

  bool selected = false;

  //요청 구분
  String inquiry_gbn;
  String inquiry_name;

  factory CustInquiryTypeGbn.fromJson(Map<String,dynamic> json) =>
      _$ModelFromJson(json);

  Map<String,dynamic> toJson() => _$ModelToJson(this);
}

CustInquiryTypeGbn _$ModelFromJson(Map<String, dynamic> json) {
  return CustInquiryTypeGbn()
    ..selected = json['selected'] as bool
    ..inquiry_gbn = json['inquiry_gbn'] as String
    ..inquiry_name = json['inquiry_name'] as String;
}

Map<String,dynamic> _$ModelToJson(CustInquiryTypeGbn instance) => <String, dynamic>{
  'selected': instance.selected,
  'inquiry_gbn': instance.inquiry_gbn,
  'inquiry_name': instance.inquiry_name,
};