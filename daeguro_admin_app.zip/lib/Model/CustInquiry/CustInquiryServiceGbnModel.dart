import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CustInquiryServiceGbn {
  CustInquiryServiceGbn();

  bool selected = false;

  //요청 구분
  String service_gbn;
  String service_name;
  String use_gbn;

  factory CustInquiryServiceGbn.fromJson(Map<String,dynamic> json) =>
      _$ModelFromJson(json);

  Map<String,dynamic> toJson() => _$ModelToJson(this);
}

CustInquiryServiceGbn _$ModelFromJson(Map<String, dynamic> json) {
  return CustInquiryServiceGbn()
    ..selected = json['selected'] as bool
    ..service_gbn = json['service_gbn'] as String
    ..service_name = json['service_name'] as String
    ..use_gbn = json['use_gbn'] as String;
}

Map<String,dynamic> _$ModelToJson(CustInquiryServiceGbn instance) => <String, dynamic>{
  'selected': instance.selected,
  'service_gbn': instance.service_gbn,
  'service_name': instance.service_name,
  'use_gbn': instance.use_gbn
};