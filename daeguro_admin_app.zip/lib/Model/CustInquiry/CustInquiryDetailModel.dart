import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CustInquiryDetailModel {
  String seqno = '';
  String service_gbn = '';
  String service_name = '';
  String inquiry_gbn = '';
  String inquiry_name = '';
  String os_type = '';
  String os_version = '';
  String device_model = '';
  String app_version = '';
  String contents = '';
  String ins_date = '';
  String cust_code = '';
  String img_file1 = '';
  String img_file2 = '';
  String img_file3 = '';
  String img_file4 = '';
  String img_file5 = '';
}