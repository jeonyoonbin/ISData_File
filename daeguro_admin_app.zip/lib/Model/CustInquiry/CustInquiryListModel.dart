
class CustInquiryListModel {
  CustInquiryListModel();

  bool selected = false;
  String seqno;
  String service_name;
  String inquiry_name;
  String contents;
  String ins_date;
}