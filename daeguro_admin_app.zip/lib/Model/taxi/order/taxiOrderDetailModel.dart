import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiOrderDetailModel {
  TaxiOrderDetailModel();

  String idGroup;
  String cdMember;
  String cdComp;
  String nmComp;
  String cdCust;
  String nmCust;
  String dtOrdNo;
  String seqOrdNo;
  String dtmIns;
  String idUsrIns;
  String nmUsrIns;
  String dtmUpd;
  String idUsrUpd;
  String nmUsrUpd;
  String ynShare;
  String ynShareText;
  String dtmShare;
  String ynReserve;
  String ynReserveText;
  String dtmReserve;
  String dtOrdNoP;
  String seqOrdNoP;
  String noRefOrdNo;
  String divOrder;
  String divOrderText;
  String divStatus;
  String divStatusText;
  String divDispat;
  String divDispatText;
  String divStatusOld;
  String divDevice;
  String rmkComp;
  String idPers;
  String cdCompPers;
  String nmPers;
  String ynOwn;
  String ynOwnText;
  String noTelPers;
  String noTelPersMy;
  String ynHide;
  String ynHideText;
  String nmLoad;
  String postLoad;
  String addrRoadLoad;
  String addrBunjiLoad;
  String addrLoad;
  String lonLoad;
  String latLoad;
  String dtmLoadReq;
  String dtmLoadEta;
  String nmUnload;
  String postUnload;
  String addrRoadUnload;
  String addrBunjiUnload;
  String addrUnload;
  String lonUnload;
  String latUnload;
  String dtmUnloadReq;
  String dtmUnloadEta;
  String ynUrgent;
  String ynUrgentText;
  String divTar;
  String divTarText;
  String distTar;
  String tmTar;
  String amtTar;
  String cdCancel;
  String cdCancelText;
  String rmkCancel;
  String divPay;
  String divPayText;
  String divMethod;
  String divMethodText;
  String divPg;
  String divPgText;
  String amtPrice;
  String amtExt;
  String amtOpt;
  String amtDc;
  String ptsUse;
  String ptsRtn;
  String ptsTake;
  String ptsTakeDrvr;
  String ptsTakeComp;
  String cdCoup;
  String noCoup;
  String amtCoup;
  String amtPayHappy;
  String amtSum;
  String amtPay;
  String amtRepay;
  String extItem;
  String noTidPg;
  String cardName;
  String cardBinType2Text;
  String cardNo;
  String btBatchKey;
  String divTax;
  String divTaxText;
  String seqEtax;
  String divCr;
  String divCrText;
  String noTidCr;
  String idCarGroup;
  String cdCarMember;
  String cdCarComp;
  String nmCarComp;
  String noCar1;
  String noCar2;
  String noCar3;
  String noCar;
  String idCarUser;
  String nmCarUser;
  String noTelCarUser;
  String cdCar;
  String cdCarText;
  String divClass;
  String divClassText;
  String divUsage;
  String divUsageText;
  String divCarPg;
  String divCarPgText;
  String divPgMethod;
  String divPgMethodText;
  String pgCarMid;
  String pgCarKey;
  String imgProfile;
  String dtmStart;
  String dtmLoad;
  String dtmUnload;
  String dtmFine;
  String ynAccident;
  String ynAccidentText;
  String dtmAccident;
  String rmkCargo;
  String rmkUser;
  String ynDrvrKpi;

  factory TaxiOrderDetailModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiOrderDetailModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiOrderDetailModel()
    ..idGroup = json['idGroup']
    ..cdMember = json['cdMember']
    ..cdComp = json['cdComp']
    ..nmComp = json['nmComp']
    ..cdCust = json['cdCust']
    ..nmCust = json['nmCust']
    ..dtOrdNo = json['dtOrdNo']
    ..seqOrdNo = json['seqOrdNo']
    ..dtmIns = json['dtmIns']
    ..idUsrIns = json['idUsrIns']
    ..nmUsrIns = json['nmUsrIns']
    ..dtmUpd = json['dtmUpd']
    ..idUsrUpd = json['idUsrUpd']
    ..nmUsrUpd = json['nmUsrUpd']
    ..ynShare = json['ynShare']
    ..ynShareText = json['ynShareText']
    ..dtmShare = json['dtmShare']
    ..ynReserve = json['ynReserve']
    ..ynReserveText = json['ynReserveText']
    ..dtmReserve = json['dtmReserve']
    ..dtOrdNoP = json['dtOrdNoP']
    ..seqOrdNoP = json['seqOrdNoP']
    ..noRefOrdNo = json['noRefOrdNo']
    ..divOrder = json['divOrder']
    ..divOrderText = json['divOrderText']
    ..divStatus = json['divStatus']
    ..divStatusText = json['divStatusText']
    ..divDispat = json['divDispat']
    ..divDispatText = json['divDispatText']
    ..divStatusOld = json['divStatusOld']
    ..divDevice = json['divDevice']
    ..rmkComp = json['rmkComp']
    ..idPers = json['idPers']
    ..cdCompPers = json['cdCompPers']
    ..nmPers = json['nmPers']
    ..ynOwn = json['ynOwn']
    ..ynOwnText = json['ynOwnText']
    ..noTelPers = json['noTelPers']
    ..noTelPersMy = json['noTelPersMy']
    ..ynHide = json['ynHide']
    ..ynHideText = json['ynHideText']
    ..nmLoad = json['nmLoad']
    ..postLoad = json['postLoad']
    ..addrRoadLoad = json['addrRoadLoad']
    ..addrBunjiLoad = json['addrBunjiLoad']
    ..addrLoad = json['addrLoad']
    ..lonLoad = json['lonLoad']
    ..latLoad = json['latLoad']
    ..dtmLoadReq = json['dtmLoadReq']
    ..dtmLoadEta = json['dtmLoadEta']
    ..nmUnload = json['nmUnload']
    ..postUnload = json['postUnload']
    ..addrRoadUnload = json['addrRoadUnload']
    ..addrBunjiUnload = json['addrBunjiUnload']
    ..addrUnload = json['addrUnload']
    ..lonUnload = json['lonUnload']
    ..latUnload = json['latUnload']
    ..dtmUnloadReq = json['dtmUnloadReq']
    ..dtmUnloadEta = json['dtmUnloadEta']
    ..ynUrgent = json['ynUrgent']
    ..ynUrgentText = json['ynUrgentText']
    ..divTar = json['divTar']
    ..divTarText = json['divTarText']
    ..distTar = json['distTar']
    ..tmTar = json['tmTar']
    ..amtTar = json['amtTar']
    ..cdCancel = json['cdCancel']
    ..cdCancelText = json['cdCancelText']
    ..rmkCancel = json['rmkCancel']
    ..divPay = json['divPay']
    ..divPayText = json['divPayText']
    ..divMethod = json['divMethod']
    ..divMethodText = json['divMethodText']
    ..divPg = json['divPg']
    ..divPgText = json['divPgText']
    ..amtPrice = json['amtPrice']
    ..amtExt = json['amtExt']
    ..amtOpt = json['amtOpt']
    ..amtDc = json['amtDc']
    ..ptsUse = json['ptsUse']
    ..ptsRtn = json['ptsRtn']
    ..ptsTake = json['ptsTake']
    ..ptsTakeDrvr = json['ptsTakeDrvr']
    ..ptsTakeComp = json['ptsTakeComp']
    ..cdCoup = json['cdCoup']
    ..noCoup = json['noCoup']
    ..amtCoup = json['amtCoup']
    ..amtPayHappy = json['amtPayHappy']
    ..amtSum = json['amtSum']
    ..amtPay = json['amtPay']
    ..amtRepay = json['amtRepay']
    ..extItem = json['extItem']
    ..noTidPg = json['noTidPg']
    ..cardName = json['cardName']
    ..cardBinType2Text = json['cardBinType2Text']
    ..cardNo = json['cardNo']
    ..btBatchKey = json['btBatchKey']
    ..divTax = json['divTax']
    ..divTaxText = json['divTaxText']
    ..seqEtax = json['seqEtax']
    ..divCr = json['divCr']
    ..divCrText = json['divCrText']
    ..noTidCr = json['noTidCr']
    ..idCarGroup = json['idCarGroup']
    ..cdCarMember = json['cdCarMember']
    ..cdCarComp = json['cdCarComp']
    ..nmCarComp = json['nmCarComp']
    ..noCar1 = json['noCar1']
    ..noCar2 = json['noCar2']
    ..noCar3 = json['noCar3']
    ..noCar = json['noCar']
    ..idCarUser = json['idCarUser']
    ..nmCarUser = json['nmCarUser']
    ..noTelCarUser = json['noTelCarUser']
    ..cdCar = json['cdCar']
    ..cdCarText = json['cdCarText']
    ..divClass = json['divClass']
    ..divClassText = json['divClassText']
    ..divUsage = json['divUsage']
    ..divUsageText = json['divUsageText']
    ..divCarPg = json['divCarPg']
    ..divCarPgText = json['divCarPgText']
    ..divPgMethod = json['divPgMethod']
    ..divPgMethodText = json['divPgMethodText']
    ..pgCarMid = json['pgCarMid']
    ..pgCarKey = json['pgCarKey']
    ..imgProfile = json['imgProfile']
    ..dtmStart = json['dtmStart']
    ..dtmLoad = json['dtmLoad']
    ..dtmUnload = json['dtmUnload']
    ..dtmFine = json['dtmFine']
    ..ynAccident = json['ynAccident']
    ..ynAccidentText = json['ynAccidentText']
    ..dtmAccident = json['dtmAccident']
    ..rmkCargo = json['rmkCargo']
    ..rmkUser = json['rmkUser']
    ..ynDrvrKpi = json['ynDrvrKpi'];
}

Map<String, dynamic> _$ModelToJson(TaxiOrderDetailModel instance) => <String, dynamic>{
      'idGroup': instance.idGroup,
      'cdMember': instance.cdMember,
      'cdComp': instance.cdComp,
      'nmComp': instance.nmComp,
      'cdCust': instance.cdCust,
      'nmCust': instance.nmCust,
      'dtOrdNo': instance.dtOrdNo,
      'seqOrdNo': instance.seqOrdNo,
      'dtmIns': instance.dtmIns,
      'idUsrIns': instance.idUsrIns,
      'nmUsrIns': instance.nmUsrIns,
      'dtmUpd': instance.dtmUpd,
      'idUsrUpd': instance.idUsrUpd,
      'nmUsrUpd': instance.nmUsrUpd,
      'ynShare': instance.ynShare,
      'ynShareText': instance.ynShareText,
      'dtmShare': instance.dtmShare,
      'ynReserve': instance.ynReserve,
      'ynReserveText': instance.ynReserveText,
      'dtmReserve': instance.dtmReserve,
      'dtOrdNoP': instance.dtOrdNoP,
      'seqOrdNoP': instance.seqOrdNoP,
      'noRefOrdNo': instance.noRefOrdNo,
      'divOrder': instance.divOrder,
      'divOrderText': instance.divOrderText,
      'divStatus': instance.divStatus,
      'divStatusText': instance.divStatusText,
      'divDispat': instance.divDispat,
      'divDispatText': instance.divDispatText,
      'divStatusOld': instance.divStatusOld,
      'divDevice': instance.divDevice,
      'rmkComp': instance.rmkComp,
      'idPers': instance.idPers,
      'cdCompPers': instance.cdCompPers,
      'nmPers': instance.nmPers,
      'ynOwn': instance.ynOwn,
      'ynOwnText': instance.ynOwnText,
      'noTelPers': instance.noTelPers,
      'noTelPersMy': instance.noTelPersMy,
      'ynHide': instance.ynHide,
      'ynHideText': instance.ynHideText,
      'nmLoad': instance.nmLoad,
      'postLoad': instance.postLoad,
      'addrRoadLoad': instance.addrRoadLoad,
      'addrBunjiLoad': instance.addrBunjiLoad,
      'addrLoad': instance.addrLoad,
      'lonLoad': instance.lonLoad,
      'latLoad': instance.latLoad,
      'dtmLoadReq': instance.dtmLoadReq,
      'dtmLoadEta': instance.dtmLoadEta,
      'nmUnload': instance.nmUnload,
      'postUnload': instance.postUnload,
      'addrRoadUnload': instance.addrRoadUnload,
      'addrBunjiUnload': instance.addrBunjiUnload,
      'addrUnload': instance.addrUnload,
      'lonUnload': instance.lonUnload,
      'latUnload': instance.latUnload,
      'dtmUnloadReq': instance.dtmUnloadReq,
      'dtmUnloadEta': instance.dtmUnloadEta,
      'ynUrgent': instance.ynUrgent,
      'ynUrgentText': instance.ynUrgentText,
      'divTar': instance.divTar,
      'divTarText': instance.divTarText,
      'distTar': instance.distTar,
      'tmTar': instance.tmTar,
      'amtTar': instance.amtTar,
      'cdCancel': instance.cdCancel,
      'cdCancelText': instance.cdCancelText,
      'rmkCancel': instance.rmkCancel,
      'divPay': instance.divPay,
      'divPayText': instance.divPayText,
      'divMethod': instance.divMethod,
      'divMethodText': instance.divMethodText,
      'divPg': instance.divPg,
      'divPgText': instance.divPgText,
      'amtPrice': instance.amtPrice,
      'amtExt': instance.amtExt,
      'amtOpt': instance.amtOpt,
      'amtDc': instance.amtDc,
      'ptsUse': instance.ptsUse,
      'ptsRtn': instance.ptsRtn,
      'ptsTake': instance.ptsTake,
      'ptsTakeDrvr': instance.ptsTakeDrvr,
      'ptsTakeComp': instance.ptsTakeComp,
      'cdCoup': instance.cdCoup,
      'noCoup': instance.noCoup,
      'amtCoup': instance.amtCoup,
      'amtPayHappy': instance.amtPayHappy,
      'amtSum': instance.amtSum,
      'amtPay': instance.amtPay,
      'amtRepay': instance.amtRepay,
      'extItem': instance.extItem,
      'noTidPg': instance.noTidPg,
      'cardName': instance.cardName,
      'cardBinType2Text': instance.cardBinType2Text,
      'cardNo': instance.cardNo,
      'btBatchKey': instance.btBatchKey,
      'divTax': instance.divTax,
      'divTaxText': instance.divTaxText,
      'seqEtax': instance.seqEtax,
      'divCr': instance.divCr,
      'divCrText': instance.divCrText,
      'noTidCr': instance.noTidCr,
      'idCarGroup': instance.idCarGroup,
      'cdCarMember': instance.cdCarMember,
      'cdCarComp': instance.cdCarComp,
      'nmCarComp': instance.nmCarComp,
      'noCar1': instance.noCar1,
      'noCar2': instance.noCar2,
      'noCar3': instance.noCar3,
      'noCar': instance.noCar,
      'idCarUser': instance.idCarUser,
      'nmCarUser': instance.nmCarUser,
      'noTelCarUser': instance.noTelCarUser,
      'cdCar': instance.cdCar,
      'cdCarText': instance.cdCarText,
      'divClass': instance.divClass,
      'divClassText': instance.divClassText,
      'divUsage': instance.divUsage,
      'divUsageText': instance.divUsageText,
      'divCarPg': instance.divCarPg,
      'divCarPgText': instance.divCarPgText,
      'divPgMethod': instance.divPgMethod,
      'divPgMethodText': instance.divPgMethodText,
      'pgCarMid': instance.pgCarMid,
      'pgCarKey': instance.pgCarKey,
      'imgProfile': instance.imgProfile,
      'dtmStart': instance.dtmStart,
      'dtmLoad': instance.dtmLoad,
      'dtmUnload': instance.dtmUnload,
      'dtmFine': instance.dtmFine,
      'ynAccident': instance.ynAccident,
      'ynAccidentText': instance.ynAccidentText,
      'dtmAccident': instance.dtmAccident,
      'rmkCargo': instance.rmkCargo,
      'rmkUser': instance.rmkUser,
      'ynDrvrKpi': instance.ynDrvrKpi,
    };
