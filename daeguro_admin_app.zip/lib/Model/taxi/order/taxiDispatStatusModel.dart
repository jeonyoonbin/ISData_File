import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiDispatStatusModel {
  TaxiDispatStatusModel();

  bool selected = false;
  String divDevice;
  String idUsrUpd;
  String nmUsrUpd;
  int cdComp;
  String dtOrdNo;
  int seqOrdNo;

  factory TaxiDispatStatusModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiDispatStatusModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiDispatStatusModel()

    ..selected = json['selected'] as bool
    ..divDevice = json['divDevice'] as String
    ..idUsrUpd = json['idUsrUpd'] as String
    ..nmUsrUpd = json['nmUsrUpd'] as String
    ..cdComp = json['cdComp'] as int
    ..dtOrdNo = json['dtOrdNo'] as String
    ..seqOrdNo = json['seqOrdNo'] as int;
}

Map<String, dynamic> _$ModelToJson(TaxiDispatStatusModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'divDevice': instance.divDevice,
  'idUsrUpd': instance.idUsrUpd,
  'nmUsrUpd': instance.nmUsrUpd,
  'cdComp': instance.cdComp,
  'dtOrdNo': instance.dtOrdNo,
  'seqOrdNo': instance.seqOrdNo,
};