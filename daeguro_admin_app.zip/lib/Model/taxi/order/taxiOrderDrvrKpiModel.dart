import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiOrderDrvrKpiModel {
  TaxiOrderDrvrKpiModel();

  bool selected = false;
  String cdComp;
  String idUser;
  String nmDrvr;
  String noCar1;
  String noCar2;
  String noCar3;
  String noCar;
  String dtOrdNo;
  String seqOrdNo;
  String cdRvw;
  String cdRvwText;
  String rmkRvw;
  String dtmIns;
  String cdScorComp;
  String cdScorCust;
  String idScorUser;
  String nmScorUser;

  factory TaxiOrderDrvrKpiModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiOrderDrvrKpiModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiOrderDrvrKpiModel()

    ..selected = json['selected'] as bool
    ..cdComp = json['cdComp'] as String
    ..idUser = json['idUser'] as String
    ..nmDrvr = json['nmDrvr'] as String
    ..noCar1 = json['noCar1'] as String
    ..noCar2 = json['noCar2'] as String
    ..noCar3 = json['noCar3'] as String
    ..noCar = json['noCar'] as String
    ..dtOrdNo = json['dtOrdNo'] as String
    ..seqOrdNo = json['seqOrdNo'] as String
    ..cdRvw = json['cdRvw'] as String
    ..cdRvwText = json['cdRvwText'] as String
    ..rmkRvw = json['rmkRvw'] as String
    ..dtmIns = json['dtmIns'] as String
    ..cdScorComp = json['cdScorComp'] as String
    ..cdScorCust = json['cdScorCust'] as String
    ..idScorUser = json['idScorUser'] as String
    ..nmScorUser = json['nmScorUser'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiOrderDrvrKpiModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'cdComp': instance.cdComp,
  'idUser': instance.idUser,
  'nmDrvr': instance.nmDrvr,
  'noCar1': instance.noCar1,
  'noCar2': instance.noCar2,
  'noCar3': instance.noCar3,
  'noCar': instance.noCar,
  'dtOrdNo': instance.dtOrdNo,
  'seqOrdNo': instance.seqOrdNo,
  'cdRvw': instance.cdRvw,
  'cdRvwText': instance.cdRvwText,
  'rmkRvw': instance.rmkRvw,
  'dtmIns': instance.dtmIns,
  'cdScorComp': instance.cdScorComp,
  'cdScorCust': instance.cdScorCust,
  'idScorUser': instance.idScorUser,
  'nmScorUser': instance.nmScorUser,
};