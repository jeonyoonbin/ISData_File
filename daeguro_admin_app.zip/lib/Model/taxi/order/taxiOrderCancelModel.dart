import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiOrderCancelModel {
  TaxiOrderCancelModel();

  bool selected = false;
  String divDevice;
  String idUsrUpd;
  String nmUsrUpd;
  int cdComp;
  String dtOrdNo;
  int seqOrdNo;
  String rmkCancel;

  factory TaxiOrderCancelModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiOrderCancelModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiOrderCancelModel()

    ..selected = json['selected'] as bool
    ..divDevice = json['divDevice'] as String
    ..idUsrUpd = json['idUsrUpd'] as String
    ..nmUsrUpd = json['nmUsrUpd'] as String
    ..cdComp = json['cdComp'] as int
    ..dtOrdNo = json['dtOrdNo'] as String
    ..seqOrdNo = json['seqOrdNo'] as int
    ..rmkCancel = json['rmkCancel'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiOrderCancelModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'divDevice': instance.divDevice,
  'idUsrUpd': instance.idUsrUpd,
  'nmUsrUpd': instance.nmUsrUpd,
  'cdComp': instance.cdComp,
  'dtOrdNo': instance.dtOrdNo,
  'seqOrdNo': instance.seqOrdNo,
  'rmkCancel': instance.rmkCancel,
};