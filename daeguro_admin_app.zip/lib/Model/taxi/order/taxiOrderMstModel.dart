import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiOrderMstModel {
  TaxiOrderMstModel();

  bool selected = false;
  bool viewSelected;
  String idGroup;
  String cdMember;
  String cdComp;
  String nmComp;
  String dtOrdNo;
  String seqOrdNo;
  String divOrderText;
  String divStatusText;
  String idPers;
  String nmPers;
  String noTelPers;
  String nmLoad;
  String nmUnload;
  String dtmStart;
  String dtmFine;
  String dtmIns;

  factory TaxiOrderMstModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiOrderMstModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiOrderMstModel()

    ..selected = json['selected'] as bool
    ..viewSelected = json['viewSelected'] as bool
    ..idGroup = json['idGroup'] as String
    ..cdMember = json['cdMember'] as String
    ..cdComp = json['cdComp'] as String
    ..nmComp = json['nmComp'] as String
    ..dtOrdNo = json['dtOrdNo'] as String
    ..seqOrdNo = json['seqOrdNo'] as String
    ..divOrderText = json['divOrderText'] as String
    ..divStatusText = json['divStatusText'] as String
    ..idPers = json['idPers'] as String
    ..nmPers = json['nmPers'] as String
    ..noTelPers = json['noTelPers'] as String
    ..nmLoad = json['nmLoad'] as String
    ..nmUnload = json['nmUnload'] as String
    ..dtmStart = json['dtmStart'] as String
    ..dtmFine = json['dtmFine'] as String
    ..dtmIns = json['dtmIns'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiOrderMstModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'viewSelected': instance.viewSelected,
  'idGroup': instance.idGroup,
  'cdMember': instance.cdMember,
  'cdComp': instance.cdComp,
  'nmComp': instance.nmComp,
  'dtOrdNo': instance.dtOrdNo,
  'seqOrdNo': instance.seqOrdNo,
  'divOrderText': instance.divOrderText,
  'divStatusText': instance.divStatusText,
  'idPers': instance.idPers,
  'nmPers': instance.nmPers,
  'noTelPers': instance.noTelPers,
  'nmLoad': instance.nmLoad,
  'nmUnload': instance.nmUnload,
  'dtmStart': instance.dtmStart,
  'dtmFine': instance.dtmFine,
  'dtmIns': instance.dtmIns
};