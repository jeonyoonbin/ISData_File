import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
// ignore: camel_case_types
class taxiCouponDisposalModel {
  taxiCouponDisposalModel();

  String divDevice;
  String idUsrUpd;
  String nmUsrUpd;
  String noCoup;
  int cdComp;
  String dtOrdNo;
  int seqOrdNo;

  factory taxiCouponDisposalModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

taxiCouponDisposalModel _$ModelFromJson(Map<String, dynamic> json) {
  return taxiCouponDisposalModel()
    ..divDevice = json['divDevice'] as String
    ..idUsrUpd = json['idUsrUpd'] as String
    ..nmUsrUpd = json['nmUsrUpd'] as String
    ..noCoup = json['noCoup'] as String
    ..cdComp = json['cdComp'] as int
    ..dtOrdNo = json['dtOrdNo'] as String
    ..seqOrdNo = json['seqOrdNo'] as int;
}

Map<String, dynamic> _$ModelToJson(taxiCouponDisposalModel instance) => <String, dynamic>{
  'divDevice': instance.divDevice,
  'idUsrUpd': instance.idUsrUpd,
  'nmUsrUpd': instance.nmUsrUpd,
  'noCoup': instance.noCoup,
  'cdComp': instance.cdComp,
  'dtOrdNo': instance.dtOrdNo,
  'seqOrdNo': instance.seqOrdNo
};