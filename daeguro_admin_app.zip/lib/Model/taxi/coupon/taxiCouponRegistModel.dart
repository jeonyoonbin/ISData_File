import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
// ignore: camel_case_types
class taxiCouponRegistModel {
  taxiCouponRegistModel();

  String idUsrIns;
  String nmUsrIns;
  int cdComp;
  String cdCoup;
  int cntCoup;

  factory taxiCouponRegistModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

taxiCouponRegistModel _$ModelFromJson(Map<String, dynamic> json) {
  return taxiCouponRegistModel()
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..cdComp = json['cdComp'] as int
    ..cdCoup = json['cdCoup'] as String
    ..cntCoup = json['cntCoup'] as int;
}

Map<String, dynamic> _$ModelToJson(taxiCouponRegistModel instance) => <String, dynamic>{
  'idUsrIns': instance.idUsrIns,
  'nmUsrIns': instance.nmUsrIns,
  'cdComp': instance.cdComp,
  'cdCoup': instance.cdCoup,
  'cntCoup': instance.cntCoup
};