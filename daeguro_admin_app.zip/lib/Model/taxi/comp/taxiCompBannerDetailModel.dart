import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiCompBannerDetailModel {
  TaxiCompBannerDetailModel();

  bool selected = false;
  String cdComp;
  String seqDisp;
  String subject;
  String dtStart;
  String dtEnd;
  String ynOpen;
  String urlLink;
  String nmFileReal;
  String nmFile;
  String imgWidth;
  String imgHeight;

  factory TaxiCompBannerDetailModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiCompBannerDetailModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiCompBannerDetailModel()

    ..selected = json['selected'] as bool
    ..cdComp = json['cdComp'] as String
    ..seqDisp = json['seqDisp'] as String
    ..subject = json['subject'] as String
    ..dtStart = json['dtStart'] as String
    ..dtEnd = json['dtEnd'] as String
    ..ynOpen = json['ynOpen'] as String
    ..urlLink = json['urlLink'] as String
    ..nmFileReal = json['nmFileReal'] as String
    ..nmFile = json['nmFile'] as String
    ..imgWidth = json['imgWidth'] as String
    ..imgHeight = json['subject'] as String;

}

Map<String, dynamic> _$ModelToJson(TaxiCompBannerDetailModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'cdComp': instance.cdComp,
  'seqDisp': instance.seqDisp,
  'subject': instance.subject,
  'dtStart': instance.dtStart,
  'dtEnd': instance.dtEnd,
  'ynOpen': instance.ynOpen,
  'urlLink': instance.urlLink,
  'nmFileReal': instance.nmFileReal,
  'nmFile': instance.nmFile,
  'imgWidth': instance.imgWidth,
  'imgHeight': instance.imgHeight
};