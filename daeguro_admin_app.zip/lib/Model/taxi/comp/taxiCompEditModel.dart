import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
// ignore: camel_case_types
class TaxiCompEditModel {
  TaxiCompEditModel();

  String idUsrIns;
  String nmUsrIns;
  int cdComp =0;
  String nmComp;
  String idGroup;
  int cdMember =0;
  String divComp;
  String lvComp;
  String noBusi;
  String noTel;
  String noFax;
  String ynUse;
  String cdBank;
  String noAcc;
  String nmAccOwner;
  String divTax;
  String ynTax;
  String divVatCharge;
  String taxEmail;
  String rmkSummary;
  String rmk;
  int cntDayTrans =0;
  int amtDayTrans =0;
  int cntMonTrans =0;
  int amtMonTrans =0;
  int amtMinSave =0;
  String ynPts;
  String ynRePts;
  String divPts;
  String unitPts;
  int amtMinPay;
  int dayUse =0;
  int amtPts =0;
  int amtMinOrder =0;
  int amtMinUse =0;
  int amtMinPts =0;
  String ynPtsCoupon;
  int amtMinCoupon =0;
  String divPayHappy;
  String unitPayHappy;
  int amtPayHappy =0;
  int amtCut =0;
  String urlCs;
  String divBusi;
  String noSoId;
  String divPg;
  String divPgMethod;
  String pgMid;
  String pgKey;
  String ynCert;
  String idUsrDeny;
  int ptsJoin =0;
  int ptsRecom =0;
  int ptsRecomUsr =0;

  factory TaxiCompEditModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiCompEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiCompEditModel()
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..cdComp = json['cdComp'] as int
    ..nmComp = json['nmComp'] as String
    ..idGroup = json['idGroup'] as String
    ..cdMember = json['cdMember'] as int
    ..divComp = json['divComp'] as String
    ..lvComp = json['lvComp'] as String
    ..noBusi = json['noBusi'] as String
    ..noTel = json['noTel'] as String
    ..noFax = json['noFax'] as String
    ..ynUse = json['ynUse'] as String
    ..cdBank = json['cdBank'] as String
    ..noAcc = json['noAcc'] as String
    ..nmAccOwner = json['nmAccOwner'] as String
    ..divTax = json['divTax'] as String
    ..ynTax = json['ynTax'] as String
    ..divVatCharge = json['divVatCharge'] as String
    ..taxEmail = json['taxEmail'] as String
    ..rmkSummary = json['rmkSummary'] as String
    ..rmk = json['rmk'] as String
    ..cntDayTrans = json['cntDayTrans'] as int
    ..amtDayTrans = json['amtDayTrans'] as int
    ..cntMonTrans = json['cntMonTrans'] as int
    ..amtMonTrans = json['amtMonTrans'] as int
    ..amtMinSave = json['amtMinSave'] as int
    ..ynPts = json['ynPts'] as String
    ..ynRePts = json['ynRePts'] as String
    ..divPts = json['divPts'] as String
    ..unitPts = json['unitPts'] as String
    ..amtMinPay = json['amtMinPay'] as int
    ..dayUse = json['dayUse'] as int
    ..amtPts = json['amtPts'] as int
    ..amtMinOrder = json['amtMinOrder'] as int
    ..amtMinUse = json['amtMinUse'] as int
    ..amtMinPts = json['amtMinPts'] as int
    ..ynPtsCoupon = json['ynPtsCoupon'] as String
    ..amtMinCoupon = json['amtMinCoupon'] as int
    ..divPayHappy = json['divPayHappy'] as String
    ..unitPayHappy = json['unitPayHappy'] as String
    ..amtPayHappy = json['amtPayHappy'] as int
    ..amtCut = json['amtCut'] as int
    ..urlCs = json['urlCs'] as String
    ..divBusi = json['divBusi'] as String
    ..noSoId = json['noSoId'] as String
    ..divPg = json['divPg'] as String
    ..divPgMethod = json['divPgMethod'] as String
    ..pgMid = json['pgMid'] as String
    ..pgKey = json['pgKey'] as String
    ..ynCert = json['ynCert'] as String
    ..idUsrDeny = json['idUsrDeny'] as String
    ..ptsJoin = json['ptsJoin'] as int
    ..ptsRecom = json['ptsRecom'] as int
    ..ptsRecomUsr = json['ptsRecomUsr'] as int;
}

Map<String, dynamic> _$ModelToJson(TaxiCompEditModel instance) => <String, dynamic>{
      'idUsrIns': instance.idUsrIns,
      'nmUsrIns': instance.nmUsrIns,
      'cdComp': instance.cdComp,
      'nmComp': instance.nmComp,
      'idGroup': instance.idGroup,
      'cdMember': instance.cdMember,
      'divComp': instance.divComp,
      'lvComp': instance.lvComp,
      'noBusi': instance.noBusi,
      'noTel': instance.noTel,
      'noFax': instance.noFax,
      'ynUse': instance.ynUse,
      'cdBank': instance.cdBank,
      'noAcc': instance.noAcc,
      'nmAccOwner': instance.nmAccOwner,
      'divTax': instance.divTax,
      'ynTax': instance.ynTax,
      'divVatCharge': instance.divVatCharge,
      'taxEmail': instance.taxEmail,
      'rmkSummary': instance.rmkSummary,
      'rmk': instance.rmk,
      'cntDayTrans': instance.cntDayTrans,
      'amtDayTrans': instance.amtDayTrans,
      'cntMonTrans': instance.cntMonTrans,
      'amtMonTrans': instance.amtMonTrans,
      'amtMinSave': instance.amtMinSave,
      'ynPts': instance.ynPts,
      'ynRePts': instance.ynRePts,
      'divPts': instance.divPts,
      'unitPts': instance.unitPts,
      'amtMinPay': instance.amtMinPay,
      'dayUse': instance.dayUse,
      'amtPts': instance.amtPts,
      'amtMinOrder': instance.amtMinOrder,
      'amtMinUse': instance.amtMinUse,
      'amtMinPts': instance.amtMinPts,
      'ynPtsCoupon': instance.ynPtsCoupon,
      'amtMinCoupon': instance.amtMinCoupon,
      'divPayHappy': instance.divPayHappy,
      'unitPayHappy': instance.unitPayHappy,
      'amtPayHappy': instance.amtPayHappy,
      'amtCut': instance.amtCut,
      'urlCs': instance.urlCs,
      'divBusi': instance.divBusi ,
      'noSoId': instance.noSoId + '"',
      'divPg': instance.divPg,
      'divPgMethod': instance.divPgMethod,
      'pgMid': instance.pgMid,
      'pgKey': '"'+ instance.pgKey,
      'ynCert': instance.ynCert,
      'idUsrDeny':instance.idUsrDeny,
      'ptsJoin': instance.ptsJoin,
      'ptsRecom': instance.ptsRecom,
      'ptsRecomUsr': instance.ptsRecomUsr,
    };
