import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiCompBannerModel {
  TaxiCompBannerModel();

  bool selected = false;
  String cdComp;
  String seqDisp;
  String subject;
  String dtStart;
  String dtEnd;
  String ynOpen;
  String urlLink;
  String cntRead;
  String nmFileReal;
  String nmFile;

  factory TaxiCompBannerModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiCompBannerModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiCompBannerModel()
    ..selected = json['selected'] as bool
    ..cdComp = json['cdComp'] as String
    ..seqDisp = json['seqDisp'] as String
    ..subject = json['subject'] as String
    ..dtStart = json['dtStart'] as String
    ..dtEnd = json['dtEnd'] as String
    ..ynOpen = json['ynOpen'] as String
    ..urlLink = json['urlLink'] as String
    ..cntRead = json['cntRead'] as String
    ..nmFileReal = json['nmFileReal'] as String
    ..nmFile = json['nmFile'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiCompBannerModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'cdComp': instance.cdComp,
  'seqDisp': instance.seqDisp,
  'subject': instance.subject,
  'dtStart': instance.dtStart,
  'dtEnd': instance.dtEnd,
  'ynOpen': instance.ynOpen,
  'urlLink': instance.urlLink,
  'cntRead': instance.cntRead,
  'nmFileReal': instance.nmFileReal,
  'nmFile': instance.nmFile
};
