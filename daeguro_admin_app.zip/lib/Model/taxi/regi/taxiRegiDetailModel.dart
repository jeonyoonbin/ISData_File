import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiRegiDetailModel {
  TaxiRegiDetailModel();

  String nmBusi;
  String noBusi;
  String noCorp;
  String nmOwner;
  String taxType;
  String divBusi;
  String addrBusi;
  String addrDtl;
  String busiItem;
  String busiType;

  factory TaxiRegiDetailModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiRegiDetailModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiRegiDetailModel()
    ..nmBusi = json['nmBusi'] as String
    ..noBusi = json['noBusi'] as String
    ..noCorp = json['noCorp'] as String
    ..nmOwner = json['nmOwner'] as String
    ..taxType = json['taxType'] as String
    ..divBusi = json['divBusi'] as String
    ..addrBusi = json['addrBusi'] as String
    ..addrDtl = json['addrDtl'] as String
    ..busiItem = json['busiItem'] as String
    ..busiType = json['busiType'] as String;

}

Map<String, dynamic> _$ModelToJson(TaxiRegiDetailModel instance) => <String, dynamic>{
  'nmBusi': instance.nmBusi,
  'noBusi': instance.noBusi,
  'noCorp': instance.noCorp,
  'nmOwner': instance.nmOwner,
  'taxType': instance.taxType,
  'divBusi': instance.divBusi,
  'addrBusi': instance.addrBusi,
  'addrDtl': instance.addrDtl,
  'busiItem': instance.busiItem,
  'busiType': instance.busiType
};