import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiRegiListModel {
  TaxiRegiListModel();

  bool selected = false;
  bool viewSelected;
  String nmBusi;
  String noBusi;
  String nmOwner;
  String taxType;
  String taxTypeText;
  String divBusi;
  String divBusiText;
  String busiSidoGungu;

  factory TaxiRegiListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiRegiListModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiRegiListModel()

    ..selected = json['selected'] as bool
    ..viewSelected = json['viewSelected'] as bool
    ..nmBusi = json['nmBusi'] as String
    ..noBusi = json['noBusi'] as String
    ..nmOwner = json['nmOwner'] as String
    ..taxType = json['taxType'] as String
    ..taxTypeText = json['taxTypeText'] as String
    ..divBusi = json['divBusi'] as String
    ..divBusiText = json['divBusiText'] as String
    ..busiSidoGungu = json['busiSidoGungu'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiRegiListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'viewSelected': instance.viewSelected,
  'nmBusi': instance.nmBusi,
  'noBusi': instance.noBusi,
  'nmOwner': instance.nmOwner,
  'taxType': instance.taxType,
  'taxTypeText': instance.taxTypeText,
  'divBusi': instance.divBusi,
  'divBusiText': instance.divBusiText,
  'busiSidoGungu': instance.busiSidoGungu
};