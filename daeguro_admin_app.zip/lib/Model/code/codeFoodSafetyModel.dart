import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CodeFoodSafetyModel {
  CodeFoodSafetyModel();

  String code;
  String nutrition;
  String allergy;
  String modUcode;
  String modName;

  factory CodeFoodSafetyModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

CodeFoodSafetyModel _$ModelFromJson(Map<String, dynamic> json) {
  return CodeFoodSafetyModel()
    ..code = json['code'] as String
    ..nutrition = json['nutrition'] as String
    ..allergy = json['allergy'] as String
    ..modUcode = json['modUcode'] as String
    ..modName = json['modName'] as String;
}

Map<String, dynamic> _$ModelToJson(CodeFoodSafetyModel instance) => <String, dynamic>{
  'code': instance.code,
  'nutrition': instance.nutrition,
  'allergy': instance.allergy,
  'modUcode': instance.modUcode,
  'modName': instance.modName
};
