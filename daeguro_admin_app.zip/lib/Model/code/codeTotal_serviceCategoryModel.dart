class CodeTotalServiceCategoryModel {
  CodeTotalServiceCategoryModel();

  bool selected = false;
  String gbn_code;
  String gbn_name;
  String use_gbn;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
}
