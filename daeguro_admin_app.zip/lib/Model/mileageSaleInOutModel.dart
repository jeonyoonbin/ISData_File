
class mileageSaleInOutModel {
  mileageSaleInOutModel();

  int MCODE = 0;
  String MNAME;
  String MEMO;
  String FR_DATE;
  String TO_DATE;
  String GBN_NM;
  int LOG_CUST_MILEAGE = 0;
  int IN_CNT = 0;
  int IN_AMT = 0;
  int ORDER_IN_CNT = 0;
  int ORDER_IN_AMT = 0;
  int SALE_IN_CNT = 0;
  int SALE_IN_AMT = 0;
  int TAXI_IN_CNT = 0;
  int TAXI_IN_AMT = 0;
  int ORDER_OUT_AMT = 0;
  int TAXI_OUT_AMT1 = 0;
  int TAXI_OUT_AMT2 = 0;
  int OUT_AMT = 0;
}