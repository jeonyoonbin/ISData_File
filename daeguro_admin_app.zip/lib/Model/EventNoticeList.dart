import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class EventNoticeList {
  EventNoticeList();

  String notice_seq;
  String notice_title;
  String disp_fr_date;
  String disp_to_date;
}


