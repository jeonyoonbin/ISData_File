import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class PayMentShinhanCancelModel {
  PayMentShinhanCancelModel();

  int server_type;
  String order_no;
  String cancel_type;
  String ip_addr;

  factory PayMentShinhanCancelModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

PayMentShinhanCancelModel _$ModelFromJson(Map<String, dynamic> json) {
  return PayMentShinhanCancelModel()
    ..server_type = json['server_type'] as int
    ..order_no = json['order_no'] as String
    ..cancel_type = json['cancel_type'] as String
    ..ip_addr = json['ip_addr'] as String;
}

Map<String, dynamic> _$ModelToJson(PayMentShinhanCancelModel instance) => <String, dynamic>{
  'server_type': instance.server_type,
  'order_no': instance.order_no,
  'cancel_type': instance.cancel_type,
  'ip_addr': instance.ip_addr,
};