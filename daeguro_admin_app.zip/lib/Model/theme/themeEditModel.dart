import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ThemeEditModel {
  ThemeEditModel();

  bool selected = false;
  String thema_code;
  String name;
  String use_gbn;
  String test_yn;
  String memo;
  String ucode;

  factory ThemeEditModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ThemeEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ThemeEditModel()
  //..selected = json['selected'] as bool
    ..thema_code = json['thema_code'] as String
    ..name = json['name'] as String
    ..use_gbn = json['use_gbn'] as String
    ..test_yn = json['test_yn'] as String
    ..memo = json['memo'] as String
    ..ucode = json['ucode'] as String;
}

Map<String, dynamic> _$ModelToJson(ThemeEditModel instance) => <String, dynamic>{
  //'selected': instance.selected,
  'thema_code': instance.thema_code,
  'name': instance.name,
  'use_gbn': instance.use_gbn,
  'test_yn': instance.test_yn,
  'memo': instance.memo,
  'ucode': instance.ucode
};
