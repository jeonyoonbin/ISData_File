
class B2BUsercouponListModel {
  B2BUsercouponListModel();

  int RNUM;
  int USER_ID;
  String NAME;
  String LOGIN_ID;
  String MOBILE;
  String COUPON_TYPE;
  String REG_DATE;
  String USE_YN;
}