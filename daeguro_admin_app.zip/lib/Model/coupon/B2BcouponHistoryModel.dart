
class B2BcouponHistoryModel {
  B2BcouponHistoryModel();

  String seqNo;
  String couponType;
  String couponNo;
  String histDate;
  String memo;

}
