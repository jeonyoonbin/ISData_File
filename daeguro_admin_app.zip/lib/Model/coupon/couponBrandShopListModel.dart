
class couponBrandShopListModel {
  couponBrandShopListModel();

  int RNUM;
  String SHOP_CD;
  String SHOP_NAME;
  String COUPON_TYPE;
  String CODE_NM;
  String USE_YN;
  int USE_MAX_COUNT = 0;
}
