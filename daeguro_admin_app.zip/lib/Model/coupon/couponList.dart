﻿
class couponList {
  couponList();

  bool selected = false;
  String couponType;
  String couponName;
  String couponNo;
  String randomNo;
  String barCode;
  String status;
  String appCustCode;
  String custName;
  String telNo;
  String useAppCustCode;
  String useCustName;
  String useTelNo;
  String orderDate;
  String orderNo;
  String useDate;
  String couponAmt;
  String linkUrl;
  String insDate;
  String insUCode;
  String insName;
  String expDate;
  String stDate;
  String confYN;
  String confDate;
  String confUCode;
  String confName;
  String shopName;
  String shopCd;
  String serviceGbn;
}


