
class couponBrandListModel {
  couponBrandListModel();

  bool selected = false;
  String RNUM;
  String COUPON_TYPE;
  String COUPON_NAME;
  String COUPON_NO;
  String RANDOM_NO;
  String BARCODE;
  String STATUS;
  String APP_SHOP_CODE;
  String SHOP_NAME;
  String APP_CUST_CODE;
  String CUST_NAME;
  String TELNO;
  String USE_APP_CUST_CODE;
  String USE_CUST_NAME;
  String USE_TELNO;
  String ORDER_DATE;
  String USE_DATE;
  String COUPON_AMT;
  String LINK_URL;
  String INS_DATE;
  String INS_UCODE;
  String INS_NAME;
  String EXP_DATE;
  String ST_DATE;
  String CONF_YN;
  String CONF_DATE;
  String CONF_UCODE;
  String CONF_NAME;
  String ORDER_NO;
}


