import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
// ignore: camel_case_types
class couponBrandAppDetailModel {
  couponBrandAppDetailModel();

  String coupon_type;
  String coupon_name;
  String chain_code;
  String chain_name;
  String order_min_amt;
  String pay_min_amt;
  String delivery_yn;
  String pack_yn;
  String display_st_date;
  String display_st_time;
  String display_exp_date;
  String display_exp_time;
  String use_yn;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;

  factory couponBrandAppDetailModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

couponBrandAppDetailModel _$ModelFromJson(Map<String, dynamic> json) {
  return couponBrandAppDetailModel()
    ..coupon_type = json['coupon_type'] as String
    ..coupon_name = json['coupon_name'] as String
    ..chain_code = json['chain_code'] as String
    ..chain_name = json['chain_name'] as String
    ..order_min_amt = json['order_min_amt'] as String
    ..pay_min_amt = json['pay_min_amt'] as String
    ..delivery_yn = json['delivery_yn'] as String
    ..pack_yn = json['pack_yn'] as String
    ..display_st_date = json['display_st_date'] as String
    ..display_st_time = json['display_st_time'] as String
    ..display_exp_date = json['display_exp_date'] as String
    ..display_exp_time = json['display_exp_time'] as String
    ..use_yn = json['use_yn'] as String
    ..ins_date = json['ins_date'] as String
    ..ins_ucode = json['ins_ucode'] as String
    ..ins_name = json['ins_name'] as String
    ..mod_date = json['mod_date'] as String
    ..mod_ucode = json['mod_ucode'] as String
    ..mod_name = json['mod_name'] as String;
}

Map<String, dynamic> _$ModelToJson(couponBrandAppDetailModel instance) => <String, dynamic>{
  'coupon_type': instance.coupon_type,
  'coupon_name': instance.coupon_name,
  'chain_code': instance.chain_code,
  'chain_name': instance.chain_name,
  'order_min_amt': instance.order_min_amt,
  'pay_min_amt': instance.pay_min_amt,
  'delivery_yn': instance.delivery_yn,
  'pack_yn': instance.pack_yn,
  'display_st_date': instance.display_st_date,
  'display_st_time': instance.display_st_time,
  'display_exp_date': instance.display_exp_date,
  'display_exp_time': instance.display_exp_time,
  'use_yn': instance.use_yn,

  'ins_date': instance.ins_date,
  'ins_ucode': instance.ins_ucode,
  'ins_name': instance.ins_name,
  'mod_date': instance.mod_date,
  'mod_ucode': instance.mod_ucode,
  'mod_name': instance.mod_name
};
