class ProdCategoryBundleModel {
  ProdCategoryBundleModel();

  bool selected;
  String m_shop_cd;
  String class_gbn;
  String cat_code;
  String name;
  String use_gbn;
  String sort_seq;
}