import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
// ignore: camel_case_types
class SubCategoryCreateModel {
  SubCategoryCreateModel();

  String class_gbn;
  String name;
  String ucode;

  factory SubCategoryCreateModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

SubCategoryCreateModel _$ModelFromJson(Map<String, dynamic> json) {
  return SubCategoryCreateModel()
    ..class_gbn = json['class_gbn'] as String
    ..name = json['name'] as String
    ..ucode = json['ucode'] as String;
}

Map<String, dynamic> _$ModelToJson(SubCategoryCreateModel instance) => <String, dynamic>{
  'class_gbn': instance.class_gbn,
  'name': instance.name,
  'ucode': instance.ucode
};