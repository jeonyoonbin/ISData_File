import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CategoryListModel {
  CategoryListModel();

  bool selected = false;
  bool isOpened = false;
  bool isChild = false;
  String class_gbn;
  String name;
  String base_gbn;
  String sort_seq;
  String use_gbn = 'Y';
  String cat_code = '';
}
