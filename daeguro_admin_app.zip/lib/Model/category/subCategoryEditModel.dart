import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class SubCategoryEditModel {
  SubCategoryEditModel();

  bool selected = false;
  String cat_code;
  String name;
  String use_gbn;
  String test_yn;
  String memo;
  String ucode;

  factory SubCategoryEditModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

SubCategoryEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return SubCategoryEditModel()
  //..selected = json['selected'] as bool
    ..cat_code = json['cat_code'] as String
    ..name = json['name'] as String
    ..use_gbn = json['use_gbn'] as String
    ..test_yn = json['test_yn'] as String
    ..memo = json['memo'] as String
    ..ucode = json['ucode'] as String;
}

Map<String, dynamic> _$ModelToJson(SubCategoryEditModel instance) => <String, dynamic>{
  //'selected': instance.selected,
  'cat_code': instance.cat_code,
  'name': instance.name,
  'use_gbn': instance.use_gbn,
  'test_yn': instance.test_yn,
  'memo': instance.memo,
  'ucode': instance.ucode
};
