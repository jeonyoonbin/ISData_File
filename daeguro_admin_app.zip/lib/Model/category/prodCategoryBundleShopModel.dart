class ProdCategoryBundleShopModel {
  ProdCategoryBundleShopModel();

  bool selected = false;
  bool isOpened = false;
  bool isChild = false;
  String m_shop_cd;
  String shop_name;
  String mcode;
  String cat_code = '';
}
