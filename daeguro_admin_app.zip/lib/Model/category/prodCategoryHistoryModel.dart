import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProdCategoryHistoryModel {
  ProdCategoryHistoryModel();

  bool selected = false;
  String seq;
  String hist_date;
  String hist_gbn;
  String memo;

  factory ProdCategoryHistoryModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ProdCategoryHistoryModel _$ModelFromJson(Map<String, dynamic> json) {
  return ProdCategoryHistoryModel()
    ..selected = json['selected'] as bool
    ..seq = json['seq'] as String
    ..hist_date = json['hist_date'] as String
    ..hist_gbn = json['hist_gbn'] as String
    ..memo = json['memo'] as String;

}

Map<String, dynamic> _$ModelToJson(ProdCategoryHistoryModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'seq': instance.seq,
  'hist_date': instance.hist_date,
  'hist_gbn': instance.hist_gbn,
  'memo': instance.memo
};