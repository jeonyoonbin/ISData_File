import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class SubCategoryListModel {
  SubCategoryListModel();

  bool selected;
  String class_gbn;
  String cat_code;
  String name;
  String use_gbn;
  String sort_seq;

  factory SubCategoryListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

SubCategoryListModel _$ModelFromJson(Map<String, dynamic> json) {
  return SubCategoryListModel()
    ..selected = json['selected'] as bool
    ..class_gbn = json['class_gbn'] as String
    ..cat_code = json['cat_code'] as String
    ..name = json['name'] as String
    ..use_gbn = json['use_gbn'] as String
    ..sort_seq = json['sort_seq'] as String;

}

Map<String, dynamic> _$ModelToJson(SubCategoryListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'class_gbn': instance.class_gbn,
  'cat_code': instance.cat_code,
  'name': instance.name,
  'use_gbn': instance.use_gbn,
  'sort_seq': instance.sort_seq
};