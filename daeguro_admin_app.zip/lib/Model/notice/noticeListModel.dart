
class noticeListModel {
  noticeListModel();

  bool selected = false;
  String noticeSeq;
  String noticeGbn;
  String systemGbn;
  String systemGbnM;
  String dispGbn;
  String dispFromDate;
  String dispToDate;
  String noticeTitle;
  String noticeContents;
  String noticeUrl_1;
  String noticeUrl_2;
  String noticeUrl_3;
  String hit;
  String orderDate;
  String insDate;
  String insUCode;
  String insName;
  String modUCode;
  String modName;
  String modDate;
  String noticeType;
}
