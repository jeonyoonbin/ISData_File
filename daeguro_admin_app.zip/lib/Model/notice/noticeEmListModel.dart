
class noticeEmListModel {
  noticeEmListModel();

  bool selected = false;
  String seq;
  String use;
  String title;
  String device_gbn;
  String contents;
  String url;
  String img_url;
  String android_ver;
  String android_min;
  String ios_ver;
  String ios_min;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
}
