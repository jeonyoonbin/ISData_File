import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class noticeEmPay2Model {
  noticeEmPay2Model();

  String pay_gbn;
  String app_pay_gbn;
  String pay_name;
  String able_yn;
  String disorder_msg;


  factory noticeEmPay2Model.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

noticeEmPay2Model _$ModelFromJson(Map<String, dynamic> json) {
  return noticeEmPay2Model()
    ..pay_gbn = json['pay_gbn'] as String
    ..app_pay_gbn = json['app_pay_gbn'] as String
    ..pay_name = json['pay_name'] as String
    ..able_yn = json['able_yn'] as String
    ..disorder_msg = json['disorder_msg'] as String;
}

Map<String, dynamic> _$ModelToJson(noticeEmPay2Model instance) => <String, dynamic>{
  'pay_gbn': instance.pay_gbn,
  'app_pay_gbn': instance.app_pay_gbn,
  'pay_name': instance.pay_name,
  'able_yn': instance.able_yn,
  'disorder_msg': instance.disorder_msg
};
