import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class noticeEmPayModel {
  noticeEmPayModel();

  bool selected = false;

  // String payBtn_use;
  // String device_gbn;
  // String contents_Card;
  // String contents_HappyPay;
  // String contents_KakaoPay;
  // String contents_NaverPay;
  // String contents_SamsungPay;
  //
  // String contents_ApplePay;
  // String contents_ZeroPay;
  // String contents_OnnuriVoucher;
  // String contents_Toss;
  // String contents_ShinhanPG;
  //
  // String contents_DirectCash;
  // String contents_DirectCard;

  String seq;
  String disorder_divice_gbn;
  String card_yn;
  String card_msg;
  String happy_pay_yn;
  String happy_pay_msg;
  String kakao_yn;
  String kakao_msg;
  String naver_yn;
  String naver_msg;
  String samsung_yn;
  String samsung_msg;
  String meet_cash_yn;
  String meet_cash_msg;
  String meet_card_yn;
  String meet_card_msg;
  String zero_pay_yn;
  String zero_pay_msg;
  String onnuri_vc_yn;
  String onnuri_vc_msg;
  String toss_yn;
  String toss_msg;
  String apple_pay_yn;
  String apple_pay_msg;

  String shinhan_pg_yn;
  String shinhan_pg_msg;

  String child_card_yn;
  String child_card_msg;

  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
  String ucode;


  factory noticeEmPayModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

noticeEmPayModel _$ModelFromJson(Map<String, dynamic> json) {
  return noticeEmPayModel()
    ..selected = json['selected'] as bool
    ..seq = json['seq'] as String
    ..disorder_divice_gbn = json['disorder_divice_gbn'] as String
    ..card_yn = json['card_yn'] as String
    ..card_msg = json['card_msg'] as String
    ..happy_pay_yn = json['happy_pay_yn'] as String
    ..happy_pay_msg = json['happy_pay_msg'] as String
    ..kakao_yn = json['kakao_yn'] as String
    ..kakao_msg = json['kakao_msg'] as String
    ..naver_yn = json['naver_yn'] as String
    ..naver_msg = json['naver_msg'] as String
    ..samsung_yn = json['samsung_yn'] as String
    ..samsung_msg = json['samsung_msg'] as String
    ..meet_cash_yn = json['meet_cash_yn'] as String
    ..meet_cash_msg = json['meet_cash_msg'] as String
    ..meet_card_yn = json['meet_card_yn'] as String
    ..meet_card_msg = json['meet_card_msg'] as String
    ..zero_pay_yn = json['zero_pay_yn'] as String
    ..zero_pay_msg = json['zero_pay_msg'] as String
    ..onnuri_vc_yn = json['onnuri_vc_yn'] as String
    ..onnuri_vc_msg = json['onnuri_vc_msg'] as String
    ..toss_yn = json['toss_yn'] as String
    ..toss_msg = json['toss_msg'] as String
    ..apple_pay_yn = json['apple_pay_yn'] as String
    ..apple_pay_msg = json['apple_pay_msg'] as String
    ..shinhan_pg_yn = json['shinhan_pg_yn'] as String
    ..shinhan_pg_msg = json['shinhan_pg_msg'] as String
    ..child_card_yn = json['child_card_yn'] as String
    ..child_card_msg = json['child_card_msg'] as String
    ..ucode = json['ucode'] as String;
}

Map<String, dynamic> _$ModelToJson(noticeEmPayModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'seq': instance.seq,
  'disorder_divice_gbn': instance.disorder_divice_gbn,
  'card_yn': instance.card_yn,
  'card_msg': instance.card_msg,
  'happy_pay_yn': instance.happy_pay_yn,
  'happy_pay_msg': instance.happy_pay_msg,
  'kakao_yn': instance.kakao_yn,
  'kakao_msg': instance.kakao_msg,
  'naver_yn': instance.naver_yn,
  'naver_msg': instance.naver_msg,
  'samsung_yn': instance.samsung_yn,
  'samsung_msg': instance.samsung_msg,
  'meet_cash_yn': instance.meet_cash_yn,
  'meet_cash_msg': instance.meet_cash_msg,
  'meet_card_yn': instance.meet_card_yn,
  'meet_card_msg': instance.meet_card_msg,
  'zero_pay_yn': instance.zero_pay_yn,
  'zero_pay_msg': instance.zero_pay_msg,
  'onnuri_vc_yn': instance.onnuri_vc_yn,
  'onnuri_vc_msg': instance.onnuri_vc_msg,
  'toss_yn': instance.toss_yn,
  'toss_msg': instance.toss_msg,
  'apple_pay_yn': instance.apple_pay_yn,
  'apple_pay_msg': instance.apple_pay_msg,
  'shinhan_pg_yn': instance.shinhan_pg_yn,
  'shinhan_pg_msg': instance.shinhan_pg_msg,
  'child_card_yn': instance.child_card_yn,
  'child_card_msg': instance.child_card_msg,
  'ucode': instance.ucode,
};
