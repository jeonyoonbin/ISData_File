
class mileageInOutModel {
  mileageInOutModel();

  String RNUM;
  int MCODE = 0;
  String MNAME;
  String CUST_GBN;
  String CUST_GBN_NM;
  int CUST_CODE = 0;
  String CUST_NAME;
  int CUST_MILEAGE = 0;
  int LOG_CUST_MILEAGE = 0;
  int IN_CNT = 0;
  int IN_AMT = 0;
  int ORDER_IN_CNT = 0;
  int ORDER_IN_AMT = 0;
  int SALE_IN_CNT = 0;
  int SALE_IN_AMT = 0;
  int TAXI_IN_CNT = 0;
  int TAXI_IN_AMT = 0;
  int ORDER_OUT_AMT = 0;
  int TAXI_OUT_AMT = 0;
  int OUT_AMT = 0;
  int TERMINATE_AMT = 0;
}