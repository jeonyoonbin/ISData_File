import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class logTaxListModel {
  logTaxListModel();

  bool selected = false;
  String SEQ;
  String ERROR_GBN;
  String DIV;
  String INS_TIME;
  String POSITION;
  String ERROR_MSG;
  String INS_UCODE;
  String USER_NAME;
  String PARAMETER;
}

