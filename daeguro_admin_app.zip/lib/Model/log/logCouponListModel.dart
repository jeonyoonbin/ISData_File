import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class logCouponListModel {
  logCouponListModel();

  bool selected = false;
  String SEQ;
  String TYPE_GBN;
  String DIV;
  String HIST_DATE;
  String POSITION;
  String MSG;
  String INS_UCODE;
  String USER_NAME;
  String PARAMETER;
}