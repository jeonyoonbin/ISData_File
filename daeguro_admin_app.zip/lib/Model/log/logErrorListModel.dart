import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class logErrorListModel {
  logErrorListModel();

  bool selected = false;
  String SEQ;
  String DIV;
  String POSITION;
  String MSG;
  String INSERT_TIME;
}