import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class logPrivacyListModel {
  logPrivacyListModel();

  bool selected = false;
  String SEQ;
  String UCODE;
  String USER_NAME;
  String LOG_TIME;
  String PID;
  String PNAME;
  String LOG_GBN;
  String POSITION;
  String CONTENT;
  String IP;
}

