import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class LogProgramNameListModel {
  LogProgramNameListModel();

  bool selected = false;
  String id;
  String name;

  factory LogProgramNameListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

LogProgramNameListModel _$ModelFromJson(Map<String, dynamic> json) {
  return LogProgramNameListModel()
    ..selected = json['selected'] as bool
    ..id = json['id'] as String
    ..name = json['name'] as String;
}

Map<String, dynamic> _$ModelToJson(LogProgramNameListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'id': instance.id,
  'name': instance.name
};