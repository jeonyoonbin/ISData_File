import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class logAuthListModel {
  logAuthListModel();

  String NO;
  String ID;
  String NAME;
  String USER_NAME;
  String MEMO;
  String HIST_DATE;
  String MOD_UCODE;
  String MOD_NAME;
  String DIV;
}