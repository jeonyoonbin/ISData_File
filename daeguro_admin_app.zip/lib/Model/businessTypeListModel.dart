
class BuinessTypeListModel {

  bool isOpened = false;
  bool isChild = false;
  String p_gungu;
  String gungu;
  int total;
  int menuName_1013;
  int menuName_1014;
  int menuName_9000;
  int menuName_1001;
  int menuName_1003;
  int menuName_1004;
  int menuName_1005;
  int menuName_1006;
  int menuName_1007;
  int menuName_1008;
  int menuName_1024;
  int menuName_1025;
  int menuName_1026;
  int menuName_1000;
  int menuName_1027;
  int menuName_1028;
  int menuName_1029;
  int menuName_1030;
  int menuName_1031;
  int menuName_1032;
  int menuName_1033;

  BuinessTypeListModel({
    this.isOpened,
    this.isChild,
    this.p_gungu,
    this.gungu,
    this.total,
    this.menuName_1013,
    this.menuName_1014,
    this.menuName_9000,
    this.menuName_1001,
    this.menuName_1003,
    this.menuName_1004,
    this.menuName_1005,
    this.menuName_1006,
    this.menuName_1007,
    this.menuName_1008,
    this.menuName_1024,
    this.menuName_1025,
    this.menuName_1026,
    this.menuName_1000,
    this.menuName_1027,
    this.menuName_1028,
    this.menuName_1029,
    this.menuName_1030,
    this.menuName_1031,
    this.menuName_1032,
    this.menuName_1033
  });
}