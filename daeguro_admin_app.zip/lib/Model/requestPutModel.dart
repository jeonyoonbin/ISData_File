import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
// ignore: camel_case_types
class RequestPutModel {
  RequestPutModel();

  String seq;
  String status;
  String alloc_ucode;
  String alloc_uname;
  String worker_ucode;
  String worker_name;
  String answer;
  String memo;
  String mod_ucode;
  String mod_name;

  factory RequestPutModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

RequestPutModel _$ModelFromJson(Map<String, dynamic> json) {
  return RequestPutModel()
    ..seq = json['seq'] as String
    ..status = json['status'] as String
    ..alloc_ucode = json['alloc_ucode'] as String
    ..alloc_uname = json['alloc_uname'] as String
    ..worker_ucode = json['alloc_ucode'] as String
    ..worker_name = json['alloc_uname'] as String
    ..answer = json['answer'] as String
    ..memo = json['memo'] as String
    ..mod_ucode = json['mod_ucode'] as String
    ..mod_name = json['mod_name'] as String;
}

Map<String, dynamic> _$ModelToJson(RequestPutModel instance) => <String, dynamic>{
  'seq': instance.seq,
  'status': instance.status,
  'alloc_ucode': instance.alloc_ucode,
  'alloc_uname': instance.alloc_uname,
  'worker_ucode': instance.worker_ucode,
  'worker_name': instance.worker_name,
  'answer': instance.answer,
  'memo': instance.memo,
  'mod_ucode': instance.mod_ucode,
  'mod_name': instance.mod_name,
};
