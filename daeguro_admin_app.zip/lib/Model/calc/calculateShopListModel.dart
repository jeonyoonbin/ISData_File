
class calculateShopListModel {
  calculateShopListModel();

  bool selected = false;

  int RNUM;
  int mcode;
  String cccode;
  String shop_cd;
  String shop_name;
  int remain_amt;
}