
class CalculateOrderPayMentModel {
  CalculateOrderPayMentModel();

  int RNUM;
  int ORDER_NO ;
  String ORDER_DATE;
  String ORDER_DATE_P;
  String ORDER_TIME;
  String STATUS;
  String SHOP_NAME;
  int CCODE;
  String CUST_NAME;
  String TELNO;
  int MENU_AMT;
  int DELI_TIP_AMT;
  int TOT_AMT;
  int COUPON_AMT;
  int MILEAGE_USE_AMT;
  int ETC_DISC_AMT;
  int DISC_AMT;
  int AMOUNT;
  String CARD_APPROVAL_GBN;
  String PAY_GBN;
  String APP_PAY_GBN;
  int PGM_AMT;
  int PG_PGM_AMT;
  int PGM_SUM_AMT;
  String SERVICE_GBN;
}
