
class calculateShopMileageModel {
  calculateShopMileageModel();

  bool selected = false;

  // 신규 UI
  int RNUM;
  int SEQNO;
  int MCODE;
  String CCCODE;
  String CCNAME;
  String SERVICE_GBN;
  String SHOP_CD;
  String SHOP_NAME;
  String ORDER_DATE;
  String CHARGE_DATE;
  String CHARGE_GBN;
  String IO_GBN;
  int CHARGE_AMT;
  int IN_AMT;
  int OUT_AMT;
  int CHARGE_UCODE;
  String MEMO;
  int ORDER_NO;
  int PRE_AMT;
  String CHARGE_NAME;
  String CHARGE_GBN_NM;
}