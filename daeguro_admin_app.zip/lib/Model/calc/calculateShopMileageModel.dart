
class calculateShopMileageModel {
  calculateShopMileageModel();

  bool selected = false;

  // 신규 UI
  int RNUM;
  int MCODE;
  String CCCODE;
  String SHOP_CD;
  String SHOP_NAME;
  int REMAIN_AMT;
  int ALL_AMT;
  int IN_AMT;
  int P_AMT;
  int K_AMT;
  int TAKE_COUNT;
  int TAKE_AMT;
}