
class CalculateSearchShopTaxModel {
  CalculateSearchShopTaxModel();

  bool selected = false;
  String orderYm;
  String mcode;
  String cccode;
  String shopCd;
  String shopName;
  String issymd;
  String taxNo;
  String taxGbn;
  String saleGbn;
  String supamt;
  String vatamt;
  String amt;
  String memo;
  String prtYn;
  String prtDate;
  String prtGbn;
  String etaxYn;
  String reqDate;
  String status;
  String rtnMsg;
  String rtnDate;
  String isrtUcode;
  String isrtDate;
  String modUcode;
  String modDate;
  String canReason;
  String receiptId;
  String etaxSeq;
  String taxAcc;
  String feeYm;
  String fdiaGbn;
  String apiComGbn;
  String cret_yn;
  String mName;
  String mainCcname;
  String regNo;
}
