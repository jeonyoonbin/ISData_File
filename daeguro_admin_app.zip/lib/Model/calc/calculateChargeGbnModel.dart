import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CalculateChargeGbnModel {
  CalculateChargeGbnModel();

  bool selected = false;
  String charge_gbn;
  String charge_name;
  String sort_seq;

  factory CalculateChargeGbnModel.fromJson(Map<String,dynamic> json) =>
      _$ModelFromJson(json);

  Map<String,dynamic> toJson() => _$ModelToJson(this);
}

CalculateChargeGbnModel _$ModelFromJson(Map<String, dynamic> json) {
  return CalculateChargeGbnModel()
    ..selected = json['selected'] as bool
    ..charge_gbn = json['charge_gbn'] as String
    ..charge_name = json['charge_name'] as String
    ..sort_seq = json['sort_seq'] as String;
}

Map<String,dynamic> _$ModelToJson(CalculateChargeGbnModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'charge_gbn': instance.charge_gbn,
  'charge_name': instance.charge_name,
  'sort_seq': instance.sort_seq,
};