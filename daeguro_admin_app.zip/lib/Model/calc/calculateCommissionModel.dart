
class CalculateCommissionModel {
  CalculateCommissionModel();

  bool selected = false;
  String yymm;
  String ccName;
  String shopCd;
  String shopName;
  String telNo;
  String regNo;
  String regNoStatus;
  String taxNo;
  int pgmInAmt;
  int pgmOutAmt;
  int pgmAmt;
  int totCnt;
  int compCnt;
  int cancelCnt;
  String prtYn;
  String status;
}