
class CalculateCcMileageModel {
  CalculateCcMileageModel();

  bool selected = false;
  int rNum;
  int seqNo;
  String ccCode;
  String ccName;
  String orderDate;
  String chargeDate;
  String chargeGbn;
  String chargeGbnNm;
  int preAmt;
  int inAmt;
  int outAmt;
  int chargeUcode;
  String chargeName;
  String memo;
  int mCode;
  String mName;
  String groupId;
  int orderNo;
  String shopCd;
  String shopName;
  int orderMcode;
  int preAmtSum;
}