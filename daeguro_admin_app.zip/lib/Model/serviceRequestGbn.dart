import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ServiceRequestGbn {
  ServiceRequestGbn();

  bool selected = false;

  //요청 구분
  int GBN_CODE;
  String GBN_NAME;

  // 요청내용
  String CODE;
  String CODE_NM;

  factory ServiceRequestGbn.fromJson(Map<String,dynamic> json) =>
      _$ModelFromJson(json);

  Map<String,dynamic> toJson() => _$ModelToJson(this);
}

ServiceRequestGbn _$ModelFromJson(Map<String, dynamic> json) {
  return ServiceRequestGbn()
    ..selected = json['selected'] as bool
    ..GBN_CODE = json['GBN_CODE'] as int
    ..GBN_NAME = json['GBN_NAME'] as String
    ..CODE = json['CODE'] as String
    ..CODE_NM = json['CODE_NM'] as String;
}

Map<String,dynamic> _$ModelToJson(ServiceRequestGbn instance) => <String, dynamic>{
  'selected': instance.selected,
  'GBN_CODE': instance.GBN_CODE,
  'GBN_NAME': instance.GBN_NAME,
  'CODE': instance.CODE,
  'CODE_NM': instance.CODE_NM
};