﻿import 'dart:convert';

import 'package:daeguro_admin_app/Model/page_model.dart';
import 'package:daeguro_admin_app/Util/tree_vo.dart';




class Menu extends TreeData {
  String id;
  String pid;
  String subsystemId;
  String name;
  String tab_name;
  String icon;
  String url;
  String pname;
  bool visible = true;

  toPage() {
    return PageModel(
      id: id,
      name: tab_name==null ? name : tab_name, //name,
      url: url,
    );
  }

  Menu({
    this.id,
    this.pid,
    this.subsystemId,
    this.name,
    this.tab_name,
    this.icon,
    this.url,
    this.pname,
    this.visible
  }) : super(id, pid);

  Menu copyWith({
    String id,
    String pid,
    String subsystemId,
    String name,
    String tab_name,
    String icon,
    String url,
    String pname,
    bool visible
  }) {
    return Menu(
      id: id ?? this.id,
      pid: pid ?? this.pid,
      subsystemId: subsystemId ?? this.subsystemId,
      name: name ?? this.name,
      tab_name: tab_name ?? this.tab_name,
      icon: icon ?? this.icon,
      url: url ?? this.url,
      pname: pname ?? this.pname,
      visible: visible ?? this.visible,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'pid': pid,
      'subsystemId': subsystemId,
      'name': name,
      'tab_name': tab_name,
      'icon': icon,
      'url': url,
      'pname': pname,
      'visible': visible,
    };
  }

  factory Menu.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return Menu(
      id: map['id'],
      pid: map['pid'],
      subsystemId: map['subsystemId'],
      name: map['name'],
      tab_name: map['tab_name'],
      icon: map['icon'],
      url: map['url'],
      pname: map['pname'],
      visible: map['visible'],
    );
  }

  String toJson() => json.encode(toMap());

  factory Menu.fromJson(String source) => Menu.fromMap(json.decode(source));

  @override
  String toString() {
    return 'Menu(id: $id, pid: $pid, subsystemId: $subsystemId, checked: $checked, name: $name, tab_name: $tab_name, icon: $icon, url: $url, pname: $pname, visible: $visible)';
  }

  @override
  bool operator ==(Object o) {
    if (identical(this, o)) return true;

    return o is Menu &&
        o.id == id &&
        o.pid == pid &&
        o.subsystemId == subsystemId &&
        o.name == name &&
        o.tab_name == tab_name &&
        o.icon == icon &&
        o.url == url &&
        o.pname == pname &&
        o.visible == visible;
  }

  @override
  int get hashCode {
    return id.hashCode ^
    pid.hashCode ^
    subsystemId.hashCode ^
    name.hashCode ^
    tab_name.hashCode ^
    icon.hashCode ^
    url.hashCode ^
    pname.hashCode ^
    visible.hashCode;
  }
}
