import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class logDetailModel {
  logDetailModel();

  bool selected = false;
  int SEQ;
  String DIV;
  String POSITION;
  String MSG;
  String INSERT_TIME;

  factory logDetailModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

logDetailModel _$ModelFromJson(Map<String, dynamic> json) {
  return logDetailModel()
    ..selected = json['selected'] as bool
    ..SEQ = json['SEQ'] as int
    ..DIV = json['DIV'] as String
    ..POSITION = json['POSITION'] as String
    ..MSG = json['MSG'] as String
    ..INSERT_TIME = json['INSERT_TIME'] as String;
}

Map<String, dynamic> _$ModelToJson(logDetailModel instance) => <String, dynamic> {
  'selected': instance.selected,
  'SEQ': instance.SEQ,
  'DIV': instance.DIV,
  'POSITION': instance.POSITION,
  'MSG': instance.MSG,
  'INSERT_TIME': instance.INSERT_TIME
};