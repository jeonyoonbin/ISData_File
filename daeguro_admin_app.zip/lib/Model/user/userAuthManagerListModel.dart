import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class UserAuthManagerListModel {
  UserAuthManagerListModel();

  bool selected = false;
  bool defaultItem = false;
  String program_id;
  String program_name;
  bool auth_read;
  bool auth_add;
  bool auth_save;
  bool auth_del;
  bool auth_masking;

  factory UserAuthManagerListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

UserAuthManagerListModel _$ModelFromJson(Map<String, dynamic> json) {
  return UserAuthManagerListModel()
    ..selected = json['selected'] as bool
    ..program_id = json['program_id'] as String
    ..program_name = json['program_name'] as String
    ..auth_read = json['auth_read'] as bool
    ..auth_add = json['auth_add'] as bool
    ..auth_save = json['auth_save'] as bool
    ..auth_del = json['auth_del'] as bool
    ..auth_masking = json['auth_masking'] as bool;
}

Map<String, dynamic> _$ModelToJson(UserAuthManagerListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'program_id': instance.program_id,
  'program_name': instance.program_name,
  'auth_read': instance.auth_read,
  'auth_add': instance.auth_add,
  'auth_save': instance.auth_save,
  'auth_del': instance.auth_del,
  'auth_masking': instance.auth_masking
};
