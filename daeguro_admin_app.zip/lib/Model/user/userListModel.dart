
class UserListModel {
  UserListModel();

  bool selected = false;
  String uCode;
  String ccCode;
  String id;
  String name;
  String insertDate;
  String retireDate;
  String level;
  String memo;
  String working;
}