class PaymentDetailModel {
  PaymentDetailModel();

  bool selected = false;
  String pay_gbn;
  String app_pay_gbn;
  String pay_name;
  String use_gbn;
  String login_yn;
  String benefit_yn;
  String notice_yn;
  String notice;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
}
