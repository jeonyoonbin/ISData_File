
class PaymentInfoHistoryModel {
  PaymentInfoHistoryModel();

  bool selected = false;
  String no;
  String insertDate;
  String memo;
}