import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
// ignore: camel_case_types
class PaymentUpdateModel {
  PaymentUpdateModel();

  String pay_gbn;
  String app_pay_gbn;
  String benefit_yn;
  String notice_yn;
  String notice;
  String mod_ucode;

  factory PaymentUpdateModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

PaymentUpdateModel _$ModelFromJson(Map<String, dynamic> json) {
  return PaymentUpdateModel()
    ..pay_gbn = json['pay_gbn'] as String
    ..app_pay_gbn = json['app_pay_gbn'] as String
    ..benefit_yn = json['benefit_yn'] as String
    ..notice_yn = json['notice_yn'] as String
    ..notice = json['notice'] as String
    ..mod_ucode = json['mod_ucode'] as String;
}

Map<String, dynamic> _$ModelToJson(PaymentUpdateModel instance) => <String, dynamic>{
  'pay_gbn': instance.pay_gbn,
  'app_pay_gbn': instance.app_pay_gbn,
  'benefit_yn': instance.benefit_yn,
  'notice_yn': instance.notice_yn,
  'notice': instance.notice,
  'mod_ucode': instance.mod_ucode
};
