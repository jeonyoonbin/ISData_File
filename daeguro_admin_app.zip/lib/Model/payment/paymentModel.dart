class PaymentModel {
  PaymentModel();

  bool selected = false;
  String pay_gbn;
  String app_pay_gbn;
  String pay_name;
  String use_gbn;
  String benefit_yn;
  String notice_yn;
}
