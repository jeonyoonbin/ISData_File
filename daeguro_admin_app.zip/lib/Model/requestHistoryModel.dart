
class RequestHistoryModel {
  RequestHistoryModel();

  bool selected = false;
  String no;
  String insertDate;
  String memo;
}