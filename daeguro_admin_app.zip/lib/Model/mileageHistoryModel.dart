
class mileageHistoryModel {
  mileageHistoryModel();

  int ORDER_NO = 0;
  String LOG_DATE;
  String CUST_NAME;
  String CUST_CODE;
  int MILEAGE_AMT = 0;
  int MILEAGE_USE_AMT = 0;
  String SHOP_NAME;
  String SHOP_CD;
  String MEMO;
  String SERVICE_GBN;
}