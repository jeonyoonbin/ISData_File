
class RequestListModel {
  RequestListModel();

  bool selected = false;
  String SEQ;
  String INSERT_DATE;
  String SHOP_CD;
  String SHOP_NAME;
  String STATUS;
  String SERVICE_GBN;
  String SERVICE_GBN_CODE;
  String SERVICE_TYPE;
  String SERVICE_TYPE_CODE;
  String CANCEL_REQ_YN;
  String COMP_TM;
  String CANCEL_TM;
  int ALLOC_UCODE;
  String ALLOC_UNAME;
  int WORKER_UCODE;
  String WORKER_NAME;
  String MEMO;
  String ANSWER_TEXT;
}