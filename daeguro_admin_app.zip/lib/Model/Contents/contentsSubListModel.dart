
class ContentsSubListModel {
  ContentsSubListModel();

  bool viewSelected = false;
  int SEQ;
  int SORT_SEQ;
  String EP_TITLE;
  String DISP_GBN;
  int HIT;
  String INS_DATE;
  int INS_UCODE;
}
