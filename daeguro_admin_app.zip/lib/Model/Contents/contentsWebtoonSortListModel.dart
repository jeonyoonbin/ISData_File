import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ContentsWebtoonSrotListModel {
  ContentsWebtoonSrotListModel();

  bool selected = false;
  int CONTENTS_CD;
  String CONTENTS_TITLE;

  factory ContentsWebtoonSrotListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ContentsWebtoonSrotListModel _$ModelFromJson(Map<String, dynamic> json) {
  return ContentsWebtoonSrotListModel()
    ..selected = json['selected'] as bool
    ..CONTENTS_CD = json['CONTENTS_CD'] as int
    ..CONTENTS_TITLE = json['CONTENTS_TITLE'] as String;
}

Map<String, dynamic> _$ModelToJson(ContentsWebtoonSrotListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'CONTENTS_CD': instance.CONTENTS_CD,
  'CONTENTS_TITLE': instance.CONTENTS_TITLE
};
