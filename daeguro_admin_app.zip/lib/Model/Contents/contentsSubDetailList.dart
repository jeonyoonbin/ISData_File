import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ContentsSubDetailList {
  ContentsSubDetailList();

  bool selected = false;
  int SEQ;
  int SORT_SEQ;
  String EP_TITLE;
  String DISP_GBN;
  String DISP_ST_DATE;
  int HIT;
  String CONTENTS_URL;
  String THUMBNAIL_URL;
  String INS_DATE;
  int INS_UCODE;
  String MOD_DATE;
  int MOD_UCODE;

  factory ContentsSubDetailList.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ContentsSubDetailList _$ModelFromJson(Map<String, dynamic> json) {
  return ContentsSubDetailList()
    ..selected = json['selected'] as bool
    ..SEQ = json['SEQ'] as int
    ..SORT_SEQ = json['SORT_SEQ'] as int
    ..EP_TITLE = json['EP_TITLE'] as String
    ..DISP_GBN = json['DISP_GBN'] as String
    ..DISP_ST_DATE = json['DISP_ST_DATE'] as String
    ..HIT = json['HIT'] as int
    ..CONTENTS_URL = json['CONTENTS_URL'] as String
    ..THUMBNAIL_URL = json['THUMBNAIL_URL'] as String
    ..INS_DATE = json['INS_DATE'] as String
    ..INS_UCODE = json['INS_UCODE'] as int
    ..MOD_DATE = json['MOD_DATE'] as String
    ..MOD_UCODE = json['MOD_UCODE'] as int;
}

Map<String, dynamic> _$ModelToJson(ContentsSubDetailList instance) => <String, dynamic>{
  'selected': instance.selected,
  'SEQ': instance.SEQ,
  'SORT_SEQ': instance.SORT_SEQ,
  'EP_TITLE': instance.EP_TITLE,
  'DISP_GBN': instance.DISP_GBN,
  'DISP_ST_DATE': instance.DISP_ST_DATE,
  'HIT': instance.HIT,
  'CONTENTS_URL': instance.CONTENTS_URL,
  'THUMBNAIL_URL': instance.THUMBNAIL_URL,
  'INS_DATE': instance.INS_DATE,
  'INS_UCODE': instance.INS_UCODE,
  'MOD_DATE': instance.MOD_DATE,
  'MOD_UCODE': instance.MOD_UCODE,
};
