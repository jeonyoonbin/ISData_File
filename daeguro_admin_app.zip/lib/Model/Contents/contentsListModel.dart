
class ContentsListModel {
  ContentsListModel();

  bool viewSelected = false;
  int RNUM;
  int CONTENTS_CD;
  String CONTENTS_TITLE;
  String DISP_GBN;
  int DISP_SEQ;
  String INS_DATE;
  int INS_UCODE;
}
