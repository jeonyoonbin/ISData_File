
class OrderCompleteToCancelModel {
  OrderCompleteToCancelModel();

  bool selected = false;
  String orderNo;
  String payGbn;
  String orderTime;
  String shopTelNo;
  String regNo;
  String serviceGbn;
  String shopName;
  String orderAmount;
  String status;
  String custCode;
  String customerTelNo;
  String tuid;
  String cardName;
  String appNo;
  String cardAmount;
  String directPay;
  String custIdGbn;
  String posInstalled;
  String posLogined;
  String shopCd;
  String cancelReason;
  String cancelType;
  String apiComCode;
  String packOrderYn;

  String modeUcode;
  String modeName;
}