class OrderCongratsBookMarkModel {
  OrderCongratsBookMarkModel();

  bool selected = false;
  String category_name;
  String bookmark_cd;
  String words_code;
  String contents;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;
}
