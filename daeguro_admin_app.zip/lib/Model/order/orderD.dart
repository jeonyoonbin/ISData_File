import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OrderAccountMenuD {

  String menuCode;
  int cost;
  int menuCost;
  int saleCost;
  int count;
  String menuName;
  String eventYn;
  String listOption;
}
