class OrderCongratsCategoryModel {
  OrderCongratsCategoryModel();

  bool selected = false;
  String category_code;
  String category_name;
  String use_gbn;
}
