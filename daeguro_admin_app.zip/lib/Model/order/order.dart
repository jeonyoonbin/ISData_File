﻿import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OrderAccount {
  OrderAccount();

  bool selected = false;
  int ORDER_NO;
  String SERVICE_GBN;
  String PAY_GBN;
  String ORDER_TIME;
  String SHOP_TELNO;
  String REG_NO;
  String SHOP_NAME;
  int ORDER_AMOUNT;
  String STATUS;
  String CUSTOMER_TELNO;
  String TUID;
  String CARD_NAME;
  String APP_NO;
  int CARD_AMOUNT;
  String DIRECT_PAY;
  String CUST_ID_GBN;
  String POS_INSTALL;
  String POS_LOGIN;
  String SHOP_CD;
  String CANCEL_TYPE;
  String API_COM_CODE;
  String PACK_ORDER_YN;
  String cardApprovalGbn;
  String RIDER_DELI_MEMO;
  String SHOP_DELI_MEMO;
  String APP_PAY_GBN;
  String APP_CUST_CODE;
  int REMAIN_AMT;
  String CANCEL_REASON;

  String modeUcode;
  String modeName;
}