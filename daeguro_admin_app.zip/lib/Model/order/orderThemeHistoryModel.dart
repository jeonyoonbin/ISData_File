import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OrderThemeHistoryModel {
  OrderThemeHistoryModel();

  bool selected = false;
  String memo;
  String histDate;

  factory OrderThemeHistoryModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

OrderThemeHistoryModel _$ModelFromJson(Map<String, dynamic> json) {
  return OrderThemeHistoryModel()
    ..selected = json['selected'] as bool
    ..memo = json['memo'] as String
    ..histDate = json['histDate'] as String;

}

Map<String, dynamic> _$ModelToJson(OrderThemeHistoryModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'memo': instance.memo,
  'histDate': instance.histDate
};