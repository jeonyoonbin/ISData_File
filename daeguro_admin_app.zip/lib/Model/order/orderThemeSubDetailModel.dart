import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OrderThemeSubDetailModel {
  OrderThemeSubDetailModel();

  bool selected = false;
  String temaName;
  String sido;
  String gungu;
  String temaMemo;
  String useGbn;
  String openYn;
  String testYn;
  String lon;
  String lat;
  String addr;
  String memo;

  factory OrderThemeSubDetailModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

OrderThemeSubDetailModel _$ModelFromJson(Map<String, dynamic> json) {
  return OrderThemeSubDetailModel()
  //..selected = json['selected'] as bool
    ..temaName = json['temaName'] as String
    ..sido = json['sido'] as String
    ..gungu = json['gungu'] as String
    ..temaMemo = json['temaMemo'] as String
    ..useGbn = json['useGbn'] as String
    ..openYn = json['openYn'] as String
    ..testYn = json['testYn'] as String
    ..lon = json['lon'] as String
    ..lat = json['lat'] as String
    ..addr = json['addr'] as String
    ..memo = json['memo'] as String;
}

Map<String, dynamic> _$ModelToJson(OrderThemeSubDetailModel instance) => <String, dynamic>{
  //'selected': instance.selected,
  'temaName': instance.temaName,
  'sido': instance.sido,
  'gungu': instance.gungu,
  'temaMemo': instance.temaMemo,
  'useGbn': instance.useGbn,
  'openYn': instance.openYn,
  'testYn': instance.testYn,
  'lon': instance.lon,
  'lat': instance.lat,
  'addr': instance.addr,
  'memo': instance.memo
};
