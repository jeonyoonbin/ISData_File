import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OrderThemeMainListModel {
  OrderThemeMainListModel();

  bool selected = false;
  bool isOpened = false;
  bool isChild = false;
  String code;
  String subcode;
  String nameMain;
  String useGbn;
}
