import 'package:json_annotation/json_annotation.dart';

class OrderThemeShopListModel {
  OrderThemeShopListModel();

  bool selected;
  String shopName;
  String shopCd;
  String regNo;
  String addr1;
  String addr2;
  String useGbn;
}