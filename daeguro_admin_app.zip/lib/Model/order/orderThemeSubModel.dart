import 'package:json_annotation/json_annotation.dart';

class OrderThemeSubModel {
  OrderThemeSubModel();

  bool selected;
  String temaCode;
  String subTemaCode;
  String temaName;
  String sido;
  String gungu;
  String temaMemo;
  String useGbn;
  int sortSeq;
  String url;
  int lon;
  int lat;
  String addr;
}