import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class pushRequestModel {
  pushRequestModel();

  String push_cd;
  String push_title;
  String send_gbn;
  String push_gbn;
  String item1;
  String reserve_send_dt;
  String object_gbn;
  String range_gbn;
  String marketing_push_gbn;
  String push_msg;
  List<String> telno;
  String ucode;

  factory pushRequestModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

pushRequestModel _$ModelFromJson(Map<String, dynamic> json) {
  return pushRequestModel()
    ..push_cd = json['push_cd'] as String
    ..push_title = json['push_title'] as String
    ..send_gbn = json['send_gbn'] as String
    ..push_gbn = json['push_gbn'] as String
    ..item1 = json['item1'] as String
    ..reserve_send_dt = json['reserve_send_dt'] as String
    ..object_gbn = json['object_gbn'] as String
    ..range_gbn = json['range_gbn'] as String
    ..marketing_push_gbn = json['marketing_push_gbn'] as String
    ..push_msg = json['push_msg'] as String
    ..telno = json['telno'] as List<String>
    ..ucode = json['ins_date'] as String;
}

Map<String, dynamic> _$ModelToJson(pushRequestModel instance) => <String, dynamic>{
  'push_cd': instance.push_cd,
  'push_title': instance.push_title,
  'send_gbn': instance.send_gbn,
  'push_gbn': instance.push_gbn,
  'item1': instance.item1,
  'reserve_send_dt': instance.reserve_send_dt,
  'object_gbn': instance.object_gbn,
  'range_gbn': instance.range_gbn,
  'marketing_push_gbn': instance.marketing_push_gbn,
  'push_msg': instance.push_msg,
  'telno': instance.telno,
  'ucode': instance.ucode,
};
