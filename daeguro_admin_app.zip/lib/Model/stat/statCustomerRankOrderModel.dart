
class StatCustomerRankOrderModel {
  StatCustomerRankOrderModel();

  int ORDER_COUNT = 0;
  String CUST_NAME;
  String TELNO;
}
