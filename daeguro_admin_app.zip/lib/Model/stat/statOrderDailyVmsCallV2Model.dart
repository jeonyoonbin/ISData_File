class StatOrderDailyVmsCallV2Model {
  StatOrderDailyVmsCallV2Model();

  String dt;
  String success_cnt;
  String s_receipt_cnt;
  String s_cancel_cnt;
  String fail_cnt;
  String f_receipt_cnt;
  String f_cancel_cnt;
}
