
class StatOrderDailyCancelReasonModel {
  StatOrderDailyCancelReasonModel();

  String ORDER_DATE;
  String CANCEL_CODE;
  int COUNT = 0;
  int COUNT_1 = 0;
  int COUNT_2 = 0;
  int COUNT_3 = 0;
  int COUNT_4 = 0;
  int COUNT_5 = 0;
  int COUNT_6 = 0;
  int COUNT_7 = 0;
  int COUNT_8 = 0;
  int COUNT_9 = 0;
  int COUNT_10 = 0;
  int COUNT_11 = 0;
  int COUNT_12 = 0;
  int COUNT_13 = 0;
  int COUNT_14 = 0;
  int COUNT_SUM = 0;
}
