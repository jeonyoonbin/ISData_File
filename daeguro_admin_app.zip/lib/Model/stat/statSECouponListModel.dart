
class StatSECouponListModel {
  StatSECouponListModel();

  String daily;
  String set_shop_cnt;
  String pub_cnt;
  String use_cnt;
  String exp_cnt;
  String du_cnt;
  String left_cnt;
}