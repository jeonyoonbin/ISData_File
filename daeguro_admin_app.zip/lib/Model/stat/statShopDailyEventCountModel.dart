
class StatShopDailyEventCountModel {
  StatShopDailyEventCountModel();

  String ORDER_DATE;

  // 날짜 세로로 변경
  int COMP_CNT = 0;
  int COMP_SUM = 0;
  int CANC_CNT = 0;
  int CANC_SUM = 0;
}