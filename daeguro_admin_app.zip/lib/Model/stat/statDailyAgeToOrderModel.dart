
class StatDailyAgeToOrderModel {
  StatDailyAgeToOrderModel();

  String ORDER_DATE;
  // 10대
  int A = 0;
  int A_COMP = 0;
  int A_CANC = 0;

  // 20대
  int B = 0;
  int B_COMP = 0;
  int B_CANC = 0;

  // 30대
  int C = 0;
  int C_COMP = 0;
  int C_CANC = 0;

  // 40대
  int D = 0;
  int D_COMP = 0;
  int D_CANC = 0;

  // 50대
  int E = 0;
  int E_COMP = 0;
  int E_CANC = 0;

  // 60대
  int F = 0;
  int F_COMP = 0;
  int F_CANC = 0;

  // 70대
  int G = 0;
  int G_COMP = 0;
  int G_CANC = 0;

  // 80대
  int H = 0;
  int H_COMP = 0;
  int H_CANC = 0;

  // 90대
  int I = 0;
  int I_COMP = 0;
  int I_CANC = 0;
}

