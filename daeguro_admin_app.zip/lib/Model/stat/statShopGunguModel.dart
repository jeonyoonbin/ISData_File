
class StatShopGunguModel {
  StatShopGunguModel();

  String OPEN_DATE;
  String GUNGU_NAME;
  int COUNT = 0;

  // 날짜 세로로 변경 (v2)
  int A = 0;
  int B = 0;
  int C = 0;
  int D = 0;
  int E = 0;
  int F = 0;
  int G = 0;
  int H = 0;
}

