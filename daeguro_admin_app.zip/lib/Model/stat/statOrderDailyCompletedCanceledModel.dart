
class StatOrderDailyCompletedCanceledModel {
  StatOrderDailyCompletedCanceledModel();

  String ORDER_DATE;
  String ORDER_STATE;
  int CNT = 0;
  int TOT_AMT = 0;
  int TOT_DELITIP = 0;
  int FIRST_COUPON = 0;
  int RE_COUPON = 0;
  int MILEAGE = 0;
  int HAPPYPAY_DISC = 0;

  // 취소 오더 정보 저장
  int C_CNT = 0;
  int C_TOT_AMT = 0;
  int C_TOT_DELITIP = 0;
  int C_FIRST_COUPON = 0;
  int C_RE_COUPON = 0;
  int C_MILEAGE = 0;
  int C_HAPPYPAY_DISC = 0;
}

