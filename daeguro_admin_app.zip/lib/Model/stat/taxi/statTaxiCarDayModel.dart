
class StatTaxiCarDayModel {
  StatTaxiCarDayModel();

  String INSERT_DATE;   // 등록일
  String PRIVATE_COUNT;   // 개인
  String CORPORATE_COUNT;   // 법인
  String TOTAL_COUNT;   // 합계
}

