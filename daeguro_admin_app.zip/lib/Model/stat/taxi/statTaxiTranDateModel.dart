
class StatTaxiTranDateModel {
  StatTaxiTranDateModel();

  String INSERT_DATE;   // 등록일
  String DRIVER;   // 기사
  String WORK; // 출근
  String DRIVE; // 운행
  String VACATION; // 운휴
  String LEAVE; // 배차
  String PUSH; // 푸시
  String CALL_OK; // 콜수락 시간
}

