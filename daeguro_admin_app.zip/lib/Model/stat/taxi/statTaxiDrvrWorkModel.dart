
class StatTaxiDrvrWorkModel {
  StatTaxiDrvrWorkModel();

  String GBN;   // 구분
  String TOTAL; // 전체
  String WORK; // 출근
  String DRIVE; // 운행
  String VACATION; // 운휴
  String LEAVE; // 퇴근
}

