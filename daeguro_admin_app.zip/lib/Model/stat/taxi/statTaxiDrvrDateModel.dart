
class StatTaxiDrvrDateModel {
  StatTaxiDrvrDateModel();

  String INSERT_DATE;   // 등록일
  String DAY;  // 요일
  String PRIVATE;  // 개인
  String CORPORATE;  // 법인
  String TOTAL;  // 합계
}

