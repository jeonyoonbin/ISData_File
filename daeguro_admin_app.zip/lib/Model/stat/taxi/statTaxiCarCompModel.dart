
class StatTaxiCarCompModel {
  StatTaxiCarCompModel();

  String COMP_NAME;   // 지점명
  String CAR_COUNT;   // 차량수
}

