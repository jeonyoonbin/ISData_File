
class StatTaxiDrvrStatusModel {
  StatTaxiDrvrStatusModel();

  String lV_USER_TEXT;   // 구분
  String WAIT; // 대기
  String HOLD; // 심사보류
  String REQUEST; // 재심사요청
  String JOIN; // 가입
  String PAUSE; // 일시중지
  String SECESSION_REQUEST; // 탈퇴요청
  String RESIGN; // 퇴사
  String SECESSION; // 탈퇴
}

