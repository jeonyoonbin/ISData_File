
class StatTaxiCompModel {
  StatTaxiCompModel();

  String COMP_NAME;   // 지점명
  String INSERT_DATE;   // 등록일
  String OPEN_YN;   // 운영여부
  String USER_COUNT;   // 사용자수
}

