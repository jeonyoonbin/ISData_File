
class StatTaxiOrderAnalyzeDayModel {
  StatTaxiOrderAnalyzeDayModel();

  String LINE_CNT;   // 개행 수
  String INSERT_DATE;   // 등록일
  String ORDER_DATE;   // 오더일
  String DAY;   // 요일
  String COMP; // 완료
  String TOTAL; // 전체
  String COMP_AVG; // 완료기사평균
  String COMP_TOP_DRIVER; // 완료상위기사
}

