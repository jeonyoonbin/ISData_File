
class StatTaxiDrvrCompModel {
  StatTaxiDrvrCompModel();

  String COMP_NAME;   // 지점명
  String USER_COUNT;  // 기사수
  String APPROVAL_COUNT;  // 승인 기사수
}

