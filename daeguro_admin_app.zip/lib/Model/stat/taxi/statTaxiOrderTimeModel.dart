
class StatTaxiOrderTimeModel {
  StatTaxiOrderTimeModel();

  String INSERT_DATE;   // 등록일
  String ORDER_DATE;   // 오더일
  String DAY;   // 요일
  String CALL;   // 호출
  String CALL_FAIL;   // 호출실패
  String DRIVE;   // 운행
  String COMP;   // 완료
  String CANCEL;   // 취소
  String CALL_RECEPT;   // 콜수신
  String TOTAL;   // 전체
  String MODIFICATION;   // 가감
  String JOIN;   // 가입
  String WORK;   // 출근
}

