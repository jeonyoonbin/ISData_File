
class StatOrderGunguModel {
  StatOrderGunguModel();

  String ORDER_DATE;

  // 날짜 세로로 되도록 수정
  int A;   // 남구
  int B;   // 달서구
  int C;   // 달성군
  int D;   // 동구
  int E;   // 북구
  int F;   // 서구
  int G;   // 수성구
  int H;   // 중구
  int I;   // 포장
}

