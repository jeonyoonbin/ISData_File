
class StatOrderGunguModel {
  StatOrderGunguModel();

  String ORDER_DATE;

  // 날짜 세로로 되도록 수정
  int A;   // 남구(주문)
  int A1;   // 남구(포장)
  int B;   // 달서구(주문)
  int B1;   // 달서구(포장)
  int C;   // 달성군(주문)
  int C1;   // 달성군(포장)
  int D;   // 동구(주문)
  int D1;   // 동구(포장)
  int E;   // 북구(주문)
  int E1;   // 북구(포장)
  int F;   // 서구(주문)
  int F1;   // 서구(포장)
  int G;   // 수성구(주문)
  int G1;   // 수성구(포장)
  int H;   // 중구(주문)
  int H1;   // 중구(포장)
  int I;   // 합계(주문)
  int I1;   // 합계(포장)
}

