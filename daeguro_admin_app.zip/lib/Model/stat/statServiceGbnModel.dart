
class StatServiceGbnModel {
  StatServiceGbnModel({
    this.STAT_DATE,
    this.TOT_CNT_0,
    this.COMP_CNT_0,
    this.CANCEL_CNT_0,
    this.ING_CNT_0,
    this.TOT_CNT_1,
    this.COMP_CNT_1,
    this.CANCEL_CNT_1,
    this.ING_CNT_1,
    this.TOT_CNT_2,
    this.COMP_CNT_2,
    this.CANCEL_CNT_2,
    this.ING_CNT_2,
    this.TOT_CNT_3,
    this.COMP_CNT_3,
    this.CANCEL_CNT_3,
    this.ING_CNT_3,
    this.TOT_CNT_4,
    this.COMP_CNT_4,
    this.CANCEL_CNT_4,
    this.ING_CNT_4,
    this.TOT_CNT_5,
    this.COMP_CNT_5,
    this.CANCEL_CNT_5,
    this.ING_CNT_5,
    this.TOT_CNT_6,
    this.COMP_CNT_6,
    this.CANCEL_CNT_6,
    this.ING_CNT_6,
    this.TOT_CNT_T,
    this.COMP_CNT_T,
    this.CANCEL_CNT_T,
    this.ING_CNT_T,
  });

  bool isOpened = false;
  String STAT_DATE;

  // 주문
  String TOT_CNT_0 = '0';
  int COMP_CNT_0 = 0;
  int CANCEL_CNT_0 = 0;
  int ING_CNT_0 = 0;
  String COMP_CNT_0_PER = '';
  String CANCEL_CNT_0_PER = '';
  String ING_CNT_0_PER = '';

  // 특별관
  String TOT_CNT_1 = '0';
  int COMP_CNT_1 = 0;
  int CANCEL_CNT_1 = 0;
  int ING_CNT_1 = 0;
  String COMP_CNT_1_PER = '';
  String CANCEL_CNT_1_PER = '';
  String ING_CNT_1_PER = '';

  // 꽃배달
  String TOT_CNT_2 = '0';
  int COMP_CNT_2 = 0;
  int CANCEL_CNT_2 = 0;
  int ING_CNT_2 = 0;
  String COMP_CNT_2_PER = '';
  String CANCEL_CNT_2_PER = '';
  String ING_CNT_2_PER = '';

  // 로컬푸드
  String TOT_CNT_3 = '0';
  int COMP_CNT_3 = 0;
  int CANCEL_CNT_3 = 0;
  int ING_CNT_3 = 0;
  String COMP_CNT_3_PER = '';
  String CANCEL_CNT_3_PER = '';
  String ING_CNT_3_PER = '';

  // 전통시장
  String TOT_CNT_4 = '0';
  int COMP_CNT_4 = 0;
  int CANCEL_CNT_4 = 0;
  int ING_CNT_4 = 0;
  String COMP_CNT_4_PER = '';
  String CANCEL_CNT_4_PER = '';
  String ING_CNT_4_PER = '';

  // 전자관
  String TOT_CNT_5 = '0';
  int COMP_CNT_5 = 0;
  int CANCEL_CNT_5 = 0;
  int ING_CNT_5 = 0;
  String COMP_CNT_5_PER = '';
  String CANCEL_CNT_5_PER = '';
  String ING_CNT_5_PER = '';

  // 밀키트
  String TOT_CNT_6 = '0';
  int COMP_CNT_6 = 0;
  int CANCEL_CNT_6 = 0;
  int ING_CNT_6 = 0;
  String COMP_CNT_6_PER = '';
  String CANCEL_CNT_6_PER = '';
  String ING_CNT_6_PER = '';

  // 택시
  String TOT_CNT_T = '0';
  int COMP_CNT_T = 0;
  int CANCEL_CNT_T = 0;
  int ING_CNT_T = 0;
  String COMP_CNT_T_PER = '';
  String CANCEL_CNT_T_PER = '';
  String ING_CNT_T_PER = '';
}