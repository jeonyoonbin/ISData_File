
class StatMileageSaleInOutMonthStaticModel {
  StatMileageSaleInOutMonthStaticModel();

  int MCODE = 0;
  String MNAME;
  String MDATE;
  int LOG_CUST_MILEAGE = 0;
  int IN_CNT = 0;
  int IN_AMT = 0;
  int ORDER_IN_CNT = 0;
  int ORDER_IN_AMT = 0;
  int SALE_IN_CNT = 0;
  int SALE_IN_AMT = 0;
  int ORDER_OUT_AMT = 0;
  int SALE_OUT_AMT = 0;
  int OUT_AMT = 0;
}
