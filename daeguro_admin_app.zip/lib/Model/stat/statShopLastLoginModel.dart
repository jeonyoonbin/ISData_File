
class StatShopLastLoginModel {
  StatShopLastLoginModel();

  String rnum;
  String shop_cd;
  String shop_name;
  String gungu;
  String last_login;
  String dd;
}