
class StatCouponDailyDrgCouponV2Model {
  StatCouponDailyDrgCouponV2Model();

  String DAILY;
  String STATUS;
  int A1 = 0;
  int A2 = 0;
  int B1 = 0;
  int B2 = 0;
  int C1 = 0;
  int C2 = 0;
  int D1 = 0;
  int D2 = 0;
  int E1 = 0;
  int E2 = 0;
  int F1 = 0;
  int F2 = 0;
  int G1 = 0;
  int G2 = 0;
  int H1 = 0;
  int H2 = 0;
}