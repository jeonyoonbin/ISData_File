
class StatOrderDailyPayGbnModel {
  StatOrderDailyPayGbnModel();

  String ORDER_DATE;
  String ORDER_STATE;
  int APP_CARD_CNT = 0;
  int APP_CARD_AMT = 0;
  int HAPPYPAY_CNT = 0;
  int HAPPYPAY_AMT = 0;
  int CARD_CNT = 0;
  int CARD_AMT = 0;
  int CASH_CNT = 0;
  int CASH_AMT = 0;

  int N_PAY_CNT = 0;
  int N_PAY_AMT = 0;

  int K_PAY_CNT = 0;
  int K_PAY_AMT = 0;

  int S_PAY_CNT = 0;
  int S_PAY_AMT = 0;
}
