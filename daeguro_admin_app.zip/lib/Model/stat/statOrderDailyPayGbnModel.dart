
class StatOrderDailyPayGbnModel {
  StatOrderDailyPayGbnModel();

  String ORDER_DATE;
  String ORDER_STATE;
  int APP_CARD_CNT = 0;
  int APP_CARD_AMT = 0;
  int HAPPYPAY_CNT = 0;
  int HAPPYPAY_AMT = 0;
  int CARD_CNT = 0;
  int CARD_AMT = 0;
  int CASH_CNT = 0;
  int CASH_AMT = 0;

  int N_PAY_CNT = 0;
  int N_PAY_AMT = 0;

  int K_PAY_CNT = 0;
  int K_PAY_AMT = 0;

  int S_PAY_CNT = 0;
  int S_PAY_AMT = 0;

  // 토스 결제
  int T_PAY_CNT = 0;
  int T_PAY_AMT = 0;

  // 모바일 상품권
  int V_PAY_CNT = 0;
  int V_PAY_AMT = 0;

  // 신한 PG
  int H_PAY_CNT = 0;
  int H_PAY_AMT = 0;

  // 아동급식
  int C_PAY_CNT = 0;
  int C_PAY_AMT = 0;

  // BC TOP 포인트
  int BC_TOP_CNT = 0;
  int BC_TOP_AMT = 0;

  // KB페이
  int KB_PAY_CNT = 0;
  int KB_PAY_AMT = 0;

  // 대구로페이
  int DGR_PAY_CNT = 0;
  int DGR_PAY_AMT = 0;

  // 페이코
  int PAYCO_CNT = 0;
  int PAYCO_AMT = 0;
}
