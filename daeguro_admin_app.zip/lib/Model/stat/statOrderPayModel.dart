
class StatOrderPayModel {
  StatOrderPayModel();

  String ORDER_DATE;
  String PAY_GBN;
  int COUNT = 0;

  // 날짜 가로 세로 변경
  int A = 0;  // 만나서 현금
  int B = 0;  // 앱 카드
  int C = 0;  // 행복페이
  int D = 0;  // 만나서카드
  int E = 0;  // 네이버 페이
  int F = 0;  // 카카오 페이
  int G = 0;  // 삼성 페이
  int H = 0;  // 토스결제
  int I = 0;  // 모바일상품권
  int J = 0;  // 신한PG
  int K = 0;  // 아동급식
  int L = 0;  // BC TOP 포인트
  int M = 0;  // KB페이
  int N = 0;  // 대구로페이
  int O = 0;  // 페이코
  int Z = 0;  // 합계
}