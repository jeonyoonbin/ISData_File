
class StatCouponCarryForwardCountCntModel {
  StatCouponCarryForwardCountCntModel();

  String dt;
  int amt = 0;
  int cnt = 0;
}