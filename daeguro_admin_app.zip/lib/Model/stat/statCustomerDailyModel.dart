
class StatCustomerDailyModel {
  StatCustomerDailyModel();

  String REG_DATE;
  String CUST_ID_GBN;
  int COUNT = 0;

  //날짜 세로로 되게 변경 (v2)
  int A = 0; // 공공앱
  int B = 0; // 구글
  int C = 0; // 카카오
  int D = 0; // 네이버
  int E = 0; // 애플
  int F = 0; // 비회원
}

