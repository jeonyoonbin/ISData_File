
class StatShopTotalOrderModel {
  StatShopTotalOrderModel();

  String ORDER_DATE;
  int CNT = 0;
  int AMT = 0;
  int OK_CNT = 0;
  int OK_AMT = 0;
  int CANCEL_CNT = 0;
  int CANCEL_AMT = 0;
  int SHOP_CONFIRM = 0;
  var COMP_PER;
  var CANCEL_PER;
}