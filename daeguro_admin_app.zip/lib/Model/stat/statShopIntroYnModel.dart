
class StatShopIntroYnModel {
  StatShopIntroYnModel();

  String rnum;
  String shop_cd;
  String shop_name;
  String r_yn;
  String i_yn;
}