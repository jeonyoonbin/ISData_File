
class StatShopOrderAmtModel {
  StatShopOrderAmtModel();

  String rnum;
  String shop_cd;
  String shop_name;
  String gungu;
  String tot_sales_amt;
  String comp_amt;
  String cancel_amt;
}