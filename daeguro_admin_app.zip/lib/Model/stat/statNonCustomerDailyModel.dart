
class StatNonCustomerDailyModel {
  StatNonCustomerDailyModel();

  String INSERT_DATE;
  int COUNT = 0;
}

