class StatOrderDailyVmsCallModel {
  StatOrderDailyVmsCallModel();

  String daily_total_date;
  int total_cnt;
  int success_cnt;
  int fail_cnt;
}
