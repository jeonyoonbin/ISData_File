
class StatOrderCategoryModel {
  StatOrderCategoryModel();

  String ITEM_CD;
  int COUNT = 0;
  int MENU_AMT = 0;
  int DELI_TIP_AMT = 0;
  int DISC_USE_AMT = 0;
}