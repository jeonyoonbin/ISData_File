
class StatOrderTimeModel {
  StatOrderTimeModel();

  String ITEM_CD;
  String HH;
  int COUNT = 0;
}
