﻿
class StatCustomerOrderModel {
  StatCustomerOrderModel();

  int DAY_COUNT;
  int ORDER_COUNT = 0;
}