
class StatShopCategoryModel {
  StatShopCategoryModel();

  String OPEN_DATE;
  String ITEM_NAME;
  int COUNT = 0;

  // 날짜 세로로 변경(v2)
  int A = 0;
  int B = 0;
  int C = 0;
  int D = 0;
  int E = 0;
  int F = 0;
  int G = 0;
  int H = 0;
  int I = 0;
  int J = 0;
  int K = 0;
  int L = 0;
  int M = 0;
  int N = 0;
  int O = 0;
  int P = 0;
  int Q = 0;
  int R = 0;
  int S = 0;
  int T = 0;
  int U = 0;
  int V = 0;
  int Z = 0;
}