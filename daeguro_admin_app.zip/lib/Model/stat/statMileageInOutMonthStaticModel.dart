
class StatMileageInOutMonthStaticModel {
  StatMileageInOutMonthStaticModel();

  String MDATE;
  int COUNT = 0;
  int SUM_CUST_MILEAGE = 0;
  int SUM_LOG_CUST_MILEAGE = 0;
  int SUM_IN_CNT = 0;
  int SUM_IN_AMT = 0;
  int SUM_ORDER_IN_CNT = 0;
  int SUM_ORDER_IN_AMT = 0;
  int SUM_SALE_IN_CNT = 0;
  int SUM_SALE_IN_AMT = 0;
  int SUM_ORDER_OUT_AMT = 0;
  int SUM_SALE_OUT_AMT = 0;
  int SUM_OUT_AMT = 0;
  int SUM_TERMINATE_AMT = 0;
}
