import 'dart:core';

import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ISQuestionMark extends StatelessWidget {
  final String label;

  const ISQuestionMark({Key key, this.label}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Tooltip(
        message: label,
        child: Stack(
          alignment: Alignment.center,
          children: <Widget> [
            Container(
              width: 17,
              height: 17,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), border: Border.all(width: 1.5, color: Colors.orange)),),
            Text('?', textAlign: TextAlign.center, style: TextStyle(fontSize: 13, fontWeight: FONT_BOLD, color: Colors.orange, fontFamily: FONT_FAMILY_ROBOTO))
          ],
        ),
        textStyle: TextStyle(fontSize: 12, color: Colors.white));
  }}