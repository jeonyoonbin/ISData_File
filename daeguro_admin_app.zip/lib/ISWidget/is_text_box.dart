import 'dart:core';

import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ISTextBox extends StatelessWidget {
  final String label;
  final String value;
  final int width;
  final bool stringYn;

  const ISTextBox({Key key, this.label, this.value, this.width, this.stringYn}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        shape: BoxShape.rectangle,
        color: Colors.blue[50],
        // borderRadius: BorderRadius.circular(6.0),
      ),
      child: Padding(
        padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              children: [
                Text('※ ', style: TextStyle(fontSize: 12, fontWeight: FONT_BOLD, color: Colors.deepOrange),),
                Text(label, style: TextStyle(fontSize: 12, fontWeight: FONT_BOLD,),),
                SizedBox(width: 10,)
              ],
            ),
            Container(
              color: Colors.white,
              width: width ?? 110,
              child: SelectableText(stringYn == true ? value : Utils.getCashComma(value), textAlign: TextAlign.right),
            ),
          ],
        ),
      ),
    );
  }}