import 'dart:convert';

import 'package:daeguro_admin_app/Model/notice/reserNoticeSortListModel.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/NoticeManager/Reser/reserNotice_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';

class AdZoneUpdateSort extends StatefulWidget {
  final String shopCode;
  final String menuCode;

  const AdZoneUpdateSort({Key key, this.shopCode, this.menuCode}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return AdZoneUpdateSortState();
  }
}

class AdZoneUpdateSortState extends State<AdZoneUpdateSort> with SingleTickerProviderStateMixin {
  //final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  //final ScrollController _scrollController = ScrollController();
  final List<reserNoticeSortListModel> sortListEvent = <reserNoticeSortListModel>[];

  int current_tabIdx = 0;

  bool isSaveEnabled = false;

  _query() {
    //print('call _query() menuCode->'+widget.menuCode);
    //formKey.currentState.save();

    loadData();
  }

  loadData() async {
    sortListEvent.clear();

    // 이벤트 바인딩
    await ReserNoticeController.to.getNoticeSortList('3', context);

    if (this.mounted) {
      ReserNoticeController.to.qDataSortList.forEach((e) {
        reserNoticeSortListModel temp = reserNoticeSortListModel.fromJson(e);

        temp.frDate = Utils.getYearMonthDayFormat(temp.frDate);
        temp.toDate = Utils.getYearMonthDayFormat(temp.toDate);

        sortListEvent.add(temp);
      });

      if (isSaveEnabled == true) {
        await Future.delayed(Duration(milliseconds: 500), () async {
          List<String> sortDataList = [];
          sortListEvent.forEach((element) {
            sortDataList.add(element.noticeSeq.toString());
          });

          if (sortDataList.length != 0) {
            String jsonData = jsonEncode(sortDataList);
            await ReserNoticeController.to.updateSort(jsonData, context);
          }

          isSaveEnabled = false;
        });
      }

      setState(() {});
    }
  }

  _editListSort(List<String> sortDataList) async {
    String jsonData = jsonEncode(sortDataList);

    //print(jsonData);

    //print('data set->'+jsonData);
    await ReserNoticeController.to.updateSort(jsonData, context);

    await Future.delayed(Duration(milliseconds: 500), () {
      loadData();
    });
  }

  @override
  void initState() {
    super.initState();
    //Get.put(AgentController());

    //formKey.currentState.reset();
    Get.put(ReserNoticeController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      //loadSidoData();
      isSaveEnabled = true;
      _query();
    });
  }

  @override
  Widget build(BuildContext context) {

    var form = Container(
      padding: EdgeInsets.only(left: 30, right: 30),
      child: Text(
        '- 게시 상태만 표시 됩니다.',
        style: TextStyle(fontSize: 12.0),
      ),
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('노출 순서 변경'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 10),
          form,
          SizedBox(height: 10),
          Expanded(
            child: sortListEvent == null
                ? Text('Data is Empty')
                : ReorderableListView(
                onReorder: _onReorder_Event,
                scrollDirection: Axis.vertical,
                padding: const EdgeInsets.only(bottom: 8.0),
                children: List.generate(sortListEvent.length, (index) {
                  return GestureDetector(
                    // onTap: (){
                    //   Navigator.pushNamed(context, '/editor', arguments: UserController.to.userData[index]);
                    // },
                    key: Key('$index'),
                    child: Card(
                      color: Colors.white,
                      elevation: 2.0,
                      child: ListTile(
                        //leading: Text(dataList[index].siguName),
                        title: Row(
                          children: [
                            Text(
                              '[' + sortListEvent[index].noticeSeq.toString() + '] ' + sortListEvent[index].title ?? '--',
                              style: TextStyle(fontWeight: FONT_BOLD, fontSize: 12),
                            ),
                            Container(
                                margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                width: 30,
                                height: 16,
                                alignment: Alignment.center,
                                color: Color.fromRGBO(87, 170, 58, 0.8431372549019608),
                                child: Text(
                                  '게시',
                                  style: TextStyle(fontSize: 8, color: Colors.white),
                                ))
                          ],
                        ),
                        subtitle: Container(
                          alignment: Alignment.topLeft,
                          child: Column(
                            children: [
                              //Text(dataList[index].noticeContents ?? '--', style: TextStyle(fontWeight: FONT_BOLD, fontSize: 10),),
                              Text(
                                sortListEvent[index].frDate + ' ~ ' + sortListEvent[index].frDate ?? '--',
                                style: TextStyle(fontWeight: FONT_BOLD, fontSize: 10),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                })),
          ),
        ],
      ),
    );
    return SizedBox(
      width: 420,
      height: 580, //isDisplayDesktop(context) ? 580 : 1000,
      child: result,
    );
  }

  void _onReorder_Event(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final reserNoticeSortListModel item = sortListEvent.removeAt(oldIndex);
      sortListEvent.insert(newIndex, item);

      List<String> sortDataList = [];
      sortListEvent.forEach((element) {
        sortDataList.add(element.noticeSeq.toString());
      });
      _editListSort(sortDataList);
    });
  }
}