import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsListModel.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/AdvertisementManager/AD_VideoUploadRegist.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsBlogEdit.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsBlogRegist.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsNotifierData.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsWebtoonEdit.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsWebtoonRegist.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsWebtoonSub.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsWebtoonUpdateSort.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contents_controller.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/NoticeManager/Reser/reserNoticeUpdateSort.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_input.dart';
import 'package:daeguro_admin_app/Model/search_items.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:async';

class AD_VideoUploadList extends StatefulWidget {
  const AD_VideoUploadList({key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return AD_VideoUploadListState();
  }
}

class AD_VideoUploadListState extends State<AD_VideoUploadList> with SingleTickerProviderStateMixin {
  get secureStorage => null;

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  bool excelEnable = true;

  TabController _nestedTabController;

  List<ContentsListModel> dataList = <ContentsListModel>[];

  List MCodeListitems = List();

  SearchItems _searchItems = new SearchItems();

  bool isCheckAll = false;

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  String _dispCbo = 'Y';

  int _currentPage = 1;
  int _totalPages = 0;

  final ScrollController _scrollController = ScrollController();

  void _pageMove(int _page) {
    _query();
  }

  _regist() async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: AD_VideoUploadRegist(),
      ),
    ).then((v) async {
      if (v == true) {
        await Future.delayed(Duration(milliseconds: 500), () {
          loadData();
        });
      }
    });
  }

  _updateSort() async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: ContentsWebtoonUpdateSort(cartegory_gbn:'R'),
      ),
    ).then((v) async {
      await Future.delayed(Duration(milliseconds: 500), () {
        loadData();
        setState(() {});
      });
    });
  }

  _reset() {
    dataList.clear();

    _searchItems = null;
    _searchItems = new SearchItems();
  }

  _query() {
    loadData();
  }

  loadData() async {
    await ISProgressDialog(context).show(status: 'Loading...');

    dataList.clear();

    await ContentsController.to.getContentsData('R', _dispCbo, _searchItems.name, _currentPage.toString(), _selectedpagerows.toString()).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((element) {
          ContentsListModel temp = ContentsListModel();//.fromJson(e);

          temp.viewSelected = element['viewSelected'] as bool;
          temp.RNUM = element['RNUM'] as int;
          temp.CONTENTS_CD = element['CONTENTS_CD'] as int;
          temp.CONTENTS_TITLE = element['CONTENTS_TITLE'] as String;
          temp.DISP_GBN = element['DISP_GBN'] as String;
          temp.DISP_SEQ = element['DISP_SEQ'] as int;
          temp.INS_DATE = element['INS_DATE'] as String;
          temp.INS_UCODE = element['INS_UCODE'] as int;

          dataList.add(temp);
        });
        _totalRowCnt = ContentsController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
      }
    });

    await ISProgressDialog(context).dismiss();

    setState(() {});
  }

  void detailCallback() {
    _query();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ContentsController());

    _nestedTabController = new TabController(length: 1, vsync: this);

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      _query();
    });
  }

  @override
  void dispose() {
    dataList.clear();
    //MCodeListitems.clear();

    _nestedTabController.dispose();
    _scrollController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //testSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.end, children: <Widget>[
        Row(
          children: [
            Text(
              '총: ${Utils.getCashComma(ContentsController.to.totalRowCnt.toString())}건',
              style: TextStyle(fontSize: 12, fontWeight: FONT_BOLD),
            ),
          ],
        ),
        Row(
          children: [
            Column(
              children: [
                Row(
                  children: [
                    ISSearchDropdown(
                      label: '게시유무',
                      width: 100,
                      value: _dispCbo,
                      onChange: (value) {
                        _dispCbo = value;
                        setState(() {});
                      },
                      item: [
                        DropdownMenuItem(
                          value: '%',
                          child: Text('전체'),
                        ),
                        DropdownMenuItem(
                          value: 'Y',
                          child: Text('게시'),
                        ),
                        DropdownMenuItem(
                          value: 'N',
                          child: Text('미 게시'),
                        ),
                      ].cast<DropdownMenuItem<String>>(),
                    ),
                    Container(
                      child: Stack(
                        alignment: Alignment.centerRight,
                        children: [
                          ISSearchInput(
                            width: 250,
                            label: '제목',
                            value: _searchItems.name,
                            onChange: (v) {
                              _searchItems.name = v;
                            },
                            onFieldSubmitted: (v) {
                              _currentPage = 1;
                              _query();
                            },
                          ),
                        ],
                      ),
                    ),
                    if (AuthUtil.isAuthReadEnabled('237') == true)
                    ISSearchButton(
                        label: '조회',
                        iconData: Icons.search,
                        onPressed: () => {
                              _currentPage = 1,
                              //_query(),
                              _query()
                            }),
                    SizedBox(width: 8),
                    if (AuthUtil.isAuthCreateEnabled('237') == true)
                    ISSearchButton(label: '영상 업로드', iconData: Icons.upload_file, onPressed: () => {_regist()}),
                    SizedBox(width: 8),
                    ISSearchButton(width: 130, label: '노출 순서', iconData: Icons.autorenew, onPressed: () => _updateSort()),
                  ],
                ),
              ],
            ),
          ],
        ),
      ]),
    );

    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          form,
          buttonBar,
          Divider(),
          ISDatatable(
            panelHeight: (MediaQuery.of(context).size.height - defaultContentsHeight),
            listWidth: Responsive.getResponsiveWidth(context, 720),
            //showCheckboxColumn: (widget.shopName == null) ? true : false,
            rows: dataList.map((item) {
              return DataRow(
                  selected: item.viewSelected ?? false,
                  color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
                    if (item.viewSelected == true) {
                      return Colors.grey.shade200;
                      //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
                    }

                    return Theme.of(context).colorScheme.primary.withOpacity(0.00);
                  }),
                  onSelectChanged: (bool value) async {
                    //_nestedTabController.index = 0;

                    dataList.forEach((element) {
                      element.viewSelected = false;
                    });

                    item.viewSelected = true;

                    _scrollController.jumpTo(0.0);

                    setState(() {});
                  },
                  cells: [
                    DataCell(Align(
                      child: SelectableText(item.CONTENTS_CD.toString(), showCursor: true),
                      alignment: Alignment.center,
                    )),
                    DataCell(Container(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Align(
                            child: Text(
                              item.CONTENTS_TITLE.toString() ?? '--',
                              style: TextStyle(color: Colors.black),
                            ),
                            alignment: Alignment.centerLeft))),
                    DataCell(Center(
                        child: item.DISP_GBN.toString() == 'Y'
                            ? Icon(Icons.radio_button_unchecked, color: Colors.blue, size: 16)
                            : Icon(Icons.clear, color: Colors.red, size: 16))),
                    DataCell(Container(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Align(
                            child: Text(
                              item.INS_DATE.replaceAll('T', ' ') ?? '--',
                              style: TextStyle(color: Colors.black),
                            ),
                            alignment: Alignment.center))),
                    DataCell(
                      Center(
                        child: InkWell(
                          child: Icon(Icons.edit, size: 20),
                          onTap: () {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) => Dialog(
                                child: ContentsBlogEdit(contents_cd: item.CONTENTS_CD.toString()),
                              ),
                            ).then((v) async {
                              if (v != null) {
                                await Future.delayed(Duration(milliseconds: 500), () {
                                  loadData();
                                });
                              }
                            });
                          },
                        ),
                      ),
                    ),
                  ]);
            }).toList(),
            columns: <DataColumn>[
              DataColumn(label: Expanded(child: Text('순번', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: SelectableText('제목', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('게시유무', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('등록일', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('관리', textAlign: TextAlign.center)),)
            ],
          ),
          Divider(),
          showPagerBar(),
        ],
      ),
    );
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                //Text('row1'),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(),
                      style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context)
                ? Container(height: 48)
                : Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      //Text('조회 데이터 : ', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL),),
                      //Text(UserController.to.totalRowCnt.toString() + ' / ' + UserController.to.total_count.toString(), style: TextStyle(fontSize: 12, fontWeight: FONT_BOLD),),
                      //SizedBox(width: 20,),
                      Text('페이지당 행 수 : ', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL),),
                      Container(
                        width: 70,
                        height: 24,
                        decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(5.0)),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton2(
                              value: _selectedpagerows,
                              isExpanded: true,
                              style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: FONT_FAMILY),
                              items: Utils.getPageRowList(),
                              dropdownMaxHeight: 180,
                              itemHeight: 36,
                              itemPadding: const EdgeInsets.only(left: 16, right: 16),
                              dropdownPadding: const EdgeInsets.symmetric(vertical: 6),
                              dropdownDecoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(6),
                              ),
                              onChanged: (value) {
                                setState(() {
                                  _selectedpagerows = value;
                                  _currentPage = 1;
                                  _query();
                                });
                              }),
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  double getListMainPanelWidth() {
    double nWidth = MediaQuery.of(context).size.width - 1000;
    if (Responsive.isTablet(context) == true)
      nWidth = nWidth + sidebarWidth;
    else if (Responsive.isMobile(context) == true) nWidth = MediaQuery.of(context).size.width;

    return nWidth;
  }
}
