import 'package:bubble_tab_indicator/bubble_tab_indicator.dart';
import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_checkbox.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select_date.dart';
import 'package:daeguro_admin_app/Model/notice/noticeRegistModel.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/View/CouponManager/coupon_controller.dart';

import 'package:daeguro_admin_app/Network/FileUpLoader.dart';
import 'package:daeguro_admin_app/constants/constant.dart';

import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class AdZoneRegist extends StatefulWidget {
  const AdZoneRegist({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return AdZoneRegistState();
  }
}

class AdZoneRegistState extends State<AdZoneRegist>  with SingleTickerProviderStateMixin {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  noticeRegistModel formData;

  List<SelectOptionVO> selectBox_noticeGbn = List();
  List<SelectOptionVO> selectBox_noticeType = List();

  TabController _nestedTabController;

  bool _indefinitely = false;

  String _couponCnt;
  String _orderDate;
  String _fromDate;
  String _toDate;

  var _file = null;
  var responseData;

  @override
  void dispose() {
    selectBox_noticeGbn.clear();
    _nestedTabController.dispose();
    formData = null;

    PaintingBinding.instance.imageCache.clearLiveImages();
    PaintingBinding.instance.imageCache.clear();

    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    Get.put(CouponController());

    _nestedTabController = new TabController(length: 2, vsync: this);

    selectBox_noticeGbn.clear();

    selectBox_noticeGbn.add(new SelectOptionVO(value: '1', label: '공지'));
    selectBox_noticeGbn.add(new SelectOptionVO(value: '2', label: '공지(사장님)'));
    selectBox_noticeGbn.add(new SelectOptionVO(value: '3', label: '이벤트'));
    selectBox_noticeGbn.add(new SelectOptionVO(value: '4', label: '배너공지(사장님)'));
    selectBox_noticeGbn.add(new SelectOptionVO(value: '5', label: '메인팝업'));
    selectBox_noticeGbn.add(new SelectOptionVO(value: '6', label: '메인팝업(사장님)'));
    selectBox_noticeGbn.add(new SelectOptionVO(value: '7', label: '시정홍보'));

    selectBox_noticeType.add(new SelectOptionVO(value: '0', label: '전체공지'));
    selectBox_noticeType.add(new SelectOptionVO(value: '1', label: '주문앱공지'));

    formData = noticeRegistModel();
    formData.extUrlYn = 'N';
    formData.dispGbn = 'Y';
    formData.noticeGbn = '1';
    formData.noticeType = '0';
    formData.orderDate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    formData.dispFromDate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    formData.dispToDate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    _orderDate = formatDate(DateTime.now(), [yyyy, '', mm, '', dd]);
    _fromDate = formatDate(DateTime.now(), [yyyy, '', mm, '', dd]);
    _toDate = formatDate(DateTime.now(), [yyyy, '', mm, '', dd]);
  }

  @override
  Widget build(BuildContext context) {
    var adInfo = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: Container(
                  margin: EdgeInsets.all(8.0),
                  decoration: new BoxDecoration(color: formData.dispGbn == 'Y' ? Colors.blue[200] : Colors.red[200], borderRadius: new BorderRadius.circular(6)),
                  child: SwitchListTile(
                    dense: true,
                    value: formData.dispGbn == 'Y' ? true : false,
                    title: Text(
                      '게시 유무',
                      style: TextStyle(fontSize: 12, color: Colors.white),
                    ),
                    onChanged: (v) {
                      setState(() {
                        formData.dispGbn = v ? 'Y' : 'N';
                        formKey.currentState.save();
                      });
                    },
                  ),
                ),
              ),
              Flexible(
                flex: 1,
                child: Row(
                  children: [
                    Flexible(
                      flex: 1,
                      child: ISSelectDate(
                        context,
                        label: '시작일',
                        value: formData.dispFromDate,
                        onTap: () async {
                          DateTime valueDt = DateTime.now();
                          final DateTime picked = await showDatePicker(
                            context: context,
                            initialDate: valueDt,
                            firstDate: DateTime(1900, 1),
                            lastDate: DateTime(2031, 12),
                          );

                          setState(() {
                            if (picked != null) {
                              formData.dispFromDate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                              _fromDate = formatDate(picked, [yyyy, '', mm, '', dd]);
                            }
                          });

                          formKey.currentState.save();
                        },
                      ),
                    ),
                    Flexible(
                      flex: 1,
                      child: ISSelectDate(
                        context,
                        label: '종료일',
                        value: formData.dispToDate.replaceAll('.', '-'),
                        onTap: () async {
                          DateTime valueDt = DateTime.now();
                          final DateTime picked = await showDatePicker(
                            context: context,
                            initialDate: valueDt,
                            firstDate: DateTime(1900, 1),
                            lastDate: DateTime(2031, 12),
                          );

                          setState(() {
                            if (picked != null) {
                              formData.dispToDate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                              _toDate = formatDate(picked, [yyyy, '', mm, '', dd]);
                            }
                          });

                          formKey.currentState.save();
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          ISInput(
            value: formData.noticeTitle,
            autofocus: true,
            context: context,
            label: '제목',
            onChange: (v) {
              formData.noticeTitle = v;
            },
            // validator: (v) {
            //   return v.isEmpty ? '[필수] 제목' : null;
            // },
          ),
          ISInput(
            value: formData.noticeContents,
            context: context,
            label: '내용',
            height: 140,
            contentPadding: 20,
            keyboardType: TextInputType.multiline,
            maxLines: 8,
            onChange: (v) {
              formData.noticeContents = v;
            },
            // validator: (v) {
            //   return v.isEmpty ? '[필수] 내용' : null;
            // },
          ),
          ISInput(
            value: formData.noticeUrl_2,
            context: context,
            label: '썸네일 URL주소',
            onChange: (v) {
              formData.noticeUrl_2 = v;
            },
          ),
          ISInput(
            value: formData.noticeUrl_2,
            context: context,
            label: '동영상 URL주소',
            onChange: (v) {
              formData.noticeUrl_2 = v;
            },
          ),
          ISInput(
            value: formData.noticeUrl_2,
            context: context,
            label: '회사 상호명',
            onChange: (v) {
              formData.noticeUrl_2 = v;
            },
          ),
          ISInput(
            value: formData.noticeUrl_2,
            context: context,
            label: '회사 로고 URL 주소',
            onChange: (v) {
              formData.noticeUrl_2 = v;
            },
          ),
        ],
      ),
    );

    var couponInfo = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: [
              Flexible(
                flex: 2,
                child: ISInput(
                  value: formData.noticeTitle,
                  autofocus: true,
                  context: context,
                  label: '쿠폰명',
                  onSaved: (v) {
                    formData.noticeTitle = v;
                  },
                  // validator: (v) {
                  //   return v.isEmpty ? '[필수] 제목' : null;
                  // },
                ),
              ),
              Flexible(
                flex: 1,
                child: ISInput(
                  value: formData.noticeTitle,
                  autofocus: true,
                  context: context,
                  label: '쿠폰기간',
                  keyboardType: TextInputType.number,
                  inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                  onSaved: (v) {
                    formData.noticeTitle = v;
                  },
                  // validator: (v) {
                  //   return v.isEmpty ? '[필수] 제목' : null;
                  // },
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                flex: 1,
                child: Expanded(
                  child: ISInput(
                    value: formData.noticeTitle,
                    autofocus: true,
                    context: context,
                    label: '쿠폰 수량',
                    readOnly: _indefinitely == true ? true : false,
                    keyboardType: TextInputType.number,
                    inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                    onChange: (v) {
                      formData.noticeTitle = v;
                    },
                    // validator: (v) {
                    //   return v.isEmpty ? '[필수] 제목' : null;
                    // },
                  ),
                ),
              ),
              Flexible(
                flex: 2,
                child: Row(
                  children: [
                    Expanded(
                      child: ISInput(
                        value: formData.noticeTitle,
                        autofocus: true,
                        context: context,
                        label: '쿠폰 금액',
                        readOnly: _indefinitely == true ? true : false,
                        keyboardType: TextInputType.number,
                        inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                        onChange: (v) {
                          formData.noticeTitle = v;
                        },
                        // validator: (v) {
                        //   return v.isEmpty ? '[필수] 제목' : null;
                        // },
                      ),
                    ),
                    Expanded(
                      child: ISInput(
                        value: formData.noticeTitle,
                        autofocus: true,
                        context: context,
                        label: '최소 주문 금액',
                        keyboardType: TextInputType.number,
                        inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                        onChange: (v) {
                          formData.noticeTitle = v;
                        },
                        // validator: (v) {
                        //   return v.isEmpty ? '[필수] 제목' : null;
                        // },
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
          ISInput(
            value: formData.noticeContents,
            context: context,
            label: '쿠폰 유의사항',
            height: 140,
            contentPadding: 20,
            keyboardType: TextInputType.multiline,
            maxLines: 8,
            onChange: (v) {
              formData.noticeContents = v;
            },
            // validator: (v) {
            //   return v.isEmpty ? '[필수] 내용' : null;
            // },
          ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () async {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            form.save();

            // if (_file == null) {
            //   ISAlert(context, '이미지를 등록 해 주십시오.');
            //   return;
            // }

            formData.orderDate = _orderDate;
            formData.dispFromDate = _fromDate;
            formData.dispToDate = _toDate;
            formData.insDate = formatDate(DateTime.now(), [yyyy, '', mm, '', dd]);
            formData.insUCode = GetStorage().read('logininfo')['uCode'];
            formData.insName = GetStorage().read('logininfo')['name'];

            formData.noticeUrl_2 = formData.noticeUrl_2.replaceAll(' ', '');

            FileUpLoadProvider provider = FileUpLoadProvider();
            provider.setResource('image', _file);
            //provider.makeNoticePostResourceRequest(formData.noticeGbn, formData.noticeType, formData.dispGbn, formData.dispFromDate, formData.dispToDate, formData.noticeTitle, formData.noticeContents, formData.noticeUrl_1, formData.noticeUrl_2, formData.orderDate, formData.insDate, formData.insUCode, formData.insName, formData.extUrlYn);

            await Future.delayed(Duration(milliseconds: 500), () {
              setState(() {
                _deleteImageFromCache();
              });
            });

            Navigator.pop(context, true);
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('광고 등록'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 10.0, bottom: 10.0, left: 8.0, right: 8.0),
              child: Container(
                height: 30.0,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade200, width: 2.0),
                  borderRadius: BorderRadius.circular(5),
                  color: Colors.grey.shade200,
                ),
                child: TabBar(
                  controller: _nestedTabController,
                  unselectedLabelColor: Colors.black45,
                  indicatorSize: TabBarIndicatorSize.tab,
                  labelStyle: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY),
                  indicator: BubbleTabIndicator(
                    indicatorRadius: 5.0,
                    indicatorHeight: 25.0,
                    indicatorColor: Colors.blue,
                    tabBarIndicatorSize: TabBarIndicatorSize.tab,
                  ),
                  tabs: [Tab(text: '광고정보'), Tab(text: '쿠폰정보')],
                ),
              ),
            ),
            Container(
              width: 480,
              height: 500,
              child: TabBarView(
                physics: NeverScrollableScrollPhysics(),
                controller: _nestedTabController,
                children: [
                  Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: adInfo),
                  Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: couponInfo),
                ],
              ),
            )

          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 480,
      height: 680,
      child: result,
    );
  }

  Future _deleteImageFromCache() async {
    //await CachedNetworkImage.evictFromCache(url);

    PaintingBinding.instance.imageCache.clearLiveImages();
    PaintingBinding.instance.imageCache.clear();

    //await DefaultCacheManager().removeFile(key);
    //await DefaultCacheManager().emptyCache();
    setState(() {});
  }
}
