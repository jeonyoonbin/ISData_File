import 'package:daeguro_admin_app/ISWidget/is_vertical_slider.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

class AdZoneDetail extends StatefulWidget {
  const AdZoneDetail({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return AdZoneDetailState();
  }
}

class VideoControlsOverlay extends StatefulWidget {
  final VideoPlayerController controller;

  VideoControlsOverlay({this.controller});

  @override
  VideoControlsOverlayState createState() => VideoControlsOverlayState();
}

class VideoControlsOverlayState extends State<VideoControlsOverlay> {
  // const VideoControlsOverlayState({Key key, this.controller})
  //     : super(key: key);

  static const List<double> _examplePlaybackRates = <double>[
    0.25,
    0.5,
    1.0,
    1.5,
    2.0,
    3.0,
    5.0,
    10.0,
  ];

  VideoPlayerController controller;

  @override
  void initState() {
    controller = widget.controller;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 50),
          reverseDuration: const Duration(milliseconds: 200),
          child: controller.value.isPlaying == true
              ? const SizedBox.shrink()
              : Container(
                  color: Colors.black26,
                  child: const Center(
                    child: Icon(Icons.play_arrow, color: Colors.white, size: 100.0, semanticLabel: '재생'),
                  ),
                ),
        ),
        Align(
          alignment: Alignment.bottomLeft,
          child: Padding(
            padding: const EdgeInsets.only(left: 6, top: 100),
            child: ISVerticalSlider(
              min: 0.0,
              max: 1.0,
              value: controller.value.volume,
              width: 10,
              activeTrackColor: Colors.amber.withOpacity(0.9),
              inactiveTrackColor: Colors.amberAccent.withOpacity(0.5),
              onChanged: (volume) {
                setState(() {
                  controller.setVolume(volume);
                });
              },
            ),
          ),
        ),
        GestureDetector(
          onTap: () {
            controller.value.isPlaying ? controller.pause() : controller.play();
            setState(() {});
          },
        ),
        // Align(
        //   alignment: Alignment.topLeft,
        //   child: PopupMenuButton<Duration>(
        //     initialValue: controller.value.captionOffset,
        //     tooltip: 'Caption Offset',
        //     onSelected: (Duration delay) {
        //       controller.setCaptionOffset(delay);
        //     },
        //     itemBuilder: (BuildContext context) {
        //       return <PopupMenuItem<Duration>>[
        //         for (final Duration offsetDuration in _exampleCaptionOffsets)
        //           PopupMenuItem<Duration>(
        //             value: offsetDuration,
        //             child: Text('${offsetDuration.inMilliseconds}ms'),
        //           )
        //       ];
        //     },
        //     child: Padding(
        //       padding: const EdgeInsets.symmetric(
        //         // Using less vertical padding as the text is also longer
        //         // horizontally, so it feels like it would need more spacing
        //         // horizontally (matching the aspect ratio of the video).
        //         vertical: 12,
        //         horizontal: 16,
        //       ),
        //       child: Text('${controller.value.captionOffset.inMilliseconds}ms'),
        //     ),
        //   ),
        // ),
        // Align(
        //   alignment: Alignment.bottomLeft,
        //   child: SliderTheme(
        //     data: SliderThemeData(
        //       valueIndicatorShape: PaddleSliderValueIndicatorShape(),
        //     ),
        //     child: Slider(
        //       value: controller.value.volume,
        //       min: 0.0,
        //       max: 1.0,
        //       divisions: 20,
        //       label: controller.value.volume.toString(),
        //       onChanged: (volume) {
        //         controller.setVolume(volume);
        //       },
        //     ),
        //   )
        //   // child: PopupMenuButton<double>(
        //   //   initialValue: controller.value.volume,
        //   //   tooltip: '재생볼륨',
        //   //   onSelected: (double volume) {
        //   //     controller.setVolume(volume);
        //   //   },
        //   //   itemBuilder: (BuildContext context) {
        //   //     return <PopupMenuItem<double>>[
        //   //       for (final double volume in _exampleVolumeRates)
        //   //         PopupMenuItem<double>(
        //   //           value: volume,
        //   //           child: Text('${volume}', style: TextStyle(fontSize: 10),),
        //   //         )
        //   //     ];
        //   //   },
        //   //   child: Padding(
        //   //     padding: const EdgeInsets.symmetric(
        //   //       // Using less vertical padding as the text is also longer
        //   //       // horizontally, so it feels like it would need more spacing
        //   //       // horizontally (matching the aspect ratio of the video).
        //   //       vertical: 12,
        //   //       horizontal: 16,
        //   //     ),
        //   //     child: Text('${controller.value.volume}'),
        //   //   ),
        //   // ),
        // ),

        Align(
          alignment: Alignment.topRight,
          child: PopupMenuButton<double>(
            initialValue: controller.value.playbackSpeed,
            tooltip: '재생속도',
            onSelected: (double speed) {
              controller.setPlaybackSpeed(speed);
            },
            itemBuilder: (BuildContext context) {
              return <PopupMenuItem<double>>[
                for (final double speed in _examplePlaybackRates)
                  PopupMenuItem<double>(
                    value: speed,
                    child: Text(
                      '${speed}x',
                      style: TextStyle(fontSize: 10),
                    ),
                  )
              ];
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(
                // Using less vertical padding as the text is also longer
                // horizontally, so it feels like it would need more spacing
                // horizontally (matching the aspect ratio of the video).
                vertical: 12,
                horizontal: 16,
              ),
              child: Text('${controller.value.playbackSpeed}x'),
            ),
          ),
        ),
      ],
    );
  }
}

class AdZoneDetailState extends State<AdZoneDetail> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  VideoPlayerController _videoPlayerController;
  ScrollController _scrollController;
  String _url = "https://insung.fastedge.net:9090/insung/광고/ad_daeguro.mp4";

  @override
  void initState() {
    super.initState();

    _videoPlayerController = VideoPlayerController.network(_url)
      ..initialize().then((_) {
        _videoPlayerController.setVolume(0.2);
        //_videoPlayerController.play();

        // _videoPlayerController.setLooping(true);
        setState(() {});
      });
  }

  @override
  void dispose() {
    _videoPlayerController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(key: formKey, child: Wrap(children: <Widget>[]));

    var result = Scaffold(
      appBar: AppBar(
        title: Text('광고 상세 조회'),
      ),
      body: Container(
        padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(5), border: Border.all(width: 1, color: Colors.grey.withOpacity(.3))),
              width: 370,
              height: 560,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    child: Text('시청 횟수: 100,000건', style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD)),
                  ),
                  SizedBox(height: 10),
                  Center(
                    child: Container(
                      child: _videoPlayerController.value.isInitialized
                          ? Stack(
                              children: <Widget>[
                                AspectRatio(
                                  aspectRatio: _videoPlayerController.value.aspectRatio,
                                  child: Stack(
                                    alignment: Alignment.bottomCenter,
                                    children: <Widget>[
                                      VideoPlayer(_videoPlayerController),
                                      VideoControlsOverlay(controller: _videoPlayerController),
                                      VideoProgressIndicator(_videoPlayerController, allowScrubbing: true),
                                    ],
                                  ),
                                )
                              ],
                            )
                          : Image.asset('assets/empty_menu.png', height: 150, width: 150),
                    ),
                  ),
                  SizedBox(height: 10),
                  Center(
                    child: ISSearchButton(
                        width: 300,
                        label: '광고 영상 보기',
                        onPressed: () async {
                          if (await canLaunch(_url)) {
                            await launch(
                              _url,
                            );
                          } else {
                            throw 'Web Request Fail $_url';
                          }
                        }),
                  ),
                  Divider(),
                  Container(
                    child: Text('회사 로고', style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD)),
                  ),
                  Center(child: Image.asset('assets/empty_menu.png', height: 150, width: 150))
                ],
              ),
            ),
            SizedBox(
              width: 20,
            ),
            Container(
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(5), border: Border.all(width: 1, color: Colors.grey.withOpacity(.3))),
              width: 370,
              height: 560,
              //EdgeInsets.all(15),
              child: Container(
                  margin: EdgeInsets.all(10),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text('상태 변경 이력', style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD)),
                      ),
                      SizedBox(height: 5),
                      Expanded(child: getHistoryTabView()),
                    ],
                  )),
            ),
          ],
        ),
      ),
      // body: SingleChildScrollView(
      //   child: Column(
      //     children: [
      //       SizedBox(height: 10),
      //       Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
      //     ],
      //   ),
      // ),
      //bottomNavigationBar: buttonBar,
    );

    return SizedBox(
      width: 800,
      height: 600,
      child: result,
    );
  }

  Widget getHistoryTabView() {
    return ListView.builder(
      controller: _scrollController,
      //padding: const EdgeInsets.symmetric(horizontal: 4.0, vertical: 8.0),
      itemCount: 0,
      itemBuilder: (BuildContext context, int index) {
        return GestureDetector(
          child: Card(
            color: Colors.white,
            elevation: 2.0,
            child: ListTile(
              title: Row(
                children: [
                  //Text('No.' + imageHistoryList[index].no.toString() ?? '--', style: TextStyle(fontWeight: FONT_BOLD, fontSize: 13)),
                  Container(
                      width: 280,
                      padding: EdgeInsets.only(top: 5),
                      child: SelectableText(
                        '--',
                        style: TextStyle(fontWeight: FONT_BOLD, fontSize: 13, color: Colors.black87),
                        showCursor: true,
                      )),
                ],
              ),
              subtitle: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [Container(alignment: Alignment.centerRight, child: Text('--', style: TextStyle(fontSize: 12), textAlign: TextAlign.right))],
              ),
            ),
          ),
        );
      },
    );
  }
}
