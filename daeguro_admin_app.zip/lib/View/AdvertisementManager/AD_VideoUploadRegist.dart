
import 'dart:io';

import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsRegistModel.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contents_controller.dart';
import 'package:daeguro_admin_app/View/CouponManager/coupon_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class AD_VideoUploadRegist extends StatefulWidget {
  const AD_VideoUploadRegist({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return AD_VideoUploadRegistState();
  }
}

class AD_VideoUploadRegistState extends State<AD_VideoUploadRegist> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  ContentsRegistModel formData;

  bool isImageSaveEnabled = false;
  bool isFileSaveEnabled = false;

  String _pickedImagePath = '';

  var _fileImage = null;

  @override
  void initState() {
    super.initState();

    Get.put(CouponController());

    formData = ContentsRegistModel();
  }

  @override
  void dispose() {
    formData = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: Container(
                  margin: EdgeInsets.all(8.0),
                  decoration: new BoxDecoration(color: formData.disp_gbn == 'Y' ? Colors.blue[200] : Colors.red[200], borderRadius: new BorderRadius.circular(6)),
                  child: SwitchListTile(
                    dense: true,
                    value: formData.disp_gbn == 'Y' ? true : false,
                    title: Text(
                      '게시 유무',
                      style: TextStyle(fontSize: 10, color: Colors.white),
                    ),
                    onChanged: (v) {
                      setState(() {
                        formData.disp_gbn = v ? 'Y' : 'N';
                        formKey.currentState.save();
                      });
                    },
                  ),
                ),
              ),
              // Flexible(
              //   flex: 1,
              //   child: Container(),
              // ),
            ],
          ),
          ISInput(
            autofocus: true,
            value: formData.contents_title,
            label: '제목',
            onSaved: (v) {
              formData.contents_title = v;
            },
          ),
          // ISInput(
          //   autofocus: true,
          //   value: formData.main_url,
          //   label: '블로그 URL',
          //   onSaved: (v) {
          //     formData.main_url = v;
          //   },
          // ),
          // ISInput(
          //   value: formData.thumbnail_url,
          //   context: context,
          //   label: '썸네일 이미지 URL',
          //   height: 80,
          //   contentPadding: 20,
          //   keyboardType: TextInputType.multiline,
          //   maxLines: 4,
          //   onSaved: (v) {
          //     formData.thumbnail_url = v;
          //   },
          // ),
          //Row(
            //children: [
              Container(
                  padding: EdgeInsets.only(left: 8.0),
                  child: Row(
                    children: [
                      Text('- 광고 영상 파일', style: TextStyle(fontWeight: FONT_BOLD),),
                      SizedBox(width: 10,),
                      AnimatedOpacity(
                        opacity: isImageSaveEnabled ? 1.0 : 0.0,
                        duration: Duration(seconds: 1),
                        child: Row(
                          children: [
                            Icon(Icons.info_outline, color: Colors.red, size: 18,),
                            Text('저장 완료', style: TextStyle(color: Colors.red, fontWeight: FONT_BOLD),),
                          ],
                        ),
                        onEnd: (){
                          setState(() {
                            isImageSaveEnabled = false;
                          });
                        },
                      ),
                    ],
                  )
              ),
              ISInput(
                value: _pickedImagePath,
                readOnly: true,
                context: context,
                label: '파일 선택(클릭)',
                //hintText: '클릭 후, 파일 선택',
                onTap: () async {
                  FilePickerResult result = await FilePicker.platform.pickFiles(withReadStream: false);

                  if (result != null) {
                    _fileImage = null;
                    _fileImage = result;

                    String fileName = result.files.first.name;
                    _pickedImagePath = fileName;
                  }
                  else {
                    // User canceled the picker
                  }

                  setState(() {});
                },
                prefixIcon: Icon(_fileImage == null ? Icons.help_outline : Icons.check_circle_outline, color: _fileImage == null ? Colors.red : Colors.blue, size: 18,),
                suffixIcon: MaterialButton(
                  color: Colors.blue,
                  minWidth: 40,
                  child: Icon(Icons.file_upload, color: Colors.white, size: 18,),//Text('저장', style: TextStyle(color: Colors.white, fontSize: 14),),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                  onPressed: () async {
                    // if (_fileImage == null || _pickedImagePath == '') {
                    //   ISAlert(context, '선택된 파일이 없습니다.');
                    //   return;
                    // }



                    String ftp_host = 'insung.fastedge.net';
                    String ftp_user = 'insung';
                    String ftp_pass = 'sjh9dnjf27dlf!@#\$5';

                    // try{
                    //   print('------- FTP Connect[host:${ftp_host}, user:${ftp_user}, pass:${ftp_pass}]');
                    //   FTPClient ftpClient = FTPClient(ftp_host, user: ftp_user, pass: ftp_pass);
                    //
                    //
                    //   ftpClient.connect();
                    //   print('------- FTP Connect Success!!!');
                    //   File fileToUpload = await _fileMock(fileName: 'uploadStepByStep.txt', content: 'uploaded Step By Step');
                    //   print('------- FTP File Create Success!!!');
                    //   ftpClient.uploadFile(fileToUpload);
                    //   print('------- FTP File Upload Success!!!');
                    //   ftpClient.disconnect();
                    // }
                    // catch (e) {
                    //   await print('Error: ${e.toString()}');
                    // }



                    // final FTPConnect _ftpConnect = new FTPConnect(ftp_host, user: ftp_user, pass: ftp_pass, debug: true, isSecured: false);
                    //
                    // ///an auxiliary function that manage showed log to UI
                    // Future<void> _log(String log) async {
                    //   print(log);
                    //   await Future.delayed(Duration(seconds: 1));
                    // }
                    //
                    // ///mock a file for the demonstration example
                    // Future<File> _fileMock({fileName = 'FlutterTest.txt', content = ''}) async {
                    //   final Directory directory = Directory('/test')..createSync(recursive: true);
                    //   final File file = File('${directory.path}/$fileName');
                    //   await file.writeAsString(content);
                    //
                    //   return file;
                    // }
                    //
                    // Future<void> _uploadStepByStep() async {
                    //   try {
                    //     await _log('Connecting to FTP ...');
                    //     await _ftpConnect.connect();
                    //     await _ftpConnect.changeDirectory('upload');
                    //     File fileToUpload = await _fileMock(fileName: 'uploadStepByStep.txt', content: 'uploaded Step By Step');
                    //     await _log('Uploading ...');
                    //     await _ftpConnect.uploadFile(fileToUpload);
                    //     await _log('file uploaded sucessfully');
                    //     await _ftpConnect.disconnect();
                    //   }
                    //   catch (e) {
                    //     await _log('Error: ${e.toString()}');
                    //   }
                    // }
                    // await _uploadStepByStep();
                    //
                    // var request = http.MultipartRequest('POST', Uri.parse(ServerInfo.REST_RESERVEURL + '/notice/setNoticeFile?div=0'));
                    // request.headers.addAll({'Content-Type' : 'multipart/form-data'});
                    //
                    // var bytes = _fileImage.files.first.bytes;
                    // String filename = _fileImage.files.first.name;
                    //
                    // request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
                    //
                    // request.send().then((response) async {
                    //   if (response.statusCode == 200) {
                    //     response.stream.bytesToString().asStream().listen((event) async {
                    //       var responseData = json.decode(event);
                    //       await DioClient().postRestLog('0', '/notice/setNoticeFile', 'Image upload Success \n\n statusCode: ${response.statusCode} \n msg: ${responseData['msg'].toString()} ');
                    //       //print('response code:${response.statusCode}, responseData:${responseData.toString()}');
                    //       //print('response path:${responseData['msg'].toString()}');
                    //
                    //       setState(() {
                    //         isImageSaveEnabled = true;
                    //       });
                    //     });
                    //   }
                    //   else{
                    //     _showResult = '[전송오류] 관리자에게 문의하세요.';
                    //
                    //     await DioClient().postRestLog('0', '/Notice/post', 'Image upload Fail \n\n statusCode: ${response.statusCode} \n param:${request.fields.toString()}');
                    //   }
                    // });
                  },
                ),
                onChange: (v) {
                  //editData.noticeTitle = v;
                },
              ),
            //],
          //)
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            form.save();

            formData.ins_ucode = GetStorage().read('logininfo')['uCode'];
            //formData.startDate = _startDate;

            ContentsController.to.postContents(formData.toJson(), context);

            Navigator.pop(context, true);
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('웹툰 컨텐츠 등록'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10),
            Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );

    return SizedBox(
      width: 450,
      height: 400,
      child: result,
    );
  }

  Future<File> _fileMock({fileName = 'FlutterTest.txt', content = ''}) async {
    final Directory directory = Directory('/test')..createSync(recursive: true);
    final File file = File('${directory.path}/$fileName');
    await file.writeAsString(content);

    return file;
  }
}
