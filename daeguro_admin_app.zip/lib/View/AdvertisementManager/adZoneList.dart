import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_date.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_input.dart';
import 'package:daeguro_admin_app/Model/search_items.dart';
import 'package:daeguro_admin_app/Model/voucher/voucherCancelListModel.dart';
import 'package:daeguro_admin_app/Model/voucher/voucherExpListModel.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/AdvertisementManager/adZoneDetail.dart';
import 'package:daeguro_admin_app/View/AdvertisementManager/adZoneRegist.dart';
import 'package:daeguro_admin_app/View/AdvertisementManager/adZoneUpdateSort.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucherExpHistory.dart';
import 'package:daeguro_admin_app/View/VoucherManager/voucher_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:date_format/date_format.dart';
import 'package:dropdown_button2/dropdown_button2.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

import 'package:get/get.dart';

class adZoneList extends StatefulWidget {
  const adZoneList({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return adZoneListState();
  }
}

class adZoneListState extends State<adZoneList> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final List<VoucherCancelListModel> dataList = <VoucherCancelListModel>[];

  String _openGbn = '1';
  SearchItems _searchItems = new SearchItems();

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    dataList.clear();

    _searchItems = null;
    _searchItems = new SearchItems();

    _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    _searchItems.enddate = formatDate(DateTime(int.parse(DateTime.now().year.toString()), int.parse(DateTime.now().month.toString()) + 1, 0), [yyyy, '-', mm, '-', dd]);
  }

  _query() {
    formKey.currentState.save();

    VoucherController.to.page.value = _currentPage;
    VoucherController.to.rows.value = _selectedpagerows;

    loadData();
  }

  _regist() async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: AdZoneRegist(),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 500), () {
          loadData();
        });
      }
    });
  }

  _detail() async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: AdZoneDetail(),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 500), () {
          loadData();
        });
      }
    });
  }

  _updateSort() async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: AdZoneUpdateSort(),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 500), () {
          loadData();
        });
      }
    });
  }

  loadData() async {
    await ISProgressDialog(context).show(status: 'Loading...');

    dataList.clear();

    await VoucherController.to.getVoucherCancelListData(_openGbn, _searchItems.code, _searchItems.startdate.replaceAll('-', ''), _searchItems.enddate.replaceAll('-', '')).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((element) {
          VoucherCancelListModel temp = VoucherCancelListModel(); //.fromJson(e);

          temp.selected = element['selected'] as bool;
          temp.cust_code = element['cust_code'] as String;
          temp.cust_name = element['cust_name'] as String;
          temp.telno = element['telno'] as String;
          temp.voucher_type = element['voucher_type'] as String;
          temp.voucher_name = element['voucher_name'] as String;
          temp.voucher_amt = element['voucher_amt'] as String;
          temp.voucher_no = element['voucher_no'] as String;
          temp.after_exp_dt = element['after_exp_dt'] as String;
          temp.partial_cancel_dt = element['partial_cancel_dt'] as String;
          temp.status = element['status'] as String;
          temp.fail_reason = element['fail_reason'] as String;

          dataList.add(temp);
        });

        _totalRowCnt = VoucherController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
      }
    });

    if (this.mounted) {
      setState(() {});
    }

    await ISProgressDialog(context).dismiss();
  }

  @override
  void initState() {
    super.initState();

    Get.put(VoucherController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      _query();
    });

    setState(() {
      _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
      _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    });
  }

  @override
  void dispose() {
    dataList.clear();

    //MCodeListitems.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //testSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Row(
            children: [
              Text(
                '총: ${Utils.getCashComma(VoucherController.to.totalRowCnt.toString())}건',
                style: TextStyle(fontSize: 12, fontWeight: FONT_BOLD),
              ),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Column(
                children: [
                  ISSearchSelectDate(
                    context,
                    label: '시작일',
                    width: 120,
                    value: _searchItems.startdate.toString(),
                    onTap: () async {
                      DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.startdate);
                      final DateTime picked = await showDatePicker(
                        context: context,
                        initialDate: valueDt,
                        firstDate: DateTime(1900, 1),
                        lastDate: DateTime(2031, 12),
                      );

                      setState(() {
                        if (picked != null) {
                          _searchItems.startdate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                        }
                      });
                    },
                  ),
                  SizedBox(height: 8),
                  ISSearchDropdown(
                    label: '게시유무',
                    width: 120,
                    value: _openGbn,
                    onChange: (value) {
                      setState(() {
                        _openGbn = value;
                        _query();
                      });
                    },
                    item: [DropdownMenuItem(value: ' ', child: Text('전체')), DropdownMenuItem(value: '1', child: Text('게시')), DropdownMenuItem(value: '2', child: Text('미게시'))].cast<DropdownMenuItem<String>>(),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                      padding: EdgeInsets.only(right: 8.0),
                      child: Row(
                        children: [
                          ISSearchSelectDate(
                            context,
                            label: '시작일',
                            width: 120,
                            value: _searchItems.startdate.toString(),
                            onTap: () async {
                              DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.startdate);
                              final DateTime picked = await showDatePicker(
                                context: context,
                                initialDate: valueDt,
                                firstDate: DateTime(1900, 1),
                                lastDate: DateTime(2031, 12),
                              );

                              setState(() {
                                if (picked != null) {
                                  _searchItems.startdate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                                }
                              });
                            },
                          ),
                          SizedBox(width: 8),
                          ISSearchButton(
                              label: '노출 순서',
                              iconData: Icons.autorenew,
                              onPressed: () => {
                                    if (EasyLoading.isShow != true) {_updateSort()}
                                  }),
                        ],
                      )),
                  SizedBox(height: 8),
                  Container(
                    child: Stack(
                      alignment: Alignment.centerRight,
                      children: [
                        ISSearchInput(
                          label: '순번, 게시제목',
                          width: 245,
                          value: _searchItems.code,
                          onChange: (v) {
                            _searchItems.code = v;
                          },
                          onFieldSubmitted: (value) {
                            _currentPage = 1;
                            _query();
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  ISSearchButton(
                      label: '등록',
                      iconData: Icons.add,
                      onPressed: () => {
                            if (EasyLoading.isShow != true) {_regist()}
                          }),
                  SizedBox(height: 8),
                  ISSearchButton(
                      label: '조회',
                      iconData: Icons.search,
                      onPressed: () => {
                            if (EasyLoading.isShow != true) {_currentPage = 1, _query()}
                          }),
                ],
              ),
              SizedBox(width: 8),
              ISSearchButton(
                  label: '상세',
                  iconData: Icons.search,
                  onPressed: () => {
                        if (EasyLoading.isShow != true) {_detail()}
                      }),
            ],
          ),
        ],
      ),
    );

    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          form,
          buttonBar,
          Divider(),
          ISDatatable(
            panelHeight: (MediaQuery.of(context).size.height - defaultContentsHeight) - 48,
            listWidth: Responsive.getResponsiveWidth(context, 640),
            rows: dataList.map((item) {
              return DataRow(cells: [
                //DataCell(Align(child: SelectableText(item.SHOP_NAME.toString() == null ? '--' : '[' + item.SHOP_CD.toString() + '] ' + item.SHOP_NAME.toString(), showCursor: true), alignment: Alignment.centerLeft,)),
                DataCell(Align(child: SelectableText(item.cust_name.toString(), showCursor: true), alignment: Alignment.center)),
                DataCell(Align(child: SelectableText(Utils.getPhoneNumFormat(item.telno.toString(), true), showCursor: true), alignment: Alignment.center)),
                DataCell(Align(child: SelectableText(item.voucher_name.toString(), showCursor: true), alignment: Alignment.centerLeft)),
                DataCell(Align(child: SelectableText(item.voucher_name.toString(), showCursor: true), alignment: Alignment.centerLeft)),
                DataCell(Align(
                  child: SelectableText(Utils.getCashComma(item.voucher_amt.toString()), style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY), showCursor: true),
                  alignment: Alignment.center,
                )),
                DataCell(Align(child: SelectableText(item.voucher_no.toString(), showCursor: true), alignment: Alignment.centerLeft)),
                DataCell(Align(child: SelectableText(Utils.getYearMonthDayFormat(item.after_exp_dt.toString()), showCursor: true), alignment: Alignment.center)),
                DataCell(Align(child: SelectableText(Utils.getYearMonthDayFormat(item.partial_cancel_dt.toString()), showCursor: true), alignment: Alignment.center)),
                DataCell(Align(child: SelectableText(item.status.toString(), showCursor: true), alignment: Alignment.center)),
                DataCell(Align(child: SelectableText(item.fail_reason.toString(), showCursor: true), alignment: Alignment.centerLeft)),
                DataCell(Align(child: SelectableText(item.fail_reason.toString(), showCursor: true), alignment: Alignment.centerLeft)),
              ]);
            }).toList(),
            columns: <DataColumn>[
              DataColumn(label: Expanded(child: SelectableText('순번', textAlign: TextAlign.center))),
              DataColumn(label: Expanded(child: SelectableText('게시제목', textAlign: TextAlign.center))),
              DataColumn(label: Expanded(child: SelectableText('회사 상호명', textAlign: TextAlign.left))),
              DataColumn(label: Expanded(child: SelectableText('게시유무', textAlign: TextAlign.left))),
              DataColumn(label: Expanded(child: SelectableText('노출순서', textAlign: TextAlign.center))),
              DataColumn(label: Expanded(child: SelectableText('게시 시작일', textAlign: TextAlign.left))),
              DataColumn(label: Expanded(child: SelectableText('게시 종료일', textAlign: TextAlign.center))),
              DataColumn(label: Expanded(child: SelectableText('남은 쿠폰수', textAlign: TextAlign.center))),
              DataColumn(label: Expanded(child: SelectableText('등록정보', textAlign: TextAlign.center))),
              DataColumn(label: Expanded(child: SelectableText('상세', textAlign: TextAlign.left))),
              DataColumn(label: Expanded(child: SelectableText('관리', textAlign: TextAlign.left))),
            ],
          ),
          Divider(),
          SizedBox(
            height: 0,
          ),
          showPagerBar(),
        ],
      ),
    );
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                //Text('row1'),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context)
                ? Container(height: 48)
                : Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      Text(
                        '페이지당 행 수 : ',
                        style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL),
                      ),
                      Container(
                        width: 70,
                        height: 24,
                        decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(5.0)),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton2(
                              value: _selectedpagerows,
                              isExpanded: true,
                              style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: FONT_FAMILY),
                              items: Utils.getPageRowList(),
                              dropdownMaxHeight: 180,
                              itemHeight: 36,
                              itemPadding: const EdgeInsets.only(left: 16, right: 16),
                              dropdownPadding: const EdgeInsets.symmetric(vertical: 6),
                              dropdownDecoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(6),
                              ),
                              onChanged: (value) {
                                setState(() {
                                  _selectedpagerows = value;
                                  _currentPage = 1;
                                  _query();
                                });
                              }),
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}
