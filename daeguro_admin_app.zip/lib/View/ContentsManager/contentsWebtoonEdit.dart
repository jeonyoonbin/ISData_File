import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsDetailList.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsEditModel.dart';
import 'package:daeguro_admin_app/Network/FileUpLoader.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contents_controller.dart';
import 'package:daeguro_admin_app/constants/serverInfo.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker_web/image_picker_web.dart';
import 'package:mime_type/mime_type.dart';
import 'dart:html' as html;
import 'package:path/path.dart' as Path;
import 'package:url_launcher/url_launcher.dart';

class ContentsWebtoonEdit extends StatefulWidget {
  final String contents_cd;

  const ContentsWebtoonEdit({Key key, this.contents_cd}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ContentsWebtoonEditState();
  }
}

class ContentsWebtoonEditState extends State<ContentsWebtoonEdit> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  ContentsDetailList formData;
  ContentsEditModel editData;

  String _themeImageURL = '';
  String _themeImageRealURL = '';
  String _mCode = '2';

  html.File _cloudFile;
  var _fileBytes;
  String _fileName;
  Image _imageWidget;

  String _uploadGbn = '';

  var _file;
  var responseData;

  loadData() async {
    formData = null;
    formData = ContentsDetailList();

    await ContentsController.to.getDetailData(widget.contents_cd).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        formData = ContentsDetailList.fromJson(value);

        _themeImageURL = formData.FILE_NAME;
        _themeImageRealURL = formData.GET_THUMBNAIL_URL;
      }
    });

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ContentsController());
    editData = ContentsEditModel();

    editData.cartegory_gbn = 'A';

    loadData();
  }

  @override
  void dispose() {
    formData = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: Container(
                  margin: EdgeInsets.all(8.0),
                  decoration: new BoxDecoration(color: formData.DISP_GBN == 'Y' ? Colors.blue[200] : Colors.red[200], borderRadius: new BorderRadius.circular(6)),
                  child: SwitchListTile(
                    dense: true,
                    value: formData.DISP_GBN == 'Y' ? true : false,
                    title: Text(
                      '게시 유무',
                      style: TextStyle(fontSize: 10, color: Colors.white),
                    ),
                    onChanged: (v) {
                      setState(() {
                        formData.DISP_GBN = v ? 'Y' : 'N';
                        formKey.currentState.save();
                      });
                    },
                  ),
                ),
              ),
              // Flexible(
              //   flex: 1,
              //   child: Container(),
              // ),
            ],
          ),
          ISInput(
            autofocus: true,
            value: formData.CONTENTS_TITLE,
            label: '제목',
            maxLines: 2,
            height: 60,
            //maxLength: 8,
            keyboardType: TextInputType.multiline,
            onChange: (v) {
              if(v.toString().replaceAll('\n', '').length > 8) {
                ISAlert(context, '제목은 8글자 이상 입력 할 수 없습니다.');

                // 개행 들어있을경우 9자 짤라서 저장
                if(v.toString().contains('\n')) {
                  formData.CONTENTS_TITLE = v.toString().substring(0, 9);
                } else {
                  formData.CONTENTS_TITLE = v.toString().substring(0, 8);
                }

                setState(() {});
              } else {
                formData.CONTENTS_TITLE = v;
              }
            },
          ),
          ISInput(
            autofocus: true,
            value: formData.MAIN_URL,
            label: 'URL',
            onSaved: (v) {
              formData.MAIN_URL = v;
            },
          ),
          ISInput(
            autofocus: true,
            value: formData.URL_TITLE,
            label: '메인 링크 제목',
            onSaved: (v) {
              formData.URL_TITLE = v;
            },
          ),
          Container(
              margin: EdgeInsets.only(left: 10, top: 5),
              child: Row(
                children: [
                  if (ServerInfo.jobMode == 'dev' ? AuthUtil.isAuthEditEnabled('236') : AuthUtil.isAuthEditEnabled('236') == true)
                    MaterialButton(
                      color: Colors.blue,
                      minWidth: 80,
                      height: 30,
                      child: Text(
                        '이미지 업로드',
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                      onPressed: () async {
                        await ISProgressDialog(context).show(status: '이미지 업로드중...');

                        var mediaData = await ImagePickerWeb.getImageInfo;

                        String mimeType = mime(Path.basename(mediaData.fileName));
                        html.File mediaFile = new html.File(mediaData.data, mediaData.fileName, {'type': mimeType});

                        if (mediaFile != null) {
                          setState(() {
                            _cloudFile = mediaFile;
                            _fileBytes = mediaData.data;
                            _fileName = mediaData.fileName;
                            _imageWidget = Image.memory(mediaData.data);
                          });
                        }

                        if(mediaFile.type.toString() == 'image/gif') {
                          _uploadGbn = 'file';
                        } else {
                          _uploadGbn = 'image';
                        }

                        _file = _fileBytes;

                        FileUpLoadProvider provider = FileUpLoadProvider();
                        provider.setResource(_uploadGbn, _file);

                        provider.uploadContentsImageResourceRequest(widget.contents_cd, _fileName).then((value) async {
                          //loadSubCategoryDetail(_selectedSubCode);

                          loadData();
                          setState(() {
                            //Url_1 = file.path;
                          });

                          await Future.delayed(Duration(milliseconds: 500), () {
                            setState(() {
                              _deleteImageFromCache();
                            });
                          });
                        });

                        await ISProgressDialog(context).dismiss();
                      },
                    ),
                  if (_themeImageURL != '' && ServerInfo.jobMode == 'dev' ? AuthUtil.isAuthEditEnabled('276') : AuthUtil.isAuthEditEnabled('278') == true)
                    Row(
                      children: [
                        SizedBox(
                          width: 8,
                        ),
                        MaterialButton(
                          color: Colors.blue,
                          minWidth: 40,
                          height: 30,
                          child: Text(
                            '삭제',
                            style: TextStyle(color: Colors.white, fontSize: 12),
                          ),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                          onPressed: () {
                            if (_themeImageURL == '' || _themeImageURL == null || _themeImageURL == 'null') return;

                            ISConfirm(context, '대문 컨텐츠 이미지 삭제', '해당 이미지를 삭제하시겠습니까?', (context) async {
                              ContentsController.to.deleteContentsImage(widget.contents_cd, _themeImageURL, context).then((value) {
                                if (value != null) {
                                  ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                } else {
                                  loadData();

                                  Navigator.pop(context);

                                  setState(() {});
                                }
                              });
                            });
                          },
                        ),
                        SizedBox(
                          width: 8,
                        ),
                      ],
                    ),
                  //Text(_themeImageURL == '' ? '저장된 파일이 없습니다.' : _themeImageURL, style: TextStyle(fontSize: 12))
                  _themeImageURL == '' || _themeImageURL == null || _themeImageURL == 'null'
                      ? Text('저장된 파일이 없습니다.', style: TextStyle(fontSize: 12))
                      : MaterialButton(
                    height: 30.0,
                    child: Text(_themeImageURL, style: TextStyle(color: Colors.black, fontSize: 13)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                    onPressed: () {
                      _launchInBrowser(_themeImageRealURL + '?tm=${Utils.getTimeStamp()}');
                    },
                  )
                ],
              )
          ),
          Container(margin: EdgeInsets.only(left: 10, top: 5), child: Text('* 이미지 사이즈는 212*212px 업로드 가능합니다.', style: TextStyle(fontSize: 12, color: Colors.black54)))
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            form.save();

            editData.contents_cd = widget.contents_cd;
            editData.contents_title = formData.CONTENTS_TITLE;
            editData.disp_gbn = formData.DISP_GBN;
            editData.main_url = formData.MAIN_URL;
            editData.url_title = formData.URL_TITLE;
            editData.mod_ucode = GetStorage().read('logininfo')['uCode'];

            ContentsController.to.putContents(editData.toJson(), context);

            Navigator.pop(context, true);
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('대문 컨텐츠 수정'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10),
            Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );

    return SizedBox(
      width: 480,
      height: 420,
      child: result,
    );
  }

  Future<void> _launchInBrowser(String url) async {
    if (await canLaunch(url)) {
      await launch(
        url,
        forceSafariVC: false, //true로 설정시, iOS 인앱 브라우저를 통해픈
        forceWebView: false, //true로 설정시, Android 인앱 브라우저를 통해 오픈
        headers: <String, String>{'my_header_key': 'my_header_value'},
      );
    } else {
      throw 'Web Request Fail $url';
    }
  }

  Future _deleteImageFromCache() async {
    //await CachedNetworkImage.evictFromCache(url);

    PaintingBinding.instance.imageCache.clearLiveImages();
    PaintingBinding.instance.imageCache.clear();

    //await DefaultCacheManager().removeFile(key);
    //await DefaultCacheManager().emptyCache();
    setState(() {});
  }
}