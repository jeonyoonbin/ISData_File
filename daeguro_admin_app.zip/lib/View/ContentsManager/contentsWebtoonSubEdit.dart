import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/is_select_date.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsRegistModel.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsSubDetailList.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsSubRegistModel.dart';
import 'package:daeguro_admin_app/Model/coupon/couponRegistModel.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contents_controller.dart';
import 'package:daeguro_admin_app/View/CouponManager/coupon_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ContentsWebtoonSubEdit extends StatefulWidget {
  final String webToonTitle;
  final String seq;

  const ContentsWebtoonSubEdit({Key key, this.webToonTitle, this.seq}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ContentsWebtoonSubEditState();
  }
}

class ContentsWebtoonSubEditState extends State<ContentsWebtoonSubEdit> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  ContentsSubRegistModel formData;
  ContentsSubDetailList dataList;

  loadData() async {
    dataList = null;
    dataList = ContentsSubDetailList();

    await ContentsController.to.getSubDetailData(widget.seq).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        dataList = ContentsSubDetailList.fromJson(value);
      }
    });
    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(CouponController());

    formData = ContentsSubRegistModel();

    formData.seq = widget.seq;

    loadData();
  }

  @override
  void dispose() {
    formData = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: Container(
                  margin: EdgeInsets.all(8.0),
                  decoration: new BoxDecoration(color: dataList.DISP_GBN == 'Y' ? Colors.blue[200] : Colors.red[200], borderRadius: new BorderRadius.circular(6)),
                  child: SwitchListTile(
                    dense: true,
                    value: dataList.DISP_GBN == 'Y' ? true : false,
                    title: Text(
                      '게시 유무',
                      style: TextStyle(fontSize: 10, color: Colors.white),
                    ),
                    onChanged: (v) {
                      setState(() {
                        dataList.DISP_GBN = v ? 'Y' : 'N';
                        formKey.currentState.save();
                      });
                    },
                  ),
                ),
              ),
              Flexible(
                flex: 1,
                child: ISSelectDate(
                  context,
                  label: '게시글 업로드 일자',
                  width: 140,
                  value: Utils.getYearMonthDayFormat(dataList.DISP_ST_DATE),
                  onTap: () async {
                    DateTime valueDt = dataList.DISP_ST_DATE == null || dataList.DISP_ST_DATE == '' ? DateTime.now() : DateTime.parse(dataList.DISP_ST_DATE.replaceAll('-', ''));

                    final DateTime picked = await showDatePicker(
                      context: context,
                      initialDate: valueDt,
                      firstDate: DateTime(1900, 1),
                      lastDate: DateTime(2031, 12),
                    );

                    setState(() {
                      if (picked != null) {
                        dataList.DISP_ST_DATE = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                      }
                    });
                  },
                ),
              ),
              // Flexible(
              //   flex: 1,
              //   child: Container(),
              // ),
            ],
          ),
          ISInput(
            autofocus: true,
            value: dataList.EP_TITLE,
            label: '제목',
            onSaved: (v) {
              dataList.EP_TITLE = v;
            },
          ),
          ISInput(
            value: dataList.THUMBNAIL_URL,
            context: context,
            label: '썸네일 이미지 URL',
            height: 80,
            contentPadding: 20,
            keyboardType: TextInputType.multiline,
            maxLines: 4,
            onSaved: (v) {
              dataList.THUMBNAIL_URL = v;
            },
          ),
          ISInput(
            autofocus: true,
            value: dataList.CONTENTS_URL,
            label: '블로그 링크 URL',
            onSaved: (v) {
              dataList.CONTENTS_URL = v;
            },
          ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            form.save();

            formData.ep_title = dataList.EP_TITLE;
            formData.disp_gbn = dataList.DISP_GBN;
            formData.contents_url = dataList.CONTENTS_URL;
            formData.thumbnail_url = dataList.THUMBNAIL_URL;
            formData.disp_st_date = dataList.DISP_ST_DATE.replaceAll('-', '');

            formData.mod_ucode = GetStorage().read('logininfo')['uCode'];

            ContentsController.to.putSubContents(formData.toJson(), context);

            Navigator.pop(context, true);
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('대문 하위 컨텐츠 수정'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10),
            Row(
              children: [
                SizedBox(width: 20),
                Align(
                    child: Row(
                      children: [
                        Text('대문 제목 : ', style: TextStyle(fontSize: 13)),
                        Text(widget.webToonTitle, style: TextStyle(fontWeight: FONT_BOLD, fontSize: 17)),
                      ],
                    ),
                    alignment: Alignment.centerLeft),
              ],
            ),
            SizedBox(height: 10),
            Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );

    return SizedBox(
      width: 450,
      height: 420,
      child: result,
    );
  }
}
