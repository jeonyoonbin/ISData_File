import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/is_select_date.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsRegistModel.dart';
import 'package:daeguro_admin_app/Model/coupon/couponRegistModel.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contents_controller.dart';
import 'package:daeguro_admin_app/View/CouponManager/coupon_controller.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ContentsBlogRegist extends StatefulWidget {
  const ContentsBlogRegist({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ContentsBlogRegistState();
  }
}

class ContentsBlogRegistState extends State<ContentsBlogRegist> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  ContentsRegistModel formData;
  String _expDate = '';

  List<SelectOptionVO> selectBox_couponType = List();
  List<SelectOptionVO> selectBox_couponItem = List();

  @override
  void initState() {
    super.initState();

    Get.put(CouponController());

    formData = ContentsRegistModel();

    formData.cartegory_gbn = 'R';
    formData.disp_gbn = 'Y';
  }

  @override
  void dispose() {
    selectBox_couponType.clear();

    selectBox_couponType = null;
    formData = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: Container(
                  margin: EdgeInsets.all(8.0),
                  decoration: new BoxDecoration(color: formData.disp_gbn == 'Y' ? Colors.blue[200] : Colors.red[200], borderRadius: new BorderRadius.circular(6)),
                  child: SwitchListTile(
                    dense: true,
                    value: formData.disp_gbn == 'Y' ? true : false,
                    title: Text(
                      '게시 유무',
                      style: TextStyle(fontSize: 10, color: Colors.white),
                    ),
                    onChanged: (v) {
                      setState(() {
                        formData.disp_gbn = v ? 'Y' : 'N';
                        formKey.currentState.save();
                      });
                    },
                  ),
                ),
              ),
              // Flexible(
              //   flex: 1,
              //   child: Container(),
              // ),
            ],
          ),
          ISInput(
            autofocus: true,
            value: formData.contents_title,
            label: '제목',
            onSaved: (v) {
              formData.contents_title = v;
            },
          ),
          ISInput(
            autofocus: true,
            value: formData.main_url,
            label: '블로그 URL',
            onSaved: (v) {
              formData.main_url = v;
            },
          ),
          ISInput(
            value: formData.thumbnail_url,
            context: context,
            label: '썸네일 이미지 URL',
            height: 80,
            contentPadding: 20,
            keyboardType: TextInputType.multiline,
            maxLines: 4,
            onSaved: (v) {
              formData.thumbnail_url = v;
            },
          ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            form.save();

            formData.ins_ucode = GetStorage().read('logininfo')['uCode'];
            //formData.startDate = _startDate;

            ContentsController.to.postContents(formData.toJson(), context);

            Navigator.pop(context, true);
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('블로그 컨텐츠 등록'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10),
            Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );

    return SizedBox(
      width: 450,
      height: 400,
      child: result,
    );
  }
}
