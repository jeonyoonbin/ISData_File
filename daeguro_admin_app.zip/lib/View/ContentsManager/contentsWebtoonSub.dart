import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsSubListModel.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentWebtoonSubRegist.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsNotifierData.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contentsWebtoonSubEdit.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contents_controller.dart';
import 'package:daeguro_admin_app/View/MappingManager/mappingList.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

import 'package:get/get.dart';

class ContentsWebtoonSub extends StatefulWidget {
  final Stream<ContentsNotifierData> stream;
  final String webToonTitle;
  final double height;

  const ContentsWebtoonSub({Key key, this.stream, this.webToonTitle, this.height}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ContentsWebtoonSubState();
  }
}

class ContentsWebtoonSubState extends State<ContentsWebtoonSub> with SingleTickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  List<ContentsSubListModel> dataSub = <ContentsSubListModel>[];

  ScrollController _scrollController;

  ContentsNotifierData detailData;

  bool isReceiveDataEnabled = false;
  bool isListSaveEnabled = false;

  String _contents_cd;

  void refreshWidget(ContentsNotifierData element) {
    detailData = element;
    _contents_cd = detailData.contents_cd;

    if (detailData != null) {
      loadData();

      isReceiveDataEnabled = true;
    } else {
      dataSub = null;
      dataSub = <ContentsSubListModel>[];

      dataSub.clear();
      isReceiveDataEnabled = false;
    }
    setState(() {});
  }

  loadData() async {
    dataSub.clear();

    await ContentsController.to.getContentsSubData(_contents_cd).then((value) {
      if (this.mounted) {
        if (value == null) {
          ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
        } else {
          value.forEach((element) {
            ContentsSubListModel temp = ContentsSubListModel();//.fromJson(e);

            temp.viewSelected = element['viewSelected'] as bool;
            temp.SEQ = element['SEQ'] as int;
            temp.SORT_SEQ = element['SORT_SEQ'] as int;
            temp.EP_TITLE = element['EP_TITLE'] as String;
            temp.DISP_GBN = element['DISP_GBN'] as String;
            temp.HIT = element['HIT'] as int;
            temp.INS_DATE = element['INS_DATE'] as String;
            temp.INS_UCODE = element['INS_UCODE'] as int;

            dataSub.add(temp);
          });
        }
      }
    });

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ContentsController());

    _scrollController = ScrollController();

    widget.stream.listen((element) {
      refreshWidget(element);
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    detailData = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Container(
        padding: EdgeInsets.only(left: 8.0, right: 8.0, bottom: 8.0), //EdgeInsets.all(8.0),
        child: getInfoView(),
      ),
    );
  }

  Widget getInfoView() {
    return Scrollbar(
      isAlwaysShown: false,
      controller: _scrollController,
      child: Column(
        children: [
          buttonBar(),
          Expanded(
            child: getTermsView(),
          )
        ],
      ),
    );
  }

  Widget getTermsView() {
    return ISDatatable(
      listWidth: 680,
      rows: dataSub.map((item) {
        return DataRow(cells: [
          DataCell(Align(
              child: SelectableText(
                item.SORT_SEQ.toString() ?? '--',
                style: TextStyle(color: Colors.black),
              ),
              alignment: Alignment.center)),
          DataCell(Align(
            child: Text(
              item.EP_TITLE ?? '--',
              style: TextStyle(color: Colors.black),
              textAlign: TextAlign.center,
            ),
            alignment: Alignment.centerLeft,
          )),
          DataCell(Center(
              child:
                  item.DISP_GBN.toString() == 'Y' ? Icon(Icons.radio_button_unchecked, color: Colors.blue, size: 16) : Icon(Icons.clear, color: Colors.red, size: 16))),
          DataCell(Center(
              child: SelectableText(
            item.HIT.toString() ?? '--',
            style: TextStyle(color: Colors.black),
          ))),
          DataCell(
            Center(
              child: InkWell(
                child: Icon(Icons.edit, size: 20),
                onTap: () {
                  if (widget.webToonTitle == null || widget.webToonTitle == '') return;

                  showDialog(
                    context: context,
                    builder: (BuildContext context) => Dialog(
                      child: ContentsWebtoonSubEdit(webToonTitle: widget.webToonTitle, seq: item.SEQ.toString()),
                    ),
                  ).then((v) async {
                    if (v == true) {
                      await Future.delayed(Duration(milliseconds: 500), () {
                        loadData();
                      });
                    }
                  });
                },
              ),
            ),
          ),
        ]);
      }).toList(),
      columns: <DataColumn>[
        DataColumn(
          label: Expanded(child: Text('순번', textAlign: TextAlign.center)),
        ),
        DataColumn(
          label: Expanded(child: Text('제목', textAlign: TextAlign.center)),
        ),
        DataColumn(
          label: Expanded(child: Text('게시유무', textAlign: TextAlign.center)),
        ),
        DataColumn(
          label: Expanded(child: Text('카운터', textAlign: TextAlign.center)),
        ),
        DataColumn(
          label: Expanded(child: Text('관리', textAlign: TextAlign.center)),
        ),
      ],
    );
  }

  Widget buttonBar() {
    return Expanded(
      flex: 0,
      child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Row(
              children: [
                Text(widget.webToonTitle, style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD),),
              ],
            ),
            Row(
              children: [
                Container(
                  height: 50,
                  child: Row(
                    children: [
                      if (AuthUtil.isAuthCreateEnabled('236') == true)
                      ISButton(
                        label: '등록',
                        iconColor: Colors.white,
                        textStyle: TextStyle(color: Colors.white),
                        iconData: Icons.save,
                        onPressed: () async {
                          if (widget.webToonTitle == null || widget.webToonTitle == '') return;

                          showDialog(
                            context: context,
                            builder: (BuildContext context) => Dialog(
                              child: ContentsWebtoonSubRegist(webToonTitle: widget.webToonTitle, contentsCd: _contents_cd),
                            ),
                          ).then((v) async {
                            if (v == true) {
                              await Future.delayed(Duration(milliseconds: 500), () {
                                loadData();
                              });
                            }
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
        ]
      )
    );
    return Container(
      padding: EdgeInsets.only(right: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [

        ],
      ),
    );
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
