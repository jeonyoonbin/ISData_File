import 'dart:convert';

import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/Model/noticeListModel.dart';
import 'package:daeguro_admin_app/Model/noticeSortListModel.dart';
import 'package:daeguro_admin_app/Model/shop/shopmenuoptionsetting.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/NoticeManager/notice_controller.dart';
import 'package:daeguro_admin_app/View/ShopManager/Menu/shopMenuOptionSettingAdd.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccount_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class NoticeUpdateSort extends StatefulWidget {
  final String shopCode;
  final String menuCode;

  const NoticeUpdateSort({Key key, this.shopCode, this.menuCode}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return NoticeUpdateSortState();
  }
}

class NoticeUpdateSortState extends State<NoticeUpdateSort> with SingleTickerProviderStateMixin {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  //final ScrollController _scrollController = ScrollController();
  final List<noticeSortListModel> dataList = <noticeSortListModel>[];
  final List<noticeSortListModel> dataList2 = <noticeSortListModel>[];
  final List<noticeSortListModel> dataList3 = <noticeSortListModel>[];

  TabController _nestedTabController;
  int current_tabIdx = 0;

  bool isSaveEnabled = false;

  _query() {
    //print('call _query() menuCode->'+widget.menuCode);
    //formKey.currentState.save();

    loadData();
  }

  loadData() async {
    dataList.clear();
    dataList2.clear();
    dataList3.clear();

    // 이벤트 바인딩
    await NoticeController.to.getNoticeSortList('3', context);

    if (this.mounted) {
      NoticeController.to.qDataSortList.forEach((e) {
        noticeSortListModel temp = noticeSortListModel.fromJson(e);

        temp.DISP_FR_DATE = Utils.getYearMonthDayFormat(temp.DISP_FR_DATE);
        temp.DISP_TO_DATE = Utils.getYearMonthDayFormat(temp.DISP_TO_DATE);

        dataList.add(temp);
      });

      if (isSaveEnabled == true) {
        await Future.delayed(Duration(milliseconds: 500), () async {
          List<String> sortDataList = [];
          dataList.forEach((element) {
            sortDataList.add(element.NOTICE_SEQ.toString());
          });

          if (sortDataList.length != 0) {
            String jsonData = jsonEncode(sortDataList);
            await NoticeController.to.updateSort(jsonData, context);
          }

          isSaveEnabled = false;
        });
      }

      setState(() {});
    }

    // 메인팝업 조회
    await NoticeController.to.getNoticeSortList('5', context);

    if (this.mounted) {
      NoticeController.to.qDataSortList.forEach((e) {
        noticeSortListModel temp = noticeSortListModel.fromJson(e);

        temp.DISP_FR_DATE = Utils.getYearMonthDayFormat(temp.DISP_FR_DATE);
        temp.DISP_TO_DATE = Utils.getYearMonthDayFormat(temp.DISP_TO_DATE);

        dataList2.add(temp);
      });

      if (isSaveEnabled == true) {
        await Future.delayed(Duration(milliseconds: 500), () async {
          List<String> sortDataList = [];
          dataList2.forEach((element) {
            sortDataList.add(element.NOTICE_SEQ.toString());
          });

          if (sortDataList.length != 0) {
            String jsonData = jsonEncode(sortDataList);
            await NoticeController.to.updateSort(jsonData, context);
          }

          isSaveEnabled = false;
        });
      }

      setState(() {});
    }

    // 공지사항 바인딩
    await NoticeController.to.getNoticeSortList('1', context);

    if (this.mounted) {
      NoticeController.to.qDataSortList.forEach((e) {
        noticeSortListModel temp = noticeSortListModel.fromJson(e);

        temp.DISP_FR_DATE = Utils.getYearMonthDayFormat(temp.DISP_FR_DATE);
        temp.DISP_TO_DATE = Utils.getYearMonthDayFormat(temp.DISP_TO_DATE);

        dataList3.add(temp);
      });

      if (isSaveEnabled == true) {
        await Future.delayed(Duration(milliseconds: 500), () async {
          List<String> sortDataList = [];
          dataList3.forEach((element) {
            sortDataList.add(element.NOTICE_SEQ.toString());
          });

          if (sortDataList.length != 0) {
            String jsonData = jsonEncode(sortDataList);
            await NoticeController.to.updateSort(jsonData, context);
          }

          isSaveEnabled = false;
        });
      }

      setState(() {});
    }
  }

  _editListSort(List<String> sortDataList) async {
    String jsonData = jsonEncode(sortDataList);

    //print(jsonData);

    //print('data set->'+jsonData);
    await NoticeController.to.updateSort(jsonData, context);

    await Future.delayed(Duration(milliseconds: 500), () {
      loadData();
    });
  }

  @override
  void initState() {
    super.initState();

    _nestedTabController = new TabController(length: 3, vsync: this);

    //Get.put(AgentController());

    //formKey.currentState.reset();

    WidgetsBinding.instance.addPostFrameCallback((c) {
      //loadSidoData();
      isSaveEnabled = true;
      _query();
    });
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(left: 30, right: 30),
            child: Text(
              '- 게시 상태만 표시 됩니다.',
              style: TextStyle(fontSize: 12.0),
            ),
          ),
        ],
      ),
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('노출 순서 변경'),
      ),
      body: NestedScrollView(
        floatHeaderSlivers: true,
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[
            SliverAppBar(
              //collapsedHeight: 100.0,
              toolbarHeight: 0.0,
              //backgroundColor: Colors.white,
              //centerTitle: true,
              pinned: true,
              floating: true,
              bottom: TabBar(
                controller: _nestedTabController,
                // indicatorColor: Colors.blue,
                // labelColor: Colors.blue,
                // unselectedLabelColor: Colors.black54,
                //isScrollable: true,
                // indicatorSize: TabBarIndicatorSize.tab,
                tabs: [
                  Tab(
                    text: '이벤트',
                  ),
                  Tab(
                    text: '메인팝업',
                  ),
                  Tab(
                    text: '공지사항',
                  )
                ],
                onTap: (v) {
                  setState(() {
                    current_tabIdx = v;
                    //print('----- current_tabIdx: '+current_tabIdx.toString());
                  });
                },
              ),
            )
          ];
        },
        body: TabBarView(
          controller: _nestedTabController,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 10),
                form,
                SizedBox(height: 10),
                Expanded(
                  child: dataList == null
                      ? Text('Data is Empty')
                      : ReorderableListView(
                          onReorder: _onMenuOptionReorder,
                          scrollDirection: Axis.vertical,
                          padding: const EdgeInsets.only(bottom: 8.0),
                          children: List.generate(dataList.length, (index) {
                            return GestureDetector(
                              // onTap: (){
                              //   Navigator.pushNamed(context, '/editor', arguments: UserController.to.userData[index]);
                              // },
                              key: Key('$index'),
                              child: Card(
                                color: Colors.white,
                                elevation: 2.0,
                                child: ListTile(
                                  //leading: Text(dataList[index].siguName),
                                  title: Row(
                                    children: [
                                      Text(
                                        '[' + dataList[index].NOTICE_SEQ.toString() + '] ' + dataList[index].NOTICE_TITLE ?? '--',
                                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                                      ),
                                      Container(
                                          margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                          width: 30,
                                          height: 16,
                                          alignment: Alignment.center,
                                          color: Color.fromRGBO(87, 170, 58, 0.8431372549019608),
                                          child: Text(
                                            '게시',
                                            style: TextStyle(fontSize: 8, color: Colors.white),
                                          ))
                                    ],
                                  ),
                                  subtitle: Container(
                                    alignment: Alignment.topLeft,
                                    child: Column(
                                      children: [
                                        //Text(dataList[index].noticeContents ?? '--', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10),),
                                        Text(
                                          dataList[index].DISP_FR_DATE + ' ~ ' + dataList[index].DISP_TO_DATE ?? '--',
                                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10),
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            );
                          })),
                ),
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 10),
                form,
                SizedBox(height: 10),
                Expanded(
                  child: dataList2 == null
                      ? Text('Data is Empty')
                      : ReorderableListView(
                          onReorder: _onMenuOptionReorder2,
                          scrollDirection: Axis.vertical,
                          padding: const EdgeInsets.only(bottom: 8.0),
                          children: List.generate(dataList2.length, (index) {
                            return GestureDetector(
                              // onTap: (){
                              //   Navigator.pushNamed(context, '/editor', arguments: UserController.to.userData[index]);
                              // },
                              key: Key('$index'),
                              child: Card(
                                color: Colors.white,
                                elevation: 2.0,
                                child: ListTile(
                                  //leading: Text(dataList2[index].siguName),
                                  title: Row(
                                    children: [
                                      Text(
                                        '[' + dataList2[index].NOTICE_SEQ.toString() + '] ' + dataList2[index].NOTICE_TITLE ?? '--',
                                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                                      ),
                                      Container(
                                          margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                          width: 30,
                                          height: 16,
                                          alignment: Alignment.center,
                                          color: Color.fromRGBO(87, 170, 58, 0.8431372549019608),
                                          child: Text(
                                            '게시',
                                            style: TextStyle(fontSize: 8, color: Colors.white),
                                          ))
                                    ],
                                  ),
                                  subtitle: Container(
                                    alignment: Alignment.topLeft,
                                    child: Column(
                                      children: [
                                        //Text(dataList2[index].noticeContents ?? '--', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10),),
                                        Text(
                                          dataList2[index].DISP_FR_DATE + ' ~ ' + dataList2[index].DISP_TO_DATE ?? '--',
                                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10),
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            );
                          })),
                ),
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 10),
                form,
                SizedBox(height: 10),
                Expanded(
                  child: dataList3 == null
                      ? Text('Data is Empty')
                      : ReorderableListView(
                      onReorder: _onMenuOptionReorder3,
                      scrollDirection: Axis.vertical,
                      padding: const EdgeInsets.only(bottom: 8.0),
                      children: List.generate(dataList3.length, (index) {
                        return GestureDetector(
                          // onTap: (){
                          //   Navigator.pushNamed(context, '/editor', arguments: UserController.to.userData[index]);
                          // },
                          key: Key('$index'),
                          child: Card(
                            color: Colors.white,
                            elevation: 2.0,
                            child: ListTile(
                              //leading: Text(dataList3[index].siguName),
                              title: Row(
                                children: [
                                  Text(
                                    '[' + dataList3[index].NOTICE_SEQ.toString() + '] ' + dataList3[index].NOTICE_TITLE ?? '--',
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                                  ),
                                  Container(
                                      margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                      width: 30,
                                      height: 16,
                                      alignment: Alignment.center,
                                      color: Color.fromRGBO(87, 170, 58, 0.8431372549019608),
                                      child: Text(
                                        '게시',
                                        style: TextStyle(fontSize: 8, color: Colors.white),
                                      ))
                                ],
                              ),
                              subtitle: Container(
                                alignment: Alignment.topLeft,
                                child: Column(
                                  children: [
                                    //Text(dataList3[index].noticeContents ?? '--', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10),),
                                    Text(
                                      dataList3[index].DISP_FR_DATE + ' ~ ' + dataList3[index].DISP_TO_DATE ?? '--',
                                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      })),
                ),
              ],
            )
          ],
        ),
      ),

      //bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 420,
      height: 580, //isDisplayDesktop(context) ? 580 : 1000,
      child: result,
    );
  }

  void _onMenuOptionReorder(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final noticeSortListModel item = dataList.removeAt(oldIndex);
      dataList.insert(newIndex, item);

      List<String> sortDataList = [];
      dataList.forEach((element) {
        sortDataList.add(element.NOTICE_SEQ.toString());
      });
      _editListSort(sortDataList);
    });
  }

  void _onMenuOptionReorder2(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final noticeSortListModel item = dataList2.removeAt(oldIndex);
      dataList2.insert(newIndex, item);

      List<String> sortDataList = [];
      dataList2.forEach((element) {
        sortDataList.add(element.NOTICE_SEQ.toString());
      });
      _editListSort(sortDataList);
    });
  }

  void _onMenuOptionReorder3(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final noticeSortListModel item = dataList3.removeAt(oldIndex);
      dataList3.insert(newIndex, item);

      List<String> sortDataList = [];
      dataList3.forEach((element) {
        sortDataList.add(element.NOTICE_SEQ.toString());
      });
      _editListSort(sortDataList);
    });
  }
}
