import 'package:daeguro_admin_app/View/LogManager/log_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:flutter/material.dart';

class PushMsgPopup extends StatefulWidget {
  final String title;
  final String msg;

  const PushMsgPopup({Key key, this.title, this.msg}) : super(key: key);

  @override
  PushMsgPopupState createState() => PushMsgPopupState();
}

class PushMsgPopupState extends State<PushMsgPopup> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var data = Container(
        alignment: Alignment.centerLeft,
        margin: const EdgeInsets.fromLTRB(20, 0, 20, 0),
        child: Column(
          children: [
            Align(child: Text('[발송내용]', style: TextStyle( fontSize: 14, fontWeight: FONT_BOLD)), alignment: Alignment.centerLeft,),
            SizedBox(height: 4),
            Align(child: SelectableText('${widget.msg}', style: TextStyle(fontSize: 13), showCursor: true,), alignment: Alignment.centerLeft,),
            SizedBox(height: 20),
          ],
        )
    );

    var result = Scaffold(
        appBar: AppBar(
          title: Text('${widget.title}'),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 20),
              data
            ],
          ),
        )
    );
    return SizedBox(
      width: 440,
      height: 500,
      child: result,
    );
  }
}
