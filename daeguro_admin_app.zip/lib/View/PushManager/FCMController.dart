import 'dart:convert';

import 'package:http/http.dart' as http;

// 추후 다이렉트 푸시발송 위한 FCMController 클래스구현
class FCMController {
  final String _serverKey = "AAAATTZqp1w:APA91bHMb6ewhwAa9yAKwgPOVBFEtmXmg7c1FdEPt7iHaqRCDRP1rYsX6XJE3ZXB2_LtoJdYrOG-9j-nGWbIi4RnRUDLcc14L5yYvSv0U-q0vi6KxY3zQRvBK2FqlGO_slCmSwQpkjMa";

  Future<void> sendMessage({String userToken, String title, String body,}) async {

    http.Response response;

    // NotificationSettings settings = await FirebaseMessaging.instance.requestPermission(
    //   alert: true,
    //   announcement: false,
    //   badge: true,
    //   carPlay: false,
    //   criticalAlert: false,
    //   provisional: false,
    //   sound: false,
    // );
    //
    // if (settings.authorizationStatus == AuthorizationStatus.authorized) {
    //   print('User granted permission');
    // } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
    //   print('User granted provisional permission');
    // } else {
    //   print('User declined or has not accepted permission');
    // }

    try {
      response = await http.post(Uri.parse('https://fcm.googleapis.com/fcm/send'),
          headers: <String, String>{
            'Content-Type': 'application/json',
            'Authorization': 'key=$_serverKey'
          },
          body: jsonEncode({
            //'ttl': '60s',
            "content_available": true,
            'data': {
              // 'click_action': 'FLUTTER_NOTIFICATION_CLICK',
              // 'id': '1',
              // 'status': 'done',
              // "action": '테스트',
              'default': {
                'pushTitle': title,
                'pushMsg': body,
                'pushGbn': '2'
              },
            },
            'notification': {
              'title': title,
              'body': body,
              'sound': 'false'
            },
            'direct_boot_ok' : true,
            'priority' : 'high',
            // 상대방 토큰 값, to -> 단일, registration_ids -> 여러명
            'to': userToken
            // 'registration_ids': tokenList
          }));
    } catch (e) {
      print('error $e');
    }
  }
}