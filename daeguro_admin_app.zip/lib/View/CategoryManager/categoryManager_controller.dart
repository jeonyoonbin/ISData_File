import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/Network/DioClient.dart';

import 'package:daeguro_admin_app/constants/serverInfo.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class CategoryController extends GetxController with SingleGetTickerProviderMixin {
  static CategoryController get to => Get.find();
  BuildContext context;

  int total_count = 0;
  int totalRowCnt = 0;

  @override
  void onInit() {
    super.onInit();
  }

  Future<dynamic> getCategoryList(String base_gbn) async {
    dynamic qData;

    final response = await DioClient().get(ServerInfo.REST_URL_CATEGORY_LIST + '?base_gbn=${base_gbn}'); //('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      qData = response.data['data'];
    else
      return null;

    return qData;
  }

  Future<dynamic> getSubCategoryList(String class_gbn) async {
    dynamic qData;

    final response = await DioClient().get(ServerInfo.REST_URL_PROD_CATEGORY_LIST + '?class_gbn=${class_gbn}');

    if (response.data['code'] == '00')
      qData = response.data['data'];
    else
      return null;


    return qData;
  }

  Future<dynamic> getSubCategoryDetail(String cat_code) async {
    dynamic qData;

    final response = await DioClient().get(ServerInfo.REST_URL_PROD_CATEGORY_DETAIL + '?cat_code=${cat_code}');

    if (response.data['code'] == '00')
      qData = response.data['data'];
    else
      return null;

    return qData;
  }


  postSubCategoryData(dynamic data, BuildContext context) async {
    var response = await DioClient().post(ServerInfo.REST_URL_PROD_SUB_CATEGORY, data: data);

    if (response.data['code'] != '00') {
      ISAlert(context, '카테고리 생성 실패하였습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  Future<dynamic> putProdCategory(dynamic bodyData, BuildContext context) async {
    try {
      final response = await DioClient().put(ServerInfo.REST_URL_PROD_SUB_CATEGORY, data: bodyData);

      if (response.data['code'].toString() != '00') {
        return response.data['msg'];
      } else
        return null;
    } catch (e) {
      print('putOrderSubTheme e:${e.toString()}');
    }
  }

  deleteCategorySubImage(String cat_code, String fileName, BuildContext context) async {
    String uCode = GetStorage().read('logininfo')['uCode'];

    final response = await DioClient().delete(ServerInfo.REST_URL_PROD_CATEGORY_DELETE + '?cat_code=${cat_code}&fileName=${fileName}&ucode=$uCode');

    if (response.data['code'] != '00') {
      ISAlert(context, '정상적으로 삭제 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  Future<List<dynamic>> getProdCategoryHistoryList(String cat_code) async {
    List<dynamic> itemsList = [];

    final response = await DioClient().get(ServerInfo.REST_URL_PROD_CATEGORY_HISTORY + '?cat_code=${cat_code}'); //('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      itemsList.assignAll(response.data['data']);
    else
      return null;

    return itemsList;
  }

  Future<dynamic> updateProdCategorySort(dynamic data) async {
    final response = await DioClient().put(ServerInfo.REST_URL_PROD_CATEGORY_UPDATE_SORT, data: data);

    if (response.data['code'] != '00') {
      return response.data['msg'];
    } else
      return null;
  }
}
