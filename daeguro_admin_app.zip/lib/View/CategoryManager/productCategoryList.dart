import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/is_tableInput.dart';
import 'package:daeguro_admin_app/Model/category/categoryListModel.dart';
import 'package:daeguro_admin_app/Model/category/prodCategoryBundleModel.dart';
import 'package:daeguro_admin_app/Model/category/prodCategoryBundleShopModel.dart';
import 'package:daeguro_admin_app/Model/category/subCategoryEditModel.dart';
import 'package:daeguro_admin_app/Network/FileUpLoader.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/CategoryManager/categoryManager_controller.dart';
import 'package:daeguro_admin_app/View/CategoryManager/categoryCreate.dart';
import 'package:daeguro_admin_app/View/CategoryManager/productCategoryHistory.dart';
import 'package:daeguro_admin_app/View/CategoryManager/productCategorySort.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderManager_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';

import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/constants/serverInfo.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import 'dart:async';

import 'package:image_picker_web/image_picker_web.dart';
import 'package:mime_type/mime_type.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:html' as html;
import 'package:path/path.dart' as Path;

class CategoryList extends StatefulWidget {
  const CategoryList({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CategoryListState();
  }
}

enum RadioUseGbn { gbn1, gbn2 }
enum RadioUseGbn2 { gbn1, gbn2 }
enum RadioTestGbn { gbn1, gbn2 }

class CategoryListState extends State<CategoryList> with SingleTickerProviderStateMixin {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<CategoryListModel> dataList = <CategoryListModel>[];
  final List<CategoryListModel> classList = <CategoryListModel>[];
  final List<CategoryListModel> bundleShopList = <CategoryListModel>[];

  ScrollController _scrollController;

  List items = List();

  String _shopJobGbn = '1';
  String _shopSearchKeyword = '';

  String _selectedComment = '';
  String _selectedCode = '';
  String _selectedSubCode = '';
  String _selBundleShopCode = '';

  RadioUseGbn _radioUseGbn;
  RadioTestGbn _radioTestGbn; // 테스트여부

  String _Name = '';
  String _Memo = '';
  String _themeTestYn = '';

  String _themeImageURL = '';
  String _themeImageRealURL = '';
  String _mCode = '2';

  html.File _cloudFile;
  var _fileBytes;
  String _fileName;
  Image _imageWidget;

  String _uploadGbn = '';

  var _file;
  var responseData;

  List<SelectOptionVO> selectBox_mCode = List();

  _reset() {
    dataList.clear();
    classList.clear();
    bundleShopList.clear();

    _selectedComment = '서브 카테고리를 선택해주세요.';

    //_themeImageURL = '저장된 파일이 없습니다.';
  }

  loadMCodeListData() async {
    selectBox_mCode.clear();

    //await AgentController.to.getDataMCodeItems();

    List MCodeListitems = Utils.getMCodeList();

    MCodeListitems.forEach((element) {
      selectBox_mCode.add(new SelectOptionVO(value: element['mCode'], label: element['mName']));
    });

    setState(() {});
  }

  loadBundleListData() async {
    dataList.clear();
    bundleShopList.clear();

    await CategoryController.to.getProdCategoryBundleShopList(_mCode).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((e) {
          CategoryListModel temp = CategoryListModel();

          if(e['code'] == _selectedCode) {
            temp.isOpened = true;
          }

          temp.class_gbn = e['m_shop_cd'];
          temp.name = e['shop_name'];
          temp.cat_code = '';

          dataList.add(temp);
          bundleShopList.add(temp);
        });
      }
    });

    setState(() {});
  }

  addSubBundleData(String m_shop_cd) async {
    List<CategoryListModel> tempMainBundleShopList = <CategoryListModel>[];

    await CategoryController.to.getProdCategoryBundleList(m_shop_cd).then((value) {
      value.forEach((element) {
        ProdCategoryBundleModel subThemeItem = ProdCategoryBundleModel();

        subThemeItem.m_shop_cd = element['m_shop_cd'];
        subThemeItem.class_gbn = element['class_gbn'];
        subThemeItem.cat_code = element['cat_code'];
        subThemeItem.name = element['name'];
        subThemeItem.use_gbn = element['use_gbn'];
        subThemeItem.sort_seq = element['sort_seq'];

        int compareIndex = dataList.indexWhere((item) => item.class_gbn == subThemeItem.m_shop_cd);

        if (compareIndex != -1) {
          CategoryListModel listItem = CategoryListModel();

          if(_selectedSubCode == element['cat_code'])
            listItem.selected = true;

          listItem.isChild = true;
          listItem.class_gbn = subThemeItem.m_shop_cd;
          listItem.name = subThemeItem.name;
          listItem.cat_code = subThemeItem.cat_code;
          listItem.use_gbn = subThemeItem.use_gbn;

          tempMainBundleShopList.add(listItem);
        }
      });

      tempMainBundleShopList = List.from(tempMainBundleShopList.reversed);

      int selectindex = dataList.indexWhere((item) => item.class_gbn.toString() == m_shop_cd);
      tempMainBundleShopList.forEach((element) {
        if (element.class_gbn != null) dataList.insert(selectindex + 1, element);
      });
    });

    setState(() {});
  }

  removeSubBundleData(String code) {
    setState(() {
      dataList.removeWhere((item) => (item.class_gbn == code && item.isChild == true));
    });
  }

  loadMainCategoryListData() async {
    dataList.clear();
    classList.clear();

    await CategoryController.to.getCategoryList('PROD').then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((e) {
          CategoryListModel temp = CategoryListModel();

          if (e['class_gbn'] == _selectedCode.toString()) {
            temp.isOpened = true;
          }

          temp.isChild = false;
          temp.class_gbn = e['class_gbn'];
          temp.name = e['name'];
          temp.base_gbn = e['base_gbn'];
          temp.sort_seq = e['sort_seq'];

          //dataList.add(temp);
          classList.add(temp);

          if (_selectedCode == '') _selectedCode = temp.class_gbn;
        });

        if(_selectedCode == 'BUNDLE') {
          loadBundleListData();
        } else {
          addSubCategoryData();
        }
      }
    });

    setState(() {});
  }

  addSubCategoryData() async {
    dataList.clear();

    await CategoryController.to.getSubCategoryList(_selectedCode).then((value) {
      value.forEach((element) {
        CategoryListModel subCategoryItem = CategoryListModel();

        if(_selectedSubCode == element['cat_code'])
          subCategoryItem.selected = true;

        subCategoryItem.class_gbn = element['class_gbn'];
        subCategoryItem.cat_code = element['cat_code'];
        subCategoryItem.name = element['name'];
        subCategoryItem.use_gbn = element['use_gbn'];
        subCategoryItem.sort_seq = element['sort_seq'];

        dataList.add(subCategoryItem);
      });
    });
    setState(() {});
  }

  loadSubCategoryDetail(String cat_code) async {
    _themeImageURL = '';
    _themeImageRealURL = '';

    await CategoryController.to.getSubCategoryDetail(cat_code).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        _Name = value['name'];
        _Memo = value['memo'];

        (value['img'] == null || value['img'] == '')
            ? _themeImageRealURL = ''
            : ServerInfo.jobMode == 'dev'
                ? _themeImageRealURL = 'https://dgpub.282.co.kr:8500/testimage/' + value['img'].toString()
                : _themeImageRealURL = 'https://image.daeguro.co.kr:40443/etc-images/icon/prodCat/' + value['img'].toString() + '?tm=${Utils.getTimeStamp()}';

        // if (_themeImageRealURL != '') {
        //   List<String> sTemp = _themeImageRealURL.split('/');
        //   _themeImageURL = sTemp[sTemp.length - 1];
        // }

        _themeImageURL = value['img'].toString();

        value['use_gbn'] == 'Y' ? _radioUseGbn = RadioUseGbn.gbn1 : _radioUseGbn = RadioUseGbn.gbn2;
        value['test_yn'] == 'Y' ? _radioTestGbn = RadioTestGbn.gbn1 : _radioTestGbn = RadioTestGbn.gbn2;
      }
    });

    setState(() {});
  }

  _regist() async {
    List<SelectOptionVO> tempMainThemeList = List();

    dataList.forEach((element) {
      if (element.isChild == false) tempMainThemeList.add(new SelectOptionVO(value: element.class_gbn, label: '[${element.class_gbn}] ${element.name}'));
    });

    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: CategoryCreate(class_gbn: _selectedCode, listModel: classList, bundleShopList : bundleShopList),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 500), () {
          _selectedComment = '서브 카테고리를 선택해주세요.';

          if(_selectedCode == 'BUNDLE') {
            loadBundleListData();
          } else {
            addSubCategoryData();
          }
        });
      }
    });
  }

  _sort() {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: ProductCategorySort(class_gbn: _selectedCode, listModel: classList),
      ),
    ).then((v) async {
      if(_selectedCode == 'BUNDLE') {
        loadBundleListData();
      } else {
        addSubCategoryData();
      }

      await Future.delayed(Duration(milliseconds: 300), () {
        dataList.forEach((element) {
          if (_selectedSubCode != element.cat_code) {
            element.selected = false;
          } else {
            element.selected = true;
          }
        });

        setState(() {});
      });
    });
  }

  @override
  void initState() {
    super.initState();

    Get.put(OrderController());
    Get.put(CategoryController());

    _selectedComment = '서브 카테고리를 선택해주세요.';
    _selectedCode = '';

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      loadMCodeListData();
      loadMainCategoryListData();
      //_query();
    });
  }

  @override
  void dispose() {
    dataList.clear();
    bundleShopList.clear();

    super.dispose();
  }

  Widget getClassTabView() {
    return ListView.builder(
      controller: _scrollController,
      //padding: const EdgeInsets.symmetric(horizontal: 4.0, vertical: 8.0),
      itemCount: classList.length,
      scrollDirection: Axis.horizontal,
      itemBuilder: (BuildContext context, int index) {
        return classList != null
            ? GestureDetector(
                child: Container(
                  //padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  margin: EdgeInsets.only(right: 5),
                  child: InkWell(
                    child: Chip(
                      padding: const EdgeInsets.all(5),
                      backgroundColor: _selectedCode == classList[index].class_gbn ? Colors.teal : Colors.grey,
                      //color.withOpacity(0.3),
                      label: Text(classList[index].name, style: TextStyle(fontSize: 11, color: Colors.white)),
                    ),
                    onTap: () {
                      _selectedCode = classList[index].class_gbn;

                      _Name = '';
                      _Memo = '';
                      _radioUseGbn = null;
                      _radioTestGbn = null;

                      if(_selectedCode == 'BUNDLE') {
                        loadBundleListData();
                      } else {
                        addSubCategoryData();
                      }
                    },
                  ),
                ),
              )
            : SizedBox.shrink();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Container(height: 35, child: getClassTabView()),
        ],
      ),
    );

    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          form,
          Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 450,
                //getListMainPanelWidth(),
                height: (MediaQuery.of(context).size.height - 135),
                padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                  color: Colors.white,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                            padding: EdgeInsets.only(left: 10),
                            child: Text(
                              '카테고리 목록',
                              style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD),
                            )),
                        Container(
                          alignment: Alignment.centerRight,
                          padding: EdgeInsets.symmetric(vertical: 2),
                          child: Row(
                            children: [
                              if (ServerInfo.jobMode == 'dev' ? AuthUtil.isAuthEditEnabled('276') : AuthUtil.isAuthEditEnabled('278') == true)
                                ISButton(
                                    label: '순서 변경',
                                    iconColor: Colors.white,
                                    textStyle: TextStyle(color: Colors.white),
                                    iconData: Icons.autorenew,
                                    onPressed: () async {
                                      _sort();
                                    }),
                              SizedBox(width: 8),
                              if (ServerInfo.jobMode == 'dev' ? AuthUtil.isAuthCreateEnabled('276') : AuthUtil.isAuthCreateEnabled('278') == true)
                                ISButton(
                                    label: '카테고리 추가',
                                    iconColor: Colors.white,
                                    textStyle: TextStyle(color: Colors.white),
                                    iconData: Icons.save,
                                    onPressed: () async {
                                      _regist();
                                    }),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Divider(),
                    Visibility(
                      visible: _selectedCode == 'BUNDLE' ? true : false,
                      child: Container(
                        alignment: Alignment.centerRight,
                        padding: EdgeInsets.symmetric(vertical: 2),
                        child:  ISSelect(
                            label: '*회원사명',
                            value: _mCode,
                            dataList: selectBox_mCode,
                            onChange: (v) {
                              setState(() {
                                _mCode = v;
                                loadBundleListData();
                                formKey.currentState.save();
                              });
                            }),
                      ),
                    ),
                    ISDatatable(
                      controller: ScrollController(),
                      headingRowHeight: 0.01,
                      dividerThickness: 0.01,
                      viewScrollAxis: Axis.vertical,
                      panelHeight: _selectedCode == 'BUNDLE' ? (MediaQuery.of(context).size.height - 261) : (MediaQuery.of(context).size.height - 245),
                      listWidth: 400,
                      dataRowHeight: 30,
                      rows: getDataRow(),
                      columns: getDataColumn(),
                    )
                  ],
                ),
              ),
              //Divider(height: 1000,),
              getDetailData(),
            ],
          ),
        ],
      ),
    );
  }

  List<DataRow> getDataRow() {
    List<DataRow> tempData = [];

    dataList.forEach((element) {
      double fontSize = 14.0;

      if (element.isChild == true) fontSize = 12.0;

      tempData.add(DataRow(
          selected: element.selected ?? false,
          color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
            if (element.selected == true) {
              return Colors.grey.shade200;
              //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
            }

            return Theme.of(context).colorScheme.primary.withOpacity(0.00);
          }),
          onSelectChanged: (bool value) {
            dataList.forEach((element) {
              element.selected = false;
            });

            element.selected = true;

            // BUNDLE = 장보기
            if(_selectedCode == 'BUNDLE') {
              if(element.isChild == true) {
                element.selected = true;
                _selBundleShopCode = element.class_gbn;
                _selectedSubCode = element.cat_code;
                element.use_gbn == 'Y' ? _radioUseGbn = RadioUseGbn.gbn1 : _radioUseGbn = RadioUseGbn.gbn2;
                _Name = element.name;

                setState(() {});
                return;
              }

              if (element.isOpened == true) {
                element.isOpened = false;
                removeSubBundleData(element.class_gbn);
              } else {
                element.isOpened = true;
                addSubBundleData(element.class_gbn);
              }

              return;
            } else {
              loadSubCategoryDetail(element.cat_code);
            }

            _selectedCode = element.class_gbn;
            _selectedSubCode = element.cat_code;

            setState(() {});
          },
          cells: [
            DataCell(Align(
              alignment: Alignment.centerLeft,
              child: _selectedCode == 'BUNDLE' ? Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  (element.isChild == true)
                      ? Container(
                    width: 30,
                  )
                      : InkWell(
                    child: Icon(element.isOpened == true ? Icons.remove_circle : Icons.add_circle, color: Colors.blue, size: 20),
                    onTap: () {
                      if(element.isChild == true) {
                        element.selected = true;
                        _selectedSubCode = element.cat_code;
                        setState(() {});
                        return;
                      }

                      if (element.isOpened == true) {
                        element.isOpened = false;
                        removeSubBundleData(element.class_gbn);
                      } else {
                        element.isOpened = true;
                        addSubBundleData(element.class_gbn);
                      }
                      return;
                    },
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Align(
                      child: Container(
                          padding: EdgeInsets.only(bottom: 2),
                          child: Text(
                            element.name.toString(),
                            style: TextStyle(color: element.use_gbn == 'Y' ? Colors.black : Colors.red, fontSize: fontSize),
                          )),
                      alignment: element.isChild == true ? Alignment.centerLeft : Alignment.center)
                ],
              ) : Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Align(
                      child: Container(
                          padding: EdgeInsets.only(bottom: 2),
                          child: Text(
                            element.name.toString(),
                            style: TextStyle(color: element.use_gbn == 'Y' ? Colors.black : Colors.red, fontSize: fontSize),
                          )),
                      alignment: element.isChild == true ? Alignment.centerLeft : Alignment.center)
                ],
              ),
            )),
          ]));
    });

    return tempData;
  }

  List<DataColumn> getDataColumn() {
    List<DataColumn> tempData = [];

    tempData.add(DataColumn(
      label: Expanded(child: Text('', textAlign: TextAlign.center)),
    ));

    return tempData;
  }

  Widget getDetailData() {
    return Container(
      width: getListMainPanelWidth(),
      height: (MediaQuery.of(context).size.height - 135),
      padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
        ],
      ),
      child: Column(
        //mainAxisAlignment: MainAxisAlignment.spaceBetween,

        children: [
          Container(
              height: MediaQuery.of(context).size.height - 161,
              alignment: Alignment.center,
              child: _selectedCode == ''
                  ? Text(
                      _selectedComment,
                      style: TextStyle(color: Colors.black45),
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 25), // .all(25),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Text('카테고리 정보', style: TextStyle(fontSize: 20)),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      if (ServerInfo.jobMode == 'dev' ? AuthUtil.isAuthEditEnabled('276') : AuthUtil.isAuthEditEnabled('278') == true)
                                        ISButton(
                                          label: '수정',
                                          iconColor: Colors.white,
                                          textStyle: TextStyle(color: Colors.white),
                                          onPressed: () {
                                            ISConfirm(context, '카테고리 정보 수정', '카테고리를 수정 하시겠습니까?', (context) async {
                                              String tempUseGbn = _radioUseGbn == RadioUseGbn.gbn1 ? 'Y' : 'N';
                                              String tempTestGbn = _radioTestGbn == RadioTestGbn.gbn1 ? 'Y' : 'N';

                                              SubCategoryEditModel formData = SubCategoryEditModel();
                                              formData.cat_code = _selectedSubCode;
                                              formData.name = _Name;
                                              formData.memo = _Memo;
                                              formData.use_gbn = tempUseGbn;
                                              formData.test_yn = tempTestGbn;
                                              formData.ucode = GetStorage().read('logininfo')['uCode'];

                                              if( _selectedCode == 'BUNDLE') {
                                                var _sendData = {
                                                  '"m_shop_cd"': '"${_selBundleShopCode}"',
                                                  '"cat_code"': '"${_selectedSubCode}"',
                                                  '"name"': '"${_Name}"',
                                                  '"use_gbn"': '"${tempUseGbn}"',
                                                  '"ucode"': '"${GetStorage().read('logininfo')['uCode']}"',
                                                };

                                                await CategoryController.to.putBundleCatData(_sendData.toString(), context).then((value) {
                                                  if (value.toString() != 'null') {
                                                    Navigator.pop(context);
                                                    ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                                  } else {
                                                    loadBundleListData();

                                                    Navigator.pop(context);
                                                  }
                                                });
                                              } else {
                                                await CategoryController.to.putProdCategory(formData.toJson(), context).then((value) {
                                                  if (value.toString() != 'null') {
                                                    Navigator.pop(context);
                                                    ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                                  } else {
                                                    addSubCategoryData();

                                                    Navigator.pop(context);
                                                  }
                                                });
                                              }
                                            });
                                          },
                                        ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      ISButton(
                                        label: '변경이력',
                                        iconColor: Colors.white,
                                        textStyle: TextStyle(color: Colors.white),
                                        onPressed: () {
                                          showDialog(
                                            context: context,
                                            builder: (BuildContext context) => Dialog(
                                              child: ProductCategoryHistory(cat_code: _selectedSubCode),
                                            ),
                                          ).then((v) async {});
                                        },
                                      )
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Table(
                                columnWidths: const {
                                  0: FixedColumnWidth(120),
                                  1: FlexColumnWidth(),
                                },
                                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                                //border: TableBorder.all(width: 0.8, color: Colors.black),
                                border: TableBorder.symmetric(inside: BorderSide(width: 0.1, color: Colors.black), outside: BorderSide(width: 1.2, color: Colors.black12)),
                                // border: TableBorder(
                                //     horizontalInside: BorderSide(color: Colors.black, width: 0.2),
                                //     verticalInside: BorderSide(color: Colors.black),
                                //     top: BorderSide(color: Colors.black),
                                //     bottom: BorderSide(color: Colors.black),
                                //     left: BorderSide(color: Colors.black),
                                //     right: BorderSide(color: Colors.black),
                                //
                                // ),
                                children: [
                                  TableRow(children: [
                                    Container(
                                        color: Colors.blue[50],
                                        height: 74,
                                        alignment: Alignment.center,
                                        child: Text('카테고리명', style: TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54, fontSize: 12))),
                                    Container(
                                      color: Colors.white,
                                      child: ISTableInput(
                                        height: 60,
                                        maxLength: _selectedCode == 'ELECTRIC' ? 10 : 6,
                                        value: _Name, //formData.bussCon ?? '',
                                        //label: '업태',
                                        textStyle: TextStyle(fontSize: 12),
                                        onChange: (v) {
                                          _Name = v;
                                        },
                                      ),
                                    ),
                                  ]),
                                  TableRow(children: [
                                    Container(
                                        color: Colors.blue[50],
                                        height: 38,
                                        alignment: Alignment.center,
                                        child: Text('사용여부', style: TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54, fontSize: 12))),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          color: Colors.white,
                                          height: 30,
                                          padding: EdgeInsets.symmetric(horizontal: 8),
                                          child: Row(
                                            children: [
                                              Radio(
                                                  value: RadioUseGbn.gbn1,
                                                  groupValue: _radioUseGbn,
                                                  onChanged: (v) async {
                                                    _radioUseGbn = v;

                                                    setState(() {});
                                                  }),
                                              Text('사용', style: TextStyle(fontSize: 10)),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                                child: Radio(
                                                    value: RadioUseGbn.gbn2,
                                                    groupValue: _radioUseGbn,
                                                    onChanged: (v) async {
                                                      _radioUseGbn = v;

                                                      setState(() {});
                                                    }),
                                              ),
                                              Text('미사용', style: TextStyle(fontSize: 10)),
                                            ],
                                          ),
                                        ),
                                        Visibility(
                                          visible: _selectedCode == 'BUNDLE' ? false : true,
                                          child: Row(
                                            children: [
                                              Container(
                                                  color: Colors.blue[50],
                                                  width: 90,
                                                  height: 38,
                                                  alignment: Alignment.center,
                                                  child: Text('테스트 여부', style: TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54, fontSize: 12))),
                                              Container(
                                                color: Colors.white,
                                                height: 30,
                                                padding: EdgeInsets.symmetric(horizontal: 8),
                                                child: Row(
                                                  children: [
                                                    Radio(
                                                        value: RadioTestGbn.gbn1,
                                                        groupValue: _radioTestGbn,
                                                        onChanged: (v) async {
                                                          _radioTestGbn = v;

                                                          setState(() {});
                                                        }),
                                                    Text('예', style: TextStyle(fontSize: 10)),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                                      child: Radio(
                                                          value: RadioTestGbn.gbn2,
                                                          groupValue: _radioTestGbn,
                                                          onChanged: (v) async {
                                                            _radioTestGbn = v;

                                                            setState(() {});
                                                          }),
                                                    ),
                                                    Text('아니오', style: TextStyle(fontSize: 10)),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ]),
                                  TableRow(children: [
                                    Visibility(
                                      visible: _selectedCode == 'BUNDLE' ? false : true,
                                      child: Container(
                                          color: Colors.blue[50],
                                          height: 38,
                                          alignment: Alignment.center,
                                          child: Text('카테고리 이미지', style: TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54, fontSize: 12))),
                                    ),
                                    Visibility(
                                      visible: _selectedCode == 'BUNDLE' ? false : true,
                                      child: Container(
                                        color: Colors.white,
                                        height: 30,
                                        padding: EdgeInsets.symmetric(horizontal: 16),
                                        child: Row(
                                          children: [
                                            if (ServerInfo.jobMode == 'dev' ? AuthUtil.isAuthEditEnabled('276') : AuthUtil.isAuthEditEnabled('278') == true)
                                              MaterialButton(
                                                color: Colors.blue,
                                                minWidth: 40,
                                                height: 30,
                                                child: Text(
                                                  '업로드',
                                                  style: TextStyle(color: Colors.white, fontSize: 12),
                                                ),
                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                                                onPressed: () async {
                                                  await ISProgressDialog(context).show(status: '이미지 업로드중...');

                                                  var mediaData = await ImagePickerWeb.getImageInfo;

                                                  String mimeType = mime(Path.basename(mediaData.fileName));
                                                  html.File mediaFile = new html.File(mediaData.data, mediaData.fileName, {'type': mimeType});

                                                  if (mediaFile != null) {
                                                    setState(() {
                                                      _cloudFile = mediaFile;
                                                      _fileBytes = mediaData.data;
                                                      _fileName = mediaData.fileName;
                                                      _imageWidget = Image.memory(mediaData.data);
                                                    });
                                                  }

                                                  if(mediaFile.type.toString() == 'image/gif') {
                                                    _uploadGbn = 'file';
                                                  } else {
                                                    _uploadGbn = 'image';
                                                  }

                                                  _file = _fileBytes;

                                                  FileUpLoadProvider provider = FileUpLoadProvider();
                                                  provider.setResource(_uploadGbn, _file);

                                                  provider.prodCategoryImageResourceRequest(_selectedSubCode, _fileName).then((value) async {
                                                    loadSubCategoryDetail(_selectedSubCode);

                                                    // loadData();
                                                    setState(() {
                                                      //Url_1 = file.path;
                                                    });

                                                    await Future.delayed(Duration(milliseconds: 500), () {
                                                      setState(() {
                                                        _deleteImageFromCache();
                                                      });
                                                    });
                                                  });

                                                  await ISProgressDialog(context).dismiss();
                                                },
                                              ),
                                            if (_themeImageURL != '' && ServerInfo.jobMode == 'dev' ? AuthUtil.isAuthEditEnabled('276') : AuthUtil.isAuthEditEnabled('278') == true)
                                              Row(
                                                children: [
                                                  SizedBox(
                                                    width: 8,
                                                  ),
                                                  MaterialButton(
                                                    color: Colors.blue,
                                                    minWidth: 40,
                                                    height: 30,
                                                    child: Text(
                                                      '삭제',
                                                      style: TextStyle(color: Colors.white, fontSize: 12),
                                                    ),
                                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                                                    onPressed: () {
                                                      if (_themeImageURL == '' || _themeImageURL == null || _themeImageURL == 'null') return;

                                                      ISConfirm(context, '카테고리 이미지 삭제', '해당 이미지를 삭제하시겠습니까?', (context) async {
                                                        CategoryController.to.deleteCategorySubImage(_selectedSubCode, _themeImageURL, context).then((value) {
                                                          if (value != null) {
                                                            ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                                          } else {
                                                            loadSubCategoryDetail(_selectedSubCode);

                                                            Navigator.pop(context);

                                                            setState(() {});
                                                          }
                                                        });
                                                      });
                                                    },
                                                  ),
                                                  SizedBox(
                                                    width: 8,
                                                  ),
                                                ],
                                              ),
                                            //Text(_themeImageURL == '' ? '저장된 파일이 없습니다.' : _themeImageURL, style: TextStyle(fontSize: 12))
                                            _themeImageURL == '' || _themeImageURL == null || _themeImageURL == 'null'
                                                ? Text('저장된 파일이 없습니다.', style: TextStyle(fontSize: 12))
                                                : MaterialButton(
                                                    height: 30.0,
                                                    child: Text(_themeImageURL, style: TextStyle(color: Colors.black, fontSize: 13)),
                                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                                                    onPressed: () {
                                                      _launchInBrowser(_themeImageRealURL + '?tm=${Utils.getTimeStamp()}');
                                                    },
                                                  )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ]),
                                  TableRow(children: [
                                    Visibility(
                                      visible: _selectedCode == 'BUNDLE' ? false : true,
                                      child: Container(
                                          color: Colors.blue[50],
                                          height: 110,
                                          alignment: Alignment.center,
                                          child: Text('메모', style: TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54, fontSize: 12))),
                                    ),
                                    Visibility(
                                      visible: _selectedCode == 'BUNDLE' ? false : true,
                                      child: Container(
                                        color: Colors.white,
                                        child: ISTableInput(
                                          value: _Memo,
                                          // formData.menuGroupMemo ?? '',
                                          //context: context,
                                          height: 95,
                                          maxLength: 50,
                                          keyboardType: TextInputType.multiline,
                                          maxLines: 8,
                                          onChange: (v) {
                                            _Memo = v;
                                          },
                                        ),
                                      ),
                                    ),
                                  ]),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ))
        ],
      ),
    );
  }

  double getListMainPanelWidth() {
    double nWidth = MediaQuery.of(context).size.width - 750;

    if (Responsive.isTablet(context) == true)
      nWidth = nWidth + sidebarWidth;
    else if (Responsive.isMobile(context) == true) nWidth = MediaQuery.of(context).size.width;

    return nWidth;
  }

  Future<void> _launchInBrowser(String url) async {
    if (await canLaunch(url)) {
      await launch(
        url,
        forceSafariVC: false, //true로 설정시, iOS 인앱 브라우저를 통해픈
        forceWebView: false, //true로 설정시, Android 인앱 브라우저를 통해 오픈
        headers: <String, String>{'my_header_key': 'my_header_value'},
      );
    } else {
      throw 'Web Request Fail $url';
    }
  }

  Future _deleteImageFromCache() async {
    //await CachedNetworkImage.evictFromCache(url);

    PaintingBinding.instance.imageCache.clearLiveImages();
    PaintingBinding.instance.imageCache.clear();

    //await DefaultCacheManager().removeFile(key);
    //await DefaultCacheManager().emptyCache();
    setState(() {});
  }
}
