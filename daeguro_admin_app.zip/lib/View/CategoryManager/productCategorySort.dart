import 'dart:convert';

import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/Model/category/categoryListModel.dart';
import 'package:daeguro_admin_app/Model/menu.dart';
import 'package:daeguro_admin_app/Model/order/orderThemeMainListModel.dart';
import 'package:daeguro_admin_app/Model/order/orderThemeSubModel.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveThemeListModel.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveThemeShopListModel.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveThemeSubModel.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/AuthManager/AuthMenuEdit.dart';
import 'package:daeguro_admin_app/View/AuthManager/auth_controller.dart';
import 'package:daeguro_admin_app/View/CategoryManager/categoryManager_controller.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderManager_controller.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reservationmanager_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ProductCategorySort extends StatefulWidget {
  final String class_gbn;
  final List<CategoryListModel> listModel;

  const ProductCategorySort({Key key, this.class_gbn, this.listModel}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ProductCategorySortState();
  }
}

class ProductCategorySortState extends State<ProductCategorySort> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  //final ScrollController _scrollController = ScrollController();
  final List<CategoryListModel> dataList = <CategoryListModel>[];
  List<DropdownMenuItem<String>> selectBox_CategoryList = [];
  List<DropdownMenuItem<String>> selectBox_BundleShopList = [];

  String _selClass;
  String selectTemaCode = '';
  String selectChildComment = '';
  String setBundleShop = '';

  //bool isSaveEnabled = false;

  _query() {
    //print('call _query() menuCode->'+widget.menuCode);
    //formKey.currentState.save();

    selectChildComment = '상위 카테고리를 선택해주세요.';

    loadData();
  }

  loadData() async {
    dataList.clear();

    if(_selClass == 'BUNDLE') {
      await CategoryController.to.getProdCategoryBundleList(setBundleShop).then((value) {
        value.forEach((e) {
          CategoryListModel temp = CategoryListModel();

          temp.isChild = false;
          temp.class_gbn = e['class_gbn'];
          temp.name = e['name'];
          temp.sort_seq = e['sort_seq'];
          temp.cat_code = e['cat_code'];
          temp.use_gbn = e['use_gbn'];

          dataList.add(temp);
        });
      });
    } else {
      await CategoryController.to.getSubCategoryList(_selClass).then((value) {
        if (value == null) {
          ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
        } else {
          value.forEach((e) {
            CategoryListModel temp = CategoryListModel();

            temp.isChild = false;
            temp.class_gbn = e['class_gbn'];
            temp.name = e['name'];
            temp.base_gbn = e['base_gbn'];
            temp.sort_seq = e['sort_seq'];
            temp.cat_code = e['cat_code'];
            temp.use_gbn = e['use_gbn'];

            dataList.add(temp);
          });
        }
      });
    }

    if (this.mounted) {
      setState(() {});
    }
  }

  _editListSortMain(List<String> sortDataList) async {
    String jsonData = jsonEncode(sortDataList);

    //print('data set->'+jsonData);
    await CategoryController.to.updateProdCategorySort(jsonData).then((value) async {
      if (value != null) {
        ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
      } else {
        await Future.delayed(Duration(milliseconds: 500), () {
          loadData();
        });
      }
    });
  }

  loadBundleListData() async {
    dataList.clear();
    selectBox_BundleShopList.clear();

    await CategoryController.to.getProdCategoryBundleShopList('').then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((e) {
          if(setBundleShop == '') {
            setBundleShop = e['m_shop_cd'].toString();
          }

          selectBox_BundleShopList.add(new DropdownMenuItem(value: e['m_shop_cd'].toString(), child: Text(e['shop_name'].toString())));
        });
      }
    });

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(CategoryController());

    //formKey.currentState.reset();

    widget.listModel.forEach((element) {
      // 서브 카테고리 제외
      if (element.isChild == true) return;

      _selClass = widget.class_gbn;

      selectBox_CategoryList.add(new DropdownMenuItem(value: element.class_gbn, child: Text(element.name)));
    });

    WidgetsBinding.instance.addPostFrameCallback((c) async {
      //loadSidoData();
      loadBundleListData();

      await Future.delayed(Duration(milliseconds: 500), () {
        setState(() {
          _query();
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: 10, right: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Flexible(
                  flex: 1,
                  child: ISSearchDropdown(
                    label: '상위 카테고리',
                    value: _selClass,
                    onChange: (value) {
                      _selClass = value;

                      _query();
                    },
                    item: selectBox_CategoryList,
                  ),
                ),
                _selClass == 'BUNDLE' ? Flexible(
                  flex: 2,
                  child: ISSearchDropdown(
                    label: '시장',
                    value: setBundleShop,
                    onChange: (value) {
                      setBundleShop = value;

                      loadData();
                    },
                    item: selectBox_BundleShopList,
                  ),
                ) : Flexible(flex: 2, child: SizedBox.shrink())
              ],
            ),
          ),
        ],
      ),
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('카테고리 순서'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          //buttonBar,
          form,
          //SizedBox(height: 10),
          Container(
            padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center ,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                        width: 365,
                        height: 430,
                        decoration: BoxDecoration(color: Colors.grey.withOpacity(.1), borderRadius: BorderRadius.circular(5), border: Border.all(width: 1, color: Colors.grey.withOpacity(.3))),
                        child: ReorderableListView(
                            scrollController: ScrollController(),
                            onReorder: _onParentMenuReorder,
                            scrollDirection: Axis.vertical,
                            padding: const EdgeInsets.only(bottom: 8.0),
                            children: List.generate(dataList.length, (index) {
                              return Card(
                                  key: Key('$index'),
                                  margin: EdgeInsets.all(4),
                                  color: Colors.white,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      Flexible(
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: <Widget>[
                                            Container(
                                              padding: const EdgeInsets.all(8),
                                              alignment: Alignment.topLeft,
                                              child: Column(
                                                children: <Widget>[
                                                  Container(
                                                    alignment: Alignment.topLeft,
                                                    child: Text(
                                                      dataList[index].name ?? '--',
                                                      style: TextStyle(color: dataList[index].use_gbn == 'Y' ? Colors.black : Colors.redAccent, fontWeight: FONT_BOLD, fontSize: 12),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  )
                                  // child: ListTile(
                                  //   minLeadingWidth: 20,
                                  //   leading: Icon(Utils.toIconData(dataChildList[index].icon), size: 21, color: Colors.black54),
                                  //   title: Text(dataChildList[index].name ?? '--', style: TextStyle(fontWeight: FONT_BOLD, fontSize: 12),),
                                  //   subtitle: Text(dataChildList[index].url ?? '--', style: TextStyle(fontWeight: FONT_BOLD, fontSize: 10),),
                                  // ),
                                  );
                            }))),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
      //bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 400,
      height: 580, //isDisplayDesktop(context) ? 580 : 1000,
      child: result,
    );
  }

  void _onParentMenuReorder(int oldIndex, int newIndex) {
    if (this.mounted) {
      setState(() {
        if (newIndex > oldIndex) {
          newIndex -= 1;
        }
        final CategoryListModel item = dataList.removeAt(oldIndex);
        dataList.insert(newIndex, item);

        List<String> sortDataList = [];

        dataList.forEach((element) {
          sortDataList.add(element.cat_code);
        });

        _editListSortMain(sortDataList);
      });
    }
  }
}
