import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/Model/category/categoryListModel.dart';
import 'package:daeguro_admin_app/Model/category/subCategoryCreateModel.dart';
import 'package:daeguro_admin_app/Model/coupon/couponRegistModel.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/View/CategoryManager/categoryManager_controller.dart';
import 'package:daeguro_admin_app/View/CouponManager/coupon_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class CategoryCreate extends StatefulWidget {
  final String class_gbn;
  final List<CategoryListModel> listModel;

  const CategoryCreate({Key key, this.class_gbn, this.listModel}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CategoryCreateState();
  }
}

class CategoryCreateState extends State<CategoryCreate> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  SubCategoryCreateModel formData;

  List<DropdownMenuItem<String>> selectBox_CategoryList = [];

  @override
  void initState() {
    super.initState();

    Get.put(CategoryController());

    formData = SubCategoryCreateModel();

    formData.class_gbn = '';
    formData.ucode = GetStorage().read('logininfo')['uCode'];

    widget.listModel.forEach((element) {
      // 서브 카테고리 제외
      if (element.isChild == true) return;

      formData.class_gbn = widget.class_gbn;

      selectBox_CategoryList.add(new DropdownMenuItem(value: element.class_gbn, child: Text(element.name)));
    });
  }

  @override
  void dispose() {
    selectBox_CategoryList.clear();

    selectBox_CategoryList = null;
    formData = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: ISSearchDropdown(
                  width: 232,
                  label: '상위 카테고리',
                  value: formData.class_gbn,
                  onChange: (value) {
                    setState(() {
                      formData.class_gbn = value;
                    });
                  },
                  item: selectBox_CategoryList,
                ),
              ),
            ],
          ),
          ISInput(
            autofocus: true,
            value: formData.name,
            label: '카테고리명',
            onSaved: (v) {
              formData.name = v;
            },
          )
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            form.save();

            CategoryController.to.postSubCategoryData(formData.toJson(), context);

            Navigator.pop(context, true);
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('카테고리 생성'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10),
            Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );

    return SizedBox(
      width: 400,
      height: 220,
      child: result,
    );
  }
}
