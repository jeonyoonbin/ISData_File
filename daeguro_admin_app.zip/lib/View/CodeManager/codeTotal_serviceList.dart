import 'dart:convert';

import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_tableInput.dart';
import 'package:daeguro_admin_app/Model/code/CodeTotalServiceTypeModel.dart';
import 'package:daeguro_admin_app/Model/code/codeTotal_serviceCategoryModel.dart';
import 'package:daeguro_admin_app/Model/order/orderCongratsBookmarkModel.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/View/CodeManager/codeTotal_serviceCategoryRegist.dart';
import 'package:daeguro_admin_app/View/CodeManager/codeTotal_serviceTypeEdit.dart';
import 'package:daeguro_admin_app/View/CodeManager/codeTotal_serviceTypeRegist.dart';
import 'package:daeguro_admin_app/View/CodeManager/code_controller.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/OrderManager/congratsSetCategory.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderManager_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';

import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

import 'dart:async';

class CodeTotalServiceList extends StatefulWidget {
  const CodeTotalServiceList({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CodeTotalServiceListState();
  }
}

enum RadioUseGbn { gbn1, gbn2 }

class CodeTotalServiceListState extends State<CodeTotalServiceList> with SingleTickerProviderStateMixin {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<CodeTotalServiceCategoryModel> categoryList = <CodeTotalServiceCategoryModel>[];
  final List<CodeTotalServiceTypeModel> typeList = <CodeTotalServiceTypeModel>[];

  bool isSaveEnabled = false;

  String _checkSelCategoryCode = '';
  String _checkSelCategoryName = '자주쓰는 경조사어';

  RadioUseGbn _radioUseGbn;

  _reset() {
    categoryList.clear();
    typeList.clear();
  }

  loadCategoryListData() async {
    categoryList.clear();

    await CodeController.to.getCodeTotalServiceCategory().then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((e) {
          CodeTotalServiceCategoryModel temp = CodeTotalServiceCategoryModel();

          if (e['gbn_code'] == _checkSelCategoryCode) temp.selected = true;

          temp.gbn_code = e['gbn_code'];
          temp.gbn_name = e['gbn_name'];
          temp.use_gbn = e['use_gbn'];
          temp.ins_date = e['ins_date'];
          temp.ins_ucode = e['ins_ucode'];
          temp.ins_name = e['ins_name'];
          temp.mod_date = e['mod_date'];
          temp.mod_ucode = e['mod_ucode'];
          temp.mod_name = e['mod_name'];

          categoryList.add(temp);
        });
      }
    });

    setState(() {});
  }

  loadListData() async {
    typeList.clear();

    await CodeController.to.getCodeTotalServiceType(_checkSelCategoryCode).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((e) {
          CodeTotalServiceTypeModel temp = CodeTotalServiceTypeModel();

          temp.gbn_code = e['gbn_code'];
          temp.gbn_name = e['gbn_name'];
          temp.type_code = e['type_code'];
          temp.type_name = e['type_name'];
          temp.use_gbn = e['use_gbn'];
          temp.ins_date = e['ins_date'];
          temp.ins_ucode = e['ins_ucode'];
          temp.ins_name = e['ins_name'];
          temp.mod_date = e['mod_date'];
          temp.mod_ucode = e['mod_ucode'];
          temp.mod_name = e['mod_name'];

          typeList.add(temp);
        });
      }
    });

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(CodeController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      loadCategoryListData();
    });
  }

  @override
  void dispose() {
    categoryList.clear();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[SizedBox(height: 10)],
      ),
    );

    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          form,
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 410,
                //getListMainPanelWidth(),
                height: (MediaQuery.of(context).size.height - 140),
                padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                  color: Colors.white,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                            padding: EdgeInsets.only(left: 5),
                            child: Text(
                              '요청구분',
                              style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD),
                            )),
                        Container(
                          alignment: Alignment.centerRight,
                          padding: EdgeInsets.symmetric(vertical: 2),
                          child: Row(
                            children: [
                              if (AuthUtil.isAuthCreateEnabled('268') == true)
                                ISButton(
                                    label: '추가',
                                    iconColor: Colors.white,
                                    textStyle: TextStyle(color: Colors.white),
                                    iconData: Icons.add,
                                    onPressed: () async {
                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) => Dialog(
                                          child: CodeTotalServiceCategoryRegist(),
                                        ),
                                      ).then((v) async {
                                        if (v != null) {
                                          await Future.delayed(Duration(milliseconds: 500), () {
                                            loadCategoryListData();
                                          });
                                        }
                                      });
                                    }),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Divider(),
                    ISDatatable(
                      controller: ScrollController(),
                      headingRowHeight: 0.01,
                      dividerThickness: 0.01,
                      viewScrollAxis: Axis.vertical,
                      panelHeight: (MediaQuery.of(context).size.height - 210),
                      listWidth: 450,
                      dataRowHeight: 30,
                      rows: getDataRow(),
                      columns: getDataColumn(),
                    )
                  ],
                ),
              ),
              //Divider(height: 1000,),
              SizedBox(width: 10),
              Container(
                width: 550,
                //getListMainPanelWidth(),
                height: (MediaQuery.of(context).size.height - 140),
                padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                  color: Colors.white,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                            padding: EdgeInsets.only(left: 5),
                            child: Text(
                              '요청구분 관리',
                              style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD),
                            )),
                        Container(
                          alignment: Alignment.centerRight,
                          padding: EdgeInsets.symmetric(vertical: 2),
                          child: Row(
                            children: [
                              if (AuthUtil.isAuthEditEnabled('268') == true)
                                Row(
                                  children: [
                                    AnimatedOpacity(
                                      opacity: isSaveEnabled ? 1.0 : 0.0,
                                      duration: Duration(seconds: 1),
                                      child: Row(
                                        children: [
                                          Icon(
                                            Icons.info_outline,
                                            color: Colors.red,
                                            size: 18,
                                          ),
                                          Text(
                                            '수정 완료',
                                            style: TextStyle(color: Colors.red, fontWeight: FONT_BOLD),
                                          ),
                                        ],
                                      ),
                                      onEnd: () {
                                        setState(() {
                                          isSaveEnabled = false;
                                        });
                                      },
                                    ),
                                    SizedBox(width: 8),
                                    ISButton(
                                        label: '수정',
                                        iconColor: Colors.white,
                                        textStyle: TextStyle(color: Colors.white),
                                        iconData: Icons.edit,
                                        onPressed: () async {
                                          await ISProgressDialog(context).show(status: '저장 중입니다.');

                                          String _useGbn = _radioUseGbn == RadioUseGbn.gbn1 ? 'Y' : 'N';

                                          await CodeController.to.updateCodeTotalServiceCategory(_checkSelCategoryCode, _checkSelCategoryName, _useGbn, context);

                                          loadCategoryListData();

                                          await ISProgressDialog(context).dismiss();

                                          setState(() {
                                            isSaveEnabled = true;
                                          });
                                        }),
                                  ],
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 5),
                    Table(
                      columnWidths: const {
                        0: FixedColumnWidth(120),
                        1: FlexColumnWidth(),
                      },
                      defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                      //border: TableBorder.all(width: 0.8, color: Colors.black),
                      border: TableBorder.symmetric(inside: BorderSide(width: 0.1, color: Colors.black), outside: BorderSide(width: 1.2, color: Colors.black12)),
                      children: [
                        TableRow(children: [
                          Container(color: Colors.blue[50], height: 44, alignment: Alignment.center, child: Text('요청구분', style: TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54, fontSize: 12))),
                          Container(
                            color: Colors.white,
                            child: ISTableInput(
                              height: 30,
                              value: _checkSelCategoryName, //formData.bussCon ?? '',
                              //label: '업태',
                              textStyle: TextStyle(fontSize: 12),
                              onChange: (v) {
                                _checkSelCategoryName = v;
                              },
                            ),
                          ),
                        ]),
                        TableRow(children: [
                          Container(color: Colors.blue[50], height: 44, alignment: Alignment.center, child: Text('사용유무', style: TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54, fontSize: 12))),
                          Container(
                            color: Colors.white,
                            height: 30,
                            padding: EdgeInsets.symmetric(horizontal: 8),
                            child: Row(
                              children: [
                                Radio(
                                    value: RadioUseGbn.gbn1,
                                    groupValue: _radioUseGbn,
                                    onChanged: (v) async {
                                      _radioUseGbn = v;

                                      setState(() {});
                                    }),
                                Text('사용', style: TextStyle(fontSize: 10)),
                                Container(
                                  margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                  child: Radio(
                                      value: RadioUseGbn.gbn2,
                                      groupValue: _radioUseGbn,
                                      onChanged: (v) async {
                                        _radioUseGbn = v;

                                        setState(() {});
                                      }),
                                ),
                                Text('미사용', style: TextStyle(fontSize: 10)),
                              ],
                            ),
                          ),
                        ]),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                            padding: EdgeInsets.only(left: 5),
                            child: Text(
                              '작업내용',
                              style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD),
                            )),
                        Container(
                          alignment: Alignment.centerRight,
                          padding: EdgeInsets.symmetric(vertical: 2),
                          child: Row(
                            children: [
                              if (AuthUtil.isAuthCreateEnabled('268') == true)
                                ISButton(
                                    label: '추가',
                                    iconColor: Colors.white,
                                    textStyle: TextStyle(color: Colors.white),
                                    iconData: Icons.add,
                                    onPressed: () async {
                                      if (_checkSelCategoryCode == '') return;

                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) => Dialog(
                                          child: CodeTotalServiceTypeRegist(gbn_code: _checkSelCategoryCode),
                                        ),
                                      ).then((v) async {
                                        if (v != null) {
                                          await Future.delayed(Duration(milliseconds: 500), () {
                                            loadListData();
                                          });
                                        }
                                      });
                                    }),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Divider(),
                    ISDatatable(
                      controller: ScrollController(),
                      headingRowHeight: 0.01,
                      dividerThickness: 0.01,
                      viewScrollAxis: Axis.vertical,
                      panelHeight: (MediaQuery.of(context).size.height - 350),
                      listWidth: 450,
                      dataRowHeight: 35,
                      rows: getTypeDataRow(),
                      columns: getTypeDataColumn(),
                    )
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  List<DataRow> getDataRow() {
    List<DataRow> tempData = [];

    categoryList.forEach((element) {
      double fontSize = 14.0;

      tempData.add(DataRow(
          selected: element.selected ?? false,
          color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
            if (element.selected == true) {
              return Colors.grey.shade200;
              //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
            }

            return Theme.of(context).colorScheme.primary.withOpacity(0.00);
          }),
          onSelectChanged: (bool value) {
            categoryList.forEach((element) {
              element.selected = false;
            });

            element.selected = true;

            _checkSelCategoryCode = element.gbn_code;
            _checkSelCategoryName = element.gbn_name;

            element.use_gbn == 'Y' ? _radioUseGbn = RadioUseGbn.gbn1 : _radioUseGbn = RadioUseGbn.gbn2;

            loadListData();
            setState(() {});
          },
          cells: [
            DataCell(Align(
                child: Container(
                    padding: EdgeInsets.only(bottom: 2),
                    child: Text(
                      '[' + element.gbn_code + '] ' + element.gbn_name,
                      style: TextStyle(color: element.use_gbn == 'Y' ? Colors.black : Colors.black45, fontSize: fontSize, decoration: element.use_gbn == 'Y' ? null : TextDecoration.lineThrough),
                    )),
                alignment: Alignment.centerLeft)),
          ]));
    });

    return tempData;
  }

  List<DataColumn> getDataColumn() {
    List<DataColumn> tempData = [];

    tempData.add(DataColumn(
      label: Expanded(child: Text('', textAlign: TextAlign.center)),
    ));

    return tempData;
  }

  List<DataRow> getTypeDataRow() {
    List<DataRow> tempData = [];

    typeList.forEach((element) {
      tempData.add(DataRow(
          selected: element.selected ?? false,
          color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
            if (element.selected == true) {
              return Colors.grey.shade200;
              //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
            }

            return Theme.of(context).colorScheme.primary.withOpacity(0.00);
          }),
          cells: [
            DataCell(Align(child: Container(padding: EdgeInsets.only(bottom: 2), child: Text('[' + element.type_code + '] ' + element.type_name, style: TextStyle(color: element.use_gbn == 'Y' ? Colors.black : Colors.black45, decoration: element.use_gbn == 'Y' ? null : TextDecoration.lineThrough))), alignment: Alignment.centerLeft)),
            DataCell(
              Align(
                  child: InkWell(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) => Dialog(
                            child: CodeTotalServiceTypeEdit(typeData: element),
                          ),
                        ).then((v) async {
                          if (v != null) {
                            await Future.delayed(Duration(milliseconds: 500), () {
                              loadListData();
                            });
                          }
                        });
                      },
                      child: Icon(Icons.edit)),
                  alignment: Alignment.centerRight),
            ),
          ]));
    });

    return tempData;
  }

  List<DataColumn> getTypeDataColumn() {
    List<DataColumn> tempData = [];

    tempData.add(DataColumn(
      label: Expanded(child: Text('', textAlign: TextAlign.center)),
    ));

    tempData.add(DataColumn(
      label: Expanded(child: Text('', textAlign: TextAlign.center)),
    ));

    return tempData;
  }
}
