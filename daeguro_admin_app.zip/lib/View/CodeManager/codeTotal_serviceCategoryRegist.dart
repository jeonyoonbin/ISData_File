import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/Model/menu.dart';
import 'package:daeguro_admin_app/View/AuthManager/auth_controller.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/View/CodeManager/code_controller.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderManager_controller.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reservationmanager_controller.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

class CodeTotalServiceCategoryRegist extends StatefulWidget {
  final List<SelectOptionVO> selectBox_mainTheme;

  const CodeTotalServiceCategoryRegist({Key key, this.selectBox_mainTheme}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CodeTotalServiceCategoryRegistState();
  }
}

class CodeTotalServiceCategoryRegistState extends State<CodeTotalServiceCategoryRegist> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  List<SelectOptionVO> selectBox_themeType = List();

  String gbn_name;
  String use_gbn = 'Y';
  String ucode;

  @override
  void initState() {
    super.initState();

    Get.put(AuthController());

    selectBox_themeType.clear();

    selectBox_themeType.add(new SelectOptionVO(value: '0', label: '메인테마'));
    selectBox_themeType.add(new SelectOptionVO(value: '1', label: '서브테마'));

    WidgetsBinding.instance.addPostFrameCallback((c) {});
  }

  @override
  void dispose() {
    selectBox_themeType.clear();
    selectBox_themeType = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Container(
            margin: EdgeInsets.all(8.0),
            decoration: new BoxDecoration(
                color: use_gbn == 'Y' ? Colors.blue[200] : Colors.red[200],
                borderRadius: new BorderRadius.circular(6)),
            child: SwitchListTile(
              dense: true,
              value: use_gbn == 'Y' ? true : false,
              title: Text('사용 유무', style: TextStyle(fontSize: 10, color: Colors.white),),
              onChanged: (v) {
                setState(() {
                  use_gbn = v ? 'Y' : 'N';
                  formKey.currentState.save();
                });
              },
            ),
          ),
          ISInput(
            value: gbn_name,
            autofocus: true,
            context: context,
            label: '카테고리명',
            onChange: (v) {
              gbn_name = v;
            },
          ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () async {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            await CodeController.to.setCodeTotalServiceCategory(gbn_name, use_gbn, context);

            Navigator.pop(context, true);
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('요청구분 등록'),
      ),
      body: Column(
        children: [
          SizedBox(height: 10),
          Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
        ],
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 400,
      height: 250,
      child: result,
    );
  }
}
