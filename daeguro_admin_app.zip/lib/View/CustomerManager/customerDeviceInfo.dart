import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/View/CustomerManager/customer_controller.dart';
import 'package:daeguro_admin_app/View/LogManager/log_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CustomerDeviceInfo extends StatefulWidget {
  final int cust_code ;
  // final logDetailModel sData;
  const CustomerDeviceInfo({Key key, this.cust_code }) : super(key: key);

  @override
  CustomerDeviceInfoState createState() => CustomerDeviceInfoState();
}

class CustomerDeviceInfoState extends State<CustomerDeviceInfo> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();

    Get.put(CustomerController());

    WidgetsBinding.instance.addPostFrameCallback((c) {

    });
  }

  @override
  Widget build(BuildContext context) {
    var data = Container(
        alignment: Alignment.centerLeft,
        margin: const EdgeInsets.fromLTRB(20, 0, 20, 0),
        child: Table(
            columnWidths: const {0: FixedColumnWidth(100), 1: FlexColumnWidth(),},
            defaultVerticalAlignment: TableCellVerticalAlignment.middle,
            //border: TableBorder.all(width: 0.8, color: Colors.black),
            border: TableBorder.symmetric(inside: BorderSide(width: 0.1, color: Colors.black), outside: BorderSide(width: 1.2, color: Colors.black12)),
            // border: TableBorder(
            //     horizontalInside: BorderSide(color: Colors.black, width: 0.2),
            //     verticalInside: BorderSide(color: Colors.black),
            //     top: BorderSide(color: Colors.black),
            //     bottom: BorderSide(color: Colors.black),
            //     left: BorderSide(color: Colors.black),
            //     right: BorderSide(color: Colors.black),
            //
            // ),
            children: [
              TableRow(children: [
                Container(
                    color: Colors.blue[50],
                    height: 36,
                    alignment: Alignment.center,
                    child: Text('회원번호', style: TextStyle(fontSize: 12))
                ),
                Container(
                  child: SelectableText('  ' + CustomerController.to.qDataDeviceInfo['CUST_CODE'].toString(), style: TextStyle(fontSize: 12), showCursor: true,),
                ),
              ]),
              TableRow(children: [
                Container(
                    color: Colors.blue[50],
                    height: 36,
                    alignment: Alignment.center,
                    child: Text('장치구분', style: TextStyle(fontSize: 12))
                ),
                Container(
                  child: SelectableText('  ' + getDeviceName(CustomerController.to.qDataDeviceInfo['DEVICE_GBN']), style: TextStyle(fontSize: 12), showCursor: true,),
                ),
              ]),
              TableRow(children: [
                Container(
                    color: Colors.blue[50],
                    height: 36,
                    alignment: Alignment.center,
                    child: Text('모델명', style: TextStyle(fontSize: 12))
                ),
                Container(
                  child: SelectableText('  ' + CustomerController.to.qDataDeviceInfo['DEVICE_MODEL'].toString(), style: TextStyle(fontSize: 12), showCursor: true,),
                ),
              ]),
              TableRow(children: [
                Container(
                    color: Colors.blue[50],
                    height: 36,
                    alignment: Alignment.center,
                    child: Text('OS 버전', style: TextStyle(fontSize: 12))
                ),
                Container(
                  child: SelectableText('  ' + CustomerController.to.qDataDeviceInfo['OS_VERSION'].toString(), style: TextStyle(fontSize: 12), showCursor: true,),
                ),
              ]),
              TableRow(children: [
                Container(
                    color: Colors.blue[50],
                    height: 36,
                    alignment: Alignment.center,
                    child: Text('앱 버전', style: TextStyle(fontSize: 12))
                ),
                Container(
                  child: SelectableText('  ' + CustomerController.to.qDataDeviceInfo['APP_VERSION'].toString(), style: TextStyle(fontSize: 12), showCursor: true,),
                ),
              ]),
              TableRow(children: [
                Container(
                    color: Colors.blue[50],
                    height: 36,
                    alignment: Alignment.center,
                    child: Text('최근 접속일', style: TextStyle(fontSize: 12))
                ),
                Container(
                  child: SelectableText('  ' + CustomerController.to.qDataDeviceInfo['LOGIN_DATE'].replaceAll('T', ' '), style: TextStyle(fontSize: 12), showCursor: true,),
                ),
              ]),
            ]
        )
        // child: Column(
        //   children: [
        //     Row(
        //       children: [
        //         Align(child: Text('[회원번호]', style: TextStyle( fontSize: 14, fontWeight: FontWeight.bold)), alignment: Alignment.centerLeft,),
        //         Align(child: SelectableText('  ' + CustomerController.to.qDataDeviceInfo['CUST_CODE'].toString(), style: TextStyle(fontSize: 13), showCursor: true,), alignment: Alignment.centerLeft,),
        //       ],
        //     ),
        //     SizedBox(height: 10),
        //     Row(
        //       children: [
        //         Align(child: Text('[장치구분]', style: TextStyle( fontSize: 14, fontWeight: FontWeight.bold)), alignment: Alignment.centerLeft,),
        //         Align(child: SelectableText('  ' + getDeviceName(CustomerController.to.qDataDeviceInfo['DEVICE_GBN']), style: TextStyle(fontSize: 13), showCursor: true,), alignment: Alignment.centerLeft,),
        //       ],
        //     ),
        //     SizedBox(height: 10),
        //     Row(
        //       children: [
        //         Align(child: Text('[모델명]', style: TextStyle( fontSize: 14, fontWeight: FontWeight.bold)), alignment: Alignment.centerLeft,),
        //         Align(child: SelectableText('  ' + CustomerController.to.qDataDeviceInfo['DEVICE_MODEL'], style: TextStyle(fontSize: 13), showCursor: true,), alignment: Alignment.centerLeft,),
        //       ],
        //     ),
        //     SizedBox(height: 10),
        //     Row(
        //       children: [
        //         Align(child: Text('[OS 버전]', style: TextStyle( fontSize: 14, fontWeight: FontWeight.bold)), alignment: Alignment.centerLeft,),
        //         Align(child: SelectableText('  ' + CustomerController.to.qDataDeviceInfo['OS_VERSION'], style: TextStyle(fontSize: 13), showCursor: true,), alignment: Alignment.centerLeft,),
        //       ],
        //     ),
        //     SizedBox(height: 10),
        //     Row(
        //       children: [
        //         Align(child: Text('[앱 버전]', style: TextStyle( fontSize: 14, fontWeight: FontWeight.bold)), alignment: Alignment.centerLeft,),
        //         Align(child: SelectableText('  ' + CustomerController.to.qDataDeviceInfo['APP_VERSION'], style: TextStyle(fontSize: 13), showCursor: true,), alignment: Alignment.centerLeft,),
        //       ],
        //     ),
        //     SizedBox(height: 10),
        //     Row(
        //       children: [
        //         Align(child: Text('[최근 접속일]', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)), alignment: Alignment.centerLeft,),
        //         Align(child: Text('  ' + CustomerController.to.qDataDeviceInfo['LOGIN_DATE'].replaceAll('T', ' '), style: TextStyle(fontSize: 13)), alignment: Alignment.centerLeft,),
        //       ],
        //     ),
        //     SizedBox(height: 10),
        //   ],
        // )
    );

    var result = Scaffold(
        appBar: AppBar(
          title: Text('회원 단말 정보'),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 20),
              data
            ],
          ),
        )
    );
    return SizedBox(
      width: 300,
      height: 320,
      child: result,
    );
  }

  String getDeviceName(String gbn){
    String retName;

    if (gbn == 'A')        retName = 'Android';
    else if (gbn == 'I')   retName = 'IOS';
    else
      retName = '알수없음';

    return retName;
  }
}
