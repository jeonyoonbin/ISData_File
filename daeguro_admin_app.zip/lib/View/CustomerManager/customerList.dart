import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_input.dart';
import 'package:daeguro_admin_app/Model/customer/customerListModel.dart';
import 'package:daeguro_admin_app/Model/search_items.dart';
import 'package:daeguro_admin_app/View/CustomerManager/customerCoupon.dart';
import 'package:daeguro_admin_app/View/CustomerManager/customerDeviceInfo.dart';
import 'package:daeguro_admin_app/View/CustomerManager/customerInfo.dart';
import 'package:daeguro_admin_app/View/CustomerManager/customerInvite.dart';
import 'package:daeguro_admin_app/View/CustomerManager/customerMileage.dart';
import 'package:daeguro_admin_app/View/CustomerManager/customerReserveList.dart';
import 'package:daeguro_admin_app/View/CustomerManager/customer_controller.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderList.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/ShopManager/Reservation/shopReservationList.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:date_format/date_format.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

class CustomerList extends StatefulWidget {
  final String custCode;
  final double popWidth;
  final double popHeight;

  const CustomerList({Key key, this.custCode, this.popWidth, this.popHeight}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CustomerListState();
  }
}

class CustomerListState extends State<CustomerList> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  SearchItems _searchItems = new SearchItems();

  List<CustomerListModel> dataList = <CustomerListModel>[];
  String _divKey = '0';
  String _div = '1';

  //int rowsPerPage = 10;

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    CustomerController.to.name.value = '';
    CustomerController.to.divKey.value = '';
    CustomerController.to.div.value = '';

    _searchItems = null;
    _searchItems = new SearchItems();

    if (isMainShowEnabled() == true) {
      _searchItems.name = '';
    }
    else {
      _div = '2';
      _searchItems.name = widget.custCode;

      //_searchItems.name = widget.custCode;
      // if (widget.custTelno != null) {
      //   _searchItems.name = widget.custTelno;
      // }
    }

    _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
    _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    //loadData();
  }

  _info(String custCode) async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: CustomerInfo(custCode: custCode),
      ),
    ).then((v) async {
      if (v != null){
        loadData();
      }
    });
  }

  _order(String custCode, String custName) async {
    double poupWidth = 1200;
    double poupHeight = 600;

    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: SizedBox(
          width: poupWidth,
          height: poupHeight,
          child: Scaffold(
            appBar: AppBar(
              title: Text('회원 주문 내역   [회원명: ${custName}]'),
            ),
            body: OrderList(custCode: custCode, custName: custName, gbn: 'N', popWidth: poupWidth, popHeight: poupHeight,),
          ),
        ),
      ),
    ).then((v) async {
    });
  }

  _reserve(String telNo, String custName) async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: SizedBox(
          width: 1400,
          height: 600,
          child: Scaffold(
            appBar: AppBar(
              title: Text('회원 예약 내역   [회원명: ${custName}]'),
            ),
            body: CustomerReserveList(
              jobGbn: '5',
              searchInfo: telNo,
            ),
          ),
        ),
      ),
    ).then((v) async {});
  }

  _mileage(String custCode, String custName) async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: CustomerMileage(custCode: custCode, custName: custName,),
      ),
    ).then((v) async {
    });
  }

  _coupon(String custCode, String custName) async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: CustomerCoupon(custCode: custCode, custName: custName,),
      ),
    ).then((v) async {
    });
  }

  _query() {
    CustomerController.to.divKey.value = _divKey;
    CustomerController.to.div.value = _div;
    CustomerController.to.name.value = _searchItems.name;
    CustomerController.to.page.value = _currentPage;
    CustomerController.to.raw.value = _selectedpagerows;
    loadData();
  }

  loadData() async {
    await ISProgressDialog(context).show(status: 'Loading...');

    dataList.clear();

    await CustomerController.to.getData().then((value) {
      if (this.mounted) {
        if (value == null) {
          ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
        }
        else{
          setState(() {
            dataList.clear();
            value.forEach((element) {
              CustomerListModel tempData = CustomerListModel();//.fromJson(e);

              tempData.CUST_CODE = element['CUST_CODE'] as int;
              tempData.CUST_NAME = element['CUST_NAME'].toString();
              tempData.TELNO = element['TELNO'].toString();
              tempData.CUST_ID = element['CUST_ID'].toString();
              tempData.CUST_PASSWORD = element['CUST_PASSWORD'].toString();
              tempData.INSERT_DATE = element['INSERT_DATE'].toString();
              tempData.DEL_DATE = element['DEL_DATE'].toString();
              tempData.ORDER_COUNT = element['ORDER_COUNT'] as int;
              tempData.RESER_COUNT = element['RESER_COUNT'] as int;
              tempData.ORDER_AMT = element['ORDER_AMT'] as int;
              tempData.MILEAGE_AMT = element['MILEAGE_AMT'] as int;
              tempData.CUST_ID_GBN = element['CUST_ID_GBN'].toString();
              tempData.MEMO = element['MEMO'].toString();

              if (tempData.INSERT_DATE != null)
                tempData.INSERT_DATE = tempData.INSERT_DATE.replaceAll('T', '  ');

              if (tempData.DEL_DATE != null)
                tempData.DEL_DATE = tempData.DEL_DATE.replaceAll('T', '  ');

              if(tempData.ORDER_COUNT == null)
                tempData.ORDER_COUNT = 0;

              if(tempData.RESER_COUNT == null)
                tempData.RESER_COUNT = 0;

              if(tempData.ORDER_AMT == null)
                tempData.ORDER_AMT = 0;

              if(tempData.MILEAGE_AMT == null)
                tempData.MILEAGE_AMT = 0;

              tempData.TELNO_ORIGINAL = tempData.TELNO.toString();

              tempData.CUST_NAME = Utils.getNameFormat(tempData.CUST_NAME.toString(), true);
              tempData.TELNO = Utils.getPhoneNumFormat(tempData.TELNO.toString(), true);

              dataList.add(tempData);
            });

            _totalRowCnt = CustomerController.to.totalRowCnt;
            _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
          });
        }
      }
    });

    await ISProgressDialog(context).dismiss();
  }

  @override
  void initState() {
    super.initState();

    Get.put(CustomerController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      //print('---- init run');
      _reset();
      _query();
    });

    setState(() {
      _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
      _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    });
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //testSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Container(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            // Row(
            //   children: <Widget>[
            //     Text('총회원수: ${Utils.getCashComma(CustomerController.to.Maincustomer)}', style: TextStyle(color: Colors.black),),
            //     SizedBox(width: 16),
            //     Text('마일리지총액: ${Utils.getCashComma(CustomerController.to.Mainmileage)}', style: TextStyle(color: Colors.black),),
            //     SizedBox(width: 16),
            //     Text('쿠폰발행총액: ${Utils.getCashComma(CustomerController.to.Maincoupon)}', style: TextStyle(color: Colors.black),),
            //   ],
            // ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                ISSearchDropdown(
                  label: '상태',
                  width: 100,
                  value: _divKey,
                  onChange: (value) {
                    setState(() {
                      _divKey = value;
                      // _currentPage = 1;
                      //
                      // _query();
                    });
                  },
                  item: [
                    DropdownMenuItem(value: '0', child: Text('전체'),),
                    DropdownMenuItem(value: '1', child: Text('사용중'),),
                    DropdownMenuItem(value: '2', child: Text('탈퇴'),),
                  ].cast<DropdownMenuItem<String>>(),
                ),
                ISSearchDropdown(
                  label: '검색조건',
                  width: 100,
                  value: _div,
                  onChange: (value) {
                    setState(() {
                      _div = value;
                      // _currentPage = 1;
                      //
                      // _query();
                    });
                  },
                  item: [
                    DropdownMenuItem(value: '1', child: Text('회원명'),),
                    DropdownMenuItem(value: '2', child: Text('회원번호'),),
                    DropdownMenuItem(value: '3', child: Text('전화번호'),),
                    DropdownMenuItem(value: '4', child: Text('메모'),),
                  ].cast<DropdownMenuItem<String>>(),
                ),
                ISSearchInput(
                  label: getKeyName(),//'키워드',
                  width: 180,
                  value: _searchItems.name,
                  onChange: (v) {
                    _searchItems.name = v;
                  },
                  onFieldSubmitted: (value) {
                    _currentPage = 1;
                    _query();
                  },
                ),
                SizedBox(height: 8,),
                ISSearchButton(
                    label: '조회',
                    iconData: Icons.search,
                    onPressed: () => {_currentPage = 1, _query()}),
              ],
            ),
          ],
        ),
      ),
    );

    var bar2 = Expanded(
        flex: 0,
        child: Container(
          // padding: EdgeInsets.only(bottom: 5),
          child: Row(
            mainAxisAlignment: (isMainShowEnabled() == true) ? MainAxisAlignment.spaceBetween : MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text('회원 총계 ', style: TextStyle(color: Colors.lightBlue, fontWeight: FONT_BOLD)),
                  SizedBox(width: 10),
                  Text('총회원수 ', style: TextStyle(color: Colors.black, fontWeight: FONT_BOLD)),
                  Text(Utils.getCashComma('${CustomerController.to.Maincustomer}'), style: TextStyle(color: Colors.black)),
                  SizedBox(width: 10),
                  Text('마일리지총액 ', style: TextStyle(color: Colors.black, fontWeight: FONT_BOLD)),
                  Text(Utils.getCashComma('${CustomerController.to.Mainmileage}'), style: TextStyle(color: Colors.black)),
                  SizedBox(width: 10),
                  Text('쿠폰발행총액 ', style: TextStyle(color: Colors.black, fontWeight: FONT_BOLD)),
                  Text(Utils.getCashComma('${CustomerController.to.Maincoupon}'), style: TextStyle(color: Colors.black)),
                ],
              ),
            ],
          ),
        )
    );

    var bar3 = Expanded(
        flex: 0,
        child: Container(
          padding: EdgeInsets.only(left: 4, right: 4, bottom: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Text('회원 가입일 : ${dataList.length == 0 ? '--' : dataList[0].INSERT_DATE.toString() == 'null' ? '--' : dataList[0].INSERT_DATE.toString()}', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 12)),
              if (dataList.length != 0 && dataList[0].DEL_DATE.toString() != 'null')
              Text('회원 탈퇴일 : ${dataList.length == 0 ? '--' : dataList[0].DEL_DATE.toString() == 'null' ? '--' : dataList[0].DEL_DATE.toString()}', style: TextStyle(color: Colors.black, fontWeight: FONT_NORMAL, fontSize: 12)),
            ],
          ),
        )
    );

    return Container(
      padding: (isMainShowEnabled() == true) ? null : EdgeInsets.only(left: 10, right: 10, bottom: 0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          form,
          (isMainShowEnabled() == true) ? buttonBar : SizedBox.shrink(),
          (isMainShowEnabled() == true) ? Divider(): SizedBox.shrink(),
          (isMainShowEnabled() == true) ? bar2 : bar3,//SizedBox.shrink(),
          (isMainShowEnabled() == true) ? Divider(): SizedBox.shrink(),
          ISDatatable(
            panelHeight: (isMainShowEnabled() == true) ? (MediaQuery.of(context).size.height-defaultContentsHeight)-54 : widget.popHeight-126,
            listWidth: (isMainShowEnabled() == true) ? Responsive.getResponsiveWidth(context, 720) : widget.popWidth-20,
            rows: dataList.map((item) {
              return DataRow(cells: [
                DataCell(Center(child: SelectableText(item.CUST_CODE.toString() ?? '--', style: TextStyle(color: Colors.black), showCursor: true,))),
                //DataCell(Center(child: SelectableText(item.CUST_NAME.toString() ?? '--', style: TextStyle(color: Colors.black),showCursor: true,))),
                DataCell(Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        InkWell(
                          child: (item.CUST_ID_GBN == 'Z' || item.CUST_ID_GBN == null || item.CUST_ID_GBN == 'null' || item.CUST_ID_GBN == '')
                              ? Icon(Icons.perm_device_info, color: Colors.blue, size: 21,)
                              : Image.asset(getIconURL(item.CUST_ID_GBN), width: 21, height: 21,),
                          onTap: () async {
                            await CustomerController.to.getDeviceInfoData(item.CUST_CODE.toString());

                            showDialog(
                                context: context,
                                builder: (BuildContext context) => Dialog(
                                  child: CustomerDeviceInfo(),
                                )
                            );
                          },
                        ),
                        SizedBox(width: 8),
                        MaterialButton(
                          minWidth: 60,
                          height: 30.0,//Responsive.isDesktop(context) == true ? 40.0 : 30.0,
                          child: Text(item.CUST_NAME.toString() ?? '--', style: TextStyle(color: Colors.black)),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                          onPressed: ()  {
                            _info(item.CUST_CODE.toString());
                          },
                        ),
                        SizedBox(width: 4),
                        SelectableText(item.TELNO.toString() ?? '--', style: TextStyle(color: Colors.black),showCursor: true,)
                      ],
                    )
                )
                ),
                //DataCell(Center(child: SelectableText(item.TELNO.toString() ?? '--', style: TextStyle(color: Colors.black),showCursor: true,))),
                // DataCell(Center(child: (isMainShowEnabled() == true)
                //     ? MaterialButton(
                //   height: 30.0,
                //   color: (item.ORDER_COUNT.toString() == '0' &&  item.ORDER_AMT.toString() == '0') ?  Colors.grey.shade300 : Colors.blue,
                //   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                //   child: Text('${Utils.getCashComma(item.ORDER_COUNT.toString())}건 / ${Utils.getCashComma(item.ORDER_AMT.toString())}원',
                //       style: TextStyle(fontSize: 13, color: Colors.white,)),
                //   onPressed: () => _order(item.CUST_CODE.toString(), item.CUST_NAME),
                // ) : SelectableText('${Utils.getCashComma(item.ORDER_COUNT.toString())}건 / ${Utils.getCashComma(item.ORDER_AMT.toString())}원',
                //     style: TextStyle(fontSize: 13, color: Colors.black,), showCursor: true)),
                // ),
                DataCell(Center(
                    child: MaterialButton(
                        height: 30.0,
                        color: (item.ORDER_COUNT.toString() == '0' &&  item.ORDER_AMT.toString() == '0') ?  Colors.grey.shade300 : Colors.blue,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                        child: Text('${Utils.getCashComma(item.ORDER_COUNT.toString())}건 / ${Utils.getCashComma(item.ORDER_AMT.toString())}원',
                        style: TextStyle(fontSize: 13, color: Colors.white,)),
                        onPressed: () => _order(item.CUST_CODE.toString(), item.CUST_NAME),
                    )
                  ),
                ),
                DataCell(Center(child: MaterialButton(
                  height: 30.0,
                          color: (item.RESER_COUNT.toString() == '0') ? Colors.grey.shade300 : Colors.blue,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                          child: Text('${Utils.getCashComma(item.RESER_COUNT.toString())} 건',
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.white,
                              )),
                          onPressed: () {
                            if(item.RESER_COUNT.toString() == '0')
                              return;

                            _reserve(item.TELNO_ORIGINAL.toString(), item.CUST_NAME);
                          })),
                ),
                DataCell(Center(child: MaterialButton(
                    height: 30.0,
                  color: (item.MILEAGE_AMT.toString() == '0') ?  Colors.grey.shade300 : Colors.blue,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                  child: Text('총액: ${Utils.getCashComma(item.MILEAGE_AMT.toString())}', style: TextStyle(fontSize: 13, color: Colors.white)),
                  onPressed: () => _mileage(item.CUST_CODE.toString(), item.CUST_NAME),
                )),
                ),
                DataCell(Center(
                    child: InkWell(
                      child: Icon(Icons.money, color: Colors.blue, size: 22),
                      onTap: () {
                        _coupon(item.CUST_CODE.toString(), item.CUST_NAME);
                      })
                    )
                ),

                // DataCell(Center(
                //     child: InkWell(
                //       child: (item.CUST_ID_GBN == 'Z' || item.CUST_ID_GBN == null || item.CUST_ID_GBN == 'null' || item.CUST_ID_GBN == '')
                //           ? Icon(Icons.perm_device_info, color: Colors.blue, size: 21,)
                //           : Image.asset(getIconURL(item.CUST_ID_GBN), width: 21, height: 21,),
                //       onTap: () async {
                //         await CustomerController.to.getDeviceInfoData(item.CUST_CODE.toString());
                //
                //         showDialog(
                //             context: context,
                //             builder: (BuildContext context) => Dialog(
                //               child: CustomerDeviceInfo(),
                //             )
                //         );
                //       },
                //     ),
                //   ),
                // ),
                // DataCell(
                //   Center(
                //     child: InkWell(
                //       child: Icon(Icons.perm_device_info, size: 20, color: Colors.blue),
                //       onTap: () async{
                //         await CustomerController.to.getDeviceInfoData(item.CUST_CODE.toString());
                //
                //         showDialog(
                //             context: context,
                //             builder: (BuildContext context) => Dialog(
                //               child: CustomerDeviceInfo(),
                //             )
                //         );
                //       },
                //     ),
                //   ),
                // ),
                DataCell(
                  Center(
                    child: InkWell(
                      child: Icon(Icons.account_box_outlined, size: 20, color: Colors.blue),
                      onTap: () async{
                        await CustomerController.to.getDeviceInfoData(item.CUST_CODE.toString());

                        showDialog(
                            context: context,
                            builder: (BuildContext context) => Dialog(
                              child: CustomerInvite(custName: item.CUST_NAME, custCode: item.CUST_CODE.toString()),
                            )
                        );
                      },
                    ),
                  ),
                ),
                DataCell(Center(
                    child: (item.MEMO.toString() == '' || item.MEMO == null  || item.MEMO == 'null')
                        ? IconButton(icon: Icon(Icons.clear, color: Colors.grey.shade400, size: 21))
                        : Tooltip(
                      child: IconButton(
                        icon: Icon(Icons.radio_button_unchecked, color: Colors.blue, size: 21),
                      ),
                      message: item.MEMO,
                      textStyle: TextStyle(fontSize: 12, color: Colors.white),
                      padding: EdgeInsets.all(5),
                    ))
                ),
                // DataCell(Center(
                //     child: InkWell(
                //       child: (item.CUST_ID_GBN == 'Z' || item.CUST_ID_GBN == null || item.CUST_ID_GBN == 'null' || item.CUST_ID_GBN == '')
                //           ? Icon(Icons.perm_device_info, color: Colors.blue, size: 21,)
                //           : Image.asset(getIconURL(item.CUST_ID_GBN), width: 21, height: 21,),
                //       onTap: () {
                //         _info(item.CUST_CODE.toString());
                //       },
                //     ),
                //   ),
                // ),

                // if (isMainShowEnabled() == true)
                //   DataCell(Center(child: SelectableText(item.INSERT_DATE.toString() == 'null' ? '--' : item.INSERT_DATE.toString(), style: TextStyle(color: Colors.black), showCursor: true))),
                // if (isMainShowEnabled() == true)
                //   DataCell(Center(child: SelectableText(item.DEL_DATE.toString() == 'null' ? '--' : item.DEL_DATE.toString(), style: TextStyle(color: Colors.black), showCursor: true))),

                if (isMainShowEnabled() == true)
                  DataCell(Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SelectableText(item.INSERT_DATE.toString() == 'null' ? '가입일: --' : '가입일: ${item.INSERT_DATE.toString()}', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                          SelectableText(item.DEL_DATE.toString() == 'null' ? '탈퇴일: --' : '탈퇴일: ${item.DEL_DATE.toString()}', style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                        ],
                      )
                    )
                  ),

              ]);
            }).toList(),
            columns: <DataColumn>[
              DataColumn(label: Expanded(child: Text('회원번호', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('회원정보', textAlign: TextAlign.center)),),
              //DataColumn(label: Expanded(child: Text('연락처', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('주문완료(건수/총액)', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('예약완료(건수)', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('마일리지', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('쿠폰', textAlign: TextAlign.center)),),

              //DataColumn(label: Expanded(child: Text('단말정보', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('친구초대', textAlign: TextAlign.center)),),
              //DataColumn(label: Expanded(child: Text('가입내역', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('메모', textAlign: TextAlign.center)),),
              if (isMainShowEnabled() == true)
                DataColumn(label: Expanded(child: Text('가입일/탈퇴일', textAlign: TextAlign.center)),),
              // if (isMainShowEnabled() == true)
              //   DataColumn(label: Expanded(child: Text('탈퇴일', textAlign: TextAlign.center)),),
            ],
          ),
          (isMainShowEnabled() == true) ? Divider(): SizedBox.shrink(),
          (isMainShowEnabled() == true) ? showPagerBar() : SizedBox.shrink(),
        ],
      ),
    );
  }

  bool isMainShowEnabled(){
    return (widget.custCode == null/* && widget.custName == null*/);
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                //Text('row1'),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context) ? Container(height: 48) : Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Text('페이지당 행 수 : ', style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL),),
                Container(
                  width: 70,
                  height: 24,
                  decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(5.0)),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton2(
                        value: _selectedpagerows,
                        isExpanded: true,
                        style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: FONT_FAMILY),
                        items: Utils.getPageRowList(),
                        dropdownMaxHeight: 180,
                        itemHeight: 36,
                        itemPadding: const EdgeInsets.only(left: 16, right: 16),
                        dropdownPadding: const EdgeInsets.symmetric(vertical: 6),
                        dropdownDecoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                        ),
                        onChanged: (value) {
                          setState(() {
                            _selectedpagerows = value;
                            _currentPage = 1;
                            _query();
                          });
                        }),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String getIconURL(String cust_id_gbn){
    String retImageURL;

    if (cust_id_gbn == 'A')            retImageURL = 'assets/daeguro_icon_32.png';
    else if (cust_id_gbn == 'G')       retImageURL = 'assets/google_icon_32.png';
    else if (cust_id_gbn == 'K')       retImageURL = 'assets/kakao_icon_32.png';
    else  if (cust_id_gbn == 'N')      retImageURL = 'assets/naver_icon_32.png';
    else    if (cust_id_gbn == 'I')    retImageURL = 'assets/apple_icon_32.png';
    //else      if (cust_id_gbn = 'Z')

    return retImageURL;
  }

  String getKeyName(){
    String retName;

    if (_div == '1')        retName = '회원명';
    else if (_div == '2')   retName = '회원번호';
    else if (_div == '3')    retName = '전화번호';
    else if (_div == '4')    retName = '메모';
    else
      retName = '구분값오류';

    return retName;
  }
}
