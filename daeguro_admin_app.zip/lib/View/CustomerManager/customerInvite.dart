import 'dart:convert';

import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/Model/customer/customerListModel.dart';
import 'package:daeguro_admin_app/Model/shop/shopEventCouponDetailModel.dart';
import 'package:daeguro_admin_app/Model/shop/shopEventCouponItemModel.dart';
import 'package:daeguro_admin_app/Model/shop/shopEventHistoryModel.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/AgentManager/agentAccount_Controller.dart';
import 'package:daeguro_admin_app/View/CustomerManager/customerList.dart';
import 'package:daeguro_admin_app/View/CustomerManager/customer_controller.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccount_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

import 'package:get/get.dart';

class CustomerInvite extends StatefulWidget {
  final String custName;
  final String custCode;

  const CustomerInvite({Key key, String this.custName, String this.custCode}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CustomerInviteState();
  }
}

class CustomerInviteState extends State<CustomerInvite> with SingleTickerProviderStateMixin {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  List<CustomerListModel> _dataList = <CustomerListModel>[];
  List<CustomerListModel> _dataList2 = <CustomerListModel>[];

  ScrollController _scrollController;

  int current_tabIdx = 0;
  String _referral_code = '';
  int _invite_cnt = 0;

  loadData() async {
    CustomerListModel temp = CustomerListModel();

    await CustomerController.to.getInviteLog(widget.custCode).then((value) {
      if (value == null) {
        //print('value is NULL');
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        _referral_code = value['referral_code'];
        _invite_cnt = int.parse(value['invite_cnt'].toString());

        // 초대 해 준 회원정보 바인딩
        if(value['invited']['my_referral_code'].toString() != 'null') {
            temp.REFERRAL_CODE = value['invited']['my_referral_code'];
            temp.CUST_CODE =  int.parse(value['invited']['cust_code']);
            temp.CUST_NAME = Utils.getNameFormat(value['invited']['cust_name'], true);
            temp.TELNO = Utils.getPhoneNumFormat(value['invited']['telno'], true);
            temp.INSERT_DATE = value['invited']['ins_date'];
          } else {
          temp.REFERRAL_CODE = '--';
          temp.CUST_CODE = null;
          temp.CUST_NAME = '--';
          temp.TELNO = '--';
          temp.INSERT_DATE = '--';
        }

        _dataList.add(temp);

        // 초대 한 회원정보 바인딩
        for(int i = 0 ; i < _invite_cnt ; i++){
          temp = CustomerListModel();
          temp.REFERRAL_CODE = value['invite'][i]['my_referral_code'];
          temp.CUST_CODE =  int.parse(value['invite'][i]['cust_code'].toString());
          temp.CUST_NAME = Utils.getNameFormat(value['invite'][i]['cust_name'], true);
          temp.TELNO = Utils.getPhoneNumFormat(value['invite'][i]['telno'], true);
          temp.INSERT_DATE = value['invite'][i]['ins_date'];

          _dataList2.add(temp);
        }
      }
    });

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(CustomerController());

    _scrollController = ScrollController();

    WidgetsBinding.instance.addPostFrameCallback((c) {
      loadData();
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
        key: formKey,
        child: Container(
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(5), border: Border.all(width: 1, color: Colors.grey.withOpacity(.3))),
          margin: EdgeInsets.fromLTRB(10, 10, 5, 10), //EdgeInsets.all(15),
          child: Column(
            children: [
              Container(
                alignment: Alignment.centerLeft,
                margin: EdgeInsets.all(5),
                child: SelectableText('[회원코드] ' + _referral_code, style: TextStyle(fontSize: 13, fontWeight: FONT_BOLD)),
              ),
              Divider(),
              Container(
                alignment: Alignment.centerLeft,
                margin: EdgeInsets.all(5),
                child: Text('[내가 초대 한 회원 정보]', style: TextStyle(fontSize: 13, fontWeight: FONT_BOLD)),
              ),
              Container(
                margin: EdgeInsets.all(5),
                child: DataTable(
                  headingRowColor: MaterialStateColor.resolveWith((states) => Colors.blue[50]),
                  headingTextStyle: TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54, fontSize: 12),
                  headingRowHeight: 24,
                  dataRowHeight: 32,
                  dividerThickness: 0.01,
                  dataRowColor: MaterialStateColor.resolveWith((states) => Colors.white),
                  dataTextStyle: TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, fontSize: 12),
                  columnSpacing: 0,
                  rows: _dataList.map((item) {
                    return DataRow(cells: [
                      DataCell(Center(
                          child: SelectableText(
                            item.REFERRAL_CODE.toString() ?? '--',
                            style: TextStyle(color: Colors.black),
                            showCursor: true,
                          ))),
                      DataCell(Center(
                          child: SelectableText(
                            item.CUST_CODE.toString() == 'null' ? '--' : item.CUST_CODE.toString(),
                            style: TextStyle(color: Colors.black),
                            showCursor: true,
                          ))),
                      DataCell(Center(
                          child: SelectableText(
                            item.CUST_NAME.toString() ?? '--',
                            style: TextStyle(color: Colors.black),
                            showCursor: true,
                          ))),
                      DataCell(Center(
                          child: SelectableText(
                            item.TELNO.toString() ?? '--',
                            style: TextStyle(color: Colors.black),
                            showCursor: true,
                          ))),
                      DataCell(Center(
                          child: SelectableText(
                            item.INSERT_DATE.toString() ?? '--',
                            style: TextStyle(color: Colors.black),
                            showCursor: true,
                          ))),
                    ]);
                  }).toList(),
                  columns: <DataColumn>[
                    DataColumn(
                      label: Container(child: Text('코드번호', textAlign: TextAlign.center), width: 80),
                    ),
                    DataColumn(
                      label: Container(child: Text('회원번호', textAlign: TextAlign.center), width: 70),
                    ),
                    DataColumn(
                      label: Container(child: Text('회원명', textAlign: TextAlign.center), width: 80),
                    ),
                    DataColumn(
                      label: Container(child: Text('연락처', textAlign: TextAlign.center), width: 100),
                    ),
                    DataColumn(
                      label: Container(child: Text('입력일자', textAlign: TextAlign.center), width: 150),
                    ),
                  ],
                ),
              ),
              Divider(),
              Container(
                margin: EdgeInsets.all(5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text('[나를 초대한 회원 정보]', style: TextStyle(fontSize: 13, fontWeight: FONT_BOLD)),
                    Text('총 ' + _invite_cnt.toString() + '건', style: TextStyle(fontSize: 13, fontWeight: FONT_BOLD)),
                  ],
                ),
              ),
              Expanded(child: Container(child: getView2(), margin: EdgeInsets.all(7)))
            ],
          ),
        ));

    var result = Scaffold(
      appBar: AppBar(
        title: Text('친구초대 내역 [회원명 : ${widget.custName}]'),
      ),
      body: form,
    );

    return SizedBox(
      width: 550,
      height: 600,
      child: result,
    );
  }

  Widget getView2() {
    return ListView.builder(
      controller: _scrollController,
      //padding: const EdgeInsets.symmetric(horizontal: 4.0, vertical: 8.0),
      itemCount: 1,
      itemBuilder: (BuildContext context, int index) {
        return _dataList2 != null ? GestureDetector(
          child:
          DataTable(
            headingRowColor: MaterialStateColor.resolveWith((states) => Colors.blue[50]),
            headingTextStyle: TextStyle(fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY, color: Colors.black54, fontSize: 12),
            headingRowHeight: 24,
            dataRowHeight: 32,
            dividerThickness: 0.01,
            dataRowColor: MaterialStateColor.resolveWith((states) => Colors.white),
            dataTextStyle: TextStyle(fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY, fontSize: 12),
            columnSpacing: 0,
            rows: _dataList2.map((item) {
              return DataRow(cells: [
                DataCell(Center(
                    child: SelectableText(
                      item.REFERRAL_CODE.toString() ?? '--',
                      style: TextStyle(color: Colors.black),
                      showCursor: true,
                    ))),
                DataCell(Center(
                    child: SelectableText(
                      item.CUST_CODE.toString() == 'null' ? '--' : item.CUST_CODE.toString(),
                      style: TextStyle(color: Colors.black),
                      showCursor: true,
                    ))),
                DataCell(Center(
                    child: SelectableText(
                      item.CUST_NAME.toString() ?? '--',
                      style: TextStyle(color: Colors.black),
                      showCursor: true,
                    ))),
                DataCell(Center(
                  child: MaterialButton(
                    height: 30.0,//Responsive.isDesktop(context) == true ? 40.0 : 30.0,
                    //color: Colors.lightBlue,
                    minWidth: 40,
                    child: Text(item.TELNO.toString() ?? '--', style: TextStyle(color: Colors.black, fontSize: 13)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                    onPressed: ()  {
                      double poupWidth = 700;
                      double poupHeight = 230;

                      //print('회원조회:${item.APP_CUST_CODE}');

                      showDialog(
                        context: context,
                        builder: (BuildContext context) => Dialog(
                          child: SizedBox(
                            width: poupWidth,
                            height: poupHeight,
                            child: Scaffold(
                              appBar: AppBar(
                                title: Text('회원 정보 [회원명: ${item.CUST_NAME}]'),
                              ),
                              body: CustomerList(custCode: item.CUST_CODE.toString(), popWidth: poupWidth, popHeight: poupHeight),
                            ),
                          ),
                          //child: CustomerList(custTelno: item.customerTelNo),//CustomerOrder(custCode: custCode, custName: custName,),
                        ),
                      );
                    },
                  ),
                )),
                DataCell(Center(
                    child: SelectableText(
                      item.INSERT_DATE.toString() ?? '--',
                      style: TextStyle(color: Colors.black),
                      showCursor: true,
                    ))),
              ]);
            }).toList(),
            columns: <DataColumn>[
              DataColumn(
                label: Container(child: Text('코드번호', textAlign: TextAlign.center), width: 80),
              ),
              DataColumn(
                label: Container(child: Text('회원번호', textAlign: TextAlign.center), width: 70),
              ),
              DataColumn(
                label: Container(child: Text('회원명', textAlign: TextAlign.center), width: 80),
              ),
              DataColumn(
                label: Container(child: Text('연락처', textAlign: TextAlign.center), width: 100),
              ),
              DataColumn(
                label: Container(child: Text('입력일자', textAlign: TextAlign.center), width: 150),
              ),
            ],
          ),
        ) : Text('Data is Empty');
      },
    );
  }
}
