
import 'package:daeguro_admin_app/View/CalculateManager/calculateCcMileage.dart';
import 'package:daeguro_admin_app/View/ShopManager/Event/shopEventList.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccountList.dart';
import 'package:daeguro_admin_app/View/Today/header.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class CalculateCcMileageManager extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return SafeArea(
      child: SingleChildScrollView(
        physics: NeverScrollableScrollPhysics(),
        padding: EdgeInsets.symmetric(horizontal: defaultWidthPadding, vertical: defaultHeightPadding),
        //child: Container(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Header(title: "콜센타 적립금 관리"),
            //SizedBox(height: defaultHeightPadding),
            CalculateCcMileage(),
          ],
        ),
      ),
    );
  }
}