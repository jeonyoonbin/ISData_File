import 'dart:convert';
import 'dart:html';

import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_text_box.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_date.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_input.dart';
import 'package:daeguro_admin_app/Model/calc/calculateCcMileageModel.dart';
import 'package:daeguro_admin_app/Model/calc/callCenter_code_name.dart';
import 'package:daeguro_admin_app/Model/search_items.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/AgentManager/agentAccount_Controller.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculateCcMileageCcenterPurchase.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculateCcMileagePurchase.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculate_controller.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderDetail.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderManager_controller.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccountList.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccount_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:daeguro_admin_app/constants/serverInfo.dart';

import 'package:date_format/date_format.dart';
import 'package:dropdown_button2/dropdown_button2.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class CalculateCcMileage extends StatefulWidget {
  final String shopName;

  const CalculateCcMileage({Key key, this.shopName}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CalculateCcMileageState();
  }
}

class CalculateCcMileageState extends State<CalculateCcMileage> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  bool excelEnable = true;

  List<CalculateCcMileageModel> dataList = <CalculateCcMileageModel>[];
  SearchItems _searchItems = new SearchItems();

  List MCodeListItems = [];
  List<SelectOptionVO> callCenterList = [];

  String _mCode = '3';
  String _ccCode = ' ';

  String _dtDiv = '1';
  String _testYn = ' ';

  String _State = ' ';

  //페이지정보
  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  //잔액
  int _sumPreAmt = 0;

  //기간별 입,출,잔액
  int _sumInAmt = 0;
  int _sumOutAmt = 0;
  int _sumPreAmtIn = 0;

  var weight;

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    _searchItems = null;
    _searchItems = new SearchItems();

    MCodeListItems = Utils.getMCodeList();

    _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    _searchItems.memo = '';
    _searchItems.name = '';
  }

  _sum() async {
    await ISProgressDialog(context).show(status: 'Loading...');

    CalculateController.to.startDate.value = _searchItems.startdate.replaceAll('-', '');
    CalculateController.to.endDate.value = _searchItems.enddate.replaceAll('-', '');
    CalculateController.to.name.value = _searchItems.name;
    CalculateController.to.memo.value = _searchItems.memo;
    CalculateController.to.testYn.value = _testYn;

    //if (this.mounted) {
    await CalculateController.to.getCcMileageDataSum(_mCode, _ccCode, _dtDiv).then((v) => {
          setState(() {
            _sumPreAmt = CalculateController.to.sumPreAmt;
            _sumInAmt = CalculateController.to.sumInAmt;
            _sumOutAmt = CalculateController.to.sumOutAmt;
            _sumPreAmtIn = CalculateController.to.sumPreAmtIn;
          })
        });
    //}
    await ISProgressDialog(context).dismiss();
  }

  _query() {
    CalculateController.to.startDate.value = _searchItems.startdate.replaceAll('-', '');
    CalculateController.to.endDate.value = _searchItems.enddate.replaceAll('-', '');
    CalculateController.to.page.value = _currentPage.round().toString();
    CalculateController.to.rows.value = _selectedpagerows.toString();
    CalculateController.to.name.value = _searchItems.name;
    CalculateController.to.memo.value = _searchItems.memo;
    CalculateController.to.testYn.value = _testYn;

    loadData();
  }

  _detail({String orderNo}) async {
    await OrderController.to.getDetailData(orderNo.toString());

    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: OrderDetail(orderNo: orderNo),
      ),
    );
  }

  loadCallCenterListData() async {
    callCenterList.clear();

    await AgentController.to.getDataCCenterItems(_mCode).then((value) {
      if (value == null) {
        ISAlert(context, '콜센터정보를 가져오지 못했습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        callCenterList.add(new SelectOptionVO(value: ' ', label: '전체', label2: ''));
        value.forEach((element) {
          CallCenterCodeName tempData = CallCenterCodeName.fromJson(element);
          callCenterList.add(new SelectOptionVO(value: tempData.ccCode, label: '[' + tempData.ccCode + ']' + tempData.ccName, label2: tempData.ccName));
        });

        setState(() {});
      }
    });

    // if (this.mounted) {
    //   setState(() {
    //
    //   });
    // }
  }

  loadData() async {
    await ISProgressDialog(context).show(status: 'Loading...');
    // MCodeListItems.clear();

    // await AgentController.to.getDataMCodeItems();
    // MCodeListItems = AgentController.to.qDataMCodeItems;

    await CalculateController.to.getCcMileageData(_mCode, _ccCode, _dtDiv).then((value) {
      //if (this.mounted) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        setState(() {
          dataList.clear();

          value.forEach((element) {
            CalculateCcMileageModel temp = CalculateCcMileageModel(); //.fromJson(e);

            temp.rNum = element['RNUM'] as int;
            temp.seqNo = element['SEQNO'] as int;
            temp.ccCode = element['CCCODE'] as String;
            temp.ccName = element['CCNAME'] as String;
            temp.orderDate = element['ORDER_DATE'] as String;
            temp.chargeDate = element['CHARGE_DATE'] as String;
            temp.chargeGbn = element['CHARGE_GBN'] as String;
            temp.chargeGbnNm = element['CHARGE_GBN_NM'] as String;
            temp.preAmt = element['PRE_AMT'] as int;
            temp.inAmt = element['IN_AMT'] as int;
            temp.outAmt = element['OUT_AMT'] as int;
            temp.chargeUcode = element['CHARGE_UCODE'] as int;
            temp.chargeName = element['CHARGE_NAME'] as String;
            temp.memo = element['MEMO'] as String;
            temp.mCode = element['MCODE'] as int;
            temp.mName = element['MNAME'] as String;
            temp.groupId = element['GROUP_ID'] as String;
            temp.orderNo = element['ORDER_NO'] as int;
            temp.shopCd = element['SHOP_CD'] as String;
            temp.shopName = element['SHOP_NAME'] as String;
            temp.orderMcode = element['ORDER_MCODE'] as int;
            temp.preAmtSum = element['PRE_AMT_SUM'] as int;

            if (temp.chargeDate != null) temp.chargeDate = temp.chargeDate.replaceAll('T', '  ');

            dataList.add(temp);
          });
          _totalRowCnt = CalculateController.to.totalRowCnt;
          _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
          _sumPreAmt = CalculateController.to.sumPreAmt;
          _sumInAmt = CalculateController.to.sumInAmt;
          _sumOutAmt = CalculateController.to.sumOutAmt;
          _sumPreAmtIn = CalculateController.to.sumPreAmtIn;
        });
      }
      //}
    });
    await ISProgressDialog(context).dismiss();
  }

  @override
  void initState() {
    super.initState();

    Get.put(OrderController());
    Get.put(AgentController());
    Get.put(CalculateController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      loadCallCenterListData();
      _query();
    });

    setState(() {
      _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
      _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
      _ccCode = ' ';
    });
  }

  @override
  void dispose() {
    if (dataList != null) {
      dataList.clear();
      dataList = null;
    }
    //MCodeListItems.clear();
    // callCenterList.clear();

    super.dispose();
  }

  @override
  void deactivate() {
    super.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //_getSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Row(mainAxisAlignment: MainAxisAlignment.end, crossAxisAlignment: CrossAxisAlignment.end, children: [
        Column(
          children: [
            ISSearchDropdown(
              label: '회원사명',
              value: _mCode,
              onChange: (value) {
                setState(() {
                  _mCode = value;
                  _currentPage = 1;

                  loadCallCenterListData();
                  _query();
                });
              },
              width: 210,
              item: MCodeListItems.map((item) {
                return new DropdownMenuItem<String>(
                    child: new Text(
                      item['mName'],
                      style: TextStyle(fontSize: 13, color: Colors.black),
                    ),
                    value: item['mCode']);
              }).toList(),
            ),
            SizedBox(
              height: 8,
            ),
            ISSearchDropdown(
              label: '콜센터명',
              value: _ccCode,
              width: 210,
              item: callCenterList.map((item) {
                return new DropdownMenuItem<String>(
                    child: new Text(
                      item.label,
                      style: TextStyle(fontSize: 13, color: Colors.black),
                    ),
                    value: item.value);
              }).toList(),
              onChange: (v) {
                if (EasyLoading.isShow == true) return;
                callCenterList.forEach((element) {
                  if (v == element.value) {
                    _ccCode = element.value;
                  }
                });

                _currentPage = 1;
                _query();
              },
            )
          ],
        ),
        Column(
          children: [
            Row(
              children: [
                ISSearchDropdown(
                  label: '기간 기준',
                  width: 120,
                  value: _dtDiv,
                  onChange: (value) {
                    setState(() {
                      _dtDiv = value;
                    });
                  },
                  item: [
                    DropdownMenuItem(
                      value: '1',
                      child: Text('회계'),
                    ),
                    DropdownMenuItem(
                      value: '2',
                      child: Text('주문시간'),
                    ),
                  ].cast<DropdownMenuItem<String>>(),
                ),
            ISSearchDropdown(
              label: '테스트 여부',
                  width: 120,
              value: _testYn,
              onChange: (value) {
                setState(() {
                  _testYn = value;
                });
              },
              item: [
                DropdownMenuItem(
                  value: ' ',
                  child: Text('전체'),
                ),
                DropdownMenuItem(
                  value: 'Y',
                  child: Text('테스트건 조회'),
                ),
                DropdownMenuItem(
                  value: 'N',
                  child: Text('테스트건 제외'),
                ),
              ].cast<DropdownMenuItem<String>>(),
            ),
              ],
            ),
            SizedBox(
              height: 8,
            ),
            Row(
              children: [
                ISSearchSelectDate(
                  context,
                  label: '시작일',
                  width: 120,
                  value: _searchItems.startdate.toString(),
                  onTap: () async {
                    DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.startdate);
                    final DateTime picked = await showDatePicker(
                      context: context,
                      initialDate: valueDt,
                      firstDate: DateTime(1900, 1),
                      lastDate: DateTime(2031, 12),
                    );

                    setState(() {
                      if (picked != null) {
                        _searchItems.startdate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                      }
                    });
                  },
                ),
                ISSearchSelectDate(
                  context,
                  label: '종료일',
                  width: 120,
                  value: _searchItems.enddate.toString(),
                  onTap: () async {
                    DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.enddate);
                    final DateTime picked = await showDatePicker(
                      context: context,
                      initialDate: valueDt,
                      firstDate: DateTime(1900, 1),
                      lastDate: DateTime(2031, 12),
                    );

                    setState(() {
                      if (picked != null) {
                        _searchItems.enddate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                      }
                    });
                  },
                ),
              ],
            )
          ],
        ),
        Column(
          children: [
            Container(
              child: Stack(
                alignment: Alignment.centerRight,
                children: [
                  ISSearchInput(
                    label: '메모',
                    width: 240,
                    value: _searchItems.memo,
                    onChange: (v) {
                      _searchItems.memo = v;
                    },
                    onFieldSubmitted: (v) {
                      _currentPage = 1;
                      _query();
                    },
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 8,
            ),
            Row(
              children: [
                Container(
                  child: Stack(
                    alignment: Alignment.centerRight,
                    children: [
                      ISSearchInput(
                        label: '주문번호',
                        width: 152,
                        value: _searchItems.name,
                        onChange: (v) {
                          _searchItems.name = v;
                        },
                        onFieldSubmitted: (v) {
                          _currentPage = 1;
                          _query();
                        },
                      ),
                    ],
                  ),
                ),
                ISSearchButton(
                    label: '조회',
                    iconData: Icons.search,
                    onPressed: () => {
                          _currentPage = 1,
                          _query(),
                        }),
                SizedBox(
                  width: 4,
                )
              ],
            )
          ],
        ),
      ]),
    );

    var bar2 = Expanded(
        flex: 0,
        child: Container(
          // padding: EdgeInsets.only(bottom: 5),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text('기간별 합계 ', style: TextStyle(color: Colors.lightBlue, fontWeight: FONT_BOLD)),
                  SizedBox(width: 10),
                  Text('입금 ', style: TextStyle(color: Colors.black, fontWeight: FONT_BOLD)),
                  Text(Utils.getCashComma('$_sumInAmt'), style: TextStyle(color: Colors.black)),
                  SizedBox(width: 10),
                  Text('출금 ', style: TextStyle(color: Colors.black, fontWeight: FONT_BOLD)),
                  Text(Utils.getCashComma('$_sumOutAmt'), style: TextStyle(color: Colors.black)),
                  SizedBox(width: 10),
                  Text('잔액 ', style: TextStyle(color: Colors.black, fontWeight: FONT_BOLD)),
                  Text(Utils.getCashComma('$_sumPreAmtIn'), style: TextStyle(color: Colors.black)),
                ],
              ),
              // SizedBox(width: 20),
              Row(
                children: [
                  ISTextBox(label: '총 잔액', width: 160, value: _sumPreAmt.toString()),
                  Container(
                    alignment: Alignment.centerRight,
                    margin: EdgeInsets.all(5),
                    child: ISButton(
                        label: '합계',
                        iconData: Icons.autorenew,
                        iconColor: Colors.white,
                        textStyle: TextStyle(color: Colors.white),
                        onPressed: () => {
                              if (EasyLoading.isShow != true) {_sum()}
                            }),
                  ),
                ],
              ),
            ],
          ),
        ));

    return Container(
      //padding: EdgeInsets.only(left: 50, right: 50, bottom: 0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // SizedBox(height: 5),
          form,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('※ 정산일자 기준, 배달완료 데이터로 조회 됩니다.', style: TextStyle(color: Colors.blue[400], fontSize: 12)),
              buttonBar,
            ],
          ),
          Divider(),
          bar2,
          Divider(),
          ISDatatable(
            panelHeight: (MediaQuery.of(context).size.height - defaultContentsHeight) - 104,
            listWidth: Responsive.getResponsiveWidth(context, 640),
            rows: dataList.map((item) {
              if (item.ccCode != null) {
                weight = FONT_NORMAL;
              } else {
                weight = FONT_NORMAL;
              }
              return DataRow(cells: [
                DataCell(Center(child: SelectableText(item.orderNo.toString() == 'null' || item.orderNo.toString() == '0' ? '--' : item.orderNo.toString() ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true))),
                DataCell(Center(child: SelectableText(item.chargeDate ?? '--', style: TextStyle(color: Colors.black, fontSize: 12), textAlign: TextAlign.center, showCursor: true))),
                DataCell(Center(child: SelectableText(item.chargeGbnNm ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(Align(child: SelectableText(item.ccName ?? '--', style: TextStyle(color: Colors.black), showCursor: true), alignment: Alignment.centerLeft)),
                DataCell(Align(
                    child: MaterialButton(
                  height: 30.0, //Responsive.isDesktop(context) == true ? 40.0 : 30.0,
                  child: Text(item.shopCd == null ? '--' : '[' + item.shopCd.toString() + '] ' + item.shopName.toString(), style: TextStyle(color: Colors.black, fontSize: 13)),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                  onPressed: () {
                    if(item.shopCd == null)
                      return;

                    double poupWidth = 1040;
                    double poupHeight = 600;

                    showDialog(
                      context: context,
                      builder: (BuildContext context) => Dialog(
                        child: SizedBox(
                          width: poupWidth,
                          height: poupHeight,
                          child: Scaffold(
                            appBar: AppBar(
                              title: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text('주문 가맹점 - [${item.shopCd}] ${item.shopName}'),
                                  Obx(() => Text(
                                        '[주문] 전체: ' + ShopController.to.shopOrderCount.value.toString() + '/완료: ' + ShopController.to.shopOrderCountOk.value.toString() + '/취소: ' + ShopController.to.shopOrderCountCancel.value.toString(),
                                        style: TextStyle(fontSize: 15, fontWeight: FONT_BOLD),
                                      ))
                                ],
                              ),
                            ),
                            body: ShopAccountList(shopCd: item.shopCd, popWidth: poupWidth, popHeight: poupHeight),
                          ),
                        ),
                      ),
                    );
                  },
                ), alignment: Alignment.centerLeft,)),
                DataCell(Align(child: SelectableText(Utils.getCashComma(item.inAmt.toString()) ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true), alignment: Alignment.centerRight)),
                DataCell(Align(child: SelectableText(Utils.getCashComma(item.outAmt.toString()) ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true), alignment: Alignment.centerRight)),
                DataCell(Align(child: SelectableText(Utils.getCashComma(item.preAmt.toString()) ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true), alignment: Alignment.centerRight)),
                DataCell(Center(child: SelectableText(item.chargeName ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(Align(child: SelectableText(item.memo ?? '--', style: TextStyle(color: Colors.black), textAlign: TextAlign.center, showCursor: true), alignment: Alignment.centerLeft)),
                DataCell(Center(
                    child: item.orderNo.toString() == 'null' || item.orderNo.toString() == '0' || item.chargeGbn.toString() == 'T'
                        ? IconButton(
                            onPressed: () {},
                            icon: Icon(
                              Icons.receipt_long,
                              color: Colors.grey,
                            ),
                            tooltip: '상세없음',
                          )
                        : IconButton(
                            onPressed: () {
                              _detail(orderNo: item.orderNo.toString());
                            },
                            icon: Icon(Icons.receipt_long),
                            tooltip: '상세',
                          ))),
                if (AuthUtil.isAuthEditEnabled('19') == true)
                  DataCell(
                    Center(
                        child: InkWell(
                      child: Icon(Icons.monetization_on),
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) => Dialog(
                            child: CalculateCcMileagePurchase(ccCode: item.ccCode, callCenterList: callCenterList),
                          ),
                        ).then((v) async {
                          if (v != null) {
                            await Future.delayed(Duration(milliseconds: 500), () {
                              loadData();
                            });
                          }
                        });
                      },
                    )),
                  ),
                if (AuthUtil.isAuthEditEnabled('19') == true)
                  DataCell(
                    Center(
                        child: InkWell(
                      child: Icon(Icons.change_circle),
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) => Dialog(
                            child: CalculateCcMileageCcenterPurchase(ccCode: item.ccCode, callCenterList: callCenterList),
                          ),
                        ).then((v) async {
                          if (v != null) {
                            await Future.delayed(Duration(milliseconds: 500), () {
                              loadData();
                            });
                          }
                        });
                      },
                      //tooltip: '콜센터간 사입처리',
                    )),
                  ),
              ]);
            }).toList(),
            columns: <DataColumn>[
              DataColumn(
                label: Expanded(child: Text('주문번호', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('적립일자', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('적립구분', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('콜센터명', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('가맹점명', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('적립금입금', textAlign: TextAlign.right)),
              ),
              DataColumn(
                label: Expanded(child: Text('적립금출금', textAlign: TextAlign.right)),
              ),
              DataColumn(
                label: Expanded(child: Text('적립잔액', textAlign: TextAlign.right)),
              ),
              DataColumn(
                label: Expanded(child: Text('작업자', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('메모', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('상세', textAlign: TextAlign.center)),
              ),
              if (AuthUtil.isAuthEditEnabled('19') == true)
                DataColumn(
                  label: Expanded(child: Text('사입', textAlign: TextAlign.center)),
                ),
              if (AuthUtil.isAuthEditEnabled('19') == true)
                DataColumn(
                  label: Expanded(child: Text('콜센터간 사입', textAlign: TextAlign.center)),
                ),
            ],
          ),
          Divider(),
          SizedBox(
            height: 0,
          ),
          showPagerBar(),
        ],
      ),
    );
  }

  void ExcelDownload() async {
    await ISProgressDialog(context).show(status: 'download...');
    String url = ServerInfo.REST_URL_CALCULATE_CCMILEAGE_EXCEL + '?mcode=$_mCode&cccode=$_ccCode&test_yn=$_testYn&date_begin=${_searchItems.startdate.replaceAll('-', '')}&date_end=${_searchItems.enddate.replaceAll('-', '')}&keyword=${_searchItems.name}&memo=${_searchItems.memo}&dt_div=$_dtDiv';

    await http.get(url).then((http.Response response) {
      var bytes = response.bodyBytes;

      DateTime now = DateTime.now();
      DateTime date = DateTime(now.year, now.month, now.day);

      AnchorElement(href: 'data:application/octet-stream;charset=utf-16le;base64,${base64.encode(bytes)}')
        ..setAttribute('download', '콜센터 적립금 관리_' + formatDate(date, [yy, mm, dd]) + '.xlsx')
        ..click();
    });

    setState(() {});

    await ISProgressDialog(context).dismiss();
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                AuthUtil.isAuthDownloadEnabled('19') == true
                    ? ISButton(
                        height: 24,
                        label: 'Excel저장',
                        iconColor: Colors.white,
                        iconData: Icons.reply,
                        textStyle: TextStyle(color: Colors.white, fontSize: 12),
                        onPressed: () {
                          ExcelDownload();
                        })
                    : Container(),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context)
                ? Container(height: 48)
                : Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      Text(
                        '조회 데이터 : ',
                        style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL),
                      ),
                      Text(
                        CalculateController.to.totalRowCnt.toString() + ' 건',
                        style: TextStyle(fontSize: 12, fontWeight: FONT_BOLD),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      Text(
                        '페이지당 행 수 : ',
                        style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL),
                      ),
                      Container(
                        width: 70,
                        height: 24,
                        decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(5.0)),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton2(
                              value: _selectedpagerows,
                              isExpanded: true,
                              style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: FONT_FAMILY),
                              items: Utils.getPageRowList(),
                              dropdownMaxHeight: 180,
                              itemHeight: 36,
                              itemPadding: const EdgeInsets.only(left: 16, right: 16),
                              dropdownPadding: const EdgeInsets.symmetric(vertical: 6),
                              dropdownDecoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(6),
                              ),
                              onChanged: (value) {
                                setState(() {
                                  _selectedpagerows = value;
                                  _currentPage = 1;
                                  _query();
                                });
                              }),
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}
