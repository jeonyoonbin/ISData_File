import 'dart:async';
import 'dart:convert';
import 'dart:html';

import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_text_box.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_date.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_input.dart';
import 'package:daeguro_admin_app/Model/calc/calculateChargeGbnModel.dart';
import 'package:daeguro_admin_app/Model/calc/calculateShopListModel.dart';
import 'package:daeguro_admin_app/Model/calc/calculateShopMileageModel.dart';
import 'package:daeguro_admin_app/Model/calc/callCenter_code_name.dart';
import 'package:daeguro_admin_app/Model/search_items.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/AgentManager/agentAccount_Controller.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculateShopPurchase.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculate_controller.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderDetail.dart';
import 'package:daeguro_admin_app/View/OrderManager/orderManager_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:daeguro_admin_app/constants/serverInfo.dart';

import 'package:date_format/date_format.dart';
import 'package:dropdown_button2/dropdown_button2.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class CalculateShopMileageV2 extends StatefulWidget {
  final String shopName;

  const CalculateShopMileageV2({Key key, this.shopName}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CalculateShopMileageV2State();
  }
}

class CalculateShopMileageV2State extends State<CalculateShopMileageV2> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  bool excelEnable = true;

  List<SelectOptionVO> chargeGbnList = [];
  List<SelectOptionVO> callCenterList = [];

  List<calculateShopMileageModel> dataList = <calculateShopMileageModel>[];
  List<calculateShopListModel> shopList = <calculateShopListModel>[];

  SearchItems _searchItems = new SearchItems();

  var weight;
  String _testYn = ' ';
  String _tradYn = ' ';
  String _chargeGbn = '%';
  String _serviceGbn = ' ';
  String _ccCode = ' ';
  String _divKey = '2';
  String _shopCd = '';
  String _keyWordLabel = '가맹점명';

  // 데이터 테이블 수시로 변경시켜줘야 되기 때문에 사용
  RxBool _searchGbn = false.obs;
  RxDouble _listWidth = 284.0.obs;

  //페이지정보
  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  List MCodeListItems = [];

  String _mCode = '2';

  //잔액
  int _sumPreAmt = 0;

  //기간별 입,출,잔액
  int _sumInAmt = 0;
  int _sumOutAmt = 0;
  int _sumPreAmtIn = 0;

  final ScrollController _scrollController = ScrollController();

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    _searchItems = null;
    _searchItems = new SearchItems();

    _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    _searchItems.memo = '';
    _searchItems.name = '';
  }

  _sum() async {
    await ISProgressDialog(context).show(status: 'Loading...');

    CalculateController.to.startDate.value = _searchItems.startdate.replaceAll('-', '');
    CalculateController.to.endDate.value = _searchItems.enddate.replaceAll('-', '');
    CalculateController.to.divKey.value = _divKey;
    CalculateController.to.name.value = _searchItems.name;
    CalculateController.to.memo.value = _searchItems.memo;

    //if (this.mounted) {

    await CalculateController.to.getShopCalculateSumV2(_serviceGbn, _mCode, _ccCode, _shopCd).timeout(const Duration(seconds: 60), onTimeout: () {
      ISAlert(context, 'TimeOut(60초) 초과로 정상 조회되지 않았습니다.');
    }).then((value) async {
      _sumPreAmt = CalculateController.to.sumPreAmt;
      _sumInAmt = CalculateController.to.sumInAmt;
      _sumOutAmt = CalculateController.to.sumOutAmt;
      _sumPreAmtIn = CalculateController.to.sumPreAmtIn;

      setState(() {});
    });
    //}

    await ISProgressDialog(context).dismiss();
  }

  _query() {
    CalculateController.to.startDate.value = _searchItems.startdate.replaceAll('-', '');
    CalculateController.to.endDate.value = _searchItems.enddate.replaceAll('-', '');
    CalculateController.to.page.value = _currentPage.round().toString();
    CalculateController.to.rows.value = _selectedpagerows.toString();
    CalculateController.to.divKey.value = _divKey;
    CalculateController.to.name.value = _searchItems.name;
    CalculateController.to.memo.value = _searchItems.memo;
    loadData();
  }

  loadData() async {
    await ISProgressDialog(context).show(status: 'Loading...');

    //MCodeListItems.clear();
    dataList.clear();

    CalculateController.to.all_amt = 0.obs;
    CalculateController.to.take_amt = 0.obs;
    CalculateController.to.remain_amt = 0.obs;

    CalculateController.to.all_amt_sum = 0.obs;
    CalculateController.to.p_amt_sum = 0.obs;
    CalculateController.to.k_amt_sum = 0.obs;
    CalculateController.to.take_count_sum = 0.obs;
    CalculateController.to.take_amt_sum = 0.obs;
    CalculateController.to.remain_amt_sum = 0.obs;

    // await AgentController.to.getDataMCodeItems();
    // MCodeListItems = AgentController.to.qDataMCodeItems;

    await CalculateController.to.getDataV2(_serviceGbn, _tradYn, _chargeGbn, _mCode, _ccCode, _testYn, _shopCd).then((value) {
      //if (this.mounted) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        dataList.clear();

        value.forEach((element) {
          calculateShopMileageModel temp = calculateShopMileageModel(); //.fromJson(e);

          temp.RNUM = element['RNUM'] as int;
          temp.SEQNO = element['SEQNO'] as int;
          temp.MCODE = element['MCODE'] as int;
          temp.CCCODE = element['CCCODE'] as String;
          temp.CCNAME = element['CCNAME'] as String;
          temp.SERVICE_GBN = element['SERVICE_GBN'] as String;
          temp.SHOP_CD = element['SHOP_CD'] as String;
          temp.SHOP_NAME = element['SHOP_NAME'] as String;
          temp.ORDER_DATE = element['ORDER_DATE'] as String;
          temp.CHARGE_DATE = element['CHARGE_DATE'] as String;
          temp.CHARGE_GBN = element['CHARGE_GBN'] as String;
          temp.IO_GBN = element['IO_GBN'] as String;
          temp.CHARGE_AMT = element['CHARGE_AMT'] as int;
          temp.IN_AMT = element['IN_AMT'] as int;
          temp.OUT_AMT = element['OUT_AMT'] as int;
          temp.CHARGE_UCODE = element['CHARGE_UCODE'] as int;
          temp.MEMO = element['MEMO'] as String;
          temp.ORDER_NO = element['ORDER_NO'] as int;
          temp.PRE_AMT = element['PRE_AMT'] as int;
          temp.CHARGE_NAME = element['CHARGE_NAME'] as String;
          temp.CHARGE_GBN_NM = element['CHARGE_GBN_NM'] as String;

          //if (temp.chargeDate != null) temp.chargeDate = temp.chargeDate.replaceAll('T', '  ');

          dataList.add(temp);
        });

        _totalRowCnt = CalculateController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
        _sumPreAmt = CalculateController.to.sumPreAmt;
        _sumInAmt = CalculateController.to.sumInAmt;
        _sumOutAmt = CalculateController.to.sumOutAmt;
        _sumPreAmtIn = CalculateController.to.sumPreAmtIn;

        setState(() {});
      }
      //}
    });
    await ISProgressDialog(context).dismiss();
  }

  loadShopData() async {
    //MCodeListItems.clear();
    shopList.clear();

    // await AgentController.to.getDataMCodeItems();
    // MCodeListItems = AgentController.to.qDataMCodeItems;

    await CalculateController.to.getShopListData(_mCode, _serviceGbn, _ccCode, _searchItems.name).then((value) {
      //if (this.mounted) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        shopList.clear();

        value.forEach((element) {
          calculateShopListModel temp = calculateShopListModel(); //.fromJson(e);

          temp.RNUM = element['RNUM'] as int;
          temp.mcode = element['mcode'] as int;
          temp.cccode = element['cccode'] as String;
          temp.shop_cd = element['shop_cd'] as String;
          temp.shop_name = element['shop_name'] as String;
          temp.remain_amt = element['remain_amt'] as int;

          shopList.add(temp);
        });

        setState(() {});
      }
      //}
    });
  }

  loadChargeGbnListData() async {
    chargeGbnList.clear();

    await CalculateController.to.getChargeGbnItems().then((value) {
      if (value == null) {
        ISAlert(context, '콜센터정보를 가져오지 못했습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((element) {
          CalculateChargeGbnModel tempData = CalculateChargeGbnModel.fromJson(element);
          chargeGbnList.add(new SelectOptionVO(value: tempData.charge_gbn, label: tempData.charge_name, label2: tempData.charge_name));
        });

        setState(() {});
      }
    });

    // if (this.mounted) {
    //   setState(() {
    //
    //   });
    // }
  }

  loadCallCenterListData() async {
    callCenterList.clear();

    await AgentController.to.getDataCCenterItems(_mCode).then((value) {
      if (value == null) {
        ISAlert(context, '콜센터정보를 가져오지 못했습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        callCenterList.add(new SelectOptionVO(value: ' ', label: '전체', label2: ''));
        value.forEach((element) {
          CallCenterCodeName tempData = CallCenterCodeName.fromJson(element);
          callCenterList.add(new SelectOptionVO(value: tempData.ccCode, label: '[' + tempData.ccCode + ']' + tempData.ccName, label2: tempData.ccName));
        });

        setState(() {});
      }
    });

    // if (this.mounted) {
    //   setState(() {
    //
    //   });
    // }
  }

  @override
  void initState() {
    super.initState();

    Get.put(AgentController());
    Get.put(CalculateController());
    Get.put(OrderController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      loadChargeGbnListData();
      loadCallCenterListData();
      MCodeListItems = Utils.getMCodeList();
      //_query();
    });

    setState(() {
      _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
      _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    });
  }

  @override
  void dispose() {
    if (dataList != null) {
      dataList.clear();
      dataList = null;
    }
    //MCodeListItems.clear();

    if (_scrollController != null) _scrollController.dispose();

    // 가맹점 적립금 관리 합계(신규)
    CalculateController.to.all_amt = 0.obs;
    CalculateController.to.take_amt = 0.obs;
    CalculateController.to.remain_amt = 0.obs;
    CalculateController.to.all_amt_sum = 0.obs;
    CalculateController.to.in_amt_sum = 0.obs;
    CalculateController.to.p_amt_sum = 0.obs;
    CalculateController.to.k_amt_sum = 0.obs;
    CalculateController.to.take_count_sum = 0.obs;
    CalculateController.to.take_amt_sum = 0.obs;
    CalculateController.to.remain_amt_sum = 0.obs;

    // 주문번호별 정산금액 조회 SUM_COUNT
    CalculateController.to.count = 0.obs;
    CalculateController.to.comp = 0.obs;
    CalculateController.to.canc = 0.obs;
    CalculateController.to.sum_menu_amt = 0.obs;
    CalculateController.to.sum_deli_tip_amt = 0.obs;
    CalculateController.to.sum_tot_amt = 0.obs;
    CalculateController.to.sum_coupon_amt = 0.obs;
    CalculateController.to.sum_mileage_use_amt = 0.obs;
    CalculateController.to.sum_etc_disc_amt = 0.obs;
    CalculateController.to.sum_disc_amt = 0.obs;
    CalculateController.to.sum_amount = 0.obs;
    CalculateController.to.sum_pgm_amt = 0.obs;
    CalculateController.to.sum_pg_pgm_amt = 0.obs;
    CalculateController.to.sum_pgm_sum_amt = 0.obs;

    super.dispose();
  }

  @override
  void deactivate() {
    super.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //_getSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Row(mainAxisAlignment: MainAxisAlignment.end, crossAxisAlignment: CrossAxisAlignment.end, children: [
        Column(
          children: [
            Row(
              children: [
                ISSearchDropdown(
                  label: '주문 구분',
                  width: 130,
                  value: _tradYn,
                  onChange: (value) {
                    setState(() {
                      _tradYn = value;
                    });
                  },
                  item: [
                    DropdownMenuItem(
                      value: ' ',
                      child: Text('전체'),
                    ),
                    DropdownMenuItem(
                      value: 'Y',
                      child: Text('묶음 주문'),
                    ),
                    DropdownMenuItem(
                      value: 'N',
                      child: Text('일반 주문'),
                    ),
                  ].cast<DropdownMenuItem<String>>(),
                ),
                ISSearchDropdown(
                  label: '적립 구분',
                  value: _chargeGbn,
                  width: 190,
                  item: chargeGbnList.map((item) {
                    return new DropdownMenuItem<String>(
                        child: new Text(
                          item.label,
                          style: TextStyle(fontSize: 13, color: Colors.black),
                        ),
                        value: item.value);
                  }).toList(),
                  onChange: (v) {
                    if (EasyLoading.isShow == true) return;
                    chargeGbnList.forEach((element) {
                      if (v == element.value) {
                        _chargeGbn = element.value;
                      }
                    });

                    _currentPage = 1;
                    //_query();
                  },
                ),
              ],
            ),
            SizedBox(
              height: 8,
            ),
            Row(
              children: [
                ISSearchDropdown(
                  label: '서비스 구분',
                  width: 130,
                  value: _serviceGbn,
                  onChange: (value) {
                    setState(() {
                      _serviceGbn = value;
                      _currentPage = 1;
                      //_query();
                    });
                  },
                  item: [
                    DropdownMenuItem(
                      value: ' ',
                      child: Text('전체'),
                    ),
                    DropdownMenuItem(
                      value: '0',
                      child: Text('주문'),
                    ),
                    DropdownMenuItem(
                      value: '1',
                      child: Text('특별관'),
                    ),
                    DropdownMenuItem(
                      value: '2',
                      child: Text('꽃배달'),
                    ),
                    DropdownMenuItem(
                      value: '3',
                      child: Text('로컬푸드'),
                    ),
                    DropdownMenuItem(
                      value: '4',
                      child: Text('전통시장'),
                    ),
                    DropdownMenuItem(
                      value: '5',
                      child: Text('전자관'),
                    ),
                    DropdownMenuItem(
                      value: '6',
                      child: Text('밀키트'),
                    ),
                  ].cast<DropdownMenuItem<String>>(),
                ),
                ISSearchDropdown(
                  label: '콜센터명',
                  value: _ccCode,
                  width: 190,
                  item: callCenterList.map((item) {
                    return new DropdownMenuItem<String>(
                        child: new Text(
                          item.label,
                          style: TextStyle(fontSize: 13, color: Colors.black),
                        ),
                        value: item.value);
                  }).toList(),
                  onChange: (v) {
                    if (EasyLoading.isShow == true) return;
                    callCenterList.forEach((element) {
                      if (v == element.value) {
                        _ccCode = element.value;
                      }
                    });

                    _currentPage = 1;
                    //_query();
                  },
                )
              ],
            ),
          ],
        ),
        Column(
          children: [
            ISSearchDropdown(
              label: '회원사명',
              value: _mCode,
              width: 240,
              item: MCodeListItems.map((item) {
                return new DropdownMenuItem<String>(
                    child: new Text(
                      item['mName'],
                      style: TextStyle(fontSize: 13, color: Colors.black),
                    ),
                    value: item['mCode']);
              }).toList(),
              onChange: (value) {
                if (EasyLoading.isShow == true) return;
                _mCode = value;
                _currentPage = 1;
                //_query();

                // setState(() {});
              },
            ),
            SizedBox(
              height: 8,
            ),
            Row(
              children: [
                ISSearchSelectDate(
                  context,
                  label: '시작일',
                  width: 120,
                  value: _searchItems.startdate.toString(),
                  onTap: () async {
                    DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.startdate);
                    final DateTime picked = await showDatePicker(
                      context: context,
                      initialDate: valueDt,
                      firstDate: DateTime(1900, 1),
                      lastDate: DateTime(2031, 12),
                    );

                    setState(() {
                      if (picked != null) {
                        _searchItems.startdate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                      }
                    });
                  },
                ),
                ISSearchSelectDate(
                  context,
                  label: '종료일',
                  width: 120,
                  value: _searchItems.enddate.toString(),
                  onTap: () async {
                    DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.enddate);
                    final DateTime picked = await showDatePicker(
                      context: context,
                      initialDate: valueDt,
                      firstDate: DateTime(1900, 1),
                      lastDate: DateTime(2031, 12),
                    );

                    setState(() {
                      if (picked != null) {
                        _searchItems.enddate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                      }
                    });
                  },
                ),
              ],
            )
          ],
        ),
        Column(
          children: [
            Row(
              children: [
                ISSearchDropdown(
                  label: '테스트 여부',
                  width: 130,
                  value: _testYn,
                  onChange: (value) {
                    setState(() {
                      _testYn = value;
                    });
                  },
                  item: [
                    DropdownMenuItem(
                      value: ' ',
                      child: Text('전체'),
                    ),
                    DropdownMenuItem(
                      value: 'Y',
                      child: Text('테스트건 조회'),
                    ),
                    DropdownMenuItem(
                      value: 'N',
                      child: Text('테스트건 제외'),
                    ),
                  ].cast<DropdownMenuItem<String>>(),
                ),
                Container(
                  child: Stack(
                    alignment: Alignment.centerRight,
                    children: [
                      ISSearchInput(
                        label: '메모',
                        width: 264,
                        value: _searchItems.memo,
                        onChange: (v) {
                          _searchItems.memo = v;
                        },
                        onFieldSubmitted: (v) {
                          _currentPage = 1;
                          _query();
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 8,
            ),
            Row(
              children: [
                ISSearchDropdown(
                  label: '검색조건',
                  width: 130,
                  value: _divKey,
                  onChange: (value) {
                    setState(() {
                      _divKey = value;

                      if (value == '2') {
                        if (_searchItems.name.toString() != '') {
                          _searchGbn.value = true;
                          _listWidth.value = 694.0;
                        } else {
                          _searchGbn.value = false;
                          _listWidth.value = 284.0;
                        }

                        _keyWordLabel = '가맹점명';
                      } else if (value == '1') {
                        _searchGbn.value = false;
                        _listWidth.value = 284.0;

                        _keyWordLabel = '주문번호';
                      }
                      // else if (value == '0') {
                      //   _keyWordLabel = '주문번호';
                      // }
                      //_query();
                    });
                  },
                  item: [
                    DropdownMenuItem(
                      value: '2',
                      child: Text('가맹점명'),
                    ),
                    DropdownMenuItem(
                      value: '1',
                      child: Text('주문번호'),
                    ),
                    //DropdownMenuItem(value: '0', child: Text('주문번호'),),
                  ].cast<DropdownMenuItem<String>>(),
                ),
                Container(
                  child: Stack(
                    alignment: Alignment.centerRight,
                    children: [
                      ISSearchInput(
                        label: _keyWordLabel,
                        width: 180,
                        value: _searchItems.name,
                        onChange: (v) {
                          _searchItems.name = v;
                        },
                        onFieldSubmitted: (v) {
                          _shopCd = '';

                          if (_divKey == '2' && _searchItems.name.toString() != '') {
                            loadShopData();
                            _searchGbn.value = true;
                            _listWidth.value = 694.0;
                          } else {
                            _searchGbn.value = false;
                            _listWidth.value = 284.0;
                          }

                          _currentPage = 1;
                          _query();
                        },
                      ),
                    ],
                  ),
                ),
                ISSearchButton(
                    width: 80,
                    label: '조회',
                    tip: '가맹점명으로 조회할 경우 좌측 조회된 가맹점에서 선택 바랍니다.',
                    iconData: Icons.search,
                    onPressed: () {
                      _shopCd = '';

                      if (_divKey == '2' && _searchItems.name.toString() != '') {
                        loadShopData();
                        _searchGbn.value = true;
                        _listWidth.value = 694.0;
                      } else {
                        _searchGbn.value = false;
                        _listWidth.value = 284.0;
                      }

                      _currentPage = 1;

                      _query();
                    }),
                SizedBox(
                  width: 4,
                )
              ],
            )
          ],
        ),
      ]),
    );

    Container bar = Container(
      color: Colors.blue[50],
      width: 1640,
      height: 74,
      child: ListView(
        controller: _scrollController,
        physics: ClampingScrollPhysics(),
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        children: [
          Container(
            alignment: Alignment.topCenter,
            margin: EdgeInsets.all(5),
            child: ISButton(
                label: '합 계\n조 회',
                height: 56,
                iconData: Icons.autorenew,
                iconColor: Colors.white,
                textStyle: TextStyle(color: Colors.white),
                onPressed: () => {
                      if (EasyLoading.isShow != true) {_currentPage = 1, _sum()}
                    }),
          ),
          Container(
            //color: Colors.blue[50],
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: <Widget>[
                    Container(padding: EdgeInsets.only(left: 10), child: Text('전체기간 합계', style: TextStyle(color: Colors.lightBlue, fontWeight: FONT_BOLD))),
                    Container(width: 245, child: ISTextBox(label: '총 적립금', width: 140, value: CalculateController.to.all_amt.toString())),
                    Container(width: 245, child: ISTextBox(label: '총 출금액', width: 140, value: CalculateController.to.take_amt.toString())),
                    Container(width: 260, child: ISTextBox(label: '적립금               ', width: 140, value: CalculateController.to.remain_amt_sum.toString())),
                  ],
                ),
                Row(
                  children: <Widget>[
                    Container(padding: EdgeInsets.only(left: 10), child: Text('검색기준 합계', style: TextStyle(color: Colors.lightBlue, fontWeight: FONT_BOLD))),
                    Container(width: 245, child: ISTextBox(label: '총 적립금', width: 140, value: CalculateController.to.all_amt_sum.toString())),
                    Container(width: 245, child: ISTextBox(label: '중개수수료', width: 140, value: CalculateController.to.p_amt_sum.toString())),
                    Container(width: 260, child: ISTextBox(label: 'PG수수료 합계', width: 140, value: CalculateController.to.k_amt_sum.toString())),
                    Container(width: 245, child: ISTextBox(label: '출금횟수', width: 140, value: CalculateController.to.take_count_sum.toString())),
                    Container(width: 245, child: ISTextBox(label: '출금액', width: 140, value: CalculateController.to.take_amt_sum.toString())),
                    //Container(width: 245, child: ISTextBox(label: '적립금', width: 140, value: CalculateController.to.remain_amt_sum.toString())),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );

    return Container(
      //padding: EdgeInsets.only(left: 50, right: 50, bottom: 0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          form,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [Text('※ 정산일자 기준, 배달완료 데이터로 조회 됩니다.', style: TextStyle(color: Colors.blue[400], fontSize: 12)), buttonBar],
          ),
          Divider(),
          Scrollbar(isAlwaysShown: true, controller: _scrollController, child: bar),
          // bar2,
          // bar3,
          Divider(),
          Row(
            children: [
              Obx(() => _searchGbn == true
                  ? Container(
                      height: (MediaQuery.of(context).size.height - defaultContentsHeight) - 138,
                      width: 400,
                      margin: EdgeInsets.only(right: 10),
                      child: ISDatatable(
                        listWidth: 400,
                        rows: shopList.map((item) {
                          if (item.shop_cd != null) {
                            weight = FONT_NORMAL;
                          } else {
                            weight = FONT_NORMAL;
                          }
                          return DataRow(cells: [
                            DataCell(Container(child: SelectableText('[' + item.shop_cd.toString() + '] ' + item.shop_name.toString(), showCursor: true), alignment: Alignment.centerLeft)),
                            if (AuthUtil.isAuthEditEnabled('18') == true)
                              DataCell(
                                item.shop_name.toString() == 'null'
                                    ? SizedBox.shrink()
                                    : Center(
                                    child: IconButton(
                                      onPressed: () {
                                        showDialog(
                                          context: context,
                                          builder: (BuildContext context) => Dialog(
                                            child: CalculateShopPurchase(mCode: item.mcode.toString(), ccCode: item.cccode.toString(), shopCd: item.shop_cd),
                                          ),
                                        ).then((v) async {
                                          if (v != null) {
                                            await Future.delayed(Duration(milliseconds: 500), () {
                                              loadData();
                                            });
                                          }
                                        });
                                      },
                                      icon: Icon(Icons.monetization_on),
                                      tooltip: '사입처리',
                                    )),
                              ),
                            DataCell(Container(child: SelectableText(Utils.getCashComma(item.remain_amt.toString()), showCursor: true), alignment: Alignment.centerRight)),
                          ], onSelectChanged: (v){
                            _shopCd = item.shop_cd.toString();
                            _currentPage = 1;

                            _query();
                          });
                        }).toList(),
                        columns: <DataColumn>[
                          //DataColumn(label: Expanded(child: Text('상점번호', textAlign: TextAlign.center)),),
                          DataColumn(
                            label: Container(child: Text('코드/상점명', textAlign: TextAlign.center), width: 150),
                          ),
                          if (AuthUtil.isAuthEditEnabled('18') == true)
                            DataColumn(
                              label: Expanded(child: Text('사입', textAlign: TextAlign.center)),
                            ),
                          DataColumn(
                            label: Container(child: Text('잔액', textAlign: TextAlign.center), width: 50),
                          ),
                        ],
                      ),
                      alignment: Alignment.center,
                    )
                  : SizedBox.shrink()),
              ISDatatable(
                panelHeight: (MediaQuery.of(context).size.height - defaultContentsHeight) - 138,
                listWidth: MediaQuery.of(context).size.width - _listWidth.value,
                rows: dataList.map((item) {
                  if (item.SHOP_CD != null) {
                    weight = FONT_NORMAL;
                  } else {
                    weight = FONT_NORMAL;
                  }
                  return DataRow(cells: [
                    //DataCell(Center(child: SelectableText(item.shopCd ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                    DataCell(Align(
                      child: SelectableText(item.SHOP_NAME.toString() == 'null' ? '' : '[' + item.SHOP_CD.toString() + '] ' + item.SHOP_NAME.toString(), showCursor: true),
                      alignment: Alignment.centerLeft,
                    )),
                    DataCell(Align(child: SelectableText(item.SHOP_NAME.toString() == 'null' ? '' : Utils.getYearMonthDayFormat(item.ORDER_DATE.toString().replaceAll('T', ' ')) ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true), alignment: Alignment.center)),
                    DataCell(Align(child: SelectableText(item.SHOP_NAME.toString() == 'null' ? '' : item.CHARGE_DATE.toString().replaceAll('T', ' ') ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true), alignment: Alignment.centerRight)),
                    DataCell(Align(child: SelectableText(item.SHOP_NAME.toString() == 'null' ? '' : item.CHARGE_GBN_NM.toString() ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true), alignment: Alignment.center)),
                    DataCell(Align(child: SelectableText(Utils.getCashComma(item.IN_AMT.toString()) ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true), alignment: Alignment.centerRight)),
                    DataCell(Align(child: SelectableText(Utils.getCashComma(item.OUT_AMT.toString()) ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true), alignment: Alignment.centerRight)),
                    DataCell(Align(child: SelectableText(Utils.getCashComma(item.PRE_AMT.toString()) ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true), alignment: Alignment.centerRight)),
                    DataCell(Align(child: SelectableText(item.SHOP_NAME.toString() == 'null' ? '' : item.CHARGE_NAME.toString() ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true), alignment: Alignment.center)),
                    // if (AuthUtil.isAuthEditEnabled('18') == true)
                    //   DataCell(
                    //     item.SHOP_NAME.toString() == 'null'
                    //         ? SizedBox.shrink()
                    //         : Center(
                    //             child: IconButton(
                    //             onPressed: () {
                    //               showDialog(
                    //                 context: context,
                    //                 builder: (BuildContext context) => Dialog(
                    //                   child: CalculateShopPurchase(sData: item),
                    //                 ),
                    //               ).then((v) async {
                    //                 if (v != null) {
                    //                   await Future.delayed(Duration(milliseconds: 500), () {
                    //                     loadData();
                    //                   });
                    //                 }
                    //               });
                    //             },
                    //             icon: Icon(Icons.monetization_on),
                    //             tooltip: '사입처리',
                    //           )),
                    //   ),
                    DataCell(Align(child: SelectableText(item.SHOP_NAME.toString() == 'null' ? '' : item.MEMO.toString() ?? '--', style: TextStyle(color: Colors.black, fontWeight: weight), showCursor: true), alignment: Alignment.centerLeft)),
                  ], color: item.SHOP_NAME.toString() == 'null' ? MaterialStateProperty.all(Colors.grey[200]) : MaterialStateProperty.all(Colors.white));
                }).toList(),
                columns: <DataColumn>[
                  //DataColumn(label: Expanded(child: Text('상점번호', textAlign: TextAlign.center)),),
                  DataColumn(
                    label: Expanded(child: Text('코드/상점명', textAlign: TextAlign.center)),
                  ),
                  DataColumn(
                    label: Expanded(child: Text('영업일자', textAlign: TextAlign.center)),
                  ),
                  DataColumn(
                    label: Expanded(child: Text('적립시간', textAlign: TextAlign.center)),
                  ),
                  DataColumn(
                    label: Expanded(child: Text('적립구분', textAlign: TextAlign.right, style: TextStyle(fontSize: 12))),
                  ),
                  DataColumn(
                    label: Expanded(child: Text('입금', textAlign: TextAlign.right, style: TextStyle(fontSize: 12))),
                  ),
                  DataColumn(
                    label: Expanded(child: Text('출금', textAlign: TextAlign.right, style: TextStyle(fontSize: 12))),
                  ),
                  DataColumn(
                    label: Expanded(child: Text('잔액', textAlign: TextAlign.right, style: TextStyle(fontSize: 12))),
                  ),
                  DataColumn(
                    label: Expanded(child: Text('작업자', textAlign: TextAlign.center)),
                  ),
                  // if (AuthUtil.isAuthEditEnabled('18') == true)
                  //   DataColumn(
                  //     label: Expanded(child: Text('사입', textAlign: TextAlign.center)),
                  //   ),
                  DataColumn(
                    label: Expanded(child: Text('메모', textAlign: TextAlign.left)),
                  ),
                ],
              )
            ],
          ),
          Divider(),
          SizedBox(
            height: 0,
          ),
          showPagerBar(),
        ],
      ),
    );
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                AuthUtil.isAuthDownloadEnabled('12') == true
                    ? ISButton(
                        height: 24,
                        label: 'Excel저장',
                        iconColor: Colors.white,
                        iconData: Icons.reply,
                        textStyle: TextStyle(color: Colors.white, fontSize: 12),
                        onPressed: () {
                          ExcelDownload();
                        })
                    : Container(),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FONT_BOLD), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context)
                ? Container(height: 48)
                : Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      Text(
                        '조회 데이터 : ',
                        style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL),
                      ),
                      Text(
                        CalculateController.to.totalRowCnt.toString() + ' 건',
                        style: TextStyle(fontSize: 12, fontWeight: FONT_BOLD),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      Text(
                        '페이지당 행 수 : ',
                        style: TextStyle(fontSize: 12, fontWeight: FONT_NORMAL),
                      ),
                      Container(
                        width: 70,
                        height: 24,
                        decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(5.0)),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton2(
                              value: _selectedpagerows,
                              isExpanded: true,
                              style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: FONT_FAMILY),
                              items: Utils.getPageRowList(),
                              dropdownMaxHeight: 180,
                              itemHeight: 36,
                              itemPadding: const EdgeInsets.only(left: 16, right: 16),
                              dropdownPadding: const EdgeInsets.symmetric(vertical: 6),
                              dropdownDecoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(6),
                              ),
                              onChanged: (value) {
                                setState(() {
                                  _selectedpagerows = value;
                                  _currentPage = 1;
                                  _query();
                                });
                              }),
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  void ExcelDownload() async {
    CalculateController.to.startDate.value = _searchItems.startdate.replaceAll('-', '');
    CalculateController.to.endDate.value = _searchItems.enddate.replaceAll('-', '');
    CalculateController.to.divKey.value = _divKey;
    CalculateController.to.name.value = _searchItems.name;
    CalculateController.to.memo.value = _searchItems.memo;

    await ISProgressDialog(context).show(status: 'download...');
    String url = ServerInfo.REST_URL_CALCULATE_SHOPMILEAGE_EXCEL_V2 +
        '?service_gbn=$_serviceGbn&trad_yn=$_tradYn&charge_gbn=$_chargeGbn&mcode=$_mCode&cccode=$_ccCode&test_yn=$_testYn&shop_cd=$_shopCd&date_begin=${CalculateController.to.startDate.value}&date_end=${CalculateController.to.endDate.value}&div=${CalculateController.to.divKey.value}&keyword=${CalculateController.to.name.value}';

    await http.get(url).then((http.Response response) {
      var bytes = response.bodyBytes;

      DateTime now = DateTime.now();
      DateTime date = DateTime(now.year, now.month, now.day);

      AnchorElement(href: 'data:application/octet-stream;charset=utf-16le;base64,${base64.encode(bytes)}')
        ..setAttribute('download', '가맹점 적립금 관리_' + formatDate(date, [yy, mm, dd]) + '.xlsx')
        ..click();
    });

    setState(() {});

    await ISProgressDialog(context).dismiss();
  }
}
