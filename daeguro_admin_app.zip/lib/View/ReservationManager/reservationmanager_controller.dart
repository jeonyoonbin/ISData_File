import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/Model/shop/shop_changepass.dart';
import 'package:daeguro_admin_app/Network/DioClient.dart';
import 'package:daeguro_admin_app/Network/DioClientPos.dart';
import 'package:daeguro_admin_app/Network/DioClientReserve.dart';

import 'package:daeguro_admin_app/constants/serverInfo.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ReservationController extends GetxController with SingleGetTickerProviderMixin {
  static ReservationController get to => Get.find();

  int totalRowCnt = 0;
  RxString raw = ''.obs;
  RxString page = ''.obs;

  int reserTotalCnt = 0;
  int reserStatus10 = 0;
  int reserStatus12 = 0;
  int reserStatus30 = 0;
  int reserStatus40 = 0;
  int reserStatus90 = 0;

  @override
  void onInit() {
    raw.value = '15';
    page.value = '1';

    super.onInit();
  }

  Future<List<dynamic>> getReserveMainThemeList() async {
    List<dynamic> itemsList = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/tema');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      itemsList.assignAll(response.data['data']);
    else
      return null;

    return itemsList;
  }

  Future<dynamic> getReserveMainThemeDetail(String temaCode) async {
    dynamic qData;

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/temaDetail?temaCode=${temaCode}');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      qData = response.data['data'][0];
    else
      return null;

    return qData;
  }

  Future<List<dynamic>> getReserveSubThemeList(String code) async {
    List<dynamic> itemsList = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/subTema?temaCode=${code}');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      itemsList.assignAll(response.data['data']);
    else
      return null;

    return itemsList;
  }

  Future<List<dynamic>> getReserveThemeShopList(String jobGbn, String temaCode, int subTemaCode, String keyword) async {
    List<dynamic> itemsList = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/temaShopList?jobGbn=${jobGbn}&temaCode=${temaCode}&subTemaCode=${subTemaCode}&searchInfo=${keyword}&page=${page.value}&rows=${raw.value}');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00') {
      totalRowCnt = int.parse(response.data['count'].toString());

      itemsList.assignAll(response.data['data']);
    }
    else
      return null;

    return itemsList;
  }

  Future<List<dynamic>> getReserveThemeShopEnableList(String jobGbn, String temaCode, int subTemaCode, String keyword) async {
    List<dynamic> itemsList = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/temaEnable?jobGbn=${jobGbn}&temaCode=${temaCode}&subTemaCode=${subTemaCode}&searchInfo=${keyword}&page=${page.value}&rows=${raw.value}');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00') {
      totalRowCnt = int.parse(response.data['count'].toString());

      itemsList.assignAll(response.data['data']);
    }
    else
      return null;

    return itemsList;
  }

  Future<dynamic> getReserveSubThemeDetail(String code, int subCode) async {
    dynamic qData;

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/subTemaDetail?temaCode=${code}&subTemaCode=${subCode}');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      qData = response.data['data'][0];
    else
      return null;

    return qData;
  }

  Future<dynamic> postMainTheme(String temaName) async {
    try{
      String uID = GetStorage().read('logininfo')['uCode'];

      final response = await DioClientReserve().post(ServerInfo.REST_RESERVEURL+'/tema?temaName=${temaName}&userId=${uID}');

      if (response.data['code'] != '00') {
        return response.data['msg'];
      }
      else
        return null;

    } catch (e){
      print('postMainTheme e:${e.toString()}');

      return e.toString();
    }
  }

  Future<dynamic> deleteMainTheme(String temaCode) async {
    try{
      final response = await DioClientReserve().delete(ServerInfo.REST_RESERVEURL+'/tema?temaCode=${temaCode}');

      if (response.data['code'] != '00') {
        return response.data['msg'];
      }
      else
        return null;

    } catch (e){
      print('deleteMainTheme e:${e.toString()}');

      return e.toString();
    }
  }

  Future<dynamic> deleteSubTheme(String temaCode, int subTemaCode) async {
    try{
      final response = await DioClientReserve().delete(ServerInfo.REST_RESERVEURL+'/subTema?subTemaCode=${subTemaCode}&temaCode=${temaCode}');

      if (response.data['code'] != '00') {
        return response.data['msg'];
      }
      else
        return null;

    } catch (e){
      print('deleteSubTheme e:${e.toString()}');

      return e.toString();
    }
  }

  Future<dynamic> postSubTheme(String temaCode, String temaName) async {
    try{
      String uID = GetStorage().read('logininfo')['uCode'];

      final response = await DioClientReserve().post(ServerInfo.REST_RESERVEURL+'/subTema?temaCode=${temaCode}&temaName=${temaName}&userId=${uID}');

      if (response.data['code'] != '00') {
        return response.data['msg'];
      }
      else
        return null;

    } catch (e){
      print('postSubTheme e:${e.toString()}');

      return e.toString();
    }
  }

  Future<dynamic> putReserMainTheme(String temaCode, dynamic bodyData, BuildContext context) async {
    try{
      String uID = GetStorage().read('logininfo')['uCode'];
      //print('putReserMainTheme bodyData:${bodyData.toString()}');
      final response = await DioClientReserve().put(ServerInfo.REST_RESERVEURL+'/tema?temaCode=${temaCode}&userId=${uID}', data: bodyData);

      if (response.data['code'] != '00') {
        ISAlert(context, '정상적으로 저장 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else
        return null;

    }catch (e){
      print('putReserMainTheme e:${e.toString()}');
    }
  }

  Future<dynamic> putReserSubTheme(String temaCode, int subTemaCoe, dynamic bodyData, BuildContext context) async {
    try{
      String uID = GetStorage().read('logininfo')['uCode'];
      //print('bodyData:${bodyData.toString()}');
      final response = await DioClientReserve().put(ServerInfo.REST_RESERVEURL+'/subTema?subTemaCode=${subTemaCoe}&temaCode=${temaCode}&userId=${uID}', data: bodyData);

      if (response.data['code'] != '00') {
        ISAlert(context, '정상적으로 저장 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else
        return null;

    }catch (e){
      print('putReserSubTheme e:${e.toString()}');
    }
  }

  Future<dynamic> putReserThemeShopConfirm(String jobGbn, String temaCode, int subTemaCode, String shopCd, BuildContext context) async {
    try{
      String uID = GetStorage().read('logininfo')['uCode'];
      //print('bodyData:/temaUpdate?jobGbn=${jobGbn}&temaCode=${temaCode}&subTemaCode=${subTemaCode}&shopCd=${shopCd}');
      final response = await DioClientReserve().put(ServerInfo.REST_RESERVEURL+'/temaUpdate?jobGbn=${jobGbn}&temaCode=${temaCode}&subTemaCode=${subTemaCode}&shopCd=${shopCd}&userId=${uID}');

      if (response.data['code'] != '00') {
        ISAlert(context, '정상적으로 저장 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else
        return null;

    }catch (e){
      print('putReserThemeShopConfirm e:${e.toString()}');
    }
  }

  Future<dynamic> setReserveShopInfoadmin(dynamic bodyData) async {
    try{
      final response = await DioClientReserve().post(ServerInfo.REST_RESERVEURL+'/shopInfo-admin', data: bodyData.toString());

      if (response.data['code'] != '00') {
        return response.data['msg'];
      }
      else
        return null;

    } catch (e){
      print('setReserveShopInfoadmin e:${e.toString()}');

      return e.toString();
    }
  }

  Future<List<dynamic>> getReserItems() async {
    List<dynamic> itemsList = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/items');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      itemsList = response.data['data'];
    else
      return null;

    return itemsList;
  }

  Future<dynamic> getReserShopInfo(String shopCode) async {
    dynamic qData;

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/shopInfo?shopCd=$shopCode');//'https://reser.daeguro.co.kr:10008/shopInfo?shopCd=$shopCode');

    if (response.data['code'] == '00') {
        qData = response.data['data'];
    }
    else
      return null;

    return qData;
  }

  Future<List<dynamic>> getReserShopThemeInfo(String shopCode) async {
    List<dynamic> qThemeData = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/subTemaShop?shopCd=$shopCode');

    if (response.data['code'] == '00') {
      qThemeData.assignAll(response.data['data']);
    }
    else
      return null;

    return qThemeData;
  }

  // Future<dynamic> setReserShopThemeInfo(dynamic bodyData, BuildContext context) async {
  //   try{
  //     //print('bodyData:${bodyData.toString()}');
  //     final response = await DioClientReserve().put(ServerInfo.REST_RESERVEURL+'/shopInfo-tema', data: bodyData.toString());//'https://reser.daeguro.co.kr:10008/shopInfo?shopCd=$shopCode');
  //
  //     if (response.data['code'] != '00') {
  //       ISAlert(context, '정상적으로 저장 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
  //     }
  //     else
  //       return null;
  //
  //   }catch (e){
  //     print('setReserShopThemeInfo e:${e.toString()}');
  //   }
  // }


  Future<List<dynamic>> getReserListData(String shopCd, String dateBegin, String dateEnd, String status, String jobGbn, String searchInfo, String page, String pageRows) async {
    List<dynamic> qData = [];

    final result = await DioClientReserve().get(ServerInfo.REST_RESERVEURL + '/reser-list'+
            '/$status?shopCd=$shopCd&dateBegin=$dateBegin&dateEnd=$dateEnd&jobGbn=$jobGbn&searchInfo=$searchInfo&page=$page&pageRows=$pageRows');

    totalRowCnt = int.parse(result.data['totalCnt'].toString());

    reserTotalCnt = result.data['totalCnt'];
    reserStatus10 = result.data['statuS10'];
    reserStatus12 = result.data['statuS12'];
    reserStatus30 = result.data['statuS30'];
    reserStatus40 = result.data['statuS40'];
    reserStatus90 = result.data['statuS90'];

    if (result.data['code'] == '00') {
      qData.assignAll(result.data['data']);
    } else
      return null;

    return qData;
  }

  Future<List<dynamic>> getShopReserveImage(String shopCode, String imageType, BuildContext context) async {
    List<dynamic> shopInfoImageList = [];

    shopInfoImageList.clear();

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL +'/shopPicture/${shopCode}?temaCode=${imageType}&page=1&pageRows=9999');

    if (response.data['code'] != '00') {
      ISAlert(context, '정상적으로 조회 되지 않았습니다. \n\n- [${response.data['code']}] ${response.data['msg']}');
    }
    else{
      totalRowCnt = int.parse(response.data['data']['count'].toString());

      shopInfoImageList.assignAll(response.data['data']['items']);
    }

    return shopInfoImageList;
  }

  deleteShopInfoImage(String ccCode, String shopCd, int seq, BuildContext context) async {
    final response = await DioClientReserve().deleteImage(ServerInfo.REST_RESERVEURL +"/shopPicture/delete", ccCode , shopCd, seq);

    if (response.data['code'] != '00') {
      ISAlert(context, '정상적으로 삭제 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  Future<List<dynamic>> getShopReserveReviewImage(String shopCode) async {
    List<dynamic> qData = [];

    final response = await DioClientReserve().get(ServerInfo.REST_URL_SHOP_RESERVE_REVIEW_IMAGE + '/$shopCode');

    if (response.data['code'] == '00') {
      qData.assignAll(response.data['data']);
    }
    else
      return null;

    return qData;
  }

  deleteShopReserveReviewImage(String ccCode, String shopCd, String seq, BuildContext context) async {
    final response = await DioClientReserve().deleteReviewImage(ServerInfo.REST_URL_SHOP_RESERVE_REVIEW_IMAGE_DELETE, ccCode, shopCd, seq);

    if (response.data['code'] != '00') {
      ISAlert(context, '정상적으로 삭제 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  deleteThemeMainImage(String temaCode, BuildContext context) async {
    final response = await DioClientReserve().delete(ServerInfo.REST_RESERVEURL +'/temaImage/delete?temaCode=${temaCode}');

    if (response.data['code'] != '00') {
      ISAlert(context, '정상적으로 삭제 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  deleteThemeSubImage(String temaCode, int subTemaCode, BuildContext context) async {
    final response = await DioClientReserve().delete(ServerInfo.REST_RESERVEURL +'/subTemaImage/delete?temaCode=${temaCode}&subTemaCode=${subTemaCode}');

    if (response.data['code'] != '00') {
      ISAlert(context, '정상적으로 삭제 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  Future<List<dynamic>> getReserveMainThemeHistoryList(String code) async {
    List<dynamic> itemsList = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/temaHist?temaCode=${code}');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      itemsList.assignAll(response.data['data']);
    else
      return null;

    return itemsList;
  }

  Future<List<dynamic>> getReserveSubThemeHistoryList(String code, int subCode) async {
    List<dynamic> itemsList = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/subTemaHist?temaCode=${code}&subTemaCode=${subCode}');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      itemsList.assignAll(response.data['data']);
    else
      return null;

    return itemsList;
  }

  Future<List<dynamic>> getShopReserveHistoryList(String shopCode) async {
    List<dynamic> itemsList = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/shopTemaHist?shopCode=${shopCode}');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      itemsList.assignAll(response.data['data']);
    else
      return null;

    return itemsList;
  }

  Future<dynamic> getApplyData(String shopCode) async {
    dynamic qData;

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/apply?shopCode=${shopCode}');

    if (response.data['code'] == '00')
      qData = response.data['data'];
    else
      return null;

    return qData;
  }

  Future<List<dynamic>> getShopReserveModifyTimeList(String shopCode, String sbGbn) async {
    List<dynamic> itemsList = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/sbTime/${sbGbn}?shopCd=${shopCode}');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      itemsList.assignAll(response.data['data']);
    else
      return null;

    return itemsList;
  }

  Future<dynamic> postShopReserveModifyTimeList(BuildContext context, dynamic data) async {
    final response = await DioClientReserve().post(ServerInfo.REST_RESERVEURL+'/sbTime', data: data);

    if (response.data['code'] != '00') {
      ISAlert(context, '정상적으로 저장 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
    else
      return '00';
  }

  Future<List<dynamic>> getShopReserveClosedayCodeList() async {
    List<dynamic> itemsList = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/items-list?item=0005');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      itemsList.assignAll(response.data['data']);
    else
      return null;

    return itemsList;
  }

  Future<List<dynamic>> getShopReserveModifyClosedayList(String shopCode, String gbn) async {
    List<dynamic> itemsList = [];

    final response = await DioClientReserve().get(ServerInfo.REST_RESERVEURL+'/dayOff/${shopCode}?gbn=${gbn}');//('https://reser.daeguro.co.kr:10008/items');

    if (response.data['code'] == '00')
      itemsList.assignAll(response.data['data']['list']);
    else
      return null;

    return itemsList;
  }

  Future<dynamic> postShopReserveModifyCloseday(BuildContext context, dynamic data) async {
    final response = await DioClientReserve().post(ServerInfo.REST_RESERVEURL+'/dayOff', data: data);

    if (response.data['code'] != '00') {
      ISAlert(context, '정상적으로 저장 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
    else
      return '00';
  }

  Future<dynamic> deleteShopReserveModifyCloseday(dynamic data) async {
    try{
      final response = await DioClientReserve().delete(ServerInfo.REST_RESERVEURL+'/dayOff', data: data);

      if (response.data['code'] != '00') {
        return response.data['msg'];
      }
      else
        return null;

    } catch (e){
      print('deleteMainTheme e:${e.toString()}');

      return e.toString();
    }
  }
}
