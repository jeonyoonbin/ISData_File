import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveThemeShopListModel.dart';
import 'package:daeguro_admin_app/Model/user/userRegistModel.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/AgentManager/agentAccount_Controller.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reservationmanager_controller.dart';
import 'package:daeguro_admin_app/View/UserManager/user_controller.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ReserveThemShopAdd extends StatefulWidget {
  final String code;
  final int subCode;
  const ReserveThemShopAdd({Key key, this.code, this.subCode}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ReserveThemShopAddState();
  }
}

class ReserveThemShopAddState extends State<ReserveThemShopAdd> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<ReserveThemeShopListModel> dataShopList = <ReserveThemeShopListModel>[];

  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  String _shopJobGbn = '1';
  String _shopSearchKeyword = '';

  List<SelectOptionVO> selectBox_ShopSearchType = [];

  _query() {
    ReservationController.to.page.value = _currentPage.round().toString();
    ReservationController.to.raw.value = _selectedpagerows.toString();

    loadThemeShopEnableList();
  }

  void _pageMove(int _page) {
    _query();
  }

  loadThemeShopEnableList() async {
    dataShopList.clear();

    await ReservationController.to.getReserveThemeShopEnableList(_shopJobGbn,  widget.code, widget.subCode, _shopSearchKeyword).then((value) {
      if(value == null){
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        value.forEach((e) {
          ReserveThemeShopListModel temp = ReserveThemeShopListModel.fromJson(e);
          dataShopList.add(temp);
        });

        int _totalRowCnt = ReservationController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
      }
    });

    setState(() {

    });
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReservationController());

    selectBox_ShopSearchType.add(new SelectOptionVO(value: '1', label: '가맹점명'));
    selectBox_ShopSearchType.add(new SelectOptionVO(value: '2', label: '사업자번호'));
    selectBox_ShopSearchType.add(new SelectOptionVO(value: '3', label: '주소'));

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _query();
    });
  }

  @override
  void dispose() {

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[

        ],
      ),
    );

    // ButtonBar buttonBar = ButtonBar(
    //   alignment: MainAxisAlignment.center,
    //   children: <Widget>[
    //     ISButton(
    //       label: '저장',
    //       iconData: Icons.save,
    //       onPressed: () {
    //         FormState form = formKey.currentState;
    //         if (!form.validate()) {
    //           return;
    //         }
    //
    //
    //       },
    //     ),
    //     ISButton(
    //       label: '취소',
    //       iconData: Icons.cancel,
    //       onPressed: () {
    //         Navigator.pop(context);
    //       },
    //     )
    //   ],
    // );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('테마 가맹점 등록'),
      ),
      body: Column(
        children: [
          SizedBox(height: 10),
          // Container(
          //     padding: EdgeInsets.symmetric(horizontal: 8.0),
          //     child: form
          // ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 16),
            // decoration: BoxDecoration(
            //     borderRadius: BorderRadius.circular(1),
            //     border: Border.all(width: 1, color: Colors.black12)
            // ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Row(
                      children: [
                        Container(
                          height: 30,
                          child: ISSelect(
                            width: 100,
                            paddingEnabled: false,
                            value: _shopJobGbn ?? '1',
                            dataList: selectBox_ShopSearchType,
                            onChange: (v){
                              _shopJobGbn = v;
                            },
                          ),
                        ),
                        ISInput(
                          height: 30,
                          width: 180,
                          value: _shopSearchKeyword,
                          textStyle: TextStyle(fontSize: 12),
                          onChange: (v) {
                            _shopSearchKeyword = v;

                          },
                          onFieldSubmitted: (value) {
                            _currentPage = 1;
                            _query();
                          },
                        ),
                        ISButton(
                          label: '조회',
                          iconData: Icons.search,
                          iconColor: Colors.white,
                          textStyle: TextStyle(color: Colors.white),
                          onPressed: () {
                          },
                        ),
                      ],
                    ),
                  ],
                ),
                //SizedBox(height: 4,),
                ISDatatable(
                  controller: ScrollController(),
                  panelHeight: 480,
                  listWidth: 800,
                  dataRowHeight: 30,
                  headingRowHeight: 24,
                  padding: EdgeInsets.all(0.0),
                  //showCheckboxColumn: (widget.shopName == null) ? true : false,
                  rows: dataShopList.map((item) {
                    return DataRow(
                        selected: item.selected ?? false,
                        color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
                          if (item.selected == true) {
                            return Colors.grey.shade200;
                            //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
                          }

                          return Theme.of(context).colorScheme.primary.withOpacity(0.00);
                        }),
                        onSelectChanged: (bool value){
                          dataShopList.forEach((element) {
                            element.selected = false;
                          });

                          item.selected = true;

                          //loadAuthData(item.uCode);

                          setState(() {
                          });
                        },
                        cells: [
                          DataCell(Align(child: Text('[${item.shopCd.toString()}] ${item.shopName.toString()}' ?? '--', style: TextStyle(color: Colors.black, fontSize: 12),), alignment: Alignment.centerLeft)),
                          DataCell(Align(child: Text(Utils.getStoreRegNumberFormat(item.regNo.toString(), false) ?? '--', style: TextStyle(color: Colors.black, fontSize: 12),), alignment: Alignment.center)),
                          DataCell(Align(child: Text('${item.addr1.toString()} ${item.addr2.toString()}' ?? '--', style: TextStyle(color: Colors.black, fontSize: 12)), alignment: Alignment.centerLeft),),
                          DataCell(
                            Center(
                              child: MaterialButton(
                                height: 30,
                                color: Colors.blue,//Colors.grey.shade400,
                                minWidth: 40,
                                child: Text('등록', style: TextStyle(color: Colors.white, fontSize: 12),),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                                onPressed: () {
                                  ISConfirm(context, '테마 가맹점 등록', '해당 가맹점을 등록하시겠습니까?', (context) async {
                                    ReservationController.to.putReserThemeShopConfirm('1', widget.code, widget.subCode, item.shopCd, context).then((value) {
                                      if (value != null){
                                        ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                      }
                                      else{
                                        //loadMainThemeListData();

                                        Navigator.pop(context);
                                        Navigator.pop(context, true);
                                      }
                                    });
                                  });
                                },
                              ),
                              // child: InkWell(
                              //     onTap: () {
                              //       //_edit(uCode: item.uCode);
                              //     },
                              //     child: Icon(Icons.delete, size: 16)
                              // ),
                            ),
                          ),
                        ]);
                  }).toList(),
                  columns: <DataColumn>[
                    DataColumn(label: Expanded(child: Text('가맹점명', textAlign: TextAlign.center)),),
                    DataColumn(label: Expanded(child: Text('사업자번호', textAlign: TextAlign.center)),),
                    DataColumn(label: Expanded(child: Text('주소', textAlign: TextAlign.center)),),
                    DataColumn(label: Expanded(child: Text('등록', textAlign: TextAlign.center)),),
                  ],
                ),
                showPagerBar(),
              ],
            ),
          )
        ],
      ),
      //bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 840,
      height: 626,
      child: result,
    );
  }

  Widget showPagerBar() {
    return Expanded(
        flex: 0,
        child: Container(
          height: 30,
          //color: Colors.yellow,
          padding: EdgeInsets.symmetric(horizontal: 8.0),
          child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                  width: 100,
                  child: Row(
                    children: <Widget>[
                      Text('총: ${Utils.getCashComma(ReservationController.to.totalRowCnt.toString())}건', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                    ],
                  ),
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      InkWell(
                          onTap: () {
                            _currentPage = 1;

                            _pageMove(_currentPage);
                          },
                          child: Icon(Icons.first_page)),
                      InkWell(
                          onTap: () {
                            if (_currentPage == 1) return;

                            _pageMove(_currentPage--);
                          },
                          child: Icon(Icons.chevron_left)),
                      Container(
                        //width: 70,
                        child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                      ),
                      InkWell(
                          onTap: () {
                            if (_currentPage >= _totalPages) return;

                            _pageMove(_currentPage++);
                          },
                          child: Icon(Icons.chevron_right)),
                      InkWell(
                          onTap: () {
                            _currentPage = _totalPages;
                            _pageMove(_currentPage);
                          },
                          child: Icon(Icons.last_page))
                    ],
                  ),
                ),
                Container(
                  //height: 36,
                  child: Responsive.isMobile(context) ? Container(/*height: 36*/) :  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      //
                      // Text(ShopController.to.totalRowCnt.toString() + ' / ' + ShopController.to.total_count.toString(), style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                      // SizedBox(width: 20,),
                      Text('페이지당 행 수 : ', style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal)),
                      Container(
                        width: 70,
                        child: DropdownButton(
                            value: _selectedpagerows,
                            underline: Container(),
                            isExpanded: true,
                            style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: 'NotoSansKR'),
                            items: Utils.getPageRowList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedpagerows = value;
                                _currentPage = 1;
                                _query();
                              });
                            }
                        ),
                      ),
                    ],
                  ),
                ),
              ]
          ),
        )
    );
  }
}
