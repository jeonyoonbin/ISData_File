import 'package:daeguro_admin_app/Model/logDetailModel.dart';
import 'package:daeguro_admin_app/Model/logListModel.dart';
import 'package:daeguro_admin_app/View/LogManager/log_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LogDetail extends StatefulWidget {
  final String seq;
  // final logDetailModel sData;
  const LogDetail({Key key, this.seq}) : super(key: key);

  @override
  LogDetailState createState() => LogDetailState();
}

class LogDetailState extends State<LogDetail> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String in_date = LogController.to.qDataDetail[0]['INSERT_TIME'];

  @override
  void initState() {
    super.initState();

    // Get.put(LogController());
  }

  @override
  Widget build(BuildContext context) {
    var data = Container(
              alignment: Alignment.centerLeft,
              margin: const EdgeInsets.fromLTRB(20, 0, 20, 0),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text('[번호]',
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: SelectableText(
                        '  ' + widget.seq,
                        style: TextStyle(fontSize: 13), showCursor: true,),
                  ),
                  SizedBox(height: 20),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text('[구분]',
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: SelectableText(
                        '  ' + LogController.to.qDataDetail[0]['DIV'],
                        style: TextStyle(fontSize: 13), showCursor: true,),
                  ),
                  SizedBox(height: 20),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text('[포지션]',
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: SelectableText(
                        '  ' +
                            LogController.to.qDataDetail[0]['POSITION'],
                        style: TextStyle(fontSize: 13), showCursor: true,),
                  ),
                  SizedBox(height: 20),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text('[로그메시지]',
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: SelectableText(
                        '  ' + LogController.to.qDataDetail[0]['MSG'],
                        style: TextStyle(fontSize: 13), showCursor: true,),
                  ),
                  SizedBox(height: 20),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text('[발생일]',
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                        '  ' +
                        in_date.replaceAll('T', ' '),
                        style: TextStyle(fontSize: 13)),
                  ),
                  SizedBox(height: 20),
                ],
              )
        );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('로그 상세 조회'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20),
            data
          ],
        ),
      )
    );
    return SizedBox(
      width: 440,
      height: 500,
      child: result,
    );
  }
}
