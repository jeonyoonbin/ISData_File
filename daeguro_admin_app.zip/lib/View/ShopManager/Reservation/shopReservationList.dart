import 'dart:html';

import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_date.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_input.dart';
import 'package:daeguro_admin_app/Model/search_items.dart';
import 'package:daeguro_admin_app/Model/shop/shop_eventListModel.dart';
import 'package:daeguro_admin_app/Provider/BackendService.dart';
import 'package:daeguro_admin_app/Util/utils.dart';

import 'package:daeguro_admin_app/View/AgentManager/agentAccount_Controller.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/ShopManager/Event/shopEventMenu.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccount_controller.dart';
import 'package:daeguro_admin_app/View/ShopManager/Event/shopEventHistory.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:date_format/date_format.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ShopReservationList extends StatefulWidget {
  const ShopReservationList({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopReservationListState();
  }
}

class ShopReservationListState extends State<ShopReservationList> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<ShopEventListModel> dataList = <ShopEventListModel>[];
  final TextEditingController _typeAheadController = TextEditingController();

  bool isSearching = false;
  String searchKeyword = '';

  SearchItems _searchItems = new SearchItems();
  String _State = '1';
  List MCodeListitems = List();

  String _mCode = '2';

  Color _color1 = Colors.blueAccent;
  Color _color2 = Colors.black;
  Color _color3 = Colors.black;
  Color _color4 = Colors.black;
  Color _color5 = Colors.black;
  Color _color6 = Colors.black;

  //int rowsPerPage = 10;

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    dataList.clear();

    _searchItems = null;
    _searchItems = new SearchItems();

    _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
    _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);

    //formKey.currentState.reset();
    //loadData();
  }

  _query() {
    //loadData();
  }

  loadMCodeListData() async {
    //MCodeListitems.clear();
    //MCodeListitems = await AgentController.to.getDataMCodeItems();
    //MCodeListitems = AgentController.to.qDataMCodeItems;

    MCodeListitems = Utils.getMCodeList();

    if (this.mounted) {
      setState(() {});
    }
  }

  _EventMenuList(String shopcode) {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: ShopEventMenu(shopCode: shopcode),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 500), () {
          _query();
        });
      }
    });
  }

  setStatusColor(String gbn) {
    if (gbn == '1') {
      _color1 = Colors.blueAccent;
      _color2 = Colors.black;
      _color3 = Colors.black;
      _color4 = Colors.black;
      _color5 = Colors.black;
      _color6 = Colors.black;
    } else if (gbn == '2') {
      _color1 = Colors.black;
      _color2 = Colors.blueAccent;
      _color3 = Colors.black;
      _color4 = Colors.black;
      _color5 = Colors.black;
      _color6 = Colors.black;
    } else if (gbn == '3') {
      _color1 = Colors.black;
      _color2 = Colors.black;
      _color3 = Colors.blueAccent;
      _color4 = Colors.black;
      _color5 = Colors.black;
      _color6 = Colors.black;
    } else if (gbn == '4') {
      _color1 = Colors.black;
      _color2 = Colors.black;
      _color3 = Colors.black;
      _color4 = Colors.blueAccent;
      _color5 = Colors.black;
      _color6 = Colors.black;
    } else if (gbn == '5') {
      _color1 = Colors.black;
      _color2 = Colors.black;
      _color3 = Colors.black;
      _color4 = Colors.black;
      _color5 = Colors.blueAccent;
      _color6 = Colors.black;
    } else if (gbn == '6') {
      _color1 = Colors.black;
      _color2 = Colors.black;
      _color3 = Colors.black;
      _color4 = Colors.black;
      _color5 = Colors.black;
      _color6 = Colors.blueAccent;
    }

    setState(() {});
  }

  loadData() async {
    await ISProgressDialog(context).show(status: 'Loading...');

    dataList.clear();

    await ShopController.to
        .getshopeventlist(_mCode, _searchItems.code, _State, _searchItems.startdate.toString(), _searchItems.enddate.toString(),
            _currentPage.round().toString(), _selectedpagerows.toString())
        .then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((e) {
          ShopEventListModel temp = ShopEventListModel.fromJson(e);
          temp.selected = false;

          temp.FROM_TIME = temp.FROM_TIME.toString().substring(0, 4) +
              '-' +
              temp.FROM_TIME.toString().substring(4, 6) +
              '-' +
              temp.FROM_TIME.toString().substring(6, 8) +
              ' ' +
              temp.FROM_TIME.toString().substring(8, 10) +
              ':' +
              temp.FROM_TIME.toString().substring(10, 12);

          temp.TO_TIME = temp.TO_TIME.toString().substring(0, 4) +
              '-' +
              temp.TO_TIME.toString().substring(4, 6) +
              '-' +
              temp.TO_TIME.toString().substring(6, 8) +
              ' ' +
              temp.TO_TIME.toString().substring(8, 10) +
              ':' +
              temp.TO_TIME.toString().substring(10, 12);

          dataList.add(temp);
        });

        _totalRowCnt = ShopController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
      }
    });

    if (this.mounted) {
      setState(() {});
    }

    await ISProgressDialog(context).dismiss();
  }

  @override
  void initState() {
    super.initState();

    Get.put(AgentController());
    Get.put(ShopController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      loadMCodeListData();
      _reset();
      _query();
    });

    setState(() {
      _searchItems.startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
      _searchItems.enddate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', dd]);
    });
  }

  @override
  void dispose() {
    dataList.clear();

    //MCodeListitems.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //testSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Row(
            children: [
              InkWell(
                  child: Text('전체: ${Utils.getCashComma(ShopController.to.totalRowCnt.toString())}건',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: _color1)),
                  onTap: () {
                    setStatusColor('1');
                    print('전체');
                  }),
              Text(' || '),
              InkWell(
                  child: Text('확정대기: ${Utils.getCashComma(ShopController.to.totalRowCnt.toString())}건',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: _color2)),
                  onTap: () {
                    setStatusColor('2');
                    print('확정대기');
                  }),
              Text(' || '),
              InkWell(
                  child: Text('예약확정: ${Utils.getCashComma(ShopController.to.totalRowCnt.toString())}건',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: _color3)),
                  onTap: () {
                    setStatusColor('3');
                    print('예약확정');
                  }),
              Text(' || '),
              InkWell(
                  child: Text('방문완료: ${Utils.getCashComma(ShopController.to.totalRowCnt.toString())}건',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: _color4)),
                  onTap: () {
                    setStatusColor('4');
                    print('방문완료');
                  }),
              Text(' || '),
              InkWell(
                  child: Text('미방문: ${Utils.getCashComma(ShopController.to.totalRowCnt.toString())}건',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: _color5)),
                  onTap: () {
                    setStatusColor('5');
                    print('미방문');
                  }),
              Text(' || '),
              InkWell(
                  child: Text('취소: ${Utils.getCashComma(ShopController.to.totalRowCnt.toString())}건',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: _color6)),
                  onTap: () {
                    setStatusColor('6');
                    print('취소');
                  }),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Column(
                children: [
                  ISSearchDropdown(
                    label: '회원사명',
                    value: _mCode,
                    onChange: (value) {
                      setState(() {
                        _currentPage = 1;
                        _mCode = value;
                        _query();
                      });
                    },
                    width: 240,
                    item: MCodeListitems.map((item) {
                      return new DropdownMenuItem<String>(
                          child: new Text(
                            item['mName'],
                            style: TextStyle(fontSize: 13, color: Colors.black),
                          ),
                          value: item['mCode']);
                    }).toList(),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Row(
                    children: [
                      ISSearchSelectDate(
                        context,
                        label: '시작일',
                        width: 120,
                        value: _searchItems.startdate.toString(),
                        onTap: () async {
                          DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.startdate);
                          final DateTime picked = await showDatePicker(
                            context: context,
                            initialDate: valueDt,
                            firstDate: DateTime(1900, 1),
                            lastDate: DateTime(2031, 12),
                          );

                          setState(() {
                            if (picked != null) {
                              _searchItems.startdate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                            }
                          });
                        },
                      ),
                      ISSearchSelectDate(
                        context,
                        label: '종료일',
                        width: 120,
                        value: _searchItems.enddate.toString(),
                        onTap: () async {
                          DateTime valueDt = isBlank ? DateTime.now() : DateTime.parse(_searchItems.enddate);
                          final DateTime picked = await showDatePicker(
                            context: context,
                            initialDate: valueDt,
                            firstDate: DateTime(1900, 1),
                            lastDate: DateTime(2031, 12),
                          );

                          setState(() {
                            if (picked != null) {
                              _searchItems.enddate = formatDate(picked, [yyyy, '-', mm, '-', dd]);
                            }
                          });
                        },
                      ),
                    ],
                  )
                ],
              ),
              Column(
                children: [
                  Container(
                    width: 350,
                    height: 40,
                    padding: EdgeInsets.only(left: 5),
                    child: TypeAheadFormField(
                      textFieldConfiguration: TextFieldConfiguration(
                        //focusNode: searchBoxFocusNode,
                        cursorColor: Colors.black,
                        style: TextStyle(color: Colors.black, fontSize: 13.0),
                        decoration: InputDecoration(
                            fillColor: Colors.grey[200],
                            filled: true,
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: const BorderRadius.all(Radius.circular(6)),
                            ),
                            hintText: '가맹점 검색...',
                            hintStyle: TextStyle(color: Colors.black54),
                            contentPadding: EdgeInsets.symmetric(horizontal: 14.0, vertical: 14.0),
                            suffixIcon: InkWell(
                              child: Icon(
                                Icons.cancel,
                                size: 16,
                                color: Colors.grey,
                              ),
                              onTap: () {
                                if (_typeAheadController == null /* || _typeAheadController.text.isEmpty*/) {
                                  return;
                                }
                                disableSearching(); //clearSearchKeyword();
                              },
                            )),
                        controller: this._typeAheadController,
                      ),
                      suggestionsCallback: (pattern) async {
                        return await BackendService.getCopyMenuShopSuggestions('2', pattern);
                      },
                      itemBuilder: (context, Map<String, String> suggestion) {
                        return ListTile(
                          title: Text(
                            '[' + suggestion['shopCd'] + '] ' + suggestion['shopName'],
                            style: TextStyle(fontSize: 14),
                          ),
                          //subtitle: Text('\$${suggestion['shopCd']}'),
                        );
                      },
                      transitionBuilder: (context, suggstionsBox, controller) {
                        return suggstionsBox;
                      },
                      onSuggestionSelected: (Map<String, String> suggestion) async {
                        clearSearchKeyword();
                        updateSearchKeyword(suggestion['shopName'].toString());
                        //clearSearchKeyword();
                      },
                    ),
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.only(right: 8.0),
                        child: ISSearchDropdown(
                          label: '조회 조건',
                          width: 150,
                          value: _State,
                          onChange: (value) {
                            setState(() {
                              _State = value;
                              _currentPage = 1;
                              _query();
                            });
                          },
                          item: [
                            DropdownMenuItem(
                              value: '1',
                              child: Text('주문번호'),
                            ),
                            DropdownMenuItem(
                              value: '2',
                              child: Text('이름/전화번호'),
                            ),
                          ].cast<DropdownMenuItem<String>>(),
                        ),
                      ),
                      Container(
                        child: Stack(
                          alignment: Alignment.centerRight,
                          children: [
                            ISSearchInput(
                              width: 200,
                              value: _searchItems.code,
                              onChange: (v) {
                                _searchItems.code = v;
                              },
                              onFieldSubmitted: (value) {
                                _currentPage = 1;
                                _query();
                              },
                            ),
                            // Container(
                            //   margin: EdgeInsets.fromLTRB(0, 15, 15, 0),
                            //   child: IconButton(
                            //     splashRadius: 15,
                            //     icon: Icon(Icons.close),
                            //     color: Colors.black54,
                            //     iconSize: 20,
                            //     onPressed: () {
                            //       _searchItems.code = '';
                            //       setState(() {});
                            //     },
                            //   ),
                            // ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              ISSearchButton(
                  label: '조회',
                  iconData: Icons.search,
                  onPressed: () => {
                        if (EasyLoading.isShow != true) {_currentPage = 1, _query()}
                      }),
            ],
          ),
        ],
      ),
    );

    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          form,
          buttonBar,
          Divider(),
          ISDatatable(
            panelHeight: (MediaQuery.of(context).size.height - defaultContentsHeight) - 48,
            listWidth: Responsive.getResponsiveWidth(context, 640),
            rows: dataList.map((item) {
              return DataRow(cells: [
                DataCell(Align(
                  child: SelectableText(item.SHOP_NAME.toString() == null ? '--' : '[' + item.SHOP_CD.toString() + '] ' + item.SHOP_NAME.toString(),
                      showCursor: true),
                  alignment: Alignment.centerLeft,
                )),
                DataCell(Align(
                  child: SelectableText(item.INS_DATE.toString().replaceAll('T', ' '), showCursor: true),
                  alignment: Alignment.center,
                )),
                DataCell(Align(
                  child: SelectableText(item.FROM_TIME.toString(), showCursor: true),
                  alignment: Alignment.center,
                )),
                DataCell(Align(
                  child: SelectableText(item.TO_TIME.toString(), showCursor: true),
                  alignment: Alignment.center,
                )),
                DataCell(Align(
                  child: SelectableText(item.STATE.toString(), showCursor: true),
                  alignment: Alignment.center,
                )),
                DataCell(Align(
                  child: SelectableText(item.EVENT_TITLE_M.toString(), showCursor: true),
                  alignment: Alignment.centerLeft,
                )),
                DataCell(
                  Center(
                    child: InkWell(
                        onTap: () {

                        },
                        child: Icon(Icons.receipt_long)
                    ),
                  ),
                ),
              ]);
            }).toList(),
            columns: <DataColumn>[
              DataColumn(label: Expanded(child: SelectableText('주문번호', textAlign: TextAlign.center))),
              DataColumn(label: Expanded(child: SelectableText('신청 일시', textAlign: TextAlign.center))),
              DataColumn(label: Expanded(child: SelectableText('상태', textAlign: TextAlign.center))),
              DataColumn(label: Expanded(child: SelectableText('예약자 정보', textAlign: TextAlign.center))),
              DataColumn(label: Expanded(child: SelectableText('예약 정보', textAlign: TextAlign.center))),
              DataColumn(label: Expanded(child: SelectableText('요청 사항', textAlign: TextAlign.left))),
              DataColumn(label: Expanded(child: SelectableText('상세', textAlign: TextAlign.left))),
            ],
          ),
          Divider(),
          SizedBox(
            height: 0,
          ),
          showPagerBar(),
        ],
      ),
    );
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                //Text('row1'),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(),
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context)
                ? Container(height: 48)
                : Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      Text(
                        '페이지당 행 수 : ',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),
                      ),
                      Container(
                        width: 70,
                        child: DropdownButton(
                            value: _selectedpagerows,
                            isExpanded: true,
                            style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: 'NotoSansKR'),
                            items: Utils.getPageRowList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedpagerows = value;
                                _currentPage = 1;
                                _query();
                              });
                            }),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  void disableSearching() {
    clearSearchKeyword();

    setState(() {
      isSearching = false;
    });
  }

  void clearSearchKeyword() {
    setState(() {
      _typeAheadController.clear();
      updateSearchKeyword('');
    });
  }

  void updateSearchKeyword(String newKeyword) {
    setState(() {
      searchKeyword = newKeyword;
      _typeAheadController.text = searchKeyword;
    });
  }
}
