import 'dart:convert';

import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_checkbox.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/Model/shop/shopReserveModifyClosedayModel.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reservationmanager_controller.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

class ShopReserveModifyCloseday extends StatefulWidget {
  final String shopCode;

  const ShopReserveModifyCloseday({Key key, this.shopCode}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopReserveModifyClosedayState();
  }
}

class ShopReserveModifyClosedayState extends State<ShopReserveModifyCloseday>  with SingleTickerProviderStateMixin {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<ShopReserveModifyClosedayModel> dataHolidayList = <ShopReserveModifyClosedayModel>[];
  final List<ShopReserveModifyClosedayModel> dataClosedayList = <ShopReserveModifyClosedayModel>[];
  final List<ShopReserveModifyClosedayModel> dataTempClosedayList = <ShopReserveModifyClosedayModel>[];

  List<DropdownMenuItem> selectBox_closeDayCd = [];

  List<DropdownMenuItem> selectBox_dayCd = [
    DropdownMenuItem(value: '0', child: Center(child: Text('요일 선택'))),
    DropdownMenuItem(value: '1', child: Center(child: Text('일요일'))),
    DropdownMenuItem(value: '2', child: Center(child: Text('월요일'))),
    DropdownMenuItem(value: '3', child: Center(child: Text('화요일'))),
    DropdownMenuItem(value: '4', child: Center(child: Text('수요일'))),
    DropdownMenuItem(value: '5', child: Center(child: Text('목요일'))),
    DropdownMenuItem(value: '6', child: Center(child: Text('금요일'))),
    DropdownMenuItem(value: '7', child: Center(child: Text('토요일'))),
  ];

  String _holidayComment = '\n* 주말(토,일)은 별도로 휴무일 설정해주세요.\n\n설정되는 공휴일\n  1. 국경일 중 3·1절, 광복절, 개천절 및 한글날  2. 1월 1일\n  3. 설날 전날, 설날, 설날 다음날 (음력 12월 말일, 1월 1일, 2일)\n  4. 석가탄신일 (음력 4월 8일)\n  5. 어린이날 (5월 5일)\n  6. 현충일 (6월 6일)\n  7. 추석 전날, 추석, 추석 다음날(음력 8월 14일, 15일, 16일)\n  8. 성탄절 (12월 25일)\n  9 .｢공직선거법｣제34조에 따른 임기 만료에 의한 선거의 선거일\n  10. 기타 정부에서 수시 지정하는 날\n';

  bool _holidayEnabled = false;

  loadClosedayCodeData() async {
    selectBox_closeDayCd.clear();

    await ReservationController.to.getShopReserveClosedayCodeList().then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        selectBox_closeDayCd.add(DropdownMenuItem(value: '0', child: Center(child: Text('주기 선택'))));
        
        value.forEach((element) {
          //print('useGbn: ${element['useGbn'].toString()}, [${element['code'].toString()}] ${element['nameMain'].toString()}');
          if (element['useGbn'].toString() == 'Y')
            selectBox_closeDayCd.add(DropdownMenuItem(value: element['code'].toString(), child: Center(child: Text(element['nameMain'].toString()))));
        });
      }
    });
  }

  loadClosedayData(String gbn) async {
    if (gbn == '1')           dataHolidayList.clear();
    else if (gbn == '3')      dataClosedayList.clear();
    else if (gbn == '5')      dataTempClosedayList.clear();

    await ReservationController.to.getShopReserveModifyClosedayList(widget.shopCode, gbn).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        value.forEach((element) {
          print('[${gbn}] element:${element.toString()}');
          ShopReserveModifyClosedayModel tempData = ShopReserveModifyClosedayModel.fromJson(element);

          if (gbn == '1')            dataHolidayList.add(tempData);
          else if (gbn == '3')       dataClosedayList.add(tempData);
          else if (gbn == '5')       dataTempClosedayList.add(tempData);
        });

        if (gbn == '1' && dataHolidayList.length != 0){
          _holidayEnabled = (dataHolidayList[0].foDay == 'N' && dataHolidayList[0].toDay == 'N') ? false : true;
        }

        if (gbn == '3' && dataClosedayList.length == 0)              dataClosedayList.add(new ShopReserveModifyClosedayModel(seq: 0));
        else if (gbn == '5'&& dataTempClosedayList.length == 0)      dataTempClosedayList.add(new ShopReserveModifyClosedayModel(seq: 0));

        setState(() {
        });
      }
    });
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReservationController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      loadClosedayCodeData();
      loadClosedayData('1');//공휴일 조회
      loadClosedayData('3');//정기휴무일 조회
      loadClosedayData('5');//임시휴무일 조회
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '닫기',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('[예약] 휴무일 설정'),
      ),
      body: Container(
          padding: EdgeInsets.only(left: 16.0, right: 16.0, top: 16.0),//symmetric(vertical: 16, horizontal: 16.0),
          child: getBodyView()
      ),
      bottomNavigationBar: buttonBar,
    );

    return SizedBox(
      width: 420,
      height: 530,
      child: result,
    );
  }

  Widget getBodyView() {
    return ListView(
      controller: ScrollController(),
      //physics: NeverScrollableScrollPhysics(),
      children: <Widget>[
        Column(
          children: [
            Divider(height: 1,),
            Container(
              height: 34,
              color: Colors.grey.shade200,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.only(left: 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('공휴일', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),),
                        SizedBox(width: 4,),
                        Tooltip(
                          child: Icon(Icons.help, color: Colors.blue, size: 16),
                          message: _holidayComment,
                          textStyle: TextStyle(fontSize: 12, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Divider(height: 1,),
            Container(
              height: 50,
              alignment: Alignment.centerLeft,
              child: ISCheckbox(label: '공휴일 설정하기',
                  value: _holidayEnabled,
                  onChanged: (v) async{
                    dataHolidayList[0].foDay = v == true ? 'Y' : 'N';
                    dataHolidayList[0].toDay = v == true ? 'Y' : 'N';

                    _holidayEnabled = v;

                    //await ISProgressDialog(context).show(status: 'Loading...');

                    String jsonData = jsonEncode(dataHolidayList);

                    var bodyData = {'"shopCode"': '"${widget.shopCode}"', '"gbn"': '"1"', '"list"': jsonData};

                    await ReservationController.to.postShopReserveModifyCloseday(context, bodyData.toString()).then((value) async {
                      if (value == '00'){
                        setState(() {
                        });
                      }

                      //Navigator.pop(context);

                      //await ISProgressDialog(context).dismiss();
                    });
                  }),
            ),
            Divider(height: 1,),
            Container(
              height: 34,
              color: Colors.grey.shade200,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.only(left: 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('정기 휴무일', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),),
                        SizedBox(width: 4,),
                        Text('(최대 20개)', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold),),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.only(right: 8),
                    child: Row(
                      children: [
                        Container(
                          width: 48,
                          child: ISButton(
                              label: '추가',
                              textStyle: TextStyle(color: Colors.white, fontSize: 12),
                              height: 26,
                              onPressed: () {
                                if (dataClosedayList.length >= 20){
                                  ISAlert(context, '정기휴무일은 최대 20개까지 등록 가능 합니다.');
                                  return;
                                }

                                setState(() {
                                  dataClosedayList.add(new ShopReserveModifyClosedayModel(seq: 0));
                                });
                              }
                          ),
                        ),
                        SizedBox(width: 4),
                        Container(
                          width: 48,
                          child: ISButton(
                              label: '저장',
                              textStyle: TextStyle(color: Colors.white, fontSize: 12),
                              height: 26,
                              onPressed: () async {
                                int emptyValue_foday = dataClosedayList.indexWhere((item) => item.foDay == '0');
                                if (emptyValue_foday != -1){
                                  ISAlert(context, '주기 선택을 해주세요.');
                                  return;
                                }

                                int emptyValue_today = dataClosedayList.indexWhere((item) => item.toDay == '0');
                                if (emptyValue_today != -1){
                                  ISAlert(context, '요일 선택을 해주세요.');
                                  return;
                                }

                                if (dataClosedayList.length == 0) return;

                                //await ISProgressDialog(context).show(status: 'Loading...');

                                String jsonData = jsonEncode(dataClosedayList);

                                var bodyData = {'"shopCode"': '"${widget.shopCode}"', '"gbn"': '"3"', '"list"': jsonData};

                                await ReservationController.to.postShopReserveModifyCloseday(context, bodyData.toString()).then((value) async {
                                  if (value == '00'){

                                  }

                                  //Navigator.pop(context);

                                  //await ISProgressDialog(context).dismiss();
                                });
                              }
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
            Divider(height: 1,),
            //SizedBox(height: 6,),
            Container(
                height: dataClosedayList.length * 40.0,
                child: ListView(
                  physics: NeverScrollableScrollPhysics(),
                  //padding: const EdgeInsets.only(left: 16, right: 16),
                  children: <Widget>[
                    DataTable(
                      // decoration: BoxDecoration(
                      //   //borderRadius: BorderRadius.circular(1),
                      //     border: Border.all(width: 0.6, color: Colors.black38)
                      // ),
                      headingRowHeight: 0.01,
                      dividerThickness: 0.01,
                      headingRowColor: MaterialStateColor.resolveWith((states) => Colors.blue[50]),
                      headingTextStyle: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'NotoSansKR', color: Colors.black54, fontSize: 12),
                      dataRowHeight: 40,
                      dataRowColor: MaterialStateColor.resolveWith((states) => Colors.white),
                      dataTextStyle: TextStyle(fontWeight: FontWeight.normal, fontFamily: 'NotoSansKR', fontSize: 14),
                      columnSpacing: 0,
                      columns: <DataColumn>[
                        DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.left)),),
                        DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.right)),),
                      ],
                      //source: listDS,
                      rows: dataClosedayList.map((item) {
                        return DataRow(cells: [
                          DataCell(Align(
                              child: Container(
                                padding: EdgeInsets.only(left: 10.0),
                                width: 160,
                                height: 26,
                                decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(5.0)),
                                child: DropdownButton(
                                  style: TextStyle(fontSize: 12, fontFamily: 'NotoSansKR', color: Colors.black),
                                  value: item.foDay,
                                  items: selectBox_closeDayCd,
                                  onChanged: (value) async {
                                    setState(() {
                                      item.foDay = value;
                                    });
                                  },
                                ),
                              ),
                              alignment: Alignment.centerLeft)
                          ),
                          DataCell(
                            Center(
                              child: Container(width: 10,),
                            )
                          ),
                          DataCell(Align(
                              child: Container(
                                padding: EdgeInsets.only(left: 10.0),
                                width: 100,
                                height: 26,
                                decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(5.0)),
                                child: DropdownButton(
                                  style: TextStyle(fontSize: 12, fontFamily: 'NotoSansKR', color: Colors.black),
                                  value: item.toDay,
                                  items: selectBox_dayCd,
                                  onChanged: (value) async {
                                    setState(() {
                                      item.toDay = value;
                                    });
                                  },
                                ),
                              ),
                              alignment: Alignment.center)
                          ),
                          DataCell(Align(
                            child: Container(
                              width: 80,
                              child: IconButton(
                                onPressed: () {
                                  if (item.foDay == '0' && item.toDay == '0' ){
                                    setState(() {
                                      dataClosedayList.remove(item);
                                    });

                                    return;
                                  }
                                  else{
                                    if (item.foDay == null || item.foDay == '0'){
                                      ISAlert(context, '주기 선택을 해주세요.');
                                      return;
                                    }

                                    if (item.toDay == null || item.toDay == '0'){
                                      ISAlert(context, '요일 선택을 해주세요.');
                                      return;
                                    }


                                    ISConfirm(context, '정기휴무일 삭제', '해당 정기휴무일을 삭제 하시겠습니까?', (context) async {
                                      Navigator.pop(context);

                                      var bodyData = {
                                        '"shopCode"': '"${widget.shopCode}"',
                                        '"gbn"': '"3"',
                                        '"seq"': '${item.seq}',
                                        '"foDay"': '"${item.foDay}"',
                                        '"toDay"': '"${item.toDay}"'
                                      };

                                      ReservationController.to.deleteShopReserveModifyCloseday(bodyData.toString()).then((value) {
                                        if (value != null){
                                          ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                        }
                                        else{
                                          loadClosedayData('3');
                                        }
                                      });
                                    });
                                  }
                                },
                                icon: Icon(Icons.delete, size: 18,),
                                tooltip: '삭제',
                              ),
                            ),alignment: Alignment.centerRight
                          )
                          ),
                        ]);
                      }).toList(),
                    ),
                  ],
                )
            ),
          ],
        ),
        SizedBox(height: 16,),
        Column(
          children: [
            Divider(height: 1,),
            Container(
              height: 34,
              color: Colors.grey.shade200,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.only(left: 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('임시 휴무일', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),),
                        SizedBox(width: 4,),
                        Text('(최대 20개)', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold),),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.only(right: 8),
                    child: Row(
                      children: [
                        Container(
                          width: 48,
                          child: ISButton(
                              label: '추가',
                              textStyle: TextStyle(color: Colors.white, fontSize: 12),
                              height: 26,
                              onPressed: () {
                                if (dataTempClosedayList.length >= 20){
                                  ISAlert(context, '임시휴무일은 최대 20개까지 등록 가능 합니다.');
                                  return;
                                }

                                setState(() {
                                  dataTempClosedayList.add(new ShopReserveModifyClosedayModel(seq: 0));
                                });
                              }
                          ),
                        ),
                        SizedBox(width: 4),
                        Container(
                          width: 48,
                          child: ISButton(
                              label: '저장',
                              textStyle: TextStyle(color: Colors.white, fontSize: 12),
                              height: 26,
                              onPressed: () async {
                                int emptyValue_foday = dataTempClosedayList.indexWhere((item) => item.foDay == '0');
                                if (emptyValue_foday != -1){
                                  ISAlert(context, '시작일을 선택을 해주세요.');
                                  return;
                                }

                                int emptyValue_today = dataTempClosedayList.indexWhere((item) => item.toDay == '0');
                                if (emptyValue_today != -1){
                                  ISAlert(context, '종료일을 선택을 해주세요.');
                                  return;
                                }

                                if (dataTempClosedayList.length == 0) return;

                                //await ISProgressDialog(context).show(status: 'Loading...');

                                String jsonData = jsonEncode(dataTempClosedayList);

                                var bodyData = {'"shopCode"': '"${widget.shopCode}"', '"gbn"': '"5"', '"list"': jsonData};

                                await ReservationController.to.postShopReserveModifyCloseday(context, bodyData.toString()).then((value) async {
                                  if (value == '00'){

                                  }

                                  //Navigator.pop(context);

                                  //await ISProgressDialog(context).dismiss();
                                });
                              }
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
            Divider(height: 1,),
            //SizedBox(height: 6,),
            Container(
                height: dataTempClosedayList.length * 40.0,
                child: ListView(
                  physics: NeverScrollableScrollPhysics(),
                  //padding: const EdgeInsets.only(left: 16, right: 16),
                  children: <Widget>[
                    DataTable(
                      // decoration: BoxDecoration(
                      //   //borderRadius: BorderRadius.circular(1),
                      //     border: Border.all(width: 0.6, color: Colors.black38)
                      // ),
                      headingRowHeight: 0.01,
                      dividerThickness: 0.01,
                      headingRowColor: MaterialStateColor.resolveWith((states) => Colors.blue[50]),
                      headingTextStyle: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'NotoSansKR', color: Colors.black54, fontSize: 12),
                      dataRowHeight: 40,
                      dataRowColor: MaterialStateColor.resolveWith((states) => Colors.white),
                      dataTextStyle: TextStyle(fontWeight: FontWeight.normal, fontFamily: 'NotoSansKR', fontSize: 14),
                      columnSpacing: 0,
                      columns: <DataColumn>[
                        DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.left)),),
                        //DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text('', textAlign: TextAlign.right)),),
                      ],
                      //source: listDS,
                      rows: dataTempClosedayList.map((item) {
                        return DataRow(cells: [
                          DataCell(Align(child: Container(
                            width: 135,
                            //height: 26,
                            child: ISInput(
                              readOnly: true,
                              value: item.foDay == '0' ? '시작일 선택': Utils.getYearMonthDayFormat(item.foDay),
                              textStyle: TextStyle(fontSize: 12),
                              textAlign: TextAlign.center,
                              onTap: () async {
                                DateTime valueDt = DateTime.now();

                                final DateTime picked = await showDatePicker(
                                  context: context,
                                  initialDate: valueDt,
                                  firstDate: DateTime(1900, 1),
                                  lastDate: DateTime(2031, 12),
                                );

                                if (picked != null) {
                                  item.foDay = formatDate(picked, [yyyy, '-', mm, '-', dd]);

                                  setState(() {
                                  });
                                }
                              },
                              onChange: (v) {

                              },
                            ),
                          ), alignment: Alignment.centerLeft)
                          ),
                          // DataCell(
                          //     Align(
                          //       child: Container(width: 10,), alignment: Alignment.center)
                          // ),
                          DataCell(Align(child: Container(
                            width: 135,
                            //height: 26,
                            child: ISInput(
                              readOnly: true,
                              value: item.toDay == '0' ? '종료일 선택': Utils.getYearMonthDayFormat(item.toDay),
                              textStyle: TextStyle(fontSize: 12),
                              textAlign: TextAlign.center,
                              onTap: () async {
                                DateTime valueDt = DateTime.now();

                                final DateTime picked = await showDatePicker(
                                  context: context,
                                  initialDate: valueDt,
                                  firstDate: DateTime(1900, 1),
                                  lastDate: DateTime(2031, 12),
                                );

                                if (picked != null) {
                                  item.toDay = formatDate(picked, [yyyy, '-', mm, '-', dd]);

                                  setState(() {
                                  });
                                }
                              },
                              onChange: (v) {

                              },
                            ),
                          ), alignment: Alignment.center)
                          ),
                          DataCell(Align(
                              child: Container(
                                width: 80,
                                child: IconButton(
                                  onPressed: () {
                                    if (item.foDay == '0' && item.toDay == '0' ){
                                      setState(() {
                                        dataTempClosedayList.remove(item);
                                      });

                                      return;
                                    }
                                    else{
                                      if (item.foDay == null || item.foDay == '0'){
                                        ISAlert(context, '시작일을 선택을 해주세요.');
                                        return;
                                      }

                                      if (item.toDay == null || item.toDay == '0'){
                                        ISAlert(context, '종료일을 선택을 해주세요.');
                                        return;
                                      }
                                      
                                      
                                      ISConfirm(context, '임시휴무일 삭제', '해당 임시휴무일을 삭제 하시겠습니까?', (context) async {
                                        Navigator.pop(context);

                                        var bodyData = {
                                          '"shopCode"': '"${widget.shopCode}"',
                                          '"gbn"': '"5"',
                                          '"seq"': '${item.seq}',
                                          '"foDay"': '"${item.foDay}"',
                                          '"toDay"': '"${item.toDay}"'
                                        };

                                        ReservationController.to.deleteShopReserveModifyCloseday(bodyData.toString()).then((value) {
                                          if (value != null){
                                            ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                                          }
                                          else{
                                            loadClosedayData('5');
                                          }
                                        });
                                      });
                                    }
                                  },
                                  icon: Icon(Icons.delete, size: 18,),
                                  tooltip: '삭제',
                                ),
                              ),alignment: Alignment.centerRight
                          )
                          ),
                        ]);
                      }).toList(),
                    ),
                  ],
                )
            ),
          ],
        )
      ],
    );
  }
}
