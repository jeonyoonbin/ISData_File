import 'package:flutter/material.dart';

class ShopDetailNotifierData{
  ShopDetailNotifierData();

  String selected_shopCode = '';
  String selected_mCode = '';
  String selected_ccCode = '';
  String selected_apiComCode = '';
  String selected_imageStatus = '';
  String selected_calcYn  = 'Y';       //정산정보
  String selected_shopInfoYn = 'Y';    //매장정보
  String selected_deliYn = 'Y';        //배송지관리
  String selected_tipYn = 'Y';         //배달팁정보
  String selected_saleYn = 'Y';        //운영정보

  // void setCurrentData(String shopCd, String mCode, String ccCode, String apiComCode, String imageStatus){
  //   this.selected_shopCode = shopCd;
  //   this.selected_mCode = mCode;
  //   this.selected_ccCode = ccCode;
  //   this.selected_apiComCode = apiComCode;
  //   this.selected_imageStatus = imageStatus;
  // }

  String get currentShopCode{
    return this.selected_shopCode;
  }

  String get currentMCode{
    return this.selected_mCode;
  }

  String get currentCCCode{
    return this.selected_ccCode;
  }

  String get currentApiComCode{
    return this.selected_apiComCode;
  }

  String get currentImageStatus{
    return this.selected_imageStatus;
  }

  String toString()  {
    return 'selected_shopCode:${selected_shopCode}, selected_mCode:${selected_mCode}, selected_ccCode:${selected_ccCode}, selected_apiComCode:${selected_apiComCode}, selected_imageStatus:${selected_imageStatus}';
  }
}