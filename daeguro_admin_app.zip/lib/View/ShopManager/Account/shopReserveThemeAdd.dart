import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveThemeListModel.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveThemeSubModel.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reservationmanager_controller.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccount_controller.dart';

import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

class ShopReserveThemeAdd extends StatefulWidget {
  final String shopCd;
  const ShopReserveThemeAdd({Key key, this.shopCd})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopReserveThemeAddState();
  }
}

class ShopReserveThemeAddState extends State<ShopReserveThemeAdd>  with SingleTickerProviderStateMixin{
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<ReserveThemeListModel> dataList = <ReserveThemeListModel>[];
  //List items = List();

  //List<SelectOptionVO> selectBox_piditem = [];

  // String _shopJobGbn = '1';
  // String _shopSearchKeyword = '';
  //
  // String _selectedCode = '';
  // int _selectedSubCode = 0;

  _reset() {
    dataList.clear();
  }

  _query() {

  }

  loadMainThemeListData() async {
    dataList.clear();

    await ReservationController.to.getReserveMainThemeList().then((value) {
      if(value == null){
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        value.forEach((e) {
          ReserveThemeListModel temp = ReserveThemeListModel.fromJson(e);
          dataList.add(temp);
        });
      }
    });

    setState(() {

    });
  }

  addSubThemeData(String code) async {
    List<ReserveThemeListModel> tempMainThemeList = <ReserveThemeListModel>[];

    await ReservationController.to.getReserveSubThemeList(code).then((value) {
      value.forEach((element) {
        ReserveThemeSubModel subThemeItem = ReserveThemeSubModel.fromJson(element);

        int compareIndex = dataList.indexWhere((item) => item.code == subThemeItem.temaCode);
        if (compareIndex != -1){
          ReserveThemeListModel listItem = ReserveThemeListModel();
          listItem.isChild = true;
          listItem.code = subThemeItem.temaCode;
          listItem.subcode = subThemeItem.subTemaCode;
          listItem.nameMain = subThemeItem.gungu != '' ? '[${subThemeItem.gungu}] ${subThemeItem.temaName}' : subThemeItem.temaName;

          tempMainThemeList.add(listItem);
        }
      });

      tempMainThemeList = List.from(tempMainThemeList.reversed);

      int selectindex = dataList.indexWhere((item) => item.code.toString() == code);
      tempMainThemeList.forEach((element) {
        if (element.code != null) dataList.insert(selectindex + 1, element);
      });

    });

    setState(() {
    });
  }

  removeSubThemeData(String code) {
    setState(() {
      dataList.removeWhere((item) => (item.code == code && item.isChild == true));
    });
  }  

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());
    Get.put(ReservationController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      loadMainThemeListData();
      //_query();
    });
  }

  @override
  void dispose() {
    dataList.clear();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '선택한 테마 저장',
          iconData: Icons.save,
          onPressed: () {
            ISConfirm(context, '테마 추가', '해당 테마로 추가하시겠습니까?', (context) async {

              dataList.forEach((element) {
                if (element.selected == true){

                  ReservationController.to.putReserThemeShopConfirm('1', element.code, element.subcode, widget.shopCd, context).then((value) {
                    if (value != null){
                      ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                    }
                    else{
                      //loadMainThemeListData();
                    }
                  });
                }
              });

              Navigator.pop(context);
              Navigator.pop(context, true);
            });
          },
        )
        // ISButton(
        //   label: '취소',
        //   iconData: Icons.cancel,
        //   onPressed: () {
        //     Navigator.pop(context);
        //   },
        // )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('[예약] 테마 추가'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: ISDatatable(
            controller: ScrollController(),
            headingRowHeight: 0.01,
            dividerThickness: 0.01,
            viewScrollAxis: Axis.vertical,
            panelHeight: (MediaQuery.of(context).size.height-175),
            listWidth: 400,
            dataRowHeight: 30,
            rows: getDataRow(),
            columns: getDataColumn(),
          ),
        ),
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 420,
      height: 640,
      child: result,
    );
  }

  List<DataRow> getDataRow() {
    List<DataRow> tempData = [];

    dataList.forEach((element) {
      double fontSize = 14.0;

      if (element.isChild == true) fontSize = 12.0;

      tempData.add(
          DataRow(
              selected: element.selected ?? false,
              color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
                if (element.selected == true) {
                  return Colors.grey.shade200;
                  //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
                }

                return Theme.of(context).colorScheme.primary.withOpacity(0.00);
              }),
              onSelectChanged: (bool value){
                dataList.forEach((element) {
                  element.selected = false;
                });

                element.selected = true;

                setState(() {

                });
              },
              cells: [
                DataCell(Align(
                  alignment: Alignment.centerLeft,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      (element.isChild == true) ? Container(width: 30,)
                          : InkWell(
                        child: Icon(element.isOpened == true ? Icons.remove_circle : Icons.add_circle, color: Colors.blue, size: 20),
                        onTap: () {
                          if (element.isOpened == true) {
                            element.isOpened = false;
                            removeSubThemeData(element.code);
                          }
                          else {
                            element.isOpened = true;
                            addSubThemeData(element.code);
                          }
                        },
                      ),
                      (element.isChild == true) ? Icon(Icons.folder, color: Colors.blue, size: 20) : Container(),
                      SizedBox(width: 10,),
                      Checkbox(
                          value: element.selected, //this.checkAll,
                          onChanged: (value) {

                            // element.selected == false ? element.selected = true : element.selected = false;
                            //
                            // setState(() {});
                          }),
                      Align(child:
                      Container(
                          padding: EdgeInsets.only(bottom: 2),
                          child: Text(element.nameMain.toString(), style: TextStyle(color: Colors.black, fontSize: fontSize),)
                      ), alignment: element.isChild == true ? Alignment.centerLeft : Alignment.center)
                    ],
                  ),
                )
                ),
              ]
          )
      );
    });

    return tempData;
  }

  List<DataColumn> getDataColumn() {
    List<DataColumn> tempData = [];

    tempData.add(DataColumn(
      label: Expanded(child: Text('', textAlign: TextAlign.center)),
    ));

    return tempData;
  }

  // double getListMainPanelWidth(){
  //   double nWidth = MediaQuery.of(context).size.width-660;
  //
  //   if (Responsive.isTablet(context) == true)           nWidth = nWidth + sidebarWidth;
  //   else if (Responsive.isMobile(context) == true)      nWidth = MediaQuery.of(context).size.width;
  //
  //   return nWidth;
  // }


}


