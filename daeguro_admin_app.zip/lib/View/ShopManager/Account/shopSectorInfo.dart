
import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/Model/shop/shopsector_info.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopDetailNotifierData.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopSectorInfoEdit.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccount_controller.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

import 'package:get/get.dart';

class ShopSectorInfo extends StatefulWidget {
  final Stream<ShopDetailNotifierData> stream;

  const ShopSectorInfo({Key key, this.stream}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopSectorInfoState();
  }
}

class ShopSectorInfoState extends State<ShopSectorInfo> with AutomaticKeepAliveClientMixin{
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  List<ShopSectorInfoModel> dataList = <ShopSectorInfoModel>[];
  List<ShopSectorInfoModel> dataShowList = <ShopSectorInfoModel>[];
  ScrollController _scrollController;

  ShopDetailNotifierData detailData;

  bool isReceiveDataEnabled = false;

  void refreshWidget(ShopDetailNotifierData element){


    detailData = element;
    if (detailData != null) {
      //print('shopSector refreshWidget() is not NULL -> [${element.selected_shopCode}]');

      loadData();

      isReceiveDataEnabled = true;

      setState(() {
        _scrollController.jumpTo(0.0);
      });
    }
    else{
      //print('shopSector refreshWidget() is NULL');

      dataList.clear();
      dataShowList.clear();

      isReceiveDataEnabled = false;

      setState(() {
        _scrollController.jumpTo(0.0);
      });
    }

    setState(() {

    });
  }

  loadData() async {
    //await EasyLoading.show();

    dataList.clear();
    dataShowList.clear();

    await ShopController.to.getSectorData(detailData.selected_shopCode).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        value.forEach((e) async {
          ShopSectorInfoModel tempData = ShopSectorInfoModel.fromJson(e);
          dataList.add(tempData);
        });

        for (final firstEle in dataList){
          ShopSectorInfoModel newData = ShopSectorInfoModel();
          if (_getCompareData(firstEle.siguName) == false){
            newData.siguName = firstEle.siguName;
            newData.dongName = _getDongData(newData.siguName);
            dataShowList.add(newData);
          }
        }
      }
    });

    //if (this.mounted){
      setState(() {

      });
   // }
  }

  bool _getCompareData(String siguName){
    bool temp = false;
    for (final element in dataShowList){
      if (element.siguName == siguName) {
        temp = true;
        break;
      }
    }
    return temp;
  }

  String _getDongData(String siguName){
    String temp = '';
    for (final element in dataList){
      if (element.siguName == siguName) {
        temp += element.dongName+' ';
      }
    }
    return temp;
  }

  _editSector(ShopSectorInfoModel editData) async {
    //await loadDongData(formData.sidoName, formData.gunGuName);
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: ShopSectorInfoEdit(
          shopCode: detailData.selected_shopCode, sData: editData,
        ),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 500), (){
          loadData();
        });
      }
    });
  }

  @override
  void initState() {
    super.initState();

    _scrollController = ScrollController();

    // WidgetsBinding.instance.addPostFrameCallback((c) {
    //   loadData();
    // });

    //if (widget.streamIsInit == false){
      widget.stream.listen((element) {
        refreshWidget(element);
      });
    //}
  }

  @override
  void dispose() {

    _scrollController.dispose();
    dataList.clear();
    dataShowList.clear();


    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.end,
      children: <Widget>[
        ISButton(
          iconData: Icons.refresh,
          iconColor: Colors.white,
          tip: '갱신',
          onPressed: (){
            if (isReceiveDataEnabled == true){
              loadData();

              setState(() {
                _scrollController.jumpTo(0.0);
              });
            }
          },
        ),
        Container(
          child: ISButton(
              label: '배송지 추가', iconData: Icons.add,
              onPressed: () => _editSector(null)),
        ),
        SizedBox(width: 10,),
      ],
    );

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 10),
        form,
        buttonBar,
        Container(
          padding: EdgeInsets.symmetric(horizontal: 8.0),
          child: Divider(),
        ),
        Expanded(
          child: Scrollbar(
            isAlwaysShown: false,
            controller: _scrollController,
            child: ListView.builder(
              controller: _scrollController,
              padding: EdgeInsets.only(left: 10, right: 10, bottom: 20),
              itemCount: dataShowList.length,
              itemBuilder: (BuildContext context, int index) {
                return dataShowList != null ? GestureDetector(
                  // onTap: (){
                  //   Navigator.pushNamed(context, '/editor', arguments: UserController.to.userData[index]);
                  // },
                  child: Card(
                    color: Colors.white,
                    elevation: 2.0,
                    child: ListTile(
                      //leading: Text(dataList[index].siguName),
                      title: Text(dataShowList[index].siguName ?? '--', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),),
                      subtitle: Text(dataShowList[index].dongName ?? '--', style: TextStyle(fontSize: 14)),
                      trailing: PopupMenuButton(
                          onSelected: (select) async {
                            // print('selectItem: '+select.toString());//BlocProvider.of<IdeaBloc>(context)..add
                            // int nSeq= int.parse(idea['seq'].toString());
                            //
                            // selectedMenu(select, nSeq);
                            if (select == 0) {
                              _editSector(dataShowList[index]);
                            }
                            else if (select == 1){
                              List<String> sidogunguData = dataShowList[index].siguName.split(' ');
                              await ShopController.to.deleteSectorData(detailData.selected_shopCode, sidogunguData[0], sidogunguData[1], context);

                              loadData();
                            }
                          },
                          itemBuilder: (context) => <PopupMenuEntry>[
                            const PopupMenuItem(value: 0, child: Center(child: Text('수정', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),))),
                            const PopupMenuItem(value: 1, child: Center(child: Text('삭제', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),)))
                          ]
                      ),
                    ),
                  ),
                ) : Text('Data is Empty');
              },
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 8.0),
          child: Divider(),
        ),
      ],
    );
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}


