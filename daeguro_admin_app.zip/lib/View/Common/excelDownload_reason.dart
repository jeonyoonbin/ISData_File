
import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class ExcelDownloadReason extends StatefulWidget {
  const ExcelDownloadReason({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ExcelDownloadReasonState();
  }
}

class ExcelDownloadReasonState extends State<ExcelDownloadReason> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  String downloadReason = '';

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          ISInput(
            label: '다운로드 사유',
            value: downloadReason,
            autofocus: true,
            context: context,
            maxLines: 10,
            height: 250,
            maxLength: 200,
            keyboardType: TextInputType.multiline,
            onChange: (v) {
              downloadReason = v;
            },
          ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '엑셀 다운로드',
          iconData: Icons.save,
          onPressed: () {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            if(downloadReason == '' || downloadReason == null) {
              ISAlert(context, '다운로드 사유를 입력해주세요.');

              return;
            }

            Navigator.pop(context, downloadReason);
          },
        ),
        ISButton(
          label: '닫기',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('고객소리함 다운로드 사유'),
      ),
      body: Column(
        children: [
          SizedBox(height: 20),
          Container(
              padding: EdgeInsets.symmetric(horizontal: 8.0),
              child: form
          ),
        ],
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 450,
      height: 390,
      child: result,
    );
  }
}