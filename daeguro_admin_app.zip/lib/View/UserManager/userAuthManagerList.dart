import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/Model/user/userAuthManagerListModel.dart';
import 'package:daeguro_admin_app/Model/user/userListModel.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/constants/constant.dart';

import 'package:daeguro_admin_app/constants/serverInfo.dart';
import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_input.dart';
import 'package:daeguro_admin_app/Model/search_items.dart';

import 'package:daeguro_admin_app/View/AgentManager/agentAccount_Controller.dart';
import 'package:daeguro_admin_app/View/UserManager/user_controller.dart';


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:url_launcher/url_launcher.dart';

import 'dart:async';

class UserAuthManagerList extends StatefulWidget {
  const UserAuthManagerList({Key key})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return UserAuthManagerListState();
  }
}

class UserAuthManagerListState extends State<UserAuthManagerList>  with SingleTickerProviderStateMixin{
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  SearchItems _searchItems = new SearchItems();

  final ScrollController _scrollController = ScrollController();

  final List<UserListModel> dataList = <UserListModel>[];

  final List<UserAuthManagerListModel> dataAuthList = <UserAuthManagerListModel>[];

  List items = List();
  List CCenterListitems = List();
  List MCodeListitems = List();

  String _mCode = '2';

  String _level = ' ';
  String _working = ' ';
  String _idname = '';
  String _memo = '';
  int _SerchCount = 0;

  //int rowsPerPage = 10;

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  bool isCheckAll_read = false;
  bool isCheckAll_add = false;
  bool isCheckAll_save = false;
  bool isCheckAll_del = false;
  bool isCheckAll_masking = false;

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    dataList.clear();

    _searchItems = null;
    _searchItems = new SearchItems();



    //formKey.currentState.reset();
    //loadData();
  }

  _query() {

    UserController.to.level.value = _level;
    UserController.to.working.value = _working;
    UserController.to.id_name.value = _searchItems.code;
    UserController.to.memo.value = _searchItems.memo;
    UserController.to.page.value = _currentPage.round().toString();
    UserController.to.raw.value = _selectedpagerows.toString();

    loadData();
  }



  loadData() async {
    dataList.clear();
    _SerchCount = 0;
    Get.put(UserController());
    Get.put(AgentController());

    await UserController.to.getData(context, _mCode);
    await AgentController.to.getDataCCenterItems(_mCode);
    await AgentController.to.getDataMCodeItems();

    CCenterListitems = AgentController.to.qDataCCenterItems;
    MCodeListitems = AgentController.to.qDataMCodeItems;

    _scrollController.jumpTo(0.0);

    if (this.mounted) {
      setState(() {
        UserController.to.qData.forEach((e) {
          _SerchCount++;
          UserListModel temp = UserListModel.fromJson(e);
          dataList.add(temp);
        });

        _totalRowCnt = UserController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
      });
    }
  }

  loadAuthData() async {
    dataAuthList.clear();

    UserAuthManagerListModel temp = UserAuthManagerListModel();
    temp.program_id = '';
    temp.program_name = '';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    temp.defaultItem = true;

    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00001';
    temp.program_name = '회원관리 조회';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00002';
    temp.program_name = '회원관리 저장';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);    

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00003';
    temp.program_name = '회원관리 상세';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00004';
    temp.program_name = '가맹점관리 입점지원금 지급';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00005';
    temp.program_name = '가맹점관리 정산정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00006';
    temp.program_name = '가맹점관리 운영정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00007';
    temp.program_name = '가맹점관리 배달팁';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00008';
    temp.program_name = '가맹점관리 기본정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00009';
    temp.program_name = '가맹점관리 메뉴관리';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00001';
    temp.program_name = '회원관리 조회';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00002';
    temp.program_name = '회원관리 저장';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00003';
    temp.program_name = '회원관리 상세';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00004';
    temp.program_name = '가맹점관리 입점지원금 지급';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00005';
    temp.program_name = '가맹점관리 정산정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00006';
    temp.program_name = '가맹점관리 운영정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00007';
    temp.program_name = '가맹점관리 배달팁';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00008';
    temp.program_name = '가맹점관리 기본정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00009';
    temp.program_name = '가맹점관리 메뉴관리';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00001';
    temp.program_name = '회원관리 조회';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00002';
    temp.program_name = '회원관리 저장';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00003';
    temp.program_name = '회원관리 상세';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00004';
    temp.program_name = '가맹점관리 입점지원금 지급';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00005';
    temp.program_name = '가맹점관리 정산정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00006';
    temp.program_name = '가맹점관리 운영정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00007';
    temp.program_name = '가맹점관리 배달팁';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00008';
    temp.program_name = '가맹점관리 기본정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00009';
    temp.program_name = '가맹점관리 메뉴관리';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00001';
    temp.program_name = '회원관리 조회';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00002';
    temp.program_name = '회원관리 저장';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00003';
    temp.program_name = '회원관리 상세';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00004';
    temp.program_name = '가맹점관리 입점지원금 지급';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00005';
    temp.program_name = '가맹점관리 정산정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00006';
    temp.program_name = '가맹점관리 운영정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00007';
    temp.program_name = '가맹점관리 배달팁';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00008';
    temp.program_name = '가맹점관리 기본정보';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    temp = null;
    temp = UserAuthManagerListModel();
    temp.program_id = 'ISDGADM_00009';
    temp.program_name = '가맹점관리 메뉴관리';
    temp.auth_read = false;
    temp.auth_add = false;
    temp.auth_save = false;
    temp.auth_del = false;
    temp.auth_masking = false;
    dataAuthList.add(temp);

    setState(() {

    });
  }


  @override
  void initState() {
    super.initState();

    Get.put(UserController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      _query();
    });
  }

  @override
  void dispose() {
    dataList.clear();
    MCodeListitems.clear();

    _scrollController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //testSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Column(
            children: [
              ISSearchDropdown(
                label: '회원사명',
                value: _mCode,
                onChange: (value) {
                  setState(() {
                    _mCode = value;
                    _currentPage = 1;
                    _query();
                  });
                },
                width: 240,
                item: MCodeListitems.map((item) {
                  return new DropdownMenuItem<String>(
                      child: new Text(
                        item['mName'],
                        style: TextStyle(fontSize: 13, color: Colors.black),
                      ),
                      value: item['mCode']);
                }).toList(),
              ),
              SizedBox(height: 8,),
              Row(
                children: [
                  ISSearchDropdown(
                    label: '접속권한',
                    width: 120,
                    value: _level,
                    onChange: (value) {
                      setState(() {
                        _level = value;
                        _currentPage = 1;
                        formKey.currentState.save();
                        _query();
                      });
                    },
                    item: [
                      DropdownMenuItem(value: ' ', child: Text('전체'),),
                      DropdownMenuItem(value: '0', child: Text('시스템'),),
                      DropdownMenuItem(value: '1', child: Text('관리자'),),
                      DropdownMenuItem(value: '5', child: Text('영업사원'),),
                      DropdownMenuItem(value: '6', child: Text('오퍼레이터'),),
                    ].cast<DropdownMenuItem<String>>(),
                  ),
                  ISSearchDropdown(
                    label: '업무상태',
                    width: 120,
                    value: _working,
                    onChange: (value) {
                      setState(() {
                        _working = value;
                        formKey.currentState.save();
                        _currentPage = 1;
                        _query();
                      });
                    },
                    item: [
                      DropdownMenuItem(value: ' ', child: Text('전체'),),
                      DropdownMenuItem(value: '1', child: Text('재직'),),
                      DropdownMenuItem(value: '3', child: Text('휴직'),),
                      DropdownMenuItem(value: '5', child: Text('퇴직'),),
                    ].cast<DropdownMenuItem<String>>(),
                  ),
                ],
              )
            ],
          ),
          Column(
            children: [
              ISSearchInput(
                label: '아이디, 이름',
                width: 200,
                value: _searchItems.code,
                onChange: (v) {
                  _searchItems.code = v;
                },
                onFieldSubmitted: (value) {
                  _currentPage = 1;
                  _query();
                },
              ),
              SizedBox(height: 8,),
              ISSearchInput(
                label: '메모',
                width: 200,
                value: _searchItems.memo,
                onChange: (v) {
                  _searchItems.memo = v;
                },
                onFieldSubmitted: (value) {
                  _currentPage = 1;
                  _query();
                },
              ),
            ],
          ),
          Column(
            children: [
              //ISSearchButton(label: '등록', iconData: Icons.add, onPressed: () => _regist()),
              SizedBox(height: 8),
              ISSearchButton(label: '조회', iconData: Icons.search, onPressed: () => {_currentPage = 1, _query()}),
            ],
          ),
        ],
      ),
    );

    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          form,
          buttonBar,
          Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: getListMainPanelWidth(),
                height: (MediaQuery.of(context).size.height-190),
                padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
                  ],
                  color: Colors.white,
                ),
                child: Column(
                  children: [
                    ISDatatable(
                      controller: _scrollController,
                      panelHeight: (MediaQuery.of(context).size.height-255),
                      listWidth: 800,
                      //showCheckboxColumn: (widget.shopName == null) ? true : false,
                      rows: dataList.map((item) {
                        return DataRow(
                            selected: item.selected ?? false,
                            color: MaterialStateProperty.resolveWith((Set<MaterialState> states) {
                              if (item.selected == true) {
                                return Colors.grey.shade200;
                                //return Theme.of(context).colorScheme.primary.withOpacity(0.38);
                              }

                              return Theme.of(context).colorScheme.primary.withOpacity(0.00);
                            }),
                            onSelectChanged: (bool value){
                              // _selectedViewSeq = item.shopCd;
                              //
                              // nSelectedShopTitle = '[${item.shopCd}] ${item.shopName}';
                              //

                              dataList.forEach((element) {
                                element.selected = false;
                              });

                              item.selected = true;

                              _scrollController.jumpTo(0.0);

                              loadAuthData();

                              setState(() {
                              });
                            },
                            cells: [
                              DataCell(Center(child: Text(item.uCode.toString() ?? '--', style: TextStyle(color: Colors.black),))),
                              DataCell(Align(child: Text(item.id.toString() ?? '--', style: TextStyle(color: Colors.black),), alignment: Alignment.centerLeft)),
                              DataCell(Align(child: Text(item.name.toString() ?? '--', style: TextStyle(color: Colors.black),), alignment: Alignment.centerLeft)),
                              DataCell(
                                Align(
                                    child: ButtonBar(
                                      children: <Widget>[
                                        Text(_getCcName(item.ccCode.toString()) ?? '--', style: TextStyle(color: Colors.black)),
                                      ],
                                      alignment: MainAxisAlignment.start,
                                    ),
                                    alignment: Alignment.centerLeft),
                              ),
                              DataCell(Align(                        child: Text(item.memo.toString() ?? '--',                         style: TextStyle(color: Colors.black)),                       alignment: Alignment.centerLeft)),
                              DataCell(Center(
                                  child: ButtonBar(
                                    children: <Widget>[
                                      Text(_getLevel(item.level.toString()) ?? '--', style: TextStyle(color: Colors.black)),
                                    ],
                                    alignment: MainAxisAlignment.center,
                                  )),
                              ),
                              DataCell(
                                Center(
                                    child: ButtonBar(
                                      children: <Widget>[
                                        Text(_getWorking(item.working.toString()) ?? '--', style: TextStyle(color: Colors.black)),
                                      ],
                                      alignment: MainAxisAlignment.center,
                                    )),
                              ),
                              DataCell(
                                Center(
                                  child: InkWell(
                                      onTap: () {
                                        //_edit(uCode: item.uCode);
                                      },
                                      child: Icon(Icons.edit)
                                  ),
                                ),
                              ),

                            ]);
                      }).toList(),
                      columns: <DataColumn>[
                        DataColumn(label: Expanded(child: Text('사용자코드', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text('아이디', textAlign: TextAlign.left)),),
                        DataColumn(label: Expanded(child: Text('이름', textAlign: TextAlign.left)),),
                        DataColumn(label: Expanded(child: Text('대리점', textAlign: TextAlign.left)),),
                        DataColumn(label: Expanded(child: Text('메모', textAlign: TextAlign.left)),),
                        DataColumn(label: Expanded(child: Text('접속권한', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text('업무상태', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text('관리', textAlign: TextAlign.center)),),
                      ],
                    ),
                    showPagerBar(),
                  ],
                ),
              ),
              //Divider(height: 1000,),
              getDetailData(),
            ],
          ),
        ],
      ),
    );
  }

  Widget getDetailData(){
    return Container(
      width: 700,
      height: (MediaQuery.of(context).size.height-190),
      padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(color: Colors.black26, offset: Offset(2.0, 2.0), blurRadius: 4.0),
        ],
      ),
      child: ISDatatable(
        //controller: _scrollController,
        panelHeight: (MediaQuery.of(context).size.height-255),
        listWidth: 680,//Responsive.getResponsiveWidth(context, 640),
        //showCheckboxColumn: (widget.shopName == null) ? true : false,
        dataRowHeight: 30,
        rows: dataAuthList.map((item) {
          return DataRow(
              cells: [
                DataCell(Center(child: Text(item.program_id.toString() ?? '--', style: TextStyle(color: Colors.black),))),
                DataCell(Align(child: Text(item.program_name.toString() ?? '--', style: TextStyle(color: Colors.black),), alignment: Alignment.centerLeft)),
                DataCell(Center(
                    child: Checkbox(
                        checkColor: Colors.white,
                        activeColor: item.defaultItem == true ? Colors.blue : Colors.black54,
                        value: item.auth_read,
                        onChanged: (value) {
                          if (item.defaultItem == true){
                            dataAuthList.forEach((element) {
                              element.auth_read = value;
                            });
                          }
                          else {
                            item.auth_read == false ? item.auth_read = true : item.auth_read = false;

                            //isRead_CheckBoxState(item.auth_read);
                          }

                          setState(() {});
                        }
                    )
                )
                ),
                DataCell(Center(
                    child: Checkbox(
                        checkColor: Colors.white,
                        activeColor: item.defaultItem == true ? Colors.blue : Colors.black54,
                        value: item.auth_add,//this.checkAll,
                        onChanged: (value) {
                          if (item.defaultItem == true){
                            dataAuthList.forEach((element) {
                              element.auth_add = value;
                            });
                          }
                          else
                            item.auth_add == false ? item.auth_add = true : item.auth_add = false;

                          setState(() {});
                        }
                    )
                )
                ),
                DataCell(Center(
                    child: Checkbox(
                        checkColor: Colors.white,
                        activeColor: item.defaultItem == true ? Colors.blue : Colors.black54,
                        value: item.auth_save,//this.checkAll,
                        onChanged: (value) {
                          if (item.defaultItem == true){
                            dataAuthList.forEach((element) {
                              element.auth_save = value;
                            });
                          }
                          else
                            item.auth_save == false ? item.auth_save = true : item.auth_save = false;

                          setState(() {});
                        }
                    )
                )
                ),
                DataCell(Center(
                    child: Checkbox(
                        checkColor: Colors.white,
                        activeColor: item.defaultItem == true ? Colors.blue : Colors.black54,
                        value: item.auth_del,//this.checkAll,
                        onChanged: (value) {
                          if (item.defaultItem == true){
                            dataAuthList.forEach((element) {
                              element.auth_del = value;
                            });
                          }
                          else
                            item.auth_del == false ? item.auth_del = true : item.auth_del = false;

                          setState(() {});
                        }
                    )
                )
                ),
                DataCell(Center(
                    child: Checkbox(
                        checkColor: Colors.white,
                        activeColor: item.defaultItem == true ? Colors.blue : Colors.black54,
                        value: item.auth_masking,//this.checkAll,
                        onChanged: (value) {
                          if (item.defaultItem == true){
                            dataAuthList.forEach((element) {
                              element.auth_masking = value;
                            });
                          }
                          else
                            item.auth_masking == false ? item.auth_masking = true : item.auth_masking = false;

                          setState(() {});
                        }
                    )
                )
                ),
                DataCell(Center(
                  child: Container(
                    width: item.defaultItem == true ?  70 : 46,
                    child: ISButton(
                      height: 24.0,
                      label: item.defaultItem == true ?  '일괄 저장' : '저장',
                      textStyle: TextStyle(color: Colors.white, fontSize: 11),
                      onPressed: () async {
                        //loadTaxBillData('1', item.shopCd, false);
                      },
                    ),
                  ),
                )),

              ]);
        }).toList(),
        columns: <DataColumn>[
          DataColumn(label: Expanded(child: Text('프로그램ID', textAlign: TextAlign.center)),),
          DataColumn(label: Expanded(child: Text('프로그램명', textAlign: TextAlign.left)),),
          DataColumn(label: Expanded(
              child: Text('조회', textAlign: TextAlign.center),
            ),
          ),
          DataColumn(label: Expanded(
              child: Text('추가', textAlign: TextAlign.center),
            ),
          ),
          DataColumn(label: Expanded(
              child: Text('저장', textAlign: TextAlign.center)
            ),
          ),
          DataColumn(label: Expanded(
              child: Text('삭제', textAlign: TextAlign.center)
            ),
          ),
          DataColumn(label: Expanded(
              child: Text('마스킹', textAlign: TextAlign.center)
            ),
          ),
          DataColumn(label: Expanded(child: Container(
          ))
          ),
        ],
      ),
    );
  }

  Widget showPagerBar() {
    return Expanded(
        flex: 0,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 8.0),
          child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                  child: Row(
                    children: <Widget>[
                      Container(),
                      // Visibility(
                      //   visible: false,
                      //   child: Text(
                      //     '[Excel 다운로드 중입니다. 잠시만 기다려 주십시오]',
                      //     style: TextStyle(color: Colors.blue),
                      //   ),
                      // ),
                    ],
                  ),
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      InkWell(
                          onTap: () {
                            _currentPage = 1;

                            _pageMove(_currentPage);
                          },
                          child: Icon(Icons.first_page)),
                      InkWell(
                          onTap: () {
                            if (_currentPage == 1) return;

                            _pageMove(_currentPage--);
                          },
                          child: Icon(Icons.chevron_left)),
                      Container(
                        //width: 70,
                        child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                      ),
                      InkWell(
                          onTap: () {
                            if (_currentPage >= _totalPages) return;

                            _pageMove(_currentPage++);
                          },
                          child: Icon(Icons.chevron_right)),
                      InkWell(
                          onTap: () {
                            _currentPage = _totalPages;
                            _pageMove(_currentPage);
                          },
                          child: Icon(Icons.last_page))
                    ],
                  ),
                ),
                Container(
                  height: 48,
                  child: Responsive.isMobile(context) ? Container(height: 48) :  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      // Text('조회 데이터 : ', style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),),
                      // Text(ShopController.to.totalRowCnt.toString() + ' / ' + ShopController.to.total_count.toString(), style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                      // SizedBox(width: 20,),
                      Text('페이지당 행 수 : ', style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal)),
                      Container(
                        width: 70,
                        child: DropdownButton(
                            value: _selectedpagerows,
                            isExpanded: true,
                            style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: 'NotoSansKR'),
                            items: Utils.getPageRowList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedpagerows = value;
                                _currentPage = 1;
                                _query();
                              });
                            }),
                      ),
                    ],
                  ),
                ),
              ]
          ),
        )
    );
  }

  Future<void> _launchInBrowser(String shopCode) async {
    //ucode, name
    String uCode = GetStorage().read('logininfo')['uCode'];
    String uID = GetStorage().read('logininfo')['id'];

    String url = ServerInfo.OWNERSITE_URL + '/$shopCode/$uCode/$uID/Store';
    // print('launch web : ' + url);

    if (await canLaunch(url)) {
      await launch(
        url,
        forceSafariVC: false, //true로 설정시, iOS 인앱 브라우저를 통해픈
        forceWebView: false, //true로 설정시, Android 인앱 브라우저를 통해 오픈
        headers: <String, String>{'my_header_key': 'my_header_value'},
      );
    } else {
      throw 'Web Request Fail $url';
    }
  }

  String _getStatus(String value) {
    String retValue = '--';

    if (value.toString().compareTo('0') == 0)
      retValue = '대기';
    else if (value.toString().compareTo('1') == 0)
      retValue = '요청';
    else if (value.toString().compareTo('2') == 0)
      retValue = '배정';
    else if (value.toString().compareTo('3') == 0)
      retValue = '완료';
    else if (value.toString().compareTo('4') == 0) retValue = '승인';

    return retValue;
  }

  isRead_CheckBoxState(bool value){
    int compareIdx = dataAuthList.indexWhere((item) => item.auth_read != value);
    if (compareIdx != -1)
      dataAuthList[0].auth_read = !value;
  }

  double getListMainPanelWidth(){
    double nWidth = MediaQuery.of(context).size.width-1000;

    if (Responsive.isTablet(context) == true)           nWidth = nWidth + sidebarWidth;
    else if (Responsive.isMobile(context) == true)      nWidth = MediaQuery.of(context).size.width;

    return nWidth;
  }

  String getMcodeName(String mCode) {
    String temp = '';
    for (final element in MCodeListitems) {
      if (element['mCode'] == mCode) {
        temp = element['mName'];
        break;
      }
    }
    return temp;
  }

  String _getLevel(String value) {
    String retValue = '--';

    if (value.toString().compareTo('0') == 0)
      retValue = '시스템';
    else if (value.toString().compareTo('1') == 0)
      retValue = '관리자';
    else if (value.toString().compareTo('3') == 0)
      retValue = '접수자';
    else if (value.toString().compareTo('5') == 0)
      retValue = '영업사원';
    else if (value.toString().compareTo('6') == 0) retValue = '오퍼레이터';

    return retValue;
  }

  String _getWorking(String value) {
    String retValue = '--';

    if (value.toString().compareTo('1') == 0)
      retValue = '재직';
    else if (value.toString().compareTo('3') == 0)
      retValue = '휴직';
    else if (value.toString().compareTo('5') == 0) retValue = '퇴직';

    return retValue;
  }

  String _getCcName(String value) {
    String retValue = '--';

    CCenterListitems.forEach((v) {
      if (value == v['ccCode']) {
        retValue = v['ccName'];
      }
    });

    return retValue;
  }
}


