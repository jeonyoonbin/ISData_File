import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/Model/search_items.dart';
import 'package:daeguro_admin_app/Model/user/userListModel.dart';
import 'package:daeguro_admin_app/Network/BackendService.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/AuthManager/auth_controller.dart';
import 'package:daeguro_admin_app/View/UserManager/user_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:get/get.dart';

class AuthManagerAuthCopy extends StatefulWidget {
  final String mCode;
  final String mWorking;
  final String fromUcode;
  final String fromUname;

  const AuthManagerAuthCopy({Key key, this.mCode, this.mWorking, this.fromUcode, this.fromUname}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return AuthManagerAuthCopyState();
  }
}

class AuthManagerAuthCopyState extends State<AuthManagerAuthCopy> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final TextEditingController _typeAheadController = TextEditingController();

  SearchItems _searchItems = new SearchItems();
  bool isSearching = false;
  String searchKeyword = '';

  //final List<UserListModel> dataList = <UserListModel>[];

  List<SelectOptionVO> selectBox_MCodeList = [];
  List<SelectOptionVO> selectBox_UserList = [];

  List<SelectOptionVO> selectBox_WorkingList = [new SelectOptionVO(value: ' ', label: '전체'), new SelectOptionVO(value: '1', label: '재직'), new SelectOptionVO(value: '3', label: '휴직'), new SelectOptionVO(value: '5', label: '퇴직')];

  String _mCode = '1';
  String _mUCode = '';
  String _selectedUser = '';

  String _level = ' ';
  String _working = '1';

  int _totalRowCnt = 0;
  int _selectedpagerows = 9999;

  int _currentPage = 1;
  int _totalPages = 0;

  @override
  void dispose() {
    PaintingBinding.instance.imageCache.clearLiveImages();
    PaintingBinding.instance.imageCache.clear();

    super.dispose();
  }

  _reset() {
    _searchItems = null;
    _searchItems = new SearchItems();

    List MCodeListitems = Utils.getMCodeList();

    _mCode = widget.mCode;
    _working = widget.mWorking;

    MCodeListitems.forEach((element) {
      selectBox_MCodeList.add(new SelectOptionVO(value: element['mCode'], label: element['mName']));
    });

    setState(() {});
  }

  /*_query() {
    UserController.to.level.value = _level;
    UserController.to.working.value = _working;
    UserController.to.id_name.value = _searchItems.keyword;
    UserController.to.memo.value = _searchItems.memo;
    UserController.to.page.value = _currentPage.round().toString();
    UserController.to.raw.value = _selectedpagerows.toString();

    _mUCode = '';
    _selectedUser = '';

    loadUserData();
  }

  loadUserData() async {
    selectBox_UserList.clear();

    await UserController.to.getData(context, _mCode).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        selectBox_UserList.add(new SelectOptionVO(value: '', label: '--'));

        value.forEach((element) {
          UserListModel temp = UserListModel(); //.fromJson(e);          //dataList.add(temp);

          temp.uCode = element['uCode'] as String;
          temp.ccCode = element['ccCode'] as String;
          temp.id = element['id'] as String;
          temp.name = element['name'] as String;
          temp.insertDate = element['insertDate'] as String;
          temp.retireDate = element['retireDate'] as String;
          temp.level = element['level'] as String;
          temp.memo = element['memo'] as String;
          temp.working = element['working'] as String;

          selectBox_UserList.add(new SelectOptionVO(value: temp.uCode, label: '[${temp.uCode}] ${temp.name}'));
        });

        _totalRowCnt = UserController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
      }
    });

    setState(() {});
  }*/

  @override
  void initState() {
    super.initState();

    Get.put(UserController());
    Get.put(AuthController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      //_query();
    });
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: [
              Flexible(
                flex: 1,
                child: ISSelect(
                  label: '회원사',
                  value: _mCode,
                  dataList: selectBox_MCodeList,
                  onChange: (v) {
                    setState(() {
                      _mCode = v;
                      _mUCode = '';
                      _selectedUser = '';
                      disableSearching();
                      //_query();
                    });
                  },
                ),
              ),
              Flexible(
                flex: 1,
                child: ISSelect(
                  label: '업무상태',
                  value: _working,
                  dataList: selectBox_WorkingList,
                  onChange: (v) {
                    setState(() {
                      _working = v;
                      _mUCode = '';
                      _selectedUser = '';
                      disableSearching();
                      //_query();
                    });
                  },
                ),
              ),
            ],
          ),
          Container(
            height: 40,
            padding: EdgeInsets.only(left: 8, right: 8),
            child: TypeAheadFormField(
              textFieldConfiguration: TextFieldConfiguration(
                //focusNode: searchBoxFocusNode,
                cursorColor: Colors.black,
                style: TextStyle(color: Colors.black, fontSize: 13.0),
                decoration: InputDecoration(
                    fillColor: Colors.grey[100],
                    filled: true,
                    border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: const BorderRadius.all(Radius.circular(6)),
                    ),
                    hintText: '회원 검색...',
                    hintStyle: TextStyle(color: Colors.black38),
                    contentPadding: EdgeInsets.symmetric(horizontal: 14.0, vertical: 14.0),
                    suffixIcon: InkWell(
                      child: Icon(
                        Icons.cancel,
                        size: 16,
                        color: Colors.grey,
                      ),
                      onTap: () {
                        if (_typeAheadController == null /* || _typeAheadController.text.isEmpty*/) {
                          return;
                        }

                        _mUCode = '';
                        _selectedUser = '';

                        disableSearching(); //clearSearchKeyword();
                      },
                    )),
                controller: this._typeAheadController,
              ),
              suggestionsCallback: (pattern) async {
                return await BackendService.getUserSuggestions(_mCode, pattern, '', _working);
              },
              itemBuilder: (context, Map<String, String> suggestion) {
                return ListTile(
                  title: Text(
                    '[' + suggestion['uCode'] + '] ' + suggestion['name'] + ',  메모: ' + suggestion['memo'],
                    style: TextStyle(fontSize: 14),
                  ),
                  //subtitle: Text('\$${suggestion['shopCd']}'),
                );
              },
              transitionBuilder: (context, suggstionsBox, controller) {
                return suggstionsBox;
              },
              onSuggestionSelected: (Map<String, String> suggestion) async {
                //updateSearchKeyword(suggestion['shopName'].toString());
                _mUCode = suggestion['uCode'];
                _selectedUser = suggestion['name'];

                updateSearchKeyword('[' + suggestion['uCode'] + '] ' + suggestion['name'] + ',  메모: ' + suggestion['memo']);
              },
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '[${widget.fromUcode}] ${widget.fromUname}',
                  style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD, color: Colors.green),
                ),
                Text(
                  ' → ',
                  style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD),
                ),
                Text(
                  _selectedUser == '' ? '대상을 선택해 주세요' : '${_selectedUser} ',
                  style: TextStyle(fontSize: 16, fontWeight: FONT_BOLD, color: Colors.blue),
                ),
                if (_selectedUser != '')
                  Text(
                    ' 으로 권한복사',
                    style: TextStyle(fontSize: 16),
                  ),
              ],
            ),
          )
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
            label: '복사',
            iconData: Icons.copy,
            textStyle: TextStyle(color: Colors.white),
            iconColor: Colors.white,
            onPressed: () async {
              if (_selectedUser == null || _selectedUser == '') {
                ISAlert(context, '대상을 선택해 주세요.');
                return;
              }

              String confrimComment = '원본: [${widget.fromUcode}] ${widget.fromUname}  → 대상: ${_selectedUser}\n\n';

              ISConfirm(context, '권한 복사', '${confrimComment}\n 권한을 복사 하시겠습니까?', (context) async {
                Navigator.pop(context);

                AuthController.to.putAdminAuthCopy(widget.fromUcode, _mUCode).then((value) async {
                  if (value != null) {
                    Navigator.pop(context);

                    ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                  } else {
                    Navigator.pop(context, true);

                    ISAlert(context, '권한 복사가 완료되었습니다..');
                  }
                });
              });
            }),
        ISButton(
          label: '닫기',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('사용자 권한 복사'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 16),
            Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 460,
      height: 270,
      child: result,
    );
  }

  void disableSearching() {
    clearSearchKeyword();

    setState(() {
      isSearching = false;
    });
  }

  void clearSearchKeyword() {
    setState(() {
      _typeAheadController.clear();
      updateSearchKeyword('');
    });
  }

  void updateSearchKeyword(String newKeyword) {
    setState(() {
      searchKeyword = newKeyword;
      _typeAheadController.text = searchKeyword;
    });
  }
}
