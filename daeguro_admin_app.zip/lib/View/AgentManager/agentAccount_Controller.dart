﻿
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/Provider/RestApiProvider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AgentController extends GetxController with SingleGetTickerProviderMixin{
  static AgentController get to => Get.find();
  BuildContext context;

  List<dynamic> qData = [];
  dynamic qDataDetail;
  List qDataCCenterItems = [];
  List qDataMCodeItems = [];
  //List<ResponseBodyApi> qData;

  RxString MCode = ''.obs;

  @override
  void onInit(){
    Get.put(RestApiProvider());

    //getData();

    super.onInit();
  }

  getData(String mCode) async {
    var result = await RestApiProvider.to.getAgent(mCode);

    qData.assignAll(result.body['data']);

    if (result.body['code'] != '00') {
      ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  getDataCCenterItems(String mCode) async {
    qDataCCenterItems.clear();

    var result = await RestApiProvider.to.getAgentCode(mCode);

    qDataCCenterItems.assignAll(result.body['data']);

    if (result.body['code'] != '00') {
      ISAlert(context, '콜센터정보를 가져오지 못했습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  getDataMCodeItems() async {
    qDataMCodeItems.clear();

    var result = await RestApiProvider.to.getMembershipCode();

    qDataMCodeItems.assignAll(result.body['data']);

    if (result.body['code'] != '00') {
      ISAlert(context, '회원사정보를 가져오지 못했습니다. \n\n관리자에게 문의 바랍니다');
    }

    return result.body['data'];
  }

  getDetailData(String ccCode) async {
    var result = await RestApiProvider.to.getAgentDetail(ccCode);

    qDataDetail = result.body['data'];
    //qDataDetail.assign(result.body['data']);

    if (result.body['code'] != '00') {
      ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  postData(Map data, BuildContext context) async {
    var result = await RestApiProvider.to.postAgent(data);

    if (result.body['code'] != '00') {
      ISAlert(context, '정상적으로 저장 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }
}