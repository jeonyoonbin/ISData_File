﻿import 'dart:convert';
import 'dart:typed_data';

import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/constants/serverInfo.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:image/image.dart' as Im;
import 'package:flutter/foundation.dart' show compute;

//curl -X POST "http://172.16.10.65:5000/Shop/PostFiles?shop_cd=1&kind=20" -H  "accept: */*" -H  "Content-Type: multipart/form-data" -F "files=@logo.png;type=image/png" -F "files=@logo2.png;type=image/png"

class FileUpLoadProvider extends ChangeNotifier {
  //static const String PROVIDER_REST_BASEURL = "https://dgpub.282.co.kr:8500"; ///0411 - REST_BASEURL이 /api로 변경됨에따라 추가하였습니다.

  String type;
  var src;
  var responseData;

  Future setResource(String type, src) async {
    this.type = type;
    this.src = src;
    this.notifyListeners();
  }

  Future makeShopMenuPutResourceRequest(String ccCode, String shopCode, String menuCode, BuildContext context) async {
    var headers = {};
    String mURL = ServerInfo.REST_URL_IMAGE + '?menu_cd=$menuCode&cccode=$ccCode&shop_cd=$shopCode';

    var uri = Uri.parse(mURL);

    // print('menu upload type['+ this.type+']:'+mURL);
    // if (this.src == null){
    //   print('resource is NULL');
    // }
    // else
    //   print('resource path -> '+this.src.path);

    var request = http.MultipartRequest('PUT', uri);
    //request.headers.addAll(headers);

    if (type == 'image') {
      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();
    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
      if(responseData['code'] != '00')
      {
        ISAlert(context, '이미지 등록에 실패 했습니다. \n\n관리자에게 문의 바랍니다');
      }
    });
  }

  Future makeRepImagePostResourceRequest(String div, String ccCode, String shopCode, BuildContext context) async {
    var headers = {};

    String uCode = GetStorage().read('logininfo')['uCode'];
    String uName = GetStorage().read('logininfo')['name'];

    String mURL = ServerInfo.REST_URL_IMAGE + '?div=$div&cccode=$ccCode&shop_cd=$shopCode&salesmanCode=$uCode&salesmanName=$uName';

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('POST', uri);

    if (type == 'image') {
      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();

      if (div == '4'){
        request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));
      }
      else{
        Im.Image image = await compressImage(list);
        request.files.add(http.MultipartFile.fromBytes('formFile', Im.encodeJpg(image, quality: 100), filename: 'upload_temp.png'));
      }
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();
    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
      if(responseData['code'] != '00') {
        //print('--- code[${responseData['code']}] msg: ${responseData['msg']}');
        ISAlert(context, '이미지 등록에 실패 했습니다. \n\n관리자에게 문의 바랍니다');
      }
    });
  }

  static Future<Im.Image> compressImage(List<int> list) async {
    return compute(_decodeImage, list);
  }

  static Im.Image _decodeImage(List<int> list) {
    Im.Image retImage = null;

    Im.Image image = Im.decodeImage(list);
    //print('original_image w:${image.width}, h:${image.height}, length:${image.length}');
    if (image.width > 1280) {
      retImage = Im.copyResize(image, width: 1280); // choose the size here, it will maintain aspect ratio
      //print('resize_image w:${retImage.width}, h:${retImage.height}, length:${retImage.length}');
    }
    else
      retImage = image;

    return retImage;
  }

  Future makeNoticePostResourceRequest(String noticeGbn, String systemGbn, String noticeType, String dispGbn, String dispFromDate, String dispToDate, String dispFromTimeH, String dispFromTimeM, String dispToTimeH, String dispToTimeM, String noticeTitle, String noticeContents, String noticeUrl_1, String noticeUrl_2, String orderDate, String insDate, String insUCode, String insName, String extUrlYn, BuildContext context) async {
    String mURL;

    ServerInfo.jobMode == 'dev' ?
    mURL = 'https://ext.daeguro.co.kr:45010/api/Notice'
        : mURL = ServerInfo.REST_URL_NOTICE;

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('POST', uri);

    request.headers.addAll({'Content-Type' : 'application/x-www-form-urlencoded'});

    request.fields['noticeGbn'] = noticeGbn;
    request.fields['systemGbn'] = systemGbn;
    request.fields['noticeType'] = noticeType;
    request.fields['dispGbn'] = dispGbn;
    request.fields['dispFromDate'] = dispFromDate;
    request.fields['dispToDate'] = dispToDate;
    request.fields['dispFromTimeH'] = dispFromTimeH;
    request.fields['dispFromTimeM'] = dispFromTimeM;
    request.fields['dispToTimeH'] = dispToTimeH;
    request.fields['dispToTimeM'] = dispToTimeM;
    request.fields['noticeTitle'] = noticeTitle;
    request.fields['noticeContents'] = noticeContents;
    request.fields['noticeUrl_1'] = noticeUrl_1 ?? '';
    request.fields['noticeUrl_2'] = noticeUrl_2;
    request.fields['orderDate'] = orderDate;
    request.fields['insDate'] = insDate;
    request.fields['insUCode'] = insUCode;
    request.fields['insName'] = insName;
    request.fields['extUrlYn'] = extUrlYn;

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          // print('event: ' + event);
          //request.files.add(null);
          responseData = json.decode(event);

          if(responseData['code'] == '00'){
            Navigator.pop(context, true);
          } else {
            ISAlert(context, responseData['msg']);
          }
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();
    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);

      if(responseData['code'] == '00'){
        Navigator.pop(context, true);
      } else {
        ISAlert(context, responseData['msg']);
      }
    });
  }

  //REST_URL_NOTICEFILE

  Future makeNoticePutResourceRequest(String noticeSeq, String noticeType, String noticeGbn, String systemGbn, String dispGbn, String dispFromDate, String dispToDate, String dispFromTimeH, String dispFromTimeM, String dispToTimeH, String dispToTimeM, String noticeTitle, String noticeContents, String noticeUrl_1, String noticeUrl_2, String orderDate, String modUcode, String modName, String extUrlYn, BuildContext context) async {
    String mURL;

    ServerInfo.jobMode == 'dev' ?
    mURL = 'https://ext.daeguro.co.kr:45010/api/Notice'
        : mURL = ServerInfo.REST_URL_NOTICE;

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('PUT', uri);

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    request.fields['noticeSeq'] = noticeSeq;
    request.fields['noticeType'] = noticeType;
    request.fields['noticeGbn'] = noticeGbn;
    request.fields['systemGbn'] = systemGbn;
    request.fields['dispGbn'] = dispGbn;
    request.fields['dispFromDate'] = dispFromDate;
    request.fields['dispToDate'] = dispToDate;
    request.fields['dispFromTimeH'] = dispFromTimeH;
    request.fields['dispFromTimeM'] = dispFromTimeM;
    request.fields['dispToTimeH'] = dispToTimeH;
    request.fields['dispToTimeM'] = dispToTimeM;
    request.fields['noticeTitle'] = noticeTitle;
    request.fields['noticeContents'] = noticeContents;
    request.fields['noticeUrl_1'] = noticeUrl_1 ?? '';
    request.fields['noticeUrl_2'] = noticeUrl_2;
    request.fields['orderDate'] = orderDate;
    request.fields['modUCode'] = modUcode;
    request.fields['modName'] = modName;
    request.fields['extUrlYn'] = extUrlYn;

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          // print('event: ' + event);
          //request.files.add(null);
          responseData = json.decode(event);

          if(responseData['code'] == '00'){
            Navigator.pop(context, true);
          } else {
            ISAlert(context, responseData['msg']);
          }
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);

      if(responseData['code'] == '00'){
        Navigator.pop(context, true);
      } else {
        ISAlert(context, responseData['msg']);
      }
    });
  }

  Future makeReserNoticePostResourceRequest(String noticeGbn, String dispGbn, String dispFromDate, String dispToDate, String noticeTitle, String noticeContents, String noticeUrl_2, String orderDate, String insDate, String insUCode, String insName) async {
    String mURL = ServerInfo.REST_RESERVEURL + '/notice';

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('POST', uri);

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    request.fields['noticeGbn'] = noticeGbn;
    request.fields['dispGbn'] = dispGbn;
    request.fields['dispFrDate'] = dispFromDate;
    request.fields['dispToDate'] = dispToDate;
    request.fields['title'] = noticeTitle;
    request.fields['contents'] = noticeContents;
    request.fields['url2'] = noticeUrl_2;
    request.fields['orderDate'] = orderDate;
    request.fields['ucode'] = insDate;
    request.fields['userName'] = insUCode;
    request.fields['insDate'] = insName;

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          // print('event: ' + event);
          //request.files.add(null);
          responseData = json.decode(event);
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('file', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    }

    var response = await request.send();
    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
      //print(response.statusCode);
    });
  }

  Future makeReserNoticePutResourceRequest(String noticeSeq, String noticeGbn, String dispGbn, String dispFromDate, String dispToDate, String noticeTitle, String noticeContents, String noticeUrl_1, String noticeUrl_2, String orderDate, String modUcode, String modName) async {
    String mURL = ServerInfo.REST_RESERVEURL + '/notice';

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('PUT', uri);

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    request.fields['noticeSeq'] = noticeSeq;
    request.fields['noticeGbn'] = noticeGbn;
    request.fields['dispGbn'] = dispGbn;
    request.fields['dispFrDate'] = dispFromDate;
    request.fields['dispToDate'] = dispToDate;
    request.fields['title'] = noticeTitle;
    request.fields['contents'] = noticeContents;
    request.fields['url2'] = noticeUrl_2;
    request.fields['orderDate'] = orderDate;
    request.fields['ucode'] = modUcode;
    request.fields['userName'] = modName;

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();

        response.stream.bytesToString().asStream().listen((event) {
          //request.files.add(null);
          // print('event: ' + event);
          responseData = json.decode(event);
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('file', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
    });
  }

  // Future makeReserShopImagePostResourceRequest(String ccCode, String shopCode, String imageType) async {
  //
  //   String mURL = ServerInfo.REST_RESERVEURL+'/shopPicture/insert';//'https://reser.daeguro.co.kr:10018/notice';
  //
  //   var uri = Uri.parse(mURL);
  //
  //   var request = http.MultipartRequest('PUT', uri);
  //
  //   //request.headers.addAll({'Content-Type' : 'application/x-www-form-urlencoded'});
  //   request.headers.addAll({'Content-Type' : 'multipart/form-data'});
  //
  //   request.fields['ccCode'] = ccCode;
  //   request.fields['shopCode'] = shopCode;
  //   request.fields['temaCode'] = imageType;
  //
  //   if (type == 'image') {
  //     if (src == null) {
  //       var response = await request.send();
  //       response.stream.bytesToString().asStream().listen((event) {
  //         // print('event: ' + event);
  //         responseData = json.decode(event);
  //       });
  //
  //       return;
  //     }
  //
  //     Uint8List data = await this.src.readAsBytes();
  //     List<int> list = data.cast();
  //     request.files.add(http.MultipartFile.fromBytes('file', list, filename: 'upload_temp.png'));
  //   }
  //   else if (type == 'file') {
  //     var bytes = src.files.first.bytes;
  //     String filename = src.files.first.name;
  //
  //     request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
  //   }
  //
  //   var response = await request.send();
  //
  //   response.stream.bytesToString().asStream().listen((event) {
  //     responseData = json.decode(event);
  //   });
  // }

  Future makeReserShopReviewPostResourceRequest(String ccCode, String shopCode, String seq) async {
    String mURL = ServerInfo.REST_RESERVEURL + '/reviewImage/insert'; //'https://reser.daeguro.co.kr:10018/notice';

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('PUT', uri);

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    request.fields['ccCode'] = ccCode;
    request.fields['shopCode'] = shopCode;
    request.fields['seq'] = seq;
    //request.fields['userId'] = GetStorage().read('logininfo')['uCode'];

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          // print('event: ' + event);
          responseData = json.decode(event);
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('file', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
    });
  }

  Future makeReserThemeMainPostResourceRequest(String temaCode) async {
    String mURL = ServerInfo.REST_RESERVEURL + '/temaImage/insert'; //'https://reser.daeguro.co.kr:10018/notice';

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('PUT', uri);

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    request.fields['temaCode'] = temaCode;

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          // print('event: ' + event);
          responseData = json.decode(event);
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();

      Im.Image image = await checkThemeGroupImageSize(list);

      if (image == null) {
        return '0';
      }

      request.files.add(http.MultipartFile.fromBytes('file', Im.encodeJpg(image, quality: 100), filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
    });
  }

  Future makeReserThemeSubPostResourceRequest(String temaCode, int subTemaCode) async {
    String mURL = ServerInfo.REST_RESERVEURL + '/subTemaImage/insert'; //'https://reser.daeguro.co.kr:10018/notice';

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('PUT', uri);

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    request.fields['temaCode'] = temaCode;
    request.fields['subTemaCode'] = subTemaCode.toString();

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          // print('event: ' + event);
          responseData = json.decode(event);
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();

      Im.Image image = await checkSubThemeImageSize(list);

      if (image == null) {
        return '0';
      }

      request.files.add(http.MultipartFile.fromBytes('file', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
    });
  }

  Future makeOrderThemeSubPostResourceRequest(String temaCode, String subTemaCode) async {
    String uCode = GetStorage().read('logininfo')['uCode'];

    String mURL = ServerInfo.REST_BASEURL + '/subTemaImage/insert?temaCode=$temaCode&subTemaCode=$subTemaCode&ucode=$uCode';//
    //String mURL = 'https://ext.daeguro.co.kr:45010/api/subTemaImage/insert?temaCode=$temaCode&subTemaCode=$subTemaCode&ucode=$uCode'; // 인터넷망 테스트 업로드

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('PUT', uri);

    request.headers.addAll({'Content-Type': 'multipart/form-data'});

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          // print('event: ' + event);
          responseData = json.decode(event);
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
    });
  }

  Future makeTaxiPostCompBannerRequest(String idUsrIns, String nmUsrIns, String cdComp, String subject, String dtStart, String dtEnd, String ynOpen, String urlLink) async {
    String mURL = ServerInfo.REST_TAXI_COMPBANNER;

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('POST', uri);

    request.headers.addAll({'key': 'xjbMVWTEdlq2bUc4aGhW+g=='});
    request.headers.addAll({'Content-Type': 'multipart/form-data'});

    request.fields['idUsrIns'] = idUsrIns;
    request.fields['nmUsrIns'] = nmUsrIns;
    request.fields['cdComp'] = cdComp;
    request.fields['subject'] = subject;
    request.fields['dtStart'] = dtStart;
    request.fields['dtEnd'] = dtEnd;
    request.fields['ynOpen'] = ynOpen;
    request.fields['urlLink'] = urlLink;

    if (type == 'image') {
      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('file', list, filename: 'upload_temp.png'));
    } else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
      //print(response.statusCode);
    });
  }

  Future makeTaxiPutCompBannerRequest(String idUsrIns, String nmUsrIns, String cdComp, String seqDisp, String subject, String dtStart, String dtEnd, String ynOpen, String urlLink) async {
    String mURL = ServerInfo.REST_TAXI_COMPBANNER;

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('PUT', uri);

    request.headers.addAll({'key': 'xjbMVWTEdlq2bUc4aGhW+g=='});
    request.headers.addAll({'Content-Type': 'multipart/form-data'});

    request.fields['idUsrIns'] = idUsrIns;
    request.fields['nmUsrIns'] = nmUsrIns;
    request.fields['cdComp'] = cdComp;
    request.fields['seqDisp'] = seqDisp;
    request.fields['subject'] = subject;
    request.fields['dtStart'] = dtStart;
    request.fields['dtEnd'] = dtEnd;
    request.fields['ynOpen'] = ynOpen;
    request.fields['urlLink'] = urlLink;

    if (type == 'image') {
      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('file', list, filename: 'upload_temp.png'));
    } else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
      //print(response.statusCode);
    });
  }

  Future makeTaxiPostWebBoardRequest(
      String idUsrIns,
      String nmUsrIns,
      String idBoard,
      String subject,
      String contHtml,
      String contText,
      String ynOpen,
      String dtStart,
      String dtEnd,) async {

    String mURL = ServerInfo.REST_TAXI_WEBBOARDLIST;

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('POST', uri);

    request.headers.addAll({'key': 'xjbMVWTEdlq2bUc4aGhW+g=='});
    request.headers.addAll({'Content-Type': 'multipart/form-data'});

    request.fields['idUsrIns'] = idUsrIns;
    request.fields['nmUsrIns'] = nmUsrIns;
    request.fields['idBoard'] = idBoard;
    request.fields['subject'] = subject;
    request.fields['contHtml'] = contHtml;
    request.fields['contText'] = contText;
    request.fields['ynOpen'] = ynOpen;
    request.fields['dtStart'] = dtStart;
    request.fields['dtEnd'] = dtEnd;

    if (type == 'image') {
      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('imgCont1', list, filename: 'upload_temp.png'));
    } else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('imgCont1', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
      //print(response.statusCode);
    });
  }

  Future makeTaxiPutWebBoardRequest(String idUsrIns, String nmUsrIns, String ipIns, String seqBoard, String noParent, String noThread, String noDepth, String idBoard, String divBoard, String cdComp, String cdCust, String dtOrdno, String seqOrdno, String nmSector, String subject, String contHtml, String contText, String ynOpen, String dtStart, String dtEnd, String noPwd) async {
    String mURL = ServerInfo.REST_TAXI_WEBBOARDLIST;

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('PUT', uri);

    request.headers.addAll({'key': 'xjbMVWTEdlq2bUc4aGhW+g=='});
    request.headers.addAll({'Content-Type': 'multipart/form-data'});

    request.fields['idUsrIns'] = idUsrIns;
    request.fields['nmUsrIns'] = nmUsrIns;
    request.fields['ipIns'] = ipIns;
    request.fields['seqBoard'] = seqBoard;
    request.fields['noParent'] = noParent;
    request.fields['noThread'] = noThread;
    request.fields['noDepth'] = noDepth;
    request.fields['idBoard'] = idBoard;
    request.fields['divBoard'] = divBoard;
    request.fields['cdComp'] = cdComp;
    request.fields['cdCust'] = cdCust;
    request.fields['dtOrdno'] = dtOrdno;
    request.fields['seqOrdno'] = seqOrdno;
    request.fields['nmSector'] = nmSector;
    request.fields['subject'] = subject;
    request.fields['contHtml'] = contHtml;
    request.fields['contText'] = contText;
    request.fields['ynOpen'] = ynOpen;
    request.fields['dtStart'] = dtStart;
    request.fields['dtEnd'] = dtEnd;
    request.fields['noPwd'] = noPwd;

    if (type == 'image') {
      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('imgCont1', list, filename: 'upload_temp.png'));
    } else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('imgCont1', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
      //print(response.statusCode);
    });
  }

  Future makeShopInfoPostResourceRequest(String div, String intro_cd, String sort, BuildContext context) async {
    String _uCode = GetStorage().read('logininfo')['uCode'];
    String _uName = GetStorage().read('logininfo')['name'];

    String mURL;

    mURL = ServerInfo.jobMode == 'dev'
        ? 'https://ext.daeguro.co.kr:45010/api/Intro/setShopInfoImage?div=$div&intro_cd=$intro_cd&sort=$sort&ucode=$_uCode&uname=$_uName'
        : ServerInfo.REST_BASEURL + '/Intro/setShopInfoImage?div=$div&intro_cd=$intro_cd&sort=$sort&ucode=$_uCode&uname=$_uName';

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('PUT', uri);

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          // print('event: ' + event);
          responseData = json.decode(event);

          if(responseData['code'] != '00'){
            ISAlert(context, responseData['msg']);
          }
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));

      // Im.Image image = await compressImage(list);
      // request.files.add(http.MultipartFile.fromBytes('formFile', Im.encodeJpg(image, quality: 100), filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);

      print(responseData);

      if(responseData['code'] != '00'){
        ISAlert(context, responseData['msg']);
      }
    });
  }

  static Future<Im.Image> checkThemeGroupImageSize(List<int> list) async {
    return compute(_checkThemeGroupImageSize, list);
  }

  static Im.Image _checkThemeGroupImageSize(List<int> list) {
    Im.Image image = Im.decodeImage(list);

    if (image.width > 570 || image.height > 345) {
      return null;
    }

    return image;
  }

  static Future<Im.Image> checkSubThemeImageSize(List<int> list) async {
    return compute(_checkSubThemeImageSize, list);
  }

  static Im.Image _checkSubThemeImageSize(List<int> list) {
    Im.Image image = Im.decodeImage(list);

    if (image.width > 200 || image.height > 200) {
      return null;
    }

    return image;
  }

  Future makeVoucherPostCardImageRequest(String img_code, String type_gbn, String use_gbn, String category_cd, String img_url, String memo, String ucode, BuildContext context) async {
    String mURL;

    mURL = ServerInfo.jobMode == 'dev'
        ? 'https://ext.daeguro.co.kr:45010/api/Voucher/updateImg'
        : ServerInfo.REST_URL_VOUCHER_CARDIMAGE_UPDATE;

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('POST', uri);

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    request.fields['img_code'] = img_code;
    request.fields['type_gbn'] = type_gbn;
    request.fields['use_gbn'] = use_gbn;
    request.fields['category_cd'] = category_cd;
    request.fields['img_url'] = img_url;
    request.fields['memo'] = memo;
    request.fields['ucode'] = ucode;

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          // print('event: ' + event);
          //request.files.add(null);
          responseData = json.decode(event);

          if(responseData['code'] == '00'){
            Navigator.pop(context, true);
          } else {
            ISAlert(context, responseData['msg']);
          }
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);

      if(responseData['code'] == '00'){
        Navigator.pop(context, true);
      } else {
        ISAlert(context, responseData['msg']);
      }
    });
  }

  Future makeVoucherPostCardSetImageRequest(String img_code, String type_gbn, String use_gbn, String category_cd, String img_url, String memo, String ucode, BuildContext context) async {
    String mURL;

    mURL = ServerInfo.jobMode == 'dev'
        ? 'https://ext.daeguro.co.kr:45010/api/Voucher/setImg'
        : ServerInfo.REST_URL_VOUCHER_CARDIMAGE_SET;

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('POST', uri);

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    request.fields['img_code'] = img_code;
    request.fields['type_gbn'] = type_gbn;
    request.fields['use_gbn'] = use_gbn;
    request.fields['category_cd'] = category_cd;
    request.fields['img_url'] = img_url;
    request.fields['memo'] = memo;
    request.fields['ucode'] = ucode;

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          // print('event: ' + event);
          //request.files.add(null);
          responseData = json.decode(event);

          if(responseData['code'] == '00'){
            Navigator.pop(context, true);
          } else {
            ISAlert(context, responseData['msg']);
          }
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);

      if(responseData['code'] == '00'){
        Navigator.pop(context, true);
      } else {
        ISAlert(context, responseData['msg']);
      }
    });
  }

  Future makeMenuMultiImagePostResourceRequest(String cccode, String shop_cd, String menu_cd, BuildContext context) async {
    var headers = {};

    String uCode = GetStorage().read('logininfo')['uCode'];
    String uName = GetStorage().read('logininfo')['name'];

    String mURL;
    ServerInfo.jobMode == 'dev' ?
    mURL = 'https://ext.daeguro.co.kr:45010/api/MenuMulti?cccode=$cccode&shop_cd=$shop_cd&menu_cd=$menu_cd&ucode=$uCode&uname=$uName'
    : mURL = ServerInfo.REST_URL_MENU_MULTI_IMAGE + '?cccode=$cccode&shop_cd=$shop_cd&menu_cd=$menu_cd&ucode=$uCode&uname=$uName';

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('POST', uri);

    if (type == 'image') {
      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();
    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
      if(responseData['code'] != '00') {
        ISAlert(context, '이미지 등록에 실패 했습니다. \n\n${responseData['msg']}');
      }
    });
  }

  Future makeMenuMultiImagePutResourceRequest(String cccode, String shop_cd, String seq, BuildContext context) async {
    var headers = {};

    String uCode = GetStorage().read('logininfo')['uCode'];
    String uName = GetStorage().read('logininfo')['name'];

    String mURL;
    ServerInfo.jobMode == 'dev' ?
    mURL = 'https://ext.daeguro.co.kr:45010/api/MenuMulti?cccode=$cccode&shop_cd=$shop_cd&seq=$seq&ucode=$uCode&uname=$uName'
        : mURL = ServerInfo.REST_URL_MENU_MULTI_IMAGE + '?cccode=$cccode&shop_cd=$shop_cd&seq=$seq&ucode=$uCode&uname=$uName';

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('PUT', uri);

    if (type == 'image') {
      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();
    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);
      if(responseData['code'] != '00') {
        ISAlert(context, '이미지 등록에 실패 했습니다. \n\n${responseData['msg']}');
      }
    });
  }

  Future makeVoucherCodePostResourceRequest(String group_cd, String use_yn, String voucher_name, String promotion_yn, String budget, String disc_gbn, String disc_range, String voucher_amt, String voucher_notice, String memo, String ucode, BuildContext context) async {
    String mURL;

    ServerInfo.jobMode == 'dev' ?
    mURL = 'https://ext.daeguro.co.kr:45010/api/Voucher/setCode'
        : mURL = ServerInfo.REST_URL_VOUCHER_CODE_SET;

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('POST', uri);

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    request.fields['group_cd'] = group_cd;
    request.fields['use_yn'] = use_yn;
    request.fields['voucher_name'] = voucher_name;
    request.fields['promotion_yn'] = promotion_yn;
    request.fields['budget'] = budget;
    request.fields['disc_gbn'] = disc_gbn;
    request.fields['disc_range'] = disc_range;
    request.fields['voucher_amt'] = voucher_amt;
    request.fields['voucher_notice'] = voucher_notice;
    request.fields['memo'] = memo;
    request.fields['ucode'] = ucode;

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          //print('event: ' + event);
          //request.files.add(null);
          responseData = json.decode(event);

          if(responseData['code'] == '00'){
            Navigator.pop(context, true);
          } else {
            ISAlert(context, responseData['msg']);
          }
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);

      if(responseData['code'] == '00'){
        Navigator.pop(context, true);
      } else {
        ISAlert(context, responseData['msg']);
      }
    });
  }

  Future makeVoucherCodePutResourceRequest(String seqno, String group_cd, String use_yn, String voucher_type, String voucher_name, String promotion_yn, String budget, String disc_gbn, String disc_range, String voucher_amt, String voucher_notice, String memo, String ucode, BuildContext context) async {
    String mURL;

    ServerInfo.jobMode == 'dev' ?
    mURL = 'https://ext.daeguro.co.kr:45010/api/Voucher/updateCode'
        : mURL = ServerInfo.REST_URL_VOUCHER_CODE_UPDATE;

    var uri = Uri.parse(mURL);

    var request = http.MultipartRequest('PUT', uri);

    request.headers.addAll({'Content-Type': 'application/x-www-form-urlencoded'});

    request.fields['seqno'] = seqno;
    request.fields['group_cd'] = group_cd;
    request.fields['use_yn'] = use_yn;
    request.fields['voucher_type'] = voucher_type;
    request.fields['voucher_name'] = voucher_name;
    request.fields['promotion_yn'] = promotion_yn;
    request.fields['budget'] = budget;
    request.fields['disc_gbn'] = disc_gbn;
    request.fields['disc_range'] = disc_range;
    request.fields['voucher_amt'] = voucher_amt;
    request.fields['voucher_notice'] = voucher_notice;
    request.fields['memo'] = memo;
    request.fields['ucode'] = ucode;

    if (type == 'image') {
      if (src == null) {
        var response = await request.send();
        response.stream.bytesToString().asStream().listen((event) {
          //print('event: ' + event);
          //request.files.add(null);
          responseData = json.decode(event);

          if(responseData['code'] == '00'){
            Navigator.pop(context, true);
          } else {
            ISAlert(context, responseData['msg']);
          }
        });

        return;
      }

      Uint8List data = await this.src.readAsBytes();
      List<int> list = data.cast();
      request.files.add(http.MultipartFile.fromBytes('formFile', list, filename: 'upload_temp.png'));
    }
    else if (type == 'file') {
      var bytes = src.files.first.bytes;
      String filename = src.files.first.name;

      request.files.add(http.MultipartFile.fromBytes('formFile', bytes, filename: filename));
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      responseData = json.decode(event);

      if(responseData['code'] == '00'){
        Navigator.pop(context, true);
      } else {
        ISAlert(context, responseData['msg']);
      }
    });
  }
}
