import 'package:daeguro_admin_app/Network/DioClient.dart';
import 'package:dio/dio.dart';

class DioClientTaxi {
  //static DioClient get to => Get.find();
  //static String default_ContentType = 'text/plain';

  static Map<String, dynamic> Header_Taxi = {
    "Access-Control-Allow-Origin": "*",
    // Required for CORS support to work
    "Access-Control-Allow-Headers": "*",
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Methods": "*",
    "Content-Type": "application/json",
    "accept": "application/json",
    "apikey": "T9kPeSeKb1DuAZbx3rfHJA==",
  };

  final Dio _dio = Dio(BaseOptions(connectTimeout: 5000, receiveTimeout: 5000, headers: Header_Taxi));

  Future<dynamic> get(String value) async {
    Response result = null;
    try {
      result = await _dio.get(value);
    } on DioError catch (e) {
      if (e.response != null) {
        await DioClient().postRestLog('0', '/DioClientTaxi/get',
            '[Dio Error] response is Not NULL \n\nError Msg: Status:${e.response?.statusCode}  DATA: ${e.response?.data} HEADERS: ${e.response?.headers} \n\nParam: ${value} ');
      } else {
        await DioClient().postRestLog('0', '/DioClientTaxi/get', '[Dio Error] response is NULL \n\nError Msg: ${e.message} \n\nParam: ${value} ');
      }
    }

    _dio.clear();
    _dio.close();

    return result;
  }
}