import 'dart:async';

import 'package:daeguro_admin_app/View/CouponManager/coupon_controller.dart';
import 'package:daeguro_admin_app/View/ShopManager/Account/shopAccount_controller.dart';
import 'package:daeguro_admin_app/View/UserManager/user_controller.dart';

class BackendService {
  static Future<List<Map<String, String>>> getCopyMenuShopSuggestions(String mCode, String keyword) async {
    List<Map<String, String>> tempList = new List<Map<String, String>>();

    await ShopController.to.getShopNameListData(mCode, keyword).then((value) {
      value.forEach((element) {
          Map<String, String> nData = {'ccCode': element['ccCode'].toString(), 'shopCd': element['shopCd'].toString(), 'shopName': element['shopName'].toString()};
          tempList.add(nData);
      });
    });

    return tempList;
  }

  static Future<List<Map<String, String>>> getCopyBrandSuggestions(String test_yn, String keyword) async {
    List<Map<String, String>> tempList = new List<Map<String, String>>();

    await CouponController.to.getBrandNameListData(test_yn, keyword).then((value) {
      value.forEach((element) {
        Map<String, String> nData = {'code': element['code'].toString(), 'name': element['name'].toString(), 'use_gbn': element['use_gbn'].toString()};
        tempList.add(nData);
      });
    });

    return tempList;
  }

  static Future<List<Map<String, String>>> getUserSuggestions(String mcode, String keyword, String ucode) async {
    List<Map<String, String>> tempList = new List<Map<String, String>>();

    await UserController.to.getUserNameListData(mcode, keyword, ucode).then((value) {
      value.forEach((element) {
        Map<String, String> nData = {'uCode': element['uCode'].toString(), 'name': element['name'].toString(), 'memo': element['memo'].toString()};
        tempList.add(nData);
      });
    });

    return tempList;
  }

  // static Future<List<Map<String, String>>> getMenuNameSuggestions(String shopCode, String keyword) async {
  //   List<Map<String, String>> tempList = new List<Map<String, String>>();
  //
  //   await ShopController.to.getMenuNameListData(shopCode, keyword).then((value) {
  //     value.forEach((element) {
  //       // Map<String, String> nData = {'ccCode': element['ccCode'].toString(), 'shopCd': element['shopCd'].toString(), 'shopName': element['shopName'].toString()};
  //       // tempList.add(nData);
  //     });
  //   });
  //
  //   return tempList;
  // }
}


