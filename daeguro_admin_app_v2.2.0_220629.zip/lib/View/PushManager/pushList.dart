import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/Model/pushListModel.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/PushManager/pushSendRegist.dart';
import 'package:daeguro_admin_app/View/PushManager/push_controller.dart';
import 'package:daeguro_admin_app/constants/constant.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

List items = List();

class PushList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return PushListState();
  }
}

class PushListState extends State {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<PushListModel> dataList = <PushListModel>[];

  String _pushKeyword = ' ';

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    //loadData();
  }

  _edit({String noticeSeq}) async {
    // noticeEmListModel editData = null;
    //
    // await NoticeController.to.getEmDetailData(noticeSeq.toString()).then((value) {
    //   if (value == null) {
    //     ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    //   } else {
    //     editData = noticeEmListModel.fromJson(value);
    //   }
    // });
    //
    // showDialog(
    //   context: context,
    //   builder: (BuildContext context) => Dialog(
    //     child: NoticeEmEdit(sData: editData),
    //   ),
    // ).then((v) async {
    //   if (v != null) {
    //     await Future.delayed(Duration(milliseconds: 500), (){
    //       _query();
    //     });
    //   }
    // });
  }

  _regist() async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: PushSendRegist(),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 500), () {
          loadData();
        });
      }
    });
  }

  _query() {
    formKey.currentState.save();

    PushController.to.page.value = _currentPage;
    PushController.to.raw.value = _selectedpagerows;
    loadData();
  }

  loadData() async {
    dataList.clear();

    // await NoticeController.to.getEmData(_pushKeyword).then((value) {
    //   if (value == null) {
    //     ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    //   } else {
    //     value.forEach((e) {
    //       noticeEmListModel temp = noticeEmListModel.fromJson(e);
    //       dataList.add(temp);
    //     });
    //
    //     _totalRowCnt = NoticeController.to.totalRowCnt;
    //     _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
    //   }
    // });

    PushListModel temp = PushListModel();
    temp.seq = '1';
    temp.title = '2022년 6월 이벤트';
    temp.sendType = '0';
    temp.startDate = '2022.06.10 13:20:00';
    temp.sendDataType = '1';
    temp.dataTarget = '1';
    temp.countSuccess = '652';
    temp.countTarget = '1000';
    temp.log = '작업중입니다.';
    temp.status = '20';

    dataList.add(temp);

    temp = PushListModel();
    temp.seq = '2';
    temp.title = '2022년 7월 이벤트';
    temp.sendType = '1';
    temp.startDate = '2022.06.10 13:20:00';
    temp.sendDataType = '0';
    temp.dataTarget = '0';
    temp.countSuccess = '145';
    temp.countTarget = '630';
    temp.log = '작업중입니다.';
    temp.status = '10';

    dataList.add(temp);

    temp = PushListModel();
    temp.seq = '3';
    temp.title = '2022년 8월 이벤트';
    temp.sendType = '0';
    temp.startDate = '2022.06.10 13:20:00';
    temp.sendDataType = '2';
    temp.dataTarget = '2';
    temp.countSuccess = '412';
    temp.countTarget = '702';
    temp.log = '작업중입니다.';
    temp.status = '30';

    dataList.add(temp);

    //if (this.mounted) {
    setState(() {

    });
    //}
  }

  @override
  void initState() {
    super.initState();

    Get.put(PushController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _reset();
      _query();
    });

    setState(() {
    });
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //testSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Row(
            children: [
              Text('총: ${Utils.getCashComma(PushController.to.totalRowCnt.toString())}건', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
            ],
          ),
          Row(
            children: [
              Column(
                children: [
                  ISSearchDropdown(
                    label: '검색조건',
                    width: 120,
                    value: _pushKeyword,
                    onChange: (value) {
                      setState(() {
                        _pushKeyword = value;
                        _currentPage = 1;
                        _query();
                      });
                    },
                    item: [
                      DropdownMenuItem(value: ' ', child: Text('전체'),),
                      DropdownMenuItem(value: '0', child: Text('제목'),),
                      DropdownMenuItem(value: '1', child: Text('상태'),),
                    ].cast<DropdownMenuItem<String>>(),
                  ),
                ],
              ),
              SizedBox(width: 8,),
              Row(
                children: [
                  ISSearchButton(
                      width: 80,
                      label: '조회',
                      iconData: Icons.search,
                      onPressed: () => {_currentPage = 1, _query()}),
                  SizedBox(width: 8,),
                  if (AuthUtil.isAuthCreateEnabled('241') == true)
                    ISSearchButton(
                        width: 80,
                        label: '발송', iconData: Icons.add, onPressed: () => _regist()),
                ],
              )
            ],
          )
        ],
      ),
    );

    return Container(
      //padding: EdgeInsets.only(left: 140, right: 140, bottom: 0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          form,
          buttonBar,
          Divider(),
          ISDatatable(
            panelHeight: (MediaQuery.of(context).size.height-defaultContentsHeight),
            listWidth: Responsive.getResponsiveWidth(context, 640), // Responsive.isTablet(context) ? MediaQuery.of(context).size.width : contentListWidth,
            rows: dataList.map((item) {
              return DataRow(cells: [
                DataCell(Center(child: SelectableText(item.seq.toString() ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(Align(child: SelectableText(item.title.toString() ?? '--', style: TextStyle(color: Colors.black), showCursor: true),alignment: Alignment.centerLeft)),
                DataCell(Center(child: SelectableText(_getPushSendType(item.sendType.toString()) ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(Center(child: SelectableText(item.startDate.toString() ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(Center(child: SelectableText(_getPushSendDataType(item.sendDataType.toString()) ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(Center(child: SelectableText(_getPushSendTargetUser(item.dataTarget.toString()), style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SelectableText(item.countSuccess.toString(), style: TextStyle(color: Colors.black, fontSize: 12), showCursor: true),
                        Text('/'),
                        SelectableText(item.countTarget.toString(), style: TextStyle(color: Colors.black, fontSize: 12), showCursor: true),
                      ],
                    ),
                  ),
                ),
                DataCell(Center(child: SelectableText(item.log.toString() ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(Center(child: SelectableText(_getPushStatus(item.status.toString()) ?? '--', style: TextStyle(color: Colors.black), showCursor: true))),
                DataCell(
                  Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        MaterialButton(
                          height: Responsive.isDesktop(context) == true ? 34.0 : 30.0,
                          color: Colors.redAccent,
                          minWidth: 40,
                          child: Text('중지',style: TextStyle(color: Colors.white, fontSize: 12),),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                          onPressed: () async {
                            // if (AuthUtil.isAuthEditEnabled('101') == false) {
                            //   ISAlert(context, '처리 권한이 없습니다. \n\n관리자에게 문의 바랍니다');
                            //   return;
                            // }
                            //
                            // ISConfirm(context, '입점지원금 지급', '입점지원금을 지급 하시겠습니까?', (context) async {
                            //   await ShopController.to.postChargeJoin(item.shopCd, GetStorage().read('logininfo')['uCode'], context).then((value) {
                            //     _query();
                            //     Navigator.of(context).pop();
                            //   });
                            // });
                          },
                        ),
                        SizedBox(width: 8,),
                        MaterialButton(
                          height: Responsive.isDesktop(context) == true ? 34.0 : 30.0,
                          color: Colors.green,
                          minWidth: 40,
                          child: Text('수정',style: TextStyle(color: Colors.white, fontSize: 12),),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                          onPressed: () async {
                            // if (AuthUtil.isAuthEditEnabled('101') == false) {
                            //   ISAlert(context, '처리 권한이 없습니다. \n\n관리자에게 문의 바랍니다');
                            //   return;
                            // }
                            //
                            // ISConfirm(context, '입점지원금 지급', '입점지원금을 지급 하시겠습니까?', (context) async {
                            //   await ShopController.to.postChargeJoin(item.shopCd, GetStorage().read('logininfo')['uCode'], context).then((value) {
                            //     _query();
                            //     Navigator.of(context).pop();
                            //   });
                            // });
                          },
                        ),
                        SizedBox(width: 8,),
                        MaterialButton(
                          height: Responsive.isDesktop(context) == true ? 34.0 : 30.0,
                          color: Colors.black38,
                          minWidth: 40,
                          child: Text('삭제',style: TextStyle(color: Colors.white, fontSize: 12),),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                          onPressed: () async {
                            // if (AuthUtil.isAuthEditEnabled('101') == false) {
                            //   ISAlert(context, '처리 권한이 없습니다. \n\n관리자에게 문의 바랍니다');
                            //   return;
                            // }
                            //
                            // ISConfirm(context, '입점지원금 지급', '입점지원금을 지급 하시겠습니까?', (context) async {
                            //   await ShopController.to.postChargeJoin(item.shopCd, GetStorage().read('logininfo')['uCode'], context).then((value) {
                            //     _query();
                            //     Navigator.of(context).pop();
                            //   });
                            // });
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ]);
            }).toList(),
            columns: <DataColumn>[
              DataColumn(label: Expanded(child: Text('번호', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('제목', textAlign: TextAlign.left)),),
              DataColumn(label: Expanded(child: Text('발송방식', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('시작일시', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('대상', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('발송범위', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('성공/대상 건수', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('로그', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('상태', textAlign: TextAlign.center)),),
              DataColumn(label: Expanded(child: Text('관리', textAlign: TextAlign.center)),),
            ],
          ),
          Divider(),
          showPagerBar(),
        ],
      ),
    );
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                //Text('row1'),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(), style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context) ? Container(height: 48) : Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Text('페이지당 행 수 : ', style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),),
                Container(
                  width: 70,
                  child: DropdownButton(
                      value: _selectedpagerows,
                      isExpanded: true,
                      style: TextStyle(
                          fontSize: 12,
                          color: Colors.black,
                          fontFamily: 'NotoSansKR'),
                      items: Utils.getPageRowList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedpagerows = value;
                          _currentPage = 1;
                          _query();
                        });
                      }),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _getPushSendType(String value) {
    String retValue = '--';

    if (value.toString().compareTo('0') == 0)      retValue = '즉시';
    else if (value.toString().compareTo('1') == 0) retValue = '예약';

    return retValue;
  }

  String _getPushSendDataType(String value) {
    String retValue = '--';

    if (value.toString().compareTo('0') == 0)      retValue = 'DB';
    else if (value.toString().compareTo('1') == 0) retValue = 'CSV';

    return retValue;
  }

  String _getPushSendTargetUser(String value) {
    String retValue = '--';

    if (value.toString().compareTo('0') == 0)      retValue = '회원만';
    else if (value.toString().compareTo('1') == 0) retValue = '전체회원';
    else if (value.toString().compareTo('2') == 0) retValue = '비회원';

    return retValue;
  }

  String _getPushSendTarget(String value) {
    String retValue = '--';

    if (value.toString().compareTo('0') == 0)      retValue = '마케팅 동의만';
    else if (value.toString().compareTo('1') == 0) retValue = '전체';

    return retValue;
  }

  String _getPushStatus(String value) {
    String retValue = '--';

    if (value.toString().compareTo('10') == 0)        retValue = '대기';
    else if (value.toString().compareTo('20') == 0)   retValue = '발송중';
    else if (value.toString().compareTo('30') == 0)   retValue = '중지';
    else if (value.toString().compareTo('40') == 0)   retValue = '완료';

    return retValue;
  }
}
