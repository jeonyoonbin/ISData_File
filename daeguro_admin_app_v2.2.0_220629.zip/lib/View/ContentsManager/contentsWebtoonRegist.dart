import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/is_select_date.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsRegistModel.dart';
import 'package:daeguro_admin_app/Model/coupon/couponRegistModel.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contents_controller.dart';
import 'package:daeguro_admin_app/View/CouponManager/coupon_controller.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ContentsWebtoonRegist extends StatefulWidget {
  const ContentsWebtoonRegist({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ContentsWebtoonRegistState();
  }
}

class ContentsWebtoonRegistState extends State<ContentsWebtoonRegist> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  ContentsRegistModel formData;
  String _expDate = '';

  List<SelectOptionVO> selectBox_couponType = List();
  List<SelectOptionVO> selectBox_couponItem = List();

  @override
  void initState() {
    super.initState();

    Get.put(CouponController());

    formData = ContentsRegistModel();

    formData.cartegory_gbn = 'A';
    formData.disp_gbn = 'Y';
  }

  @override
  void dispose() {
    selectBox_couponType.clear();

    selectBox_couponType = null;
    formData = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: Container(
                  margin: EdgeInsets.all(8.0),
                  decoration: new BoxDecoration(color: formData.disp_gbn == 'Y' ? Colors.blue[200] : Colors.red[200], borderRadius: new BorderRadius.circular(6)),
                  child: SwitchListTile(
                    dense: true,
                    value: formData.disp_gbn == 'Y' ? true : false,
                    title: Text(
                      '게시 유무',
                      style: TextStyle(fontSize: 10, color: Colors.white),
                    ),
                    onChanged: (v) {
                      setState(() {
                        formData.disp_gbn = v ? 'Y' : 'N';
                        formKey.currentState.save();
                      });
                    },
                  ),
                ),
              ),
              // Flexible(
              //   flex: 1,
              //   child: Container(),
              // ),
            ],
          ),
          ISInput(
            autofocus: true,
            value: formData.contents_title,
            label: '제목',
            onSaved: (v) {
              formData.contents_title = v;
            },
          ),
          ISInput(
            autofocus: true,
            value: formData.main_url,
            label: 'URL',
            onSaved: (v) {
              formData.main_url  = v;
            },
          ),
          ISInput(
            autofocus: true,
            value: formData.url_title,
            label: '메인 링크 제목',
            onSaved: (v) {
              formData.url_title = v;
            },
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Flexible(
                flex: 1,
                child: Container(
                  child: ISInput(
                    height: 64,
                    value: formData.emoji_code,
                    maxLength: 5,
                    label: '이모지 코드',
                    onSaved: (v) {
                      formData.emoji_code = v;
                    },
                  ),
                ),
              ),
              Flexible(
                flex: 2,
                child: Container(
                    margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                    alignment: Alignment.topLeft,
                    child: Text('※ 이모지 코드 앞부분 "U+" 는 제외하고 입력 바랍니다\n예) U+1F61C (X) ,  1F61C (O)', style: TextStyle(fontSize: 11, color: Colors.redAccent))),
              )
            ],
          ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            form.save();

            formData.emoji_code = formData.emoji_code.replaceAll('U+', '');

            formData.ins_ucode = GetStorage().read('logininfo')['uCode'];
            //formData.startDate = _startDate;
            ContentsController.to.postContents(formData.toJson(), context);

            Navigator.pop(context, true);
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('웹툰 컨텐츠 등록'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10),
            Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );

    return SizedBox(
      width: 480,
      height: 420,
      child: result,
    );
  }
}
