import 'package:daeguro_admin_app/ISWidget/is_datatable.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_button.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/Model/reservation/reserveFAQListModel.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/Layout/responsive.dart';
import 'package:daeguro_admin_app/View/NoticeManager/notice_controller.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reservationmanager_controller.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reserveFAQEdit.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reserveFAQRegist.dart';
import 'package:daeguro_admin_app/constants/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

List items = List();

class ReserveFAQList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return ReserveFAQListState();
  }
}

class ReserveFAQListState extends State {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final List<ReserveFAQListModel> dataList = <ReserveFAQListModel>[];

  String _faqGbn = 'ALL';

  int _totalRowCnt = 0;
  int _selectedpagerows = 15;

  int _currentPage = 1;
  int _totalPages = 0;

  void _pageMove(int _page) {
    _query();
  }

  _reset() {
    //loadData();
  }

  _edit({String gbn, String answer, String question, int seq}) async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: ReserveFAQEdit(gbn: gbn, seq: seq, answer: answer, question: question),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 300), () {
          _query();
          setState(() {});
        });
      }
    });
  }

  _regist() async {
    showDialog(
      context: context,
      builder: (BuildContext context) => Dialog(
        child: ReserveFAQRegist(),
      ),
    ).then((v) async {
      if (v != null) {
        await Future.delayed(Duration(milliseconds: 300), () {
          loadData();
        });
      }
    });
  }

  _query() {
    formKey.currentState.save();

    loadData();
  }

  loadData() async {
    dataList.clear();

    await ReservationController.to.getReserveFAQList(_faqGbn).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        value.forEach((e) {
          ReserveFAQListModel temp = ReserveFAQListModel.fromJson(e);
          temp.insertDate = temp.insertDate.substring(0, 8) + 'T' + temp.insertDate.substring(8) + '00';

          if (temp.modDate != '') {
            temp.modDate = temp.modDate.substring(0, 8) + 'T' + temp.modDate.substring(8) + '00';
          }

          dataList.add(temp);
        });

        _totalRowCnt = NoticeController.to.totalRowCnt;
        _totalPages = (_totalRowCnt / _selectedpagerows).ceil();
      }
    });

    //if (this.mounted) {
    setState(() {});
    //}
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReservationController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      _query();
    });
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          //testSearchBox(),
        ],
      ),
    );

    var buttonBar = Expanded(
      flex: 0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Row(
            children: [
              Column(
                children: [
                  Row(
                    children: [
                      ISSearchDropdown(
                        label: 'FAQ 구분',
                        width: 100,
                        value: _faqGbn,
                        onChange: (value) {
                          setState(() {
                            _faqGbn = value;
                            _currentPage = 1;
                            _query();
                          });
                        },
                        item: [
                          DropdownMenuItem(
                            value: 'ALL',
                            child: Text('전체'),
                          ),
                          DropdownMenuItem(
                            value: '1',
                            child: Text('주문/결제'),
                          ),
                          DropdownMenuItem(
                            value: '2',
                            child: Text('회원정보'),
                          ),
                          DropdownMenuItem(
                            value: '3',
                            child: Text('이용문의'),
                          ),
                        ].cast<DropdownMenuItem<String>>(),
                      ),
                    ],
                  )
                ],
              ),
              SizedBox(
                width: 8,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (AuthUtil.isAuthReadEnabled('238') == true)
                      ISSearchButton(width: 80, label: '조회', iconData: Icons.search, onPressed: () => {_currentPage = 1, _query()}),
                      SizedBox(
                        width: 8,
                      ),
                      if (AuthUtil.isAuthCreateEnabled('238') == true) ISSearchButton(width: 80, label: '등록', iconData: Icons.add, onPressed: () => _regist()),
                    ],
                  )
                ],
              ),
            ],
          )
        ],
      ),
    );

    return Container(
      //padding: EdgeInsets.only(left: 140, right: 140, bottom: 0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          form,
          buttonBar,
          Divider(),
          ISDatatable(
            panelHeight: (MediaQuery.of(context).size.height - defaultContentsHeight),
            listWidth: Responsive.getResponsiveWidth(context, 640), // Responsive.isTablet(context) ? MediaQuery.of(context).size.width : contentListWidth,
            rows: dataList.map((item) {
              return DataRow(cells: [
                DataCell(Center(
                    child: Text(
                  item.seq.toString() ?? '--',
                  style: TextStyle(color: Colors.black),
                ))),
                DataCell(Center(child: Text(_getFAQGBN(item.gbn.toString()) ?? '--', style: TextStyle(color: Colors.black)))),
                DataCell(Align(
                    child: Text(
                      item.question.toString() ?? '--',
                      style: TextStyle(color: Colors.black),
                    ),
                    alignment: Alignment.centerLeft)),
                DataCell(
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SelectableText(item.insertId.toString() == '' ? '등록자: --' : '등록자: ${item.insertId.toString()}',
                            style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                        SelectableText(item.insertDate.toString() == '' ? '등록일: --' : '등록일: ${DateTime.parse(item.insertDate).toString().replaceAll(':00.000', '')}',
                            style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                      ],
                    ),
                  ),
                ),
                DataCell(
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SelectableText(item.modId.toString() == '' ? '수정자: --' : '수정자: ${item.modId.toString()}',
                            style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                        SelectableText(item.modDate.toString() == '' ? '수정일: --' : '수정일: ${DateTime.parse(item.modDate).toString().replaceAll(':00.000', '')}',
                            style: TextStyle(color: Colors.black, fontSize: 10), showCursor: true),
                      ],
                    ),
                  ),
                ),
                DataCell(
                  Center(
                    child: InkWell(
                        onTap: () {
                          _edit(gbn: item.gbn.toString(), answer: item.answer, question: item.question, seq: item.seq);
                        },
                        child: Icon(Icons.edit)),
                  ),
                ),
              ]);
            }).toList(),
            columns: <DataColumn>[
              DataColumn(
                label: Expanded(child: Text('순번', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('구분', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('질문내용', textAlign: TextAlign.left)),
              ),
              DataColumn(
                label: Expanded(child: Text('등록정보', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('수정정보', textAlign: TextAlign.center)),
              ),
              DataColumn(
                label: Expanded(child: Text('관리', textAlign: TextAlign.center)),
              ),
            ],
          ),
          Divider(),
          showPagerBar(),
        ],
      ),
    );
  }

  Container showPagerBar() {
    return Container(
      //padding: const EdgeInsets.only(left: 20.0, right: 20.0),
      child: Row(
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Row(
              children: <Widget>[
                //Text('row1'),
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                InkWell(
                    onTap: () {
                      _currentPage = 1;

                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.first_page)),
                InkWell(
                    onTap: () {
                      if (_currentPage == 1) return;

                      _pageMove(_currentPage--);
                    },
                    child: Icon(Icons.chevron_left)),
                Container(
                  //width: 70,
                  child: Text(_currentPage.toInt().toString() + ' / ' + _totalPages.toString(),
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                ),
                InkWell(
                    onTap: () {
                      if (_currentPage >= _totalPages) return;

                      _pageMove(_currentPage++);
                    },
                    child: Icon(Icons.chevron_right)),
                InkWell(
                    onTap: () {
                      _currentPage = _totalPages;
                      _pageMove(_currentPage);
                    },
                    child: Icon(Icons.last_page))
              ],
            ),
          ),
          Flexible(
            flex: 1,
            child: Responsive.isMobile(context)
                ? Container(height: 48)
                : Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      Text(
                        '페이지당 행 수 : ',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),
                      ),
                      Container(
                        width: 70,
                        child: DropdownButton(
                            value: _selectedpagerows,
                            isExpanded: true,
                            style: TextStyle(fontSize: 12, color: Colors.black, fontFamily: 'NotoSansKR'),
                            items: Utils.getPageRowList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedpagerows = value;
                                _currentPage = 1;
                                _query();
                              });
                            }),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  String _getFAQGBN(String value) {
    String retValue = '--';

    if (value.toString().compareTo('1') == 0)
      retValue = '주문/결제';
    else if (value.toString().compareTo('2') == 0)
      retValue = '회원정보';
    else if (value.toString().compareTo('3') == 0) retValue = '이용문의';
    return retValue;
  }
}
