import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ContentsListModel {
  ContentsListModel();

  bool viewSelected = false;
  int RNUM;
  int CONTENTS_CD;
  String CONTENTS_TITLE;
  String DISP_GBN;
  int DISP_SEQ;
  String INS_DATE;
  int INS_UCODE;

  factory ContentsListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ContentsListModel _$ModelFromJson(Map<String, dynamic> json) {
  return ContentsListModel()
    ..viewSelected = json['viewSelected'] as bool
    ..RNUM = json['RNUM'] as int
    ..CONTENTS_CD = json['CONTENTS_CD'] as int
    ..CONTENTS_TITLE = json['CONTENTS_TITLE'] as String
    ..DISP_GBN = json['DISP_GBN'] as String
    ..DISP_SEQ = json['DISP_SEQ'] as int
    ..INS_DATE = json['INS_DATE'] as String
    ..INS_UCODE = json['INS_UCODE'] as int;
}

Map<String, dynamic> _$ModelToJson(ContentsListModel instance) => <String, dynamic>{
  'viewSelected': instance.viewSelected,
  'RNUM': instance.RNUM,
  'CONTENTS_CD': instance.CONTENTS_CD,
  'CONTENTS_TITLE': instance.CONTENTS_TITLE,
  'DISP_GBN': instance.DISP_GBN,
  'DISP_SEQ': instance.DISP_SEQ,
  'INS_DATE': instance.INS_DATE,
  'INS_UCODE': instance.INS_UCODE
};
