import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class PushListModel {
  PushListModel();

  bool selected = false;
  String seq;
  String title;
  String sendType;
  String startDate;
  String sendDataType;
  String dataTarget;
  String countSuccess;
  String countTarget;
  String log;
  String status;

  factory PushListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

PushListModel _$ModelFromJson(Map<String, dynamic> json) {
  return PushListModel()
    ..selected = json['selected'] as bool
    ..seq = json['seq'] as String
    ..title = json['title'] as String
    ..sendType = json['sendType'] as String
    ..startDate = json['startDate'] as String
    ..sendDataType = json['sendDataType'] as String
    ..dataTarget = json['dataTarget'] as String
    ..countSuccess = json['countSuccess'] as String
    ..countTarget = json['countTarget'] as String
    ..log = json['log'] as String
    ..status = json['status'] as String;
}

Map<String, dynamic> _$ModelToJson(PushListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'seq': instance.seq,
  'title': instance.title,
  'sendType': instance.sendType,
  'startDate': instance.startDate,
  'sendDataType': instance.sendDataType,
  'dataTarget': instance.dataTarget,
  'countSuccess': instance.countSuccess,
  'countTarget': instance.countTarget,
  'log': instance.log,
  'status': instance.status,
};
