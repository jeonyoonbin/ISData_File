


class ImageUploadModel{
  bool isUploaded;
  bool uploading;
  var imageFile;
  String imageUrl;

  ImageUploadModel({
    this.isUploaded,
    this.uploading,
    this.imageFile,
    this.imageUrl,
  });
}