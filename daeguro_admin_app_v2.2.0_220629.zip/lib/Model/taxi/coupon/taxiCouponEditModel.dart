import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
// ignore: camel_case_types
class taxiCouponEditModel {
  taxiCouponEditModel();

  String idUsrUpd;
  String nmUsrUpd;
  int cdComp;
  String cdCoup;
  String idConfUsr;
  String nmConfUsr;
  int cntCoup;

  factory taxiCouponEditModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

taxiCouponEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return taxiCouponEditModel()
    ..idUsrUpd = json['idUsrUpd'] as String
    ..nmUsrUpd = json['nmUsrUpd'] as String
    ..cdComp = json['cdComp'] as int
    ..cdCoup = json['cdCoup'] as String
    ..idConfUsr = json['idConfUsr'] as String
    ..nmConfUsr = json['nmConfUsr'] as String
    ..cntCoup = json['cntCoup'] as int;
}

Map<String, dynamic> _$ModelToJson(taxiCouponEditModel instance) => <String, dynamic>{
  'idUsrUpd': instance.idUsrUpd,
  'nmUsrUpd': instance.nmUsrUpd,
  'cdComp': instance.cdComp,
  'cdCoup': instance.cdCoup,
  'idConfUsr': instance.idConfUsr,
  'nmConfUsr': instance.nmConfUsr,
  'cntCoup': instance.cntCoup
};