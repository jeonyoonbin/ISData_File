import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ContentsSubRegistModel {
  ContentsSubRegistModel();

  bool viewSelected = false;
  String contents_cd;
  String episode;
  String ep_title;
  String disp_gbn;
  String contents_url;
  String thumbnail_url;
  String ins_ucode;
  String mod_ucode;

  factory ContentsSubRegistModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ContentsSubRegistModel _$ModelFromJson(Map<String, dynamic> json) {
  return ContentsSubRegistModel()
    ..viewSelected = json['viewSelected'] as bool
    ..contents_cd = json['contents_cd'] as String
    ..episode = json['episode'] as String
    ..ep_title = json['ep_title'] as String
    ..disp_gbn = json['disp_gbn'] as String
    ..contents_url = json['contents_url'] as String
    ..thumbnail_url = json['thumbnail_url'] as String
    ..ins_ucode = json['ins_ucode'] as String
    ..mod_ucode = json['mod_ucode'] as String;
}

Map<String, dynamic> _$ModelToJson(ContentsSubRegistModel instance) => <String, dynamic>{
  'viewSelected': instance.viewSelected,
  'contents_cd': instance.contents_cd,
  'episode': instance.episode,
  'ep_title': instance.ep_title,
  'disp_gbn': instance.disp_gbn,
  'contents_url': instance.contents_url,
  'thumbnail_url': instance.thumbnail_url,
  'ins_ucode': instance.ins_ucode,
  'mod_ucode': instance.mod_ucode,
};
