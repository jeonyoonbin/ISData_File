import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiCompDocRegistModel {
  TaxiCompDocRegistModel();

  bool selected = false;
  String idUsrIns = '';
  String nmUsrIns = '';
  int cdComp = 0;
  String oper = '';
  String terms = '';
  String privacy = '';
  String personal = '';
  String consign = '';
  String third = '';
  String loc = '';
  String epay = '';
  String etax = '';
  String push = '';
  String join = '';
  String termsCalc = '';

  factory TaxiCompDocRegistModel.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiCompDocRegistModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiCompDocRegistModel()
    ..selected = json['selected'] as bool
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..cdComp = json['cdComp'] as int
    ..oper = json['oper'] as String
    ..terms = json['terms'] as String
    ..privacy = json['privacy'] as String
    ..personal = json['personal'] as String
    ..consign = json['consign'] as String
    ..third = json['third'] as String
    ..loc = json['loc'] as String
    ..epay = json['epay'] as String
    ..etax = json['etax'] as String
    ..push = json['push'] as String
    ..join = json['join'] as String
    ..termsCalc = json['termsCalc'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiCompDocRegistModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'idUsrIns': instance.idUsrIns,
  'nmUsrIns': instance.nmUsrIns,
  'cdComp': instance.cdComp,
  'oper': instance.oper,
  'terms': instance.terms,
  'privacy': instance.privacy,
  'personal': instance.personal,
  'consign': instance.consign,
  'third': instance.third,
  'loc': instance.loc,
  'epay': instance.epay,
  'etax': instance.etax,
  'push': instance.push,
  'join': instance.join,
  'termsCalc': instance.termsCalc
};
