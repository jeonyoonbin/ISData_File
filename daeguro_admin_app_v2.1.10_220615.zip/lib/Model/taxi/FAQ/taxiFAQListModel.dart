import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiFAQListModel {
  TaxiFAQListModel();

  bool selected = false;
  bool viewSelected;
  String seqBoard;
  String noParent;
  String noThread;
  String noDepth;
  String divSubBoard;
  String divSubBoardText;
  String ynOpen;
  String subject;
  String idUsrIns;
  String nmUsrIns;
  String dtmIns;

  factory TaxiFAQListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiFAQListModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiFAQListModel()

    ..selected = json['selected'] as bool
    ..viewSelected = json['viewSelected'] as bool
    ..seqBoard = json['seqBoard'] as String
    ..noParent = json['noParent'] as String
    ..noThread = json['noThread'] as String
    ..noDepth = json['noDepth'] as String
    ..divSubBoard = json['divSubBoard'] as String
    ..divSubBoardText = json['divSubBoardText'] as String
    ..ynOpen = json['ynOpen'] as String
    ..subject = json['subject'] as String
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..dtmIns = json['dtmIns'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiFAQListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'viewSelected': instance.viewSelected,
  'seqBoard': instance.seqBoard,
  'noParent': instance.noParent,
  'noThread': instance.noThread,
  'noDepth': instance.noDepth,
  'divSubBoard': instance.divSubBoard,
  'divSubBoardText': instance.divSubBoardText,
  'ynOpen': instance.ynOpen,
  'subject': instance.subject,
  'idUsrIns': instance.idUsrIns,
  'nmUsrIns': instance.nmUsrIns,
  'dtmIns': instance.dtmIns
};