import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiFAQDetailModel {
  TaxiFAQDetailModel();

  bool selected = false;
  bool viewSelected;
  String seqBoard;
  String noParent;
  String noThread;
  String noDepth;
  String divSubBoard;
  String divSubBoardText;
  String idUsrIns;
  String nmUsrIns;
  String dtmIns;
  String ynOpen;
  String subject;
  String contText;

  factory TaxiFAQDetailModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiFAQDetailModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiFAQDetailModel()

    ..selected = json['selected'] as bool
    ..viewSelected = json['viewSelected'] as bool
    ..seqBoard = json['seqBoard'] as String
    ..noParent = json['noParent'] as String
    ..noThread = json['noThread'] as String
    ..noDepth = json['noDepth'] as String
    ..divSubBoard = json['divSubBoard'] as String
    ..divSubBoardText = json['divSubBoardText'] as String
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..dtmIns = json['dtmIns'] as String
    ..ynOpen = json['ynOpen'] as String
    ..subject = json['subject'] as String
    ..contText = json['contText'] as String;

}

Map<String, dynamic> _$ModelToJson(TaxiFAQDetailModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'viewSelected': instance.viewSelected,
  'seqBoard': instance.seqBoard,
  'noParent': instance.noParent,
  'noThread': instance.noThread,
  'noDepth': instance.noDepth,
  'divSubBoard': instance.divSubBoard,
  'divSubBoardText': instance.divSubBoardText,
  'idUsrIns': instance.idUsrIns,
  'nmUsrIns': instance.nmUsrIns,
  'dtmIns': instance.dtmIns,
  'ynOpen': instance.ynOpen,
  'subject': instance.subject,
  'contText': instance.contText
};