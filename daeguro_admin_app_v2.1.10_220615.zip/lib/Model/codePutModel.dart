import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CodePutModel {
  CodePutModel();

  String codeGrp;
  String code;
  String codeName;
  String memo = '';
  String amt1 = '0.0';
  String amt2 = '0.0';
  String amt3 = '0.0';
  String amt4 = '0.0';
  String gbn1 = '';//쿠폰 이미지로고
  String gbn3 = '';//쿠폰 배경색
  String value1 = '';
  String value2 = '';
  String value3 = '';
  String value4 = '';
  String value5 = '';
  String etc_code1 = '';
  String useGbn = '';
  String testYn = '';
  String etc_code2; // QR 코드 사용날짜 기한
  String etc_code3 = ''; // QR 여부
  String insUCode = ''; // 대구
  String insName;
  String modUCode;
  String modName;
  String pubGbn;

  factory CodePutModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

CodePutModel _$ModelFromJson(Map<String, dynamic> json) {
  return CodePutModel()
    ..codeGrp = json['codeGrp'] as String
    ..code = json['code'] as String
    ..codeName = json['codeName'] as String
    ..memo = json['memo'] as String
    ..amt1 = json['amt1'] as String
    ..amt2 = json['amt2'] as String
    ..amt3 = json['amt3'] as String
    ..amt4 = json['amt4'] as String
    ..gbn1 = json['gbn1'] as String
    ..gbn3 = json['gbn3'] as String
    ..value1 = json['value1'] as String
    ..value2 = json['value2'] as String
    ..value3 = json['value3'] as String
    ..value4 = json['value4'] as String
    ..value5 = json['value5'] as String
    ..etc_code1 = json['etc_code1'] as String
    ..useGbn = json['useGbn'] as String
    ..testYn = json['testYn'] as String
    ..etc_code2 = json['etc_code2'] as String
    ..etc_code3 = json['etc_code3'] as String
    ..insUCode = json['insUCode'] as String
    ..insName = json['insName'] as String
    ..modUCode = json['modUCode'] as String
    ..modName = json['modName'] as String
    ..pubGbn = json['pubGbn'] as String;
}

Map<String, dynamic> _$ModelToJson(CodePutModel instance) => <String, dynamic>{
  'codeGrp': instance.codeGrp,
  'code': instance.code,
  'codeName': instance.codeName,
  'memo': instance.memo,
  'amt1': instance.amt1,
  'amt2': instance.amt2,
  'amt3': instance.amt3,
  'amt4': instance.amt4,
  'gbn1': instance.gbn1,
  'gbn3': instance.gbn3,
  'value1': instance.value1,
  'value2': instance.value2,
  'value3': instance.value3,
  'value4': instance.value4,
  'value5': instance.value5,
  'etc_code1': instance.etc_code1,
  'useGbn': instance.useGbn,
  'testYn': instance.testYn,
  'etc_code2': instance.etc_code2,
  'etc_code3': instance.etc_code3,
  'insUCode': instance.insUCode,
  'insName': instance.insName,
  'modUCode': instance.modUCode,
  'modName': instance.modName,
  'pubGbn': instance.pubGbn,
};
