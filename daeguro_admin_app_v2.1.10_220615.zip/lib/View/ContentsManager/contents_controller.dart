import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/Network/DioClient.dart';

import 'package:daeguro_admin_app/constants/serverInfo.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ContentsController extends GetxController with SingleGetTickerProviderMixin {
  static ContentsController get to => Get.find();
  BuildContext context;

  dynamic qDataDetail;
  List<dynamic> qDataSortList = [];

  int total_count = 0;
  int totalRowCnt = 0;

  RxString startDate = ''.obs;
  RxString endDate = ''.obs;
  RxInt rows = 0.obs;
  RxInt page = 0.obs;

  RxString divKey = ''.obs;
  RxString keyword = ''.obs;

  RxString div = ''.obs;
  RxString userName = ''.obs;
  RxString modName = ''.obs;
  RxString type_gbn = ''.obs;

  @override
  void onInit() {
    rows.value = 30; //15;
    page.value = 1;

    super.onInit();
  }

  Future<List<dynamic>> getContentsData(String cartegory_gbn, String disp_gbn, String keyword, String page, String rows) async {
    List<dynamic> qData = [];

    final response = await DioClient().get(ServerInfo.REST_URL_CONTENTS + '?cartegory_gbn=$cartegory_gbn&disp_gbn=$disp_gbn&keyword=$keyword&page=$page&rows=$rows');

    qData.clear();

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['totalCount'].toString());
      totalRowCnt = int.parse(response.data['count'].toString());

      qData.assignAll(response.data['data']);
    } else
      return null;

    return qData;
  }

  Future<dynamic> getDetailData(String contents_cd) async {
    final response = await DioClient().get(ServerInfo.REST_URL_CONTENTS + '/$contents_cd ');

    if (response.data['code'] == '00') {
      qDataDetail = response.data['data'];
      return qDataDetail;
    }

    return null;
  }

  postContents(Map data, BuildContext context) async {
    var response = await DioClient().post(ServerInfo.REST_URL_CONTENTS_REGIST, data: data);

    if (response.data['code'] != '00') {
      ISAlert(context, '쿠폰 발행이 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  putContents(Map data, BuildContext context) async {
    var response = await DioClient().put(ServerInfo.REST_URL_CONTENTS_EDIT, data: data);

    if (response.data['code'] != '00') {
      ISAlert(context, '쿠폰 발행이 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  Future<List<dynamic>> getContentsSubData(String contents_cd) async {
    List<dynamic> qData = [];

    final response = await DioClient().get(ServerInfo.REST_URL_CONTENTS_SUB + '?contents_cd=$contents_cd');

    qData.clear();

    if (response.data['code'] == '00') {
      total_count = int.parse(response.data['count'].toString());

      qData.assignAll(response.data['data']);
    } else
      return null;

    return qData;
  }

  postSubContents(Map data, BuildContext context) async {
    var response = await DioClient().post(ServerInfo.REST_URL_SUB_CONTENTS_REGIST, data: data);

    if (response.data['code'] != '00') {
      ISAlert(context, '쿠폰 발행이 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  putSubContents(Map data, BuildContext context) async {

    var response = await DioClient().put(ServerInfo.REST_URL_SUB_CONTENTS_EDIT, data: data);

    if (response.data['code'] != '00') {
      ISAlert(context, '쿠폰 발행이 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }

  Future<dynamic> getSubDetailData(String contents_cd, String episode ) async {
    final response = await DioClient().get(ServerInfo.REST_URL_CONTENTS_SUB + '/$contents_cd/$episode');

    if (response.data['code'] == '00') {
      qDataDetail = response.data['data'];
      return qDataDetail;
    }

    return null;
  }

  getSortList(String cartegory_gbn, BuildContext context) async {
    final response = await DioClient().get(ServerInfo.REST_URL_SORT_LSIT+'?cartegory_gbn=$cartegory_gbn');

    qDataSortList.assignAll(response.data['data']);

    if (response.data['code'].toString() == null ||
        response.data['code'].toString() == 'null' ||
        response.data['code'].toString() == '') {
      ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      return;
    }
  }

  updateSort(dynamic data, BuildContext context) async {
    final response = await DioClient().post(ServerInfo.REST_URL_SORT_UPDATE, data : data);

    if (response.data['code'] != '00') {
      ISAlert(context, '정상적으로 저장 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
    }
  }
}
