﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Notice.Request
{
    public class RequestNoticeV2 : RequestCommon
    {
        public string frDate { get; set; }
        public string toDate { get; set; }
        public string noticeGbn { get; set; }
        public string dispGbn { get; set; }
        public string pageCnt { get; set; }
        public string pageNum { get; set; }
    }
}
