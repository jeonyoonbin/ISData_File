﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Notice.Request
{
    public class RequestNoticeDetail : RequestCommon
    {
        public string seq { get; set; }
    }
}
