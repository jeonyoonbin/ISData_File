﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Notice.Response
{
    public class ResponseNoticeList
    {
        public string noticeSeq { get; set; }
        public string noticeGbn { get; set; }
        public string dispGbn { get; set; }
        public string dispFrDate { get; set; }
        public string dispToDate { get; set; }
        public string noticeTitle { get; set; }
        public string noticeContents { get; set; }
        public string noticeUrl1 { get; set; }
        public string noticeUrl2 { get; set; }
        public string noticeUrl3 { get; set; }
        public string insUcode { get; set; }
        public string insName { get; set; }
        public string modUcode { get; set; }
        public string modName { get; set; }
        public string modDate { get; set; }
        public string orderDate { get; set; }
        public string insDate { get; set; }
        public string sortSeq { get; set; }
    }
}
