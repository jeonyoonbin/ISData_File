﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Menu.Response
{
    public class ResponseMenuGroup 
    {
        public string menuGroupCd { get; set; }
        public string menuGroupName { get; set; }
        public string menuNames { get; set; }
    }
}
