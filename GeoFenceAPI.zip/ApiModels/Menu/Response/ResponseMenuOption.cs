﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Menu.Response
{
    public class ResponseMenuOption
    {
        public string menuOptionGroupCd { get; set; }
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string optionNames { get; set; }
        public string minCount { get; set; }
        public string multiYn { get; set; }
        public string multiCount { get; set; }
    }
}
