﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Menu.Request
{
    public class RequestMenuOption : RequestCommon
    {
        public string menuCd { get; set; }
    }
}
