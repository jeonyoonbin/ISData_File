﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Menu.Request
{
    public class RequestMenuGroup : RequestCommon
    {
        public string menuGroupCd { get; set; }
        public string menuGroupName { get; set; }
        public string menuGroupMemo { get; set; }
        public string useYn { get; set; }
    }
}
