﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Menu.Request
{
    public class RequestMenuList : RequestCommon
    {
        public string group_cd { get; set; }
        public string useYn { get; set; }
        public string adultYn { get; set; }
        public string flagYn { get; set; }
        public string menu_group_name { get; set; }
    }
}
