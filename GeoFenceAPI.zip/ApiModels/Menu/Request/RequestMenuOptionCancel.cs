﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Menu.Request
{
    public class RequestMenuOptionCancel : RequestCommon
    {
        public string menuCd { get; set; }
        public string menuOptionGroupCd { get; set; }
    }
}
