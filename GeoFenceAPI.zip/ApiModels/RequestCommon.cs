﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels
{
    public class RequestCommon
    {
        public string job_gbn { get; set; }
        public int mcode { get; set; }
        public string cccode { get; set; }
        public int shop_cd { get; set; }
        public int ucode { get; set; }
        public string mName { get; set; }
    }
}
