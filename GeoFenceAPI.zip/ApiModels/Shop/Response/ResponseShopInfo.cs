﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Shop.Response
{
    public class ResponseShopInfo
    {
        public string shopName { get; set; }
        public string ccname { get; set; }
        public string owner { get; set; }
        public string telno { get; set; }
        public string mobile { get; set; }
        public string addrJibun { get; set; }
        public string addrRoad { get; set; }
        public string loc { get; set; }
        public string itemNames { get; set; }
        public string shopType { get; set; }
        public string acceptState { get; set; }
        public string deliInfo { get; set; }
        public string appPayType { get; set; }
        public string shopIntro { get; set; }
        public string shopReviewIntro { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
        public string toGoDiscAmt { get; set; }
        public string toGoMinAmt { get; set; }
        public string toGoAcceptState { get; set; }
    }
}
