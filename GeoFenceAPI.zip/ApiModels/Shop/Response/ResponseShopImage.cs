﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Shop.Response
{
    public class ResponseShopImage
    {
        public string seq { get; set; }
        public string imageGbn { get; set; }
        [JsonProperty("FILE_NAME")]
        public string fileName { get; set; }
        [JsonProperty("SORT_SEQ")]
        public string sortSeq { get; set; }
    }
}
