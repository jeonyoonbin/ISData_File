﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Shop.Response
{
    public class ResponseWithDraw
    {
        public string withdrawCycle { get; set; } // M:매달 W:매주 D:매일
        public string withdrawDate { get; set; } // 출금일
        public string withdrawDay { get; set; } // 출금요일
        public string withdrawHour { get; set; } // 출금시간
        public string withdrawMinute { get; set; } // 출근분
        public string withdrawAmt { get; set; } // 출금금액
        public string fullWithdrawalYn { get; set; } // Y:전액출금 N:정해진 금액출금
        public string useYn { get; set; } // 사용 여부
    }
}
