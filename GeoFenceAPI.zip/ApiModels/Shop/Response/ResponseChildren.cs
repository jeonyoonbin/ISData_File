﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Shop.Response
{
    public class ResponseChildren
    {
        public string childrenYn { get; set; }
    }
}
