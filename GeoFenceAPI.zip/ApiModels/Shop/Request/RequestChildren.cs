﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Shop.Request
{
    public class RequestChildren : RequestCommon
    {
        public string childrenYn { get; set; }
        public string modGbn { get; set; } = "C";
    }
}
