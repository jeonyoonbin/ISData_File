﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Shop.Request
{
    public class RequestSetShopImage : RequestCommon
    {
        public string seq { get; set; }
        public string imageGbn { get; set; }
        public string fileName { get; set; }
        public string imageFile { get; set; }

    }
}
