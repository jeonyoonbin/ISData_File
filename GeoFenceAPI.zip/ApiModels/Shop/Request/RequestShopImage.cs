﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Shop.Request
{
    public class RequestShopImage : RequestCommon
    {
        public string seq { get; set; }
        public string imageGbn { get; set; }
        public string fileName { get; set; }
        public IFormFile iFile { get; set; }
        public string imageFile { get; set; }
    }
}
