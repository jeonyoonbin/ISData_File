﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Shop.Request
{
    public class RequestWithDraw : RequestCommon
    {
        public string cycle { get; set; }     // M:매달 W:매주 D:매일
        public string date { get; set; }     // 출금일
        public string day { get; set; }     // 출금요일 1:일 2:월 3:화 4:수 5:목 6:금 7:토
        public string hour { get; set; }     // 출금시간
        public string minute { get; set; }     // 출금분
        public string amt { get; set; }     // 출금액
        public string allYn { get; set; }    // 전액출금여부
        public string useYn { get; set; }    // 사용구분
    }
}
