﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Shop.Request
{
    public class RequestShopInfo : RequestCommon
    {
        public string data1 { get; set; }
        public string data2 { get; set; }
    }
}
