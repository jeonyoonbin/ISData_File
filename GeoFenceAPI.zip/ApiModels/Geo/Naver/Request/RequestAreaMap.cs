﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Geo.Naver.Request
{
    public class RequestAreaMap : RequestCommon
    {
        public string keys { get; set; }
        public string tip { get; set; }
        public string setGbn { get; set; }
    }
}
