﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Geo.Naver.Request
{
    public class RequestAreaMapGroup : RequestCommon
    {
        public int groupCode { get; set; }
        public int groupName { get; set; }
        public int tip { get; set; }
    }
}
