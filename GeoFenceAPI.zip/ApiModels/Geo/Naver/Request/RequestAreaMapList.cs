﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Geo.Naver.Request
{
    public class RequestAreaMapList : RequestCommon
    {
        public List<string> keys { get; set; }
        public List<string> setGbn { get; set; }
        public List<int> tip { get; set; }
        public List<int> groupCode { get; set; }
    }
}
