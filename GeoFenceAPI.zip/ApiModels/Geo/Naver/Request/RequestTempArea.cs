﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Geo.Naver.Request
{
    public class RequestTempArea : RequestCommon
    {
        public List<TempAreaItems> items { get; set; }   
    }
    public class TempAreaItems
    {
        public string seqno { get; set; }
        public string lon_start { get; set; }
        public string job_gbn { get; set; }
        public string lon_end { get; set; }
        public string lat_start { get; set; }
        public string lat_end { get; set; }
    }
}
