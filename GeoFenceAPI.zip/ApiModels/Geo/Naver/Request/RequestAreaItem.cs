﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Geo.Naver.Request
{
    public class RequestAreaItem : RequestCommon
    {
       public List<AreaItem> item { get; set; }
    }

    public class AreaItem
    {
        public string Zoom { get; set; }
        public string xIndex { get; set; }
        public string yIndex { get; set; }
        public string tip { get; set; }
    }
}
