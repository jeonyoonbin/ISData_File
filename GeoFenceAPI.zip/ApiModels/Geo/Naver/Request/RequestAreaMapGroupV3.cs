﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Geo.Naver.Request
{
    public class RequestAreaMapGroupV3 : RequestCommon
    {
       public List<MapGroupList> AreaInfo { get; set; }
    }
    public class MapGroupList
    {
        public string SetGbn { get; set; }
        public int groupCode { get; set; }
        public string groupName { get; set; }
        public int deliTip { get; set; }
    }
}
