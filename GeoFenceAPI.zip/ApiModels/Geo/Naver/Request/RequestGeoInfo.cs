﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Geo.Naver.Request
{
    public class RequestGeoInfo : RequestCommon
    {
        public string deliveryTip { get; set; }
        public string groupCode { get; set; }
    }
}
