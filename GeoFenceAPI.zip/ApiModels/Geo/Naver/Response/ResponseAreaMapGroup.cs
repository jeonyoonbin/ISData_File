﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Geo.Naver.Response
{
    public class ResponseAreaMapGroup
    {
        public string shopCd { get; set; }
        public int groupCode { get; set; }
        public string tip { get; set; }
    }
}
