﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Geo.Naver.Response
{
    public class ResponseAreaMap
    {
        public string shopCd { get; set; }
        public string geoSeqno { get; set; }
        public string groupCode { get; set; }
        public string tip { get; set; }
    }
}
