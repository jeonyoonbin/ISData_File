﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Geo.address.Request
{
    public class RequestAddressInfo : RequestCommon
    {
        public string sido { get; set; }
        public string gungu { get; set; }
        public string dong { get; set; }
    }
}
