﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Option.Response
{
    public class ResponseOptionInfo
    {
        public string optionCd { get; set; }
        public string optionName { get; set; }
        public string optionMemo { get; set; }
        public string cost { get; set; }
        public string useYn { get; set; }
        public string noFlag { get; set; }
        public string adultOnly { get; set; }
    }
}
