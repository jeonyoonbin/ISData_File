﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Option.Response
{
    public class ResponseOptionAll
    {
        public string group_type { get; set; }
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string menu_cd { get; set; }
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string optionGroupMemo { get; set; }
        public string option_yn { get; set; }
        public string use_yn { get; set; }
        public string sort_seq { get; set; }
        public string file_name { get; set; }
        public string req_yn { get; set; }
        public string multi_yn { get; set; }
        public string multi_count { get; set; }
        public string min_count { get; set; }
        public List<OGnOption> options { get; set; }
    }
    public class OGnOption
    {
        public string group_type { get; set; }
        public string menu_cd { get; set; }
        public string optionGroupCd { get; set; }
        public string option_cd { get; set; }
        public string option_name { get; set; }
        public string option_meno { get; set; }
        public string option_cost { get; set; }
        public string option_use_yn { get; set; }
        public string sort_seq { get; set; }
        public string file_name { get; set; }
        public string o_no_flag { get; set; }
        public string work_gbn { get; set; }
    } 
    
}
