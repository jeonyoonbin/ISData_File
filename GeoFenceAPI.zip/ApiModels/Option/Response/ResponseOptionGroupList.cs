﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Option.Response
{
    public class ResponseOptionGroupList
    {
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string optionNames { get; set; }
    }
}
