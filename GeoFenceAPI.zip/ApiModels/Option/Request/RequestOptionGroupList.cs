﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Option.Request
{
    public class RequestOptionGroupList :RequestCommon
    {
        public string menuCd { get; set; }
    }
}
