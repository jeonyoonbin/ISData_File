﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.ApiModels.Option.Request
{
    public class RequestOptionGroup : RequestCommon
    {
        public string groupName { get; set; }
        public string groupMemo { get; set; }
        public string minCount { get; set; }
        public string maxCount { get; set; }
        public string multiYn { get; set; }
        public string useYn { get; set; }
    }
}
