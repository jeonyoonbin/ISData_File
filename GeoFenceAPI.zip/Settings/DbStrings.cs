﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.Settings
{
    public class DbStrings
    {
        public string IsDaegu { get; set; }
        public string testDb { get; set; }
    }
}
