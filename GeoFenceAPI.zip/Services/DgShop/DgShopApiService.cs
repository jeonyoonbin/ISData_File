﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using GeoFenceAPI.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace GeoFenceAPI.Services.DgShop
{
    public class DgShopApiService
    {
        public HttpClient client { get; set; }
        public DgShopApiService(HttpClient _client, IConfiguration config, IHttpContextAccessor accessor)
        {
            client = _client;
            client.BaseAddress = new Uri(config.GetValue<string>("api:daegu"));
            client.DefaultRequestHeaders.Add("Accept", "application/json");
            client.DefaultRequestHeaders.Add("User-Agent", "IsPosWebSettings");

            //var bearerToken = accessor.HttpContext.Request.Headers["Authorization"].FirstOrDefault(h => h.StartsWith("bearer ", StringComparison.CurrentCultureIgnoreCase));
            //bearerToken = accessor.HttpContext.Session.GetString("jwt_token");
            //if (bearerToken != null)
            //{
            //    _client.DefaultRequestHeaders.Add("Authorization", "bearer " + bearerToken);
            //}
        }
        /// <summary>
        /// Method Get
        /// </summary>
        /// <typeparam name="T">리턴 받을 데이터 타입</typeparam>
        /// <param name="Url"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<Result<T>> Get<T>(string Url, string parameters = null)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);
                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        /// <summary>
        /// Method Get
        /// </summary>
        /// <typeparam name="T">리턴 받을 데이터 타입</typeparam>
        /// <param name="Url"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<ResultSingle<T>> GetSingle<T>(string Url, string parameters = null)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);
                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ResultSingle<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        /// <summary>
        /// Method Post
        /// </summary>
        /// <typeparam name="T">리턴 받을 데이터 타입</typeparam>
        /// <typeparam name="T2">요청 데이터 모델</typeparam>
        /// <param name="url"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public async Task<Result<T>> Post<T, T2>(string url, T2 content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }

                
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                var response = await client.PostAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                { 
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    Result<T> t = new Result<T>();
                    t.code = "99";
                    t.msg = "인증되지 않은 사용자입니다.";
                    return t;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<ResultSingle<T>> PostSingle<T, T2>(string url, T2 content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }


                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                var response = await client.PostAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ResultSingle<T>>(responseStream);

                    return temp;
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    Result<T> t = new Result<T>();
                    t.code = "99";
                    t.msg = "인증되지 않은 사용자입니다.";
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
    }
}
