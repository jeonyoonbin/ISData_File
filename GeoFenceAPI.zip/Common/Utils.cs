﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GeoFenceAPI.Common
{
    public class Utils
    {
        public static string oracleConnectString;
        public static string aes_key = "d25hbnNkbXNlb3JuZmhxb2VrZmRtc2VvcmRtZmhhYmM=";
        public static string aes_key2 = "jKi1E8Y1VDGMvezfLgIOuA4mnRA4FQCoxC71FSn5pPk=";

        #region base64
        public static string SetBase64(string data)
        {
            byte[] btyesUTF8 = Encoding.UTF8.GetBytes(data);

            string base64UTF8 = Convert.ToBase64String(btyesUTF8);


            return base64UTF8;
        }
        #endregion
        #region MD5
        public static string SetMD5(string data)
        {
            MD5 MD5Hash = MD5.Create();
            byte[] md5Byte = MD5Hash.ComputeHash(Encoding.UTF8.GetBytes(data));

            StringBuilder sb = new StringBuilder();

            for(var i = 0; i < md5Byte.Length; i++)
            {
                sb.Append(md5Byte[i].ToString("x2"));
            }
            string result = sb.ToString().ToUpper();

            sb.Clear();


            return result;

        }
        #endregion

        #region SHA
        public static string Sha256(string data)
        {
            SHA256 sha = new SHA256Managed();
            byte[] hash = sha.ComputeHash(Encoding.ASCII.GetBytes(data));
            StringBuilder sb = new StringBuilder();
            foreach (byte b in hash)
            {
                sb.AppendFormat("{0:x2}", b);
            }
            return sb.ToString();

        }
        public static string p_Sha256(string data)
        {
            SHA256 sha = new SHA256Managed();
            byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(data));
            StringBuilder sb = new StringBuilder();
            foreach (byte b in hash)
            {
                sb.AppendFormat("{0:x2}", b);
            }
            return sb.ToString();

        }
        public static string Sha512(string data)
        {
            SHA512 sha = new SHA512Managed();
            byte[] hash = sha.ComputeHash(Encoding.ASCII.GetBytes(data));
            StringBuilder sb = new StringBuilder();
            foreach (byte b in hash)
            {
                sb.AppendFormat("{0:x2}", b);
            }
            return sb.ToString();
        }
        #endregion

        #region AES
        public static string Aes_Decrypt(string decript, string key)
        {
            RijndaelManaged aes = new RijndaelManaged();
            aes.KeySize = 256;
            aes.BlockSize = 128;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            aes.Key = Convert.FromBase64String(key);
            aes.IV = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

            var decrypt = aes.CreateDecryptor();

            byte[] xBuff = null;
            using (var ms = new MemoryStream())
            {
                using (var cs = new CryptoStream(ms, decrypt, CryptoStreamMode.Write))
                {
                    byte[] xXml = Convert.FromBase64String(decript);
                    cs.Write(xXml, 0, xXml.Length);
                }
                xBuff = ms.ToArray();
            }

            string output = Encoding.UTF8.GetString(xBuff);
            return output;
        }
        public static string Aes_Encrypt(string encript, string key)
        {
            RijndaelManaged aes = new RijndaelManaged();
            aes.KeySize = 256;
            aes.BlockSize = 128;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            aes.Key = Convert.FromBase64String(key);
            aes.IV = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

            var encrypt = aes.CreateEncryptor(aes.Key, aes.IV);
            byte[] xBuff = null;
            using (var ms = new MemoryStream())
            {
                using (var cs = new CryptoStream(ms, encrypt, CryptoStreamMode.Write))
                {
                    byte[] xXml = Encoding.UTF8.GetBytes(encript);
                    cs.Write(xXml, 0, xXml.Length);
                }

                xBuff = ms.ToArray();
            }

            string output = Convert.ToBase64String(xBuff);
            return output;
        }
        public static string GenKey()
        {
            RijndaelManaged aes = new RijndaelManaged();
            aes.KeySize = 256;
            aes.BlockSize = 128;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            aes.GenerateKey();

            string key = Convert.ToBase64String(aes.Key);
            return key;
        }
        #endregion

        public static string DateTimeFormatToSendData(string value)
        {
            return value.Replace(":", "");
        }
        public static string DateTimeFormat(string value)
        {
            if (string.IsNullOrEmpty(value) || value.Length != 4) return value;

            return value.Insert(2, ":");
        }
        public static string ParseDateTime(string dateTime)
        {
            if (dateTime.Trim().Length == 14)
            {
                DateTime.TryParseExact(dateTime, "yyyyMMddHHmmss", null, System.Globalization.DateTimeStyles.None, out DateTime dt);
                return dt.ToString("yyyy-MM-dd HH:mm:ss");
            }
            else if (dateTime.Trim().Length == 8)
            {
                DateTime.TryParseExact(dateTime, "yyyyMMdd", null, System.Globalization.DateTimeStyles.None, out DateTime dt);
                return dt.ToString("yyyy-MM-dd");
            }
            return dateTime;
        }
        public static string ParseDataTimeComma(string dateTime)
        {
            if (dateTime.Trim().Length == 8)
            {
                DateTime.TryParseExact(dateTime, "yyyyMMdd", null, System.Globalization.DateTimeStyles.None, out DateTime dt);
                return dt.ToString("yyyy. MM. dd");
            }
            return dateTime;
        }
        public static string ParseDataTimehipen(string dateTime)
        {
            if (dateTime.Trim().Length == 8)
            {
                DateTime.TryParseExact(dateTime, "yyyyMMdd", null, System.Globalization.DateTimeStyles.None, out DateTime dt);
                return dt.ToString("yyyy-MM-dd");
            }
            return dateTime;
        }
        public static string NumberFormatOptionCost(string value, bool addCurrency = false)
        {
            try
            {
                if (string.IsNullOrEmpty(value)) return string.Format("{0:N0}", 0);
                if (addCurrency) return string.Format("{0:N0}", Convert.ToInt32(value.Replace(",", "")));

                return string.Format("{0:N0}", Convert.ToInt32(value.Replace(",", "")));
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static string NumberFormat(string value, bool addCurrency = false)
        {
            try
            {
                if (string.IsNullOrEmpty(value)) return string.Format("{0:N0} 원", 0);
                if (addCurrency) return string.Format("{0:N0} 원", Convert.ToInt32(value.Replace(",", "")));

                return string.Format("{0:N0}", Convert.ToInt32(value.Replace(",", "")));
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static string NumberFormat(int value, bool addCurrency = false)
        {
            try
            {
                if (value == 0) return string.Format("{0:N0} 원", 0);
                if (addCurrency) return string.Format("{0:N0} 원", value);

                return string.Format("{0:N0}", value);
            }
            catch (Exception)
            {

                throw;
            }
        }
        public static string NumberFormat(long value, bool addCurrency = false)
        {
            try
            {
                if (value == 0) return string.Format("{0:N0}", 0);
                if (addCurrency) return string.Format("{0:N0}원", value);

                return string.Format("{0:N0}", value);
            }
            catch (Exception)
            {

                throw;
            }
        }
        public static string NumberFormatToSendData(string numberFormatString)
        {
            var temp = numberFormatString.Replace(",", "").Replace("원", "");
            return temp.TrimEnd();
        }
        public static int betweenDateTimeDays(string from, string to)
        {
            if (string.IsNullOrEmpty(from))
            {
                //return 0;
                from = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            }
            if (string.IsNullOrEmpty(to))
            {
                to = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            }
            try
            {
                from = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                var after = DateTime.ParseExact(from, "yyyy-MM-dd HH:mm:ss", null);
                var before = DateTime.ParseExact(to, "yyyy-MM-dd HH:mm:ss", null);

                var result = before - after;

                return result.Days;
            }
            catch (Exception)
            {
                throw;
            }

        }
        public static int betweenDateTimeDays_V2(string from, string to)
        {
            if (string.IsNullOrEmpty(from))
            {
                //return 0;
                from = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            }
            if (string.IsNullOrEmpty(to))
            {
                to = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            }
            try
            {
                var after = DateTime.ParseExact(from, "yyyy-MM-dd HH:mm:ss", null);
                var before = DateTime.ParseExact(to, "yyyy-MM-dd HH:mm:ss", null);

                var result = before - after;

                return result.Days;
            }
            catch (Exception)
            {
                throw;
            }

        }
        public static string StringFormatToDateAmPMDel(string value)
        {
            if (string.IsNullOrEmpty(value)) return value;

            DateTime.TryParse(value, null, System.Globalization.DateTimeStyles.AssumeLocal, out DateTime convertDate);
            return convertDate.ToString("yyyy-MM-ddHHmm");
        }
        public static string StringFormatToDateTime(string value)
        {
            if (string.IsNullOrEmpty(value)) return value;

            DateTime.TryParseExact(value, "yyyyMMddHHmmss", null, System.Globalization.DateTimeStyles.None, out DateTime convertDate);
            return convertDate.ToString("yyyy-MM-dd HH:mm:ss");
        }
        public static string StringFormatToDate(string value)
        {
            if (string.IsNullOrEmpty(value)) return value;

            DateTime.TryParseExact(value, "yyyyMMdd", null, System.Globalization.DateTimeStyles.None, out DateTime convertDate);
            return convertDate.ToString("yyyy-MM-dd");
        }

        public static string StringFormatToDateTime(string value , bool yn)
        {
            if (string.IsNullOrEmpty(value)) return value;

            DateTime.TryParseExact(value, "yyyyMMddHHmmss", null, System.Globalization.DateTimeStyles.None, out DateTime convertDate);
            return convertDate.ToString("yyyy-MM-dd tt h:mm:ss");
        }
        public static string StringFormatToDay(string value)
        {
            if (string.IsNullOrEmpty(value)) return value;
            CultureInfo culture = CultureInfo.CreateSpecificCulture("Ko-KR");
            DateTime.TryParseExact(value, "yyyyMMdd", null, System.Globalization.DateTimeStyles.None, out DateTime convertDate);
            return convertDate.ToString("(ddd)", culture);
        }
        public static string StringFormatToTime(string value)
        {
            if(string.IsNullOrEmpty(value)) return value;

            DateTime.TryParseExact(value, "HHmm", null, System.Globalization.DateTimeStyles.None, out DateTime convertDate);
            return convertDate.ToString("tt h:mm");
        }
       
        public static string StringFormatToTimeDeleteDate(string value)
        {
            if (string.IsNullOrEmpty(value)) return value;

            DateTime.TryParseExact(value, "yyyyMMddHHmmss", null, System.Globalization.DateTimeStyles.None, out DateTime convertDate);
            return convertDate.ToString("yyyy. MM. dd");
        }
        public static string RegexValid(string regex, string value)
        {
            if (string.IsNullOrEmpty(value)) return value;

            Regex vaildRegex = new Regex(regex);
            MatchCollection matches = vaildRegex.Matches(value);
            Match match2 = vaildRegex.Match(value);

            if (match2.Length < 4)
            {
                return value;
            }

            var tempResult = string.Join('-', match2.Groups[1], match2.Groups[2], match2.Groups[3]);

            if (string.IsNullOrEmpty(tempResult)) return value;

            return tempResult;

        }
        public static string RegexValid8(string regex, string value)
        {
            if (string.IsNullOrEmpty(value)) return value;

            Regex vaildRegex = new Regex(regex);
            MatchCollection matches = vaildRegex.Matches(value);
            Match match2 = vaildRegex.Match(value);

            if (match2.Length < 4)
            {
                return value;
            }

            var tempResult = string.Join('-', match2.Groups[1], match2.Groups[2]);

            if (string.IsNullOrEmpty(tempResult)) return value;

            return tempResult;

        }
        public static string GenerateRandomFileName()
        {
            var randomName = Path.GetRandomFileName();

            string[] temp = randomName.Split(".");
            return temp[0];
        }
        public static bool IsImage(IFormFile file)
        {
            switch (file.ContentType)
            {
                case "image/jpg":
                case "image/jpeg":
                case "image/pjpeg":
                case "image/x-png":
                case "image/png":
                    return true;
                default:
                    return false;
            }
        }
        public static bool IsImageExtension(IFormFile file)
        {
            switch (Path.GetExtension(file.FileName))
            {
                case ".jpg":
                case ".jpeg":
                case ".png":
                    return true;
                default:
                    return false;
            }
        }
      

        public bool MoneyCheck(string str)
        {
            Int32.TryParse(str, out int money);

            if (money % 100 > 0)
            {
                return false;
            }
            return true;
        }
        public bool Money10wonCheck(string str)
        {
            Int32.TryParse(str, out int money);

            if (money % 10 > 0)
            {
                return false;
            }
            return true;
        }

        #region Week First And Last Day from given day
        public DateTime DtGetFirstDayOfWeek(DateTime nowTime, DayOfWeek firstDay)
        {
            CultureInfo info = new CultureInfo("ko-kr");
            info.DateTimeFormat = new DateTimeFormatInfo()
            {
                FirstDayOfWeek = firstDay
            };
            var diff = nowTime.DayOfWeek - info.DateTimeFormat.FirstDayOfWeek;
            if (diff < 0)
            {
                diff += 7;
            }
            return nowTime.AddDays(-diff).Date;
        }

        public string GetFirstDayOfWeek(DateTime nowTime, string dayType, DayOfWeek firstDay)
        {
            return DtGetFirstDayOfWeek(nowTime, firstDay).ToString(dayType);
        }

        public DateTime DtGetLastDayOfWeek(DateTime nowTime, DayOfWeek firstDay)
        {
            CultureInfo info = new CultureInfo("ko-kr");
            info.DateTimeFormat = new DateTimeFormatInfo()
            {
                FirstDayOfWeek = firstDay
            };
            var diff = nowTime.DayOfWeek - info.DateTimeFormat.FirstDayOfWeek;
            if (diff < 0)
                diff += 7;
            DateTime start = nowTime.AddDays(-diff).Date;
            return start.AddDays(6).Date;
        }
        public string GetLastDayOfWeek(DateTime nowTime, string dayType, DayOfWeek firstDay)
        {
            return DtGetLastDayOfWeek(nowTime, firstDay).ToString(dayType);
        }
        #endregion


        public static void SaveError(string errorPosition, string errorMsg)
        {

        }



        #region 은행 명
        public static string GetBankName(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return "값이 존재하지않습니다.";
            }

            var result = "";
            switch (value)
            {
                case "02":
                    result = "산업";
                    break;
                case "03":
                    result = "기업";
                    break;
                case "04":
                    result = "국민";
                    break;
                case "05":
                    result = "외환";
                    break;
                case "07":
                    result = "수협";
                    break;
                case "08":
                    result = "수출";
                    break;
                case "11":
                    result = "농협";
                    break;
                case "12":
                    result = "단협";
                    break;
                case "20":
                    result = "우리";
                    break;
                case "23":
                    result = "SC은행";
                    break;
                case "27":
                    result = "씨티";
                    break;
                case "32":
                    result = "부산";
                    break;
                case "34":
                    result = "광주";
                    break;
                case "35":
                    result = "제주";
                    break;
                case "37":
                    result = "전북";
                    break;
                case "39":
                    result = "경남";
                    break;
                case "71":
                    result = "우체국";
                    break;
                case "81":
                    result = "KEB하나";
                    break;
                case "88":
                    result = "신한";
                    break;
                case "31":
                    result = "대구";
                    break;
                case "50":
                    result = "상호저축";
                    break;
                case "48":
                    result = "신협";
                    break;
                case "45":
                    result = "새마을";
                    break;
                case "89":
                    result = "K,뱅크";
                    break;
                case "90":
                    result = "카카오뱅크";
                    break;
                default:
                    result = "올바른 값을 입력하지않았습니다.";
                    break;

            }
            return result;
        }
        #endregion
    }
}
