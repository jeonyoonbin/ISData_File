﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.Common
{
    public enum LOG_TYPE { DAILY, MONTHLY }
    public class LogManager
    {
        public string _path;

        #region 생성자
        public LogManager(string path, LOG_TYPE type, string prefix, string postfix)
        {
            this._path = path;
            _SetLogPath(type, prefix, postfix);
        }
        public LogManager(string prefix, string postfix)
            : this(System.IO.Path.Combine(@"c:", "Log"), LOG_TYPE.DAILY, prefix, postfix)
        {
        }
        public LogManager(string path)
            : this(System.IO.Path.Combine(@"c:", "ReceiptLog"), LOG_TYPE.DAILY, null, null)
        { }
        public LogManager()
            : this(System.IO.Path.Combine(@"c:\", "Log"), LOG_TYPE.DAILY, null, null)
        {
        }
        #endregion
        #region SetPath
        private void _SetLogPath(LOG_TYPE type, string prefix, string postfix)
        {
            string path = "";
            string name = "";

            switch (type)
            {
                case LOG_TYPE.MONTHLY:
                    path = string.Format(@"{0}\", DateTime.Now.Year);
                    name = DateTime.Now.ToString("yyyyMMdd");
                    break;
                case LOG_TYPE.DAILY:
                    path = string.Format(@"{0}\{1}\", DateTime.Now.Year, DateTime.Now.ToString("MM"));
                    name = DateTime.Now.ToString("yyyyMMdd");
                    break;
            }

            _path = System.IO.Path.Combine(_path, path);

            if (!System.IO.Directory.Exists(_path))
                System.IO.Directory.CreateDirectory(_path);

            if (!string.IsNullOrEmpty(prefix))
                name = prefix + name;
            if (!string.IsNullOrEmpty(postfix))
                name = name + prefix;
            name += ".txt";

            _path = System.IO.Path.Combine(_path, name);
        }
        #endregion
        #region write 함수
        public void write(string data)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(_path, true))
                {
                    writer.Write(data);
                }
            }
            catch (Exception e)
            {

            }

        }
        public void writeLine(string data)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(_path, true))
                {
                    writer.WriteLine(DateTime.Now.ToString("[yyyyMMdd HH:mm:ss]\t") + data);
                }
            }
            catch (Exception e)
            {

            }

        }
        public void writeByte(byte[] data)
        {
            try
            {
                using (BinaryWriter writer = new BinaryWriter(File.OpenWrite(_path)))
                {
                    writer.Write(data, 0, data.Length);
                    writer.Write(0x0a);
                    writer.Flush();
                    writer.Close();
                }
            }
            catch (Exception e)
            {
                writeLine(e.ToString());
            }
        }
        #endregion
    }
}
