﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.Common
{
    public class CodeMsg
    {
        public string code { get; set; }
        public string msg { get; set; }
    }
}
