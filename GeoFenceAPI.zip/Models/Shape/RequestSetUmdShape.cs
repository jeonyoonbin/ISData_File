﻿namespace GeoFenceAPI.Models.Shape
{
    public class RequestSetUmdShape : ShapeUmd
    {
        public string job_gbn { get; set; }
        public string mod_ucode { get; set; }
        public string mod_user { get; set; }
    }
}
