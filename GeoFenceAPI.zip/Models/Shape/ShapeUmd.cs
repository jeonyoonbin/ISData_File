﻿using System.Collections.Generic;

namespace GeoFenceAPI.Models.Shape
{
    public class ShapeUmd
    {
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umd { get; set; }
        public string ri { get; set; }
        public List<ShapePoint> pointArray { get; set; }
        public ShapeBound bound { get; set; }
    }

    public class ShapePoint
    {
        public double lon_x { get; set; }
        public double lat_y { get; set; }
    }
    public class NaverMapPoint
    {
        public double x { get; set; }
        public double y { get; set; }
        public double _lng { get; set; }
        public double _lat { get; set; }
    }

    public class ShapeBound
    {
        public double left { get; set; }
        public double top { get; set; }
        public double right { get; set; }
        public double bottom { get; set; }
    }
}
