﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.Models.ResponseModel
{
    public class Request
    {
        public string job_gbn { get; set; }
        public int mcode { get; set; }
        public string cccode { get; set; }
        public int shop_cd { get; set; }
        public string u_code { get; set; }
        public string login_name { get; set; }
        public string login_code { get; set; }
    }
}
