﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.Models.ResponseModel
{
    public class CustMenu
    {
        public List<CustOrderMenu> menus { get; set; }
    }
    public class CustOrderMenu
    {
        public string menuCode { get; set; }
        public int cost { get; set; }
        public int menuCost { get; set; }
        public int saleCost { get; set; }
        public int count { get; set; }
        public string description { get; set; }
        public string menuName { get; set; }
        public string eventYn { get; set; }
        public List<OrderUnitOption> orderUnitOptions { get; set; }
    }
    public class OrderUnitOption
    {
        public string optionCode { get; set; }
        public int cost { get; set; }
        public string name { get; set; }
    }
}
