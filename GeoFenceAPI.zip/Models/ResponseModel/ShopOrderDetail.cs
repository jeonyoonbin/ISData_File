﻿using System.Collections.Generic;

namespace GeoFenceAPI.Models.ResponseModel
{
    public class ShopOrderDetail
    {
        public string order_no { get; set; }
        public string shop_name { get; set; }
        public string status { get; set; }
        public string cancel_reason { get; set; }
        public string menu_name { get; set; }
        public string menu_amt { get; set; }
        public string order_amt_tip { get; set; }
        public string coupon_amt { get; set; }
        public string amount { get; set; }
        public string order_no1 { get; set; }
        public string order_time { get; set; }
        public string shop_dong_addr { get; set; }
        public string shop_road_addr { get; set; }
        public string shop_addr_detail { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
        public string cust_dong_addr { get; set; }
        public string cust_road_addr { get; set; }
        public string cust_addr_detail { get; set; }
        public string pack_order_yn { get; set; }
        public string app_pay_gbn { get; set; }
        public string pay_gbn { get; set; }
        public string rider_deli_memo { get; set; }
        public string shop_deli_memo { get; set; }
        public string mynumber { get; set; }
        public string mileage_use_amt { get; set; }
        public string happy_disc_amt { get; set; }
        public string deli_tip_disc_amt { get; set; }
        public string to_go_disc_amt { get; set; }
        public string menu_desc { get; set; }
        public string cust_lon { get; set; }
        public string cust_lat { get; set; }
        public List<CustOrderMenu> menu_info { get; set; }
    }
}
