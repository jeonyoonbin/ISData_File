﻿using System.Collections.Generic;

namespace GeoFenceAPI.Models.GeoFence
{
    public class RequestSetCommonUmd
    {
        public string hcode { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umd { get; set; }
        public List<double> lon_x { get; set; }
        public List<double> lat_y { get; set; }
    }
}
