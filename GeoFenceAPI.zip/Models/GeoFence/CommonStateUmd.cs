﻿namespace GeoFenceAPI.Models.GeoFence
{
    public class CommonStateUmd
    {
        public string hcode { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umd { get; set; }
        public string shape_sequence { get; set; }
        public double lon_x { get; set; }
        public double lat_y { get; set; }
    }
}
