﻿namespace GeoFenceAPI.Models.GeoFence
{
    public class NaverGeoData
    {
        public int shop_cd { get; set; }
        public int data_seq { get; set; }
        public string data { get; set; }
        public string insert_date { get; set; }
        public string insert_ucode { get; set; }
        public string insert_name { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
        public string mod_date { get; set; }
    }
}
