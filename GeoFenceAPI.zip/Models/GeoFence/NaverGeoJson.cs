﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeoFenceAPI.Models.GeoFence
{
    public class NaverGeoJson
    {
        public string type { get; set; }
        public string name { get; set; }
        public Crs crs { get; set; }
        public List<features> features { get; set; }
    }
    public class Crs
    {
        public string  type { get; set; }
        public Properties properties { get; set; }
    }
    public class Properties
    {
        public string name { get; set; }
    }

    public class features
    {
        public string type { get; set; }
        public NaverProperties properties { get; set; }
        public NaverGeometryMulti geometry { get; set; }
    }
    public class NaverProperties
    {
        public string BASE_DATE { get; set; }
        public string ADM_DR_CD { get; set; }
        public string ADM_DR_NM { get; set; }
        public string OBJECTID { get; set; }
    }
    public class NaverGeometryMulti
    {
        public string type { get; set; }
        public List<List<List<double>>> coordinates { get; set; }
    }
}
