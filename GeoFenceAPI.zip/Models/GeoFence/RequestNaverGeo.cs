﻿namespace GeoFenceAPI.Models.GeoFence
{
    public class RequestNaverGeo
    {
        public string job_gbn { get; set; }
        public int shop_cd { get; set; }
        public int data_seq { get; set; }
        public string data { get; set; }
        public string mod_user { get; set; }
        public string mod_ucode { get; set; }
    }
}
