﻿namespace GeoFenceAPI.Models.GeoFence
{
    public class RequestInsertGeoFence
    {
        public string points { get; set; }
        public string area_name { get; set; }
        public string area_amount { get; set; }
        public string area_sequence { get; set; }
        public int fence_sequence { get; set; }
        public string use_area { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umd { get; set; }
        public string ri { get; set; }
    }
}
