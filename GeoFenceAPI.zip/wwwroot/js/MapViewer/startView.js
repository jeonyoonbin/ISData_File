﻿
$(document).ready(function () {
    AreaData();
});

function AreaData() {
    $.ajax({
        method: "POST",
        url: "/home/getAreaIndex",
        success: function (data, status, xhr) {
            console.log(data.data);
            console.log(map);
            if (typeof data.data != "undefined") {
                for (let temp in data.data) {
                    let tl = tileClickTopLeft(parseInt(data.data[temp].xIndex), parseInt(data.data[temp].yIndex), parseInt(data.data[temp].zoom));
                    let br = tileClickBottomRight(parseInt(data.data[temp].xIndex) + 1, parseInt(data.data[temp].yIndex) + 1, parseInt(data.data[temp].Zoom));
                    var Rectangle = new naver.maps.Rectangle({
                        bounds: new naver.maps.LatLngBounds(
                            new naver.maps.LatLng(tl._lat, tl._lng),
                            new naver.maps.LatLng(br._lat, br._lng)
                        ),
                        map: map
                    });
                    //console.log(data.data[temp]);
                }
                
            }
        },
        error: function (xhr, status, data) {

        }
    });
}