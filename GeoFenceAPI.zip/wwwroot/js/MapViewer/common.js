﻿
//global
var Browser = { a: navigator.userAgent.toLowerCase() }

Browser = {
    ie: false,
    ie6: Browser.a.indexOf('msie 6') != -1,
    ie7: Browser.a.indexOf('msie 7') != -1,
    ie8: Browser.a.indexOf('msie 8') != -1,
    oprea: !!window.opera,
    safari: Browser.a.indexOf('safari') != -1,
    mac: Browser.a.indexOf('mac') != -1,
    chrome: Browser.a.indexOf('chrome') != -1,
    firefox: Browser.a.indexOf('firefox') != -1
}

var nowZoom = 100;
var maxZoom = 100;
var minZoom = 100;

var SizeChk = function () {
    if (Browser.chrome) {
        alert('화면 크기 기능 제공하지않습니다.');
    }
}