﻿//global
var elementTip = "";
var elementDefault = "tip";
var elementGeoPosition = {};
var elementGeoPosition_UMD = {};
$(document).ready(function () {

    $('input.new-input').on('click', function (e) {
       
        $(this).parent().trigger('click');
    });

    $('#sigungu').on('change', function (e) {


        $('#umd').empty();
        var defualt = $("<option value='' selected>" + "예)읍면동" + "</option>");
        $.ajax({
            method: 'post',
            async: true,
            url: "/home/lonlatGeoPosition",
            data: {
                type: "3",
                address: {
                    gungu: $('#sigungu').val()
                }
            },
            success: function (data, status, xhr) {
                if (data.code = "00") {
                    $('#umd').append(defualt);
                    for (var items in data.data) {
                        console.log(items);
                        if (typeof elementGeoPosition[$('#sido').val()] == "undefined") {
                            elementGeoPosition[$('#sido').val()] = {};
                        }
                        var value = {
                            lon: data.data[items].lonGrs80,
                            lat: data.data[items].latGrs80
                        }
                        var valueindex = data.data[items].hSmall;
                        elementGeoPosition[$('#sido').val()][valueindex] = value;

                        var options = $("<option value=" + data.data[items].hSmall + ">" + data.data[items].hSmall + "</option>");
                        $('#umd').append(options);
                    }
                    console.log(elementGeoPosition);
                }
            },
            error: function (xhr, status, data) {

            }
        });
    });

    $('#umd').on('change', function (e) {

        $('#umdRi').empty();
        var defualt = $("<option value='' selected>" + "예)금포리, 명곡리" + "</option>");
        $.ajax({
            method: 'post',
            async: true,
            url: "/home/lonlatGeoPosition",
            data: {
                type: "5",
                address: {
                    gungu: $('#sigungu').val(),
                    dong: $('#umd').val()
                }
            },
            success: function (data, status, xhr) {
                if (data.code = "00") {
                    console.log(data.data);
                    $('#umdRi').append(defualt);
                    let position = elementGeoPosition[$('#sido').val()][$('#umd').val()];

                    initMap.setCenter(new naver.maps.LatLng(position.lat, position.lon));
                    for (var items in data.data) {
                        console.log(items);
                        
                        if (typeof elementGeoPosition_UMD[$('#umd').val()] == "undefined") {
                            elementGeoPosition_UMD[$('#umd').val()] = {};
                        }
                        var value = {
                            lon: data.data[items].lonGrs80,
                            lat: data.data[items].latGrs80
                        }
                        var valueindex = data.data[items].bDetaill;
                        elementGeoPosition_UMD[$('#umd').val()][valueindex] = value;

                        var options = $("<option value=" + data.data[items].bDetaill + ">" + data.data[items].bDetaill + "</option>");
                        $('#umdRi').append(options);
                    }
                }
                console.log(elementGeoPosition_UMD);
            },
            error: function (xhr, status, data) {

            }
        });
    });

    $('#umdRi').on('change', function (e) {
        let position = elementGeoPosition_UMD[$('#umd').val()][$('#umdRi').val()];
        console.log(position);
        initMap.setCenter(new naver.maps.LatLng(position.lat, position.lon));
    });


});

function AreaSelect(tip_Element) {
    elementTip = $(this);
    console.log(elementTip);

    var logId = $(tip_Element).attr('id');
    console.log(logId);

    return logId;
}
var tipTypeseletor = function () {
    return $("input[name='area']:checked").attr('id');
};


function AreaBackGroundColor(areaCount){

    var color = "";
    switch (areaCount) {
        case 1:
            color = "#f141d3";
            break;
        case 2:
            color = "#f39e02";
            break;
        case 3:
            color = "#41eb00";
            break;
        case 4:
            color = "#a700ff";
            break;
        case 5:
            color = "#2100ff";
            break;
        case 6:
            color = "#a700ff";
            break;
        case 7:
            color = "#f8a8f8";
            break;
        case 8:
            color = "#ffd0ad";
            break;
        case 9:
            color = "#a8d5f8";
            break;
        case 10:
            color = "#c8c8c8";
            break;

    }

    return color;
}

function AreaAdd(status){

    if(($('.input-group.radio-wrap .input-group-text').length - 1) < 5){
        $.ajax({
            method: 'post',
            async: true,
            url: "/home/SetAreaGroup",
            data: {
                status: status,
            },
            success: function (data, status, xhr) {
                if (data.code = "00") {
                    var html = $('.copy-fields').html();
                    NewPopup.alertOkNo1("구역 설정",
                        "구역이 추가되었습니다.",
                        "확인",
                        function (res) {
                            if (res) {
                               
                            }
                        });
                    $('#areaCopyPath').before(html);
                    var addDiv = $('.input-group-text')
                    var addArea = $('.input-group-text').closest('input[name=area]').prevObject;
                    $(addArea[$('.input-group-text').length - 2]).attr('data-code', data.data);
                    $(addArea[$('.input-group-text').length - 2]).find('input:first').attr('id', '구역' + ($('.input-group-text').length - 1));
                    $(addArea[$('.input-group-text').length - 2]).find('input:first').siblings().eq(1).html('구역' + ($('.input-group-text').length - 1));
                    $(addArea[$('.input-group-text').length - 2]).find('div.sec-money input').attr('id', 'M구역' + ($('.input-group-text').length - 1));
                    $(addArea[$('.input-group-text').length - 2]).find('div.sec-money input')
                        .attr('style', 'border-color :' + AreaBackGroundColor($('.input-group-text').length - 1) + "!important");
                    $(addArea[$('.input-group-text').length - 2]).find('div.sec-money input').css('color', AreaBackGroundColor($('.input-group-text').length - 1));
                    $(addArea[$('.input-group-text').length - 2]).find('input:first').prop('checked', true);
                }
            },
            error: function (xhr, status, data) {

            }
        });
    }else {
        

        NewPopup.alertOkNo2("배달 구역 추가",
            "더 이상 생성하실수 없습니다.",
            "확인",
            function(res){
                if(res){
                    return false;
                }
            })
            return false;
    }
}
function AreaUpdate(status){

    var resultList = {};
    var AreaEle = $('.input-group-text');
    var AreaInput = AreaEle.closest('input[name=area]').prevObject;

    console.log(AreaInput);
    for(let i = 0 ; i < AreaEle.length -1 ; i++){
       console.log($(AreaInput[i]).data('code'));
       if (typeof resultList[i] == "undefined") {
            resultList[i] = {};
        }
        resultList[i] = {
            groupCode : $(AreaInput[i]).data('code'),
            deliTip : $(AreaInput[i]).find('div.sec-money input').val()
        }
    }
   
    $.ajax({
        method: 'post',
        async: true,
        url: "/naverMap/SetAreaGroup",
        data: {
            status: status,
            model:{
                AreaInfo : resultList
            }
        },
        success: function (data, status, xhr) {
            if (data.code = "00") {
                resultList = [];
                NewPopup.alertOkNo1("구역 및 저장",
                    "구역 팁 저장이 되었습니다.",
                    "확인",
                    function (res) {
                        if (res) {
                            return;
                        }
                    }
                 )
            }
        },
        error: function (xhr, status, data) {

        }
    });
}

function AreaDeleted(status) {
    var resultList = {};
    var AreaEle = $('.input-group-text');
    var AreaInput = AreaEle.closest('input[name=area]').prevObject;

    for (let i = 0; i < AreaEle.length - 1; i++) {
        console.log($(AreaInput[i]).data('code'));
        if (typeof resultList[i] == "undefined") {
            resultList[i] = {};
        }
        resultList[i] = {
            groupCode: $('[name=area]:checked').closest('.input-group-text').data('code')
        }
    }
    NewPopup.danger("구역 삭제",
        $('[name=area]:checked').attr('id') + "을(를) 삭제하시겠습니까?",
        "확인",
        "취소",
        function (res) {
            if (res) {
                

                $.ajax({
                    method: 'post',
                    async: true,
                    url: "/naverMap/SetAreaGroup",
                    data: {
                        status: status,
                        model: {
                            AreaInfo: resultList
                        }
                    },
                    success: function (data, status, xhr) {
                        if (data.code = "00") {
                            resultList = [];
                            NewPopup.alertOkNo1("구역 삭제",
                                "삭제되었습니다.",
                                "확인",
                                function (res) {
                                    if (res) {
                                        location.reload();
                                        return;
                                    }
                                }
                            );
               
                        }
                    },
                    error: function (xhr, status, data) {

                    }
                });
                return;
            }
        }
    );
}