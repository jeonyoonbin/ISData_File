﻿// 짝,짝  홀,짝
// 짝,홀  홀,홀
// 맵 인덱스 가공 작업 
function getZoomIndexPoint(mapData) {

    if (Object.keys(mapData).length == 0) {
        return;
    }
    let zoomList = Object.keys(mapData);
    console.log(zoomList);
    zoomList.sort(function (a, b) {
        console.log(a + "," + b);
        return b - a;
    });
    console.log('before : ');
    console.log(mapData);
    for (let i = 0; i < zoomList.length; i++) {
        let mapZoom = zoomList[i];

        
        let ignoreList = [];
        let addList = {};
        let list = mapData[mapZoom];
        let zoom = mapZoom;
        let keyList = Object.keys(list);
        if (keyList.length < 4) {
            continue;
        }
        for (let key in list) {
            if (ignoreList.indexOf(key) >= 0) {
                continue;
            }
            let x = list[key]["x"];
            let y = list[key]["y"];
            let tip = list[key]["tip"];
            let checkObj = getPointPosition(x, y, zoom);
            let checkList = checkObj["checkList"];
            let defaultPoint = checkObj["defaultPoint"];
            let checkNum = 0;
            for (let i = 0; i < checkList.length; i++) {
                let SubMapData = list[checkList[i]];
                console.log(SubMapData);
                if (keyList.indexOf(checkList[i]) >= 0) {
                    if (tip == SubMapData["tip"]) {
                        checkNum++;
                    }
                        //
                    
                }
            }
            console.log(checkNum);

            if (checkNum == 3) {
                ignoreList.push(...checkList);
                let zoomIndex = zoom - 1;
                let customX = defaultPoint.x / 2;
                let customY = defaultPoint.y / 2;
                let pointIndex = zoomIndex + "_" + customX + "_" + customY;
                if (typeof mapData[zoomIndex] == "undefined") {
                    mapData[zoomIndex] = {};
                }
                mapData[zoomIndex][pointIndex] = {
                    zoom: zoomIndex,
                    x: customX,
                    y: customY,
                    tip: tip
                };

                /*if(mapData[zoomindex] == )*/
            } else {
                addList[key] = list[key];
            }
        }
        mapData[zoom] = addList;

        if (Object.keys(mapData[zoom]).length <= 0) {
            delete mapData[zoom];
        }
    }
    
    return mapData;
}

// 축소 포인트 되기 위한 포인트 리스트 
function getPointPosition(x, y, zoom) {
    let a = x % 2;
    let b = y % 2;

    let checkList = [];
    let obj = {};
    if (a == 0 && b == 0) {
        // 짝짝
        obj["defaultPoint"] = { x: x, y: y };
        checkList.push(zoom + "_" + (x + 1) + "_" + y)       //2번
        checkList.push(zoom + "_" + x + "_" + (y + 1))       //3번
        checkList.push(zoom + "_" + (x + 1) + "_" + (y + 1)) //4번
    } else if (a == 1 && b == 0) {
        // 홀짝
        let defaultPoint = { x: (x - 1), y: y };
        obj["defaultPoint"] = defaultPoint;
        checkList.push(zoom + "_" + (x - 1) + "_" + y)            //1번
        checkList.push(zoom + "_" + (x - 1) + "_" + (y + 1)) //3번
        checkList.push(zoom + "_" + x + "_" + (y + 1))       //4번
    } else if (a == 0 && b == 1) {
        // 짝홀
        let defaultPoint = { x: x, y: (y - 1) };
        obj["defaultPoint"] = defaultPoint;
        checkList.push(zoom + "_" + x + "_" + (y - 1))            //1번
        checkList.push(zoom + "_" + (x + 1) + "_" + (y - 1)) //2번
        checkList.push(zoom + "_" + (x + 1) + "_" + y)       //4번
    } else {
        // 홀홀
        let defaultPoint = { x: (x - 1), y: (y - 1) };
        obj["defaultPoint"] = defaultPoint;
        checkList.push(zoom + "_" + (x - 1) + "_" + (y - 1))            //1번
        checkList.push(zoom + "_" + x + "_" + (y - 1))       //2번
        checkList.push(zoom + "_" + (x - 1) + "_" + y)       //3번
    }

    obj["checkList"] = checkList;
    return obj;
}

// 확대 포인트 좌표 리스트 
function getMinSizePointList(zoom, x, y) {
    let obj = [];
    if (zoom = 21) {
        return;
    }

    let defaultX = x * 2;
    let defaultY = y * 2;
    obj.push(defaultX, defaultY)        // 1번
    obj.push((x + 1) + "_" + y)         // 2번
    obj.push(x + "_" + (y + 1))         // 3번
    obj.push((x + 1) + "_" + (y + 1))   // 4번
    return obj;
}

// DB에 저장될 인덱스 정보 리스트 
function getInsertMapList(shopCode, mapData) {
    let mapList = [];
    for (let zoom in mapData) {
        let obj = mapData[zoom];
        for (let key in obj) {
            let x = obj[key]["x"];
            let y = obj[key]["y"];

            let mapIndex = zoom + "_" + x + "_" + y;
            mapList.push({
                SHOP_CD: shopCode,
                MAP_INDEX: mapIndex
            });
        }
    }

    return mapList;
}

var zoomMin = 14;
var zoomMax = 21;
var ignoreList = {};
function setIgnorePosition(x, y, zoom, tip) {
    if (zoom == zoomMin) {
        return 0;
    }
    let checkX = x;
    let checkY = y;

    if (typeof ignoreList[tip] == "undefined") {
        ignoreList[tip] = {};
    }

    for (let i = zoom; i > zoomMin; i--) {
        let pointInfo = getPointPosition(checkX, checkY, i);

        let defaultPoint = pointInfo["defaultPoint"];
        let zoomIndex = i - 1;
        let customX = defaultPoint.x / 2;
        let customY = defaultPoint.y / 2;
        let pointIndex = zoomIndex + "_" + customX + "_" + customY;

        ignoreList[tip][pointIndex] = 1;
        checkX = customX;
        checkY = customY;
    }
    
}
function delIgnorePosition(x, y, zoom, tip) {
    if (zoom == zoomMin) {
        return 0;
    }
    let checkX = x;
    let checkY = y;

    if (typeof ignoreList[tip] == "undefined") {
        ignoreList[tip] = {};
    }

    for (let i = zoom; i > zoomMin; i--) {
       
        let pointInfo = getPointPosition(checkX, checkY, i);

        let defaultPoint = pointInfo["defaultPoint"];
        let zoomIndex = i - 1;
        let customX = defaultPoint.x / 2;
        let customY = defaultPoint.y / 2;
        let pointIndex = zoomIndex + "_" + customX + "_" + customY;

        delete ignoreList[tip][pointIndex];
        checkX = customX;
        checkY = customY;
    }
}

function getUpTileList(x, y, zoom) {
    //if (zoom == zoomMin) {
    //    return 0;
    //}

    zoomMin = 14;
    let checkX = x;
    let checkY = y;
    let list = {};
    if (typeof list[zoom] == "undefined") {
        list[zoom] = {};
    }
    let first = zoom + "_" + x + "_" + y;
    list[zoom][first] =1;
    for (let i = zoom; i > zoomMin; i--) {
        
        let pointInfo = getPointPosition(checkX, checkY, i);

        let defaultPoint = pointInfo["defaultPoint"];
        let zoomIndex = i - 1;
        let customX = defaultPoint.x / 2;
        let customY = defaultPoint.y / 2;
        let pointIndex = zoomIndex + "_" + customX + "_" + customY;
       // list.push(pointIndex);
        if (typeof list[zoomIndex] == "undefined") {
            list[zoomIndex] = {};
        }
        list[zoomIndex][pointIndex] = 1;
        checkX = customX;
        checkY = customY;
    }
    return list;
}

function getUpTileList_2(x, y, zoom) {
    //if (zoom == zoomMin) {
    //    return 0;
    //}
    14

    zoomMin = 21;
    let checkX = x;
    let checkY = y;
    let list = {};
    if (typeof list[zoom] == "undefined") {
        list[zoom] = {};
    }
    let first = zoom + "_" + x + "_" + y;
    list[zoom][first] = 1;
    for (let i = zoom; i < zoomMin; i++) {

        let pointInfo = getPointPosition(checkX, checkY, i);
        console.log(pointInfo);
        let defaultPoint = pointInfo["defaultPoint"];
        let zoomIndex = i + 1;
        let customX = defaultPoint.x * 2;
        let customY = defaultPoint.y * 2;
        let pointIndex = zoomIndex + "_" + customX + "_" + customY;
        // list.push(pointIndex);
        if (typeof list[zoomIndex] == "undefined") {
            list[zoomIndex] = {};
        }
        list[zoomIndex][pointIndex] = 1;
        checkX = customX;
        checkY = customY;
    }
    return list;
}
function checkPosition(x, y, zoom, tip) {
    let checkNum = 0;
    let checkIndex = zoom + "_" + x + "_" + y;
    for (let key in ignoreList) {
        if (tip == parseInt(key)) {
            continue;
        }
        if (ignoreList[key][checkIndex] == 1) {
            checkNum++;
            break;
        }
    }
    // 이미 다른 구역에서 존재할때 false
    if (checkNum > 0) {
        console.log("11")
        return false;
    } else {
        // 이미 다른 구역에서 존재하지 않을때 true
       // console.log("22")
        return true;
    }
}
function GetTileUpscale(){

}


function DeleteSetAreaTile(xIndex, yIndex, zoom){
    let x = xIndex % 2;
    let y = yIndex % 2;
    if(x == 0 && y == 0){
        let rect_tl  = tileClickTopLeft(xIndex, yIndex, zoom);
        let rect_br  = tileClickBottomRight(Math.abs(xIndex + 1), Math.abs(yIndex + 1), zoom)
        //중심좌표 
        Rectanglelist = new naver.maps.Rectangle({
            bounds: new naver.maps.LatLngBounds(
                new naver.maps.LatLng(rect_tl._lat, rect_tl._lng),
                new naver.maps.LatLng(rect_br._lat, rect_br._lng)
            ),
            fillColor: "#1fcaff",
            fillOpacity: 0.3,
            strokeColor: "#1fcaff",
            strokeOpacity: 0.5,
            clickable: true,
            map: initMap
        });
    }else if(x == 1 && y == 0){
        let rect_tl  = tileClickTopLeft(xIndex, yIndex, zoom);
        let rect_br  = tileClickBottomRight(Math.abs(xIndex + 1), Math.abs(yIndex + 1), zoom)
        //중심좌표 
        Rectanglelist = new naver.maps.Rectangle({
            bounds: new naver.maps.LatLngBounds(
                new naver.maps.LatLng(rect_tl._lat, rect_tl._lng),
                new naver.maps.LatLng(rect_br._lat, rect_br._lng)
            ),
            fillColor: "#1fcaff",
            fillOpacity: 0.3,
            strokeColor: "#1fcaff",
            strokeOpacity: 0.5,
            clickable: true,
            map: initMap
        });
    }else if(x == 0 && y == 1){
        let rect_tl  = tileClickTopLeft(xIndex, yIndex, zoom);
        let rect_br  = tileClickBottomRight(Math.abs(xIndex + 1), Math.abs(yIndex + 1), zoom)
        //중심좌표 
        Rectanglelist = new naver.maps.Rectangle({
            bounds: new naver.maps.LatLngBounds(
                new naver.maps.LatLng(rect_tl._lat, rect_tl._lng),
                new naver.maps.LatLng(rect_br._lat, rect_br._lng)
            ),
            fillColor: "#1fcaff",
            fillOpacity: 0.3,
            strokeColor: "#1fcaff",
            strokeOpacity: 0.5,
            clickable: true,
            map: initMap
        });
    }else {
        let rect_tl  = tileClickTopLeft(xIndex, yIndex, zoom);
        let rect_br  = tileClickBottomRight(Math.abs(xIndex + 1), Math.abs(yIndex + 1), zoom)
        //중심좌표 
        Rectanglelist = new naver.maps.Rectangle({
            bounds: new naver.maps.LatLngBounds(
                new naver.maps.LatLng(rect_tl._lat, rect_tl._lng),
                new naver.maps.LatLng(rect_br._lat, rect_br._lng)
            ),
            fillColor: "#1fcaff",
            fillOpacity: 0.3,
            strokeColor: "#1fcaff",
            strokeOpacity: 0.5,
            clickable: true,
            map: initMap
        });
    }
}