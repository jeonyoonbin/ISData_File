﻿//LoadMap();



var mapType = {
    name: "line",
    minZoom: 0,
    maxZoom: 22,
    tileSize: new N.Size(50, 50),
    getTileData: function (x, y, z) {
        var w = this.tileSize.width,
            h = this.tileSize.height,
            canvas = document.createElement("canvas"),
            context = canvas.getContext("2d");

        var lineNumber = 1;
        line = lineNumber++;

        canvas.width = w;
        canvas.height = h;

        context.globalAlpha = 0.2;

        context.rect(0, 0, w, h);
        context.fillStyle = "#000";
        context.fill();
        context.lineWidth = 1;
        context.strokeStyle = "#aaa";
        context.stroke();

        context.font = "blod " + line + "px";
        context.textBaseline = "middle";
        context.textAlign = "center";
        context.fillStyle = "#fff";
        context.fillText(line, w / 2, h / 2);

        return context.getImageData(0, 0, w, h);

    }
}
//canvasMap

//var CanvasMapTypeOptions = {
//    minZoom: 0,
//    maxZoom: 22,
//    Projection: naver.maps.EPSG3857,
//    name: '세계 지도',
//    tileSize: new naver.maps.Size(64, 64),
//    repeatX: true,
//    vendor: 'MyCorp',
//    provider: [{
//        title: "TEST MAP v 1.0",
//    }, {
//        title: "OpenStreetMap",
//        link: "http://wwww.openstreetmap.org/copyright"
//    }, {
//        title: "/대구광역시",
//        bounds: new naver.maps.LatLngBounds(
//            new N.LatLng(35.9066003, 128.5402184),
//            new N.LatLng(35.7819909, 128.7599449))
//    }],
//    getTileData: function (x, y, z) {
//        var canvas = document.createElement('canvas'),
//            ctx = canvas.getContext('2d');
//        var w = this.tileSize.width,
//            h = this.tileSize.height;

//        return ctx.getImageData(0, 0, w, h)
//    }
//};

var map = new naver.maps.Map('map', {
    center: new naver.maps.LatLng(35.8709977, 128.5842066),
    zoom: 14,
    minZoom: 1,
    maxZoom: 21,
    //zoomControlOptions: {
    //    style: naver.maps.ZoomControlStyle.LARGE,
    //    position: naver.maps.Position.TOP_LEFT
    //},
    //mapTypeId: "line",
    //mapTypes: new N.PaneTypeRegistry({
    //    "line": new N.CanvasMapType(CanvasMapTypeOptions)
    //}),
    tileSize: new naver.maps.Size(64, 64),
    mapTypeControl: true,
    mapTypeControlOptions: {
        style: naver.maps.MapTypeControlStyle.DROPDOWN
    }
});

// var CanvasMapType = new naver.maps.CanvasMapType(CanvasMapTypeOptions)

// 폴리곤 
//InitNaverAjax();
/**
 *  타일 그리드 안됨 02.19
 * 
 * */
var tileGridLayer = new naver.maps.Layer('tileGrid', {
    name: "TileGrid",
    minZoom: 1,
    maxZoom: 16,
    //tileSize: new naver.maps.Size(parseInt(64, 10), parseInt(64, 10)),
    tileSize: new naver.maps.Size(256, 256),
    overlayMap: true,
    getTile: function (x, y, z) {
        var squareline = 0;

        var w = this.tileSize.width;
        var h = this.tileSize.height;

        //console.log(this.getTile.Global);

        switch (z) {
            case 21:
                squareline = 16;
                break;

        }

        var div = $('<div class="tilegrid">(' + [z, x, y].join(', ') + ')<br> 크기 :' + squareline + '<br> w  :' + w + '<br> h  :' + h + '</div>');
        return div[0];
    }
});

$(document).ready(function () {


});
//tileGridLayer.setTile(17, 112349, 51530);
tileGridLayer.setMap(map);
tileGridLayer.refresh(true);
map.refresh(true);
var marker;
//naver.map.Event.addListener(map, 'mapType_changed', function (options) {
//    console.log(options);
//});
naver.maps.Event.addListener(map, 'click', function (e) {

    var mapwitdh = 256 * Math.pow(2, map.getZoom());
    console.log(mapwitdh);
    var mapHeight = mapwitdh;

    var sinLatitude = Math.sin(e.coord._lat * Math.PI / 180);
    var pixelX = ((e.coord._lng + 180) / 360) * 256 * Math.pow(2, map.getZoom());
    var pixelY = (0.5 - Math.log((1 + sinLatitude) / (1 - sinLatitude)) / (4 * Math.PI)) * 256 * Math.pow(2, map.getZoom());


    var tileX = Math.floor(pixelX / 256),
        tileY = Math.floor(pixelY / 256);

    //타일좌표
    var numberOfTilesWide = Math.pow(2, map.getZoom());

    var numberOfTilesHigh = numberOfTilesWide;


    var Marker = new N.Marker({
        position: new N.LatLng(pixelX, pixelY),
        map: map
    });

    console.log(pixelX);

    console.log(pixelY);

    var latlng = e.coord,
        utmk = naver.maps.TransCoord.fromLatLngToUTMK(latlng),
        tm128 = naver.maps.TransCoord.fromUTMKToTM128(utmk);
    var _projection = map.getProjection();


    //map.setPosition(tileX, tileY);
    //console.log("----------------------start");

    //console.log(_projection);
    //console.log(_projection.fromPointToCoord(e.point));

    //console.log("----------------------projection END");
    //console.log(map.getZoom());

    //console.log(utmk);
    //console.log(tm128);
    //console.log("----------------------");
    //console.log(e);
    //console.log(e.coord);
    //var pointDiv = new N.Point(e.point);
    //console.log(pointDiv);
    //console.log("----------------------END");

    //console.log(_projection.__targets.projection.target.tileIndexArray);
    //var Rect_index = _projection.__targets.projection.target;
    //let p_bottomR = Rect_index.projectionBottomRight;
    //let p_topl = Rect_index.projectionTopLeft;

    //console.log("---------------------------------------");

    //console.log(Rect_index.tileIndexArray.__targets.centerPoint.)

    //console.log(_projection.fromPointToCoord(p_bottomR));
    //console.log(_projection.fromPointToCoord(p_bottomR).getTileCount);
    //console.log("---------------------------------------");
    //console.log(tileGridLayer.getMap());
    //console.log(tileGridLayer.getMap().__targets.rotation_m.target.center);
    if (marker) {

        marker.setPosition(e.coord);
        // PointToAddress(e.coord);
    }
});
    /**
 KVO
 */


    //var contentEl = $('img');
    //naver.maps.Event.addListener(map, 'Tile_changed', function (tileOptions) {
    //    tileOptions.tileSize(50, 50);
    //});
    //var poligon = new N.Polygon({
    //    map: map,
    //    paths: [
    //        itemList
    //    ],
    //    fillColor: 'red',
    //    fillOpacity: 0.2,
    //    strokeWeight: 2,
    //    strokeColor: 'red',
    //    clickable: true,
    //});