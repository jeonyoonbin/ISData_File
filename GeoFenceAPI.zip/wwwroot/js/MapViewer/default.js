﻿
// Global var
var position = new N.LatLng(35.86094, 128.56775);
var marker = [];
var check_Items = [];
var temp = {}
var difftemp = {};
var vaildcheck = {};
var overlapTemp = {};
var MapStack = new MapAreaStack();
var imgTileSize = 128;
var naverNormalMapType = naver.maps.NaverStyleMapTypeOptions.getNormalMap();


var tooltip = $('<ul style="position: absolute; padding: 0px; cursor: pointer; margin: 0px; list-style: none' +
    'font - size: 13px; background: rgb(255, 255, 255); color: rgb(0, 0, 0); z - index: 1;' +
    'box - shadow: rgba(0, 0, 0, 0.3) 0px 1px 2px 0.5px; box - sizing: content - box!important;' +
    'left: 335px; top: 446px; ">' +
    '<li style = "margin: 0px; padding: 4px 14px; background: rgb(255, 255, 255); " >삭제</li></ul >');

//map
initMap = new N.Map('map', {
    center: position,
    zoomControl: true,
    zoomControlOptions: {
        style: naver.maps.ZoomControlStyle.LARGE,
        position: naver.maps.Position.TOP_LEFT
    },
    mapTypeControl: false,
    zoom: 13,
    minZoom: 14
});
//rectangle 
//var Rectanglelist = new naver.maps.Rectangle({
//    fillColor: "#1fcaff",
//    fillOpacity: 0.3,
//    strokeColor: "#1fcaff",
//    strokeOpacity: 0.5,
//    clickable: true,
//    map: map
//});
// function 

$(function () {



    //TileGrid
    var tileGridLayer = new naver.maps.Layer('tileGrid', {
        name: "TileGrid",
        minZoom: 13,
        maxZoom: 22,
        tileSize: new naver.maps.Size(imgTileSize, imgTileSize),
        getTile: function (x, y, z) {
            var div = $('<div class="tilegrid" id=' + x + y + '></div>');

            return div[0];
        }
    });
    //marker


    //Listener Event
    //naver.maps.Event.addListener(initMap, 'click', function (e) {
    //    //marker.setPosition(e.coord);
    //    //e.coord lat lng value
    //    console.log(e.point)

    //    //  console.log(e.coord);

    //    // click var
    //    var tileSize = initMap.getMapType().tileSize.width;
    //    var projection = initMap.getProjection();
    //    //var center = map.getCenter();
    //    // console.log(projection);
    //    //console.log(center);
    //    var zoom = initMap.getZoom();
    //    var centerPixel = projection.fromCoordToPoint(e.coord);

    //    // console.log(centerPixel);
    //    var xPixel = Math.floor(projection.scaleUp(centerPixel.x, zoom));
    //    var yPixel = Math.floor(projection.scaleUp(centerPixel.y, zoom));
    //    var xIndex = Math.floor(xPixel / tileSize);
    //    var yIndex = Math.floor(yPixel / tileSize);

    //    //  console.log(e.coord.x);
    //    //  console.log(e.coord.y);

    //    //  console.log(projection.scaleUp(centerPixel.x, zoom));

    //    //click Tile index 
    //    //   console.log("click : Tile gird index Value");
    //    //   console.log("x :" + xIndex);
    //    //   console.log("y :" + yIndex);
    //    // search div id selection
    //    //   console.log($('#' + xIndex + yIndex));
    //    //$('#' + xIndex + yIndex).css('color', "red");
    //    //$('#' + xIndex + yIndex).css('opacity', "0.4");
    //    //$('#' + xIndex + yIndex).css('background', "#1fcaff");6
    //    //var overlap = ValidLatLngCheck(temp, e.coord.x, e.coord.y, zoom, CoordToPoint);
    //    CoordToPoint(e.coord.x, e.coord.y, zoom);
    //    //if (!overlap) {
    //    //    return false;
    //    //}
    //    var RectangleVaild = getPointPosition(xIndex, yIndex, zoom);

    //    //   console.log(RectangleVaild);
    //    var centerpoint = new N.Point((xIndex * tileSize) + (tileSize / 2), ((e.coord.y + 1) * tileSize) + (tileSize / 2));
    //    var itemx = Math.PI - 2 * Math.PI * yPixel / (1 << zoom);
    //    var n = Math.pow(2, zoom);
    //    var t_tileY = xIndex / n * 360.0 - 180.0;
    //    var lat_rad = Math.atan(Math.sinh(Math.PI * (1 - 2 * yIndex / n)));
    //    var t_tilex = lat_rad * 180.0 / Math.PI;
    //    //console.log(c_tilex);
    //    //console.log(c_tileY);
    //    //console.log( 180 / Math.PI * Math.atan( 0.5 * (Math.exp(zoom) - Math.exp(itemx))));
    //    //

    //    //   console.log()
    //    //  console.log(centerpoint);
    //    //marker.setPosition(new N.LatLng(t_tileY, t_tilex));
    //    var tl = tileClickTopLeft(xIndex, yIndex, zoom);
    //    var br = tileClickBottomRight(Math.abs(xIndex + 1), Math.abs(yIndex + 1), zoom)
    //    //Rectanglelist = new naver.maps.Rectangle({
    //    //    bounds: new N.LatLngBounds(
    //    //        new N.LatLng(tl._lat, tl._lng),
    //    //        new N.LatLng(br._lat, br._lng)
    //    //    ),
    //    //    fillColor: "#ff0000",
    //    //    fillOpacity: 0.3,
    //    //    strokeColor: "#f00",
    //    //    strokeOpacity: 0.5,
    //    //    clickable : true,
    //    //    map: map
    //    //});

    //    let MapAreaIndex = [];
    //    ReactangleSet(tl, br, zoom, tipTypeseletor(), e.coord, "", "");
    //    //MapStack.push(MapAreaIndex);


    //    //if (typeof MapAreaStack[0] == "undefined") {
    //    //    MapAreaStack[0] = {};
    //    //}
    //    //for (let numning = 0; i < MapStack.length(); i++) {
    //    //    MapAreaIndex[numning] = zoom
    //    //}


    //    //MapStack.pop()

    //    //  console.log(tileClickTopLeft(xIndex, yIndex, zoom));
    //    //  console.log(br);
    //    // console.log();
    //    var Items = {
    //        zoom: zoom,
    //        list: {
    //            x: xIndex,
    //            y: yIndex
    //        }
    //    };
    //    var clickList = [];



    //    //console.log(functionTemp);

    //    check_Items.push(Items);
    //    //   console.log(check_Items);
    //    //  console.log(RectangleVaild);


    //    setIgnorePosition(xIndex, yIndex, zoom, tipTypeseletor());
    //    // switch (tipTypeseletor()) {
    //    //     case "tip1":
    //    //         setIgnorePosition(xIndex, yIndex, zoom, "tip1");
    //    //         break;
    //    //     case "tip2":
    //    //         setIgnorePosition(xIndex, yIndex, zoom, "tip2");
    //    //         break;
    //    //     default:
    //    //         console.log("none selector");
    //    //         break;
    //    // }


    //    OverLapCheck(xIndex, yIndex, zoom);

    //    //CoordToPoint(e.coord.x, e.coord.y);
    //    //marker.setPosition(t_tileY,t_tilex);

    //});
    //tooltip.appendTo(map.getPanes().floatPane);
    changeTileSize(initMap, imgTileSize);
    tileGridLayer.setMap(initMap);
    initMap.refresh(true);


});

function tileClickTopLeft(x, y, z) {
    let n = Math.pow(2, z);
    let y_rad = Math.atan(Math.sinh(Math.PI * (1 - 2 * y / n)));
    let coordX = x / n * 360.0 - 180.0;
    let coordY = y_rad * 180.0 / Math.PI;

    let coord = {
        _lat: coordY,
        _lng: coordX,
    }
    return coord;
}
function tileClickBottomRight(x, y, z) {
    let n = Math.pow(2, z);
    let y_rad = Math.atan(Math.sinh(Math.PI * (1 - 2 * y / n)));
    let coordX = x / n * 360.0 - 180.0;
    let coordY = y_rad * 180.0 / Math.PI;

    let coord = {
        _lat: coordY,
        _lng: coordX
    }
    return coord;
}
async function ValidLatLngCheck(objTemp, x, y, z, callback) {

    let zoom = z;

    let maxZoom = 21;
    let difference = [];
    let objList = Object.keys(objTemp);


    if (typeof vaildcheck[zoom] == "undefined") {
        return;
    }
    for (let i = 0; i < maxZoom + 1 - zoom; i++) {
        let loopZoom = zoom + i;
        for (let j = 0; j < objList.length; j++) {
            if (objList[j] == loopZoom) {
                difference = Object.keys(objTemp[loopZoom]).filter(x => Object.keys(vaildcheck[loopZoom]).includes(x));
            } else {
                console.log("없");
            }
        }

    }
    console.log(difference);

    if (Object.keys(difference).length > 0) {
        return true;
    }
    //초기화
    vaildcheck = {};
    return false;
}

function OverLapCheck(xIndex, yIndex, zoom) {
    let resultZoom = Object.keys(temp); //가지고있는 맵정보 /14 15 16 17 18 19 20 
    let zoomLevel = zoom; // 현재 클릭 줌레벨   /17 
    let overList = {};
    for (let i = 0; i < resultZoom.length; i++) {
        if (resultZoom[i] < zoomLevel) {
            let defaultZoom = Math.pow(2, resultZoom[i]);
            let value = temp[resultZoom[i]];
            console.log(value);
            //let obj = { zoom: zoomLevel, x: xIndex, y: yIndex };
            //let index = zoomLevel + "_" + xIndex + "_" + yIndex;
            //temp[zoomLevel][index] = obj;
        }
    }
}

async function ReactangleSet(tl, br, z, tipType, coord, x, y) {

    var tileSize = initMap.getMapType().tileSize.width;
    var projection = initMap.getProjection();
    //var center = map.getCenter();
    //console.log(projection);
    //console.log(center);
    //console.log(tl);
    var zoomLevel = parseInt(z);
    var booleasy = "";
    console.log();
    //console.log(coord);

    // console.log(new naver.maps.LatLng(Math.floor(tl._lat * 10000000) / 10000000, Math.floor(tl._lng * 10000000) / 10000000));
    //var tarm = new naver.maps.TransCoord.fromLatLngToEPSG3857(new naver.maps.LatLng(tl._lat, tl._lng));
    var centerPixel = projection.fromCoordToPoint(coord);
    var tipNum = "";
    //console.log("----");
    if (coord == '') {
        var xIndex = x
        var yIndex = y;
        //console.log(xIndex);
        //console.log (yIndex);
        if (tl == '' && br == '') {
            tl = tileClickTopLeft(xIndex, yIndex, zoomLevel);
            br = tileClickBottomRight(Math.abs(xIndex + 1), Math.abs(yIndex + 1), zoomLevel);
        }
        //console.log(tl);
        tipNum = tipType;
    } else {
        var xPixel = Math.floor(projection.scaleUp(centerPixel.x, zoomLevel));
        var yPixel = Math.floor(projection.scaleUp(centerPixel.y, zoomLevel));
        var xIndex = Math.floor(xPixel / tileSize);
        var yIndex = Math.floor(yPixel / tileSize);
        tipNum = tipType;
    }

    booleasy = await checkPosition(xIndex, yIndex, zoomLevel, tipNum);
    console.log(booleasy);
    if (!booleasy) {
        NewPopup.alertOkNo1("배달지역",
            "다른 배달구역이 존재합니다. 제거 후 이용 부탁드립니다.",
            "확인",
            function (res) {
                if (res) {
                    return;
                }
            }
        );
        return;
    }

    if (typeof temp[zoomLevel] == "undefined") {
        temp[zoomLevel] = {};
    }


    var obj = { zoom: zoomLevel, x: xIndex, y: yIndex, tip: tipNum };
    var index = zoomLevel + "_" + xIndex + "_" + yIndex;
    temp[zoomLevel][index] = obj;


    // console.log(tipNum);
    rectangle_1(tl, br, tipNum);
    // console.log(temp);
    // switch (tipType) {
    //     case "tip1":
    //         rectangle_1(tl,br,tipNum);
    //         break;
    //     case "tip2":
    //         rectangle_2(tl, br, tipNum);
    //         break;
    //     default:
    //         console.log("none selector");
    //         break;
    // }
}
/**
 * tip1
 * @param {topLeft} tl
 * @param {bottomRight} br
 */
function rectangle_1(tl, br, tipNum) {
    let tempSpl = tipNum.split("구역");

    let colorStr = AreaBackGroundColor(parseInt(tempSpl[1]));
    //console.log(colorStr);
    var Rectanglelist = new naver.maps.Rectangle({
        bounds: new naver.maps.LatLngBounds(
            new naver.maps.LatLng(tl._lat, tl._lng),
            new naver.maps.LatLng(br._lat, br._lng)
        ),
        fillColor: colorStr,
        fillOpacity: 0.3,
        strokeColor: colorStr,
        strokeOpacity: 0.5,
        clickable: true,
        map: initMap
    });
    // console.log(Rectanglelist.getDrawingRect());
    //naver.maps.Event.addListener(Rectanglelist, 'rightclick', function (e) {
    //    var tileSize = initMap.getMapType().tileSize.width;
    //    var projection = initMap.getProjection();
    //    var zoom = initMap.getZoom();
    //    var centerPixel = projection.fromCoordToPoint(e.coord);
    //    var xPixel = Math.floor(projection.scaleUp(centerPixel.x, zoom));
    //    var yPixel = Math.floor(projection.scaleUp(centerPixel.y, zoom));
    //    var xIndex = Math.floor(xPixel / tileSize);
    //    var yIndex = Math.floor(yPixel / tileSize);

    //    console.log(Rectanglelist.getDrawingRect())
    //    if (typeof difftemp[zoom] == "undefined") {
    //        difftemp[zoom] = {};
    //    }

    //    var obj = { zoom: zoom, x: xIndex, y: yIndex };
    //    console.log(e);
    //    console.log(obj);
    //    var tempList = getUpTileList(xIndex, yIndex, zoom);
    //    var index = zoom + "_" + xIndex + "_" + yIndex;
    //    difftemp[zoom][index] = obj;
    //    console.log(difftemp);
    //    console.log(temp);
    //    let dif = Object.keys(temp).filter(x => Object.keys(tempList).includes(x));
    //    console.log(dif);
    //    console.log(tempList);
    //    let zoomAreaOverlap = true;
    //    let difnumber = Object.keys(tempList);
    //    let tempKeys = Object.keys(temp);
    //    let themeTemp = temp;
    //    let iscomTemp = [];
    //    for (let i = 0; i < difnumber.length; i++) {
    //        console.log(difnumber[i]);
    //        if (parseInt(tempKeys[i]) > parseInt(Object.keys(tempList)[i])) {
    //            let min = parseInt(tempKeys[i]);
    //            let max = parseInt(Object.keys(tempList)[i]);
    //            let isEmtp = max - min;

    //            for (let loopCnt = max; loopCnt < min; loopCnt++) {
    //                if (typeof themeTemp[loopCnt] == "undefined") {
    //                    themeTemp[loopCnt] = {};
    //                }
    //                themeTemp[loopCnt][loopCnt + "_0_0"] = {
    //                    zoom: loopCnt,
    //                    x: 0,
    //                    y: 0,
    //                    tip: tipNum
    //                }
    //            }
    //            i = i + 0;
    //            continue;
    //        } else {
    //            iscomTemp = Object.keys(Object.entries(temp)[i][1]).filter(x => Object.keys(Object.entries(tempList)[i][1]).includes(x));
    //        }
    //        let areaIndex = [];
    //        if (Object.keys(temp).filter(x => zoom.toString().includes(x)).length > 0) {
    //            areaIndex = Object.keys(temp[zoom]).filter(function (str) { return str.includes(index) });
    //        } else {

    //        }
    //        if (areaIndex.length > 0) {

    //            let tempIndex = areaIndex[0];
    //            let tempSplit = tempIndex.split('_');
    //            console.log(tempSplit[1] + "_" + tempSplit[2]);
    //            delete temp[tempSplit[0]][tempIndex];
    //            delIgnorePosition(tempSplit[1], tempSplit[2], tempSplit[0], tipNum);
    //            Rectanglelist.setMap(null);
    //            break;
    //        }

    //        let comTemp = [];
    //        if (iscomTemp.length > 0) {
    //            console.log(iscomTemp);
    //            comTemp.push(Object.keys(tempList[difnumber[i]]));
    //        } else {
    //            continue;
    //        }


    //        console.log(comTemp);

    //        if (comTemp.length > 0) {
    //            delete temp[dif[i]][comTemp[0]];
    //            let comTempStr = comTemp[0] + "";
    //            console.log(comTempStr);
    //            let IgnorekeyStr = comTempStr.split('_');
    //            delIgnorePosition(IgnorekeyStr[1], IgnorekeyStr[2], IgnorekeyStr[0], tipNum);
    //            let tempRectangle = {};
    //            if (typeof tempRectangle[dif[i]] == "undefined") {
    //                tempRectangle[dif[i]] = {};
    //            }

    //            tempRectangle[dif[i]][comTemp] = {
    //                zoom: parseInt(IgnorekeyStr[0]),
    //                x: parseInt(IgnorekeyStr[1]),
    //                y: parseInt(IgnorekeyStr[2]),
    //                tip: tipNum
    //            };
    //            console.log("현재 좌표");
    //            console.log(index);
    //            console.log("최상단의 기준 좌표");
    //            console.log(tempRectangle);
    //            let ZoomRectangle = getZoomIndexPoint(tempRectangle);
    //            console.log(ZoomRectangle);

    //            console.log(parseInt(IgnorekeyStr[0]));

    //            //if(parseInt(IgnorekeyStr[0]) <= 14){
    //            //continue;
    //            Rectanglelist.setMap(null);
    //            let isEvenX = xIndex % 2 == 0 ? 0 : 1;
    //            let isEvenY = yIndex % 2 == 0 ? 0 : 1;
    //            // if(IgnorekeyStr[0] == '14'){ // 16-- 15--  
    //            for (let tempIndex = zoom; tempIndex > parseInt(IgnorekeyStr[0]); tempIndex--) {


    //                let xidx = Math.floor(parseInt(xIndex) / Math.pow(2, (zoom - tempIndex)));
    //                let yidx = Math.floor(parseInt(yIndex) / Math.pow(2, (zoom - tempIndex)));
    //                let xTile = xidx % 2;
    //                let yTile = yidx % 2;
    //                console.log(xidx + "||" + yidx + "||" + tempIndex);
    //                if (xTile == 0 && yTile == 0) {
    //                    console.log(xidx);
    //                    setIgnorePosition(xidx + 1, yidx, tempIndex, tipNum);
    //                    setIgnorePosition(xidx, yidx + 1, tempIndex, tipNum);
    //                    setIgnorePosition(xidx + 1, yidx + 1, tempIndex, tipNum);

    //                    ReactangleSet('', '', tempIndex, tipNum, '', xidx + 1, yidx);
    //                    ReactangleSet('', '', tempIndex, tipNum, '', xidx, yidx + 1);
    //                    ReactangleSet('', '', tempIndex, tipNum, '', xidx + 1, yidx + 1);
    //                } else if (xTile == 1 && yTile == 0) {
    //                    console.log(xidx);
    //                    setIgnorePosition(xidx - 1, yidx, tempIndex, tipNum); //  짝 짝
    //                    setIgnorePosition(xidx - 1, yidx + 1, tempIndex, tipNum); // 짝 홀
    //                    setIgnorePosition(xidx, yidx + 1, tempIndex, tipNum); //  홀 홀 

    //                    ReactangleSet('', '', tempIndex, tipNum, '', (xidx - 1), yidx);
    //                    ReactangleSet('', '', tempIndex, tipNum, '', (xidx - 1), (yidx + 1));
    //                    ReactangleSet('', '', tempIndex, tipNum, '', xidx, (yidx + 1));
    //                }
    //                else if (xTile == 0 && yTile == 1) {
    //                    console.log(xidx);
    //                    setIgnorePosition(xidx + 1, yidx - 1, tempIndex, tipNum); //홀 짝
    //                    setIgnorePosition(xidx, yidx - 1, tempIndex, tipNum);  // 짝 짝 
    //                    setIgnorePosition(xidx + 1, yidx, tempIndex, tipNum);   // 홀 홀 

    //                    ReactangleSet('', '', tempIndex, tipNum, '', xidx + 1, yidx - 1);
    //                    ReactangleSet('', '', tempIndex, tipNum, '', xidx, yidx - 1);
    //                    ReactangleSet('', '', tempIndex, tipNum, '', xidx + 1, yidx);
    //                } else {
    //                    console.log(xidx);
    //                    setIgnorePosition(xidx - 1, yidx - 1, tempIndex, tipNum);
    //                    setIgnorePosition(xidx, yidx - 1, tempIndex, tipNum);
    //                    setIgnorePosition(xidx - 1, yidx, tempIndex, tipNum);

    //                    ReactangleSet('', '', tempIndex, tipNum, '', xidx - 1, yidx - 1);
    //                    ReactangleSet('', '', tempIndex, tipNum, '', xidx, yidx - 1);
    //                    ReactangleSet('', '', tempIndex, tipNum, '', xidx - 1, yidx);
    //                }
    //            }
    //            // }

    //            continue;
    //            // }
    //            Rectanglelist.setMap(null);
    //            //for(let idx = parseInt(zoom); idx > parseInt(IgnorekeyStr[0]); idx--){
    //            console.log(xIndex + "||" + yIndex || zoom) //16 
    //            xIndex = parseInt(xIndex);
    //            yIndex = parseInt(yIndex);
    //            let idx = parseInt(zoom);
    //            let x = xIndex % 2;
    //            let y = yIndex % 2;

    //            if (x == 0 && y == 0) {
    //                setIgnorePosition(xIndex + 1, yIndex, idx, "tip1");
    //                setIgnorePosition(xIndex, yIndex + 1, idx, "tip1");
    //                setIgnorePosition(xIndex + 1, yIndex + 1, idx, "tip1");


    //                ReactangleSet('', '', idx, "tip1", '', xIndex + 1, yIndex);
    //                ReactangleSet('', '', idx, "tip1", '', xIndex, yIndex + 1);
    //                ReactangleSet('', '', idx, "tip1", '', xIndex + 1, yIndex + 1);
    //            }
    //            else if (x == 1 && y == 0) {
    //                setIgnorePosition(xIndex - 1, yIndex, idx, "tip1");
    //                setIgnorePosition(xIndex - 1, yIndex + 1, idx, "tip1");
    //                setIgnorePosition(xIndex, yIndex + 1, idx, "tip1");



    //                ReactangleSet('', '', idx, "tip1", '', xIndex - 1, yIndex);
    //                ReactangleSet('', '', idx, "tip1", '', xIndex - 1, yIndex + 1);
    //                ReactangleSet('', '', idx, "tip1", '', xIndex, yIndex + 1);
    //            }
    //            else if (x == 0 && y == 1) {
    //                setIgnorePosition(xIndex + 1, yIndex - 1, idx, "tip1");
    //                setIgnorePosition(xIndex, yIndex - 1, idx, "tip1");
    //                setIgnorePosition(xIndex + 1, yIndex, idx, "tip1");



    //                ReactangleSet('', '', idx, "tip1", '', xIndex + 1, yIndex - 1);
    //                ReactangleSet('', '', idx, "tip1", '', xIndex, yIndex - 1);
    //                ReactangleSet('', '', idx, "tip1", '', xIndex + 1, yIndex);
    //            } else {
    //                setIgnorePosition(xIndex - 1, yIndex - 1, idx, "tip1");
    //                setIgnorePosition(xIndex, yIndex - 1, idx, "tip1");
    //                setIgnorePosition(xIndex - 1, yIndex, idx, "tip1");



    //                ReactangleSet('', '', idx, "tip1", '', xIndex - 1, yIndex - 1);
    //                ReactangleSet('', '', idx, "tip1", '', xIndex, yIndex - 1);
    //                ReactangleSet('', '', idx, "tip1", '', xIndex - 1, yIndex);
    //            }
    //            //  }
    //            zoomAreaOverlap = false;
    //            comTemp = [];
    //        } else {
    //            zoomAreaOverlap = true;
    //        }
    //    }
    //    // if (zoomAreaOverlap) {
    //    //     alert("해당 줌레벨에서 삭제 영역이 존재하지않습니다" +
    //    //         "\n동일한 줌레벨로 이동후 삭제 처리 해주시기바랍니다");
    //    //     return;
    //    // }

    //    //console.log(compleTemp);
    //    //Rectanglelist.setMap(null);

    //    difftemp = [];
    //    console.log(e.coord);
    //});
}
/**
 * tip2
 * @param {topLeft} tl
 * @param {bottomRight} br
 */
function rectangle_2(tl, br, tipNum) {
    var Rectanglelist = new naver.maps.Rectangle({
        bounds: new naver.maps.LatLngBounds(
            new naver.maps.LatLng(tl._lat, tl._lng),
            new naver.maps.LatLng(br._lat, br._lng)
        ),
        fillColor: "#8977ad",
        fillOpacity: 0.3,
        strokeColor: "#8977ad",
        strokeOpacity: 0.5,
        clickable: true,
        map: initMap
    });
    naver.maps.Event.addListener(Rectanglelist, 'rightclick', function (e) {
        var tileSize = initMap.getMapType().tileSize.width;
        var projection = initMap.getProjection();
        var zoom = initMap.getZoom();
        var centerPixel = projection.fromCoordToPoint(e.coord);
        var xPixel = Math.floor(projection.scaleUp(centerPixel.x, zoom));
        var yPixel = Math.floor(projection.scaleUp(centerPixel.y, zoom));
        var xIndex = Math.floor(xPixel / tileSize);
        var yIndex = Math.floor(yPixel / tileSize);

        if (typeof difftemp[zoom] == "undefined") {
            difftemp[zoom] = {};
        }
        var obj = { zoom: zoom, x: xIndex, y: yIndex };
        var tempList = getUpTileList(xIndex, yIndex, zoom);
        var index = zoom + "_" + xIndex + "_" + yIndex;
        difftemp[zoom][index] = obj;
        console.log(difftemp);
        let zoomAreaOverlap = true;

        let dif = Object.keys(temp).filter(x => Object.keys(tempList).includes(x));
        console.log(dif);

        for (let i = 0; i < dif.length; i++) {
            let comTemp = Object.keys(temp[dif[i]]).filter(x => Object.keys(tempList[dif[i]]).includes(x));

            console.log(comTemp);

            if (comTemp.length > 0) {
                delete temp[dif[i]][comTemp];
                let IgnorekeyStr = comTemp[0].split('_');
                delIgnorePosition(IgnorekeyStr[1], IgnorekeyStr[2], IgnorekeyStr[0], tipNum);
                zoomAreaOverlap = false;
                break;
            } else {
                zoomAreaOverlap = true;
            }
        }
        if (zoomAreaOverlap) {
            alert("해당 줌레벨에서 삭제 영역이 존재하지않습니다" +
                "\n동일한 줌레벨로 이동후 삭제 처리 해주시기바랍니다");
            return;
        }


        //console.log(compleTemp);
        Rectanglelist.setMap(null);

        difftemp = [];
        console.log(e.coord);
    });
}

async function AreaData() {


    getParameter("shopCode");

   
    $.ajax({
        method: "POST",
        url: "/home/getAreaIndex",
        data: {
            ShopCode: getParameter("shopCode")
        },
        success: function (data, status, xhr) {
            console.log("data : ");
            console.log(data.data);



            if (typeof data.data != "undefined") {
                let typeList = Object.keys(data.data);
                console.log(typeList)
                //if (typeList.length == 1) {
                //    $('#tip1').siblings().eq(2).val(addComma(typeList[0]).toString());//2000
                //}

                if (typeList.length > 0) {
                    for (let i = 0; i < typeList.length; i++) {

                        //for (let eleindex = 0; i < $('.input-group-text').length - 1; eleindex++) {
                        //    let groupCode = $($('.input-group-text')[eleindex]).data('code');
                        //  //  if (groupCode == typeList[i].)
                        //}

                        //$('#M구역' + (i + 1)).val(addComma(typeList[i]));
                    }
                }
                // if (typeList.length == 2) {
                //     $('#tip1').siblings().eq(2).val(addComma(typeList[0]).toString());//2000
                //     $('#tip2').siblings().eq(2).val(addComma(typeList[1]).toString()); //5000
                // }
                for (let temp in data.data) {
                    //console.log(temp); //tip
                    let mapData = data.data[temp];

                    for (let item in mapData) {
                        let mapInfo = mapData[item];
                        let topleft = tileClickTopLeft(parseInt(mapInfo.xIndex), parseInt(mapInfo.yIndex), parseInt(mapInfo.zoom));
                        let botomright = tileClickBottomRight(parseInt(mapInfo.xIndex) + 1, parseInt(mapInfo.yIndex) + 1, parseInt(mapInfo.zoom));


                        // console.log(botomright);
                        //console.log(Rectanglelist);

                        let index = typeList.indexOf(temp) + 1;
                        console.log(index);
                        for (let i = 0; i < typeList.length; i++) {
                            setIgnorePosition(parseInt(mapInfo.xIndex), parseInt(mapInfo.yIndex), parseInt(mapInfo.zoom), "구역" + (i + 1));
                        }

                        // if (index == 1) {
                        //      setIgnorePosition(parseInt(mapInfo.xIndex), parseInt(mapInfo.yIndex), parseInt(mapInfo.zoom), "tip1");
                        // }
                        // if (index == 2) {
                        //      setIgnorePosition(parseInt(mapInfo.xIndex), parseInt(mapInfo.yIndex), parseInt(mapInfo.zoom), "tip2");
                        // }


                        //console.log(parseInt(mapInfo.xIndex));
                        // console.log(parseInt(mapInfo.yIndex));
                        ReactangleSet(topleft, botomright, mapInfo.zoom, "구역" + index, '', parseInt(mapInfo.xIndex), parseInt(mapInfo.yIndex));
                    }






                    // Rectalgeitems =  new naver.maps.Rectangle({
                    //    bounds: new naver.maps.LatLngBounds(
                    //        new naver.maps.LatLng(topleft._lat, topleft._lng),
                    //        new naver.maps.LatLng(botomright._lat, botomright._lng)
                    //    ),
                    //    fillColor: "#1fcaff",
                    //    fillOpacity: 0.3,
                    //    strokeColor: "#1fcaff",
                    //    strokeOpacity: 0.5,
                    //    clickable: true,
                    //    map: map
                    //});

                }
                // console.log(Rectalgeitems.getBounds());

            }
        },
        error: function (xhr, status, data) {

        }
    });
}
function CoordToPoint(x, y, z) {
    $.ajax({
        method: "POST",
        url: "/home/getCoordinateToPoint",
        data: {
            x: x + "",
            y: y + "",
            z: z + ""
        },
        success: function (data, status, xhr) {

            if (data.code == "00") {
                let setData = data.data;

                for (let i = 0; i < setData.length; i++) {
                    if (typeof vaildcheck[setData[i].zoom] == "undefined") {
                        vaildcheck[setData[i].zoom] = {};
                    }
                    var VO = { zoom: setData[i].zoom, x: setData[i].xIndex, y: setData[i].yIndex };
                    var value = setData[i].zoom + "_" + setData[i].xIndex + "_" + setData[i].yIndex;
                    vaildcheck[setData[i].zoom][value] = VO;
                }
                console.log(vaildcheck);
                let zoom = z;
                let maxZoom = 21;
                for (let i = 0; i < maxZoom + 1 - zoom; i++) {
                    let zooming = z + i;
                    for (let j = 0; j < Object.keys(temp).length; j++) {
                        if (Object.keys(temp)[j] == zooming) {
                            console.log(Object.keys(temp[zooming]));
                        }
                    }
                }
                console.log(check_Items);
                //let difference = [];
                //let objList = Object.keys(temp);

                //if (typeof vaildcheck[zoom] == "undefined") {
                //    return;
                //}
                //for (let i = 0; i < maxZoom + 1 - zoom; i++) {
                //    let loopZoom = zoom + i;
                //    for (let j = 0; j < objList.length; j++) {
                //        if (objList[j] == loopZoom) {
                //            difference = Object.keys(temp[loopZoom]).filter(x => Object.keys(vaildcheck[loopZoom]).includes(x));
                //        } else {
                //            console.log("없");
                //        }
                //    }
                //}
                //console.log(difference);
                //if (Object.keys(difference).length > 0) {
                //}
                //초기화
                vaildcheck = {};
            }
            // console.log(data.data);
        },
        error: function (xhr, status, data) {

        }
    });
}
function setTestBounds() {
    //console.log(temp);
    // getZoomIndexPoint(temp);
    // console.log("리스트 ");
    //console.log();
    let count = 0;
    let Data = getZoomIndexPoint(temp);
    let returnlist = [];
    for (var items in Data) {
        let list = Data[items];
        //console.log(Data[items]);
        for (var key in list) {
            //  console.log(key);
            returnlist[count] = {
                keys: list[key]["zoom"] + "_" + list[key]["x"] + "_" + list[key]["y"],
                tip: list[key]["tip"] == "tip1" ? $('#tip1').siblings().eq(2).val() : $('#tip2').siblings().eq(2).val()
            }
            count++;
        }
    }
}

function SetBounds() {

    if (typeof temp == "undefined") {
        NewPopup.alertOkNo2("배달 지역", "영역을 선택해주세요", "확인", function (res) {
            if (res) {
                return;
            }
        });
        return;
    }

    var Data = [];

    Data = getZoomIndexPoint(temp);
    if (typeof Data == "undefined") {
        NewPopup.alertOkNo2("배달 지역", "영역을 선택해주세요", "확인", function (res) {
            if (res) {
                return;
            }
        });
        return;
    }
    var returnlist = [];
    let count = 0;
    for (var items in Data) {
        let list = Data[items];
        //console.log(Data[items]);
        for (var key in list) {
            console.log(key);
            returnlist[count] = {
                keys: list[key]["zoom"] + "_" + list[key]["x"] + "_" + list[key]["y"],
                tip: list[key]["tip"]
            }
            count++;
        }
    }
    // console.log(Data);
    console.log(returnlist);
    $('.loading-con').show();
    $('.w-dim-layer').show();
    $.ajax({
        method: 'post',
        url: '/NaverMap/SetAreaIndex',
        data: { item: returnlist },
        success: function (data, status, xhr) {
            if (data.code == "00") {
                $('.loading-con').hide();
                $('.w-dim-layer').hide();
                location.reload();
            }
            $('.loading-con').hide();
            $('.w-dim-layer').hide();
        },
        error: function (xhr, status, data) {
            $('.loading-con').hide();
            $('.w-dim-layer').hide();
        }
    });

}
function SetBoundsJson() {

    if (typeof temp == "undefined") {
        NewPopup.alertOkNo2("배달 지역", "영역을 선택해주세요", "확인", function (res) {
            if (res) {
                return;
            }
        });
        return;
    }

    var Data = [];

    Data = getZoomIndexPoint(temp);
    if (typeof Data == "undefined") {
        NewPopup.alertOkNo2("배달 지역", "영역을 선택해주세요", "확인", function (res) {
            if (res) {
                return;
            }
        });
        return;
    }
    var returnlist = [];
    let count = 0;
    for (var items in Data) {
        let list = Data[items];
        //console.log(Data[items]);
        for (var key in list) {
            console.log(key);
            returnlist[count] = {
                keys: list[key]["zoom"] + "_" + list[key]["x"] + "_" + list[key]["y"],
                tip: list[key]["tip"]
            }
            count++;
        }
    }
    // console.log(Data);
    console.log(returnlist);
    $.ajax({
        method: 'post',
        contentType: 'json',
        url: '/NaverMap/SetAreaIndex',
        data: {
            item:
                JSON.stringify({ returnlist })
        },
        success: function (data, status, xhr) {
            if (data.code == "00") {
                location.reload();
            }
        },
        error: function (xhr, status, data) {
        }
    });

}
function changeTileSize(map, tileSize) {
    //var naverMapType = map;
    var naverMap = map.getMapType();
    var mapOptions = naverMap.getMapTypeOptions();

    mapOptions.tileSize = tileSize;
    naverMap.setMapTypeOptions(mapOptions);


} 


function getParameter(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);

    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}