﻿
var btn_zoomLevel = 0;
var listener = [];
var RectangleOverride = [];

$(function () {
    $('button[name=circlebtn]').on('click', function () {
        //console.log(RectangleOverride);
        btn_zoomLevel = 0;
        console.log(RectangleOverride.length);
        if (RectangleOverride.length > 0) {
            console.log(RectangleOverride.getMap());
        } else {
            console.log(RectangleOverride);
        }
        
        let circle_val = parseInt($(this).val());
        //console.log(naver.maps.Event.hasListener(map, 'mouseover'));
       // naver.maps.Event.removeListener(map, 'mouseover');
       // naver.maps.Event.removeListener(map, 'mouseout');
       
        if (circle_val > 0) {
            //naver.maps.Event.removeListener(listener);
            btn_zoomLevel = parseInt(btn_zoomLevel + circle_val);
            console.log(btn_zoomLevel);
        } else {
           // naver.maps.Event.removeListener(listener);
            btn_zoomLevel = parseInt(btn_zoomLevel + circle_val);
            console.log(btn_zoomLevel);
        }
        //listener =  naver.maps.Event.addListener(map, 'mouseover', function (e) {
        //    console.log(e.coord);
        //    var tileSize = map.getMapType().tileSize.width;

        //    var projection = map.getProjection();
        //    var zoom = map.getZoom();
        //    var centerPixel = projection.fromCoordToPoint(e.coord);

        //    var xPixel = Math.floor(projection.scaleUp(centerPixel.x, zoom + btn_zoomLevel));
        //    var yPixel = Math.floor(projection.scaleUp(centerPixel.y, zoom + btn_zoomLevel));
        //    var xIndex = Math.floor(xPixel / tileSize);
        //    var yIndex = Math.floor(yPixel / tileSize);

        //    console.log(zoom + btn_zoomLevel);

        //    var tl = tileClickTopLeft(xIndex, yIndex, zoom + btn_zoomLevel);
        //    var br = tileClickBottomRight(Math.abs(xIndex + 1), Math.abs(yIndex + 1), zoom + btn_zoomLevel)

        //    RectangleOverride = new naver.maps.Rectangle({
        //        bounds: new N.LatLngBounds(
        //            new N.LatLng(tl._lat, tl._lng),
        //            new N.LatLng(br._lat, br._lng)
        //        ),
        //        fillColor: "#ff0000",
        //        fillOpacity: 0.3,
        //        strokeColor: "#f00",
        //        strokeOpacity: 0.5,
        //        clickable: true,
        //        map: map
        //    });
        //    naver.maps.Event.addListener(RectangleOverride, 'mouseout', function (e) {
        //        //console.log(RectangleOverride);
        //        var tileSize = map.getMapType().tileSize.width;

        //        var projection = map.getProjection();
        //        var zoom = map.getZoom();
        //        var centerPixel = projection.fromCoordToPoint(e.coord);

        //        var xPixel = Math.floor(projection.scaleUp(centerPixel.x, zoom));
        //        var yPixel = Math.floor(projection.scaleUp(centerPixel.y, zoom));
        //        var xIndex = Math.floor(xPixel / tileSize);
        //        var yIndex = Math.floor(yPixel / tileSize);


        //        var tl = tileClickTopLeft(xIndex, yIndex, zoom);
        //        var br = tileClickBottomRight(Math.abs(xIndex + 1), Math.abs(yIndex + 1), zoom)


        //        RectangleOverride.setMap(null);
        //    });
            

        //    //naver.maps.Event.removeListener(listener);

        //});
        initMap.data.removerListener('clicke');

        initMap.data.addListener('click', function (e) {
            var tileSize = initMap.getMapType().tileSize.width;
            var projection = initMap.getProjection();
            //var center = map.getCenter();
            
            //console.log(center);
            var zoom = initMap.getZoom();
            var centerPixel = projection.fromCoordToPoint(e.coord);
            console.log(zoom + btn_zoomLevel);
            console.log(centerPixel);
            var xPixel = Math.floor(projection.scaleUp(centerPixel.x, zoom + btn_zoomLevel));
            var yPixel = Math.floor(projection.scaleUp(centerPixel.y, zoom + btn_zoomLevel));
            var xIndex = Math.floor(xPixel / tileSize);
            var yIndex = Math.floor(yPixel / tileSize);

            console.log(e.coord.x);
            console.log(e.coord.y);

            console.log(projection.scaleUp(centerPixel.x, zoom));

            //click Tile index 
            console.log("click : Tile gird index Value");
            console.log("x :" + xIndex);
            console.log("y :" + yIndex);
            // search div id selection
            console.log($('#' + xIndex + yIndex));
            //$('#' + xIndex + yIndex).css('color', "red");
            //$('#' + xIndex + yIndex).css('opacity', "0.4");
            //$('#' + xIndex + yIndex).css('background', "#1fcaff");6
            //var overlap = ValidLatLngCheck(temp, e.coord.x, e.coord.y, zoom, CoordToPoint);
            CoordToPoint(e.coord.x, e.coord.y, zoom + btn_zoomLevel);
            //if (!overlap) {
            //    return false;
            //}
            var RectangleVaild = getPointPosition(xIndex, yIndex, zoom + btn_zoomLevel);

            console.log(RectangleVaild);
            var centerpoint = new N.Point((xIndex * tileSize) + (tileSize / 2), ((e.coord.y + 1) * tileSize) + (tileSize / 2));
            var itemx = Math.PI - 2 * Math.PI * yPixel / (1 << zoom);
            var n = Math.pow(2, zoom);
            var t_tileY = xIndex / n * 360.0 - 180.0;
            var lat_rad = Math.atan(Math.sinh(Math.PI * (1 - 2 * yIndex / n)));
            var t_tilex = lat_rad * 180.0 / Math.PI;
            //console.log(c_tilex);
            //console.log(c_tileY);
            //console.log( 180 / Math.PI * Math.atan( 0.5 * (Math.exp(zoom) - Math.exp(itemx))));
            //

            console.log()
            console.log(centerpoint);
            //marker.setPosition(new N.LatLng(t_tileY, t_tilex));
            var tl = tileClickTopLeft(xIndex, yIndex, zoom + btn_zoomLevel);
            var br = tileClickBottomRight(Math.abs(xIndex + 1), Math.abs(yIndex + 1), zoom + btn_zoomLevel)
            //Rectanglelist = new naver.maps.Rectangle({
            //    bounds: new N.LatLngBounds(
            //        new N.LatLng(tl._lat, tl._lng),
            //        new N.LatLng(br._lat, br._lng)
            //    ),
            //    fillColor: "#ff0000",
            //    fillOpacity: 0.3,
            //    strokeColor: "#f00",
            //    strokeOpacity: 0.5,
            //    clickable : true,
            //    map: map
            //});


            ReactangleSet(tl, br, zoom, tipTypeseletor(), e.coord, "", "");

            console.log(tileClickTopLeft(xIndex, yIndex, zoom + btn_zoomLevel));
            console.log(br);
            console.log();
            var Items = {
                zoom: zoom,
                list: {
                    x: xIndex,
                    y: yIndex
                }
            };
            var clickList = [];



            //console.log(functionTemp);

            check_Items.push(Items);
            console.log(check_Items);
            console.log(RectangleVaild);

            switch (tipTypeseletor()) {
                case "tip1":
                    setIgnorePosition(xIndex, yIndex, zoom, "tip1");
                    break;
                case "tip2":
                    setIgnorePosition(xIndex, yIndex, zoom, "tip2");
                    break;
                default:
                    console.log("none selector");
                    break;
            }


            OverLapCheck(xIndex, yIndex, zoom + btn_zoomLevel);
        });
    });
    
});