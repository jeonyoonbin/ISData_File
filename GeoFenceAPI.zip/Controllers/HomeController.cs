﻿using GeoFenceAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using GeoFenceAPI.ApiModels.Geo.Naver.Request;
using GeoFenceAPI.ApiModels.Geo.Naver.Response;
using GeoFenceAPI.ApiModels.Shop.Request;
using GeoFenceAPI.ApiModels.Shop.Response;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using GeoFenceAPI.Services.DgShop;
using System.IO;
using Newtonsoft.Json;
using GeoFenceAPI.Models.GeoFence;
using GeoFenceAPI.ApiModels.Geo.address.Request;
using GeoFenceAPI.ApiModels.Geo.address.Response;
using GeoFenceAPI.Models.RequestModel;
using GeoFenceAPI.Models.ResponseModel;
using GeoFenceAPI.Common;

namespace GeoFenceAPI.Controllers
{
    public class HomeController : Controller
    {
        private readonly DgShopApiService dgShop;

        public HomeController(ILogger<HomeController> logger, DgShopApiService dgShop)
        {
            this.dgShop = dgShop;
        }
        public async Task<IActionResult> index(string key, string shopCode, string lon, string lat, string orderNo)
        {


            var sha256_key = Utils.Sha256("orderselect");

            if (key != sha256_key)
            {
                return NotFound();
            }

            int keySplit = Convert.ToInt32(shopCode) % 2;
            string NaverCode = "";
            if (keySplit == 0)
            {
                NaverCode = "78g0t8cgpg";
            }
            else
            {
                NaverCode = "zoh7rn2ppp";
            }

            RequestOrderState requestModel = new RequestOrderState()
            {
                shop_cd = Convert.ToInt32(shopCode),
                job_gbn = ((int)CUST_ORDER_SEARCH_TYPE.주문상세).ToString(),
                order_no = orderNo
            };


            var req = await dgShop.Post<ResponseShopInfo, RequestShopInfo>("/api/ShopManagement/GetShopInfo", new RequestShopInfo
            {
                job_gbn = "1",
                shop_cd = Convert.ToInt32(shopCode),

            });

            if (req.code.Equals("00") && orderNo.ToString() != "")
            {
                ViewBag.GroupArea = await GetAreaGroup(shopCode);
                ViewBag.NaverCode = NaverCode;
                ViewBag.OrderX = lon;
                ViewBag.OrderY = lat;

                if(orderNo != null)
                {
                    var Order = await dgShop.Post<ShopOrderDetail, RequestOrderState>("CustOrderDetail_V3", requestModel);

                    if (Order.code.Equals("00"))
                    {
                        var OrderSingleList = Order.data.SingleOrDefault();

                        ViewBag.OrderX = OrderSingleList.cust_lon;
                        ViewBag.OrderY = OrderSingleList.cust_lat;
                    }
                }
                return View(req.data);
            }

            await Task.Delay(0);
            return View();
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        #region method
        public async Task<List<ResponseAreaMapGroup>> GetAreaGroup(string shopCode)
        {
            var result = await dgShop.Post<ResponseAreaMapGroup, RequestAreaMapGroup>("/api/GeoMapManagement/GetAreaGroup", new RequestAreaMapGroup
            {
                job_gbn = "1",
                shop_cd = Convert.ToInt32(shopCode)
            });

            if (result.code.Equals("00"))
            {
                return result.data;
            }
            else
            {
                return new List<ResponseAreaMapGroup>();
            }
        }
        public async Task<IActionResult> getAreaIndex(string shopCode)
        {

            var req = await dgShop.Post<ResponseAreaMap, RequestGeoInfo>("/api/GeoMapManagement/GetAreaMap_V2", new RequestGeoInfo
            {
                job_gbn = "5",
                shop_cd = Convert.ToInt32(shopCode)
                //groupCode = "%"
            });

            if (req.code.Equals("00"))
            {
                List<AreaItem> list = new List<AreaItem>();
                Dictionary<string, List<AreaItem>> dicItem = new Dictionary<string, List<AreaItem>>();
                foreach (var item in req.data.OrderBy(x => x.groupCode).ToList())
                {
                    var key = item.geoSeqno.Split("_");
                    var tip = item.tip;
                    var groupCocde = item.groupCode;

                    var value = new AreaItem();
                    value.Zoom = key[0];
                    value.xIndex = key[1];
                    value.yIndex = key[2];
                    value.tip = item.groupCode;
                    list.Add(value);

                    if (!dicItem.ContainsKey(groupCocde))
                    {
                        dicItem.Add(groupCocde, new List<AreaItem>());
                    }
                    dicItem[groupCocde].Add(value);

                }

                return Ok(new
                {
                    code = "00",
                    Msg = "성공",
                    Data = dicItem
                }); ;
            }
            return Ok(new
            {
                code = "99",
                Msg = "데이터 없음"
            });
        }
        [HttpPost]
        public async Task<IActionResult> getCoordinateToPoint(string x, string y, string z)
        {
            if (string.IsNullOrEmpty(x))
            {
                return Ok(new
                {
                    code = "00",
                    Msg = "실패"
                });
            }

            //var sinLatitude = Math.sin(e.coord._lat * Math.PI / 180);

            //var pX = ((e.coord._lng + 180) / 360) * imgTileSize * Math.pow(2, map.getZoom());

            //var pY = (0.5 - Math.log((1 + sinLatitude) / (1 - sinLatitude)) / (4 * Math.PI)) * imgTileSize * Math.pow(2, map.getZoom());

            //console.log("px : " + Math.floor(pX / imgTileSize) + " " + "pY : " + Math.floor(pY / imgTileSize));


            var DefaultLevel = Convert.ToInt32(z); // 기본 줌 레벨
            var MaxLevel = 21; // 최대 줌레벨
            var imgTileSize = 128;

            var _lat = Convert.ToDouble(y);
            var _lng = Convert.ToDouble(x);

            var sinLatitude = Math.Sin(_lat * Math.PI / 180);
            List<AreaItem> list = new List<AreaItem>();

            for (var i = 0; i < MaxLevel + 1 - DefaultLevel; i++)
            {
                var value = new AreaItem();
                var zoomLevel = DefaultLevel + i;
                var pX = ((_lng + 180) / 360) * imgTileSize * Math.Pow(2, zoomLevel);
                var pY = (0.5 - Math.Log((1 + sinLatitude) / (1 - sinLatitude)) / (4 * Math.PI)) * imgTileSize * Math.Pow(2, zoomLevel);
                value.Zoom = zoomLevel.ToString();
                value.xIndex = Math.Floor(pX / imgTileSize).ToString();
                value.yIndex = Math.Floor(pY / imgTileSize).ToString();

                list.Add(value);
            }
            var req = list;

            await Task.Delay(0);
            return Ok(new
            {
                code = "00",
                Msg = "성공",
                data = req
            });
        }
        [HttpPost]
        public async Task<IActionResult> lonlatGeoPosition(string type, RequestAddressInfo address)
        {
            if (string.IsNullOrEmpty(type))
            {
                return Ok(new
                {
                    code = "99",
                    msg = "주소 조회가 실패했습니다."
                });
            }
            address.job_gbn = type;
            List<ResponseAddressInfo> result = new List<ResponseAddressInfo>();

            if (type.Equals("1") || type.Equals("3") || type.Equals("5"))
            {
                result = await GetAddressSiGunGu(address);

                return Ok(new
                {
                    code = "00",
                    msg = "성공",
                    data = result
                });
            }


            return Ok(new
            {
                code = "99",
                msg = "주소 조회가 실패했습니다."
            });
        }
        #endregion
        #region function address
        private async Task<List<ResponseAddressInfo>> GetAddressSiGunGu(RequestAddressInfo address)
        {
            List<ResponseAddressInfo> temp = new List<ResponseAddressInfo>();
            var req = await dgShop.Post<ResponseAddressInfo, RequestAddressInfo>("/api/GeoMapManagement/GetDongLonLat", new RequestAddressInfo
            {
                job_gbn = address.job_gbn,
                sido = "대구광역시",
                gungu = address.gungu,
                dong = address.dong
            });

            foreach (var items in req.data)
            {
                if (address.job_gbn.Equals("1"))
                {
                    temp.Add(new ResponseAddressInfo
                    {
                        hMiddle = items.hMiddle,
                        lonGrs80 = items.lonGrs80,
                        latGrs80 = items.latGrs80
                    });
                }
                else if (address.job_gbn.Equals("3"))
                {
                    temp.Add(new ResponseAddressInfo
                    {
                        hSmall = items.hSmall,
                        lonGrs80 = items.lonGrs80,
                        latGrs80 = items.latGrs80
                    });
                }
                else if (address.job_gbn.Equals("5"))
                {
                    temp.Add(new ResponseAddressInfo
                    {
                        bDetaill = items.bDetaill,
                        lonGrs80 = items.lonGrs80,
                        latGrs80 = items.latGrs80
                    });
                }
                else
                {

                }

            }

            return temp;
        }


        #endregion
        #region json
        public JsonResult DaeguJson()
        {
            try
            {
                var folderJSON = Path.Combine(Directory.GetCurrentDirectory(), $"wwwroot\\{"Json\\dongdaeguLine3.deojson.geojson"}");
                var JSON = System.IO.File.ReadAllText(folderJSON);

                var jsonObj = JsonConvert.DeserializeObject<NaverGeoJson>(JSON);

                return Json(jsonObj);
            }
            catch (Exception e)
            {
                return Json(new
                {
                    code = "99",
                    Msg = e.Message
                });
            }
        }
        
        #endregion
    }
}
