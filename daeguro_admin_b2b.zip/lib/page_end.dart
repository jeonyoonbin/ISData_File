// ignore_for_file: file_names, prefer_const_constructors, prefer_const_literals_to_create_immutables
//import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Page_End extends StatefulWidget {
  const Page_End({Key key, this.expdate}) : super(key: key);

  final String expdate;

  @override
  _Page_EndState createState() => _Page_EndState();
}

class _Page_EndState extends State<Page_End> {

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image(
            image: AssetImage("assets/images/BI_1.png"),
            width: 200.0,
          ),
          SizedBox(height: 10),
          Text('이벤트 기간이 끝났습니다.\n이벤트 기간을 확인 바랍니다.', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, fontFamily: 'NotoSansKR'), textAlign: TextAlign.center)
        ],
      ),
    );
  }
}
