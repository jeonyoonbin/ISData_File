// ignore_for_file: file_names, prefer_const_constructors, prefer_const_literals_to_create_immutables
//import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Page_Error extends StatefulWidget {
  @override
  _Page_ErrorState createState() => _Page_ErrorState();
}

class _Page_ErrorState extends State<Page_Error> {

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image(
            image: AssetImage("assets/images/BI_1.png"),
            width: 200.0,
          ),
          SizedBox(height: 10),
          Text('잘못된 URL 경로 입니다.\nURL을 확인 바랍니다.', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, fontFamily: 'NotoSansKR'), textAlign: TextAlign.center)
        ],
      ),
    );
  }
}
