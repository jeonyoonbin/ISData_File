import 'dart:convert';
import 'dart:html';

import 'package:daeguro_admin_b2b/119/119_login.dart';
import 'package:daeguro_admin_b2b/eland/eland_login.dart';
import 'package:daeguro_admin_b2b/goonpark/goonpark_login.dart';
import 'package:daeguro_admin_b2b/homeComponent.dart';
import 'package:daeguro_admin_b2b/hyundai/hyundai_login.dart';
import 'package:daeguro_admin_b2b/page_end.dart';
import 'package:daeguro_admin_b2b/page_error.dart';
import 'package:daeguro_admin_b2b/spark/spark_login.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:url_strategy/url_strategy.dart';
import 'package:http/http.dart' as http;

getParams() {
  var uri = Uri.dataFromString(window.location.href);
  Map<String, String> params = uri.queryParameters;
  var page = params['page'];

  return page;
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  setPathUrlStrategy();

  String _page = getParams();

  String exp_date = '20301231';

  // if (_page == '119') {
  //   await http.get('http://dgpub.282.co.kr:8426/B2BCoupon/getPeriod?couponType=B2B_C201').then((http.Response response){
  //     var decodeBody = jsonDecode(response.body);
  //
  //     exp_date = decodeBody['data']['EXP_DATE'].toString();
  //   });
  // } else if (_page == 'eworld') {
  //   await http.get('http://dgpub.282.co.kr:8426/B2BCoupon/getPeriod?couponType=B2B_C200').then((http.Response response){
  //     var decodeBody = jsonDecode(response.body);
  //
  //     exp_date = decodeBody['data']['EXP_DATE'].toString();
  //   });
  // } else if (_page == 'goonpark') {
  //   await http.get('http://dgpub.282.co.kr:8426/B2BCoupon/getPeriod?couponType=B2B_C203').then((http.Response response){
  //     var decodeBody = jsonDecode(response.body);
  //
  //     exp_date = decodeBody['data']['EXP_DATE'].toString();
  //   });
  // }

  runApp(MyApp(page: _page, expdate: exp_date));
}

class MyApp extends StatelessWidget {
  const MyApp({Key key, this.page, this.expdate}) : super(key: key);

  final String page;
  final String expdate;

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      localizationsDelegates: const [
        GlobalCupertinoLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      title: '대구로 QR 시스템',
      supportedLocales: const [Locale('ko', 'KR')],
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: '대구로 QR 시스템', page: page, expdate: expdate),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key key, this.title, this.page, this.expdate}) : super(key: key);

  final String title;
  final String page;
  final String expdate;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        //body: widget.expdate == ' ' || int.parse(widget.expdate) < int.parse(formatDate(DateTime.now(), [yyyy, mm, dd])) ? Page_End() : _Page(widget.page));
        body: _Page(widget.page));
  }
}

 Widget _Page(String _page) {
  if (_page == '119') {
    return Login_119();
  } else if (_page == 'eworld') {
    return Login_Eland();
  } else if (_page == 'admin') {
    return HomeComponent();
  } else if (_page == 'goonpark') {
    return Login_Goonpark();
  } else if (_page == 'hyundai') {
    return Login_Hyundai();
  } else if (_page == 'spark') {
    return Login_Spark();
  } else {
    return  Page_Error();
  }
}
