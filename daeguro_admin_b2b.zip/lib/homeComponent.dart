// ignore_for_file: file_names

import 'package:daeguro_admin_b2b/119/119_login.dart';
import 'package:daeguro_admin_b2b/eland/eland_login.dart';
import 'package:daeguro_admin_b2b/goonpark/goonpark_login.dart';
import 'package:daeguro_admin_b2b/hyundai/hyundai_login.dart';
import 'package:daeguro_admin_b2b/spark/spark_login.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

class HomeComponent extends StatefulWidget {
  @override
  State createState() => HomeComponentState();
}

class HomeComponentState extends State<HomeComponent> {
  @override
  Widget build(BuildContext context) {
    var menuWidgets = <Widget>[
      menuButton(context, 'assets/images/119_2.jpg', "대구소방\nQR 사이트 연결", "119"),
      menuButton(context, 'assets/images/eworld2.png', "이월드 이벤트\n QR 사이트 연결", "eworld"),
      menuButton(context, 'assets/images/goonpark.png', "군파크 루지 이벤트\n QR 사이트 연결", "goonpark"),
      menuButton(context, 'assets/images/hyundai.png', "현대 시티 아울렛 이벤트\n QR 사이트 연결", "hyundai"),
      menuButton(context, 'assets/images/spark.png', "스파크랜드 이벤트\n QR 사이트 연결", "spark"),
    ];

    final size = MediaQuery.of(context).size;
    final childRatio = (size.width / size.height) * 1;

    return Material(
      child: SafeArea(
        top: true,
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Center(
              child: Padding(
                padding: EdgeInsets.only(top: 25),
                child: Image(
                  image: AssetImage("assets/images/BI_1.png"),
                  width: 80.0,
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25),
                child: GridView.count(
                  childAspectRatio: childRatio,
                  crossAxisCount: 2,
                  mainAxisSpacing: 5,
                  children: menuWidgets,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // helpers
  Widget menuButton(BuildContext context, String assetSrc, String title, String key) {
    return Padding(
      padding: EdgeInsets.all(4.0),
      child: Container(
        height: 55.0,
        child: TextButton(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Container(
                  height: 90,
                  child: Image.asset(
                    assetSrc,
                    fit: BoxFit.contain,
                  ),
                ),
              ),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(color: const Color(0xAA001133), fontFamily: 'NotoSansKR', fontSize: 15, fontWeight: FontWeight.bold),
              )
            ],
          ),
          onPressed: () {
            tappedMenuButton(context, key);
          },
        ),
      ),
    );
  }

  // actions
  void tappedMenuButton(BuildContext context, String key) {
    String message = "testtest";
    String hexCode = "#FFFFFF";
    String result;

    String route = "";

    if(key == '119')
    {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Login_119()),
      );
    }
    else if (key == 'eworld'){
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Login_Eland()),
      );
    }
    else if (key == 'goonpark'){
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Login_Goonpark()),
      );
    }
    else if (key == 'hyundai'){
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Login_Hyundai()),
      );
    }
    else if (key == 'spark'){
    Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => Login_Spark()),
    );
    }
  }
}
