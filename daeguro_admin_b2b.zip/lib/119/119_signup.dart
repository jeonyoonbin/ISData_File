// ignore_for_file: file_names, prefer_const_constructors
import 'dart:convert';

import 'package:daeguro_admin_b2b/119/119_scan.dart';
import 'package:daeguro_admin_b2b/utils.dart';
//import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

class SignUp_119 extends StatefulWidget {
  @override
  _SignUp_119State createState() => _SignUp_119State();
}

class _SignUp_119State extends State<SignUp_119> {

  String _name = '';
  String _loginId = '';
  String _loginPw = '';
  String _loginPw_check = '';
  String _mobile = '';
  String _msg = '';

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('[회원가입]', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, fontFamily: 'NotoSansKR')),
            Divider(),
            Container(
              width: 250,
              margin: const EdgeInsets.fromLTRB(0, 10, 0, 0),
              child: TextField(
                decoration: InputDecoration(
                    fillColor: Color(0xffdefcfc),
                    filled: true,
                    border: new OutlineInputBorder(borderSide: BorderSide(width: 0, style: BorderStyle.none), borderRadius: const BorderRadius.all(const Radius.circular(10))),
                    labelText: '아이디',
                    labelStyle: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.blue, fontFamily: 'NotoSansKR')),
                onChanged: (text) {
                  _loginId = text;
                  setState(() {});
                },
                style: TextStyle(fontSize: 15, color: Colors.black, fontFamily: 'NotoSansKR'),
              ),
            ),
            Container(
              width: 250,
              margin: const EdgeInsets.fromLTRB(0, 10, 0, 0),
              child: TextField(
                decoration: InputDecoration(
                    fillColor: Color(0xffdefcfc),
                    filled: true,
                    border: new OutlineInputBorder(borderSide: BorderSide(width: 0, style: BorderStyle.none), borderRadius: const BorderRadius.all(const Radius.circular(10))),
                    labelText: '비밀번호',
                    labelStyle: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.blue, fontFamily: 'NotoSansKR')),
                onChanged: (text) {
                  _loginPw = text;
                  setState(() {});
                },
                obscureText: true,
                enableSuggestions: false,
                autocorrect: false,
                style: TextStyle(fontSize: 15, color: Colors.black, fontFamily: 'NotoSansKR'),
              ),
            ),
            Container(
              width: 250,
              margin: const EdgeInsets.fromLTRB(0, 10, 0, 0),
              child: TextField(
                decoration: InputDecoration(
                    fillColor: Color(0xffdefcfc),
                    filled: true,
                    border: new OutlineInputBorder(borderSide: BorderSide(width: 0, style: BorderStyle.none), borderRadius: const BorderRadius.all(const Radius.circular(10))),
                    labelText: '비밀번호 확인',
                    labelStyle: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.blue, fontFamily: 'NotoSansKR')),
                onChanged: (text) {
                  _loginPw_check = text;
                  setState(() {});
                },
                obscureText: true,
                enableSuggestions: false,
                autocorrect: false,
                style: TextStyle(fontSize: 15, color: Colors.black, fontFamily: 'NotoSansKR'),
              ),
            ),
            Container(
              width: 250,
              margin: const EdgeInsets.fromLTRB(0, 10, 0, 0),
              child: TextField(
                decoration: InputDecoration(
                    fillColor: Color(0xffdefcfc),
                    filled: true,
                    border: new OutlineInputBorder(borderSide: BorderSide(width: 0, style: BorderStyle.none), borderRadius: const BorderRadius.all(const Radius.circular(10))),
                    labelText: '이름',
                    labelStyle: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.blue, fontFamily: 'NotoSansKR')),
                onChanged: (text) {
                  _name = text;
                  setState(() {});
                },
                style: TextStyle(fontSize: 15, color: Colors.black, fontFamily: 'NotoSansKR'),
              ),
            ),
            Container(
              width: 250,
              margin: const EdgeInsets.fromLTRB(0, 10, 0, 0),
              child: TextField(
                inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                decoration: InputDecoration(
                    fillColor: Color(0xffdefcfc),
                    filled: true,
                    border: new OutlineInputBorder(borderSide: BorderSide(width: 0, style: BorderStyle.none), borderRadius: const BorderRadius.all(const Radius.circular(10))),
                    labelText: '전화번호',
                    labelStyle: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.blue, fontFamily: 'NotoSansKR')),
                onChanged: (text) {
                  _mobile = text;
                  setState(() {});
                },
                style: TextStyle(fontSize: 15, color: Colors.black, fontFamily: 'NotoSansKR'),
              ),
            ),
            Container(margin: EdgeInsets.all(10), width: 300, child: Text(_msg, style: TextStyle(fontSize: 15, color: Colors.red, fontFamily: 'NotoSansKR'), textAlign: TextAlign.center)),
            Container(
              height: 60,
              width: 250,
              child: ElevatedButton(
                style: ButtonStyle(shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)))),
                child: Text(
                  '회원가입',
                  style: TextStyle(fontFamily: 'NotoSansKR'),
                ),
                onPressed: () async {
                  _msg = '';

                  setState(() {});

                  if (_loginId == '') {
                    _msg = '아이디를 입력 바랍니다.';
                    return;
                  }

                  if (_loginPw == '') {
                    _msg = '비밀번호를 입력 바랍니다.';
                    return;
                  }

                  if (_loginPw != _loginPw_check) {
                    _msg = '입력하신 비밀번호가 다릅니다.';
                    setState(() {});
                    return;
                  }

                  if (_name == '') {
                    _msg = '이름을 입력 바랍니다.';
                    return;
                  }

                  if (_mobile == '') {
                    _msg = '전화번호를 입력 바랍니다.';
                    return;
                  }

                  await http.post(Utils.REST_BASEURL + '/B2BUser?name=$_name&loginId=$_loginId&loginPwd=$_loginPw&mobile=$_mobile&couponType=B2B_C201').then((http.Response response) async {
                    var decodeBody = jsonDecode(response.body);

                    if (decodeBody['code'] != '00') {
                      _msg = decodeBody['msg'];
                      setState(() {});
                      return;
                    } else {
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          elevation: 6,
                          backgroundColor: Colors.blue,
                          behavior: SnackBarBehavior.floating,
                          content: Text('회원가입이 완료 되었습니다', style: TextStyle(fontFamily: 'NotoSansKR')),
                          duration: Duration(seconds: 3)));
                    }
                  });
                },
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 60,
              width: 250,
              child: ElevatedButton(
                style: ButtonStyle(
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                    backgroundColor: MaterialStateProperty.all(Colors.redAccent)),
                child: Text(
                  '취소',
                  style: TextStyle(fontFamily: 'NotoSansKR'),
                ),
                onPressed: () {},
              ),
            ),
          ],
        ),
      ),
    );
  }
}
