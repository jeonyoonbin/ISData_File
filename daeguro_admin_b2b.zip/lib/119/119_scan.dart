// ignore_for_file: file_names, prefer_const_constructors
import 'dart:convert';

import 'package:daeguro_admin_b2b/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_b2b/utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:jsqr/scanner.dart';
import 'package:http/http.dart' as http;

class Scan_119 extends StatefulWidget {
  final String USER_ID;

  const Scan_119({Key key, this.USER_ID}) : super(key: key);

  @override
  _Scan_119State createState() => _Scan_119State();
}

class _Scan_119State extends State<Scan_119> {
  String _qrText = '';

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          leading: Container(
            margin: EdgeInsets.fromLTRB(10, 5, 0, 0),
            child: Image(
              image: AssetImage("assets/images/BI_1.png"),
              width: 150.0,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 0,
        ),
        body: Container(
          color: Colors.white,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image(
                  image: AssetImage("assets/images/119_1.jpg"),
                  width: 180.0,
                ),
                Container(
                  width: 350,
                  child: TextFormField(
                    controller: TextEditingController(text: _qrText),
                    onChanged: (v) {
                      _qrText = v;
                    },
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.qr_code_2, size: 30),
                      //suffixIcon: Icon(Icons.camera_alt, size: 30),
                      suffixIcon: IconButton(
                          icon: Icon(Icons.camera_alt, size: 30),
                          splashRadius: 5,
                          onPressed: () {
                            setState(() async {
                              var code = await showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    var width = MediaQuery.of(context).size.width;
                                    var height = MediaQuery.of(context).size.height;
                                    return AlertDialog(
                                      actions: <Widget>[
                                        CircleAvatar(
                                          radius: 30,
                                          backgroundColor: Colors.white,
                                          child: IconButton(
                                              onPressed: () {
                                                Navigator.pop(context);
                                              },
                                              icon: Icon(Icons.close, size: 30, color: Colors.red),
                                              alignment: Alignment.center),
                                        )
                                      ],
                                      insetPadding: EdgeInsets.zero,
                                      title: const Text('[QR 코드를 스캔 하십시오]', style: TextStyle(fontFamily: 'NotoSansKR')),
                                      content: OverflowBox(
                                        maxWidth: width,
                                        child: Container(
                                            //height: height - 20,
                                            width: width,
                                            child: Scanner()),
                                      ),
                                    );
                                  });

                              _qrText = code;
                              setState(() {});
                            });
                          }),
                      labelStyle: TextStyle(fontSize: 14, fontFamily: 'NotoSansKR'),
                      labelText: 'QR 바코드 입력',
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  width: 350,
                  height: 150,
                  alignment: Alignment.topCenter,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        height: 100,
                        width: 150,
                        child: ElevatedButton(
                          style: ButtonStyle(
                              elevation: MaterialStateProperty.all(0),
                              backgroundColor: MaterialStateProperty.all(Colors.blueAccent),
                              shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)))),
                          child: Text('사용', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'NotoSansKR')),
                          onPressed: () async {
                            ScaffoldMessenger.of(context).clearSnackBars();

                            if (_qrText == '') {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                  elevation: 6,
                                  backgroundColor: Colors.redAccent,
                                  behavior: SnackBarBehavior.floating,
                                  content: Text('쿠폰정보를 입력 바랍니다.', style: TextStyle(fontFamily: 'NotoSansKR')),
                                  duration: Duration(seconds: 3)));
                              return;
                            }

                            ISConfirm(context, '쿠폰 사용', '해당쿠폰을 사용 하시겠습니까?', (context) async {
                              String modUcode = widget.USER_ID;

                              await http
                                  .put(Utils.REST_BASEURL + '/B2BCoupon/setCouponAppCustomer?modUcode=$modUcode&custCode=' '&couponType=B2B_C201&couponNo=$_qrText&status=30')
                                  .then((http.Response response) async {
                                var decodeBody = jsonDecode(response.body);

                                if (decodeBody['code'] != '00') {
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                      elevation: 6,
                                      backgroundColor: Colors.redAccent,
                                      behavior: SnackBarBehavior.floating,
                                      content: Text(decodeBody['msg'], style: TextStyle(fontFamily: 'NotoSansKR')),
                                      duration: Duration(seconds: 3)));
                                  return;
                                } else {
                                  setState(() {
                                    _qrText = '';
                                  });

                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                      elevation: 6,
                                      backgroundColor: Colors.green,
                                      behavior: SnackBarBehavior.floating,
                                      content: Text('해당 쿠폰이 사용 되었습니다.', style: TextStyle(fontFamily: 'NotoSansKR')),
                                      duration: Duration(seconds: 3)));
                                }
                              });

                              Navigator.pop(context, true);
                            });
                          },
                        ),
                      ),
                      Container(
                        height: 100,
                        width: 150,
                        child: ElevatedButton(
                          style: ButtonStyle(
                              elevation: MaterialStateProperty.all(0),
                              backgroundColor: MaterialStateProperty.all(Colors.blueAccent),
                              shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)))),
                          child: Text('사용 취소', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'NotoSansKR')),
                          onPressed: () {
                            ScaffoldMessenger.of(context).clearSnackBars();

                            if (_qrText == '') {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                  elevation: 6,
                                  backgroundColor: Colors.redAccent,
                                  behavior: SnackBarBehavior.floating,
                                  content: Text('쿠폰정보를 입력 바랍니다.', style: TextStyle(fontFamily: 'NotoSansKR')),
                                  duration: Duration(seconds: 3)));
                              return;
                            }

                            ISConfirm(context, '쿠폰 사용 취소', '해당쿠폰을 사용 취소 하시겠습니까?', (context) async {
                              String modUcode = widget.USER_ID;

                              await http
                                  .put(Utils.REST_BASEURL + '/B2BCoupon/setCouponAppCustomer?modUcode=$modUcode&couponType=B2B_C201&couponNo=$_qrText&status=50')
                                  .then((http.Response response) async {
                                var decodeBody = jsonDecode(response.body);

                                if (decodeBody['code'] != '00') {
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                      elevation: 6,
                                      backgroundColor: Colors.redAccent,
                                      behavior: SnackBarBehavior.floating,
                                      content: Text(decodeBody['msg'], style: TextStyle(fontFamily: 'NotoSansKR')),
                                      duration: Duration(seconds: 3)));
                                  return;
                                } else {
                                  setState(() {
                                    _qrText = '';
                                  });

                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                      elevation: 6,
                                      backgroundColor: Colors.green,
                                      behavior: SnackBarBehavior.floating,
                                      content: Text('해당 쿠폰이 사용취소 되었습니다.', style: TextStyle(fontFamily: 'NotoSansKR')),
                                      duration: Duration(seconds: 3)));
                                }
                              });

                              Navigator.pop(context, true);
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
