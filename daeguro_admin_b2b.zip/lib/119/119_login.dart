// ignore_for_file: file_names, prefer_const_constructors
import 'dart:convert';

import 'package:daeguro_admin_b2b/119/119_scan.dart';
import 'package:daeguro_admin_b2b/119/119_signup.dart';
import 'package:daeguro_admin_b2b/utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Login_119 extends StatefulWidget {
  @override
  _Login_119State createState() => _Login_119State();
}

class _Login_119State extends State<Login_119> {
  String _loginId = '';
  String _loginPw = '';

  int _selOn = 0;
  int _selOff = 0;

  List<dynamic> _dataCntList = [];

  @override
  void initState() {
    super.initState();

    http.get(Utils.REST_BASEURL + '/B2BCoupon/getCount?couponType=B2B_C201').then((http.Response response) async {
      if (response.statusCode != 200) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          elevation: 6,
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
          content: Text('서버 연결 실패하였습니다.' + '\n대구로 고객센터에 문의 바랍니다[1661-3773]', style: TextStyle(fontFamily: 'NotoSansKR')),
          duration: Duration(seconds: 3),
        ));

        return;
      }

      var decodeBody = jsonDecode(response.body);

      _dataCntList = decodeBody['data'];

      _selOff = _dataCntList.length;

      setState(() {});
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        elevation: 6,
        backgroundColor: Colors.redAccent,
        behavior: SnackBarBehavior.floating,
        content: Text('서버 연결 실패하였습니다.' + '\n대구로 고객센터에 문의 바랍니다[1661-3773]', style: TextStyle(fontFamily: 'NotoSansKR')),
        duration: Duration(seconds: 3),
      ));

      return;
    });
  }

  void _login() async {
    ScaffoldMessenger.of(context).clearSnackBars();
    await http.get(Utils.REST_BASEURL + '/B2BUser/getLogin?couponType=B2B_C201&id=$_loginId&pwd=$_loginPw').then((http.Response response) async {
      if (response.statusCode != 200) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          elevation: 6,
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
          content: Text('서버 연결 실패하였습니다.' + '\n대구로 고객센터에 문의 바랍니다[1661-3773]', style: TextStyle(fontFamily: 'NotoSansKR')),
          duration: Duration(seconds: 3),
        ));

        return;
      }

      var decodeBody = jsonDecode(response.body);

      if (decodeBody['code'] != '00') {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          elevation: 6,
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
          content: Text(decodeBody['msg'] + '\n대구로 고객센터에 문의 바랍니다[1661-3773]', style: TextStyle(fontFamily: 'NotoSansKR')),
          duration: Duration(seconds: 3),
        ));
        return;
      } else {
        await Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Scan_119(USER_ID: decodeBody['data']['USER_ID'].toString())),
        );
      }
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        elevation: 6,
        backgroundColor: Colors.redAccent,
        behavior: SnackBarBehavior.floating,
        content: Text('서버 연결 실패하였습니다.' + '\n대구로 고객센터에 문의 바랍니다[1661-3773]', style: TextStyle(fontFamily: 'NotoSansKR')),
        duration: Duration(seconds: 3),
      ));

      return;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:  Colors.white,
      appBar: AppBar(
        leading: Container(
          margin: EdgeInsets.fromLTRB(10, 5, 0, 0),
          child: Image(
            image: AssetImage("assets/images/BI_1.png"),
            width: 150.0,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Center(
          child: SingleChildScrollView(
            child: Container(
              color: Colors.white,
              alignment: Alignment.center,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image(
                    image: AssetImage("assets/images/119_1.jpg"),
                    width: 200.0,
                  ),
                  SizedBox(height: 10),
                  Container(
                    width: 250,
                    margin: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                    child: TextField(
                      decoration: InputDecoration(
                          fillColor: Color(0xffdefcfc),
                          filled: true,
                          border: new OutlineInputBorder(borderSide: BorderSide(width: 0, style: BorderStyle.none), borderRadius: const BorderRadius.all(const Radius.circular(10))),
                          labelText: '아이디',
                          labelStyle: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.blue, fontFamily: 'NotoSansKR')),
                      onChanged: (text) {
                        _loginId = text;
                        setState(() {});
                      },
                      style: TextStyle(fontSize: 15, color: Colors.black, fontFamily: 'NotoSansKR'),
                    ),
                  ),
                  Container(
                    width: 250,
                    margin: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                    child: TextField(
                      decoration: InputDecoration(
                          fillColor: Color(0xffdefcfc),
                          filled: true,
                          border: new OutlineInputBorder(borderSide: BorderSide(width: 0, style: BorderStyle.none), borderRadius: const BorderRadius.all(const Radius.circular(10))),
                          labelText: 'password',
                          labelStyle: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.blue)),
                      onChanged: (text) {
                        _loginPw = text;
                        setState(() {});
                      },
                      onSubmitted: (v) {
                        _login();
                      },
                      obscureText: true,
                      enableSuggestions: false,
                      autocorrect: false,
                      style: TextStyle(fontSize: 15, color: Colors.black),
                    ),
                  ),
                  SizedBox(height: 10),
                  Container(
                    height: 60,
                    width: 250,
                    child: ElevatedButton(
                      style:
                          ButtonStyle(elevation: MaterialStateProperty.all(0), shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)))),
                      child: Text(
                        '로그인',
                        style: TextStyle(fontFamily: 'NotoSansKR'),
                      ),
                      onPressed: () async {
                        _login();
                      },
                    ),
                  ),
                  SizedBox(height: 10),
                  Container(
                    width: 320,
                    height: double.parse(((_selOff * 50) + (_selOn * 100)).toString()),
                    child: getCntView(),
                  ),
                  // SizedBox(height: 10),
                  // Container(
                  //   height: 60,
                  //   width: 250,
                  //   child: ElevatedButton(
                  //     style: ButtonStyle(shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)))),
                  //     child: Text(
                  //       '회원가입',
                  //       style: TextStyle(fontFamily: 'NotoSansKR'),
                  //     ),
                  //     onPressed: () {
                  //       Navigator.push(
                  //         context,
                  //         MaterialPageRoute(builder: (context) => SignUp_119()),
                  //       );
                  //     },
                  //   ),
                  // ),
                ],
              ),
            ),
          ),
        ),
    );
  }

  Widget getCntView() {
    return ListView.builder(
      controller: ScrollController(),
      //padding: const EdgeInsets.symmetric(horizontal: 4.0, vertical: 8.0),
      itemCount: _dataCntList.length,
      itemBuilder: (BuildContext context, int index) {
        return _dataCntList != null
            ? ListTileTheme(
          dense: true,
          child: ExpansionTile(
            onExpansionChanged: (isExpanded) {
              if (isExpanded) {
                _selOn++;
                _selOff--;
              } else {
                _selOn--;
                _selOff++;
              }

              setState(() {});
            },
            title: Column(
              children: [
                Align(child: Text(_dataCntList[index]['ITEM_NM'], style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 13, fontWeight: FontWeight.bold)), alignment: Alignment.centerLeft),
                Align(
                    child: Text('[총 발행 : ${_dataCntList[index]['TOTAL']} 건,  발급 : ${_dataCntList[index]['USE']} 건,  잔여 : ${_dataCntList[index]['LEFT']} 건]',
                        style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 12)),
                    alignment: Alignment.centerLeft),
              ],
            ),
            children: [
              Column(
                children: [
                  Align(child: Text('      ' + _dataCntList[index]['MEMO'], style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 12)), alignment: Alignment.centerLeft),
                  Align(
                      child: Text(
                          '[사용 기한 : ${_dataCntList[index]['EXP_DATE'].substring(0, 4) + '-' + _dataCntList[index]['EXP_DATE'].substring(4, 6) + '-' + _dataCntList[index]['EXP_DATE'].substring(6, 8)}] ',
                          style: TextStyle(fontFamily: 'NotoSansKR', fontSize: 12)),
                      alignment: Alignment.centerRight),
                ],
              ),
            ],
          ),
        )
            : Container();
      },
    );
  }
}
