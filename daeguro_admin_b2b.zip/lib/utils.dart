class Utils {
  static const String REST_BASEURL = 'https://ext.daeguro.co.kr:45010/api';
  //static const String REST_BASEURL = 'http://dgpub.282.co.kr:8426';
}