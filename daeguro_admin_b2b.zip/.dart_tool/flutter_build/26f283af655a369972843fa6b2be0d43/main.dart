// @dart=2.7

import 'dart:ui' as ui;

import 'package:daeguro_admin_b2b/main.dart' as entrypoint;

Future<void> main() async {
  await ui.webOnlyInitializePlatform();
  entrypoint.main();
}
