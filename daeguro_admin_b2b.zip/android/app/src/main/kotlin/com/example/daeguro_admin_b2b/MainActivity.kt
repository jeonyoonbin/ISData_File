package com.example.daeguro_admin_b2b

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
