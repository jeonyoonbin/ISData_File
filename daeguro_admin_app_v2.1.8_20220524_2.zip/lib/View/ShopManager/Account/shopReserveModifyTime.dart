import 'dart:convert';

import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_progressDialog.dart';
import 'package:daeguro_admin_app/Model/shop/shopReserveModifyTimeModel.dart';
import 'package:daeguro_admin_app/Util/auth_util.dart';
import 'package:daeguro_admin_app/Util/multi_masked_formatter.dart';
import 'package:daeguro_admin_app/Util/utils.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reservationmanager_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';

class ShopReserveModifyTime extends StatefulWidget {
  final String shopCode;
  final String sbGbn;//S:운영시간, B:브레이크타임

  //final ShopBasicInfo sData;

  const ShopReserveModifyTime({Key key, this.shopCode, this.sbGbn}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopReserveModifyTimeState();
  }
}

class ShopReserveModifyTimeState extends State<ShopReserveModifyTime> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final List<ShopReserveModifyTimeModel> dataList = <ShopReserveModifyTimeModel>[];

  bool chkTimeGbn = false;

  loadData() async {
    dataList.clear();

    await ReservationController.to.getShopReserveModifyTimeList(widget.shopCode, widget.sbGbn).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      }
      else {
        value.forEach((element) {
          ShopReserveModifyTimeModel tempData = ShopReserveModifyTimeModel.fromJson(element);
          dataList.add(tempData);
        });

        if (dataList.length == 0){
          dataList.add(new ShopReserveModifyTimeModel(dayGbn: '1', closeGbn: 'N'));
          dataList.add(new ShopReserveModifyTimeModel(dayGbn: '2', closeGbn: 'N'));
          dataList.add(new ShopReserveModifyTimeModel(dayGbn: '3', closeGbn: 'N'));
          dataList.add(new ShopReserveModifyTimeModel(dayGbn: '4', closeGbn: 'N'));
          dataList.add(new ShopReserveModifyTimeModel(dayGbn: '5', closeGbn: 'N'));
          dataList.add(new ShopReserveModifyTimeModel(dayGbn: '6', closeGbn: 'N'));
          dataList.add(new ShopReserveModifyTimeModel(dayGbn: '7', closeGbn: 'N'));
        }

        setState(() {

        });
      }
    });
  }

  @override
  void initState() {
    super.initState();

    Get.put(ReservationController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      loadData();
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          iconColor: Colors.white,
          textStyle: TextStyle(color: Colors.white),
          onPressed: () async {

            List<ShopReserveModifyTimeModel> saveListdata = <ShopReserveModifyTimeModel>[];

            chkTimeGbn = false;

            dataList.forEach((element) {
              if (element.openTime != '') {
                if (chkTimeGbn == true) return;

                if (element.openTime.length != 4) {
                  ISAlert(context, '[시작시간] 잘못된 시간형식 입니다.');
                  chkTimeGbn = true;
                  return;
                }

                if (int.parse(element.openTime) > 2359) {
                  ISAlert(context, '시간은 최대 23:59 입니다.');
                  chkTimeGbn = true;
                  return;
                }

                if (int.parse(element.openTime.substring(2, 4)) > 59) {
                  ISAlert(context, '[시작시간] 잘못된 시간형식 입니다.');
                  chkTimeGbn = true;
                  return;
                }
              }

              if (element.closeTime != '') {
                if (element.closeTime.length != 4) {
                  ISAlert(context, '[종료시간] 잘못된 시간형식 입니다.');
                  chkTimeGbn = true;
                  return;
                }

                if (int.parse(element.closeTime) > 2359) {
                  ISAlert(context, '종료시간은 최대 23:59 입니다.');
                  chkTimeGbn = true;
                  return;
                }

                if (int.parse(element.closeTime.substring(2, 4)) > 59) {
                  ISAlert(context, '[종료시간] 잘못된 시간형식 입니다.');
                  chkTimeGbn = true;
                  return;
                }
              }

              saveListdata.add(element);
            });

            if (saveListdata.length == 0) return;

            await ISProgressDialog(context).show(status: 'Loading...');

            String jsonData = jsonEncode(saveListdata);

            var bodyData = {'"shopCode"': '"${widget.shopCode}"', '"sbGbn"': '"${widget.sbGbn}"', '"sbTimeUnit"': jsonData};

            await ReservationController.to.postShopReserveModifyTimeList(context, bodyData.toString()).then((value) async {
              if (value == '00'){

              }

              Navigator.pop(context);

              await ISProgressDialog(context).dismiss();
            });
          },
        ),
        ISButton(
          label: '닫기',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text(widget.sbGbn == 'S' ? '[예약] 영업시간 설정' : '[예약] 브레이크타임 설정'),
      ),
      body: Container(
          padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16.0),
          child: getBodyView()
      ),
      bottomNavigationBar: buttonBar,
    );

    return SizedBox(
      width: 420,
      height: 500,
      child: result,
    );
  }

  Widget getBodyView() {
    return ListView(
      controller: ScrollController(),
      physics: NeverScrollableScrollPhysics(),
      children: <Widget>[
        Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(widget.sbGbn == 'S' ? '영업시간 설정' : '브레이크타임 설정', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),),
                ISButton(
                    label: '일괄 입력',
                    textStyle: TextStyle(color: Colors.white, fontSize: 12),
                    height: 26,
                    onPressed: () {
                      setState(() {
                        int idx = 0;
                        String tempFrStand, tempToStand, tempGbn;
                        dataList.forEach((element) {
                          if (idx == 0) {
                            if (element.openTime == null || element.openTime == '' || element.closeTime == null || element.closeTime == '') {
                              tempFrStand = '0900';
                              tempToStand = '2359';
                              tempGbn = 'N';
                            } else {
                              tempFrStand = element.openTime;
                              tempToStand = element.closeTime;
                              tempGbn = element.closeGbn;
                            }
                          }

                          element.openTime = tempFrStand;
                          element.closeTime = tempToStand;
                          element.closeGbn = tempGbn;

                          idx++;
                        });
                      });
                    }
                )
              ],
            ),
            SizedBox(height: 6,),
            Container(
                height: 360,
                child: ListView(
                  //physics: NeverScrollableScrollPhysics(),
                  //padding: const EdgeInsets.only(left: 16, right: 16),
                  children: <Widget>[
                    DataTable(
                      decoration: BoxDecoration(
                          //borderRadius: BorderRadius.circular(1),
                          border: Border.all(width: 0.6, color: Colors.black38)
                      ),
                      headingRowColor: MaterialStateColor.resolveWith((states) => Colors.blue[50]),
                      headingTextStyle: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'NotoSansKR', color: Colors.black54, fontSize: 12),
                      headingRowHeight: 30,
                      dataRowHeight: 40,
                      dataRowColor: MaterialStateColor.resolveWith((states) => Colors.white),
                      dataTextStyle: TextStyle(fontWeight: FontWeight.normal, fontFamily: 'NotoSansKR', fontSize: 14),
                      columnSpacing: 0,
                      columns: <DataColumn>[
                        DataColumn(label: Expanded(child: Text('요일', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text(widget.sbGbn == 'S' ? '영업 시작' : '휴게 시작', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text(widget.sbGbn == 'S' ? '영업 종료' : '휴게 종료', textAlign: TextAlign.center)),),
                        DataColumn(label: Expanded(child: Text(widget.sbGbn == 'S' ? '휴무' : '없음', textAlign: TextAlign.center)),),
                      ],
                      //source: listDS,
                      rows: dataList.map((item) {
                        return DataRow(cells: [
                          DataCell(Center(child: Text(Utils.getDay(item.dayGbn) ?? '--', style: TextStyle(color: item.closeGbn == 'Y' ? Colors.black38: Colors.black, fontSize: 12)))),
                          DataCell(Center(
                              child: Container(
                                width: 80,
                                height: 30,
                                child: TextFormField(
                                  textAlign: TextAlign.center,
                                  style: TextStyle(fontWeight: FontWeight.normal, fontFamily: 'NotoSansKR', fontSize: 14),
                                  keyboardType: TextInputType.number,
                                  inputFormatters: <TextInputFormatter>[
                                    MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')
                                  ],
                                  expands: false,
                                  maxLines: 1,
                                  controller: TextEditingController(text: Utils.getTimeFormat(item.openTime) ?? '--'),//Utils.getTimeSet(value)),
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(borderRadius: /*BorderRadius.zero*/const BorderRadius.all(Radius.circular(4)), borderSide: BorderSide(color: Colors.white, width: 1)),
                                    contentPadding: EdgeInsets.all(5),
                                    counterText: '',
                                  ),
                                  onChanged: (v){
                                    //item.tipFrStand = v;
                                    item.openTime = v.toString().replaceAll(':', '');
                                  },
                                ),
                              )
                          )),
                          DataCell(Center(
                            //child: getTimesetData(item.tipToStand)
                            child: Container(
                              width: 80,
                              height: 30,
                              child: TextFormField(
                                textAlign: TextAlign.center,
                                style: TextStyle(fontWeight: FontWeight.normal, fontFamily: 'NotoSansKR', fontSize: 14),
                                keyboardType: TextInputType.number,
                                inputFormatters: <TextInputFormatter>[
                                  MultiMaskedTextInputFormatter(masks: ['x:xx', 'xx:xx'], separator: ':')
                                ],
                                expands: false,
                                maxLines: 1,
                                controller: TextEditingController(text: Utils.getTimeFormat(item.closeTime) ?? '--'),//Utils.getTimeSet(value)),
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(borderRadius: /*BorderRadius.zero*/const BorderRadius.all(Radius.circular(4)), borderSide: BorderSide(color: Colors.white, width: 1)),
                                  contentPadding: EdgeInsets.all(5),
                                  counterText: '',
                                ),
                                onChanged: (v){
                                  //item.tipToStand = v;
                                  item.closeTime = v.toString().replaceAll(':', '');
                                },
                              ),
                            ),
                          )),
                          DataCell(Center(
                            child: Container(
                              child: Checkbox(
                                  checkColor: Colors.white,
                                  activeColor: Colors.blue,//Colors.black54,//item.defaultItem == true ? Colors.blue :
                                  value: item.closeGbn == 'Y' ? true : false,
                                  onChanged: (value) {
                                    item.closeGbn == 'N' ? item.closeGbn = 'Y' : item.closeGbn = 'N';

                                    // if (item.defaultItem == true){
                                    //   dataAuthList.forEach((element) {
                                    //     element.CREATE_YN = (value == true ? 'Y' : 'N');
                                    //   });
                                    // }
                                    // else {
                                    //   item.CREATE_YN == 'N' ? item.CREATE_YN = 'Y' : item.CREATE_YN = 'N';
                                    //
                                    //   refreshDefaultItem(item.CREATE_YN, 1);
                                    // }

                                    setState(() {});
                                  }
                              ),
                            ),
                          )
                          ),
                        ]);
                      }).toList(),
                    ),
                  ],
                )
            ),
          ],
        )
      ],
    );
  }
}
