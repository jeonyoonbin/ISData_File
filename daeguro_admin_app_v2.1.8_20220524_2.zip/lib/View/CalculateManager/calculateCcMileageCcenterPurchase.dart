
import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/search/is_search_dropdown.dart';
import 'package:daeguro_admin_app/Model/calc/calculateShopMileageModel.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/View/CalculateManager/calculate_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';

class CalculateCcMileageCcenterPurchase extends StatefulWidget {
  final String ccCode;
  final List<SelectOptionVO> callCenterList;

  const CalculateCcMileageCcenterPurchase({Key key, this.ccCode, this.callCenterList})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CalculateCcMileageCcenterPurchaseState();
  }
}

class CalculateCcMileageCcenterPurchaseState extends State<CalculateCcMileageCcenterPurchase> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  //ApiCompanyDModel formData = ApiCompanyDModel();

  //String _ioGbn = 'I';
  String _amt = '';
  //String _memo = '';
  String _toCcCode = ' ';

  //List<SelectOptionVO> selectBox_ioGbnType = List();

  @override
  void initState() {
    super.initState();

    // selectBox_ioGbnType.clear();
    //
    // selectBox_ioGbnType.add(new SelectOptionVO(value: 'I', label: '입금'));
    // selectBox_ioGbnType.add(new SelectOptionVO(value: 'O', label: '출금'));

    widget.callCenterList.forEach((element) {
        if (element.label == '전체')
          element.label = '--';
    });

    // if (widget.sData != null) {
    //   formData = widget.sData;
    // } else {
    //   formData = ApiCompanyDModel();
    // }
  }

  @override
  void dispose() {
    //selectBox_ioGbnType.clear();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: [
              Flexible(
                flex: 1,
                child: ISSelect(
                  label: '출금 콜센터명',
                  ignoring: true,
                  value: widget.ccCode,
                  dataList: widget.callCenterList,
                  onChange: (v) {

                  },
                ),
              ),
              Flexible(
                flex: 1,
                child: ISSelect(
                  label: '입금 콜센터명',
                  value: _toCcCode,
                  dataList: widget.callCenterList,
                  onChange: (v) {
                    widget.callCenterList.forEach((element) {
                      if (v == element.value) {
                        _toCcCode = element.value;
                      }
                    });
                  },
                ),
              )
            ],
          ),
          Row(
            children: <Widget>[
              // Flexible(
              //   flex: 1,
              //   child: ISSelect(
              //     label: '사입 구분',
              //     value: _ioGbn,
              //     dataList: selectBox_ioGbnType,
              //     onChange: (value) {
              //       setState(() {
              //         _ioGbn = value;
              //       });
              //     },
              //   ),
              // ),
              Flexible(
                  flex: 1,
                  child: ISInput(
                    autofocus: true,
                    value: _amt,//formData.MEMO,
                    label: '금액',
                    onChange: (v) {
                      _amt = v;
                    },
                  )
              ),
            ],
          ),
          // Container(
          //   child: ISInput(
          //     autofocus: true,
          //     value: _memo,//formData.MEMO,
          //     label: '메모',
          //     textStyle: TextStyle(fontSize: 12),
          //     maxLines: 8,
          //     height: 120,
          //     keyboardType: TextInputType.multiline,
          //     // validator: (v) {
          //     //   return v.isEmpty ? '수량을 입력해주세요' : null;
          //     // },
          //     onChange: (v) {
          //       _memo = v;
          //     },
          //   ),
          // ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '실행',
          iconData: Icons.save,
          onPressed: () async {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            form.save();

            if (_toCcCode.trim().toString() == ''){
              ISAlert(context, '입금 콜센터를 확인해 주세요.');
              return;
            }

            if (_amt == ''){
              ISAlert(context, '금액을 입력해 주세요.');
              return;
            }

            String _uCode = GetStorage().read('logininfo')['uCode'];
            // formData.userName = GetStorage().read('logininfo')['name'];

            CalculateController.to.postCcMileageMoveCharge(context, widget.ccCode, _toCcCode, _amt, _uCode);

            Navigator.pop(context, true);
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('콜센터간 사입 처리'),
      ),
      body: Column(
        children: [
          SizedBox(height: 10),
          Container(
              padding: EdgeInsets.symmetric(horizontal: 8.0),
              child: form
          ),
        ],
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 430,
      height: 240,
      child: result,
    );
  }
}
