import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class taxiNoticeListModel {
  taxiNoticeListModel();

  bool selected = false;
  String seqBoard;
  String noParent;
  String noThread;
  String noDepth;
  String idBoard;
  String divBoard;
  String cdComp;
  String subject;
  String ynOpen;
  String dtStart;
  String dtEnd;

  factory taxiNoticeListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

taxiNoticeListModel _$ModelFromJson(Map<String, dynamic> json) {
  return taxiNoticeListModel()
    ..selected = json['selected'] as bool
    ..seqBoard = json['seqBoard'] as String
    ..noParent = json['noParent'] as String
    ..noThread = json['noThread'] as String
    ..noDepth = json['noDepth'] as String
    ..idBoard = json['idBoard'] as String
    ..divBoard = json['divBoard'] as String
    ..cdComp = json['cdComp'] as String
    ..subject = json['subject'] as String
    ..ynOpen = json['ynOpen'] as String
    ..dtStart = json['dtStart'] as String
    ..dtEnd = json['dtEnd'] as String;
}

Map<String, dynamic> _$ModelToJson(taxiNoticeListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'seqBoard': instance.seqBoard,
  'noParent': instance.noParent,
  'noThread': instance.noThread,
  'noDepth': instance.noDepth,
  'idBoard': instance.idBoard,
  'divBoard': instance.divBoard,
  'cdComp': instance.cdComp,
  'subject': instance.subject,
  'ynOpen': instance.ynOpen,
  'dtStart': instance.dtStart,
  'dtEnd': instance.dtEnd
};
