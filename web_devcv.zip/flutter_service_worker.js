'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "assets/AssetManifest.json": "a151be06f7730265b6ac2f3c333306b7",
"assets/assets/animat-responsive-color.gif": "43c68fbe91e9b8a83464d04ddc357fb5",
"assets/assets/apple_icon_32.png": "cd698fc10fa1ab630671a91a02555c40",
"assets/assets/BI_1.png": "a4a13f1571f223f8755a999e3129433e",
"assets/assets/BI_5.png": "98b06947e367c218ee9d64b2d60fc097",
"assets/assets/BI_6.png": "9053cbceb7874e31a75f23830bf27b7f",
"assets/assets/btnAppAlertnotice_000.png": "71c7286ff095b815b040f5a48e67c7ae",
"assets/assets/btnAppAlertnotice_001.png": "e934b5afe75555f7fb87575531e34caa",
"assets/assets/btnAppAlertnotice_100.png": "6bc3765982ee5e6cd9efd4e4296eca0f",
"assets/assets/btnAppAlertnotice_101.png": "2bbc3743d36a18d59614c0c808155837",
"assets/assets/btnAppAlertnotice_200.png": "dc19237773a0a1585afc7715cace18e4",
"assets/assets/btnAppAlertnotice_201.png": "3d2c7d5079329cfe8a1ca9cfcfbca808",
"assets/assets/dadaegu.png": "fff557202bf40bd4b2044fad542e20f0",
"assets/assets/daeguro_icon_32.png": "7d56d047296879a6a0bccace8a8745aa",
"assets/assets/editor.html": "02312e7a1e9edb0c9b4a5d832eadcb41",
"assets/assets/empty_menu.png": "d11e8b5488486811419a6487f61f9a97",
"assets/assets/flower_info_1.png": "c6377ba1d6b662530624646b3566e18a",
"assets/assets/fonts/font_roboto_bold.ttf": "e07df86cef2e721115583d61d1fb68a6",
"assets/assets/fonts/font_roboto_regular.ttf": "11eabca2251325cfc5589c9c6fb57b46",
"assets/assets/fonts/NotoSansKR-Regular.otf": "913f146b0200b19b17eb4de8b4427a9c",
"assets/assets/google_icon_32.png": "cf5e6630ae753609af1a8106b2eb8861",
"assets/assets/image-resize.min.js": "c6329b8b4f764d9983d291c02ac2389d",
"assets/assets/info1.png": "24d8079cc39d5941ed000b73a71e7eea",
"assets/assets/info2.png": "d579a8d2c8490fae9cd83820495c3872",
"assets/assets/initCardImage.jpg": "8e9e7da146db08732d97b7f1113563ce",
"assets/assets/initVoucherImage.png": "febee732a03361bf33a73c7ad5dd1770",
"assets/assets/jquery.min.js": "9ac39dc31635a363e377eda0f6fbe03f",
"assets/assets/kakao_icon_32.png": "17ffe8d48c72e9348c3937be25ae18bc",
"assets/assets/logo.png": "cf0f6e83eedd8fcf8ff8e844cac548fb",
"assets/assets/naver_icon_32.png": "4ce9b2838256207b3401a446e1ec7794",
"assets/assets/quill.bubble.css": "da771fde1afdc1549ed61f2e111211b8",
"assets/assets/quill.js": "405d190bcde9746579f8e6fae5dc5cdf",
"assets/assets/quill.snow.css": "e91875a3a958d4cd53dab04c99c6964f",
"assets/assets/serverInfo.txt": "ae8c867154c72c576eaf0c8a3b70d029",
"assets/assets/view.html": "3cfe193e645e65176871d4c52a835791",
"assets/FontManifest.json": "6c8485c2576b3ded3a533c56e2df3f4c",
"assets/fonts/MaterialIcons-Regular.otf": "4e6447691c9509f7acdbf8a931a85ca1",
"assets/NOTICES": "cc518c9075802831df1b21994c0c0f66",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/packages/flutter_inappwebview/t_rex_runner/t-rex.css": "5a8d0222407e388155d7d1395a75d5b9",
"assets/packages/flutter_inappwebview/t_rex_runner/t-rex.html": "16911fcc170c8af1c5457940bd0bf055",
"assets/packages/html_editor_enhanced/assets/font/summernote.eot": "f4a47ce92c02ef70fc848508f4cec94a",
"assets/packages/html_editor_enhanced/assets/font/summernote.ttf": "82fa597f29de41cd41a7c402bcf09ba5",
"assets/packages/html_editor_enhanced/assets/font/summernote.woff": "c1a96d26d30d9e0b2fd33c080d88c72e",
"assets/packages/html_editor_enhanced/assets/font/summernote.woff2": "f694db69cded200e4edd999fddef81b7",
"assets/packages/html_editor_enhanced/assets/jquery.min.js": "dc5e7f18c8d36ac1d3d4753a87c98d0a",
"assets/packages/html_editor_enhanced/assets/plugins/additional-text-tags/summernote-add-text-tags.css": "de07ab5a4d56bb952997e73f70293fd3",
"assets/packages/html_editor_enhanced/assets/plugins/additional-text-tags/summernote-add-text-tags.js": "92b9bdd6bf477b2b5f6a9dcc3548c360",
"assets/packages/html_editor_enhanced/assets/plugins/summernote-at-mention/bundle.js": "297c8de712d990695fe1b73327f72b2a",
"assets/packages/html_editor_enhanced/assets/plugins/summernote-case-converter/summernote-case-converter.js": "436223c547bc8fe220f58da03e27bdcc",
"assets/packages/html_editor_enhanced/assets/plugins/summernote-codewrapper/summernote-ext-codewrapper.min.js": "fcee96125f8310c1ebe51d06f7ab761e",
"assets/packages/html_editor_enhanced/assets/plugins/summernote-emoji/summernote-ext-emoji-ajax.css": "fcd1d224545428dad2f684887738724d",
"assets/packages/html_editor_enhanced/assets/plugins/summernote-emoji/summernote-ext-emoji-ajax.js": "841136db7b3fe2db4db070e06769d674",
"assets/packages/html_editor_enhanced/assets/plugins/summernote-file/summernote-file.js": "ff8055e39a04b5fe6e13031ca88ef278",
"assets/packages/html_editor_enhanced/assets/plugins/summernote-list-styles/summernote-list-styles.css": "af3d39f54c88336cfec859e9aee90fea",
"assets/packages/html_editor_enhanced/assets/plugins/summernote-list-styles/summernote-list-styles.js": "0ea0e9e9a5474573e1b133bab3fd39b1",
"assets/packages/html_editor_enhanced/assets/plugins/summernote-rtl/summernote-ext-rtl.js": "3e921472369ed4d53776cea3e3047238",
"assets/packages/html_editor_enhanced/assets/summernote-lite-dark.css": "f338b364d403291905bc9a5cbc89b986",
"assets/packages/html_editor_enhanced/assets/summernote-lite.min.css": "e43795ac694ce873fd375cadc044e996",
"assets/packages/html_editor_enhanced/assets/summernote-lite.min.js": "15e3ba38b931760d5bba02653dfe05aa",
"assets/packages/html_editor_enhanced/assets/summernote-no-plugins.html": "4f81344100a4f8b701e0fd05c19f50d1",
"assets/packages/html_editor_enhanced/assets/summernote.html": "3c30a7f2fb5d81cc589e611ebe67d99b",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"index.html": "7ae9434018e6f46a4362a5b5dac19f68",
"/": "7ae9434018e6f46a4362a5b5dac19f68",
"main.dart.js": "fe8110052a58632be02f70a88dfdf0bf",
"manifest.json": "3d178707007b3b60d91745e0464910a0",
"version.json": "da6be7110a6130989fd7332a7a03cf8d"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "/",
"main.dart.js",
"index.html",
"assets/NOTICES",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache.
        return response || fetch(event.request).then((response) => {
          cache.put(event.request, response.clone());
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
