import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiOrderHistModel {
  TaxiOrderHistModel();

  bool selected = false;
  String dtOrdNo;
  String seqOrdNo;
  String dtmIns;
  String idUsrIns;
  String nmUsrIns;
  String divDevice;
  String colComments;
  String statusDesc;

  factory TaxiOrderHistModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiOrderHistModel _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiOrderHistModel()

    ..selected = json['selected'] as bool
    ..dtOrdNo = json['dtOrdNo'] as String
    ..seqOrdNo = json['seqOrdNo'] as String
    ..dtmIns = json['dtmIns'] as String
    ..idUsrIns = json['idUsrIns'] as String
    ..nmUsrIns = json['nmUsrIns'] as String
    ..divDevice = json['divDevice'] as String
    ..colComments = json['colComments'] as String
    ..statusDesc = json['statusDesc'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiOrderHistModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'dtOrdNo': instance.dtOrdNo,
  'seqOrdNo': instance.seqOrdNo,
  'dtmIns': instance.dtmIns,
  'idUsrIns': instance.idUsrIns,
  'nmUsrIns': instance.nmUsrIns,
  'divDevice': instance.divDevice,
  'colComments': instance.colComments,
  'statusDesc': instance.statusDesc,
};