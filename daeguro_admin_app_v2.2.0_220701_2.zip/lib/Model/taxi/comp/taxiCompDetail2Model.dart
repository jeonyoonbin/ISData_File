import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class TaxiCompDetail2Model {
  TaxiCompDetail2Model();

  bool selected = false;
  bool viewSelected;
  String cdComp;
  String cdVaccBank;
  String cdVaccBankText;
  String noVacc;
  String cntDayTrans;
  String amtDayTrans;
  String cntMonTrans;
  String amtMonTrans;
  String amtMinSave;
  String urlCs;
  String ynPts;
  String ynPtsText;
  String ynRePts;
  String ynRePtsText;
  String amtMinPay;
  String divPts;
  String divPtsText;
  String unitPts;
  String unitPtsText;
  String amtPts;
  String dayUse;
  String amtMinOrder;
  String amtMinUse;
  String amtMinPts;
  String ynPtsCoupon;
  String ynPtsCouponText;
  String amtMinCoupon;
  String divPayHappy;
  String divPayHappyText;
  String unitPayHappy;
  String unitPayHappyText;
  String amtPayHappy;
  String amtCut;
  String amtCutText;

  factory TaxiCompDetail2Model.fromJson(Map<String, dynamic> json) => _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

TaxiCompDetail2Model _$ModelFromJson(Map<String, dynamic> json) {
  return TaxiCompDetail2Model()
    ..selected = json['selected'] as bool
    ..viewSelected = json['viewSelected'] as bool
    ..cdComp = json['cdComp'] as String
    ..cdVaccBank = json['cdVaccBank'] as String
    ..cdVaccBankText = json['cdVaccBankText'] as String
    ..noVacc = json['noVacc'] as String
    ..cntDayTrans = json['cntDayTrans'] as String
    ..amtDayTrans = json['amtDayTrans'] as String
    ..cntMonTrans = json['cntMonTrans'] as String
    ..amtMonTrans = json['amtMonTrans'] as String
    ..amtMinSave = json['amtMinSave'] as String
    ..urlCs = json['urlCs'] as String
    ..ynPts = json['ynPts'] as String
    ..ynPtsText = json['ynPtsText'] as String
    ..ynRePts = json['ynRePts'] as String
    ..ynRePtsText = json['ynRePtsText'] as String
    ..amtMinPay = json['amtMinPay'] as String
    ..divPts = json['divPts'] as String
    ..divPtsText = json['divPtsText'] as String
    ..unitPts = json['unitPts'] as String
    ..unitPtsText = json['unitPtsText'] as String
    ..amtPts = json['amtPts'] as String
    ..dayUse = json['dayUse'] as String
    ..amtMinOrder = json['amtMinOrder'] as String
    ..amtMinUse = json['amtMinUse'] as String
    ..amtMinPts = json['amtMinPts'] as String
    ..ynPtsCoupon = json['ynPtsCoupon'] as String
    ..ynPtsCouponText = json['ynPtsCouponText'] as String
    ..amtMinCoupon = json['amtMinCoupon'] as String
    ..divPayHappy = json['divPayHappy'] as String
    ..divPayHappyText = json['divPayHappyText'] as String
    ..unitPayHappy = json['unitPayHappy'] as String
    ..unitPayHappyText = json['unitPayHappyText'] as String
    ..amtPayHappy = json['amtPayHappy'] as String
    ..amtCut = json['amtCut'] as String
    ..amtCutText = json['amtCutText'] as String;
}

Map<String, dynamic> _$ModelToJson(TaxiCompDetail2Model instance) => <String, dynamic>{
      'selected': instance.selected,
      'viewSelected': instance.viewSelected,
      'cdComp': instance.cdComp,
      'cdVaccBank': instance.cdVaccBank,
      'cdVaccBankText': instance.cdVaccBankText,
      'noVacc': instance.noVacc,
      'cntDayTrans': instance.cntDayTrans,
      'amtDayTrans': instance.amtDayTrans,
      'cntMonTrans': instance.cntMonTrans,
      'amtMonTrans': instance.amtMonTrans,
      'amtMinSave': instance.amtMinSave,
      'urlCs': instance.urlCs,
      'ynPts': instance.ynPts,
      'ynPtsText': instance.ynPtsText,
      'ynRePts': instance.ynRePts,
      'ynRePtsText': instance.ynRePtsText,
      'amtMinPay': instance.amtMinPay,
      'divPts': instance.divPts,
      'divPtsText': instance.divPtsText,
      'unitPts': instance.unitPts,
      'unitPtsText': instance.unitPtsText,
      'amtPts': instance.amtPts,
      'dayUse': instance.dayUse,
      'amtMinOrder': instance.amtMinOrder,
      'amtMinUse': instance.amtMinUse,
      'amtMinPts': instance.amtMinPts,
      'ynPtsCoupon': instance.ynPtsCoupon,
      'ynPtsCouponText': instance.ynPtsCouponText,
      'amtMinCoupon': instance.amtMinCoupon,
      'divPayHappy': instance.divPayHappy,
      'divPayHappyText': instance.divPayHappyText,
      'unitPayHappy': instance.unitPayHappy,
      'unitPayHappyText': instance.unitPayHappyText,
      'amtPayHappy': instance.amtPayHappy,
      'amtCut': instance.amtCut,
      'amtCutText': instance.amtCutText
    };
