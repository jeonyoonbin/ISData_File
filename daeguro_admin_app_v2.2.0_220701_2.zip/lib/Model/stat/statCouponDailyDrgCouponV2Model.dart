import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class StatCouponDailyDrgCouponV2Model {
  StatCouponDailyDrgCouponV2Model();

  String DAILY;
  String STATUS;
  int A1 = 0;
  int A2 = 0;
  int B1 = 0;
  int B2 = 0;
  int C1 = 0;
  int C2 = 0;
  int D1 = 0;
  int D2 = 0;
  int E1 = 0;
  int E2 = 0;

  factory StatCouponDailyDrgCouponV2Model.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

StatCouponDailyDrgCouponV2Model _$ModelFromJson(Map<String, dynamic> json) {
  return StatCouponDailyDrgCouponV2Model()
    ..DAILY = json['DAILY'] as String
    ..STATUS = json['STATUS'] as String
    ..A1 = json['A1'] as int
    ..A2 = json['A2'] as int
    ..B1 = json['B1'] as int
    ..B2 = json['B2'] as int
    ..C1 = json['C1'] as int
    ..C2 = json['C2'] as int
    ..D1 = json['D1'] as int
    ..D2 = json['D2'] as int
    ..E1 = json['E1'] as int
    ..E2 = json['E2'] as int;
}

Map<String, dynamic> _$ModelToJson(StatCouponDailyDrgCouponV2Model instance) => <String, dynamic>{
  'DAILY': instance.DAILY,
  'STATUS': instance.STATUS,
  'A1': instance.A1,
  'A2': instance.A2,
  'B1': instance.B1,
  'B2': instance.B2,
  'C1': instance.C1,
  'C2': instance.C2,
  'D1': instance.D1,
  'D2': instance.D2,
  'E1': instance.E1,
  'E2': instance.E2
};
