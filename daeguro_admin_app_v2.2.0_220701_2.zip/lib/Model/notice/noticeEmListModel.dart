import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class noticeEmListModel {
  noticeEmListModel();

  bool selected = false;
  String seq;
  String use;
  String title;
  String contents;
  String url;
  String img_url;
  String android_ver;
  String android_min;
  String ios_ver;
  String ios_min;
  String ins_date;
  String ins_ucode;
  String ins_name;
  String mod_date;
  String mod_ucode;
  String mod_name;

  factory noticeEmListModel.fromJson(Map<String,dynamic> json) => _$ModelFromJson(json);
  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

noticeEmListModel _$ModelFromJson(Map<String, dynamic> json) {
  return noticeEmListModel()
    ..selected = json['selected'] as bool
    ..seq = json['seq'] as String
    ..use = json['use'] as String
    ..title = json['title'] as String
    ..contents = json['contents'] as String
    ..url = json['url'] as String
    ..img_url = json['img_url'] as String
    ..android_ver = json['android_ver'] as String
    ..android_min = json['android_min'] as String
    ..ios_ver = json['ios_ver'] as String
    ..ios_min = json['ios_min'] as String
    ..ins_date = json['ins_date'] as String
    ..ins_ucode = json['ins_ucode'] as String
    ..ins_name = json['ins_name'] as String
    ..mod_date = json['mod_date'] as String
    ..mod_ucode = json['mod_ucode'] as String
    ..mod_name = json['mod_name'] as String
  ;
}

Map<String, dynamic> _$ModelToJson(noticeEmListModel instance) => <String, dynamic>{
  'selected': instance.selected,
  'seq': instance.seq,
  'use': instance.use,
  'title': instance.title,
  'contents': instance.contents,
  'url': instance.url,
  'img_url': instance.img_url,
  'android_ver': instance.android_ver,
  'android_min': instance.android_min,
  'ios_ver': instance.ios_ver,
  'ios_min': instance.ios_min,
  'ins_date': instance.ins_date,
  'ins_ucode': instance.ins_ucode,
  'ins_name': instance.ins_name,
  'mod_date': instance.mod_date,
  'mod_ucode': instance.mod_ucode,
  'mod_name': instance.mod_name,
};
