import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopReserveUpdateNoticeModel {
  ShopReserveUpdateNoticeModel();

  String shopCd = '';
  String ccCode = '';
  String notice = '';
  String userID = '';

  factory ShopReserveUpdateNoticeModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopReserveUpdateNoticeModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopReserveUpdateNoticeModel()
    ..shopCd = json['shopCd'] as String
    ..ccCode = json['ccCode'] as String
    ..notice = json['notice'] as String
    ..userID = json['userID'] as String;

}

Map<String, dynamic> _$ModelToJson(ShopReserveUpdateNoticeModel instance) => <String, dynamic>{
  'shopCd': instance.shopCd,
  'ccCode': instance.ccCode,
  'notice': instance.notice,
  'userID': instance.userID
};