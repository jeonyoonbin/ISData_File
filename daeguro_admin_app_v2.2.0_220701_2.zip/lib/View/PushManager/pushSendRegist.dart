


import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/is_tableInput.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/View/PushManager/push_controller.dart';

import 'package:date_format/date_format.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';


class PushSendRegist extends StatefulWidget {
  const PushSendRegist({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return PushSendRegistState();
  }
}

enum RadioUseGbn { gbn1, gbn2 }

class PushSendRegistState extends State<PushSendRegist> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  List<SelectOptionVO> selectBox_Year = [];
  List<SelectOptionVO> selectBox_Month = [];
  List<SelectOptionVO> selectBox_Day = [];

  List<SelectOptionVO> selectBox_Hour = [];
  List<SelectOptionVO> selectBox_Minute = [];

  List<SelectOptionVO> selectBox_sendDataType = [];

  List<SelectOptionVO> selectBox_sendTargetUser = [];
  List<SelectOptionVO> selectBox_sendTarget = [];

  RadioUseGbn _radioUseGbn;

  String _pushTitle = '';
  String _pushMemo = '';
  String _pushTestPhonenum = '';

  String _sendTypeYear = '';
  String _sendTypeMonth = '';
  String _sendTypeDay = '';
  String _sendTypeHour = '9';
  String _sendTypeMinute = '00';

  String _sendTargetUser = '0';
  String _sendTarget = '0';

  String _sendDataType = '0';

  String _sendlimitStartHour = '0';
  String _sendlimitStartMinute = '00';

  String _sendlimitEndHour = '7';
  String _sendlimitEndMinute = '00';

  String btnTypeString = '';

  @override
  void dispose(){
    selectBox_Year.clear();
    selectBox_Month.clear();
    selectBox_Hour.clear();
    selectBox_Minute.clear();

    super.dispose();
  }

  setDateTimeFormatList() {
    DateTime now = DateTime.now();

    _sendTypeYear = now.year.toString();
    _sendTypeMonth = now.month.toString();
    _sendTypeDay = now.day.toString();

    var Monthlist = Iterable<int>.generate(13).toList();
    var Hourlist = Iterable<int>.generate(24).toList();
    var Minutelist = Iterable<int>.generate(6).toList();


    selectBox_Year.add(new SelectOptionVO(value: '${now.year.toString()}', label: '${now.year.toString()}'));

    Monthlist.forEach((element) {
      String value = (element < 10) ? '0${element}': element.toString();

      if (element > 0) {
        //print('element:${element}, value:${value}');
        selectBox_Month.add(new SelectOptionVO(value: '${element}', label: '${value}'));
      }
    });

    setMonthlyDayReset();

    Hourlist.forEach((element) {
      String value = (element < 10) ? '0${element}': element.toString();

      selectBox_Hour.add(new SelectOptionVO(value: '${element}', label: '${value}'));
    });

    Minutelist.forEach((element) {
      String value = (element == 0) ? '00': '${(element*10)}';



      selectBox_Minute.add(new SelectOptionVO(value: '${value}', label: '${value}'));
    });
  }

  setMonthlyDayReset(){
    selectBox_Day.clear();

    String endDay = formatDate(DateTime(int.parse(_sendTypeYear), int.parse(_sendTypeMonth) + 1, 0), [dd]);

    var Daylist = Iterable<int>.generate(int.parse(endDay)+1).toList();

    Daylist.forEach((element) {
      String value = (element < 10) ? '0${element}': element.toString();

      if (element > 0)
        selectBox_Day.add(new SelectOptionVO(value: '${element}', label: '${value}'));
    });
  }

  @override
  void initState() {
    super.initState();

    Get.put(PushController());

    setDateTimeFormatList();


    selectBox_sendDataType.add(new SelectOptionVO(value: '0', label: 'DB'));
    selectBox_sendDataType.add(new SelectOptionVO(value: '1', label: 'CSV'));

    selectBox_sendTargetUser.add(new SelectOptionVO(value: '0', label: '회원만'));
    selectBox_sendTargetUser.add(new SelectOptionVO(value: '1', label: '전체회원'));
    selectBox_sendTargetUser.add(new SelectOptionVO(value: '2', label: '비회원'));

    selectBox_sendTarget.add(new SelectOptionVO(value: '0', label: '전체'));
    selectBox_sendTarget.add(new SelectOptionVO(value: '1', label: '마케팅 동의만'));


    _radioUseGbn = RadioUseGbn.gbn1;
    btnTypeString = '즉시';
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
            Table(
              columnWidths: const {0: FixedColumnWidth(130), 1: FlexColumnWidth(),},
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                border: TableBorder.symmetric(inside: BorderSide(width: 0.1, color: Colors.black), outside: BorderSide(width: 1.2, color: Colors.black12)),
                children: [
                  TableRow(children: [
                    Container(
                        color: Colors.blue[50],
                        height: 44,
                        alignment: Alignment.center,
                        child: Text('제목', style: TextStyle(fontSize: 12),)
                    ),
                    Container(
                      color: Colors.white,
                      child: ISTableInput(
                        height: 30,
                        value: _pushTitle,
                        textStyle: TextStyle(fontSize: 12),
                        onChange: (v) {
                          _pushTitle = v;
                          setState(() {

                          });
                        },
                      ),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                        color: Colors.blue[50],
                        height: 74,
                        alignment: Alignment.center,
                        child: Text('발송 방식', style: TextStyle(fontSize: 12))
                    ),
                    Container(
                      color: Colors.white,
                      height: 76,
                      padding: EdgeInsets.only(left: 16),//symmetric(horizontal: 16),
                      child: Column(
                        children: [
                          SizedBox(height: 4,),
                          Row(
                            children: [
                              Radio(
                                  value: RadioUseGbn.gbn1,
                                  groupValue: _radioUseGbn,
                                  onChanged: (v) async {
                                    _radioUseGbn = v;
                                    
                                    setState(() {
                                      btnTypeString = '즉시';
                                    });
                                  }),
                              Text('즉시', style: TextStyle(fontSize: 12)),
                              Container(
                                margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                                child: Radio(
                                    value: RadioUseGbn.gbn2,
                                    groupValue: _radioUseGbn,
                                    onChanged: (v) async {
                                      _radioUseGbn = v;

                                      setState(() {
                                        btnTypeString = '예약';
                                      });
                                    }),
                              ),
                              Text('예약', style: TextStyle(fontSize: 12)),
                            ],
                          ),
                          SizedBox(height: 4,),
                          Row(
                            children: [
                              ISSelect(
                                width: 70,
                                height: 30,
                                paddingEnabled: false,
                                value: _sendTypeYear ?? '',
                                dataList: selectBox_Year,
                                onChange: (v){
                                  //current_Sido = v;
                                },
                              ),
                              SizedBox(width: 4,),
                              Text('년'),
                              SizedBox(width: 10,),
                              ISSelect(
                                width: 60,
                                height: 30,
                                paddingEnabled: false,
                                value: _sendTypeMonth ?? '',
                                dataList: selectBox_Month,
                                onChange: (v){
                                  _sendTypeMonth = v;
                                  setMonthlyDayReset();
                                  setState(() {

                                  });
                                },
                              ),
                              SizedBox(width: 4,),
                              Text('월'),
                              SizedBox(width: 4,),
                              ISSelect(
                                width: 60,
                                height: 30,
                                paddingEnabled: false,
                                value: _sendTypeDay ?? '',
                                dataList: selectBox_Day,
                                onChange: (v){
                                  //_themeGungu = v;
                                },
                              ),
                              SizedBox(width: 4,),
                              Text('일'),
                              SizedBox(width: 10,),
                              ISSelect(
                                width: 60,
                                height: 30,
                                paddingEnabled: false,
                                value: _sendTypeHour ?? '',
                                dataList: selectBox_Hour,
                                onChange: (v){
                                  //current_Sido = v;
                                },
                              ),
                              SizedBox(width: 4,),
                              Text('시'),
                              SizedBox(width: 4,),
                              ISSelect(
                                width: 60,
                                height: 30,
                                paddingEnabled: false,
                                value: _sendTypeMinute ?? '',
                                dataList: selectBox_Minute,
                                onChange: (v){
                                  //_themeGungu = v;
                                },
                              ),
                              SizedBox(width: 4,),
                              Text('분'),
                            ],
                          )
                        ],
                      ),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                        color: Colors.blue[50],
                        height: 54,
                        alignment: Alignment.center,
                        child: Text('발송제한시간', style: TextStyle(fontSize: 12))
                    ),
                    Container(
                      color: Colors.white,
                      height: 56,
                      padding: EdgeInsets.only(left: 16),//symmetric(horizontal: 16),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              ISSelect(
                                width: 60,
                                height: 30,
                                paddingEnabled: false,
                                value: _sendlimitStartHour ?? '',
                                dataList: selectBox_Hour,
                                onChange: (v){
                                  _sendlimitStartHour = v;
                                },
                              ),
                              SizedBox(width: 4,),
                              Text('시'),
                              SizedBox(width: 10,),
                              ISSelect(
                                width: 60,
                                height: 30,
                                paddingEnabled: false,
                                value: _sendlimitStartMinute ?? '',
                                dataList: selectBox_Minute,
                                onChange: (v){
                                  _sendlimitStartMinute = v;
                                },
                              ),
                              SizedBox(width: 4,),
                              Text('분'),
                              SizedBox(width: 10,),
                              Text('~'),
                              SizedBox(width: 10,),
                              ISSelect(
                                width: 60,
                                height: 30,
                                paddingEnabled: false,
                                value: _sendlimitEndHour ?? '',
                                dataList: selectBox_Hour,
                                onChange: (v){
                                  _sendlimitEndHour = v;
                                },
                              ),
                              SizedBox(width: 4,),
                              Text('시'),
                              SizedBox(width: 10,),
                              ISSelect(
                                width: 60,
                                height: 30,
                                paddingEnabled: false,
                                value: _sendlimitEndMinute ?? '',
                                dataList: selectBox_Minute,
                                onChange: (v){
                                  _sendlimitEndMinute = v;
                                },
                              ),
                              SizedBox(width: 4,),
                              Text('분'),
                            ],
                          ),
                          SizedBox(height: 4,),
                          Text('* 설정된 시간까지 발송이 중지 됩니다.', style: TextStyle(fontSize: 10, color: Colors.red),),
                        ],
                      ),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                        color: Colors.blue[50],
                        height: 74,
                        alignment: Alignment.center,
                        child: Text('대상 DB/CSV', style: TextStyle(fontSize: 12))
                    ),
                    Container(
                      color: Colors.white,
                      height: 76,
                      padding: EdgeInsets.only(left: 16),//symmetric(horizontal: 16),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 4,),
                          Row(
                            children: [
                              Row(
                                children: [
                                  ISSelect(
                                    width: 120,
                                    height: 30,
                                    paddingEnabled: false,
                                    value: _sendDataType ?? '',
                                    dataList: selectBox_sendDataType,
                                    onChange: (v){
                                      _sendDataType = v;
                                    },
                                  )
                                ],
                              ),
                              SizedBox(width: 20,),
                              Row(
                                children: [
                                  MaterialButton(
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Icon(Icons.file_download, color: Colors.blue, size: 21,),
                                        SizedBox(width: 4,),
                                        Text('샘플파일(sample.csv) 다운로드', style: TextStyle(color: Colors.black, fontSize: 12))
                                      ],
                                    ),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                                    onPressed: ()  {
                                      //_launchInBrowser(_themeImageRealURL +'?tm=${Utils.getTimeStamp()}');
                                    },
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 4,),
                          Row(
                            children: [
                              MaterialButton(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Icon(Icons.folder_open, color: Colors.blue, size: 21,),
                                    SizedBox(width: 4,),
                                    Text('선택된 파일이 없습니다.', style: TextStyle(color: Colors.black, fontSize: 12))
                                  ],
                                ),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                                onPressed: ()  {
                                  //_launchInBrowser(_themeImageRealURL +'?tm=${Utils.getTimeStamp()}');
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                        color: Colors.blue[50],
                        height: 44,
                        alignment: Alignment.center,
                        child: Text('발송 범위', style: TextStyle(fontSize: 12))
                    ),
                    Container(
                      color: Colors.white,
                      height: 46,
                      padding: EdgeInsets.only(left: 16),//symmetric(horizontal: 16),
                      child: Row(
                        children: [
                          ISSelect(
                            width: 120,
                            height: 30,
                            paddingEnabled: false,
                            value: _sendTargetUser ?? '',
                            dataList: selectBox_sendTargetUser,
                            onChange: (v){
                              _sendTargetUser = v;
                            },
                          ),
                          SizedBox(width: 10,),
                          Row(
                            children: [
                              ISSelect(
                                width: 120,
                                height: 30,
                                paddingEnabled: false,
                                value: _sendTarget ?? '',
                                dataList: selectBox_sendTarget,
                                onChange: (v){
                                  _sendTarget = v;
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                        color: Colors.blue[50],
                        height: 134,
                        alignment: Alignment.center,
                        child: Text('푸시 문구', style: TextStyle(fontSize: 12))
                    ),
                    Container(
                      color: Colors.white,
                      child: ISTableInput(
                        value: _pushMemo,// formData.menuGroupMemo ?? '',
                        //context: context,
                        height: 120,
                        keyboardType: TextInputType.multiline,
                        maxLines: 8,
                        maxLength: 50,//임시로 50글자로 제한
                        onChange: (v) {
                          _pushMemo = v;
                        },
                      ),
                    ),
                  ]),
                  TableRow(children: [
                    Container(
                        color: Colors.blue[50],
                        height: 44,
                        alignment: Alignment.center,
                        child: Text('테스트 발송 번호', style: TextStyle(fontSize: 12),)
                    ),
                    Container(
                      color: Colors.white,
                      child: Row(
                        children: [
                          ISTableInput(
                            width: 200,
                            height: 30,
                            value: _pushTestPhonenum,//formData.bussCon ?? '',
                            //label: '업태',
                            textStyle: TextStyle(fontSize: 12),
                            onChange: (v) {
                              _pushTestPhonenum = v;
                              setState(() {

                              });
                            },
                          ),
                          SizedBox(width: 4,),
                          MaterialButton(
                            color: Colors.blue,
                            minWidth: 70,
                            height: 36,
                            child: Text('단건 발송 테스트', style: TextStyle(color: Colors.white, fontSize: 12),),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),
                            onPressed: (){

                            },
                          )

                        ],
                      ),
                    )
                  ]),
                ]
            ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '${btnTypeString} 발송',
          iconData: Icons.sms,
          onPressed: () async {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            form.save();


          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('앱 푸시 발송'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
                padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
                child: form
            ),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 700,
      height: 620,
      child: result,
    );
  }

}
