import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/ISWidget/is_select_date.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsDetailList.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsEditModel.dart';
import 'package:daeguro_admin_app/Model/Contents/contentsRegistModel.dart';
import 'package:daeguro_admin_app/Model/coupon/couponRegistModel.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/View/ContentsManager/contents_controller.dart';
import 'package:daeguro_admin_app/View/CouponManager/coupon_controller.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ContentsBlogEdit extends StatefulWidget {
  final String contents_cd;

  const ContentsBlogEdit({Key key, this.contents_cd}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ContentsBlogEditState();
  }
}

class ContentsBlogEditState extends State<ContentsBlogEdit> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  ContentsDetailList formData;
  ContentsEditModel editData;

  String _expDate = '';

  List<SelectOptionVO> selectBox_couponType = List();
  List<SelectOptionVO> selectBox_couponItem = List();

  loadData() async {
    formData = null;
    formData = ContentsDetailList();

    await ContentsController.to.getDetailData(widget.contents_cd).then((value) {
      if (value == null) {
        ISAlert(context, '정상조회가 되지 않았습니다. \n\n관리자에게 문의 바랍니다');
      } else {
        formData = ContentsDetailList.fromJson(value);
      }
    });

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ContentsController());
    editData = ContentsEditModel();

    editData.cartegory_gbn = 'R';

    loadData();
  }

  @override
  void dispose() {
    selectBox_couponType.clear();

    selectBox_couponType = null;
    formData = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: Container(
                  margin: EdgeInsets.all(8.0),
                  decoration: new BoxDecoration(color: formData.DISP_GBN == 'Y' ? Colors.blue[200] : Colors.red[200], borderRadius: new BorderRadius.circular(6)),
                  child: SwitchListTile(
                    dense: true,
                    value: formData.DISP_GBN == 'Y' ? true : false,
                    title: Text(
                      '게시 유무',
                      style: TextStyle(fontSize: 10, color: Colors.white),
                    ),
                    onChanged: (v) {
                      setState(() {
                        formData.DISP_GBN = v ? 'Y' : 'N';
                        formKey.currentState.save();
                      });
                    },
                  ),
                ),
              ),
              // Flexible(
              //   flex: 1,
              //   child: Container(),
              // ),
            ],
          ),
          ISInput(
            autofocus: true,
            value: formData.CONTENTS_TITLE,
            label: '제목',
            onSaved: (v) {
              formData.CONTENTS_TITLE = v;
            },
          ),
          ISInput(
            autofocus: true,
            value: formData.MAIN_URL,
            label: '블로그 URL',
            onSaved: (v) {
              formData.MAIN_URL = v;
            },
          ),
          ISInput(
            value: formData.THUMBNAIL_URL,
            context: context,
            label: '썸네일 이미지 URL',
            height: 80,
            contentPadding: 20,
            keyboardType: TextInputType.multiline,
            maxLines: 4,
            onSaved: (v) {
              formData.THUMBNAIL_URL = v;
            },
          ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            form.save();

            editData.contents_cd = widget.contents_cd;
            editData.contents_title = formData.CONTENTS_TITLE;
            editData.disp_gbn = formData.DISP_GBN;
            editData.main_url = formData.MAIN_URL;
            editData.thumbnail_url = formData.THUMBNAIL_URL;
            editData.mod_ucode = GetStorage().read('logininfo')['uCode'];

            ContentsController.to.putContents(editData.toJson(), context);

            Navigator.pop(context, true);
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('블로그 컨텐츠 수정'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10),
            Container(padding: EdgeInsets.symmetric(horizontal: 8.0), child: form),
          ],
        ),
      ),
      bottomNavigationBar: buttonBar,
    );

    return SizedBox(
      width: 450,
      height: 400,
      child: result,
    );
  }
}
