import 'package:daeguro_admin_app/ISWidget/is_button.dart';
import 'package:daeguro_admin_app/ISWidget/is_dialog.dart';
import 'package:daeguro_admin_app/ISWidget/is_input.dart';
import 'package:daeguro_admin_app/ISWidget/is_select.dart';
import 'package:daeguro_admin_app/Model/menu.dart';
import 'package:daeguro_admin_app/View/AuthManager/auth_controller.dart';
import 'package:daeguro_admin_app/Util/select_option_vo.dart';
import 'package:daeguro_admin_app/View/ReservationManager/reservationmanager_controller.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

class ReserveThemeRegist extends StatefulWidget {
  final List<SelectOptionVO> selectBox_mainTheme;

  const ReserveThemeRegist({Key key, this.selectBox_mainTheme}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ReserveThemeRegistState();
  }
}

class ReserveThemeRegistState extends State<ReserveThemeRegist> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  List<SelectOptionVO> selectBox_themeType = List();

  String _themeType = '0';
  String _themeName = '';
  String _themeMainCd = '';

  @override
  void initState() {
    super.initState();

    Get.put(AuthController());

    selectBox_themeType.clear();

    selectBox_themeType.add(new SelectOptionVO(value: '0', label: '메인테마'));
    selectBox_themeType.add(new SelectOptionVO(value: '1', label: '서브테마'));

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {
    selectBox_themeType.clear();
    selectBox_themeType = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var form = Form(
      key: formKey,
      child: Wrap(
        children: <Widget>[
          Row(
            children: <Widget>[
              Flexible(
                flex: 1,
                child: ISSelect(
                    label: '테마유형',
                    value: _themeType,
                    dataList: selectBox_themeType,
                    onChange: (v) {
                      setState(() {
                        _themeType = v;
                        if (_themeType == '0')
                          _themeMainCd = '';

                        formKey.currentState.save();
                      });
                    }),
              ),
              Flexible(
                flex: 2,
                child: ISSelect(
                    ignoring: _themeType == '0' ? true : false,
                    label: '메인테마',
                    value: _themeMainCd,
                    dataList: widget.selectBox_mainTheme,
                    onChange: (v) {
                      setState(() {
                        _themeMainCd = v;
                        formKey.currentState.save();
                      });
                    }),
              ),
            ],
          ),
          ISInput(
            value: _themeName,
            autofocus: true,
            context: context,
            label: _themeType == '0' ? '메인테마명' : '서브테마명',
            // inputFormatters: <TextInputFormatter>[
            //   FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z0-9ㄱ-ㅎ가-힣$@!%*#?~^<>,.&+=]'))
            // ],
            onChange: (v) {
              _themeName = v;
            },
          ),
        ],
      ),
    );

    ButtonBar buttonBar = ButtonBar(
      alignment: MainAxisAlignment.center,
      children: <Widget>[
        ISButton(
          label: '저장',
          iconData: Icons.save,
          onPressed: () {
            FormState form = formKey.currentState;
            if (!form.validate()) {
              return;
            }

            if (_themeName == '' || _themeName == null) {
              ISAlert(context, '테마명을 확인해주세요.');
              return;
            }

            form.save();
            
            if (_themeType == '0'){
              ReservationController.to.postMainTheme(_themeName).then((value) {
                if (value != null){
                  ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                }
                else{
                  Navigator.pop(context, true);
                }
              });
            }
            else if (_themeType == '1'){
              if (_themeMainCd == '' || _themeMainCd == null){
                ISAlert(context, '메인테마를 선택해주세요.');
                return;
              }

              ReservationController.to.postSubTheme(_themeMainCd, _themeName).then((value) {
                if (value != null){
                  ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
                }
                else{
                  Navigator.pop(context, true);
                }
              });
            }

            // String visibleStr =  formData.visible == true ? 'Y' : 'N';
            //
            // if (formData.menuDepth == 0) {
            //   formData.pid = '';
            // }
            // else if (formData.menuDepth == 2){
            //   formData.icon = '';
            //   formData.url = '';
            // }
            //
            // if (formData.pid == null || formData.pid == 'null' || formData.pid == '') {
            //   if (formData.menuDepth == 1 || formData.menuDepth == 2){
            //     ISAlert(context, '상위메뉴를 선택해주세요.');
            //     return;
            //   }
            //
            //   formData.pid = '';
            // }
            //
            // //print('id:${formData.id}, pid:${formData.pid}, menuDepth:${formData.menuDepth}, name:${formData.name}, icon:${formData.icon}, url:${formData.url}, visibleStr:$visibleStr');
            //
            // AuthController.to.postMenuData(formData.pid, formData.menuDepth, formData.name, formData.icon, formData.url, visibleStr).then((value) {
            //   if (value != null){
            //     ISAlert(context, '정상처리가 되지 않았습니다. \n\n${value}');
            //   }
            //   else{
            //     Navigator.pop(context, true);
            //   }
            // });
          },
        ),
        ISButton(
          label: '취소',
          iconData: Icons.cancel,
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
    );

    var result = Scaffold(
      appBar: AppBar(
        title: Text('예약 테마 등록'),
      ),
      body: Column(
        children: [
          SizedBox(height: 10),
          Container(
              padding: EdgeInsets.symmetric(horizontal: 8.0),
              child: form
          ),
        ],
      ),
      bottomNavigationBar: buttonBar,
    );
    return SizedBox(
      width: 400,
      height: 250,
      child: result,
    );
  }
}
