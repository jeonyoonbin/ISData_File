import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/models/MenuManager/optionGroupListModel.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManagerController.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/optionLinkAdd.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class MenuOptionLink extends StatefulWidget {
  final String? menuCd;
  const MenuOptionLink({Key? key, this.menuCd})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return MenuOptionLinkState();
  }
}

class MenuOptionLinkState extends State<MenuOptionLink> {

  final List<OptionGroupListModel> dataList = <OptionGroupListModel>[];

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(MenuInfoController.to.getOptionLinkList(widget.menuCd!))
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataList.clear();

      value.forEach((element) {
        OptionGroupListModel temp = OptionGroupListModel();

        temp.menuOptGrpCd = element['menuOptGrpCd'] as String;
        temp.optGrpCd = element['optGrpCd'] as String;
        temp.optGrpName = element['optGrpName'] as String;
        temp.optNames = element['optNames'] as String;
        //temp.menuNames = element['menuNames'] as String;
        temp.minCount = element['minCount'] as String;
        temp.multiCount = element['multiCount'] as String;
        temp.multiYn = element['multiYn'] as String;
        // temp.useYn = element['useYn'] as String;
        // temp.reqYn = element['reqYn'] as String;

        dataList.add(temp);
      });
    }

    setState(() {});

    // var value = await showDialog(
    //     context: context,
    //     builder: (context) => FutureProgressDialog(MenuInfoController.to.getOptionLinkList(widget.menuCd!))
    // );
    //
    // if (value == null) {
    //   ISAlert(context, content: '정상조회가 되지 않았습니다. \n\n다시 시도해 주세요');
    //   //Navigator.of(context).pop;
    // }
    // else {
    //   dataList.clear();
    //
    //   value.forEach((element) {
    //     OptionLinkModel temp = OptionLinkModel();
    //     temp.selectYn = element['selectYn'] as String;
    //     temp.optGrpCd = element['optGrpCd'] as String;
    //     temp.optGrpName = element['optGrpName'] as String;
    //     temp.minCount = element['minCount'] as String;
    //     temp.multiCount = element['multiCount'] as String;
    //     temp.multiYn = element['multiYn'] as String;
    //     temp.optNames = element['optNames'] as String;
    //     dataList.add(temp);
    //   });
    // }
    //
    // setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    dataList.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(MenuInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 600),
      contentPadding: const EdgeInsets.symmetric(horizontal: 8),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('옵션 설정', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: Material(
        color: Colors.transparent,
        borderOnForeground: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //const Divider(color: Colors.grey, height: 0.0,),
              const SizedBox(height: 12,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('옵션 설정', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                    ISButton(
                        child: Row(
                          children: const [
                            Icon(Icons.add),
                            Text('옵션 그룹 추가')
                        ],
                        ),
                        onPressed: () {
                          _addOptionGroup();
                        }),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: dataList == null
                    ? const Text('Data is Empty')
                    : ReorderableListView(
                    onReorder: _onMenuOptionReorder,
                    scrollController: ScrollController(),
                    padding: const EdgeInsets.only(bottom: 8.0),
                    children: List.generate(dataList.length, (index) {
                      return Card(
                        key: Key('$index'),
                        color: Colors.white,
                        elevation: 1,
                        shape: appTheme.cardShapStyle,
                        margin: const EdgeInsets.all(4),
                        child: ListTile(
                          title: Text(dataList[index].optGrpName ?? '--', style: const TextStyle(fontSize: 14, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                          subtitle: Text(dataList[index].optNames ?? '--', style: const TextStyle(fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                          trailing: Padding(
                            padding: const EdgeInsets.only(right: 20),
                            child: OutlinedButton(
                              style: ButtonStyle(side: MaterialStateProperty.all(const BorderSide(color: Colors.red))),
                              onPressed: () {
                                _deleteMenuOptionGroup(widget.menuCd!, dataList[index].menuOptGrpCd!, dataList[index].optGrpName!);
                              },
                              child: const Text('해제', style: TextStyle(color: Colors.red),),
                            ),
                          ),
                        ),
                      );
                    })),
              )
            ],
          ),
        ),
      ),
      actions: null,
      // actions: [
      //   SizedBox(
      //     child: FilledButton(
      //       style: appTheme.popupButtonStyleLeft,
      //       onPressed: () {
      //         Navigator.pop(context);
      //       },
      //       child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
      //     ),
      //   ),
      //   SizedBox(
      //     child: FilledButton(
      //       style: appTheme.popupButtonStyleRight,
      //       onPressed: () {
      //
      //       },
      //       child: const Text('적용', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
      //     ),
      //   ),
      // ],
    );
  }

  void _onMenuOptionReorder(int oldIndex, int newIndex) async {
    try {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }

      final OptionGroupListModel item = dataList.removeAt(oldIndex);
      dataList.insert(newIndex, item);

      List<String> sortDataList = [];
      dataList.forEach((element) {
        sortDataList.add(element.menuOptGrpCd!);
      });
      _editListSort('2', sortDataList);

      setState(() {});
    } catch (e) {}
  }

  _editListSort(String div, List<String> sortDataList) async {
    String jsonData = jsonEncode(sortDataList);

    await MenuInfoController.to.updateListSort(div, jsonData);

    await Future.delayed(const Duration(milliseconds: 500), () {
      requestAPIData();
    });
  }

  _deleteMenuOptionGroup(String menuCd, String menuOptGrpCd, String optGrpName) {
    ISConfirm(context, '메뉴 연결 옵션 그룹 해제', '연결된 [${optGrpName}]옵션 그룹을 해제합니다. \n\n계속 진행하시겠습니까?', (context, isOK) async {
      Navigator.of(context).pop();

      if (isOK){
        var value = await showDialog(
            context: context,
            barrierColor: Colors.transparent,
            builder: (context) => FutureProgressDialog(MenuInfoController.to.deleteOptionLink(menuCd, menuOptGrpCd))
        );

        if (value == null) {
          ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
        }
        else {
          if (value == '00') {
            requestAPIData();
          }
          else{
            ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
          }
        }
      }
    });
  }

  _addOptionGroup() async {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => MenuOptionLinkAdd(menuCd: widget.menuCd),
    ).then((v) async {
      if (v != true) {
        await Future.delayed(const Duration(milliseconds: 500), () {
          requestAPIData();
        });
      }
    });
  }
}


