import 'dart:convert';

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/common/serverInfo.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/MenuManager/menuTopListEditModel.dart';
import 'package:daeguro_ceo_app/models/MenuManager/menuTopListInfoModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productListModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productTopMenuAdd.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuManagerController.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/topMenuAdd.dart';
import 'package:daeguro_ceo_app/theme.dart';

import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class TopMenuInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const TopMenuInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<TopMenuInfoMain> createState() => _TopMenuInfoMainState();
}

class _TopMenuInfoMainState extends State<TopMenuInfoMain> {

  final List<MenuTopListInfoModel> dataItemList = <MenuTopListInfoModel>[];

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(MenuInfoController.to.getTopMenuList())
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataItemList.clear();

      value.forEach((element) {
        MenuTopListInfoModel temp = MenuTopListInfoModel();

        temp.menuCd = element['menuCd'] as String;
        temp.menuName = element['menuName'] as String;
        temp.mMainYn = element['mMainYn'] as String;
        temp.fileName = element['fileName'] as String;
        temp.menuCost = element['menuCost'] as String;
        temp.useGbn = element['useGbn'] as String;
        temp.noFlag = element['noFlag'] as String;

        if(ServerInfo.jobMode == 'real')
          temp.fileName = temp.fileName.toString().replaceAll('https://image.daeguro.co.kr:40443/', '/');

        dataItemList.add(temp);
      });
    }

    setState(() {});
  }

  requestTopMenuRemove(String menuCd) async {

    MenuTopListEditModel sendData = MenuTopListEditModel();

    sendData.shopCd = AuthService.SHOPCD;
    sendData.mainYn = 'N';
    sendData.menuCd = menuCd;
    sendData.uCode = AuthService.uCode;
    sendData.uName = AuthService.uName;

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(MenuInfoController.to.removeTopMenu(sendData.toJson()))
    );

    if (value != '00') {
      ISAlert(context, content: '정상 등록되지 않았습니다.\n${value} \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      requestAPIData();
    }
  }

  @override
  void initState() {
    super.initState();

    Get.put(MenuInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    dataItemList.clear();
  }

  void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          if (AuthService.ShopServiceGbn != AuthService.SHOPGBN_FLOWER){
            requestAPIData();
          }
          else{
            router.go('/');
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
        elevation: 1,
        shape: appTheme.cardShapStyle,
        child: SingleChildScrollView(
          scrollDirection: Responsive.isMobile(context) ? Axis.horizontal : Axis.vertical,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('* 최대 6개까지 등록 가능합니다.', style: TextStyle(color: Colors.grey, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                  const SizedBox(width: 10,),
                ISButton(
                  child: const Text('대표 상품 추가'),
                  onPressed: () {
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => TopMenuAdd(topMenuCount: dataItemList.length),
                    ).then((v) async {
                      if (v == true) {
                        await Future.delayed(const Duration(milliseconds: 500), () {
                          requestAPIData();
                        });
                      }
                    });
                  },
                )
              ],
            ),
          ),
        ),
        ),
        //const SizedBox(height: 4),
        //const Divider(color: Colors.black,),//fluentUI.Divider(style: fluentUI.DividerThemeData(horizontalMargin: EdgeInsets.zero)),
        Expanded(child: itemListView()),

        const Divider(height: 1)
      ],
    );
  }

  Widget itemListView() {
    final appTheme = context.watch<AppTheme>();

    return SizedBox(
        height: widget.tabviewHeight! - 87,
        child: ListView.builder(
            shrinkWrap: true,
            padding: EdgeInsets.zero,
            itemBuilder: (ctx, index){
              return Card(
                key: Key('$index'),
                elevation: 1,
                shape: appTheme.cardShapStyle,
                margin: const EdgeInsets.all(4),
                //color: dataMenuList[index].selected == true ? const Color.fromRGBO(165, 216, 252, 1.0) : Colors.white,
                child: InkWell(
                  splashColor: const Color.fromRGBO(165, 216, 252, 1.0),
                  // onTap: () {
                  //   for (var element in dataItemList) {
                  //     element.selected = false;
                  //   }
                  //   // _menuGroupCd = dataGroupList[index].menuGroupCd;
                  //   //
                  //   // ShopController.to.MainCount.value = int.parse(dataGroupList[index].mainCount);
                  //   //
                  //   dataItemList[index].selected = true;
                  //   //
                  //   // loadMenuListData(dataGroupList[index].menuGroupCd, menuGroupName: dataGroupList[index].menuGroupName);
                  //   setState(() {});
                  // },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Responsive.isMobile(context)
                        ? Column(
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            const SizedBox(width: 8,),
                            Card(
                              color: Colors.grey.shade200,
                              clipBehavior: Clip.antiAlias,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6.0),),
                              //elevation: 4.0, //그림자 깊이
                              //margin: const EdgeInsets.all(4),
                              child: SizedBox(
                                width: 104,
                                height: 104,
                                child: dataItemList[index].fileName == null
                                    ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 104)
                                    : Image.network('${dataItemList[index].fileName!}?tm=${Utils.getTimeStamp()}', fit: BoxFit.fitWidth, gaplessPlayback: true,
                                  loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                    if (loadingProgress == null) return child;
                                    return const Center(
                                      child: CircularProgressIndicator(
                                        valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                      ),
                                    );
                                  },
                                  errorBuilder: (context, error, stackTrace) {
                                    return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 104);
                                  },
                                ),
                              ),
                            ),
                            const SizedBox(width: 8,),
                            Flexible(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Row(
                                      children: [
                                        dataItemList[index].useGbn == 'Y'
                                            ? Container(
                                            width: 36,
                                            height: 18,
                                            alignment: Alignment.center,
                                            decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                            child: const Center(
                                                child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                                ))
                                        ) : Container(
                                            width: 36,
                                            height: 18,
                                            alignment: Alignment.center,
                                            decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                            child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                        ),
                                        dataItemList[index].noFlag == 'Y'
                                            ? Container(
                                            width: 26,
                                            height: 18,
                                            margin: const EdgeInsets.only(left: 2.0),
                                            alignment: Alignment.center,
                                            decoration: AppTheme.getListBadgeDecoration(Colors.redAccent.shade100),
                                            child: const Center(child: Text('품절', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                        ) : const SizedBox.shrink(),
                                      ],
                                    ),
                                    const SizedBox(height: 5),
                                    Text(dataItemList[index].menuName ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                                    Text('${Utils.getCashComma(dataItemList[index].menuCost!)} 원', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                                    const SizedBox(height: 5),
                                    OutlinedButton(
                                      style: ButtonStyle(side: MaterialStateProperty.all(const BorderSide(color: Colors.red))),
                                      onPressed: () {
                                        ISConfirm(context, '대표 메뉴 해제', '해당 대표 메뉴를 해제하시겠습니까?', (context, isOK) async {
                                          Navigator.of(context).pop();

                                          if (isOK) {
                                            requestTopMenuRemove(dataItemList[index].menuCd!);
                                          }
                                        });
                                      },
                                      child: const Text('대표 메뉴 해제', style: TextStyle(color: Colors.red,fontSize: 13),),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                    ],
                    ) : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        const SizedBox(width: 8,),
                        Card(
                          color: Colors.grey.shade200,
                          clipBehavior: Clip.antiAlias,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6.0),),
                          //elevation: 4.0, //그림자 깊이
                          //margin: const EdgeInsets.all(4),
                          child: SizedBox(
                            width: 104,
                            height: 104,
                            child: dataItemList[index].fileName == null
                                ? const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 104)
                                : Image.network(
                              '${dataItemList[index].fileName!}?tm=${Utils.getTimeStamp()}',
                              fit: BoxFit.fitWidth,
                              gaplessPlayback: true,
                              loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                if (loadingProgress == null) return child;
                                return const Center(
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
                                  ),
                                );
                              },
                              errorBuilder: (context, error, stackTrace) {
                                return const Image(image: AssetImage('images/thumbnail-empty.png'), width: 104, height: 104);
                              },
                            ),
                          ),
                        ),
                        const SizedBox(width: 8,),
                        Flexible(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Row(
                                  children: [
                                    dataItemList[index].useGbn == 'Y'
                                        ? Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                        child: const Center(
                                            child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                            ))
                                    ) : Container(
                                        width: 36,
                                        height: 18,
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                        child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                    ),
                                    dataItemList[index].noFlag == 'Y'
                                        ? Container(
                                        width: 26,
                                        height: 18,
                                        margin: const EdgeInsets.only(left: 2.0),
                                        alignment: Alignment.center,
                                        decoration: AppTheme.getListBadgeDecoration(Colors.redAccent.shade100),
                                        child: const Center(child: Text('품절', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),))
                                    ) : const SizedBox.shrink(),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Text(dataItemList[index].menuName ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY),),
                                Text('${Utils.getCashComma(dataItemList[index].menuCost!)} 원', style: const TextStyle(fontSize: 14, fontFamily: FONT_FAMILY)),
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(0, 0, 30, 0),
                          child: OutlinedButton(
                            style: ButtonStyle(side: MaterialStateProperty.all(const BorderSide(color: Colors.red))),
                            onPressed: () {
                              ISConfirm(context, '대표 메뉴 해제', '해당 대표 메뉴를 해제하시겠습니까?', (context, isOK) async {
                                Navigator.of(context).pop();

                                if (isOK){
                                  requestTopMenuRemove(dataItemList[index].menuCd!);
                                }
                              });
                            },
                            child: const Text('대표 메뉴 해제', style: TextStyle(color: Colors.red),),
                          ),
                        ),
                        // Padding(
                        //     padding: const EdgeInsets.fromLTRB(0, 0, 30, 0),
                        //     child: IconButton(
                        //       icon: const Icon(Icons.more_horiz, size: 20),
                        //       color: Colors.black,
                        //       tooltip: '수정',
                        //       onPressed: () {
                        //         List<String> values = ['메뉴 수정', '옵션 설정', '메뉴 품절', '메뉴 삭제'];
                        //
                        //         ISOptionDialog(context, const BoxConstraints(maxWidth: 360.0, maxHeight: 290), dataItemList[index].name!, values, (context, selectIdx) async {
                        //           Navigator.of(context).pop();
                        //         });
                        //       },
                        //
                        //     )
                        // ),
                      ],
                    ),
                  ),
                ),
              );
            },
            itemCount: dataItemList.length
        )
    );
  }
}