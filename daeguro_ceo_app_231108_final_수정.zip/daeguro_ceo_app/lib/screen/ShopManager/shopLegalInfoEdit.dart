import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateInfoModel.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopLegalInfoEdit extends StatefulWidget {
  final ShopOperateInfoModel? sData;
  const ShopLegalInfoEdit({Key? key, this.sData})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopLegalInfoEditState();
  }
}

class ShopLegalInfoEditState extends State<ShopLegalInfoEdit> {
  ShopOperateInfoModel formData = ShopOperateInfoModel();

  @override
  void dispose() {
    super.dispose();
    formData = ShopOperateInfoModel();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    formData = widget.sData!;

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: buildContentDialog(context, appTheme),
    );
  }

  ContentDialog buildContentDialog(fluentUI.BuildContext context, AppTheme appTheme) {
    return ContentDialog(
        constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 725),
        contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            const Text('법적 고지 안내', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12,),
                ISLabelBarSub(
                  title: '법에 의한 인증 허가등을 받았음을 확인할 수 있는 경우 그에 대한 사항',
                  titleStyle: const TextStyle(color: Colors.black, fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                  titlePadding: const EdgeInsets.symmetric(horizontal: 20),
                  bodyPadding: const EdgeInsets.symmetric(vertical: 8),
                  body: ISInput(
                    value: formData.lAuth,
                    context: context,
                    height: 130,
                    //padding: 0,
                    label: '설명',
                    keyboardType: TextInputType.multiline,
                    maxLines: 8,
                    maxLength: 4000,
                    onChange: (v) {
                      formData.lAuth = v;
                    },
                  ),
                ),
                const SizedBox(height: 6),
                ISLabelBarSub(
                  title: 'A/S책임자와 전화번호 또는 소비자상담 관련 전화번호',
                  titleStyle: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                  bodyPadding: const EdgeInsets.symmetric(vertical: 8),
                  body: ISInput(
                    value: formData.lTel,
                    context: context,
                    height: 130,
                    //padding: 0,
                    label: '설명',
                    keyboardType: TextInputType.multiline,
                    maxLines: 8,
                    maxLength: 4000,
                    onChange: (v) {
                      formData.lTel = v;
                    },
                  ),
                ),
                const SizedBox(height: 6),
                ISLabelBarSub(
                  title: '판매자',
                  titleStyle: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                  bodyPadding: const EdgeInsets.symmetric(vertical: 8),
                  body: ISInput(
                    value: formData.lSeller,
                    context: context,
                    height: 130,
                    //padding: 0,
                    label: '설명',
                    keyboardType: TextInputType.multiline,
                    maxLines: 8,
                    maxLength: 4000,
                    onChange: (v) {
                      formData.lSeller = v;
                    },
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () async {
                ISConfirm(context, '법적 고지 안내 변경', '법적 고지 안내 정보를 변경합니다. \n\n계속 진행하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                  Navigator.of(context).pop();

                  if (isOK){
                    ShopOperateEditModel sendData = ShopOperateEditModel();
                    sendData.shopCd = AuthService.SHOPCD;
                    sendData.modUcode = AuthService.uCode;
                    sendData.modName = AuthService.uName;
                    sendData.jobGbn = '9';
                    sendData.lAuth = formData.lAuth;
                    sendData.lTel = formData.lTel;
                    sendData.lSeller = formData.lSeller;

                    var value = await showDialog(
                        context: context,
                        builder: (context) => FutureProgressDialog(ShopController.to.updateOperateInfo(sendData.toJson()))
                    );

                    if (value == '00') {
                      Navigator.of(context).pop(true);
                      ISAlert(context, title: '알림', content: '변경이 완료되었습니다.');
                    }
                    else {
                      ISAlert(context, content: '정상 등록되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
                    }
                  }
                });
              },
              child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      );
  }



}


