import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopInfoModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateEditModel.dart';
import 'package:daeguro_ceo_app/models/ShopManager/shopOperateInfoModel.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ShopReserveTimeEdit extends StatefulWidget {
  final ShopOperateInfoModel? sData;

  const ShopReserveTimeEdit({Key? key, this.sData})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ShopReserveTimeEditState();
  }
}

class ShopReserveTimeEditState extends State<ShopReserveTimeEdit> {
  ShopOperateInfoModel formData = ShopOperateInfoModel();

  List<String>? reserveHourItemList = <String>[];
  List<String>? reserveMinItemList = <String>[];

  List<String>? selectedReserveHourItemList = <String>[];
  List<String>? selectedReserveMinItemList = <String>[];


  @override
  void dispose() {
    super.dispose();

    formData = ShopOperateInfoModel();
    reserveHourItemList?.clear();
    selectedReserveHourItemList?.clear();
    reserveMinItemList?.clear();
    selectedReserveMinItemList?.clear();
  }

  @override
  void initState() {
    super.initState();

    Get.put(ShopController());

    reserveHourItemList = List.generate(12, (index) {
      return '${(index+1)}';
    });

    reserveMinItemList!.add('00');
    reserveMinItemList!.add('30');

    formData = widget.sData!;

    if (formData.reserveTerm != '' && formData.reserveTerm!.length == 4) {
      selectedReserveHourItemList!.add(int.parse(formData.reserveTerm!.substring(0, 2)).toString());
      selectedReserveMinItemList!.add(formData.reserveTerm!.substring(2, 4));
    }


    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 470),
      contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
      isFillActions: true,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 20),
          const Text('예약 가능 시간 안내', style: TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
          fluentUI.SmallIconButton(
            child: fluentUI.Tooltip(
              message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
              child: fluentUI.IconButton(
                icon: const Icon(fluentUI.FluentIcons.chrome_close),
                onPressed: Navigator.of(context).pop,
              ),
            ),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12,),
                ISLabelBarSub(
                  title: '예약 가능 시간 설정',
                  body: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('상점에서 배송할 수 있는 가장 빠른 시간을 설정해 주세요.', style: TextStyle(fontSize:12, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL)),
                      const SizedBox(height: 8,),
                      _SelectReserveHourView(),
                      const Divider(),
                      _SelectReserveMinView()
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
      actions: [
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleLeft,
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
        SizedBox(
          child: FilledButton(
            style: appTheme.popupButtonStyleRight,
            onPressed: () async {
              if (selectedReserveHourItemList!.isEmpty == true || selectedReserveMinItemList!.isEmpty == true){
                ISAlert(context, content: '설정된 시간을 확인해 주세요.');
                return;
              }

              ISConfirm(context, '결제 수단 변경', '결제 수단 정보를 변경합니다. \n\n계속 진행하시겠습니까?', constraints: const BoxConstraints(maxWidth: 380.0, maxHeight: 550), (context, isOK) async {
                Navigator.of(context).pop();

                if (isOK){
                  String sendStr = int.parse(selectedReserveHourItemList![0]) < 10 ? '0${selectedReserveHourItemList![0]}': selectedReserveHourItemList![0];
                  sendStr += selectedReserveMinItemList![0];

                  ShopOperateEditModel sendData = ShopOperateEditModel();
                  sendData.shopCd = AuthService.SHOPCD;
                  sendData.modUcode = AuthService.uCode;
                  sendData.modName = AuthService.uName;
                  sendData.jobGbn = '7';
                  sendData.reserveTerm = sendStr;

                  var value = await showDialog(
                      context: context,
                      builder: (context) => FutureProgressDialog(ShopController.to.updateOperateInfo(sendData.toJson()))
                  );

                  if (value == '00') {
                    Navigator.of(context).pop(true);
                    ISAlert(context, title: '알림', content: '변경이 완료되었습니다.');
                  }
                  else {
                    ISAlert(context, content: '정상 등록되지 않았습니다.\n[다시 시도해 주세요]\n→ ${value}');
                  }
                }
              });
            },
            child: const Text('변경', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
          ),
        ),
      ],
    );
  }

  Widget _SelectReserveHourView()
  {
    List<Widget> choices = [];

    if (reserveHourItemList != null){
      reserveHourItemList?.forEach((item) {
        choices.add(
            Container(
              padding: const EdgeInsets.all(4.0),
              child: ChoiceChip(
                  label: Text('${item.toString()}시간', style: const TextStyle(fontSize: 14, color: Colors.white,fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON),),
                  labelPadding: const EdgeInsets.symmetric(horizontal: 16.0),
                  shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(4.0))),
                  selectedColor: const Color(0xff01CAFF),
                  selected: selectedReserveHourItemList!.contains(item),
                  onSelected: (v) {
                    setState(() {
                      selectedReserveHourItemList!.clear();//단일선택용(주석처리시, 멀티선택 처리됨)
                      selectedReserveHourItemList!.contains(item) ? selectedReserveHourItemList!.remove(item) : selectedReserveHourItemList!.add(item);
                    });
                  }
              ),
            ));
      });
    }

    return Wrap(
      children: choices,
    );
  }

  Widget _SelectReserveMinView()
  {
    List<Widget> choices = [];

    if (reserveMinItemList != null){
      reserveMinItemList?.forEach((item) {
        choices.add(
            Container(
              padding: const EdgeInsets.all(4.0),
              child: ChoiceChip(
                  label: Text(item == '00' ? '1시간' : '30분', style: const TextStyle(fontSize: 14, color: Colors.white,fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY_NEXON),),
                  labelPadding: const EdgeInsets.symmetric(horizontal: 16.0),
                  shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(4.0))),
                  selectedColor: const Color(0xff01CAFF),
                  selected: selectedReserveMinItemList!.contains(item),
                  onSelected: (v) {
                    setState(() {
                      selectedReserveMinItemList!.clear();//단일선택용(주석처리시, 멀티선택 처리됨)
                      selectedReserveMinItemList!.contains(item) ? selectedReserveMinItemList!.remove(item) : selectedReserveMinItemList!.add(item);
                    });
                  }
              ),
            ));
      });
    }

    return Wrap(
      children: choices,
    );
  }
}


