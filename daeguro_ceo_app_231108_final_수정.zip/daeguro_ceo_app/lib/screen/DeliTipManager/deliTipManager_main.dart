

import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarMain.dart';
import 'package:daeguro_ceo_app/layout/layout_bottom.dart';
import 'package:daeguro_ceo_app/layout/layout_header.dart';
import 'package:daeguro_ceo_app/layout/responsive.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/deliTipCost_main.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/deliTipSector_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopHolidayInfoMain.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopInfo_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopOperateInfo_main.dart';
import 'package:daeguro_ceo_app/screen/ShopManager/shopRegistInfo_main.dart';
import 'package:daeguro_ceo_app/widgets/page.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';

class DelipTipManagerMain extends StatefulWidget {
  const DelipTipManagerMain({Key? key}) : super(key: key);

  @override
  State<DelipTipManagerMain> createState() => _DelipTipManagerMainState();
}

class _DelipTipManagerMainState extends State<DelipTipManagerMain> with PageMixin{
  //final ScrollController _scrollController = ScrollController();
  List<Tab> currTabs = AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET
      ?
  <Tab>[
    const Tab(height: 60, text: '     배달팁 설정     '),
  ]
      :
  <Tab>[
    const Tab(height: 60, text: '     배달 지역     '),
    const Tab(height: 60, text: '     배달팁 설정     '),
  ];


  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((c) {
    });
  }

  @override
  void dispose() {
    //_scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    return fluentUI.ScaffoldPage.withPadding(
      resizeToAvoidBottomInset: false,
      //scrollController: _scrollController,

      header: const LayoutHeader(),
      bottomBar: const LayoutBottom(),
      content: SizedBox(
        height: MediaQuery.of(context).size.height - (Responsive.isMobile(context) == true ? 280 : 330),//1000,//560,
        child: DefaultTabController(
          initialIndex: 0,
          length: currTabs.length,
          child: Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              elevation: 0.0,
              backgroundColor: Colors.transparent,
              title: TabBar(
                indicatorColor: Colors.black,
                labelStyle: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),
                unselectedLabelStyle: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
                indicatorPadding: EdgeInsets.only(bottom: 15),
                indicatorWeight: 2,
                indicatorSize: TabBarIndicatorSize.label,
                labelColor: Colors.black,
                isScrollable: true,
                padding: const EdgeInsets.all(0),
                labelPadding: const EdgeInsets.all(0),
                tabs: currTabs,
              ),
            ),
            body: Padding(
              padding: EdgeInsets.only(top: 22),
              child: TabBarView(
                physics: NeverScrollableScrollPhysics(),
                children:
                AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET
                    ?
                <Widget>[
                  DeliTipCostMain(),
                ]
                    :
                <Widget>[
                  DeliTipSectorMain(),
                  DeliTipCostMain(),
                ]
              ),
            ),
          ),
        ),
      ),
    );
  }

  requestAPIData() async {
  }
}