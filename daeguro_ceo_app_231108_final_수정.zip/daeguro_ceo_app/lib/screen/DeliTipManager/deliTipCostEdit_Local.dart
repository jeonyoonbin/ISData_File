import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_labelBarSub.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipAmtAreaModel.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipAmtEditModel.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipAmtListModel.dart';
import 'package:daeguro_ceo_app/models/DeliTipManager/deliTipSectorEditModel.dart';
import 'package:daeguro_ceo_app/screen/DeliTipManager/delitipController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class DeliTipCost_LocalEdit extends StatefulWidget {
  final String? jobGbn;
  final String? tipAmt;
  final List<String?> selectDong;
  final List<DeliTipAmtListModel>? sData;
  final List<String?>? otherPriceSelectDong;


  const DeliTipCost_LocalEdit({Key? key, this.jobGbn, required this.selectDong, this.tipAmt, this.sData, this.otherPriceSelectDong}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return DeliTipCost_LocalEditState();
  }
}

class DeliTipCost_LocalEditState extends State<DeliTipCost_LocalEdit> {

  List<String>? originalDongList_DongGu = [];
  List<String>? originalDongList_SeogGu = [];
  List<String>? originalDongList_NamGu = [];
  List<String>? originalDongList_BukGu = [];
  List<String>? originalDongList_JungGu = [];
  List<String>? originalDongList_DalseoGu = [];
  List<String>? originalDongList_SuseongGu = [];
  List<String>? originalDongList_DalseongGun = [];

  List<String>? selectedDongList_DongGu = [];
  List<String>? selectedDongList_SeogGu = [];
  List<String>? selectedDongList_NamGu = [];
  List<String>? selectedDongList_BukGu = [];
  List<String>? selectedDongList_JungGu = [];
  List<String>? selectedDongList_DalseoGu = [];
  List<String>? selectedDongList_SuseongGu = [];
  List<String>? selectedDongList_DalseongGun = [];

  bool allSelectDongGu = false;
  bool allSelectSeogGu = false;
  bool allSelectNamGu = false;
  bool allSelectBukGu = false;
  bool allSelectJungGu = false;
  bool allSelectDalseoGu = false;
  bool allSelectSuseongGu = false;
  bool allSelectDalseongGun = false;

  String? inputTipAmt = '0';

  String? sendValiText;

  // requestAPIData() async {
  //   setState(() {});
  // }

  requestAPI_SetData(DeliTipAmtEditModel sendData) async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(DeliTipController.to.setShopTipAmt(sendData.toJson()))
    );

    if (value == null) {
      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요');
    }
    else {
      if (value == '00') {
      }
      else{
        ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
      }
    }
  }

  loadSidoGunguData({required List<String?> selectDong}) async {

    originalDongList_DongGu?.clear();
    originalDongList_SeogGu?.clear();
    originalDongList_NamGu?.clear();
    originalDongList_BukGu?.clear();
    originalDongList_JungGu?.clear();
    originalDongList_DalseoGu?.clear();
    originalDongList_SuseongGu?.clear();
    originalDongList_DalseongGun?.clear();

    selectedDongList_DongGu?.clear();
    selectedDongList_SeogGu?.clear();
    selectedDongList_NamGu?.clear();
    selectedDongList_BukGu?.clear();
    selectedDongList_JungGu?.clear();
    selectedDongList_DalseoGu?.clear();
    selectedDongList_SuseongGu?.clear();
    selectedDongList_DalseongGun?.clear();

    allSelectDongGu = false;
    allSelectSeogGu = false;
    allSelectNamGu = false;
    allSelectBukGu = false;
    allSelectJungGu = false;
    allSelectDalseoGu = false;
    allSelectSuseongGu = false;
    allSelectDalseongGun = false;

    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(DeliTipController.to.getDeliTipSectorList())
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      List<String> deliverAreaGungu = [];
      List<DeliTipAmtAreaModel> tempList = [];
      value.forEach((element) {
        DeliTipAmtAreaModel tempData = DeliTipAmtAreaModel();
        tempData.gungu = element['gunguName'] as String;
        tempData.dong = element['dongName'] as String;

        tempList.add(tempData);

        int result = deliverAreaGungu.indexWhere((element) => element == tempData.gungu);

        if (result == -1) {
          deliverAreaGungu.add(tempData.gungu!);
        }
      });

      for (var gunguItem in deliverAreaGungu) {
        for (var element in tempList) {
          if (gunguItem == element.gungu){
            if (gunguItem == '동구')        {         originalDongList_DongGu!.add(element.dong!);            }
            else if (gunguItem == '서구')   {         originalDongList_SeogGu!.add(element.dong!);            }
            else if (gunguItem == '남구')   {         originalDongList_NamGu!.add(element.dong!);             }
            else if (gunguItem == '북구')   {         originalDongList_BukGu!.add(element.dong!);             }
            else if (gunguItem == '중구')   {         originalDongList_JungGu!.add(element.dong!);            }
            else if (gunguItem == '달서구') {         originalDongList_DalseoGu!.add(element.dong!);          }
            else if (gunguItem == '수성구') {         originalDongList_SuseongGu!.add(element.dong!);         }
            else if (gunguItem == '달성군') {         originalDongList_DalseongGun!.add(element.dong!);       }

            if (widget.otherPriceSelectDong != null) {
              originalDongList_DongGu!.removeWhere((item) => widget.otherPriceSelectDong!.contains(item));
              originalDongList_SeogGu!.removeWhere((item) => widget.otherPriceSelectDong!.contains(item));
              originalDongList_NamGu!.removeWhere((item) => widget.otherPriceSelectDong!.contains(item));
              originalDongList_BukGu!.removeWhere((item) => widget.otherPriceSelectDong!.contains(item));
              originalDongList_JungGu!.removeWhere((item) => widget.otherPriceSelectDong!.contains(item));
              originalDongList_DalseoGu!.removeWhere((item) => widget.otherPriceSelectDong!.contains(item));
              originalDongList_SuseongGu!.removeWhere((item) => widget.otherPriceSelectDong!.contains(item));
              originalDongList_DalseongGun!.removeWhere((item) => widget.otherPriceSelectDong!.contains(item));
            }

            if (selectDong != []){
              var result = selectDong.indexWhere((v) => v == element.dong);
              if (result != -1){
                if (widget.jobGbn != '1') {
                  if (gunguItem == '동구')        {selectedDongList_DongGu!.add(element.dong!);     }
                  else if (gunguItem == '서구')   {selectedDongList_SeogGu!.add(element.dong!);     }
                  else if (gunguItem == '남구')   {selectedDongList_NamGu!.add(element.dong!);      }
                  else if (gunguItem == '북구')   {selectedDongList_BukGu!.add(element.dong!);      }
                  else if (gunguItem == '중구')   {selectedDongList_JungGu!.add(element.dong!);     }
                  else if (gunguItem == '달서구') {selectedDongList_DalseoGu!.add(element.dong!);   }
                  else if (gunguItem == '수성구') {selectedDongList_SuseongGu!.add(element.dong!);  }
                  else if (gunguItem == '달성군') {selectedDongList_DalseongGun!.add(element.dong!);}
                } else {
                  if (gunguItem == '동구') {
                    originalDongList_DongGu!.remove(element.dong!);
                  } else if (gunguItem == '서구') {
                    originalDongList_SeogGu!.remove(element.dong!);
                  } else if (gunguItem == '남구') {
                    originalDongList_NamGu!.remove(element.dong!);
                  } else if (gunguItem == '북구') {
                    originalDongList_BukGu!.remove(element.dong!);
                  } else if (gunguItem == '중구') {
                    originalDongList_JungGu!.remove(element.dong!);
                  } else if (gunguItem == '달서구') {
                    originalDongList_DalseoGu!.remove(element.dong!);
                  } else if (gunguItem == '수성구') {
                    originalDongList_SuseongGu!.remove(element.dong!);
                  } else if (gunguItem == '달성군') {
                    originalDongList_DalseongGun!.remove(element.dong!);
                  }
                }
              }
            }
          }
        }
      }

      allSelectDongGu = originalDongList_DongGu!.length == selectedDongList_DongGu!.length ? true : false;
      allSelectSeogGu = originalDongList_SeogGu!.length == selectedDongList_SeogGu!.length ? true : false;
      allSelectNamGu = originalDongList_NamGu!.length == selectedDongList_NamGu!.length ? true : false;
      allSelectBukGu = originalDongList_BukGu!.length == selectedDongList_BukGu!.length ? true : false;
      allSelectJungGu = originalDongList_JungGu!.length == selectedDongList_JungGu!.length ? true : false;
      allSelectDalseoGu = originalDongList_DalseoGu!.length == selectedDongList_DalseoGu!.length ? true : false;
      allSelectSuseongGu = originalDongList_SuseongGu!.length == selectedDongList_SuseongGu!.length ? true : false;
      allSelectDalseongGun = originalDongList_DalseongGun!.length == selectedDongList_DalseongGun!.length ? true : false;

      setState(() {});
    }
  }

  @override
  void dispose() {
    super.dispose();
    originalDongList_DongGu?.clear();
    originalDongList_SeogGu?.clear();
    originalDongList_NamGu?.clear();
    originalDongList_BukGu?.clear();
    originalDongList_JungGu?.clear();
    originalDongList_DalseoGu?.clear();
    originalDongList_SuseongGu?.clear();
    originalDongList_DalseongGun?.clear();
    selectedDongList_DongGu?.clear();
    selectedDongList_SeogGu?.clear();
    selectedDongList_NamGu?.clear();
    selectedDongList_BukGu?.clear();
    selectedDongList_JungGu?.clear();
    selectedDongList_DalseoGu?.clear();
    selectedDongList_SuseongGu?.clear();
    selectedDongList_DalseongGun?.clear();

    Get.put(DeliTipController()).deliTipError?.value = '';
  }

  @override
  void initState() {
    super.initState();

    Get.put(DeliTipController());

    if (widget.jobGbn == '1') {

    }
    else{
      inputTipAmt = widget.tipAmt;
    }

    WidgetsBinding.instance.addPostFrameCallback((c) {
      loadSidoGunguData(selectDong: widget.selectDong);
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 460.0, maxHeight: 720),
        contentPadding: const EdgeInsets.all(0.0),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            Text(widget.jobGbn == '1' ? '주문 지역별 배달팁 추가' : '주문 지역별 배달팁 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Material(
            color: Colors.transparent,
            borderOnForeground: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ISLabelBarSub(
                    title: '배달팁',
                    body: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Material(
                          color: Colors.transparent,
                          child: ISInput(
                            value: Utils.getCashComma(inputTipAmt!),
                            textAlign: TextAlign.end,
                            width: 200,
                            label: '금액',
                            // keyboardType: TextInputType.number,
                            // inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                              TextInputFormatter.withFunction(
                                    (oldValue, newValue) {
                                  if (newValue.text.isEmpty) {
                                    return newValue;
                                  }
                                  try {
                                    final parsedValue = int.parse(newValue.text);
                                    if (parsedValue <= 999900) {
                                      final formattedValue = Utils.getCashComma(parsedValue.toString());

                                      // 커서 위치 계산
                                      final cursorPosition = newValue.selection.baseOffset;
                                      final newCursorPosition = cursorPosition + (formattedValue.length - newValue.text.length);

                                      return TextEditingValue(
                                        text: formattedValue,
                                        selection: TextSelection.collapsed(offset: newCursorPosition),
                                      );
                                    }
                                  } catch (_) {}
                                  return oldValue;
                                },
                              ),
                            ],
                            onChange: (v) {
                                inputTipAmt = v.toString().replaceAll(',', '');

                                try{
                                  if(int.parse(v!.toString().replaceAll(',', '')) % 100 != 0){
                                    Get.put(DeliTipController()).deliTipError?.value = '100원 단위 이상의 금액만 입력 가능합니다.' ;
                                  }
                                  else{
                                    Get.put(DeliTipController()).deliTipError?.value = '';
                                  }
                                }
                                catch(_){
                                  Get.put(DeliTipController()).deliTipError?.value = '';
                                }
                            },
                            validator: (v){
                              return sendValiText;
                            },
                          ),
                        ),
                        const SizedBox(width: 8,),
                        const Text('원', style: TextStyle(fontSize: 16, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10, left: 16),
                    child: Obx(() {
                      if(Get.find<DeliTipController>().deliTipError!.value != ''){
                        sendValiText = Get.find<DeliTipController>().deliTipError!.value;
                        return Text(sendValiText!, style: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: Colors.redAccent));
                      }
                      else {
                        sendValiText = null;
                        return Container();
                      }
                    }),
                  ),
                  const Divider(height: 1),

                  ISLabelBarSub(
                    title: '배달 지역 선택',
                    body: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        if (originalDongList_DongGu!.isNotEmpty) ...[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                '동구',
                                style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                              ),
                              ISCheckbox(
                                label: '전체 선택',
                                value: allSelectDongGu,
                                onChanged: (v) {
                                  setState(() {
                                    allSelectDongGu = v;
                                    selectedDongList_DongGu!.clear();
                                    if (v == true) {
                                      selectedDongList_DongGu!.addAll(originalDongList_DongGu!);
                                    }
                                  });
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _DongMultiSelectView('동구', originalDongList_DongGu, selectedDongList_DongGu),
                          const SizedBox(height: 16),
                        ],
                        if (originalDongList_SeogGu!.isNotEmpty) ...[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                '서구',
                                style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                              ),
                              ISCheckbox(
                                label: '전체 선택',
                                value: allSelectSeogGu,
                                onChanged: (v) {
                                  setState(() {
                                    allSelectSeogGu = v;
                                    selectedDongList_SeogGu!.clear();
                                    if (v == true) {
                                      selectedDongList_SeogGu!.addAll(originalDongList_SeogGu!);
                                    }
                                  });
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _DongMultiSelectView('서구', originalDongList_SeogGu, selectedDongList_SeogGu),
                          const SizedBox(height: 16),
                        ],
                        if (originalDongList_NamGu!.isNotEmpty) ...[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                '남구',
                                style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                              ),
                              ISCheckbox(
                                label: '전체 선택',
                                value: allSelectNamGu,
                                onChanged: (v) {
                                  setState(() {
                                    allSelectNamGu = v;
                                    selectedDongList_NamGu!.clear();
                                    if (v == true) {
                                      selectedDongList_NamGu!.addAll(originalDongList_NamGu!);
                                    }
                                  });
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _DongMultiSelectView('남구', originalDongList_NamGu, selectedDongList_NamGu),
                          const SizedBox(height: 16),
                        ],
                        if (originalDongList_BukGu!.isNotEmpty) ...[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                '북구',
                                style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                              ),
                              ISCheckbox(
                                label: '전체 선택',
                                value: allSelectBukGu,
                                onChanged: (v) {
                                  setState(() {
                                    allSelectBukGu = v;
                                    selectedDongList_BukGu!.clear();
                                    if (v == true) {
                                      selectedDongList_BukGu!.addAll(originalDongList_BukGu!);
                                    }
                                  });
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _DongMultiSelectView('북구', originalDongList_BukGu, selectedDongList_BukGu),
                          const SizedBox(height: 16),
                        ],
                        if (originalDongList_JungGu!.isNotEmpty) ...[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                '중구',
                                style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                              ),
                              ISCheckbox(
                                label: '전체 선택',
                                value: allSelectJungGu,
                                onChanged: (v) {
                                  setState(() {
                                    allSelectJungGu = v;
                                    selectedDongList_JungGu!.clear();
                                    if (v == true) {
                                      selectedDongList_JungGu!.addAll(originalDongList_JungGu!);
                                    }
                                  });
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _DongMultiSelectView('중구', originalDongList_JungGu, selectedDongList_JungGu),
                          const SizedBox(height: 16),
                        ],
                        if (originalDongList_DalseoGu!.isNotEmpty) ...[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                '달서구',
                                style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                              ),
                              ISCheckbox(
                                label: '전체 선택',
                                value: allSelectDalseoGu,
                                onChanged: (v) {
                                  setState(() {
                                    allSelectDalseoGu = v;
                                    selectedDongList_DalseoGu!.clear();
                                    if (v == true) {
                                      selectedDongList_DalseoGu!.addAll(originalDongList_DalseoGu!);
                                    }
                                  });
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _DongMultiSelectView('달서구', originalDongList_DalseoGu, selectedDongList_DalseoGu),
                          const SizedBox(height: 16),
                        ],
                        if (originalDongList_SuseongGu!.isNotEmpty) ...[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                '수성구',
                                style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                              ),
                              ISCheckbox(
                                label: '전체 선택',
                                value: allSelectSuseongGu,
                                onChanged: (v) {
                                  setState(() {
                                    allSelectSuseongGu = v;
                                    selectedDongList_SuseongGu!.clear();
                                    if (v == true) {
                                      selectedDongList_SuseongGu!.addAll(originalDongList_SuseongGu!);
                                    }
                                  });
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _DongMultiSelectView('수성구', originalDongList_SuseongGu, selectedDongList_SuseongGu),
                          const SizedBox(height: 16),
                        ],
                        if (originalDongList_DalseongGun!.isNotEmpty) ...[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                '달성군',
                                style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),
                              ),
                              ISCheckbox(
                                label: '전체 선택',
                                value: allSelectDalseongGun,
                                onChanged: (v) {
                                  setState(() {
                                    allSelectDalseongGun = v;
                                    selectedDongList_DalseongGun!.clear();
                                    if (v == true) {
                                      selectedDongList_DalseongGun!.addAll(originalDongList_DalseongGun!);
                                    }
                                  });
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _DongMultiSelectView('달성군', originalDongList_DalseongGun, selectedDongList_DalseongGun),
                          const SizedBox(height: 16),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () async {
              if (inputTipAmt == '' || sendValiText != null) {
                  ISAlert(context, content: '배달팁을 확인해 주세요.');
                  return;
                }

                List<String> retValue = getSelectedDongList();

                if (retValue == null || retValue.isEmpty) {
                  ISAlert(context, content: '배달 지역을 선택해 주세요.');
                  return;
                }

                DeliTipAmtEditModel sendData = DeliTipAmtEditModel();
                sendData.shopCd = AuthService.SHOPCD;

                if (widget.jobGbn == '1') {
                  await setData(retValue, sendData);
                } else {
                  // 기존값 삭제 부분
                  for (int i = 0; i < widget.selectDong.length; i += 11) {
                    int end = (i + 11 < widget.selectDong.length) ? i + 11 : widget.selectDong.length;
                    List<String> sendjobGbn = [];
                    List<String> sendtipSeq = [];
                    List<String> sendtipGbn = [];
                    List<String> sendtipDay = [];
                    List<String> sendtipFrStand = [];
                    List<String> sendtipToStand = [];
                    List<String> sendtipAmt = [];

                    for (int j = i; j < end; j++) {
                      String retSeq = _getDongCompareData(widget.selectDong[j]!);
                      sendjobGbn.add('D');
                      sendtipSeq.add(retSeq);
                      sendtipGbn.add('9');
                      sendtipDay.add('1');
                      sendtipFrStand.add(widget.selectDong[j]!);
                      sendtipToStand.add('0');
                      sendtipAmt.add(inputTipAmt!);
                    }
                    sendData.jobGbn = sendjobGbn;
                    sendData.tipSeq = sendtipSeq;
                    sendData.tipGbn = sendtipGbn;
                    sendData.tipDay = sendtipDay;
                    sendData.tipFrStand = sendtipFrStand;
                    sendData.tipToStand = sendtipToStand;
                    sendData.tipAmt = sendtipAmt;

                    sendData.uCode = AuthService.uCode;
                    sendData.uName = AuthService.uName;

                    await DeliTipController.to.setShopTipAmt(sendData.toJson());

                    sendjobGbn.clear();
                    sendtipSeq.clear();
                    sendtipGbn.clear();
                    sendtipDay.clear();
                    sendtipFrStand.clear();
                    sendtipToStand.clear();
                    sendtipAmt.clear();
                  }

                  sendData = DeliTipAmtEditModel();
                  sendData.shopCd = AuthService.SHOPCD;

                  await setData(retValue, sendData);
                }
                Navigator.of(context).pop(true);
              },
              child: Text(widget.jobGbn == '1' ? '등록' : '적용', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> setData(List<String> retValue, DeliTipAmtEditModel sendData) async {
    for (int i = 0; i < retValue.length; i += 11) {
      int end = (i + 11 < retValue.length) ? i + 11 : retValue.length;

      List<String> sendjobGbn = [];
      List<String> sendtipSeq = [];
      List<String> sendtipGbn = [];
      List<String> sendtipDay = [];
      List<String> sendtipFrStand = [];
      List<String> sendtipToStand = [];
      List<String> sendtipAmt = [];

      for (int j = i; j < end; j++) {
        sendjobGbn.add('I');
        sendtipSeq.add('');
        sendtipGbn.add('9');
        sendtipDay.add('1');
        sendtipFrStand.add(retValue[j]);
        sendtipToStand.add('0');
        sendtipAmt.add(inputTipAmt!);
      }

      sendData.jobGbn = sendjobGbn;
      sendData.tipSeq = sendtipSeq;
      sendData.tipGbn = sendtipGbn;
      sendData.tipDay = sendtipDay;
      sendData.tipFrStand = sendtipFrStand;
      sendData.tipToStand = sendtipToStand;
      sendData.tipAmt = sendtipAmt;

      sendData.uCode = AuthService.uCode;
      sendData.uName = AuthService.uName;

      await requestAPI_SetData(sendData);
    }
  }

  List<String> getSelectedDongList() {
    List<String> temp = [];
    for (var element in selectedDongList_DongGu!) {
      temp.add(element);
    }
    for (var element in selectedDongList_SeogGu!) {
      temp.add(element);
    }
    for (var element in selectedDongList_NamGu!) {
      temp.add(element);
    }
    for (var element in selectedDongList_BukGu!) {
      temp.add(element);
    }
    for (var element in selectedDongList_JungGu!) {
      temp.add(element);
    }
    for (var element in selectedDongList_DalseoGu!) {
      temp.add(element);
    }
    for (var element in selectedDongList_SuseongGu!) {
      temp.add(element);
    }
    for (var element in selectedDongList_DalseongGun!) {
      temp.add(element);
    }

    return temp;
  }

  String _getDongCompareData(String dongName) {
    String retSeq = '';

    for (final element in widget.sData!) {
      if (element.tipFrStand == dongName) {
        retSeq = element.tipSeq!;
        break;
      }
    }
    return retSeq;
  }

  Widget _DongMultiSelectView(String gungu, List<String>? tempList, List<String>? tempSelectedList) {
    List<Widget> choices = [];

    if (tempList != null) {
      tempList?.forEach((item) {
        choices.add(Padding(
          padding: const EdgeInsets.all(4.0),
          child: ChoiceChip(
              label: Text(
                item,
                style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY),
              ),
              shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(4.0))),
              selectedColor: const Color(0xff01CAFF),
              selected: tempSelectedList!.contains(item),
              onSelected: (v) {
                setState(() {
                  tempSelectedList!.contains(item) ? tempSelectedList.remove(item) : tempSelectedList.add(item);
                  allSelectDongGu = originalDongList_DongGu!.length == selectedDongList_DongGu!.length ? true : false;
                  allSelectSeogGu = originalDongList_SeogGu!.length == selectedDongList_SeogGu!.length ? true : false;
                  allSelectNamGu = originalDongList_NamGu!.length == selectedDongList_NamGu!.length ? true : false;
                  allSelectBukGu = originalDongList_BukGu!.length == selectedDongList_BukGu!.length ? true : false;
                  allSelectJungGu = originalDongList_JungGu!.length == selectedDongList_JungGu!.length ? true : false;
                  allSelectDalseoGu = originalDongList_DalseoGu!.length == selectedDongList_DalseoGu!.length ? true : false;
                  allSelectSuseongGu = originalDongList_SuseongGu!.length == selectedDongList_SuseongGu!.length ? true : false;
                  allSelectDalseongGun = originalDongList_DalseongGun!.length == selectedDongList_DalseongGun!.length ? true : false;
                });
              }),
        ));
      });
    }

    return Wrap(
      children: choices,
    );
  }
}
