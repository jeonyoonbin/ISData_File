import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/flutter_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/datepicker/multiple_view_date_range_picker.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_checkbox.dart';
import 'package:daeguro_ceo_app/iswidgets/is_dialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_input.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_date.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_search_dropdown.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productListEditModel.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productListModel.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:date_format/date_format.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductListEdit extends StatefulWidget {
  final ProductListModel? sData;
  final String? catCode;
  final String? classGbn;

  const ProductListEdit({Key? key, this.sData, this.catCode, this.classGbn}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return ProductListEditState();
  }
}

enum RadioDiscGbn { discGbnPercent, discGbnComment }
enum RadioUseGbn { useGbnY, useGbnN }
enum RadioNoFlagGbn { noflagGbnY, noflagGbnN }
enum RadioMainGbn { mainGbnY, mainGbnN }

class ProductListEditState extends State<ProductListEdit> {
  ProductListEditModel formData = ProductListEditModel();

  String? startdate = '';
  String? enddate = '';

  RadioDiscGbn? _radioDiscGbn;
  RadioUseGbn? _radioUseGbn;
  RadioMainGbn? _radioMainGbn;
  RadioNoFlagGbn? _radioNoFlagGbn;

  bool checkState_AlwaysDiscount = true;

  List<ISOptionModel> selectBox_Category = [];
  List<ISOptionModel> selectBox_Theme = [];
  List<ISOptionModel> selectBox_ProdGroup = [];

  List<String> selectCategoryCodeList = [];
  List<String> selectThemeCodeList = [];
  List<String> selectProdGroupCodeList = [];

  requestAPIGroupNameData() async {
    await ProductInfoController.to.getTypeListV2('C', 'FLOWER',AuthService.SHOPCD).then((value) {
      if (value == null) {
        ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      }
      else {
        selectBox_Category.clear();
        
        value.forEach((element) {
          selectBox_Category.add(ISOptionModel(value: element['cat_code'].toString(), label: element['name'].toString()));
        });

        if (widget.sData != null){
          List<String> tempArr = widget.sData!.catCodes!.split(',');
          if (tempArr.isEmpty){
          }
          else{
            selectCategoryCodeList!.clear();
            for (var element in tempArr) {
              if (_getCompareListData(element, selectBox_Category)){
                selectCategoryCodeList!.add(element);
              }
            }
          }
        }
      }
    });

    await ProductInfoController.to.getTypeListV2('T', 'FLOWER',AuthService.SHOPCD).then((value) {
      if (value == null) {
        ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      }
      else {
        selectBox_Theme.clear();

        value.forEach((element) {
          selectBox_Theme.add(ISOptionModel(value: element['thema_code'].toString(), label: element['name'].toString()));
        });

        if (widget.sData != null){
          List<String> tempArr = widget.sData!.themCodes!.split(',');
          if (tempArr.isEmpty){
          }
          else{
            selectThemeCodeList!.clear();
            for (var element in tempArr) {
              if (_getCompareListData(element, selectBox_Theme)){
                selectThemeCodeList!.add(element);
              }
            }
          }
        }

      }
    });
    setState(() {});
  }

  requestAPIMarketGroupNameData() async {
    await ProductInfoController.to.getTypeListV2('C', 'BUNDLE', AuthService.SHOPCD).then((value) {
      if (value == null) {
        ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      }
      else {
        selectBox_Category.clear();

        value.forEach((element) {
          selectBox_Category.add(ISOptionModel(value: element['cat_code'].toString(), label: element['name'].toString()));
        });

        if (widget.sData != null){
          List<String> tempArr = widget.sData!.catCodes!.split(',');
          if (tempArr.isEmpty){
          }
          else{
            selectCategoryCodeList!.clear();
            for (var element in tempArr) {
              if (_getCompareListData(element, selectBox_Category)){
                selectCategoryCodeList!.add(element);
              }
            }
          }
        }
      }
    });

    setState(() {});
  }

  requestAPIElectMarketGroupNameData() async {
    await ProductInfoController.to.getTypeListV2('C', 'ELECTRIC',AuthService.SHOPCD).then((value) {
      if (value == null) {
        ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      }
      else {
        selectBox_Category.clear();

        value.forEach((element) {
          selectBox_Category.add(ISOptionModel(value: element['cat_code'].toString(), label: element['name'].toString()));
        });

        if (widget.sData != null){
          List<String> tempArr = widget.sData!.catCodes!.split(',');
          if (tempArr.isEmpty){
          }
          else{
            selectCategoryCodeList!.clear();
            for (var element in tempArr) {
              if (_getCompareListData(element, selectBox_Category)){
                selectCategoryCodeList!.add(element);
              }
            }
          }
        }
      }
    });

    await ProductInfoController.to.getTypeListV2('G', 'ELECTRIC',AuthService.SHOPCD).then((value) {
      if (value == null) {
        ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      }
      else {
        selectBox_ProdGroup.clear();

        value.forEach((element) {
          selectBox_ProdGroup.add(ISOptionModel(value: element['grpCode'].toString(), label: element['name'].toString()));
        });

        if (widget.sData != null){
          String temp = widget.sData!.prodGrpCodes!;
          if (temp == null){
          }
          else{
            selectProdGroupCodeList!.clear();
              if (_getCompareListData(temp, selectBox_ProdGroup)){
                selectProdGroupCodeList!.add(temp);
            }
          }
        }

      }
    });
    setState(() {});
  }

  bool _getCompareListData(String item, List<ISOptionModel> resList){
    bool temp = false;

    for (final element in resList!){
      if (element.value == item) {
        temp = true;
        break;
      }
    }
    return temp;
  }

  @override
  void dispose() {
    super.dispose();
    formData = ProductListEditModel();
    selectBox_Category.clear();
    selectBox_Theme.clear();
    selectBox_ProdGroup.clear();
    selectCategoryCodeList.clear();
    selectThemeCodeList.clear();
    selectProdGroupCodeList.clear();
  }


  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    if (widget.sData == null) {
      formData.shopCd = AuthService.SHOPCD;
      //formData.prodCd = '';
      //formData.catCode = '';
      //List<String>? themaCode;
      formData.name = '';
      formData.cost = '';
      formData.amount = '';
      formData.discAmt = '';
      formData.discRatio = '';
      formData.discStDt = '';
      formData.discToDt = '';
      formData.ribbonCardYn = 'N';
      formData.useGbn = 'Y';
      formData.noFlag = 'N';
      formData.mainYn = 'N';
      formData.discMarkGbn = '3';
      formData.memo = '';
      formData.description = '';
      formData.uCode = AuthService.uCode;
      formData.uName = AuthService.uName;

      // _radioDiscGbn = formData.discMarkGbn == '3' ? RadioDiscGbn.discGbnPercent : RadioDiscGbn.discGbnComment;
      _radioUseGbn = formData.useGbn == 'Y' ? RadioUseGbn.useGbnY : RadioUseGbn.useGbnN ;
      _radioMainGbn = formData.mainYn == 'Y' ? RadioMainGbn.mainGbnY : RadioMainGbn.mainGbnN;
      _radioNoFlagGbn = formData.noFlag == 'N' ? RadioNoFlagGbn.noflagGbnY : RadioNoFlagGbn.noflagGbnN;

      startdate = formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']);
      enddate = formatDate(DateTime(2999, 12, 31), [yyyy, '-', mm, '-', dd]);
      //enddate = formatDate(DateTime(int.parse(DateTime.now().year.toString()), int.parse(DateTime.now().month.toString()) + 1, 0), [yyyy, '-', mm, '-', dd]);
    }
    else{
      formData.shopCd = AuthService.SHOPCD;
      formData.prodCd = widget.sData!.prodCode;
      //formData.catCode = widget.catCode;
      //List<String>? themaCode;
      formData.name = widget.sData!.prodName;
      formData.cost = widget.sData!.cost;
      formData.amount = widget.sData!.amount;
      formData.discAmt = widget.sData!.discAmt;
      formData.discRatio = widget.sData!.discRatio;
      formData.discStDt = widget.sData!.discStDt;
      formData.discToDt = widget.sData!.discToDt;
      formData.ribbonCardYn = widget.sData!.ribbonCardYn;
      formData.useGbn = widget.sData!.useGbn;
      formData.noFlag = widget.sData!.noFlag;
      formData.mainYn = widget.sData!.mainYn;
      formData.discMarkGbn = '3'; //widget.sData!.discMarkGbn;
      formData.memo = widget.sData!.memo;
      formData.description = widget.sData!.description;
      formData.uCode = AuthService.uCode;
      formData.uName = AuthService.uName;

      // _radioDiscGbn = formData.discMarkGbn == '3' ? RadioDiscGbn.discGbnPercent : RadioDiscGbn.discGbnComment;
      _radioUseGbn = formData.useGbn == 'Y' ? RadioUseGbn.useGbnY : RadioUseGbn.useGbnN ;
      _radioMainGbn = formData.mainYn == 'Y' ? RadioMainGbn.mainGbnY : RadioMainGbn.mainGbnN;
      _radioNoFlagGbn = formData.noFlag == 'N' ? RadioNoFlagGbn.noflagGbnY : RadioNoFlagGbn.noflagGbnN;

      startdate = (formData.discStDt == null || formData.discStDt == '') ? formatDate(DateTime.now(), [yyyy, '-', mm, '-', '01']) : startdate = DateFormat('yyyy-MM-dd').format(DateTime.parse(formData.discStDt.toString())).toString();
      enddate = (formData.discToDt == null || formData.discToDt == '') ? formatDate(DateTime(int.parse(DateTime.now().year.toString()), int.parse(DateTime.now().month.toString()) + 1, 0), [yyyy, '-', mm, '-', dd]) : enddate = DateFormat('yyyy-MM-dd').format(DateTime.parse(formData.discToDt.toString())).toString();

      checkState_AlwaysDiscount = (formData.discToDt == '29991231') ? true : false;
    }

    WidgetsBinding.instance.addPostFrameCallback((c) {
      if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_MARKET){
        requestAPIMarketGroupNameData();
      }
      else if(AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET){
        requestAPIElectMarketGroupNameData();
      }
      else{
        requestAPIGroupNameData();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.transparent,
      body: ContentDialog(
        constraints: const BoxConstraints(maxWidth: 400.0, maxHeight: 720),
        contentPadding: const EdgeInsets.all(0.0),//const EdgeInsets.symmetric(horizontal: 20),
        isFillActions: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            Text(widget.sData == null ? '상품 신규 등록' : '상품 정보 수정', style: const TextStyle(fontSize: 22, fontFamily: FONT_FAMILY),),
            fluentUI.SmallIconButton(
              child: fluentUI.Tooltip(
                message: fluentUI.FluentLocalizations.of(context).closeButtonLabel,
                child: fluentUI.IconButton(
                  icon: const Icon(fluentUI.FluentIcons.chrome_close),
                  onPressed: Navigator.of(context).pop,
                ),
              ),
            ),
          ],
        ),
        content: Material(
          color: Colors.transparent,
          borderOnForeground: false,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12,),
                  const Text('상품명', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                  const SizedBox(height: 8),
                  ISInput(
                    autofocus: true,
                    height: 64,
                    value: formData.name,
                    context: context,
                    label: '예) 상품이름',
                    maxLength: 50,
                    onChange: (v) {
                      formData.name = v;
                    },
                  ),
                  // const SizedBox(height: 8),
                  // Row(
                  //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //   children: [
                  //     const Text('노출 구분', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                  //     Row(
                  //       children: [
                  //         Radio(
                  //             value: RadioDiscGbn.discGbnPercent,
                  //             groupValue: _radioDiscGbn,
                  //             onChanged: (v) async {
                  //               setState(() {
                  //                 _radioDiscGbn = v as RadioDiscGbn?;
                  //
                  //                 formData.discMarkGbn = '3';
                  //               });
                  //             }),
                  //         const Text('퍼센트', style: TextStyle(fontSize: 12)),
                  //         const SizedBox(width: 40,),
                  //         Radio(
                  //             value: RadioDiscGbn.discGbnComment,
                  //             groupValue: _radioDiscGbn,
                  //             onChanged: (v) async {
                  //               setState(() {
                  //                 _radioDiscGbn = v as RadioDiscGbn?;
                  //
                  //                 formData.discMarkGbn = '0';
                  //               });
                  //             }),
                  //         const Text('할인 문구', style: TextStyle(fontSize: 12)),
                  //         const SizedBox(width: 16,)
                  //       ],
                  //     )
                  //
                  //   ],
                  // ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('상품 금액', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                          const SizedBox(height: 8),
                          ISInput(
                            textAlign: TextAlign.end,
                            suffixText: '원',
                            value: widget.sData == null && Utils.getCashComma(formData.cost!) == '0' ? '' : Utils.getCashComma(formData.cost!),
                            context: context,
                            label: '금액',
                            width: 120,
                            maxLines: 1,
                            onChange: (v) {

                              formData.cost = v.toString().replaceAll(',', '');
                              formData.discRatio == '' || formData.discRatio == null
                                  ? formData.discRatio = '0'
                                  : formData.discRatio;


                              // var _calc = (int.parse(v.toString().replaceAll(',', '')) - (int.parse(v.toString().replaceAll(',', '')) * int.parse(formData.discRatio!) / 100)).ceil();
                              // formData.amount = _calc.toString();
                              var _calc = ((int.parse(formData.cost!) - int.parse(formData.amount!)) * 100 / int.parse(formData.cost!)).ceil();
                              formData.discRatio = _calc.toString();

                              setState(() {});
                            },
                            keyboardType: TextInputType.number,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                                TextInputFormatter.withFunction(
                                      (oldValue, newValue) {
                                    if (newValue.text.isEmpty) {
                                      return newValue;
                                    }
                                    try {
                                      final parsedValue = int.parse(newValue.text);
                                      if (parsedValue <= 1000000000) {
                                        final formattedValue = Utils.getCashComma(parsedValue.toString());

                                        // 커서 위치 계산
                                        final cursorPosition = newValue.selection.baseOffset;
                                        final newCursorPosition = cursorPosition + (formattedValue.length - newValue.text.length);

                                        return TextEditingValue(
                                          text: formattedValue,
                                          selection: TextSelection.collapsed(offset: newCursorPosition),
                                        );
                                      }
                                    } catch (_) {}
                                    return oldValue;
                                  },
                                ),
                              ]
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('할인된 금액', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                          const SizedBox(height: 8),
                          ISInput(
                            textAlign: TextAlign.end,
                            suffixText: '원',
                          value: widget.sData == null && Utils.getCashComma(formData.amount!) == '0' ? '' : Utils.getCashComma(formData.amount!),
                            context: context,
                            label: '금액',
                            width: 120,
                            maxLines: 1,
                            onChange: (v) {
                              if(v != ''){
                                if (int.parse(v.toString().replaceAll(',', '')) > int.parse(formData.cost!)) {
                                  ISAlert(context, content: '일반 가격보다 높을 수 없습니다.');
                                  formData.discRatio = '0';
                                  formData.amount = formData.cost;
                                  setState(() {});
                                  return;
                                }
                                formData.amount = v.toString().replaceAll(',', '');

                                // var _calc = ((int.parse(formData.cost!) - int.parse(formData.amount!)) * 100 / int.parse(formData.cost!)).ceil();
                                var _calc = ((int.parse(formData.cost!) - int.parse(formData.amount!)) * 100 / int.parse(formData.cost!)).ceil();
                                formData.discRatio = _calc.toString();
                              }
                              setState(() {
                              });
                            },
                            keyboardType: TextInputType.number,
                            // inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],

                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                                TextInputFormatter.withFunction(
                                      (oldValue, newValue) {
                                    if (newValue.text.isEmpty) {
                                      return newValue;
                                    }
                                    try {
                                      final parsedValue = int.parse(newValue.text);
                                      if (parsedValue <= 1000000000) {
                                        final formattedValue = Utils.getCashComma(parsedValue.toString());

                                        // 커서 위치 계산
                                        final cursorPosition = newValue.selection.baseOffset;
                                        final newCursorPosition = cursorPosition + (formattedValue.length - newValue.text.length);

                                        return TextEditingValue(
                                          text: formattedValue,
                                          selection: TextSelection.collapsed(offset: newCursorPosition),
                                        );
                                      }
                                    } catch (_) {}
                                    return oldValue;
                                  },
                                ),
                              ]
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('할인율(%)', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                          const SizedBox(height: 8),
                          ISInput(
                            textAlign: TextAlign.end,
                            suffixText: '%',
                          value:  widget.sData == null && Utils.getCashComma(formData.discRatio!) == '0' ? '' : Utils.getCashComma(formData.discRatio!),
                            context: context,
                            label: '할인율(%)',
                            width: 100,
                            maxLines: 1,
                            onChange: (v) {
                              if(v != ''){
                                if (int.parse(v) > 100) {
                                  ISAlert(context, content: '100% 이상 입력 할 수 없습니다.');
                                  formData.discRatio = '0';
                                  formData.amount = formData.cost;
                                  setState(() {});
                                  return;
                                }
                                var _calc = (int.parse(formData.cost!) - (int.parse(formData.cost!) * int.parse(v) / 100)).ceil();
                                formData.amount = _calc.toString();

                                formData.discRatio = v;

                              }
                              setState(() {
                              });
                            },
                            keyboardType: TextInputType.number,
                            inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))],
                          ),
                        ],
                      )
                    ],
                  ),
                  const SizedBox(height: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('상품설명', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                      const SizedBox(height: 8),
                      ISInput(
                        height: 100,
                        keyboardType: TextInputType.multiline,
                        maxLines: 8,
                        value: formData.description,
                        context: context,
                        label: '상품설명',
                        maxLength: 100,
                        onChange: (v) {
                          setState(() {
                            if(v.length <= 100) {
                              formData.description = v;
                            }
                          });
                        },
                      ),
                      const SizedBox(height: 16),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('상품 할인 기간', style: TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Material(
                            child: ISSearchSelectDate(
                              label: '기간 선택',
                              width: 230,
                              value: '${widget.sData == null ? DateFormat('yyyy-MM-dd').format(DateTime.now()) :startdate.toString()} ~ ${enddate.toString()}',
                              onTap: () async {
                                showGeneralDialog(
                                    context: context,
                                    barrierDismissible: true,
                                    barrierLabel: '',
                                    barrierColor: Colors.black54,
                                    pageBuilder: (context, animation, secondaryAnimation) {
                                      return Dialog(
                                          insetPadding: EdgeInsets.zero,
                                          elevation: 0,
                                          backgroundColor: Colors.white,
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                                          child: MultipleViewDateRangePicker(
                                            startDate: widget.sData == null ?  DateTime.now(): DateTime.parse(startdate!),
                                            endDate: DateTime.parse(enddate!),
                                            setDateActionCallback: ({startDate, endDate}) {
                                              setState(() {
                                                startdate = DateFormat('yyyy-MM-dd').format(startDate!);
                                                enddate = DateFormat('yyyy-MM-dd').format(endDate!);
                                              });
                                              Navigator.of(context).pop();
                                            },
                                          ));
                                    });
                              },
                            ),
                          ),
                          const SizedBox(width: 16.0,),
                          Material(child: ISCheckbox(
                              label: '계속 할인',
                              value: checkState_AlwaysDiscount,

                              onChanged: (v) {
                                setState(() {
                                  enddate = (v == true) ? formatDate(DateTime(2999, 12, 31), [yyyy, '-', mm, '-', dd]) : formatDate(DateTime(int.parse(DateTime.now().year.toString()), int.parse(DateTime.now().month.toString()) + 1, 0), [yyyy, '-', mm, '-', dd]);

                                  checkState_AlwaysDiscount = v!;
                                });
                              }
                            )
                          ),
                        ],
                      )
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER)...[
                    ISCheckbox(
                      label: '리본/카드 옵션',
                      value: formData.ribbonCardYn == 'Y',
                      //onChanged: (v) => setState(() => checkState_RibbonCardOption = v!)
                      onChanged: (v) {
                        setState(() {
                          formData.ribbonCardYn = (v == true) ? 'Y' : 'N';
                        });
                      },
                    ),
                    const SizedBox(height: 16,),
                    const Row(
                      children: [
                        Text('카테고리', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                        SizedBox(width: 4,),
                        Text('(* 카테고리는 최대 3개 지정 가능합니다.)', style: TextStyle(color: Colors.black54, fontSize: 10, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Flex(
                        direction: Axis.horizontal,
                        children: [
                          Expanded(
                            child: Wrap(
                              alignment: WrapAlignment.start,
                              spacing: 8.0,
                              children: _buildCategoryCheckBox(),
                            ),
                          ),
                        ]
                    ),
                    const SizedBox(height: 16,),
                    const Row(
                      children: [
                        Text('테마', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                        SizedBox(width: 4,),
                        Text('(* 테마는 최대 3개 지정 가능합니다.)', style: TextStyle(color: Colors.black54, fontSize: 10, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Flex(
                        direction: Axis.horizontal,
                        children: [
                          Expanded(
                            child: Wrap(
                              alignment: WrapAlignment.start,
                              spacing: 8.0,
                              children: _buildThemeCheckBox(),
                            ),
                          ),
                        ]
                    ),
                  ]
                  else if(AuthService.ShopServiceGbn == AuthService.SHOPGBN_ELECTMARKET)...[
                    const SizedBox(height: 16,),
                    const Row(
                      children: [
                        Text('카테고리', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                        SizedBox(width: 4,),
                        Text('(* 카테고리는 최대 3개 지정 가능합니다.)', style: TextStyle(color: Colors.black54, fontSize: 10, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Flex(
                        direction: Axis.horizontal,
                        children: [
                          Expanded(
                            child: Wrap(
                              alignment: WrapAlignment.start,
                              spacing: 8.0,
                              children: _buildCategoryCheckBox(),
                            ),
                          ),
                        ]
                    ),
                    const SizedBox(height: 16,),
                    const Row(
                      children: [
                        Text('상품그룹', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                        SizedBox(width: 4,),
                        Text('(* 상품 그룹은 1개 지정 가능합니다.)', style: TextStyle(color: Colors.black54, fontSize: 10, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Flex(
                        direction: Axis.horizontal,
                        children: [
                          Expanded(
                            child: Wrap(
                              alignment: WrapAlignment.start,
                              spacing: 8.0,
                              children: _buildProdGroupCheckBox(),
                            ),
                          ),
                        ]
                    ),
                  ]
                  else...[
                    const SizedBox(height: 16,),
                    const Row(
                      children: [
                        Text('카테고리', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD),),
                        SizedBox(width: 4,),
                        Text('(* 카테고리는 최대 3개 지정 가능합니다.)', style: TextStyle(color: Colors.black54, fontSize: 10, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Flex(
                        direction: Axis.horizontal,
                        children: [
                          Expanded(
                            child: Wrap(
                              alignment: WrapAlignment.start,
                              spacing: 8.0,
                              children: _buildCategoryCheckBox(),
                            ),
                          ),
                        ]
                    ),
                  ],
                  const Divider(),
                  Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('사용 여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                          Row(
                            children: [
                              Radio(
                                  value: RadioUseGbn.useGbnY,
                                  groupValue: _radioUseGbn,
                                  onChanged: (v) async {
                                    setState(() {
                                      _radioUseGbn = v as RadioUseGbn?;

                                      formData.useGbn = 'Y';
                                    });
                                  }),
                              const Text('사용', style: TextStyle(fontSize: 12)),
                              const SizedBox(width: 40,),
                              Radio(
                                  value: RadioUseGbn.useGbnN,
                                  groupValue: _radioUseGbn,
                                  onChanged: (v) async {
                                    setState(() {
                                      _radioUseGbn = v as RadioUseGbn?;

                                      formData.useGbn = 'N';
                                    });
                                  }),
                              const Text('미사용', style: TextStyle(fontSize: 12)),
                              const SizedBox(width: 16,)
                            ],
                          )

                        ],
                      ),
                      const SizedBox(height: 6,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('품절 여부', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                          Row(
                            children: [
                              Radio(
                                  value: RadioNoFlagGbn.noflagGbnY,
                                  groupValue: _radioNoFlagGbn,
                                  onChanged: (v) async {
                                    setState(() {
                                      _radioNoFlagGbn = v as RadioNoFlagGbn?;

                                      formData.noFlag = 'N';
                                    });
                                  }),
                              const Text('판매중', style: TextStyle(fontSize: 12)),
                              const SizedBox(width: 30,),
                              Radio(
                                  value: RadioNoFlagGbn.noflagGbnN,
                                  groupValue: _radioNoFlagGbn,
                                  onChanged: (v) async {
                                    setState(() {
                                      _radioNoFlagGbn = v as RadioNoFlagGbn?;

                                      formData.noFlag = 'Y';
                                    });
                                  }),
                              const Text('품절', style: TextStyle(fontSize: 12)),
                              const SizedBox(width: 26,),
                            ],
                          )

                        ],
                      ),
                      const SizedBox(height: 6,),

                      if(AuthService.ShopServiceGbn != AuthService.SHOPGBN_ELECTMARKET)
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('대표 상품', style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, fontWeight: FONT_BOLD)),
                          Row(
                            children: [
                              Radio(
                                  value: RadioMainGbn.mainGbnY,
                                  groupValue: _radioMainGbn,
                                  onChanged: (v) async {
                                    setState(() {
                                      _radioMainGbn = v as RadioMainGbn?;

                                      formData.mainYn = 'Y';
                                    });
                                  }),
                              const Text('사용', style: TextStyle(fontSize: 12)),
                              const SizedBox(width: 40,),
                              Radio(
                                  value: RadioMainGbn.mainGbnN,
                                  groupValue: _radioMainGbn,
                                  onChanged: (v) async {
                                    setState(() {
                                      _radioMainGbn = v as RadioMainGbn?;

                                      formData.mainYn = 'N';
                                    });
                                  }),
                              const Text('미사용', style: TextStyle(fontSize: 12)),
                              const SizedBox(width: 16,)
                            ],
                          )

                        ],
                      ),
                    ],
                  ),
                  const Divider(),
                ],
              ),
            ),
          ),
        ),
        actions: [
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleLeft,
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('취소', style: TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
          SizedBox(
            child: FilledButton(
              style: appTheme.popupButtonStyleRight,
              onPressed: () {

                if (formData.name == '' || formData.name == null) {
                  ISAlert(context, content: '상품명을 확인해 주세요.');
                  return;
                }

                if (formData.cost == '' || formData.cost == null || formData.cost == '0') {
                  ISAlert(context, content: '금액을 확인해 주세요.');
                  return;
                }else if(formData.amount == '' || formData.amount == null || formData.discRatio == '' || formData.discRatio == null){
                  formData.discRatio = '0';
                  formData.discAmt = '0';
                  formData.amount = formData.cost;
                }

                if(int.parse(formData.cost!) < int.parse(formData.amount!)){
                  ISAlert(context, content: '상품 금액이 할인된 금액보다 적을 수 없습니다.');
                  return;
                }

                if (selectCategoryCodeList.isEmpty) {
                  ISAlert(context, content: '카테고리를 확인해 주세요.');
                  return;
                }

                if(formData.amount != ((int.parse(formData.cost!) - (int.parse(formData.cost!) * int.parse(formData.discRatio!) / 100)).floor()).toString() && formData.discRatio != (((int.parse(formData.cost!) - int.parse(formData.amount!)) * 100 / int.parse(formData.cost!)).ceil()).toString()){
                  ISAlert(context, content: '상품 금액을 확인해 주세요.');
                  return;
                }

                BuildContext oldContext = context;

                ISConfirm(context, widget.sData == null ? '상품 등록' : '상품 수정', widget.sData == null ? '신규 상품 정보를 등록하시겠습니까?' : '상품 정보를 변경하시겠습니까?', constraints: const BoxConstraints(maxWidth: 360.0, maxHeight: 260), (context, isOK) async {
                  Navigator.of(context).pop();

                  if (isOK){
                    formData.shopCd = AuthService.SHOPCD;
                    formData.prodCd = widget.sData == null ? '' : formData.prodCd;
                    formData.catCode = selectCategoryCodeList;
                    formData.themaCode = selectThemeCodeList;
                    formData.grpCode = selectProdGroupCodeList[0];
                    formData.discStDt = startdate!.replaceAll('-', '');
                    formData.discToDt = enddate!.replaceAll('-', '');

                    if(formData.amount == ''){
                      formData.discAmt = '';
                    }else{
                    formData.discAmt = (double.parse(formData.cost!) - double.parse(formData.amount!)).toString();
                    }
                    var value = null;

                    if (widget.sData == null){
                      value = await showDialog(
                          context: context,
                          builder: (context) => FutureProgressDialog(ProductInfoController.to.addProduct(formData.toJson()))
                      );
                    }
                    else{
                      value = await showDialog(
                          context: context,
                          builder: (context) => FutureProgressDialog(ProductInfoController.to.setProduct(formData.toJson()))
                      );
                    }


                    if (value == null) {
                      ISAlert(context, content: '정상 처리가 되지 않았습니다. \n\n다시 시도해 주세요.');
                    }
                    else {
                      if (value == '00') {
                        Navigator.of(oldContext).pop(true);
                      }
                      else{
                        ISAlert(context, content: '정상 처리가 되지 않았습니다.\n→ ${value} ');
                      }
                    }

                  }
                });
              },
              child: Text(widget.sData == null ? '등록' : '적용', style: const TextStyle(fontSize: 18, fontFamily: FONT_FAMILY)),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildCategoryCheckBox(){
    List<Widget> retWidget = [];

    selectBox_Category.forEach((element) {
      retWidget.add(
        ISCheckbox(
            label: element.label,
            value: selectCategoryCodeList!.contains(element.value),
            onChanged: (v) {
              selectCategoryCodeList!.contains(element.value) ? selectCategoryCodeList!.remove(element.value) : selectCategoryCodeList!.add(element.value.toString());

              if (selectCategoryCodeList.length > 3){
                selectCategoryCodeList!.remove(element.value);

                ISAlert(context, content: '카테고리 선택은 최대 3개까지 가능합니다.');

                setState(() { });

                return;
              }
              else{
                setState(() {
                });
              }
            }
        ),
      );
    });

    return retWidget;
  }

  List<Widget> _buildThemeCheckBox(){
    List<Widget> retWidget = [];

    selectBox_Theme.forEach((element) {
      retWidget.add(
        ISCheckbox(
            label: element.label,
            value: selectThemeCodeList!.contains(element.value),
            onChanged: (v) {
              selectThemeCodeList!.contains(element.value) ? selectThemeCodeList!.remove(element.value) : selectThemeCodeList!.add(element.value.toString());

              if (selectThemeCodeList.length > 3){
                selectThemeCodeList!.remove(element.value);

                ISAlert(context, content: '테마 선택은 최대 3개까지 가능합니다.');

                setState(() { });

                return;
              }
              else{
                setState(() {
                });
              }
            }
        ),
      );
    });

    return retWidget;
  }


  List<Widget> _buildProdGroupCheckBox(){
    List<Widget> retWidget = [];

    selectBox_ProdGroup.forEach((element) {
      retWidget.add(
        ISCheckbox(
            label: element.label,
            value: selectProdGroupCodeList!.contains(element.value),
            onChanged: (v) {
              selectProdGroupCodeList!.contains(element.value) ? selectProdGroupCodeList!.remove(element.value) : selectProdGroupCodeList!.add(element.value.toString());

              if (selectProdGroupCodeList.length > 1){
                selectProdGroupCodeList!.remove(element.value);

                ISAlert(context, content: '상품 그룹 선택은 1개 지정 가능합니다.');

                setState(() { });

                return;
              }
              else{
                setState(() {
                });
              }
            }
        ),
      );
    });

    return retWidget;
  }
}


