
import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/config/auth_service.dart';
import 'package:daeguro_ceo_app/iswidgets/is_alertdialog.dart';
import 'package:daeguro_ceo_app/iswidgets/is_progressDialog.dart';
import 'package:daeguro_ceo_app/iswidgets/isd_button.dart';
import 'package:daeguro_ceo_app/models/ProductManager/productOriginLocalListModel.dart';
import 'package:daeguro_ceo_app/routes/routes.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productManagerController.dart';
import 'package:daeguro_ceo_app/screen/Flower/ProductManager/productOriginLocalEdit.dart';
import 'package:daeguro_ceo_app/screen/MenuManager/menuGroupEdit.dart';
import 'package:daeguro_ceo_app/theme.dart';
import 'package:daeguro_ceo_app/util/utils.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluentUI;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductOriginLocalInfoMain extends StatefulWidget {
  final double? tabviewHeight;
  const ProductOriginLocalInfoMain({Key? key, this.tabviewHeight}) : super(key: key);

  @override
  State<ProductOriginLocalInfoMain> createState() => _ProductOriginLocalInfoMainState();
}

class _ProductOriginLocalInfoMainState extends State<ProductOriginLocalInfoMain> {

  final List<ProductOriginLocalListModel> dataItemList = <ProductOriginLocalListModel>[];

  String? tempStr = '';

  requestAPIData() async {
    var value = await showDialog(
        context: context,
        barrierColor: Colors.transparent,
        builder: (context) => FutureProgressDialog(ProductInfoController.to.getProductOriginList())
    );

    if (value == null) {
      ISAlert(context, content: '정상 조회가 되지 않았습니다. \n\n다시 시도해 주세요.');
      //Navigator.of(context).pop;
    }
    else {
      dataItemList.clear();

      value.forEach((element) {
        ProductOriginLocalListModel temp = ProductOriginLocalListModel();
        temp.seq = element['seq'] as String;
        temp.title = element['title'] as String;
        temp.contents = element['contents'] as String;
        temp.useGbn = element['useGbn'] as String;

        dataItemList.add(temp);
      });
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    Get.put(ProductInfoController());

    WidgetsBinding.instance.addPostFrameCallback((c) {
      requestAPIData();
    });
  }

  @override
  void dispose() {
    super.dispose();
    dataItemList.clear();
  }

void refresh(final _appTheme) async {
    if (mounted) {
      if (_appTheme.ShopRefresh == true ) {
        _appTheme.ShopRefresh = false;

        WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
          if (AuthService.ShopServiceGbn == AuthService.SHOPGBN_FLOWER){
            requestAPIData();
          }
          else{
            router.go('/');
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    assert(fluentUI.debugCheckHasFluentTheme(context));

    final appTheme = context.watch<AppTheme>();

    Future.microtask(() => refresh(appTheme));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          elevation: 1,
          shape: appTheme.cardShapStyle,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('원산지', style: TextStyle(fontSize: 18, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY)),
                ISButton(
                  child: const Text('원산지 추가'),
                  onPressed: () {
                    showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) => const ProductOriginLocalEdit(),
                    ).then((v) async {
                      if (v == true) {
                        await Future.delayed(Duration(milliseconds: 500), () {
                          requestAPIData();
                        });
                      }
                    });
                  },
                )
              ],
            ),
          ),
        ),
        const SizedBox(height: 4),
        //const Divider(color: Colors.black,),//fluentUI.Divider(style: fluentUI.DividerThemeData(horizontalMargin: EdgeInsets.zero)),
        Expanded(child: itemListView()),

        const Divider(height: 1)
      ],
    );
  }

  Widget itemListView() {
    final appTheme = context.watch<AppTheme>();

    return SizedBox(
      height: widget.tabviewHeight! - 91,
      child: ListView.builder(
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          itemBuilder: (ctx, index) {
            return InkWell(
              onTap: (){
                showProductSelectList(index);
              },
              child: Card(
                elevation: 1,
                shape: appTheme.cardShapStyle,
                child: Padding(
                  key: Key('$index'),
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Flexible(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Container(
                              padding: const EdgeInsets.only(left: 4, right: 0, top: 8, bottom: 2),
                              alignment: Alignment.topLeft,
                              child: Column(
                                children: <Widget>[
                                  Row(
                                    children: [
                                      dataItemList[index].useGbn == 'Y'
                                          ? Container(
                                          width: 36,
                                          height: 18,
                                          alignment: Alignment.center,
                                          decoration: AppTheme.getListBadgeDecoration(const Color.fromRGBO(87, 170, 58, 0.8431372549019608)),
                                          child: const Center(
                                              child: Text('사용중', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),
                                              ))
                                      ) : Container(
                                          width: 36,
                                          height: 18,
                                          alignment: Alignment.center,
                                          decoration: AppTheme.getListBadgeDecoration(Colors.black26),
                                          child: const Text('미사용', style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL),)
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 5),
                                  Container(
                                    alignment: Alignment.topLeft,
                                    child: Text(dataItemList[index].title ?? '--', style: const TextStyle(fontSize: 16, fontWeight: FONT_BOLD, fontFamily: FONT_FAMILY),),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.only(left: 4, right: 10, top: 2, bottom: 8),
                              alignment: Alignment.topLeft,
                              child: Text('${dataItemList[index].contents!}', style: const TextStyle(color: Colors.black54, fontSize: 12, fontWeight: FONT_NORMAL, fontFamily: FONT_FAMILY)),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                          padding: const EdgeInsets.fromLTRB(0, 0, 30, 0),
                          child: IconButton(
                            icon: const Icon(Icons.more_horiz, size: 20),
                            color: Colors.black,
                            tooltip: '수정',
                            onPressed: () {
                              showProductSelectList(index);
                            },
                          )
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
          //separatorBuilder: (BuildContext context, int index) { return const Divider(thickness: 1, height: 0.0,); },
          itemCount: dataItemList.length
      ),
    );
  }

  showProductSelectList(int index){
    List<String> values = ['원산지 수정'];

    ISOptionDialog(context, const BoxConstraints(maxWidth: 360.0, maxHeight: 116), dataItemList[index].title!, values, (context, selectIdx) async {
      Navigator.of(context).pop();
      if (selectIdx == 0){
        showDialog(
          context: context,
          barrierDismissible: true,
          builder: (context) => ProductOriginLocalEdit(sData: dataItemList.elementAt(index)),
        ).then((v) async {
          if (v == true) {
            await Future.delayed(Duration(milliseconds: 500), () {
              requestAPIData();
            });
          }
        });
      }
    });
  }
}

