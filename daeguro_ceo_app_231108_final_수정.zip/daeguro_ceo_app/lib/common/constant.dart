import 'package:flutter/material.dart';

// const primaryColor = Color(0xFF2697FF);
// const secondaryColor = Color(0xFF2A2D3E);
// const bgColor = Color(0xFF212332);
//
// const defaultWidthPadding = 32.0;
// const defaultHeightPadding = 16.0;
// const defaultAllPadding = 16.0;
// const defaultContentsHeight = 178;//194;

const naviPaneOpenWidth = 240.0;//260
const naviPaneCompactWidth = 50.0;//260

const naviPaneItemChildHeight = 30.0;

const String FONT_FAMILY = "HanSansNeo";//"NotoSansKR";//'Roboto';//
const String FONT_FAMILY_NEXON = "Nexon";

const FontWeight FONT_BOLD = FontWeight.bold;
const FontWeight FONT_NORMAL = FontWeight.normal;

const TextStyle naviHeaderTextStyle = TextStyle(fontSize: 13.0, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL, color: Colors.grey, );
const TextStyle naviItemTextStyle = TextStyle(fontSize: 16.0, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);
const TextStyle naviFooterTextStyle = TextStyle(fontSize: 13.0, fontFamily: FONT_FAMILY, fontWeight: FONT_NORMAL);
//
// ButtonStyle? get popupButtonStyleLeft => ButtonStyle(
//   minimumSize: MaterialStateProperty.all(const Size(60,70)),
//   backgroundColor: const MaterialStatePropertyAll(Color(0xff333333)),
//   shape: const MaterialStatePropertyAll(
//       RoundedRectangleBorder(
//           borderRadius: BorderRadius.only(bottomLeft: Radius.circular(12.0))
//       )
//   ),
// );
// ButtonStyle? get popupButtonStyleRight => ButtonStyle(
//   minimumSize: MaterialStateProperty.all(const Size(60,70)),//Size.fromHeight(60),
//   backgroundColor: const MaterialStatePropertyAll(Color(0xff01CAFF)),
//   shape: const MaterialStatePropertyAll(
//       RoundedRectangleBorder(
//           borderRadius: BorderRadius.only(bottomRight: Radius.circular(12.0))//BorderRadius.circular(4.0))
//       )
//   ),
// );



