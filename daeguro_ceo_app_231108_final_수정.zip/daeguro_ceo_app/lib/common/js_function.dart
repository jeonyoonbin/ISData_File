// <<<<<<<APK Only>>>>>>>
import 'package:flutter/material.dart';

void runAppRefresh() {
  debugPrint('this function is only for Web version');
}

void showConfirm(String empty) {
  debugPrint('this function is only for Web version');
}

void pagePrev() {
  debugPrint('this function is only for Web version');
}

void pwaGuide() {
  debugPrint('this function is only for Web version');
}

Future keyboardVisibleFunction(ScrollController scrollController) async {
  Future.delayed(const Duration(milliseconds: 330)).then((value) =>
      scrollController.animateTo(180,
          duration: const Duration(milliseconds: 100), curve: Curves.easeIn));
}

//
//

// // <<<<<<<Web Only>>>>>>>
// @JS()
// library javascript_bundler;

// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:js/js.dart';
// import 'dart:html';
// import 'package:mobile_admin/config/auth_service.dart';
// import 'package:mobile_admin/config/server_info.dart';

// @JS('appRefresh')
// external void runAppRefresh();

// @JS('downloadImg')
// external void showConfirm(var _uri);

// @JS('pagePrev')
// external void pagePrev();

// Future keyboardVisibleFunction(ScrollController scrollController) async {
//   if (GetPlatform.isIOS &&
//       !window.matchMedia('(display-mode: standalone)').matches) {
//     Future.delayed(const Duration(milliseconds: 500)).then((value) =>
//         scrollController.animateTo(180,
//             duration: const Duration(milliseconds: 100), curve: Curves.easeIn));
//   } else {
//     Future.delayed(const Duration(milliseconds: 330)).then((value) =>
//         scrollController.animateTo(180,
//             duration: const Duration(milliseconds: 100), curve: Curves.easeIn));
//   }
// }

// void pwaGuide() {
//   if (GetPlatform.isIOS &&
//       !window.matchMedia('(display-mode: standalone)').matches) {
//     AuthService.to.userStorage.read(key: '@pwaGuideOff').then(
//           (value) => value != ServerInfo.APP_VERSION
//               ? {
//                   Future.delayed(const Duration(milliseconds: 700))
//                       .then((value) => iosPwaGuidePopup())
//                 }
//               : null,
//         );
//   } else if (GetPlatform.isAndroid &&
//       !window.matchMedia('(display-mode: standalone)').matches) {
//     AuthService.to.userStorage.read(key: '@pwaGuideOff').then(
//           (value) => value != ServerInfo.APP_VERSION
//               ? {
//                   Future.delayed(const Duration(milliseconds: 700))
//                       .then((value) => androidPwaGuidePopup())
//                 }
//               : null,
//         );
//   }
// }

// androidPwaGuidePopup() {
//   Get.dialog(Dialog(
//     insetPadding: EdgeInsets.zero,
//     alignment: Alignment.topCenter,
//     child: Container(
//       color: const Color(0xff01CAFF),
//       height: 400,
//       width: Get.width,
//       padding: const EdgeInsets.all(20),
//       child: Center(
//           child: Column(
//         crossAxisAlignment: CrossAxisAlignment.center,
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           const Text(
//             '<크롬 브라우저>',
//             style: TextStyle(
//               fontFamily: 'NotoSansKR',
//               fontWeight: FontWeight.bold,
//               fontSize: 19,
//               color: Color(0xffFFFFFF),
//             ),
//           ),
//           Wrap(
//             alignment: WrapAlignment.center,
//             children: const [
//               Icon(
//                 Icons.more_vert,
//                 color: Color(0xffFFFFFF),
//               ),
//               Text(
//                 '을 누른 후',
//                 style: TextStyle(
//                   fontFamily: 'NotoSansKR',
//                   fontSize: 18,
//                   color: Color(0xffFFFFFF),
//                 ),
//               ),
//               Icon(
//                 Icons.add_to_home_screen,
//                 color: Color(0xffFFFFFF),
//               ),
//               Text(
//                 '\'앱 설치\'를 눌러 앱을',
//                 style: TextStyle(
//                   fontFamily: 'NotoSansKR',
//                   fontSize: 18,
//                   color: Color(0xffFFFFFF),
//                 ),
//               ),
//               Text(
//                 '설치하세요',
//                 style: TextStyle(
//                   fontFamily: 'NotoSansKR',
//                   fontSize: 18,
//                   color: Color(0xffFFFFFF),
//                 ),
//               ),
//             ],
//           ),
//           const Divider(),
//           const Text(
//             '<삼성 인터넷 브라우저>',
//             style: TextStyle(
//               fontFamily: 'NotoSansKR',
//               fontWeight: FontWeight.bold,
//               fontSize: 19,
//               color: Color(0xffFFFFFF),
//             ),
//           ),
//           Wrap(
//             alignment: WrapAlignment.center,
//             children: const [
//               Text(
//                 '상단 주소창 우측',
//                 style: TextStyle(
//                   fontFamily: 'NotoSansKR',
//                   fontSize: 18,
//                   color: Color(0xffFFFFFF),
//                 ),
//               ),
//               Icon(
//                 Icons.arrow_circle_down,
//                 color: Color(0xffFFFFFF),
//               ),
//               Text(
//                 '을 눌러 앱을',
//                 style: TextStyle(
//                   fontFamily: 'NotoSansKR',
//                   fontSize: 18,
//                   color: Color(0xffFFFFFF),
//                 ),
//               ),
//               Text(
//                 '설치하세요',
//                 style: TextStyle(
//                   fontFamily: 'NotoSansKR',
//                   fontSize: 18,
//                   color: Color(0xffFFFFFF),
//                 ),
//               ),
//             ],
//           ),
//           const Divider(),
//           const SizedBox(
//             height: 90,
//             child: Text(
//               '최적의 사용자 경험을 위해 앱을 설치해 주세요\n앱을 설치하면 앱 아이콘이 생성되고 일반 앱과 같이 사용할 수 있습니다',
//               textAlign: TextAlign.center,
//               style: TextStyle(
//                 fontFamily: 'NotoSansKR',
//                 fontSize: 16,
//                 color: Color(0xffFFFFFF),
//               ),
//             ),
//           ),
//           Container(
//             margin: const EdgeInsets.only(top: 15, bottom: 5),
//             height: 30,
//             child: ElevatedButton(
//               style: TextButton.styleFrom(
//                   backgroundColor: const Color.fromARGB(255, 95, 153, 198)),
//               child: const Text(
//                 "다시 표시 안함",
//                 style: TextStyle(
//                     fontFamily: 'NotoSansKR',
//                     fontWeight: FontWeight.bold,
//                     fontSize: 15,
//                     color: Color(0xffFFFFFF)),
//               ),
//               onPressed: () {
//                 AuthService.to.userStorage
//                     .write(key: '@pwaGuideOff', value: ServerInfo.APP_VERSION)
//                     .then((value) => Get.back());
//               },
//             ),
//           ),
//         ],
//       )),
//     ),
//   ));
// }

// iosPwaGuidePopup() {
//   Get.bottomSheet(Container(
//     color: const Color(0xff01CAFF),
//     height: 400,
//     width: Get.width,
//     padding: const EdgeInsets.all(20),
//     child: Center(
//         child: Column(
//       crossAxisAlignment: CrossAxisAlignment.center,
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: const [
//             Icon(
//               Icons.ios_share,
//               color: Color(0xffFFFFFF),
//             ),
//             Text(
//               ' 을 누른 후 \'홈 화면에 추가\'를',
//               style: TextStyle(
//                 fontFamily: 'NotoSansKR',
//                 fontWeight: FontWeight.bold,
//                 fontSize: 18,
//                 color: Color(0xffFFFFFF),
//               ),
//             ),
//           ],
//         ),
//         const Text(
//           '눌러 앱을 설치하세요',
//           style: TextStyle(
//             fontFamily: 'NotoSansKR',
//             fontWeight: FontWeight.bold,
//             fontSize: 18,
//             color: Color(0xffFFFFFF),
//           ),
//         ),
//         const Text(
//           '<Safari(사파리) 브라우저에서 지원>',
//           style: TextStyle(
//             fontFamily: 'NotoSansKR',
//             fontWeight: FontWeight.bold,
//             fontSize: 18,
//             color: Color(0xffFFFFFF),
//           ),
//         ),
//         const Divider(),
//         // Wrap(
//         //   alignment: WrapAlignment.center,
//         //   children: const [
//         const SizedBox(
//           height: 90,
//           child: Text(
//             '최적의 사용자 경험을 위해 앱을 설치해 주세요\n앱을 설치하면 홈 화면에 앱 아이콘이 생성되고 일반 앱과 같이 사용할 수 있습니다',
//             textAlign: TextAlign.center,
//             style: TextStyle(
//               fontFamily: 'NotoSansKR',
//               fontSize: 16,
//               color: Color(0xffFFFFFF),
//             ),
//           ),
//         ),
//         Container(
//           margin: const EdgeInsets.symmetric(vertical: 5),
//           height: 30,
//           width: Get.width - 40,
//           child: ElevatedButton(
//             style: TextButton.styleFrom(
//                 backgroundColor: const Color.fromARGB(255, 95, 153, 198)),
//             child: const Text(
//               "다시 표시 안함",
//               style: TextStyle(
//                   fontFamily: 'NotoSansKR',
//                   fontWeight: FontWeight.bold,
//                   fontSize: 15,
//                   color: Color(0xffFFFFFF)),
//             ),
//             onPressed: () {
//               AuthService.to.userStorage
//                   .write(key: '@pwaGuideOff', value: ServerInfo.APP_VERSION)
//                   .then((value) => Get.back());
//               // Get.back();
//             },
//           ),
//         ),
//       ],
//     )),
//   ));
// }
