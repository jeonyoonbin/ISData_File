class OptionMenuLinkChildModel {
  OptionMenuLinkChildModel();

  String? selectYn;
  String? menuGrpCd;
  String? menuGrpName;
  String? menuCd;
  String? menuName;
  String? menuCost;
}
