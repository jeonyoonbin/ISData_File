import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionGroupNewItemModel {
  OptionGroupNewItemModel();

  String? name;
  String? cost = '0';
  String? noFlag = 'N';
}