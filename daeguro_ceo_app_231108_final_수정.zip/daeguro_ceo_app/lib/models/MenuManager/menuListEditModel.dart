import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class MenuListEditModel {
  MenuListEditModel();

  bool selected = false;
  String? shopCd;
  String? groupCd;
  String? menuCd;
  String? menuName;
  String? menuCost;
  String? menuDesc;
  String? useGbn;
  String? noFlag;
  String? mAloneOrder;
  String? mMainYn;
  String? adultOnly;
  String? singleOrderYn;
  String? orderLimitYn;
  String? orderLimitQnt;
  String? uName;

  factory MenuListEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

MenuListEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return MenuListEditModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd']
    ..groupCd = json['groupCd']
    ..menuCd = json['menuCd']
    ..menuName = json['menuName']
    ..menuCost = json['menuCost']
    ..menuDesc = json['menuDesc']
    ..useGbn = json['useGbn']
    ..noFlag = json['noFlag']
    ..mAloneOrder = json['mAloneOrder']
    ..mMainYn = json['mMainYn']
    ..adultOnly = json['adultOnly']
    ..singleOrderYn = json['singleOrderYn']
    ..orderLimitYn = json['orderLimitYn']
    ..orderLimitQnt = json['orderLimitQnt']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(MenuListEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'groupCd': instance.groupCd,
      'menuCd': instance.menuCd,
      'menuName': instance.menuName,
      'menuCost': instance.menuCost,
      'menuDesc': instance.menuDesc,
      'useGbn': instance.useGbn,
      'noFlag': instance.noFlag,
      'mAloneOrder': instance.mAloneOrder,
      'mMainYn': instance.mMainYn,
      'adultOnly': instance.adultOnly,
      'singleOrderYn': instance.singleOrderYn,
      'orderLimitYn': instance.orderLimitYn,
      'orderLimitQnt': instance.orderLimitQnt,
      'uName': instance.uName
    };
