import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class OptionGroupListModel {
  OptionGroupListModel();

  bool selected = false;
  bool isFlag = false;

  String? menuOptGrpCd;
  String? optGrpCd;
  String? optGrpName;
  String? optGrpMemo;
  String? optNames;
  String? menuNames;
  String? minCount;
  String? multiCount;
  String? multiYn;
  String? useYn;
  String? reqYn;

  factory OptionGroupListModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

OptionGroupListModel _$ModelFromJson(Map<String, dynamic> json) {
  return OptionGroupListModel()
    //..selected = json['selected'] as String
    ..menuOptGrpCd = json['menuOptGrpCd'] as String
    ..optGrpCd = json['optGrpCd'] as String
    ..optGrpName = json['optGrpName'] as String
    ..optGrpMemo = json['optGrpMemo'] as String
    ..optNames = json['optNames'] as String
    ..menuNames = json['menuNames'] as String
    ..minCount = json['minCount'] as String
    ..multiCount = json['multiCount'] as String
    ..multiYn = json['multiYn'] as String
    ..useYn = json['useYn'] as String
    ..reqYn = json['reqYn'] as String;
}

Map<String, dynamic> _$ModelToJson(OptionGroupListModel instance) =>
    <String, dynamic>{
      //'selected': instance.selected,
      'menuOptGrpCd': instance.menuOptGrpCd,
      'optGrpCd': instance.optGrpCd,
      'optGrpName': instance.optGrpName,
      'optGrpMemo': instance.optGrpMemo,
      'optNames': instance.optNames,
      'menuNames': instance.menuNames,
      'minCount': instance.minCount,
      'multiCount': instance.multiCount,
      'multiYn': instance.multiYn,
      'useYn': instance.useYn,
      'reqYn': instance.reqYn
    };
