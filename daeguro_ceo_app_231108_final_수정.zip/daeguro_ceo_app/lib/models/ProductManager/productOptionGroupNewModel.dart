import 'package:json_annotation/json_annotation.dart';

import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProductOptionGroupNewModel {
  ProductOptionGroupNewModel();

  bool selected = false;
  String? shopCd;
  String? name;
  String? minCnt;
  String? multiCnt;
  String? useGbn;
  String? addYn;
  List<String>? optionName;
  List<String>? optionCost;
  List<String>? optionNoFlag;
  String? uCode;
  String? uName;

  factory ProductOptionGroupNewModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ProductOptionGroupNewModel _$ModelFromJson(Map<String, dynamic> json) {
  return ProductOptionGroupNewModel()
  // ..selected = json['selected'] as bool
    ..shopCd = json['shopCd']
    ..name = json['name']
    ..minCnt = json['minCnt']
    ..multiCnt = json['multiCnt']
    ..useGbn = json['useGbn']
    ..addYn = json['addYn']
    ..optionName = json['optionName'].cast<String>()
    ..optionCost = json['optionCost'].cast<String>()
    ..optionNoFlag = json['oNoFlagYn'].cast<String>()
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(ProductOptionGroupNewModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'shopCd': instance.shopCd,
      'name': instance.name,
      'minCnt': instance.minCnt,
      'multiCnt': instance.multiCnt,
      'useGbn': instance.useGbn,
      'addYn': instance.addYn,
      'optionName': instance.optionName,
      'optionCost': instance.optionCost,
      'oNoFlagYn': instance.optionNoFlag,
      'uCode': instance.uCode,
      'uName': instance.uName
    };

