class DashboardTotalOsModel {
  DashboardTotalOsModel();

  String? device_gbn = '';
  int? count = 0;
}
