class DashboardTotalCancelModel {
  DashboardTotalCancelModel();

  String? cancel_code = '';
  int? count = 0;
}
