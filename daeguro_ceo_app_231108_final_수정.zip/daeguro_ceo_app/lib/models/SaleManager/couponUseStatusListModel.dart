class CouponUseStatusListModel {
  CouponUseStatusListModel({
    this.rNum,
    this.couponDate,
    this.couponName,
    this.totalCount,
    this.totalUseCnt,
    this.totalUseAmt,
    this.couponTypeCnt,
    this.couponAmt,
    this.totalPubCnt,
    this.totalPubAmt,
    this.isChild = false,
  });
  bool selected = false;
  bool viewSelected = false;
  bool isChild = false;
  bool isOpened = false;

  String? rNum;
  String? couponDate;
  String? couponName;
  String? totalCount;
  String? totalUseCnt;
  String? totalUseAmt;
  String? couponTypeCnt;

  String? couponAmt;
  String? totalPubCnt;
  String? totalPubAmt;
}
