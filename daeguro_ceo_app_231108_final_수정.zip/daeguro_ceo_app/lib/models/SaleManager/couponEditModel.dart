import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CouponEditModel {
  CouponEditModel();

  String? jobGbn;
  String? shopCd;
  String? applyGbn;
  String? couponName;
  String? displayStDate;
  String? displayEndDate;
  List<String>? applyMinAmt;
  List<String>? couponAmt;
  String? expSetDate;
  String? useGbn;
  String? seq;
  String? couponType;
  String? uCode;
  String? uName;

  factory CouponEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

CouponEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return CouponEditModel()
    ..jobGbn = json['jobGbn']
    ..shopCd = json['shopCd']
    ..applyGbn = json['applyGbn']
    ..couponName = json['couponName']
    ..displayStDate = json['displayStDate']
    ..displayEndDate = json['displayEndDate']
    ..applyMinAmt = json['applyMinAmt'].cast<String>()
    ..couponAmt = json['couponAmt'].cast<String>()
    ..expSetDate = json['expSetDate']
    ..useGbn = json['useGbn']
    ..seq = json['seq']
    ..couponType = json['couponType']
    ..uCode = json['uCode']
    ..uName = json['uName'];
}

Map<String, dynamic> _$ModelToJson(CouponEditModel instance) =>
    <String, dynamic>{
      // 'selected': instance.selected,
      'jobGbn': instance.jobGbn,
      'shopCd': instance.shopCd,
      'applyGbn': instance.applyGbn,
      'couponName': instance.couponName,
      'displayStDate': instance.displayStDate,
      'displayEndDate': instance.displayEndDate,
      'applyMinAmt': instance.applyMinAmt,
      'couponAmt': instance.couponAmt,
      'expSetDate': instance.expSetDate,
      'useGbn': instance.useGbn,
      'seq': instance.seq,
      'couponType': instance.couponType,
      'uCode': instance.uCode,
      'uName': instance.uName
    };
