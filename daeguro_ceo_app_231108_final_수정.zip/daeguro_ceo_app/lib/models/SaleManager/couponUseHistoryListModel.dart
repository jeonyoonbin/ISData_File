class CouponUseHistoryListModel {
  CouponUseHistoryListModel({
    this.rNum,
    this.couponName,
    this.applyGbn,
    this.applyGbnName,
    this.couponAmt,
    this.useDate,
    this.orderNo,
    this.custNickName,
    this.isChild = false,
    this.isChild2 = false,
  });
  bool selected = false;
  bool viewSelected = false;
  bool isChild = false;
  bool isChild2 = false;
  bool isOpened = false;

  String? rNum;
  String? couponName = '';
  String? applyGbn = '';
  String? applyGbnName = '';
  String? couponAmt = '';
  String? useDate = '';
  String? orderNo = '';
  String? custNickName = '';
}
