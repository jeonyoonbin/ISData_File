import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class CouponListModel {
  CouponListModel({
    this.useGbn,
    this.isChild = false
  });

  bool isChild = false;
  bool? selected = false;
  String? rNum = '';
  String? seq = '';
  String? shopCd = '';
  String? couponType = '';
  String? applyGbn = '';
  String? couponName = '';
  String? displayStDate = '';
  String? displayEndDate = '';
  String? expSetDate = '';
  String? useGbn = '';
  String? status = '';
  String? couponNotice = '';
  String? couponAmt = '';
  String? tipFrStand = '';
  String? issueQnt = '';
  String? useQnt = '';
}