class RequestServiceDataModel {
  RequestServiceDataModel({
    this.groupCd,
    this.menuCd,
    this.imageName,
  });
  bool selected = false;

  String? shopCd;
  String? reason;

  String? first;
  String? second;
  String? third;

  String? groupCd;
  String? menuCd;
  String? imageName;
  String? menuName;
  String? image_url;
  String? beforeImageURL;
  String? afterImageUrl;
  String? afterImageURL;

  String? afterShopName;
  String? beforeShopName;
  String? afterMobile;
  String? beforeMobile;
  List<String>? fileNames = [];

  ////////////////////////////


  ////////////////////////////
  String? a_roadAdd;
  String? a_jibun;
  String? a_detail_address;
  String? a_lat;
  String? a_lon;
  String? a_SIDO;
  String? a_SIGUGUN;
  String? a_DONGMYUN;
  String? a_RI;
  String? a_ROAD_NAME;
  String? a_BUILDING_NUMBER;
  String? a_BUILDING_NAME;
  String? a_LAND_NUMBER;
  String? a_POSTAL_CODE;
  String? b_roadAdd;
  String? b_jibun;
  String? b_detail_address;
  String? b_lat;
  String? b_lon;
  String? b_SIDO;
  String? b_SIGUGUN;
  String? b_DONGMYUN;
  String? b_RI;
  String? b_ROAD_NAME;
  String? b_BUILDING_NUMBER;
  String? b_BUILDING_NAME;
  String? b_LAND_NUMBER;
  String? b_POSTAL_CODE;

////////////////////////////
}
