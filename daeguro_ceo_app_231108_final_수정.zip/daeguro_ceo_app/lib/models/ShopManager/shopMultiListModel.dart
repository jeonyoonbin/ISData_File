import 'package:daeguro_ceo_app/screen/ShopManager/shopRegistInfo_main.dart';

class ShopMultiListModel {
  ShopMultiListModel();
  String? shopCd = '';
  String? shopName = '';
  String? itemCd = '';
  String? itemCd2 = '';
  String? itemCd3 = '';
  String? absentYn = '';
  String? repYn = '';
}
