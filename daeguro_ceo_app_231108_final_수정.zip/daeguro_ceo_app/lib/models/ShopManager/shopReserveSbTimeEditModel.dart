import 'package:daeguro_ceo_app/models/ShopManager/shopOperateReserveTimeModel.dart';
import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopReserveSbTimeEditModel {
  ShopReserveSbTimeEditModel();

  String? dayGbn = '';
  String? openTime = '';
  String? closeTime = '';
  String? closeGbn = '';

  factory ShopReserveSbTimeEditModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopReserveSbTimeEditModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopReserveSbTimeEditModel()
    ..dayGbn = json['dayGbn'] as String
    ..openTime = json['openTime'] as String
    ..closeTime = json['closeTime'] as String
    ..closeGbn = json['closeGbn'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopReserveSbTimeEditModel instance) => <String, dynamic>{
  '"dayGbn"': '"${instance.dayGbn}"',
  '"openTime"': '"${instance.openTime}"',
  '"closeTime"': '"${instance.closeTime}"',
  '"closeGbn"': '"${instance.closeGbn}"',
};
