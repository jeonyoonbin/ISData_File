import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ShopReserveCasesPeopleModel {
  ShopReserveCasesPeopleModel();

  bool? selected = false;
  String? shopCd = '';
  String? ccCode = '';
  String? casesCnt = '';
  String? peopleCnt = '';
  String? userID = '';

  factory ShopReserveCasesPeopleModel.fromJson(Map<String, dynamic> json) =>
      _$ModelFromJson(json);

  Map<String, dynamic> toJson() => _$ModelToJson(this);
}

ShopReserveCasesPeopleModel _$ModelFromJson(Map<String, dynamic> json) {
  return ShopReserveCasesPeopleModel()
    ..shopCd = json['shopCd'] as String
    ..ccCode = json['ccCode'] as String
    ..casesCnt = json['casesCnt'] as String
    ..peopleCnt = json['peopleCnt'] as String
    ..userID = json['userID'] as String;
}

Map<String, dynamic> _$ModelToJson(ShopReserveCasesPeopleModel instance) => <String, dynamic>{
  'shopCd': instance.shopCd,
  'ccCode': instance.ccCode,
  'casesCnt': instance.casesCnt,
  'peopleCnt': instance.peopleCnt,
  'userID': instance.userID
};