import 'dart:convert';

import 'package:daeguro_ceo_app/models/Common/linkToModel.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:encrypt/encrypt.dart' as EncryptPack;
import 'package:crypto/crypto.dart' as CryptoPack;

class Utils {
  static bool loginState = false;
  static bool isFullScreen = false;

  static String REST_BASEURL = '';

  // static bool isMobile(BuildContext context) => MediaQuery.of(context).size.width < 850;
  // static bool isTablet(BuildContext context) => MediaQuery.of(context).size.width < 1366 && MediaQuery.of(context).size.width >= 850;
  // static bool isDesktop(BuildContext context) => MediaQuery.of(context).size.width >= 1366;


  static bool isMinimal(BuildContext context) => MediaQuery.of(context).size.width < 640;
  static bool isCompact(BuildContext context) => MediaQuery.of(context).size.width < 1008 && MediaQuery.of(context).size.width >= 640;
  static bool isOpen(BuildContext context) => MediaQuery.of(context).size.width >= 1008;

  //top, open, compact, minimal

  static setFullScreenState(bool state) {
    isFullScreen = state;
  }

  static bool getFullScreenState() {
    return isFullScreen;
  }

  static message(text, {durationSeconds = 3}) {
    //BotToast.showText(text: text, duration: Duration(seconds: durationSeconds));
  }

  static List getMCodeList(){
    return GetStorage().read('MCodeListinfo');
  }

  static String getDay(String code){
    String retDay = '';
    if (code == '1')        retDay = '일요일';
    else if (code == '2')        retDay = '월요일';
    else if (code == '3')        retDay = '화요일';
    else if (code == '4')        retDay = '수요일';
    else if (code == '5')        retDay = '목요일';
    else if (code == '6')        retDay = '금요일';
    else if (code == '7')        retDay = '토요일';

    return retDay;
  }

  // static isMenuDisplayTypeDrawer(BuildContext context) {
  //   LayoutController layoutController = Get.find();
  //   return layoutController.menuDisplayType == MenuDisplayType.drawer;
  // }

  static setLoginState(bool state) {
    loginState = state;
  }

  static String getUserID() {
    return GetStorage().read('logininfo')['id'];
  }

  // static setAppVersionInfo(String version) {
  //   GetStorage().write('appinfo', version);
  // }
  //
  // static String getAppVersionInfo() {
  //   return ServerInfo.APP_VERSION; //GetStorage().read('appinfo');
  // }

  static bool isLogin() {
    return loginState; //GetStorage().hasData(Constant.KEY_TOKEN);
  }

  static logout() {
    // GetStorage().remove(Constant.KEY_TOKEN);
    // GetStorage().remove(Constant.KEY_MENU_LIST);
    // GetStorage().remove(Constant.KEY_DICT_ITEM_LIST);

    // 기존 로그인 정보 삭제
    GetStorage().remove('logininfo');
  }

  static String? validatePassword(String value){
    if(value.isEmpty){
      //focusNode.requestFocus();
      return null;//'비밀번호를 입력하세요.';
    }
    else {
      Pattern pattern = r'^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?~^<>,.&+=])[A-Za-z\d$@$!%*#?~^<>,.&+=]{10,30}$';
      RegExp regExp = RegExp(pattern.toString());
      if(!regExp.hasMatch(value)){
        //focusNode.requestFocus();
        return '- 패스워드는 대소문자, 특수문자, 숫자 포함\n 최소10자 이상으로 입력하세요.';
      }
      else{
        return null;
      }
    }
  }

  static List<DropdownMenuItem> getPageRowList(){
    List<DropdownMenuItem> retList = [
      DropdownMenuItem(value: 15, child: Center(child: Text('15'))),
      DropdownMenuItem(value: 30, child: Center(child: Text('30'))),
      DropdownMenuItem(value: 50, child: Center(child: Text('50'))),
    ];

    return retList;
  }

  static bool isInt(String str) {
    if(str == null) {
      return false;
    }
    return int.tryParse(str) != null;
  }

  static bool isKorean(String str) {
    final regExp = RegExp('[가-힣]+');

    return regExp.hasMatch(str);

  }

  static bool validateNumber(String value, bool isValidated) {
    RegExp regExp = new RegExp(r'^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)$');
    if (value.length == 0) {
      return false;
    }
    else if (!regExp.hasMatch(value)) {
      return false;
    }
    return true;
  }

  static bool validateString(String value) {
    RegExp regExp = new RegExp(r'(^[a-zA-Z ]*$)');
    if (value.length == 0) {
      return false;
    }
    else if (!regExp.hasMatch(value)) {
      return false;
    }
    return true;
  }

  static String? getTimeFormat(String value) {
    if (value == null || value == '' || value == ' ')      return '';

    String? retStr = null;
    if (value.length == 3) {
      retStr = value.substring(0, 1) + ':' + value.substring(1, 3);
    }    else if (value.length == 4) {
      retStr = value.substring(0, 2) + ':' + value.substring(2, 4);
    } else if (value.length == 6) {
      retStr = value.substring(0, 2) + ':' + value.substring(2, 4) + ':' + value.substring(4, 6);
    }

    return retStr;
  }

  static String getNameAbsoluteFormat(String name, bool isValidated) {
    if (name == null || name == '' || name == ' ' || name == 'null') return '--';

    if (isValidated == false)
      return name;

    if (name.length < 3){
      return name;
    }

    String retStr = '';
    String firstName = ''; // 성
    String middleName = ''; // 이름 중간
    String lastName = ''; //이름 끝
    int lastNameStartPoint; // 이름 시작 포인터

    firstName = name.substring(0, 1);
    lastNameStartPoint = name.indexOf(firstName);
    if(name.trim().length > 2){
      middleName = name.substring(lastNameStartPoint + 1, name.trim().length-1);
      lastName = name.substring(lastNameStartPoint + (name.trim().length - 1), name.trim().length);
    }
    else{
      middleName = name.substring(lastNameStartPoint + 1, name.trim().length);
    }

    String makers = "";
    for(int i = 0; i < middleName.length; i++){
      makers += "*";
    }

    lastName = middleName.replaceAll(middleName, makers) + lastName;
    retStr = firstName + lastName;

    return retStr;
  }

  static String getNameFormat(String name, bool isValidated) {
    if (name == null || name == '' || name == ' ' || name == 'null') return '--';

    if (isValidated == false)
      return name;

    String retStr = '';
    String firstName = ''; // 성
    String middleName = ''; // 이름 중간
    String lastName = ''; //이름 끝
    int lastNameStartPoint; // 이름 시작 포인터

    if (validateString(name) == true){
      String nonMaskingPre = name.substring(0, name.length-3);
      String nonMaskingPost = name.substring(name.length-1, name.length);

      retStr += nonMaskingPre;
      retStr += '**';
      retStr += nonMaskingPost;

      return retStr;
    }

    if(name.length > 1){
      firstName = name.substring(0, 1);
      lastNameStartPoint = name.indexOf(firstName);
      if(name.trim().length > 2){
        middleName = name.substring(lastNameStartPoint + 1, name.trim().length-1);
        lastName = name.substring(lastNameStartPoint + (name.trim().length - 1), name.trim().length);
      }
      else{
        middleName = name.substring(lastNameStartPoint + 1, name.trim().length);
      }

      String makers = "";
      for(int i = 0; i < middleName.length; i++){
        makers += "*";
      }

      lastName = middleName.replaceAll(middleName, makers) + lastName;
      retStr = firstName + lastName;
    }
    else{
      retStr = name;
    }
    return retStr;
  }

  static String getEmailFormat(String value, bool isValidated) {
    if (value == null || value == '' || value == ' ' || value == 'null') return '';

    String retStr;

    if (value.contains('@') == false){
      return value;
    }

    List<String> splitStr = value.split('@');
    if (splitStr == null || splitStr.length == 0)
      return value;

    int len = splitStr[0].length;
    String maskingEmail = '';
    if (len > 3){
      maskingEmail += splitStr[0].substring(0,3);
      for (int i = 3; i<len; i++)
        maskingEmail+='*';
    }
    else{
      maskingEmail += splitStr[0].substring(0,1);
      for (int i = 1; i<len; i++)
        maskingEmail+='*';
    }

    retStr = maskingEmail + '@' + splitStr[1];

    return retStr;
  }


  static String getAddressFormat(String value, bool isValidated) {
    if (value == null || value == '' || value == ' ' || value == 'null') return '';

    String retStr = '';

    int maskingIndex = value.indexOf(RegExp(r'읍 |면 |동 |가 |리 |로 |길 '));

    if (maskingIndex <= 0 )
      return value;

    String nonMaskingStr = value.substring(0, maskingIndex+2);
    String MaskingStr = value.substring(maskingIndex+2, value.length);

    retStr += nonMaskingStr;
    for (int i = 0; i<MaskingStr.length; i++){
      retStr += '*';
    }

    return retStr;
  }

  static String getAddressEtcFormat(String value, bool isValidated) {
    if (value == null || value == '' || value == ' ' || value == 'null') return '';

    String retStr = '';

    int maskingLength = value.length;

    for (int i = 0; i<maskingLength; i++) {
      retStr += '*';
    }

    return retStr;
  }

  static String getBirthFormat(String value, bool isValidated) {
    if (value == null || value == '' || value == ' ' || value == 'null') return '';

    String retStr= '';

    if (value.length < 6)
      return value;

    // String nonMaskingStr = value.substring(0, value.length-2);
    // retStr =  nonMaskingStr+ '**';

    if (isValidated == false)        retStr = value.replaceAllMapped(RegExp(r'(\d{4})(\d{2})(\d+)'), (Match m) => "${m[1]}.${m[2]}.${m[3]}");
    else                            retStr = value.replaceAllMapped(RegExp(r'(\d{4})(\d{2})(\d+)'), (Match m) => "${m[1]}.${m[2]}.${'**'}");

    return retStr;
  }

  static String getAccountNoFormat(String value, bool isValidated) {
    if (value == null || value == '' || value == ' ' || value == 'null') return '';

    String retStr = '';

    if (value.length <= 4)
      return value;

    int maskingLength = value.length-4;

    String nonMaskingStr = value.substring(maskingLength, value.length);

    for (int i = 0; i<maskingLength; i++) {
      retStr += '*';
    }

    retStr += nonMaskingStr;

    return retStr;
  }

  static String getPhoneNumFormat(String value, bool isValidated) {
    if (value == null || value == '' || value == ' '  || value == 'null')      return '';

    String retStr = '';

    if (value.length == 8) {
      if (isValidated == false)        retStr = value.replaceAllMapped(RegExp(r'(\d{4})(\d+)'), (Match m) => "${m[1]}-${m[2]}");
      else                            retStr = value.replaceAllMapped(RegExp(r'(\d{4})(\d+)'), (Match m) => "${'****'}-${m[2]}");
    }
    else if (value.length == 10) {
      if (isValidated == false)        retStr = value.replaceAllMapped(RegExp(r'(\d{3})(\d{3})(\d+)'), (Match m) => "${m[1]}-${m[2]}-${m[3]}");
      else                            retStr = value.replaceAllMapped(RegExp(r'(\d{3})(\d{3})(\d+)'), (Match m) => "${m[1]}-${'***'}-${m[3]}");
    }
    else if (value.length == 11) {
      if (isValidated == false)        retStr = value.replaceAllMapped(RegExp(r'(\d{3})(\d{4})(\d+)'), (Match m) => "${m[1]}-${m[2]}-${m[3]}");
      else                            retStr = value.replaceAllMapped(RegExp(r'(\d{3})(\d{4})(\d+)'), (Match m) => "${m[1]}-${'****'}-${m[3]}");
    }
    else if (value.length == 12) {
      if (isValidated == false)        retStr = value.replaceAllMapped(RegExp(r'(\d{4})(\d{4})(\d+)'), (Match m) => "${m[1]}-${m[2]}-${m[3]}");
      else                            retStr = value.replaceAllMapped(RegExp(r'(\d{3})(\d{4})(\d+)'), (Match m) => "${m[1]}-${'****'}-${m[3]}");
    }
    else {
      if (isValidated == false)        retStr = value.replaceAllMapped(RegExp(r'(\d{3})(\d{3,4})(\d+)'), (Match m) => "${m[1]}-${m[2]}-${m[3]}");
      else                            retStr = value.replaceAllMapped(RegExp(r'(\d{3})(\d{3,4})(\d+)'), (Match m) => "${m[1]}-${'***'}-${m[3]}");
    }

    return retStr;
  }

  static String getYearMonthFormat(String value) {
    if (value == null || value == '' || value == ' ') return '';

    String retStr;

    retStr = value.replaceAllMapped(RegExp(r'(\d{4})(\d{2})'), (Match m) => "${m[1]}-${m[2]}");

    return retStr;
  }

  static String getYearMonthDayFormat(String value) {
    if (value == null || value == '' || value == ' ') return '';

    String retStr;

    retStr = value.replaceAllMapped(RegExp(r'(\d{4})(\d{2})(\d{2})'), (Match m) => "${m[1]}-${m[2]}-${m[3]}");

    return retStr;
  }

  static String getYearMonthDayTimeFormat(String value) {
    if (value == null || value == '' || value == ' ') return '';

    String retStr;

    retStr = value.replaceAllMapped(RegExp(r'(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})'), (Match m) => "${m[1]}-${m[2]}-${m[3]} ${m[4]}:${m[5]}");

    return retStr;
  }

  static String getStoreRegNumberFormat(String value, bool isValidated) {
    if (value == null || value == '' || value == ' ')      return '';

    String retStr;
    //retStr = value.replaceAllMapped(RegExp(r'(\d{3})(\d{2})(\d+)'), (Match m) => "${m[1]}-${m[2]}-${m[3]}");
    retStr = value.replaceAllMapped(RegExp(r'(\d{3})(\d{2})(\d+)'), (Match m) => "${m[1]}-${'**'}-${m[3]}");

    if (isValidated == false)
      return value.replaceAllMapped(RegExp(r'(\d{3})(\d{2})(\d+)'), (Match m) => "${m[1]}-${m[2]}-${m[3]}");

    return retStr;
  }

  static String getCashComma(String value) {
    if (value == null || value == '' || value == ' ' || value == 'null' || (isInt(value) == false)) return '0';

    int temp = int.parse(value);
    return new NumberFormat('###,###,###,###').format(temp).replaceAll(' ', '');
  }

  static String getCurrencyCashFormat(String value) {
    final formatCurrency = new NumberFormat.simpleCurrency(locale: 'ko_KR', name: '', decimalDigits: 0);

    return formatCurrency.format(value);
  }

  static String getDateFormat(String value){
    if (value == null || value == '' || value == ' ')      return '';

    String retStr = value.substring(0, 4) + '-' +
                  value.substring(4, 6) + '-'  +
                  value.substring(6, 8);

    return retStr;
  }

  // static String getTimeSet(String value){
  //   if (value == null || value == '' || value == ' ')
  //     return '--';
  //
  //   if(value == '0000')
  //     return '00:00';
  //
  //   int temp = int.parse(value);
  //   return new NumberFormat('##,##').format(temp).replaceAll(',', ':');
  // }

  // static toIconData(String icon) {
  //   // if (icon == null || icon == '') {
  //   //   return Icons.menu;
  //   // }
  //   // IconData iconData = IconData(int.parse(icon), fontFamily: 'MaterialIcons');
  //   return iconPackage[icon]; // ?? Icons.menu;
  // }

  static launchURL(url) async {
    if (await canLaunch(url)) {
      await launch(
          url,
          forceSafariVC: true, //true로 설정시, iOS 인앱 브라우저를 통해픈
          forceWebView: true, //true로 설정시, Android 인앱 브라우저를 통해 오픈
          headers: <String, String>{'my_header_key': 'my_header_value'},
      );
    }
    else {
      throw 'Web Request Fail $url';
    }
  }

  static int getTimeStamp() {
    return (DateTime.now().millisecondsSinceEpoch + DateTime.now().timeZoneOffset.inMilliseconds) ~/ 1000;
  }

  static bool fileExtensionCheck(String fileName){
    return (fileName.endsWith('png') == true || fileName.endsWith('jpg') == true || fileName.endsWith('jpeg') == true) ? false : true;
  }

  static String? requestAESEncrypt(String payload) {

    try{
      final key = EncryptPack.Key.fromUtf8('12345678901234567890123456789012');
      final iv = EncryptPack.IV.fromLength(16);
      final encrypter = EncryptPack.Encrypter(EncryptPack.AES(key, mode: EncryptPack.AESMode.cbc));

      String result = encrypter.decrypt64(payload, iv: iv);

      return result;
    } catch (e){

      return null;
    }
  }

  static dynamic? requestAESDecrypt(String payload) {
    try{
      String aes_key = "d25hbnNkbXNlb3JuZmhxb2VrZmRtc2VvcmRtZmhhYmM=";

      final key = EncryptPack.Key.fromBase64(aes_key);
      final iv = EncryptPack.IV.fromLength(16);

      final encrypter = EncryptPack.Encrypter(EncryptPack.AES(key, mode: EncryptPack.AESMode.cbc));
      dynamic result = encrypter.decrypt64(payload!, iv: iv);

      return result;

    } catch (e){
      return null;
    }

    return null;
  }

  // static _checkInternet() async {
  //   var listener = await ConnectionChecker()
  //       .getInstance()
  //       .setDuration(Duration(
  //     seconds: 1,
  //   ))
  //       .listener(
  //     connected: () {
  //       setState(() {
  //         _online = true;
  //       });
  //     },
  //     disconnected: () {
  //       setState(() {
  //         _online = false;
  //       });
  //     },
  //   );
  // }

  static List<List<String>> splitCSV(String csvStr){
    csvStr = csvStr.replaceAll('\r\n', '\n'); // convert CRLF to LF
    List<List<String>> list = [[]];
    int now = 0;
    for(int i = 0; i < csvStr.length; i++){
      if( csvStr[i] == '"' ){
        String s = "";
        int j = i+1;
        for( ; j < csvStr.length; j++){
          if( csvStr[j] == '"' ){
            j++;
            if( j >= csvStr.length ){
              return [];
            }
            bool breakSign = false;
            switch (csvStr[j]) {
              case '"': // just "
                s += '"';
                break;
              case ',': // cell ending
                list[now].add(s);
                breakSign = true;
                break;
              case '\n':  // cell ending and line ending
                list[now].add(s);
                list.add([]);
                now++;
                breakSign = true;
                break;
              default:
                return [];
            }
            if( breakSign ) break;
          }
          else{
            s += csvStr[j];
          }
        }
        i = j;
      }
      else{
        String s = "";
        int j = i;
        for( ; j < csvStr.length; j++){
          bool breakSign = false;
          switch (csvStr[j]) {
            case '"':
              j++;
              if( j >= csvStr.length ){
                return [];
              }
              if( csvStr[j] == '"' ){ // just "
                s += '"';
              }
              else{
                return [];
              }
              break;
            case ',': // cell ending
              list[now].add(s);
              breakSign = true;
              break;
            case '\n':  // cell ending and line ending
              list[now].add(s);
              list.add([]);
              now++;
              breakSign = true;
              break;
            default:
              s += csvStr[j];
          }
          if( breakSign ) break;
        }
        i = j;
      }
    }
    if( list.last.isEmpty ) list.removeAt(list.length-1);
    return list;
  }


}