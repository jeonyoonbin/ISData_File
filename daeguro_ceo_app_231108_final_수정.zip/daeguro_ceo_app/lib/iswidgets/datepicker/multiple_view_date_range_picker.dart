import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:flutter/material.dart';
import 'package:debounce_throttle/debounce_throttle.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import './model/date_range_type.dart';
import './utils/colors_utils.dart';
import './widgets/text_field_builder.dart';
import './widgets/wrap_text_button.dart';
import 'package:intl/intl.dart';

typedef SetDateActionCallback = Function({DateTime? startDate, DateTime? endDate});

class MultipleViewDateRangePicker extends StatefulWidget {
  final String cancelText;
  final String confirmText;
  final String? last5daysTitle;
  final String? last7daysTitle;
  final String? last30daysTitle;
  final String? last3monthsTitle;
  final String? lastYearTitle;
  final String? nowDayTitle;
  final SetDateActionCallback? setDateActionCallback;
  final DateRangePickerController? datePickerController;
  final TextEditingController? startDateInputController;
  final TextEditingController? endDateInputController;
  final DateTime? startDate;
  final DateTime? endDate;
  final DateTime? minDate;
  final List<Widget>? customDateRangeButtons;
  bool? futureDateRangeButtons;

  MultipleViewDateRangePicker({
    Key? key,
    this.confirmText = '선택',
    this.cancelText = '취소',
    this.last5daysTitle,
    this.last7daysTitle,
    this.last30daysTitle,
    this.last3monthsTitle,
    this.lastYearTitle,
    this.nowDayTitle,
    this.startDate,
    this.endDate,
    this.setDateActionCallback,
    this.datePickerController,
    this.startDateInputController,
    this.endDateInputController,
    this.customDateRangeButtons,
    this.minDate,
    this.futureDateRangeButtons,
  }) : super(key: key);

  @override
  State<MultipleViewDateRangePicker> createState() => _MultipleViewDateRangePickerState();
}

class _MultipleViewDateRangePickerState extends State<MultipleViewDateRangePicker> {
  final String dateTimePattern = 'yyyy-MM-dd';

  late DateRangePickerController _datePickerController;
  late TextEditingController _startDateInputController;
  late TextEditingController _endDateInputController;

  DateTime? _startDate, _endDate;
  late Debouncer _denounceStartDate, _denounceEndDate;

  // header(연도) 커스터마이징 추후 작업필요 https://www.syncfusion.com/kb/11427/how-to-customize-the-header-view-of-the-flutter-date-range-picker
  String? headerString = '03 2023';
  double cellWidth = 20;
  /////////////////////////

  @override
  void initState() {
    _datePickerController = widget.datePickerController ?? DateRangePickerController();
    _startDateInputController = widget.startDateInputController ?? TextEditingController();
    _endDateInputController = widget.endDateInputController ?? TextEditingController();
    _startDate = widget.startDate ?? DateTime.now();
    _endDate = widget.endDate ?? DateTime.now();
    _initDebounceTimeForDate();
    _updateDateTextInput();
    super.initState();
  }

  void _initDebounceTimeForDate() {
    _denounceStartDate = Debouncer<String>(const Duration(milliseconds: 300), initialValue: '');
    _denounceEndDate = Debouncer<String>(const Duration(milliseconds: 300), initialValue: '');

    _denounceStartDate.values.listen((value) => _onStartDateTextChanged(value));
    _denounceEndDate.values.listen((value) => _onEndDateTextChanged(value));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 500,
      width: 650,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(color: ColorsUtils.colorShadow, spreadRadius: 32, blurRadius: 32, offset: Offset.zero), BoxShadow(color: ColorsUtils.colorShadow, spreadRadius: 12, blurRadius: 12, offset: Offset.zero)]),
      child: Column(children: [
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(16.0),
                alignment: Alignment.centerLeft,
                child: Wrap(spacing: 10, runSpacing: 10, children: [if (widget.customDateRangeButtons != null) ...widget.customDateRangeButtons! else ...DateRangeType.values.map((dateRange) => WrapTextButton(dateRange.getTitle(last90daysTitle: widget.last3monthsTitle, last30daysTitle: widget.last30daysTitle, last7daysTitle: widget.last7daysTitle, last5daysTitle: widget.last5daysTitle, nowDayTitle: widget.nowDayTitle), onTap: () => _selectDateRange(dateRange, widget.futureDateRangeButtons))).toList()]),
              ),
            ],
          ),
        ),
        const Divider(color: ColorsUtils.colorDivider, height: 1),
        // Row(
        //   children: <Widget>[
        //     Container(
        //       height: cellWidth,
        //       width: cellWidth + 10,
        //     ),
        //     Container(
        //         width: cellWidth,
        //         height: cellWidth,
        //         color: Color(0xFFfa697c),
        //         child: IconButton(
        //           icon: Icon(Icons.arrow_left),
        //           color: Colors.white,
        //           iconSize: 20,
        //           highlightColor: Colors.lightGreen,
        //           onPressed: () {
        //             setState(() {
        //               _datePickerController.backward!();
        //             });
        //           },
        //         )),
        //     Container(
        //       color: Color(0xFFfa697c),
        //       height: cellWidth,
        //       width: cellWidth * 4.5,
        //       child: Text(headerString!,
        //           textAlign: TextAlign.center,
        //           style: TextStyle(
        //               fontSize: 25, color: Colors.white, height: 1.4)),
        //     ),
        //     Container(
        //         width: cellWidth,
        //         height: cellWidth,
        //         color: Color(0xFFfa697c),
        //         child: IconButton(
        //           icon: Icon(Icons.arrow_right),
        //           color: Colors.white,
        //           highlightColor: Colors.lightGreen,
        //           onPressed: () {
        //             setState(() {
        //               _datePickerController.forward!();
        //             });
        //           },
        //         )),
        //     Container(
        //       height: cellWidth,
        //       width: cellWidth,
        //     )
        //   ],
        // ),
        Expanded(
          child: Stack(children: [

            Positioned.fill(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: SfDateRangePicker(
                    minDate: widget.minDate,
                    controller: _datePickerController,
                    onSelectionChanged: _onSelectionChanged,
                    view: DateRangePickerView.month,
                    selectionMode: DateRangePickerSelectionMode.range,
                    initialDisplayDate: _startDate,
                    initialSelectedRange: PickerDateRange(_startDate, _endDate),
                    enableMultiView: true,
                    enablePastDates: true,
                    viewSpacing: 16,
                    headerHeight: 52,
                    //headerHeight: 0,
                    onViewChanged: viewChanged,
                    backgroundColor: Colors.white,
                    selectionShape: DateRangePickerSelectionShape.rectangle,
                    showNavigationArrow: true,
                    showTodayButton: false,
                    selectionColor: ColorsUtils.colorButton,
                    startRangeSelectionColor: ColorsUtils.colorButton,
                    endRangeSelectionColor: ColorsUtils.colorButton,
                    selectionRadius: 6,
                    yearCellStyle: const DateRangePickerYearCellStyle(
                        textStyle: TextStyle(fontFamily: FONT_FAMILY),
                        todayTextStyle: TextStyle(fontFamily: FONT_FAMILY)
                    ),
                    monthViewSettings: DateRangePickerMonthViewSettings(
                        dayFormat: _isVerticalArrangement(context) ? 'EE' : 'EEE',
                        firstDayOfWeek: 1,
                        viewHeaderHeight: 48,
                        viewHeaderStyle: const DateRangePickerViewHeaderStyle(
                            backgroundColor: Colors.white,
                            textStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: FONT_FAMILY)
                        )
                    ),
                    monthCellStyle: DateRangePickerMonthCellStyle(
                      cellDecoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(6)),
                      todayTextStyle: const TextStyle(color: ColorsUtils.colorButton, fontWeight: FontWeight.bold),
                      disabledDatesTextStyle: const TextStyle(color: ColorsUtils.colorButton, fontWeight: FontWeight.bold),
                    ),
                    headerStyle: const DateRangePickerHeaderStyle(
                        textAlign: TextAlign.center,
                        textStyle: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: FONT_FAMILY)
                    ),
                  ),
                )),
            const Center(child: VerticalDivider(color: ColorsUtils.colorDivider, width: 1)),
          ]),
        ),
        const Divider(color: ColorsUtils.colorDivider, height: 1),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 20),
          child: _buildBottomView(context),
        ),
      ]),
    );
  }

  Widget _buildBottomView(BuildContext context) {
    if (_isVerticalArrangement(context)) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          //   TextFieldBuilder(
          //     key: const Key('start_date_input'),
          //     textController: _startDateInputController,
          //     onTextChange: (value) {
          //       _denounceStartDate.value = value;
          //     },
          //     hintText: 'yyyy-MM-dd',
          //     keyboardType: TextInputType.number,
          //     inputFormatters: [
          //       DateInputFormatter(),
          //     ],
          //   ),
          //   const SizedBox(width: 12),
          //   const SizedBox(width: 12),
          //   TextFieldBuilder(
          //     key: const Key('end_date_input'),
          //     textController: _endDateInputController,
          //     onTextChange: (value) {
          //       _denounceEndDate.value = value;
          //     },
          //     hintText: 'yyyy-MM-dd',
          //     keyboardType: TextInputType.number,
          //     inputFormatters: [
          //       DateInputFormatter(),
          //     ],
          //   ),
          // ]),
          //const SizedBox(height: 16),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Expanded(
              child: WrapTextButton(
                widget.cancelText,
                maxWidth: 150,
                textStyle: const TextStyle(color: ColorsUtils.colorButton, fontWeight: FontWeight.w500, fontSize: 15),
                radius: 10,
                padding: const EdgeInsets.symmetric(horizontal: 34, vertical: 4),
                backgroundColor: ColorsUtils.colorButtonDisable,
                onTap: () => Navigator.of(context).pop(),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: WrapTextButton(
                widget.confirmText,
                textStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500, fontSize: 15),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
                radius: 10,
                backgroundColor: ColorsUtils.colorButton,
                onTap: () => widget.setDateActionCallback?.call(startDate: _startDate, endDate: _endDate ?? DateTime.now()),
              ),
            ),
          ])
        ],
      );
    } else {
      return Row(children: [
        // TextFieldBuilder(
        //   key: const Key('start_date_input'),
        //   textController: _startDateInputController,
        //   onTextChange: (value) {
        //     _denounceStartDate.value = value;
        //   },
        //   hintText: 'yyyy-MM-dd',
        //   keyboardType: TextInputType.number,
        //   inputFormatters: [
        //     DateInputFormatter(),
        //   ],
        // ),
        // const SizedBox(width: 12),
        // const SizedBox(width: 12),
        // TextFieldBuilder(
        //   key: const Key('end_date_input'),
        //   textController: _endDateInputController,
        //   onTextChange: (value) {
        //     _denounceEndDate.value = value;
        //   },
        //   hintText: 'yyyy-MM-dd',
        //   keyboardType: TextInputType.number,
        //   inputFormatters: [
        //     DateInputFormatter(),
        //   ],
        // ),
        const Spacer(),
        WrapTextButton(
          widget.cancelText,
          maxWidth: 150,
          textStyle: const TextStyle(color: ColorsUtils.colorButton, fontWeight: FontWeight.w500, fontSize: 15),
          radius: 10,
          padding: const EdgeInsets.symmetric(horizontal: 34, vertical: 4),
          backgroundColor: ColorsUtils.colorButtonDisable,
          onTap: () => Navigator.of(context).pop(),
        ),
        const SizedBox(width: 12),
        WrapTextButton(
          widget.confirmText,
          maxWidth: 150,
          textStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500, fontSize: 15),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
          radius: 10,
          backgroundColor: ColorsUtils.colorButton,
          onTap: () => widget.setDateActionCallback?.call(startDate: _startDate, endDate: _endDate ?? DateTime.now()),
        )
      ]);
    }
  }

  void viewChanged(DateRangePickerViewChangedArgs args) {
    final DateTime visibleStartDate = args.visibleDateRange.startDate!;
    final DateTime visibleEndDate = args.visibleDateRange. endDate!;
    final int totalVisibleDays = (visibleStartDate.difference(visibleEndDate).inDays);
    final DateTime midDate = visibleStartDate.add(Duration(days: totalVisibleDays ~/ 2));
    headerString = DateFormat('MMMM yyyy').format(midDate).toString();
    SchedulerBinding.instance!.addPostFrameCallback((duration) {
      setState(() {});
    });
  }

  void _onSelectionChanged(DateRangePickerSelectionChangedArgs args) {
    if (args.value is PickerDateRange) {
      _startDate = args.value.startDate;
      _endDate = args.value.endDate;
      _updateDateTextInput();
    }
  }

  void _onStartDateTextChanged(String value) {
    if (value.isNotEmpty && !value.contains('-')) {
      final startDate = DateFormat(dateTimePattern).parse(value);
      _startDate = startDate;
      _updateDatePickerSelection();
    }
  }

  void _onEndDateTextChanged(String value) {
    if (value.isNotEmpty && !value.contains('-')) {
      final endDate = DateFormat(dateTimePattern).parse(value);
      _endDate = endDate;
      _updateDatePickerSelection();
    }
  }

  void _selectDateRange(DateRangeType dateRangeType, bool? futureDateRangeButtons) {
    switch (dateRangeType) {
      case DateRangeType.last90days:
        final today = DateTime.now();
        final last90Days = today.subtract(const Duration(days: 90));
        final next90Days = today.add(const Duration(days: 90));
        if(futureDateRangeButtons != true){
          _startDate = last90Days;
          _endDate = today;
        } else {
          _startDate = today;
          _endDate = next90Days;
        }
        _updateDateTextInput();
        _updateDatePickerSelection();
        break;
      case DateRangeType.last30days:
        final today = DateTime.now();
        final last30Days = today.subtract(const Duration(days: 30));
        final next30Days = today.add(const Duration(days: 30));
        if(futureDateRangeButtons != true){
          _startDate = last30Days;
          _endDate = today;
        } else {
          _startDate = today;
          _endDate = next30Days;
        }
        _updateDateTextInput();
        _updateDatePickerSelection();
        break;
      case DateRangeType.last7days:
        final today = DateTime.now();
        final last7Days = today.subtract(const Duration(days: 7));
        final next7Days = today.add(const Duration(days: 7));
        if(futureDateRangeButtons != true){
          _startDate = last7Days;
          _endDate = today;
        } else {
          _startDate = today;
          _endDate = next7Days;
        }
        _updateDateTextInput();
        _updateDatePickerSelection();
        break;
      case DateRangeType.last5days:
        final today = DateTime.now();
        final last5Days = today.subtract(const Duration(days: 5));
        final next5Days = today.add(const Duration(days: 5));
        if(futureDateRangeButtons != true){
          _startDate = last5Days;
          _endDate = today;
        } else {
          _startDate = today;
          _endDate = next5Days;
        }
        _updateDateTextInput();
        _updateDatePickerSelection();
        break;
      case DateRangeType.thisMonth:
        final today = DateTime.now();
        final this1day = DateTime(today.year, today.month, 1);
        final thisEndDay = DateTime(today.year, today.month + 1, 0);
        if(futureDateRangeButtons != true){
          _startDate = this1day;
          _endDate = today;
        } else {
          _startDate = today;
          _endDate = thisEndDay;
        }
        _updateDateTextInput();
        _updateDatePickerSelection();
        break;
      case DateRangeType.nowDay:
        final today = DateTime.now();
        _startDate = today;
        _endDate = today;
        _updateDateTextInput();
        _updateDatePickerSelection();
        break;
    }
  }

  Future<void> _updateDatePickerSelection() async {
    _datePickerController.selectedRange = PickerDateRange(_startDate, _endDate);
    _datePickerController.displayDate = _startDate;
  }

  void _updateDateTextInput() {
    if (_startDate != null) {
      final startDateString = DateFormat(dateTimePattern).format(_startDate!);
      _startDateInputController.value = TextEditingValue(text: startDateString, selection: TextSelection(baseOffset: startDateString.length, extentOffset: startDateString.length));
    } else {
      _startDateInputController.clear();
    }
    if (_endDate != null) {
      final endDateString = DateFormat(dateTimePattern).format(_endDate!);
      _endDateInputController.value = TextEditingValue(text: endDateString, selection: TextSelection(baseOffset: endDateString.length, extentOffset: endDateString.length));
    } else {
      _endDateInputController.clear();
    }
  }

  bool _isVerticalArrangement(BuildContext context) => MediaQuery.of(context).size.width < 800;

  @override
  void dispose() {
    _denounceStartDate.cancel();
    _denounceEndDate.cancel();
    _startDateInputController.dispose();
    _endDateInputController.dispose();
    _datePickerController.dispose();
    super.dispose();
  }
}