import 'package:flutter/material.dart';

class ISButton extends StatelessWidget {

  final Widget? child;
  final bool? isReverseColor;
  final double? width;
  final double? height;
  final Color? buttonColor;
  final VoidCallback? onPressed;

  const ISButton({Key? key, this.child, this.isReverseColor = false, this.width = 64.0, this.height = 36.0, this.buttonColor = const Color(0xff01CAFF), this.onPressed,}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ButtonStyle(
        visualDensity: const VisualDensity(horizontal: -2, vertical: -2),
        minimumSize: MaterialStateProperty.all(Size(width!, height!)),
        foregroundColor: MaterialStateProperty.all(isReverseColor! ? buttonColor : Colors.white),
        shape: MaterialStatePropertyAll(
            RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4.0),
                side: BorderSide(color: buttonColor!, width: 0.5)
            ),
        ),
        backgroundColor: MaterialStateProperty.resolveWith((states) {
            if (states.contains(MaterialState.disabled)) {
              return Colors.grey;
            } else {
              return isReverseColor! ? Colors.white : buttonColor;//Colors.blue;
            }
          },
        ),
      ),
      child: child,
    );
  }
}
