
import 'package:flutter/material.dart';

class ISLabelBarMain extends StatelessWidget {
  //final String? label;
  final Widget? leading;
  final Widget? trailing;
  final bool? underLine;

  const ISLabelBarMain({Key? key, this.leading, this.trailing, this.underLine = true}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      alignment: Alignment.centerLeft,
      width: double.infinity,
      decoration: underLine == true ? const BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black)),
      ) : null,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              //Text(label!, style: const TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),),
              leading == null ? const SizedBox.shrink() : leading!,
              trailing == null ? const SizedBox.shrink() : trailing!,
            ],
          ),
      ),
    );
  }
}