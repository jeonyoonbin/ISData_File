﻿
import 'package:daeguro_ceo_app/common/constant.dart';
import 'package:daeguro_ceo_app/iswidgets/is_optionModel.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';

class ISSearchDropdown extends StatelessWidget {
  final double? width;
  final double? height;
  final String? label;
  final String? value;
  final ValueChanged? onChange;
  //final EdgeInsets? padding;
  final List<ISOptionModel>? item;
  final bool? ignoring;

  const ISSearchDropdown({Key? key, this.width, this.height, this.label, this.value, this.onChange/*, this.padding*/, this.item = const [], this.ignoring = false}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return (value == '' || value == null) ? SizedBox(
      width: width ?? 200,
      //height: height,
      child: IgnorePointer(
        ignoring: ignoring!,
        child: DropdownButtonFormField2(
          items: item?.map((v) {
            return DropdownMenuItem<String>(value: v.value.toString(), child: Text(v.label.toString(), style: const TextStyle(color: Colors.black, fontFamily: FONT_FAMILY)),);
          }).toList(),
          isExpanded: true,
          style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, color: ignoring == false ? Colors.black : Colors.black38, overflow: TextOverflow.ellipsis),
          decoration: InputDecoration(
            isDense: true,
            fillColor: Colors.white,
            filled: true,
            hintText: '    ${label!}',
            hintStyle: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, color: Colors.black54),
            contentPadding: EdgeInsets.zero,

            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Colors.black12),
              borderRadius: BorderRadius.circular(4.0),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Colors.black12, width: 1.4),
              borderRadius: BorderRadius.circular(4.0),
            ),
          ),

          buttonStyleData: ButtonStyleData(
            width: width,
            height: height ?? 48,
            overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
            padding: const EdgeInsets.symmetric(horizontal: 8.0,)
          ),
          // iconStyleData: IconStyleData(
          //   icon: Icon(Icons.arrow_drop_down, color: ignoring == false ? Colors.black : Colors.black38),
          //   iconSize: 24,
          // ),
          dropdownStyleData: DropdownStyleData(
            width: width,
            padding: EdgeInsets.zero,//const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(4.0),
            ),
          ),
          menuItemStyleData: const MenuItemStyleData(
            height: 36,
            padding: EdgeInsets.symmetric(horizontal: 16),
          ),
          // onChanged: (value) {
          //   if (onChange != null) {
          //     onChange!(value);
          //   }
          // },
        ),
      ),
    ) : SizedBox(
      width: width ?? 200,
      //height: height,
      child: IgnorePointer(
        ignoring: ignoring!,
        child: DropdownButtonFormField2(
          isExpanded: true,
          value: value,
          alignment: AlignmentDirectional.centerEnd,
          items: item?.map((v) {
            return DropdownMenuItem<String>(value: v.value.toString(), child: Text(v.label.toString(), style: const TextStyle(color: Colors.black, fontFamily: FONT_FAMILY)),);
          }).toList(),

          style: TextStyle(fontSize: 14, fontFamily: FONT_FAMILY, color: ignoring == false ? Colors.black : Colors.black38, overflow: TextOverflow.ellipsis),
          decoration: InputDecoration(
            isDense: true,
            fillColor: ignoring == true ? Colors.grey[200] : Colors.white,
            filled: true,
            hintText: '    ${label!}',
            hintStyle: const TextStyle(fontSize: 13, fontFamily: FONT_FAMILY, color: Colors.black54),
            contentPadding: EdgeInsets.zero,

            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Colors.black12),
              borderRadius: BorderRadius.circular(4.0),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Colors.black12, width: 1.4),
              borderRadius: BorderRadius.circular(4.0),
            ),
          ),

          buttonStyleData: ButtonStyleData(
              width: width,
              height: height ?? 48,
              overlayColor: MaterialStateProperty.resolveWith<Color>((Set<MaterialState> states) => Colors.transparent),
              padding: const EdgeInsets.symmetric(horizontal: 8.0,)
          ),
          iconStyleData: IconStyleData(
            icon: Icon(Icons.arrow_drop_down, color: ignoring == false ? Colors.black : Colors.black38),
            iconSize: 24,
          ),
          dropdownStyleData: DropdownStyleData(
            width: width,
            maxHeight: 180,
            openInterval: const Interval(0.0, 0.0),//fastOutSlowIn),
            padding: EdgeInsets.zero,//const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(4.0),
            ),
            scrollbarTheme: ScrollbarThemeData(
                thickness: MaterialStateProperty.all(6.0),
                //thumbColor: MaterialStateProperty.all(const Color(0xFFc1c1c1)),
                thumbVisibility: MaterialStateProperty.all((item!.length > 5) ? true : false)
            ),
          ),
          menuItemStyleData: const MenuItemStyleData(
            height: 36,
            padding: EdgeInsets.symmetric(horizontal: 16),
          ),
          onChanged: (value) {
            if (onChange != null) {
              onChange!(value);
            }
          },
        ),
      ),
    );

    // return (value == '' || value == null)
    //     ? Container(
    //   width: width,
    //   child: Container(
    //     //margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
    //     child: Wrap(
    //       children: [
    //         //Container(padding: EdgeInsets.fromLTRB(15, 5, 0, 0), height: 20, child: Text(label, style: TextStyle(fontSize: 10, color: Colors.black54))),
    //         Container(
    //             padding: padding ?? const EdgeInsets.fromLTRB(8, 0, 0, 0),
    //             height: 40,
    //             child: IgnorePointer(
    //               ignoring: ignoring ?? false,
    //               child: DropdownButtonFormField2 (
    //                 decoration: InputDecoration(
    //                   contentPadding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 10.0),
    //                   fillColor: Colors.grey[200],
    //                   filled: true,
    //                   labelText: label,
    //                   labelStyle: const TextStyle(color: Colors.black54, fontSize: 12),
    //                   border: const OutlineInputBorder(
    //                     borderSide: BorderSide.none,
    //                     borderRadius: BorderRadius.all(Radius.circular(6)),
    //                   ),
    //                 ),
    //                 itemHeight: 36,
    //                 itemPadding: const EdgeInsets.only(left: 16, right: 16),
    //                 dropdownPadding: const EdgeInsets.symmetric(vertical: 6),
    //                 dropdownDecoration: BoxDecoration(
    //                   borderRadius: BorderRadius.circular(6),
    //                 ),
    //                 style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, color: ignoring == false ? Colors.black : Colors.black38, overflow: TextOverflow.ellipsis),
    //                 isExpanded: true,
    //                 onChanged: (value) {
    //                   if (onChange != null) {
    //                     onChange!(value);
    //                   }
    //                 },
    //                 items: item,
    //               ),
    //             )),
    //       ],
    //     ),
    //   ),
    // )
    //     : Container(
    //   width: width,
    //   child: Container(
    //     //margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
    //     child: Wrap(
    //       children: [
    //         //Container(padding: EdgeInsets.fromLTRB(15, 5, 0, 0), height: 20, child: Text(label, style: TextStyle(fontSize: 10, color: Colors.black54))),
    //         Container(
    //             padding: padding ?? const EdgeInsets.fromLTRB(8, 0, 0, 0),
    //             height: 40,
    //             child: IgnorePointer(
    //               ignoring: ignoring!,
    //               child: DropdownButtonFormField2 (
    //                 icon: Icon(Icons.arrow_drop_down, size: 24, color: ignoring == false ? Colors.black : Colors.black38,),
    //                 decoration: InputDecoration(
    //                   contentPadding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 10.0),
    //                   fillColor: Colors.white,
    //                   filled: true,
    //                   hintText: label,
    //                   hintStyle: const TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, color: Colors.black54),
    //                   border: const OutlineInputBorder(
    //                     //borderSide: BorderSide.none,
    //                     borderRadius: BorderRadius.all(Radius.circular(6)),
    //                   ),
    //                 ),
    //                 itemHeight: 36,
    //                 itemPadding: const EdgeInsets.only(left: 16, right: 16),
    //                 dropdownPadding: const EdgeInsets.symmetric(vertical: 6),
    //                 dropdownDecoration: BoxDecoration(
    //                   borderRadius: BorderRadius.circular(6),
    //                 ),
    //                 style: TextStyle(fontSize: 12, fontFamily: FONT_FAMILY, color: ignoring == false ? Colors.black : Colors.black38, overflow: TextOverflow.ellipsis),
    //                 isExpanded: true,
    //                 value: value,
    //                 onChanged: (value) {
    //                   if (onChange != null) {
    //                     onChange!(value);
    //                   }
    //                 },
    //                 items: item,
    //               ),
    //             )),
    //       ],
    //     ),
    //   ),
    // );
  }
}
