﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using PosWebApp.jwt;
using PosWebApp.Models.RequestModel;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Helpers
{
    public class JwtMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly JwtAppSettings _appSettings;

        public JwtMiddleware(RequestDelegate next, IOptions<JwtAppSettings> appSettings)
        {
            _next = next;
            _appSettings = appSettings.Value;
        }

        public async Task Invoke(HttpContext context
#if JWT_TEST_CODE
            , ILoginService loginService
#endif
            )
        {
            var token = context.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            if(token != null)
            {
#if JWT_TEST_CODE
                attachUserToContext(context, loginService, token);
#endif
            }
            await _next(context);
        }
#if JWT_TEST_CODE
        private async void attachUserToContext(HttpContext context

            ,ILoginService loginService, string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                var jwtToken = (JwtSecurityToken)validatedToken;
                var userId = jwtToken.Claims.First(x => x.Type == "Id").Value;

                context.Items["User"] = await loginService.GetById(userId);
            }
            catch
            {

            }
        }
#endif
    }
}
