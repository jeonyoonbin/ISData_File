﻿using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.Reservation.Picture.Request;
using PosWebApp.Models.Reservation.Store.Request;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace PosWebApp.Services.Reservation
{
    public class ReservationService_T
    {
        private readonly HttpClient client;

        public ReservationService_T(HttpClient client, IConfiguration config)
        {
            this.client = client;
            this.client.BaseAddress = new Uri(config.GetValue<string>("api:Reservation_T"));
        }

        public async Task<Result<T>> Get<T>(string Url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);
                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<ResultSingle<T>> GetSingle<T>(string Url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);
                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ResultSingle<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<ResultArray<T>> GetArray<T>(string Url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);
                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ResultArray<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<ResultReservationCondition<T>> GetCondition<T>(string Url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);
                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ResultReservationCondition<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<Result<T>> Post<T, T2>(string url, T2 content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }


                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                var response = await client.PostAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    Result<T> t = new Result<T>();
                    t.code = "99";
                    t.msg = "인증되지 않은 사용자입니다.";
                    return t;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<Result<T>> Put<T>(string url)
        {
            try
            {
                if (url == null)
                {
                    return null;
                }
                var request = new HttpRequestMessage(HttpMethod.Put, url);
               // request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                var response = await client.PutAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<Result<T>> PutJson<T>(string url)
        {
            try
            {
                if (url == null)
                {
                    return null;
                }
                var request = new HttpRequestMessage(HttpMethod.Put, url);
                // request.Content = new StringContent("",Encoding.UTF8, "application/json");
                var response = await client.PutAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<Result<T>> PutImage<T, T2>(string url, RequestReservationImageInit content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                //string UrlResult = url + "?ccCode=" + content.ccCode +
                //            "&shopCode=" + content.shopCode.ToString();

                var request = new HttpRequestMessage(HttpMethod.Put, url);
                //request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");
                var formDataContent = new MultipartFormDataContent();
                byte[] data;
                using (var br = new BinaryReader(content.file.OpenReadStream()))
                {
                    data = br.ReadBytes((int)content.file.OpenReadStream().Length);
                }
                ByteArrayContent bytes = new ByteArrayContent(data);
                formDataContent.Add(new StringContent(content.ccCode), "ccCode");
                formDataContent.Add(new StringContent(content.shopCode), "shopCode");
                formDataContent.Add(bytes, "file", content.file.FileName);
                request.Content = formDataContent;
                var response = await client.PutAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }

        public async Task<Result<T>> PutPicture<T, T2>(string url, RequestReservationShopPictrue content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                //string UrlResult = url + "?ccCode=" + content.ccCode +
                //            "&shopCode=" + content.shopCode.ToString();

                var request = new HttpRequestMessage(HttpMethod.Put, url);
                //request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");
                var formDataContent = new MultipartFormDataContent();
                byte[] data;
                using (var br = new BinaryReader(content.file.OpenReadStream()))
                {
                    data = br.ReadBytes((int)content.file.OpenReadStream().Length);
                }
                ByteArrayContent bytes = new ByteArrayContent(content.imagebinary);
                formDataContent.Add(new StringContent(content.ccCode), "ccCode");
                formDataContent.Add(new StringContent(content.shopCd), "shopCode");
                formDataContent.Add(bytes, "file", content.file.FileName);
                formDataContent.Add(new StringContent(content.temaCode), "temaCode");

                request.Content = formDataContent;
                var response = await client.PutAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<Result<T>> Put<T, T2>(string url, T2 content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }


                var request = new HttpRequestMessage(HttpMethod.Put, url);
                request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                var response = await client.PutAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    Result<T> t = new Result<T>();
                    t.code = "99";
                    t.msg = "인증되지 않은 사용자입니다.";
                    return t;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<Result<T>> Delete<T, T2>(string url, T2 content)
        {
            try
            {
                if(content == null)
                {
                    return null;
                }
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Delete,
                    RequestUri = new Uri(client.BaseAddress.ToString() + url),
                    Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json")
                };

                //request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");



                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
    }
}
