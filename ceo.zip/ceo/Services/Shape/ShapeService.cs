﻿using Microsoft.Extensions.Options;
using PosWebApp.Models.Shape;
using PosWebApp.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

using System.Threading.Tasks;

namespace PosWebApp.Services.Shape
{
    public class ShapeService
    {
        private readonly HttpClient client;
        private readonly IOptions<ApiStrings> apiStrings;

        public ShapeService(HttpClient _client, IOptions<ApiStrings> apiStrings)
        {
            client = _client;
            this.apiStrings = apiStrings;
            client.BaseAddress = new Uri(apiStrings.Value.local);
        }



    }
}
