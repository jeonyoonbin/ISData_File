﻿using PosWebApp.Models.ResponseModel;
using System.Threading.Tasks;

namespace PosWebApp.Services.Addr
{
    public interface IAddressApi
    {
        Task<GovAddress> Get<T>(string Url, string parameters = null);
    }
}