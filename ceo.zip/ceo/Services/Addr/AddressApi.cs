﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PosWebApp.Services.Addr
{
    public class AddressApi : IAddressApi
    {
        private readonly HttpClient client;

        public AddressApi(HttpClient _client, IConfiguration config)
        {
            client = _client;
            client.BaseAddress = new Uri(config.GetValue<string>("api:address"));
            client.DefaultRequestHeaders.Add("Accept", "application/json");
            client.DefaultRequestHeaders.Add("User-Agent", "IsPosWebSettings");
        }

        public async Task<GovAddress> Get<T>(string Url, string parameters = null)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);

                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<GovAddress>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
    }
}
