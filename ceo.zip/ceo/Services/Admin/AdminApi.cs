﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.Images;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Services.Admin
{
    public class AdminApi
    {
        private readonly HttpClient client;

        public AdminApi(HttpClient _client, IConfiguration config)
        {
            client = _client;
            client.BaseAddress = new Uri(config.GetValue<string>("api:admin"));
            client.DefaultRequestHeaders.Add("Accept", "application/json");
            client.DefaultRequestHeaders.Add("User-Agent", "IsPosWebSettings");
        }

        /// <summary>
        /// Method Get
        /// </summary>
        /// <typeparam name="T">리턴 받을 데이터 타입</typeparam>
        /// <param name="Url"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<Result<T>> Get<T>(string Url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);

                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;

                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        /// <summary>
        /// Method Get
        /// </summary>
        /// <typeparam name="T">리턴 받을 데이터 타입</typeparam>
        /// <param name="Url"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<ResultSingle<T>> GetSingle<T>(string Url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);


                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ResultSingle<T>>(responseStream);

                    return temp;

                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        /// <summary>
        /// Method Post
        /// </summary>
        /// <typeparam name="T">리턴 받을 데이터 타입</typeparam>
        /// <typeparam name="T2">요청 데이터 모델</typeparam>
        /// <param name="url"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public async Task<Result<T>> Post<T, T2>(string url, T2 content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                var response = await client.PostAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        /// <summary>
        /// Method Post
        /// </summary>
        /// <typeparam name="T">리턴 받을 데이터 타입</typeparam>
        /// <typeparam name="T2">요청 데이터 모델</typeparam>
        /// <param name="url"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public async Task<Result<T>> Put<T, T2>(string url, T2 content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                var request = new HttpRequestMessage(HttpMethod.Put, url);
                request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                var response = await client.PutAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<Result<T>> PutImage<T, T2>(string url, RequestMenuImage content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                string UrlResult = url + "?menu_cd="+ content.menu_cd +
                            "&shop_cd="+ content.shop_cd.ToString() + 
                            "&cccode="+ content.cccode;

                var request = new HttpRequestMessage(HttpMethod.Put, UrlResult);
                //request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");
                var formDataContent = new MultipartFormDataContent();
                byte[] data;
                using(var br = new BinaryReader(content.formFile.OpenReadStream()))
                {
                    data = br.ReadBytes((int)content.formFile.OpenReadStream().Length);
                }
                ByteArrayContent bytes = new ByteArrayContent(data);
                formDataContent.Add(bytes, "formFile", content.formFile.FileName);
                request.Content = formDataContent;
                var response = await client.PutAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<Result<T>> Delete<T>(string Url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Delete, Url);


                var response = await client.DeleteAsync(request.RequestUri.ToString());

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;

                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
    }
}
