﻿using System.Net.Http;
using System.Threading.Tasks;

namespace PosWebApp.Services.DaeguroPos
{
    public interface IDaeguroService
    {
        HttpClient client { get; set; }

        Task<T> Post<T, T2>(string url, T2 content);
    }
}