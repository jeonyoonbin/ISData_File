﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Services.DaeguroPos
{
    public class DaeguroService : IDaeguroService
    {
        public HttpClient client { get; set; }
        private readonly string auth;
        public DaeguroService(HttpClient _client, IConfiguration config)
        {
            auth = config.GetValue<string>("daeguroPosAuth");
            client = _client;
            client.BaseAddress = new Uri(config.GetValue<string>("api:daguroPos"));
            client.DefaultRequestHeaders.Add("Accept", "application/json");
            client.DefaultRequestHeaders.Add("User-Agent", "IsPosWebSettings");
            if (!string.IsNullOrEmpty(auth))
            {
                client.DefaultRequestHeaders.Add("Authorization", auth);
            }
            
        }

        public async Task<T> Post<T, T2>(string url, T2 content)
        {

            var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

            var response = await client.PostAsync(request.RequestUri, request.Content);
            var readString = await response.Content.ReadAsStringAsync();

            var result = JsonConvert.DeserializeObject<T>(readString);

            return result;
        }
    }

}
