﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.Store.Image;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Services.StoreImage
{
    public class ShopStoreImageService
    {
        private readonly HttpClient client;

        public ShopStoreImageService(HttpClient client, IConfiguration config)
        {
            this.client = client;
            this.client.BaseAddress = new Uri(config.GetValue<string>("api:StoreImage"));
        }

        public async Task<Result<T>> Post<T>(string url, RequestStoreImage content, IFormFile iFile = null)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                var argument = new Dictionary<string, string>()
                {
                        { "div"      ,content.div  },
                        { "shop_cd"  ,content.shop_cd  },
                        { "image_gbn",content.image_gbn }
                };
                if (content.seqno != null)
                {
                    argument.Add("seqno", content.seqno);
                }
                var query = QueryHelpers.AddQueryString(url, argument);
               
                var request = new HttpRequestMessage(HttpMethod.Post, query);


                if(iFile != null)
                {
                    var formDataContent = new MultipartFormDataContent();
                    byte[] data;
                    using (var br = new BinaryReader(iFile.OpenReadStream()))
                    {
                        data = br.ReadBytes((int)iFile.OpenReadStream().Length);
                    }
                    ByteArrayContent bytes = new ByteArrayContent(data);
                    formDataContent.Add(bytes, "formFile", iFile.FileName);
                    request.Content = formDataContent;
                }
                else
                {
                    
                }

                //request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

               var response = await client.PostAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    Result<T> t = new Result<T>();
                    t.code = "99";
                    t.msg = "인증되지 않은 사용자입니다.";
                    return t;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<Result<T>> Put<T>(string url, RequestStoreImageV2 content, IFormFile iFile = null)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                var argument = new Dictionary<string, string>()
                {
                        { "div"  ,content.div  },
                        { "intro_cd",content.intro_cd },
                        { "sort",content.sort },
                        { "ucode","0" },
                        { "uname",content.uname },
                };
                var query = QueryHelpers.AddQueryString(url, argument);

                var request = new HttpRequestMessage(HttpMethod.Put, query);


                if (iFile != null)
                {
                    var formDataContent = new MultipartFormDataContent();
                    byte[] data;
                    using (var br = new BinaryReader(iFile.OpenReadStream()))
                    {
                        data = br.ReadBytes((int)iFile.OpenReadStream().Length);
                    }
                    ByteArrayContent bytes = new ByteArrayContent(data);
                    formDataContent.Add(bytes, "formFile", iFile.FileName);
                    request.Content = formDataContent;
                }
                else
                {

                }

                //request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                var response = await client.PutAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    Result<T> t = new Result<T>();
                    t.code = "99";
                    t.msg = "인증되지 않은 사용자입니다.";
                    return t;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<Result<T>> Get<T>(string Url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);

                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<Result<T>>(responseStream);

                    return temp;

                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
    }
}
