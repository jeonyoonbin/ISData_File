﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Services.ChangeRequest
{
    public class ChangeHistoryAPI
    {
        private readonly HttpClient client;

        public ChangeHistoryAPI(HttpClient _client, IConfiguration config)
        {
            client = _client;
            client.BaseAddress = new Uri(config.GetValue<string>("api:daegu"));
            client.DefaultRequestHeaders.Add("Accept", "application/json");
            client.DefaultRequestHeaders.Add("User-Agent", "IsPosWebSettings");
        }

        public async Task<T> Post<T, T2>(string url, T2 content)
        {

            var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

            var response = await client.PostAsync(request.RequestUri, request.Content);
            var readString = await response.Content.ReadAsStringAsync();

            var result = JsonConvert.DeserializeObject<T>(readString);

            return result;
        }
    }
}
