﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Services.ShopMall
{
    public class ShopMallService
    {
        public HttpClient client { get; set; }
        private readonly string auth;
        public ShopMallService(HttpClient _client, IConfiguration config, IHttpContextAccessor accessor)
        {
            auth = config.GetValue<string>("shopMall:mallkey");
            client = _client;
            client.BaseAddress = new Uri(config.GetValue<string>("api:shopMall"));
            client.DefaultRequestHeaders.Add("Accept", "application/json");
            client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", auth);
           
        }

        /// <summary>
        /// Method Post
        /// </summary>
        /// <typeparam name="T">요청 데이터 모델</typeparam>
        /// <param name="url"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public async Task<MallResult<T>> Post<T,T2>(string url, T2 content, string method)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }

                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");
                if (!client.DefaultRequestHeaders.Equals("method"))
                {
                    client.DefaultRequestHeaders.Remove("method");
                }
                client.DefaultRequestHeaders.Add("method", method);
                var response = await client.PostAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<MallResult<T>>(responseStream);

                    return temp;
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    MallResult<T> t = new MallResult<T>();
                    return t;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
    }

    
}
