﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.Review;
using PosWebApp.Models.Review.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Services.DgReview
{
    public class ReviewDaeguAPI
    {
        private readonly HttpClient client;

        public ReviewDaeguAPI(HttpClient _client, IConfiguration config, IHttpContextAccessor accessor)
        {
            client = _client;
            client.BaseAddress = new Uri(config.GetValue<string>("api:review_Daegu"));
            var bearerToken = accessor.HttpContext.Request.Headers["Authorization"].FirstOrDefault(h => h.StartsWith("bearer ", StringComparison.CurrentCultureIgnoreCase));
            bearerToken = accessor.HttpContext.Session.GetString("jwt_token");
            if (bearerToken != null)
            {
                _client.DefaultRequestHeaders.Add("Authorization", "bearer " + bearerToken);
            }
        }


        public async Task<ReviewResult<T>> Get<T>(string Url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);
                
                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ReviewResult<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }

        public async Task<ReviewListResult<T>> GetList<T>(string Url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, Url);

                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ReviewListResult<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        /// <summary>
        /// Method Post
        /// </summary>
        /// <typeparam name="T">리턴 받을 데이터 타입</typeparam>
        /// <typeparam name="T2">요청 데이터 모델</typeparam>
        /// <param name="url"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public async Task<ReviewResult<T>> Post<T, T2>(string url, T2 content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                var response = await client.PostAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ReviewResult<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<ReviewListResult<T>> PostList<T, T2>(string url, T2 content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                var response = await client.PostAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ReviewListResult<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<ReviewResult<T>> PostV2<T, T2>(string url, T2 content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                client.BaseAddress = new Uri("https://review.daeguro.co.kr:45008/");

                var response = await client.PostAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ReviewResult<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<ReviewResult<T>> Put<T, T2>(string url, T2 content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                var request = new HttpRequestMessage(HttpMethod.Put, url);
                request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");

                var response = await client.PutAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ReviewResult<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public async Task<ReviewResult<T>> Delete<T, T2>(string url, T2 content)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Delete,
                    RequestUri = new Uri(client.BaseAddress.ToString() + url),
                    Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json")
                };
                
                //request.Content = new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented), Encoding.UTF8, "application/json");




                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ReviewResult<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
    }
}
