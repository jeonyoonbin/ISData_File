﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.Review.Responses;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Services.DgReview
{
    public class ReviewApi
    {
        private readonly HttpClient client;
        /// <summary>
        /// 상용 버전 출시 때 아래 멤버 키를 반드시 받아야 한다.
        /// </summary>
        public string member_key { get; set; } = "daegu";

        public ReviewApi(HttpClient _client, IConfiguration config)
        {
            client = _client;
            client.BaseAddress = new Uri(config.GetValue<string>("api:review_running"));

            member_key = config.GetValue<string>("api:review_member_key");

            client.DefaultRequestHeaders.Add("member-key", member_key);
        }

        public void addToken(string auth)
        {
            if (!string.IsNullOrEmpty(auth) )
            {
                client.DefaultRequestHeaders.Add("Authorization", auth);
            }
        }

        /// <summary>
        /// Method Get
        /// </summary>
        /// <typeparam name="T">리턴 받을 데이터 타입</typeparam>
        /// <param name="Url"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<ReviewResponse<T>> Get<T>(string Url, string token = null, string parameters = null)
        {
            try
            {
                addToken(token);

                var request = new HttpRequestMessage(HttpMethod.Get, Url);

                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ReviewResponse<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }

        /// <summary>
        /// Method Post
        /// </summary>
        /// <typeparam name="T">리턴 받을 데이터 타입</typeparam>
        /// <typeparam name="T2">요청 데이터 모델</typeparam>
        /// <param name="url"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public async Task<ReviewResponse<T>> Post<T, T2>(string url, T2 content, string token = null)
        {
            try
            {
                if (content == null)
                {
                    return null;
                }

                addToken(token);

                var formDataContent = new MultipartFormDataContent();
                formDataContent.Add(new StringContent(url), "cmd");

                var aaa = JsonConvert.SerializeObject(content, Formatting.Indented);
                formDataContent.Add(new StringContent(JsonConvert.SerializeObject(content, Formatting.Indented)), "body");

                var request = new HttpRequestMessage(HttpMethod.Post, "Prod/review");
                request.Content = formDataContent;

                var response = await client.PostAsync(request.RequestUri, request.Content);

                if (response.IsSuccessStatusCode)
                {
                    var responseStream = await response.Content.ReadAsStringAsync();

                    var temp = JsonConvert.DeserializeObject<ReviewResponse<T>>(responseStream);

                    return temp;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }

    }
}
