﻿using Microsoft.Extensions.Options;
using PosWebApp.Models.GIS;
using PosWebApp.Settings;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace PosWebApp.Services.NaverGeoFence
{
    public class DawulService
    {
        private readonly HttpClient client;

        public DawulService(HttpClient client, IOptions<ApiStrings> api)
        {
            this.client = client;
            this.client.BaseAddress = new Uri(api.Value.daeguroPosAdminApi);
        }

        public async Task<NaverGISConverter> GetDawulUmdAsync(string sido, string sigungu, string umd)
        {
            var response = await client.PostAsJsonAsync("Dawul/Shape", new
            {
                sido = sido,
                sigungu = sigungu,
                umd = umd
            });

            if(response.IsSuccessStatusCode)
            {
                var responseString =  await response.Content.ReadAsStringAsync();
                NaverGISConverter convert = new NaverGISConverter(responseString);

                return convert;
            }

            return null;
        }
    }
}
