﻿using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.GeoFence;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace PosWebApp.Services.NaverGeoFence
{
    public class GeoFenceApi
    {
        private readonly HttpClient client;

        public GeoFenceApi(HttpClient client)
        {
            this.client = client;
        }


        public async Task<HttpResponseMessage> SetShopFenceNew(RequestSetShopFence info) => await client.PostAsJsonAsync("api/GeoFence/Shop/SetNew", info);

        public async Task<HttpResponseMessage> GetShopDeliveryFence(RequestSetShopFence info) => await client.PostAsJsonAsync("api/GeoFence/Shop/GetDeliveryFencce", info);

        public async Task<HttpResponseMessage> DeleteShopFenceNew(RequestDeleteShopArea info) => await client.PostAsJsonAsync("api/GeoFence/Shop/DeleteNew", info);

        public async Task<HttpResponseMessage> GetSequence(RequestSetShopFence info) => await client.PostAsJsonAsync("api/GeoFence/Shop/Seq", info);


        public async Task<HttpResponseMessage> SetCommonUmd(RequestSetCommonUmd info) => await client.PostAsJsonAsync("api/GeoFence/Comm/Set", info);

        public async Task<HttpResponseMessage> GetCommonUmd(RequestSetCommonUmd info) => await client.PostAsJsonAsync("api/GeoFence/Comm/Get", info);


        //public async Task<HttpResponseMessage> SetShopFence(RequestSetShopFence info) => await client.PostAsJsonAsync("api/GeoFence/Shop/Set", info);
        //public async Task<HttpResponseMessage> GetShopFence(RequestSetShopFence info) => await client.PostAsJsonAsync("api/GeoFence/Shop/Get", info);
        //public async Task<HttpResponseMessage> GetShopFenceNew(RequestSetShopFence info) => await client.PostAsJsonAsync("api/GeoFence/Shop/GetNew", info);
        //public async Task<HttpResponseMessage> DeleteShopFence(RequestDeleteShopArea info) => await client.PostAsJsonAsync("api/GeoFence/Shop/Delete", info);
        /*
        public async Task<Result<NaverGeoData>> GetNaverGeo(RequestNaverGeo info)
        {
            Result<NaverGeoData> result = new Result<NaverGeoData>();
            var response = await client.PostAsJsonAsync("api/GeoFence/Get", info);

            try
            {
                Debug.WriteLine(response.StatusCode);

                if (response.IsSuccessStatusCode)
                {
                    var contentString = await response.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<Result<NaverGeoData>>(contentString);

                    return result;
                }
                else
                {
                    result.code = response.StatusCode.ToString();
                    result.msg = response.ReasonPhrase;
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        public async Task<HttpResponseMessage> SetNaverGeo(RequestNaverGeo info) => await client.PostAsJsonAsync("api/GeoFence/Set", info);
        */
    }
}
