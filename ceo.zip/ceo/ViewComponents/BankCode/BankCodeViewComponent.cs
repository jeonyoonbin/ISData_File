﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Pos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.ViewComponents.BankCode
{
    public class BankCodeViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgShop;
        public BankCodeViewComponent(DgShopApiService api)
        {
            dgShop = api;
        }
        public async Task<IViewComponentResult> InvokeAsync(ShopAccountModel model, string bankCode, bool disabled = false)
        {
            var temp = await dgShop.Get<BankList>("BankList");

            var result = temp.data.Find(x => x.bankcode.Equals(bankCode));
            ViewBag.banklist = ViewBag.membership = new SelectList(temp.data, "bankcode", "bankname", bankCode);

            ViewData["Disabled"] = disabled;

            return View();
        }
    }
}
