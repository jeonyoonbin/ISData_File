﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Notice.Request;
using PosWebApp.ApiModels.Notice.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.ViewComponents
{
    public class BannerViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgShop;

        public BannerViewComponent(DgShopApiService api)
        {
            dgShop = api;
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {

            var req = await dgShop.Post<ResponseNoticeListV2, RequestNoticeV2>("/api/NoticeManagement/GetNoticeList_V2", new RequestNoticeV2
            {
                job_gbn = "11",
                noticeGbn = "4",
                dispGbn = "N",
                frDate = null,
                toDate = null
            });

            if (req.code.Equals("00"))
            {
                ViewBag.Banner = req.data;
                return View();
            }


            return View();
        }

    }
}
