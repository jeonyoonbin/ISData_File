﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Shop.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.ViewComponents
{
    [SessionDgShop]
    public class ChildrenSchoollunchViewComponent : ViewComponent
    {
        private readonly string flag;
        private readonly DgShopApiService dgShop;

        public ChildrenSchoollunchViewComponent(DgShopApiService api, IConfiguration config)
        {
            dgShop = api;
            flag = config.GetValue<string>("inspection:ChildrenFlag");
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var childrenYn = await dgShop.Post<ResponseChildren, PosWebApp.ApiModels.RequestCommon>("/api/shopManagement/GetChildrenSchoolLunch", new PosWebApp.ApiModels.RequestCommon
            {
                job_gbn = "",
                shop_cd = info.shop_cd,
                mcode = info.mcode
            });

            var childrenYnSingle = childrenYn.data.SingleOrDefault();
            if (childrenYnSingle.childrenYn == "Y")
            {
                ViewBag.childrenYnSingle = "Y";
                return View();
            }
            else
            {
                ViewBag.childrenYnSingle = childrenYnSingle.childrenYn;
                return View();
            }
            
            return View();
        }
    }
}
