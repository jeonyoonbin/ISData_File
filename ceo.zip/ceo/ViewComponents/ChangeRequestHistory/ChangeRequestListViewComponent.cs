﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.ChangeRequest.Request;
using PosWebApp.Models.ChangeRequest.Response;
using PosWebApp.Models.Common;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.ChangeRequestHistory.Index;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UAParser;

namespace PosWebApp.ViewComponents.ChangeRequestHistory
{
    public class ChangeRequestListViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgshop;
        public ChangeRequestListViewComponent(DgShopApiService dg)
        {
            dgshop = dg;
        }

        public async Task<IViewComponentResult> InvokeAsync(GetCommon param, int? pageNumber)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (pageNumber == null)
            {
                pageNumber = 1;
            }
            int pageSize = 10;

            var browser = HttpContext.Request.Headers["User-Agent"].ToString();
            var uaParser = Parser.GetDefault();
            ClientInfo c = uaParser.Parse(browser);

            string device = c.UA.Family;

            if (device.IndexOf("Mobile") > -1)
            {
                pageSize = 5;
            }
            RequestCommonAPI RSapi = new RequestCommonAPI(dgshop);
            var result = await RSapi.RequestServiceList(new RequestCommon
            {
                shop_cd = info.shop_cd,
                job_gbn = "1",
                status = param.type,
                service_gbn = param.request_type,
                from = param.from.Replace("-", ""),
                to = param.to.Replace("-", "")
            });


            if (!result.code.Equals("00"))
            {
                return View(PaginatedList<ResponseCommon>.Create(param.list.AsQueryable<ResponseCommon>(),
                pageNumber ?? 1, pageSize, param.type, param.request_type, param.options, param.from, param.to));
            }
            GetCommon common = new GetCommon();

            common.list = new List<ResponseCommon>();
            common.list = result.data;
            common.type = param.type;
            common.request_type = param.request_type;
            common.options = param.options;
            common.from = param.from;
            common.to = param.to;

           
            ViewBag.pageNumber = pageNumber;
            for (int i = 0; i < common.list.Count(); i++)
            {
                if (common.list[i].service_gbn.Equals("100"))
                {
                    common.list[i].after_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                    common.list[i].before_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                }
                else if (common.list[i].service_gbn.Equals("200"))
                {
                    common.list[i].after_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                    common.list[i].before_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                }
                else if (common.list[i].service_gbn.Equals("201"))
                {
                    common.list[i].after_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                    common.list[i].before_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                }
                else if (common.list[i].service_gbn.Equals("202"))
                {
                    common.list[i].after_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                    common.list[i].before_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                }
                else if (common.list[i].service_gbn.Equals("300"))
                {
                    common.list[i].after_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                    common.list[i].before_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                }
                else if (common.list[i].service_gbn.Equals("301"))
                {
                    common.list[i].after_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                    common.list[i].before_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                }
                else if (common.list[i].service_gbn.Equals("400"))
                {
                    common.list[i].after_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                    common.list[i].before_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                }
                else if (common.list[i].service_gbn.Equals("600")) 
                {
                    common.list[i].before_data = JsonConvert.DeserializeObject<ServiceCommon>(common.list[i].service_data);
                    List<kindSecond_Detail> resultSecondetail = new List<kindSecond_Detail>();

                    if(common.list[i].before_data.second.Length > 1)
                    {
                        var secondSplit = common.list[i].before_data.second.Split(",");

                        kindSecond_Detail detail = new kindSecond_Detail();
                        for (var s = 0; s < secondSplit.Length; s++)
                        {

                            if (secondSplit[s] == "1")
                            {
                                detail.menucost = "1";
                            }
                            else if (secondSplit[s] == "2")
                            {
                                detail.deliveryTip = "2";
                            }
                            else if (secondSplit[s] == "3")
                            {
                                detail.shopCoupon = "3";
                            }
                            else if (secondSplit[s] == "4")
                            {
                                detail.packSale = "4";
                            }
                            else if (secondSplit[s] == "5")
                            {
                                detail.dontExist = "5";
                            }
                        }
                        resultSecondetail.Add(detail);

                        common.list[i].before_data.seconDetail = resultSecondetail;
                    }
                    else
                    {
                        var secondSplit = common.list[i].before_data.second;

                        kindSecond_Detail detail = new kindSecond_Detail();
                        if (secondSplit == "1")
                        {
                            detail.menucost = "1";
                        }
                        else if (secondSplit == "2")
                        {
                            detail.deliveryTip = "2";
                        }
                        else if (secondSplit == "3")
                        {
                            detail.shopCoupon = "3";
                        }
                        else if (secondSplit == "4")
                        {
                            detail.packSale = "4";
                        }
                        else if (secondSplit == "5")
                        {
                            detail.dontExist = "5";
                        }
                        resultSecondetail.Add(detail);

                        common.list[i].before_data.seconDetail = resultSecondetail;
                    }
                }
                else if (common.list[i].service_gbn.Equals("601"))
                {

                }
                else
                {

                }
            }
            /*
             * Filter
             */

            /*type linq*/
            if (!param.type.Equals("%"))
                common.list = (List<ResponseCommon>)common.list.Where(x => x.status.Equals(common.type)).ToList();

            /*service linq*/
            if (!param.request_type.Equals("%"))
                common.list = (List<ResponseCommon>)common.list.Where(x => x.service_gbn.Equals(common.request_type)).ToList();


            ViewBag.getParamType = param.type;
            ViewBag.getParamRequestType = param.request_type;
            //if (temp.code == "00")
            //{
            //    //return View(temp.data);
            //    return View(PaginatedList<ResponseCommon>.Create(model.list.AsQueryable<ResponseCommon>(), pageNumber ?? 1, pageSize, from, to));

            //}
           
            return View(PaginatedList<ResponseCommon>.Create(common.list.AsQueryable<ResponseCommon>(),
                pageNumber ?? 1, pageSize, param.type, param.request_type, param.options, param.from, param.to));
        }
    }
}
