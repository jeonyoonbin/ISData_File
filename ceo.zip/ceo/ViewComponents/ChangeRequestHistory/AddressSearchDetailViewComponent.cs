﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.NaverGeocode;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static PosWebApp.Models.Naver.ResponseNaver;

namespace PosWebApp.ViewComponents.ChangeRequestHistory
{
    [SessionDgShop]
    public class AddressSearchDetailViewComponent : ViewComponent
    {
        private readonly NaverApi naverAPI;
        public AddressSearchDetailViewComponent(NaverApi api)
        {
            naverAPI = api;
        }
        public async Task<IViewComponentResult> InvokeAsync(string search)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(search))
            {
                ResponseNaverGeocode none = new ResponseNaverGeocode();
                ViewBag.result = none;
                return View();
            }

            var temp = await naverAPI.Geocoding(search);
            AddressTotal addressTotal = new AddressTotal();
            int i = 0;
            foreach (var item in temp.addresses)
            {
                var geo = item;

                var reverse = await naverAPI.ReverseGeocoding(Convert.ToDouble(geo.x), Convert.ToDouble(geo.y));

                var adm = reverse.results.Find(x => x.name.Equals("admcode"));
                var addr = reverse.results.Find(x => x.name.Equals("addr"));
                var legal = reverse.results.Find(x => x.name.Equals("legalcode"));
                var road = reverse.results.Find(x => x.name.Equals("roadaddr"));


                addressTotal.SIDO_NAME = addr.region.area1.name;
                addressTotal.SIGUNGU_NAME = addr.region.area2.name;
                addressTotal.DONG_NAME = addr.region.area3.name;
                addressTotal.HDONG_NAME = adm == null ? "" : adm.region.area3.name;
                addressTotal.RI_NAME = addr.region.area4.name;
                addressTotal.JIBUN_FIRST = addr.land.number1;
                addressTotal.JIBUN_SECOND = addr.land.number2;

                if (road != null)
                {
                    addressTotal.ROAD_NAME = road.land.name;
                    addressTotal.BLD_FIRST = road.land.number1;
                    addressTotal.BLD_SECOND = road.land.number2;
                    addressTotal.BLD_DETAILNAME = road.land.addition0.value;
                }
                else
                {
                    addressTotal.ROAD_NAME = string.Empty;
                    addressTotal.BLD_FIRST = string.Empty;
                    addressTotal.BLD_SECOND = string.Empty;
                    addressTotal.BLD_DETAILNAME = string.Empty;
                }

                addressTotal.LON = Convert.ToDouble(geo.x);
                addressTotal.LAT = Convert.ToDouble(geo.y);

                var umdr = addressTotal.RI_NAME.Length > 0 ? string.Join(' ', addressTotal.DONG_NAME, addressTotal.RI_NAME) : addressTotal.DONG_NAME;

                var master_sub = addressTotal.JIBUN_SECOND.Length > 0 ? string.Join('-', addressTotal.JIBUN_FIRST, addressTotal.JIBUN_SECOND) : addressTotal.JIBUN_FIRST;

                var build_master_sub = addressTotal.BLD_SECOND.Length > 0 ? string.Join('-', addressTotal.BLD_FIRST, addressTotal.BLD_SECOND) : addressTotal.BLD_FIRST;

                addressTotal.jibunAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    umdr,
                    master_sub);


                addressTotal.roadAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    addressTotal.ROAD_NAME,
                    build_master_sub
                    );

                temp.addresses[i].roadAddress = addressTotal.roadAddress;

                i++;
            }
            ViewBag.reuslt = temp;
            ViewBag.searchText = search;
            return View();
        }
    }
    
}
