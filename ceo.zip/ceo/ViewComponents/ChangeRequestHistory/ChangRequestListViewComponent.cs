﻿using Microsoft.AspNetCore.Mvc;
using PosWebApp.Database;
using PosWebApp.Models.ChangeRequest.Response;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.ChangeRequestHistory.Index;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UAParser;

namespace PosWebApp.ViewComponents.ChangeRequestHistory
{
    public class ChangRequestListViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgshop;
        public ChangRequestListViewComponent(DgShopApiService dg)
        {
            dgshop = dg;
        }

        public async Task<IViewComponentResult> InvokeAsync(GetCommon model, int? pageNumber)
        {

            if(pageNumber == null)
            {
                pageNumber = 1;
            }
            int pageSize = 5;

            var browser = HttpContext.Request.Headers["User-Agent"].ToString();
            var uaParser = Parser.GetDefault();
            ClientInfo c = uaParser.Parse(browser);

            string device = c.UA.Family;

            if (device.IndexOf("Mobile") > -1)
            {
                pageSize = 10;
            }

            ViewBag.getParamType = model.type;
            ViewBag.getParamRequestType = model.request_type;
            //if (temp.code == "00")
            //{
            //    //return View(temp.data);
            //    return View(PaginatedList<ResponseCommon>.Create(model.list.AsQueryable<ResponseCommon>(), pageNumber ?? 1, pageSize, from, to));

            //}
           
            return View(PaginatedList<ResponseCommon>.Create(model.list.AsQueryable<ResponseCommon>(),
                pageNumber ?? 1, pageSize, model.type, model.request_type, model.options, model.from, model.to));
        }
    }
}
