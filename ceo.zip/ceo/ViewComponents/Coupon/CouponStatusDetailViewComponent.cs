﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ApiModels.Coupon.Request;
using PosWebApp.ApiModels.Coupon.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Coupon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.ViewComponents.Coupon
{
    public class CouponStatusDetailViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgShop;
        public CouponStatusDetailViewComponent(DgShopApiService dgShop)
        {
            this.dgShop = dgShop;
        }

        public async Task<IViewComponentResult> InvokeAsync(string key)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var detail_result = await dgShop.Post<ResponseCouponStatus, RequestCouponStatus>("/api/CouponManagement/GetCouponStatusList", new RequestCouponStatus
            {
                job_gbn = "2",
                shop_cd = info.shop_cd,
                from = key.Replace("-", "")
            });

            List<CouponStatusDetail> list_detail = new List<CouponStatusDetail>();


            if (detail_result.code.Equals("00"))
            {
                for(var i = 0; i < detail_result.data.Count(); i++)
                {
                    for(var idx = 0; idx < detail_result.data[i].detail.Count(); idx++)
                    {
                        CouponStatusDetail statusDetail = new CouponStatusDetail()
                        {
                            couponDate = detail_result.data[i].detail[idx].couponDate,
                            couponName = detail_result.data[i].detail[idx].couponName,
                            couponAmt = detail_result.data[i].detail[idx].couponAmt,
                            totalUseAmt = detail_result.data[i].detail[idx].totalUseAmt,
                            totalUseCount = detail_result.data[i].detail[idx].totalUseCount,
                            totalPublishedCount = detail_result.data[i].detail[idx].totalPublishedCount,
                            totalPublishedAmt = detail_result.data[i].detail[idx].totalPublishedAmt,
                            useCouponAmt = detail_result.data[i].detail[idx].useCouponAmt,
                        };
                        //var publishedSumAmt = Convert.ToInt64(detail_result.data[i].detail[idx].totalPublishedCount);
                        var useSumAmt = Convert.ToInt64(detail_result.data[i].detail[idx].totalUseAmt);

                        statusDetail.totalAmt = useSumAmt * Convert.ToInt32(detail_result.data[i].detail[idx].totalUseCount);


                        list_detail.Add(statusDetail);
                    }
                }




                ViewBag.detail = list_detail;
            }
            else
            {
                ViewBag.detail = new List<CouponStatusDetail>();
            }

            return View();
        }
    }
}
