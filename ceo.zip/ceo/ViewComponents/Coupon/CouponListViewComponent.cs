﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ApiModels.Coupon.Request;
using PosWebApp.ApiModels.Coupon.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Coupon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.ViewComponents.Coupon
{
    public class CouponListViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgShop;
        /**
        쿠폰 관리 리스트
         */
        public CouponListViewComponent(DgShopApiService api)
        {
            dgShop = api;
        }
        public async Task<IViewComponentResult> InvokeAsync(CouponManagementViewModel result)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var req = await dgShop.Post<ResponseCoupon, RequestCoupon>("/api/CouponManagement/GetCouponManagement", new RequestCoupon
            {
                job_gbn = "",
                shop_cd = info.shop_cd,
                searchGbn = result.options == "4" ? "1" : result.searchGbn,
                from = string.IsNullOrEmpty(result.from) ? "" :  result.from.Replace("-",""),
                to = string.IsNullOrEmpty(result.to) ? "" : result.to.Replace("-", ""),
                useGbn = "%",
                status = result.eventGbn,
                pageCnt = result.pageCnt,
                pageNum = result.pageNum
            });
            

            if (req.code.Equals("00"))
            {
                ViewBag.TotalCnt = req.msg.Split(",")[0];
                ViewBag.couponList = req.data;
                ViewBag.pageNumber = result.pageNum;
            }
            else
            {
                ViewBag.TotalCnt = 0;
                ViewBag.pageNumber = 1;
                ViewBag.couponList = new List<ResponseCoupon>();
            }

            return View(result);
        }
    }
}
