﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ApiModels.Coupon.Request;
using PosWebApp.ApiModels.Coupon.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Coupon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.ViewComponents.Coupon
{
    public class CouponUseListViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgShop;
        public CouponUseListViewComponent(DgShopApiService dgShop)
        {
            this.dgShop = dgShop;
        }

        public async Task<IViewComponentResult> InvokeAsync(CouponeListViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var result = await dgShop.Post<ResponseCouponList, RequestCouponList>("/api/CouponManagement/GetCouponList", new RequestCouponList
            {
                shop_cd = info.shop_cd,
                searchGbn = model.searchGbn,
                packOrderGbn = model.packOrderGbn,
                from = model.from.Replace("-",""),
                to = model.to.Replace("-", ""),
                pageCnt = model.pageCnt,
                pageNum = model.pageNum,
                orderNo = model.orderNo
            });


            if (result.code.Equals("00"))
            {
                ViewBag.TotalCnt = result.msg.Split(',')[0];
                ViewBag.TotalCouponAmt = result.data.Sum(x => Convert.ToInt32(x.couponAmt.Replace(",", "")));
                ViewBag.CouponList = result.data;
            }
            else
            {
                ViewBag.TotalCnt = 0;
                ViewBag.TotalCouponAmt = 0;
                ViewBag.CouponList = new List<ResponseCouponList>();
            }

            return View(model);
        }
    }
}
