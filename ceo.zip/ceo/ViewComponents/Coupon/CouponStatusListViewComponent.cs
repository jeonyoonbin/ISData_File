﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ApiModels.Coupon.Request;
using PosWebApp.ApiModels.Coupon.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Coupon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.ViewComponents.Coupon
{
    public class CouponStatusListViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgShop;
        public CouponStatusListViewComponent(DgShopApiService dgShop)
        {
            this.dgShop = dgShop;
        }

        public async Task<IViewComponentResult> InvokeAsync(CouponStatusViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var result = await dgShop.Post<ResponseCouponStatus, RequestCouponStatus>("/api/CouponManagement/GetCouponStatusList", new RequestCouponStatus
            {
                job_gbn = "1",
                shop_cd = info.shop_cd,
                from = model.from.Replace("-",""),
                to = model.to.Replace("-", ""),
                pageCnt = model.pageCnt,
                pageNum = model.pageNum,
            });

            

            if (result.code.Equals("00"))
            {
                ViewBag.useCnt =string.IsNullOrEmpty(result.msg.Split(',')[3]) ? "0" : result.msg.Split(',')[3];//총 사용건
                ViewBag.couponCnt = result.msg.Split(',')[0]; //총 발급건
                ViewBag.TotalCouponAmt = result.msg.Split(',')[2];
                ViewBag.CouponList = result.data;
                ViewBag.pageNumber = model.pageNum;
            }
            else
            {
                ViewBag.useCnt = 0; //총 사용건
                ViewBag.couponCnt = 0; //총 발급건
                ViewBag.TotalCouponAmt = 0;
                ViewBag.pageNumber = 1;
                ViewBag.CouponList = new List<ResponseCouponStatus>();
            }

            return View(model);
        }
    }
}
