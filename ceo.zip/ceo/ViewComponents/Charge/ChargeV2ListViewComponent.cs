﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Charge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UAParser;

namespace PosWebApp.ViewComponents.Charge
{
    [SessionDgShop]
    public class ChargeV2ListViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgShop;

        public ChargeV2ListViewComponent(DgShopApiService api)
        {
            dgShop = api;
        }
        public async Task<IViewComponentResult> InvokeAsync(RequestShopSalesList model, int? pageNumber)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            SelectList type = new SelectList(getType(), "Value", "Text", "%");
            ViewBag.Type = type;

            SelectList packOrderYN = new SelectList(getPackOrderYN(), "Value", "Text", "%");
            ViewBag.packOrderYN = packOrderYN;

            SelectList memo = new SelectList(getMemo(), "Value", "Text", "%");
            ViewBag.memo = memo;


            RequestShopSalesList reqData = new RequestShopSalesList
            {
                cccode = info.cccode,
                from_date = model.from_date.Replace("-", ""),
                to_date = model.to_date.Replace("-", ""),
                job_gbn = ((int)SalesType.CHARGE).ToString(),
                shop_cd = info.shop_cd,
                pack_order_yn = model.pack_order_yn,
                memo_gbn = model.memo_gbn
            };
            

            if (pageNumber == null)
            {
                pageNumber = 1;
            }
            int pageSize = 10;
            var browser = HttpContext.Request.Headers["User-Agent"].ToString();
            var uaParser = Parser.GetDefault();
            ClientInfo c = uaParser.Parse(browser);

            string device = c.UA.Family;

            if (device.IndexOf("Mobile") > -1)
            {
                pageSize = 5;
            }
            switch (model.type_gbn)
            {
                case "%":
                    reqData.app_order_gbn = "%";
                    reqData.pay_gbn = "%";
                    reqData.charge_gbn = "1,3,K,P";
                    break;
                case "1":
                    reqData.app_order_gbn = "1";
                    reqData.pay_gbn = "%";
                    reqData.charge_gbn = "K,P";
                    break;
                case "5":
                    reqData.app_order_gbn = "5";
                    reqData.pay_gbn = "%";
                    reqData.charge_gbn = "K,P";
                    break;
                case "3":
                    reqData.app_order_gbn = "3";
                    reqData.pay_gbn = "%";
                    reqData.charge_gbn = "K,P";
                    break;
                case "7":
                    reqData.app_order_gbn = "3";
                    reqData.pay_gbn = "7";
                    reqData.charge_gbn = "K,P";
                    break;
                case "10":
                    reqData.charge_gbn = "3";
                    break;
                case "11":
                    reqData.app_order_gbn = "";
                    reqData.pay_gbn = "";
                    reqData.charge_gbn = "1";
                    break;

            }

            var ChargeReq = await dgShop.Post<ResponseShopSalesList, RequestShopSalesList>("/api/ShopManagement/Charge_v3", reqData);
            long moneySum = 0;
            long totaldeposit = 0;
            long totalwithdraw = 0;
            //filter 
            Result<ResponseShopSalesList> resultList = new Result<ResponseShopSalesList>();
            List<ResponseShopSalesList> ListData = new List<ResponseShopSalesList>();
            resultList = ChargeReq;
            if (!model.pack_order_yn.Equals("%"))
            {
                resultList.data = GetPackOrderList(resultList, model.pack_order_yn);
            }
            //ViewBag.ToTChargeMoney = 
            
            if (!string.IsNullOrEmpty(model.search))
            {
                resultList.data = SearchResult(resultList, model.search);
            }


            foreach (var item in resultList.data)
            {
                moneySum += Convert.ToInt64(item.total_amount == "" ? "0" : item.total_amount) + (Convert.ToInt64(item.transfer_amt == "" ? "0" : item.transfer_amt) * -1);
                totaldeposit += Convert.ToInt64(item.tot_amount == "" ? "0" : item.tot_amount);
                totalwithdraw += Convert.ToInt64(item.total_fee_amount) + Convert.ToInt64(item.delivery_total_amount) +  (Convert.ToInt64(item.transfer_amt) * -1);
            }
            ViewBag.Sum = Utils.NumberFormat(moneySum);
            ViewBag.deposit = Utils.NumberFormat(totaldeposit);
            ViewBag.withdraw = Utils.NumberFormat(totalwithdraw);
            ListData = resultList.data;

            if (model.memo_gbn.Equals("N"))
            {
                ListData = resultList.data.Where(x => x.memo.Contains("완료=>취소")).ToList();
            }
            else if (model.memo_gbn.Equals("Y"))
            {
                ListData = resultList.data.Where(x => x.memo.Equals("")).ToList();
            }
            else
            {

            }

            if (model.type_gbn == "10")
            {
                ViewBag.typeGbn = "10";
            } 
            else if(model.type_gbn == "11")
            {
                ViewBag.typeGbn = "11";
                ViewBag.chargeList = resultList.data.Where(x => x.admin_amt != "0").ToList();
            }
            else if(model.type_gbn == "%")
            {
                ViewBag.typeGbn = "%";
            }
            else {
                ViewBag.typeGbn = reqData.pay_gbn == "7" ? "7" : reqData.app_order_gbn;
            }
            ViewBag.packOrderGbn = reqData.pack_order_yn;
            ViewBag.memoGbn = model.memo_gbn;

            ViewBag.chargeList = SalesPagination<ResponseShopSalesList>.Create(ListData.AsQueryable<ResponseShopSalesList>(),
                pageNumber ?? 1, pageSize, model.from_date, model.to_date);

            return View(model);
        }
        //public List<ResponseShopChargeList> SelectResult(Result<ResponseShopChargeList> result, string selectKey)
        //{
        //    var Key = result.data;
        //    switch (selectKey)
        //    {
        //        case "all":
        //            Key.
        //            break;
        //        case "in":
        //            Key = "in";
        //            break;
        //        case "out":
        //            Key = "out";
        //            break;
        //        default:
        //            Key = "all";
        //            break;
        //    }
        //    return.Where(t => t.)
        //}
        public List<ResponseShopSalesList> SearchResult(Result<ResponseShopSalesList> result, string searchKey)
        {

            return result.data.Where(x => x.memo.Contains(searchKey)).ToList();

        }
        public List<ResponseShopSalesList> GetPackOrderList(Result<ResponseShopSalesList> result, string packOrderYN)
        {

            List<ResponseShopSalesList> resultList = new List<ResponseShopSalesList>();
           
            switch (packOrderYN)
            {
                case "%":
                    resultList =  result.data.ToList();
                    break;
                case "Y":
                    resultList = result.data.Where(x => x.pack_order_yn.Equals("Y")).ToList();
                    break;
                case "N":
                    resultList =  result.data.Where(x => x.pack_order_yn.Equals("N")).ToList();
                    break;
            }

            return resultList;

            //return result.data.Where(x => x.memo.Contains(searchKey)).ToList();

        }

        private List<SelectListItem> getType()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "만나서결제(현금)",
                Value = "1"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "만나서결제(카드)",
                Value = "5"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "앱결제",
                Value = "3"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "행복페이",
                Value = "7"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "출금 계좌이체",
                Value = "10"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "사입",
                Value = "11"
            });
            return temp;
        }
        private List<SelectListItem> getPackOrderYN()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "배달",
                Value = "N"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "포장",
                Value = "Y"
            });

            return temp;
        }
        private List<SelectListItem> getMemo()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "운영사 취소",
                Value = "N"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "완료",
                Value = "Y"
            });

            return temp;
        }
    }
}
