﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.ApiModels.Shop.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.ViewComponents.Charge
{
    public class ChargeShopMallDetailViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgShop;

        public ChargeShopMallDetailViewComponent(DgShopApiService api)
        {
            dgShop = api;
        }
        public async Task<IViewComponentResult> InvokeAsync(string from, string gbn)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            
            

            var ChargeReq = await dgShop.Post<ResponseChargeDetail, RequestChargeDetail>("/api/ShopManagement/shopMallChargeDetail", new RequestChargeDetail
            {
               cccode = info.cccode,
               shop_cd = info.shop_cd,
               from = from.Replace("-",""),
               io_gbn = gbn
            });

            if (ChargeReq.code.Equals("00"))
            {
                ViewBag.detail = ChargeReq.data;
            }
            else
            {
                ViewBag.datail = new List<ResponseChargeDetail>();
            }
            
            return View(ChargeReq);
        }
    }
}
