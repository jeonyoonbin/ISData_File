﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.ViewComponents.Charge
{
    public class ChargeShopMallListViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgShop;

        public ChargeShopMallListViewComponent(DgShopApiService api)
        {
            dgShop = api;
        }
        public async Task<IViewComponentResult> InvokeAsync(RequestShopSalesList model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestShopSalesList reqData = new RequestShopSalesList
            {
                cccode = info.cccode,
                from_date = model.from_date.Replace("-", ""),
                to_date = model.to_date.Replace("-", ""),
                job_gbn = ((int)SalesType.SHOPMALL).ToString(),
                shop_cd = info.shop_cd,
                pageNumber = model.pageNumber == 0  ? 1 : model.pageNumber
            };

            var ChargeReq = await dgShop.Post<ResponseShopSalesList, RequestShopSalesList>("/api/ShopManagement/shopMallChargeV4", reqData);
            long moneySum = 0;
            long totaldeposit = 0;
            long totalwithdraw = 0;

            foreach (var item in ChargeReq.data)
            {
                moneySum += Convert.ToInt64(item.charge_amt == "" ? "0" : item.charge_amt); //총 적립금
                totaldeposit += Convert.ToInt64(item.in_amt == "" ? "0" : item.in_amt);                                                                             //총 입
                totalwithdraw += Convert.ToInt64(item.out_amt == "" ? "0" : item.out_amt);
            }
            ViewBag.Sum = Utils.NumberFormat(moneySum);
            ViewBag.deposit = Utils.NumberFormat(totaldeposit);
            ViewBag.withdraw = Utils.NumberFormat(totalwithdraw);


            ViewBag.shopMallList = ChargeReq.data;

            var resultCnt = ChargeReq.msg.Split(",");

            ViewBag.Count = resultCnt[0];
            ViewBag.pageNumber = resultCnt[1];
            ViewBag.totalAmt = resultCnt[2];
            return View(model);
        }
    }
}
