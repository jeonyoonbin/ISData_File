﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Charge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.ViewComponents.Charge
{
    public class ChargeInOutListViewComponent : ViewComponent
    {
        private readonly DgShopApiService dgShop;

        public ChargeInOutListViewComponent(DgShopApiService api)
        {
            dgShop = api;
        }
        public async Task<IViewComponentResult> InvokeAsync(ChargeListViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestAccShopChargeList requestChargeList = new RequestAccShopChargeList()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                fr_date = model.from.Replace("-", ""),
                to_date = model.to.Replace("-", ""),
                charge_gbn = model.charge_gbn,
                io_gbn = model.io_gbn,
                job_gbn = model.job_gbn,
            };

            var chargeList = await dgShop.Post<ResponseShopChargeList, Request>("GetChargeList", requestChargeList);

            ViewBag.chargeList = chargeList.data;

            if (!string.IsNullOrEmpty(model.search))
            {
                ViewBag.chargeList = SearchResult(chargeList, model.search);
            }
            return View();
        }
        //public List<ResponseShopChargeList> SelectResult(Result<ResponseShopChargeList> result, string selectKey)
        //{
        //    var Key = result.data;
        //    switch (selectKey)
        //    {
        //        case "all":
        //            Key.
        //            break;
        //        case "in":
        //            Key = "in";
        //            break;
        //        case "out":
        //            Key = "out";
        //            break;
        //        default:
        //            Key = "all";
        //            break;
        //    }
        //    return.Where(t => t.)
        //}
        public List<ResponseShopChargeList> SearchResult(Result<ResponseShopChargeList> result, string searchKey)
        {

            return result.data.Where(t => t.memo.Contains(searchKey)).ToList();
            
        }
    }
}
