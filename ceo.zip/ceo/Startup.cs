using AspNetCoreHero.ToastNotification;
using AspNetCoreHero.ToastNotification.Extensions;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Helpers;
using PosWebApp.jwt;
using PosWebApp.Services.Addr;
using PosWebApp.Services.Admin;
using PosWebApp.Services.DaeguroPos;
using PosWebApp.Services.DgReview;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.NaverGeocode;
using PosWebApp.Services.NaverGeoFence;
using PosWebApp.Services.Reservation;
using PosWebApp.Services.ShopMall;
using PosWebApp.Services.StoreImage;
using PosWebApp.Settings;
using System;
using System.Text;

namespace PosWebApp
{
    public class Startup
    {
        private const string WebServer = "Webserver";
        //private const string AdminServer = "AdminServer";
        //private const string AdminServerTest = "AdminServerTest";
        //private const string AdminServerReal = "AdminServerReal";
        private string daeguroApi;

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            //Utils.oracleConnectString = configuration.GetValue<string>("database:testDb"); 
            Utils.oracleConnectString = configuration.GetValue<string>("database:testDb150");
              //Utils.oracleConnectString = configuration.GetValue<string>("database:IsDaegu");
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews().AddRazorRuntimeCompilation();
            //services.AddDistributedMemoryCache();     <== ��� ���� Ȯ�� �غ���

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("ShopApi", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "DgShop API",
                    Description = "�뱸 ������ ����� ����Ʈ API",
                    Contact = new Microsoft.OpenApi.Models.OpenApiContact
                    {
                        Name = "���� ����",
                        Email = string.Empty,
                        Url = new Uri(Configuration.GetValue<string>("api:daegu"))
                    }
                });
                //c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                //{
                //    In = ParameterLocation.Header,
                //    Description = "JWT with Bearer into field",
                //    Name = "Authorization",
                //    Type = SecuritySchemeType.ApiKey
                //});
                //c.AddSecurityRequirement(new OpenApiSecurityRequirement {
                //    {
                //     new OpenApiSecurityScheme
                //     {
                //         Reference = new OpenApiReference
                //         {
                //             Type = ReferenceType.SecurityScheme,
                //             Id = "Beaer"
                //         }
                //    },
                //    new string[] { }
                //}
                //});
            });

            services.Configure<DbStrings>(Configuration.GetSection("database"));
            services.Configure<ApiStrings>(Configuration.GetSection("api"));
           // services.Configure<JwtAppSettings>(Configuration.GetSection("AppSettings"));

            daeguroApi = Configuration.GetSection("api")["local"];

            services.AddDistributedMemoryCache();
            services.AddSession(options =>
            {
                 options.IdleTimeout = TimeSpan.FromHours(2);
                //options.IdleTimeout = TimeSpan.FromMinutes(3);
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
            });

            services.Configure<FormOptions>(options =>
            {
                options.ValueCountLimit = int.MaxValue;
                options.ValueLengthLimit = int.MaxValue;
            });
            //services.AddCors(options =>
            //{
            //    options.AddPolicy(name: WebServer, 
            //        builder =>
            //        {
            //            builder.WithOrigins("http://172.16.10.74:30001");
            //            builder.AllowAnyHeader();
            //        });
            //});
            services.AddNotyf(config =>
            {
                config.DurationInSeconds = 10;
                config.IsDismissable = true;
                config.Position = NotyfPosition.TopCenter;
            });


            services.AddBrowserDetection();
            //services.AddRazorPages();
            services.AddMvc(options =>
            {
                options.MaxModelBindingCollectionSize = int.MaxValue;
            }).SetCompatibilityVersion(Microsoft.AspNetCore.Mvc.CompatibilityVersion.Version_3_0);
            services.AddHttpContextAccessor();
            services.AddHttpClient<DgShopApiService>();
            services.AddHttpClient<AdminApi>();
            services.AddHttpClient<ReviewApi>();
            services.AddHttpClient<ReviewDaeguAPI>();
            services.AddHttpClient<ReviewDaeguAPI_T>();
            services.AddHttpClient<ReservationService_T>();
            services.AddHttpClient<ReservationService_Image>();
            services.AddHttpClient<ReservationReviewService>();
            services.AddHttpClient<SyncDaeguroPosService>();
            services.AddHttpClient<ShopStoreImageService>();
            services.AddHttpClient<ShopMallService>();

            services.AddHttpClient<IDaeguroService, DaeguroService>();
            services.AddHttpClient<GeoFenceApi>(client => client.BaseAddress = new Uri(daeguroApi));
            services.AddTransient<IDaeguDatabase, DaeguDatabase>();
            services.AddHttpClient<IAddressApi, AddressApi>();
            services.AddTransient<IUploadImage, UploadImage>();
            services.AddTransient<NaverApi>();
            
            services.AddHttpClient<DawulService>();


            //services.AddHttpsRedirection(options =>
            //{
                
            //    options.HttpsPort = 443;
            //});

#if JWT_TEST_CODE
            // jwt test code
            var key = Configuration.GetValue<string>("AppSettings:Secret");
            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;

           }).AddJwtBearer(x =>
           {
               x.RequireHttpsMetadata = false;
               x.SaveToken = true;
               x.TokenValidationParameters = new TokenValidationParameters
               {
                   ValidateIssuerSigningKey = true,
                   IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(key)),
                   ValidateIssuer = false,
                   ValidateAudience = false
               };
               x.Audience = "/Pos/login";
               
           });

            services.AddScoped<ILoginService, LoginService>();
            services.AddSingleton<IJwtAuthenticationManager>(new JwtAuthenticationManager(key));
#endif
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                //app.UseStatusCodePagesWithReExecute("/Error/{0}");
                //app.UseExceptionHandler("/Error/Error/404");
                //app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/ceo/swagger/ShopApi/swagger.json", "DgShop V1.0");
                    c.DefaultModelExpandDepth(-1);
                });
            }
            else
            {
                app.UseStatusCodePagesWithReExecute("/Error/{0}");

                //app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            //app.UseStatusCodePagesWithRedirects("/Error/{0}");

            app.UseStatusCodePagesWithRedirects("/Error/{0}");
           

            app.UseNotyf();
            app.UseHttpsRedirection();
            app.UseDefaultFiles();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseRouting();
            //app.UseRequestLocalization();
            app.UseCors(x => x.AllowAnyHeader().AllowAnyOrigin().AllowAnyMethod()
               );

            app.UseSession();

#if JWT_TEST_CODE
            //app.Use(async (context, next) =>
            //{
            //    var jwtToken = context.Session.GetString("jwt_token");
            //    if (!string.IsNullOrEmpty(jwtToken))
            //    {
            //        context.Request.Headers.Add("Authorization", string.Concat("Bearer ", jwtToken));
            //    }

            //    await next();
            //});
            app.UseMiddleware<JwtMiddleware>();
#endif
            //app.UseResponseCompression();
            //app.UseResponseCaching();
            //app.UseHttpContextItemsMiddleware();
            app.UseAuthentication();
            app.UseAuthorization();

            

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Pos}/{action=Login}");

                //endpoints.MapBlazorHub();
                //endpoints.MapFallbackToPage("/Host");
            });
        }
    }
}
