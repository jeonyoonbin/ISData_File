﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.ShopMall;
using PosWebApp.Common;
using PosWebApp.MallModel.Shop;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.ShopMall;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Mall
{
    [Route("/Mall/[controller]/[action]")]
    [SessionDgShop]
    public class Shop : Controller
    {
        private readonly ShopMallService shopMall;
        private readonly DgShopApiService dgshop;
        public Shop(ShopMallService shopMall, IConfiguration config, DgShopApiService dgShop)
        {
            
            this.shopMall = shopMall;
            this.dgshop = dgShop;
        }

        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (info.mallYN.Equals("N"))
            {

            }
            else
            {

            }
            //var userinfo = await dgshop.Post<ResponseUserInfo, ApiModels.ShopMall.RequestUserInfo>("/api/ApiManagement/GetUserInfo", new ApiModels.ShopMall.RequestUserInfo
            //{
            //    shop_cd = info.shop_cd,
            //    shop_id = info.shop_id
            //});

            //if (userinfo.code.Equals("00")){
                
            //}
            MallModel.Shop.RequestUserInfo user = new MallModel.Shop.RequestUserInfo();

            user.user_id = info.shop_id;

            //password Md5 Encrypt
            //Utils.SetMD5()


            ////var shop = await shopMall.Post<MallModel.Shop.RequestUserInfo>("/api/V1/users/exist/", user, "GET");


            //if (shop.Result.SingleOrDefault().result_info.code.Equals("1000"))
            //{
            //    //success
            //}
            //else
            //{
            //    //fail
            //}
            return View();
        }
        public async Task<IActionResult> Request()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Request(string password)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            return View();
        }
    }
}
