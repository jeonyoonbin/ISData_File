﻿namespace PosWebApp.MallModel.Shop
{
    public class RequestCurrentInfo
    {
        public string user_id { get; set; }
        public string password { get; set; }
        public string change_password { get; set; }
    }
}
