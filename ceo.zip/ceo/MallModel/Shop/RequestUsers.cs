﻿namespace PosWebApp.MallModel.Shop
{
    public class RequestUsers
    {
        public string user_id { get; set; }
        public string password { get; set; }
        public string user_name { get; set; }
        public string tel_no { get; set; }
        public string email { get; set; }
        public string memo { get; set; }
        public string fk_shop_cd { get; set; }
        public string sido { get; set; }
        public string gugun { get; set; }
        public string dong { get; set; }
        public string address { get; set; }
        public string address_detail { get; set; }
        public string address_lon { get; set; }
        public string address_lat { get; set; }

    }
}
