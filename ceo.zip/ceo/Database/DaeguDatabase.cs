﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using PosWebApp.Common;
using PosWebApp.Models.Event;
using PosWebApp.Models.Log.Request;
using PosWebApp.Models.MappApi;
using PosWebApp.Models.Operate.Request;
using PosWebApp.Models.OptionGroupOptions;
using PosWebApp.Models.OrderArea;
using PosWebApp.Models.Pos;
using PosWebApp.Models.RequestDaeguroPos;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.ViewModels.Pos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Database
{
    public class DaeguDatabase : IDisposable, IDaeguDatabase
    {
        private readonly string DbString;
        #region ctor
        public DaeguDatabase()
        {

        }

        public DaeguDatabase(string connectionString, IConfiguration configuration)
        {
            DbString = connectionString;
            //DbString = configuration.GetValue<string>("database:IsDaegu");
        }
        public void Dispose()
        {

        }
        #endregion

        #region Rest API

        #region Common

        /// <summary>
        /// 은행코드
        /// GET_BANK_LIST
        /// </summary>
        /// <returns></returns>
        public async Task<Result<BankList>> BankList()
        {
            Result<BankList> result = new Result<BankList>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM.GET_BANK_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<BankList> modelList = new List<BankList>();
                                while (reader.Read())
                                {
                                    BankList model = new BankList()
                                    {
                                        bankcode = reader["BANKCODE"].ToString(),
                                        bankname = reader["BANKNAME"].ToString(),
                                        bankname1 = reader["BANKNAME"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;

        }
        /// <summary>
        /// 가맹점 업종 코드
        /// </summary>
        /// <returns></returns>
        public async Task<Result<ShopBizItem>> ShopBizItemList()
        {
            Result<ShopBizItem> result = new Result<ShopBizItem>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM.GET_TIEM_MST_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopBizItem> modelList = new List<ShopBizItem>();
                                while (reader.Read())
                                {
                                    int.TryParse(reader["sort_seq"].ToString(), out int sortSeq);

                                    ShopBizItem model = new ShopBizItem()
                                    {
                                        item_cd = reader["item_cd"].ToString(),
                                        item_name = reader["item_name"].ToString(),
                                        sort_seq = sortSeq
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        public Result<TaxType> BizTaxType()
        {
            Result<TaxType> result = new Result<TaxType>();

            try
            {
                result.data = TaxType.GetTaxTypes().ToList();

                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        public async Task<ResultSingle<string>> GetSysDate()
        {
            ResultSingle<string> result = new ResultSingle<string>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.GET_SYS_DATE",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_date", OracleDbType.Varchar2, 24)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                        result.data = cmd.Parameters["out_ret_date"].Value.ToString();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        #endregion

        #region 주소
        public async Task<Result<Sido>> GetSido()
        {
            Result<Sido> result = new Result<Sido>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.GET_SIDO_SEARCH_DAWUL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            List<Sido> modelList = new List<Sido>();
                            while (reader.Read())
                            {
                                Sido model = new Sido()
                                {
                                    b_code = reader["b_code"].ToString(),
                                    lat = reader["lat"].ToString(),
                                    lon = reader["lon"].ToString(),
                                    sido = reader["b_large"].ToString(),
                                };
                                modelList.Add(model);
                            }

                            result.data = modelList;
                            result.code = "00";
                            result.msg = "성공";
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        public async Task<Result<Gungu>> GetSigungu(RequestSigungudong info)
        {
            Result<Gungu> result = new Result<Gungu>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.GET_GUNGU_SEARCH_DAWUL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            List<Gungu> modelList = new List<Gungu>();
                            while (reader.Read())
                            {
                                Gungu model = new Gungu()
                                {
                                    b_code = reader["b_code"].ToString(),
                                    sigungu = reader["b_middle"].ToString(),
                                    h_code = reader["b_code"].ToString(),
                                    //sido reader["b_code"].ToString(),
                                };
                                modelList.Add(model);
                            }

                            result.data = modelList;
                            result.code = "00";
                            result.msg = "성공";
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        public async Task<Result<HDong>> GetHdong(RequestSigungudong info)
        {
            Result<HDong> result = new Result<HDong>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.GET_DONG_SEARCH_NEW_DAWUL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                        cmd.Parameters.Add(new OracleParameter("in_gungu", OracleDbType.Varchar2)).Value = info.sigungu;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            List<HDong> modelList = new List<HDong>();
                            while (reader.Read())
                            {
                                string hsmall = reader["h_small"].ToString();
                                if (hsmall.Length > 0)
                                {
                                    HDong model = new HDong()
                                    {
                                        lat = reader["lat"].ToString(),
                                        lon = reader["lon"].ToString(),
                                        sido = reader["h_large"].ToString(),
                                        sigungu = reader["h_middle_origin"].ToString(),
                                        humdr = reader["h_small"].ToString(),
                                        h_code = reader["h_code"].ToString(),
                                    };
                                    modelList.Add(model);
                                }

                            }

                            result.data = modelList;
                            result.code = "00";
                            result.msg = "성공";
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        public async Task<Result<HDong>> GetUmdrB(RequestSigungudong info)
        {
            Result<HDong> result = new Result<HDong>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "JWCHO_TEST_PACKAGE.GET_DAWUL_BDONG",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                        cmd.Parameters.Add(new OracleParameter("in_gungu", OracleDbType.Varchar2)).Value = info.sigungu;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<HDong> modelList = new List<HDong>();
                                while (await reader.ReadAsync())
                                {
                                    HDong model = new HDong()
                                    {
                                        sido = reader["b_large"].ToString(),
                                        sigungu = reader["b_middle_origin"].ToString(),
                                        b_code = reader["b_code"].ToString(),
                                        b_name = reader["b_small"].ToString(),
                                        b_ri_name = reader["b_detail"].ToString(),
                                        lon = reader["lat_grs80"].ToString(),
                                        lat = reader["lon_grs80"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


            return result;
        }
        public async Task<Result<HDong>> GetUmdrH(RequestSigungudong info)
        {
            Result<HDong> result = new Result<HDong>();

            using (OracleConnection conn = new OracleConnection(DbString))
            {
                await conn.OpenAsync();
                using (OracleCommand cmd = new OracleCommand()
                {
                    Connection = conn,
                    CommandText = "JWCHO_TEST_PACKAGE.GET_DAWUL_HDONG",
                    CommandType = CommandType.StoredProcedure
                })
                {
                    cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                    cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                    cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                    cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                    cmd.Parameters.Add(new OracleParameter("in_gungu", OracleDbType.Varchar2)).Value = info.sigungu;
                    cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        if (code.Equals("00"))
                        {
                            List<HDong> modelList = new List<HDong>();
                            while (await reader.ReadAsync())
                            {
                                HDong model = new HDong()
                                {
                                    sido = reader["h_large"].ToString(),
                                    sigungu = reader["h_middle_origin"].ToString(),
                                    h_name = reader["h_small"].ToString(),
                                    lat = reader["lon_grs80"].ToString(),
                                    lon = reader["lat_grs80"].ToString()
                                };
                                modelList.Add(model);
                            }
                            result.data = modelList;
                        }
                        result.code = code;
                        result.msg = message;
                    }
                }
            }
            return result;
        }
        #endregion

        #region 출금
        /// <summary>
        /// 가맹점 출금 유무 및 가맹점 계좌/예금주 확인 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ResponseShopAccountInfo>> GetShopAccountInfo(Request info)
        {
            Result<ResponseShopAccountInfo> result = new Result<ResponseShopAccountInfo>();

            try
            {
                using (OracleConnection connection = new OracleConnection(DbString))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = connection,
                        CommandText = "PKG_IS_WEB_SHOP_V3.GET_SHOP_ACCOUNT_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            List<ResponseShopAccountInfo> modelList = new List<ResponseShopAccountInfo>();
                            if (code.Equals("00"))
                            {
                                while (await reader.ReadAsync())
                                {
                                    ResponseShopAccountInfo model = new ResponseShopAccountInfo()
                                    {
                                        account_info = reader["계좌정보"].ToString(),
                                        account_no = reader["계좌번호"].ToString(),
                                        account_owner = reader["예금주"].ToString(),
                                        bank_code = reader["은행코드"].ToString(),
                                        confirm_gbn = reader["acc_confirm_gbn"].ToString(),
                                        remain_amt = reader["적립금잔액"].ToString(),
                                        transfering_amt = reader["이체요청중인금액"].ToString(),
                                        transfer_sms_gbn = reader["amt_trans_sms_gbn"].ToString(),
                                        real_remain_amt = reader["real_remain_amt"].ToString(),
                                        bank_name = reader["bankname"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        /// <summary>
        /// 예금주 확인 조회가 "N"일 경우 예금주 확인 및 결과 등록
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<CodeMsg> SetAccConfirmGbn(RequestSetAccConfirmGbn info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.SET_SHOP_ACC_CONFIRM_GBN",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_acc_confirm_gbn", OracleDbType.Varchar2)).Value = info.in_acc_confirm_gbn;
                        cmd.Parameters.Add(new OracleParameter("out_rtn_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_rtn_mesg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();
                        string code = cmd.Parameters["out_rtn_code"].Value.ToString();
                        string message = cmd.Parameters["out_rtn_mesg"].Value.ToString();

                        result.code = code;
                        result.msg = message;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 출금 시 SMS 인증 요청
        /// 이거 어디감 ?
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<CodeMsg> SetTransferSmsCheck(RequestSmsCheck info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                using (OracleConnection connection = new OracleConnection(DbString))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = connection,
                        CommandText = "PKG_IS_API_POS.SET_SHOP_TRANS_SMS_CHK",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_sms_conf_no", OracleDbType.Varchar2)).Value = info.sms_conf_no;
                        cmd.Parameters.Add(new OracleParameter("rtn_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("rtn_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["rtn_code"].Value.ToString();
                        result.msg = cmd.Parameters["rtn_msg"].Value.ToString();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 사입출금/이체시 sms 인증 추가
        /// 1 출금 가능 여부 확인
        /// 3 SMS 인증 번호 확인
        /// 5 SMS 인증 번호 발송 요청
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<CodeMsg> GetShopTransSmsCheck(RequestTransSmsCheck info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.GET_SHOP_TRANS_SMS_CHK",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_sms_conf_no", OracleDbType.Varchar2)).Value = info.sms_no;
                        cmd.Parameters.Add(new OracleParameter("rtn_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("rtn_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["rtn_code"].Value.ToString();
                        result.msg = cmd.Parameters["rtn_msg"].Value.ToString();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 적립금 내역 조회 1: 리스트 조회, 3: 적립 내역, 9: 적립금 구분 코드
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ResponseShopChargeList>> GetShopInfoChargeList(RequestAccShopChargeList info)
        {
            Result<ResponseShopChargeList> result = new Result<ResponseShopChargeList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.GET_SHOP_INFOCHARGE_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_fr_dt", OracleDbType.Varchar2)).Value = info.fr_date;
                        cmd.Parameters.Add(new OracleParameter("in_to_dt", OracleDbType.Varchar2)).Value = info.to_date;
                        cmd.Parameters.Add(new OracleParameter("in_io_gbn", OracleDbType.Varchar2)).Value = info.io_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_charge_gbn", OracleDbType.Varchar2)).Value = info.charge_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_memo", OracleDbType.Varchar2)).Value = info.memo;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseShopChargeList> modelList = new List<ResponseShopChargeList>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseShopChargeList model = new ResponseShopChargeList()
                                    {
                                        seqno = reader["seqno"].ToString(),
                                        mcode = reader["mcode"].ToString(),
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        order_date = reader["order_date"].ToString(),
                                        order_no = reader["order_no"].ToString(),
                                        charge_date = reader["charge_date"].ToString(),
                                        charge_gbn = reader["charge_gbn"].ToString(),
                                        charge_gbn_name = reader["charge_gbn_name"].ToString(),
                                        in_amt = reader["in_amt"].ToString(),
                                        out_amt = reader["out_amt"].ToString(),
                                        charge_amt = reader["charge_amt"].ToString(),
                                        charge_ucode = reader["charge_ucode"].ToString(),
                                        memo = reader["memo"].ToString(),
                                        bank_code = reader["bankcode"].ToString(),
                                        vaccount = reader["vaccount"].ToString(),
                                        charge_acc = reader["charge_acc"].ToString(),
                                        tran_mcode = reader["mcode"].ToString(),
                                        tran_cccode = reader["tran_cccode"].ToString(),
                                        shop_name = reader["shop_name"].ToString(),
                                        user_name = reader["user_name"].ToString(),
                                        acc_date = reader["acc_date"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


            return result;
        }

        /// <summary>
        /// 출금 요청
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<CodeMsg> SetShopTransfer(RequestShopChargeList info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                using (OracleConnection connection = new OracleConnection(DbString))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = connection,
                        CommandText = "PKG_IS_API_POS.GETSHOP_INFOCHARGE_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("mobile", OracleDbType.Varchar2)).Value = info.mobile;
                        cmd.Parameters.Add(new OracleParameter("in_amt", OracleDbType.Varchar2)).Value = info.amount;
                        cmd.Parameters.Add(new OracleParameter("in_memo", OracleDbType.Varchar2)).Value = info.memo;
                        cmd.Parameters.Add(new OracleParameter("in_shop_pass", OracleDbType.Varchar2)).Value = info.pass;
                        cmd.Parameters.Add(new OracleParameter("out_rtn", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_rtn"].Value.ToString();

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// SMS 인증 상태 체크
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<SmsConfirmStatus>> GetSmsConfirmStatus(Request info)
        {
            Result<SmsConfirmStatus> result = new Result<SmsConfirmStatus>();

            using (OracleConnection conn = new OracleConnection(DbString))
            {
                await conn.OpenAsync();
                using (OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandText = "JWCHO_TEST_PACKAGE.GET_SMS_CONFIRM_INFO",
                    CommandType = CommandType.StoredProcedure
                })
                {
                    cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                    cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                    cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                    cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        if (code.Equals("00"))
                        {
                            List<SmsConfirmStatus> modelList = new List<SmsConfirmStatus>();
                            while (await reader.ReadAsync())
                            {
                                SmsConfirmStatus model = new SmsConfirmStatus()
                                {
                                    confirm_no = reader["sms_conf_no"].ToString(),
                                    issue_date = reader["issue_date"].ToString(),
                                    issue_time = reader["issue_time"].ToString(),
                                    confirm_status = reader["sms_conf_status"].ToString()
                                };
                                //result.data = model;
                                modelList.Add(model);
                            }
                            result.data = modelList;
                        }
                        result.code = code;
                        result.msg = message;
                    }
                }
            }

            return result;
        }

        #endregion

        #region 가맹점 정보

        /// <summary>
        /// 가맹점의 모든 정보를 가져온다. ( 사장님 사이트에서는 사용하지 않음
        /// </summary>
        /// <param name="id"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public async Task<Result<ShopInfo>> ShopInfoAll(string id, string password)
        {
            Result<ShopInfo> response = new Result<ShopInfo>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = $"SELECT C.CCNAME, C.MCODE, C.GROUP_ID, C.MOBILE, C.TELNO, S.* FROM SHOP_INFO S, CALLCENTER C WHERE SHOP_ID = '{id}' AND SHOP_PASS = '{password}' AND S.CCCODE = C.CCCODE",
                        CommandType = CommandType.Text

                    })
                    {
                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            List<ShopInfo> shopList = new List<ShopInfo>();

                            while (reader.Read())
                            {
                                ShopInfo model = new ShopInfo(reader);
                                shopList.Add(model);
                            };

                            response.code = "00";
                            response.msg = "성공";
                            response.data = shopList;

                        }


                    }

                }
            }
            catch (Exception)
            {
                throw;
            }

            return response;
        }

        public async Task<Result<ShopSessionDefaultInfo>> GetShopFromMapp(RqeuestPosLink info)
        {
            Result<ShopSessionDefaultInfo> result = new Result<ShopSessionDefaultInfo>();

            try
            {
                using (OracleConnection connection = new OracleConnection(DbString))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = connection,
                        CommandText = "PKG_IS_WEB_SHOP_V2.POS_LINK",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_mapp_type", OracleDbType.Varchar2)).Value = info.mapp_type;
                        cmd.Parameters.Add(new OracleParameter("in_mapp_gbn", OracleDbType.Varchar2)).Value = info.mapp_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_mapp_code", OracleDbType.Varchar2)).Value = info.mapp_code;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopSessionDefaultInfo> modelList = new List<ShopSessionDefaultInfo>();
                                while (await reader.ReadAsync())
                                {
                                    ShopSessionDefaultInfo model = new ShopSessionDefaultInfo()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        ccname = reader["ccname"].ToString(),
                                        group_id = reader["group_id"].ToString(),
                                        mcode = Convert.ToInt32(reader["mcode"].ToString()),
                                        center_mobile = reader["center_mobile"].ToString(),
                                        shop_cd = Convert.ToInt32(reader["shop_cd"].ToString()),
                                        shop_name = reader["shop_name"].ToString(),
                                        center_telno = reader["center_telno"].ToString(),
                                        shop_telno = reader["shop_telno"].ToString(),
                                        shop_mobile = reader["shop_mobile"].ToString(),
                                        use_gbn = reader["use_gbn"].ToString(),
                                        shop_id = reader["shop_id"].ToString(),
                                        shop_type = reader["shop_type"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;

                        }

                    }
                }

            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        public async Task<Result<ShopAllInfo>> SearchShopForMapp(RequestSearchShop info)
        {
            Result<ShopAllInfo> result = new Result<ShopAllInfo>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.GET_SHOP_FOR_MAPP",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_id", OracleDbType.Varchar2)).Value = info.search_data;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopAllInfo> modelList = new List<ShopAllInfo>();
                                while (await reader.ReadAsync())
                                {
                                    ShopAllInfo model = new ShopAllInfo()
                                    {
                                        mcode = reader["mcode"].ToString(),
                                        cccode = reader["콜센타코드"].ToString(),
                                        ccname = reader["콜센타명"].ToString(),
                                        shop_cd = reader["가맹점코드"].ToString(),
                                        shop_name = reader["가맹점명"].ToString(),
                                        shop_id = reader["아이디"].ToString(),
                                        telno = reader["전화번호"].ToString(),
                                        address = reader["주소"].ToString(),
                                        mobile = reader["휴대폰"].ToString(),
                                        road = reader["도로명"].ToString(),
                                        item_cd = reader["ITEM_CD"].ToString(),
                                        app_in_date = reader["APP_IN_DATE"].ToString(),
                                        app_order_yn = reader["APP_ORDER_YN"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }
        /// <summary>
        /// 가맹점 ID 여부 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<Result<CodeMsg>> GetByShop(RequestLogin info)
        {
            Result<CodeMsg> result = new Result<CodeMsg>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_T.GET_SHOP_WEB_ACCOUNT_CHECK",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_id", OracleDbType.Varchar2)).Value = info.id;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }

        /// <summary>
        /// 가맹점 기본 정보 저장 ( 세션 저장용 )
        /// ShopLoginSql 메소드를 대체.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public async Task<Result<ShopSessionDefaultInfo>> ShopSessionInfo(string id, string password, string shop_cd = null, string ucode = null)
        {
            Result<ShopSessionDefaultInfo> response = new Result<ShopSessionDefaultInfo>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_V2.GET_SHOP_WEB_SESSION_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "2";
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_id", OracleDbType.Varchar2)).Value = id;
                        cmd.Parameters.Add(new OracleParameter("in_pw", OracleDbType.Varchar2)).Value = password;
                        cmd.Parameters.Add(new OracleParameter("in_ucode", OracleDbType.Varchar2)).Value = ucode;
                        cmd.Parameters.Add(new OracleParameter("in_key", OracleDbType.Varchar2)).Value = "dlstjdepdlxj!23212";

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            int cols = dt.Columns.Count;
                            int rows = dt.Rows.Count;
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            // row 출력
                            List<ShopSessionDefaultInfo> shopList = new List<ShopSessionDefaultInfo>();


                            foreach (DataRow row in dt.Rows)
                            {
                                ShopSessionDefaultInfo model = new ShopSessionDefaultInfo()
                                {
                                    cccode = row["cccode"].ToString(),
                                    ccname = row["ccname"].ToString(),
                                    group_id = row["group_id"].ToString(),
                                    mcode = Convert.ToInt32(row["mcode"].ToString()),
                                    center_mobile = row["center_mobile"].ToString(),
                                    shop_cd = Convert.ToInt32(row["shop_cd"].ToString()),
                                    shop_name = row["shop_name"].ToString(),
                                    shop_id = row["shop_id"].ToString(),
                                    center_telno = row["center_telno"].ToString(),
                                    shop_telno = row["shop_telno"].ToString(),
                                    shop_mobile = row["shop_mobile"].ToString(),
                                    use_gbn = row["use_gbn"].ToString(),
                                    shop_type = row["shop_type"].ToString()
                                };
                                shopList.Add(model);
                            }


                            response.code = code;
                            response.msg = message;
                            response.data = shopList;
                        }
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }

            return response;
        }

        public async Task<Result<SynchronizeShopInfo>> ShopAndPosSynchronizeInfo(Request info)
        {
            Result<SynchronizeShopInfo> result = new Result<SynchronizeShopInfo>();

            try
            {
                using (OracleConnection connection = new OracleConnection(DbString))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = connection,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.GET_SHOP_SYNCHRONIZE_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<SynchronizeShopInfo> modelList = new List<SynchronizeShopInfo>();
                                while (await reader.ReadAsync())
                                {
                                    if (info.job_gbn.Equals("1"))
                                    {
                                        SynchronizeShopInfo model = new SynchronizeShopInfo()
                                        {
                                            addr1 = reader["addr1"].ToString(),
                                            addr2 = reader["addr2"].ToString(),
                                            build_no = reader["road_dest_addr"].ToString(),
                                            buss_owner = reader["buss_owner"].ToString(),
                                            cccode = reader["cccode"].ToString(),
                                            dong = reader["dong_name"].ToString(),
                                            jibun = reader["dest_jibun"].ToString(),
                                            lat = reader["lat"].ToString(),
                                            lon = reader["lon"].ToString(),
                                            mobile = reader["mobile"].ToString(),
                                            reg_no = reader["reg_no"].ToString(),
                                            shop_cd = reader["shop_cd"].ToString(),
                                            shop_id = reader["shop_id"].ToString(),
                                            shop_name = reader["shop_name"].ToString(),
                                            sido = reader["sido_name"].ToString(),
                                            sigungu = reader["gungu_name"].ToString(),
                                            road = reader["road_dest_dong"].ToString(),
                                            telno = reader["telno"].ToString(),
                                            build_name = reader["road_dest_building"].ToString(),
                                            acc_no = reader["account_no"].ToString(),
                                            acc_owner = reader["acc_owner"].ToString(),
                                            bank_code = reader["bankcode"].ToString(),
                                            mcode = reader["mcode"].ToString()
                                        };
                                        modelList.Add(model);
                                    }
                                    else
                                    {
                                        SynchronizeShopInfo model = new SynchronizeShopInfo()
                                        {
                                            addr1 = reader["addr1"].ToString(),
                                            addr2 = reader["addr2"].ToString(),
                                            build_no = reader["road_dest_addr"].ToString(),
                                            buss_owner = reader["buss_owner"].ToString(),
                                            cccode = reader["cccode"].ToString(),
                                            dong = reader["dong_name"].ToString(),
                                            jibun = reader["dest_jibun"].ToString(),
                                            lat = reader["lat"].ToString(),
                                            lon = reader["lon"].ToString(),
                                            mobile = reader["mobile"].ToString(),
                                            reg_no = reader["reg_no"].ToString(),
                                            shop_cd = reader["shop_cd"].ToString(),
                                            shop_id = reader["shop_id"].ToString(),
                                            shop_name = reader["shop_name"].ToString(),
                                            sido = reader["sido_name"].ToString(),
                                            sigungu = reader["gungu_name"].ToString(),
                                            road = reader["road_dest_dong"].ToString(),
                                            telno = reader["telno"].ToString(),
                                            build_name = reader["road_dest_building"].ToString(),
                                            acc_no = reader["account_no"].ToString(),
                                            acc_owner = reader["acc_owner"].ToString(),
                                            api_com_code = reader["api_com_code"].ToString(),
                                            api_com_gbn = reader["api_com_gbn"].ToString(),
                                            api_com_id = reader["api_com_id"].ToString(),
                                            api_com_pass = reader["api_com_pass"].ToString(),
                                            api_type = reader["api_type"].ToString(),
                                            bank_code = reader["bankcode"].ToString(),
                                            mcode = reader["mcode"].ToString()
                                        };
                                        modelList.Add(model);
                                    }


                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }


            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 가맹점정보 조회(영업시간 확인)
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> ShopBizTimeInfo(Request info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.GET_SHOP_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        result.code = code;
                        result.msg = message;


                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 가맹점 이동내역 조회(공공앱 기준), 2021/03/07
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> ShopMoveHist(Request info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.GET_SHOP_MOVE_HIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("Out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    Debug.WriteLine(dt.Columns[i].ToString().ToLower());
                                }

                                foreach (DataRow row in dt.Rows)
                                {


                                }

                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 가맹점 POS Update 정보 저장. (2019/02/25 )
        /// </summary>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetShopPosInfo(RequestSetShopPosInfo info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.SET_SHOP_POS_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_ver_info", OracleDbType.Varchar2)).Value = info.ver_info;
                        cmd.Parameters.Add(new OracleParameter("in_query_data", OracleDbType.Clob)).Value = info.query_data;
                        cmd.Parameters.Add(new OracleParameter("memo", OracleDbType.Varchar2)).Value = info.memo;
                        cmd.Parameters.Add(new OracleParameter("in_update_gbn", OracleDbType.Varchar2)).Value = info.update_gbn;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        result.code = code;
                        result.msg = message;

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 가맹점 POS Update 정보 조회. (2019/02/25 ) 
        /// </summary>
        /// <returns></returns>
        public async Task<Result<PosInfo>> GetShopPosInfo(string job_gbn, string date)
        {
            Result<PosInfo> result = new Result<PosInfo>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.GET_SHOP_POS_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_date", OracleDbType.Varchar2)).Value = date;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    Debug.WriteLine(dt.Columns[i].ToString().ToLower());
                                }

                                List<PosInfo> modelList = new List<PosInfo>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    PosInfo model = new PosInfo()
                                    {
                                        ins_date = row["ins_date"].ToString(),
                                        memo = row["memo"].ToString(),
                                        query_data = row["query_data"].ToString(),
                                        update_gbn = row["update_gbn"].ToString(),
                                        ver_info = row["ver_info"].ToString(),
                                    };
                                    modelList.Add(model);
                                }

                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }



                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 POS Update 결과 저장. (2019/02/25 ) 
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetShopPosUpdateInfo(RequestSetShopPosUpdateInfo info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.SET_SHOP_POS_UPDATE_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_ver_info", OracleDbType.Varchar2)).Value = info.ver_info;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        result.code = code;
                        result.msg = message;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점정보 상세, 2015/01/12
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopDetail>> ShopDetail(Request info)
        {
            Result<ShopDetail> result = new Result<ShopDetail>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_SHOP_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopDetail> modelList = new List<ShopDetail>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopDetail model = new ShopDetail()
                                    {
                                        cccode = row["콜센타코드"].ToString(),
                                        ccname = row["콜센타명"].ToString(),
                                        shop_cd = row["가맹점코드"].ToString(),
                                        shop_name = row["가맹점명"].ToString(),
                                        telno = row["전화번호"].ToString(),
                                        mobile = row["휴대폰"].ToString(),
                                        sido = row["시도"].ToString(),
                                        gungu = row["군구"].ToString(),
                                        dong_name = row["동명"].ToString(),
                                        상세위치 = row["상세위치"].ToString(),
                                        출발지 = row["출발지"].ToString(),
                                        주소 = row["주소"].ToString(),
                                        lon = row["lon"].ToString(),
                                        lat = row["lat"].ToString(),
                                        memo = row["메모"].ToString(),
                                        cook_wait_time = row["조리시간"].ToString(),
                                        영업시작시간 = row["영업시작시간"].ToString(),
                                        영업종료시간 = row["영업종료시간"].ToString(),
                                        shop_gbn = row["가맹점구분"].ToString(),
                                        u_plues_id = row["카드아이디"].ToString(),
                                        card_sub_id = row["서브아이디"].ToString(),
                                        app_order_yn = row["app_order_yn"].ToString(),
                                        app_in_date = row["app_in_date"].ToString(),
                                        app_calc_amt = row["app_calc_amt"].ToString(),
                                        app_calc_gbn = row["app_calc_gbn"].ToString(),
                                        app_file_name = row["app_file_name"].ToString(),
                                        app_min_amt = row["app_min_amt"].ToString(),
                                        app_pay_type = row["app_pay_type"].ToString(),
                                        sale_fr_time = row["sale_fr_time"].ToString(),
                                        sale_to_time = row["sale_to_time"].ToString(),
                                        food_order_yn = row["food_order_yn"].ToString(),
                                        item_cd = row["item_cd"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }


                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        /// <summary>
        /// 영업동 설정
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopSector>> GetShopSector(RequestGetShopSector info)
        {
            Result<ShopSector> result = new Result<ShopSector>();
            try
            {
                using (OracleConnection connection = new OracleConnection(DbString))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = connection,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.GET_SHOP_SECTOR",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopSector> modelList = new List<ShopSector>();
                                while (reader.Read())
                                {
                                    ShopSector model = new ShopSector()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        sido = reader["sido_name"].ToString(),
                                        sido_code = reader["sido_code"].ToString(),
                                        sigungu = reader["gungu_name"].ToString(),
                                        sigungu_code = reader["gungu_code"].ToString(),
                                        umdr = reader["dong_name"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopSector>> SetShopSector(RequestSetShopSector info)
        {
            Result<ShopSector> result = new Result<ShopSector>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.SET_SHOP_SECTOR",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_sido_code", OracleDbType.Varchar2)).Value = info.sido_code;
                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                        cmd.Parameters.Add(new OracleParameter("in_gungu_code", OracleDbType.Varchar2)).Value = info.sigungu_code;
                        cmd.Parameters.Add(new OracleParameter("in_gungu", OracleDbType.Varchar2)).Value = info.sigungu;
                        cmd.Parameters.Add(new OracleParameter("in_dong", OracleDbType.Varchar2)).Value = info.dong;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetShopSector_V2(RequestUpdateOrderArea info)
        {
            Result<dynamic> result = new Result<dynamic>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_V2.SET_SHOP_SECTOR_V2",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_set_gbn", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.setbgn.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd.ToString();
                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                        cmd.Parameters.Add(new OracleParameter("in_gungu", OracleDbType.Varchar2)).Value = info.gungu;
                        cmd.Parameters.Add(new OracleParameter("in_dong", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.dong.ToArray();
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }

        public async Task<Result<ShopSector>> SetShopSectorMulti(RequestSetShopSectorMulti info)
        {
            Result<ShopSector> result = new Result<ShopSector>();


            #region Make String
            List<string> sidoCodeList = new List<string>();
            List<string> sidoNameList = new List<string>();
            List<string> sigunguCodeList = new List<string>();
            List<string> sigunguNameList = new List<string>();
            List<string> dongNameList = new List<string>();

            foreach (var item in info.sectorData)
            {
                sidoCodeList.Add(item.sido_code);
                sidoNameList.Add(item.sido);
                sigunguCodeList.Add(item.sigungu_code);
                sigunguNameList.Add(item.sigungu);
                dongNameList.Add(item.dong);
            }
            #endregion

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.SET_SHOP_SECTOR_MULTI",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("in_sido_code", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = sidoCodeList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = sidoNameList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_gungu_code", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = sigunguCodeList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_gungu", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = sigunguNameList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_dong", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = dongNameList.ToArray();

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }


        /// <summary>
        /// 최소 배달 금액
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetAppMinAmt(RequestAppMinAmt info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.UPDATE_APP_MIN_AMT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_min_amt", OracleDbType.Varchar2)).Value = info.app_min_amt;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Int32)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            result.code = code;
                            result.msg = message;

                        }



                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 무료 배송 금액(배달비 무료)
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetFreeOrderAmt(RequestFreeOrderAmt info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.UPDATE_FREE_ORDER_AMT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_free_amt", OracleDbType.Varchar2)).Value = info.free_amount;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Int32)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            result.code = code;
                            result.msg = message;

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 배송 완료 시간 설정
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetOrderCompleteTime(RequestOrderCompleteTime info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandType = CommandType.StoredProcedure,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.UPDATE_ORDER_COMPLETE_TIME"
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_order_complete_time", OracleDbType.Varchar2)).Value = info.order_comp_time;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        /// <summary>
        /// 배송 완료 시간 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ORDER_COMPLETE_TIME>> GetOrderCompleteTime(Request info)
        {
            Result<ORDER_COMPLETE_TIME> result = new Result<ORDER_COMPLETE_TIME>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandType = CommandType.StoredProcedure,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.GET_ORDER_COMPLETE_TIME"
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ORDER_COMPLETE_TIME> modelList = new List<ORDER_COMPLETE_TIME>();
                                while (await reader.ReadAsync())
                                {
                                    ORDER_COMPLETE_TIME model = new ORDER_COMPLETE_TIME()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        shop_name = reader["shop_name"].ToString(),
                                        accept_state = reader["accept_state"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        /// <summary>
        /// 검색 태그 설정
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetSearchTag(RequestUpdateSearchTag info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.UPDATE_SEARCH_TAG",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_search_tag", OracleDbType.Varchar2)).Value = info.search_tag;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_user;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        public async Task<Result<ShopSearchTag>> GetSearchTag(Request info)
        {
            Result<ShopSearchTag> result = new Result<ShopSearchTag>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.GET_SEARCH_TAG",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopSearchTag> modelList = new List<ShopSearchTag>();
                                while (await reader.ReadAsync())
                                {
                                    ShopSearchTag model = new ShopSearchTag();
                                    model.search_tag = reader["search_tag"].ToString();
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }


        /// <summary>
        /// 가맹점 이미지 저장
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<StoreImageUrl>> SetStoreImage(RequestSetImageUrl info)
        {
            Result<StoreImageUrl> result = new Result<StoreImageUrl>();

            try
            {
                using (OracleConnection connection = new OracleConnection(DbString))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = connection,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.UPDATE_APP_FILE_NAME",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_img_url", OracleDbType.Varchar2)).Value = info.image_url;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_user;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<StoreImageUrl> modelList = new List<StoreImageUrl>();
                                while (await reader.ReadAsync())
                                {
                                    StoreImageUrl model = new StoreImageUrl()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        shop_name = reader["shop_name"].ToString(),
                                        image_url = reader["app_file_name"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 로고 이미지
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<StoreImageUrl>> SetLogoImage(RequestSetImageUrl info)
        {
            Result<StoreImageUrl> result = new Result<StoreImageUrl>();

            try
            {
                using (OracleConnection connection = new OracleConnection(DbString))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = connection,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.UPDATE_LOGO_NAME",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_img_url", OracleDbType.Varchar2)).Value = info.image_url;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_user;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<StoreImageUrl> modelList = new List<StoreImageUrl>();
                                while (await reader.ReadAsync())
                                {
                                    StoreImageUrl model = new StoreImageUrl()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        shop_name = reader["shop_name"].ToString(),
                                        image_url = reader["app_logo_name"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 영업시간 변경
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopSaleTime>> SetSaleTime(RequestSaleTime info)
        {
            Result<ShopSaleTime> result = new Result<ShopSaleTime>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.UPDATE_SALE_TIME",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_fr_time", OracleDbType.Varchar2)).Value = info.from_time;
                        cmd.Parameters.Add(new OracleParameter("in_to_time", OracleDbType.Varchar2)).Value = info.to_time;
                        cmd.Parameters.Add(new OracleParameter("in_next_day", OracleDbType.Varchar2)).Value = info.next_day;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_user;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopSaleTime> modelList = new List<ShopSaleTime>();
                                while (await reader.ReadAsync())
                                {
                                    ShopSaleTime model = new ShopSaleTime()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        shop_name = reader["shop_name"].ToString(),
                                        from_time = reader["sale_fr_time"].ToString(),
                                        to_time = reader["sale_to_time"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        public async Task<Result<ShopItemCodes>> SetITemCodes(RequestShopItemCodes info)
        {
            Result<ShopItemCodes> result = new Result<ShopItemCodes>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.UPDATE_ITEM_CD",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = info.item_cd;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd2", OracleDbType.Varchar2)).Value = info.item_cd2;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd3", OracleDbType.Varchar2)).Value = info.item_cd3;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_user;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopItemCodes> modelList = new List<ShopItemCodes>();
                                while (await reader.ReadAsync())
                                {
                                    ShopItemCodes model = new ShopItemCodes()
                                    {
                                        item_cd = reader["item_cd"].ToString(),
                                        item_cd2 = reader["item_cd2"].ToString(),
                                        item_cd3 = reader["item_cd3"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        public async Task<ResultSingle<ShopPayType>> GetShopPayType(Request info)
        {
            ResultSingle<ShopPayType> result = new ResultSingle<ShopPayType>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.GET_SHOP_PAY_TYPE",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                await reader.ReadAsync();

                                ShopPayType model = new ShopPayType
                                {
                                    shop_cd = reader["shop_cd"].ToString(),
                                    app_pay_type = reader["app_pay_type"].ToString(),
                                    mod_name = reader["mod_name"].ToString(),
                                    mod_ucode = reader["mod_ucode"].ToString()
                                };

                                result.data = model;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw;
            }

            return result;
        }

        public async Task<ResultSingle<ShopPayType>> SetShopPayType(RequestShopPayType info)
        {
            ResultSingle<ShopPayType> result = new ResultSingle<ShopPayType>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.SET_SHOP_PAY_TYPE",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_pay_type", OracleDbType.Varchar2)).Value = info.pay_type;
                        cmd.Parameters.Add(new OracleParameter("in_mod_ucode", OracleDbType.Varchar2)).Value = info.mod_ucode;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                await reader.ReadAsync();

                                ShopPayType model = new ShopPayType
                                {
                                    shop_cd = reader["shop_cd"].ToString(),
                                    app_pay_type = reader["app_pay_type"].ToString(),
                                    mod_name = reader["mod_name"].ToString(),
                                    mod_ucode = reader["mod_ucode"].ToString()
                                };

                                result.data = model;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        #endregion

        #region 가맹점 적립금

        /// <summary>
        /// 가맹점 계좌이체 요청
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<dynamic> SetShopInfoTran(RequestShopInfoTran info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.SET_SHOP_SHOPINFOTRAN",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_mobile", OracleDbType.Varchar2)).Value = info.mobile;
                        cmd.Parameters.Add(new OracleParameter("in_amt", OracleDbType.Varchar2)).Value = info.amt;
                        cmd.Parameters.Add(new OracleParameter("in_memo", OracleDbType.Varchar2)).Value = info.memo;
                        cmd.Parameters.Add(new OracleParameter("in_shop_pass", OracleDbType.Varchar2)).Value = info.shop_password;

                        cmd.Parameters.Add(new OracleParameter("out_rtn", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            // 리턴 코드가 없음
                            string code = "00";
                            string message = cmd.Parameters["out_rtn"].Value.ToString();

                            result.code = code;
                            result.msg = message;


                           
                        }
                    }
                }
            }
            catch (Exception e)
            {
                //await log.Post<dynamic, RequestLogData>("", new RequestLogData
                //{
                //    name = "ceo",
                //    type = "server",
                //    subType = "",
                //    errorLevel = "INFO",
                //    errorCode = e.ToString(),
                //    methodName = "SetShopInfoTran",
                //    paramData = JsonConvert.SerializeObject(info),
                //    dbPackage = "PKG_IS_API_POS.SET_SHOP_SHOPINFOTRAN",
                //    status = "error",
                //    date = Convert.ToInt32(DateTime.Now.ToString("yyyyMMddHHmmss"))
                //});
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 적립금 입출 내역 리스트
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopInfoChargeList>> ShopInfoChargeList(RequestShopInfoChargeList info)
        {
            Result<ShopInfoChargeList> response = new Result<ShopInfoChargeList>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_INFOCHARGE.GET_SHOP_INFOCHARGE_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        #region Parameters
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_mcode", OracleDbType.Varchar2)).Value = info.mcode;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_fr_dt", OracleDbType.Varchar2)).Value = info.fromDate;
                        cmd.Parameters.Add(new OracleParameter("in_to_dt", OracleDbType.Varchar2)).Value = info.toDate;
                        cmd.Parameters.Add(new OracleParameter("in_io_gbn", OracleDbType.Varchar2)).Value = info.ioType;
                        cmd.Parameters.Add(new OracleParameter("in_charge_gbn", OracleDbType.Varchar2)).Value = info.chargeType;
                        cmd.Parameters.Add(new OracleParameter("in_memo", OracleDbType.Varchar2)).Value = info.memo;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;
                        #endregion

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                int cols = dt.Columns.Count;
                                int rows = dt.Rows.Count;

                                for (int i = 0; i < cols; i++)
                                {
                                    Debug.WriteLine(dt.Columns[i].ToString().ToLowerInvariant());
                                }
                                List<ShopInfoChargeList> modelList = new List<ShopInfoChargeList>();
                                await Task.Run(() =>
                                {
                                    foreach (DataRow row in dt.Rows)
                                    {
                                        ShopInfoChargeList model = new ShopInfoChargeList()
                                        {
                                            SEQNO = row["SEQNO"].ToString(),
                                            MCODE = row["MCODE"].ToString(),
                                            CCCODE = row["CCCODE"].ToString(),
                                            SHOP_CD = row["SHOP_CD"].ToString(),
                                            ORDER_DATE = row["ORDER_DATE"].ToString(),
                                            ORDER_NO = row["ORDER_NO"].ToString(),
                                            CHARGE_DATE = row["CHARGE_DATE"].ToString(),
                                            CHARGE_GBN = row["CHARGE_GBN"].ToString(),
                                            IN_AMT = row["IN_AMT"].ToString(),
                                            OUT_AMT = row["OUT_AMT"].ToString(),
                                            CHARGE_AMT = row["CHARGE_AMT"].ToString(),
                                            CHARGE_UCODE = row["CHARGE_UCODE"].ToString(),
                                            MEMO = row["MEMO"].ToString(),
                                            BANKCODE = row["BANKCODE"].ToString(),
                                            VACCOUNT = row["VACCOUNT"].ToString(),
                                            CHARGE_ACC = row["CHARGE_ACC"].ToString(),
                                            TRAN_MCODE = row["TRAN_MCODE"].ToString(),
                                            TRAN_CCCODE = row["TRAN_CCCODE"].ToString(),
                                            SHOP_NAME = row["SHOP_NAME"].ToString(),
                                            USER_ID = row["USER_ID"].ToString(),
                                            ACC_DATE = row["ACC_DATE"].ToString(),
                                        };
                                        modelList.Add(model);
                                    }
                                });

                                response.data = modelList;
                            }

                            response.code = code;
                            response.msg = message;
                        }
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        /// <summary>
        /// 가맹점적립금 계좌이체내역조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopAccountTrans>> ShopAccountTrans(RequestShopAccountTrans info)
        {
            Result<ShopAccountTrans> result = new Result<ShopAccountTrans>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_INFOCHARGE.GET_SHOP_ACCOUNT_TRANS",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        #region Parameters
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_mcode", OracleDbType.Varchar2)).Value = info.mcode;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_fr_dt", OracleDbType.Varchar2)).Value = info.fromDate;
                        cmd.Parameters.Add(new OracleParameter("in_to_dt", OracleDbType.Varchar2)).Value = info.toDate;
                        cmd.Parameters.Add(new OracleParameter("in_memo", OracleDbType.Varchar2)).Value = info.memo;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;
                        #endregion

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            int cols = dt.Columns.Count;

                            List<ShopAccountTrans> modelList = new List<ShopAccountTrans>();
                            foreach (DataRow row in dt.Rows)
                            {
                                ShopAccountTrans model = new ShopAccountTrans()
                                {
                                    tran_seqno = row["tran_seqno"].ToString(),
                                    tran_date = row["tran_date"].ToString(),
                                    tran_time = row[""].ToString(),
                                    disp_tran_time = row["disp_tran_time"].ToString(),
                                    cccode = row["cccode"].ToString(),
                                    ccname = row["ccname"].ToString(),
                                    order_date = row["order_date"].ToString(),
                                    tran_amt = row["tran_amt"].ToString(),
                                    memo = row["memo"].ToString(),
                                    user_name = row["user_name"].ToString(),
                                    tran_res = row["tran_res"].ToString()
                                };
                                modelList.Add(model);
                            }

                            result.data = modelList;
                            result.code = code;
                            result.msg = message;

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점적립금 계좌이체 상세
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopAccountTransD>> ShopAccountTransD(RequestShopAccountTransD info)
        {
            Result<ShopAccountTransD> result = new Result<ShopAccountTransD>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_INFOCHARGE.GET_SHOP_ACCOUNT_TRANS_D",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        #region Parameters
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_tran_seqno", OracleDbType.Varchar2)).Value = info.trans_seqno;
                        cmd.Parameters.Add(new OracleParameter("in_tran_date", OracleDbType.Varchar2)).Value = info.trans_date;
                        cmd.Parameters.Add(new OracleParameter("in_tran_time", OracleDbType.Varchar2)).Value = info.trans_time;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;
                        #endregion

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            int cols = dt.Columns.Count;

                            if (code.Equals("00"))
                            {
                                List<ShopAccountTransD> modelList = new List<ShopAccountTransD>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopAccountTransD model = new ShopAccountTransD()
                                    {
                                        tran_seqno = row["tran_seqno"].ToString(),
                                        tran_time = row["tran_time"].ToString(),
                                        mcode = row["mcode"].ToString(),
                                        cccode = row["cccode"].ToString(),
                                        ucode = row["ucode"].ToString(),
                                        user_name = row["user_name"].ToString(),
                                        mobile = row["mobile"].ToString(),
                                        isrt_date = row["isrt_date"].ToString(),
                                        tran_memo = row["tran_memo"].ToString(),
                                        remain_amt = row["remain_amt"].ToString(),
                                        tran_amt = row["tran_amt"].ToString(),
                                        cc_account = row["cc_account"].ToString(),
                                        user_pass = row["user_pass"].ToString(),
                                        memo = row["memo"].ToString(),
                                        req_amt = row["req_amt"].ToString(),
                                        bankcode = row["bankcode"].ToString(),
                                        account_no = row["account_no"].ToString(),
                                        acc_owner = row["acc_owner"].ToString(),
                                        shop_cd = row["shop_cd"].ToString(),
                                        acc_confirm_gbn = row["acc_confirm_gbn"].ToString(),
                                        shop_mobile = row["shop_mobile"].ToString()
                                    };
                                    modelList.Add(model);
                                }

                                result.data = modelList;
                            }


                            result.code = code;
                            result.msg = message;

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 계좌 및 잔액 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopTransRemainAmt>> GetTransRemainAmt(Request info)
        {
            Result<ShopTransRemainAmt> result = new Result<ShopTransRemainAmt>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();

                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_INFOCHARGE.GET_TRANS_REMAIN_AMT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopTransRemainAmt> modelList = new List<ShopTransRemainAmt>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopTransRemainAmt model = new ShopTransRemainAmt()
                                    {
                                        remain_amt = row["remain_amt"].ToString(),
                                        bank_info = row["remain_amt"].ToString(),
                                        bankcode = row["remain_amt"].ToString(),
                                        account_no = row["remain_amt"].ToString(),
                                        acc_owner = row["remain_amt"].ToString(),
                                        acc_confirm_gbn = row["remain_amt"].ToString(),
                                        mobile = row["remain_amt"].ToString(),
                                    };

                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;

                        }

                    }

                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 이체계좌 인증구분 수정
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetAccConvirmGbn(Request info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_INFOCHARGE.SET_ACC_CONFIRM_GBN",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();

                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    Debug.WriteLine(dt.Columns[i].ToString().ToLower());
                                }

                                foreach (DataRow row in dt.Rows)
                                {

                                }
                            }
                            result.code = code;
                            result.msg = message;
                        }




                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        public async Task<Result<ResponseShopInfoChargeOrderList>> GetShopInfoChargeOrderList(RequestShopInfoChargeOrderList info)
        {
            Result<ResponseShopInfoChargeOrderList> result = new Result<ResponseShopInfoChargeOrderList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.GET_SHOP_INFOCHARGE_ORDER_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_order_no", OracleDbType.Varchar2)).Value = info.order_no;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseShopInfoChargeOrderList> modelList = new List<ResponseShopInfoChargeOrderList>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseShopInfoChargeOrderList model = new ResponseShopInfoChargeOrderList
                                    {
                                        seqno = reader["seqno"].ToString(),
                                        order_date = reader["order_date"].ToString(),
                                        order_no = reader["order_no"].ToString(),
                                        menu_amount = reader["menu_amt"].ToString(),
                                        delivery_tip_amount = reader["deli_tip_amt"].ToString(),
                                        total_amount = reader["tot_amt"].ToString(),
                                        disc_amount = reader["disc_amt"].ToString(),
                                        amount = reader["amount"].ToString(),
                                        coupon_amount = reader["coupon_amt"].ToString(),
                                        mileage_use_amount = reader["mileage_use_amt"].ToString(),
                                        charge_date = reader["charge_date"].ToString(),
                                        charge_gbn = reader["charge_gbn"].ToString(),
                                        charge_gbn_name = reader["charge_gbn_name"].ToString(),
                                        in_amount = reader["in_amt"].ToString(),
                                        out_amount = reader["out_amt"].ToString(),
                                        charge_amount = reader["charge_amt"].ToString(),
                                        memo = reader["memo"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        #endregion

        #region 가맹점 노출 정보
        /// <summary>
        /// 가맹점 노출 정보 조회
        /// GET_SHOP_DP_MANAGER_LIST
        /// </summary>
        /// <param name="info"></param>
        /// <param name="UseGbn"></param>
        /// <returns></returns>
        public async Task<Result<ShopFlag>> ShopFlag(Request info, string UseGbn)
        {
            Result<ShopFlag> result = new Result<ShopFlag>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_SHOP_DP_MANAGER_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_use_gbn", OracleDbType.Varchar2)).Value = UseGbn;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            int cols = dt.Columns.Count;
                            int rows = dt.Rows.Count;

                            for (int i = 0; i < cols; i++)
                            {
                                Debug.WriteLine(dt.Columns[i].ToString());
                            }

                            if (code.Equals("00"))
                            {
                                List<ShopFlag> modelList = new List<ShopFlag>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopFlag model = new ShopFlag()
                                    {
                                        ADDR = row["ADDR"].ToString(),
                                        CCCODE = row["CCCODE"].ToString(),
                                        DP_LAT = row["DP_LAT"].ToString(),
                                        DP_LON = row["DP_LON"].ToString(),
                                        DP_SEQ = row["DP_SEQ"].ToString(),
                                        DP_SHOP_NAME = row["DP_SHOP_NAME"].ToString(),
                                        DP_TELNO = row["DP_TELNO"].ToString(),
                                        INS_DATE = row["INS_DATE"].ToString(),
                                        INS_NAME = row["INS_NAME"].ToString(),
                                        INS_UCODE = row["INS_UCODE"].ToString(),
                                        MEMO = row["MEMO"].ToString(),
                                        MOD_DATE = row["MOD_DATE"].ToString(),
                                        MOD_NAME = row["MOD_NAME"].ToString(),
                                        MOD_UCODE = row["MOD_UCODE"].ToString(),
                                        ROAD_ADDR = row["ROAD_ADDR"].ToString(),
                                        SHOP_CD = row["SHOP_CD"].ToString(),
                                        USE_GBN = row["USE_GBN"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }

        /// <summary>
        /// 가맹점 노출 정보 관리
        /// SET_SHOP_DP_MANAGER
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<dynamic> ShopCreateFlag(ShopFlagData model)
        {
            Result<dynamic> result = new Result<dynamic>();

            using (OracleConnection conn = new OracleConnection(DbString))
            {
                await conn.OpenAsync();
                using (OracleCommand cmd = new OracleCommand()
                {
                    Connection = conn,
                    CommandText = "PKG_IS_COMM_SHOP_WEB.SET_SHOP_DP_MANAGER",
                    CommandType = CommandType.StoredProcedure
                })
                {
                    #region Parameters
                    cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = model.job_gbn;
                    cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = model.shopCode;
                    cmd.Parameters.Add(new OracleParameter("in_dp_seq", OracleDbType.Varchar2)).Value = model.flagSequence;
                    cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = model.cccode;
                    cmd.Parameters.Add(new OracleParameter("in_dp_shop_name", OracleDbType.Varchar2)).Value = model.displayShopName;
                    cmd.Parameters.Add(new OracleParameter("in_dp_telno", OracleDbType.Varchar2)).Value = model.displayShopTelno;
                    cmd.Parameters.Add(new OracleParameter("in_use_gbn", OracleDbType.Varchar2)).Value = model.useGbn ? "Y" : "N";
                    cmd.Parameters.Add(new OracleParameter("in_dp_lon", OracleDbType.Varchar2)).Value = model.lon;
                    cmd.Parameters.Add(new OracleParameter("in_dp_lat", OracleDbType.Varchar2)).Value = model.lat;
                    cmd.Parameters.Add(new OracleParameter("in_road_addr", OracleDbType.Varchar2)).Value = model.road;
                    cmd.Parameters.Add(new OracleParameter("in_addr", OracleDbType.Varchar2)).Value = model.addr;
                    cmd.Parameters.Add(new OracleParameter("in_memo", OracleDbType.Varchar2)).Value = model.memo;
                    cmd.Parameters.Add(new OracleParameter("in_user_ucode", OracleDbType.Varchar2)).Value = model.updateUserCode;
                    cmd.Parameters.Add(new OracleParameter("in_user_name", OracleDbType.Varchar2)).Value = model.updateUserName;
                    cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;
                    #endregion

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }
                }
            }

            return result;
        }
        #endregion

        #region 가맹점 휴무 관리
        /// <summary>
        /// 요일별 휴무 등록 / 수정, 임시 휴무 등록 / 수정
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopHoliday>> SetShopHolidayTerm(RequestSetHoliday info)
        {
            Result<ShopHoliday> result = new Result<ShopHoliday>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_V2.SET_SHOP_HOLIDAY_TERM",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_absent", OracleDbType.Varchar2)).Value = info.running;
                        cmd.Parameters.Add(new OracleParameter("in_holiday", OracleDbType.Varchar2)).Value = info.day_of_holiday.ToString();
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.login_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.login_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();
                            if (code.Equals("00"))
                            {
                                List<ShopHoliday> modelList = new List<ShopHoliday>();
                                while (reader.Read())
                                {
                                    ShopHoliday model = new ShopHoliday()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        day_of_holiday = reader["holiday_term"].ToString(),
                                        running = reader["ABSENT_YN"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 요일별 휴무 조회, 임시 휴무 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopHoliday>> GetShopHolidayTerm(Request info)
        {
            Result<ShopHoliday> result = new Result<ShopHoliday>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS_SHOP.GET_SHOP_HOLIDAY_TERM",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopHoliday> modelList = new List<ShopHoliday>();
                                while (reader.Read())
                                {
                                    ShopHoliday model = new ShopHoliday()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        day_of_holiday = reader["holiday_term"].ToString(),
                                        running = reader["ABSENT_YN"].ToString(),
                                    };
                                    modelList.Add(model);

                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


            return result;
        }


        #endregion

        #region 가맹점 배달팁 관리

        /// <summary>
        /// 가맹점 공휴일에 대한 배달팁 조회
        /// GET_SHOP_REST_LIST
        /// 1 공휴일 및 배달팁 관리 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>

        public async Task<Result<ShopRestList>> ShopRestList(RequestShopRestList info)
        {
            Result<ShopRestList> result = new Result<ShopRestList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_SHOP_REST_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_rest_dt", OracleDbType.Varchar2)).Value = info.rest_date;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopRestList> modelList = new List<ShopRestList>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopRestList model = new ShopRestList()
                                    {
                                        SHOP_CD = row["SHOP_CD"].ToString(),
                                        SHOP_NAME = row["SHOP_NAME"].ToString(),
                                        REST_DT = row["REST_DT"].ToString(),
                                        MEMO = row["MEMO"].ToString(),
                                        INS_UCODE = row["INS_UCODE"].ToString(),
                                        INS_NAME = row["INS_NAME"].ToString(),
                                        INS_DATE = row["INS_DATE"].ToString(),
                                        MOD_UCODE = row["MOD_UCODE"].ToString(),
                                        MOD_NAME = row["MOD_NAME"].ToString(),
                                        MOD_DATE = row["MOD_DATE"].ToString(),
                                    };
                                    modelList.Add(model);

                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;

        }

        /// <summary>
        /// 가맹점 공휴일에 대한 배달팁  관리
        /// SET_SHOP_REST
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetShopRest(RequestSetShopRest info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.SET_SHOP_REST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_rest_date", OracleDbType.Varchar2)).Value = info.rest_date;
                        cmd.Parameters.Add(new OracleParameter("in_rest_tip_amt", OracleDbType.Varchar2)).Value = info.rest_tip_amt;
                        cmd.Parameters.Add(new OracleParameter("in_memo", OracleDbType.Varchar2)).Value = info.memo;

                        cmd.Parameters.Add(new OracleParameter("in_user_ucode", OracleDbType.Int32)).Value = info.user_code;
                        cmd.Parameters.Add(new OracleParameter("in_user_name", OracleDbType.Varchar2)).Value = info.user_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        result.code = code;
                        result.msg = message;

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }


        /// <summary>
        /// 가맹점 가맹점 배달팁 요금설정 조회
        /// 배달팁 구분 ( 1: 거리, 3: 주문금액, 5: 요일-일월화수목금토일 )
        /// 팁요금 ( 1: 거리기준, 3: 주문금액기준 )
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopInfoTipAmt>> ShopInfoTipAmtList(RequestShopInfoTipAmt info)
        {
            Result<ShopInfoTipAmt> result = new Result<ShopInfoTipAmt>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();

                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_SHOP_INFO_TIP_AMT_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_tip_gbn", OracleDbType.Varchar2)).Value = info.tip_gbn;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);


                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    Debug.WriteLine(dt.Columns[i].ToString().ToLower());
                                }

                                List<ShopInfoTipAmt> modelList = new List<ShopInfoTipAmt>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopInfoTipAmt model = new ShopInfoTipAmt()
                                    {
                                        shop_cd = row["shop_cd"].ToString(),
                                        shop_name = row["shop_name"].ToString(),
                                        tip_seq = row["tip_seq"].ToString(),
                                        tip_gbn = row["tip_gbn"].ToString(),
                                        tip_day = row["tip_day"].ToString(),
                                        tip_fr_stand = row["tip_fr_stand"].ToString(),
                                        tip_to_stand = row["tip_to_stand"].ToString(),
                                        tip_amt = row["tip_amt"].ToString(),
                                        tip_amt_rate = row["tip_amt_rate"].ToString(),
                                        tip_next_day = row["tip_next_day"].ToString(),
                                        ins_ucode = row["ins_ucode"].ToString(),
                                        ins_name = row["ins_name"].ToString(),
                                        ins_date = row["ins_date"].ToString(),
                                        mod_ucode = row["mod_ucode"].ToString(),
                                        mod_name = row["mod_name"].ToString(),
                                        mod_date = row["mod_date"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        public async Task<Result<ShopInfoTipAmt>> ShopInfoTipAmtListV2(RequestShopInfoTipAmt info)
        {
            Result<ShopInfoTipAmt> result = new Result<ShopInfoTipAmt>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();

                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_V3.GET_SHOP_INFO_TIP_AMT_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_tip_gbn", OracleDbType.Varchar2)).Value = info.tip_gbn;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);


                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    Debug.WriteLine(dt.Columns[i].ToString().ToLower());
                                }

                                List<ShopInfoTipAmt> modelList = new List<ShopInfoTipAmt>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopInfoTipAmt model = new ShopInfoTipAmt()
                                    {
                                        shop_cd = row["shop_cd"].ToString(),
                                        shop_name = row["shop_name"].ToString(),
                                        tip_seq = row["tip_seq"].ToString(),
                                        tip_gbn = row["tip_gbn"].ToString(),
                                        tip_day = row["tip_day"].ToString(),
                                        tip_fr_stand = row["tip_fr_stand"].ToString(),
                                        tip_to_stand = row["tip_to_stand"].ToString(),
                                        tip_amt = row["tip_amt"].ToString(),
                                        tip_amt_rate = row["tip_amt_rate"].ToString(),
                                        tip_next_day = row["tip_next_day"].ToString(),
                                        ins_ucode = row["ins_ucode"].ToString(),
                                        ins_name = row["ins_name"].ToString(),
                                        ins_date = row["ins_date"].ToString(),
                                        mod_ucode = row["mod_ucode"].ToString(),
                                        mod_name = row["mod_name"].ToString(),
                                        mod_date = row["mod_date"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        /// <summary>
        /// 가맹점 가맹점 배달팁 요금설정 관리
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetShopInfoTipAmt(RequestSetShopInfoTipAmt info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.SET_SHOP_INFO_TIP_AMT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_tip_seq", OracleDbType.Int32)).Value = info.tip_seq;
                        cmd.Parameters.Add(new OracleParameter("in_tip_gbn", OracleDbType.Varchar2)).Value = info.tip_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_tip_day", OracleDbType.Varchar2)).Value = info.tip_day;
                        cmd.Parameters.Add(new OracleParameter("in_tip_fr_stand", OracleDbType.Varchar2)).Value = info.tip_from_stand;
                        cmd.Parameters.Add(new OracleParameter("in_tip_to_stand", OracleDbType.Varchar2)).Value = info.tip_to_stand;
                        cmd.Parameters.Add(new OracleParameter("in_tip_amt", OracleDbType.Varchar2)).Value = info.tip_amt;
                        cmd.Parameters.Add(new OracleParameter("in_tip_amt_rate", OracleDbType.Varchar2)).Value = info.tip_amt_rate;
                        cmd.Parameters.Add(new OracleParameter("in_tip_next_dat", OracleDbType.Varchar2)).Value = info.tip_next_day;
                        cmd.Parameters.Add(new OracleParameter("in_user_ucode", OracleDbType.Varchar2)).Value = info.user_code;
                        cmd.Parameters.Add(new OracleParameter("in_user_name", OracleDbType.Varchar2)).Value = info.user_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;


                        await cmd.ExecuteNonQueryAsync();

                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        result.code = code;
                        result.msg = message;

                    }
                }

            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        public async Task<Result<dynamic>> SetShopInfoTipAmt_V2(RequestSetShopInfoTipAmt_V2 info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_V3.SET_SHOP_INFO_TIP_AMT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.job_gbn.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_tip_seq", OracleDbType.Int32)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.tip_seq.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_gbn", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.tip_gbn.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_day", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.tip_day.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_fr_stand", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.tip_from_stand.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_to_stand", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.tip_to_stand.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_amt", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.tip_amt.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_amt_rate", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.tip_amt_rate.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_next_day", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.tip_next_day.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_user_ucode", OracleDbType.Int32)).Value = info.user_code;
                        cmd.Parameters.Add(new OracleParameter("in_user_name", OracleDbType.Varchar2)).Value = info.user_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        result.code = code;
                        result.msg = message;

                    }
                }

            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        /// <summary>
        /// 주문 금액 별 배달팁 설정 ( 리스트 형태 )
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetShopInfoTipAmtMulti(RequestSetShopInfoTipAmtList info)
        {
            Result<dynamic> result = new Result<dynamic>();

            #region Make String
            List<int> tip_seq = new List<int>();
            List<string> tip_gbn = new List<string>();
            List<string> tip_day = new List<string>();
            List<string> tip_from_stand = new List<string>();
            List<string> tip_to_stand = new List<string>();
            List<string> tip_amt = new List<string>();
            List<string> tip_amt_rate = new List<string>();
            List<string> tip_next_day = new List<string>();

            foreach (var item in info.itemList)
            {
                tip_seq.Add(item.tip_seq);
                tip_gbn.Add(item.tip_gbn);
                tip_day.Add("1");           // 사용하지 않는 필드 고정
                tip_from_stand.Add(item.tip_from_stand);
                tip_to_stand.Add("0");    // 사용하지 않는 필드 고정
                tip_amt.Add(item.tip_amt);
                tip_amt_rate.Add(item.tip_amt_rate);
                tip_next_day.Add(item.tip_next_day);
            }
            #endregion

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.SET_FOOD_TIP_AMT_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_tip_seq", OracleDbType.Int32)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = tip_seq.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_gbn", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = tip_gbn.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_day", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = tip_day.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_fr_stand", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = tip_from_stand.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_to_stand", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = tip_to_stand.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_amt", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = tip_amt.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_amt_rate", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = tip_amt_rate.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_tip_next_day", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = tip_next_day.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_user_ucode", OracleDbType.Varchar2)).Value = info.user_code;
                        cmd.Parameters.Add(new OracleParameter("in_user_name", OracleDbType.Varchar2)).Value = info.user_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;


                        await cmd.ExecuteNonQueryAsync();

                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        result.code = code;
                        result.msg = message;

                    }
                }

            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        #endregion

        #region 고객 오더

        /// <summary>
        /// 가맹점 주문조회(현재일기준 5일이내) , 2017/01/20
        /// 가맹점 주문 (PRCS_GBN  = '3' )
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopOrder>> ShopOrderList(RequestShopOrderList info)
        {
            Result<ShopOrder> result = new Result<ShopOrder>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.GET_SHOP_ORDER_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_from_date", OracleDbType.Varchar2)).Value = info.from_date;
                        cmd.Parameters.Add(new OracleParameter("in_to_date", OracleDbType.Varchar2)).Value = info.to_date;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    Debug.WriteLine(dt.Columns[i].ToString().ToLower());
                                }

                                List<ShopOrder> modelList = new List<ShopOrder>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopOrder model = new ShopOrder(row, CUST_ORDER_SEARCH_TYPE.기본내역);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 주문확인 및  취소
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> ShopOrderState(RequestOrderState info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.SET_SHOP_ORDER_STATE",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_order_date", OracleDbType.Varchar2)).Value = info.order_date;
                        cmd.Parameters.Add(new OracleParameter("in_order_no", OracleDbType.Varchar2)).Value = info.order_no;
                        cmd.Parameters.Add(new OracleParameter("in_status", OracleDbType.Varchar2)).Value = info.status;
                        cmd.Parameters.Add(new OracleParameter("in_memo", OracleDbType.Varchar2)).Value = info.memo;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_user;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        result.code = code;
                        result.msg = message;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 고객주문 기본, 2016/03/08
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopOrder>> CustOrderDefaultDetail(RequestOrderState info)
        {
            Result<ShopOrder> result = new Result<ShopOrder>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS.GET_CUST_ORDER_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_order_no", OracleDbType.Varchar2)).Value = info.order_no;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();



                            if (code.Equals("00"))
                            {

                                if (info.job_gbn.Equals(((int)CUST_ORDER_SEARCH_TYPE.기본내역).ToString()))
                                {

                                    List<ShopOrder> modelList = new List<ShopOrder>();
                                    foreach (DataRow row in dt.Rows)
                                    {
                                        ShopOrder model = new ShopOrder(row, CUST_ORDER_SEARCH_TYPE.기본내역);
                                        modelList.Add(model);
                                    }
                                    result.data = modelList;
                                }
                                else if (info.job_gbn.Equals(((int)CUST_ORDER_SEARCH_TYPE.주문메뉴내역).ToString()))
                                {
                                    for (int i = 0; i < dt.Columns.Count; i++)
                                    {
                                        Debug.WriteLine(dt.Columns[i].ToString());
                                    }
                                }
                                else if (info.job_gbn.Equals(((int)CUST_ORDER_SEARCH_TYPE.주문메뉴와옵션메뉴내역).ToString()))
                                {
                                    for (int i = 0; i < dt.Columns.Count; i++)
                                    {
                                        Debug.WriteLine(dt.Columns[i].ToString());
                                    }
                                }



                            }

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        public async Task<Result<CustOrderMenu>> CustOrderDetailWithMenuInfo(RequestOrderState info)
        {
            Result<CustOrderMenu> result = new Result<CustOrderMenu>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_V2.GET_CUST_ORDER_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = ((int)CUST_ORDER_SEARCH_TYPE.주문메뉴내역).ToString();
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_order_no", OracleDbType.Varchar2)).Value = info.order_no;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (DbDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                while (reader.Read())
                                {
                                    var temp = reader["품목"].ToString();
                                    if (temp != null)
                                    {
                                        var menuData = JsonConvert.DeserializeObject<List<CustOrderMenu>>(temp);
                                        result.data = menuData;
                                    }
                                }

                            }

                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 고객 오더 상세 내역
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopOrderDetail>> CustOrderDetail(RequestOrderState info)
        {
            Result<ShopOrderDetail> result = new Result<ShopOrderDetail>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_V2.GET_CUST_ORDER_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("in_order_no", OracleDbType.Varchar2)).Value = info.order_no;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                if (info.job_gbn.Equals(((int)CUST_ORDER_SEARCH_TYPE.주문상세).ToString()))
                                {
                                    List<ShopOrderDetail> modelList = new List<ShopOrderDetail>();
                                    foreach (DataRow row in dt.Rows)
                                    {
                                        ShopOrderDetail model = new ShopOrderDetail()
                                        {
                                            amount = row[nameof(ShopOrderDetail.amount)].ToString(),
                                            app_pay_gbn = row[nameof(ShopOrderDetail.app_pay_gbn)].ToString(),
                                            cancel_reason = row[nameof(ShopOrderDetail.cancel_reason)].ToString(),
                                            coupon_amt = row[nameof(ShopOrderDetail.coupon_amt)].ToString(),
                                            cust_addr_detail = row[nameof(ShopOrderDetail.cust_addr_detail)].ToString(),
                                            cust_dong_addr = row[nameof(ShopOrderDetail.cust_dong_addr)].ToString(),
                                            cust_road_addr = row[nameof(ShopOrderDetail.cust_road_addr)].ToString(),
                                            lat = row[nameof(ShopOrderDetail.lat)].ToString(),
                                            lon = row[nameof(ShopOrderDetail.lon)].ToString(),
                                            menu_amt = row[nameof(ShopOrderDetail.menu_amt)].ToString(),
                                            menu_name = row[nameof(ShopOrderDetail.menu_name)].ToString(),
                                            order_amt_tip = row[nameof(ShopOrderDetail.order_amt_tip)].ToString(),
                                            order_no = row[nameof(ShopOrderDetail.order_no)].ToString(),
                                            order_time = row[nameof(ShopOrderDetail.order_time)].ToString(),
                                            pack_order_yn = row[nameof(ShopOrderDetail.pack_order_yn)].ToString(),
                                            pay_gbn = row[nameof(ShopOrderDetail.pay_gbn)].ToString(),
                                            rider_deli_memo = row[nameof(ShopOrderDetail.rider_deli_memo)].ToString(),
                                            shop_addr_detail = row[nameof(ShopOrderDetail.shop_addr_detail)].ToString(),
                                            shop_deli_memo = row[nameof(ShopOrderDetail.shop_deli_memo)].ToString(),
                                            shop_dong_addr = row[nameof(ShopOrderDetail.shop_dong_addr)].ToString(),
                                            shop_name = row[nameof(ShopOrderDetail.shop_name)].ToString(),
                                            shop_road_addr = row[nameof(ShopOrderDetail.shop_road_addr)].ToString(),
                                            status = row[nameof(ShopOrderDetail.status)].ToString(),
                                            mynumber = row[nameof(ShopOrderDetail.mynumber)].ToString(),
                                            mileage_use_amt = row[nameof(ShopOrderDetail.mileage_use_amt)].ToString(),
                                            happy_disc_amt = row[nameof(ShopOrderDetail.happy_disc_amt)].ToString()
                                        };
                                        modelList.Add(model);
                                    }
                                    result.data = modelList;
                                }
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        public async Task<Result<dynamic>> GetCustOrderList(Request info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        CommandText = "PKG_CUST_ORDER_LIST",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        /// 가맹점 코드로 가져오는 패키지가 아님.
                        /// 가맹점 코드로 가져오는 패키지가 필요함.
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        /// <summary>
        /// 고객 오더 상세 내역_V3
        /// </summary>
        /// <param name="info"></param>
        public async Task<Result<ShopOrderDetail>> CustOrderDetail_V3(RequestOrderState info)
        {
            Result<ShopOrderDetail> result = new Result<ShopOrderDetail>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_V3.GET_CUST_ORDER_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_order_no", OracleDbType.Varchar2)).Value = info.order_no;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                if (info.job_gbn.Equals(((int)CUST_ORDER_SEARCH_TYPE.주문상세).ToString()))
                                {
                                    List<ShopOrderDetail> modelList = new List<ShopOrderDetail>();
                                    foreach (DataRow row in dt.Rows)
                                    {
                                        ShopOrderDetail model = new ShopOrderDetail()
                                        {
                                            amount = row[nameof(ShopOrderDetail.amount)].ToString(),
                                            app_pay_gbn = row[nameof(ShopOrderDetail.app_pay_gbn)].ToString(),
                                            cancel_reason = row[nameof(ShopOrderDetail.cancel_reason)].ToString(),
                                            coupon_amt = row[nameof(ShopOrderDetail.coupon_amt)].ToString(),
                                            cust_addr_detail = row[nameof(ShopOrderDetail.cust_addr_detail)].ToString(),
                                            cust_dong_addr = row[nameof(ShopOrderDetail.cust_dong_addr)].ToString(),
                                            cust_road_addr = row[nameof(ShopOrderDetail.cust_road_addr)].ToString(),
                                            lat = row[nameof(ShopOrderDetail.lat)].ToString(),
                                            lon = row[nameof(ShopOrderDetail.lon)].ToString(),
                                            menu_amt = row[nameof(ShopOrderDetail.menu_amt)].ToString(),
                                            menu_name = row[nameof(ShopOrderDetail.menu_name)].ToString(),
                                            order_amt_tip = row[nameof(ShopOrderDetail.order_amt_tip)].ToString(),
                                            order_no = row[nameof(ShopOrderDetail.order_no)].ToString(),
                                            order_time = row[nameof(ShopOrderDetail.order_time)].ToString(),
                                            pack_order_yn = row[nameof(ShopOrderDetail.pack_order_yn)].ToString(),
                                            pay_gbn = row[nameof(ShopOrderDetail.pay_gbn)].ToString(),
                                            rider_deli_memo = row[nameof(ShopOrderDetail.rider_deli_memo)].ToString(),
                                            shop_addr_detail = row[nameof(ShopOrderDetail.shop_addr_detail)].ToString(),
                                            shop_deli_memo = row[nameof(ShopOrderDetail.shop_deli_memo)].ToString(),
                                            shop_dong_addr = row[nameof(ShopOrderDetail.shop_dong_addr)].ToString(),
                                            shop_name = row[nameof(ShopOrderDetail.shop_name)].ToString(),
                                            shop_road_addr = row[nameof(ShopOrderDetail.shop_road_addr)].ToString(),
                                            status = row[nameof(ShopOrderDetail.status)].ToString(),
                                            mynumber = row[nameof(ShopOrderDetail.mynumber)].ToString(),
                                            mileage_use_amt = row[nameof(ShopOrderDetail.mileage_use_amt)].ToString(),
                                            happy_disc_amt = row[nameof(ShopOrderDetail.happy_disc_amt)].ToString(),
                                            deli_tip_disc_amt = row[nameof(ShopOrderDetail.deli_tip_disc_amt)].ToString(),
                                            to_go_disc_amt = row[nameof(ShopOrderDetail.to_go_disc_amt)].ToString(),
                                            menu_desc = row[nameof(ShopOrderDetail.menu_desc)].ToString(),
                                            cust_lon = row[nameof(ShopOrderDetail.cust_lon)].ToString(),
                                            cust_lat = row[nameof(ShopOrderDetail.cust_lat)].ToString(),

                                        };
                                        model.menu_info = JsonConvert.DeserializeObject<List<CustOrderMenu>>(model.menu_desc);
                                        modelList.Add(model);
                                    }
                                    result.data = modelList;
                                }
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        /// <returns></returns>
        #endregion

        #region 가맹점 메뉴

        /// <summary>
        /// 주문 업종분류코드 , 2015/01/07
        /// </summary>
        /// <returns></returns>
        public async Task<Result<ShopBizItemCode>> ShopBizItemCode()
        {
            Result<ShopBizItemCode> result = new Result<ShopBizItemCode>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_COMM_ITEM_CD",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopBizItemCode> modelList = new List<ShopBizItemCode>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopBizItemCode model = new ShopBizItemCode()
                                    {
                                        ITEM_CD = row["ITEM_CD"].ToString(),
                                        ITEM_DESC = row["ITEM_DESC"].ToString(),
                                        ITEM_NAME = row["ITEM_NAME"].ToString()
                                    };
                                    modelList.Add(model);
                                }

                                result.data = modelList.OrderBy(x => x.ITEM_CD).ToList();
                            }
                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 업종 가맹점별 메뉴상세 조회  , 2015/02/12
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopSMenu>> CommShopSMenuDetail(RequestSMenuDetail info)
        {
            Result<ShopSMenu> result = new Result<ShopSMenu>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_COMM_SMENU_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = info.item_cd;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    Debug.WriteLine(dt.Columns[i].ToString().ToLower());
                                }

                                List<ShopSMenu> modelList = new List<ShopSMenu>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopSMenu model = new ShopSMenu(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }

                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 업종 가맹점별 메뉴 조회  , 2015/01/13
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopSMenu>> CommShopSMenuList(RequestSMenuList info)
        {
            Result<ShopSMenu> result = new Result<ShopSMenu>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_COMM_SMENU_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = info.item_cd;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_cd", OracleDbType.Varchar2)).Value = info.group_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_name", OracleDbType.Varchar2)).Value = info.menu_name;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopSMenu> modelList = new List<ShopSMenu>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopSMenu model = new ShopSMenu(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }

                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 업종별 메뉴그룹 조회  , 2015/01/12
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopSMenuGroup>> CommShopSMenuGroupList(RequestSMenuGroupList info)
        {
            Result<ShopSMenuGroup> result = new Result<ShopSMenuGroup>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_COMM_SMENU_GROUP_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = info.item_cd;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_type", OracleDbType.Varchar2)).Value = info.group_type;
                        cmd.Parameters.Add(new OracleParameter("in_group_name", OracleDbType.Varchar2)).Value = info.group_name;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;
                        cmd.Parameters.Add(new OracleParameter("in_option_yn", OracleDbType.Varchar2)).Value = info.option_yn;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopSMenuGroup> modelList = new List<ShopSMenuGroup>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopSMenuGroup model = new ShopSMenuGroup(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }

                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 업종별 메뉴옵션 그룹 조회  , 2015/02/12
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopSMenuGroup>> CommShopSMenuGroupDetail(RequestSMenuGroupDetail info)
        {
            Result<ShopSMenuGroup> result = new Result<ShopSMenuGroup>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_COMM_SMENU_GROUP_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = info.item_cd;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_group_cd", OracleDbType.Varchar2)).Value = info.menu_group_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            //await Task.Run(() => );
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopSMenuGroup> modelList = new List<ShopSMenuGroup>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopSMenuGroup model = new ShopSMenuGroup(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }

                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 업종별 메뉴옵션 상세조회 , 2015/02/12
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopSMenuOption>> CommShopSMenuOptionDetail(RequestSMenuOptionDetail info)
        {
            Result<ShopSMenuOption> result = new Result<ShopSMenuOption>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_COMM_SMENU_OPTION_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = info.item_cd;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_option_cd", OracleDbType.Varchar2)).Value = info.option_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    Debug.WriteLine(dt.Columns[i].ToString().ToLower());
                                }

                                List<ShopSMenuOption> modelList = new List<ShopSMenuOption>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopSMenuOption model = new ShopSMenuOption(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }

                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 업종별 메뉴옵션 조회  , 2015/01/13
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopSMenuOption>> CommShopSMenuOptionList(RequestSMenuOptionList info)
        {
            Result<ShopSMenuOption> result = new Result<ShopSMenuOption>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_COMM_SMENU_OPTION_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = info.item_cd;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_opt_group_cd", OracleDbType.Varchar2)).Value = info.opt_group_cd;
                        cmd.Parameters.Add(new OracleParameter("in_option_name", OracleDbType.Varchar2)).Value = info.option_name;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopSMenuOption> modelList = new List<ShopSMenuOption>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopSMenuOption model = new ShopSMenuOption(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }

                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 업종별 메뉴상호 상세 조회  , 2015/02/10
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<SShop>> CommShopDetail(RequestComShopDetail info)
        {
            Result<SShop> result = new Result<SShop>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_COMM_SSHOP_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = info.item_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_group_cd", OracleDbType.Varchar2)).Value = info.menu_group_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    Debug.WriteLine(dt.Columns[i].ToString().ToLower());
                                }

                                List<SShop> modelList = new List<SShop>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    SShop model = new SShop(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }

                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 업종별 메뉴상호 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<SShop>> CommShopList(RequestComShopList info)
        {
            Result<SShop> result = new Result<SShop>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_COMM_SSHOP_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = info.item_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_type", OracleDbType.Varchar2)).Value = info.group_type;
                        cmd.Parameters.Add(new OracleParameter("in_group_name", OracleDbType.Varchar2)).Value = info.group_name;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    Debug.WriteLine(dt.Columns[i].ToString().ToLower());
                                }

                                List<SShop> modelList = new List<SShop>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    SShop model = new SShop(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }

                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 가맹점별 메뉴상세  조회  , 2015/02/12
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopMenuDetail>> GetMenuDetail(RequestMenuDetail info)
        {
            Result<ShopMenuDetail> result = new Result<ShopMenuDetail>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_MENU_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_cd", OracleDbType.Varchar2)).Value = info.group_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Int32)).Value = info.menu_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopMenuDetail> modelList = new List<ShopMenuDetail>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopMenuDetail model = new ShopMenuDetail(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점별 메뉴 조회  , 2015/01/15
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<SHOP_MENU>> GetMenuList(RequestMenuList info)
        {
            Result<SHOP_MENU> result = new Result<SHOP_MENU>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_MENU_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_cd", OracleDbType.Varchar2)).Value = info.group_cd;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<SHOP_MENU> modelList = new List<SHOP_MENU>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    SHOP_MENU model = new SHOP_MENU(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점별 메뉴 조회  , 2015/04/08
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<SHOP_MENU_NEW>> GetMenuListNew(RequestMenuList info)
        {
            Result<SHOP_MENU_NEW> result = new Result<SHOP_MENU_NEW>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_MENU_LIST_NEW",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_cd", OracleDbType.Varchar2)).Value = info.group_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<SHOP_MENU_NEW> modelList = new List<SHOP_MENU_NEW>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    SHOP_MENU_NEW model = new SHOP_MENU_NEW(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴그룹 상세조회 , 2015/02/12
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopMenuGroup>> GetMenuGroupDetail(RequestMenuGroupDetail info)
        {
            Result<ShopMenuGroup> result = new Result<ShopMenuGroup>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_MENU_GROUP_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_cd", OracleDbType.Varchar2)).Value = info.group_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopMenuGroup> modelList = new List<ShopMenuGroup>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopMenuGroup model = new ShopMenuGroup(row);
                                    modelList.Add(model);
                                }

                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴그룹 조회 , 2015/01/15
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopMenuGroup>> GetMenuGroupList(RequestMenuGroupList info)
        {
            Result<ShopMenuGroup> result = new Result<ShopMenuGroup>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_MENU_GROUP_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_type", OracleDbType.Varchar2)).Value = info.group_type;
                        cmd.Parameters.Add(new OracleParameter("in_group_name", OracleDbType.Varchar2)).Value = info.group_name;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;
                        cmd.Parameters.Add(new OracleParameter("in_option_yn", OracleDbType.Varchar2)).Value = info.option_yn;
                        cmd.Parameters.Add(new OracleParameter("in_main_img_yn", OracleDbType.Varchar2)).Value = info.main_img_yn;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopMenuGroup> modelList = new List<ShopMenuGroup>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopMenuGroup model = new ShopMenuGroup(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 그룹상세  조회 , 2015/02/12
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopMenuOptionGroup>> GetMenuOGroupDetail(RequestMenuOptionGroupDetail info)
        {
            Result<ShopMenuOptionGroup> result = new Result<ShopMenuOptionGroup>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_MENU_OGROUP_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_o_group_cd", OracleDbType.Varchar2)).Value = info.option_group_cd;


                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopMenuOptionGroup> modelList = new List<ShopMenuOptionGroup>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopMenuOptionGroup model = new ShopMenuOptionGroup(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 그룹 조회 , 2015/01/15
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopMenuOptionGroup>> GetMenuOGroupList(RequestMenuOptionGroupList info)
        {
            Result<ShopMenuOptionGroup> result = new Result<ShopMenuOptionGroup>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_MENU_OGROUP_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_name", OracleDbType.Varchar2)).Value = info.group_name;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;
                        cmd.Parameters.Add(new OracleParameter("in_option_yn", OracleDbType.Varchar2)).Value = info.option_yn;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopMenuOptionGroup> modelList = new List<ShopMenuOptionGroup>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopMenuOptionGroup model = new ShopMenuOptionGroup(row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 상세 조회 , 2015/02/12
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopMenuOption>> GetMenuOptionDetail(RequestMenuOptionDetail info)
        {
            Result<ShopMenuOption> result = new Result<ShopMenuOption>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_MENU_OPTION_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Int32)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_opt_cd", OracleDbType.Int32)).Value = info.opt_cd;


                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopMenuOption> modelList = new List<ShopMenuOption>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopMenuOption model = new ShopMenuOption(row);
                                    modelList.Add(model);
                                }

                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 상세 조회 , 2015/01/15
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopMenuOption>> GetMenuOptionList(RequestMenuOptionList info)
        {
            Result<ShopMenuOption> result = new Result<ShopMenuOption>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_MENU_OPTION_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_o_group_cd", OracleDbType.Varchar2)).Value = info.option_group_cd;
                        cmd.Parameters.Add(new OracleParameter("in_option_name", OracleDbType.Varchar2)).Value = info.option_name;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            for (int i = 0; i < dt.Columns.Count; i++)
                            {
                                Debug.WriteLine(dt.Columns[i].ToString());
                            }

                            if (code.Equals("00"))
                            {
                                List<ShopMenuOption> modelList = new List<ShopMenuOption>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopMenuOption model = new ShopMenuOption(info.job_gbn, row);
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 조회 
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopMenuOptionList>> GetMenuOptionListNew(RequestMenuOptionList info)
        {
            Result<ShopMenuOptionList> result = new Result<ShopMenuOptionList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_MENU_OPTION_LIST_NEW",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopMenuOptionList> modelList = new List<ShopMenuOptionList>();
                                foreach (DataRow row in dt.Rows)
                                {
                                    ShopMenuOptionList model = new ShopMenuOptionList()
                                    {
                                        ckey = row["ckey"].ToString(),
                                        pkey = row["pkey"].ToString(),
                                        cccode = row["cccode"].ToString(),
                                        shop_cd = row["shop_cd"].ToString(),
                                        menu_cd = row["menu_cd"].ToString(),
                                        option_group_cd = row["option_group_cd"].ToString(),
                                        option_cd = row["option_cd"].ToString(),
                                        option_name = row["o_name"].ToString(),
                                        option_cost = row["ocost"].ToString(),
                                        sort_seq = Convert.ToInt32(row["sort_seq"].ToString()),
                                        option_type = row["otype"].ToString(),
                                        req_yn = row["req_yn"].ToString(),
                                        multi_yn = row["multi_yn"].ToString(),
                                        multi_count = Convert.ToInt32(row["multi_count"].ToString()),
                                        option_count = Convert.ToInt32(row["opt_cnt"].ToString()),
                                        min_count = Convert.ToInt32(row["min_count"].ToString())
                                    };
                                    modelList.Add(model);
                                }

                                result.data = modelList;
                            }

                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 메뉴상태 변경 , 2015/3/17
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetCommMenuStatus(RequestSetCommMenuStatus info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.SET_COMM_MENU_STATUS",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = info.item_cd;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_group_type", OracleDbType.Varchar2)).Value = info.menu_group_type;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_option_cd", OracleDbType.Varchar2)).Value = info.option_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_cd", OracleDbType.Varchar2)).Value = info.group_cd;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        cmd.ExecuteNonQuery();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }
                }

            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴그룹 등록
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetMenuGroup(RequestSetMenuGroup info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.SET_MENU_GROUP",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_cd", OracleDbType.Int32)).Value = info.group_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_name", OracleDbType.Varchar2)).Value = info.group_name;
                        cmd.Parameters.Add(new OracleParameter("in_group_memo", OracleDbType.Varchar2)).Value = info.group_memo;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;
                        cmd.Parameters.Add(new OracleParameter("in_option_yn", OracleDbType.Varchar2)).Value = info.option_yn;
                        cmd.Parameters.Add(new OracleParameter("in_group_file_name", OracleDbType.Varchar2)).Value = info.group_file_name;
                        cmd.Parameters.Add(new OracleParameter("in_sort_seq", OracleDbType.Varchar2)).Value = info.sort_seq;
                        cmd.Parameters.Add(new OracleParameter("in_main_img_yn", OracleDbType.Varchar2)).Value = info.main_img_yn;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        cmd.ExecuteNonQuery();
                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();
                        result.code = code;
                        result.msg = message;
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점별 메뉴 등록
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetMenuList(RequestSetMenuList info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.SET_MENU_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_cd", OracleDbType.Varchar2)).Value = info.group_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_name", OracleDbType.Varchar2)).Value = info.menu_name;
                        cmd.Parameters.Add(new OracleParameter("in_menu_sname", OracleDbType.Varchar2)).Value = info.menu_sname;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cost", OracleDbType.Varchar2)).Value = info.menu_cost;
                        cmd.Parameters.Add(new OracleParameter("in_menu_desc", OracleDbType.Varchar2)).Value = info.menu_desc;
                        cmd.Parameters.Add(new OracleParameter("in_sort_seq", OracleDbType.Varchar2)).Value = info.sort_seq;
                        cmd.Parameters.Add(new OracleParameter("in_file_name", OracleDbType.Varchar2)).Value = info.file_name;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;

                        cmd.Parameters.Add(new OracleParameter("in_m_alone_order", OracleDbType.Varchar2)).Value = info.menu_alone_order;
                        cmd.Parameters.Add(new OracleParameter("in_m_search_tag", OracleDbType.Varchar2)).Value = info.menu_search_tag;
                        cmd.Parameters.Add(new OracleParameter("in_m_main_yn", OracleDbType.Varchar2)).Value = info.menu_main_yn;
                        cmd.Parameters.Add(new OracleParameter("in_m_menu_type", OracleDbType.Varchar2)).Value = info.m_menu_type;

                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        cmd.ExecuteNonQuery();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }




            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 그룹 등록 
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SET_MENU_OGROUP(RequestSetOptionMenuGroup info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.SET_MENU_OGROUP",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_cd", OracleDbType.Varchar2)).Value = info.group_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_name", OracleDbType.Varchar2)).Value = info.group_name;
                        cmd.Parameters.Add(new OracleParameter("in_group_memo", OracleDbType.Varchar2)).Value = info.group_memo;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;
                        cmd.Parameters.Add(new OracleParameter("in_option_yn", OracleDbType.Varchar2)).Value = info.option_yn;
                        cmd.Parameters.Add(new OracleParameter("in_req_yn", OracleDbType.Varchar2)).Value = info.req_yn;
                        cmd.Parameters.Add(new OracleParameter("in_multi_yn", OracleDbType.Varchar2)).Value = info.multi_yn;
                        cmd.Parameters.Add(new OracleParameter("in_multi_count", OracleDbType.Int32)).Value = info.multi_count;
                        cmd.Parameters.Add(new OracleParameter("in_group_file_name", OracleDbType.Varchar2)).Value = info.group_file_name;
                        cmd.Parameters.Add(new OracleParameter("in_sort_seq", OracleDbType.Varchar2)).Value = info.sort_seq;
                        cmd.Parameters.Add(new OracleParameter("in_min_count", OracleDbType.Int32)).Value = info.min_count;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        cmd.ExecuteNonQuery();
                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 상세 등록
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetMenuOption(RequestSetMenuOption info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.SET_MENU_OPTION",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_option_cd", OracleDbType.Varchar2)).Value = info.option_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_cd", OracleDbType.Varchar2)).Value = info.group_cd;
                        cmd.Parameters.Add(new OracleParameter("in_option_name", OracleDbType.Varchar2)).Value = info.option_name;
                        cmd.Parameters.Add(new OracleParameter("in_option_memo", OracleDbType.Varchar2)).Value = info.option_memo;
                        cmd.Parameters.Add(new OracleParameter("in_cost", OracleDbType.Varchar2)).Value = info.cost;
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)).Value = info.use_yn;
                        cmd.Parameters.Add(new OracleParameter("in_file_name", OracleDbType.Varchar2)).Value = info.file_name;
                        cmd.Parameters.Add(new OracleParameter("in_sort_seq", OracleDbType.Varchar2)).Value = info.sort_seq;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        cmd.ExecuteNonQuery();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 메뉴 품절 처리
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ResponseMenuSoldout>> SetMenuSoldOut(RequestMenuSoldOut info)
        {
            Result<ResponseMenuSoldout> result = new Result<ResponseMenuSoldout>();

            try
            {
                using (OracleConnection connection = new OracleConnection(DbString))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = connection,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.SET_MENU_ENABLE",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_enable", OracleDbType.Varchar2)).Value = info.soldout;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseMenuSoldout> modelList = new List<ResponseMenuSoldout>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseMenuSoldout model = new ResponseMenuSoldout()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        menu_cd = reader["menu_cd"].ToString(),
                                        no_flag = reader["no_flag"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 메뉴 순서 변경
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<dynamic> SortListItem(RequestSortItem info)
        {
            CodeMsg codeMsg = new CodeMsg();

            try
            {
                using (OracleConnection con = new OracleConnection(DbString))
                {
                    await con.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = con,
                        CommandText = "PKG_IS_WEB_SHOP_T.UPDATE_SORT_SEQ",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cd_array", OracleDbType.Int32)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.item_codes.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_mod_system", OracleDbType.Varchar2)).Value = info.u_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_ucode", OracleDbType.Varchar2)).Value = info.login_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.login_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        codeMsg.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        codeMsg.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            return codeMsg;
        }

        /// <summary>
        /// 메뉴 옵션 품절/해제
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ResponseMenuOptionSoldout>> SetMenuOptionSoldout(RequestMenuOptionSoldout info)
        {
            Result<ResponseMenuOptionSoldout> result = new Result<ResponseMenuOptionSoldout>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.SET_MENU_OPTION_ENABLE",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_option_cd", OracleDbType.Varchar2)).Value = info.option_cd;
                        cmd.Parameters.Add(new OracleParameter("in_enable", OracleDbType.Varchar2)).Value = info.soldout;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_user;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseMenuOptionSoldout> modelList = new List<ResponseMenuOptionSoldout>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseMenuOptionSoldout model = new ResponseMenuOptionSoldout()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        menu_option_cd = reader["option_cd"].ToString(),
                                        o_no_flag = reader["o_no_flag"].ToString() == null ? "N" : reader["o_no_flag"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = msg;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }

        /// <summary>
        /// 대표 메뉴 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ResponseMajorMenu>> GetMajorMenu(Request info)
        {
            Result<ResponseMajorMenu> result = new Result<ResponseMajorMenu>();

            try
            {
                using (OracleConnection connection = new OracleConnection(DbString))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = connection,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.GET_MAJOR_MENU_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseMajorMenu> modelList = new List<ResponseMajorMenu>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseMajorMenu model = new ResponseMajorMenu()
                                    {
                                        menu_cd = reader["menu_cd"].ToString(),
                                        menu_name = reader["menu_name"].ToString(),
                                        m_main_yn = reader["m_main_yn"].ToString(),
                                        file_name = reader["file_name"].ToString(),
                                    };

                                    modelList.Add(model);

                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


            return result;
        }
        /// <summary>
        /// 대표 메뉴 설정
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ResponseMajorMenu>> SetMajorMenu(RequestMajorMenu info)
        {
            Result<ResponseMajorMenu> result = new Result<ResponseMajorMenu>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_V4.SET_MAJOR_MENU",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_main_yn", OracleDbType.Varchar2)).Value = info.m_main_yn;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_cd;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;
                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseMajorMenu> modelList = new List<ResponseMajorMenu>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseMajorMenu model = new ResponseMajorMenu()
                                    {
                                        menu_cd = reader["menu_cd"].ToString(),
                                        menu_name = reader["menu_name"].ToString(),
                                        m_main_yn = reader["m_main_yn"].ToString()
                                    };

                                    modelList.Add(model);

                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


            return result;
        }
        #endregion

        #region 가맹점 원산지
        /// <summary>
        /// 가맹점 원산지 가져오기
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopFoodOrigins>> GetShopOrigin(Request info)
        {
            Result<ShopFoodOrigins> result = new Result<ShopFoodOrigins>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_SHOP_DETAIL",
                        //CommandText = "PKG_IS_WEB_SHOP_V2.GET_OPERATE_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "3";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopFoodOrigins> modelList = new List<ShopFoodOrigins>();
                                while (reader.Read())
                                {
                                    ShopFoodOrigins model = new ShopFoodOrigins()
                                    {
                                        content = reader["shop_origin_mark"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 원산지 설정
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetShopOrigin(RequestSetShopOrigin info)
        {
            Result<dynamic> result = new Result<dynamic>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.SET_SHOP_ORIGIN",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_origin_mark", OracleDbType.Varchar2)).Value = info.origin_mark;
                        cmd.Parameters.Add(new OracleParameter("in_user_ucode", OracleDbType.Varchar2)).Value = info.user_code;
                        cmd.Parameters.Add(new OracleParameter("in_user_name", OracleDbType.Varchar2)).Value = info.user_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }
            return result;
        }

        /// <summary>
        /// 가맹점 소개글
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopIntro>> GetShopIntro(RequestSetShopOrigin info)
        {
            Result<ShopIntro> result = new Result<ShopIntro>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_SHOP_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "5";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopIntro> modelList = new List<ShopIntro>();
                                while (reader.Read())
                                {
                                    ShopIntro model = new ShopIntro()
                                    {
                                        shop_intro = reader["shop_intro"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        /// <summary>
        /// 가맹점 소개글 설정
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<dynamic>> SetShopIntro(RequestSetShopOrigin info)
        {
            Result<dynamic> result = new Result<dynamic>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.SET_SHOP_INTRO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_shop_intro", OracleDbType.Varchar2)).Value = info.shop_intro;
                        cmd.Parameters.Add(new OracleParameter("in_user_ucode", OracleDbType.Varchar2)).Value = info.user_code;
                        cmd.Parameters.Add(new OracleParameter("in_user_name", OracleDbType.Varchar2)).Value = info.user_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }
            return result;
        }

        #endregion

        #region 가맹점 매핑

        /// <summary>
        /// 매핑 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopMapping>> GetMapping(RequestShopMapping info)
        {
            Result<ShopMapping> result = new Result<ShopMapping>();

            using (OracleConnection conn = new OracleConnection(DbString))
            {
                await conn.OpenAsync();
                using (OracleCommand cmd = new OracleCommand()
                {
                    Connection = conn,
                    CommandText = "PKG_IS_COMM.GET_SHOP_INFO_API_MAP_LIST",
                    CommandType = CommandType.StoredProcedure
                })
                {
                    cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                    cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                    cmd.Parameters.Add(new OracleParameter("in_api_use_gbn", OracleDbType.Varchar2)).Value = info.api_use_gbn;
                    cmd.Parameters.Add(new OracleParameter("in_api_type", OracleDbType.Varchar2)).Value = info.api_type;

                    cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                    using (OracleDataReader reader = cmd.ExecuteReader())
                    {
                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        if (code.Equals("00"))
                        {
                            List<ShopMapping> modelList = new List<ShopMapping>();
                            while (reader.Read())
                            {
                                ShopMapping model = new ShopMapping()
                                {
                                    API_COM_AUTH = reader["API_COM_AUTH"].ToString(),
                                    API_COM_CODE = reader["API_COM_CODE"].ToString(),
                                    API_COM_CODE2 = reader["API_COM_CODE2"].ToString(),
                                    API_COM_GBN = reader["API_COM_GBN"].ToString(),
                                    API_COM_ID = reader["API_COM_ID"].ToString(),
                                    API_COM_PASS = reader["API_COM_PASS"].ToString(),
                                    API_COM_TOKEN = reader["API_COM_TOKEN"].ToString(),
                                    API_DAILY_TOKEN = reader["API_DAILY_TOKEN"].ToString(),
                                    API_TYPE = reader["API_TYPE"].ToString(),
                                    API_USE_YN = reader["API_USE_YN"].ToString(),
                                    CCCODE = reader["CCCODE"].ToString(),
                                    INS_DATE = reader["INS_DATE"].ToString(),
                                    INS_NAME = reader["INS_NAME"].ToString(),
                                    INS_UCODE = reader["INS_UCODE"].ToString(),
                                    MOD_DATE = reader["MOD_DATE"].ToString(),
                                    MOD_NAME = reader["MOD_NAME"].ToString(),
                                    MOD_UCODE = reader["MOD_UCODE"].ToString(),
                                    SHOP_CD = reader["SHOP_CD"].ToString(),
                                    SHOP_MAP_SEQ = reader["SHOP_MAP_SEQ"].ToString(),
                                    SHOP_NAME = reader["SHOP_NAME"].ToString(),
                                };
                                modelList.Add(model);
                            }
                            result.data = modelList;
                        }
                        result.code = code;
                        result.msg = message;
                    }

                }
            }

            return result;
        }
        /// <summary>
        /// 매핑 설정
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopMapping>> SetMapping(RequestShopMappingUpdate info)
        {
            Result<ShopMapping> result = new Result<ShopMapping>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM.SET_SHOP_INFO_API_MAP",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_map_seq", OracleDbType.Int32)).Value = info.shop_map_seq;
                        cmd.Parameters.Add(new OracleParameter("in_api_use_yn", OracleDbType.Varchar2)).Value = info.api_use_yn;
                        cmd.Parameters.Add(new OracleParameter("in_api_type", OracleDbType.Varchar2)).Value = info.api_type;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.api_com_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.api_com_code;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code2", OracleDbType.Varchar2)).Value = info.api_com_code_2;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_token", OracleDbType.Varchar2)).Value = info.api_com_token;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_auth", OracleDbType.Varchar2)).Value = info.api_com_auth;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_id", OracleDbType.Varchar2)).Value = info.api_com_id;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_pass", OracleDbType.Varchar2)).Value = info.api_com_pass;
                        cmd.Parameters.Add(new OracleParameter("in_api_daily_token", OracleDbType.Varchar2)).Value = info.api_daily_token;
                        cmd.Parameters.Add(new OracleParameter("in_api_memo", OracleDbType.Varchar2)).Value = info.api_memo;
                        cmd.Parameters.Add(new OracleParameter("in_ins_ucode", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_ins_name", OracleDbType.Varchar2)).Value = info.mod_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        //using (OracleDataReader reader = cmd.ExecuteReader())
                        cmd.ExecuteNonQuery();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// API 매핑 업체 리스트
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<API_COMPANY_INFO>> GetApiCompanyList(RequestApiCompanyInfo info)
        {
            Result<API_COMPANY_INFO> result = new Result<API_COMPANY_INFO>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.GET_API_COMPANY_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_com_type", OracleDbType.Varchar2)).Value = info.com_type;
                        cmd.Parameters.Add(new OracleParameter("in_com_code", OracleDbType.Varchar2)).Value = info.com_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_sequence", OracleDbType.Varchar2)).Value = info.sequence;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<API_COMPANY_INFO> modelList = new List<API_COMPANY_INFO>();
                                while (await reader.ReadAsync())
                                {
                                    API_COMPANY_INFO model = new API_COMPANY_INFO()
                                    {
                                        seq = reader["seq"].ToString(),
                                        company_gbn = reader["company_gbn"].ToString(),
                                        company_gbn_2 = reader["company_gbn_2"].ToString(),
                                        company_name = reader["company_name"].ToString(),
                                        company_token = reader["company_token"].ToString(),
                                        company_type = reader["company_type"].ToString(),
                                        company_auth = reader["company_auth"].ToString(),

                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// API 매핑 업체 수정
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<API_COMPANY_INFO>> SetApiCompany(RequestApiCompanyInfo info)
        {
            Result<API_COMPANY_INFO> result = new Result<API_COMPANY_INFO>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.SET_API_COMPANY_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_sequence", OracleDbType.Varchar2)).Value = info.sequence;
                        cmd.Parameters.Add(new OracleParameter("in_com_type", OracleDbType.Varchar2)).Value = info.com_type;
                        cmd.Parameters.Add(new OracleParameter("in_com_code", OracleDbType.Varchar2)).Value = info.com_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_com_code_2", OracleDbType.Varchar2)).Value = info.com_gbn_2;
                        cmd.Parameters.Add(new OracleParameter("in_com_name", OracleDbType.Varchar2)).Value = info.com_name;
                        cmd.Parameters.Add(new OracleParameter("in_com_token", OracleDbType.Varchar2)).Value = info.com_token;
                        cmd.Parameters.Add(new OracleParameter("in_com_auth", OracleDbType.Varchar2)).Value = info.com_auth;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_user;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<API_COMPANY_INFO> modelList = new List<API_COMPANY_INFO>();
                                while (await reader.ReadAsync())
                                {
                                    API_COMPANY_INFO model = new API_COMPANY_INFO()
                                    {
                                        seq = reader["seq"].ToString(),
                                        company_gbn = reader["company_gbn"].ToString(),
                                        company_gbn_2 = reader["company_gbn_2"].ToString(),
                                        company_name = reader["company_name"].ToString(),
                                        company_token = reader["company_token"].ToString(),
                                        company_type = reader["company_type"].ToString(),
                                        company_auth = reader["company_auth"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;

                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }



        #endregion

        #region 매핑 API

        /// <summary>
        /// 매핑 업체로 상점 메뉴 그룹 전송
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ResponseMappMenuGroup>> GetMappMenuGroup(RequestMappMenuGroup info)
        {
            Result<ResponseMappMenuGroup> result = new Result<ResponseMappMenuGroup>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_TEST_PACKAGE.MAPP_GET_SHOP_MENU_GROUP",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_name;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_shop;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseMappMenuGroup> modelList = new List<ResponseMappMenuGroup>();

                                while (await reader.ReadAsync())
                                {
                                    Int32.TryParse(reader["sort_seq"].ToString(), out int sort_seq);

                                    ResponseMappMenuGroup model = new ResponseMappMenuGroup
                                    {
                                        sort_seq = sort_seq,
                                        menu_group_code = reader["menu_group_cd"].ToString(),
                                        menu_group_name = reader["menu_group_name"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


            return result;
        }

        /// <summary>
        /// 매핑 업체로 상점 메뉴 리스트 전송
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ResponseMappMenuList>> GetMappMenuList(RequestMappMenuList info)
        {
            Result<ResponseMappMenuList> result = new Result<ResponseMappMenuList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_TEST_PACKAGE.MAPP_GET_SHOP_MENU_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_shop;
                        cmd.Parameters.Add(new OracleParameter("in_menu_group_cd", OracleDbType.Varchar2)).Value = info.menu_group_code;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseMappMenuList> modelList = new List<ResponseMappMenuList>();
                                while (await reader.ReadAsync())
                                {
                                    Int32.TryParse(reader["sort_seq"].ToString(), out int sort_seq);

                                    ResponseMappMenuList model = new ResponseMappMenuList
                                    {
                                        sort_seq = sort_seq,
                                        menu_group_code = reader["menu_group_cd"].ToString(),
                                        menu_group_name = reader["menu_group_name"].ToString(),
                                        menu_code = reader["menu_cd"].ToString(),
                                        menu_name = reader["menu_name"].ToString(),
                                        soldout = reader["no_flag"].ToString().Equals("Y") ? true : false
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 매핑 업체로 상점 메뉴 옵션 그룹 전송
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ResponseMappMenuOptionGroup>> GetMappMenuOptionGroup(RequestMappMenuOptionGroup info)
        {
            Result<ResponseMappMenuOptionGroup> result = new Result<ResponseMappMenuOptionGroup>();

            try
            {
                using (OracleConnection con = new OracleConnection(DbString))
                {
                    await con.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = con,
                        CommandText = "JWCHO_TEST_PACKAGE.MAPP_GET_SHOP_MENU_O_GROUP",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_name;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_shop;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_code;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseMappMenuOptionGroup> modelList = new List<ResponseMappMenuOptionGroup>();
                                while (await reader.ReadAsync())
                                {
                                    Int32.TryParse(reader["sort_seq"].ToString(), out int sort_seq);

                                    ResponseMappMenuOptionGroup model = new ResponseMappMenuOptionGroup
                                    {
                                        sort_seq = sort_seq,
                                        menu_code = reader["menu_cd"].ToString(),
                                        option_group_code = reader["option_group_cd"].ToString(),
                                        option_group_name = reader["option_group_name"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


            return result;
        }

        /// <summary>
        /// 매핑 업체로 상점 메뉴 옵션 리스트 전송
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ResponseMappMenuOptionList>> GetMappMenuOptionList(RequestMappMenuOptionList info)
        {
            Result<ResponseMappMenuOptionList> result = new Result<ResponseMappMenuOptionList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_TEST_PACKAGE.MAPP_GET_SHOP_MENU_OPTION",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_name;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_shop;
                        cmd.Parameters.Add(new OracleParameter("in_option_group_cd", OracleDbType.Varchar2)).Value = info.option_group_code;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseMappMenuOptionList> modelList = new List<ResponseMappMenuOptionList>();
                                while (await reader.ReadAsync())
                                {
                                    Int32.TryParse(reader["sort_seq"].ToString(), out int sort_seq);
                                    ResponseMappMenuOptionList model = new ResponseMappMenuOptionList()
                                    {
                                        sort_seq = sort_seq,
                                        menu_cd = reader["menu_cd"].ToString(),
                                        option_group_cd = reader["option_group_cd"].ToString(),
                                        option_group_name = reader["option_group_name"].ToString(),
                                        option_cd = reader["option_cd"].ToString(),
                                        option_name = reader["option_name"].ToString(),
                                        soldout = reader["o_no_flag"].ToString().Equals("Y") ? true : false
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            return result;
        }

        /// <summary>
        /// 매핑 업체로부터 상점 메뉴 품절/해제 수신
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<ResultSingle<ResponseSetMappMenuSoldout>> SetMappMenuSoldout(RequestSetMappMenuSoldout info)
        {
            ResultSingle<ResponseSetMappMenuSoldout> result = new ResultSingle<ResponseSetMappMenuSoldout>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_TEST_PACKAGE.MAPP_SET_MENU_SOLDOUT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_name;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_code;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_code;
                        cmd.Parameters.Add(new OracleParameter("in_soldout", OracleDbType.Varchar2)).Value = info.soldout ? "Y" : "N";
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                await reader.ReadAsync();
                                ResponseSetMappMenuSoldout model = new ResponseSetMappMenuSoldout()
                                {
                                    menu_group_code = reader["menu_group_cd"].ToString(),
                                    menu_code = reader["menu_cd"].ToString(),
                                    soldout = reader["no_flag"].ToString().Equals("Y") ? true : false,
                                };
                                result.data = model;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        /// <summary>
        /// 매핑 업체로부터 상점 메뉴 옵션 품절/해제 수신
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<ResultSingle<ResponseSetMappMenuOptionSoldout>> SetMappMenuOptionSoldout(RequestSetmappMenuOptionSoldout info)
        {
            ResultSingle<ResponseSetMappMenuOptionSoldout> result = new ResultSingle<ResponseSetMappMenuOptionSoldout>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "JWCHO_TEST_PACKAGE.MAPP_SET_MENU_OPTION_SOLDOUT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_name;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_shop;
                        cmd.Parameters.Add(new OracleParameter("in_option_cd", OracleDbType.Varchar2)).Value = info.option_code;
                        cmd.Parameters.Add(new OracleParameter("in_soldout", OracleDbType.Varchar2)).Value = info.soldout ? "Y" : "N";
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                await reader.ReadAsync();

                                ResponseSetMappMenuOptionSoldout model = new ResponseSetMappMenuOptionSoldout
                                {
                                    option_code = reader["option_cd"].ToString(),
                                    option_group_code = reader["option_group_cd"].ToString(),
                                    soldout = reader["o_no_flag"].ToString().Equals("Y") ? true : false
                                };
                                result.data = model;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 매핑 업체로부터 상점 휴점/개점
        /// </summary>
        public async Task<ResultSingle<ResponseSetMappOperate>> SetMappShopOperate(RequestSetMappOperate info)
        {
            ResultSingle<ResponseSetMappOperate> result = new ResultSingle<ResponseSetMappOperate>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "JWCHO_TEST_PACKAGE.MAPP_SET_SHOP_OPERATE",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_name;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_shop;
                        cmd.Parameters.Add(new OracleParameter("in_rest_gbn", OracleDbType.Varchar2)).Value = info.rest ? "N" : "Y";
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                await reader.ReadAsync();

                                ResponseSetMappOperate model = new ResponseSetMappOperate
                                {
                                    rest = reader["absent_yn"].ToString().Equals("Y") ? false : true
                                };
                                result.data = model;

                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 상점 휴점/개점 상태 전송
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<ResultSingle<ResponseSetMappOperate>> GetMappShopOperate(RequestSetMappOperate info)
        {
            ResultSingle<ResponseSetMappOperate> result = new ResultSingle<ResponseSetMappOperate>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_TEST_PACKAGE.MAPP_GET_SHOP_OPERATE",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_name;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_shop;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                await reader.ReadAsync();

                                ResponseSetMappOperate model = new ResponseSetMappOperate();
                                model.rest = reader["ABSENT_YN"].ToString().Equals("Y") ? false : true;

                                result.data = model;
                            }
                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        /// <summary>
        /// 상점 연결 상태 저장
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<CodeMsg> SetShopConnectionLog(RequestConnectionLog info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS_SHOP.SET_SHOP_CONN_LOG",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.in_job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_name;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_store_code;
                        cmd.Parameters.Add(new OracleParameter("in_log_gbn", OracleDbType.Varchar2)).Value = info.log_type;
                        cmd.Parameters.Add(new OracleParameter("in_ip", OracleDbType.Varchar2)).Value = info.ip;
                        cmd.Parameters.Add(new OracleParameter("in_mac", OracleDbType.Varchar2)).Value = info.mac;
                        cmd.Parameters.Add(new OracleParameter("in_memo", OracleDbType.Varchar2)).Value = info.memo;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        /// <summary>
        /// 휴점 설정
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<ResultSingle<ResponseSetMappOperate>> SetShopAbsent(RequestSetMappOperate info)
        {
            ResultSingle<ResponseSetMappOperate> result = new ResultSingle<ResponseSetMappOperate>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_POS_BTOB.SET_SHOP_ABSENT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_name;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_shop;
                        cmd.Parameters.Add(new OracleParameter("in_absent_gbn", OracleDbType.Varchar2)).Value = info.absent_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_absent_time", OracleDbType.Varchar2)).Value = info.absent_time;
                        cmd.Parameters.Add(new OracleParameter("out_absent_yn", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;


                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string absent = cmd.Parameters["out_absent_yn"].Value.ToString();
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                await reader.ReadAsync();

                                ResponseSetMappOperate model = new ResponseSetMappOperate
                                {
                                    rest = cmd.Parameters["out_absent_yn"].Value.ToString().Equals("Y") ? false : true
                                };
                                result.data = model;

                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        #endregion


        #endregion

        /// <summary>
        /// 가맹점 로그인 ( 기본정보만 수령 )
        /// </summary>
        /// <param name="id"></param>
        /// <param name="password"></param>
        /// <param name="mac"></param>
        /// <param name="ip"></param>
        /// <param name="hostname"></param>
        /// <returns></returns>
        public async Task<Result<DaeguShopInfo>> ShopLogin(string id, string password, string mac, string ip, string hostname)
        {
            Result<DaeguShopInfo> responseDaeguShopInfo = new Result<DaeguShopInfo>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_ANEW_FOOD_API_POS.GET_POS_LOGIN",
                        CommandType = CommandType.StoredProcedure

                    })
                    {
                        #region Login Parameters
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_id", OracleDbType.Varchar2)).Value = id;
                        cmd.Parameters.Add(new OracleParameter("in_pw", OracleDbType.Varchar2)).Value = password;
                        cmd.Parameters.Add(new OracleParameter("in_pc_ip", OracleDbType.Varchar2)).Value = hostname;
                        cmd.Parameters.Add(new OracleParameter("in_pc_address", OracleDbType.Varchar2)).Value = ip;
                        cmd.Parameters.Add(new OracleParameter("in_mac_address", OracleDbType.Varchar2)).Value = mac;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;
                        #endregion

                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                int cols = dt.Columns.Count;
                                int rows = dt.Rows.Count;

                                // column 출력
                                foreach (var colItem in dt.Columns)
                                {
                                    Debug.WriteLine(colItem.ToString());
                                }
                                // row 출력
                                foreach (DataRow row in dt.Rows)
                                {
                                    List<DaeguShopInfo> modelList = new List<DaeguShopInfo>();

                                    DaeguShopInfo info = new DaeguShopInfo()
                                    {
                                        GROUP_ID = row["group_id"].ToString(),
                                        CCCODE = row["cccode"].ToString(),
                                        SHOP_CD = row["shop_cd"].ToString(),
                                        ADDR = row["addr"].ToString(),
                                        API_COM_CODE = row["api_com_code"].ToString(),
                                        API_COM_GBN = row["api_com_gbn"].ToString(),
                                        API_POS_GBN = row["api_pos_gbn"].ToString(),
                                        APP_ORDER_YN = row["app_order_yn"].ToString(),
                                        CCNAME = row["ccname"].ToString(),
                                        CENTER_CALLBACK_TELNO = row["center_callback_telno"].ToString(),
                                        CENTER_MOBILE = row["center_mobile"].ToString(),
                                        DONG_NAME = row["dong_name"].ToString(),
                                        GUNGU_NAME = row["gungu_name"].ToString(),
                                        SIDO_NAME = row["sido_name"].ToString(),
                                        LAT = row["lat"].ToString(),
                                        LON = row["lon"].ToString(),
                                        MCODE = row["mcode"].ToString(),
                                        MULTI_SHOP_ID_YN = row["multi_shop_id_yn"].ToString(),
                                        NEW_CHAT_GBN = row["new_chat_gbn"].ToString(),
                                        OWNER = row["owner"].ToString(),
                                        REG_NO = row["reg_no"].ToString(),
                                        SHOP_NAME = row["shop_name"].ToString(),
                                        SHOP_TELNO = row["shop_telno"].ToString(),

                                    };
                                    modelList.Add(info);

                                }
                                responseDaeguShopInfo.code = "00";
                                responseDaeguShopInfo.msg = "성공";

                            }
                            else
                            {
                                responseDaeguShopInfo.code = code;
                                responseDaeguShopInfo.msg = message;
                            }

                        }
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }

            return responseDaeguShopInfo;
        }

        /// <summary>
        /// 가맹점 계좌 정보
        /// </summary>
        /// <param name="shopCode"></param>
        /// <returns></returns>
        public async Task<Result<ShopAccount>> ShopAccount(Request info)
        {
            Result<ShopAccount> result = new Result<ShopAccount>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        CommandText = "PKG_IS_WEB_SHOP.GET_SHOP_BANK_ACCOUNT",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopAccount> modelList = new List<ShopAccount>();
                                while (reader.Read())
                                {
                                    ShopAccount model = new ShopAccount()
                                    {
                                        ACCOUNT_NO = reader["account_no"].ToString(),
                                        ACC_OWNER = reader["ACC_OWNER"].ToString(),
                                        BANKCODE = reader["BANKCODE"].ToString(),
                                        PAY_CONFIRM = reader["PAY_CONFIRM"].ToString(),
                                        ACC_CONFIRM_GBN = reader["ACC_CONFIRM_GBN"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;

        }

        /// <summary>
        /// 가맹점 계좌 수정 ( 등록은 없음. 가맹점 테이블 이용 )
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopAccount>> SetShopAccount(RequestShopAccount info)
        {
            Result<ShopAccount> result = new Result<ShopAccount>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.SET_SHOP_BANK_ACCOUNT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_bank_cd", OracleDbType.Varchar2)).Value = info.bank_code;
                        cmd.Parameters.Add(new OracleParameter("in_account_no", OracleDbType.Varchar2)).Value = info.account;
                        cmd.Parameters.Add(new OracleParameter("in_acc_owner", OracleDbType.Varchar2)).Value = info.owner;
                        //cmd.Parameters.Add(new OracleParameter("in_pay_confirm", OracleDbType.Varchar2)).Value = info.pay_confirm;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopAccount> modelList = new List<ShopAccount>();
                                while (reader.Read())
                                {
                                    ShopAccount model = new ShopAccount()
                                    {
                                        ACCOUNT_NO = reader["account_no"].ToString(),
                                        ACC_OWNER = reader["ACC_OWNER"].ToString(),
                                        BANKCODE = reader["BANKCODE"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;

                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 사업자 정보
        /// </summary>
        /// <param name="shopCode"></param>
        /// <returns></returns>
        public async Task<Result<ShopBizInfo>> ShopBizInfo(Request info)
        {
            Result<ShopBizInfo> result = new Result<ShopBizInfo>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.GET_SHOP_BIZINFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopBizInfo> modelList = new List<ShopBizInfo>();
                                while (reader.Read())
                                {
                                    ShopBizInfo model = new ShopBizInfo()
                                    {
                                        BUSS_ADDR = reader["BUSS_ADDR"].ToString(),
                                        BUSS_CON = reader["BUSS_CON"].ToString(),
                                        BUSS_OWNER = reader["BUSS_OWNER"].ToString(),
                                        BUSS_TAX_TYPE = reader["BUSS_TAX_TYPE"].ToString(),
                                        BUSS_TYPE = reader["BUSS_TYPE"].ToString(),
                                        REG_NO = reader["REG_NO"].ToString(),
                                        OWNER = reader["OWNER"].ToString(),
                                        EMAIL = reader["EMAIL"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;

                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        public async Task<Result<ShopBizInfo>> ShopBizinfoEmail(RequestSetEmail info)
        {
            Result<ShopBizInfo> result = new Result<ShopBizInfo>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.SET_SHOP_EMAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_email", OracleDbType.Varchar2)).Value = info.Email;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopBizInfo> modelList = new List<ShopBizInfo>();
                                while (reader.Read())
                                {
                                    ShopBizInfo model = new ShopBizInfo()
                                    {
                                        BUSS_ADDR = reader["BUSS_ADDR"].ToString(),
                                        BUSS_CON = reader["BUSS_CON"].ToString(),
                                        BUSS_OWNER = reader["BUSS_OWNER"].ToString(),
                                        BUSS_TAX_TYPE = reader["BUSS_TAX_TYPE"].ToString(),
                                        BUSS_TYPE = reader["BUSS_TYPE"].ToString(),
                                        REG_NO = reader["REG_NO"].ToString(),
                                        OWNER = reader["OWNER"].ToString(),
                                        EMAIL = reader["EMAIL"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }
        public async Task<Result<ShopBizInfo>> SetShopBizInfo(RequestSetBizInfo info)
        {
            Result<ShopBizInfo> result = new Result<ShopBizInfo>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.SET_SHOP_BIZINFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_reg_no", OracleDbType.Varchar2)).Value = info.reg_no;
                        cmd.Parameters.Add(new OracleParameter("in_buss_owner", OracleDbType.Varchar2)).Value = info.owner;
                        cmd.Parameters.Add(new OracleParameter("in_buss_con", OracleDbType.Varchar2)).Value = info.buss_con;
                        cmd.Parameters.Add(new OracleParameter("in_buss_type", OracleDbType.Varchar2)).Value = info.buss_type;
                        cmd.Parameters.Add(new OracleParameter("in_buss_addr", OracleDbType.Varchar2)).Value = info.address;
                        cmd.Parameters.Add(new OracleParameter("in_buss_tax_type", OracleDbType.Varchar2)).Value = info.tax_type;
                        cmd.Parameters.Add(new OracleParameter("in_owner", OracleDbType.Varchar2)).Value = info.owner;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ShopBizInfo> modelList = new List<ShopBizInfo>();
                                while (reader.Read())
                                {
                                    ShopBizInfo model = new ShopBizInfo()
                                    {
                                        BUSS_ADDR = reader["BUSS_ADDR"].ToString(),
                                        BUSS_CON = reader["BUSS_CON"].ToString(),
                                        BUSS_OWNER = reader["BUSS_OWNER"].ToString(),
                                        BUSS_TAX_TYPE = reader["BUSS_TAX_TYPE"].ToString(),
                                        BUSS_TYPE = reader["BUSS_TYPE"].ToString(),
                                        REG_NO = reader["REG_NO"].ToString(),
                                        OWNER = reader["OWNER"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        /// <summary>
        /// 매장 정보
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ShopDefaultInfo>> ShopDefaultInfo(Request info)
        {
            Result<ShopDefaultInfo> result = new Result<ShopDefaultInfo>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {

                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.SHOP_HOMEPAGE_DEFAULT_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();
                            if (code.Equals("00"))
                            {
                                List<ShopDefaultInfo> modelList = new List<ShopDefaultInfo>();
                                while (reader.Read())
                                {
                                    ShopDefaultInfo model = new ShopDefaultInfo()
                                    {
                                        EMAIL = reader["가맹점EMAIL"].ToString(),
                                        PC_YN = reader["가맹점단말기종류"].ToString(),
                                        SHOP_LEVEL = reader["가맹점등급"].ToString(),
                                        APP_LOGO_NAME = reader["가맹점로고URL"].ToString(),
                                        TELNO = reader["가맹점전화번호"].ToString(),
                                        SHOP_TYPE = reader["가맹점타입"].ToString(),
                                        MOBILE = reader["가맹점휴대전화"].ToString(),
                                        ROAD_DEST_ADDR = reader["건물번호"].ToString(),
                                        OWNER_BIRTH = reader["대표자생년월일"].ToString(),
                                        ROAD_DEST_DONG = reader["도로명"].ToString(),
                                        DONG_NAME = reader["동명도로명"].ToString(),
                                        USE_GBN = reader["사용미사용"].ToString(),
                                        LOC = reader["상세주소"].ToString(),
                                        GUNGU_NAME = reader["시군구명"].ToString(),
                                        SIDO_NAME = reader["시도명"].ToString(),
                                        ITEM_CD = reader["업종코드"].ToString(),
                                        MAIN_ITEM = reader["주요품목"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        public async Task<Result<ShopStoreInfo>> ShopDefaultInfoNew(Request info)
        {
            Result<ShopStoreInfo> result = new Result<ShopStoreInfo>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {

                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_COMM_SHOP_WEB.GET_SHOP_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();
                            if (code.Equals("00"))
                            {
                                List<ShopStoreInfo> modelList = new List<ShopStoreInfo>();
                                while (reader.Read())
                                {
                                    ShopStoreInfo model = new ShopStoreInfo()
                                    {
                                        app_calc_amt = reader["app_calc_amt"].ToString(),
                                        app_calc_gbn = reader["app_calc_gbn"].ToString(),
                                        app_file_name = reader["app_file_name"].ToString(),
                                        app_in_date = reader["app_in_date"].ToString(),
                                        app_min_amt = reader["app_min_amt"].ToString(),
                                        app_order_yn = reader["app_order_yn"].ToString(),
                                        app_pay_type = reader["app_pay_type"].ToString(),
                                        food_order_yn = reader["food_order_yn"].ToString(),
                                        item_cd = reader["item_cd"].ToString(),
                                        item_cd2 = reader["item_cd2"].ToString(),
                                        item_cd3 = reader["item_cd3"].ToString(),
                                        lat = reader["lat"].ToString(),
                                        lon = reader["lon"].ToString(),
                                        sale_fr_time = reader["sale_fr_time"].ToString(),
                                        sale_to_time = reader["sale_to_time"].ToString(),
                                        shop_gbn = reader["가맹점구분"].ToString(),
                                        shop_name = reader["가맹점명"].ToString(),
                                        shop_cd = reader["가맹점코드"].ToString(),
                                        card_sub_id = reader["서브아이디"].ToString(),
                                        telno = reader["전화번호"].ToString(),
                                        cook_wait_time = reader["조리시간"].ToString(),
                                        u_plues_id = reader["카드아이디"].ToString(),
                                        ccname = reader["콜센타명"].ToString(),
                                        cccode = reader["콜센타코드"].ToString(),
                                        mobile = reader["휴대폰"].ToString(),
                                        addr1 = reader["addr1"].ToString(),
                                        addr2 = reader["addr2"].ToString(),
                                        alone_order = reader["alone_order"].ToString(),
                                        accept_state = reader["accept_state"].ToString(),
                                        app_logo_name = reader["app_logo_name"].ToString(),
                                        dest_jibun = reader["dest_jibun"].ToString(),
                                        dong_name = reader["dong_name"].ToString(),
                                        food_pack_fee_yn = reader["food_pack_fee_yn"].ToString(),
                                        free_order_amt = reader["free_order_amt"].ToString(),
                                        gungu_name = reader["gungu_name"].ToString(),
                                        loc = reader["loc"].ToString(),
                                        road_dest_addr = reader["road_dest_addr"].ToString(),
                                        road_dest_building = reader["road_dest_building"].ToString(),
                                        road_dest_dong = reader["road_dest_dong"].ToString(),
                                        search_tag = reader["search_tag"].ToString(),
                                        shop_type = reader["shop_type"].ToString(),
                                        sido_name = reader["sido_name"].ToString(),
                                        stamp_use_gbn = reader["stamp_use_gbn"].ToString(),
                                        memo = reader["메모"].ToString(),
                                        happy_pay = reader["iscard_use_gbn"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        public async Task<Result<ShopDefaultInfo>> ShopDefaultInfoUpdate(Request Info)
        {
            Result<ShopDefaultInfo> result = new Result<ShopDefaultInfo>();

            await Task.Delay(0);
            return result;
        }

        public async Task<Result<ShopAddress>> ShopAddress(Request info)
        {
            Result<ShopAddress> result = new Result<ShopAddress>();

            using (OracleConnection conn = new OracleConnection(DbString))
            {
                await conn.OpenAsync();
                using (OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandText = "PKG_IS_WEB_SHOP.GET_SHOP_ADDRESS",
                    CommandType = CommandType.StoredProcedure
                })
                {
                    cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                    cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                    cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                    using (OracleDataReader reader = cmd.ExecuteReader())
                    {
                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        if (code.Equals("00"))
                        {
                            List<ShopAddress> modelList = new List<ShopAddress>();
                            while (reader.Read())
                            {
                                ShopAddress model = new ShopAddress()
                                {
                                    addr1 = reader["addr1"].ToString(),
                                    addr2 = reader["addr2"].ToString(),
                                    dest_jibun = reader["dest_jibun"].ToString(),
                                    dong_name = reader["dong_name"].ToString(),
                                    gungu_name = reader["gungu_name"].ToString(),
                                    lat = Convert.ToDouble(reader["lat"].ToString()),
                                    lon = Convert.ToDouble(reader["lon"].ToString()),
                                    road_dest_addr = reader["road_dest_addr"].ToString(),
                                    road_dest_building = reader["road_dest_building"].ToString(),
                                    road_dest_dong = reader["road_dest_dong"].ToString(),
                                    sido_name = reader["sido_name"].ToString(),
                                    loc = reader["loc"].ToString()
                                };
                                modelList.Add(model);
                            }
                            result.data = modelList;
                        }
                        result.code = code;
                        result.msg = message;
                    }
                }
            }

            return result;
        }
        public async Task<Result<ShopAddress>> ShopAddressUpdate(RequestSetShopAddress info)
        {
            Result<ShopAddress> result = new Result<ShopAddress>();

            using (OracleConnection conn = new OracleConnection(DbString))
            {
                await conn.OpenAsync();
                using (OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_SHOP_INFO.SET_SHOP_ADDR"
                })
                {
                    cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                    cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                    cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                    cmd.Parameters.Add(new OracleParameter("in_lon", OracleDbType.Double)).Value = info.lon;
                    cmd.Parameters.Add(new OracleParameter("in_lat", OracleDbType.Double)).Value = info.lat;
                    cmd.Parameters.Add(new OracleParameter("in_addr1", OracleDbType.Varchar2)).Value = info.addr1;
                    cmd.Parameters.Add(new OracleParameter("in_addr2", OracleDbType.Varchar2)).Value = info.addr2;
                    cmd.Parameters.Add(new OracleParameter("in_sido_name", OracleDbType.Varchar2)).Value = info.sido_name;
                    cmd.Parameters.Add(new OracleParameter("in_gungu_name", OracleDbType.Varchar2)).Value = info.gungu_name;
                    cmd.Parameters.Add(new OracleParameter("in_dong_name", OracleDbType.Varchar2)).Value = info.dong_name;
                    cmd.Parameters.Add(new OracleParameter("in_road_dest_dong", OracleDbType.Varchar2)).Value = info.road_dest_dong;
                    cmd.Parameters.Add(new OracleParameter("in_road_dest_addr", OracleDbType.Varchar2)).Value = info.road_dest_addr;
                    cmd.Parameters.Add(new OracleParameter("in_dest_jibun", OracleDbType.Varchar2)).Value = info.dest_jibun;
                    cmd.Parameters.Add(new OracleParameter("in_road_dest_bd", OracleDbType.Varchar2)).Value = info.road_dest_bd;
                    cmd.Parameters.Add(new OracleParameter("in_loc", OracleDbType.Varchar2)).Value = info.loc;
                    cmd.Parameters.Add(new OracleParameter("in_mod_ucode", OracleDbType.Varchar2)).Value = info.mod_ucode;
                    cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_name;

                    cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                    using (OracleDataReader reader = cmd.ExecuteReader())
                    {
                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();
                        if (code.Equals("00"))
                        {
                            List<ShopAddress> modelList = new List<ShopAddress>();
                            while (reader.Read())
                            {
                                ShopAddress model = new ShopAddress()
                                {
                                    addr1 = reader["addr1"].ToString(),
                                    addr2 = reader["addr2"].ToString(),
                                    dest_jibun = reader["dest_jibun"].ToString(),
                                    dong_name = reader["dong_name"].ToString(),
                                    gungu_name = reader["gungu_name"].ToString(),
                                    lat = Convert.ToDouble(reader["lat"].ToString()),
                                    lon = Convert.ToDouble(reader["lon"].ToString()),
                                    road_dest_addr = reader["road_dest_addr"].ToString(),
                                    road_dest_building = reader["road_dest_building"].ToString(),
                                    road_dest_dong = reader["road_dest_dong"].ToString(),
                                    sido_name = reader["sido_name"].ToString()
                                };
                                modelList.Add(model);
                            }
                            result.data = modelList;
                        }
                        result.code = code;
                        result.msg = message;
                    }

                }
            }


            return result;
        }

        public async Task<Result<ShopOperateInfo>> ShopOperateInfo(int shopCode)
        {
            Result<ShopOperateInfo> result = new Result<ShopOperateInfo>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.GET_OPERATE_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = "";
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = shopCode;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;



                        DataTable dt = new DataTable();
                        using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        {
                            adapter.Fill(dt);

                            int cols = dt.Columns.Count;
                            int rows = dt.Rows.Count;

                            for (int i = 0; i < cols; i++)
                            {
                                Debug.WriteLine(dt.Columns[i].ToString());
                            }
                            List<ShopOperateInfo> modelList = new List<ShopOperateInfo>();
                            foreach (DataRow row in dt.Rows)
                            {
                                ShopOperateInfo model = new ShopOperateInfo()
                                {
                                    SALE_FR_TIME = row["영업시작시간"].ToString(),
                                    SALE_TO_TIME = row["영업종료시간"].ToString(),
                                    ABSENT_YN = row["개점휴점_영업일시정지"].ToString(),
                                    HOLIDAY_TERM = row["정기휴일"].ToString()
                                };
                                modelList.Add(model);

                            }
                            result.data = modelList;
                            result.code = "00";
                            result.msg = "성공";
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }
        public async Task<Result<Models.Operate.Request.ShopOperateInfo_V2>> ShopOperateInfo_v2(int shopCode)
        {
            Result<Models.Operate.Request.ShopOperateInfo_V2> result = new Result<Models.Operate.Request.ShopOperateInfo_V2>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_V2.GET_OPERATE_INFO",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = shopCode;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor2", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync(CommandBehavior.CloseConnection))
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();
                            List<Models.Operate.Request.ShopOperateInfo_V2> modelList = new List<Models.Operate.Request.ShopOperateInfo_V2>();
                            Models.Operate.Request.ShopOperateInfo_V2 model = new Models.Operate.Request.ShopOperateInfo_V2();
                            if (code.Equals("00"))
                            {
                                while (await reader.ReadAsync())
                                {

                                    model.ABSENT_YN = reader[0].ToString();
                                    model.SHOP_ORIGIN_MARK = reader[1].ToString();
                                    model.REVIEW_USE_GBN = reader[2].ToString();
                                    model.HOLIDAY_TERM = reader[3].ToString();
                                }
                                if (reader.NextResult())
                                {
                                    Models.Operate.Request.TipShopOperateInfo items = new Models.Operate.Request.TipShopOperateInfo();
                                    model.TipList = new List<TipShopOperateInfo>();
                                    while (await reader.ReadAsync())
                                    {
                                        items.TIP_SEQ = reader[0].ToString();
                                        items.TIP_DAY = reader[1].ToString();
                                        items.TIP_FR_STAND = reader[2].ToString();
                                        items.TIP_TO_STAND = reader[3].ToString();
                                        items.TIP_NEXT_DAY = reader[4].ToString();

                                        model.TipList.Add(items);
                                    }

                                }
                                modelList.Add(model);
                                model = null;
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }

                        //DataTable dt = new DataTable();
                        //using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                        //{
                        //    adapter.Fill(dt);

                        //    int cols = dt.Columns.Count;
                        //    int rows = dt.Rows.Count;

                        //    for (int i = 0; i < cols; i++)
                        //    {
                        //        Debug.WriteLine(dt.Columns[i].ToString());
                        //    }
                        //    List<ShopOperateInfo_V2> modelList = new List<ShopOperateInfo_V2>();
                        //    foreach (DataRow row in dt.Rows)
                        //    {
                        //        ShopOperateInfo_V2 model = new ShopOperateInfo_V2()
                        //        {
                        //            ABSENT_YN = row["ABSENT_YN"].ToString(),
                        //            SHOP_ORIGIN_MARK = row["SHOP_ORIGIN_MARK"].ToString(),
                        //            REVIEW_USE_GBN = row["영업시작시간"].ToString(),
                        //            SALE_TO_TIME = row["영업종료시간"].ToString(),
                        //            ABSENT_YN = row["개점휴점_영업일시정지"].ToString(),
                        //            HOLIDAY_TERM = row["정기휴일"].ToString()
                        //        };
                        //        modelList.Add(model);

                        //    }
                        //    result.data = modelList;
                        //    result.code = "00";
                        //    result.msg = "성공";
                        //}
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }

        public async Task<Result<ReviewStatus>> ShopReviewStatus(Request info)
        {
            Result<ReviewStatus> result = new Result<ReviewStatus>();

            try
            {
                using (OracleConnection connection = new OracleConnection(DbString))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = connection,
                        CommandText = "PKG_IS_WEB_SHOP_V2.GET_REVIEW_STATUS",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ReviewStatus> modelList = new List<ReviewStatus>();
                                while (await reader.ReadAsync())
                                {
                                    ReviewStatus model = new ReviewStatus()
                                    {
                                        status = reader["review_use_gbn"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        #region 리뷰

        /// <summary>
        /// 리뷰 사용/미사용
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ReviewStatus>> SetReviewGbn(RequsetSetReviewGbn info)
        {
            Result<ReviewStatus> result = new Result<ReviewStatus>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP_V2.SET_REVIEW_YN",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_use_gbn", OracleDbType.Varchar2)).Value = info.use_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_user;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ReviewStatus> modelList = new List<ReviewStatus>();
                                while (await reader.ReadAsync())
                                {
                                    ReviewStatus model = new ReviewStatus()
                                    {
                                        status = reader["review_use_gbn"].ToString()
                                    };
                                    modelList.Add(model);
                                }

                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }


        #endregion

        #region 가맹점 정보 변경 API


        /// <summary>
        /// 아이디 변경
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<CodeMsg> ChangeId(RequestChangeId info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        CommandText = "JWCHO_TEST_PACKAGE.SET_SHOP_ID",
                        Connection = conn,
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_id", OracleDbType.Varchar2)).Value = info.Id;
                        cmd.Parameters.Add(new OracleParameter("mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("mod_name", OracleDbType.Varchar2)).Value = info.mod_user;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 비밀번호 변경
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<CodeMsg> ChangePassword(RequestChangePassword info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "JWCHO_TEST_PACKAGE.SET_PASSWORD",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_id", OracleDbType.Varchar2)).Value = info.id;
                        cmd.Parameters.Add(new OracleParameter("in_current", OracleDbType.Varchar2)).Value = info.current;
                        cmd.Parameters.Add(new OracleParameter("in_pw", OracleDbType.Varchar2)).Value = info.password;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_user;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 영업 상태 변경 ( 단독 )
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<ResultSingle<ResponseShopRunningStatus>> SetShopRunningStatus(RequestShopRunningStatus info)
        {
            ResultSingle<ResponseShopRunningStatus> result = new ResultSingle<ResponseShopRunningStatus>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS_SHOP.SET_SHOP_RUNNING",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_absent", OracleDbType.Varchar2)).Value = info.runningStatus;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_user;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                while (await reader.ReadAsync())
                                {
                                    ResponseShopRunningStatus model = new ResponseShopRunningStatus()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        running_status = reader["absent_yn"].ToString(),
                                    };
                                    result.data = model;
                                }
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }

        /// <summary>
        /// 가맹점 사업자 번호 변경
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public async Task<Result<ResponseShopBizNo>> SetShopBizNo(RequestShopBizno info)
        {
            Result<ResponseShopBizNo> result = new Result<ResponseShopBizNo>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_API_POS_SHOP.SET_SHOP_BIZ_NUMBER",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_cur_biz_no", OracleDbType.Varchar2)).Value = info.current_bizno;
                        cmd.Parameters.Add(new OracleParameter("in_biz_no", OracleDbType.Varchar2)).Value = info.bizno;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_code;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_user;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseShopBizNo> modelList = new List<ResponseShopBizNo>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseShopBizNo model = new ResponseShopBizNo()
                                    {
                                        bizno = reader["reg_no"].ToString(),
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        #endregion

        #region 상점 통계 자료

        public async Task<Result<ResponseShopManagerList>> GetShopManagerList(RequestShopManagerList info)
        {
            Result<ResponseShopManagerList> result = new Result<ResponseShopManagerList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.GET_SHOP_MANAGER_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_fr_date", OracleDbType.Varchar2)).Value = info.from_date;
                        cmd.Parameters.Add(new OracleParameter("in_to_date", OracleDbType.Varchar2)).Value = info.to_date;
                        cmd.Parameters.Add(new OracleParameter("in_day_gbn", OracleDbType.Varchar2)).Value = info.day_gbn;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseShopManagerList> modelList = new List<ResponseShopManagerList>();
                                while (await reader.ReadAsync())
                                {
                                    modelList.Add(new ResponseShopManagerList((ShopManagerType)Convert.ToInt32(info.job_gbn), reader));
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        public async Task<Result<ResponseShopSalesList>> GetShopSalesList(RequestShopSalesList info)
        {
            Result<ResponseShopSalesList> result = new Result<ResponseShopSalesList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.GET_SHOP_SALES_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_pack_order_yn", OracleDbType.Varchar2)).Value = info.pack_order_yn;
                        cmd.Parameters.Add(new OracleParameter("in_fr_date", OracleDbType.Varchar2)).Value = info.from_date;
                        cmd.Parameters.Add(new OracleParameter("in_to_date", OracleDbType.Varchar2)).Value = info.to_date;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseShopSalesList> modelList = new List<ResponseShopSalesList>();
                                while (await reader.ReadAsync())
                                {
                                    modelList.Add(new ResponseShopSalesList((SalesType)Convert.ToInt32(info.job_gbn), reader));
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        public async Task<Result<ResponseShopSalesList>> GetShopSalse_v2_List(RequestShopSalesList info)
        {
            Result<ResponseShopSalesList> result = new Result<ResponseShopSalesList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.GET_SHOP_SALES_LIST_V2",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_pack_order_yn", OracleDbType.Varchar2)).Value = info.pack_order_yn;
                        cmd.Parameters.Add(new OracleParameter("in_app_order_gbn", OracleDbType.Varchar2)).Value = info.app_order_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_pay_bgn", OracleDbType.Varchar2)).Value = info.pay_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_charge_gbn", OracleDbType.Varchar2)).Value = info.charge_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_fr_date", OracleDbType.Varchar2)).Value = info.from_date;
                        cmd.Parameters.Add(new OracleParameter("in_to_date", OracleDbType.Varchar2)).Value = info.to_date;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseShopSalesList> modelList = new List<ResponseShopSalesList>();
                                while (await reader.ReadAsync())
                                {
                                    modelList.Add(new ResponseShopSalesList((SalesType)Convert.ToInt32(info.job_gbn), reader));
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        public async Task<Result<ResponseShopSalesList>> GetShopCharge_v2_List(RequestShopSalesList info)
        {
            Result<ResponseShopSalesList> result = new Result<ResponseShopSalesList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.GET_SHOP_SALES_LIST_V2",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_pack_order_yn", OracleDbType.Varchar2)).Value = info.pack_order_yn;
                        cmd.Parameters.Add(new OracleParameter("in_app_order_gbn", OracleDbType.Varchar2)).Value = info.app_order_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_pay_bgn", OracleDbType.Varchar2)).Value = info.pay_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_charge_gbn", OracleDbType.Varchar2)).Value = info.charge_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_fr_date", OracleDbType.Varchar2)).Value = info.from_date;
                        cmd.Parameters.Add(new OracleParameter("in_to_date", OracleDbType.Varchar2)).Value = info.to_date;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseShopSalesList> modelList = new List<ResponseShopSalesList>();
                                while (await reader.ReadAsync())
                                {
                                    modelList.Add(new ResponseShopSalesList((SalesType)Convert.ToInt32(info.job_gbn), reader));
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        #endregion

        #region 메뉴 옵션 그룹 & 옵션

        public async Task<ResultSingle<ResponseGetOGnOptions>> GetMenuOptionGroupAndOptions(RequestGetOGnOptions info)
        {
            ResultSingle<ResponseGetOGnOptions> result = new ResultSingle<ResponseGetOGnOptions>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.GET_MENU_OPTION_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_option_group_cd", OracleDbType.Varchar2)).Value = info.optionGroupCd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                await reader.ReadAsync();

                                ResponseGetOGnOptions model = new ResponseGetOGnOptions();
                                model.group_type = reader["group_type"].ToString();
                                model.cccode = reader["cccode"].ToString();
                                model.shop_cd = reader["shop_cd"].ToString();
                                model.menu_cd = reader["menu_cd"].ToString();
                                model.optionGroupCd = reader["o_group_cd"].ToString();
                                model.optionGroupName = reader["o_group_name"].ToString();
                                model.optionGroupMemo = reader["o_group_memo"].ToString();
                                model.option_yn = reader["option_yn"].ToString();
                                model.use_yn = reader["use_yn"].ToString();
                                model.sort_seq = reader["sort_seq"].ToString();
                                model.file_name = reader["file_name"].ToString();
                                model.req_yn = reader["req_yn"].ToString();
                                model.multi_yn = reader["multi_yn"].ToString();
                                model.multi_count = reader["multi_count"].ToString();
                                model.min_count = reader["min_count"].ToString();

                                model.options = new List<OGnOption>();
                                while (await reader.ReadAsync())
                                {
                                    OGnOption option = new OGnOption()
                                    {
                                        group_type = reader["group_type"].ToString(),
                                        optionGroupCd = reader["o_group_cd"].ToString(),
                                        option_cd = reader["option_cd"].ToString(),
                                        option_name = reader["option_name"].ToString(),
                                        option_meno = reader["option_memo"].ToString(),
                                        option_cost = reader["option_cost"].ToString(),
                                        option_use_yn = reader["use_yn"].ToString(),
                                        sort_seq = reader["sort_seq"].ToString(),
                                        file_name = reader["file_name"].ToString(),
                                        o_no_flag = reader["o_no_flag"].ToString()
                                    };
                                    model.options.Add(option);
                                }
                                result.data = model;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;

        }

        public async Task<Result<ResponseGetOGnOptions>> SetMenuOptionGroupAndOptions(RequestSetOGnOptions info)
        {
            Result<ResponseGetOGnOptions> result = new Result<ResponseGetOGnOptions>();

            try
            {
                #region Make Option List
                var workGbnList = new List<string>();
                var optionCodeList = new List<long>();
                var optionNameList = new List<string>();
                var optionMemoList = new List<string>();
                var optionCostList = new List<int>();
                var optionUseYnList = new List<string>();
                var noFlagList = new List<string>();
                var sortSeqList = new List<int>();

                if (info.options != null && info.options.Count > 0)
                {
                    foreach (var item in info.options)
                    {
                        workGbnList.Add(item.work_gbn);
                        optionCodeList.Add(Convert.ToInt64(item.option_cd));
                        optionNameList.Add(item.option_name);
                        optionMemoList.Add(item.option_memo);
                        optionCostList.Add(Convert.ToInt32(item.option_cost));
                        optionUseYnList.Add(item.option_use_yn);
                        noFlagList.Add(item.o_no_flag);
                        sortSeqList.Add(item.sort_seq);
                    }
                }
                else
                {
                    workGbnList.Add("NONE");
                    optionCodeList.Add(0);
                    optionNameList.Add("NONE");
                    optionMemoList.Add("NONE");
                    optionCostList.Add(0);
                    optionUseYnList.Add("NONE");
                    noFlagList.Add("NONE");
                    sortSeqList.Add(0);
                }
                #endregion

                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "JWCHO_SHOP_INFO_PACKAGE.UPDATE_MENU_OPTION_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_group_cd", OracleDbType.Varchar2)).Value = info.optionGroupCd;
                        cmd.Parameters.Add(new OracleParameter("in_group_name", OracleDbType.Varchar2)).Value = info.optionGroupName;
                        cmd.Parameters.Add(new OracleParameter("in_min_count", OracleDbType.Varchar2)).Value = info.min_count;
                        cmd.Parameters.Add(new OracleParameter("in_max_count", OracleDbType.Varchar2)).Value = info.multi_count;
                        cmd.Parameters.Add(new OracleParameter("in_group_use_yn", OracleDbType.Varchar2)).Value = info.option_group_use_yn;
                        cmd.Parameters.Add(new OracleParameter("in_work_gbn", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = workGbnList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_option_cd", OracleDbType.Int64)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = optionCodeList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_option_name", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = optionNameList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_option_memo", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = optionMemoList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_cost", OracleDbType.Int32)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = optionCostList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_use_yn", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = optionUseYnList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_no_flag", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = noFlagList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("sort_seq", OracleDbType.Int32)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = sortSeqList.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_user;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();


                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        result.code = code;
                        result.msg = message;

                    }


                }
            }
            catch (Exception)
            {

                throw;
            }

            return result;
        }


        #endregion

        #region System InOut Log

        public async Task<CodeMsg> SetShopInOut(RequestSystemInout info)
        {
            CodeMsg result = new CodeMsg();

            Debug.WriteLine(DbString);
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_WEB_SHOP.SET_SHOP_SYSETM_INOUT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_mcode", OracleDbType.Varchar2)).Value = info.mcode;
                        cmd.Parameters.Add(new OracleParameter("in_cccode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_ucode", OracleDbType.Varchar2)).Value = info.cccode;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_user_id", OracleDbType.Varchar2)).Value = info.user_id;
                        cmd.Parameters.Add(new OracleParameter("in_macaddress", OracleDbType.Varchar2)).Value = info.mac_address;
                        cmd.Parameters.Add(new OracleParameter("in_pc_name", OracleDbType.Varchar2)).Value = info.pc_name;
                        cmd.Parameters.Add(new OracleParameter("in_pc_ip", OracleDbType.Varchar2)).Value = info.pc_ip;
                        cmd.Parameters.Add(new OracleParameter("in_log_gbn", OracleDbType.Varchar2)).Value = info.log_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_inout_gbn", OracleDbType.Varchar2)).Value = info.inout_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_pgm_id", OracleDbType.Varchar2)).Value = info.pgm_id;
                        cmd.Parameters.Add(new OracleParameter("in_pgm_name", OracleDbType.Varchar2)).Value = info.pgm_name;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }
        #endregion

        #region 사장님 사이트의 메뉴/배달팁/운영 정보 등의 동의 여부 확인/조회

        public async Task<ResultSingle<ResponseUserAgreement>> GetShopInfoAgreement(RequestGetUserAgreement info)
        {
            ResultSingle<ResponseUserAgreement> result = new ResultSingle<ResponseUserAgreement>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_USER_AGREEMENT.GET_SHOP_INFO_USER_AGREEMENT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_name;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_store_code;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_value", OracleDbType.Varchar2, 100)).Direction = ParameterDirection.Output;


                        using (var reader = cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();
                            string value = cmd.Parameters["out_ret_value"].Value.ToString();

                            result.code = code;
                            result.msg = message;
                            result.data = new ResponseUserAgreement
                            {
                                agreement = value
                            };
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        public async Task<ResultSingle<ResponseUserAgreement>> SetShopInfoAgreement(RequestSetUserAgreement info)
        {
            ResultSingle<ResponseUserAgreement> result = new ResultSingle<ResponseUserAgreement>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_USER_AGREEMENT.SET_SHOP_INFO_USER_AGREEMENT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_gbn", OracleDbType.Varchar2)).Value = info.company_name;
                        cmd.Parameters.Add(new OracleParameter("in_api_com_code", OracleDbType.Varchar2)).Value = info.company_store_code;
                        cmd.Parameters.Add(new OracleParameter("in_device_type", OracleDbType.Varchar2)).Value = info.device_type;
                        cmd.Parameters.Add(new OracleParameter("in_device_info", OracleDbType.Varchar2)).Value = info.device_info;
                        cmd.Parameters.Add(new OracleParameter("in_confirm_yn", OracleDbType.Varchar2)).Value = "Y";
                        cmd.Parameters.Add(new OracleParameter("in_pos_id", OracleDbType.Varchar2)).Value = info.pos_id;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_value", OracleDbType.Varchar2, 100)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                        result.data = new ResponseUserAgreement
                        {
                            agreement = cmd.Parameters["out_ret_value"].Value.ToString()
                        };

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }

        #endregion
    }
}
