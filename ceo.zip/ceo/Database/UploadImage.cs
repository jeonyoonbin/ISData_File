﻿using Microsoft.Extensions.Configuration;
using PosWebApp.Common;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Database
{
    public enum UploadType
    {
        LOGO = 1,
        SIGNBOARD,
        MENU_GROUP,
        MENU,
        MENU_OPTION_GROUP,
        MENU_OPTION
    }

    public class UploadImage : IUploadImage
    {
        private readonly DgShopApiService dgShop;
        private readonly long fileSizeLimit;
        private readonly string storeImgPath;
        private readonly string logoImgPath;
        private readonly string menuImgPath;
        private readonly string domain;

        public UploadImage()
        {

        }
        public UploadImage(IConfiguration configuration, DgShopApiService api)
        {
            dgShop = api;

            #region 파일 업로드 관련
            fileSizeLimit = configuration.GetValue<long>("upload:FileSizeLimit");
            storeImgPath = configuration.GetValue<string>("upload:shopSignBoardPath");
            logoImgPath = configuration.GetValue<string>("upload:shopLogoPath");
            menuImgPath = configuration.GetValue<string>("upload:menuPath");
            domain = configuration.GetValue<string>("upload:appDomain");
            #endregion
        }

        public async Task<ResponseUploadImage> Upload(UploadFile model, ShopSessionDefaultInfo info, string type)
        {
            ResponseUploadImage response = new ResponseUploadImage();

            LogManager log = new LogManager();


            try
            {
                var responseFileInfo = CheckFile(model);

                if (!responseFileInfo.code.Equals("00"))
                {
                    return responseFileInfo;
                }

                // 파일 이름 보안. 업로드한 파일과 동일한 파일명을 사용하지 않는다.
                //Path.GetRandomFileName()
                //Path.GetTempFileName()
                var extension = Path.GetExtension(model.FormFile.FileName);

                // 폴더 생성
                var saveFolder = GetSaveFolder(type, info);

                // 파일 저장 ( Local )
                var filePath = await CreateAndCopyFile(model, saveFolder, extension);
                if (filePath.code.Equals("00"))
                {
                    // 이미지 URL 저장
                    var temp = await SaveImageUrlToDatabase(type, filePath.url, info);
                    response = temp;
                    response.url = filePath.url; 
                    return response;
                }
                else
                {
                    response = filePath;
                }
            }
            catch (Exception e)
            {
                log.writeLine(e.Message);
                response.code = "99";
                response.message = e.Message;
            }

            return response;
        }

        private ResponseUploadImage CheckFile(UploadFile model)
        {
            ResponseUploadImage response = new ResponseUploadImage();

            if (model.FormFile.Length < 1)
            {
                response.code = "99";
                response.message = string.Concat("파일을 전송 받지 못했습니다. 네티워크 또는 서버 문제일 수 있습니다.", model.FormFile.FileName);
                return response;
            }

            // 이미지 체크
            if (!Utils.IsImage(model.FormFile))
            {
                response.code = "99";
                response.message = string.Concat("지원하지 않는 파일 입니다.", model.FormFile.FileName);
                return response;
            }

            // 이미지 확장자 체크
            if (!Utils.IsImageExtension(model.FormFile))
            {
                response.code = "99";
                response.message = string.Concat("지원하지 않는 파일 입니다.", model.FormFile.FileName);
                return response;
            }

            /// 파일 사이즈 체크
            if (model.FormFile.Length > Convert.ToInt32(fileSizeLimit))
            {
                response.code = "99";
                response.message = string.Concat("파일 사이즈가 너무 큽니다. : ", model.FormFile);
                return response;
            }

            response.code = "00";
            response.message = "성공";
            return response;
        }

        /// <summary>
        /// 이미지 저장 경로 설정
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        private string GetImagePath(string type)
        {
            switch (type)
            {
                case nameof(UploadType.LOGO):
                    return logoImgPath;
                case nameof(UploadType.SIGNBOARD):
                    return storeImgPath;
                case nameof(UploadType.MENU):
                    return menuImgPath;
                default:
                    return "";
            }
        }

        /// <summary>
        /// 가맹점 별 저장 폴더 생성
        /// </summary>
        /// <param name="type"></param>
        /// <param name="info"></param>
        /// <returns></returns>
        private string GetSaveFolder(string type, ShopSessionDefaultInfo info)
        {
            LogManager log = new LogManager();
            // 호출 된 화면에 따른 이미지 파일 경로를 추출
            string imagePath = GetImagePath(type);

            log.writeLine(imagePath);

            var saveFolder = Path.Combine(imagePath, info.cccode, info.shop_cd.ToString());
            if (!Directory.Exists(saveFolder))
            {
                log.writeLine("Create Directory");
                Directory.CreateDirectory(saveFolder);
            }
            return saveFolder;
        }

        private async Task<ResponseUploadImage> CreateAndCopyFile(UploadFile model, string saveFolder, string extension)
        {
            ResponseUploadImage response = new ResponseUploadImage();
            try
            {
                // 랜덤 파일명 생성
                var filePath = Path.Combine(string.Concat(Utils.GenerateRandomFileName(), extension));
                LogManager log = new LogManager();
                log.writeLine(filePath);

                if (File.Exists(Path.Combine(saveFolder, filePath)))
                {
                    log.writeLine("delete exist file");
                    File.Delete(Path.Combine(saveFolder, filePath));
                }
                // 파일 생성
                using var stream = System.IO.File.Create(Path.Combine(saveFolder, filePath));
                // 파일 복사
                await model.FormFile.CopyToAsync(stream);

                response.code = "00";
                response.message = "성공";
                response.url = filePath;
                return response;
            }
            catch (Exception e)
            {
                response.code = "99";
                response.message = e.Message;
            }

            return response;
        }

        private async Task<ResponseUploadImage> SaveImageUrlToDatabase(string type, string filePath, ShopSessionDefaultInfo info)
        {
            ResponseUploadImage response = new ResponseUploadImage();

            string url = string.Empty;
            switch (type)
            {
                case nameof(UploadType.LOGO):
                    url = "SetLogoImage";
                    break;

                case nameof(UploadType.SIGNBOARD):
                    url = "SetStoreImage";
                    break;
                case nameof(UploadType.MENU):
                    {
                        response.code = "00";
                        response.message = "성공";
                    }
                    return response;
                default:
                    break;
            }

            var temp = await dgShop.Post<StoreImageUrl, RequestSetImageUrl>(url, new RequestSetImageUrl
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                image_url = filePath,
                mod_code = info.login_code,
                mod_user = info.login_name
            });

            response.code = temp.code;
            response.message = temp.msg;
            
            return response;
        }
    }
}
