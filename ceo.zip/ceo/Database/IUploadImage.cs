﻿using PosWebApp.Models.ResponseModel;
using PosWebApp.ViewModels;
using System.Threading.Tasks;

namespace PosWebApp.Database
{
    public interface IUploadImage
    {
        Task<ResponseUploadImage> Upload(UploadFile model, ShopSessionDefaultInfo info, string type);
    }
}