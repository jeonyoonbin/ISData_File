﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PosWebApp.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Database
{
    public class CommonData
    {
        private static List<string> GetHours24()
        {
            List<string> temp = new List<string>();
            for (int i = 0; i <= 24; i++)
            {
                temp.Add(string.Format("{0:D2}", i));
            }
            return temp;
        }
        private static List<string> GetMinutes()
        {
            List<string> temp = new List<string>();
            for (int i = 0; i <= 59; i += 10)
            {
                temp.Add(string.Format("{0:D2}", i));
            }
            return temp;
        }
        public static List<SelectListItem> GetHoursSelect()
        {
            List<SelectListItem> itemList = new List<SelectListItem>();
            foreach (var item in GetHours24())
            {
                var temp = new SelectListItem()
                {
                    Text = $"{item} 시",
                    Value = item,
                    Selected = false
                };
                itemList.Add(temp);
            }
            return itemList;
        }
        public static List<SelectListItem> GetMinutesSelect()
        {
            List<SelectListItem> itemList = new List<SelectListItem>();
            foreach (var item in GetMinutes())
            {
                itemList.Add(new SelectListItem()
                {
                    Text = $"{item} 분",
                    Value = item,
                    Selected = false
                });
            }
            return itemList;
        }
        public static List<SelectListItem> GetB2bCompanyType()
        {
            List<SelectListItem> itemList = new List<SelectListItem>();
            itemList.Add(new SelectListItem
            {
                Text = "주문",
                Value = "1",
            });
            itemList.Add(new SelectListItem
            {
                Text = "POS(배달)",
                Value = "3"
            });
            return itemList;
        }
        public static List<SelectListItem> GetUseGBN()
        {
            List<SelectListItem> itemList = new List<SelectListItem>();
            itemList.Add(new SelectListItem
            {
                Text = "사용",
                Value = "Y"
            });
            itemList.Add(new SelectListItem
            {
                Text = "미사용",
                Value = "N"
            });
            return itemList;
        }
    }

}
