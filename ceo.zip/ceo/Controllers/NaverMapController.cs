﻿using AspNetCoreHero.ToastNotification.Abstractions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Options;
using Microsoft.JSInterop;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels;
using PosWebApp.ApiModels.Geo.address.Request;
using PosWebApp.ApiModels.Geo.address.Response;
using PosWebApp.ApiModels.Geo.Naver.Request;
using PosWebApp.ApiModels.Geo.Naver.Response;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.ApiModels.Shop.Response;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.GeoFence;
using PosWebApp.Models.GIS;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Poly;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.NaverGeoFence;
using PosWebApp.Settings;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class NaverMapController : Controller
    {

        private string _result;
        private object xResult;
        private readonly GeoFenceApi api;
       // private readonly DawulService dawul;
        private readonly DgShopApiService dgShop;
        private readonly INotyfService notify;
        private readonly IOptions<ApiStrings> apiStrings;

        public NaverMapController(GeoFenceApi api, DgShopApiService dgShop, INotyfService notify, IOptions<ApiStrings> apiStrings)
        {
            this.api = api;
           // this.dawul = dawul;
            this.dgShop = dgShop;
            this.notify = notify;
            this.apiStrings = apiStrings;
        }
        public async Task<IActionResult> Index()
        {

            await Task.Delay(0);
            return View();
        }
        public async Task<IActionResult> InOut()
        {
            await Task.Delay(0);
            return View();
        }
        public async Task<IActionResult> Edit()
        {
            await Task.Delay(0);
            return View();
        }

        public async Task<IActionResult> In()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            int keySplit = info.shop_cd % 2;
            string NaverCode = "";
            if(keySplit == 0)
            {
                NaverCode = "e1w8riblms";
            }else
            {
                NaverCode = "zoh7rn2ppp";
            }

            var req = await dgShop.Post<ResponseShopInfo, RequestShopInfo>("/api/ShopManagement/GetShopInfo", new RequestShopInfo
            {
                job_gbn = "1",
                shop_cd = info.shop_cd,

            });

            if (req.code.Equals("00"))
            {
                ViewBag.GroupArea = await GetAreaGroup();
                ViewBag.NaverCode = NaverCode;
                return View(req.data);
            }
           
            await Task.Delay(0);
            return View();
        } 
        public JsonResult DaeguJson()
        {
            try
            {
                var folderJSON = Path.Combine(Directory.GetCurrentDirectory(), $"wwwroot\\{"Json\\dongdaeguLine3.deojson.geojson"}");
                var JSON = System.IO.File.ReadAllText(folderJSON);

                var jsonObj = JsonConvert.DeserializeObject<NaverGeoJson>(JSON);

                return Json(jsonObj);
            }
            catch (Exception e)
            {
                return Json(new
                {
                    code = "99",
                    Msg = e.Message
                });
            }
        }


        [HttpPost]
        public async Task<IActionResult> Edit(string str)
        {
            await Task.Delay(0);
            return View();
        }
        #region New Naver API 
        // private async Task TileIndex() => _result = await _JsModule.InvokeAsync<string>("NaverLatLngToPoint", xResult);

        [HttpPost]
        public async Task<IActionResult> getCoordinateToPoint(string x, string y, string z)
        {
            if (string.IsNullOrEmpty(x))
            {
                return Ok(new
                {
                    code = "00",
                    Msg = "실패"
                });
            }

            //var sinLatitude = Math.sin(e.coord._lat * Math.PI / 180);

            //var pX = ((e.coord._lng + 180) / 360) * imgTileSize * Math.pow(2, map.getZoom());

            //var pY = (0.5 - Math.log((1 + sinLatitude) / (1 - sinLatitude)) / (4 * Math.PI)) * imgTileSize * Math.pow(2, map.getZoom());

            //console.log("px : " + Math.floor(pX / imgTileSize) + " " + "pY : " + Math.floor(pY / imgTileSize));


            var DefaultLevel = Convert.ToInt32(z); // 기본 줌 레벨
            var MaxLevel = 21; // 최대 줌레벨
            var imgTileSize = 128;

            var _lat = Convert.ToDouble(y);
            var _lng = Convert.ToDouble(x);

            var sinLatitude = Math.Sin(_lat * Math.PI / 180);
            List<AreaItem> list = new List<AreaItem>();

            for (var i = 0; i < MaxLevel + 1 - DefaultLevel; i++)
            {
                var value = new AreaItem();
                var zoomLevel = DefaultLevel + i;
                var pX = ((_lng + 180) / 360) * imgTileSize * Math.Pow(2, zoomLevel);
                var pY = (0.5 - Math.Log((1 + sinLatitude) / (1 - sinLatitude)) / (4 * Math.PI)) * imgTileSize * Math.Pow(2, zoomLevel);
                value.Zoom = zoomLevel.ToString();
                value.xIndex = Math.Floor(pX / imgTileSize).ToString();
                value.yIndex = Math.Floor(pY / imgTileSize).ToString();

                list.Add(value);
            }
            var req = list;

            await Task.Delay(0);
            return Ok(new
            {
                code = "00",
                Msg = "성공",
                data  = req
            });
        }
        [HttpPost]
        public async Task<IActionResult> getAreaIndex()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var req = await dgShop.Post<ResponseAreaMap, RequestGeoInfo>("/api/GeoMapManagement/GetAreaMap_V2", new RequestGeoInfo
            {
                job_gbn = "5",
                shop_cd = info.shop_cd
                //groupCode = "%"
            });

            if (req.code.Equals("00"))
            {
                List<AreaItem> list = new List<AreaItem>();
                Dictionary<string, List<AreaItem>> dicItem = new Dictionary<string, List<AreaItem>>();
                foreach (var item in req.data.OrderBy(x => x.groupCode).ToList())
                {
                    var key = item.geoSeqno.Split("_");
                    var tip = item.tip;
                    var groupCocde = item.groupCode;
                    
                    var value = new AreaItem();
                    value.Zoom = key[0];
                    value.xIndex = key[1];
                    value.yIndex = key[2];
                    value.tip = item.groupCode;
                    list.Add(value);

                    if (!dicItem.ContainsKey(groupCocde))
                    {
                        dicItem.Add(groupCocde, new List<AreaItem>());
                    }
                    dicItem[groupCocde].Add(value);

                }

                return Ok(new
                {
                    code = "00",
                    Msg = "성공",
                    Data = dicItem
                }); ;
            }
            return Ok(new
            {
                code = "99",
                Msg = "데이터 없음"
            });
        }
        [RequestFormLimits(ValueCountLimit = int.MaxValue)]
        [HttpPost]
        public async Task<IActionResult> SetAreaIndex(List<RequestAreaMap> item)
        {

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (item.Count() == 0)
            {
                return Ok(new
                {
                    Code = "99",
                    Msg = "선택된 영역이 없습니다. 다시이용바랍니다"
                });
            }
            //var list = new RequestAreaItem();
            //foreach (var key in item)
            //{
            //    var listKey = new AreaItem();
            //    var area_replace = key.keys.Split('_');
            //    listKey.Zoom = area_replace[0];
            //    listKey.xIndex = area_replace[1];
            //    listKey.yIndex = area_replace[2];

            //    list.item.Add(listKey);
            //}
            RequestAreaMapList list = new RequestAreaMapList();
            list.keys = new List<string>();
            list.tip = new List<int>();
            list.setGbn = new List<string>();
            list.groupCode = new List<int>();

            var tempGroupCode =new  List<int>();
            var groupCodeList = await GetAreaGroup();

            var continueCheck = true;



            foreach (var temp in item)
            {
                var deletekeys = temp.keys.Contains("_0_0");
               if(! deletekeys)
                {
                    list.keys.Add(temp.keys);
                    //list.tip.Add(Convert.ToInt32(temp.tip.Replace(",", "")));
                    list.setGbn.Add("I");
                    continueCheck = false;
                }
                else
                {
                    continueCheck = true;
                }

                for (int i = 0; i < groupCodeList.Count(); i++)
                {
                    if (!continueCheck)
                    {
                        if (Convert.ToInt32(temp.tip.Replace("구역", "")) > 0)
                        {
                            list.groupCode.Add(groupCodeList[(Convert.ToInt32(temp.tip.Replace("구역", "")) - 1)].groupCode);
                            break;
                        }
                    }else
                    {
                        break;
                    }
                }


                Debug.WriteLine(list.groupCode);
            }
            list.job_gbn = "I";
            list.ucode = info.login_code;
            list.mName = info.login_name;
            list.shop_cd = info.shop_cd;

            if(list.keys.Count != list.keys.Distinct().Count())
            {
               
            }

            var duplicates = list.keys.GroupBy(i => i).Where(g => g.Count() > 1).Select(g => g.Key);


            foreach(var d_item  in duplicates)
            {
                Debug.WriteLine($"중복 : {d_item}");
            }
            var result = await dgShop.Post<dynamic, RequestAreaMapList>("/api/GeoMapManagement/SetAreaMap_V2", list);

            if (result.code.Equals("00"))
            {
                return Ok(new
                {
                    Code = "00",
                    Msg = "성공"
                });
            }
            return Ok(new
            {
                Code = "99",
                Msg = "실패"
            });
        }
        public async Task<IActionResult> SetAreaIndex_T(List<RequestAreaMap> item)
        {

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (item.Count() == 0)
            {
                return Ok(new
                {
                    Code = "99",
                    Msg = "선택된 영역이 없습니다. 다시이용바랍니다"
                });
            }
            //var list = new RequestAreaItem();
            //foreach (var key in item)
            //{
            //    var listKey = new AreaItem();
            //    var area_replace = key.keys.Split('_');
            //    listKey.Zoom = area_replace[0];
            //    listKey.xIndex = area_replace[1];
            //    listKey.yIndex = area_replace[2];

            //    list.item.Add(listKey);
            //}
            RequestAreaMapList list = new RequestAreaMapList();
            list.keys = new List<string>();
            list.tip = new List<int>();
            list.setGbn = new List<string>();
            list.groupCode = new List<int>();

            var tempGroupCode = new List<int>();
            var groupCodeList = await GetAreaGroup();

            var continueCheck = true;



            foreach (var temp in item)
            {
                var deletekeys = temp.keys.Contains("_0_0");
                if (!deletekeys)
                {
                    list.keys.Add(temp.keys);
                    //list.tip.Add(Convert.ToInt32(temp.tip.Replace(",", "")));
                    list.setGbn.Add("I");
                    continueCheck = false;
                }
                else
                {
                    continueCheck = true;
                }

                for (int i = 0; i < groupCodeList.Count(); i++)
                {
                    if (!continueCheck)
                    {
                        if (Convert.ToInt32(temp.tip.Replace("구역", "")) > 0)
                        {
                            list.groupCode.Add(groupCodeList[(Convert.ToInt32(temp.tip.Replace("구역", "")) - 1)].groupCode);
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }


                Debug.WriteLine(list.groupCode);
            }
            list.job_gbn = "I";
            list.ucode = info.login_code;
            list.mName = info.login_name;
            list.shop_cd = info.shop_cd;

            if (list.keys.Count != list.keys.Distinct().Count())
            {

            }

            var duplicates = list.keys.GroupBy(i => i).Where(g => g.Count() > 1).Select(g => g.Key);


            foreach (var d_item in duplicates)
            {
                Debug.WriteLine($"중복 : {d_item}");
            }
            var result = await dgShop.Post<dynamic, RequestAreaMapList>("/api/GeoMapManagement/SetAreaMap_V3", list);

            if (result.code.Equals("00"))
            {
                return Ok(new
                {
                    Code = "00",
                    Msg = "성공"
                });
            }
            return Ok(new
            {
                Code = "99",
                Msg = "실패"
            });
        }
        public async Task<List<ResponseAreaMapGroup>> GetAreaGroup()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var result = await dgShop.Post<ResponseAreaMapGroup, RequestAreaMapGroup>("/api/GeoMapManagement/GetAreaGroup", new RequestAreaMapGroup
            {
                job_gbn = "1",
                shop_cd = info.shop_cd,
                mcode = info.login_code,
                mName = info.login_name
            });

            if (result.code.Equals("00"))
            {
                return result.data;
            }
            else
            {
                return new List<ResponseAreaMapGroup>();
            }
        }
        [HttpPost]
        public async Task<IActionResult> SetAreaGroup(string status, RequestAreaMapGroupV3 model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if(status == null)
            {
                return Ok(new
                {
                    code = "98",
                    Msg = "관리자의 문의 부탁드립니다. 구역 생성 실패1"
                });
            }
            if(status == "I")
            {

                model.job_gbn = status;
                model.shop_cd = info.shop_cd;
                model.mcode = info.login_code;
                model.mName = info.login_name;
                model.AreaInfo = new List<MapGroupList>();
                var result = await dgShop.Post<dynamic, RequestAreaMapGroupV3>("/api/GeoMapManagement/SetAreaGroup_V3", model);

                if (result.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        Msg = "성공",
                        data = result.msg
                    }) ;
                }
            }
            else if(status == "U")
            {
                if(model == null)
                {
                    return Ok(new
                    {
                        code="99",
                        Msg = "저장 할 구역이 없습니다."
                    });
                }

                model.job_gbn = status;
                model.shop_cd = info.shop_cd;
                model.mcode = info.login_code;
                model.mName = info.login_name;
                for (var i = 0; i < model.AreaInfo.Count(); i++)
                {
                    model.AreaInfo[i].SetGbn = status;
                }

                var result = await dgShop.Post<dynamic, RequestAreaMapGroupV3>("/api/GeoMapManagement/SetAreaGroup_V3", model);

                if (result.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        Msg = "성공"
                    });
                }
            }
            else if (status == "D")
            {
                if (model == null)
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "삭제 할 구역이 존재하지않습니다."
                    });
                }

                model.job_gbn = status;
                model.shop_cd = info.shop_cd;
                model.mcode = info.login_code;
                model.mName = info.login_name;
                for (var i = 0; i < model.AreaInfo.Count(); i++)
                {
                    model.AreaInfo[i].SetGbn = status;
                }

                var result = await dgShop.Post<dynamic, RequestAreaMapGroupV3>("/api/GeoMapManagement/SetAreaGroup_V3", model);

                if (result.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        Msg = "성공"
                    });
                }
            }

            return Ok(new
            {
                code = "99",
                Msg = "관리자의 문의 부탁드립니다. 구역 생성 실패2"
            });
        }

        #endregion
        #region 공용 읍면동 형상 데이터
        [HttpGet]
        //public async Task<IActionResult> SetCommonUmd(string sido, string sigungu, string umd, string ri = null)
        //{
        //    try
        //    {
        //        NaverGISConverter result = await dawul.GetDawulUmdAsync(sido, sigungu, umd);

        //        List<List<double>> shapeData = new List<List<double>>();

        //        string lCode = string.Empty;

        //        if (result.Collection.GetType() == typeof(NaverFeatureCollection))
        //        {
        //            var temp = (NaverFeatureCollection)result.Collection;

        //            foreach (var features in temp.features)
        //            {
        //                lCode = features.properties.lcode;
        //                shapeData = features.geometry.coordinates[0];
        //            }
        //        }
        //        else if (result.Collection.GetType() == typeof(NaverFeatureCollectionMulti))
        //        {
        //            var temp = (NaverFeatureCollectionMulti)result.Collection;

        //            foreach (var features in temp.features)
        //            {
        //                lCode = features.properties.lcode;
        //                // 외곽만 사용
        //                shapeData = features.geometry.coordinates[0][0];
        //            }
        //        }

        //        List<double> lonArray = new List<double>();
        //        List<double> latArray = new List<double>();
        //        foreach (var item in shapeData)
        //        {
        //            lonArray.Add(item[0]);
        //            latArray.Add(item[1]);
        //        }

        //        RequestSetCommonUmd requestData = new RequestSetCommonUmd()
        //        {
        //            hcode = lCode,
        //            sido = sido,
        //            sigungu = sigungu,
        //            umd = umd,
        //            lon_x = lonArray,
        //            lat_y = latArray
        //        };

        //        var response = await api.SetCommonUmd(requestData);

        //        if (response.IsSuccessStatusCode)
        //        {
        //            var responseString = await response.Content.ReadAsStringAsync();

        //            var responseData = JsonConvert.DeserializeObject(responseString);

        //            return Json(responseData);
        //        }

        //        notify.Error("공용 데이터 저장 실패 했습니다.");
        //        return Json(new
        //        {
        //            code = "99",
        //            message = "공용 데이터 저장 실패 했습니다."
        //        });
        //    }
        //    catch (Exception e)
        //    {
        //        notify.Error($"에러 : {e.Message}");
        //        return Json(new
        //        {
        //            code = "99",
        //            message = e.Message
        //        });
        //    }
        //}

        //[HttpGet]
        //public async Task<IActionResult> GetCommonUmd(string sido, string sigungu, string umd, string ri = null)
        //{
        //    try
        //    {
        //        RequestSetCommonUmd requestData = new RequestSetCommonUmd()
        //        {
        //            sido = sido,
        //            sigungu = sigungu,
        //            umd = umd,
        //        };

        //        var response = await api.GetCommonUmd(requestData);

        //        if (response.IsSuccessStatusCode)
        //        {
        //            var responseString = await response.Content.ReadAsStringAsync();

        //            var responseData = JsonConvert.DeserializeObject<Result<CommonStateUmd>>(responseString);

        //            return Json(responseData);
        //        }

        //        notify.Error("공용 데이터를 가져오는데 실패 했습니다.");
        //        return Json(new
        //        {
        //            code = "99",
        //            message = "공용 데이터를 가져오는데 실패 했습니다."
        //        });
        //    }
        //    catch (Exception e)
        //    {
        //        notify.Error($"에러 : {e.Message}");
        //        return Json(new
        //        {
        //            code = "99",
        //            message = e.Message
        //        });
        //    }
        //}
        #endregion

        #region NaverPoly
        [HttpPost]
        public async Task<IActionResult> getNaverPoly()
        {
            //start 
            double x_init = 128.60918;
            double y_init = 35.876393;

            double x = 128.60918;
            double y = 35.876393;

            int x_count = 100;
            int y_count = 100;

            double y_plusLength = 0.000111;
            double x_plusLength = 0.00009;

            Random random = new Random();
            x += random.Next(1, 10) * 0.0001;
            y += random.Next(1, 10) * 0.0001;

            List<PointLatlng> pList = new List<PointLatlng>();

            List<List<PointLatlng>> retrunList = new List<List<PointLatlng>>();

            
            pList.Add(new PointLatlng(y, x));
            pList.Add(new PointLatlng(y + y_plusLength, x));
            pList.Add(new PointLatlng(y + y_plusLength, x + x_plusLength));
            pList.Add(new PointLatlng(y, x + x_plusLength));

            for(int i = 0; i < y_count; i++)
            {
                y += y_plusLength;
                x = x_init;
               
                for (int j = 0; j < x_count; j++)
                {
                    x += x_plusLength;
                    List<PointLatlng> itemList = new List<PointLatlng>();

                    itemList.Add(new PointLatlng(y, x));
                    itemList.Add(new PointLatlng(y + y_plusLength, x));
                    itemList.Add(new PointLatlng(y + y_plusLength, x + x_plusLength));
                    itemList.Add(new PointLatlng(y, x + x_plusLength));
                    retrunList.Add(itemList);

                }

               
            }
            await Task.Delay(0);
            return Ok(new
            {
                code = "00",
                data = retrunList
            });
        }
        #endregion



        #region Drawing Manager
        //[HttpGet]
        //public async Task<IActionResult> GetUmdData(string sido, string sigungu, string umd, string ri = null)
        //{
        //    NaverGISConverter result = await dawul.GetDawulUmdAsync(sido, sigungu, umd);

        //    List<NaverPolygon> model = new List<NaverPolygon>();

        //    if (result.Collection.GetType() == typeof(NaverFeatureCollection))
        //    {
        //        var temp = (NaverFeatureCollection)result.Collection;

        //        foreach (var features in temp.features)
        //        {
        //            NaverPolygon np = new NaverPolygon();
        //            np.paths_origin = features.geometry.coordinates[0];
        //            np.sido = features.properties.sido;
        //            np.sigungu = features.properties.sigungu;
        //            np.umd = features.properties.umd;
        //            model.Add(np);

        //        }
        //        var jsonData = new
        //        {
        //            polydata = model
        //        };
        //        return Content(JsonConvert.SerializeObject(jsonData));
        //    }
        //    else if (result.Collection.GetType() == typeof(NaverFeatureCollectionMulti))
        //    {
        //        var temp = (NaverFeatureCollectionMulti)result.Collection;

        //        foreach (var features in temp.features)
        //        {
        //            // 외곽만 사용
        //            NaverPolygon np = new NaverPolygon();
        //            np.paths_origin = features.geometry.coordinates[0][0];
        //            np.sido = features.properties.sido;
        //            np.sigungu = features.properties.sigungu;
        //            np.umd = features.properties.umd;
        //            np.ri = features.properties.ri;
        //            model.Add(np);

        //        }
        //        var jsonData = new
        //        {
        //            polydata = model
        //        };
        //        return Content(JsonConvert.SerializeObject(jsonData));
        //    }

        //    notify.Error("영역을 가져오는데 실패 했습니다 (개발실 문의)");
        //    return Content(JsonConvert.SerializeObject(new
        //    {
        //        code = "99",
        //        msg = "영역을 가져오는데 실패 했습니다 (개발실 문의)"
        //    }));
        //}

        [HttpPost]
        public async Task<IActionResult> GetShopSingleDeliveryArea(string areaname)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestSetShopFence reqFence = new RequestSetShopFence { shop_cd = info.shop_cd };

            var response = await api.GetShopDeliveryFence(reqFence);

            if (response.IsSuccessStatusCode)
            {
                var responseData = await response.Content.ReadAsStringAsync();
                Result<ShopFence> shop = JsonConvert.DeserializeObject<Result<ShopFence>>(responseData);

                if (shop.code.Equals("00"))
                {
                    List<NaverPolygon> model = new List<NaverPolygon>();
                    foreach (var area in shop.data)
                    {
                        int.TryParse(area.fence_amount, out int amount);

                        NaverPolygon poly = new NaverPolygon();
                        poly.id = area.area;
                        poly.paths = area.fence._array;
                        poly.name = area.fence_name;
                        poly.amount = amount;
                        poly.fence_sequence = area.fence_seq;
                        poly.paths_origin = area.areaPoints;
                        poly.use_fence = area.use_fence;
                        poly.sido = area.sido;
                        poly.sigungu = area.sigungu;
                        poly.umd = area.umd;
                        poly.full_addr = area.full_addr;


                        model.Add(poly);
                    }

                    var tempArea = model.FirstOrDefault(x => string.Join(' ', x.umd, x.ri).TrimEnd() == areaname);

                    var firstItem = tempArea.paths_origin.FirstOrDefault();
                    var lastItem = tempArea.paths_origin.LastOrDefault();

                    if (!(firstItem[0] == lastItem[0] && firstItem[1] == lastItem[1]))
                    {
                        tempArea.paths_origin.Add(firstItem);
                    }

                    var jsonData = new
                    {
                        polydata = tempArea
                    };

                    return Content(JsonConvert.SerializeObject(jsonData));
                }
            }

            notify.Error("영역을 가져오는데 실패 했습니다 (개발실 문의)");
            return Content(JsonConvert.SerializeObject(new
            {
                code = "99",
                msg = "영역을 가져오는데 실패 했습니다 (개발실 문의)"
            }));
        }

        [HttpPost]
        public async Task<IActionResult> GetShopDeliveryArea()
        {
            try
            {
                string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
                ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
                if(sessionString  == null)
                {
                    return Content(JsonConvert.SerializeObject(new
                    {
                        code = "99",
                        msg = "session expired",
                        data = string.Concat(apiStrings.Value.local)
                    }));
                }
                
                info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

                RequestSetShopFence reqFence = new RequestSetShopFence { shop_cd = info.shop_cd };

                // 배달 지역 + 사용자 정의 배달 지역
                var response = await api.GetShopDeliveryFence(reqFence);

                if (response.IsSuccessStatusCode)
                {
                    var responseData = await response.Content.ReadAsStringAsync();
                    Result<ShopFence> shop = JsonConvert.DeserializeObject<Result<ShopFence>>(responseData);

                    if (shop.code.Equals("00"))
                    {
                        List<NaverPolygon> model = new List<NaverPolygon>();
                        foreach (var area in shop.data)
                        {
                            int.TryParse(area.fence_amount, out int amount);

                            NaverPolygon poly = new NaverPolygon();
                            poly.id = area.area;
                            poly.paths = area.fence._array;
                            //poly.name = area.fence_name;
                            poly.name = area.full_addr;
                            poly.amount = amount;
                            poly.fence_sequence = area.fence_seq;
                            poly.paths_origin = area.areaPoints;
                            poly.use_fence = area.use_fence;

                            poly.sido = area.sido;
                            poly.sigungu = area.sigungu;
                            poly.umd = area.umd;
                            poly.ri = area.ri;
                            poly.insert_type = area.insert_type;
                            poly.full_addr = area.full_addr;

                            model.Add(poly);
                        }

                        var jsonData = new
                        {
                            polydata = model
                        };

                        return Content(JsonConvert.SerializeObject(jsonData));
                    }
                }

                notify.Error("영역을 가져오는데 실패 했습니다.", 5);
                return Content(JsonConvert.SerializeObject(new
                {
                    code = "99",
                    msg = "영역을 가져오는데 실패 했습니다 (개발실 문의)"
                }));
            }
            catch (Exception e)
            {
                notify.Error($"에러 : {e.Message}", 5);
                return Content(JsonConvert.SerializeObject(new
                {
                    code = "99",
                    msg = e.Message
                }));

            }
        }


        [HttpPost]
        public async Task<IActionResult> UpdateShopDeliveryArea(RequestInsertGeoFence model)
        {
            try
            {
                string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
                if (sessionString == null)
                {
                    return Content(JsonConvert.SerializeObject(new
                    {
                        code = "99",
                        msg = "session expired",
                        data = string.Concat(apiStrings.Value.local)
                    }));
                }
                ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
                info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

                /// View 에서 넘어온 데이터 파싱
                List<NaverPolygonArray> userDrawingData = JsonConvert.DeserializeObject<List<NaverPolygonArray>>(model.points);


                RequestSetShopFence fenceInfo = new RequestSetShopFence
                {
                    shop_cd = info.shop_cd,
                    fence_sequence = model.fence_sequence,
                    fence_name = model.area_name,
                    shop_fences = new List<ShopFence>(),
                    job_gbn = "U",
                    sido = model.sido,
                    sigungu = model.sigungu,
                    umd = model.umd,
                    ri = model.ri,
                    amount = model.area_amount,
                    use_gbn = model.use_area,
                    insert_type = "C",
                    mod_code = info.shop_cd.ToString(),
                    mod_user = info.shop_name
                };

                foreach (var fence in userDrawingData)
                {
                    ShopFence sf = new ShopFence()
                    {
                        area = Convert.ToInt32(model.area_sequence),
                        fence = fence,
                        fence_name = model.area_name,
                        fence_amount = model.area_amount,
                        use_fence = model.use_area,
                        sido = model.sido,
                        sigungu = model.sigungu,
                        umd = model.umd,
                        ri = model.ri
                    };
                    fenceInfo.shop_fences.Add(sf);
                }

                /// 영역 등록
                var response = await api.SetShopFenceNew(fenceInfo);

                if (response.IsSuccessStatusCode)
                {
                    var responseString = await response.Content.ReadAsStringAsync();
                    notify.Success("업데이트 완료 했습니다.", 2);
                    return Content(responseString);
                }
                else
                {
                    notify.Error($"에러 : 상태코드 {response.StatusCode }", 5);
                    return Content(JsonConvert.SerializeObject(new
                    {
                        code = "99",
                        msg = response.StatusCode
                    }));
                }
            }
            catch (Exception e)
            {
                notify.Error($"에러 : {e.Message}", 5);
                return Content(JsonConvert.SerializeObject(new
                {
                    code = "99",
                    msg = e.Message
                }));
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteShopDeliveryArea(RequestDeleteShopArea model)
        {
            try
            {
                string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
                if (sessionString == null)
                {
                    return Content(JsonConvert.SerializeObject(new
                    {
                        code = "99",
                        msg = "session expired",
                        data = string.Concat(apiStrings.Value.local)
                    }));
                }
                ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
                info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

                model.shop_cd = info.shop_cd;

                var response = await api.DeleteShopFenceNew(model);

                if (response.IsSuccessStatusCode)
                {
                    var responseString = await response.Content.ReadAsStringAsync();

                    notify.Success("삭제 완료 했습니다.", 2);
                    return Content(responseString);
                }
                else
                {
                    notify.Error($"에러 : 상태코드 {response.StatusCode }", 5);
                    return Content(JsonConvert.SerializeObject(new
                    {
                        code = "99",
                        msg = response.StatusCode
                    }));
                }
            }
            catch (Exception e)
            {
                notify.Error($"에러 : {e.Message }", 5);
                return Content(JsonConvert.SerializeObject(new
                {
                    code = "99",
                    msg = e.Message
                }));
            }
        }


        #endregion

        #region Rest Api
        [HttpGet]
        public async Task<IActionResult> GetShopArea()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopSector, Request>("GetShopSectorRaw", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            return Content(JsonConvert.SerializeObject(temp.data));
        }

        [HttpPost]
        public async Task<IActionResult> lonlatGeoPosition(string type, RequestAddressInfo address)
        {
            if (string.IsNullOrEmpty(type))
            {
                return Ok(new
                {
                    code = "99",
                    msg = "주소 조회가 실패했습니다."
                });
            }
            address.job_gbn = type;
            List<ResponseAddressInfo> result = new List<ResponseAddressInfo>();

            if(type.Equals("1") || type.Equals("3") || type.Equals("5"))
            {
                result = await GetAddressSiGunGu(address);

                return Ok(new
                {
                    code = "00",
                    msg = "성공",
                    data = result
                });
            }
           

            return Ok(new
            {
                code = "99",
                msg = "주소 조회가 실패했습니다."
            });
        }
        #endregion

        private async Task<ResultSingle<Dictionary<string, List<AreaItem>>>> middleTileSizeAsync()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            List<AreaItem> list = new List<AreaItem>();

            ResultSingle<Dictionary<string, List<AreaItem>>> result = new ResultSingle<Dictionary<string, List<AreaItem>>>();
            Dictionary<string, List<AreaItem>> dicItem = new Dictionary<string, List<AreaItem>>();

            var req = await dgShop.Post<ResponseAreaMap, RequestCommon>("/api/GeoMapManagement/GetAreaMap", new RequestCommon
            {
                job_gbn = "1",
                shop_cd = info.shop_cd
            });

            if (!req.code.Equals("00"))
            {
                //조회 결과 없음
                result.code = req.code;
                result.msg = req.msg;
                return result;
            }

            try
            {
                foreach (var item in req.data)
                {
                    var key = item.geoSeqno.Split("_");
                    var tip = item.tip;

                    var value = new AreaItem();
                    value.Zoom = key[0];
                    value.xIndex = key[1];
                    value.yIndex = key[2];
                    value.tip = tip;
                    list.Add(value);

                    if (!dicItem.ContainsKey(tip))
                    {
                        dicItem.Add(tip, new List<AreaItem>());
                    }
                    dicItem[tip].Add(value);
                }

                result.code = req.code;
                result.msg = req.msg;
                result.data = dicItem;
                
            }
            catch(Exception e)
            {
                result.code = "99";
                result.msg = e.ToString();
                return result;
            }

            return result;
            
        }

        #region function address
        private async Task<List<ResponseAddressInfo>> GetAddressSiGunGu(RequestAddressInfo address)
        {
            List<ResponseAddressInfo> temp = new List<ResponseAddressInfo>();
            var req = await dgShop.Post<ResponseAddressInfo, RequestAddressInfo>("/api/GeoMapManagement/GetDongLonLat", new RequestAddressInfo
            {
                job_gbn = address.job_gbn,
                sido = "대구광역시",
                gungu = address.gungu,
                dong = address.dong
            });

            foreach(var items in req.data)
            {
                if(address.job_gbn.Equals("1"))
                {
                    temp.Add(new ResponseAddressInfo
                    {
                        hMiddle = items.hMiddle,
                        lonGrs80 = items.lonGrs80,
                        latGrs80 = items.latGrs80
                    });
                }
                else if (address.job_gbn.Equals("3"))
                {
                    temp.Add(new ResponseAddressInfo
                    {
                        hSmall = items.hSmall,
                        lonGrs80 = items.lonGrs80,
                        latGrs80 = items.latGrs80
                    });
                }
                else if (address.job_gbn.Equals("5"))
                {
                    temp.Add(new ResponseAddressInfo
                    {
                        bDetaill = items.bDetaill,
                        lonGrs80 = items.lonGrs80,
                        latGrs80 = items.latGrs80
                    });
                }
                else
                {

                }
                
            }

            return temp;
        }

        
        #endregion

        /* 사용안함 리스트
         

        [HttpPost]
        public async Task<IActionResult> InsertShopDeliveryArea(RequestInsertGeoFence model)
        {
            try
            {
                string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
                ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
                info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

                //NaverGISConverter converter = new NaverGISConverter(str);
                /// View 에서 넘어온 데이터 파싱
                List<NaverPolygonArray> userDrawingData = JsonConvert.DeserializeObject<List<NaverPolygonArray>>(model.points);


                RequestSetShopFence fenceInfo = new RequestSetShopFence
                {
                    shop_cd = info.shop_cd,
                    shop_fences = new List<ShopFence>(),
                    job_gbn = "I",
                    sido = model.sido,
                    sigungu = model.sigungu,
                    umd = model.umd,
                    ri = model.ri,
                    amount = model.area_amount,
                    insert_type = "C",
                    use_gbn = model.use_area,
                    mod_code = info.shop_cd.ToString(),
                    mod_user = info.shop_name
                };

                foreach (var fence in userDrawingData)
                {
                    ShopFence sf = new ShopFence()
                    {
                        //area = sequence++,
                        fence = fence,
                        fence_name = model.area_name,
                        fence_amount = model.area_amount,
                        use_fence = model.use_area,
                        sido = model.sido,
                        sigungu = model.sigungu,
                        umd = model.umd
                    };
                    fenceInfo.shop_fences.Add(sf);
                }

                ///// 영역 등록
                var response = await api.SetShopFenceNew(fenceInfo);

                if (response.IsSuccessStatusCode)
                {
                    var responseString = await response.Content.ReadAsStringAsync();
                    return Content(responseString);
                }
                else
                {
                    return Content(JsonConvert.SerializeObject(new
                    {
                        code = "99",
                        msg = response.StatusCode
                    }));
                }

            }
            catch (Exception e)
            {
                return Content(JsonConvert.SerializeObject(new
                {
                    code = "99",
                    msg = e.Message
                }));
            }
        }


        #region GeoJson

        [HttpGet]
        public async Task<IActionResult> GetGeoData()
        {
#if DEBUG
            RequestNaverGeo info = new RequestNaverGeo()
            {
                job_gbn = "1",
                shop_cd = 1
            };
#else
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo shopinfo = new ShopSessionDefaultInfo();
            shopinfo = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestNaverGeo info = new RequestNaverGeo()
            {
                job_gbn = "1",
                shop_cd = shopinfo.shop_cd
            };
#endif
            var temp = await api.GetNaverGeo(info);

            if (temp.code.Equals("00"))
            {
                return Content(JsonConvert.SerializeObject(temp.data));
            }

            return Content("");
        }

        [HttpPost]
        public async Task InsertShopArea(string geotype, string areaInfo)
        {
            try
            {
#if DEBUG
                RequestNaverGeo info = new RequestNaverGeo()
                {
                    job_gbn = "1",
                    shop_cd = 1,
                    data = areaInfo,
                    data_seq = 1,
                    mod_ucode = "2334",
                    mod_user = "복순이"
                };
#else
                string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
                ShopSessionDefaultInfo shopinfo = new ShopSessionDefaultInfo();
                shopinfo = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

                RequestNaverGeo info = new RequestNaverGeo()
                {
                    job_gbn = "1",
                    shop_cd = shopinfo.shop_cd,
                    data = areaInfo,
                    data_seq = 1,
                    mod_ucode = shopinfo.shop_cd.ToString(),
                    mod_user = shopinfo.shop_name
                };
#endif
                var SequenceInfo = await api.GetNaverGeo(info);



                var temp = await api.SetNaverGeo(info);

                if (temp.IsSuccessStatusCode)
                {
                    var response = await temp.Content.ReadAsStringAsync();
                    var responseData = JsonConvert.DeserializeObject<Result<NaverGeoData>>(response);

                    if (responseData.code.Equals("00"))
                    {

                    }
                    else
                    {
                        // error page
                    }
                }



            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }

            await Task.Delay(0);
            Debug.WriteLine(areaInfo);
        }

        [HttpPost]
        public async Task UpdateShopArea(string areaInfo)
        {
            //FeatureCollection geoJson = JsonConvert.DeserializeObject<FeatureCollection>(areaInfo);
            await Task.Delay(0);
            //Debug.WriteLine(areaInfo);
        }

        [HttpPost]
        public async Task DeleteShopArea(string areaInfo)
        {
            //FeatureCollection geoJson = JsonConvert.DeserializeObject<FeatureCollection>(areaInfo);
            await Task.Delay(0);
            //Debug.WriteLine(areaInfo);
        }

        #endregion




         * */
    }
}
