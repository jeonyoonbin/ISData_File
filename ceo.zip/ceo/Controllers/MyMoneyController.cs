﻿using AspNetCoreHero.ToastNotification.Abstractions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore.Scaffolding;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.ApiModels.Shop.Response;
using PosWebApp.Common;
using PosWebApp.Models.Common;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.MyMoney;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{

    [SessionDgShop]
    public class MyMoneyController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly INotyfService _notyf;
        public MyMoneyController(DgShopApiService api, INotyfService notifi)
        {
            dgShop = api;
            _notyf = notifi;
        }

        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var shopAccountInfo = await dgShop.Post<ResponseShopAccountInfo, Request>("AccInfo", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });



            if (!shopAccountInfo.code.Equals("00"))
            {
                ViewBag.code = shopAccountInfo.code;
                ViewBag.errorMsg = "계좌 정보를 확인하지 못했습니다";
                return View();
            }

            var shopAccInfo = shopAccountInfo.data.SingleOrDefault();
            if (string.IsNullOrEmpty(shopAccInfo.account_owner))
            {
                ViewBag.code = "99";
                ViewBag.errorMsg = "계좌 정보를 확인하지 못했습니다";
                return View();
            }

            var accountInfo = shopAccountInfo.data.SingleOrDefault();
            if (!accountInfo.confirm_gbn.Equals("Y"))
            {
                ViewBag.code = shopAccountInfo.code;
                ViewBag.errorMsg = "출금 계좌 미확인";
                return View();
            };

            ViewBag.code = "00";
            ViewBag.errorMsg = "";

            int out_money = Convert.ToInt32(accountInfo.remain_amt) - 200;

            var AutoModel = await dgShop.Post<ResponseWithDraw, PosWebApp.ApiModels.RequestCommon>("/api/shopManagement/GetWithDraw", new PosWebApp.ApiModels.RequestCommon
            {
                job_gbn = "",
                shop_cd = info.shop_cd
            });


            ShopAccountInfoViewModel model = new ShopAccountInfoViewModel()
            {
                remain_amt = accountInfo.remain_amt,
                account_no = accountInfo.account_no,
                account_owner = accountInfo.account_owner,
                bank_code = accountInfo.bank_code,
                //bank_name =    //accountInfo.account_info.Replace(":", "").Replace("(", "").Replace(")", "").Replace(accountInfo.account_no, "").Replace(accountInfo.account_owner, ""),
                bank_name = accountInfo.bank_name,
                transfering_amt = accountInfo.transfering_amt,
                out_money = out_money,
                real_remain_amt = accountInfo.real_remain_amt
            };
            ViewBag.CanOut = out_money > 0 ? true : false;
            ViewBag.ViewOutput = (info.shop_id != null && info.shop_id.Equals(info.login_name)) ? true : false;
            ViewBag.autoWith = AutoModel.data.SingleOrDefault();

            return View(model);
        }

        public async Task<IActionResult> AccountAuth(ShopAccountInfoViewModel viewModel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestTransSmsCheck requestAvailable = new RequestTransSmsCheck()
            {
                job_gbn = ((int)SmsTransType.출금가능유무).ToString(),
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                sms_no = viewModel.sms_no
            };
           // var available = await dgShop.Post<CodeMsg, RequestTransSmsCheck>("SmsCheck", requestAvailable);
            var available = await dgShop.Post<CodeMsg, RequestTransSmsCheck>("/api/MyMoneyManagement/GetShopTransSmsCheck", requestAvailable);
            if (!available.code.Equals("00"))
            {
                return Json(new
                {
                    code = available.code,
                    message = available.msg
                });
            }
            else
            {
                _notyf.Success("사장님 휴대전화로 인증번호가 발송 되었습니다.", 5);
                return Json(new
                {
                    code = available.code,
                    message = available.msg
                });
            }

            //return Json(new
            //{
            //    code = "00",
            //    message = "성공"
            //});
        }

        public IActionResult SmsConfirm()
        {
            return View();
        }
        public IActionResult AutoSmsConfirm()
        {
            ViewBag.days = new SelectList(GetDaysName(), "Value", "Text", "");
            return View();
        }
        public IActionResult SmsPassConfirm(string Money = null)
        {

            return PartialView("SmsPassConfirm");
        }
        [HttpPost]
        public async Task<IActionResult> SmsConfirm(ShopAccountInfoViewModel viewModel = null, string paswword = null)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestTransSmsCheck requestSmsConfirm = new RequestTransSmsCheck()
            {
                job_gbn = ((int)SmsTransType.SMS인증번호확인).ToString(),
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                sms_no = viewModel.sms_no
            };
            var smsResult = await dgShop.Post<CodeMsg, RequestTransSmsCheck>("SmsCheck", requestSmsConfirm);
            if (!smsResult.code.Equals("00"))
            {
                _notyf.Error("인증번호가 맞지않습니다.", 5);

                return Ok(new
                {
                    code = "99",
                    Msg = "인증실패"
                });
            }
            else
            {
                #region jwcho add 2021.06.28
                var shopAccountInfo = await dgShop.Post<ResponseShopAccountInfo, Request>("AccInfo", new Request
                {
                    cccode = info.cccode,
                    shop_cd = info.shop_cd
                });

                // 에러 처리 확인 필요
                if (!shopAccountInfo.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = shopAccountInfo.msg
                    });
                }
                var accountInfo = shopAccountInfo.data.SingleOrDefault();
                viewModel.remain_amt = accountInfo.remain_amt;
                viewModel.real_remain_amt = accountInfo.real_remain_amt;
                int remainMoney = Convert.ToInt32(accountInfo.remain_amt);
                viewModel.transfering_amt = (remainMoney - 200).ToString();
                ViewBag.avlMoney = remainMoney - 200;
                #endregion

                _notyf.Success("인증 성공", 5);
                return PartialView("SmsPassConfirm", viewModel);
            }

        }
        [HttpPost]
        public async Task<IActionResult> AutoSmsConfirm(ShopAccountInfoViewModel viewModel = null, string paswword = null)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            AutoShopAccountInfoViewModel result = new AutoShopAccountInfoViewModel();
            ViewBag.days = new SelectList(GetDaysName(), "Value", "Text", "");

            RequestTransSmsCheck requestSmsConfirm = new RequestTransSmsCheck()
            {
                job_gbn = ((int)SmsTransType.SMS인증번호확인).ToString(),
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                sms_no = viewModel.sms_no
            };

            var smsResult = await dgShop.Post<CodeMsg, RequestTransSmsCheck>("SmsCheck", requestSmsConfirm);
            if (!smsResult.code.Equals("00"))
            {
                _notyf.Error("인증번호가 맞지않습니다.", 5);

                return Ok(new
                {
                    code = "99",
                    Msg = "인증실패"
                });
            }
            else
            {
                #region auto IO

                var model = await dgShop.Post<ResponseWithDraw, PosWebApp.ApiModels.RequestCommon>("/api/shopManagement/GetWithDraw", new PosWebApp.ApiModels.RequestCommon
                {
                    job_gbn = "",
                    shop_cd = info.shop_cd
                });
                if (model.data.Count == 0)
                {
                    result.withdrawCycle = "D";
                    result.withdrawHour = "09";
                    result.withdrawMinute = "00";
                    return PartialView("AutoSmsPassConfirm", result);
                }
                #endregion
                var modelsingle = model.data.SingleOrDefault();
                result.fullWithdrawallYn = modelsingle.fullWithdrawalYn == "Y" ? true : false;
                result.withdrawAmt = modelsingle.withdrawAmt;
                result.withdrawCycle = modelsingle.withdrawCycle;
                if (!string.IsNullOrEmpty(modelsingle.withdrawDay))
                {
                    ViewBag.days = new SelectList(GetDaysName(), "Value", "Text", modelsingle.withdrawDay);
                }
                else
                {
                    ViewBag.days = new SelectList(GetDaysName(), "Value", "Text", "");
                }
                result.withdrawDate = modelsingle.withdrawDate;
                result.withdrawDay = modelsingle.withdrawDay;
                result.withdrawHour = modelsingle.withdrawHour;
                result.withdrawMinute = modelsingle.withdrawMinute;


                _notyf.Success("인증 성공", 5);
                return PartialView("AutoSmsPassConfirm", result);
            }

        }
        [HttpPost]
        public async Task<IActionResult> GetMyMoney(ShopAccountInfoViewModel viewModel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var shopAccountInfo = await dgShop.Post<ResponseShopAccountInfo, Request>("AccInfo", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            var accountInfo = shopAccountInfo.data.SingleOrDefault();

            int out_money = Convert.ToInt32(accountInfo.remain_amt) - 200;

            var requestMoney = Convert.ToInt32(viewModel.request_amt);
            if (out_money <= requestMoney)
            {
                ModelState.AddModelError("Error", "적립금보다 출금액이 큽니다");

                return ViewComponent("GetMoney");
            }
            // 스크립트 코드로 해결 해야 하나...


            return ViewComponent("GetMoney");
        }
        [HttpPost]
        public async Task<IActionResult> SendMoney(ShopAccountInfoViewModel viewModel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ViewBag.avlMoney = viewModel.transfering_amt.Replace(",", "");

            if (string.IsNullOrEmpty(viewModel.request_amt))
            {
                _notyf.Error("출금하실 금액을 작성해주세요", 5);
                return PartialView("SmsPassConfirm", viewModel);
            }

            viewModel.request_amt = viewModel.request_amt.Replace(",", "");


            var ceoInfo = await dgShop.Post<SmsConfirmStatus, Request>("SmsStatus", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });
            if (!ceoInfo.code.Equals("00"))
            {
                //정보 없을떄
                _notyf.Warning("새로고침후 이용해주세요.");
                return PartialView("SmsPassConfirm", viewModel);
            }

            var ceoInfoSingle = ceoInfo.data.SingleOrDefault();
            var nowTime = Convert.ToDateTime(DateTime.Now.ToString("HH:mm:ss"));
            var smsConfirmTimeOut = DateTime.ParseExact(ceoInfoSingle.issue_time, "HH:mm:ss", null).AddMinutes(3);
            var smsConfirm = ceoInfoSingle.confirm_status;
            if (smsConfirmTimeOut > nowTime && smsConfirm.Equals("Y"))
            {
                //인증성공
                var shopAccountInfo = await dgShop.Post<ResponseShopAccountInfo, Request>("AccInfo", new Request
                {
                    cccode = info.cccode,
                    shop_cd = info.shop_cd
                });
                var accountInfo = shopAccountInfo.data.SingleOrDefault();

                int out_money = Convert.ToInt32(accountInfo.remain_amt) - 200;

                var requestMoney = Convert.ToInt32(viewModel.request_amt);
                if (out_money < requestMoney)
                {
                    //
                    // _notyf.Custom("커스텀 노티 - 5초 후 닫습니다.", 5, "#8600FF", "fa fa-gear");
                    // _notyf.Success(string.Concat(viewModel.remain_amt, "출금 성공!"),5
                    _notyf.Error("출금 금액이 부족합니다.", 5);
                    ModelState.AddModelError("Error", "출금 금액이 부족합니다.");
                    return PartialView("SmsPassConfirm", viewModel);
                }
                RequestShopInfoTran AmtModel = new RequestShopInfoTran()
                {
                    amt = viewModel.request_amt,
                    cccode = info.cccode,
                    job_gbn = "",
                    mcode = info.mcode,
                    memo = "사장님 사이트에서 출금",
                    mobile = info.shop_mobile, // 변경
                    shop_cd = info.shop_cd,
                    shop_password = viewModel.pass_confirm // 변경
                };

                var amtSuccess = await dgShop.Post<dynamic, RequestShopInfoTran>("TransMoney", AmtModel);

                if (amtSuccess.msg == "0")
                {
                    //출금완료
                    _notyf.Success("출금 요청되었습니다. \n 5초 뒤에 이동합니다.", 5);
                    TempData["success"] = "OK";
                }
                else
                {
                    //실패
                    _notyf.Error(amtSuccess.msg, 5);
                    ModelState.AddModelError("Error", amtSuccess.msg);
                }
                return PartialView("SmsPassConfirm", viewModel);
            }
            else
            {
                //인증만료
                _notyf.Error("SMS 인증 시간만료입니다. 다시 인증후 이용해주세요.", 5);
                ModelState.AddModelError("Error", "SMS 인증후 이용해주세요.");
                return PartialView("SmsPassConfirm", viewModel);
            }
        }
        [HttpPost]
        public async Task<IActionResult> AutoSendMoney(AutoShopAccountInfoViewModel viewModel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if(viewModel.withdrawCycle == "W" && string.IsNullOrEmpty(viewModel.withdrawDay))
            {
                _notyf.Error("요일을 선택해주세요", 5);
                ViewBag.days = new SelectList(GetDaysName(), "Value", "Text", "");
                ModelState.AddModelError("", "");
                return PartialView("AutoSmsPassConfirm", viewModel);
            }


            if (viewModel.fullWithdrawallYn)
            {
                viewModel.withdrawAmt = "0";
            }
            else
            {
                if (string.IsNullOrEmpty(viewModel.withdrawAmt))
                {
                    _notyf.Error("금액을 입력해주세요", 5);
                    ViewBag.days = new SelectList(GetDaysName(), "Value", "Text", "");
                    ModelState.AddModelError("", "");
                    return PartialView("AutoSmsPassConfirm", viewModel);
                }
            }

            RequestWithDraw result = new RequestWithDraw();

            result.job_gbn = "";
            result.shop_cd = info.shop_cd;
            result.hour = viewModel.withdrawHour;
            result.minute = viewModel.withdrawMinute;
            result.date = viewModel.withdrawDate;
            result.day = viewModel.withdrawDay;
            result.amt = viewModel.withdrawAmt;
            result.allYn = viewModel.fullWithdrawallYn ? "Y" : "N";
            result.useYn = "Y";
            result.cycle = viewModel.withdrawCycle.ToUpper();
            result.mcode = info.login_code;
            result.mName = info.login_name;

            var req = await dgShop.Post<dynamic, RequestWithDraw>("/api/ShopManagement/SetWithDraw", result);

            if (req.code.Equals("00"))
            {
                _notyf.Success("저장 성공!</br> 5초 뒤 적립금 출금 화면으로 갑니다.", 5);
                return PartialView("AutoSmsPassConfirm", viewModel);
            }
            _notyf.Error(req.msg, 5);
            ModelState.AddModelError("Error", req.msg);
            ViewBag.days = new SelectList(GetDaysName(), "Value", "Text", "");
            return PartialView("AutoSmsPassConfirm", viewModel);
        }
        [HttpPost]
        public async Task<IActionResult> AutoCancel()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestWithDraw result = new RequestWithDraw()
            {
                useYn = "N",
                shop_cd = info.shop_cd,
                mcode = info.login_code,
                mName = info.login_name
            };

            var req = await dgShop.Post<dynamic, RequestWithDraw>("/api/ShopManagement/SetWithDraw", result);

            if (req.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    msg = "자동출금 해지되었습니다."
                });
            }

            return Ok(new
            {
                code = "99",
                msg = "오류가 발생하였습니다."
            });
        }
        /// <summary>
        /// 계좌정보 변경 요청
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<IActionResult> RequestConfirm()
        {
            return PartialView("_PartialRequestConfirm", new ServiceConfirm());
        }
        private List<SelectListItem> GetDaysName()
        {
            List<SelectListItem> itemList = new List<SelectListItem>();
            itemList.Add(new SelectListItem
            {
                Text = "일요일",
                Value = "1",
            });
            itemList.Add(new SelectListItem
            {
                Text = "월요일",
                Value = "2",
            });
            itemList.Add(new SelectListItem
            {
                Text = "화요일",
                Value = "3",
            });
            itemList.Add(new SelectListItem
            {
                Text = "수요일",
                Value = "4",
            });
            itemList.Add(new SelectListItem
            {
                Text = "목요일",
                Value = "5",
            });
            itemList.Add(new SelectListItem
            {
                Text = "금요일",
                Value = "6",
            });
            itemList.Add(new SelectListItem
            {
                Text = "토요일",
                Value = "7",
            });

            return itemList;
        }
    }
}
