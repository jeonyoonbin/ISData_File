﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class BizInfoController : Controller
    {
        private readonly DgShopApiService dgShop;
        public BizInfoController(DgShopApiService api)
        {
            dgShop = api;
        }

        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            Request req = new Request()
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };
            var temp = await dgShop.Post<ShopBizInfo, Request>("BizInfo", req);
            if (temp.code.Equals("00"))
            {
                var viewResult = temp.data.SingleOrDefault();

                if (string.IsNullOrEmpty(viewResult.EMAIL))
                {
                    viewResult.emails = null;
                }
                else
                {
                    viewResult.emails = viewResult.EMAIL.Split("@");
                }
                
                return View(viewResult);
            }
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Email(ShopBizInfo param)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if (string.IsNullOrEmpty(param.EMAIL))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "이메일을 입력해주세요"
                });
            }
            RequestSetEmail model = new RequestSetEmail()
            {
                shop_cd = info.shop_cd,
                cccode = info.cccode,
                Email = param.EMAIL,
                job_gbn = "1"
            };

            var req = await dgShop.Post<ShopBizInfo, RequestSetEmail>("SetEmail", model);

            if (req.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    Msg = "성공"
                });
            }

            return BadRequest(new
            {
                code = "99",
                Msg = req.msg
            });
        }

        public async Task<IActionResult> Edit()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var taxType = await dgShop.Get<TaxType>("BizTaxType");

            Request req = new Request()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };
            var temp = await dgShop.Post<ShopBizInfo, Request>("BizInfo", req);
            if (temp.code.Equals("00"))
            {
                var viewResult = temp.data.SingleOrDefault();
                ViewBag.taxType = new SelectList(taxType.data, "code", "type_name", viewResult.BUSS_TAX_TYPE);

                return View(viewResult);
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Edit(ShopBizInfo model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var temp = await dgShop.Post<ShopBizInfo, RequestSetBizInfo>("BizInfo/Set", new RequestSetBizInfo()
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                address = model.BUSS_ADDR,
                buss_con = model.BUSS_CON,
                buss_type = model.BUSS_TYPE,
                tax_type = model.BUSS_TAX_TYPE,
                reg_no = model.REG_NO,
                owner = model.BUSS_OWNER
            });

            if (temp.code.Equals("00"))
            {
                return RedirectToAction(nameof(Index));
            }

            return View(model);

        }

    }
}
