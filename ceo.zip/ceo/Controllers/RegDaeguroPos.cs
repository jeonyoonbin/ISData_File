﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.RequestDaeguroPos;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseDaeguroPos;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DaeguroPos;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.RegDaeguroPos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    public class RegDaeguroPos : Controller
    {
        private readonly IDaeguroService daeguroPos;
        private readonly DgShopApiService dgShop;

        public RegDaeguroPos(IDaeguroService service, DgShopApiService api)
        {
            daeguroPos = service;
            dgShop = api;
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> Index(string memberCode = null, string centerCode = null)
        {
            var data = new
            {
                job_gbn = "USEFIND"
            };

            #region 회원사 가져오기

            var membershipList = await daeguroPos.Post<Membership, dynamic>("GetMembership", data);

            if (string.IsNullOrEmpty(memberCode))
            {
                ViewBag.memberships = new SelectList(new List<Membership>() { membershipList }, "mcode", "mname");
            }
            else
            {
                ViewBag.memberships = new SelectList(new List<Membership>() { membershipList }, "mcode", "mname", memberCode);
            }

            #endregion
            if (string.IsNullOrEmpty(memberCode))
            {
                ViewBag.centers = new SelectList(new List<Callcenter>(), "cccode", "ccname");
            }
            else
            {
                if (string.IsNullOrEmpty(centerCode))
                {
                    var centerdata = new
                    {
                        job_gbn = "FIND",
                        mcode = memberCode
                    };

                    var centerList = await daeguroPos.Post<CenterList, dynamic>("GetCallcenter", centerdata);
                    ViewBag.centers = new SelectList(centerList.ccList, "cccode", "ccname");
                }
                else
                {
                    var centerdata = new
                    {
                        job_gbn = "FIND",
                        mcode = memberCode
                    };

                    var centerList = await daeguroPos.Post<CenterList, dynamic>("GetCallcenter", centerdata);
                    ViewBag.centers = new SelectList(centerList.ccList, "cccode", "ccname", centerCode);
                }
            }




            return View();
        }

        /// <summary>
        /// 대구로POS 전용 등록 페이지
        /// </summary>
        /// <param name="id"></param>
        /// <param name="memberCode"></param>
        /// <param name="centerCode"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Create(string id, string memberCode = null, string centerCode = null)
        {
            var data = new
            {
                job_gbn = "USEFIND"
            };

            #region 회원사 가져오기

            var membershipList = await daeguroPos.Post<MembershipList, dynamic>("GetMembership", data);

            if(!membershipList.code.Equals("0"))
            {
                ModelState.AddModelError("", "회원사 리스트를 가져오는데 실패 했습니다");
                return View();
            }

            var memberships = membershipList.mList.Where(x => x.mname.Equals("대구로") || x.mname.Equals("대구로테스트")).ToList();

            if (string.IsNullOrEmpty(memberCode))
            {

                ViewBag.memberships = new SelectList(memberships, "mcode", "mname");
            }
            else
            {
                ViewBag.memberships = new SelectList(memberships, "mcode", "mname", memberCode);
            }


            #endregion

            #region 콜센터 가져오기

            if (string.IsNullOrEmpty(memberCode))
            {
                ViewBag.centers = new SelectList(new List<Callcenter>(), "cccode", "ccname");
            }
            else
            {
                if (string.IsNullOrEmpty(centerCode))
                {
                    var centerdata = new
                    {
                        job_gbn = "FIND",
                        mcode = memberCode
                    };

                    var centerList = await daeguroPos.Post<CenterList, dynamic>("GetCallcenter", centerdata);
                    ViewBag.centers = new SelectList(centerList.ccList, "cccode", "ccname");
                }
                else
                {
                    var centerdata = new
                    {
                        job_gbn = "FIND",
                        mcode = memberCode
                    };

                    var centerList = await daeguroPos.Post<CenterList, dynamic>("GetCallcenter", centerdata);
                    ViewBag.centers = new SelectList(centerList.ccList, "cccode", "ccname", centerCode);
                }
            }
            #endregion


            /// 대구로 테스트에서는 멤버쉽, 콜센터 정보를 강제 설정해 놓는다.

            string mcode = string.Empty;
            string cccode = string.Empty;

            #region 상점 정보 가져오기

            Request req = new Request()
            {
                job_gbn = "1",
                shop_cd = Convert.ToInt32(id)
            };

            var temp = await dgShop.Post<SynchronizeShopInfo, Request>("syncInfo", req);
            if (temp.code.Equals("00"))
            {
                var daeguroShop = temp.data.SingleOrDefault();

                RegisterDaeguroPosViewModel model = new RegisterDaeguroPosViewModel()
                {
                    bizno = daeguroShop.reg_no,
                    mobile = daeguroShop.mobile,
                    owner = daeguroShop.buss_owner,
                    pos_id = daeguroShop.shop_id,
                    shop_cd = daeguroShop.shop_cd,
                    telno = daeguroShop.telno,
                    shop_name = daeguroShop.shop_name
                };

                return View(model);

            }

            ModelState.AddModelError("", string.Concat("대구로 사장님 정보를 가져오는데 실패 했습니다. ", Environment.NewLine, temp.msg));
            #endregion

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(RegisterDaeguroPosViewModel model, string memberCode = null, string centerCode = null)
        {

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            #region 회원사 가져오기
            var data = new
            {
                job_gbn = "USEFIND"
            };

            var membershipList = await daeguroPos.Post<Membership, dynamic>("GetMembership", data);

            if (string.IsNullOrEmpty(memberCode))
            {
                ViewBag.memberships = new SelectList(new List<Membership>() { membershipList }, "mcode", "mname");
            }
            else
            {
                ViewBag.memberships = new SelectList(new List<Membership>() { membershipList }, "mcode", "mname", memberCode);
            }

            #endregion

            #region 콜센터 가져오기

            if (string.IsNullOrEmpty(memberCode))
            {
                ViewBag.centers = new SelectList(new List<Callcenter>(), "cccode", "ccname");
            }
            else
            {
                if (string.IsNullOrEmpty(centerCode))
                {
                    var centerdata = new
                    {
                        job_gbn = "FIND",
                        mcode = memberCode
                    };

                    var centerList = await daeguroPos.Post<CenterList, dynamic>("GetCallcenter", centerdata);
                    ViewBag.centers = new SelectList(centerList.ccList, "cccode", "ccname");
                }
                else
                {
                    var centerdata = new
                    {
                        job_gbn = "FIND",
                        mcode = memberCode
                    };

                    var centerList = await daeguroPos.Post<CenterList, dynamic>("GetCallcenter", centerdata);
                    ViewBag.centers = new SelectList(centerList.ccList, "cccode", "ccname", centerCode);
                }
            }
            #endregion

            string mcode = string.Empty;
            string cccode = string.Empty;

            mcode = "2";
            cccode = "2";


            Request req = new Request()
            {
                job_gbn = "1",
                shop_cd = Convert.ToInt32(model.shop_cd)
            };

            var temp = await dgShop.Post<SynchronizeShopInfo, Request>("syncInfo", req);
            if (temp.code.Equals("00"))
            {
                var daeguroShop = temp.data.SingleOrDefault();

                // 대구로POS 가맹점 등록과 매핑
                RequestDaeguroPosRegistShop requestRegist = new RequestDaeguroPosRegistShop()
                {
                    job_gbn = "INSERT",

                    //mcode = model.pos_mcode,
                    //cccode = model.pos_cccode,
                    mcode = mcode,
                    cccode = cccode,

                    shop_name = model.shop_name,
                    login_id = model.pos_id,
                    login_pw = Utils.Sha256("eornfh"), // default : eornfh
                    owner = model.owner,
                    reg_no = model.bizno,
                    telno = model.telno,
                    mobile = model.mobile,

                    use_gbn = "Y",

                    //address = daeguroShop.addr1,
                    address = string.Join(' ', daeguroShop.sido, daeguroShop.sigungu, daeguroShop.road, daeguroShop.build_no),
                    sido = daeguroShop.sido,
                    sigungu = daeguroShop.sigungu,
                    bdong = daeguroShop.dong,
                    address_detail = daeguroShop.build_name,
                    road = daeguroShop.road,
                    
                    lon = string.IsNullOrEmpty(daeguroShop.lon) ? 0 : Convert.ToDouble(daeguroShop.lon),
                    lat = string.IsNullOrEmpty(daeguroShop.lat) ? 0 : Convert.ToDouble(daeguroShop.lat),
                    mod_ucode = "DAEGURO"
                };

                RequestRegistAndMappDaeguroPos registInfo = new RequestRegistAndMappDaeguroPos
                {
                    shop_info = requestRegist
                };

                var insertResult = await daeguroPos.Post<ResponseDaeguroPosInsert, RequestRegistAndMappDaeguroPos>("DaeguroApp_Process", registInfo);

                if(insertResult.code.Equals("0"))
                {
                    // 대구로POS 연동 코드 (하드코딩)
                    RequestShopMappingUpdate mappingData = new RequestShopMappingUpdate()
                    {
                        api_type = "3",
                        api_com_code = insertResult.shop_token,
                        api_com_gbn = "ISPOS",
                        
                        api_com_id = insertResult.pos_shop_info.login_id,
                        api_com_pass = Utils.Sha256("eornfh"),
                        api_use_yn = "Y",
                        cccode = daeguroShop.cccode,
                        shop_cd = Convert.ToInt32(daeguroShop.shop_cd),
                        job_gbn = "I",
                        mod_code = info.login_code,
                        mod_name = info.login_name
                    };

                    var mappResult = await dgShop.Post<ShopMapping, RequestShopMappingUpdate>("MappList/Set", mappingData);
                    if (mappResult.code.Equals("00"))
                    {
                        return RedirectToAction("Index", "Mapp");
                    }


                    ModelState.AddModelError("", mappResult.msg);
                    return View(model); ;
                }

                return View(model);
            }

            ModelState.AddModelError("", temp.msg);
            return View(model);
        }


    }
}
