﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.Review.Adm;
using PosWebApp.Models.Review.Requests;
using PosWebApp.Models.Review.Responses;
using PosWebApp.Services.DgReview;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReviewRestController : ControllerBase
    {
        private readonly ReviewApi api;

        public ReviewRestController(ReviewApi api)
        {
            this.api = api;
        }

        [HttpGet("getString")]
        public string GetString()
        {
            return "token api";
        }

        [HttpPost("token")]
        public async Task<ReviewResponse<TokenBody>> GetToken(RequestBody body)
        {
            ReviewResponse<TokenBody> response = new ReviewResponse<TokenBody>();

            response = await api.Post<TokenBody, dynamic>("get_token", new
            {
                member_company_code = "daegu"
            });

            return response;
        }

        [HttpPost("Register")]
        public async Task<ReviewResponse<ResponseRegistStore>> SetShopReview(RequestBody body)
        {
            ReviewResponse<ResponseRegistStore> response = new ReviewResponse<ResponseRegistStore>();

            try
            {
                var jsonObj = JsonConvert.DeserializeObject<RequestRegistStore>(body.body);

                response = await api.Post<ResponseRegistStore, RequestRegistStore>("reg_store", jsonObj);
            }
            catch (Exception e)
            {
                response.statusCode = StatusCodes.Status400BadRequest;
                response.body.error = e.Message;
            }

            return response;
        }

        [HttpPost("ShopInfo")]
        public async Task<ReviewResponse<ResponseStore>> GetShopReviewInfo(RequestBody body)
        {
            ReviewResponse<ResponseStore> response = new ReviewResponse<ResponseStore>();

            try
            {
                var jsonObj = JsonConvert.DeserializeObject<ReviewStore>(body.body);

                response = await api.Post<ResponseStore, ReviewStore>("select_store", jsonObj);
            }
            catch (Exception e)
            {
                response.statusCode = StatusCodes.Status400BadRequest;
                response.body.error = e.Message;
            }

            return response;
        }


    }
}
