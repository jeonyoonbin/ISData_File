﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using PosWebApp.Database;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    public class RegisterController : Controller
    {
        private readonly string DaeguDbConnectionString;
        private readonly string PosDb;
        private readonly IDaeguDatabase db;
        private readonly DgShopApiService dgShop;

        public RegisterController(IConfiguration configuration, IDaeguDatabase daeguDb, DgShopApiService api)
        {
            dgShop = api;

        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
