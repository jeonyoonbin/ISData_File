﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.Common;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Order;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class OrderController : Controller
    {
        private readonly DgShopApiService dgShop;
        public OrderController(IConfiguration configuration, DgShopApiService api)
        {
            dgShop = api;
        }
        public IActionResult Index(string searchText)
        {
            if(!string.IsNullOrEmpty(searchText))
            {
                return View("Search");
            }
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Search(SearchList viewModel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");


            if (!ModelState.IsValid)
            {
                return RedirectToAction("Search");
            }
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            
            ViewBag.options = viewModel.options;
            if(!string.IsNullOrEmpty(viewModel.from) || !string.IsNullOrEmpty(viewModel.to)) { 
                var from = DateTime.ParseExact(viewModel.from, "yyyy-MM-dd", null);
                var to = DateTime.ParseExact(viewModel.to, "yyyy-MM-dd", null);
         

                if (DateTime.Compare(from, to) > 0)
                {
                    ModelState.AddModelError("", "이후 날짜가 이전 날짜보다 더 큽니다.");
                }
            }
            
            await Task.Delay(0);
            return View(viewModel);
        }
        [HttpGet]
        public async Task<IActionResult> Search(SearchList viewModel, string get = null)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ViewBag.options = viewModel.options;
            RequestShopOrderList requestModel;
            if (viewModel.from != null)
            {
                requestModel = new RequestShopOrderList()
                {
                    job_gbn = ((int)ORDER_SEARCH_TYPE.기간).ToString(),
                    shop_cd = info.shop_cd,
                    cccode = info.cccode,
                    from_date = viewModel.from.Replace("-", ""),
                    to_date = viewModel.to.Replace("-", "")
                };
            }
            else
            {
                requestModel = new RequestShopOrderList()
                {
                    job_gbn = ((int)ORDER_SEARCH_TYPE.최근).ToString(),
                    shop_cd = info.shop_cd,
                    cccode = info.cccode
                };
                ViewBag.options = "5";
                viewModel.from = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd");
                viewModel.to = DateTime.Now.ToString("yyyy-MM-dd");


            }

            var from = DateTime.ParseExact(viewModel.from, "yyyy-MM-dd", null);
            var to = DateTime.ParseExact(viewModel.to, "yyyy-MM-dd", null);

            if(DateTime.Compare(from, to) > 0)
            {
                ModelState.AddModelError("", "조회 날짜가 이전 날짜보다 이후날짜가 더 큽니다.");
            }
            await Task.Delay(0);
            return View(viewModel);
        }

        public async Task<IActionResult> Detail(OrderDetail order = null)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (!string.IsNullOrEmpty(order.id))
            {
                RequestOrderState requestModel = new RequestOrderState()
                {
                    cccode = info.cccode,
                    shop_cd = info.shop_cd,
                    job_gbn = ((int)CUST_ORDER_SEARCH_TYPE.주문상세).ToString(),
                    order_no = order.id
                };

                Result<ShopOrderDetail> result = await dgShop.Post<ShopOrderDetail, RequestOrderState>("/api/OrderManagement/OrderDetail", requestModel);
                if (result.code == "00")
                {
                    ViewBag.status = orderStatus.getStatusNames(Convert.ToInt32(result.data.SingleOrDefault().status));

                    var detailList = result.data.SingleOrDefault();
                    StringBuilder sb = new StringBuilder();
                    string[] dongAddr = detailList.cust_dong_addr.Split(" ");
                    string[] roadAddr = detailList.cust_road_addr.Split(" ");
                    sb.AppendJoin(" ", maskingAddrValue(dongAddr));
                    detailList.cust_dong_addr = sb.ToString();
                    sb.Clear();

                    sb.AppendJoin(" ", maskingAddrValue(roadAddr));
                    detailList.cust_road_addr = sb.ToString();


                    return View(detailList);
                }

            }
            return View();
        }
        public IActionResult OrderSearch(int pageNumber, string from, string to, string options)
        {
            return ViewComponent("Order", new
            {
                pageNumber = pageNumber,
                from = from,
                to = to,
                options = options
            });
        } 
        public string[] maskingAddrValue(string[] array)
        {
            var length = array.Length;
            array[length -1] = "***";

            return array;
        }
    }
    public class OrderDetail
    {
        public string id { get; set; }
    }
}
