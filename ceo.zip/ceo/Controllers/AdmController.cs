﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.Common;
using PosWebApp.Models.Admin.Request;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.Reservation.Apply.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.Reservation;
using PosWebApp.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    public class AdmController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly ReservationService_T reservationService;
        private readonly string localurl;
        private readonly string ReservationFlag;

        public AdmController(DgShopApiService api, ReservationService_T reservationService, IConfiguration configuration)
        {
            dgShop = api;
            this.reservationService = reservationService;
            localurl = configuration.GetValue<string>("api:local");
            this.ReservationFlag = configuration.GetValue<string>("inspection:ReservationFlag");
        }

        [HttpGet("Login")]
        public IActionResult Index(string url)
        {
            if (string.IsNullOrEmpty(url))
            {
                return NotFound();
            }

            //var reqURL = System.Web.HttpUtility.UrlEncode(Utils.Aes_Encrypt(JsonConvert.SerializeObject(temp), Utils.aes_key2));
            //AdmViewModelV2 model = new AdmViewModelV2();
            //var temp = Utils.Aes_Decrypt(key, Utils.aes_key2);
            //var aesModel = JsonConvert.DeserializeObject<RequestAdminAESModel>(temp);


            ViewBag.request = url;
            return View();
        }
        //[HttpGet("Login/{scd}/{ucode}/{uname}/{job_name}")]
        //public IActionResult Index(string scd, string ucode, string uname, string job_name)
        //{
        //    ViewData["ucode"] = ucode;
        //    ViewData["uname"] = uname;
        //    ViewData["reqUrl"] = job_name;
        //    ViewData["shop_cd"] = scd;
        //    return View();
        //}
        //[HttpGet]
        //public async Task<IActionResult> LinkTo(string reqURL)
        //{
        //    if (string.IsNullOrEmpty(reqURL))
        //    {
        //        return BadRequest(new { Code = "99", Msg = "맞지않는내용입니다." });
        //    }
        //    RequestAdminAESModel aesModel = new RequestAdminAESModel();

        //    try
        //    {
        //        //var temp2 = System.Web.HttpUtility.UrlEncode(Utils.Aes_Encrypt(JsonConvert.SerializeObject(reqURL), Utils.aes_key2));
        //       var temp = Utils.Aes_Decrypt(reqURL, Utils.aes_key2);
        //       aesModel = JsonConvert.DeserializeObject<RequestAdminAESModel>(temp);
        //    }
        //    catch (Exception e) 
        //    {
        //        return BadRequest(new { Code = "99", Msg = "맞지않는내용입니다." });
        //    }
        //    if(aesModel == null)
        //    {
        //        return BadRequest(new { Code = "99", Msg = "맞지않는내용입니다." });
        //    }

        //    try
        //    {
        //        Result<ShopSessionDefaultInfo> shopInfo = await dgShop.Post<ShopSessionDefaultInfo, RequestLogin>("Default", new RequestLogin
        //        {
        //            shop_cd = aesModel.shopCd,
        //            ucode = aesModel.uCode
        //        });
        //        if (shopInfo.data == null || shopInfo.data.Count == 0)
        //        {
        //            return Ok(new
        //            {
        //                code = "99",
        //                msg = shopInfo.msg
        //            });
        //        }

        //        // jwcho 2021.03.11 사용 중인 1개의 가맹점만 가져온다.
        //        var myShop = shopInfo.data.SingleOrDefault<ShopSessionDefaultInfo>(x => x.use_gbn.Equals("Y"));

        //        if (myShop != null)
        //        {
        //            myShop.login_code = Convert.ToInt32(aesModel.uCode);
        //            myShop.login_name = aesModel.uName;

        //            var sessionString = JsonConvert.SerializeObject(myShop);
        //            HttpContext.Session.SetString("shopDefaultInfo", sessionString);


        //            return RedirectToAction("index", "Store");
        //        }
        //    }catch(Exception e)
        //    {
        //        return BadRequest(new { Code = "99", Msg = "맞지않는내용입니다." });
        //    }

        //    return BadRequest(new { Code = "99", Msg = "맞지않는내용입니다." });
        //}

        public async Task<IActionResult> Login(string request)
        {
            if (string.IsNullOrEmpty(request))
            {
                return Ok(new
                {
                    code = "99",
                    message = "입력 데이터가 잘못 되었습니다"
                });
            }
            CodeMsg msg = new CodeMsg();
            AdmViewModelV2 model = new AdmViewModelV2();
            try
            {
                var temp = Utils.Aes_Decrypt(request, Utils.aes_key2);
                model = JsonConvert.DeserializeObject<AdmViewModelV2>(temp);
            }
            catch (Exception e)
            {
                msg.code = "99";
                msg.msg = "입력된 데이터가 잘못되었습니다.";
            }

            if(msg.code == "99")
            {
                return Ok(new
                {
                    code = "99",
                    msg = msg.msg
                });
            }

            if (JobToUrl(model.jobName).Length < 1)
            {
                return Ok(new
                {
                    code = "99",
                    msg = "작업 내용이 없습니다"
                });
            }

            try
            {
                RequestLoginInfo login = new RequestLoginInfo()
                {
                    job_gbn = "2",
                    shop_cd = Convert.ToInt32(model.shopCd),
                    id = model.id,
                    password = model.password
                };
                //Result<ShopSessionDefaultInfo> shopInfo = await dgShop.Post<ShopSessionDefaultInfo, RequestLoginInfo>("Default", login);

                var shopInfo = await dgShop.Post<ShopSessionDefaultInfo, RequestLoginInfo>("/api/ShopManagement/GetLogin", new RequestLoginInfo
                {
                    job_gbn = "2",
                    id = login.id,
                    password = login.password.ToUpper(),
                    shop_cd = login.shop_cd
                });
                if (shopInfo.data == null || shopInfo.data.Count == 0)
                {
                    return Ok(new
                    {
                        code = "99",
                        msg = "사용자 정보가 없습니다"
                    });
                }
                
                // jwcho 2021.03.11 사용 중인 1개의 가맹점만 가져온다.
                var myShop = shopInfo.data.SingleOrDefault<ShopSessionDefaultInfo>(x => x.use_gbn.Equals("Y"));
                var reser = await reservationService.Get<ResponseReservationApply>("apply?shopCode=" + myShop.shop_cd);

                if (!reser.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "99",
                        msg = "사용자 정보가 없습니다"
                    });
                }
                if (myShop != null)
                {

                    //2023.03.16 멀티샵 infomation
                    var mulitShop = await dgShop.Post<ResponseShopAccountInfo, Models.RequestModel.Request>("/api/ShopManagement/AccInfo", new Models.RequestModel.Request
                    {
                        cccode = myShop.cccode,
                        shop_cd = myShop.shop_cd
                    });

                    if (mulitShop.code.Equals("00"))
                    {
                        var mulitSingle = mulitShop.data.SingleOrDefault();

                        myShop.multMasterCd = mulitSingle.multiShopCd;
                        myShop.multshopYn = mulitSingle.multiShopYn;
                        myShop.representativeYn = mulitSingle.representativeYn;
                    }

                    myShop.login_code = Convert.ToInt32(myShop.ucode);
                    myShop.login_name = myShop.uname;
                    myShop.u_code = "A";
                    myShop.reservationYN = reser.data.SingleOrDefault().status;

                    var sessionString = JsonConvert.SerializeObject(myShop);
                    HttpContext.Session.SetString("shopDefaultInfo", sessionString);


                    var now = DateTime.Now;
                    var EndTime = DateTime.ParseExact(ReservationFlag, "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture);
                    var diffTime = DateTime.Compare(EndTime, now);

                    if (myShop.shop_type == "9")
                    {
                        if (myShop.reservationYN.Equals("30"))
                        {
                            if (diffTime > 0)
                            {
                                HttpContext.Response.Cookies.Append("reser", "N");

                                return Ok(new
                                {
                                    code = "00",
                                    msg = "성공",
                                    data = "/Main/index"
                                });
                            }
                            else
                            {
                                HttpContext.Response.Cookies.Append("reser", "Y");

                                return Ok(new
                                {
                                    code = "00",
                                    msg = "성공",
                                    data = "/Reservation/index"
                                });
                            }
                        }
                        else if (myShop.reservationYN.Equals("20"))
                        {
                            return Ok(new
                            {
                                code = "99",
                                msg = "예약서비스 심사중입니다. 심사완료 후 이용부탁드립니다."
                            });
                        }
                        else if (myShop.reservationYN.Equals("00"))
                        {

                            return Ok(new
                            {
                                code = "99",
                                msg = "예약서비스 신청 후 이용바랍니다. "
                            });
                        }
                    }

                    if (myShop.reservationYN.Equals("30"))
                    {
                        HttpContext.Response.Cookies.Append("reser", "N");

                    }
                    else if (myShop.reservationYN.Equals("00") || myShop.reservationYN.Equals("20"))
                    {
                        HttpContext.Response.Cookies.Append("reser", "N");
                        //배달/포장만하는경우 -> 신청페이지
                        // 둘다잇을경우 -> main/index

                    }

                    return Ok(new
                    {
                        code = "00",
                        msg = "성공",
                        data = string.Concat(localurl, JobToUrl(model.jobName))
                    });
                }
            }
            catch (Exception e)
            {
                return Ok(new
                {
                    code = "99",
                    msg = e.Message
                });
            }

            return Ok(new
            {
                code = "99",
                msg = "알수 없는 오류"
            });
        }
        private string JobToUrl(string job_name)
        {
            string geoViewerYn = job_name.ToLower();


            if (geoViewerYn.Contains("geofenceviewer"))
            {
                var result = WebUtility.UrlDecode(job_name);
         

                return result;

            }
            
            switch (job_name.ToLower())
            {
                case "operate": return "Operate/Index";
                case "account": return "StoreAccount/Index";
                case "biz": return "BizInfo/Index";
                case "store": return "Store/Index";
                case "menu_group": return "Menu/GetGroupSelect";
                case "menu": return "Menu/MenuInquiry";
                case "geofence": return "DeliveryAreaTip/Index";
                default:
                    return "";
            }
        }
    }
}
