﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Database;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Flag;
using PosWebApp.ViewModels.Mapp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class MappController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly string config;

        public MappController(DgShopApiService api, IConfiguration _config)
        {
            dgShop = api;
            config = _config.GetValue<string>("api:local");
        }

        #region 매핑 관리

        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestShopMapping req = new RequestShopMapping()
            {
                job_gbn = "1",
                api_type = "%"
            };
            var temp = await dgShop.Post<ShopMapping, RequestShopMapping>("MappList", req);

            if (temp.code.Equals("00"))
            {
                List<ShopMappingModel> modelList = new List<ShopMappingModel>();
                foreach (var item in temp.data)
                {
                    ShopMappingModel model = new ShopMappingModel()
                    {
                        shop_map_seq = item.SHOP_MAP_SEQ,
                        api_com_gbn = item.API_COM_GBN,
                        api_com_code = item.API_COM_CODE,
                        api_com_code2 = item.API_COM_CODE2,
                        api_com_id = item.API_COM_ID,
                        api_com_pass = item.API_COM_PASS,
                        api_com_auth = item.API_COM_AUTH,
                        api_com_token = item.API_COM_TOKEN,
                        api_daily_token = item.API_DAILY_TOKEN,
                        api_type = item.API_TYPE,
                        api_use_yn = item.API_USE_YN,
                        shop_name = item.SHOP_NAME,
                        shop_cd = item.SHOP_CD,
                        cccode = item.CCCODE
                    };
                    modelList.Add(model);
                }

                return View(modelList);
            }

            return View();
        }
        [HttpGet]
        public async Task<IActionResult> Index(string search_text)
        {
            if (!string.IsNullOrEmpty(search_text))
            {
                search_text = search_text.Trim();
                ViewData["SearchText"] = search_text;
            }

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestShopMapping req = new RequestShopMapping()
            {
                job_gbn = "1",
                api_type = "%"
            };
            var temp = await dgShop.Post<ShopMapping, RequestShopMapping>("MappList", req);

            if (temp.code.Equals("00"))
            {
                var searchShop = temp.data;
                if (search_text != null)
                {
                    searchShop = searchShop.Where(x => x.SHOP_NAME.Contains(search_text)).ToList();
                }

                List<ShopMappingModel> modelList = new List<ShopMappingModel>();
                foreach (var item in searchShop)
                {
                    ShopMappingModel model = new ShopMappingModel()
                    {
                        shop_map_seq = item.SHOP_MAP_SEQ,
                        api_com_gbn = item.API_COM_GBN,
                        api_com_code = item.API_COM_CODE,
                        api_com_code2 = item.API_COM_CODE2,
                        api_com_id = item.API_COM_ID,
                        api_com_pass = item.API_COM_PASS,
                        api_com_auth = item.API_COM_AUTH,
                        api_com_token = item.API_COM_TOKEN,
                        api_daily_token = item.API_DAILY_TOKEN,
                        api_type = item.API_TYPE,
                        api_use_yn = item.API_USE_YN,
                        shop_name = item.SHOP_NAME,
                        shop_cd = item.SHOP_CD,
                        cccode = item.CCCODE
                    };
                    modelList.Add(model);
                }

                return View(modelList);
            }


            return View();
        }

        public async Task<IActionResult> GetShop(string search_text, string code1, string code2, string myname, string tid)
        {
            RequestShopMapping req = new RequestShopMapping()
            {
                job_gbn = "1",
                api_type = "%"
            };

            var temp = await dgShop.Post<ShopMapping, RequestShopMapping>("MappList", req);

            if (search_text != null)
            {
                if(temp == null)
                {
                    return Ok(new
                    {
                        code = "99",
                        message = "데이터 요청에 에러 관리자에게 문의 하세요."
                    });
                }
                else if(!temp.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "99",
                        message = temp.msg
                    });
                }

                var searchShop = temp.data;
                searchShop = searchShop.Where(x => x.SHOP_CD.Equals(code1)).ToList();
                if(searchShop.Count > 0)
                {
                    return Ok(new
                    {
                        code = "01",
                        message = "이미 연결 된 업체 정보가 있습니다."
                    });
                }

                return Ok(new
                {
                    code = "00",
                    message = string.Concat( $"Mapp/Create?searchText={search_text}&code1={code1}&code2={code2}&shop_id={tid}&shop_name={myname}")
                }); ;
            }

            return Ok(new
            {
                code = "99",
                message = "상점 정보를 수신하지 못 했습니다."
            });
        }

        [HttpGet]
        public async Task<IActionResult> GetCompanyList(string type)
        {
            var b2bCompanyList = await dgShop.Post<ApiCompanyInfoViewModel, RequestApiCompanyInfo>("apicom/List", new RequestApiCompanyInfo()
            {
                job_gbn = "1",
                com_type = type
            });

            if (b2bCompanyList.code.Equals("00"))
            {
                ViewBag.b2bList = new SelectList(b2bCompanyList.data, "company_code", "company_name");
            }

            return View();
        }

        public async Task<IActionResult> CreateList(string searchText, string code1, string code2, string shop_id, string shop_name)
        {
            if (string.IsNullOrEmpty(searchText))
            {
                return View();
            }
            searchText = searchText.Trim();
            ViewData["searchText"] = searchText;
            ViewData["shop_id"] = shop_id;
            ViewData["shop_name"] = shop_name;
            ViewData["shop_cd"] = code1;
            ViewData["cccode"] = code2;

            RequestSearchShop requestShopData = new RequestSearchShop();

            // 일반 검색일 때

            requestShopData.job_gbn = "1";
            requestShopData.search_data = searchText;

            var shopList = await dgShop.Post<ShopAllInfo, RequestSearchShop>("Search/Shop", requestShopData);



            if (shopList.code.Equals("00"))
            {
                ViewBag.shopList = shopList.data;

                // 업체 타입
                ViewBag.comType = new SelectList(CommonData.GetB2bCompanyType(), "Value", "Text", "3");

                // 업체 리스트

                var b2bCompanyList = await dgShop.Post<ApiCompanyInfoViewModel, RequestApiCompanyInfo>("apicom/List", new RequestApiCompanyInfo()
                {
                    job_gbn = "1",
                    com_type = "3",
                });

                if (b2bCompanyList.code.Equals("00"))
                {
                    ViewBag.b2bList = new SelectList(b2bCompanyList.data, "company_code", "company_name");
                }

            }

            // 선택 된 가맹점 정보 셋팅
            //if (!string.IsNullOrEmpty(shop_id))
            //{
            //    var found = shopList.data.Where(x => x.shop_id.Equals(shop_id)).FirstOrDefault();

            //    ShopMappingModel model = new ShopMappingModel()
            //    {
            //        shop_cd = found.shop_cd,
            //        shop_name = found.shop_name,
            //        cccode = found.cccode
            //    };

            //    return View(model);
            //}

            return View();
        }


        public async Task<IActionResult> Create(string searchText, string code1, string code2, string shop_id, string shop_name)
        {

            if (string.IsNullOrEmpty(searchText))
            {
                return View();
            }

            searchText = searchText.Trim();
            ViewData["searchText"] = searchText;
            ViewData["shop_id"] = shop_id;
            ViewData["shop_name"] = shop_name;
            ViewData["shop_cd"] = code1;
            ViewData["cccode"] = code2;

            RequestSearchShop requestShopData = new RequestSearchShop();

            // 일반 검색일 때

            requestShopData.job_gbn = "1";
            requestShopData.search_data = searchText;

            var shopList = await dgShop.Post<ShopAllInfo, RequestSearchShop>("Search/Shop", requestShopData);



            if (shopList.code.Equals("00"))
            {
                ViewBag.shopList = shopList.data;

                // 업체 타입
                ViewBag.comType = new SelectList(CommonData.GetB2bCompanyType(), "Value", "Text", "3");

                // 업체 리스트

                var b2bCompanyList = await dgShop.Post<ApiCompanyInfoViewModel, RequestApiCompanyInfo>("apicom/List", new RequestApiCompanyInfo()
                {
                    job_gbn = "1",
                    com_type = "3",
                });

                if (b2bCompanyList.code.Equals("00"))
                {
                    ViewBag.b2bList = new SelectList(b2bCompanyList.data, "company_gbn", "company_name");
                }

            }

            return View();

        }
        [HttpPost]
        public async Task<IActionResult> Create(ShopMappingModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ViewData["shop_cd"] = model.shop_cd;
            ViewData["cccode"] = model.cccode;
            ViewData["shop_id"] = model.shop_id;
            ViewData["shop_name"] = model.shop_name;

            model.api_type = "3";
            ViewBag.comType = new SelectList(CommonData.GetB2bCompanyType(), "Value", "Text", model.api_type);

            var b2bCompanyList = await dgShop.Post<ApiCompanyInfoViewModel, RequestApiCompanyInfo>("apicom/List", new RequestApiCompanyInfo()
            {
                job_gbn = "1",
                com_type = "3",
                com_gbn = model.api_com_gbn
            });

            if (b2bCompanyList.code.Equals("00"))
            {
                ViewBag.b2bList = new SelectList(b2bCompanyList.data, "company_gbn", "company_name");
            }

            var selectedCompany = b2bCompanyList.data.SingleOrDefault();

            if (model.api_com_gbn.Equals("--"))
            {
                ModelState.AddModelError("api_com_gbn", "연동 업체를 선택해 주세요");
                return View(model);
            }
            /// company Info 자동 셋팅. 업체마다 다름. 현재는 API INFO를 기준으로 자동  대입.
            /// auth, token 정보는 추후 개발 사항에 따라 달라질 수 있음
            RequestShopMappingUpdate mappingData = new RequestShopMappingUpdate()
            {
                api_com_auth = model.api_com_auth,
                api_type = selectedCompany.company_type,
                api_com_code = model.api_com_code,
                api_com_code_2 = model.api_com_code2,
                api_com_gbn = selectedCompany.company_gbn,
                api_com_token = model.api_com_token,
                api_com_id = model.api_com_id,
                api_com_pass = model.api_com_pass,
                api_use_yn = "Y",
                cccode = model.cccode,
                job_gbn = "I",
                shop_cd = Convert.ToInt32(model.shop_cd),
                mod_code = info.login_code,
                mod_name = info.login_name
            };

            var temp = await dgShop.Post<ShopMapping, RequestShopMappingUpdate>("MappList/Set", mappingData);
            if (temp.code.Equals("00"))
            {
                return RedirectToAction("Index", "Mapp");
            }

            ModelState.AddModelError("", temp.msg);

            // 업체 리스트를 새로 불러와야 함.
            var b2bCompanyListnew = await dgShop.Post<ApiCompanyInfoViewModel, RequestApiCompanyInfo>("apicom/List", new RequestApiCompanyInfo()
            {
                job_gbn = "1",
                com_type = "3",
            });

            if (b2bCompanyListnew.code.Equals("00"))
            {
                ViewBag.b2bList = new SelectList(b2bCompanyListnew.data, "company_gbn", "company_name");
            }
            return View();
        }

        public async Task<IActionResult> Update(string seq, string code, string api_type)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            RequestShopMapping req = new RequestShopMapping()
            {
                job_gbn = "3",
                shop_cd = Convert.ToInt32(code),
                api_type = api_type
            };

            var temp = await dgShop.Post<ShopMapping, RequestShopMapping>("MappList", req);

            if (temp.code.Equals("00"))
            {
                var mappData = temp.data.SingleOrDefault(x => x.SHOP_MAP_SEQ.Equals(seq));

                ViewBag.comType = new SelectList(CommonData.GetB2bCompanyType(), "Value", "Text", mappData.API_TYPE);

                ViewBag.usegbn = new SelectList(CommonData.GetUseGBN(), "Value", "Text", mappData.API_USE_YN);

                var b2bCompanyList = await dgShop.Post<ApiCompanyInfoViewModel, RequestApiCompanyInfo>("apicom/List", new RequestApiCompanyInfo()
                {
                    job_gbn = "1",
                    com_type = mappData.API_TYPE
                });

                if (b2bCompanyList.code.Equals("00"))
                {
                    ViewBag.b2bList = new SelectList(b2bCompanyList.data, "company_gbn", "company_name", mappData.API_COM_GBN);
                }
                else
                {
                    ModelState.AddModelError("api_com_gbn", b2bCompanyList.msg);
                    return View(mappData);
                }

                ShopMappingModel model = new ShopMappingModel()
                {
                    cccode = mappData.CCCODE,
                    shop_cd = mappData.SHOP_CD,
                    shop_map_seq = mappData.SHOP_MAP_SEQ,
                    api_com_gbn = mappData.API_COM_GBN,
                    api_com_code = mappData.API_COM_CODE,
                    api_com_code2 = mappData.API_COM_CODE2,
                    api_com_id = mappData.API_COM_ID,
                    api_com_pass = mappData.API_COM_PASS,
                    api_com_auth = mappData.API_COM_AUTH,
                    api_com_token = mappData.API_COM_TOKEN,
                    api_daily_token = mappData.API_DAILY_TOKEN,
                    api_type = mappData.API_TYPE,
                    api_use_yn = mappData.API_USE_YN,
                    shop_name = mappData.SHOP_NAME

                };
                return View(model);
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Update(ShopMappingModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ViewBag.comType = new SelectList(CommonData.GetB2bCompanyType(), "Value", "Text", model.api_type);
            ViewBag.usegbn = new SelectList(CommonData.GetUseGBN(), "Value", "Text", model.api_use_yn);

            var b2bCompanyList = await dgShop.Post<ApiCompanyInfoViewModel, RequestApiCompanyInfo>("apicom/List", new RequestApiCompanyInfo()
            {
                job_gbn = "1",
                com_type = model.api_type,
            });

            if (b2bCompanyList.code.Equals("00"))
            {
                ViewBag.b2bList = new SelectList(b2bCompanyList.data, "company_gbn", "company_name", model.api_com_gbn);
            }
            else
            {
                ModelState.AddModelError("api_com_gbn", b2bCompanyList.msg);
                return View(model);
            }

            var selectedB2bCompany = b2bCompanyList.data.Find(x => x.company_gbn.Equals(model.api_com_gbn));


            /// 업데이트에서는  token, auth 정보를 수정할 수 있도록 해놓음.
            RequestShopMappingUpdate updateData = new RequestShopMappingUpdate()
            {
                job_gbn = "U",
                cccode = model.cccode,
                shop_cd = Convert.ToInt32(model.shop_cd),
                api_com_gbn = selectedB2bCompany.company_gbn,
                api_type = selectedB2bCompany.company_type,
                api_com_auth = model.api_com_auth,
                api_com_code = model.api_com_code,
                api_com_code_2 = model.api_com_code2,
                api_com_id = model.api_com_id,
                api_com_pass = model.api_com_pass,
                api_com_token = model.api_com_token,
                api_daily_token = model.api_daily_token,
                api_memo = model.memo,
                api_use_yn = model.api_use_yn,
                shop_map_seq = Convert.ToInt32(model.shop_map_seq),
                mod_code = info.login_code,
                mod_name = info.login_name

            };
            var temp = await dgShop.Post<ShopMapping, RequestShopMappingUpdate>("MappList/Set", updateData);

            if(temp.code.Equals("00"))
            {
                return RedirectToAction("Index", "Mapp");
            }

            ModelState.AddModelError("", temp.msg);

            return View(model);
        }
        #endregion

        #region API 업체 등록/수정 관리

        public async Task<IActionResult> B2bCompany()
        {
            var temp = await dgShop.Post<ApiCompanyInfoViewModel, RequestApiCompanyInfo>("apicom/List", new RequestApiCompanyInfo()
            {
                job_gbn = "1"
            });

            return View(temp.data);
        }

        public IActionResult CreateB2bCompany()
        {
            ViewBag.comType = new SelectList(CommonData.GetB2bCompanyType(), "Value", "Text");

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateB2bCompany(ApiCompanyInfoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ModelState.AddModelError("", "데이터가 유효하지 않습니다.");
                return View(model);
            }

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ViewBag.comType = new SelectList(CommonData.GetB2bCompanyType(), "Value", "Text", model);

            var temp = await dgShop.Post<ApiCompanyInfoViewModel, RequestApiCompanyInfo>("apicom/Set", new RequestApiCompanyInfo()
            {
                job_gbn = "I",
                com_gbn = model.company_gbn,
                com_gbn_2 = model.company_gbn_2,
                com_name = model.company_name,
                com_token = model.company_token,
                com_type = model.company_type,
                com_auth = model.company_auth,
                mod_code = info.login_code,
                mod_user = info.login_name
            }) ;

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("B2bCompany", "Mapp");
            }

            return View(model);
        }

        public async Task<IActionResult> Updateb2bCompany(string sequence)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ApiCompanyInfoViewModel, RequestApiCompanyInfo>("apicom/List", new RequestApiCompanyInfo()
            {
                job_gbn = "1",
                sequence = sequence,
            });

            var viewData = temp.data.SingleOrDefault();

            ViewBag.comType = new SelectList(CommonData.GetB2bCompanyType(), "Value", "Text", viewData.company_type);

            return View(temp.data.SingleOrDefault());
        }

        [HttpPost]
        public async Task<IActionResult> UpdateB2bCompany(ApiCompanyInfoViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ViewBag.comType = new SelectList(CommonData.GetB2bCompanyType(), "Value", "Text", model.company_type);

            // 업데이트 테스트 필요

            var temp = await dgShop.Post<ApiCompanyInfoViewModel, RequestApiCompanyInfo>("apicom/Set", new RequestApiCompanyInfo()
            {
                job_gbn = "U",
                sequence = model.seq,
                com_gbn = model.company_gbn,
                com_gbn_2 = model.company_gbn_2,
                com_name = model.company_name,
                com_token = model.company_token,
                com_type = model.company_type,
                com_auth = model.company_auth,
                mod_code = info.login_code,
                mod_user = info.login_name
            });

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("B2bCompany", "Mapp");
            }

            return View(model);
        }

        #endregion

    }
}
