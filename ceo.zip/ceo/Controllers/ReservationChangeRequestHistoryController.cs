﻿using Microsoft.AspNetCore.Mvc;
using PosWebApp.ActionFilter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ReservationChangeRequestHistoryController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
