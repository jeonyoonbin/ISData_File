﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class PackingSaleController : Controller
    {
        private readonly DgShopApiService dgShop;
        public PackingSaleController(DgShopApiService dgShop)
        {
            this.dgShop = dgShop;
        }
        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp_v2 = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                  ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                  {
                      job_gbn = "1",
                      shop_cd = info.shop_cd,
                  });

            if (temp_v2.code.Equals("00"))
                ViewBag.ShopStore = temp_v2.data.SingleOrDefault();

            return View();
        }

        public async Task<IActionResult> Setting()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var packing = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                  ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                  {
                      job_gbn = "1",
                      shop_cd = info.shop_cd,

                  });

            if (packing.code.Equals("00"))
            {

                var singleTemp = packing.data.SingleOrDefault();
                return View(singleTemp);
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Setting(ApiModels.Shop.Response.ResponseShopInfo model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            Utils utils = new Utils();

            if (string.IsNullOrEmpty(model.toGoMinAmt))
            {
                model.toGoMinAmt = "0";
            }
            if (string.IsNullOrEmpty(model.toGoDiscAmt))
            {
                model.toGoDiscAmt = "0";
            }
            if (string.IsNullOrEmpty(model.toGoMinDiscAmt))
            {
                model.toGoMinDiscAmt = "0";
            }
            if (!utils.MoneyCheck(model.toGoMinAmt.Replace(",", "")))
            {
                ModelState.AddModelError("toGoMinAmt", "최소주문 금액은 100원 단위 이상으로 설정 가능합니다.");
                return View(model);
            }
            if (!utils.MoneyCheck(model.toGoDiscAmt.Replace(",", "")))
            {
                ModelState.AddModelError("toGoDiscAmt", "포장 할인금액은 100원 단위 이상으로 설정 가능합니다.");
                return View(model);
            }


            //model.toGoDiscAmt = Convert.ToInt32(model.toGoDiscAmt.Replace(",", "")).ToString();
            //model.toGoMinAmt = Convert.ToInt32(model.toGoMinAmt.Replace(",", "")).ToString();
            var packing = await dgShop.Post<dynamic, ApiModels.Shop.Request.RequestShopInfo>
                   ("/api/ShopManagement/SetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                   {
                       job_gbn = "7",
                       shop_cd = info.shop_cd,
                       mcode = info.login_code,
                       mName = info.login_name,
                       data1 = model.toGoDiscAmt.Replace(",", ""),
                       data2 = model.toGoMinAmt.Replace(",", ""),
                       data3 = model.toGoMinDiscAmt.Replace(",", ""),
                   });

            if (packing.code.Equals("00"))
            {
                return RedirectToAction("Index");
            }
            ModelState.AddModelError("", packing.msg);
            return View(model);
        }
    }
}
