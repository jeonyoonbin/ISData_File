﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels;
using PosWebApp.ApiModels.Menu.Response;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.Admin.Response;
using PosWebApp.Models.Common;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Admin;
using PosWebApp.Services.DgShop;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class MenuGroupController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly AdminApi adminApi;
        public MenuGroupController(IConfiguration configuration, DgShopApiService api, IUploadImage _uploadImage, AdminApi _adminApi)
        {
            dgShop = api;
            adminApi = _adminApi;
        }
        //public async Task<IActionResult> Choice(string idx = null)
        //{
        //    string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
        //    ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
        //    info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

        //    ViewBag.index = idx;

        //    UrlParams url = new UrlParams();
        //    url.AddParams("shopCd", info.shop_cd.ToString());
        //    var responseMenuGroup = await adminApi.Get<ResponseMenuGroupList>("MenuGroup" + url.ToUrl());

        //    if(responseMenuGroup.code == "00")
        //    {
        //        List<MenuGroupList> menuGroup = new List<MenuGroupList>();
        //        foreach (var select in responseMenuGroup.data)
        //        {
        //            menuGroup.Add(new MenuGroupList() { group_cd = select.menuGroupCd, menu_group_name = select.menuGroupName });
        //        }
        //        ViewBag.selectItem = new SelectList(menuGroup, "group_cd", "menu_group_name", ViewBag.index);
        //    }
        //    return View();
        //}
        public async Task<IActionResult> Choice(string idx = null)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ViewBag.index = idx;

            UrlParams url = new UrlParams();
            url.AddParams("shopCd", info.shop_cd.ToString());
            var responseMenuGroup = await dgShop.Post<ResponseMenuGroup,RequestCommon>("/api/MenuGroupManagement/MenuGroupList", new RequestCommon
            {
                shop_cd = info.shop_cd
            });

            if (responseMenuGroup.code == "00")
            {
                List<MenuGroupList> menuGroup = new List<MenuGroupList>();
                foreach (var select in responseMenuGroup.data)
                {
                    menuGroup.Add(new MenuGroupList() { group_cd = select.menuGroupCd, menu_group_name = select.menuGroupName });
                }
                ViewBag.selectItem = new SelectList(menuGroup, "group_cd", "menu_group_name", ViewBag.index);
            }
            return View();
        }

        public IActionResult test()
        {
            return View();
        }
    }
}
