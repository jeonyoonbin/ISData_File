﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.ApiModels.ShopMall.Respsone;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.RequestDaeguroPos;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseDaeguroPos;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DaeguroPos;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.ShopMall;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class SyncController : ControllerBase
    {
        private readonly IDaeguroService daeguroPosApi;
        private readonly DgShopApiService daeguroApi;
        private readonly IDaeguDatabase db;
        private readonly ShopMallService shopMall;
        private readonly NLog.Logger nlogger;

        public SyncController(IDaeguroService daeguroPosService, DgShopApiService api, ShopMallService shopMall, IDaeguDatabase daeguDb)
        {
            daeguroPosApi = daeguroPosService;
            daeguroApi = api;
            this.shopMall = shopMall;
            db = daeguDb;
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }

        /// <summary>
        /// 사업자 번호 변경 ( 동기화 )
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetBizno")]
        public async Task<Result<ResponseShopBizNo>> SetSetShopBizNo(RequestShopBizno model)
        {
            Result<ResponseShopBizNo> result = new Result<ResponseShopBizNo>();

            try
            {
                #region 매핑 된 가맹점 정보 확인

                var daeguroShopInfo = await daeguroApi.Post<SynchronizeShopInfo, Request>("syncInfo", model);

                if (!daeguroShopInfo.code.Equals("00"))
                {
                    throw new Exception("가맹점 정보 수집에 실패 했습니다");
                }

                var daeguro = daeguroShopInfo.data.SingleOrDefault();

                if (!daeguro.api_com_gbn.Equals("ISPOS"))
                {
                    throw new Exception("혀용되지 않은 업체입니다.");
                }

                if (!model.current_bizno.Equals(daeguro.reg_no))
                {
                    throw new Exception("가맹점 정보가 일치하지 않습니다.");
                }
                #endregion

                #region POS 정보 수정 요청
                /// 사업자 번호 전달
                daeguro.reg_no = model.bizno;

                RequestDaeguroPosRegistShop requestRegist = new RequestDaeguroPosRegistShop(daeguro);
                RequestRegistAndMappDaeguroPos registInfo = new RequestRegistAndMappDaeguroPos
                {
                    shop_info = requestRegist
                };

                var insertResult = await daeguroPosApi.Post<ResponseDaeguroPosInsert, RequestRegistAndMappDaeguroPos>("DaeguroApp_Process", registInfo);

                #endregion

                #region POS 정보 수정 실패 시 업데이트 중단
                if (!insertResult.code.Equals("0"))
                {
                    result.code = "80";
                    result.msg = string.Concat("POS 정보 수정 실패. 대구로 상점 정보 업데이트 불가", Environment.NewLine, insertResult.message);

                    return result;
                }
                #endregion

                #region 내정보 수정 요청
                /// POS 정보 수정 요청이 성공 했다면 내 정보를 수정한다.
                result = await daeguroApi.Post<ResponseShopBizNo, RequestShopBizno>("SetBizNo", model);

                if (!result.code.Equals("00"))
                {
                    #region 내정보 수정 요청 실패 시 롤백

                    daeguro.reg_no = model.current_bizno;

                    RequestDaeguroPosRegistShop requestRegistRollback = new RequestDaeguroPosRegistShop(daeguro);
                    RequestRegistAndMappDaeguroPos registInfoRollback = new RequestRegistAndMappDaeguroPos
                    {
                        shop_info = requestRegist
                    };

                    var insertResultRollback = await daeguroPosApi.Post<ResponseDaeguroPosInsert, RequestRegistAndMappDaeguroPos>("DaeguroApp_Process", registInfo);

                    if (insertResultRollback.code.Equals("0"))
                    {
                        result.code = "80";
                        result.msg = string.Concat("대구로 상점 정보 수정에 실패하여 POS 정보가 롤백 되었습니다.", Environment.NewLine, insertResultRollback.message);
                        return result;
                    }
                    else
                    {
                        result.code = "80";
                        result.msg = string.Concat("대구로 상점 정보 수정 실패하여. POS 정보 롤백을 수행하였으나 성공하지 못 했습니다", Environment.NewLine, insertResultRollback);
                        return result;
                    }
                    #endregion
                }
                #endregion
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("MyPass")]
        public async Task<CodeMsg> SetMyPassword(RequestChangePassword model)
        {
            CodeMsg result = new CodeMsg();
            nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 요청 ");
            nlogger.Info($"[ Change Password {model.shop_cd}] shop_cd = {model.shop_cd} origin data = {JsonConvert.SerializeObject(model)}");
            try
            {
                #region 기존 상점 확인

                var shopConfirm = await daeguroApi.Post<ShopSessionDefaultInfo, RequestLoginInfo>("/api/ShopManagement/GetLogin", new RequestLoginInfo
                {
                    job_gbn = "1",
                    id = model.id,
                    password = Utils.Sha256(model.current)
                });

                if (!shopConfirm.code.Equals("00"))
                {
                    result.code = "99";
                    result.msg = "상점 조회 실패했습니다.";
                    nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                    nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                    return result;
                }
                #endregion


                #region 매핑 된 가맹점 정보 확인

                var daeguroShopInfo = await daeguroApi.Post<SynchronizeShopInfo, Request>("/api/SyncManagement/GetShopSynchronize", model);

                var Closure_shopmall = await shopMall.Post<Listparameter,MallModel.Shop.RequestUserInfo>("/api/V1/users/exist/", new MallModel.Shop.RequestUserInfo
                {
                    user_id = model.id,
                    password = Utils.SetMD5(model.current)
                }, "GET");

                if (!daeguroShopInfo.code.Equals("00"))
                {
                    result.code = "99";
                    result.msg = "가맹점 정보 수집에 실패 했습니다.";
                    nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                    nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");

                    return result;
                }
                #region 폐쇄몰 여부
                var Closure_requestShopMall = Closure_shopmall;
                if (Closure_requestShopMall.code.Equals("1000"))
                {
                    if (Closure_requestShopMall.data.query_code.Equals("OK"))
                    {
                        model.shopMallYn = "Y";
                    }
                    else
                    {
                        model.shopMallYn = "N";
                    }
                }
                else
                {
                    model.shopMallYn = "N";
                }
                #endregion

                //daeguroShopInfo.data = null;

                // 연동 정보가 없다면 대구로 정보만 수정한다.
                if (daeguroShopInfo.data == null && model.shopMallYn == "N" || daeguroShopInfo.data.Count == 0 && model.shopMallYn == "N")
                {
                    var daeguroShop = await daeguroApi.Post<CodeMsg, RequestChangePassword>("/api/ShopManagement/SetShopPassword", model);

                    result.code = daeguroShop.code;
                    result.msg =  string.Concat(daeguroShop.msg, " 연동 정보가 없어 대구로 정보만 업데이트 되었습니다") ;
                    nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                    nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                    return result;
                }

                if(daeguroShopInfo.data == null && model.shopMallYn == "Y" || daeguroShopInfo.data.Count == 0 && model.shopMallYn == "Y")
                {
                    #region 연동 정보 X 쇼핑몰 O
                    var daeguroShop = await daeguroApi.Post<CodeMsg, RequestChangePassword>("/api/ShopManagement/SetShopPassword", model);
                    if (daeguroShop.code.Equals("00"))
                    {
                        MallModel.Shop.RequestCurrentInfo info = new MallModel.Shop.RequestCurrentInfo()
                        {
                            user_id = model.id,
                            password = Utils.SetMD5(model.current),
                            change_password = Utils.SetMD5(model.password)
                        };
                        var ChangeShopmall = await shopMall.Post<Listparameter, MallModel.Shop.RequestCurrentInfo>("/api/V1/users/setup/password/", info, "PUT");

                        var requestShopMall = ChangeShopmall;
                        if(!requestShopMall.code.Equals("1000") && requestShopMall.data.parameter != null)
                        {
                            requestShopMall.data.query_code = "NO";
                            requestShopMall.msg = requestShopMall.data.parameter[0].msg != null ? requestShopMall.data.query_msg : "쇼핑몰정보가 존재하지않습니다.";
                        }
                        if (!requestShopMall.code.Equals("1000") && !requestShopMall.data.query_code.Equals("OK")) { 
                           
                            result.code = "80";
                            result.msg = string.Concat("shopMall 정보 수정 실패. 연동 정보가 없어 대구로 상점만 업데이트했습니다.", Environment.NewLine, requestShopMall.msg);
                            nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                            nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                            return result;
                            
                        }

                        result.code = daeguroShop.code;
                        result.msg = string.Concat(daeguroShop.msg, "연동 정보가 없어, 대구로, 쇼핑몰 업데이트 되었습니다");
                        nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                        nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                        return result;
                    }
                    else
                    {
                        result.code = daeguroShop.code;
                        result.msg = string.Concat(daeguroShop.msg, "가맹점 정보 수집에 실패 했습니다.");
                        nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                        nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                        return result;
                    }
                    #endregion
                }



                #region 쇼핑몰 비밀번호 변경

//#if Mall_TEST_CODE
                if (model.shopMallYn.Equals("Y"))  // 기본정보에 쇼핑몰 정보가 잇을경우
                {
                    var ChangeShopmall = await shopMall.Post<Listparameter,MallModel.Shop.RequestCurrentInfo>("/api/V1/users/setup/password/", new MallModel.Shop.RequestCurrentInfo
                    {
                        user_id = model.id,
                        password = Utils.SetMD5(model.current),
                        change_password = Utils.SetMD5(model.password)
                    }, "PUT");

                    var requestShopMall = ChangeShopmall;
                    if (!requestShopMall.code.Equals("1000") && requestShopMall.data.parameter != null)
                    {
                        requestShopMall.data.query_code = "NO";
                        requestShopMall.msg = requestShopMall.data.parameter[0].msg != null ? requestShopMall.data.query_msg : "쇼핑몰정보가 존재하지않습니다.";
                    }

                    if (!requestShopMall.code.Equals("1000") && !requestShopMall.data.query_code.Equals("OK"))
                    {
                        result.code = "70";
                        result.msg = string.Concat("shopMall 정보 수정 실패. 대구로 상점 정보 업데이트를 수행하지 못 했습니다.", Environment.NewLine, requestShopMall.msg);
                        nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                        nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                        return result;
                    }
                }

                if (model.shopMallYn.Equals("N"))  // 기본정보 쇼핑몰 X 
                {
                    var shopmall = await shopMall.Post<Listparameter,MallModel.Shop.RequestUserInfo>("/api/V1/users/exist/", new MallModel.Shop.RequestUserInfo
                    {
                        user_id = model.id,
                        password = Utils.SetMD5(model.password)
                    }, "GET");

                    var requestShopMall = shopmall;

                    if (requestShopMall.code.Equals("1000"))
                    {
                        if (requestShopMall.code.Equals("OK"))
                        {
                            var ChangeShopmall = await shopMall.Post<Listparameter,MallModel.Shop.RequestCurrentInfo>("/api/V1/users/setup/password/", new MallModel.Shop.RequestCurrentInfo
                            {
                                user_id = model.id,
                                password = Utils.SetMD5(model.current),
                                change_password = Utils.SetMD5(model.password)
                            }, "PUT"); 

                            var request = ChangeShopmall;
                            //쇼핑몰 정보 조회 후  -> shopmall 정보수정 실패 , 대구로 업데이트 수행하지않음 
                            
                            if (!request.code.Equals("1000") && request.data.parameter != null)
                            {
                                request.data.query_code = "NO";
                                request.msg = request.data.parameter[0].msg;
                            }
                            if (!request.code.Equals("1000") && !request.data.query_msg.Equals("OK"))
                            {
                                result.code = "70";
                                result.msg = string.Concat("shopMall 정보 수정 실패. 대구로 상점 정보 업데이트를 수행하지 못 했습니다.", Environment.NewLine, request.msg);
                                nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                                nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                                return result;
                            }
                        }
                    }
                }

//#endif
                #endregion

                var daeguro = daeguroShopInfo.data.SingleOrDefault();

                nlogger.Info($"Request shop_cd = {model.shop_cd} to {daeguro.api_com_code}");

                if (!daeguro.api_com_gbn.Equals("ISPOS"))
                {
                    result.code = "99";
                    result.msg = "혀용되지 않은 업체입니다.";
                    nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}]", result.msg));
                    nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                    return result;
                }

                /// ID 정보가 맞는지 확인 ( 대구로 )
                if (!model.id.Equals(daeguro.shop_id))
                {
                    result.code = "99";
                    result.msg = "가맹점 정보가 일치하지 않습니다.";
                    nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                    nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                    return result;
                }
                #endregion

                #region POS 정보 수정 요청

                /// 비밀번호. 
                /// 임시로 POS 쪽에서만 암호화를 진행
                /// 대구로 서비스에서 암호화가 됐을 때 View 에서부터 암호화 된 데이터를 수신 받아야 한다.
                /// daeguro.api_com_pass = model.password;
                daeguro.api_com_pass = Utils.Sha256(model.password);
                nlogger.Info($"$[ Change Password {model.shop_cd}] {model.password} to {daeguro.api_com_pass}");
                /// 대구로 서비스 내에서만 사용해야 함
                /// 사용자 MCODE 가 2일 때는 실  사용자, 그 외는 1 테스트로 연결
                RequestDaeguroPosRegistShop requestRegist = new RequestDaeguroPosRegistShop(daeguro)
                {
                    job_gbn = "PWD_UPDATE",
                    mcode = daeguro.mcode.Equals("2") ? "2" : "1",
                    cccode = daeguro.cccode.Equals("2") ? "2" : "1"
                };
                RequestRegistAndMappDaeguroPos registInfo = new RequestRegistAndMappDaeguroPos
                {
                    shop_info = requestRegist
                };

                var insertResult = await daeguroPosApi.Post<ResponseDaeguroPosInsert, RequestRegistAndMappDaeguroPos>("DaeguroApp_Process", registInfo);

                #endregion

                #region POS 정보 수정 실패 시 업데이트 중단
                if (!insertResult.code.Equals("0"))
                {
                    result.code = "80";
                    result.msg = string.Concat("POS 정보 수정 실패. 대구로 상점 정보 업데이트를 수행하지 못 했습니다.", Environment.NewLine, insertResult.message);
                    nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                    nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                    // return result;

                    result = await ShopMallPass(model);

                    return result;
                    
                }
                #endregion
                
                #region 내정보 수정 요청 
                /// POS 정보 수정 요청이 성공 했다면 내 정보를 수정한다.
                var daguroResult = await daeguroApi.Post<CodeMsg, RequestChangePassword>("/api/ShopManagement/SetShopPassword", model);

                if (!daguroResult.code.Equals("00"))
                {
                    #region 내정보 수정 요청 실패 시 롤백
                    daeguro.api_com_pass = model.current;

                    RequestDaeguroPosRegistShop requestRegistRollback = new RequestDaeguroPosRegistShop(daeguro);
                    RequestRegistAndMappDaeguroPos registInfoRollback = new RequestRegistAndMappDaeguroPos
                    {
                        shop_info = requestRegist
                    };

                    var insertResultRollback = await daeguroPosApi.Post<ResponseDaeguroPosInsert, RequestRegistAndMappDaeguroPos>("DaeguroApp_Process", registInfo);

                    if (insertResultRollback.code.Equals("0"))
                    {
                        result.code = "80";
                        result.msg = string.Concat("상점 정보 수정에 실패하여 POS 정보가 롤백 되었습니다. 롤백 ", insertResultRollback.message);
                        nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                        nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");

                        result = await ShopMallPass(model);

                        return result;
                    }
                    else
                    {
                        result.code = "80";
                        result.msg = string.Concat("상점 정보 수정 실패 했습니다. POS 정보 롤백을 수행하였으나 성공하지 못 했습니다 롤백 ", insertResultRollback);
                        nlogger.Info(string.Concat($"[ Change Password {model.shop_cd}] ", result.msg));
                        nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");

                        result = await ShopMallPass(model);

                        return result;
                    }

                    // 쇼핑몰 롤백
                    #endregion
                }

                result.code = daguroResult.code;
                result.msg = daguroResult.msg;

                #endregion

            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            nlogger.Info($"[ Change Password ] ===== 패스워드 변경 완료, Shop_CD ==== {model.shop_cd}");
            return result;
        }


        private async Task<CodeMsg> ShopMallPass(RequestChangePassword model)
        {
            var result = new CodeMsg();

            try
            {
                if (model.shopMallYn.Equals("Y"))  // 기본정보에 쇼핑몰 정보가 잇을경우
                {
                    var ChangeShopmall = await shopMall.Post<Listparameter, MallModel.Shop.RequestCurrentInfo>("/api/V1/users/setup/password/", new MallModel.Shop.RequestCurrentInfo
                    {
                        user_id = model.id,
                        password = Utils.SetMD5(model.password),
                        change_password = Utils.SetMD5(model.current)
                    }, "PUT");

                    var requestShopMall = ChangeShopmall;
                    if (!requestShopMall.code.Equals("1000") && requestShopMall.data.parameter != null)
                    {
                        requestShopMall.data.query_code = "NO";
                        requestShopMall.msg = requestShopMall.data.parameter[0].msg != null ? requestShopMall.data.query_msg : "쇼핑몰정보가 존재하지않습니다.";
                    }

                    if (!requestShopMall.code.Equals("1000") && !requestShopMall.data.query_code.Equals("OK"))
                    {
                        result.code = "70";
                        result.msg = string.Concat("ShopMallPassshopMall 정보 수정 실패. 대구로 상점 정보 업데이트를 수행하지 못 했습니다.", Environment.NewLine, requestShopMall.msg);
                        nlogger.Info(string.Concat($"[ Change Password ShopMallPass {model.shop_cd}] ", result.msg));
                        nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                        return result;
                    }
                }

                if (model.shopMallYn.Equals("N"))  // 기본정보 쇼핑몰 X 
                {
                    var shopmall = await shopMall.Post<Listparameter, MallModel.Shop.RequestUserInfo>("/api/V1/users/exist/", new MallModel.Shop.RequestUserInfo
                    {
                        user_id = model.id,
                        password = Utils.SetMD5(model.password)
                    }, "GET");

                    var requestShopMall = shopmall;

                    if (requestShopMall.code.Equals("1000"))
                    {
                        if (requestShopMall.data.query_code.Equals("OK"))
                        {
                            var ChangeShopmall = await shopMall.Post<Listparameter, MallModel.Shop.RequestCurrentInfo>("/api/V1/users/setup/password/", new MallModel.Shop.RequestCurrentInfo
                            {
                                user_id = model.id,
                                password = Utils.SetMD5(model.password),
                                change_password = Utils.SetMD5(model.current)
                            }, "PUT");

                            var request = ChangeShopmall;
                            if (!request.code.Equals("1000") && request.data.parameter != null)
                            {
                                request.data.query_code = "NO";
                                request.msg = requestShopMall.data.parameter[0].msg == null ? requestShopMall.data.query_msg : "쇼핑몰정보가 존재하지않습니다.";
                            }

                            //쇼핑몰 정보 조회 후  -> shopmall 정보수정 실패 , 대구로 업데이트 수행하지않음 
                            if (!request.code.Equals("1000") && !request.data.query_code.Equals("OK"))
                            {
                                result.code = "70";
                                result.msg = string.Concat("shopMall 정보 수정 실패. 대구로 상점 정보 업데이트를 수행하지 못 했습니다.", Environment.NewLine, request.msg);
                                nlogger.Info(string.Concat($"[ Change Password ShopMallPass {model.shop_cd}] ", result.msg));
                                nlogger.Info($"[ Change Password {model.shop_cd}] ===== 패스워드 변경 실패");
                                return result;
                            }
                        }
                    }
                }
                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
    }
}
