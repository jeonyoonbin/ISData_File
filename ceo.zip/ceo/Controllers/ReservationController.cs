﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Models.Reservation;
using PosWebApp.Models.Reservation.Apply.Response;
using PosWebApp.Models.Reservation.Condition.Response;
using PosWebApp.Models.Reservation.Main;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Reservation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ReservationController : Controller
    {
        private readonly ReservationService_T reservation;
        private readonly string ReservationFlag;
        public ReservationController(ReservationService_T reservation, IConfiguration configuration)
        {
            this.reservation = reservation;
            this.ReservationFlag = configuration.GetValue<string>("inspection:ReservationFlag");
        }
        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var nowDate = DateTime.Now;
            var EndTime = DateTime.ParseExact(ReservationFlag, "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture);
            var diffTime = DateTime.Compare(EndTime, nowDate);

            var applyquery = QueryHelpers.AddQueryString("/apply", new Dictionary<string, string>()
            {
                {"shopCode", info.shop_cd.ToString() }
            });

            var applyreq = await reservation.Get<ResponseReservationApply>(applyquery);

            if (string.IsNullOrEmpty(info.reservationYN) || !applyreq.data.SingleOrDefault().status.Equals("30"))
            {
                HttpContext.Response.Cookies.Append("reser", "N");
                return RedirectToAction("ReservationApply");
            }


            if (applyreq.data.SingleOrDefault().status.Equals("30"))
            {
                if (diffTime > 0)
                {
                    HttpContext.Response.Cookies.Append("reser", "N");
                    return RedirectToAction("ReservationApply");
                }
                else
                {
                    HttpContext.Response.Cookies.Append("reser", "Y");
                }
            }

            ReservationMainInfo mainInfo = new ReservationMainInfo();
            mainInfo.shopName = info.shop_name;

            var now = DateTime.Now;
            var dateEnd = new DateTime(now.Year, now.Month, 1).AddMonths(1).AddDays(-1).ToString("yyyyMMdd");
            var dateBegin = new DateTime(now.Year, now.Month, 1).ToString("yyyyMMdd");

            var query = QueryHelpers.AddQueryString("/reser", new Dictionary<string, string>()
            {
                {"shopCd",info.shop_cd.ToString() },
                {"dateBegin",dateBegin},
                {"dateEnd", dateEnd }
            });


            var req = await reservation.Get<ResponseReservationInfo>(query);

            if (req.code.Equals("00"))
            {
                var returnList = req.data.SingleOrDefault();
                ViewBag.Total = Convert.ToInt32(returnList.status10) +
                                Convert.ToInt32(returnList.status12) +
                                Convert.ToInt32(returnList.status30) +
                                Convert.ToInt32(returnList.status40) +
                                Convert.ToInt32(returnList.status90);
                ViewBag.Status = returnList;
                //ViewBag.statusType = model.selectedType == "Y" ? "1" : model.selectedType;
                // 10028 서버에만 존재함 
                var DayEnd = await reservation.Get<ResponseReservationDayEnd>("shopMagam/" + info.shop_cd);


                ViewBag.DayEnd = DayEnd.data.SingleOrDefault().reserMagamGbn;
                return View(mainInfo);
            }
            ViewBag.Total = 0;
            ViewBag.Status = new ResponseReservationInfo();
            ViewBag.DayEnd = "N";

            return View(mainInfo);
        }
        public async Task<IActionResult> MonthReversion(string start, string end)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var now = DateTime.Now;
            if (string.IsNullOrEmpty(start))
            {
                start = new DateTime(now.Year, now.Month, 1).ToString("yyyyMMdd");
                end = new DateTime(now.Year, now.Month, 1).ToString("yyyyMMdd");
            }
            //var isStart = DateTime.ParseExact(start, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
            //var isEnd = DateTime.ParseExact(end, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
            //var temp = isStart;
            //var isMonth = isEnd.Month - isStart.Month > 1 ? temp.AddMonths(1) : temp;
           
            //var dateEnd = new DateTime(now.Year, isMonth.Month, 1).AddMonths(1).AddDays(-1).ToString("yyyyMMdd");
            //var dateBegin = new DateTime(now.Year, isMonth.Month, 1).ToString("yyyyMMdd");

            var query = QueryHelpers.AddQueryString("/reser-date", new Dictionary<string, string>()
            {
                {"shopCd",info.shop_cd.ToString() },
                {"dateBegin",start.Replace("-","")},
                {"dateEnd", end.Replace("-","") }
            });

            var req = await reservation.Get<ReservationDay>(query);
            
            if (req.code.Equals("00"))
            {
                foreach(var item in req.data)
                {
                    item.text10 = "예약대기 (" + item.status10 + ")";
                    item.text12 = "확정 (" + item.status12 + ")";
                    item.text30 = "방문완료(" + item.status30 + ")";
                    item.text40 = "예약취소 (" + item.status40 + ")";
                    item.text90 = "예약미방문 (" + item.status90 + ")";
                    item.reserDate = Utils.StringFormatToDate(item.reserDate);
                }
                return Ok(new
                {
                    code = "00",
                    Msg = "성공",
                    data = req.data
                });
            }
            return Ok(new
            {
                code = "99",
                Msg = "실패"
            });
        }
        #region 
        public async Task<IActionResult> DayEnd(bool magam)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var DayEnd = await reservation.Put<dynamic,RequestReservationDayEnd>("shopMagam", new RequestReservationDayEnd
            { 
                shopCode = info.shop_cd.ToString(),
                userId = info.login_name,
                reserMagamGbn = magam ? "Y": "N"
            });

            if (DayEnd.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    Msg = magam ? "마감" : "해제",
                    
                });
            }

            return Ok(new
            {
                code = "99",
                Msg = DayEnd.msg
            });
        }
        #endregion

        public IActionResult Intro()
        {
           
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> init()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var req = await reservation.Put<dynamic, RequestReservationIntro>("apply", new RequestReservationIntro()
            {
                shopCd = info.shop_cd.ToString(),
                uCode = info.login_code.ToString(),
                userName = info.login_name,
                gbn = "1"
            });
            return Ok(new
            {
                code = "00",
                Msg = "성공"
            });
        }
        public IActionResult Intro2()
        {
            HttpContext.Response.Cookies.Append("reser", "N");
            return View();
        }
        public IActionResult ShopIntro()
        {
            return View();
        }

        public IActionResult OwnerIntro()
        {
            return View();
        }

        public IActionResult AddressChange()
        {
            return View();
        }

        public IActionResult CategoryChange()
        {
            return View();
        }
        #region 예약 입점 신청 
        public async Task<IActionResult> ReservationApply()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var query = QueryHelpers.AddQueryString("/apply", new Dictionary<string, string>()
            {
                {"shopCode", info.shop_cd.ToString() }
            });

            var req = await reservation.Get<ResponseReservationApply>(query);


            if (req.code.Equals("00"))
            {
                var singleModel = req.data.SingleOrDefault();
                if (singleModel.gbn.Equals("Y"))
                {
                    if (singleModel.status.Contains("30"))
                    {


                        var nowDate = DateTime.Now;
                        var EndTime = DateTime.ParseExact(ReservationFlag, "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture);
                        var diffTime = DateTime.Compare(EndTime, nowDate);


                        if (diffTime > 0)
                        {
                            HttpContext.Response.Cookies.Append("reser", "N");
                            return RedirectToAction("ReservationApplyConfirmIng");
                        }
                        else
                        {
                            info.reservationYN = "Y";
                            var session_save = JsonConvert.SerializeObject(info);
                            HttpContext.Session.SetString("shopDefaultInfo", session_save);

                            HttpContext.Response.Cookies.Append("reser", "Y");
                            return RedirectToAction("index");
                        }

                       
                    }
                    else if (singleModel.status.Contains("20"))
                    {
                        return RedirectToAction("ReservationApplyConfirmIng");
                    }
                    else
                    {
                        return View();
                    }
                }
                else
                {
                    return View();
                }
            }

            return Ok();
        }
        
        public async Task<IActionResult> ReservationApplyConfirm()
        {
            return View();
        }
        public async Task<IActionResult> ReservationApplyConfirmIng()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var query = QueryHelpers.AddQueryString("apply", new Dictionary<string, string>()
            {
                {"shopCode", info.shop_cd.ToString() }
            });

            var req = await reservation.Get<ResponseReservationApply>(query);


            if (req.code.Equals("00"))
            {
                var applystatus = req.data.SingleOrDefault().status;

                if (applystatus.Equals("30"))
                {

                    var nowDate = DateTime.Now;
                    var EndTime = DateTime.ParseExact(ReservationFlag, "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture);
                    var diffTime = DateTime.Compare(EndTime, nowDate);


                    if (diffTime > 0)
                    {
                        HttpContext.Response.Cookies.Append("reser", "N");
                        return View(req.data.SingleOrDefault());
                    }
                    else
                    {
                        info.reservationYN = "Y";
                        var session_save = JsonConvert.SerializeObject(info);
                        HttpContext.Session.SetString("shopDefaultInfo", session_save);

                        HttpContext.Response.Cookies.Append("reser", "Y");
                        return RedirectToAction("index");
                    }
                }
                return View(req.data.SingleOrDefault());
            }
            else
            {
                return RedirectToAction("ReservationConfirm");
            }

        }
        #endregion
    }
}
