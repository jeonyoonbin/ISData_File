﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.MappApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class B2bApiController : ControllerBase
    {
        private readonly IDaeguDatabase db;
        public B2bApiController(IDaeguDatabase daeguDb, IConfiguration configuration)
        {
            db = new DaeguDatabase(Utils.oracleConnectString, configuration);
        }

        #region 매핑 API

        /// <summary>
        /// 상점 메뉴 그룹 제공
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuGroup")]
        public async Task<Result<ResponseMappMenuGroup>> GetMappMenuGroup(RequestMappMenuGroup model)
        {
            Result<ResponseMappMenuGroup> result = new Result<ResponseMappMenuGroup>();

            try
            {
                result = await db.GetMappMenuGroup(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 상점 메뉴 리스트 제공
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuList")]
        public async Task<Result<ResponseMappMenuList>> GetMappMenuList(RequestMappMenuList model)
        {
            Result<ResponseMappMenuList> result = new Result<ResponseMappMenuList>();

            try
            {
                result = await db.GetMappMenuList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 상점 메뉴 옵션 그룹 제공
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("OptionGroup")]
        public async Task<Result<ResponseMappMenuOptionGroup>> GetMappMenuOptionGroup(RequestMappMenuOptionGroup model)
        {
            Result<ResponseMappMenuOptionGroup> result = new Result<ResponseMappMenuOptionGroup>();

            try
            {
                result = await db.GetMappMenuOptionGroup(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 상점 메뉴 옵션 리스트 제공
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("OptionList")]
        public async Task<Result<ResponseMappMenuOptionList>> GetMappMenuOptionList(RequestMappMenuOptionList model)
        {
            Result<ResponseMappMenuOptionList> result = new Result<ResponseMappMenuOptionList>();

            try
            {
                result = await db.GetMappMenuOptionList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        /// <summary>
        /// 상점 메뉴 품절/해제 처리
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Soldout/Menu")]
        public async Task<ResultSingle<ResponseSetMappMenuSoldout>> SetMappMenuSoldout(RequestSetMappMenuSoldout model)
        {
            ResultSingle<ResponseSetMappMenuSoldout> result = new ResultSingle<ResponseSetMappMenuSoldout>();

            try
            {
                result = await db.SetMappMenuSoldout(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 상점 메뉴 옵션 품절/해제 처리
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Soldout/Option")]
        public async Task<ResultSingle<ResponseSetMappMenuOptionSoldout>> SetMappMenuOptionSoldout(RequestSetmappMenuOptionSoldout model)
        {
            ResultSingle<ResponseSetMappMenuOptionSoldout> result = new ResultSingle<ResponseSetMappMenuOptionSoldout>();

            try
            {
                result = await db.SetMappMenuOptionSoldout(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 상점 휴점/영업 처리
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Rest/Set")]
        public async Task<ResultSingle<ResponseSetMappOperate>> SetMappOperate(RequestSetMappOperate model)
        {
            ResultSingle<ResponseSetMappOperate> result = new ResultSingle<ResponseSetMappOperate>();

            try
            {
                result = await db.SetMappShopOperate(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 상점 휴점/개점 상태 전송
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Rest/Get")]
        public async Task<ResultSingle<ResponseSetMappOperate>> GetMappOperate(RequestSetMappOperate model)
        {
            ResultSingle<ResponseSetMappOperate> result = new ResultSingle<ResponseSetMappOperate>();

            try
            {
                result = await db.GetMappShopOperate(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 상점 연결 상태 저장
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("log/Connection")]
        public async Task<CodeMsg> SetShopConnectionLog(RequestConnectionLog model)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                result = await db.SetShopConnectionLog(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        /// <summary>
        /// 휴점 설정
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Absent")]
        public async Task<ResultSingle<ResponseSetMappOperate>> SetShopAbsent(RequestSetMappOperate model)
        {
            ResultSingle<ResponseSetMappOperate> result = new ResultSingle<ResponseSetMappOperate>();

            try
            {
                if(!string.IsNullOrEmpty(model.absent_time)) { 

                    var addMinut = Convert.ToInt32( model.absent_time);
                    string dt = DateTime.Now.AddMinutes(addMinut).ToString("yyyyMMddHHmm");
                    model.absent_time = dt;
                }

                result = await db.SetShopAbsent(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        #endregion

        [HttpPost("Owner/Agreement/Get")]
        public async Task<ResultSingle<ResponseUserAgreement>> GetShopInfoAgreement(RequestGetUserAgreement model)
        {
            ResultSingle<ResponseUserAgreement> result = new ResultSingle<ResponseUserAgreement>();
            try
            {
                result = await db.GetShopInfoAgreement(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("Owner/Agreement/Set")]
        public async Task<ResultSingle<ResponseUserAgreement>> SetShopInfoAgreement(RequestSetUserAgreement model)
        {
            ResultSingle<ResponseUserAgreement> result = new ResultSingle<ResponseUserAgreement>();
            try
            {
                result = await db.SetShopInfoAgreement(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
    }
}
