﻿using System.IO;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PosWebApp.Models.FAQ;
using PosWebApp.ActionFilter;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class FAQController : Controller
    {
        public IActionResult Index(int type = 1, string search = null)
        {
            switch (type)
            {
                case 1:
                    ViewBag.type = "입점 관련";
                    break;
                case 2:
                    ViewBag.type = "운영 기준";
                    break;
                case 3:
                    ViewBag.type = "이벤트";
                    break;
                case 4:
                    ViewBag.type = "사장님 사이트";
                    break;
                case 5:
                    ViewBag.type = "POS";
                    break;
                default:
                    ViewBag.type = "입점 관련";
                    break;
            }

            try
            {
                var folderJSON = Path.Combine(Directory.GetCurrentDirectory(), $"wwwroot\\{"Json\\FAQ.json"}");
                var JSON = System.IO.File.ReadAllText(folderJSON);

                var jsonObj = JsonConvert.DeserializeObject<JsonFAQ>(JSON);

                return View(jsonObj);

            }
            catch(Exception e)
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = e.Message
                });
            }
        }
    }
}
