﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.Common;
using PosWebApp.Models.Reservation;
using PosWebApp.Models.Reservation.items;
using PosWebApp.Models.Reservation.Operate.Request;
using PosWebApp.Models.Reservation.Operate.Response;
using PosWebApp.Models.Reservation.Store.Request;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Reservation;
using PosWebApp.ViewModels.Reservation.Operate;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ReservationOperateController : Controller
    {
        private readonly ReservationService_T reservationService;
        
        public ReservationOperateController(ReservationService_T _reservationService, IConfiguration configuration)
        {
            reservationService = _reservationService;
            
        }

        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var query = QueryHelpers.AddQueryString("/manage?", "shopCd", info.shop_cd.ToString());
            var result = await reservationService.Get<ResponseReservationOperateInfo>(query);

            var f_req = await reservationService.GetArray<ResponseReservationDayOff>("dayOff/" + info.shop_cd + "?gbn=" + "1");
            var s_req = await reservationService.GetArray<ResponseReservationDayOff>("dayOff/" + info.shop_cd + "?gbn=" + "3");
            var t_req = await reservationService.GetArray<ResponseReservationDayOff>("dayOff/" + info.shop_cd + "?gbn=" + "5");

            var argument = new Dictionary<string, string>()
            {
                { "shopCode", info.shop_cd.ToString() }
            };

            var queryMaxPeople = QueryHelpers.AddQueryString("/casesPeople", argument);

            var req = await reservationService.Get<RequestHourlyMaxPeople>(queryMaxPeople);
            var reqReserTime = await reservationService.Get<ResponseReserTime>("/reserTime/" + info.shop_cd.ToString());


            if (reqReserTime.code.Equals("00"))
            {
                foreach (var item in reqReserTime.data)
                {
                    if (item.dayGbn == "1")
                    {
                        item.dayGbn = "8";
                    }
                    if (item.reserTime != null)
                    {
                        foreach (var subitem in item.reserTime)
                        {
                            var splitStr = subitem.time.Substring(0, 2) + ":" + subitem.time.Substring(2);
                            subitem.time = splitStr;
                        }
                    }
                }

                ViewBag.reserTime =  reqReserTime.data.OrderBy(x => Convert.ToInt32(x.dayGbn)).ToList();
            }else
            {
                ViewBag.reserTime = new List<ResponseReserTime>();
            }
            if (req.code.Equals("00"))
            {
                ViewBag.HourlyMaxPeople = req.data.SingleOrDefault();
            }
            else
            {
                ViewBag.HourlyMaxPeopl = new RequestHourlyMaxPeople();
            }

            if (result.code.Equals("00"))
            {
                var sbTime = result.data.SingleOrDefault().sbTimeLists;
                if (sbTime.Count() > 0)
                {
                    foreach (var items in sbTime)
                    {
                        if (items.closeGbn == "N")
                        {
                            var startSplit = 2;
                            items.openTime = items.openTime.Substring(0, startSplit) + " : " + items.openTime.Substring(startSplit, 2);
                            items.closeTime = items.closeTime.Substring(0, startSplit) + " : " + items.closeTime.Substring(startSplit, 2);

                        }
                    }
                }

                if (f_req.code.Equals("00"))
                {
                    ViewBag.dayOffInfo = f_req.data;
                    ViewBag.regularHoliDayInfo = s_req.data;
                    ViewBag.temporaryHoliDayInfo = t_req.data;
                }
                else
                {
                    ViewBag.dayOffInfo = new ResponseReservationDayOff();
                    ViewBag.regularHoliDayInfo   = new ResponseReservationDayOff();
                    ViewBag.temporaryHoliDayInfo = new ResponseReservationDayOff();
                }
                
                return View(result.data.SingleOrDefault());
            }


            return View();
        }

        public IActionResult ModifyOperationStatus(string idx)
        {
            if (string.IsNullOrEmpty(idx))
            {
                idx = "N";
            }
            var result = new RequestStatus();
            result.running = idx;

            return View(result);
        }
        [HttpPost]
        public async Task<IActionResult> OperationStatus(string running)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var query = QueryHelpers.AddQueryString("/reserve-use?", new Dictionary<string, string>()
            {
                {"shopCd", info.shop_cd.ToString()},
                {"reserveYn",  running }
            });

            var result = await reservationService.Put<dynamic>(query);

            return RedirectToAction("Index", "ReservationOperate");
        }

        public async Task<IActionResult> ModifyOperationHours()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //B 휴게타임
            var query = QueryHelpers.AddQueryString("/SbTime/S", new Dictionary<string, string>(){
                { "shopCd", info.shop_cd.ToString() }

            });

            var req = await reservationService.Get<sbTime>(query);


            List<ReserTime> viewReser = new List<ReserTime>();
            if (req.code.Equals("00"))
            {
                foreach (var items in req.data)
                {
                    if (items.closeGbn == "N")
                    {
                        var startSplit = 2;
                        items.openTime = items.openTime.Substring(0, startSplit) + " : " + items.openTime.Substring(startSplit, 2);
                        items.closeTime = items.closeTime.Substring(0, startSplit) + " : " + items.closeTime.Substring(startSplit, 2);
                    }
                    ReserTime reser = new ReserTime()
                    {
                        closeGbn = items.closeGbn == "Y" ? true : false,
                        closeTime = items.closeTime,
                        dayGbn = items.dayGbn == "1" ? "8" : items.dayGbn,
                        openTime = items.openTime
                    };
                    viewReser.Add(reser);
                }

                return View(viewReser.OrderBy(x => Convert.ToInt32(x.dayGbn)).ToList());
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> InityOperationHours(List<ReserTime> model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestReservationSBTime request = new RequestReservationSBTime();

            if (model.Count() > 0)
            {
                request.sbTimeUnit = new List<sbTimeUnit>();
                foreach (var item in model)
                {
                    sbTimeUnit sub = new sbTimeUnit
                    {
                        closeGbn = item.closeGbn ? "Y" : "N",
                        closeTime = item.closeGbn ? "" : item.closeTime.Replace(":", ""),
                        openTime = item.closeGbn ? "" : item.openTime.Replace(":", ""),
                        dayGbn = GetNameDay(item.dayGbn)
                    };
                    request.sbTimeUnit.Add(sub);
                }

                request.sbGbn = "S";
                request.shopCode = info.shop_cd.ToString();


                var result = await reservationService.Post<dynamic, RequestReservationSBTime>
                    ("/sbTime", request);


                if (result.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        Msg = result.msg,
                        data = "/ReservationOperate/Index"
                    });
                }
                else
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = result.msg == null ? "오류가 발생했습니다." : result.msg
                    });
                }

            }
            else
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "내부 오류입니다. 재설정 해주시기바랍니다."
                });
            }
        }

        public async Task<IActionResult> ModifyAmenities()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var query = QueryHelpers.AddQueryString("/manage?", "shopCd", info.shop_cd.ToString());
            var result = await reservationService.Get<ResponseReservationOperateInfo>(query);

            if (result.code.Equals("00"))
            {
                var temp = result.data.SingleOrDefault();
                var modelInject = new AmenitiesViewModel
                {
                    facilities_1 = temp.facilities_1.Equals("Y") ? true : false,
                    facilities_2 = temp.facilities_2.Equals("Y") ? true : false,
                    facilities_3 = temp.facilities_3.Equals("Y") ? true : false,
                    facilities_4 = temp.facilities_4.Equals("Y") ? true : false,
                    facilities_5 = temp.facilities_5.Equals("Y") ? true : false,
                    facilities_6 = temp.facilities_6.Equals("Y") ? true : false,
                    facilities_7 = temp.facilities_7.Equals("Y") ? true : false,
                    facilities_8 = temp.facilities_8.Equals("Y") ? true : false,
                    facilities_9 = temp.facilities_9.Equals("Y") ? true : false,
                    facilities_10 = temp.facilities_10.Equals("Y") ? true : false
                };

                return View(modelInject);
            }


            return View();
        }
        [HttpPost]
        public async Task<IActionResult> InitAmenities(AmenitiesViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (model != null)
            {
                var returnAmenities = new RequestReservationAmenities
                {
                    shopCd = info.shop_cd.ToString(),
                    ccCode = info.cccode,
                    userId = info.login_name,
                    facilities_1 = model.facilities_1 ? "Y" : "N",
                    facilities_2 = model.facilities_2 ? "Y" : "N",
                    facilities_3 = model.facilities_3 ? "Y" : "N",
                    facilities_4 = model.facilities_4 ? "Y" : "N",
                    facilities_5 = model.facilities_5 ? "Y" : "N",
                    facilities_6 = model.facilities_6 ? "Y" : "N",
                    facilities_7 = model.facilities_7 ? "Y" : "N",
                    facilities_8 = model.facilities_8 ? "Y" : "N",
                    facilities_9 = model.facilities_9 ? "Y" : "N",
                    facilities_10 = model.facilities_10 ? "Y" : "N",
                };

                var result = await reservationService.Post<dynamic, RequestReservationAmenities>("/facilities", returnAmenities);

                if (result.code.Equals("00"))
                {
                    return RedirectToAction("index", "ReservationOperate");
                }
                else
                {
                    return RedirectToAction("ModifyAmenities", model);
                }
            }


            return RedirectToAction("ModifyAmenities", model);
        }

        public async Task<IActionResult> ModifyBreaktime()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //S 운영타임
            var query = QueryHelpers.AddQueryString("/SbTime/B", new Dictionary<string, string>(){
                { "shopCd", info.shop_cd.ToString() }

            });

            var req = await reservationService.Get<sbTime>(query);


            List<ReserTime> viewReser = new List<ReserTime>();
            if (req.code.Equals("00"))
            {
                foreach (var items in req.data)
                {
                    if (items.closeGbn == "N")
                    {
                        var startSplit = 2;
                        items.openTime = items.openTime.Substring(0, startSplit) + " : " + items.openTime.Substring(startSplit, 2);
                        items.closeTime = items.closeTime.Substring(0, startSplit) + " : " + items.closeTime.Substring(startSplit, 2);
                    }
                    ReserTime reser = new ReserTime()
                    {
                        closeGbn = items.closeGbn == "Y" ? true : false,
                        closeTime = items.closeTime,
                        dayGbn = items.dayGbn == "1" ? "8" : items.dayGbn,
                        openTime = items.openTime
                    };
                    viewReser.Add(reser);
                }

                return View(viewReser.OrderBy(x => Convert.ToInt32(x.dayGbn)).ToList());
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> InitBreakTime(List<ReserTime> model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestReservationSBTime request = new RequestReservationSBTime();

            if (model.Count() > 0)
            {
                request.sbTimeUnit = new List<sbTimeUnit>();
                foreach (var item in model)
                {
                    sbTimeUnit sub = new sbTimeUnit
                    {
                        closeGbn = item.closeGbn ? "Y" : "N",
                        closeTime = item.closeGbn ? "" : item.closeTime.Replace(":", ""),
                        openTime = item.closeGbn ? "" : item.openTime.Replace(":", ""),
                        dayGbn = GetNameDay(item.dayGbn)
                    };
                    request.sbTimeUnit.Add(sub);
                }

                request.sbGbn = "B";
                request.shopCode = info.shop_cd.ToString();


                var result = await reservationService.Post<dynamic, RequestReservationSBTime>
                    ("/sbTime", request);


                if (result.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        Msg = result.msg,
                        data = "/ReservationOperate/Index"
                    });
                }
                else
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = result.msg == null ? "오류가 발생했습니다." : result.msg
                    });
                }

            }
            else
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "내부 오류입니다. 재설정 해주시기바랍니다."
                });
            }
        }
        public IActionResult ModifyReview(string idx)
        {
            if (string.IsNullOrEmpty(idx))
            {
                idx = "N";
            }
            var result = new RequestStatus();
            result.running = idx;

            return View(result);
        }
        [HttpPost]
        public async Task<IActionResult> ReviewStatus(string running)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var query = QueryHelpers.AddQueryString("/review-use?", new Dictionary<string, string>()
            {
                {"shopCd", info.shop_cd.ToString()},
                {"reviewUseGbn",  running }
            });

            var result = await reservationService.Put<dynamic>(query);

            return RedirectToAction("Index", "ReservationOperate");
        }

        public async Task<IActionResult> ModifyHoliday()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var f_req = await reservationService.GetArray<ResponseReservationDayOff>("dayOff/" + info.shop_cd + "?gbn=" + "1");
            var s_req = await reservationService.GetArray<ResponseReservationDayOff>("dayOff/" + info.shop_cd + "?gbn=" + "3");
            var t_req = await reservationService.GetArray<ResponseReservationDayOff>("dayOff/" + info.shop_cd + "?gbn=" + "5");

            if (f_req.code.Equals("00"))
            {

                ViewBag.dayOffInfo = f_req.data;
                ViewBag.regularHoliDayInfo = s_req.data;
                ViewBag.temporaryHoliDayInfo = t_req.data;


                SelectList weekOffList = new SelectList(await GetWeekList(), "Value", "Text", "%");
                ViewBag.dayWeekOffInfo = weekOffList;
                ViewBag.days = new SelectList(Days.GetDayItems(), "value", "name", "%");
                return View();
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ModifyHoliday(List<ResponseReservationDayOff> models)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if(models.Count() == 0)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "저장 할 내용이 존재하지않습니다."
                });
            }
            string errorCode = null;
            string errorMsg = null;
            try
            {
                for (var i = 0; i < models.Count(); i++)
                {
                    if (models[i].gbn.Equals("1"))
                    {
                        models[i].shopCode = info.shop_cd.ToString();
                        var req = await reservationService.Post<dynamic, ResponseReservationDayOff>("dayOff", models[i]);

                        if (req.code.Equals("00"))
                        {
                            continue;
                        }
                        else
                        {
                            errorCode = "공휴일 설정";
                            errorMsg = req.msg;
                        }
                    }
                    else if (models[i].gbn.Equals("3"))
                    {
                        models[i].shopCode = info.shop_cd.ToString();
                        var req = await reservationService.Post<dynamic, ResponseReservationDayOff>("dayOff", models[i]);
                        if (req.code.Equals("00"))
                        {
                            continue;
                        }
                        else
                        {
                            errorCode = "정기 휴무일";
                            errorMsg = req.msg;
                        }
                    }
                    else if (models[i].gbn.Equals("5"))
                    {
                        models[i].shopCode = info.shop_cd.ToString();
                        for(var index = 0; index < models[i].list.Count(); index++)
                        {
                            models[i].list[index].foDay = models[i].list[index].foDay.Replace("-","");
                            models[i].list[index].toDay = models[i].list[index].toDay.Replace("-","");
                        }
                        var req = await reservationService.Post<dynamic, ResponseReservationDayOff>("dayOff", models[i]);
                        if (req.code.Equals("00"))
                        {
                            continue;
                        }
                        else
                        {
                            errorCode = "임시 휴무일";
                            errorMsg = req.msg;
                        }
                    }
                    else
                    {
                        return Ok(new
                        {
                            code = "99",
                            Msg = "저장 할 내용이 존재하지않습니다."
                        });
                    }
                }
            }
            catch (Exception)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = errorCode + " " + errorMsg
                });
            }
            
            return Ok(new
            {
                code = "00",
                Msg = "성공"
            });
        }
        [HttpPost]
        public async Task<IActionResult> DeleteHoliday(RequestDeleteDayOff model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if (model == null)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "삭제 할 내용이 존재하지않습니다."
                });
            }

            model.shopCode = info.shop_cd.ToString();

            var req = await reservationService.Delete<dynamic, RequestDeleteDayOff>("dayOff", model);


            if (req.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    Msg = "성공"
                });
            }

            return Ok(new
            {
                code = "99",
                Msg = req.msg
            });
        }

        #region 예약 가능 시간 설정
        public async Task<IActionResult> AvailableTime()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var req = await reservationService.Get<ResponseReserTime>("/reserTime/" + info.shop_cd.ToString());


            if (req.code.Equals("00"))
            {
                foreach(var item in req.data)
                {
                    if(item.dayGbn == "1")
                    {
                        item.dayGbn = "8";
                    }
                    if(item.reserTime != null)
                    {
                        foreach (var subitem in item.reserTime)
                        {
                            var splitStr = subitem.time.Substring(0, 2) + ":" + subitem.time.Substring(2);
                            subitem.time = splitStr;
                        }
                    }
                }

                
                return View(req.data.OrderBy(x => Convert.ToInt32(x.dayGbn)).ToList());
            }
            else
            {
                return View();
            }
        }

        public async Task<IActionResult> AvailableTime2()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var req = await reservationService.Get<ResponseReserTime>("/reserTime/" + info.shop_cd.ToString());


            if (req.code.Equals("00"))
            {
                foreach (var item in req.data)
                {
                    if (item.dayGbn == "1")
                    {
                        item.dayGbn = "8";
                    }
                    if (item.reserTime != null)
                    {
                        foreach (var subitem in item.reserTime)
                        {
                            var splitStr = subitem.time.Substring(0, 2) + ":" + subitem.time.Substring(2);
                            subitem.time = splitStr;
                        }
                    }
                }


                return View(req.data.OrderBy(x => Convert.ToInt32(x.dayGbn)).ToList());
            }
            else
            {
                return View();
            }
        }
        [HttpPost]
        public async Task<IActionResult> AvailableSetTime(ReserTiemViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var succeessType = 0;

            if(model.listY != null)
            {
                var result = new RequestReserTime();

                result.reserTimePostUnits = new List<ReserTimeItem>();

                foreach (var item in model.listY)
                {
                    var resultSub = new ReserTimeItem()
                    {
                        dayGbn = item.gbn,
                        time = item.time.Replace(":", "")
                    };
                    result.reserTimePostUnits.Add(resultSub);
                }
                result.shopCode = info.shop_cd.ToString();
                result.userId = info.login_name.ToString();
                var req = await reservationService.Post<dynamic, RequestReserTime>("/reserTime/", result);

                if (req.code.Equals("00"))
                {
                    succeessType++;
                }
            }

            if(model.listN != null)
            {
                var result = new RequestReserTime();

                result.reserTimePostUnits = new List<ReserTimeItem>();

                foreach (var item in model.listN)
                {
                    var resultSub = new ReserTimeItem()
                    {
                        dayGbn = item.gbn,
                        time = item.time.Replace(":", "")
                    };
                    result.reserTimePostUnits.Add(resultSub);
                }
                result.shopCode = info.shop_cd.ToString();
                result.userId = info.login_name.ToString();

                var req = await reservationService.Post<dynamic, RequestReserTime>("/reserTime/cancel/", result);

                if (req.code.Equals("00"))
                {
                    succeessType++;
                }
            }

            if(succeessType > 0)
            {
                return Ok(new
                {
                    code = "00",
                    Msg = "성공"
                });
            }
            else
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "실패"
                });
            }
        }
        public async Task<IActionResult> AvailableTimeModal()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            return PartialView("SetTime");
        }
        #endregion
        #region 시간당 최대 인원
        public async Task<IActionResult> HourlyMaxPeople()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var argument = new Dictionary<string, string>()
            {
                { "shopCode", info.shop_cd.ToString() }
            };

            var query = QueryHelpers.AddQueryString("/casesPeople", argument);

            var req = await reservationService.Get<RequestHourlyMaxPeople>(query);

            if (req.code.Equals("00"))
            {
                return View(req.data.SingleOrDefault());
            }

            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> HourlyMaxPeople(RequestHourlyMaxPeople model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var req = await reservationService.Put<dynamic, RequestHourlyMaxPeople>("/casesPeople", new RequestHourlyMaxPeople
            {
                shopCd = info.shop_cd.ToString(),
                casesCnt = model.casesCnt,
                ccCode = info.cccode,
                peopleCnt = model.peopleCnt,
                userId = info.login_name
            });

            if (req.code.Equals("00"))
            {
                return RedirectToAction("index");
            }
            ModelState.AddModelError("", req.msg);
            return View(model);
        }
        #endregion
        #region method
        public string GetNameDay(string dayGbn)
        {
            switch (dayGbn)
            {
                case "매일":
                    return "0";
                case "일요일":
                    return "1";
                case "월요일":
                    return "2";
                case "화요일":
                    return "3";
                case "수요일":
                    return "4";
                case "목요일":
                    return "5";
                case "금요일":
                    return "6";
                case "토요일":
                    return "7";
            }
            return "";
        }

        public async Task<List<SelectListItem>> GetWeekList()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            List<SelectListItem> temp = new List<SelectListItem>();
            var query = QueryHelpers.AddQueryString("items-list", new Dictionary<string, string>()
            {
                { "item", "0005"}
            });

            var req = await reservationService.Get<reservationDayOffItem>(query);


            if (req.code.Equals("00"))
            {
                for (var i = 0; i < req.data.Count(); i++)
                {
                    temp.Add(new SelectListItem()
                    {
                        Selected = (req.data[i].useGbn == "Y" ? true : false),
                        Text = req.data[i].nameMain,
                        Value = req.data[i].code
                    });
                }
            }
            return temp;
        }
        #endregion
    }
}
