﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.Admin.Request;
using PosWebApp.Models.Admin.Response;
using PosWebApp.Models.ChangeRequest.Request;
using PosWebApp.Models.Common;
using PosWebApp.Models.Images;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Admin;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels;
using PosWebApp.ViewModels.ChangeRequestHistory.Menu;
using PosWebApp.ViewModels.Menu;
using PosWebApp.ViewModels.Pos;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class MenuController : Controller
    {
        private readonly IDaeguDatabase db;
        private readonly DgShopApiService dgShop;
        private readonly AdminApi adminApi;
        private readonly IUploadImage uploadImage;
        private readonly string imageUrl;
        private readonly NLog.Logger nlogger;
        private readonly string singleOrderCheck;
        public MenuController(IConfiguration configuration, DgShopApiService api, IUploadImage _uploadImage, AdminApi _adminApi)
        {
            dgShop = api;
            adminApi = _adminApi;
            uploadImage = _uploadImage;
            var menuImgPath = configuration.GetValue<string>("upload:menuPath");
            var domain = configuration.GetValue<string>("upload:appDomain");
            imageUrl = string.Concat(domain, menuImgPath);
            nlogger = NLog.LogManager.GetCurrentClassLogger();

            singleOrderCheck = configuration.GetValue<string>("inspection:SingleOrderFlag");
        }
        #region 메뉴그룹
        [HttpGet]
        public IActionResult GroupInsert(string id = null)
        {
            if (!string.IsNullOrEmpty(id))
            {
                MenuGroupViewModel modelbinding = new MenuGroupViewModel()
                {
                    sort_seq = Convert.ToInt32(id)
                };

                return View(modelbinding);
            }
            return View();
        }
        /// <summary>
        /// 그룹 추가
        /// </summary>
        /// <param name="viewModel"></param> 
        /// <returns></returns>
        [HttpPost]
        [PreventDuplicateRequestAttribute]
        public async Task<IActionResult> GroupInsert(MenuGroupViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (viewModel.group_name == null)
            {
                ModelState.AddModelError("", "그룹 이름을 적어주세요!");
                return View();
            }

            RequestSetMenuGroup insertModel = new RequestSetMenuGroup()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                mcode = info.mcode,
                job_gbn = "I",
                group_name = viewModel.group_name,
                group_memo = viewModel.group_memo,
                use_yn = viewModel.use_yn,
                sort_seq = viewModel.sort_seq,
                mod_name = info.login_name
            };


            Result<dynamic> result = await dgShop.Post<dynamic, RequestSetMenuGroup>("SetMenuGroup", insertModel);

            if (result.code == "00")
            {
                return RedirectToAction("GetGroupSelect");
            }
            else
            {
                ModelState.AddModelError("", "등록되지않았습니다.");
            }

            return View();
        }
        /// <summary>
        /// 그룹 수정
        /// </summary>
        /// <param name="length"></param>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> GroupUpdate(string length = null, MenuGroupViewModel viewModel = null)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (!string.IsNullOrEmpty(length))
            {
                Int32.TryParse(info.group_id, out int groupId);
                Int32.TryParse(length, out int groupCODE);
                RequestMenuDetail selectModel = new RequestMenuDetail()
                {
                    cccode = info.cccode,
                    group_cd = groupCODE,
                    mcode = info.mcode,
                    shop_cd = info.shop_cd
                };
                Result<dynamic> temp = await dgShop.Post<dynamic, RequestMenuDetail>("MenuGroupDetail", selectModel);

                if (temp.code == "00")
                {
                    MenuGroupViewModel updateModel = new MenuGroupViewModel()
                    {
                        group_cd = temp.data[0].menu_group_cd,
                        group_file_name = temp.data[0].group_file_name,
                        group_memo = temp.data[0].menu_group_memo,
                        main_img_yn = temp.data[0].main_img_yn,
                        option_yn = temp.data[0].option_yn,
                        group_name = temp.data[0].menu_group_name,
                        use_yn = temp.data[0].use_yn,
                        sort_seq = temp.data[0].sort_seq
                    };

                    return PartialView("GroupUpdate", updateModel);
                }

                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                return PartialView("GroupUpdate", viewModel);
            }

            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> GroupUpdate(MenuGroupViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return View(viewModel);
            }
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            Int32.TryParse(viewModel.group_cd, out int groupCd);
            RequestSetMenuGroup UpdateModel = new RequestSetMenuGroup()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                mcode = info.mcode,
                job_gbn = "U",
                group_cd = groupCd, //?
                group_name = viewModel.group_name,
                group_memo = viewModel.group_memo,
                use_yn = viewModel.use_yn,
                option_yn = viewModel.option_yn,
                group_file_name = viewModel.group_file_name,
                sort_seq = viewModel.sort_seq,
                main_img_yn = viewModel.main_img_yn,
                mod_name = info.login_name
            };

            Result<dynamic> result = await dgShop.Post<dynamic, RequestSetMenuGroup>("SetMenuGroup", UpdateModel);

            if (result.code == "00")
            {
                return RedirectToAction("GetGroupSelect", "Menu");
            }

            return View();
        }

        /// <summary>
        /// 그룹조회
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> GetGroupSelect()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestMenuGroupList selectModel = new RequestMenuGroupList()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
            };
            //var result = await dgShop.Post<ApiModels.Menu.Response.ResponseMenuGroup, ApiModels.RequestCommon>
            //    ("/api/MenuGroupManagement/MenuGroupList", new ApiModels.RequestCommon
            //    {
            //        shop_cd = info.shop_cd
            //    });

            Result<ShopMenuGroup> result = await dgShop.Post<ShopMenuGroup, RequestMenuGroupList>("MenuGroupList", selectModel);

            if (result.code == "00")
            {
                if (result.data.Count() == 0)
                {
                    ViewBag.Message = "메뉴 그룹을 설정하시거나 메뉴 그룹을 추가 해주세요";
                    return View();
                }
                return View(result.data);
            }

            return View();
        }
        #endregion

        #region 메뉴정보

        public async Task<IActionResult> MenuInquiry(string id = null)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestMenuGroupList selectedModel = new RequestMenuGroupList()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
            };
            Result<ShopMenuGroup> result = await dgShop.Post<ShopMenuGroup, RequestMenuGroupList>("MenuGroupList", selectedModel);
            if (result.code == "00")
            {
                List<MenuGroupList> menuGroup = new List<MenuGroupList>();
                foreach (var select in result.data)
                {
                    menuGroup.Add(new MenuGroupList() { group_cd = select.menu_group_cd, menu_group_name = select.menu_group_name });
                }
                ViewBag.selectItem = new SelectList(menuGroup, "group_cd", "menu_group_name", id);

                return View();
            }
            return NotFound();

        }
        [HttpPost]
        public async Task<IActionResult> MenuSelected(MenuGroupList selected)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //ViewData["MenuUrl"] = string.Concat(imageUrl, info.cccode, '/', info.shop_cd);

            ViewData["MenuUrl"] = string.Concat("image/thumb?div=P&cccode=", info.cccode, "&shop_cd=", info.shop_cd);

            if (selected.group_cd != null)
            {
                RequestMenuList menuList = new RequestMenuList()
                {
                    shop_cd = info.shop_cd,
                    cccode = info.cccode,
                    group_cd = selected.group_cd,
                    use_yn = "%",
                    job_gbn = "3"
                };

                Result<SHOP_MENU> temp = await dgShop.Post<SHOP_MENU, RequestMenuList>("MenuList", menuList);

                if (temp.code == "00")
                {
                    ViewBag.group_cd = selected.group_cd;
                    return View(temp.data);
                }
                return View(temp.data);
            }
            else if (selected.group_cd == null)
            {
                return BadRequest(new
                {
                    code = "400",
                    Msg = "등록되지않는 메뉴그룹입니다. \n 메뉴그룹 등록 후 이용해주세요."
                });
            }

            return NotFound();

        }
        public async Task<IActionResult> Modify(int id, int m)
        {
            if (id > 0)
            {
                string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
                ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
                info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

                RequestMenuDetail selectModel = new RequestMenuDetail()
                {
                    cccode = info.cccode,
                    group_cd = id,
                    job_gbn = "3",
                    shop_cd = info.shop_cd,
                    menu_cd = m,
                };

                Result<ShopMenuDetail> temp = await dgShop.Post<ShopMenuDetail, RequestMenuDetail>("MenuDetail", selectModel);

                if (temp.code == "00")
                {
                    //return View(temp.data.SingleOrDefault());

                    return PartialView("Modify", temp.data.SingleOrDefault());
                }
                return View(temp.data);
            }
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Modify(ShopMenuDetail shopModel)
        {

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            if (shopModel.menu_name == null)
            {
                ModelState.AddModelError("", "메뉴 이름을 등록해주세요");
                return PartialView("Modify", shopModel);
            }
            if (!ModelState.IsValid)
            {
                return View();
            }
            UploadFile fileInfo = new UploadFile();
            fileInfo.FormFile = shopModel.formFile;

            if (fileInfo.FormFile != null)
            {
                var uploadResult = await uploadImage.Upload(fileInfo, info, nameof(UploadType.MENU));
                if (!uploadResult.code.Equals("00"))
                {
                    Debug.WriteLine("파일 업로드 실패 : " + uploadResult.message);
                    return View();
                }
                shopModel.file_name = uploadResult.url;
            }

            RequestSetMenuList ModifyModel = new RequestSetMenuList()
            {
                cccode = info.cccode,
                mcode = info.mcode,
                shop_cd = info.shop_cd,
                mod_name = info.login_name,
                job_gbn = "U"
            };

            ModifyModel.group_cd = shopModel.menu_group_cd;
            ModifyModel.file_name = shopModel.file_name;
            ModifyModel.menu_alone_order = shopModel.alone_order;
            ModifyModel.menu_cd = shopModel.menu_cd;
            ModifyModel.menu_cost = shopModel.menu_cost;
            ModifyModel.menu_name = shopModel.menu_name;
            ModifyModel.menu_main_yn = shopModel.main_yn;
            ModifyModel.menu_search_tag = shopModel.search_tag;
            ModifyModel.use_yn = shopModel.use_gbn;
            ModifyModel.sort_seq = Convert.ToInt32(shopModel.sort_seq);
            ModifyModel.m_menu_type = shopModel.menu_type;


            Result<dynamic> temp = await dgShop.Post<dynamic, RequestSetMenuList>("SetMenuList", ModifyModel);

            if (temp.code == "00")
            {
                return PartialView("Modify", shopModel);
            }
            else
            {
                ModelState.AddModelError("", "메뉴 수정에 실패했습니다.");
                return PartialView("Modify", shopModel);
            }
        }
        [HttpPost]
        public async Task<IActionResult> SoldOut(string menu_cd, string yn)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (menu_cd == null | yn == null)
            {
                return BadRequest();
            }

            RequestMenuSoldOut soldOutModel = new RequestMenuSoldOut()
            {
                cccode = info.cccode,
                menu_cd = menu_cd,
                job_gbn = "U",
                shop_cd = info.shop_cd,
                mcode = info.mcode,
                soldout = yn,
            };

            var req = await dgShop.Post<ResponseMenuSoldout, RequestMenuSoldOut>("SetMenuSoldout", soldOutModel);

            if (req.code == "00")
            {
                return Ok();
            }
            else if (req.code != "00")
            {
                return BadRequest(new
                {
                    code = "400",
                    msg = "서버에 요청하였으나 실패하였습니다."
                }); ; ;
            }

            return NotFound();

        }
        public IActionResult MenuInsert(int id, int count)
        {
            if (id > 0 && count > 0)
            {
                var temp = new SHOP_MENU();

                temp.menu_group_cd = id.ToString();
                temp.sort_seq = count;

                return PartialView("menuInsert", temp);
            }
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> MenuInsert(SHOP_MENU shopInfo)
        {

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            if (shopInfo.menu_name == null)
            {
                ModelState.AddModelError("", "메뉴 이름을 등록해주세요");
                return PartialView("menuInsert", shopInfo);
            }

            if (!ModelState.IsValid)
            {
                return View();
            }
            UploadFile fileInfo = new UploadFile();
            fileInfo.FormFile = shopInfo.formFile;

            if (fileInfo.FormFile != null)
            {
                var uploadResult = await uploadImage.Upload(fileInfo, info, nameof(UploadType.MENU));
                if (!uploadResult.code.Equals("00"))
                {
                    Debug.WriteLine("파일 업로드 실패 : " + uploadResult.message);
                    return View();
                }
                shopInfo.file_name = uploadResult.url;
            }

            //shopInfo.file_name = uploadResult.url;

            RequestSetMenuList insertModel = new RequestSetMenuList()
            {
                cccode = info.cccode,
                mcode = info.mcode,
                shop_cd = info.shop_cd,
                mod_name = info.login_name,

                group_cd = shopInfo.menu_group_cd,
                file_name = shopInfo.file_name,
                job_gbn = "I",
                menu_alone_order = shopInfo.alone_order,

                menu_cd = shopInfo.menu_cd,
                menu_cost = shopInfo.menu_cost,
                menu_main_yn = shopInfo.main_yn,
                menu_name = shopInfo.menu_name,
                menu_desc = shopInfo.menu_desc,
                menu_sname = shopInfo.menu_sname,
                use_yn = shopInfo.use_gbn,
                menu_search_tag = shopInfo.search_tag,
                m_menu_type = shopInfo.menu_type,
                sort_seq = Convert.ToInt32(shopInfo.sort_seq),

            };

            Result<dynamic> temp = await dgShop.Post<dynamic, RequestSetMenuList>("SetMenuList", insertModel);

            if (temp.code == "00")
            {
                return PartialView("menuInsert", shopInfo);
            }
            ModelState.AddModelError("", "메뉴등록에 실패하였습니다. 다시작성해주세요.");
            return PartialView("menuInsert", shopInfo);
            //return RedirectToAction("MenuInquiry", "Menu", new { id = shopInfo.menu_group_cd });
        }
        public async Task<IActionResult> MenuSortable(string id)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestMenuList menuList = new RequestMenuList()
            {
                shop_cd = info.shop_cd,
                cccode = info.cccode,
                group_cd = id,
                use_yn = "%",
                job_gbn = "3"
            };

            Result<SHOP_MENU> temp = await dgShop.Post<SHOP_MENU, RequestMenuList>("MenuList", menuList);

            if (temp.code == "00")
            {
                ViewBag.group_cd = id;
                return View(temp.data);
            }
            return View(temp.data);
        }
        #endregion

        #region ViewComponent - MenuListFilter
        public IActionResult MenuListFilter(MenuGroupList selected)
        {
            if (selected.group_cd != null)
            {
                return ViewComponent("MenuList", selected.group_cd);
            }
            else
            {
                return BadRequest(new
                {
                    code = "400",
                    Msg = "등록되지않는 메뉴그룹입니다. \n 메뉴그룹 등록 후 이용해주세요."
                });
            }
        }
        [HttpPost]
        public IActionResult DesignList(PosWebApp.ApiModels.Menu.Request.RequestMenuList selected)
        {
            if (selected.group_cd == null && selected.searchName != null)
            {
                return ViewComponent("DesignList", selected);
            }
            if (selected.group_cd != null)
            {
                return ViewComponent("DesignList", selected);
            }
            else
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "등록되지않는 메뉴그룹입니다. \n 메뉴그룹 등록 후 이용해주세요."
                });
            }
        }
        #endregion
        #region ajax -  Sortconnection
        [HttpPost]
        public IActionResult SortList(string div, string[] idx)
        {
            if (idx == null)
            {
                return BadRequest(new
                {
                    code = "400",
                    Msg = "값이 존재하지않습니다. 새로고침후 이용해주세요."
                });
            }
            if (idx.Count() > 1)
            {
                string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
                ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
                info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
                RequestSortItem requestList = new RequestSortItem()
                {
                    job_gbn = div,
                    shop_cd = info.shop_cd,
                    u_code = info.u_code,
                    login_code = info.login_code.ToString(),
                    login_name = info.login_name,
                    item_codes = new List<int>()
                };

                for (int i = 0; i < idx.Count(); i++)
                {
                    requestList.item_codes.Add(Convert.ToInt32(idx[i]));
                }

                var req = dgShop.Post<CodeMsg, RequestSortItem>("SortList", requestList);

                if (req.Result.code == "00")
                {
                    return Ok(new
                    {
                        code = "200",
                        Msg = "정상처리완료"
                    });
                }
                else
                {
                    return BadRequest(new
                    {
                        code = "400",
                        Msg = "처리중 알수없는 에러로인한 등록에 실패하였습니다."
                    });
                }
            }
            return NotFound();
        }
        #endregion

        #region Admin - Menu

        public IActionResult List(MenuGroupList selected)
        {
            if (selected.group_cd != null)
            {
                return ViewComponent("List", selected.group_cd);
            }
            else
            {
                return BadRequest(new
                {
                    code = "400",
                    Msg = "등록되지않는 메뉴그룹입니다. \n 메뉴그룹 등록 후 이용해주세요."
                });
            }
        }
        public async Task<IActionResult> Info(string idx)
        {
            if (idx == null)
            {
                return BadRequest(new
                {
                    code = "400",
                    Msg = "값이 존재하지않습니다. 새로고침후 이용해주세요."
                });
            }
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //var req = await adminApi.GetSingle<ResponseMenuInfo>("Menu" + "/" + idx);


            var req = await dgShop.PostSingle<ApiModels.Menu.Response.ResponseMenuInfo, ApiModels.Menu.Request.RequestMenuInfo>
                ("/api/MenuManagement/MenuDetails", new ApiModels.Menu.Request.RequestMenuInfo
                {
                    shop_cd = info.shop_cd,
                    menuCd = idx
                });

            // BlackDay
            var blackDay = await dgShop.Post<dynamic, Models.RequestModel.Request>("/api/ShopManagement/GetBlackDayCheck", new Models.RequestModel.Request
            {
                shop_cd = info.shop_cd
            });
            ViewBag.blackDayCode = (blackDay.code != null ? blackDay.code : "99");
            if (req.code == "00")
            {
                ShopMenuInfo temp = new ShopMenuInfo()
                {
                    aloneOrder  = req.data.aloneOrder.Equals("Y") ? true : false,
                    mainYn      = req.data.mainYn.Equals("Y") ? true : false,
                    menuCd      = req.data.menuCd,
                    menuCost    = req.data.menuCost,
                    menuDesc    = req.data.menuDesc,
                    menuGroupCd = req.data.menuGroupCd,
                    menuName    = req.data.menuName.TrimStart().TrimEnd(),
                    useYn       = req.data.useYn,
                    noFlag      = req.data.noFlag,
                    adultOnly   = req.data.adultOnly,
                    singleOrderYn = req.data.singleOrderYn,
                };
                return PartialView("Info", temp);
            }
            return BadRequest();
        }
        public IActionResult Detail(ResponseMenuInfo model)
        {
            return PartialView("Detail", model);
        }
        public async Task<IActionResult> Add(string idx = null)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo sessionInfo = new ShopSessionDefaultInfo();
            sessionInfo = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(idx))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "새로고침후 다시 이용해주세요."
                });
            }
            // BlackDay
            var blackDay = await dgShop.Post<dynamic, Models.RequestModel.Request>("/api/ShopManagement/GetBlackDayCheck", new Models.RequestModel.Request
            {
                shop_cd = sessionInfo.shop_cd
            });

            ViewBag.blackDayCode = (blackDay.code != null ? blackDay.code : "99");

            PosWebApp.ApiModels.Menu.Request.RequestMenuInfo info = new PosWebApp.ApiModels.Menu.Request.RequestMenuInfo()
            {
                groupCd = idx,
                adultOnly = "N"
            };

            ViewBag.singleOrderCheck = singleOrderCheck;
            return PartialView("Add", info);
        }
        public async Task<IActionResult> ServiceHistory(string idx = null, string item = null, string name = null)
        {
            if (string.IsNullOrEmpty(idx) || string.IsNullOrEmpty(item) || string.IsNullOrEmpty(name))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "새로고침후 다시 이용해주세요."
                });
            }
            var menuRequest = await adminApi.GetSingle<ResponseMenuInfo>(string.Join('/', "Menu", item));
            SetMenuIns info = new SetMenuIns()
            {
                groupCd = menuRequest.data.menuGroupCd,
                menuCd = menuRequest.data.menuCd,
                menuName = menuRequest.data.menuName,
                imageName = name
            };
            return PartialView("ServiceRequest", info);
        }
        [HttpPost]
        public async Task<IActionResult> ServiceHistory(RequestMenuDel info)
        {

            RequestMenuDel modelInfo = info;
            ModelState.AddModelError("", "저장중 오류가 발생했습니다. 새로고침후 다시이용해주세요");
            return PartialView("ServiceRequest", modelInfo);
        }
        [HttpPost]
        public async Task<IActionResult> Add(PosWebApp.ApiModels.Menu.Request.RequestMenuInfo infoModel)
        {
            if (string.IsNullOrEmpty(infoModel.menuName))
            {
                ModelState.AddModelError("", "메뉴 이름을 등록해주세요");
                return PartialView("Add", infoModel);
            }
            if (string.IsNullOrEmpty(infoModel.menuCost))
            {
                ModelState.AddModelError("", "금액을 설정해주세요");
                return PartialView("Add", infoModel);
            }
            var menuMoney = Convert.ToInt32(infoModel.menuCost.Replace(",", ""));
            

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if (info.shop_cd != 13960)
            { 
                if (menuMoney >= 500000)
                {
                    ModelState.AddModelError("", "메뉴 금액은 50만원 이상 설정하실수 없습니다.");
                    return PartialView("Add", infoModel);
                }
            }

            Utils utils = new Utils();
            PosWebApp.ApiModels.Menu.Request.RequestMenuInfo AddModel = new PosWebApp.ApiModels.Menu.Request.RequestMenuInfo()
            {
                aloneOrder = infoModel.aloneOrder.Equals("true") ? "Y" : "N",
                insertName = info.login_name,
                mainYn = infoModel.mainYn.Equals("true") ? "Y" : "N",
                menuCost = infoModel.menuCost.Replace(",", ""),
                menuDesc = infoModel.menuDesc == null ? null : infoModel.menuDesc.TrimStart().TrimEnd(),
                menuName = infoModel.menuName.TrimStart().TrimEnd(),
                useYn = infoModel.useYn,
                groupCd = infoModel.groupCd,
                shop_cd = info.shop_cd,
                noFlag = infoModel.noFlag,
                adultOnly = infoModel.adultOnly,
                singleOrderYn = infoModel.singleOrderYn
            };

            if (!utils.Money10wonCheck(AddModel.menuCost))
            {
                ModelState.AddModelError("", "메뉴 금액은 10원 단위 이상으로 설정 가능합니다.");
                return PartialView("Add", infoModel);
            }
            // BlackDay
            var blackDay = await dgShop.Post<dynamic, Models.RequestModel.Request>("/api/ShopManagement/GetBlackDayCheck", new Models.RequestModel.Request
            {
                shop_cd = info.shop_cd
            });

            ViewBag.blackDayCode = (blackDay.code != null ? blackDay.code : "99");
            //var req = await adminApi.Post<dynamic, RequestMenuInfo>("Menu", AddModel);
            var req = await dgShop.Post<PosWebApp.ApiModels.Menu.Response.ResponseMenuInfo, PosWebApp.ApiModels.Menu.Request.RequestMenuInfo>
                ("/api/MenuManagement/MenuAdd", AddModel);

            if(req.code == "88")
            {
                var bodyContent = JsonConvert.SerializeObject(AddModel);
                nlogger.Info($"[ CEO Menu kindShopError ,Shopcd === {info.shop_cd} json = {bodyContent} ]");
                ViewBag.kindErrorCode = req.code;
                ViewBag.KindErrorMenuAdd = req.msg;
                ModelState.AddModelError("", req.msg);
                return PartialView("Add", infoModel);
            }

            if (req.code == "00")
            {
                var bodyContent = JsonConvert.SerializeObject(AddModel);
                nlogger.Info($"[ CEO Menu Success ,Shopcd === {info.shop_cd} json = {bodyContent} ]");
                return PartialView("Add", infoModel);
            }
            else
            {
                //var bodyContent = JsonConvert.SerializeObject(AddModel);
                //nlogger.Info($"[ CEO Menu Success ,Shopcd === {info.shop_cd} json = {bodyContent} ]");
                var bodyContent = JsonConvert.SerializeObject(AddModel);
                nlogger.Info($"[ CEO Menu MajorSetting Error ,Shopcd === {info.shop_cd} json = {bodyContent} ]");
                ModelState.AddModelError("", req.msg);
                return PartialView("Add", infoModel);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Update(ShopMenuInfo model)
        {
            if (model.menuName == null)
            {
                ModelState.AddModelError("", "메뉴 이름을 등록해주세요");
                return PartialView("Info", model);
            }

            var menuMoney = Convert.ToInt32(model.menuCost.Replace(",", ""));

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            if (info.shop_cd != 13960)
            {
                if (menuMoney >= 500000)
                {
                    ModelState.AddModelError("", "메뉴 금액은 50만원 이상 설정하실수 없습니다.");
                    return PartialView("Info", model);
                }
            }


            Utils utils = new Utils();
            PosWebApp.ApiModels.Menu.Request.RequestMenuInfo infoModel = new PosWebApp.ApiModels.Menu.Request.RequestMenuInfo()
            {
                aloneOrder = model.aloneOrder ? "Y" : "N",
                insertName = info.login_name,
                mainYn = model.mainYn ? "Y" : "N",
                menuCd = model.menuCd,
                menuCost = model.menuCost.Replace(",", ""),
                menuDesc = model.menuDesc == null ? null : model.menuDesc.TrimStart().TrimEnd(),
                menuName = model.menuName.TrimStart().TrimEnd(),
                useYn = model.useYn,
                noFlag = model.noFlag,
                adultOnly = model.adultOnly,
                shop_cd = info.shop_cd,
                singleOrderYn = model.singleOrderYn
            };

            if (!utils.Money10wonCheck(infoModel.menuCost))
            {
                ModelState.AddModelError("", "메뉴 금액은 10원 단위 이상으로 설정 가능합니다.");
                return PartialView("Info", model);
            }


            // BlackDay
            var blackDay = await dgShop.Post<dynamic, Models.RequestModel.Request>("/api/ShopManagement/GetBlackDayCheck", new Models.RequestModel.Request
            {
                shop_cd = info.shop_cd
            });

             ViewBag.blackDayCode = (blackDay.code != null ? blackDay.code : "99");

            // var req = await adminApi.Put<dynamic, RequestMenuInfo>("Menu", infoModel);
            //var req = await dgShop.Post<PosWebApp.ApiModels.Menu.Response.ResponseMenuInfo, PosWebApp.ApiModels.Menu.Request.RequestMenuInfo>("/api/MenuManagement/MenuUpdate", infoModel);
            var req = await dgShop.Post<PosWebApp.ApiModels.Menu.Response.ResponseMenuInfo, PosWebApp.ApiModels.Menu.Request.RequestMenuInfo>
                ("/api/MenuManagement/MenuUpdate", infoModel);


            if (req.code == "00")
            {
                var bodyContent = JsonConvert.SerializeObject(infoModel);
                nlogger.Info($"[ CEO Menu Success ,Shopcd === {info.shop_cd} json = {bodyContent} ]");
                return PartialView("Info", model);
            }
            if( req.code == "90")
            {
                var bodyContent = JsonConvert.SerializeObject(infoModel);
                nlogger.Info($"[ CEO Menu LiveEvent Error ,Shopcd === {info.shop_cd} json = {bodyContent} ]");
                ModelState.AddModelError("", "라이브 이벤트 중 수정 불가능합니다.");
                return PartialView("Info", model);
            }
            if (req.code == "99")
            {
                var bodyContent = JsonConvert.SerializeObject(infoModel);
                nlogger.Info($"[ CEO Menu MajorSetting Error ,Shopcd === {info.shop_cd} json = {bodyContent} ]");
                ModelState.AddModelError("", req.msg);
                return PartialView("Info", model);
            }

            if (req.code == "88")
            {
                var bodyContent = JsonConvert.SerializeObject(infoModel);
                nlogger.Info($"[ CEO Menu kindShopError ,Shopcd === {info.shop_cd} json = {bodyContent} ]");
                ViewBag.kindErrorCode = req.code;
                ViewBag.KindErrorMenuUpdate = req.msg;
                ModelState.AddModelError("", req.msg);
                return PartialView("Info", model);
            }

            ModelState.AddModelError("", "저장중 오류가 발생했습니다. 새로고침후 다시이용해주세요");
            return PartialView("Info", model);
        }
        [HttpPost]
        public async Task<IActionResult> ImageUpload(RequestMenuImage model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            if (string.IsNullOrEmpty(model.menu_cd))
            {
                ModelState.AddModelError("", "메뉴 이름을 등록해주세요");
                return PartialView("Info", model);
            }
            model.cccode = info.cccode;
            model.shop_cd = info.shop_cd;
            var imageReq = await adminApi.PutImage<dynamic, RequestMenuImage>("Image", model);

            if (imageReq.code == "00")
            {
                return Ok();
            }
            ModelState.AddModelError("", "저장중 오류가 발생했습니다. 새로고침후 다시이용해주세요");
            return Ok();
        }
        #endregion
    }
}
