﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.Reservation.Picture;
using PosWebApp.Models.Reservation.Picture.Request;
using PosWebApp.Models.Reservation.Picture.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Reservation;
using PosWebApp.ViewModels.Reservation.Picture;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UAParser;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ReservationPicture : Controller
    {
        private readonly ReservationService_T reservation;
        public ReservationPicture(ReservationService_T reservation)
        {
            this.reservation = reservation;
        }
        public async Task<IActionResult> InitImage(ReservaionPictureInit Model, int? pageNumber)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (pageNumber == null)
            {
                pageNumber = 1;
            }

            int pageSize = 10;
            var browser = HttpContext.Request.Headers["User-Agent"].ToString();
            var uaParser = Parser.GetDefault();
            ClientInfo c = uaParser.Parse(browser);

            string device = c.UA.Family;

            if (device.IndexOf("Mobile") > -1)
            {
                pageSize = 5;
            }
            var temaList = await TemaGroupSearch();
            var temaCode = "";
            if (!string.IsNullOrEmpty(Model.temaName))
                temaCode = temaList.Where(x => x.Text.Equals(Model.temaName)).ToList().SingleOrDefault().Value;
            else
                temaCode = "";



            var Query = QueryHelpers.AddQueryString("/ShopPicture/" + info.shop_cd, new Dictionary<string, string>()
            {
                {"temaCode" , string.IsNullOrEmpty(temaCode) ? "" : temaCode.Trim() },
                {"page", pageNumber.ToString() },
                {"pageRows", "10" }
            });


            var response = await reservation.GetSingle<ResponseShopPictureList>(Query);

            ViewBag.selected = string.IsNullOrEmpty(Model.temaName) ? "" : Model.temaName.Trim();

            if (response.code.Equals("00"))
            {
                ReservationShopPictrueViewModel result = new ReservationShopPictrueViewModel();
                result.items = new List<PictureRows>();
                List<PictureRows> row = new List<PictureRows>();


                foreach (var temp in response.data.items)
                {
                    PictureRows pictureRows = new PictureRows()
                    {
                        exposureGbn = temp.exposureGbn == "Y" ? true : false,
                        fileName = temp.fileName,
                        fileUrl = temp.fileUrl,
                        noticeName = temp.noticeName,
                        seq = temp.seq,
                        sortSeq = temp.sortSeq,
                        temaName = temp.temaName
                    };

                    row.Add(pictureRows);
                }

                ViewBag.type = new SelectList(await TemaGroupSearch(), "Value", "Text", "%");
                result.items = row;
                result.count = response.data.count;

                return View(result);
            }

            return View();
        }
        public IActionResult PictureFilter(string tema, int? pageNumber)
        {
            return ViewComponent("ReservationPicturePage", new
            {
                tema = tema,
                pageNumber = pageNumber
            });
        }
        public async Task<IActionResult> PictureUpdate(List<PictureRows> model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            RequestReservaionPictureUpdate result = new RequestReservaionPictureUpdate();
            result.pictureInfos = new List<Pictureinfo>();
            try
            {
                if (model == null || model.Count() == 0)
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "저장할 사진을 선택해주세요"
                    });
                }
                foreach (var items in model)
                {
                    Pictureinfo temp = new Pictureinfo
                    {
                        exposureGbn = items.exposureGbn == true ? "Y" : "N",
                        seq = items.seq,
                        sortSeq = items.sortSeq,
                        temaCode = items.temaCode
                    };
                    result.pictureInfos.Add(temp);
                }
                result.ccCode = info.cccode;
                result.shopCode = info.shop_cd.ToString();


                var request = await reservation.Post<dynamic, RequestReservaionPictureUpdate>("/shopPicture/update", result);

                if (request.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        Msg = "성공"
                    });
                }
                else
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "실패"
                    });
                }
            }
            catch (Exception)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "실패"
                });
            }

        }

        public async Task<IActionResult> PictureDelete(List<PictureRows> model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            RequestReservaionPictureUpdate result = new RequestReservaionPictureUpdate();
            result.pictureInfos = new List<Pictureinfo>();
            try
            {
                if (model == null || model.Count() == 0)
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "삭제할 사진을 선택해주세요"
                    });
                }
                foreach (var items in model)
                {
                    Pictureinfo temp = new Pictureinfo
                    {
                        seq = items.seq,
                    };
                    result.pictureInfos.Add(temp);
                }
                result.ccCode = info.cccode;
                result.shopCode = info.shop_cd.ToString();


                var request = await reservation.Delete<dynamic, RequestReservaionPictureUpdate>("shopPicture/delete", result);

                if (request.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        Msg = "성공"
                    });
                }
                else
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "실패"
                    });
                }
            }
            catch (Exception)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "실패"
                });
            }

        }
        public IActionResult PictureCreate()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ReservationPictureViewModel req = new ReservationPictureViewModel();

            return PartialView("PictureCreate", req);
        }
        [HttpPost]
        public async Task<IActionResult> shopPicture(ReservationPictureViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if(model.file == null)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "이미지 선택 후 이용바랍니다."
                });
            }


            RequestReservationShopPictrue result = new RequestReservationShopPictrue();
#pragma warning disable CA1416 // Validate platform compatibility
            Image image = Image.FromStream(model.file.OpenReadStream(), true, true);
            var newImage = new Bitmap(1280, 720);
            if (image.Width >= 1280)
#pragma warning restore CA1416 // Validate platform compatibility
            {

                using (var g = Graphics.FromImage(newImage))
                {
                    g.DrawImage(image, 0, 0, 1280, 720);
                }


                if (newImage != null)
                {
                    using (MemoryStream stream = new MemoryStream())
                    {
                        newImage.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
                        result.imagebinary = stream.ToArray();
                    }


                }
            }else
            {
                using(var g = Graphics.FromImage(image))
                {
                    g.DrawImage(image, 0, 0, image.Width, image.Height);
                }

                using ( var stream = new MemoryStream())
                {
                    image.Save(stream, image.RawFormat);
                    result.imagebinary = stream.ToArray();
                }
            }

            result.ccCode = info.cccode;
            result.shopCd = info.shop_cd.ToString();
            result.file = model.file;
            result.temaCode = model.temaCode;


            var response = await reservation.PutPicture<dynamic, RequestReservationShopPictrue>("shopPicture/insert", result);


            if (response.code.Equals("00"))
            {
                return PartialView("PictureCreate");
            }

            return PartialView("PictureCreate", model);
        }

        public async Task<List<SelectListItem>> TemaGroupSearch()
        {
            List<SelectListItem> temp = new List<SelectListItem>();

            var response = await reservation.Get<TemaGroupPicture>("/pictureGroups");

            if (response.code.Equals("00"))
            {
                foreach (var item in response.data)
                {
                    temp.Add(new SelectListItem()
                    {
                        Selected = true,
                        Text = item.temaName,
                        Value = item.temaCode
                    });
                }
            }

            return temp;
        }

        public async Task<IActionResult> PictrueSort(string[] idx)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var sortItem = new RequestReservationSort()
            {
                shopCode = info.shop_cd.ToString(),
                seq = idx
            };

            var req = await reservation.Post<dynamic, RequestReservationSort>("/shopPicture-sort", sortItem);


            if (req.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    msg = "성공"
                });
            }

            return Ok(new
            {
                code = "99",
                msg = "실패"
            });
        }
    }
}
