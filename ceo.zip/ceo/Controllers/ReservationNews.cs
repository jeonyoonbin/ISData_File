﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Models.Reservation.News.Request;
using PosWebApp.Models.Reservation.News.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Reservation;
using PosWebApp.ViewModels.Reservation.Condition;
using PosWebApp.ViewModels.Reservation.News;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UAParser;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ReservationNews : Controller
    {
        private readonly ReservationService_T reservation;
        public ReservationNews(ReservationService_T reservation)
        {
            this.reservation = reservation;
        }
        public async Task<IActionResult> Index(ReservationNewsViewModel model, string selectedType, int? pageNumber)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (pageNumber == null)
            {
                pageNumber = 1;
            }

            int pageSize = 10;
            var browser = HttpContext.Request.Headers["User-Agent"].ToString();
            var uaParser = Parser.GetDefault();
            ClientInfo c = uaParser.Parse(browser);

            string device = c.UA.Family;

            if (device.IndexOf("Mobile") > -1)
            {
                pageSize = 5;
            }
            ReservationNewsViewModel result = new ReservationNewsViewModel();

            if(model.choice != null)
                result.choice = model.choice;
            if (model.searchText != null)
                result.searchText = model.searchText;
            result.pageNum = pageNumber.ToString();

            var query = QueryHelpers.AddQueryString("/shopNews", new Dictionary<string, string>()
            {
                {"shopCd", info.shop_cd.ToString()},
                {"page", pageNumber.ToString() },
                {"rows", pageSize.ToString()}
            });
            if (string.IsNullOrEmpty(model.searchText))
            {
                query = query.Insert(query.Length, "&JobGbn=1");
            }
            else
            {
                query = query.Insert(query.Length, "&JobGbn=" + (model.choice == "subject" ? "1" : "2"));
                query = query.Insert(query.Length, "&searchInfo=" + model.searchText);
            }

            var req = await reservation.GetSingle<ResponseReservationList>(query);

            if (req.code.Equals("00"))
            {
                ViewBag.CountNumber = req.data.count;
            }

            return View(result);
        }
        public IActionResult PageFilter(ReservationNewsViewModel model, int? pageNumber) 
        {
            return ViewComponent("ReservationNewsList", new
            {
                model = model,
                pageNumber = pageNumber
            });
        }

        public async Task<IActionResult> News(string type, string seq = null)
        {
            RequestReservaionNews news = new RequestReservaionNews();

            switch (type)
            {
                case "1":
                    news.typeGbn = "insert";
                    ViewBag.Title = "매장 소식 등록";
                    ViewBag.SaveName = "등록";
                    break;
                case "2":
                    news.typeGbn = "modify";
                    news.seq = Convert.ToInt32(seq);
                    ViewBag.Title = "매장 소식 수정";
                    ViewBag.SaveName = "수정";
                    
                    var item = await GetNews(news);
                    var singleitems = item.data.SingleOrDefault();
                    news.contents = singleitems.contents;
                    news.title = singleitems.title;

                    break;
            }
            await Task.Delay(0);

            return PartialView("MakeNews", news);
        }
        [HttpPost]
        public async Task<IActionResult> intiNew(RequestReservaionNews model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            model.shopCd = info.shop_cd.ToString();

            if (model.typeGbn.Equals("insert"))
            {

                if(string.IsNullOrEmpty(model.title) || string.IsNullOrEmpty(model.contents))
                {
                    ModelState.AddModelError("", "등록에 실패했습니다" );
                    return PartialView("MakeNews", model);
                }
                model.useGbn = "Y";
                
                var req = await reservation.Post<dynamic, RequestReservationNewsV2>("/shopNews", new RequestReservationNewsV2()
                {
                    contents = model.contents,
                    shopCd = info.shop_cd.ToString(),
                    title = model.title,
                     useGbn = "Y"
                });

                if (req.code.Equals("00"))
                {
                    return PartialView("MakeNews", model);
                }
                else
                {
                    ModelState.AddModelError("", "등록에 실패했습니다" + req.msg);
                    return PartialView("MakeNews", model);
                }
            }
            else if (model.typeGbn.Equals("modify"))
            {
                model.useGbn = "Y";

                if (string.IsNullOrEmpty(model.title) || string.IsNullOrEmpty(model.contents))
                {
                    ModelState.AddModelError("", "등록에 실패했습니다");
                    return PartialView("MakeNews", model);
                }

                var req = await reservation.Put<dynamic, RequestReservaionNews>("/shopNews", model);

                if (req.code.Equals("00"))
                {
                    return PartialView("MakeNews", model);
                }
                else
                {
                    ModelState.AddModelError("", "등록에 실패했습니다" + req.msg);
                    return PartialView("MakeNews", model);
                }
            }
            else
            {
                ModelState.AddModelError("", "타입 구분자가 존재하지않습니다. 새로고침후 이용바랍니다.");
                return PartialView("MakeNews", model);
            }
        }

        public async Task<Result<ResponseNewsSingle>> GetNews(RequestReservaionNews news)
        {
            Result<ResponseNewsSingle> result = new Result<ResponseNewsSingle>();
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            try
            {
                var query = QueryHelpers.AddQueryString("/shopNews/" + news.seq, new Dictionary<string, string>()
                {
                    { "shopCd", info.shop_cd.ToString() }
                });

                var req = await reservation.Get<ResponseNewsSingle>(query);

                if (req.code.Equals("00"))
                {

                    return req;
                }
            }
            catch (Exception)
            {
                result.code = "99";
                result.msg = "조회결과가 존재하지않습니다.";
                return result;
            }

            return result;
        }
        public async Task<IActionResult> NewsDeleted(string seq)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if (string.IsNullOrEmpty(seq))
            {

                return Ok(new
                {
                    code = "99",
                    Msg = "번호가 존재하지않습니다. 새로고침후 이용바랍니다."
                }) ;
            }

            var req = await reservation.Delete<dynamic, RequestReservaionNews>("shopNews", new RequestReservaionNews()
            {
                shopCd = info.shop_cd.ToString(),
                seq = Convert.ToInt32(seq)
            }) ;

            if (req.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    Msg = "성공"
                });
            }
            else
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "실패"
                });
            }
        }
    }
}
