﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class DeliveryAreaTipController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly string localurl;
        private readonly string deliveryTipFlag;

        public DeliveryAreaTipController(DgShopApiService api, IConfiguration configuration)
        {
            dgShop = api;
            localurl = configuration.GetValue<string>("api:local");
            deliveryTipFlag = configuration.GetValue<string>("inspection:DeliveryTipFlag");
        }

        public async Task<IActionResult> Index()
        {

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var now = DateTime.Now;
            var EndTime = DateTime.ParseExact(deliveryTipFlag, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
            var diffTime = (EndTime - now).Hours;

            if (diffTime > 0)
            {
                ViewBag.diffTime = "Y";
            }
            else
            {
                ViewBag.diffTime = "N";
            }

            var result = await dgShop.Post<dynamic, ApiModels.RequestCommon>("/api/GeoMapManagement/GetShopGeoYN", new ApiModels.RequestCommon
            { 
                shop_cd = info.shop_cd,
                job_gbn = ""
            });

            if (result.code.Equals("00"))
            {
                ViewBag.GeoShopYn = result.data.SingleOrDefault();
            }

            return View();
        }
    }
}
