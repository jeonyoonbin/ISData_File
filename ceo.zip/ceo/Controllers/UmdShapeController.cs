﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.GeoFence;
using PosWebApp.Models.GIS;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.NaverGeoFence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UmdShapeController : ControllerBase
    {
        private readonly GeoFenceApi api;
        private readonly DawulService dawul;
        private readonly DgShopApiService dgShop;

        public UmdShapeController(GeoFenceApi api, DawulService dawul, DgShopApiService dgShop)
        {
            this.api = api;
            this.dawul = dawul;
            this.dgShop = dgShop;
        }

        /// <summary>
        /// 공용 테이블에 데이터 밀어 넣기
        /// </summary>
        /// <param name="sido"></param>
        /// <param name="sigungu"></param>
        /// <param name="umd"></param>
        /// <param name="ri"></param>
        /// <returns></returns>
        [HttpGet("Set")]
        public async Task<CodeMsg> SetCommonUmd(string sido, string sigungu, string umd, string ri = null)
        {
            NaverGISConverter result = await dawul.GetDawulUmdAsync(sido, sigungu, umd);

            List<List<double>> shapeData = new List<List<double>>();

            string lCode = string.Empty;

            if (result.Collection.GetType() == typeof(NaverFeatureCollection))
            {
                var temp = (NaverFeatureCollection)result.Collection;

                foreach (var features in temp.features)
                {
                    lCode = features.properties.lcode;
                    shapeData = features.geometry.coordinates[0];
                }
            }
            else if (result.Collection.GetType() == typeof(NaverFeatureCollectionMulti))
            {
                var temp = (NaverFeatureCollectionMulti)result.Collection;

                foreach (var features in temp.features)
                {
                    lCode = features.properties.lcode;
                    // 외곽만 사용
                    shapeData = features.geometry.coordinates[0][0];
                }
            }

            List<double> lonArray = new List<double>();
            List<double> latArray = new List<double>();
            foreach (var item in shapeData)
            {
                lonArray.Add(item[0]);
                latArray.Add(item[1]);
            }

            RequestSetCommonUmd requestData = new RequestSetCommonUmd()
            {
                hcode = lCode,
                sido = sido,
                sigungu = sigungu,
                umd = umd,
                lon_x = lonArray,
                lat_y = latArray
            };

            var response = await api.SetCommonUmd(requestData);

            if (response.IsSuccessStatusCode)
            {
                var responseString = await response.Content.ReadAsStringAsync();

                var responseData = JsonConvert.DeserializeObject<CodeMsg>(responseString);

                return responseData;
            }

            return null;
        }

        /// <summary>
        /// 공용 테이블 데이터 가져오기
        /// </summary>
        /// <param name="sido"></param>
        /// <param name="sigungu"></param>
        /// <param name="umd"></param>
        /// <param name="ri"></param>
        /// <returns></returns>
        [HttpGet("Get")]
        public async Task<Result<CommonStateUmd>> GetCommonUmd(string sido, string sigungu, string umd, string ri = null)
        {
            RequestSetCommonUmd requestData = new RequestSetCommonUmd()
            {
                sido = sido,
                sigungu = sigungu,
                umd = umd,
            };

            var response = await api.GetCommonUmd(requestData);

            if (response.IsSuccessStatusCode)
            {
                var responseString = await response.Content.ReadAsStringAsync();

                var responseData = JsonConvert.DeserializeObject<Result<CommonStateUmd>>(responseString);

                return responseData;
            }
            return null;
        }

        /// <summary>
        /// 공용 테이블에 형상 데이터 밀어 넣기.
        /// 전체 리스트를 조회 하기 위해서 가맹점 데이터를 임시로 넣어 둠
        /// 유입 된 가맹점의 배달지역이 모두 설정 되어 있어야 함.
        /// </summary>
        /// <param name="shopInfo"></param>
        /// <returns></returns>
        [HttpPost("SetAll")]
        public async Task<dynamic> SetCommonUmdAll(Request shopInfo)
        {
            /// 상점에서 읍면동 리스트를 가져온다.
            var temp = await dgShop.Post<ShopSector, Request>("GetShopSectorRaw", new Request
            {
                cccode = shopInfo.cccode,
                shop_cd = shopInfo.shop_cd
            });

            if (temp.code.Equals("00"))
            {
                foreach (var item in temp.data)
                {
                    var temp2 = await SetCommonUmd(item.sido, item.sigungu, item.umdr);

                    if (!temp2.code.Equals("00"))
                    {
                        return new
                        {
                            code = "99",
                            message = string.Format($"처리중 오류 발생. {item.sido} {item.sigungu} {item.umdr}")
                        };
                    }
                }

                return new
                {
                    code = "00",
                    message = "성공"
                };
            }
            else
            {
                return new
                {
                    code = "99",
                    message = temp.msg
                };
            }
        }

        /// <summary>
        /// 공용 테이블 형상 데이터를 선택 가맹점의 배달지역에 따라 복사
        /// 상점 최초 영역 설정 시 사용
        /// 초기화 관련해서는 사용자 영역을 남겨 둘지 정하기 바람.
        /// </summary>
        /// <param name="shopInfo"></param>
        /// <returns></returns>
        [HttpPost("SetCommonShape")]
        public async Task<dynamic> SetCommonUmdShapeToShop(Request shopInfo)
        {
            await Task.Delay(0);
            /// 상점에서 읍면동 리스트를 가져온다.
        //    var temp = await dgShop.Post<ShopSector, Request>("GetShopSectorRaw", new Request
        //    {
        //        cccode = shopInfo.cccode,
        //        shop_cd = shopInfo.shop_cd
        //    });

        //    if (temp.code.Equals("00"))
        //    {

        //        int areaSequenceNumber = 0;

        //        foreach (var item in temp.data)
        //        {
        //            // 배달 지역 리스트를 가져오고 배달 지역에 대한 형상 데이터를 저장한다. ( 순번에 맞게... )
        //            var commonShape = await GetCommonUmd(item.sido, item.sigungu, item.umdr);
        //            if (commonShape.code.Equals("00"))
        //            {
        //                RequestSetShopFence model = new RequestSetShopFence()
        //                {
        //                    shop_cd = shopInfo.shop_cd,
        //                    shop_fences = new List<ShopFence>()
        //                };
        //                ShopFence fence = new ShopFence()
        //                {
        //                    use_fence = "Y",
        //                    fence_name = item.umdr,
        //                    area = areaSequenceNumber++,
        //                    fence = new NaverPolygonArray(),
        //                    areaPoints = new List<List<double>>(),
        //                    fence_amount = "500",
        //                };

        //            }









        //        }




        //    }

        //}
            return null;
        }
}
}
