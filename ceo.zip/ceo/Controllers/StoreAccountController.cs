﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Pos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class StoreAccountController : Controller
    {
        private readonly DgShopApiService dgShop;
        public StoreAccountController(DgShopApiService api)
        {
            dgShop = api;
        }
        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            Request req = new Request()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };

            var temp = await dgShop.Post<ShopAccountModel, Request>("Account", req);

            // 2021.07.09 jwcho 로그인을 통한 접근이 아니면 출금 버튼을 보여주지 않는다.
            ViewBag.ViewOutput = (info.shop_id != null && info.shop_id.Equals(info.login_name)) ? true : false;

            return View(temp.data.SingleOrDefault());
        }

        public async Task<IActionResult> SetShopAccount()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            Request req = new Request()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };

            var temp = await dgShop.Post<ShopAccountModel, Request>("Account", req);

            return View(temp.data.SingleOrDefault());
        }

        [HttpPost]
        public async Task<IActionResult> SetShopAccount(ShopAccountModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestShopAccount req = new RequestShopAccount()
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                account = model.account_no,
                bank_code = model.bankcode,
                owner = model.acc_owner,
                pay_confirm = model.pay_confirm
            };

            var temp = await dgShop.Post<ShopAccountModel, RequestShopAccount>("Account/Set", req);
            if (temp.code.Equals("00"))
            {
                return RedirectToAction(nameof(Index));
            }
            else
                ModelState.AddModelError("", temp.msg);
            return View(model);

        }
    }
}
