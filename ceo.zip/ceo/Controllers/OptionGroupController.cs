﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Menu.Request;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.Admin.Request;
using PosWebApp.Models.Admin.Response;
using PosWebApp.Models.OptionGroupOptions;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Admin;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.OptionGroup;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class OptionGroupController : Controller
    {
        private readonly string DaeguDbConnectionString;
        private readonly string PosDb;
        private readonly IDaeguDatabase db;
        private readonly DgShopApiService dgShop;
        private readonly AdminApi adminAPI;
        private readonly NLog.Logger nlogger;

        public OptionGroupController(IConfiguration configuration, IDaeguDatabase daeguDb, DgShopApiService api, AdminApi adminApi)
        {
            dgShop = api;
            adminAPI = adminApi;
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }

        public async Task<IActionResult> Use(int? id)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            UrlParams url = new UrlParams();
            var menu_cd = "";
            if (id == null)
            {
                menu_cd = "";
            }
            else
            {
                menu_cd = id.ToString();
            }
            url.AddParams("shopCd", info.shop_cd.ToString());
            url.AddParams("MenuCd", menu_cd);

            var req = await adminAPI.Get<ResponseOptionGroup>("OptionGroup" + url.ToUrl());

            if (req.code == "00")
            {
                return View(req.data.OrderBy(x => x.selected.Equals("Y")));
            }
            ViewBag.Message = "메뉴 옵션 조회에 실패하였거나, 조회에 실패하였습니다.";
            return View();
        }
        public async Task<IActionResult> List(int? page, int? id)
        {
            ViewBag.id = id ?? 1;
            ViewBag.page = page ?? 1;

            await Task.Delay(0);
            return View();
        }

        public IActionResult ListFromComponent(int? page, int? id)
        {
            return ViewComponent("OptionGroupList", new { page = page, id = id });
        }

        public async Task<IActionResult> Detail(string idx = null)
        {
            if (string.IsNullOrEmpty(idx))
            {
                ModelState.AddModelError("", "조회 인자가없습니다. 새로고침 후 다시이용해주세요.");
                return PartialView("Detail");
            }
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //var req = await adminAPI.GetSingle<ResponseOptionGroupInfo>(string.Join("/", "OptionGroup", idx));
            var newOptions = await dgShop.PostSingle<ResponseGetOGnOptions, RequestGetOGnOptions>("OGnOptions/Get", new RequestGetOGnOptions
            {
                shop_cd = info.shop_cd,
                optionGroupCd = idx
            });

            ViewBag.groupOptions = idx;

            if (newOptions.code == "00")
            {
                return PartialView("Detail", newOptions.data);
            }
            ModelState.AddModelError("", "오류로인하여 정보를 가져올수없습니다. 새로고침 후 다시이용해주세요.");
            return PartialView("Detail");
        }
        [HttpPost]
        public async Task<IActionResult> Detail(ResponseGetOGnOptions from = null, List<OGnOption> optionitems = null )
        {
            from.options = new List<OGnOption>();

            if(optionitems.Count() > 0)
                from.options.AddRange(optionitems);

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            Utils utils = new Utils();

            ViewBag.groupOptions = from.optionGroupCd;
            for(var i = 0; i < optionitems.Count(); i++)
            {
                if (from.options[i].work_gbn.Equals("D"))
                {
                    continue;
                }
                if (string.IsNullOrEmpty(from.options[i].option_name))
                {
                    ModelState.AddModelError("", "옵션 이름을 적어주세요.");
                    return PartialView("Detail",from);
                }
                if (string.IsNullOrEmpty(from.options[i].work_gbn))
                {
                    ModelState.AddModelError("", "오류로인하여 정보를 가져올수없습니다. 새로고침 후 다시이용해주세요.");
                    return PartialView("Detail", from);
                }
                if (!utils.Money10wonCheck(from.options[i].option_cost)){
                    ModelState.AddModelError("", "오류로인하여 정보를 가져올수없습니다. 새로고침 후 다시이용해주세요.");
                    return PartialView("Detail", from);
                }
            }

            if (string.IsNullOrEmpty(from.optionGroupName))
            {
                ModelState.AddModelError("", "오류로인하여 정보를 가져올수없습니다. 새로고침 후 다시이용해주세요.");
                return PartialView("Detail");
            }
            if (Convert.ToUInt32(from.min_count) > Convert.ToUInt32(from.multi_count))
            {
                ModelState.AddModelError("", "최소값은 최대를 넘을수없습니다.");
                return PartialView("Detail", from);
            }
            from.shop_cd = info.shop_cd.ToString();

            var reqCURD = new List<RequestSetOGnOption>();
            
            int number = 1;
            for (var i = 0; i < optionitems.Count(); i++)
            {
                RequestSetOGnOption setOptions = new RequestSetOGnOption();
                if (from.options[i].work_gbn.Equals("S"))
                {
                    setOptions.work_gbn = "U";
                }else { 
                    setOptions.work_gbn= from.options[i].work_gbn;
                }
                setOptions.option_cd = from.options[i].option_cd;
                setOptions.option_cost = from.options[i].option_cost.Replace(",","");
                setOptions.option_use_yn = from.options[i].option_use_yn;
                setOptions.option_memo = from.options[i].option_meno;
                setOptions.o_no_flag = from.options[i].o_no_flag;
                setOptions.option_name = from.options[i].option_name;

                if (!from.options[i].work_gbn.Equals("D")) { 
                    setOptions.sort_seq = number;
                    number++;
                }
                reqCURD.Add(setOptions);
            }
            if(Convert.ToInt32(from.multi_count) > number - 1 )
            {
                ModelState.AddModelError("", "최대 선택갯수를 확인해주세요.");
                return PartialView("Detail", from);
            }
            number = 0;
            var Response = await dgShop.Post<dynamic, RequestSetOGnOptions>("OGnOptions/Set", new RequestSetOGnOptions
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                optionGroupCd = from.optionGroupCd,
                optionGroupName = from.optionGroupName,
                min_count = from.min_count,
                multi_count = from.multi_count,
                option_group_use_yn = from.use_yn,
                mod_user = info.login_name,
                options = reqCURD
            });

            if(Response.code == "00")
            {
                ViewBag.groupOptions = from.optionGroupCd;
                return PartialView("Detail", from);
            }
            ////var req = await adminAPI.Put<dynamic, ResponseOptionGroupInfo>("OptionGroup", from);
            //if (req.code == "00")
            //{
            //    return PartialView("Detail", req.data);
            //}
            ModelState.AddModelError("", "오류로인하여 정보를 가져올수없습니다. 새로고침 후 다시이용해주세요.");
            return BadRequest(new {
                code = "400",
                msg = Response.msg
            });
        }
        public IActionResult Add()
        {
            return View(); // PartialView("Add");
        }
        [HttpPost]
        public async Task<IActionResult> Add(OptionGroupAdd optionModel)
        {
            if (string.IsNullOrEmpty(optionModel.optionGroupName))
            {
                ModelState.AddModelError("", "이름이 없습니다.");
                return View(optionModel);
            }
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ApiModels.Option.Request.RequestOptionGroup GroupModel = new ApiModels.Option.Request.RequestOptionGroup()
            {
                mName = info.login_name,
                groupMemo = optionModel.optionGroupMemo,
                groupName = optionModel.optionGroupName,
                shop_cd = info.shop_cd,
                maxCount = "0",
                minCount = "0",
                multiYn = "N",
                useYn = optionModel.useYn

                //maxCount = optionModel.maxCount,
                //minCount = optionModel.minCount,
                //multiYn = optionModel.multiYn
            };

            // var response = await adminAPI.Post<ResponseOptionGroup, RequestOptionGroupAdd>("OptionGroup", GroupModel);
            var response = await dgShop.Post<dynamic, ApiModels.Option.Request.RequestOptionGroup>
                 ("/api/OptionManagement/OptionGroupAdd", GroupModel);

            if (response.code.Equals("00"))
            {
                return RedirectToAction("List", "OptionGroup");
            }

            ModelState.AddModelError("", response.msg);
            return View(optionModel);
        }
        public async Task<IActionResult> choiceList(int? page, int? id)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var menu_cd = "";

            if (page == null)
            {
                page = 1;
            }
            if (id == null)
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "존재하지않는 페이지입니다."
                });
            }
            else
            {
                menu_cd = id.ToString();
            }

            int pageSize = 10;
            UrlParams url = new UrlParams();
            url.AddParams("shopCd", info.shop_cd.ToString());
            url.AddParams("MenuCd", id.ToString());

            var req = await adminAPI.Get<ResponseOptionGroup>("OptionGroup" + url.ToUrl());

            if (req.code == "00")
            {
                TempData["menu_cd"] = id.ToString();
                return View(PaginatedList<ResponseOptionGroup>.Create(
                    req.data.OrderBy(x => x.selected.Equals("N"))
                    .AsQueryable<ResponseOptionGroup>(), page ?? 1, pageSize));
            }
            ViewBag.Message = "메뉴 옵션 조회에 실패하였거나, 조회에 실패하였습니다.";
            return View();
        }
        #region Menu OptionGroup 
        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<IActionResult> MenuView(string idx, string code, string a)
        {
            if (string.IsNullOrEmpty(idx))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "조회할수없습니다. 새로고침후 이용해주세요."
                });
            }

            var timeStamp = a; 
            var NowTime = DateTime.Now.ToString("HHmmss");

            try
            {
                if (Convert.ToInt32(a) <= Convert.ToInt32(NowTime))
                {
                    a = NowTime;
                }

            }
            catch (Exception e)
            {
                nlogger.Info($"[ CEO MenuView Error ,MenuCD === {idx}, http Status === { StatusCodes.Status500InternalServerError }, Error === {e.Message}] ");
               
                return StatusCode(500);
            }

            if (!string.IsNullOrEmpty(idx) && !string.IsNullOrEmpty(code) && !string.IsNullOrEmpty(a))
            {
                TempData["Menu_cd"] = idx;
                TempData["group_cd"] = code;
                TempData["TimeStemp"] = a;
                await Task.Delay(0);
                return View();
            }

            return BadRequest(new
            {
                code = "99",
                Msg = "조회할수없습니다. 새로고침후 이용해주세요."
            });
        }
        public async Task<IActionResult> MenuCancel(string idx, string pagecode, string code)
        {
            if (string.IsNullOrEmpty(idx) || string.IsNullOrEmpty(pagecode) || string.IsNullOrEmpty(code))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "삭제할수없습니다. 새로고침후 이용해주세요."
                });
            }
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            

            var result = new RequestMenuOptionCancel
            {
                shop_cd = info.shop_cd,
                menuCd = pagecode,
                menuOptionGroupCd = idx
            };

            var req = await dgShop.Post<dynamic, RequestMenuOptionCancel>("/api/MenuManagement/MenuOptionCancel", result);


            //var req = await adminAPI.Delete<dynamic>("MenuOptionGroup" + "/" + idx);

            if (req.code == "00")
            {
                return RedirectToAction("MenuView", new { idx = pagecode, code = code });
            }
            return BadRequest(new
            {
                code = "99",
                Msg = "삭제할수없습니다. 새로고침후 이용해주세요."
            });
        }

        public async Task<IActionResult> DeleteMenuOptionGroup(string idx, string page, string pageIndex)
        {
            if (string.IsNullOrEmpty(idx))
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "삭제할수없습니다. 새로고침후 이용해주세요.",
                    page = page,
                    pageIndex = pageIndex
                });
            }

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            // var req = await adminAPI.Delete<dynamic>("OptionGroup" + "/" + idx);

            var req = await dgShop.Post<dynamic, ApiModels.Option.Request.RequestOption>
                ("/api/OptionManagement/OptionGroupDelete", new ApiModels.Option.Request.RequestOption
                {
                    shop_cd = info.shop_cd,
                    optionGroupCd = idx,
                    mName = info.login_name
                });

            if (!req.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "99",
                    message = req.msg,
                    page = page,
                    pageIndex = pageIndex
                });
            }

            return Ok(new
            {
                code = "00",
                message = "성공",
                page = page,
                pageIndex = pageIndex
            });


        }

        #endregion

        #region ajax-call 
        public async Task<IActionResult> MenuOptionAdd(string cd, string[] idx)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            List<string> add = new List<string>(idx);

            UrlParams url = new UrlParams();
            url.AddParams("MenuCd", cd);
            var req = await adminAPI.Post<dynamic, List<string>>("MenuOptionGroup" + url.ToUrl(), add);

            if (req.code == "00")
            {
                return Ok();
            }
            return BadRequest();
        }

        public IActionResult CheckList(int? page, string id = null)
        {

            if (page == null)
            {
                page = 1;
            }
            if (id == null)
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "존재하지않는 페이지입니다."
                });
            }

            return ViewComponent("CheckTableList", new { page = page, id = id });
        }
        #endregion
    }
}
