﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.Pos;
using PosWebApp.Settings;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    public class DnController : Controller
    {
        private readonly IOptions<ApiStrings> apis;

        public DnController(IOptions<ApiStrings> apis)
        {
            this.apis = apis;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("hist_ver/{id}")]
        public async Task<dynamic> GetPosLoginHist(string id)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(apis.Value.daeguroPosAdminApi);

            var errorMsg = string.Empty;

            try
            {
                var response = await client.GetStringAsync($"Common/login_history_version/{DateTime.Now.ToString("yyyyMMdd")}/{id}");

                Result<PosLogHistory> result = JsonConvert.DeserializeObject<Result<PosLogHistory>>(response);

                var returnData = result.data.First();

                return new
                {
                    returnCode = result.code,
                    returnMessage = result.msg,
                    shop_id = returnData.shop_id,
                    shop_name =  returnData.shop_name,
                    address = returnData.shop_address,
                    login_ver = returnData.login_version
                };

                Debug.WriteLine(response.ToString());
            }
            catch(Exception e)
            {
                Debug.WriteLine(e.Message);
                errorMsg = e.Message;
            }
            finally
            {
                client.Dispose();
            }

            return new
            {
                returnCode = "99",
                returnMessage = errorMsg
            };

        }
    }
}
