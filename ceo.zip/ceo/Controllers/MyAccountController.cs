﻿using AspNetCoreHero.ToastNotification.Abstractions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.ChangeRequest.Request;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DaeguroPos;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.MyAccount;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class MyAccountController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly SyncDaeguroPosService syncPos;
        private readonly INotyfService _notyf;
        private readonly NLog.Logger nlogger;
        public MyAccountController(DgShopApiService api, SyncDaeguroPosService syncApi, INotyfService notifi)
        {
            dgShop = api;
            syncPos = syncApi;
            _notyf = notifi;
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }

        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestCommonAPI RSapi = new RequestCommonAPI(dgShop);
            var statusCancel = new[] { "10", "30" };
            var requestList = await RSapi.RequestServiceList(new RequestCommon
            {
                job_gbn = "1",
                shop_cd = info.shop_cd,
                service_gbn = "400",
                from = "20221231",
                to = "20300101"
            });
            var le = requestList.data.Where(x => statusCancel.Contains(x.status)).ToList();
            if (requestList.code.Equals("00"))
            {
                ViewBag.request400 = le.Count();
            }else
            {
                ViewBag.request400 = 0;
            }
            

            return View();
        }

        public IActionResult Shopcancellation()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Shopcancellation(string provision)
        {
            if (provision != "Y")
            {
                ModelState.AddModelError("", "동의여부를 체크해주세요");
                return View();
            }

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var serviceReq = await dgShop.Post<CodeMsg, PosWebApp.Models.ChangeRequest.Request.RequestCommon>("/api/RequestService/SetServiceRequest", new PosWebApp.Models.ChangeRequest.Request.RequestCommon
            {
                job_gbn = "1",
                mod_name = info.login_name,
                mod_ucode = info.login_code,
                seq = 0,
                service_data = "{\"provision\":\"" + provision + "\"}",
                service_gbn = "400",
                shop_cd = info.shop_cd,
                status = "10",
            }) ;

            if (serviceReq.code.Equals("00"))
            {
                _notyf.Success("입점 해지 신청완료되었습니다.", 5);
                return RedirectToAction("index", "Main");
            }


            return View();
        }
        public async Task<IActionResult> CancellationModal(string provision)
        {
            if(provision != "true")
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "동의체크"
                });
            }
            return PartialView("cancellationModal", new RequestCancellationModal());
        }
        [HttpPost]
        public async Task<IActionResult> CancellationModal(RequestCancellationModal model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (model == null)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "실패"
                });
            }

            if (model.formImages == null)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "첨부파일을 확인해주세요."
                });
            }
            if (string.IsNullOrEmpty(model.reason) || model.reason.Length < 1)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "해지 사유를 작성해주세요.(2자이상)"
                });
            }

            var datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            var imageFile = new ImageUtils();
            var isImage = new ResultSingle<string>();
            var fileName = "";
            var fileNames = new string[model.formImages.Count()];

#if DEBUG
            var imageURL = "https://ceo.daeguro.co.kr";
#else
            var imageURL = "https://ceo.daeguro.co.kr";
            //var imageURL = "https://ceoimage.daeguro.co.kr:45013";
#endif
            var cancellation = new ShopCancellation(model);
            cancellation.fileNames = new List<string>();
            try
            {
                foreach(var picture in model.formImages)
                {
                    if(picture.Length > 6291456)
                    {
                        return Ok(new
                        {
                            code = "99",
                            Msg = picture.FileName + "이미지가 너무 큽니다."
                        });
                    }
                }

                int idx = 0;
                foreach (var files in fileNames)
                {
                    fileName = datetime + DateTime.Now.ToString("ffff") + idx + "_" + "400" + ".jpg";
                    fileNames[idx] = fileName;
                    cancellation.fileNames.Add(imageURL + "/RequestServiceImage" + "/CanCellation" + "/" + DateTime.Now.ToString("yyyyMMdd") + "/" + info.shop_cd + "/" + fileName);
                    idx++;
                }
                isImage = await imageFile.FileListUpload(info.shop_cd.ToString(), model.formImages, fileNames.ToList(), "CanCellation");



                if (isImage.code.Equals("00"))
                {
                    nlogger.Info("해지 요청 이미지 신청..");

                    var serviceReq = await dgShop.Post<CodeMsg, RequestCommon>("/api/RequestService/SetServiceRequest", new RequestCommon
                    {
                        job_gbn = "1",
                        mod_name = info.login_name,
                        mod_ucode = info.login_code,
                        seq = 0,
                        service_data = JsonConvert.SerializeObject(cancellation, Formatting.Indented, new JsonSerializerSettings
                        {
                            NullValueHandling = NullValueHandling.Ignore
                        }),
                        service_gbn = "400",
                        shop_cd = info.shop_cd,
                        status = "10",
                    });

                    if (serviceReq.code.Equals("00"))
                    {
                        nlogger.Info($"해지 요청 이미지 성공 {info.shop_cd}");
                        return Ok(new
                        {
                            code = "00",
                            Msg = "성공"
                        });
                    }
                    else
                    {
                        nlogger.Info($"해지 요청 이미지 실패 {serviceReq.msg}");
                        nlogger.Info($"해지 요청 이미지 실패 shopCd === {serviceReq.msg}, Model ===={JsonConvert.SerializeObject(cancellation)}");

                        return Ok(new
                        {
                            code = "99",
                            Msg = serviceReq.msg
                        });
                    }
                }
                else
                {
                    nlogger.Info($"해지 요청 이미지 실패 {isImage.msg}");
                    nlogger.Info($"해지 요청 이미지 실패 shopCd === {isImage.msg}, Model ===={JsonConvert.SerializeObject(cancellation)}");

                    return Ok(new
                    {
                        code = "99",
                        Msg = isImage.data
                    });
                }
            }
            catch (Exception e)
            {
                ViewBag.Error = e.Message;
                return Ok(new
                {
                    code = "99",
                    Msg = ViewBag.Error
                });
            }
            return PartialView("cancellationModal", model);
        }
        public IActionResult MyPass()
        {
            ViewBag.complete = false;

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> MyPass(PasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            if (model.password.Equals("eornfh"))
            {
                ModelState.AddModelError("", "입력하신 비밀번호는 입력 하실 수 없습니다");
                model.password = string.Empty;
                model.password_confirm = string.Empty;
                return View(model);
            }

#if true
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestChangePassword pass = new RequestChangePassword()
            {
                job_gbn = "2",
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                id = info.shop_id,
                current = model.current,
                password = model.password_confirm,
                mod_code = info.login_code,
                mod_user = info.login_name,
                shopMallYn = info.mallYN
            };
#endif
            //RequestChangePassword pass = new RequestChangePassword()
            //{
            //    cccode = "3",
            //    shop_cd = 1,
            //    id = "공주찜닭",
            //    current = model.current,
            //    password = model.password_confirm,
            //    mod_code = 333,
            //    mod_user = "4444"
            //};

            var temp = await syncPos.Post<CodeMsg, RequestChangePassword>("MyPass", pass);

            if(temp.code.Equals("00"))
            {
                ViewBag.complete = true;
                return View(model);
            }

            ModelState.AddModelError("", temp.msg);

            return View(model);
        }

    }
}
