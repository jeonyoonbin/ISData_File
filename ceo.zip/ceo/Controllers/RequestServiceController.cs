﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using PosWebApp.Common;
using PosWebApp.Models.ChangeRequest.Request;
using PosWebApp.Models.ChangeRequest.Response;
using PosWebApp.Settings;

namespace PosWebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RequestServiceController : ControllerBase
    {
        public IOptions<DbStrings> DbString { get; }

        public RequestServiceController(IOptions<DbStrings> dbString)
        {
            DbString = dbString;
        }
        #region 변경요청 로그조회 
        [HttpPost("GetRequestService")]
        public async Task<Result<ResponseCommon>> GetRequestService(RequestCommon info)
        {
            Result<ResponseCommon> result = new Result<ResponseCommon>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.IsDaegu))
                {
                    await conn.OpenAsync(); 
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        CommandText = "PKG_IS_WEB_SHOP_T.GET_SERVICE_REQ_HIST_LIST",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_status", OracleDbType.Varchar2)).Value = info.status;
                        cmd.Parameters.Add(new OracleParameter("in_service_gbn", OracleDbType.Varchar2)).Value = info.service_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_from_date", OracleDbType.Varchar2)).Value = info.from;
                        cmd.Parameters.Add(new OracleParameter("in_to_date ", OracleDbType.Varchar2)).Value = info.to;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseCommon> modelList = new List<ResponseCommon>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseCommon model = new ResponseCommon()
                                    {
                                        hist_seq = reader["hist_seq"].ToString(),
                                        status = reader["status"].ToString(),
                                        status_name = reader["status_name"].ToString(),
                                        service_gbn = reader["service_gbn"].ToString(),
                                        service_gbn_name = reader["service_gbn_name"].ToString(),
                                        insert_date = reader["insert_date"].ToString(),
                                        mod_date = reader["mod_date"].ToString(),
                                        answer_text = reader["answer_text"].ToString(),
                                        service_data = reader["service_data"].ToString(),
                                        file_name = reader["file_name"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        #endregion
        #region 변경요청 조회 
        [HttpPost("GetRequestServiceList")]
        public async Task<Result<ResponseCommon>> GetRequestServiceList(RequestCommon info)
        {
            Result<ResponseCommon> result = new Result<ResponseCommon>();
            try
            {
                //using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                using (OracleConnection conn = new OracleConnection(DbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        CommandText = "PKG_IS_WEB_SHOP_V3.GET_SERVICE_REQ_LIST",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_status", OracleDbType.Varchar2)).Value = info.status;
                        cmd.Parameters.Add(new OracleParameter("in_service_gbn", OracleDbType.Varchar2)).Value = info.service_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_from_date", OracleDbType.Varchar2)).Value = info.from;
                        cmd.Parameters.Add(new OracleParameter("in_to_date ", OracleDbType.Varchar2)).Value = info.to;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseCommon> modelList = new List<ResponseCommon>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseCommon model = new ResponseCommon()
                                    {
                                        seq = reader["seq"].ToString(),
                                        status = reader["status"].ToString(),
                                        status_name = reader["status_name"].ToString(),
                                        service_gbn = reader["service_gbn"].ToString(),
                                        service_gbn_name = reader["service_gbn_name"].ToString(),
                                        insert_date = reader["insert_date"].ToString(),
                                        mod_date = reader["mod_date"].ToString(),
                                        answer_text = reader["answer_text"].ToString(),
                                        service_data = reader["service_data"].ToString(),
                                        file_name = reader["file_name"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        #endregion

        #region  변경요청 등록
        [HttpPost("SetServiceRequest")]
        public async Task<Result<CodeMsg>> SetBizInfo(RequestCommon info)
        {
            Result<CodeMsg> result = new Result<CodeMsg>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.IsDaegu))
                //using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        CommandText = "PKG_IS_WEB_SHOP_V3.SET_SERVICE",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_seq", OracleDbType.Int32)).Value = info.seq;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_status", OracleDbType.Varchar2)).Value = info.status;
                        cmd.Parameters.Add(new OracleParameter("in_service_gbn", OracleDbType.Varchar2)).Value = info.service_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_mod_ucode", OracleDbType.Int32)).Value = info.mod_ucode;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_name;
                        cmd.Parameters.Add(new OracleParameter("in_service_data", OracleDbType.Varchar2)).Value = info.service_data;
                        cmd.Parameters.Add(new OracleParameter("in_filter", OracleDbType.Varchar2)).Value = info.filter;
                        cmd.Parameters.Add(new OracleParameter("in_file_name", OracleDbType.Varchar2)).Value = info.file_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        #endregion
        #region 사업자 번호 중복
        [HttpPost("OverLapRegNo")]
        public async Task<ResultSingle<CodeMsg>> OverLapRegNo(RequestOverLapRegNo info)
        {
            ResultSingle<CodeMsg> result = new ResultSingle<CodeMsg>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        CommandText = "PKG_IS_WEB_SHOP_T.GET_BUSINESS_NO",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2, 20)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_business_no", OracleDbType.Varchar2, 200)).Value = info.RegNo;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;
                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        #endregion

        #region 공통 코드 - 변경요청
        [HttpPost("GetServiceTypeCommon")]
        public async Task<Result<ResponseServiceTypeCommon>> GetServiceTypeCommon(RequestServiceTypeCommon info)
        {
            Result<ResponseServiceTypeCommon> result = new Result<ResponseServiceTypeCommon>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        CommandText = "PKG_IS_ADMIN_SHOP_REQ.GET_SERVICE_REQ_TYPE",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_gbn_code ", OracleDbType.Int32)).Value = info.GbnCode;
                        cmd.Parameters.Add(new OracleParameter("out_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_code"].Value.ToString();
                            string message = cmd.Parameters["out_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseServiceTypeCommon> modelList = new List<ResponseServiceTypeCommon>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseServiceTypeCommon model = new ResponseServiceTypeCommon()
                                    {
                                        typeCode = reader["TYPE_CODE"].ToString(),
                                        typeName = reader["TYPE_NAME"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        #endregion
        #region 착한매장 상세조회
        [HttpPost("GetKindShop")]
        public async Task<Result<ResponseServiceDetail>> GetKindShop(RequestCommon info)
        {
            Result<ResponseServiceDetail> result = new Result<ResponseServiceDetail>();
            try
            {
                //using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                using (OracleConnection conn = new OracleConnection(DbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        CommandText = "PKG_IS_WEB_SHOP_V3.GET_SERVICE_DETAIL",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_service_gbn", OracleDbType.Varchar2)).Value = info.service_gbn;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseServiceDetail> modelList = new List<ResponseServiceDetail>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseServiceDetail model = new ResponseServiceDetail()
                                    {
                                        kindShopYn       = reader["KIND_SHOP_YN"].ToString(),
                                        kindShopCancelDt = reader["KIND_SHOP_CANCEL_DT"].ToString(),
                                        seq              = reader["SEQ"].ToString(),
                                        status           = reader["STATUS"].ToString(),
                                        statusName       = reader["STATUS_NAME"].ToString(),
                                        serviceGbn       = reader["SERVICE_GBN"].ToString(),
                                        btnReqYn         = reader["BTN_REQ_YN"].ToString(),
                                        btnReqCancelYn   = reader["BTN_REQ_CANCEL_YN"].ToString(),
                                        btnDelYn         = reader["BTN_DEL_YN"].ToString(),
                                        btnDelCancelYn   = reader["BTN_DEL_CANCEL_YN"].ToString(),
                                        answerText       = reader["ANSWER_TEXT"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        #endregion
    }
}
