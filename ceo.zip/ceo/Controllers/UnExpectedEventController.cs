﻿using System;
using System.Collections.Generic;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Models.Event;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.UnExpectedEvent;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class UnExpectedEventController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly string storeImageUrl;
        private readonly string logoImageUrl;
        private readonly NLog.Logger nlogger;
        public UnExpectedEventController(DgShopApiService api, IConfiguration config)
        {
            dgShop = api;
            storeImageUrl = config.GetValue<string>("upload:shopSignBoardPath");
            logoImageUrl = config.GetValue<string>("upload:shopLogoPath");
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }
        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            UnExpectedEventViewModel viewModel = new UnExpectedEventViewModel();
            


            
#if DEBUG 

            var systemTime = DateTime.Now;
            var EndTime = DateTime.ParseExact("2359", "HHmm", System.Globalization.CultureInfo.InvariantCulture);
            var eventStartTime = DateTime.ParseExact("0000", "HHmm", System.Globalization.CultureInfo.InvariantCulture);
#else
            var systemTime = DateTime.Now;
            var EndTime = DateTime.ParseExact("2200", "HHmm", System.Globalization.CultureInfo.InvariantCulture);
            var eventStartTime = DateTime.ParseExact("0900", "HHmm", System.Globalization.CultureInfo.InvariantCulture);
#endif
            TimeSpan enterTiem = systemTime - eventStartTime;
            TimeSpan resultTime = systemTime - EndTime;
            
            

            var mstreq = await dgShop.Post<ResponseShopEventList, RequestShopEventList>("/api/Event/Master/List", new RequestShopEventList
            {
                use_gbn = "%",
                job_gbn = "1",
                shop_cd = info.shop_cd
            });

            if (mstreq.code == "00")
            {
                if (mstreq.data.Count > 0)
                {
                    var data = mstreq.data.SingleOrDefault();
                    var startTime = data.start_time.Insert(2, ":");
                    var endTime = data.end_time.Insert(2, ":");
                    viewModel.start_time = startTime;
                    viewModel.end_time = endTime;
                    viewModel.use_yn = data.use_gbn.Equals("Y") ? true : false; 
                    viewModel.overUse_gbn = "Y";
                    var resultList = await dgShop.Post<ResponseShopEventList, RequestShopEventList>("/api/Event/List", new RequestShopEventList
                    {
                        use_gbn = "Y",
                        job_gbn = "1",
                        shop_cd = info.shop_cd,
                        cccode = info.cccode
                    });

                    viewModel.eventList = resultList.data;
                }

                if (resultTime.TotalMinutes < 0 && enterTiem.TotalMinutes > 0)
                {
                    //등록 가능
                   
                    ViewBag.DangerCode = "00";

                    if(viewModel.eventList == null)
                    {
                        viewModel.eventList = new List<ResponseShopEventList>();
                    }
                }
                else
                {
                    //등록 불가
                    ViewBag.DangerCode = "99";
                    
                    viewModel.use_yn = false;

                    if (viewModel.eventList == null)
                    {
                        viewModel.eventList = new List<ResponseShopEventList>();
                    }
                }
            }
            if (ViewBag.DangerCode == "99")
            {
                //오늘 사용불가
                viewModel.overUse_gbn = "Y";
                viewModel.use_yn = false;
                ViewBag.EndMsg = "금일 이벤트 등록이 종료되었습니다. 내일 다시 진행해주시기 바랍니다. ";
            }

            var MenuReq = await dgShop.Post<EventMenu, Request>("/api/Event/Menus", new Request
            {
                cccode = info.cccode,
                job_gbn = "1",
                mcode = info.mcode,
                shop_cd = info.shop_cd
            });
            // Mcode 1 인경우만 허용
            if (info.mcode != 1)
            {
                viewModel.menuList = MenuReq.data;
                ViewBag.Shop = info;
                ViewBag.EndMsg = "라이브이벤트 오픈 전입니다. 다른 서비스 이용부탁드립니다.";
                return View(viewModel);
            }
            if (MenuReq.code == "00")
            {

                ViewBag.Shop = info;
                viewModel.menuList = MenuReq.data;
                return View(viewModel);
            }
            return View();

        }
        [HttpPost]
        public async Task<IActionResult> TimeSet(UnExpectedEventViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var JobGbn = "I";
            if (string.IsNullOrEmpty(model.start_time))
            {
                ModelState.AddModelError("", "시간을 설정을 설정 해주세요");
                return RedirectToAction("Index", "UnExpectedEvent", model);
            }
            var mstList = await dgShop.Post<ResponseShopEventList, RequestShopEventList>("/api/Event/Master/List", new RequestShopEventList
            {
                use_gbn = "%",
                job_gbn = "1",
                shop_cd = info.shop_cd
            });
            if (mstList.code == "00")
            {

                if (mstList.data.Count() > 0)
                {
                    if (mstList.data.SingleOrDefault().use_gbn.Equals("Y"))
                    {
                        JobGbn = "U";
                    }
                }
            }
            var mstreq = await dgShop.Post<CodeMsg, RequestSetShopEvent>("/api/Event/Master/Set", new RequestSetShopEvent
            {
                job_gbn = JobGbn,
                shop_cd = info.shop_cd,
                from_time = model.start_time.Replace(":", ""),
                to_time = model.end_time.Replace(":", ""),
                //from_time = "1700",
                //to_time = "1830",
                ins_name = info.login_name,
                event_title = model.event_title
            });

            if (mstreq.code == "00")
            {
                nlogger.Info($"[ CEO UnExpectedEvent TimeSET Error ,Shopcd === {info.shop_cd}, MST CODE === { mstreq.code }, MST MSG === { mstreq.msg }] ");
                return RedirectToAction("Index", "UnExpectedEvent", model);
            }

            return BadRequest(new
            {
                code = "99",
                Msg = mstreq.msg
            });
        }
        [HttpPost]
        public async Task<IActionResult> TimeCancel(UnExpectedEventViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (!model.use_yn)
            {
                var mstreq = await dgShop.Post<CodeMsg, RequestSetShopEvent>("/api/Event/Master/UnSet", new RequestSetShopEvent
                {
                    job_gbn = "I",
                    shop_cd = info.shop_cd,
                    from_time = model.start_time,
                    to_time = model.end_time,
                    ins_name = info.login_name
                });

                if (mstreq.code == "00")
                {
                    nlogger.Info($"[ CEO UnExpectedEvent TimeCancel Error ,Shopcd === {info.shop_cd}, MST CODE === { mstreq.code }, MST MSG === { mstreq.msg }] ");
                    return Ok(new
                    {
                        code = "00",
                        Msg = "성공"
                    });
                }
            }
            return BadRequest(new
            {
                code = "99",
                Msg = "이벤트 설정 실패"
            });
        }
        [HttpPost]
        public async Task<IActionResult> TableSet(EventTableViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(model.menuCd))
            {
                ModelState.AddModelError("", "메뉴가 존재하지않습니다.");
            }
            var eventAmt = model.eventAmt.Replace(",", "");
            var menuCost = model.menuCost.Replace(",", "");

            if(Convert.ToInt32(eventAmt) > Convert.ToInt32(menuCost))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "메뉴금액보다 할인금액이 더 많습니다."
                }) ;
            }
            
            var mstReq = await dgShop.Post<dynamic, RequestSetShopEvent>("/api/Event/Set", new RequestSetShopEvent
            {
                job_gbn = "I",
                event_amt = model.eventAmt.Replace(",",""),
                event_amt_gbn = "1",
                shop_cd = info.shop_cd,
                from_time = model.startTime,
                to_time = model.endTime,
                menu_cd = Convert.ToInt32(model.menuCd),
                ins_name = info.login_name,

            });

            if (mstReq.code == "00")
            {
                nlogger.Info($"[ CEO UnExpectedEvent TableSET Error ,Shopcd === {info.shop_cd}, MST CODE === { mstReq.code }, MST MSG === { mstReq.msg }] ");
                return Ok(new
                {
                    code = "00",
                    Msg = "등록완료"
                });
            }
            return BadRequest(new
            {
                code = "99",
                Msg = mstReq.msg
            });
        }
        [HttpPost]
        public async Task<IActionResult> TableDelete(string idx)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(idx))
            {
                ModelState.AddModelError("", "메뉴가 존재하지않습니다.");
                return BadRequest(new
                {
                    code = "99",
                    Msg = "메뉴가 존재하지 않습니다."
                });
            }
            var eventReq = await dgShop.Post<dynamic, RequestShopEventNoUse>("/api/Event/UnSet", new RequestShopEventNoUse
            {
                job_gbn = "I",
                shop_cd = info.shop_cd,
                menu_cd = Convert.ToInt32(idx),
                ins_name = info.login_name
            });

            if(eventReq.code == "00")
            {
                nlogger.Info($"[ CEO UnExpectedEvent Table Delete Error Succses ,Shopcd === {info.shop_cd}, MST CODE === { eventReq.code }, MST MSG === { eventReq.msg }] ");
                return Ok(new
                {
                    code = "00",
                    Msg = "이벤트 등록이 되었습니다."
                });
            }
            nlogger.Info($"[ CEO UnExpectedEvent Table Delete Falid Error ,Shopcd === {info.shop_cd}, MST CODE === { eventReq.code }, MST MSG === { eventReq.msg }] ");
            return BadRequest(new
            {
                code = "99",
                Msg = eventReq.msg
            });
        }

        public async Task<IActionResult> RealTime()
        {
            var realtime = await dgShop.GetSingle<string>("Date");

            if (realtime.code == "00")
                return Ok(realtime.data);
            else
                return BadRequest(new 
                {
                    code = "99",
                    Msg = "조회 실패"
                });
        }
        [HttpPost]
        public async Task<IActionResult> PushSend()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            var mstreq = await dgShop.Post<ResponseShopEventList, RequestShopEventList>("/api/Event/Master/List", new RequestShopEventList
            {
                use_gbn = "%",
                job_gbn = "1",
                shop_cd = info.shop_cd
            });

            if (mstreq.code == "00")
            {
                if (mstreq.data.Count() > 0)
                {
                    var sendYN = mstreq.data.SingleOrDefault().push_send_yn;

                    if (sendYN.Equals("Y"))
                    {
                        return BadRequest(new
                        {
                            code = "99",
                            Msg = "이미 알림이 발송되었습니다."
                        });
                    }
                    var resultList = await dgShop.Post<ResponseShopEventList, RequestShopEventList>("/api/Event/List", new RequestShopEventList
                    {
                        use_gbn = "Y",
                        job_gbn = "1",
                        shop_cd = info.shop_cd,
                        cccode = info.cccode
                    });
                    if(resultList.data.Count() == 0)
                    {
                        return BadRequest(new
                        {
                            code = "99",
                            Msg = "메뉴 등록 후 발송해 주시기 바랍니다."
                        });
                    }
                }
                else
                {
                    return BadRequest(new
                    {
                        code = "99",
                        Msg = "이벤트가 대기중입니다.\n 이벤트가 진행중일 경에만 발송 가능합니다."
                    });
                }
            }
            var pushReq = await dgShop.Post<dynamic, RequestShopEventNoUse>("/api/Event/Push", new RequestShopEventNoUse
            {
                job_gbn = "I",
                shop_cd = info.shop_cd,
                ins_name = info.login_name
            });

            if(pushReq.code == "00")
            {
                nlogger.Info($"[ CEO UnExpectedEvent PushSend Success ,Shopcd === {info.shop_cd}, MST CODE === { pushReq.code }, MST MSG === { pushReq.msg }] ");
                return Ok(new
                {
                    code = "00",
                    Msg = "발송 되었습니다.",
                    shopName = info.shop_name,
                    startTime = mstreq.data.SingleOrDefault().start_time.Insert(2,":"),
                    EndTime = mstreq.data.SingleOrDefault().end_time.Insert(2, ":")
                }); ;
            }
            nlogger.Info($"[ CEO UnExpectedEvent PushSend Fail ,Shopcd === {info.shop_cd}, MST CODE === { pushReq.code }, MST MSG === { pushReq.msg }] ");
            return BadRequest(new
            {
                code = "99",
                Msg = pushReq.msg
            });
        }

        public async Task<IActionResult> Event()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            UnExpectedEventViewModel viewModel = new UnExpectedEventViewModel();

#if DEBUG

            var systemTime = DateTime.Now;
            //var EndTime = DateTime.ParseExact("2359", "HHmm", System.Globalization.CultureInfo.InvariantCulture);
            //var eventStartTime = DateTime.ParseExact("0000", "HHmm", System.Globalization.CultureInfo.InvariantCulture);
#else
            var systemTime = DateTime.Now;
            var EndTime = DateTime.ParseExact("2359", "HHmm", System.Globalization.CultureInfo.InvariantCulture);
            var eventStartTime = DateTime.ParseExact("0000", "HHmm", System.Globalization.CultureInfo.InvariantCulture);
#endif
           // TimeSpan enterTiem = systemTime - eventStartTime;
           // TimeSpan resultTime = systemTime - EndTime;

            //if (info.mcode != 1)
            //{
            //    viewModel.event_yn = "N";
            //    viewModel.push_yn = "N";
            //    ViewBag.Shop = info;
            //    viewModel.eventList = new List<ResponseShopEventList>();
            //    ViewBag.EndMsg = "라이브이벤트 오픈 전입니다. 다른 서비스 이용부탁드립니다.";
            //    return View(viewModel);
            //}

            var mstreq = await dgShop.Post<ResponseShopEventList, RequestShopEventList>("/api/Event/Master/List", new RequestShopEventList
            {
                use_gbn = "%",
                job_gbn = "1",
                shop_cd = info.shop_cd
            });

            var req = await dgShop.PostSingle< ResponseGetLiveEvent, RequestShopEventList>("/api/Event/GetLiveEvent", new RequestShopEventList
            {
                use_gbn = "%",
                job_gbn = "1",
                shop_cd = info.shop_cd
            });

            ViewBag.Shop = info;
            viewModel.eventList = new List<ResponseShopEventList>();
            if (req.code == "00")
            {
                var signData = req.data;

                if (signData.event_yn.Equals("E")) //종료
                {
                    ViewBag.DangerCode = "99";
                    viewModel.event_yn = signData.event_yn;
                    viewModel.push_yn = signData.push_yn;
                    viewModel.logo = signData.shop_logo;
                    viewModel.shop_name = signData.shop_name;
                    viewModel.remaining_time = signData.remaining_time;
                    ViewBag.color = ShopBackGroundColor(info.shop_cd);
                    return View(viewModel);

                }
                else if(signData.event_yn.Equals("N")) // 등록 전
                {
                    ViewBag.DangerCode = "00";
                    viewModel.event_yn = signData.event_yn;
                    viewModel.push_yn = signData.push_yn;
                    viewModel.logo = signData.shop_logo;
                    viewModel.shop_name = signData.shop_name;
                    viewModel.remaining_time = signData.remaining_time;
                    ViewBag.color = ShopBackGroundColor(info.shop_cd);
                    return View(viewModel);

                }
                else if(signData.event_yn.Equals("R")) // 시작 전
                {
                    ViewBag.DangerCode = "90";
                    var startTime = signData.fr_time.Insert(2, ":");
                    var endTime = signData.to_time.Insert(2, ":");
                    viewModel.start_time = startTime;
                    viewModel.end_time = endTime;
                    // viewModel.use_yn = signData..Equals("Y") ? true : false;
                    viewModel.overUse_gbn = "Y";
                    viewModel.logo = signData.shop_logo;
                    viewModel.shop_name = signData.shop_name;
                    viewModel.event_title = signData.event_title;
                    viewModel.remaining_time = signData.remaining_time;
                    ViewBag.eventGbn = signData.MenuList[0].event_amt_gbn;
                    viewModel.eventList = signData.MenuList;
                    viewModel.push_yn = signData.push_yn;
                    viewModel.event_yn = signData.event_yn;
                }
                else if (signData.event_yn.Equals("Y") ) // 등록 완료
                {
                    var startTime = signData.fr_time.Insert(2, ":");
                    var endTime = signData.to_time.Insert(2, ":");
                    viewModel.start_time = startTime;
                    viewModel.end_time = endTime;
                   // viewModel.use_yn = signData..Equals("Y") ? true : false;
                    viewModel.overUse_gbn = "Y";
                    viewModel.logo = signData.shop_logo;
                    viewModel.shop_name = signData.shop_name;
                    viewModel.event_title = signData.event_title;
                    if (signData.MenuList[0].event_amt_gbn.Equals("3"))
                    {
                        viewModel.salesAmt = signData.MenuList.First().event_amt;
                        for (int i = 0; i < signData.MenuList.Count(); i++)
                        {
                            signData.MenuList[i].event_amt = (Convert.ToInt32(signData.MenuList[i].menu_cost) * Convert.ToInt32(signData.MenuList[i].event_amt) * 0.01).ToString(); 
                        }
                    }else
                    {
                        viewModel.salesAmt = signData.MenuList.First().event_amt;
                    }

                    viewModel.eventList = signData.MenuList;
                    viewModel.push_yn = signData.push_yn;
                    ViewBag.eventGbn = signData.MenuList[0].event_amt_gbn;
                    var minutes = Convert.ToDouble(signData.remaining_time);
                    TimeSpan hours = TimeSpan.FromMinutes(minutes);
                    viewModel.remaining_time = signData.remaining_time;

                    var before = Convert.ToInt32(signData.to_time.Substring(0, 2)) * 60 + Convert.ToInt32(signData.to_time.Substring(2, 2));
                    var after = Convert.ToInt32(signData.fr_time.Substring(0, 2)) * 60 + Convert.ToInt32(signData.fr_time.Substring(2, 2));
                    ViewBag.EndTime = (before - after) * 60;
                    viewModel.hours = hours;
                    viewModel.event_yn = signData.event_yn;
                    ViewBag.DangerCode = "90";
                }
            }
           
            if (ViewBag.DangerCode == "90")
            {
                ViewBag.color = ShopBackGroundColor(info.shop_cd);
                return View(viewModel);
            }
            

            //if (mstreq.code == "00")
            //{
            //    if (resultTime.TotalMinutes < 0 && enterTiem.TotalMinutes > 0)
            //    {
            //        //등록 가능

            //        ViewBag.DangerCode = "00";

            //        if (viewModel.eventList == null)
            //        {
            //            viewModel.eventList = new List<ResponseShopEventList>();
            //        }
            //    }
            //    else
            //    {
            //        //등록 불가
            //        ViewBag.DangerCode = "99";

            //        viewModel.use_yn = false;

            //        if (viewModel.eventList == null)
            //        {
            //            viewModel.eventList = new List<ResponseShopEventList>();
            //        }
            //    }
            //    if (mstreq.data.Count > 0)
            //    {
            //        var data = mstreq.data.SingleOrDefault();
            //        var startTime = data.start_time.Insert(2, ":");
            //        var endTime = data.end_time.Insert(2, ":");
            //        viewModel.start_time = startTime;
            //        viewModel.end_time = endTime;
            //        viewModel.use_yn = data.use_gbn.Equals("Y") ? true : false;
            //        viewModel.overUse_gbn = "Y";
            //        viewModel.event_title = data.event_title;
            //        var resultList = await dgShop.Post<ResponseShopEventList, RequestShopEventList>("/api/Event/List", new RequestShopEventList
            //        {
            //            use_gbn = "Y",
            //            job_gbn = "1",
            //            shop_cd = info.shop_cd,
            //            cccode = info.cccode
            //        });

            //        viewModel.eventList = resultList.data;
            //        if (data.use_gbn.Equals("Y"))
            //        {
            //            var EventDate = DateTime.ParseExact(data.order_date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);

            //            TimeSpan ts = new TimeSpan(Convert.ToInt32(data.end_time.Substring(0, 2)), Convert.ToInt32(data.end_time.Substring(2, 2)),0);
            //            EventDate = EventDate.Date + ts;
            //            var EventTime = DateTime.ParseExact(data.end_time,"HHmm", System.Globalization.CultureInfo.InvariantCulture);
                        
            //            TimeSpan timeOut = systemTime - EventDate;

            //            if(timeOut.TotalMinutes < 0)
            //            {
            //                ViewBag.DangerCode = "00";
            //            }
            //            else
            //            {
            //                ViewBag.DangerCode = "99";
            //            }
            //        }else
            //        {
            //            var EventDate = DateTime.ParseExact(data.order_date, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);

            //            TimeSpan ts = new TimeSpan(Convert.ToInt32(data.end_time.Substring(0, 2)), Convert.ToInt32(data.end_time.Substring(2, 2)), 0);
            //            EventDate = EventDate.Date + ts;
            //            var EventTime = DateTime.ParseExact(data.end_time, "HHmm", System.Globalization.CultureInfo.InvariantCulture);

            //            TimeSpan timeOut = systemTime - EventDate;

            //            if (timeOut.TotalMinutes < 0)
            //            {
            //                ViewBag.DangerCode = "00";
            //            }
            //            else
            //            {
            //                ViewBag.DangerCode = "99";
            //            }
            //        }
            //    }
            //}
            if (ViewBag.DangerCode == "99")
            {
                //오늘 사용불가
                viewModel.overUse_gbn = "Y";
                viewModel.use_yn = false;
                ViewBag.EndMsg = "금일 이벤트 등록이 종료되었습니다. 내일 다시 진행해주시기 바랍니다. ";
            }

            var MenuReq = await dgShop.Post<EventMenu, Request>("/api/Event/Menus", new Request
            {
                cccode = info.cccode,
                job_gbn = "1",
                mcode = info.mcode,
                shop_cd = info.shop_cd
            });
            // Mcode 1 인경우만 허용
            if (info.mcode != 1)
            {
                viewModel.menuList = MenuReq.data;
                ViewBag.Shop = info;
                ViewBag.EndMsg = "라이브이벤트 오픈 전입니다. 다른 서비스 이용부탁드립니다.";
                return View(viewModel);
            }
            if (MenuReq.code == "00")
            {

                ViewBag.Shop = info;
                viewModel.menuList = MenuReq.data;
                return View(viewModel);
            }


            return View();
        }
        public async Task<IActionResult> PreView(UnExpectedEventPreView model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            Request req = new Request()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };

            var temp = await dgShop.Post<ShopStoreInfo, Request>("DefaultInfo", req);
            if (temp.code.Equals("00"))
            {
                var shopDefaultInfo = temp.data.SingleOrDefault();
                ViewBag.ShopDefault = shopDefaultInfo;

                ViewData["StoreImage"] = string.Concat(storeImageUrl, shopDefaultInfo.app_logo_name);

                if (!string.IsNullOrEmpty(shopDefaultInfo.app_file_name))
                {
                    ViewData["StoreLogo"] = string.Concat(logoImageUrl, shopDefaultInfo.app_file_name);
                }
                else
                {
                    ViewData["StoreLogo"] = "/img/image-gallery.png";
                }

            }
            model.shop_name = info.shop_name;

            var saveReq = await dgShop.PostSingle<ResponseGetLiveEvent, RequestShopEventList>("/api/Event/GetLiveEvent", new RequestShopEventList
            {
                use_gbn = "%",
                job_gbn = "1",
                shop_cd = info.shop_cd
            });

            model.menu_list = new List<PreViewMenu>();
            PreViewMenu menuItem = new PreViewMenu();

            for(var i = 0; i < saveReq.data.MenuList.Count(); i++)
            {
                menuItem.menu_name = saveReq.data.MenuList[i].menu_name;
                menuItem.disc_menu_cost = Math.Round((Convert.ToDouble(saveReq.data.MenuList[i].event_amt) / (Convert.ToInt32(saveReq.data.MenuList[i].menu_cost)) * 100));
                model.menu_list.Add(menuItem);
            }
            model.remaining_time = saveReq.data.remaining_time;
            ViewBag.maxDisc = model.menu_list.Select(x => x.disc_menu_cost).ToArray().Max();

            return PartialView("Preview",model);
        }
        public async Task<IActionResult> MenuInfo(string[] checkCd = null, string[] SaleQnt = null, string eventAmt = null, string eventGbn = null)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var MenuReq = await dgShop.Post<EventMenu, Request>("/api/Event/Menus", new Request
            {
                cccode = info.cccode,
                job_gbn = "1",
                mcode = info.mcode,
                shop_cd = info.shop_cd
            });

            if(checkCd.Count() > 0)
            {
                for(int j = 0; j < checkCd.Count(); j++) { 
                    for( int i= 0; i < MenuReq.data.Count(); i++)
                    {
                        if(MenuReq.data[i].menu_cd == checkCd[j])
                        {
                            MenuReq.data[i].cheackYN = "Y";
                        }
                    }
                }
            }
            // BlackDay
            var blackDay = await dgShop.Post<dynamic, Models.RequestModel.Request>("/api/ShopManagement/GetBlackDayCheck", new Models.RequestModel.Request
            {
                shop_cd = info.shop_cd
            });
            if (blackDay.code.Equals("00"))
            {
                if (checkCd.Count() > 0)
                {
                    for (int j = 0; j < checkCd.Count(); j++)
                    {
                        for (int i = 0; i < MenuReq.data.Count(); i++)
                        {
                            if (MenuReq.data[i].menu_cd == checkCd[j])
                            {
                                MenuReq.data[i].saleQnt = SaleQnt[j];
                            }
                        }
                    }
                }
            }


            ViewBag.blackDayCode = (blackDay.code != null ? blackDay.code : "99");

            EventSales MenuSales = new EventSales();
            if(MenuReq.code == "00")
            {
                if (!string.IsNullOrEmpty(eventAmt))
                {
                    ViewBag.eventGbn = eventGbn;
                    ViewBag.eventAmt = eventAmt;
                }else
                {
                    ViewBag.eventGbn = "1";

                }
              
                MenuSales.MenuList = MenuReq.data;
                return PartialView("MenuInfo", MenuSales);
            }

            ModelState.AddModelError("", "메뉴를 가져오지못했습니다. 고객센터에 문의하세요");

            return PartialView("MenuInfo", new EventMenu());
            
        }
        [HttpPost]
        public async Task<IActionResult> EventSave(UnExpentedEventViewModelV2 model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            var systemTime = DateTime.Now;
            var replceEndTime = model.end_time.Replace(":", "");
            TimeSpan ts = new TimeSpan(23,59,0);
            //if (systemTime.Minute > 30)
            //{
            //    string timehours = systemTime.addhours(1).tostring("hh");
            //    model.start_time = string.concat(timehours + ":" + "00");
            //}
            //else
            //{
            //    model.start_time = string.concat(model.start_time.substring(0, 2) + ":" + "30");
            //}

            

            if (string.IsNullOrEmpty(model.event_title))
            {
                return BadRequest(new
                {
                    Msg = "이벤트 제목을 입력해주세요."
                });
            }
            if (model.event_title.Length > 20)
            {
                return BadRequest(new
                {
                    Msg = "이벤트 제목 길이가 너무깁니다."
                });
            }
            if(model.eventList == null)
            {
                return BadRequest(new
                {
                    Msg = "메뉴 등록 후 이용해주세요."
                });
            }
            var bodyContent = "";
            var RequestModel = new RequestLiveEvent
            {
                start_time = model.start_time.Replace(":", ""),
                end_time = model.end_time.Replace(":", ""),
                eventList = model.eventList,
                ins_name = info.shop_name,
                job_gbn = "I",
                event_title = model.event_title,
                shop_cd = info.shop_cd,
                
            };
            var req = await dgShop.Post<dynamic, RequestLiveEvent>("/api/Event/SetLiveEvent", RequestModel);

            if(req.code == "00")
            {
                bodyContent = JsonConvert.SerializeObject(RequestModel);
                nlogger.Info($"[ CEO UnExpectedEvent Success ,Shopcd === {info.shop_cd}, JsonBody = {bodyContent}");
                return Ok(new
                {
                    msg = "성공"
                });
            }

            bodyContent = JsonConvert.SerializeObject(RequestModel);
            nlogger.Info($"[ CEO UnExpectedEvent Faild ,Shopcd === {info.shop_cd}, JsonBody = {bodyContent}");
            return BadRequest(new
            {

                Msg = req.msg
            }) ;
        }
        [HttpPost]
        public async Task<IActionResult> EventStop(UnExpentedEventViewModelV2 model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            var bodyContent = "";
            var RequestModel = new RequestLiveEvent
            {
                ins_name = info.shop_name,
                job_gbn = "D",
                shop_cd = info.shop_cd,
            };
            var req = await dgShop.Post<dynamic, RequestLiveEvent>("/api/Event/SetLiveEvent", RequestModel);

            if (req.code == "00")
            {
                bodyContent = JsonConvert.SerializeObject(RequestModel);
                nlogger.Info($"[ CEO UnExpectedEvent STOP Success ,Shopcd === {info.shop_cd}, JsonBody = {bodyContent}");
                return Ok(new
                {
                    msg = "성공"
                });
            }
            bodyContent = JsonConvert.SerializeObject(RequestModel);
            nlogger.Info($"[ CEO UnExpectedEvent STOP Fail ,Shopcd === {info.shop_cd}, JsonBody = {bodyContent}");
            return BadRequest(new
            {
                Msg = "실패"
            });
        }
        [HttpPost]
        public async Task<IActionResult> MenuDelete(string idx)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(idx))
            {
                ModelState.AddModelError("", "메뉴가 존재하지않습니다.");
                return BadRequest(new
                {
                    code = "99",
                    Msg = "메뉴가 존재하지 않습니다."
                });
            }
            var eventReq = await dgShop.Post<dynamic, RequestShopEventNoUse>("/api/Event/MenuDelete", new RequestShopEventNoUse
            {
                job_gbn = "D",
                shop_cd = info.shop_cd,
                menu_cd = Convert.ToInt32(idx),
                ins_name = info.login_name
            });

            if (eventReq.code == "00")
            {
                nlogger.Info($"[ CEO UnExpectedEvent Table Delete Succses ,Shopcd === {info.shop_cd}, MST CODE === { eventReq.code }, MST MSG === { eventReq.msg }] ");
                return Ok(new
                {
                    code = "00",
                    Msg = "이벤트 등록이 되었습니다."
                });
            }
            nlogger.Info($"[ CEO UnExpectedEvent Table Delete Falid Error ,Shopcd === {info.shop_cd}, MST CODE === { eventReq.code }, MST MSG === { eventReq.msg }] ");
            return BadRequest(new
            {
                code = "99",
                Msg = eventReq.msg
            });
        }
        public string ShopBackGroundColor(int shopCode)
        {
            var color = "";
            var convertshopCd = Convert.ToInt32(shopCode);

            var switchColor = convertshopCd % 10;

            switch (switchColor)
            {
                case 0:
                    color = "#f8aba8";
                    break;
                case 1:
                    color = "#a8e2f8";
                    break;
                case 2:
                    color = "#b8e77b";
                    break;
                case 3:
                    color = "#a8c5f8";
                    break;
                case 4:
                    color = "#ffdd84";
                    break;
                case 5:
                    color = "#b3a8f8";
                    break;
                case 6:
                    color = "#f8a8f8";
                    break;
                case 7:
                    color = "#ffd0ad";
                    break;
                case 8:
                    color = "#a8d5f8";
                    break;
                case 9:
                    color = "#c8c8c8";
                    break;

            }

            return color;
        }
    }
}
