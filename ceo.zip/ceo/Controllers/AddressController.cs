﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class AddressController : Controller
    {
        private readonly DgShopApiService dgShop;

        public AddressController(DgShopApiService api)
        {
            dgShop = api;
        }

        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            Request req = new Request()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };
            var temp = await dgShop.Post<ShopAddress, Request>("Address", req);
            if (temp.code.Equals("00"))
            {
                return View(temp.data.SingleOrDefault());
            }

            return View(new ShopAddress());
        }

        [HttpPost]
        public async Task<IActionResult> Index(ShopAddress model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopAddress, RequestSetShopAddress>("Address/Update", new RequestSetShopAddress()
            {
                shop_cd = info.shop_cd,
                cccode = info.cccode,
                addr1 = model.addr1,
                addr2 = model.addr2,
                dest_jibun = model.dest_jibun,
                dong_name = model.dong_name,
                gungu_name = model.gungu_name,
                job_gbn = "1",
                lat = model.lat,
                lon = model.lon,
                mcode = info.mcode,
                mod_name = info.login_name,
                mod_ucode = info.login_code,
                road_dest_addr = model.road_dest_addr,
                road_dest_bd = model.road_dest_building,
                road_dest_dong = model.road_dest_dong,
                sido_name = model.sido_name,
                loc = model.loc
            });
            if (temp.code.Equals("00"))
            {
                return RedirectToAction("Index", "Store");
            }

            return View();
        }
    }
}
