﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    public class ErrorController : Controller
    {
        private readonly ILogger<ErrorController> logger;

        public ErrorController(ILogger<ErrorController> logger)
        {

            this.logger = logger;
        }
        public IActionResult Index()
        {
            return View();
        }

        [Route("Error/{statusCode}")]
        [HttpGet]
        public IActionResult HttpStatusCodeHandler(int statusCode)
        {
            var statusCodeResult = HttpContext.Features.Get<IStatusCodeReExecuteFeature>();

            switch(statusCode)
            {
                case 404:
                    {
                        ViewBag.ErrorMessage = "페이지를 찾을 수 없습니다.";
                        ViewBag.ErrorCode = "404";
                        //ViewBag.Path = statusCodeResult.OriginalPath;
                        //ViewBag.QS = statusCodeResult.OriginalQueryString;
                        //logger.LogWarning($"404 Error. Path = {statusCodeResult.OriginalPath} and QueryString = {statusCodeResult.OriginalQueryString}");
                        logger.LogWarning("404 Error");
                    }
                    return View("NotFound");
                    break;
                case 401:
                    {
                        ViewBag.ErrorMessage = "인증 에러로 페이지를 찾을 수 없습니다." ;
                        ViewBag.ErrorCode = "401";
                        //ViewBag.Path = statusCodeResult.OriginalPath;
                        //ViewBag.QS = statusCodeResult.OriginalQueryString;
                        //logger.LogWarning($"500 Error. Path = {statusCodeResult.OriginalPath} and QueryString = {statusCodeResult.OriginalQueryString}");
                        logger.LogWarning("401 Error");
                    }
                    return View("NotFound");
                    break;
                case 500:
                    {
                        ViewBag.ErrorMessage = "내부 서버 오류로 표시할 수 없음";
                        ViewBag.ErrorCode = "500";
                        //ViewBag.Path = statusCodeResult.OriginalPath;
                        //ViewBag.QS = statusCodeResult.OriginalQueryString;
                        //logger.LogWarning($"500 Error. Path = {statusCodeResult.OriginalPath} and QueryString = {statusCodeResult.OriginalQueryString}");
                        logger.LogWarning("500 Error");
                    }
                    return View("InternalServer");
                    break;
                case 502:
                    {
                        ViewBag.ErrorMessage = "올바른 요청을 받지 못했습니다.";
                        ViewBag.ErrorCode = "502";
                        //ViewBag.Path = statusCodeResult.OriginalPath;
                        //ViewBag.QS = statusCodeResult.OriginalQueryString;
                       // logger.LogWarning($"502 Error. Path = {statusCodeResult.OriginalPath} and QueryString = {statusCodeResult.OriginalQueryString}");
                       logger.LogWarning("502 Error");
                    }
                    return View("InternalServer");
                    break;
            }

            return View("NotFound");
        }

        [Route("Error")]
        [AllowAnonymous]
        [HttpGet]
        public IActionResult Error()
        {
            var exceptionDetails = HttpContext.Features.Get<IExceptionHandlerPathFeature>();

            ViewBag.ExceptionPath = exceptionDetails.Path;
            ViewBag.ExceptionMessage = exceptionDetails.Error.Message;
            ViewBag.StackTrace = exceptionDetails.Error.StackTrace;

            logger.LogError($"Path { exceptionDetails.Path } threw an Exception { exceptionDetails.Error} StackTrace = {exceptionDetails.Error.StackTrace}");

            return View("Error");
        }
    }
}
