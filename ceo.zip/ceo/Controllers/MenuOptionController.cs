﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PosWebApp.Common;
using PosWebApp.Models.Admin.Request;
using PosWebApp.Models.Admin.Response;
using PosWebApp.Services.Admin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MenuOptionController : ControllerBase
    {
        private readonly AdminApi adminApi;

        public MenuOptionController(AdminApi adminApi)
        {
            this.adminApi = adminApi;
        }


        [HttpPost("Update")]
        public async Task<Result<ResponseOptionList>> MenuOptionListUsingAdminApi(
            RequestOptionList model)
        {
            Result<ResponseOptionList> result = new Result<ResponseOptionList>();

            try
            {
                foreach(var item in model.option_list)
                {
                    if(string.IsNullOrEmpty(item.job_gbn) || !(item.job_gbn.Equals("U") || item.job_gbn.Equals("I") || item.job_gbn.Equals("D")))
                    {
                        result.code = "99";
                        result.msg = "유효하지 않은 작업입니다.";
                        return result;
                    }
                }

                foreach (var item in model.option_list)
                {
                    if (item.job_gbn.Equals("update"))
                    {
                        var msg = await adminApi.Put<dynamic, dynamic>("Optioon", item);
                        if (!msg.Equals("00")) throw new Exception($"{msg.msg} {item.optionName}");
                    }
                    else if (item.job_gbn.Equals("insert"))
                    {
                        var msg = await adminApi.Post<dynamic, dynamic>("Option", item);
                        if (!msg.Equals("00")) throw new Exception($"{msg.msg} {item.optionName}");
                    }
                    else if (item.job_gbn.Equals("delete"))
                    {
                        var msg = await adminApi.Delete<dynamic>($"Option/{item.optionCd}");
                        if (!msg.Equals("00")) throw new Exception($"{msg.msg} {item.optionName}");
                    }
                }

                result.code = "00";
                result.msg = "성공";

            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
    }
}
