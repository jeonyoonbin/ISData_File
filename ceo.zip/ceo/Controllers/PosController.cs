﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.jwt;
using PosWebApp.Models;
using PosWebApp.Models.Pos;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.Reservation.Apply.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.Reservation;
using PosWebApp.Services.ShopMall;
using PosWebApp.ViewModels;
using PosWebApp.ViewModels.Pos;
using Shyjus.BrowserDetection;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    public class PosController : Controller
    {
        private readonly string DaeguDbConnectionString;
        private readonly IDaeguDatabase db;
        private readonly DgShopApiService dgShop;
        private readonly ReservationService_T reservationService;
        private readonly IConfiguration config;
        private readonly ILogger _logger;
        private readonly IBrowserDetector browserDetector;
        private readonly ShopMallService shopMall;
        private readonly string ReservationFlag;

#if JWT_TEST_CODE
        private readonly IJwtAuthenticationManager jwtAuthenticationManager;
        private readonly ILoginService _loginService;
#endif

        public PosController(IConfiguration configuration, IDaeguDatabase daeguDb, DgShopApiService api, ILogger<PosController> logger, ReservationService_T reservationService
            /*, IBrowserDetector browserDetector*/
#if Mall_TEST_CODE
            ,ShopMallService shopMall
#endif
#if JWT_TEST_CODE
            , IJwtAuthenticationManager jwtAuthenticationManager
            , ILoginService loginService
#endif
            )
        {
            //this.browserDetector = browserDetector;
            this.DaeguDbConnectionString = configuration.GetValue<string>("database:IsDaegu");
            config = configuration;
            dgShop = api;
            this.reservationService = reservationService;
            _logger = logger;
            this.ReservationFlag = configuration.GetValue<string>("inspection:ReservationFlag");
#if JWT_TEST_CODE
            this.jwtAuthenticationManager = jwtAuthenticationManager;
            _loginService = loginService;
#endif
#if Mall_TEST_CODE
            this.shopMall = shopMall;
#endif 
        }

        public IActionResult LoginPass()
        {
            //string sessionString = HttpContext.Session.GetString("shopwwwInfo");

            //ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            //info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            //if (string.IsNullOrEmpty(sessionString))
            //{
            //    return View();
            //}
            //// 2021.07.07 로그
            //var req = await dgShop.Post<CodeMsg, RequestSystemInout>("inout", new RequestSystemInout
            //{
            //    cccode = info.cccode,
            //    inout_gbn = "O",
            //    job_gbn = "",
            //    mac_address = "",
            //    user_id = info.shop_id,
            //    pc_name = "테스트중",
            //    mcode = info.mcode,
            //    pc_ip = HttpContext.Connection.RemoteIpAddress.ToString()
            //});
            return View();
        }

        [HttpGet]
        public IActionResult Index()
        {
            // jwcho 2021.03.11 사용 중인 1개의 가맹점만 가져온다.
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            if (sessionString == null)
            {
                return RedirectToAction("Login", "Pos");
            }

            var info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ViewData["shopName"] = info.shop_name;

            return View(info);
        }


        [HttpPost]
        public async Task<IActionResult> Index(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var temp = HttpContext.Connection.RemoteIpAddress;
            var headerValue = HttpContext.Request.Headers["User-Agent"];

            Result<DaeguShopInfo> shopInfo = await dgShop.Post<DaeguShopInfo, RequestLogin>("ShopLogin", new RequestLogin()
            {
                id = model.id,
                password = model.password
            });

            if (shopInfo.data == null)
            {
                ModelState.AddModelError(string.Empty, "사용자 정보가 없습니다");
                return View(model);
            }


            ViewBag.shopInfos = shopInfo;

            return View();
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult Login()
        {
#if TESTGBN
                ViewBag.testCode = "Y";
#endif

            //var browser = this.browserDetector.Browser;

            //if (browser.Name == BrowserNames.Edge || browser.Name == BrowserNames.Chrome
            //    || browser.Name == BrowserNames.EdgeChromium || browser.Name == BrowserNames.Safari)
            //{
                return View();
            //}
            //else
            //{
            //    return Redirect("https://ceo.daeguro.co.kr/_supportService.html");
            //}
            
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            
            if (string.IsNullOrEmpty(sessionString))
            {
                return RedirectToAction("LoginPass", "Pos");
            }
            
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            // 2021.07.07 로그
            var req = await dgShop.Post<CodeMsg, RequestSystemInout>("inout", new RequestSystemInout
            {
                cccode = info.cccode,
                inout_gbn = "O",
                job_gbn = "",
                mac_address = "",
                user_id = info.shop_id,
                pc_name = "테스트중",
                mcode = info.mcode,
                shop_cd = info.shop_cd,
                pc_ip = HttpContext.Connection.RemoteIpAddress.ToString(),
                pgm_name = "사장님사이트",
            });
            //HttpContext.Session.SetString("shopDefaultInfo", string.Empty);
            HttpContext.Session.Clear();

            return RedirectToAction("LoginPass", "Pos");
        }

        [AllowAnonymous] 
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            //var temp = HttpContext.Connection.RemoteIpAddress;
            //var headerValue = HttpContext.Request.Headers["User-Agent"];

            //var hostEntry = Dns.GetHostEntry(HttpContext.Connection.RemoteIpAddress);
            //Debug.WriteLine(hostEntry.HostName);


            RequestLogin login = new RequestLogin()
            {
                id = model.id,
                password = Utils.Sha256(model.password)
            };
#if TESTGBN
            if(model.otppass == "webTest"){
                ViewBag.testCode = "Y";
                //return RedirectToAction("Index", "Main");

            }else {
                return Redirect("https://ceo.daeguro.co.kr/");
            }
#endif
#if DefensePW
            if (model.defensePW == "!dlstjdepdlxk")
            {
                //return RedirectToAction("Index", "Main");
            }
            else
            {
                //return Redirect("https://ceo.daeguro.co.kr/");

                ModelState.AddModelError(string.Empty, "잘못접근한 상태이십니다.");
                return View(model);
            }
#endif


           // Result<ShopSessionDefaultInfo> shopInfo = await dgShop.Post<ShopSessionDefaultInfo, RequestLogin>("Default", login);

            var shopInfo = await dgShop.Post<ShopSessionDefaultInfo, RequestLoginInfo>("/api/ShopManagement/GetLogin", new RequestLoginInfo
            {
               job_gbn = "1",
               id = login.id,
               password = login.password
            });
            if (shopInfo.data == null || shopInfo.data.Count == 0)
            {
                ModelState.AddModelError(string.Empty, shopInfo.msg);
                return View(model);
            }

            // jwcho 2021.03.11 사용 중인 1개의 가맹점만 가져온다.
            var myShop = shopInfo.data.SingleOrDefault<ShopSessionDefaultInfo>(x => x.use_gbn.Equals("Y"));
            if (myShop == null)
            {
                ModelState.AddModelError(string.Empty, "대구로 사용 미승인 상태입니다.");
                return View(model);
            }
            var reser = await reservationService.Get<ResponseReservationApply>("apply?shopCode=" + myShop.shop_cd);

            if (!reser.code.Equals("00"))
            {
                ModelState.AddModelError(string.Empty, "대구로 사용 미승인 상태입니다.");
                return View(model);
            }

            //2023.03.16 멀티샵 infomation
            var mulitShop = await dgShop.Post<ResponseShopAccountInfo, Request>("/api/ShopManagement/AccInfo", new Models.RequestModel.Request
            {
                cccode = myShop.cccode,
                shop_cd = myShop.shop_cd
            });

            if (mulitShop.code.Equals("00"))
            {
                var mulitSingle = mulitShop.data.SingleOrDefault();

                myShop.multMasterCd = mulitSingle.multiShopCd;
                myShop.multshopYn = mulitSingle.multiShopYn;
                myShop.representativeYn = mulitSingle.representativeYn;
            }
           
            myShop.login_code = myShop.shop_cd;
            myShop.login_name = model.id;
            myShop.u_code = "S";
            myShop.reservationYN = reser.data.SingleOrDefault().status;

#if Mall_TEST_CODE

            var shopmall = await shopMall.Post<MallModel.Shop.RequestUserInfo>("/api/V1/users/exist/", new MallModel.Shop.RequestUserInfo
            {
                user_id = model.id,
                password = Utils.SetMD5(model.password)
            } , "GET");

            var requestShopMall = shopmall.Result;

            if (requestShopMall[0].result_info.code.Equals("1000"))
            {
                if (requestShopMall[1].query_result.code.Equals("OK"))
                {
                    myShop.mallYN = "Y";
                }
                else
                {
                    myShop.mallYN = "N";
                }
            }
          
#endif 

#if JWT_TEST_CODE
            //var generatedToken = jwtAuthenticationManager.Authenticate(model.id, model.password);
            var responseLogin = await _loginService.AuthenticateAsync(model);
            if(responseLogin == null)
            {
                ModelState.AddModelError(string.Empty, "사용자 정보가 없습니다");
                return View(model);
            }

            HttpContext.Session.SetString("jwt_token", responseLogin.token);
#endif
            var sessionString = JsonConvert.SerializeObject(myShop);
            HttpContext.Session.SetString("shopDefaultInfo", sessionString);


            var now = DateTime.Now;
            var EndTime = DateTime.ParseExact(ReservationFlag, "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture);
            var diffTime = DateTime.Compare(EndTime, now);

           


            if (myShop.shop_type == "9")
            {
                if (myShop.reservationYN.Equals("30"))
                {
                    if (diffTime > 0)
                    {
                        HttpContext.Response.Cookies.Append("reser", "N");

                        return RedirectToAction("index", "Main");
                    }
                    else
                    {
                        HttpContext.Response.Cookies.Append("reser", "Y");

                        return RedirectToAction("index", "Reservation");
                    }
                    //HttpContext.Response.Cookies.Append("reser", "Y");

                    //return RedirectToAction("index", "Reservation");
                }
                else if (myShop.reservationYN.Equals("20"))
                {
                    ModelState.AddModelError(string.Empty, "예약서비스 심사중입니다. 심사완료 후 이용부탁드립니다.");
                    return View(model);
                }
                else if(myShop.reservationYN.Equals("00"))
                {
                    ModelState.AddModelError(string.Empty, "예약서비스 신청 후 이용바랍니다. ");
                    return View(model);
                }
            }




            if (myShop.reservationYN.Equals("30"))
            {
                HttpContext.Response.Cookies.Append("reser", "N");

                return RedirectToAction("index", "Main");
            }
            else if (myShop.reservationYN.Equals("00") || myShop.reservationYN.Equals("20"))
            {
                HttpContext.Response.Cookies.Append("reser", "N");
                //배달/포장만하는경우 -> 신청페이지
                // 둘다잇을경우 -> main/index
                //if (myShop.reservationYN.Equals("20"))
                //{
                //    ModelState.AddModelError(string.Empty, "예약서비스 심사중입니다. 심사완료 후 이용부탁드립니다.");
                //    return View(model);
                //}

            }
            //else
            //{
           // HttpContext.Response.Cookies.Append("reser", "N");
            //}

            //HttpContext.Response.Cookies.Append("reser", )

            // 2021.05.24 jwcho 비밀번호 초기화 코드 주석. 활성화 시기 확인 필요
            //if (model.password.Equals("daeguro"))
            //{
            //    return RedirectToAction("MyPass", "MyAccount");
            //}
            

            return RedirectToAction("Index", "Main");
        }

        /// <summary>
        /// 가맹점 깃발 꽂기
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> ShopCreateFlag(ShopFlagDataViewModel viewModel)
        {
            // TODO: 전화 번호를 새로 입력 받아야 하나 ?
            if (!ModelState.IsValid)
            {
                return View(viewModel);
            }

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (info == null) return View();

            ShopFlagData model = new ShopFlagData()
            {
                addr = viewModel.buildNo,
                updateUserCode = info.shop_cd.ToString(),
                updateUserName = info.shop_name,
                cccode = info.cccode,
                shopCode = info.shop_cd.ToString(),
                memo = viewModel.memo,

                displayShopName = viewModel.displayShopName.Length > 0 ? viewModel.displayShopName : info.shop_name,
                displayShopTelno = viewModel.displayShopTelno.Length > 0 ? viewModel.displayShopTelno : "",
                flagSequence = viewModel.flagSequence,
                lat = viewModel.lat,
                lon = viewModel.lon,
                road = viewModel.road,
                type = viewModel.type,
                useGbn = viewModel.useGbn
            };


            DaeguDatabase db = new DaeguDatabase(DaeguDbConnectionString, config);
            var temp = await db.ShopCreateFlag(model);

            return View(temp);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }

}
