﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Models.Tax.Request;
using PosWebApp.Models.Tax.Response;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Tax;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class Surtax : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly NLog.Logger nlogger;
        public Surtax(DgShopApiService api)
        {
            dgShop = api;
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }
        public async Task<IActionResult> Index(TaxListViewModel viewModel)
        {

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if(string.IsNullOrEmpty(viewModel.from) || string.IsNullOrEmpty(viewModel.to))
            {
                viewModel.from = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd");
                viewModel.to = DateTime.Now.ToString("yyyy-MM-dd");
                viewModel.options = "0";
                viewModel.ismeet = viewModel.meetYn.Equals("Y") ? true : false; 
            }

            var req = await dgShop.Post<ResponseTax, RequestTax>("/api/Tax/GetTaxList", new RequestTax
            { 
                job_gbn = "1",
                from = viewModel.from.Replace("-", ""),
                to = viewModel.to.Replace("-", ""),
                meetYn = viewModel.meetYn,
                shop_cd = info.shop_cd
            });
            if (req.code.Equals("00"))
            {
                TaxListViewModel model = new TaxListViewModel();
                model.list = new List<ResponseTax>();
                model.from = viewModel.from;
                model.to = viewModel.to;
                model.options = viewModel.options;
                model.meetYn = viewModel.meetYn;
                model.ismeet = viewModel.ismeet;
                model.list = req.data;


                return View(model);
            }
            ViewBag.Error = req.msg;
            ViewBag.Code = req.code;

            TaxListViewModel errorModel = new TaxListViewModel();


            return View(errorModel);
        }
        public async Task<IActionResult> PrintTax(string from, string to, bool ismeet)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var req = await dgShop.Post<ResponseTax, RequestTax>("/api/Tax/GetTaxList", new RequestTax
            {
                job_gbn = "1",
                from = from.Replace("-", ""),
                to = to.Replace("-", ""),
                meetYn = ismeet ? "Y" : "N",
                shop_cd = info.shop_cd
            });

            if (req.code.Equals("00"))
            {
                TaxListViewModel model = new TaxListViewModel();
                model.list = new List<ResponseTax>();
                model.from = from.Replace("-", ". ");
                model.to = to.Replace("-", ". ");
                model.ismeet = ismeet;
                model.list = req.data;

                long Samt = 0;
                long Svat_amt = 0;
                long Stotal_amt = 0;

                long Pcnt = 0;
                long Pamt = 0;
                long Pvat_amt = 0;
                long Ptotal_amt = 0;

                for(int i = 0; i < req.data.Count(); i++)
                {
                    Samt += Convert.ToInt64(req.data[i].card_amt) + Convert.ToInt64(req.data[i].cash_amt) + Convert.ToInt64(req.data[i].etc_amt);
                    Svat_amt += Convert.ToInt64(req.data[i].card_vat_amt) + Convert.ToInt64(req.data[i].cash_vat_amt) + Convert.ToInt64(req.data[i].etc_vat_amt);
                    Stotal_amt += Convert.ToInt64(req.data[i].total_card_amt) + Convert.ToInt64(req.data[i].total_cash_amt) + Convert.ToInt64(req.data[i].total_etc_amt);

                    Pcnt = Convert.ToInt64(req.data[i].pg_fee_cnt) + Convert.ToInt64(req.data[i].app_fee_cnt);
                    Pamt = Convert.ToInt64(req.data[i].pg_fee_amt) + Convert.ToInt64(req.data[i].app_fee_amt);
                    Pvat_amt = Convert.ToInt64(req.data[i].pg_fee_vat_amt) + Convert.ToInt64(req.data[i].app_fee_vat_amt);
                    Ptotal_amt = Convert.ToInt64(req.data[i].total_pg_fee_amt) + Convert.ToInt64(req.data[i].total_app_fee_amt);
                }

                ViewBag.Samt = Samt;
                ViewBag.Svat_amt = Svat_amt;
                ViewBag.Stotal_amt = Stotal_amt;

                ViewBag.Pcnt = Pcnt;
                ViewBag.Pamt = Math.Abs(Pamt);
                ViewBag.Pvat_amt = Math.Abs(Pvat_amt);
                ViewBag.Ptotal_amt = Math.Abs(Ptotal_amt);

                var today = DateTime.Now.ToString("yyyy. MM. dd");
                ViewBag.today = today;

                return PartialView("PrintModal", model);
            }

            return BadRequest(new
            {
                Msg = "데이터 조회중 에러가 발생했습니다. 관리자에게 문의해주세요"
            });
            
        }
        #region 매출
        [HttpPost]
        public async Task<IActionResult> ExcelSales(string from, string to, bool ismeet)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            nlogger.Info($"[ CEO Surtax ExcelSales Start ,Shopcd === {info.shop_cd}, from == {from}, to == {to}, meetYn == {ismeet}");
            try
            {
                using (var workbook = new XLWorkbook())
                {

                    var worksheet = workbook.Worksheets.Add("부가세신고자료(매출)");
                    worksheet.Cell(1, 1).Value = "부가세신고자료(매출)";
                    worksheet.Cell(1, 1).Style.Font.SetFontSize(23);
                    worksheet.Range(worksheet.Cell(1, 1), worksheet.Cell(3, 7)).Merge();
                    worksheet.Cell(1, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(1, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    worksheet.Cell(4, 1).Value = "조회일" + " : " + DateTime.Now.ToString("yyyy-MM-dd");
                    worksheet.Range(worksheet.Cell(4, 1), worksheet.Cell(4, 7)).Merge();
                    worksheet.Cell(4, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;

                    worksheet.Cell(5, 1).Value = "조회 기간" + " : " + from + " ~ " + to;
                    worksheet.Range(worksheet.Cell(5, 1), worksheet.Cell(5, 7)).Merge();
                    worksheet.Cell(5, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;

                    /*
                     * Item Header
                     */
                    worksheet.Cell(6, 1).Value = "주문일시";
                    worksheet.Cell(6, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 2).Value = "주문번호";
                    worksheet.Cell(6, 2).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 3).Value = "매출구분";
                    worksheet.Cell(6, 3).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 4).Value = "결제수단";
                    worksheet.Cell(6, 4).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 5).Value = "공급가액";
                    worksheet.Cell(6, 5).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 6).Value = "부가세";
                    worksheet.Cell(6, 6).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 7).Value = "합계";
                    worksheet.Cell(6, 7).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    /*
                     * Items select
                     */
                    var dgresult = new RequestTax
                    {
                        job_gbn = "3",
                        from = from.Replace("-", ""),
                        to = to.Replace("-", ""),
                        meetYn = ismeet ? "Y" : "N",
                        shop_cd = info.shop_cd
                    };

                    var req = await dgShop.Post<ResponseTax, RequestTax>("/api/Tax/GetTaxList", dgresult);

                    var JsonBody = JsonConvert.SerializeObject(dgresult);
                    nlogger.Info($"[ CEO Surtax ExcelSales Data ,Shopcd === {info.shop_cd},  Body === {JsonBody}");
                    /*
                     * Item Insert 
                     * 7 row Data binding
                     */
                    if (req.code.Equals("00"))
                    {
                        for(int i = 0; i < req.data.Count(); i++)
                        {
                            worksheet.Cell(7 + i, 1).Value = req.data[i].order_time;
                            worksheet.Cell(7 + i, 2).Value = req.data[i].order_no;
                            worksheet.Cell(7 + i, 3).Value = req.data[i].charge_gbn_name;
                            worksheet.Cell(7 + i, 4).Value = req.data[i].pay_gbn_name;
                            worksheet.Cell(7 + i, 5).Value = req.data[i].charge_amt;
                            worksheet.Cell(7 + i, 6).Value = req.data[i].charge_vat_amt;
                            worksheet.Cell(7 + i, 7).Value = req.data[i].total_charge_amt;
                            
                            
                           if( i == (req.data.Count() - 1))
                            {
                                worksheet.Range(worksheet.Cell(7, 5), worksheet.Cell(7 + (req.data.Count() - 1), 7)).Style
                                .NumberFormat.Format = "#,##0";
                                worksheet.Range(worksheet.Cell(7, 1), worksheet.Cell(7 + (req.data.Count() - 1), 7)).Style
                                   .Border.SetTopBorder(XLBorderStyleValues.Thin)
                                   .Border.SetRightBorder(XLBorderStyleValues.Thin)
                                   .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                                   .Border.SetInsideBorder(XLBorderStyleValues.Thin)
                                   .Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                            }
                        }
                        
                    }

                    worksheet.Range(worksheet.Cell(1, 1), worksheet.Cell(5, 7)).Style
                       .Border.SetTopBorder(XLBorderStyleValues.Thin)
                       .Border.SetRightBorder(XLBorderStyleValues.Thin)
                       .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                       .Border.SetInsideBorder(XLBorderStyleValues.Thin);

                    worksheet.Range(worksheet.Cell(6, 1), worksheet.Cell(6, 7)).Style
                       .Border.SetTopBorder(XLBorderStyleValues.Thin)
                       .Border.SetRightBorder(XLBorderStyleValues.Thin)
                       .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                       .Border.SetInsideBorder(XLBorderStyleValues.Thin)
                       .Fill.SetBackgroundColor(XLColor.LightSlateGray)
                       .Font.SetFontColor(XLColor.White);

                    worksheet.Columns("A", "G").Width = 22;

                    worksheet.Rows().Height = 16.5;
                    worksheet.Rows().AdjustToContents();
                    worksheet.SheetView.ZoomScale = 125;
                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        await Task.Delay(100);
                        nlogger.Info($"[ CEO Surtax ExcelSales Success ,Shopcd === {info.shop_cd}");
                        return File(content,
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            string.Concat("부가세신고자료(매출)_", DateTime.Now.ToString("yyyyMMddHHmmss"), ".xlsx"));
                    }
                }
            }
            catch(Exception e)
            {
                nlogger.Info($"[ CEO Surtax ExcelSales Fail ,Shopcd === {info.shop_cd},Error Msg ====== {e.Message.ToString()}");
                return BadRequest();
            }
        }
        #endregion
        #region 매입
        [HttpPost]
        public async Task<IActionResult> ExcelPurchase(string from, string to, bool ismeet)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            nlogger.Info($"[ CEO Surtax ExcelPurchase Start ,Shopcd === {info.shop_cd}, from == {from}, to == {to}, meetYn == {ismeet}");
            try
            {
                using (var workbook = new XLWorkbook())
                {

                    var worksheet = workbook.Worksheets.Add("부가세신고자료(매입)");
                    worksheet.Cell(1, 1).Value = "부가세신고자료(매입)";
                    worksheet.Cell(1, 1).Style.Font.SetFontSize(23);
                    worksheet.Range(worksheet.Cell(1, 1), worksheet.Cell(3, 8)).Merge();
                    worksheet.Cell(1, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(1, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    worksheet.Cell(4, 1).Value = "조회일" + " : " + DateTime.Now.ToString("yyyy-MM-dd");
                    worksheet.Range(worksheet.Cell(4, 1), worksheet.Cell(4, 8)).Merge();
                    worksheet.Cell(4, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;

                    worksheet.Cell(5, 1).Value = "조회 기간" + " : " + from + " ~ " + to;
                    worksheet.Range(worksheet.Cell(5, 1), worksheet.Cell(5, 8)).Merge();
                    worksheet.Cell(5, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;

                    /*
                     * Item Header
                     */
                    worksheet.Cell(6, 1).Value = "일자";
                    worksheet.Cell(6, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 2).Value = "주문번호";
                    worksheet.Cell(6, 2).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 3).Value = "매입구분";
                    worksheet.Cell(6, 3).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 4).Value = "영수증구분";
                    worksheet.Cell(6, 4).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 5).Value = "승인번호";
                    worksheet.Cell(6, 5).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 6).Value = "공급가액";
                    worksheet.Cell(6, 6).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 7).Value = "부가세";
                    worksheet.Cell(6, 7).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(6, 8).Value = "합계";
                    worksheet.Cell(6, 8).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    /*
                     * Items select
                     */
                    var dgresult = new RequestTax
                    {
                        job_gbn = "5",
                        from = from.Replace("-", ""),
                        to = to.Replace("-", ""),
                        meetYn = ismeet ? "Y" : "N",
                        shop_cd = info.shop_cd
                    };

                    var req = await dgShop.Post<ResponseTax, RequestTax>("/api/Tax/GetTaxList", dgresult);

                    var JsonBody = JsonConvert.SerializeObject(dgresult);
                    nlogger.Info($"[ CEO Surtax ExcelPurchase Data ,Shopcd === {info.shop_cd},  Body === {JsonBody}");
                    /*
                     * Item Insert 
                     * 7 row Data binding
                     */
                    if (req.code.Equals("00"))
                    {
                        for (int i = 0; i < req.data.Count(); i++)
                        {
                            worksheet.Cell(7 + i, 1).Value = req.data[i].order_time;
                            worksheet.Cell(7 + i, 2).Value = req.data[i].order_no;
                            worksheet.Cell(7 + i, 3).Value = req.data[i].charge_gbn_name;
                            worksheet.Cell(7 + i, 4).Value = req.data[i].pay_gbn_name;
                            worksheet.Cell(7 + i, 5).Value = req.data[i].app_no;
                            worksheet.Cell(7 + i, 6).Value = req.data[i].charge_amt;
                            worksheet.Cell(7 + i, 7).Value = req.data[i].charge_vat_amt;
                            worksheet.Cell(7 + i, 8).Value = req.data[i].total_charge_amt;

                            if( i == (req.data.Count() - 1))
                            {
                                worksheet.Range(worksheet.Cell(7, 6), worksheet.Cell(7 + (req.data.Count() - 1), 8)).Style
                               .NumberFormat.Format = "#,##0";
                                worksheet.Range(worksheet.Cell(7, 1), worksheet.Cell(7 + (req.data.Count() - 1), 8)).Style
                                   .Border.SetTopBorder(XLBorderStyleValues.Thin)
                                   .Border.SetRightBorder(XLBorderStyleValues.Thin)
                                   .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                                   .Border.SetInsideBorder(XLBorderStyleValues.Thin)
                                   .Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                            }
                        }
                        }
                       

                    worksheet.Range(worksheet.Cell(1, 1), worksheet.Cell(5, 8)).Style
                       .Border.SetTopBorder(XLBorderStyleValues.Thin)
                       .Border.SetRightBorder(XLBorderStyleValues.Thin)
                       .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                       .Border.SetInsideBorder(XLBorderStyleValues.Thin);

                    worksheet.Range(worksheet.Cell(6, 1), worksheet.Cell(6, 8)).Style
                       .Border.SetTopBorder(XLBorderStyleValues.Thin)
                       .Border.SetRightBorder(XLBorderStyleValues.Thin)
                       .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                       .Border.SetInsideBorder(XLBorderStyleValues.Thin)
                       .Fill.SetBackgroundColor(XLColor.LightSlateGray)
                       .Font.SetFontColor(XLColor.White);

                    worksheet.Columns("A", "H").Width = 22;

                    worksheet.Rows().Height = 16.5;
                    worksheet.Rows().AdjustToContents();
                    worksheet.SheetView.ZoomScale = 125;
                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        await Task.Delay(100);
                        nlogger.Info($"[ CEO Surtax ExcelSales Success ,Shopcd === {info.shop_cd}");
                        return File(content,
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            string.Concat("부가세신고자료(매입)_", DateTime.Now.ToString("yyyyMMddHHmmss"), ".xlsx"));
                    }
                }
            }
            catch (Exception e)
            {
                nlogger.Info($"[ CEO Surtax ExcelSales Fail ,Shopcd === {info.shop_cd}, Error Msg ====== {e.Message.ToString()}");
                return BadRequest();
            }
        }
        #endregion
    }
}
