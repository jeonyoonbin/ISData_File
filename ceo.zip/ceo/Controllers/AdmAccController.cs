﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.Models.AdmAcc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    /// <summary>
    /// 어드민 사이트에서 호출
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class AdmAccController : ControllerBase
    {
        private string doznUrl = "http://dozn1.insungdata.com:9100/dozn/account/json/";
        private string real_doznUrl = "http://dozn2.insungdata.com:9200/dozn/account/json";
        private string urlappend = "1/IS_DAEGU/1/1/0";

        [HttpGet("Get")]
        public string Get()
        {
            return doznUrl;
        }
        [HttpPost("confirm")]
        public async Task<dynamic> confirm(RequestAdmAccountConfirm info)
        {
            string Url = string.Join('/', info.bank_code, info.account_no, info.account_owner, urlappend);

            HttpClient httpClient = new HttpClient();
            httpClient.BaseAddress = new Uri(doznUrl);
            httpClient.DefaultRequestHeaders.Add("Accept", "application/json");

            var request = new HttpRequestMessage(HttpMethod.Get, Url);

            var response = await httpClient.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                var responseStream = await response.Content.ReadAsStringAsync();

                return responseStream;

            }

            return BadRequest();
        }
        [HttpPost("confrim_v2")]
        public async Task<dynamic> confirm_v2(RequestAdmAccountConfirmV2 info)
        {
            HttpClient httpClient = new HttpClient();
            httpClient.BaseAddress = new Uri(real_doznUrl);

            httpClient.DefaultRequestHeaders.Add("Accept", "application/json");


            var formDataContent = new MultipartFormDataContent();
            var request = new HttpRequestMessage(HttpMethod.Post, real_doznUrl);
            //

            formDataContent.Add(new StringContent(info.bankCd), "bankCd");
            formDataContent.Add(new StringContent(info.accountNo), "accountNo");
            formDataContent.Add(new StringContent(info.accountNm), "accountNm");
            formDataContent.Add(new StringContent(info.accountGb), "accountGb");
            formDataContent.Add(new StringContent(info.systemGb), "systemGb");
            formDataContent.Add(new StringContent(info.mcode), "mcode");
            formDataContent.Add(new StringContent(info.cccode), "cccode");
            formDataContent.Add(new StringContent(info.ucode), "ucode");
            request.Content = formDataContent;
            var response = await httpClient.PostAsync(request.RequestUri, request.Content);

            if (response.IsSuccessStatusCode)
            {
                var responseStream = await response.Content.ReadAsStringAsync();

                return responseStream;

            }

            return BadRequest();
        }
    }
}
