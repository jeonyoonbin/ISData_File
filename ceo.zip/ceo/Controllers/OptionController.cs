﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.Admin.Request;
using PosWebApp.Models.Admin.Response;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Admin;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Option;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class OptionController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly AdminApi adminAPI;
        private readonly NLog.Logger nlogger;

        public OptionController(IConfiguration configuration, IDaeguDatabase daeguDb, DgShopApiService api, AdminApi adminApi)
        {
            dgShop = api;
            adminAPI = adminApi;
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }

        #region 옵션 그룹

        public async Task<IActionResult> OptionGroupInquiry(int id, string code)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (id > 0)
            {
                RequestSetOptionMenuGroup selectModel = new RequestSetOptionMenuGroup()
                {
                    cccode = info.cccode,
                    mcode = info.mcode,
                    shop_cd = info.shop_cd,
                    mod_name = info.login_name,
                    menu_cd = id.ToString()
                };

                Result<ShopMenuOptionGroup> temp = await dgShop.Post<ShopMenuOptionGroup, RequestSetOptionMenuGroup>("MenuOptionGroupList", selectModel);

                if (temp.code == "00")
                {
                    TempData["menu_cd"] = id;
                    ViewBag.group_cd = code;
                    return View(temp.data);
                }
                else if (temp.code != "00")
                {
                    ViewBag.Message = "조회에 실패하였습니다.";
                    return View();
                }
            }
            ViewBag.Message = "메뉴 옵션 조회에 실패하였거나, 조회에 실패하였습니다.";
            return View();
        }
        public IActionResult OptionGroupAdd(int id, int seq)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (id > 0)
            {
                ShopMenuOptionGroup tempModel = new ShopMenuOptionGroup()
                {
                    menu_cd = id.ToString(),
                    sort_seq = seq
                };

                return View(tempModel);
            }


            return View();
        }
        [HttpPost]
        public async Task<IActionResult> OptionGroupAdd(ShopMenuOptionGroup shopmodel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (shopmodel.option_group_name == null)
            {
                ModelState.AddModelError("", "메뉴 옵션 그룹 이름을 등록해주세요.");
                return View(shopmodel);
            }

            if (!ModelState.IsValid)
            {
                return View();
            }
            if (shopmodel.min_count > shopmodel.multi_count)
            {
                ModelState.AddModelError("min_count", "최소값은 최대를 넘을수없습니다.");
                return View(shopmodel);
            }
            RequestSetOptionMenuGroup insertModel = new RequestSetOptionMenuGroup()
            {
                cccode = info.cccode,
                mcode = info.mcode,
                shop_cd = info.shop_cd,
                mod_name = info.login_name,

                job_gbn = "I",
                group_name = shopmodel.option_group_name,
                group_memo = shopmodel.option_group_memo,
                group_file_name = shopmodel.ogroup_file_name,

                sort_seq = shopmodel.sort_seq,
                menu_cd = shopmodel.menu_cd,
                multi_yn = shopmodel.multi_yn,
                multi_count = shopmodel.multi_count,
                req_yn = shopmodel.req_yn,
                option_yn = shopmodel.option_yn,
                min_count = shopmodel.min_count

            };

            Result<dynamic> temp = await dgShop.Post<dynamic, RequestSetOptionMenuGroup>("SetMenuOptionGroup", insertModel);

            if (temp.code == "00")
            {
                Int32.TryParse(insertModel.menu_cd, out int MenuSeq);
                return RedirectToAction("OptionGroupInquiry", "Option", new { id = MenuSeq });

            }
            else if (temp.code != "00")
            {
                ModelState.AddModelError("", "메뉴 옵션 그룹을 추가하는중 예상하지 못한 에러로인한 등록이 실패하였습니다.");
                return View(shopmodel);
            }

            return View();
        }
        /*
         * OptionGroupModify
         * **/
        public async Task<IActionResult> Modify(int id, string option_name, string menu_cd, string tempdata)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (id > 0)
            {
                //MenuOptionDetail
                RequestMenuOptionGroupDetail updateModel = new RequestMenuOptionGroupDetail()
                {
                    cccode = info.cccode,
                    mcode = info.mcode,
                    shop_cd = info.shop_cd,
                    menu_cd = tempdata,
                    option_group_cd = id.ToString()
                };

                Result<ShopMenuOptionGroup> temp = await dgShop.Post<ShopMenuOptionGroup, RequestMenuOptionGroupDetail>("MenuOptionGroupDetail", updateModel);

                if (temp.code == "00")
                {
                    return PartialView("Modify", temp.data.SingleOrDefault());
                }
            }
            return PartialView();
        }
        [HttpPost]
        public async Task<IActionResult> Modify(ShopMenuOptionGroup shopmodel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            if (shopmodel.option_group_name == null)
            {
                ModelState.AddModelError("", "옵션 그룹 이름을 등록해주세요");
                return PartialView("Modify", shopmodel);
            }

            if (!ModelState.IsValid)
            {
                return View();
            }
            if (shopmodel.min_count > shopmodel.multi_count)
            {
                ModelState.AddModelError("min_count", "최소값은 최대를 넘을수없습니다.");
                return PartialView("Modify", shopmodel);
            }
            RequestSetOptionMenuGroup updateModel = new RequestSetOptionMenuGroup()
            {
                cccode = info.cccode,
                mcode = info.mcode,
                shop_cd = info.shop_cd,
                mod_name = info.login_name,

                job_gbn = "U",
                group_cd = shopmodel.option_group_cd,
                group_name = shopmodel.option_group_name,
                group_memo = shopmodel.option_group_memo,
                group_file_name = shopmodel.ogroup_file_name,

                sort_seq = shopmodel.sort_seq,
                menu_cd = shopmodel.menu_cd,
                multi_yn = shopmodel.multi_yn,
                req_yn = shopmodel.req_yn,
                option_yn = shopmodel.option_yn,

                multi_count = shopmodel.multi_count,
                min_count = shopmodel.min_count

            };
            Result<dynamic> temp = await dgShop.Post<dynamic, RequestSetOptionMenuGroup>("SetMenuOptionGroup", updateModel);
            if (temp.code == "00")
            {
                Int32.TryParse(updateModel.menu_cd, out int MenuSeq);
                return PartialView("Modify", shopmodel);
                //return RedirectToAction("OptionGroupInquiry", "Option", new { id = MenuSeq });
            }
            ModelState.AddModelError("", "수정에 실패하였습니다. ");
            return PartialView("Modify", shopmodel);
        }
        #endregion
        #region 메뉴 옵션
        public async Task<IActionResult> ShopOptionList(int id, string group_name, int code)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestMenuOptionList selectModel = new RequestMenuOptionList()
            {
                cccode = info.cccode,
                mcode = info.mcode,
                shop_cd = info.shop_cd,
                menu_cd = id.ToString(),
                option_group_cd = code,
                job_gbn = "1"

            };

            Result<ShopMenuOption> temp = await dgShop.Post<ShopMenuOption, RequestMenuOptionList>("MenuOptionList", selectModel);

            if (temp.code == "00")
            {
                ViewData["option_name"] = group_name;
                TempData["Menucd"] = id;
                TempData["Seq"] = temp.data.Count();
                TempData["auth"] = code.ToString();
                View(temp.data);
            }

            return View();
        }
        public IActionResult OptionAdd(int id, int seq, int auth)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ShopMenuOption model = new ShopMenuOption()
            {
                menu_cd = id.ToString(),
                sort_seq = seq,
                option_group_cd = auth.ToString(),
            };
            return PartialView("OptionAdd", model);
        }
        [HttpPost]
        public async Task<IActionResult> OptionAdd(ShopMenuOption shopModel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (shopModel.option_name == null)
            {
                ModelState.AddModelError("", "옵션 이름을 등록해주세요.");
                return PartialView("OptionAdd", shopModel);
            }
            if (!ModelState.IsValid)
            {
                return View();
            }


            RequestSetMenuOption insertModel = new RequestSetMenuOption()
            {
                cccode = info.cccode,
                mcode = info.mcode,
                shop_cd = info.shop_cd,
                mod_name = info.login_name,
                job_gbn = "I",
                cost = shopModel.ocost,
                file_name = shopModel.omenu_file_name,
                group_cd = shopModel.option_group_cd, // MenuOption Group CD
                menu_cd = shopModel.menu_cd,
                option_cd = shopModel.option_cd,
                option_memo = shopModel.option_memo,
                option_name = shopModel.option_name,
                sort_seq = shopModel.sort_seq,
                use_yn = shopModel.use_yn
            };

            Result<dynamic> temp = await dgShop.Post<dynamic, RequestSetMenuOption>("SetMenuOption", insertModel);

            if (temp.code == "00")
            {
                return PartialView("OptionAdd", shopModel);
            }
            ModelState.AddModelError("", "등록에 실패하셨습니다.");
            return PartialView("OptionAdd", shopModel);
        }
        public async Task<IActionResult> OptionModify(int id, int optioncd)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //ShopMenuOption

            RequestMenuOptionDetail detailModel = new RequestMenuOptionDetail()
            {
                cccode = info.cccode,
                mcode = info.mcode,
                shop_cd = info.shop_cd,

                menu_cd = id,
                opt_cd = optioncd
            };

            Result<ShopMenuOption> temp = await dgShop.Post<ShopMenuOption, RequestMenuOptionDetail>("MenuOptionDetail", detailModel);

            if (temp.code == "00")
            {
                return PartialView("OptionModify", temp.data.ToList().SingleOrDefault());
            }
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> OptionModify(ShopMenuOption optionmodel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            if (optionmodel.option_name == null)
            {
                ModelState.AddModelError("", "옵션 이름을 등록해주세요");
                return PartialView("OptionModify", optionmodel);
            }

            if (!ModelState.IsValid)
            {
                return View();
            }
            RequestSetMenuOption insertModel = new RequestSetMenuOption()
            {
                cccode = info.cccode,
                mcode = info.mcode,
                shop_cd = info.shop_cd,
                mod_name = info.login_name,
                job_gbn = "U",
                cost = optionmodel.ocost,
                file_name = optionmodel.omenu_file_name,
                group_cd = optionmodel.option_group_cd, // MenuOption Group CD
                menu_cd = optionmodel.menu_cd,
                option_cd = optionmodel.option_cd,
                option_memo = optionmodel.option_memo,
                option_name = optionmodel.option_name,
                sort_seq = optionmodel.sort_seq,
                use_yn = optionmodel.use_yn
            };

            Result<dynamic> temp = await dgShop.Post<dynamic, RequestSetMenuOption>("SetMenuOption", insertModel);

            if (temp.code == "00")
            {
                return PartialView("OptionModify", optionmodel);
            }
            ModelState.AddModelError("", "등록에 실패하였습니다.");
            return PartialView("OptionModify", optionmodel);
        }
        [HttpPost]
        public async Task<IActionResult> OptionMenuSoldOut(string option_cd, string yn)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(option_cd) || string.IsNullOrEmpty(yn))
            {
                return BadRequest();
            }

            RequestMenuOptionSoldout requestModel = new RequestMenuOptionSoldout()
            {
                cccode = info.cccode,
                option_cd = Convert.ToInt32(option_cd),
                job_gbn = "U",
                shop_cd = info.shop_cd,
                mcode = info.mcode,
                soldout = yn
            };

            Result<ResponseMenuOptionSoldout> req = await dgShop.Post<ResponseMenuOptionSoldout, RequestMenuOptionSoldout>("SetMenuOptSoldout", requestModel);

            if (req.code == "00")
            {
                return Ok(new
                {
                    code = "00",
                    msg = "성공하셨습니다."
                });
            }
            return BadRequest(new
            {
                code = "400",
                msg = "알수없는 이유로 실패하였습니다. 새로고침후 다시 이용해주세요."
            });
        }
        #endregion
        #region Admin - Option
        public async Task<IActionResult> List(int id)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (id > 0)
            {
                var req = await dgShop.Post<ApiModels.Option.Response.ResponseOptionInfo, ApiModels.Option.Request.RequestOption>
                   ("/api/OptionManagement/OptionList", new ApiModels.Option.Request.RequestOption
                   {
                       shop_cd = info.shop_cd,
                       optionGroupCd = id.ToString()
                   });

               // var req = await adminAPI.Get<ResponseOptionList>("Option/optionList/" + id);
                if (req.code == "00")
                {
                    TempData["code"] = id;
                    return View(req.data.OrderBy(x => x.useYn.Equals("Y")));
                }
                return BadRequest();
            }

            return BadRequest();
        }
        public IActionResult Add(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return BadRequest();
            }
            else
            {
                OptionAdd model = new OptionAdd()
                {
                    optionGroupCd = id
                };
                return View(model);
            }
        }
        public async Task<IActionResult> Update(string idx)
        {
            if (idx == null)
            {
                return BadRequest(new
                {
                    code = "400",
                    Msg = "값이 존재하지않습니다. 새로고침후 이용해주세요."
                });
            }
            if (!string.IsNullOrEmpty(idx))
            {
                string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
                ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
                info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
                /// admin / Option /{ option_cd}
                //var req = await adminAPI.GetSingle<ResponseOption>("Option" + "/" + idx);

                var req = await dgShop.Post<ApiModels.Option.Response.ResponseOptionInfo, ApiModels.Option.Request.RequestOption>
                    ("/api/OptionManagement/OptionDetail", new ApiModels.Option.Request.RequestOption
                    {
                        shop_cd = info.shop_cd,
                        optionCd = idx
                    });

                if (req.code == "00")
                {
                    return PartialView("Change", req.data.SingleOrDefault());
                }
                else
                {
                    return BadRequest(new
                    {
                        code = "400",
                        Msg = "처리중 알수없는 에러로인한 등록에 실패하였습니다."
                    });
                }
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> Add(OptionAdd optionModel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            Utils utils = new Utils();
            RequestOptionAdd addModel = new RequestOptionAdd()
            {
                shopCd = info.shop_cd.ToString(),
                cost = optionModel.cost,
                insertName = info.login_name,
                optionCd = optionModel.optionCd,
                optionGroupCd = optionModel.optionGroupCd,
                optionMemo = optionModel.optionMemo,
                optionName = optionModel.optionName,
                useYn = optionModel.useYn,
                noFlag = optionModel.noFlag
            };

            if (!utils.Money10wonCheck(addModel.cost))
            {
                ModelState.AddModelError("cost", "메뉴 금액은 10원 단위 이상으로 설정 가능합니다.");
                return View("Add", optionModel);
            }


            //var req = await adminAPI.Post<dynamic, RequestOptionAdd>("Option", addModel);

            var req = await dgShop.Post<dynamic, ApiModels.Option.Request.RequestOption>("/api/OptionManagement/OptionAdd",
                new ApiModels.Option.Request.RequestOption
                {
                    shop_cd = info.shop_cd,
                    cost = optionModel.cost,
                    mName = info.login_name,
                    optionCd = optionModel.optionCd,
                    optionGroupCd = optionModel.optionGroupCd,
                    optionMemo = optionModel.optionMemo,
                    optionName = optionModel.optionName,
                    useYn = optionModel.useYn,
                    noFlag = optionModel.noFlag
                });

            if (req.code == "00")
            {
                var bodyContent = JsonConvert.SerializeObject(addModel);
                nlogger.Info($"[ CEO Menu Success ,Shopcd === {info.shop_cd} json = {bodyContent} ]");
                return RedirectToAction("List", "Option", new { id = optionModel.optionGroupCd });
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddFromComponent(OptionAdd model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(model.optionGroupCd) || string.IsNullOrEmpty(model.cost))
            {
                return Ok(new
                {
                    code = "99",
                    Message = "데이터가 유효하지 않습니다."
                });
            }

            RequestOptionAdd addModel = new RequestOptionAdd()
            {
                shopCd = info.shop_cd.ToString(),
                cost = model.cost,
                optionCd = model.optionCd,
                optionGroupCd = model.optionGroupCd,
                optionMemo = model.optionMemo,
                optionName = model.optionName,
                useYn = "Y",

                insertName = info.login_name,
            };

            var req = await adminAPI.Post<dynamic, RequestOptionAdd>("Option", addModel);


            if (req.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    Message = "성공"
                });
            }

            return Ok(new
            {
                code = "99",
                Message = req.msg
            });
        }

        [HttpPost]
        public async Task<IActionResult> DeleteFromComponent(OptionAdd model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(model.optionCd))
            {
                return Ok(new
                {
                    code = "99",
                    Message = "데이터가 유효하지 않습니다."
                });
            }

            RequestOptionAdd deleteRequest = new RequestOptionAdd
            {
                optionCd = model.optionCd,
                insertName = info.login_name
            };
            var response = await adminAPI.Delete<dynamic>(string.Join('/', "Option", model.optionCd));

            if (response.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    message = "성공"
                });
            }
            return Ok(new
            {
                code = "99",
                message = response.msg
            });
        }

        public IActionResult RefreshComponent(string idx)
        {
            return ViewComponent("OptionGroupOptions", new { idx = idx });
        }

        #endregion

        #region ajax -  Sortconnection
        [HttpPost]
        public IActionResult SortList(string div, string[] idx, string menu)
        {
            if (idx == null)
            {
                return BadRequest(new
                {
                    code = "400",
                    Msg = "값이 존재하지않습니다. 새로고침후 이용해주세요."
                });
            }
            if (string.IsNullOrEmpty(menu))
            {
                return Ok(new
                {
                    code = "00",
                    Msg = "새로고침 후 이용해주세요."
                });
            }
            if (idx.Count() > 1)
            {
                string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
                ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
                info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
                RequestSortItem requestList = new RequestSortItem()
                {
                    job_gbn = div,
                    item_codes = new List<int>(),
                    menu_cd = menu,
                    u_code = info.u_code,
                    login_code = info.login_code.ToString(),
                    login_name = info.login_name,
                    shop_cd = info.shop_cd
                };

                for (int i = 0; i < idx.Count(); i++)
                {
                    requestList.item_codes.Add(Convert.ToInt32(idx[i]));
                }

                var req = dgShop.Post<CodeMsg, RequestSortItem>("SortList", requestList);

                if (req.Result.code == "00")
                {
                    return Ok(new
                    {
                        code = "200",
                        Msg = "정상처리완료"
                    });
                }
                else
                {
                    return BadRequest(new
                    {
                        code = "400",
                        Msg = "처리중 알수없는 에러로인한 등록에 실패하였습니다."
                    });
                }
            }
            return NotFound();
        }
        #endregion

        #region Modal
        [HttpPost]
        public async Task<IActionResult> Change(ApiModels.Option.Response.ResponseOptionInfo model)
        {
            if (string.IsNullOrEmpty(model.optionName))
            {
                ModelState.AddModelError("optionName", "이름이 존재하지않습니다.");
                return PartialView("Change", model);
            }
            if (string.IsNullOrEmpty(model.useYn))
            {
                ModelState.AddModelError("useYn", "사용구분을 선택해주세요");
                return PartialView("Change", model);
            }
            var convertCost = Convert.ToInt32(model.cost.Replace(",",""));

            if((convertCost % 10) > 0)
            {
                ModelState.AddModelError("cost", "10원단위로 설정가능합니다.");
                return PartialView("Change", model);
            }
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ApiModels.Option.Request.RequestOption updateModel = new ApiModels.Option.Request.RequestOption()
            {
                shop_cd = info.shop_cd,
                cost = model.cost.Replace(",",""),
                mName = info.login_name,
                optionCd = model.optionCd,
                optionMemo = model.optionMemo,
                useYn = model.useYn,
                optionName = model.optionName,
                noFlag = model.noFlag,
                adultOnly = model.adultOnly
            };

            //var req = await adminAPI.Put<ResponseOption, RequestOptionAdd>("Option", updateModel);
            var req = await dgShop.Post<dynamic, ApiModels.Option.Request.RequestOption>
                ("/api/OptionManagement/OptionUpdate", updateModel);

            if (req.code == "00")
            {
                return PartialView("Change", model);
            }

            ModelState.AddModelError("", "수정 실패 하였습니다. 새로고침후 다시 수정해주시기바랍니다.");
            return PartialView("Change", model);
        }
        #endregion
        #region admin -  option choice Sort
        [HttpPost]
        public IActionResult OCSort(string div, string[] idx, string menu)
        {
            if (idx == null)
            {
                return BadRequest(new
                {
                    code = "400",
                    Msg = "값이 존재하지않습니다. 새로고침후 이용해주세요."
                });
            }
            if (string.IsNullOrEmpty(menu))
            {
                return Ok(new
                {
                    code = "00",
                    Msg = "새로고침 후 이용해주세요."
                });
            }
            if (idx.Count() > 1)
            {
                string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
                ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
                info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
                RequestSortItem requestList = new RequestSortItem()
                {
                    job_gbn = div,
                    item_codes = new List<int>(),
                    menu_cd = menu,
                    u_code = info.u_code,
                    login_code = info.login_code.ToString(),
                    login_name = info.login_name,
                    shop_cd = info.shop_cd
                };

                for (int i = 0; i < idx.Count(); i++)
                {
                    requestList.item_codes.Add(Convert.ToInt32(idx[i]));
                }

                var req = dgShop.Post<CodeMsg, RequestSortItem>("SortList", requestList);

                if (req.Result.code == "00")
                {
                    return Ok(new
                    {
                        code = "200",
                        Msg = "정상처리완료"
                    });
                }
                else
                {
                    return Ok(new
                    {
                        code = "400",
                        Msg = "처리중 알수없는 에러로인한 등록에 실패하였습니다."
                    });
                }
            }
            return NotFound();
        }
        #endregion
    }
}
