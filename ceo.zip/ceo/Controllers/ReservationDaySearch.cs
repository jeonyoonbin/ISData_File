﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.Reservation.Operate.Request;
using PosWebApp.Models.Reservation.Operate.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Reservation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ReservationDaySearch : Controller
    {
        private readonly ReservationService_T reservation;
        public ReservationDaySearch(ReservationService_T reservation)
        {
            this.reservation = reservation;
        }

        public async Task<IActionResult> index(RequestDaySearch model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(model.from))
            {
                //ViewBag.daySearch = new ResponseDaySearch();
                model.from = DateTime.Now.ToString("yyyy-MM-dd");
                return View(model);
            }
            
            return View(model);
        }
        public async Task<IActionResult> reserOnOff(string result, string date)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(result))
            {
                return Ok(new
                {
                    code = "99",
                    msg = "값 설정 후 이용부탁드립니다."
                });
            }
            var splidate = date.Split(" ");
            var req = await reservation.Put<dynamic, RequestTimeOnOff>("/SetShopTimeOffCeo", new RequestTimeOnOff
            {
                shopCode = info.shop_cd.ToString(),
                orderDate = splidate[0],
                dayTime = splidate[1],
                reserYN = result,
                userId = info.login_name
            });

            if (req.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    msg = "성공",
                });
            }
            else
            {
                return Ok(new
                {
                    code = "99",
                    msg = req.msg
                });
            }
        }
    }
}
