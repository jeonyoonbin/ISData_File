﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Models.Reservation.Store.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Models.Review.Requests;
using PosWebApp.Models.Review.Responses;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.Reservation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ReservationReviewController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly ReservationService_T reservation;
        private readonly ReservationReviewService reservationReview;
        private readonly NLog.Logger nlogger;

        public ReservationReviewController(DgShopApiService dgshop, ReservationService_T reservation, ReservationReviewService reservationreview)
        {
            this.dgShop = dgshop;
            this.reservation = reservation;
            this.reservationReview = reservationreview;
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }
        public async Task<IActionResult> fail()
        {
            return View();
        }
        public async Task<IActionResult> Index(string pageNum = null, string type = null)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(pageNum))
            {
                pageNum = "";
            }
            ViewBag.enabled = true;
            RequestReviewCEO temp = new RequestReviewCEO
            {
                shopCode = info.shop_cd.ToString(),
                pageCnt = "",
                pageNum = pageNum,
                photoYn = "",
                SortGbn = ""
            };
            switch (type)
            {
                case "a":
                    ViewBag.Type = "a";
                    temp.JobGbn = "10";
                    break;
                case "un":
                    ViewBag.Type = "un";
                    temp.JobGbn = "12";
                    break;
                case "y":
                    ViewBag.Type = "y";
                    temp.JobGbn = "11";
                    break;
                default:
                    ViewBag.Type = "a";
                    temp.JobGbn = "10";
                    break;
            }
            var query = QueryHelpers.AddQueryString("/shopInfo-ss?", new Dictionary<string, string>()
            {
                {"shopCd", info.shop_cd.ToString()},
            });

            /// var shopDefaultInfo = await reservation.Get<ResponseReservationStore>(query);
            var reviewStatus = await reservation.Get<ResponseReservationStore>(query);
            if (reviewStatus.data.SingleOrDefault().reviewUseGbn.Equals("N"))
            {

                return RedirectToAction("fail");
            }


            var req = await reservationReview.Get<ResponseReviewCEO>("CEO?" +
                "shopCode=" + temp.shopCode +
                "&pageCnt=" + temp.pageCnt +
                "&pageNum=" + temp.pageNum +
                "&photoYn=" + temp.photoYn +
                "&SortGbn=" + temp.SortGbn +
                "&JobGbn=" + temp.JobGbn
                );

            if (req.code == "00")
            {
                var answerinfo = await reservationReview.Get<ResponseAnswerScore>("count?" +
                                                                     "shopCode=" + info.shop_cd);

                ViewBag.answer = answerinfo.data;
                return View(req.data);
            }
            return Ok();
        }


        public async Task<IActionResult> CeoAnswer(items answer)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(answer.orderNo))
            {
                ViewBag.returnType = "99";
                ViewBag.Msg = "오더가 존재하지않습니다.";
                return Ok();
            }
            RequestReviewCeoAnswer temp = new RequestReviewCeoAnswer()
            {
                content = answer.answerContent,
                answerVisibleGbn = "A", // A 전체 , O 리뷰작성자+사장님, M 답글작성자(고객X)
                orderNo = answer.orderNo,
                modName = info.ccname,
                modUcode = info.shop_cd.ToString(),
                shopCode = info.shop_cd.ToString()
            };
            var req = await reservationReview.Post<CodeMsg, RequestReviewCeoAnswer>("answer", temp);

            if (req.code == "00")
            {
                return RedirectToAction("info");
            }

            /**
             * Error 
             * 
             */
            var bodyContent = JsonConvert.SerializeObject(temp);
            nlogger.Info($"[ CEO AnswerResevation Error ,Shopcd === {info.shop_cd}, body ==== {bodyContent}");
            return BadRequest(new
            {
                Msg = req.msg
            });

        }
        public async Task<IActionResult> CeoAnswerUpdate(items answer)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(answer.orderNo))
            {
                ViewBag.returnType = "99";
                ViewBag.Msg = "오더가 존재하지않습니다.";
                return Ok();
            }
            RequestReviewCeoAnswer temp = new RequestReviewCeoAnswer()
            {
                content = answer.answerContent,
                answerVisibleGbn = "A", // A 전체 , O 리뷰작성자+사장님, M 답글작성자(고객X)
                orderNo = answer.orderNo,
                modName = info.ccname,
                modUcode = info.shop_cd.ToString(),
                shopCode = info.shop_cd.ToString()
            };
            var req = await reservationReview.Put<CodeMsg, RequestReviewCeoAnswer>("answer", temp);

            if (req.code == "00")
            {
                return RedirectToAction("info");
            }

            /**
             * Error 
             * 
             */
            var bodyContent = JsonConvert.SerializeObject(temp);
            nlogger.Info($"[ CEO AnswerResevationUpdate Error ,Shopcd === {info.shop_cd}, body ==== {bodyContent}");
            return BadRequest(new
            {
                Msg = req.msg
            });
        }
        public async Task<IActionResult> CeoAnswerDelete(items answer)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(answer.orderNo))
            {
                ViewBag.returnType = "99";
                ViewBag.Msg = "오더가 존재하지않습니다.";
                return Ok();
            }
            RequestReviewCeoAnswer temp = new RequestReviewCeoAnswer()
            {
                //content = answer.answerContent,
                //answerVisibleGbn = "A", // A 전체 , O 리뷰작성자+사장님, M 답글작성자(고객X)
                orderNo = answer.orderNo,
                modName = info.ccname,
                modUcode = info.shop_cd.ToString(),
                shopCode = info.shop_cd.ToString()
            };
            var req = await reservationReview.Delete<CodeMsg, RequestReviewCeoAnswer>("answer", temp);

            if (req.code == "00")
            {
                return Ok();
            }

            /**
             * Error 
             * 
             */
            var bodyContent = JsonConvert.SerializeObject(temp);
            nlogger.Info($"[ CEO AnswerResevation Error ,Shopcd === {info.shop_cd},body ==== {bodyContent}");
            return BadRequest(new
            {
                Msg = req.msg
            });

        }
    }
}
