﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Models.Reservation;
using PosWebApp.Models.Reservation.Operate.Response;
using PosWebApp.Models.Reservation.Store.Request;
using PosWebApp.Models.Reservation.Store.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Reservation;
using PosWebApp.ViewModels.Reservation.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ReservationStoreController : Controller
    {
        private readonly ReservationService_T reservation;
        private readonly ReservationService_Image reservationImage;
        private readonly string logoImageUrl;
        private readonly string reservationCost;
        public ReservationStoreController(ReservationService_T _reservation, ReservationService_Image _reservationImage, IConfiguration config)
        {
            this.reservation = _reservation;
            this.reservationImage = _reservationImage;
            this.logoImageUrl = config.GetValue<string>("upload:shopLogoPath");
            this.reservationCost = config.GetValue<string>("inspection:ReservationCost");
        }
        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var query = QueryHelpers.AddQueryString("/shopInfo-ss?", new Dictionary<string, string>()
            {
                {"shopCd", info.shop_cd.ToString()},
            });


            var shopDefaultInfo = await reservation.Get<ResponseReservationStore>(query);
            var reviewInfo = await reservation.Get<ResponseShopInfoImage>("reviewImage/" + info.shop_cd);
            var menuCostYn = await reservation.Get<ResponseNonuAmount>("/menuCostShow/" + info.shop_cd);


            if (shopDefaultInfo.code.Equals("00"))
            {
                var shopSingleDefault = shopDefaultInfo.data.SingleOrDefault();
                var menuCostYnSingle = menuCostYn.data.SingleOrDefault();
                if (reviewInfo.code.Equals("00"))
                {
                    ViewBag.reviewImageInfo = reviewInfo.data;

                }
                else
                {
                    ViewBag.reviewImageInfo = new List<ResponseShopInfoImage>();
                }
                if (menuCostYn.code.Equals("00"))
                {
                    ViewBag.menuCostYn = menuCostYnSingle.menuCostShowGbn;
                }
                else
                {
                    ViewBag.menuCostYn = null;
                }

                if (!string.IsNullOrEmpty(shopSingleDefault.shopFileName))
                {
                    ViewData["StoreLogo"] = shopSingleDefault.shopFileName;
                }
                else
                {
                    ViewData["StoreLogo"] = "/img/image-gallery.png";
                }

                ViewBag.ReservationCost = reservationCost;
                return View(shopSingleDefault);
            }

            return View();
        }

        #region 한줄소개, 리뷰, 매장 알림
        public async Task<IActionResult> ShopIntro()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var query = QueryHelpers.AddQueryString("/shopInfo-ss?", new Dictionary<string, string>()
            {
                {"shopCd", info.shop_cd.ToString()},
            });

            var shopDefaultInfo = await reservation.Get<ResponseReservationStore>(query);


            if (shopDefaultInfo.code.Equals("00"))
            {
                var returnSingle = shopDefaultInfo.data.SingleOrDefault();

                View(returnSingle);
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ShopIntro(string text)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            var query = QueryHelpers.AddQueryString("/introduce?", new Dictionary<string, string>()
            {
                {"shopCd", info.shop_cd.ToString()},
                {"ccCode", info.cccode.ToString()},
                {"introduce", string.IsNullOrEmpty(text) ? "" : text },
                { "userId", info.login_name }
            });


            var req = await reservation.Put<dynamic>(query);

            if (req.code.Equals("00"))
            {
                ViewBag.Sucess = "Y";
                var query2 = QueryHelpers.AddQueryString("/shopInfo-ss?", new Dictionary<string, string>()
                {
                    {"shopCd", info.shop_cd.ToString()},
                });

                var shopDefaultInfo = await reservation.Get<ResponseReservationStore>(query2);


                if (shopDefaultInfo.code.Equals("00"))
                {
                    var returnSingle = shopDefaultInfo.data.SingleOrDefault();

                    return View(returnSingle);
                }
            }

            ModelState.AddModelError("", req.msg);
            return View();
        }
        public async Task<IActionResult> OwnerIntro()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var query = QueryHelpers.AddQueryString("/shopInfo-ss?", new Dictionary<string, string>()
            {
                {"shopCd", info.shop_cd.ToString()},
            });

            var shopDefaultInfo = await reservation.Get<ResponseReservationStore>(query);

           // var ownerShopImage = await reservation.Get<ResponseShopInfoImage>("shopImage/"+ info.shop_cd.ToString());

            if (shopDefaultInfo.code.Equals("00"))
            {
                var returnSingle = shopDefaultInfo.data.SingleOrDefault();

                //if (ownerShopImage.code.Equals("00"))
                //{
                //    ViewBag.shopImage = ownerShopImage.data;
                //}
                ViewBag.shopImage = new List<ResponseShopInfoImage>();

                return View(returnSingle);
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> OwnerIntro(string text)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

           

            var req = await reservation.Put<dynamic, RequestReservationOwnerIntro>("/updateNotice", new RequestReservationOwnerIntro
            {
                shopCd = info.shop_cd.ToString(),
                ccCode = info.cccode.ToString(),
                notice = text,
                userID = info.login_name
            });


           // var req = await reservation.PutJson<dynamic>(query);

            if (req.code.Equals("00"))
            {
                ViewBag.Sucess = "Y";

                var query = QueryHelpers.AddQueryString("/shopInfo-ss?", new Dictionary<string, string>()
                {
                    {"shopCd", info.shop_cd.ToString()},
                });

                var shopDefaultInfo = await reservation.Get<ResponseReservationStore>(query);



                if (shopDefaultInfo.code.Equals("00"))
                {
                    var returnSingle = shopDefaultInfo.data.SingleOrDefault();

                    //if (ownerShopImage.code.Equals("00"))
                    //{
                    //    ViewBag.shopImage = ownerShopImage.data;
                    //}
                    ViewBag.shopImage = new List<ResponseShopInfoImage>();

                    return View(returnSingle);
                }


                return View();
            }

            ModelState.AddModelError("", req.msg);
            return View();
        }
        public async Task<IActionResult> ReviewIntro()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var query = QueryHelpers.AddQueryString("/shopInfo-ss?", new Dictionary<string, string>()
            {
                {"shopCd", info.shop_cd.ToString()},
            });

            var shopDefaultInfo = await reservation.Get<ResponseReservationStore>(query);

            var ownerShopImage = await reservation.Get<ResponseShopInfoImage>("reviewImage/"+ info.shop_cd.ToString());

            if (shopDefaultInfo.code.Equals("00"))
            {
                var returnSingle = shopDefaultInfo.data.SingleOrDefault();
                 
                if (ownerShopImage.code.Equals("00"))
                {
                    ViewBag.reviewImage = ownerShopImage.data;
                }
                else
                {
                    ViewBag.reviewImage = new List<ResponseShopInfoImage>();
                }

                return View(returnSingle);
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ReviewIntro(string text)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var req = await reservation.Put<dynamic, RequestReservationReviewIntro>("/reviewIntro", new RequestReservationReviewIntro
            { 
                shopCd = info.shop_cd.ToString(),
                ccCode = info.cccode.ToString(),
                shopReviewIntro = text,
                userId = info.login_name
            });

            if (req.code.Equals("00"))
            {
                ViewBag.Sucess = "Y";

                var query = QueryHelpers.AddQueryString("/shopInfo-ss?", new Dictionary<string, string>()
                {
                    {"shopCd", info.shop_cd.ToString()},
                });

                var shopDefaultInfo = await reservation.Get<ResponseReservationStore>(query);

                var ownerShopImage = await reservation.Get<ResponseShopInfoImage>("reviewImage/" + info.shop_cd.ToString());

                if (shopDefaultInfo.code.Equals("00"))
                {
                    var returnSingle = shopDefaultInfo.data.SingleOrDefault();

                    if (ownerShopImage.code.Equals("00"))
                    {
                        ViewBag.reviewImage = ownerShopImage.data;
                    }
                    else
                    {
                        ViewBag.reviewImage = new List<ResponseShopInfoImage>();
                    }

                    return View(returnSingle);
                }
            }

            ModelState.AddModelError("", req.msg);
            return View();
        }

        public async Task<IActionResult> InsIntro(string type)
        {
            ReservationIntroImage intro = new ReservationIntroImage();

            switch (type)
            {
                case "1":
                    intro.type = "Shop";
                    ViewBag.Title = "매장 알림 이미지 등록";
                    break;
                case "2":
                    intro.type = "Review";
                    ViewBag.Title = "리뷰 알림 이미지 등록";
                    break;
            }
            await Task.Delay(0);

            return PartialView("IntroImage", intro);
        }
        [HttpPost]
        public async Task<IActionResult> IntroImageInstail(ReservationIntroImage model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(model.iFile.FileName))
            {
                return Ok(new
                {
                    Code = "99",
                    Msg = "서비스요청 에러입니다. 새로고침 후 이용부탁드립니다."
                });
            }
            if(model.type == "1")
            {
                var response = await reservationImage.PutImage<dynamic, RequestReservationImageInit>("shopImage/insert", new RequestReservationImageInit
                {
                    ccCode = info.cccode,
                    shopCode = info.shop_cd.ToString(),
                    file = model.iFile
                });

                if (response.code.Equals("00"))
                {
                    PartialView("IntroImage");
                }
                else
                {
                    ModelState.AddModelError("", "서비스요청 에러입니다. 새로고침 후 이용부탁드립니다.");
                    PartialView("IntroImage");
                }
            }
            if(model.type == "2")
            {
                var countReq = await reservationImage.Get<ResponseShopInfoImage>("reviewImage/" + info.shop_cd);

                var reviewImageCut = countReq.data;

                if (reviewImageCut.Count() > 2)
                {
                    ModelState.AddModelError("", "리뷰 이미지 갯수 초과입니다. 기존 리뷰이미지 삭제 후 이용바랍니다.");

                    PartialView("IntroImage");
                }

                var response = await reservationImage.PutImage<dynamic, RequestReservationImageInit>("reviewImage/insert", new RequestReservationImageInit
                {
                    ccCode = info.cccode,
                    shopCode = info.shop_cd.ToString(),
                    file = model.iFile,
                    
                });

                if (response.code.Equals("00"))
                {
                    PartialView("IntroImage");
                }
                else
                {
                    ModelState.AddModelError("", "서비스요청 에러입니다. 새로고침 후 이용부탁드립니다.");
                    PartialView("IntroImage");
                }
            }
            
           
            return PartialView("IntroImage");
        }
        [HttpPost]
        public  async Task<IActionResult> IntroImageDelete(RequestReservationImage model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (model.seq <= 0)
            {
                return Ok(new
                {
                    Code = "99",
                    Msg = "서비스요청 에러입니다. 새로고침 후 이용부탁드립니다."
                });
            }

            model.shopCode = info.shop_cd.ToString();
            model.ccCode = info.cccode;
            var req = new Result<dynamic>();
            if (model.type == "1")
            {
                req = await reservationImage.Delete<dynamic, RequestReservationImage>("shopImage/delete",
                        model);

                if (req.code.Equals("00"))
                {
                    return Ok(new
                    {
                        Code = "00",
                        Msg = "성공"
                    });
                }
            }
            if(model.type == "2")
            {
                model.userId = info.login_name;
                req = await reservationImage.Delete<dynamic, RequestReservationImage>("reviewImage/delete",
                           model);

                if (req.code.Equals("00"))
                {
                    return Ok(new
                    {
                        Code = "00",
                        Msg = "성공"
                    });
                }
            }

            return Ok(new
                {
                    Code = "99",
                    Msg = req.msg
                });
        }
        #endregion

        #region 금액 표기여부
        public async Task<IActionResult> NounAmount()
        {
            var ReservationCostYn = reservationCost;
            ReservationNonuAmount result = new ReservationNonuAmount();
           
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var req = await reservation.Get<ResponseNonuAmount>("/menuCostShow/" + info.shop_cd);
           
            if (req.code.Equals("00"))
            {
                
                result.useYn = req.data.SingleOrDefault().menuCostShowGbn;
                return View(result);
            }

            ModelState.AddModelError("", "새로고침후 이용바랍니다.");
            return View(result);
        }
        [HttpPost]
        public async Task<IActionResult> NounAmount(ReservationNonuAmount model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var req = await reservation.Put<dynamic, RequestNonuAmount>("/menuCostShow", new RequestNonuAmount
            {
                shopCode = info.shop_cd.ToString(),
                userId = info.login_name.ToString(),
                menuCostShowGbn = model.useYn
            });

            if (req.code.Equals("00"))
            {
                return RedirectToAction("index");
            }

            ModelState.AddModelError("", req.msg);
            return View(model);
        }
        #endregion
        //public IActionResult OwnerIntro()
        //{
        //    return View();
        //}

        //public IActionResult ReviewIntro()
        //{
        //    return View();
        //}

        public IActionResult AddressChange()
        {
            return View();
        }

        public IActionResult CategoryChange()
        {
            return View();
        }
    }
}
