﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class UploadController : Controller
    {
        private DgShopApiService dgShop;
        private readonly IConfiguration config;
        private readonly IHostingEnvironment env;
        private readonly long _fileSizeLimit;
        private readonly string storeImgPath;
        private readonly string logoImgPath;
        private readonly string menuImgPath;
        private readonly string domain;
        private readonly ILogger<PosController> _logger;

        public UploadController(IConfiguration configuration, DgShopApiService api, ILogger<PosController> logger, IHostingEnvironment _env)
        {
            dgShop = api;
            config = configuration;
            env = _env;

            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> PostFiles(UploadFile model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            try
            {
                UploadImage upload = new UploadImage(config, dgShop);
                var temp = await upload.Upload(model, info, nameof(UploadType.SIGNBOARD));
            }
            catch (Exception e)
            {

                throw;
            }


            return RedirectToAction("Index", "Store");
        }

        [HttpPost]
        public async Task<IActionResult> UploadLogo(UploadFile model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            try
            {
                UploadImage upload = new UploadImage(config, dgShop);
                var temp = await upload.Upload(model, info, nameof(UploadType.LOGO));
            }
            catch (Exception e)
            {

                throw;
            }


            return RedirectToAction("Index", "Store");
        }

        public async Task<IActionResult> UploadMenuImage(UploadFile model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            try
            {
                UploadImage upload = new UploadImage(config, dgShop);
                var temp = await upload.Upload(model, info, nameof(UploadType.MENU));
            }
            catch (Exception e)
            {

                throw;
            }

            return RedirectToAction("index", "Store");
        }

        [HttpPost]
        public ActionResult UploadFiles(List<IFormFile> postedFiles)
        {
            string wwwPath = this.env.WebRootPath;
            string conetentPath = this.env.ContentRootPath;

            string path = Path.Combine(this.env.WebRootPath, "Uploads");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            foreach(IFormFile postedFile in postedFiles)
            {
                string fileName = Path.GetFileName(postedFile.FileName);
                using (FileStream stream = new FileStream(Path.Combine(path, fileName), FileMode.Create))
                {
                    postedFile.CopyTo(stream);
                }
            }

            return Content("success");
        }
    }
}
