﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.ApiModels.Shop.Response;
using PosWebApp.Common;
using PosWebApp.Models.Admin.Response;
using PosWebApp.Models.ChangeRequest.Request;
using PosWebApp.Models.ChangeRequest.Response;
using PosWebApp.Models.Common;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Admin;
using PosWebApp.Services.DgReview;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.NaverGeocode;
using PosWebApp.ViewModels.ChangeRequestHistory.Address;
using PosWebApp.ViewModels.ChangeRequestHistory.Bizinfo;
using PosWebApp.ViewModels.ChangeRequestHistory.Category;
using PosWebApp.ViewModels.ChangeRequestHistory.Index;
using PosWebApp.ViewModels.ChangeRequestHistory.Menu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ChangeRequestHistory : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly NaverApi naverAPI;
#if DEBUG
        private readonly ReviewDaeguAPI_T reviewDaeguService;
#else
        private readonly ReviewDaeguAPI reviewDaeguService;
#endif
        private readonly NLog.Logger nlogger;
        private readonly AdminApi adminApi;
        private readonly string kakaoDaeguroURL;
        public ChangeRequestHistory(DgShopApiService api, IConfiguration configuration, NaverApi naverApi, AdminApi _adminApi, ReviewDaeguAPI_T _reviewAPI_T, ReviewDaeguAPI _reviewAPI)
        {
            dgShop = api;
            naverAPI = naverApi;
            adminApi = _adminApi;
            kakaoDaeguroURL = configuration.GetValue<string>("api:kakaoDaeguro");
#if DEBUG
            reviewDaeguService = _reviewAPI_T;
#else
            reviewDaeguService = _reviewAPI;
#endif
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }
        public async Task<IActionResult> Index(GetCommon param, int? pageNumber)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestCommonAPI RSapi = new RequestCommonAPI(dgShop);

            if (string.IsNullOrEmpty(param.from))
            {
                param.from = DateTime.Now.ToString("yyyy-MM-dd");
                param.to = DateTime.Now.ToString("yyyy-MM-dd");
                param.options = "";
                param.type = "%";
                param.request_type = "%";
            }

            ViewBag.Type = new SelectList(GetType(), "Value", "Text", "%");
            ViewBag.RequestType = new SelectList(GetRquestType(), "Value", "Text", "%");

            return View(param);
        }
        /*
         * index pagenation link 
         */
        public IActionResult IndexSearch(GetCommon param, int pageNumber)
        {
            ViewBag.Type = new SelectList(GetType(), "Value", "Text", "%");
            ViewBag.RequestType = new SelectList(GetRquestType(), "Value", "Text", "%");

            return ViewComponent("ChangeRequestList", new
            {
                param = param,
                pageNumber = pageNumber
            });
        }
        public async Task<IActionResult> AddressChange()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestCommonAPI RSapi = new RequestCommonAPI(dgShop);

            var req = await RSapi.RequestServiceList(new RequestCommon
            {
                shop_cd = info.shop_cd,
                job_gbn = "1",
                status = "%",
                service_gbn = "200",
                from = DateTime.Now.AddMonths(-6).ToString("yyyyMMdd"),
                to = DateTime.Now.ToString("yyyyMMdd")
            });

            var statusCancel = new[] { "35", "40", "50" };


            
            if (req.code.Equals("00"))
            {
                var statusCode = req.data.Where(x => statusCancel.Contains(x.status)).ToList();
                if(req.data.Count() > 0)
                {
                    if (statusCode.Count() == 0)
                    {
                        ViewBag.ErrorCode = "99";
                        ViewBag.Msg = "이전 변경 신청 이력이 존재합니다.<br>" + "심사 결과는<span class=" + '"' + "primary-color" + '"' + ">\"변경 요청 이력\"</span>메뉴에서 확인해주세요.";
                    }
                    else
                    {
                        return View();
                    }
                   
                }
                return View();
            }
            else
            {
                ViewBag.ErrorCode = "99";
                ViewBag.Msg = req.msg;
            }

            return View();
        }
        #region 카테고리 
        public async Task<IActionResult> CategoryChange(CategoryViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestCommonAPI RSapi = new RequestCommonAPI(dgShop);

            var req = await RSapi.RequestServiceList(new RequestCommon
            {
                shop_cd = info.shop_cd,
                job_gbn = "1",
                status = "%",
                service_gbn = "201",
                from = DateTime.Now.AddMonths(-6).ToString("yyyyMMdd"),
                to = DateTime.Now.ToString("yyyyMMdd")
            });

            var statusCancel = new[] { "10", "30" };
            if (req.code.Equals("00"))
            {
                var statusCode = req.data.Where(x => statusCancel.Contains(x.status)).ToList();
                if (req.data.Count() > 0)
                {
                    if (statusCode.Count() > 0)
                    {
                        ViewBag.ErrorCode = "99";
                        ViewBag.Msg = "이전 변경 신청 이력이 존재합니다.<br>" + "심사 결과는<span class=" + '"' + "primary-color" + '"' + ">\"변경 요청 이력\"</span>메뉴에서 확인해주세요.";
                    }
                    else
                    {

                    }

                }
            }
            else
            {
                ViewBag.ErrorCode = "99";
                ViewBag.Msg = req.msg;
                return View();
            }
            var itemList = await dgShop.Get<ShopBizItemCode>("BizItemCode");

            var temp = await dgShop.Post<ShopStoreInfo, Request>("DefaultInfo", new Models.ChangeRequest.Request.Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });
            if (temp.code.Equals("00"))
            {
                var shopDefaultInfo = temp.data.SingleOrDefault();
                //ViewBag.ShopDefault = shopDefaultInfo;

                ViewBag.item1 = new SelectList(itemList.data, "ITEM_CD", "ITEM_NAME", shopDefaultInfo.item_cd);
                ViewBag.item2 = new SelectList(itemList.data, "ITEM_CD", "ITEM_NAME", shopDefaultInfo.item_cd2);
                ViewBag.item3 = new SelectList(itemList.data, "ITEM_CD", "ITEM_NAME", shopDefaultInfo.item_cd3);
                return View(model);
            }


            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ServiceCategory(CategoryViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (model.item_cd.Equals(""))
            {
                ViewBag.Error = "필수값 입력해주세요.";
                return View("CategoryChange", model);
            }
            var serialModel = new RequestCategory
            {
                a_item_cd = model.item_cd,
                a_item_cd2 = model.item_cd2,
                a_item_cd3 = model.item_cd3,
            };
            var temp = await dgShop.Post<ShopStoreInfo, Request>("DefaultInfo", new Models.ChangeRequest.Request.Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            if (temp.code.Equals("00"))
            {
                var shopDefaultInfo = temp.data.SingleOrDefault();
                serialModel.b_item_cd = shopDefaultInfo.item_cd;
                serialModel.b_item_cd2 = shopDefaultInfo.item_cd2;
                serialModel.b_item_cd3 = shopDefaultInfo.item_cd3;
            }

            var serviceReq = await dgShop.Post<CodeMsg, RequestCommon>("/api/RequestService/SetServiceRequest", new RequestCommon
            {
                file_name = "",
                job_gbn = "",
                mod_name = info.login_name,
                mod_ucode = info.login_code,
                seq = 0,
                service_data = JsonConvert.SerializeObject(serialModel),
                service_gbn = "201", // 매정정보 > 카테고리 변경신청
                shop_cd = info.shop_cd,
                status = "10"
            });

            if (serviceReq.code.Equals("00"))
            {
                ViewBag.Ok = "00";
                ViewBag.Msg = "변경 신청 완료되었습니다.<br>" + "심사 결과는<span class=" + '"' + "primary-color" + '"' + ">\"변경 요청 이력\"" + "</span>메뉴에서 확인해주세요.";
                return View("CategoryChange", model);
            }
            ViewBag.Error = "요청중 에러가 발생했습니다. 관리자에게 문의해주세요.";
            return View("CategoryChange", model);
        }
        #endregion
        public IActionResult InterlockChange()
        {
            return View();
        }
        public IActionResult StoreChange()
        {
            return View();
        }
        #region 사업자 변경 신청
        public async Task<IActionResult> BizInfoChange()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            RequestCommonAPI RSapi = new RequestCommonAPI(dgShop);


            var taxType = await dgShop.Get<TaxType>("BizTaxType");
            Request req = new Request()
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };

            var requestType = await RSapi.RequestServiceType(new RequestServiceTypeCommon
            {
                GbnCode = "1",
                shopCode = info.shop_cd.ToString()
            });

            var requestWithdrawalGBN = await RSapi.RequestServiceList(new RequestCommon
            {
                shop_cd = info.shop_cd,
                status = "10",
                service_gbn = "400"
            });

            var temp = await dgShop.Post<ShopBizInfo, Request>("BizInfo", req);
            if (temp.code.Equals("00"))
            {
                var viewResult = temp.data.SingleOrDefault();
                //SetShopBizInfo bizInfo = new SetShopBizInfo() {
                //    BUSS_ADDR = viewResult.BUSS_ADDR,
                //    BUSS_CON = viewResult.BUSS_CON,
                //    BUSS_OWNER = viewResult.BUSS_OWNER,
                //    BUSS_TAX_TYPE = viewResult.BUSS_TAX_TYPE,
                //    BUSS_TYPE = viewResult.BUSS_TYPE,
                //    OWNER = viewResult.OWNER,
                //    REG_NO = viewResult.REG_NO
                //};

                var requestBizTypeSelectList = new SelectList(new List<SelectListItem>());
                var requestSelectList = new List<SelectListItem>();
                if (requestWithdrawalGBN.data == null)
                {
                    for (var i = 0; i < requestType.data.Count; i++)
                    {
                        if (requestType.data[i].typeCode.Equals("102"))
                        {
                            requestType.data[i].typeName = requestType.data[i].typeName + "해지 신청시";
                            requestType.data[i].Disabled = true;
                        }
                        else if (requestType.data[i].typeCode.Equals("105"))
                        {
                            requestType.data[i].typeName = requestType.data[i].typeName + "해지 신청시";
                            requestType.data[i].Disabled = true;
                        }
                        else if (requestType.data[i].typeCode.Equals("106"))
                        {
                            requestType.data[i].typeName = requestType.data[i].typeName + "해지 신청시";
                            requestType.data[i].Disabled = true;
                        }
                        requestSelectList.Add(
                             new SelectListItem { Selected = false, Text = requestType.data[i].typeName, Value = requestType.data[i].typeCode, Disabled = (requestType.data[i].Disabled ? true : false) }
                        );
                    }

                    ViewBag.requestBizType = requestSelectList;
                }
                else
                {
                    for (var i = 0; i < requestType.data.Count; i++)
                    {
                        requestSelectList.Add(
                             new SelectListItem { Selected = false, Text = requestType.data[i].typeName, Value = requestType.data[i].typeCode, Disabled = (requestType.data[i].Disabled ? true : false) }
                        );
                    }

                    ViewBag.requestBizType = requestSelectList;
                }


               // ViewBag.requestBizType2 = new SelectList(reqeustType.data);

                

                SetShopBizInfo bizInfo = new SetShopBizInfo();
                
                ViewBag.taxType = new SelectList(taxType.data, "code", "type_name", viewResult.BUSS_TAX_TYPE);

                return View(bizInfo);
            }
            return View();
        }
        public async Task<IActionResult> ServiceBizInfo(SetShopBizInfo model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            var taxType = await dgShop.Get<TaxType>("BizTaxType");
            ViewBag.taxType = new SelectList(taxType.data, "code", "type_name", model.BUSS_TAX_TYPE);
            if (string.IsNullOrEmpty(model.REG_NO))
            {
                ModelState.AddModelError("", "사업자 번호가 없습니다.");
                return PartialView("BizInfoChange", model);
            }
            if (model.REG_FILE == null)
            {
                ModelState.AddModelError("", "사업자 이미지가 없습니다.");
                return PartialView("BizInfoChange", model);
            }
            if (string.IsNullOrEmpty(model.OWNER))
            {
                ModelState.AddModelError("", "대표자명이 존재하지않습니다.");
                return PartialView("BizInfoChange", model);
            }
            if (string.IsNullOrEmpty(model.BUSS_CON))
            {
                ModelState.AddModelError("", "업태가 존재하지않습니다.");
                return PartialView("BizInfoChange", model);
            }
            if (string.IsNullOrEmpty(model.BUSS_TYPE))
            {
                ModelState.AddModelError("", "업종이(가) 존재하지않습니다.");
                return PartialView("BizInfoChange", model);
            }
            if (string.IsNullOrEmpty(model.BUSS_ADDR))
            {
                ModelState.AddModelError("", "사업자 주소가 존재하지않습니다.");
                return PartialView("BizInfoChange", model);
            }
            var tempResult = new RequestBizInfo
            {
                reg_no = model.REG_NO.Replace("-", ""),
                buss_addr = string.Join(' ', model.BUSS_ADDR, model.buss_AddrDetail),
                buss_con = model.BUSS_CON,
                owner = model.OWNER,
                buss_tax_type = model.BUSS_TAX_TYPE,
                buss_type = model.BUSS_TYPE,
                reg_image = model.REG_FILE,
                cccode = info.cccode,
                job_gbn = "",
                shop_cd = info.shop_cd,
                status = "10",
                service_gbn = "100",
            };

            Request req = new Request()
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };
            var temp = await dgShop.Post<ShopBizInfo, Request>("BizInfo", req);

            var datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            var imageFile = new ImageUtils();
            var isImage = new ResultSingle<string>();
            var fileName = "";
#if DEBUG
            var imageURL = "https://192.168.30.109:45013/";
#else
            var imageURL = "https://ceo.daeuguro.co.kr/";
            //var imageURL = "https://192.168.30.109:45013/";
#endif
            try
            {
                //로그 넣어야됨
                if (string.IsNullOrEmpty(tempResult.reg_image.FileName))
                {
                    ModelState.AddModelError("", "사업자 등록 이미지가 존재하지않습니다. 다시 작성해주세요.");
                    return View(model);
                }
                else
                {
                    fileName = datetime + "_" + "100" + ".jpg";
                    isImage = await imageFile.FileUpload(info.shop_cd.ToString(), tempResult.reg_image, fileName, "Bizinfo");
                }

                if (isImage.code.Equals("00"))
                {
                    //이미지 저장 성공
                    var beforeInfo = temp.data.SingleOrDefault();
                    var beforeData = new RequestBizInfo
                    {
                        reg_no = beforeInfo.REG_NO.Replace("-", ""),
                        buss_addr = string.Join(' ', beforeInfo.BUSS_ADDR),
                        buss_con = beforeInfo.BUSS_CON,
                        owner = beforeInfo.OWNER,
                        buss_tax_type = beforeInfo.BUSS_TAX_TYPE,
                        buss_type = beforeInfo.BUSS_TYPE,
                    };
                    var reqmodal = new RequestSetBizinfo(tempResult, beforeData);
                    //reqmodal.image_url = imageURL + "/RequestServiceImage" + "/Bizinfo/" + isImage.data + "/" + info.shop_cd + "/" + fileName;
                    //RequestServiceImage/Bizinfo/20211119/1/20211119155814_100.jpg
                    reqmodal.image_url = imageURL + "RequestServiceImage" + "/" + "Bizinfo" + "/" + "20211119" + "/" + info.shop_cd + "/" + "20211122165549_100.jpg";
                    var serviceReq = await dgShop.Post<CodeMsg, RequestCommon>("/api/RequestService/SetServiceRequest", new RequestCommon
                    {
                        file_name = "",
                        job_gbn = "",
                        mod_name = info.login_name,
                        mod_ucode = info.login_code,
                        seq = 0,
                        service_data = JsonConvert.SerializeObject(reqmodal),
                        //existing = JsonConvert.SerializeObject(temp.data.SingleOrDefault()),
                        service_gbn = "100",
                        shop_cd = info.shop_cd,
                        status = "10"
                    });

                    if (serviceReq.code.Equals("00"))
                    {
                        return PartialView("BizInfoChange", model);
                    }
                    else
                    {
                        ModelState.AddModelError("", serviceReq.msg);
                        return PartialView("BizInfoChange", model);
                    }

                }
                else
                {
                    ModelState.AddModelError("", "이미지 저장에 실패하셨습니다. 관리자의 문의해주세요.");
                    return PartialView("BizInfoChange", model);
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("", e.Message);
                return PartialView("BizInfoChange", model);
            }


            return PartialView("BizInfoChange", model);

        }
        /**
          사업자 중복 신청
         */
        public async Task<IActionResult> GetOverLapRegNo(string RegNo)
        {

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            if (string.IsNullOrEmpty(RegNo))
            {
                return BadRequest(new
                {
                    Msg = "사업자 번호가 존재하지않습니다."
                });
            }
            RegNo = RegNo.Replace("-", "");
            if (RegNo.Length < 10 || RegNo.Length > 10)
            {
                return BadRequest(new
                {
                    Msg = "사업자 번호를 확인해주세요."
                });
            }
            var req = await dgShop.PostSingle<string, RequestOverLapRegNo>("/api/RequestService/OverLapRegNo", new RequestOverLapRegNo
            {
                shop_cd = info.shop_cd,
                job_gbn = "1",
                RegNo = RegNo
            });

            if (req.code.Equals("00"))
            {
                return Ok(new
                {
                    Msg = req.msg
                });
            }

            return BadRequest(new
            {
                Msg = req.msg
            });
        }
        #endregion
        #region 주소 검색
        public IActionResult NaverAddress()
        {
            return PartialView("AddressModal");
        }
        [HttpPost]
        public async Task<IActionResult> NaverAddressSearch(string Search)
        {
            if (string.IsNullOrEmpty(Search))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "주소값을 입력해주세요"
                });
            }

            var temp = await naverAPI.Geocoding(Search);
            AddressTotal addressTotal = new AddressTotal();
            int i = 0;
            foreach (var item in temp.addresses)
            {
                var geo = item;

                var reverse = await naverAPI.ReverseGeocoding(Convert.ToDouble(geo.x), Convert.ToDouble(geo.y));

                var adm = reverse.results.Find(x => x.name.Equals("admcode"));
                var addr = reverse.results.Find(x => x.name.Equals("addr"));
                var legal = reverse.results.Find(x => x.name.Equals("legalcode"));
                var road = reverse.results.Find(x => x.name.Equals("roadaddr"));


                addressTotal.SIDO_NAME = addr.region.area1.name;
                addressTotal.SIGUNGU_NAME = addr.region.area2.name;
                addressTotal.DONG_NAME = addr.region.area3.name;
                addressTotal.HDONG_NAME = adm == null ? "" : adm.region.area3.name;
                addressTotal.RI_NAME = addr.region.area4.name;
                addressTotal.JIBUN_FIRST = addr.land.number1;
                addressTotal.JIBUN_SECOND = addr.land.number2;

                if (road != null)
                {
                    addressTotal.ROAD_NAME = road.land.name;
                    addressTotal.BLD_FIRST = road.land.number1;
                    addressTotal.BLD_SECOND = road.land.number2;
                    addressTotal.BLD_DETAILNAME = road.land.addition0.value;
                }
                else
                {
                    addressTotal.ROAD_NAME = string.Empty;
                    addressTotal.BLD_FIRST = string.Empty;
                    addressTotal.BLD_SECOND = string.Empty;
                    addressTotal.BLD_DETAILNAME = string.Empty;
                }

                addressTotal.LON = Convert.ToDouble(geo.x);
                addressTotal.LAT = Convert.ToDouble(geo.y);

                var umdr = addressTotal.RI_NAME.Length > 0 ? string.Join(' ', addressTotal.DONG_NAME, addressTotal.RI_NAME) : addressTotal.DONG_NAME;

                var master_sub = addressTotal.JIBUN_SECOND.Length > 0 ? string.Join('-', addressTotal.JIBUN_FIRST, addressTotal.JIBUN_SECOND) : addressTotal.JIBUN_FIRST;

                var build_master_sub = addressTotal.BLD_SECOND.Length > 0 ? string.Join('-', addressTotal.BLD_FIRST, addressTotal.BLD_SECOND) : addressTotal.BLD_FIRST;

                addressTotal.jibunAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    umdr,
                    master_sub);


                addressTotal.roadAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    addressTotal.ROAD_NAME,
                    build_master_sub
                    );

                temp.addresses[i].roadAddress = addressTotal.roadAddress;

                i++;
            }

            return PartialView("AddressModal", temp.addresses);
        }
        public IActionResult OnSearchFilter(string search)
        {
            if (string.IsNullOrEmpty(search))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "주소를 입력해주세요."
                });
            }

            return ViewComponent("AddressSearchDetail", search);
        }
        public IActionResult KaKaoAdderss()
        {
            return PartialView("KakaoIframe");
        }
        /*
         * KaKao
         */
        [HttpPost]
        public async Task<IActionResult> KaKaoToNaver(string addressName)
        {
            if (string.IsNullOrEmpty(addressName))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "주소값을 입력해주세요"
                });
            }

            var temp = await naverAPI.Geocoding(addressName);
            AddressTotal addressTotal = new AddressTotal();
            int i = 0;
            foreach (var item in temp.addresses)
            {
                var geo = item;

                var reverse = await naverAPI.ReverseGeocoding(Convert.ToDouble(geo.x), Convert.ToDouble(geo.y));

                var adm = reverse.results.Find(x => x.name.Equals("admcode"));
                var addr = reverse.results.Find(x => x.name.Equals("addr"));
                var legal = reverse.results.Find(x => x.name.Equals("legalcode"));
                var road = reverse.results.Find(x => x.name.Equals("roadaddr"));


                addressTotal.SIDO_NAME = addr.region.area1.name;
                addressTotal.SIGUNGU_NAME = addr.region.area2.name;
                addressTotal.DONG_NAME = addr.region.area3.name;
                addressTotal.HDONG_NAME = adm == null ? "" : adm.region.area3.name;
                addressTotal.RI_NAME = addr.region.area4.name;
                addressTotal.JIBUN_FIRST = addr.land.number1;
                addressTotal.JIBUN_SECOND = addr.land.number2;

                if (road != null)
                {
                    addressTotal.ROAD_NAME = road.land.name;
                    addressTotal.BLD_FIRST = road.land.number1;
                    addressTotal.BLD_SECOND = road.land.number2;
                    addressTotal.BLD_DETAILNAME = road.land.addition0.value;
                }
                else
                {
                    addressTotal.ROAD_NAME = string.Empty;
                    addressTotal.BLD_FIRST = string.Empty;
                    addressTotal.BLD_SECOND = string.Empty;
                    addressTotal.BLD_DETAILNAME = string.Empty;
                }

                addressTotal.LON = Convert.ToDouble(geo.x);
                addressTotal.LAT = Convert.ToDouble(geo.y);

                var umdr = addressTotal.RI_NAME.Length > 0 ? string.Join(' ', addressTotal.DONG_NAME, addressTotal.RI_NAME) : addressTotal.DONG_NAME;

                var master_sub = addressTotal.JIBUN_SECOND.Length > 0 ? string.Join('-', addressTotal.JIBUN_FIRST, addressTotal.JIBUN_SECOND) : addressTotal.JIBUN_FIRST;

                var build_master_sub = addressTotal.BLD_SECOND.Length > 0 ? string.Join('-', addressTotal.BLD_FIRST, addressTotal.BLD_SECOND) : addressTotal.BLD_FIRST;

                addressTotal.jibunAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    umdr,
                    master_sub);


                addressTotal.roadAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    addressTotal.ROAD_NAME,
                    build_master_sub
                    );

                temp.addresses[i].roadAddress = addressTotal.roadAddress;

                i++;
            }

            return Ok(new
            {
                data = temp.addresses
            });
        }
        #endregion
        public async Task<IActionResult> ServiceStore(ServiceReqeustShopInfo model)
        {
            string beforeImageURL = "https://image.daeguro.co.kr:40443/" + "images/";

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            RequestCommonAPI RSapi = new RequestCommonAPI(dgShop);


            var nowDate = DateTime.Now.ToString("yyyyMMdd");
            /*valid check*/

            /*가맹점 명*/
            if (model.ReqSelected == "1")
            {
                if(model.shopName == info.shop_name)
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "기존에 입력된 가맹점명과 동일합니다."
                    });
                }

                if (model.formImages == null)
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "첨부 서류가 존재하지않습니다. 파일 첨부 후 이용바랍니다."
                    });
                }
                if (model.formImages.Count() > 0)
                {
                    var imageLength = model.formImages.Count();

                    for(var i = 0; i < imageLength; i++)
                    {
                        if(model.formImages[i].Length > 6291456) //6mb
                        {
                            return Ok(new
                            {
                                code = "99",
                                Msg = model.formImages[i].FileName + "용량이 큽니다. 다시 요청 바랍니다."
                            });
                        }
                    }
                }
                else
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "첨부 서류가 존재하지않습니다. 파일 첨부 후 이용바랍니다."
                    });
                }

                if (string.IsNullOrEmpty(model.shopName))
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "변경하실 가맹점명을 입력해주세요."
                    });
                } 

                if(model.iFile1.Count() < 1)
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "첨부서류를 확인해주세요."
                    });
                }
                /*Model data Binding*/

                var datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
                var imageFile = new ImageUtils();
                var isImage = new ResultSingle<string>();
                var fileName = "";
                var fileNames = new string[model.formImages.Count()];

                var storeModel = new StoreRequest(model);
                storeModel.BeforeShopName = info.shop_name;
                storeModel.BeforeMobile = info.shop_mobile;
                storeModel.fileNames = new List<string>();
#if DEBUG
                var imageURL = "https://ceo.daeguro.co.kr";
#else
            var imageURL = "https://ceo.daeguro.co.kr";
            //var imageURL = "https://ceoimage.daeguro.co.kr:45013";
#endif
                try
                {
                    int idx = 0;
                    foreach(var files in fileNames)
                    {
                        fileName = datetime + DateTime.Now.ToString("ffff") + idx  + "_" + "200" + ".jpg";
                        fileNames[idx] = fileName;
                        storeModel.fileNames.Add(imageURL + "/RequestServiceImage" + "/StoreImage" + "/" + nowDate + "/" + info.shop_cd + "/" + fileName);
                        idx++;
                    }
                    isImage = await imageFile.FileListUpload(info.shop_cd.ToString(), model.formImages, fileNames.ToList(), "StoreImage");

                    

                    if (isImage.code.Equals("00"))
                    {
                        nlogger.Info("매장정보요청 가맹점 이미지 신청..");

                        var serviceReq = await dgShop.Post<CodeMsg, RequestCommon>("/api/RequestService/SetServiceRequest", new RequestCommon
                        {
                            job_gbn = "1",
                            mod_name = info.login_name,
                            mod_ucode = info.login_code,
                            seq = 0,
                            service_data = JsonConvert.SerializeObject(storeModel,Formatting.Indented, new JsonSerializerSettings
                                            {
                                                NullValueHandling = NullValueHandling.Ignore
                                            }),
                            service_gbn = "200",
                            shop_cd = info.shop_cd,
                            status = "10",
                        });

                        if (serviceReq.code.Equals("00"))
                        {
                            nlogger.Info($"매장정보요청 가맹점 이미지 성공 {info.shop_cd}");
                            return Ok(new
                            {
                                code = "00",
                                Msg = "성공"
                            });
                        }
                        else
                        {
                            nlogger.Info($"매장정보요청 가맹점 이미지 실패 {serviceReq.msg}");
                            nlogger.Info($"매장정보요청 가맹점 이미지 실패 shopCd === {serviceReq.msg}, Model ===={JsonConvert.SerializeObject(storeModel)}");

                            return Ok(new
                            {
                                code = "99",
                                Msg = serviceReq.msg
                            });
                        }
                    }
                    else
                    {
                        nlogger.Info($"매장정보요청 가맹점 이미지 실패 {isImage.msg}");
                        nlogger.Info($"매장정보요청 가맹점 이미지 실패 shopCd === {isImage.msg}, Model ===={JsonConvert.SerializeObject(storeModel)}");

                        return Ok(new
                        {
                            code = "99",
                            Msg = isImage.data
                        });
                    }
                }
                catch (Exception e)
                {
                    ViewBag.Error = e.Message;
                    return Ok(new
                    {
                        code = "99",
                        Msg = ViewBag.Error
                    });
                }
                return Ok(new
                {
                    code = "99",
                    Msg = ViewBag.Error
                });
            }
            /*휴대전화번호*/
            if (model.ReqSelected == "2")
            {
                if (model.mobile.Replace("-","") == info.shop_mobile.Replace("-", ""))
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "기존에 입력된 휴대전화번호와 동일합니다."
                    });
                }
                if (string.IsNullOrEmpty(model.mobile))
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "변경하실 휴대폰번호를 입력해주세요."
                    });
                }
                
                if (model.formImages == null)
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "첨부 서류가 존재하지않습니다. 파일 첨부 후 이용바랍니다."
                    });
                }
                if (model.formImages.Count() < 1)
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "첨부서류를 확인해주세요."
                    });
                }
                /*Model data Binding*/

                var datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
                var imageFile = new ImageUtils();
                var isImage = new ResultSingle<string>();
                var fileName = "";
                var fileNames = new string[model.formImages.Count()];

                var storeModel = new StoreRequest(model);
                storeModel.BeforeShopName = info.shop_name;
                storeModel.BeforeMobile = info.shop_mobile;
                storeModel.fileNames = new List<string>();
#if DEBUG
                var imageURL = "https://ceo.daeguro.co.kr";
#else
            var imageURL = "https://ceo.daeguro.co.kr";
            //var imageURL = "https://ceoimage.daeguro.co.kr:45013";
#endif
                try
                {
                    int idx = 0;
                    foreach (var files in fileNames)
                    {
                        fileName = datetime + DateTime.Now.ToString("ffff") + idx + "_" + "201" + ".jpg";
                        fileNames[idx] = fileName;
                        storeModel.fileNames.Add( imageURL + "/RequestServiceImage" + "/StoreImage" + "/" + nowDate + "/" + info.shop_cd + "/" + fileName);
                        idx++;
                    }
                    isImage = await imageFile.FileListUpload(info.shop_cd.ToString(), model.formImages, fileNames.ToList(), "StoreImage");



                    if (isImage.code.Equals("00"))
                    {
                        nlogger.Info("매장정보요청 휴대전화번호 이미지 신청..");

                        var serviceReq = await dgShop.Post<CodeMsg, RequestCommon>("/api/RequestService/SetServiceRequest", new RequestCommon
                        {
                            job_gbn = "1",
                            mod_name = info.login_name,
                            mod_ucode = info.login_code,
                            seq = 0,
                            service_data = JsonConvert.SerializeObject(storeModel, Formatting.Indented, new JsonSerializerSettings
                            {
                                NullValueHandling = NullValueHandling.Ignore
                            }),
                            service_gbn = "201",
                            shop_cd = info.shop_cd,
                            status = "10",
                        });

                        if (serviceReq.code.Equals("00"))
                        {
                            nlogger.Info($"매장정보요청 휴대전화번호 이미지 성공 {info.shop_cd}");
                            return Ok(new
                            {
                                code = "00",
                                Msg = "성공"
                            });
                        }
                        else
                        {
                            nlogger.Info($"매장정보요청 휴대전화번호 이미지 실패 {serviceReq.msg}");
                            nlogger.Info($"매장정보요청 휴대전화번호 이미지 실패 shopCd === {serviceReq.msg}, Model ===={JsonConvert.SerializeObject(storeModel)}");

                            return Ok(new
                            {
                                code = "99",
                                Msg = serviceReq.msg
                            });
                        }
                    }
                    else
                    {
                        nlogger.Info($"매장정보요청 휴대전화번호 이미지 실패 {isImage.msg}");
                        nlogger.Info($"매장정보요청 휴대전화번호 이미지 실패 shopCd === {isImage.msg}, Model ===={JsonConvert.SerializeObject(storeModel)}");

                        return Ok(new
                        {
                            code = "99",
                            Msg = isImage.data
                        });
                    }
                }
                catch (Exception e)
                {
                    ViewBag.Error = e.Message;
                    return Ok(new
                    {
                        code = "99",
                        Msg = ViewBag.Error
                    });
                }
                return Ok(new
                {
                    code = "99",
                    Msg = ViewBag.Error
                });

            }
            /*로고 이미지*/
            if (model.ReqSelected == "3")
            {
                if (model.iFile2 == null)
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "로고이미지를 확인해주세요."
                    });
                }
                /*Model data Binding*/

                var datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
                
                var imageFile = new ImageUtils();
                var isImage = new ResultSingle<string>();
                var fileName = "";
                var fileNames = new string[1];

                /*매장 전 로고 이미지 가져오기*/
                var temp = await dgShop.Post<ShopStoreInfo, Models.RequestModel.Request>("DefaultInfo",  new Models.RequestModel.Request
                {
                    shop_cd = info.shop_cd,
                    cccode = info.cccode
                });

                if (!temp.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "이미지를 불러오다 실패했습니다. 새로고침 후 이용부탁드립니다."
                    });
                }

                var shopInfoData = temp.data.SingleOrDefault();

                var storeModel = new StoreRequest(model);
                storeModel.BeforeShopName = info.shop_name;
                storeModel.BeforeMobile = info.shop_mobile;
                storeModel.fileNames = new List<string>();

                if (!string.IsNullOrEmpty(shopInfoData.app_file_name))
                {
                    storeModel.beforeImageURL = string.Concat("https://image.daeguro.co.kr:40443/images/", shopInfoData.app_file_name);
                }

                   

#if DEBUG
                var imageURL = "https://ceo.daeguro.co.kr";
#else
            var imageURL = "https://ceo.daeguro.co.kr";
            //var imageURL = "https://ceoimage.daeguro.co.kr:45013";
#endif
                try
                {
                    int idx = 0;
                    fileName = datetime + DateTime.Now.ToString("ffff") + idx + "_" + "202" + ".jpg";
                    //fileNames[idx] = fileName;
                    storeModel.fileNames.Add(imageURL + "/RequestServiceImage" + "/StoreImage" + "/" + nowDate + "/" + info.shop_cd + "/" + fileName);
                    isImage = await imageFile.FileUpload(info.shop_cd.ToString(), model.iFile2, fileName, "StoreImage");

                    if (isImage.code.Equals("00"))
                    {
                        nlogger.Info("매장정보요청 로고 이미지 신청..");
                        storeModel.afterImageURL = storeModel.fileNames[0].ToString();
                        var serviceReq = await dgShop.Post<CodeMsg, RequestCommon>("/api/RequestService/SetServiceRequest", new RequestCommon
                        {
                            job_gbn = "1",
                            mod_name = info.login_name,
                            mod_ucode = info.login_code,
                            seq = 0,
                            service_data = JsonConvert.SerializeObject(storeModel, Formatting.Indented, new JsonSerializerSettings
                            {
                                NullValueHandling = NullValueHandling.Ignore
                            }),
                            service_gbn = "202",
                            shop_cd = info.shop_cd,
                            status = "10",
                        });

                        if (serviceReq.code.Equals("00"))
                        {
                            nlogger.Info($"매장정보요청 로고 이미지 성공 {info.shop_cd}");
                            return Ok(new
                            {
                                code = "00",
                                Msg = "성공"
                            });
                        }
                        else
                        {
                            nlogger.Info($"매장정보요청 로고 이미지 실패 {serviceReq.msg}");
                            nlogger.Info($"매장정보요청 로고 이미지 실패 shopCd === {serviceReq.msg}, Model ===={JsonConvert.SerializeObject(storeModel)}");

                            return Ok(new
                            {
                                code = "99",
                                Msg = serviceReq.msg
                            });
                        }
                    }
                    else
                    {
                        nlogger.Info($"매장정보요청 로고 이미지 실패 {isImage.msg}");
                        nlogger.Info($"매장정보요청 로고 이미지 실패 shopCd === {isImage.msg}, Model ===={JsonConvert.SerializeObject(storeModel)}");

                        return Ok(new
                        {
                            code = "99",
                            Msg = isImage.data
                        });
                    }
                }
                catch (Exception e)
                {
                    ViewBag.Error = e.Message;
                    return Ok(new
                    {
                        code = "99",
                        Msg = ViewBag.Error
                    });
                }
                return Ok(new
                {
                    code = "99",
                    Msg = ViewBag.Error
                });
            }
            /*valid check End*/
            if (model == null)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "잘못된 접근입니다."
                });
            }

            return Ok(new
            {
                code = "00",
                Msg = "성공"
            });
        }
        #region 매장 주소
        [HttpPost]
        public async Task<IActionResult> ServiceAddress(AddressViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(model.jibun))
            {

                return BadRequest(new
                {
                    code = "99",
                    Msg = "주소를 입력해주세요"
                });
            }
            if (string.IsNullOrEmpty(model.SIDO))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "주소를 다시 작성해주세요"
                });
            }
            PosWebApp.Models.RequestModel.Request req = new PosWebApp.Models.RequestModel.Request()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };

            var temp = await dgShop.Post<ShopStoreInfo, PosWebApp.Models.RequestModel.Request>("DefaultInfo", req);
            if (temp.code.Equals("00"))
            {
                var shopDefaultInfo = temp.data.SingleOrDefault();
               
                RequestAddress RequestJsonData = new RequestAddress(model);
                RequestJsonData.b_jibun = shopDefaultInfo.addr2;
                RequestJsonData.b_roadAdd = shopDefaultInfo.addr1;
                RequestJsonData.b_detail_address = shopDefaultInfo.loc;


                var serviceReq = await dgShop.Post<CodeMsg, RequestCommon>("/api/RequestService/SetServiceRequest", new RequestCommon
                {
                    file_name = "",
                    job_gbn = "",
                    mod_name = info.login_name,
                    mod_ucode = info.login_code,
                    seq = 0,
                    service_data = JsonConvert.SerializeObject(RequestJsonData),
                    //existing = JsonConvert.SerializeObject(temp.data.SingleOrDefault()),
                    service_gbn = "200",
                    shop_cd = info.shop_cd,
                    status = "10"
                });

                if (serviceReq.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        Msg = "성공"
                    });
                }

                return BadRequest(new
                {
                    code = "99",
                    Msg = serviceReq.msg
                });

            }
            return BadRequest(new
            {
                code = "99",
                Msg = temp.msg
            });
        }
        #endregion

        #region 메뉴 관리
        [HttpPost]
        public async Task<IActionResult> MenuImageDel(RequestMenuDel menu)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            if (string.IsNullOrEmpty(menu.groupCd) || string.IsNullOrEmpty(menu.menuCd) || string.IsNullOrEmpty(menu.imageName))
            {
                return Ok(new
                {
                    Code = "99",
                    Msg = "서비스요청 에러입니다. 새로고침 후 이용부탁드립니다."
                });
            }
            if (menu.imageName.Equals("/img/image-gallery.png"))
            {
                return Ok(new
                {
                    Code = "99",
                    Msg = "삭제 할 이미지가 존재하지않습니다."
                });
            }

            //RequestCommonAPI RSapi = new RequestCommonAPI(dgShop);
            //var beforeModel = await RSapi.ReqeustServiceGBN(new RequestCommon
            //{
            //    shop_cd = info.shop_cd,
            //    job_gbn = "1",
            //    status = '',
            //    service_gbn = param.request_type,
            //    from = param.from.Replace("-", ""),
            //    to = param.to.Replace("-", "")

            //});
            var serviceReq = await dgShop.Post<CodeMsg, RequestCommon>("/api/RequestService/SetServiceRequest", new RequestCommon
            {
                file_name = "",
                job_gbn = "1",
                mod_name = info.login_name,
                mod_ucode = info.login_code,
                seq = 0,
                service_data = JsonConvert.SerializeObject(menu),
                service_gbn = "301",
                shop_cd = info.shop_cd,
                status = "10",
                filter = menu.menuCd
            });
            if (serviceReq.code.Equals("00"))
            {
                return Ok(new
                {
                    Code = "00",
                    Msg = "완료"
                });
            }
            return Ok(new
            {
                Code = "99",
                Msg = serviceReq.msg
            });

        }
        [HttpPost]
        public async Task<IActionResult> MenuImageIns(SetMenuIns menu)
        {
            string beforeImageURL = "https://image.daeguro.co.kr:40443/" + "images/"; 
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            ViewBag.kakaoDaeguro = kakaoDaeguroURL;


            if (string.IsNullOrEmpty(menu.groupCd) || string.IsNullOrEmpty(menu.menuCd) || string.IsNullOrEmpty(menu.imageName)
                || string.IsNullOrEmpty(menu.menuName) || string.IsNullOrEmpty(menu.iFile.FileName))
            {
                return BadRequest(new
                {
                    Code = "99",
                    Msg = "서비스요청 에러입니다. 새로고침 후 이용부탁드립니다."
                });
            }

            if(menu.iFile.Length > 16777215)
            {
                return BadRequest(new
                {
                    Code = "99",
                    Msg = "파일 사이즈가 너무큽니다. 파일크기를 줄이시거나 관리자에게 문의바랍니다."
                });
            }

            /*이미지 이름 Filter*/
            var requestModel = new RequestMenuIns(menu);
            string exising_imageURL = beforeImageURL + menu.imageName;
            requestModel.image_url = exising_imageURL;
            menu.imageName = menu.imageName.Replace(string.Join('/', info.cccode, info.shop_cd) + "/", "");

            if (menu.imageName.Equals("/"))
            {
                exising_imageURL = "";
            }

            var datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            var imageFile = new ImageUtils();
            var isImage = new ResultSingle<string>();
            var fileName = "";
#if DEBUG
            var imageURL = "https://ceo.daeguro.co.kr";
#else
            var imageURL = "https://ceo.daeguro.co.kr";
            //var imageURL = "https://ceoimage.daeguro.co.kr:45013";
#endif
            try
            {
                //    //로그 넣어야됨
                if (string.IsNullOrEmpty(menu.iFile.FileName))
                {
                    ModelState.AddModelError("", "메뉴 이미지가 없습니다. 등록 후 이용해주세요.");
                    return PartialView("MenuChange", menu);
                }
                else
                {
                    fileName = datetime + "_" + "300" + ".jpg";
                    isImage = await imageFile.FileUpload(info.shop_cd.ToString(), menu.iFile, fileName, "MenuImage");

                    if (isImage.code.Equals("00"))
                    {
                        nlogger.Info("메뉴 이미지 변경신청...");
                        requestModel.imageName = fileName;
                        requestModel.afterImageURL = imageURL + "/RequestServiceImage" + "/MenuImage/" + isImage.data + "/" + info.shop_cd + "/" + fileName;

                        var serviceReq = await dgShop.Post<CodeMsg, RequestCommon>("/api/RequestService/SetServiceRequest", new RequestCommon
                        {
                            file_name = requestModel.imageName,
                            job_gbn = "1",
                            mod_name = info.login_name,
                            mod_ucode = info.login_code,
                            seq = 0,
                            service_data = JsonConvert.SerializeObject(requestModel),
                            service_gbn = "300",
                            shop_cd = info.shop_cd,
                            status = "10",
                            filter = menu.menuCd
                        });


                        if (serviceReq.code.Equals("00"))
                        {
                            nlogger.Info("메뉴 이미지 변경신청...성공");
                            return PartialView("MenuChange", menu);
                        }
                        else
                        {
                            nlogger.Info($"메뉴 이미지 변경신청...실패 {serviceReq.msg}");
                            ModelState.AddModelError("", serviceReq.msg);
                            return PartialView("MenuChange", menu);
                        }
                    }
                    else
                    {
                        nlogger.Info($"메뉴 이미지 변경신청...실패 {isImage.msg}");
                        ModelState.AddModelError("", "이미지 저장중 에러가 발생했습니다. 관리자에게 문의해주세요.");
                        return PartialView("MenuChange", menu);
                    }
                }
            }
            catch (Exception e)
            {
                ViewBag.Error = e.Message;
            }

            return View();
        }
        public async Task<IActionResult> MenuServiceImage(string idx = null, string item = null, string name = null)
        {
            ViewBag.kakaoDaeguro = kakaoDaeguroURL;
            if (string.IsNullOrEmpty(idx) || string.IsNullOrEmpty(item) || string.IsNullOrEmpty(name))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "새로고침후 다시 이용해주세요."
                });
            }
            RequestCommonAPI RSapi = new RequestCommonAPI(dgShop);
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            var req = await RSapi.RequestServiceList(new RequestCommon
            {
                shop_cd= info.shop_cd,
                job_gbn = "1",
                status = "%",
                service_gbn = "300",
                from = "20221231",
                to = "20300101"
            });
            var statusCancel = new[] { "10", "30" };
            var statusCode = req.data.Where(x => statusCancel.Contains(x.status)).ToList();
            var filterMenuCode = statusCode.Where(x => x.service_data.Contains("\"menuCd\":\"" + item)).ToList();

            if(req.data.Count() > 0)
            {
                if(filterMenuCode.Count() > 0)
                {
                    return Ok(new
                    {
                        code = "99",
                        Msg = "이전 변경 신청 이력이 존재합니다.<br>" + "심사 결과는<span class=" + '"' + "primary-color" + '"' + ">\"변경 요청 이력\"</span>메뉴에서 확인해주세요."
                    });
                }
            }

            var menuRequest = await adminApi.GetSingle<ResponseMenuInfo>(string.Join('/', "Menu", item));
            SetMenuIns info2 = new SetMenuIns()
            {
                groupCd = menuRequest.data.menuGroupCd,
                menuCd = menuRequest.data.menuCd,
                menuName = menuRequest.data.menuName,
                imageName = name
            };
            return PartialView("MenuChange", info2);
        }
        #endregion

        #region 적립금 
        public async Task<IActionResult> PointChange()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            return View();
        }
        [HttpPost]
        public async Task<IActionResult> PointChange(ServiceConfirm model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (model == null)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "실패"
                });
            }

            if (model.formImages == null)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "첨부파일을 확인해주세요."
                });
            }


            var datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            var imageFile = new ImageUtils();
            var isImage = new ResultSingle<string>();
            var fileName = "";
            var fileNames = new string[model.formImages.Count()];

#if DEBUG
            var imageURL = "https://ceo.daeguro.co.kr";
#else
            var imageURL = "https://ceo.daeguro.co.kr";
            //var imageURL = "https://ceoimage.daeguro.co.kr:45013";
#endif
            var confirmRequest = new ShopConfirmService(info.shop_cd);
            confirmRequest.fileNames = new List<string>();
            try
            {
                foreach (var picture in model.formImages)
                {
                    if (picture.Length > 6291456)
                    {
                        return Ok(new
                        {
                            code = "99",
                            Msg = picture.FileName + "이미지가 너무 큽니다."
                        });
                    }
                }

                int idx = 0;
                foreach (var files in fileNames)
                {
                    fileName = datetime + DateTime.Now.ToString("ffff") + idx + "_" + "400" + ".jpg";
                    fileNames[idx] = fileName;
                    confirmRequest.fileNames.Add(imageURL + "/RequestServiceImage" + "/CanCellation" + "/" + DateTime.Now.ToString("yyyyMMdd") + "/" + info.shop_cd + "/" + fileName);
                    idx++;
                }
                isImage = await imageFile.FileListUpload(info.shop_cd.ToString(), model.formImages, fileNames.ToList(), "CanCellation");




                if (isImage.code.Equals("00"))
                {
                    //nlogger.Info("매장정보요청 가맹점 이미지 신청..");

                    var serviceReq = await dgShop.Post<CodeMsg, RequestCommon>("/api/RequestService/SetServiceRequest", new RequestCommon
                    {
                        job_gbn = "1",
                        mod_name = info.login_name,
                        mod_ucode = info.login_code,
                        seq = 0,
                        service_data = JsonConvert.SerializeObject(confirmRequest, Formatting.Indented, new JsonSerializerSettings
                        {
                            NullValueHandling = NullValueHandling.Ignore
                        }),
                        service_gbn = "500",
                        shop_cd = info.shop_cd,
                        status = "10",
                    });

                    if (serviceReq.code.Equals("00"))
                    {
                         nlogger.Info($"계좌변경 이미지 성공 {info.shop_cd}");
                        return Ok(new
                        {
                            code = "00",
                            Msg = "성공"
                        });
                    }
                    else
                    {
                          nlogger.Info($"계좌변경 이미지 실패 {serviceReq.msg}");
                          nlogger.Info($"계좌변경 이미지 실패 shopCd === {serviceReq.msg}, Model ===={JsonConvert.SerializeObject(confirmRequest)}");

                        return Ok(new
                        {
                            code = "99",
                            Msg = serviceReq.msg
                        });
                    }
                }
                else
                {
                     nlogger.Info($"계좌변경 이미지 실패 {isImage.msg}");
                     nlogger.Info($"계좌변경 이미지 실패 shopCd === {isImage.msg}, Model ===={JsonConvert.SerializeObject(confirmRequest)}");

                    return Ok(new
                    {
                        code = "99",
                        Msg = isImage.data
                    });
                }
            }
            catch (Exception e)
            {
                ViewBag.Error = e.Message;
                return Ok(new
                {
                    code = "99",
                    Msg = ViewBag.Error
                });
            }

            return View();
        }
        #endregion

        #region 공통
        private List<SelectListItem> GetType()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "요청",
                Value = "10"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "심사중",
                Value = "30"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "완료",
                Value = "40"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "반려",
                Value = "35"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "취소",
                Value = "50"
            });

            return temp;
        }
        private List<SelectListItem> GetRquestType()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            //temp.Add(new SelectListItem()
            //{
            //    Selected = true,
            //    Text = "사업자 정보변경",
            //    Value = "100"
            //});
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "매장정보(가맹점명)",
                Value = "200"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "매장정보(휴대전화번호)",
                Value = "201"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "매장정보(로고이미지)",
                Value = "202"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "메뉴 이미지 입력/수정",
                Value = "300"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "메뉴 이미지 삭제 요청",
                Value = "301"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "가맹점 해지 요청",
                Value = "400"
            });
            return temp;
        }

        /*
         * Cancel Reqeust
         */
        [HttpPost]
        public async Task<IActionResult> serviceCancel(RequestCancal model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if(string.IsNullOrEmpty(model.seq) || string.IsNullOrEmpty(model.service))
            {
                return Ok(new
                {
                    Code = "99",
                    Msg = "필수값을 입력해주세요."
                });
            }
            if(model.service.Equals("300") || model.service.Equals("301") || model.service.Equals("302"))
            {
                model.menuCode = "\"menuCd\"" + ":" + "\"" + model.menuCode + "\"";
            }
            else
            {
                model.menuCode = null;
            }
            var serviceReq = await dgShop.Post<CodeMsg, RequestCommon>("/api/RequestService/SetServiceRequest", new RequestCommon
            {
                file_name = "",
                job_gbn = "",
                mod_name = info.login_name,
                mod_ucode = info.login_code,
                seq = Convert.ToInt32(model.seq),
                service_data = null,
                service_gbn = model.service, // 매정정보 > 카테고리 변경신청
                filter = model.menuCode,
                shop_cd = info.shop_cd,
                status = "20"
            });


            if (serviceReq.code.Equals("00"))
            {
                return Ok(new 
                { 
                    code = "00",
                    msg = "성공"
                });
            }
            else
            {
                return Ok(new
                {
                    code = "99",
                    Msg = serviceReq.msg
                });

            }
           
        }
        #endregion
    }
}
