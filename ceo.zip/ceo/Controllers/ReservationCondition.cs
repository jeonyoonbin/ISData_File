﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Models.Reservation;
using PosWebApp.Models.Reservation.Condition.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Reservation;
using PosWebApp.ViewModels.Reservation.Condition;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UAParser;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ReservationCondition : Controller
    {
        private readonly ReservationService_T reservationService;

        public ReservationCondition (ReservationService_T reservation)
        {
            this.reservationService = reservation;
        }

        public async Task<IActionResult> Index(ReservationViewDateTime ViewModel, string selectedType, int? pageNumber)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            var now = DateTime.Now;
            var dateEnd = "";
            var dateBegin = "";
            dateEnd = now.AddMonths(1).ToString("yyyy-MM-dd");
            dateBegin =  now.ToString("yyyy-MM-dd");
            var type = "";

            if(!string.IsNullOrEmpty(ViewModel.from) || !string.IsNullOrEmpty(ViewModel.to))
            {
                var convertFrom = Utils.StringFormatToDateAmPMDel(ViewModel.from);
                var convertTo = Utils.StringFormatToDateAmPMDel(ViewModel.to);
                dateEnd = convertTo;
                dateBegin = convertFrom;
            }else
            {
                ViewModel = new ReservationViewDateTime();
                ViewModel.pageNum = (int)1;
                ViewModel.from = dateBegin;
                ViewModel.to = dateEnd;
            }


            if (pageNumber == null)
            {
                pageNumber = 1;
            }
            
            int pageSize = 10;
            var browser = HttpContext.Request.Headers["User-Agent"].ToString();
            var uaParser = Parser.GetDefault();
            ClientInfo c = uaParser.Parse(browser);

            string device = c.UA.Family;

            if (device.IndexOf("Mobile") > -1)
            {
                pageSize = 5;
            }
            //if (ViewModel.options == null)
            //{
            //    ViewModel.from = dateBegin;
            //    ViewModel.to = dateEnd;
            //    ViewModel.pageNum = (int)pageNumber;
            //    ViewModel.options = "30";
            //    ViewModel.selectedType = "ALL";
            //}
            if(ViewBag.option != null)
            {
                ViewModel.pageNum = (int)pageNumber;
                OptionsScaling(ViewModel,now);
            }
            

            if (ViewModel.selectedType.Equals("a"))
            {
                type = "ALL";
                ViewModel.selectedType = selectedType == "a" ? "ALL" : SelectedDownScaling(selectedType);
            }else
            {
                type = SelectedDownScaling(selectedType);
                ViewModel.selectedType = type;
            }
            var query = QueryHelpers.AddQueryString("/reser-list/" + type + "?", new Dictionary<string, string>()
            {
                {"shopCd", info.shop_cd.ToString()},
                {"dateBegin", ViewModel.from.Replace("-","") },
                {"dateEnd", ViewModel.to.Replace("-","") },
                {"jobGbn" , "1" },
                {"page", pageNumber.ToString() },
                {"pageRows", pageSize.ToString()}
            });
            var req = await reservationService.GetCondition<ResponseReservationData>(query);

            if (req.code.Equals("00"))
            {

                var scalingList = req.data;
                
                if (!string.IsNullOrEmpty(ViewModel.inputText))
                {
                    scalingList = scalingList.Where(x => x.orderNo.Contains(ViewModel.inputText)).ToList();
                }
                ViewBag.totalCnt = req;
                //ViewBag.ListTimeModel = ReserPagination<ResponseReservationData>.Create(req.data.AsQueryable<ResponseReservationData>(),
                //pageNumber ?? 1, pageSize, ViewModel.from, ViewModel.to, ViewModel.selectedType);
                ViewBag.statusType = type;
                ViewBag.ListTimeModel = scalingList;
                return View(ViewModel);
            }
            ViewBag.ListTimeModel = new ResultReservationCondition<ResponseReservationData>();
            return View();
        }


        public IActionResult PageFilter(ReservationViewDateTime model, string selectType, int? pageNumber)
        {
            return ViewComponent("ReservationPageNation", new
            {
                model = model,
                selectType = selectType,
                pageNumber = pageNumber
            });
        }

        #region method
        public string SelectedDownScaling(string type)
        {
            if (string.IsNullOrEmpty(type))
            {
                return "ALL";
            }
            var returnString = "";

            switch (type)
            {
                case "a":
                    returnString = "ALL";
                    break;
                case "w":
                    returnString = "10";
                    break;
                case "r":
                    returnString = "12";
                    break;
                case "o":
                    returnString = "30";
                    break;
                case "c":
                    returnString = "40";
                    break;
                case "n":
                    returnString = "90";
                    break;
                case "":
                    returnString = "ALL";
                    break;
            }

            return returnString;
        }
        public ReservationViewDateTime OptionsScaling(ReservationViewDateTime model, DateTime now)
        {
            var returnString = "";

            switch (model.options)
            {
                case "3":
                    model.from = now.ToString("yyyy-MM-dd");
                    model.to = now.AddDays(3).ToString("yyyy-MM-dd");
                    break;
                case "7":
                    model.from = now.ToString("yyyy-MM-dd");
                    model.to = now.AddDays(7).ToString("yyyy-MM-dd");
                    break;
                case "14":
                    model.from = now.ToString("yyyy-MM-dd");
                    model.to = now.AddDays(14).ToString("yyyy-MM-dd");
                    break;
                case "30":
                    model.from = now.ToString("yyyy-MM-dd");
                    model.to = now.AddMonths(1).ToString("yyyy-MM-dd");
                    break;
                case "90":
                    model.from = now.ToString("yyyy-MM-dd");
                    model.to = now.AddMonths(3).ToString("yyyy-MM-dd");
                    break;
            }

            return model;
        }

        #endregion
    }
}
