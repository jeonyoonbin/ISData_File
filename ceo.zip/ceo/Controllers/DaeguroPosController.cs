﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.Common;
using PosWebApp.Models.RequestDaeguroPos;
using PosWebApp.Models.Reservation.Apply.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.Reservation;
using PosWebApp.Services.ShopMall;
using PosWebApp.ViewModels.RegDaeguroPos;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    public class DaeguroPosController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly ReservationService_T reservationService;
       
        private readonly string localurl;
        private readonly string ReservationFlag;

        public DaeguroPosController(DgShopApiService api, ReservationService_T reservationService, IConfiguration configuration)
        {
            dgShop = api;
            this.reservationService = reservationService;
            localurl = configuration.GetValue<string>("api:local");
            this.ReservationFlag = configuration.GetValue<string>("inspection:ReservationFlag");
           
        }

        public IActionResult Index()
        {
            return View();
        }

        //[HttpGet("LinkTo/{type}/{mapp_gbn}/{mapp_code}/{uname}/{job_name}")]
        //public IActionResult Index(string type, string mapp_gbn, string mapp_code, string uname, string job_name)
        //{
        //    ViewData["mapp"] = mapp_gbn;
        //    ViewData["code"] = mapp_code;
        //    ViewData["reqUrl"] = job_name;
        //    ViewData["uname"] = uname;
        //    ViewData["type"] = type;
        //    return View();
        //}

        [HttpGet("LinkTo")]
        public IActionResult Index(string url)
        {
            //DaeguroPosLinkToViewModel obj = null;
            //try
            //{
            //    var temp = Utils.Aes_Decrypt(url, Utils.aes_key);
            //    obj = JsonConvert.DeserializeObject<DaeguroPosLinkToViewModel>(temp);


            //}
            //catch (Exception e)
            //{
            //    Debug.WriteLine(e.Message);
            //}

            //if (obj == null)
            //{
            //    return BadRequest();
            //}
            //else
            //{
            //    ViewData["mapp"] = obj.mapp;
            //    ViewData["code"] = obj.code;
            //    ViewData["reqUrl"] = obj.job_name;
            //    ViewData["uname"] = obj.uname;
            //    ViewData["type"] = obj.type;
            //}


            return View();
        }

        [HttpPost]
        public async Task<IActionResult> DaeguroLinkTo(string url)
        {
            //if (!ModelState.IsValid)
            //{
            //    return Ok(new
            //    {
            //        code = "99",
            //        message = "입력 데이터가 잘못 되었습니다"
            //    });
            //}
            DaeguroPosLinkToViewModel model = null;
           
            var temp = Utils.Aes_Decrypt(url, Utils.aes_key);
            model = JsonConvert.DeserializeObject<DaeguroPosLinkToViewModel>(temp);

            if(model == null)
            {
                return Ok(new
                {
                    code = "99",
                    message = "입력 데이터가 잘못 되었습니다"
                });
            }

            if (JobToUrl(model.job_name).Length < 1)
            {
                return Ok(new
                {
                    code = "99",
                    msg = "작업 내용이 없습니다"
                });
            }

            RqeuestPosLink linkto = new RqeuestPosLink()
            {
                mapp_code = model.code,
                mapp_gbn = model.mapp,
                mapp_type = model.type,
                job_gbn = "1",
            };
            Result<ShopSessionDefaultInfo> shopInfo = await dgShop.Post<ShopSessionDefaultInfo, RqeuestPosLink>("LinkTo", linkto);
            if (shopInfo.data == null || shopInfo.data.Count == 0)
            {
                return Ok(new
                {
                    code = "99",
                    msg = "사용자 정보가 없습니다"
                });
            }

            var myShop = shopInfo.data.SingleOrDefault<ShopSessionDefaultInfo>(x => x.use_gbn.Equals("Y"));
            var reser = await reservationService.Get<ResponseReservationApply>("apply?shopCode=" + myShop.shop_cd);

            if (!reser.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "99",
                    msg = "사용자 정보가 없습니다"
                });
            }
            if (myShop != null)
            {
                //2023.03.16 멀티샵 infomation
                var mulitShop = await dgShop.Post<ResponseShopAccountInfo, Models.RequestModel.Request>("/api/ShopManagement/AccInfo", new Models.RequestModel.Request
                {
                    cccode = myShop.cccode,
                    shop_cd = myShop.shop_cd
                });

                if (mulitShop.code.Equals("00"))
                {
                    var mulitSingle = mulitShop.data.SingleOrDefault();

                    myShop.multMasterCd = mulitSingle.multiShopCd;
                    myShop.multshopYn = mulitSingle.multiShopYn;
                    myShop.representativeYn = mulitSingle.representativeYn;
                }


                myShop.login_code = myShop.shop_cd;
                myShop.login_name = myShop.shop_id;
                myShop.u_code = "P";
                myShop.reservationYN = reser.data.SingleOrDefault().status;

                var sessionString = JsonConvert.SerializeObject(myShop);
                HttpContext.Session.SetString("shopDefaultInfo", sessionString);


                var now = DateTime.Now;
                var EndTime = DateTime.ParseExact(ReservationFlag, "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture);
                var diffTime = DateTime.Compare(EndTime, now);


                if (myShop.shop_type == "9")
                {
                    if (myShop.reservationYN.Equals("30"))
                    {
                        if (diffTime > 0)
                        {
                            HttpContext.Response.Cookies.Append("reser", "N");

                            return Ok(new
                            {
                                code = "00",
                                msg = "성공",
                                data = string.Concat(localurl, JobToUrl("main"))
                            });
                        }
                        else
                        {
                            HttpContext.Response.Cookies.Append("reser", "Y");

                            return Ok(new
                            {
                                code = "00",
                                msg = "성공",
                                data = string.Concat(localurl, JobToUrl("reservation"))
                            });
                        }
                    }
                    else if (myShop.reservationYN.Equals("20"))
                    {
                        ModelState.AddModelError(string.Empty, "예약서비스 심사중입니다. 심사완료 후 이용부탁드립니다.");
                        return Ok(new
                        {
                            code = "70",
                            msg = "성공",
                            data = string.Concat(localurl, JobToUrl(model.job_name))
                        });
                    }
                    else if (myShop.reservationYN.Equals("00"))
                    {
                        ModelState.AddModelError(string.Empty, "예약서비스 신청 후 이용바랍니다. ");
                        return Ok(new
                        {
                            code = "70",
                            msg = "성공",
                            data = string.Concat(localurl, JobToUrl(model.job_name))
                        });
                    }
                }



                if (myShop.reservationYN.Equals("30"))
                {
                    HttpContext.Response.Cookies.Append("reser", "N");

                }
                else if (myShop.reservationYN.Equals("00") || myShop.reservationYN.Equals("20"))
                {
                    HttpContext.Response.Cookies.Append("reser", "N");
                    //배달/포장만하는경우 -> 신청페이지
                    // 둘다잇을경우 -> main/index

                }



                return Ok(new
                {
                    code = "00",
                    msg = "성공",
                    data = string.Concat(localurl, JobToUrl(model.job_name))
                });
            }

            return Ok(new
            {
                code = "99",
                msg = "알 수 없는 오류",
                data = string.Concat(localurl, JobToUrl(model.job_name))
            });
        }



        private string JobToUrl(string job_name)
        {
            switch (job_name.ToLower())
            {
                case "operate": return "Operate/Index";
                case "account": return "StoreAccount/Index";
                case "biz": return "BizInfo/Index";
                case "store": return "Store/Index";
                case "menu_group": return "Menu/GetGroupSelect";
                case "menu": return "Menu/MenuInquiry";
                case "main": return "Main/Index";
                case "statics": return "Statics/Sales";
                case "reservation": return "Reservation/Index";
                case "shopmall": return "shopmall";
                default:
                    return "";
            }
        }
    }
}
