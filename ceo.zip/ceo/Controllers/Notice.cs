﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Notice.Request;
using PosWebApp.ApiModels.Notice.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class Notice : Controller
    {
        private readonly DgShopApiService dgShop;

        public Notice(DgShopApiService dgShop)
        {
            this.dgShop = dgShop;
        }
        public async Task<IActionResult> Index(string text, string choice, int? pageNumber)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            
            if(pageNumber == null)
            {
                pageNumber = 1;
            }

            if (string.IsNullOrEmpty(text))
            {
                text = null;
                choice = null;
            }
          
            var req = await dgShop.Post<ResponseNoticeListV2, RequestNoticeV2>("/api/NoticeManagement/GetNoticeList_V2", new RequestNoticeV2
            {
                job_gbn = "11",
                noticeGbn = "2",
                dispGbn = "N",
                frDate = null,
                toDate = null,
                pageNum = pageNumber == 0 ? "0" : pageNumber.ToString(),
                pageCnt = 10.ToString()
            });

            if (req.code.Equals("00"))
            {
                ViewBag.pageNumber = pageNumber == 0 ? "0" : pageNumber.ToString();

                var counting = req.msg.Split(','); // 1.total 2. page

                ViewBag.searchText = text;
                ViewBag.count = counting[0];
                ViewBag.pageCnt = counting[1];
                ViewBag.choice = choice;
                if (string.IsNullOrEmpty(choice))
                {
                    return View(req.data);
                }
                if (choice.Equals("subject"))
                {
                    return View(req.data.Where(x => x.noticeTitle.Contains(text)).ToList());
                }
                if (choice.Equals("content"))
                {
                    return View(req.data.Where(x => x.noticeContents.Contains(text)).ToList());
                }
            }
            
            return View();
        }
        public IActionResult PageFilter(string text, string choice, int? pageNum)
        {
            return ViewComponent("NoticeList", new
            {
                text = text,
                choice =  choice,
                pageNum = pageNum
            });
        }

        public async Task<IActionResult> NoticeDetail(string seq)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(seq))
            {
                
                return Ok(new
                {
                    code = "99",
                    Msg = "목록 조회 번호가 존재하지않습니다."
                });
            }

            var req = await dgShop.Post<ResponseNoticeList, RequestNoticeDetail>("/api/NoticeManagement/GetNoticeDetail", new RequestNoticeDetail
            {
                job_gbn = "2",
                seq = seq
            });

            if (req.code.Equals("00"))
            {
                return PartialView("Detail", req.data.SingleOrDefault());
            }
            ModelState.AddModelError("", "목록 조회시 오류가 발생했습니다. 새로고침 후 이용바랍니다.");
            return PartialView("Detail");
        }
    }
}
