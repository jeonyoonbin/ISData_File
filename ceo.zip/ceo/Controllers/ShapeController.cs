﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using PosWebApp.Common;
using PosWebApp.Models.Shape;
using PosWebApp.Settings;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShapeController : ControllerBase
    {
        private readonly IOptions<DbStrings> dbString;

        public ShapeController(IOptions<DbStrings> dbString)
        {
            this.dbString = dbString;
        }

        [HttpPost("Set")]
        public async Task<dynamic> SetUmdShape(RequestSetUmdShape info)
        {
            Result<dynamic> result = new Result<dynamic>();

            List<double> lon_x = new List<double>();
            List<double> lat_y = new List<double>();
            foreach (var item in info.pointArray)
            {
                lon_x.Add(item.lon_x);
                lat_y.Add(item.lat_y);
            }

            try
            {
                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_UMD_SHAPE.SET_UMD_SHAPE",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                        cmd.Parameters.Add(new OracleParameter("in_sigungu", OracleDbType.Varchar2)).Value = info.sigungu;
                        cmd.Parameters.Add(new OracleParameter("in_umd", OracleDbType.Varchar2)).Value = info.umd;
                        cmd.Parameters.Add(new OracleParameter("in_ri", OracleDbType.Varchar2)).Value = info.ri;
                        cmd.Parameters.Add(new OracleParameter("in_lon_x", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = lon_x.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_lat_y", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = lat_y.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_mod_ucode", OracleDbType.Varchar2)).Value = info.mod_ucode;
                        cmd.Parameters.Add(new OracleParameter("in_mod_name", OracleDbType.Varchar2)).Value = info.mod_user;

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("Get")]
        public async Task<ResultSingle<ShapeUmd>> GetUmdShape(RequestGetUmdShape info)
        {
            ResultSingle<ShapeUmd> result = new ResultSingle<ShapeUmd>();

            try
            {
                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_UMD_SHAPE.GET_UMD_SHAPE",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                        cmd.Parameters.Add(new OracleParameter("in_sigungu", OracleDbType.Varchar2)).Value = info.sigungu;
                        cmd.Parameters.Add(new OracleParameter("in_umd", OracleDbType.Varchar2)).Value = info.umd;
                        cmd.Parameters.Add(new OracleParameter("in_ri", OracleDbType.Varchar2)).Value = null;
                        cmd.Parameters.Add(new OracleParameter("out_left", OracleDbType.Double)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_top", OracleDbType.Double)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_right", OracleDbType.Double)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_bottom", OracleDbType.Double)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();


                            if (code.Equals("00"))
                            {
                                ShapeBound bound = new ShapeBound()
                                {
                                    left = Convert.ToDouble(cmd.Parameters["out_left"].Value.ToString()),
                                    top = Convert.ToDouble(cmd.Parameters["out_top"].Value.ToString()),
                                    right = Convert.ToDouble(cmd.Parameters["out_right"].Value.ToString()),
                                    bottom = Convert.ToDouble(cmd.Parameters["out_bottom"].Value.ToString())
                                };


                                List<ShapePoint> spList = new List<ShapePoint>();
                                while (await reader.ReadAsync())
                                {
                                    ShapePoint sp = new ShapePoint()
                                    {
                                        lat_y = Convert.ToDouble(reader["lat_y"].ToString()),
                                        lon_x = Convert.ToDouble(reader["lon_x"].ToString())
                                    };
                                    spList.Add(sp);
                                }

                                ShapeUmd model = new ShapeUmd()
                                {
                                    sido = info.sido,
                                    sigungu = info.sigungu,
                                    umd = info.umd,
                                    bound = bound,
                                    pointArray = spList
                                };
                                result.data = model;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
    }
}
