﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.Reservation;
using PosWebApp.ViewModels.Reservation.BizInfo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ReservationBizInfo : Controller
    {
        private readonly ReservationService_T reservationService;
        public ReservationBizInfo(ReservationService_T reservation)
        {
            this.reservationService = reservation;
        }
        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var query = QueryHelpers.AddQueryString("/shopBizInfo", new Dictionary<string, string>()
            {
                {"ccCode", info.cccode.ToString()},
                {"shopCd",info.shop_cd.ToString()},
            });

            var req = await reservationService.Get<shopBizInfo>(query);

            if (req.code.Equals("00"))
            {
                var tempEmail = req.data.SingleOrDefault();

                if (string.IsNullOrEmpty(tempEmail.email))
                {
                    req.data.SingleOrDefault().emailaddr = null;
                }
                else
                {
                    req.data.SingleOrDefault().emailaddr = tempEmail.email.Split("@");
                }
                return View(req.data.SingleOrDefault());
            }

            return View();
        }

        //[HttpPost]
        //public async Task<IActionResult> Email(shopBizInfo param)
        //{
        //    string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
        //    ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
        //    info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

          


        //    var req = await reservationService.Post<dynamic, shopBizInfo>("shopBizInfo", param);
        //}
    }
}
