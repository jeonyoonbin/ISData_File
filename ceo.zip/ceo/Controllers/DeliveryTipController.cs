﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Microsoft.JSInterop;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Models.Common;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.DeliveryTip;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class DeliveryTipController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly string localurl;
        private readonly string deliveryTipFlag;

        public DeliveryTipController(DgShopApiService api, IConfiguration configuration)
        {
            dgShop = api;
            localurl = configuration.GetValue<string>("api:local");
            deliveryTipFlag = configuration.GetValue<string>("inspection:DeliveryTipFlag");
        }

        public IActionResult Index()
        {

            /* 배달 지역 및 배달 팁 으로 변경.
             * DeliveryAreaTip 하위목록 ViewComponent - DeliveryTip
             */
            var now = DateTime.Now;
            var EndTime = DateTime.ParseExact(deliveryTipFlag, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
            var diffTime = (EndTime - now).Days;

            if (diffTime > 0)
            {
                ViewBag.diffTime = "Y";
            }
            else
            {
                ViewBag.diffTime = "N";
            }
            return View();
        }

        #region 영업 시간 조회

        //public async Task<IActionResult> BizTimeAsync()
        //{
        //    string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
        //    ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
        //    info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

        //    var temp = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
        //    {
        //        tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.영업시간).ToString(),
        //        job_gbn = "1",
        //        shop_cd = info.shop_cd
        //    });
        //    //ViewBag.bizTimeData = temp.data;

        //    return View(temp.data);
        //}
        // Create
        public async Task<IActionResult> BizTime()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            #region 리스트 조회
            var gbn_selectList = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
            {
                tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.영업시간).ToString(),
                job_gbn = "1",
                shop_cd = info.shop_cd
            });
            if (gbn_selectList.data.Count() > 0)
            {
                var daysList = from s in gbn_selectList.data
                               select s.tip_day;

                var dayscount = Days.GetDayItems().ToList();

                foreach (var index in daysList)
                {
                    var indexof = dayscount.FindIndex(x => x.value == Convert.ToInt32(index));
                    dayscount.RemoveAt(indexof);
                }
                ViewBag.days = new SelectList(dayscount, "value", "name");
            }
            else
            {
                ViewBag.days = new SelectList(Days.GetDayItems(), "value", "name", "2");
            }
            #endregion

            //ViewBag.days = new SelectList(Days.GetDayItems(), "value", "name", "2");
            ViewBag.dayRange = new SelectList(Days.GetDayItems(), "value", "name", "0");
            ShopInfoTipAmtModel model = new ShopInfoTipAmtModel();
            model.tip_fr_stand = "10:00";
            model.tip_to_stand = "20:00";
            return View(model);
        }
        [HttpPost]
        public async Task<IActionResult> BizTime(ShopInfoTipAmtModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            if (model.tip_day == null)
            {
                ModelState.AddModelError("", "날짜를 선택해주세요");
                return View();
            }
            RequestSetShopInfoTipAmt tip = new RequestSetShopInfoTipAmt()
            {
                shop_cd = info.shop_cd,
                job_gbn = "I",
                tip_gbn = ((int)DELIVERY_TIP_GBN.영업시간).ToString(),
                tip_from_stand = model.tip_fr_stand.Replace(":", ""),
                tip_to_stand = model.tip_to_stand.Replace(":", ""),
                tip_seq = Convert.ToInt32(model.tip_seq),
                tip_day = model.tip_day,
                tip_amt = "0",        // 요일범위 0: 사용안함, 1: 일요일
                tip_next_day = model.tip_next_day ? "Y" : "N",
                user_code = info.login_code,
                user_name = info.login_name
            };

            ViewBag.days = new SelectList(Days.GetDayItems(), "value", "name", model.tip_day);
            ViewBag.dayRange = new SelectList(Days.GetDayItems(), "value", "name", model.tip_amt);

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestSetShopInfoTipAmt>("SetDeliveryTipAmt", tip);

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("index", "Operate");
            }

            return View(model);
        }
        public async Task<IActionResult> UpdateBizTime(string id)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
            {
                tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.영업시간).ToString(),
                job_gbn = "1",
                shop_cd = info.shop_cd
            });

            if (temp.code.Equals("00"))
            {
                var value = temp.data.Find(x => x.tip_seq.Equals(id));

                ShopInfoTipAmtModel model = new ShopInfoTipAmtModel()
                {
                    tip_seq = value.tip_seq,
                    tip_gbn = value.tip_gbn,
                    tip_amt = value.tip_amt,
                    tip_amt_rate = value.tip_amt_rate,
                    tip_day = value.tip_day,
                    tip_fr_stand = value.tip_fr_stand.Insert(2, ":"),
                    tip_to_stand = value.tip_to_stand.Insert(2, ":"),
                    tip_next_day = value.tip_next_day.Equals("Y") ? true : false,           // 다음날
                };

                ViewBag.days = new SelectList(Days.GetDayItems().Where(x => x.value.Equals(Convert.ToInt32(value.tip_day))), "value", "name", value.tip_day);
                ViewBag.dayRange = new SelectList(Days.GetDayItems(), "value", "name", value.tip_amt);

                return View(model);
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UpdateBizTime(ShopInfoTipAmtModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            
            RequestSetShopInfoTipAmt tip = new RequestSetShopInfoTipAmt()
            {
                shop_cd = info.shop_cd,
                job_gbn = "U",
                tip_gbn = ((int)DELIVERY_TIP_GBN.영업시간).ToString(),
                tip_from_stand = model.tip_fr_stand.Replace(":", ""),
                tip_to_stand = model.tip_to_stand.Replace(":", ""),
                tip_seq = Convert.ToInt32(model.tip_seq),
                tip_day = model.tip_day,
                tip_amt = "0", // 2021.05.10 jwcho 사용안함. model.tip_amt,// 요일 범위 0 : 사용안함, 1 : 일요일...
                tip_next_day = model.tip_next_day ? "Y" : "N",      // 다음날
                user_code = info.login_code,
                user_name = info.login_name
            };
            if (Convert.ToInt32(model.tip_fr_stand.Replace(":","")) >= Convert.ToInt32(model.tip_to_stand.Replace(":", "")))
            {
                tip.tip_next_day = "Y";
            }
            if (Convert.ToInt32(model.tip_fr_stand.Replace(":", "")) < Convert.ToInt32(model.tip_to_stand.Replace(":", "")))
            {
                tip.tip_next_day = "N";
            }
            var temp = await dgShop.Post<ShopInfoTipAmt, RequestSetShopInfoTipAmt>("SetDeliveryTipAmt", tip);

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("index", "Operate");
            }
            else
                ModelState.AddModelError("", temp.msg);

            ViewBag.days = new SelectList(Days.GetDayItems().Where(x => x.value.Equals(Convert.ToInt32(model.tip_day))), "value", "name", model.tip_day);
            ViewBag.dayRange = new SelectList(Days.GetDayItems(), "value", "name", model.tip_amt);

            return View(model);
        }


        public async Task<ActionResult> DeleteBizTime(string id)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
            {
                tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.영업시간).ToString(),
                job_gbn = "1",
                shop_cd = info.shop_cd
            });

            if (temp.code.Equals("00"))
            {
                var value = temp.data.Find(x => x.tip_seq.Equals(id));

                if (value == null)
                {

                    return Content("아이템을 찾을 수 없습니다.");
                }

                RequestSetShopInfoTipAmt tip = new RequestSetShopInfoTipAmt()
                {
                    job_gbn = "D",
                    shop_cd = info.shop_cd,
                    tip_gbn = ((int)DELIVERY_TIP_GBN.영업시간).ToString(),
                    tip_seq = Convert.ToInt32(value.tip_seq),
                    user_code = info.login_code,
                    user_name = info.login_name
                };

                var temp2 = await dgShop.Post<ShopInfoTipAmt, RequestSetShopInfoTipAmt>("SetDeliveryTipAmt", tip);

                if (temp.code.Equals("00"))
                {
                    return RedirectToAction("index", "Operate");
                }
                else
                    ModelState.AddModelError("", temp.msg);
            }

            return View();
        }

        #endregion

        #region 시간대별 배달팁

        public async Task<IActionResult> TimeZone()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            /*var temp = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
             {
                 tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.시간대).ToString(),
                 job_gbn = "1",
                 shop_cd = info.shop_cd
             });
             if (temp.data.Count() > 0)
             {
                 var daysList = from s in temp.data
                                select s.tip_day;

                 var dayscount = Days.GetDayItems().ToList();

                 foreach (var index in daysList)
                 {
                     var indexof = dayscount.FindIndex(x => x.value == Convert.ToInt32(index));
                     dayscount.RemoveAt(indexof);
                 }
                 ViewBag.days = new SelectList(dayscount, "value", "name");
             }
             else
             {
                 ViewBag.days = new SelectList(Days.GetDayItems(), "value", "name");
             }*/


            ViewBag.days = TimeZoneDay.GetDayItems();
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> TimeZone(ShopInfoTipAmtModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            #region DaysFilter - SelectList 

            //var selectList = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
            //{
            //    tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.시간대).ToString(),
            //    job_gbn = "1",
            //    shop_cd = info.shop_cd
            //});

            //if (selectList.data.Count() > 0)
            //{
            //    var daysList = from s in selectList.data
            //                   select s.tip_day;

            //    var dayscount = Days.GetDayItems().ToList();

            //    foreach (var index in daysList)
            //    {
            //        var indexof = dayscount.FindIndex(x => x.value == Convert.ToInt32(index));
            //        dayscount.RemoveAt(indexof);
            //    }
            //    ViewBag.days = new SelectList(dayscount, "value", "name");
            //}
            //else
            //{
            //    ViewBag.days = new SelectList(Days.GetDayItems(), "value", "name");
            //}
            ViewBag.days = TimeZoneDay.GetDayItems();
            #endregion

            if (model.tip_days == null)
            {
                ModelState.AddModelError("tip_day", "날짜를 선택해 주세요");
                return View();
            }
            if (model.tip_fr_stand == null)
            {
                ModelState.AddModelError("tip_fr_stand", "시작 시간을 설정해 주세요");
                return View();
            }
            if (model.tip_to_stand == null)
            {
                ModelState.AddModelError("tip_to_stand", "종료 시간을 설정해 주세요");
                return View();
            }
            if (string.IsNullOrEmpty(model.tip_amt))
            {
                ModelState.AddModelError("tip_amt", "배달팁 요금을 입력해 주세요");
                return View();
            }
            Utils utils = new Utils();
            RequestSetShopInfoTipAmt tip = new RequestSetShopInfoTipAmt()
            {
                shop_cd = info.shop_cd,
                tip_amt = model.tip_amt.Replace(",",""),
                job_gbn = "I",
                tip_from_stand = model.tip_fr_stand.Replace(":", ""),
                tip_to_stand = model.tip_to_stand.Replace(":", ""),
                tip_seq = Convert.ToInt32(model.tip_seq),
                tip_gbn = ((int)DELIVERY_TIP_GBN.시간대).ToString(),
                tip_day = model.tip_day,
                tip_next_day = model.tip_next_day ? "Y" : "N",
                user_code = info.login_code,
                user_name = info.login_name
            };
            RequestSetShopInfoTipAmt_V2 NewTip = new RequestSetShopInfoTipAmt_V2()
            {
                job_gbn = new List<string>(),
                tip_amt = new List<string>(),
                tip_from_stand = new List<string>(),
                tip_to_stand = new List<string>(),
                tip_seq = new List<int>(),
                tip_gbn = new List<string>(),
                tip_day = new List<string>(),
                tip_next_day = new List<string>(),
                tip_amt_rate = new List<string>(),
            };
            foreach (var days in model.tip_days)
            {
                NewTip.shop_cd = info.shop_cd;
                NewTip.job_gbn.Add("I");
                NewTip.tip_amt.Add(model.tip_amt.Replace(",", ""));
                NewTip.tip_from_stand.Add( model.tip_fr_stand.Replace(":", ""));
                NewTip.tip_to_stand.Add( model.tip_to_stand.Replace(":", ""));
                NewTip.tip_seq.Add( Convert.ToInt32(model.tip_seq));
                NewTip.tip_gbn.Add(((int)DELIVERY_TIP_GBN.시간대).ToString());
                NewTip.tip_day.Add((days== "8" ? "1" : days));
                NewTip.tip_next_day.Add( model.tip_next_day ? "Y" : "N");
                NewTip.tip_amt_rate.Add(null);
                NewTip.user_code = info.login_code;
                NewTip.user_name = info.login_name;
            }
            
            if (!utils.MoneyCheck(tip.tip_amt))
            {
                ModelState.AddModelError("tip_amt", "배달팁은 100원 단위 이상으로 설정 가능합니다.");
                return View(model);
            }

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestSetShopInfoTipAmt_V2>("SetDeliveryTipAmtV2", NewTip);

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("index", "DeliveryAreaTip");
            }

            if(temp.code.Equals("99"))
            {
                ModelState.AddModelError("tip_fr_stand", temp.msg);

                //if(model.tip_days.Count() > 0)
                //{
                //    var daysList = from s in model.tip_days
                //                   select s;

                //    var dayscount = TimeZoneDay.GetDayItems().ToList();

                //    foreach (var index in daysList)
                //    {
                //        var indexof = dayscount.FindIndex(x => x.DayValue == Convert.ToInt32(index));
                //        dayscount.RemoveAt(indexof);
                //    }


                //    ViewBag.days = new SelectList(dayscount, "DayValue", "DayName");
                //}

               
                return View(model);
            }
            if (temp.code.Equals("98"))
            {
                ModelState.AddModelError("tip_fr_stand", "저장중에 오류가 발견되었습니다. 관리자에게 문의 바랍니다.");
                return View(model);
            }
            return View(model);
        }
        public async Task<IActionResult> UpdateTimeZone(string id)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
            {
                tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.시간대).ToString(),
                job_gbn = "1",
                shop_cd = info.shop_cd
            });
            if (temp.code.Equals("00"))
            {
                var value = temp.data.Find(x => x.tip_seq.Equals(id));
                ShopInfoTipAmtModel model = new ShopInfoTipAmtModel()
                {
                    tip_seq = value.tip_seq,
                    tip_gbn = value.tip_gbn,
                    tip_amt = value.tip_amt,
                    tip_amt_rate = value.tip_amt_rate,
                    tip_day = value.tip_day,
                    tip_fr_stand = value.tip_fr_stand.Insert(2, ":"),
                    tip_to_stand = value.tip_to_stand.Insert(2, ":")
                };
                ViewBag.days = new SelectList(Days.GetDayItems().Where(x => x.value == Convert.ToInt32(value.tip_day)), "value", "name", value.tip_day);
                return View(model);
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UpdateTimeZone(ShopInfoTipAmtModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            ViewBag.days = new SelectList(Days.GetDayItems().Where(x => x.value == Convert.ToInt32(model.tip_day)), "value", "name", model.tip_day);
            if (model.tip_day == null)
            {
                ModelState.AddModelError("tip_day", "날짜를 선택 해 주세요");
                return View(model);
            }
            if (model.tip_fr_stand == null)
            {
                ModelState.AddModelError("tip_fr_stand", "시작 시간을 설정 해 주세요");
                return View(model);
            }
            if (model.tip_to_stand == null)
            {
                ModelState.AddModelError("tip_to_stand", "종료 시간을 설정 해 주세요");
                return View(model);
            }
            if (string.IsNullOrEmpty(model.tip_amt))
            {
                ModelState.AddModelError("tip_amt", "배달팁 요금을 입력 해 주세요");
                return View(model);
            }
            Utils utils = new Utils();
            RequestSetShopInfoTipAmt tip = new RequestSetShopInfoTipAmt()
            {
                shop_cd = info.shop_cd,
                tip_amt = model.tip_amt.Replace(",",""),
                job_gbn = "U",
                tip_from_stand = model.tip_fr_stand.Replace(":", ""),
                tip_to_stand = model.tip_to_stand.Replace(":", ""),
                tip_seq = Convert.ToInt32(model.tip_seq),
                tip_gbn = ((int)DELIVERY_TIP_GBN.시간대).ToString(),
                tip_day = model.tip_day,
                tip_next_day = model.tip_next_day ? "Y" : "N",
                user_code = info.login_code,
                user_name = info.login_name
            };




            if (Convert.ToInt32(model.tip_fr_stand.Replace(":", "")) >= Convert.ToInt32(model.tip_to_stand.Replace(":", "")))
            {
                tip.tip_next_day = "Y";
            }
            if (Convert.ToInt32(model.tip_fr_stand.Replace(":", "")) < Convert.ToInt32(model.tip_to_stand.Replace(":", "")))
            {
                tip.tip_next_day = "N";
            }
            if (!utils.MoneyCheck(tip.tip_amt))
            {
                ModelState.AddModelError("tip_amt", "배달팁은 100원 단위 이상으로 설정 가능합니다.");
                return View(model);
            }

            RequestSetShopInfoTipAmt_V2 NewTip = new RequestSetShopInfoTipAmt_V2()
            {
                job_gbn = new List<string>(),
                tip_amt = new List<string>(),
                tip_from_stand = new List<string>(),
                tip_to_stand = new List<string>(),
                tip_seq = new List<int>(),
                tip_gbn = new List<string>(),
                tip_day = new List<string>(),
                tip_next_day = new List<string>(),
                tip_amt_rate = new List<string>(),
            };
            NewTip.shop_cd = info.shop_cd;
            NewTip.job_gbn.Add("U");
            NewTip.tip_amt.Add(model.tip_amt.Replace(",", ""));
            NewTip.tip_from_stand.Add(model.tip_fr_stand.Replace(":", ""));
            NewTip.tip_to_stand.Add(model.tip_to_stand.Replace(":", ""));
            NewTip.tip_seq.Add(Convert.ToInt32(model.tip_seq));
            NewTip.tip_gbn.Add(((int)DELIVERY_TIP_GBN.시간대).ToString());
            NewTip.tip_day.Add(model.tip_day);
            NewTip.tip_next_day.Add(model.tip_next_day ? "Y" : "N");
            NewTip.tip_amt_rate.Add(null);
            NewTip.user_code = info.login_code;
            NewTip.user_name = info.login_name;
            var temp = await dgShop.Post<ShopInfoTipAmt, RequestSetShopInfoTipAmt_V2>("SetDeliveryTipAmtV2", NewTip);

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("index", "DeliveryAreaTip");
            }
            else
                ModelState.AddModelError("", temp.msg);

            return View(model);
        }
        public async Task<IActionResult> DeleteTimeZone(string id)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (id == null)
            {
                ModelState.AddModelError("", "존재하지않는 값입니다.");
                return View();
            }
            RequestSetShopInfoTipAmt tip = new RequestSetShopInfoTipAmt()
            {
                shop_cd = info.shop_cd,
                job_gbn = "D",
                tip_seq = Convert.ToInt32(id),
                tip_gbn = ((int)DELIVERY_TIP_GBN.시간대).ToString(),
                user_code = info.login_code,
                user_name = info.login_name
            };

            RequestSetShopInfoTipAmt_V2 NewTip = new RequestSetShopInfoTipAmt_V2()
            {
                job_gbn = new List<string>(),
                tip_amt = new List<string>(),
                tip_from_stand = new List<string>(),
                tip_to_stand = new List<string>(),
                tip_seq = new List<int>(),
                tip_gbn = new List<string>(),
                tip_day = new List<string>(),
                tip_next_day = new List<string>(),
                tip_amt_rate = new List<string>(),
            };
            NewTip.shop_cd = info.shop_cd;
            NewTip.job_gbn.Add("D");
            NewTip.tip_amt.Add(null);
            NewTip.tip_from_stand.Add(null);
            NewTip.tip_to_stand.Add(null);
            NewTip.tip_seq.Add(Convert.ToInt32(id));
            NewTip.tip_gbn.Add(((int)DELIVERY_TIP_GBN.시간대).ToString());
            NewTip.tip_day.Add(null);
            NewTip.tip_next_day.Add(null);
            NewTip.tip_amt_rate.Add(null);
            NewTip.user_code = info.login_code;
            NewTip.user_name = info.login_name;


            var temp = await dgShop.Post<ShopInfoTipAmt, RequestSetShopInfoTipAmt>("SetDeliveryTipAmt", tip);

            if (temp.code == "00")
            {
                return RedirectToAction("index", "DeliveryAreaTip");
            }
            else
            {
                ModelState.AddModelError("", temp.msg);
            }
            return View();
        }


        #endregion

        #region 주문 금액별 배달팁

        public IActionResult FoodAmount()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> FoodAmount(ShopInfoTipAmtModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            RequestSetShopInfoTipAmt tip = new RequestSetShopInfoTipAmt()
            {
                shop_cd = info.shop_cd,
                tip_amt = model.tip_amt.Replace(",", ""),
                job_gbn = "I",
                tip_from_stand = model.tip_fr_stand.Replace(",", ""),
                tip_to_stand = model.tip_to_stand,
                tip_seq = Convert.ToInt32(model.tip_seq),
                tip_gbn = ((int)DELIVERY_TIP_GBN.금액).ToString(),
                tip_day = "1",      // 사용안함 (고정)
                user_code = info.login_code,
                user_name = info.login_name
            };
            
           


            var temp = await dgShop.Post<ShopInfoTipAmt, RequestSetShopInfoTipAmt>("SetDeliveryTipAmt", tip);

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("index", "DeliveryAreaTip");
            }

            return View();
        }

        public async Task<IActionResult> UpdateFoodAmount(string id)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
            {
                tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.금액).ToString(),
                job_gbn = "1",
                shop_cd = info.shop_cd
            });

            if (temp.code.Equals("00"))
            {
                var value = temp.data.Find(x => x.tip_seq.Equals(id));
                ShopInfoTipAmtModel model = new ShopInfoTipAmtModel()
                {
                    tip_seq = value.tip_seq,
                    tip_gbn = value.tip_gbn,
                    tip_amt = value.tip_amt,
                    tip_amt_rate = value.tip_amt_rate,
                    tip_day = value.tip_day,
                    tip_fr_stand = value.tip_fr_stand,
                    tip_to_stand = value.tip_to_stand
                };

                return View(model);
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UpdateFoodAmount(ShopInfoTipAmtModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestSetShopInfoTipAmt tip = new RequestSetShopInfoTipAmt()
            {
                shop_cd = info.shop_cd,
                tip_amt = model.tip_amt.Replace(",", ""),
                job_gbn = "U",
                tip_from_stand = model.tip_fr_stand.Replace(":", ""),
                tip_to_stand = model.tip_to_stand.Replace(":", ""),
                tip_seq = Convert.ToInt32(model.tip_seq),
                tip_gbn = ((int)DELIVERY_TIP_GBN.금액).ToString(),
                tip_day = model.tip_day,
                user_code = info.login_code,
                user_name = info.login_name
            };

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestSetShopInfoTipAmt>("SetDeliveryTipAmt", tip);

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("index","DeliveryAreaTip");
            }
            else
                ModelState.AddModelError("", temp.msg);

            return View(model);
        }

        public async Task<IActionResult> FoodAmountList()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            if (sessionString != null)
            {
                ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
                info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

                var temp = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
                {
                    tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.금액).ToString(),
                    job_gbn = "1",
                    shop_cd = info.shop_cd
                });
                if (temp.code == "00")
                {
                    return View(temp.data.OrderBy(x => x.tip_seq).ToList());
                }
            }

            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> FoodAmountList(List<ShopInfoTipAmt> listModel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            var checkByte = Encoding.UTF8.GetBytes(info.shop_name);

            if(checkByte.Length > 50)
            {
                info.shop_name = Encoding.Default.GetString(checkByte,0,50);
            }
            
            RequestSetShopInfoTipAmtList ListReqModel = new RequestSetShopInfoTipAmtList()
            {
                job_gbn = "I",
                shop_cd = info.shop_cd.ToString(),
                user_code = info.mcode.ToString(),
                user_name = info.shop_name,
                itemList = new List<RequestSetShopInfoTipAmtItem>()
            };

            RequestSetShopInfoTipAmt_V2 NewTip = new RequestSetShopInfoTipAmt_V2()
            {
                job_gbn = new List<string>(),
                tip_amt = new List<string>(),
                tip_from_stand = new List<string>(),
                tip_to_stand = new List<string>(),
                tip_seq = new List<int>(),
                tip_gbn = new List<string>(),
                tip_day = new List<string>(),
                tip_next_day = new List<string>(),
                tip_amt_rate = new List<string>(),
            };
            NewTip.shop_cd = info.shop_cd;
           
            NewTip.user_code = info.login_code;
            NewTip.user_name = info.login_name;



            Utils utils = new Utils();
            var deliveryTipCheck = true;
            var deliveryleastCeck = true;
            var ModelErrorMsg = "";
            foreach (var item in listModel)
            {
                int i = 0;
                RequestSetShopInfoTipAmtItem tempModel = new RequestSetShopInfoTipAmtItem();


                tempModel.tip_amt = item.tip_amt.Replace(",", "");
                tempModel.tip_seq = Convert.ToInt32(item.tip_seq);
                tempModel.tip_from_stand = item.tip_fr_stand.Replace(",", "");
                tempModel.tip_to_stand = "0"; // 고정
                tempModel.tip_gbn = ((int)DELIVERY_TIP_GBN.금액).ToString();
                tempModel.tip_day = "1"; // 고정
                ListReqModel.itemList.Add(tempModel);



                NewTip.job_gbn.Add(item.status);
                NewTip.tip_amt.Add(item.tip_amt.Replace(",", ""));
                NewTip.tip_from_stand.Add(item.tip_fr_stand.Replace(",", ""));
                NewTip.tip_to_stand.Add("0");
                NewTip.tip_seq.Add(Convert.ToInt32(item.tip_seq));
                NewTip.tip_gbn.Add(((int)DELIVERY_TIP_GBN.금액).ToString());
                NewTip.tip_day.Add("1");
                NewTip.tip_next_day.Add(null);
                NewTip.tip_amt_rate.Add(null);

                if (!utils.MoneyCheck(tempModel.tip_amt))
                {
                    deliveryTipCheck = false;
                    
                    ModelErrorMsg = "배달팁은 100원 단위 이상으로 설정 가능합니다.\n";
                    
                }
                if (!utils.MoneyCheck(tempModel.tip_to_stand))
                {
                    deliveryleastCeck = false;
                    
                    ModelErrorMsg = "최소금액은 100원 단위 이상으로 설정 가능합니다.\n" ;
                }
                i++;
            }
            if (!deliveryleastCeck | !deliveryTipCheck)
            {
                return BadRequest(new
                {
                    code = "99",
                    msg = "등록이 실패되었습니다."

                });
            }


            var req = await dgShop.Post<dynamic, RequestSetShopInfoTipAmt_V2>("SetDeliveryTipAmtV2", NewTip);
           

            if (req.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    msg = "성공",
                    url = string.Concat(localurl, "DeliveryAreaTip/Index")
                });
            }
            else
                ModelState.AddModelError("", req.msg);

            return BadRequest(new
            {
                code = "99",
                msg = req.msg

            });
        }
        #endregion

        #region 동별 배달팁
        public async Task<IActionResult> UmdArea()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopSector, Request>("GetShopSectorRaw", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            ViewBag.gunguList = temp.data.GroupBy(x => x.sigungu).ToList();

            return View();
        }


        [HttpPost]
        public async Task<IActionResult> UmdArea(ShopInfoTipAmtModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var umdList = await dgShop.Post<ShopSector, Request>("GetShopSectorRaw", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            ViewBag.gunguList = umdList.data.GroupBy(x => x.sigungu).ToList();

            if (string.IsNullOrEmpty(model.tip_fr_stand))
            {
                ModelState.AddModelError("tip_fr_stand", "배달팁 목적지가 설정 되지 않았습니다");
                return View();
            }

            if(string.IsNullOrEmpty(model.tip_amt))
            {
                ModelState.AddModelError("tip_amt", "배달팁 금액을 입력 해 주세요.");
                return View();
            }

            Utils utils = new Utils();
            RequestSetShopInfoTipAmt tip = new RequestSetShopInfoTipAmt()
            {
                job_gbn = "I",
                shop_cd = info.shop_cd,
                tip_seq = Convert.ToInt32(model.tip_seq),
                tip_gbn = ((int)DELIVERY_TIP_GBN.동별).ToString(),
                tip_from_stand = model.tip_fr_stand,
                tip_amt = model.tip_amt.Replace(",", ""),
                tip_to_stand = "0",     // 사용안함 고정)
                tip_day = "1",          // 사용안함 (고정)
                user_code = info.login_code,
                user_name = info.login_name
            };
            if (!utils.MoneyCheck(tip.tip_amt))
            {
                ModelState.AddModelError("tip_amt", "배달팁은 100원 단위 이상으로 설정 가능합니다.");
                return View(model);
            }

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestSetShopInfoTipAmt>("SetDeliveryTipAmt", tip);

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("index", "DeliveryAreaTip");
            }

            var gunguList = await dgShop.Post<ShopSector, Request>("GetShopSectorRaw", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            ViewBag.gunguList = gunguList.data.GroupBy(x => x.sigungu).ToList();

            ModelState.AddModelError("tip_fr_stand", temp.msg);

            return View(model);
        }

        public async Task<IActionResult> UpdateUmdArea(string id)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var gunguList = await dgShop.Post<ShopSector, Request>("GetShopSectorRaw", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            ViewBag.gunguList = gunguList.data.GroupBy(x => x.sigungu).ToList();

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
            {
                tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.동별).ToString(),
                job_gbn = "1",
                shop_cd = info.shop_cd
            });

            if (temp.code.Equals("00"))
            {
                var value = temp.data.Find(x => x.tip_seq.Equals(id));
                ShopInfoTipAmtModel model = new ShopInfoTipAmtModel()
                {
                    tip_seq = value.tip_seq,
                    tip_gbn = value.tip_gbn,
                    tip_fr_stand = value.tip_fr_stand,
                    tip_amt = value.tip_amt,
                    tip_day = "1",      // 사용안함 (고정)
                    tip_to_stand = "0", // 사용안함 (고정)
                    tip_amt_rate = value.tip_amt_rate
                };
                return View(model);
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UpdateUmdArea(ShopInfoTipAmtModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            Utils utils = new Utils();
            RequestSetShopInfoTipAmt tip = new RequestSetShopInfoTipAmt()
            {
                job_gbn = "U",
                shop_cd = info.shop_cd,
                tip_gbn = ((int)DELIVERY_TIP_GBN.동별).ToString(),
                tip_seq = Convert.ToInt32(model.tip_seq),
                tip_from_stand = model.tip_fr_stand,
                tip_amt = model.tip_amt.Replace(",", ""),
                tip_to_stand = "0", // 사용안함 (고정)
                tip_day = "1",      // 사용안함 (고정)
                user_code = info.login_code,
                user_name = info.login_name
            };
            var gunguList = await dgShop.Post<ShopSector, Request>("GetShopSectorRaw", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            ViewBag.gunguList = gunguList.data.GroupBy(x => x.sigungu).ToList();
            if (!utils.MoneyCheck(tip.tip_amt))
            {
                ModelState.AddModelError("tip_amt", "배달팁은 100원 단위 이상으로 설정 가능합니다.");
                return View(model);
            }

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestSetShopInfoTipAmt>("SetDeliveryTipAmt", tip);

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("index", "DeliveryAreaTip");
            }

            

            ModelState.AddModelError("", temp.msg);

            return View(model);
        }
        public async Task<IActionResult> DeleteUmdArea(string id)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            if (id == null)
            {
                ModelState.AddModelError("", "존재하지않는 값입니다.");
                return View();
            }
            RequestSetShopInfoTipAmt tip = new RequestSetShopInfoTipAmt()
            {
                job_gbn = "D",
                shop_cd = info.shop_cd,
                tip_gbn = ((int)DELIVERY_TIP_GBN.동별).ToString(),
                tip_seq = Convert.ToInt32(id),
                tip_to_stand = "0", // 사용안함 (고정)
                tip_day = "1",      // 사용안함 (고정)
                user_code = info.login_code,
                user_name = info.login_name
            };

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestSetShopInfoTipAmt>("SetDeliveryTipAmt", tip);

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("index", "DeliveryAreaTip");
            }
            else
                ModelState.AddModelError("", temp.msg);

            return View();
        }
        #endregion

    }
}
