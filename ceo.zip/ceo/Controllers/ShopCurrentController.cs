﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.ApiModels.Shop.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ShopCurrentController : Controller
    {
        private readonly DgShopApiService dgShop;
        public ShopCurrentController(DgShopApiService dgShop)
        {
            this.dgShop = dgShop;
        }
        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var multiShopList = await dgShop.Post<ResponseMultiShopOverALL, RequestMulitShopList>("/api/ShopManagement/GetMultiShopOverAll", new RequestMulitShopList
            {
                shop_cd = info.shop_cd,
                multiShopCd = info.multMasterCd
            });

            if (multiShopList.code.Equals("00"))
            {
                if(multiShopList.data.Count() > 0)
                {
                    for(var i = 0; i < multiShopList.data.Count(); i++)
                    {
                        var shopDefaultInfo = multiShopList.data[i];
                        var stringItem = await GetItemJoin(shopDefaultInfo.itemCd);
                        var stringItem2 = await GetItemJoin(shopDefaultInfo.itemCd2);
                        var stringItem3 = await GetItemJoin(shopDefaultInfo.itemCd3);



                        List<string> categoryItemList = new List<string>();
                        categoryItemList.Add(stringItem);
                        categoryItemList.Add(stringItem2);
                        categoryItemList.Add(stringItem3);

                        for (var idx = 0; idx < categoryItemList.Count(); idx++)
                        {
                            if (string.IsNullOrEmpty(categoryItemList[idx]))
                            {
                                categoryItemList.RemoveAt(idx);
                            }
                        }

                        multiShopList.data[i].categoryNames = string.Join(" | ", categoryItemList);
                    }
                    
                }
                return View(multiShopList.data);
            }
            return View(new List<ResponseMultiShopOverALL>());
        }
        [HttpPost]
        public async Task<IActionResult> SetMultiShopAbsent(string code)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(code))
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "알수없는 요청입니다."
                });
            }
            var multiShopList = await dgShop.Post<ResponseMultiShopOverALL, RequestMulitShopList>("/api/ShopManagement/GetMultiShopOverAll", new RequestMulitShopList
            {
                shop_cd = info.shop_cd,
                multiShopCd = info.multMasterCd
            });
            RequestMultiShopAbsentList result;
            if (multiShopList.code.Equals("00"))
            {
                var temp = multiShopList.data;
                result = new RequestMultiShopAbsentList
                {
                    mcode = info.login_code,
                    mName = info.login_name
                };
                if (code.Equals("Y"))
                {
                    result.shopCd = new List<string>();
                    result.absentYn = new List<string>();

                    result.shopCd.AddRange(temp.Select(x => x.shopCd).ToList());
                    foreach(var i in temp)
                    {
                        result.absentYn.Add("Y");
                    }
                }
                if (code.Equals("N"))
                {
                    result.shopCd = new List<string>();
                    result.absentYn = new List<string>();

                    result.shopCd.AddRange(temp.Select(x => x.shopCd).ToList());
                    foreach (var i in multiShopList.data)
                    {
                        result.absentYn.Add("N");
                    }
                }

                var absentResult = await dgShop.Post<dynamic, RequestMultiShopAbsentList>("/api/ShopManagement/SetMulitShopAbsent", result);

                if (absentResult.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        Msg = "성공"
                    });
                }
            }
            else if (!multiShopList.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "잘못접근된 경로입니다."
                });
            }
            return Ok(new
            {
                code = "99",
                Msg = "실패"
            });
        }
        [HttpPost]
        public async Task<IActionResult> SetMultiShopAloneAbsent (string code, string absent)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(absent))
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "알수없는 요청입니다."
                });
            }
            var multiShopList = await dgShop.Post<ResponseMultiShopOverALL, RequestMulitShopList>("/api/ShopManagement/GetMultiShopOverAll", new RequestMulitShopList
            {
                shop_cd = info.shop_cd,
                multiShopCd = info.multMasterCd
            });
            RequestMultiShopAbsentList result;
            if (multiShopList.code.Equals("00"))
            {
                var temp = multiShopList.data;
                result = new RequestMultiShopAbsentList
                {
                    mcode = info.login_code,
                    mName = info.login_name
                };

                var AloneAbsent = temp.Where(x => x.shopCd.Equals(code)).ToList();
                
                
                if (absent.Equals("Y"))
                {
                    result.shopCd = new List<string>();
                    result.absentYn = new List<string>();

                    result.shopCd.AddRange(AloneAbsent.Select(x => x.shopCd).ToList());
                    foreach (var i in AloneAbsent)
                    {
                        result.absentYn.Add("Y");
                    }
                }
                if (absent.Equals("N"))
                {
                    result.shopCd = new List<string>();
                    result.absentYn = new List<string>();

                    result.shopCd.AddRange(AloneAbsent.Select(x => x.shopCd).ToList());
                    foreach (var i in AloneAbsent)
                    {
                        result.absentYn.Add("N");
                    }
                }

                var absentResult = await dgShop.Post<dynamic, RequestMultiShopAbsentList>("/api/ShopManagement/SetMulitShopAbsent", result);

                if (absentResult.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        Msg = "성공"
                    });
                }
            }
            else if (!multiShopList.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "잘못접근된 경로입니다."
                });
            }
            return Ok(new
            {
                code = "99",
                Msg = "실패"
            });
        }
        public async Task<dynamic> GetItemJoin(string itemCode)
        {
            if (string.IsNullOrEmpty(itemCode))
            {
                return null;
            }

            var temp = await dgShop.Get<ShopBizItem>("BizItemList");

            var result = temp.data.Find(x => x.item_cd.Equals(itemCode));

            if (result == null)
            {
                return "";
            }
            return result.item_name;
        }
    }
}
