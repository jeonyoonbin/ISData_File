﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PosWebApp.ActionFilter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ShopSale : Controller
    {
        // GET: ShopSale
        public IActionResult Index()
        {
            return View();
        }

    }
}
