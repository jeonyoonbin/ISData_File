﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels;
using PosWebApp.ApiModels.Coupon.Request;
using PosWebApp.ApiModels.Coupon.Response;
using PosWebApp.ApiModels.Shop.Response;
using PosWebApp.Common;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Coupon;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class CouponController : Controller
    {
        private readonly DgShopApiService dgShop;
        public CouponController(DgShopApiService api)
        {
            dgShop = api;
        }
        public async Task<IActionResult> CouponManagement(CouponManagementViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (model.from == null)
            {
                CouponManagementViewModel result = new CouponManagementViewModel();

                result.from = DateTime.Now.ToString("yyyy-MM-dd");
                result.to = DateTime.Now.AddMonths(1).ToString("yyyy-MM-dd");

                result.options = "4";
                result.pageCnt = 10;
                result.pageNum = 1;
                result.searchGbn = "2";
                result.eventGbn = "2";
                
                return View(result);
            }else if(model.options == "4")
            {
                model.from = "";
                model.to = "";

                return View(model);
            }
            else
            {

                model.pageCnt = model.pageCnt;
                model.pageNum = model.pageNum;
                return View(model);
            }


        }
        public async Task<IActionResult> CouponUseHistory(CouponeListViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (model.from == null)
            {
                CouponeListViewModel result = new CouponeListViewModel()
                {
                    from =  DateTime.Now.AddMonths(-1).ToString("yyyy-MM-dd"),
                    to = DateTime.Now.ToString("yyyy-MM-dd"),
                    options = "0",
                    pageCnt = 10,
                    pageNum = 1,
                    packOrderGbn = "%",
                    searchGbn = "2"
                };

                return View(result);
            }
            if(model.pageCnt == 10)
            {
                model.pageCnt = 10;
                model.pageNum = 1;
            }

            return View(model);
        }
        public IActionResult CouponHistory()
        {
            return View();
        }
        public async Task<IActionResult> CouponStatus(CouponStatusViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (model.from == null)
            {
                CouponStatusViewModel result = new CouponStatusViewModel()
                {
                    from = DateTime.Now.AddMonths(-1).ToString("yyyy-MM-dd"),
                    to = DateTime.Now.ToString("yyyy-MM-dd"),
                    options = "0",
                    pageCnt = 10,
                    pageNum = 1
                };

                return View(result);
            }
            if (model.pageCnt == 10)
            {
                model.pageCnt = 10;
                model.pageNum = 1;
            }



            return View(model);
        }
        public async Task<IActionResult> couponAdd()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
            {
                tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.금액).ToString(),
                job_gbn = "1",
                shop_cd = info.shop_cd
            });

            SelectList salesMoney = new SelectList(getSalesMoney(), "Value", "Text", "%");
            ViewBag.salesMoney = salesMoney;

            ViewBag.foodAmount = (temp.data.ToList()).OrderBy(x => int.Parse(x.tip_fr_stand)).ToList();


            return PartialView("PartialCoupon", new CouponDetailViewModel
            {
                displayStDate = DateTime.Now.ToString("yyyy-MM-dd"),
                type = "1",
                applyGbn = "D",
                detail = new List<ResponseCouponDetail>()
            });
        }

        public async Task<IActionResult> MangagementPageFilter(CouponManagementViewModel model)
        {
            return ViewComponent("CouponList", new
            {
                result = model
            });
        }
        public async Task<IActionResult> UsePageFilter(CouponeListViewModel model)
        {
            return ViewComponent("CouponUseList", new
            {
                model = model
            });
        }
        public async Task<IActionResult> StatusPageFilter(CouponStatusViewModel model)
        {
            return ViewComponent("CouponStatusList", new
            {
                model = model
            });
        }
        public async Task<IActionResult> couponDetail(string type, string coupon)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if (string.IsNullOrEmpty(type))
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "구분자가 존재하지않습니다."
                });
            }

            var couponInfo = new CouponDetailViewModel();
            couponInfo.detail = new List<ResponseCouponDetail>();
            var req_coupon = await dgShop.PostSingle<CouponDetailViewModel, RequestCouponDetail>("/api/CouponManagement/GetDetailCouponManagement", new RequestCouponDetail
            {
                job_gbn = "1",
                shop_cd = info.shop_cd,
                couponType = coupon
            });

            if (req_coupon.code.Equals("00"))
            {
                couponInfo.type = type;
                couponInfo = req_coupon.data;

                var temp = await dgShop.Post<ShopInfoTipAmt, RequestShopInfoTipAmt>("DeliveryTipAmtList", new RequestShopInfoTipAmt
                {
                    tip_gbn = Convert.ToInt32(DELIVERY_TIP_GBN.금액).ToString(),
                    job_gbn = "1",
                    shop_cd = info.shop_cd
                });

                ViewBag.foodAmount = (temp.data.ToList()).OrderBy(x => int.Parse(x.tip_fr_stand)).ToList();


                SelectList salesMoney = new SelectList(getSalesMoney(), "Value", "Text", "%");
                ViewBag.salesMoney = salesMoney;

                couponInfo.displayEndDate = Utils.StringFormatToDate(couponInfo.displayEndDate);
                couponInfo.displayStDate = Utils.StringFormatToDate(couponInfo.displayStDate);
            }
            else
            {
                return Ok(new
                {
                    code = "99",
                    Msg = req_coupon.msg
                });
            }


            var req_couponDetail = await dgShop.PostSingle<CouponDetailViewModel, RequestCouponDetail>("/api/CouponManagement/GetDetailCouponManagement", new RequestCouponDetail
            {
                job_gbn = "3",
                shop_cd = info.shop_cd,
                couponType = coupon
            });

            couponInfo.type = type;
            couponInfo.couponType = coupon;
            couponInfo.detail = req_couponDetail.data.detail;

            return PartialView("PartialCoupon", couponInfo);
        }
        [HttpPost]
        public async Task<IActionResult> saleYn()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var result = await dgShop.Post<ResponseShopSaleInfo, RequestCommon>("/api/ShopManagement/GetShopSaleInfo", new RequestCommon
            {
                shop_cd = info.shop_cd
            });

            if (result.code.Equals("00"))
            {
                var data = result.data.SingleOrDefault();
                return Ok(new
                {
                    code = "00",
                    live = data.liveEventYn.Equals("Y") ? "사용" : "미사용",
                    packing = data.toGoDiscYn.Equals("Y") ? "사용" : "미사용",
                    coupon = data.shopCouponYn.Equals("Y") ? "사용" : "미사용",
                });
            }

            return Ok(new
            {
                code = "99",
                msg = ""
            });
        }
        [HttpPost]
        public async Task<IActionResult> SetCouponList(CouponDetailViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var diffTime = DateTime.Compare(Convert.ToDateTime(model.displayEndDate), Convert.ToDateTime(model.displayStDate));
            Debug.WriteLine(diffTime);
            if(diffTime < 0)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "쿠폰 적용기간이 전보다 큽니다" 
                });
            }
            Result<dynamic> result = new Result<dynamic>();
            RequestCouponSetting setResult = new RequestCouponSetting();
            
            if (model.type == "1")
            {
                setResult.applyGbn = model.applyGbn;
                setResult.couponName = model.couponName;
                setResult.couponType = model.couponType;
                setResult.displayEndDate = model.displayEndDate.Replace("-", "");
                setResult.displayStDate = model.displayStDate.Replace("-", "");
                setResult.expSetDate = model.expSetDate;
                setResult.job_gbn = model.type;
                setResult.mcode = info.login_code;
                setResult.mName = info.login_name;
                setResult.shop_cd = info.shop_cd;
            }
            else if( model.type == "2")
            {
                setResult.job_gbn = model.type;
                setResult.useGbn = model.useGbn;
                setResult.couponType = model.couponType;
                setResult.mcode = info.login_code;
                setResult.mName = info.login_name;
                setResult.shop_cd = info.shop_cd;
                setResult.seq = model.seq;
                setResult.displayEndDate = model.displayEndDate == null ? "" : model.displayEndDate.Replace("-", "");
                setResult.displayStDate = model.displayStDate == null ? "" :  model.displayStDate.Replace("-", "");

                if(model.detail == null)
                {
                    model.detail = new List<ResponseCouponDetail>();
                    ResponseCouponDetail Oracle1250Error = new ResponseCouponDetail();
                    Oracle1250Error.applyMinAmt = null;
                    Oracle1250Error.couponAmt = null;

                    model.detail.Add(Oracle1250Error);
                }
            }
            
            
            setResult.applyMinAmt = new List<string>();
            setResult.couponAmt = new List<string>();
            foreach (var m_item in model.detail)
            {
                //setResult.applyMinAmt.Add(m_item.applyMinAmt.Replace(",", ""));
                //setResult.couponAmt.Add(m_item.couponAmt.Replace(",", ""));
                setResult.applyMinAmt.Add(m_item.applyMinAmt == null ? "0" : m_item.applyMinAmt.Replace(",",""));
                setResult.couponAmt.Add(m_item.couponAmt == null ? "0" : m_item.couponAmt.Replace(",", ""));
            }



            if (model.type == "1") // 신규등록
            {
                result = await dgShop.Post<dynamic, RequestCouponSetting>("/api/CouponManagement/SetCouponSetting", setResult);
            }
            else if (model.type == "2")
            {
                result = await dgShop.Post<dynamic, RequestCouponSetting>("/api/CouponManagement/SetCouponSetting", setResult);
            }

            if (result.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    Msg = "성공"
                });
            }
            else
            {
                return Ok(new
                {
                    code = "99",
                    Msg = result.msg
                });
            }


        }
        #region method

        public int ConvertToDate(string optionLevel)
        {

            int result = 0;
            if (string.IsNullOrEmpty(optionLevel))
            {
                return 1;
            }

            switch (optionLevel)
            {
                case "0":
                    result = 1;
                    break;
                case "1":
                    result = 3;
                    break;
                case "2":
                    result = 6;
                    break;
                case "3":
                    result = 1;
                    break;
                case "4":
                    result = 0;
                    break;
                case "5":
                    result = 99;
                    break;
            }

            return result;
        }

        private List<SelectListItem> getSalesMoney()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            int counting = 1000;
            for (var i = 0; i < 19;i++)
            {
                var formatText = Utils.NumberFormatWonDelete(counting, true);
                var formatValue = Utils.NumberFormatWonDelete(counting);
                temp.Add(new SelectListItem()
                {
                    Selected = true,
                    Text = formatText,
                    Value = counting.ToString()
                });
                counting += 500;
            }
            return temp;

            #endregion
        }
    }
}
