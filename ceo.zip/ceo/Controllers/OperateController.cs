﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.ApiModels.Shop.Response;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.ChangeRequest.Response;
using PosWebApp.Models.Operate.Request;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Pos;
using PosWebApp.ViewModels.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class OperateController : Controller
    {
        private readonly DgShopApiService dgShop;

        /// <summary>
        /// 가맹점 운영 정보
        /// </summary>
        /// <returns></returns>
        public OperateController(DgShopApiService api)
        {
            dgShop = api;
        }
        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            Request req = new Request()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };

            var operate = dgShop.Post<ShopOperateInfo_V2, Request>("OperateVerion2", req);
            var origins = dgShop.Post<ShopFoodOrigins, dynamic>("GetShopOrigin", req);
            var intro = dgShop.Post<ShopIntro, Request>("GetShopIntro", req);
            var review = dgShop.Post<ReviewStatus, Request>("ReviewStatus", req);

            //var smartshop = dgShop.Post<ResponseServiceDetail, PosWebApp.Models.ChangeRequest.Request.RequestCommon>("/api/RequestService/GetKindShop", new PosWebApp.Models.ChangeRequest.Request.RequestCommon
            //{
            //    job_gbn = "1",
            //    shop_cd = Convert.ToInt32(info.shop_cd),
            //    service_gbn = "600"
            //});
            var smartshop = dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                   ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                   {
                       job_gbn = "1",
                       shop_cd = info.shop_cd,
                   });

            await Task.WhenAll(operate, origins, intro, smartshop);

            ViewData["operate"] = operate.Result.data.SingleOrDefault();
            ViewData["origins"] = origins.Result.data.SingleOrDefault();
            ViewData["intro"] = intro.Result.data.SingleOrDefault();
            ViewData["reviewStatus"] = review.Result.data.SingleOrDefault();
            ViewData["smartshop"] = smartshop.Result.data.SingleOrDefault();

            return View();
        }

        #region 운영시간 ( 영업시간 ) Default

        public IActionResult UpdateSaleTime(string start, string end)
        {
            SaleTimeViewModel model = new SaleTimeViewModel()
            {
                from_datetime = start,
                to_datetime = end
            };

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateSaleTime(SaleTimeViewModel viewModel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestSaleTime req = new RequestSaleTime()
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                from_time = viewModel.from_datetime.Replace(":", ""),
                to_time = viewModel.to_datetime.Replace(":", ""),
                next_day = viewModel.nextDay ? "Y" : "N",
                mod_code = info.login_code,
                mod_user = info.login_name,
            };

            var temp = await dgShop.Post<ShopSaleTime, RequestSaleTime>("SetSaleTime", req);
            if (temp.code.Equals("00"))
            {
                return RedirectToAction("Index");
            }

            return View();
        }

        #endregion

        public async Task<IActionResult> RegularHoliday(string data)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(data))
            {
                return BadRequest(new
                {
                    code="99",
                    msg = "데이터를 조회할수없습니다."
                });
            }

            Request req = new Request()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };

            var temp = await dgShop.Post<ShopHoliday, Request>("GetShopHoliday", req);

            if (temp.code.Equals("00"))
            {
                TempData["choice"] = data;
                return View(temp.data.SingleOrDefault());
            }

            return View();
        }

        /// <summary>
        /// 가맹점 정기 휴무일 설정
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> RegularHoliday(ShopHolidayViewModel model, string submit)
        {
            /// 김성근 이사님 요청 중
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var req = new
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                running = model.running,
                day_of_holiday = model.day_of_holiday,
                login_code = info.login_code.ToString(),
                login_name = info.login_name.ToString()
            };

            var temp = await dgShop.Post<ShopHoliday, dynamic>("SetShopHolidayTerm", req);
            if (temp.code.Equals("00"))
                return RedirectToAction(nameof(Index));

            return View(model);
        }

        public async Task<IActionResult> SetTemporaryHoliday()
        {
            await Task.Delay(0);
            return View();
        }

        #region 원산지
        /// <summary>
        /// 원산지, 가맹점 소개글 조회
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> RenderShopIntro()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            if (sessionString == null) return PartialView();
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopIntro, dynamic>("GetShopIntro", new
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            return View(temp.data.SingleOrDefault());
        }

        /// <summary>
        /// 가맹점 소개글
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> RenderShopIntro(ShopIntro model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<dynamic, dynamic>("SetShopIntro", new RequestSetShopOrigin
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                job_gbn = "I",
                shop_intro = model.shop_intro,
                user_code = info.login_code,
                user_name = info.login_name
            });

            return RedirectToAction("Index", "Store");
        }
        #endregion

        #region 원산지 설정
        public async Task<IActionResult> Origins()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            if (sessionString == null) return PartialView();
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopFoodOrigins, Request>("GetShopOrigin", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            return View(temp.data.SingleOrDefault());
        }

        [HttpPost]
        public async Task<IActionResult> Origins(ShopFoodOrigins model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopFoodOrigins, RequestSetShopOrigin>("SetShopOrigin", new RequestSetShopOrigin
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                job_gbn = "I",
                origin_mark = model.content,
                user_code = info.login_code,
                user_name = info.login_name
            });

            return RedirectToAction("Index");
        }
        #endregion

        #region 리뷰 사용/미사용
        public async Task<IActionResult> UpdateReviewStatus()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var review = await dgShop.Post<ReviewStatus, Request>("ReviewStatus", new Request
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                
            });

            return View(review.data.SingleOrDefault());
        }

        [HttpPost]
        public async Task<IActionResult> UpdateReviewStatus(ReviewStatus model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ReviewStatus, RequsetSetReviewGbn>("use_review", new RequsetSetReviewGbn
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                job_gbn = "1",
                mod_code = info.login_code,
                mod_user = info.login_name,
                use_gbn = model.status
            });

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("Index");
            }

            return View(model);
        }
        #endregion

        #region 착한매장
        /// <summary>
        /// 착한매장
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<IActionResult> RequestKindShop()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var smartshop = await dgShop.Post<ResponseServiceDetail, PosWebApp.Models.ChangeRequest.Request.RequestCommon>("/api/RequestService/GetKindShop", new PosWebApp.Models.ChangeRequest.Request.RequestCommon
            {
                job_gbn = "1",
                shop_cd = Convert.ToInt32(info.shop_cd),
                service_gbn = "600"
            });
            if (smartshop.code.Equals("00"))
            {
                return View(smartshop.data.SingleOrDefault());
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> RequestKindShop(Models.RequestModel.Request info)
        {
            return View();
        }

        public async Task<IActionResult> RequestKindApplication()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var smartshop = await dgShop.Post<ResponseServiceDetail, PosWebApp.Models.ChangeRequest.Request.RequestCommon>("/api/RequestService/GetKindShop", new PosWebApp.Models.ChangeRequest.Request.RequestCommon
            {
                job_gbn = "1",
                shop_cd = Convert.ToInt32(info.shop_cd),
                service_gbn = "600"
            });

            if (smartshop.code.Equals("00") && smartshop.data.SingleOrDefault().btnReqYn.Equals("Y"))
            {
                return PartialView("_PartialKindApplication", new PosWebApp.Models.ChangeRequest.Request.RequestKindModal
                {
                    
                });
            }


            return PartialView("_PartialKindApplication", new PosWebApp.Models.ChangeRequest.Request.RequestKindModal
            {
                
            });
        }
        [HttpPost]
        public async Task<IActionResult> RequestKindApplication(PosWebApp.Models.ChangeRequest.Request.RequestKindModal model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var second = new List<string>();
            if (model.menucost.Equals(true))
                second.Add("1");
            if (model.deliveryTip.Equals(true))
                second.Add("2");
            if (model.shopCoupon.Equals(true))
                second.Add("3");
            if (model.packSale.Equals(true))
                second.Add("4");
            if (model.dontExist.Equals(true))
                second.Add("5");

            var resultString = string.Join(",", second);

            var resultModal = new Models.ChangeRequest.Request.RequestKindApplication()
            {
                first = model.first,
                second = resultString,
                third = model.thrid
            };

            var req = await dgShop.Post<CodeMsg, PosWebApp.Models.ChangeRequest.Request.RequestCommon>("/api/RequestService/SetServiceRequest", new Models.ChangeRequest.Request.RequestCommon
            {
                file_name = "",
                job_gbn = "",
                mod_name = info.login_name,
                mod_ucode = info.login_code,
                seq = 0,
                service_data = JsonConvert.SerializeObject(resultModal),
                service_gbn = "600", // 착한매장신청 
                shop_cd = info.shop_cd,
                status = "10"
            });


            if(!req.code.Equals("00"))
            {
                ModelState.AddModelError("", "* 저장 중 에러가 발생했습니다. 관리자에게 문의 부탁드립니다.");
                return PartialView("_PartialKindApplication", model);
            }
            return PartialView("_PartialKindApplication",model);
        }
        [HttpPost]
        public async Task<IActionResult> RequestKindCancel()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //착한매장 SEQ 가져와서 아래 넣으면 취소
            var getResult = await dgShop.Post<ResponseServiceDetail, PosWebApp.Models.ChangeRequest.Request.RequestCommon>("/api/RequestService/GetKindShop", new PosWebApp.Models.ChangeRequest.Request.RequestCommon
            {
                job_gbn = "1",
                shop_cd = Convert.ToInt32(info.shop_cd),
                service_gbn = "600"
            });

            if (getResult.code.Equals("00"))
            {
                var cencelResult = getResult.data.SingleOrDefault().btnReqCancelYn;

                if (cencelResult.Equals("Y"))
                {
                    //취소가능
                    var req = await dgShop.Post<CodeMsg, PosWebApp.Models.ChangeRequest.Request.RequestCommon>("/api/RequestService/SetServiceRequest", new Models.ChangeRequest.Request.RequestCommon
                    {
                        file_name = "",
                        job_gbn = "",
                        mod_name = info.login_name,
                        mod_ucode = info.login_code,
                        seq = Convert.ToInt32(getResult.data.SingleOrDefault().seq),
                        service_gbn = "600", // 착한매장취소 
                        shop_cd = info.shop_cd,
                        status = "20"
                    });

                    if (req.code.Equals("00"))
                    {
                        return Ok(new
                        {
                            code = "00",
                            msg = "성공"
                        });
                    }
                    else
                    {
                        return Ok(new
                        {
                            code = "99",
                            msg = req.msg
                        });
                    }
                }
                else
                {
                    //취소 불가능
                    return Ok(new
                    {
                        code = "99",
                        msg = "실패"
                    });
                }
            }

            //취소 불가능
            return Ok(new
            {
                code = "99",
                msg = "실패"
            });
        }
        [HttpPost]
        public async Task<IActionResult> RequestKindWithdrawal()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //착한매장 SEQ 가져와서 아래 넣으면 해지
            var getResult = await dgShop.Post<ResponseServiceDetail, PosWebApp.Models.ChangeRequest.Request.RequestCommon>("/api/RequestService/GetKindShop", new PosWebApp.Models.ChangeRequest.Request.RequestCommon
            {
                job_gbn = "1",
                shop_cd = Convert.ToInt32(info.shop_cd),
                service_gbn = "600"
            });


            if (getResult.code.Equals("00"))
            {
                var cencelResult = getResult.data.SingleOrDefault().btnDelYn;

                if (cencelResult.Equals("Y"))
                {
                    //해지가능
                    var req = await dgShop.Post<CodeMsg, PosWebApp.Models.ChangeRequest.Request.RequestCommon>("/api/RequestService/SetServiceRequest", new Models.ChangeRequest.Request.RequestCommon
                    {
                        file_name = "",
                        job_gbn = "",
                        mod_name = info.login_name,
                        mod_ucode = info.login_code,
                        seq = Convert.ToInt32(getResult.data.SingleOrDefault().seq),
                        service_gbn = "601", // 착한매장취소 
                        shop_cd = info.shop_cd,
                        status = "10"
                    });

                    if (req.code.Equals("00"))
                    {
                        return Ok(new
                        {
                            code = "00",
                            msg = "성공"
                        });
                    }
                    else
                    {
                        return Ok(new
                        {
                            code = "99",
                            msg = req.msg
                        });
                    }
                }
                else
                {
                    //취소 불가능
                    return Ok(new
                    {
                        code = "99",
                        msg = "실패"
                    });
                }
            }

            //취소 불가능
            return Ok(new
            {
                code = "99",
                msg = "실패"
            });
        }
        #endregion
    }
}
