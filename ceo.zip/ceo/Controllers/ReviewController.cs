﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor.Infrastructure;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Models.Review;
using PosWebApp.Models.Review.Requests;
using PosWebApp.Models.Review.Responses;
using PosWebApp.Services.DgReview;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Review;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ReviewController : Controller
    {
        private readonly ReviewApi reviewService;
#if DEBUG
        private readonly ReviewDaeguAPI_T reviewDaeguService;
#else
        private readonly ReviewDaeguAPI reviewDaeguService;
#endif
        private readonly DgShopApiService dgShop;
        private readonly NLog.Logger nlogger;

        public ReviewController(ReviewApi reviewApi, ReviewDaeguAPI_T daeguAPI_T, ReviewDaeguAPI daeguAPI, IConfiguration configuration, DgShopApiService api)
        {
            reviewService = reviewApi;
#if DEBUG
            reviewDaeguService = daeguAPI_T;
#else
            reviewDaeguService = daeguAPI;
#endif
            dgShop = api;
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }
        #region rogall API
        /// <summary>
        /// 리뷰 토큰 조회
        /// </summary>
        /// <returns></returns>
        [HttpGet("get_token")]
        public async Task<CodeMsg> get_token()
        {
            CodeMsg result = new CodeMsg();
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");

            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            try
            {
                var temp = await reviewService.Post<TokenBody, dynamic>("get_token", new
                {
                    member_company_code = "daegu"
                });

                if (temp.statusCode == 200)
                {
                    result.code = "00";
                    result.msg = temp.body.token;
                    return result;
                }
                else
                {
                    result.code = "99";
                    result.msg = temp.body.error == null ? "알수 없는 에러" : temp.body.error;
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;

            }

            return result;
        }

        /// <summary>
        /// 리뷰 index
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> index()
        {
            var tokenData = await get_token();
            if (!tokenData.code.Equals("00"))
            {
                ViewBag.enable = false;
                ViewBag.message = tokenData.msg;
                return View();
            }

            ReviewSessionToken token = new ReviewSessionToken();
            token.token = tokenData.msg;
            var setToken = JsonConvert.SerializeObject(token);
            HttpContext.Session.SetString("ReviewToken", setToken);

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            #region 상점 정보 조회

            ReviewStore req = new ReviewStore()
            {
                store_code = info.shop_cd.ToString(),
                member_company_code = "daegu",
                cc_code = ""
            };

            var response = await reviewService.Post<ResponseStore, ReviewStore>("select_store", req, token.token);

            if (response.statusCode == 200)
            {
                #region 가맹점의 리뷰 사용 상태 확인

                var review = await dgShop.Post<ReviewStatus, Request>("ReviewStatus", new Request
                {
                    job_gbn = "1",
                    cccode = info.cccode,
                    shop_cd = info.shop_cd,

                });

                if (!review.code.Equals("00"))
                {
                    ViewBag.enabled = false;
                    ViewBag.message = review.msg;
                    return View();
                }
                if (review.data.SingleOrDefault().status.Equals("N"))
                {
                    ViewBag.enabled = false;
                    return View();
                }

                ViewBag.enabled = true;

                #endregion

                // jwcho 2021.05.16 TODO: 리뷰 관련 루틴 전체 분석 필요.
                // 리뷰 일정 관계로 아래 링크를 살려 둠
#if false
                return View(response.body.store);
#else
                return RedirectToAction("Store");
#endif
            }
            else if (response.statusCode == StatusCodes.Status300MultipleChoices)
            {
                ViewBag.message = response.body.error;
                return View();
            }

            return View();
            #endregion

        }
        /// <summary>
        /// 리뷰 상점 조회
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> Store()
        {
            ReviewSessionToken token = new ReviewSessionToken();
            string sessionToken = HttpContext.Session.GetString("ReviewToken");
            token = JsonConvert.DeserializeObject<ReviewSessionToken>(sessionToken);

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            var nullAnswer = string.IsNullOrEmpty(ViewBag.nullAnswer) ? null : ViewBag.nullAnswer;
            if (!string.IsNullOrEmpty(nullAnswer))
            {
                ViewBag.nullAnswer = nullAnswer;
            }
            ReviewStore req = new ReviewStore()
            {
                store_code = info.shop_cd.ToString(),
                member_company_code = "daegu",
                cc_code = ""
            };

            var response = await reviewService.Post<ResponseStore, ReviewStore>("select_store", req, token.token);

            if (response.statusCode == 200)
            {
                return View(response.body.store);
            }
            else if (response.statusCode == StatusCodes.Status300MultipleChoices)
            {
                ViewBag.message = response.body.error;
                return View();
            }
            return View();
        }
        /// <summary>
        /// 리뷰 상점 월별 거래건수 및 평점조회
        /// </summary>
        /// <returns></returns>

        #region 리뷰
        /// <summary>
        /// 리뷰 조회
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> Select(int? page, string type = null)
        {
            ReviewSessionToken token = new ReviewSessionToken();
            string sessionToken = HttpContext.Session.GetString("ReviewToken");
            token = JsonConvert.DeserializeObject<ReviewSessionToken>(sessionToken);

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            int PageNumber = 0;
            if (page == null || page == 1)
            {
                page = 1;
            }
            else
            {
                PageNumber = (int)(page - 1);
            }

            if (page == null)
            {
                page = 1;
            }

            ViewBag.pageNumber = page;
            /*
             * 리뷰 갯수 
             * **/
            RequestReportMStore ReviewReq = new RequestReportMStore()
            {
                cc_code = "",
                member_company_code = "daegu",
                store_code = info.shop_cd.ToString()
            };
            var cnt = 0;
            double answer_cnt = 0;
            var Response = await reviewService.Post<ResponseReportMStore, RequestReportMStore>("report_store_monthly_v2", ReviewReq, token.token);
            if (Response.statusCode == 200)
            {

                for (int i = 0; i < Response.body.result_data.Count; i++)
                {
                    cnt += Response.body.result_data[i].tran_cnt;
                    answer_cnt += Response.body.result_data[i].answer_cnt;
                }

                ViewBag.ReportStore = Response.body;
            }
            else
            {
                return NotFound();
            }
            //
            RequestReviewSelect req = new RequestReviewSelect()
            {
                cc_code = "",
                member_company_code = "daegu",
                page = PageNumber,
                use_type = "Y", // A:모든 Y: 미삭제만
                visible_opt = "A",//A:모든 O:사장님만, M:나만
                store_code = info.shop_cd.ToString(),
                order_opt = ""

            };
            var response = await reviewService.Post<ResponseReviewSelect, RequestReviewSelect>("select_review", req);

            if (response.statusCode == 200)
            {
                List<ReviewAnswer> answer = new List<ReviewAnswer>();


                for (var i = 0; i < response.body.count; i++)
                {
                    ReviewAnswer item = new ReviewAnswer();
                    item.answers = new List<ReviewAnswer>();
                    if (response.body.result_data[i].review_type == 0)
                    {
                        item.review_type = response.body.result_data[i].review_type;
                        item.board_idx = response.body.result_data[i].board_idx;
                        item.ref_board_idx = response.body.result_data[i].ref_board_idx;
                        item.ref_board_seq = response.body.result_data[i].ref_board_seq;
                        item.user_id = response.body.result_data[i].user_id;
                        item.nick_name = response.body.result_data[i].nick_name + "님";
                        item.subject = response.body.result_data[i].subject;
                        item.content = response.body.result_data[i].content;
                        item.board_img_url_1 = response.body.result_data[i].board_img_url_1;
                        item.board_img_url_2 = response.body.result_data[i].board_img_url_2;
                        item.board_img_url_3 = response.body.result_data[i].board_img_url_3;
                        item.board_img_url_4 = response.body.result_data[i].board_img_url_4;
                        item.board_img_url_5 = response.body.result_data[i].board_img_url_5;
                        item.order_menu = response.body.result_data[i].order_menu;
                        item.order_num = response.body.result_data[i].order_num;
                        item.eval_score = response.body.result_data[i].eval_score;
                        item.memo = response.body.result_data[i].memo;
                        item.visible_opt = response.body.result_data[i].visible_opt;
                        item.ins_date = response.body.result_data[i].ins_date;
                        item.upd_date = response.body.result_data[i].upd_date;
                        answer.Add(item);
                        for (int num = i + 1; num < response.body.count; num++)
                        {

                            if (response.body.result_data[num].review_type == 1)
                            {

                                ReviewAnswer sub_item = new ReviewAnswer();

                                sub_item.review_type = response.body.result_data[num].review_type;
                                sub_item.board_idx = response.body.result_data[num].board_idx;
                                sub_item.ref_board_idx = response.body.result_data[num].ref_board_idx;
                                sub_item.ref_board_seq = response.body.result_data[num].ref_board_seq;
                                sub_item.user_id = response.body.result_data[num].user_id;
                                sub_item.nick_name = response.body.result_data[num].nick_name;
                                sub_item.subject = response.body.result_data[num].subject;
                                sub_item.content = response.body.result_data[num].content;
                                sub_item.board_img_url_1 = response.body.result_data[num].board_img_url_1;
                                sub_item.board_img_url_2 = response.body.result_data[num].board_img_url_2;
                                sub_item.board_img_url_3 = response.body.result_data[num].board_img_url_3;
                                sub_item.board_img_url_4 = response.body.result_data[num].board_img_url_4;
                                sub_item.board_img_url_5 = response.body.result_data[num].board_img_url_5;
                                sub_item.order_menu = response.body.result_data[num].order_menu;
                                sub_item.order_num = response.body.result_data[num].order_num;
                                sub_item.eval_score = response.body.result_data[num].eval_score;
                                sub_item.memo = response.body.result_data[num].memo;
                                sub_item.visible_opt = response.body.result_data[num].visible_opt;
                                sub_item.ins_date = response.body.result_data[num].ins_date;
                                sub_item.upd_date = response.body.result_data[num].upd_date;

                                item.answers.Add(sub_item);
                                i++;
                            }
                            else if (response.body.result_data[num].review_type == 0)
                            {
                                break;
                            }
                        }
                    }
                }
                double TotalCnt = 0;
                var typeAnswer = new List<ReviewAnswer>();
                switch (type)
                {
                    case "a":
                        typeAnswer = answer;
                        TotalCnt = cnt;
                        break;
                    case "y": // 답변
                        typeAnswer = (from item in answer
                                      where item.answers.Count() > 0
                                      select item).ToList();
                        TotalCnt = answer_cnt;
                        break;
                    case "n": //미답변
                        typeAnswer = (from item in answer
                                      where item.answers.Count() == 0
                                      select item).ToList();
                        TotalCnt = (double)cnt - answer_cnt;
                        break;
                    case null:
                        type = "a";
                        TotalCnt = cnt;
                        typeAnswer = answer;
                        break;

                }
                ViewBag.Type = type;
                return View(ReviewPageList<ReviewAnswer>.Create(typeAnswer, TotalCnt, page ?? 1, 10));
            }
            return View();
        }
        /// <summary>
        /// 리뷰 답변 등록
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> Answer(ReviewAnswer answerModel)
        {
            ReviewSessionToken token = new ReviewSessionToken();
            string sessionToken = HttpContext.Session.GetString("ReviewToken");
            token = JsonConvert.DeserializeObject<ReviewSessionToken>(sessionToken);

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //if (string.IsNullOrEmpty(answerModel.content))
            //{
            //    ViewBag.nullAnswer = "입력값이 존재하지않습니다. 다시 입력해주시기 바랍니다.";
            //    nlogger.Info($"[ CEO Answer Error ,Shopcd === {info.shop_cd}, Content Null ===={ (string.IsNullOrEmpty(answerModel.content) ? "NULL" : answerModel.content)}");
            //    return View("store");
            //}
            RequestReviewAnswerModify req = new RequestReviewAnswerModify()
            {
                board_idx = answerModel.board_idx,
                subject = "",
                content = answerModel.content,
                user_id = info.shop_name,
                memo = "",
                cc_code = "",
                member_company_code = "daegu",
                store_code = info.shop_cd.ToString(),
                visible_opt = "A", // (A:전체, O:사장님만, M:나만)
            };

            var response = await reviewService.Post<ReviewOK, RequestReviewAnswerModify>("reg_review_answer", req, token.token);

            if (response.statusCode == 200)
            {
                return RedirectToAction("store");
            }
            var bodyContent = JsonConvert.SerializeObject(response.body);
            nlogger.Info($"[ CEO Answer Error ,Shopcd === {info.shop_cd}, http Status === { response.statusCode }, Body === {bodyContent}]");
            return NotFound();
        }
        /// <summary>
        /// 리뷰 답변 수정 등록
        /// </summary>
        /// <returns></returns>
        /// 
        public async Task<IActionResult> AnswerModify(ReviewAnswer answerModel)
        {
            ReviewSessionToken token = new ReviewSessionToken();
            string sessionToken = HttpContext.Session.GetString("ReviewToken");
            token = JsonConvert.DeserializeObject<ReviewSessionToken>(sessionToken);

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //if (string.IsNullOrEmpty(answerModel.content))
            //{
            //    ViewBag.nullAnswer = "입력값이 존재하지않습니다. 다시 입력해주시기 바랍니다.";
            //    nlogger.Info($"[ CEO Answer Error ,Shopcd === {info.shop_cd}, Content Null ===={ (string.IsNullOrEmpty(answerModel.content) ? "NULL" : answerModel.content)}");
            //    return View("store");
            //}
            RequestReviewAnswerModify req = new RequestReviewAnswerModify()
            {
                board_idx = answerModel.board_idx,
                subject = "",
                content = answerModel.content,
                user_id = info.shop_name,
                use_yn = "Y",
                memo = "",
                cc_code = "",
                member_company_code = "daegu",
                store_code = info.shop_cd.ToString(),
                visible_opt = "A", // (A:전체, O:사장님만, M:나만)
            };

            var response = await reviewService.Post<ReviewOK, RequestReviewAnswerModify>("alter_review_answer", req, token.token);

            if (response.statusCode == 200)
            {
                return RedirectToAction("store");
            }
            var bodyContent = JsonConvert.SerializeObject(response.body);
            nlogger.Info($"[ CEO AnswerModify Error ,Shopcd === {info.shop_cd}, http Status === { response.statusCode }, Body === {bodyContent}] ");
            return NotFound();
        }

        public async Task<IActionResult> AnswerDelete(ReviewAnswer answerModel)
        {
            ReviewSessionToken token = new ReviewSessionToken();
            string sessionToken = HttpContext.Session.GetString("ReviewToken");
            token = JsonConvert.DeserializeObject<ReviewSessionToken>(sessionToken);

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestReviewAnswerModify req = new RequestReviewAnswerModify()
            {
                board_idx = answerModel.board_idx,
                subject = "",
                content = answerModel.content,
                user_id = info.shop_name,
                use_yn = "N",
                memo = "",
                cc_code = "",
                member_company_code = "daegu",
                store_code = info.shop_cd.ToString(),
                visible_opt = "A", // (A:전체, O:사장님만, M:나만)
            };

            var response = await reviewService.Post<ReviewOK, RequestReviewAnswerModify>("alter_review_answer", req, token.token);

            if (response.statusCode == 200)
            {
                return RedirectToAction("store");
            }
            var bodyContent = JsonConvert.SerializeObject(response.body);
            nlogger.Info($"[ CEO AnswerDelete Error ,Shopcd === {info.shop_cd}, http Status === { response.statusCode }, Body === {bodyContent}] ");
            return NotFound();
        }
        #endregion

        #endregion

        #region Daeguro API
        public async Task<IActionResult> fail()
        {
            return View();
        }
        public async Task<IActionResult> info(string pageNum = null, string type = null)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ViewBag.enabled = true;
            RequestReviewCEO temp = new RequestReviewCEO
            {
                shopCode = info.shop_cd.ToString(),
                pageCnt = "",
                pageNum = pageNum,
                photoYn = "",
                SortGbn = ""
            };
            switch (type)
            {
                case "a":
                    ViewBag.Type = "a";
                    temp.JobGbn = "10";
                    break;
                case "un":
                    ViewBag.Type = "un";
                    temp.JobGbn = "12";
                    break;
                case "y":
                    ViewBag.Type = "y";
                    temp.JobGbn = "11";
                    break;
                default:
                    ViewBag.Type = "a";
                    temp.JobGbn = "10";
                    break;
            }
            var reviewStatus = await dgShop.Post<ReviewStatus, Request>("ReviewStatus", new Request
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd,

            });
            if (reviewStatus.data.SingleOrDefault().status.Equals("N"))
            {

                return RedirectToAction("fail");
            }


            //var req = await reviewDaeguService.Get<ResponseReviewCEO>("CEO?" +
            //    "shopCode=" + temp.shopCode +
            //    "&pageCnt=" + temp.pageCnt +
            //    "&pageNum=" + temp.pageNum +
            //    "&photoYn=" + temp.photoYn +
            //    "&SortGbn=" + temp.SortGbn +
            //    "&JobGbn=" + temp.JobGbn
            //    );

            var req = await reviewDaeguService.Get<ResponseReviewCEO>("v2/Review/CEO?" +
                "shopCode=" + temp.shopCode +
                "&pageCnt=" + temp.pageCnt +
                "&pageNum=" + temp.pageNum +
                "&photoYn=" + temp.photoYn +
                "&SortGbn=" + temp.SortGbn +
                "&JobGbn=" + temp.JobGbn
                );

            if (req.code == "00")
            {
                var answerinfo = await reviewDaeguService.Get<ResponseAnswerScore>("Review/count?" +
                                                                     "shopCode=" + info.shop_cd);

                ViewBag.answer = answerinfo.data;
                return View(req.data);
            }
            return Ok();
        }
        public async Task<IActionResult> CeoAnswer(items answer)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(answer.orderNo))
            {
                ViewBag.returnType = "99";
                ViewBag.Msg = "오더가 존재하지않습니다.";
                return Ok();
            }
            RequestReviewCeoAnswer temp = new RequestReviewCeoAnswer()
            {
                content = answer.answerContent,
                answerVisibleGbn = "A", // A 전체 , O 리뷰작성자+사장님, M 답글작성자(고객X)
                orderNo = answer.orderNo,
                modName = info.ccname,
                modUcode = info.shop_cd.ToString(),
                shopCode = info.shop_cd.ToString()
            };
            var req = await reviewDaeguService.Post<CodeMsg, RequestReviewCeoAnswer>("Review/answer", temp);

            if (req.code == "00")
            {
                return RedirectToAction("info");
            }

            /**
             * Error 
             * 
             */
            var bodyContent = JsonConvert.SerializeObject(temp);
            nlogger.Info($"[ CEO Answer Error ,Shopcd === {info.shop_cd}, body ==== {bodyContent}");
            return BadRequest(new
            {
                Msg = req.msg
            });

        }
        public async Task<IActionResult> CeoAnswerUpdate(items answer)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(answer.orderNo))
            {
                ViewBag.returnType = "99";
                ViewBag.Msg = "오더가 존재하지않습니다.";
                return Ok();
            }
            RequestReviewCeoAnswer temp = new RequestReviewCeoAnswer()
            {
                content = answer.answerContent,
                answerVisibleGbn = "A", // A 전체 , O 리뷰작성자+사장님, M 답글작성자(고객X)
                orderNo = answer.orderNo,
                modName = info.ccname,
                modUcode = info.shop_cd.ToString(),
                shopCode = info.shop_cd.ToString()
            };
            var req = await reviewDaeguService.Put<CodeMsg, RequestReviewCeoAnswer>("Review/answer", temp);

            if (req.code == "00")
            {
                return RedirectToAction("info");
            }

            /**
             * Error 
             * 
             */
            var bodyContent = JsonConvert.SerializeObject(temp);
            nlogger.Info($"[ CEO AnswerUpdate Error ,Shopcd === {info.shop_cd}, body ==== {bodyContent}");
            return BadRequest(new
            {
                Msg = req.msg
            });
        }
        public async Task<IActionResult> CeoAnswerDelete(items answer)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(answer.orderNo))
            {
                ViewBag.returnType = "99";
                ViewBag.Msg = "오더가 존재하지않습니다.";
                return Ok();
            }
            RequestReviewCeoAnswer temp = new RequestReviewCeoAnswer()
            {
                //content = answer.answerContent,
                //answerVisibleGbn = "A", // A 전체 , O 리뷰작성자+사장님, M 답글작성자(고객X)
                orderNo = answer.orderNo,
                modName = info.ccname,
                modUcode = info.shop_cd.ToString(),
                shopCode = info.shop_cd.ToString()
            };
            var req = await reviewDaeguService.Delete<CodeMsg, RequestReviewCeoAnswer>("Review/answer", temp);

            if (req.code == "00")
            {
                return Ok();
            }

            /**
             * Error 
             * 
             */
            var bodyContent = JsonConvert.SerializeObject(temp);
            nlogger.Info($"[ CEO Answer Error ,Shopcd === {info.shop_cd},body ==== {bodyContent}");
            return BadRequest(new
            {
                Msg = req.msg
            });

        }
        #endregion


        #region 블라인드 
        public async Task<IActionResult> BlindIndex(BlindChangeRequest param, int? pageNumber)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if (string.IsNullOrEmpty(param.from))
            {
                param.from = DateTime.Now.ToString("yyyy-MM-dd");
                param.to = DateTime.Now.ToString("yyyy-MM-dd");
                param.options = "";
            }

            ViewBag.Type = new SelectList(GetType(), "Value", "Text", "%");
            //ViewBag.RequestType = new SelectList(GetRquestType(), "Value", "Text", "%");
            return View(param);
        }
        public async Task<IActionResult> BlindRequest(string no)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            await Task.Delay(0);


            var blindTypeList = await reviewDaeguService.GetList<ResponseBilndType>("Review/blindType");

            if (blindTypeList.code.Equals("00"))
            {
                ViewBag.blindType = new SelectList(GetBlindReasonType(blindTypeList.data), "Value", "Text", "");

                RequestBlindReason answer = new RequestBlindReason
                {
                    orderNo = no
                };

                return PartialView(answer);
            }
            RequestBlindReason nullAnswer = new RequestBlindReason();
            ModelState.AddModelError("", "주문번호를 가져오지 못했습니다. 관리자에게 문의 바랍니다.");
            return PartialView(nullAnswer);


        }
        [HttpPost]
        public async Task<IActionResult> BlindRequestSave(RequestBlindReason param)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var blindTypeList = await reviewDaeguService.GetList<ResponseBilndType>("Review/blindType");

            if (blindTypeList.code.Equals("00"))
            {
                ViewBag.blindType = new SelectList(GetBlindReasonType(blindTypeList.data), "Value", "Text", "");
            }



            if (string.IsNullOrEmpty(param.blindCode))
            {
                ModelState.AddModelError("", "분류 구분을 선택해주세요.");
                return PartialView("BlindRequest", param);
            }
            if (string.IsNullOrEmpty(param.blindReason))
            {
                ModelState.AddModelError("", "사유가 존재하지않습니다. 작성 후 다시 눌러주세요.");
                return PartialView("BlindRequest", param);
            }
            nlogger.Info($"[ReviewBlind SHOP_CD save === {info.shop_cd} ]");

            param.shop_cd = info.shop_cd;
            param.modUcode = info.login_code.ToString();
            param.modUName = info.login_name;
            param.job_gbn = "1";
            param.visibleGbn = "R"; // r-> 요청 , c -> 취소 
            param.blindEndDt = DateTime.Now.ToString("yyyyMMdd");

            var reqResult = await reviewDaeguService.PostV2<CodeMsg, RequestBlindReason>(string.Join("/", "v2", "review", "blind"), param);


            if (reqResult.code.Equals("00"))
            {
                return PartialView("BlindRequest", param);
            }
            if (reqResult.code.Equals("99"))
            {
                ModelState.AddModelError("", reqResult.msg);
                return PartialView("BlindRequest", param);
            }
            ModelState.AddModelError("", "블라인드 요청에 실패하였습니다. 관리자에게 문의 바랍니다.");
            return PartialView("BlindRequest", param);
        }
        [HttpPost]
        public async Task<IActionResult> BlindRequestCancel(RequestBlindReason model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            
            nlogger.Info($"[ReviewBlind SHOP_CD cancal=== {info.shop_cd} ]");

            model.shop_cd = info.shop_cd;
            model.modUcode = info.login_code.ToString();
            model.modUName = info.login_name;
            model.job_gbn = "1";
            model.visibleGbn = "C"; // r-> 요청 , c -> 취소 
            model.blindEndDt = DateTime.Now.ToString("yyyyMMdd");

            var reqResult = await reviewDaeguService.PostV2<CodeMsg, RequestBlindReason>(string.Join("/", "v2", "review", "blind"), model);


            if (reqResult.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    msg = "성공"
                });
            }
            else if (reqResult.code.Equals("99"))
            {
                return Ok(new
                {
                    code = "99",
                    msg =  reqResult.msg
                });
            }
            else
            {
                return Ok(new
                {
                    code = "99",
                    msg = reqResult.msg
                });
            }
            
        }
        /*
         * 블라인드 페이지네이션 링크
         */
        public IActionResult BlindSearch(BlindChangeRequest model, int pageNumber)
        {
            ViewBag.Type = new SelectList(GetType(), "Value", "Text", "%");
            return ViewComponent("BlindRequestList", new
            {
                model = model,
                pageNumber = pageNumber

            });
        }
        /*
         * 리뷰 블라인드 사유 타입
         */
        public List<SelectListItem> GetBlindReasonType(List<ResponseBilndType> model)
        {
            if (model.Count() == 0)
            {
                return null;
            }
            List<SelectListItem> selectType = new List<SelectListItem>();
            foreach (var item in model)
            {
                selectType.Add(new SelectListItem
                {
                    Text = item.blindReason,
                    Value = item.blindCode
                });
            }
            return selectType;
        }

        public IActionResult BlindInfo(items item)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if (string.IsNullOrEmpty(item.orderNo))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "요청"
                });
            }

            return PartialView(item);
        }
        #endregion

        private List<SelectListItem> GetType()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "요청",
                Value = "10"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "완료",
                Value = "40"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "보완",
                Value = "35"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "기타",
                Value = "99"
            });

            return temp;
        }
    }
}