﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.GeoFence;
using PosWebApp.Models.Shape;
using PosWebApp.Settings;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GeoFence : ControllerBase
    {
        private readonly IOptions<DbStrings> dbString;

        public GeoFence(IOptions<DbStrings> dbString)
        {
            this.dbString = dbString;
        }

        #region Common State Area

        [HttpPost("Comm/Set")]
        public async Task<CodeMsg> SetCommonStateArea(RequestSetCommonUmd info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_GEOFENCE.SET_COMMON_UMD",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_hcode", OracleDbType.Varchar2)).Value = info.hcode;
                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                        cmd.Parameters.Add(new OracleParameter("in_sigungu", OracleDbType.Varchar2)).Value = info.sigungu;
                        cmd.Parameters.Add(new OracleParameter("in_umd", OracleDbType.Varchar2)).Value = info.umd;
                        cmd.Parameters.Add(new OracleParameter("in_lon_x", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.lon_x.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_lat_y", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = info.lat_y.ToArray();
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("Comm/Get")]
        public async Task<Result<CommonStateUmd>> GetCommonStateArea(RequestSetCommonUmd info)
        {
            Result<CommonStateUmd> result = new Result<CommonStateUmd>();

            try
            {
                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_GEOFENCE.GET_COMMON_UMD",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                        cmd.Parameters.Add(new OracleParameter("in_sigungu", OracleDbType.Varchar2)).Value = info.sigungu;
                        cmd.Parameters.Add(new OracleParameter("in_umd", OracleDbType.Varchar2)).Value = info.umd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<CommonStateUmd> modelList = new List<CommonStateUmd>();
                                while (await reader.ReadAsync())
                                {
                                    CommonStateUmd model = new CommonStateUmd
                                    {
                                        sido = reader["sido"].ToString(),
                                        sigungu = reader["sigungu"].ToString(),
                                        umd = reader["umd"].ToString(),
                                        shape_sequence = reader["shape_sequence"].ToString(),
                                        lon_x = Convert.ToDouble(reader["lon_x"].ToString()),
                                        lat_y = Convert.ToDouble(reader["lat_y"].ToString()),
                                        hcode = reader["hcode"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        #endregion


        [HttpPost("Shop/SetNew")]
        public async Task<Result<dynamic>> SetShopFenceNew(RequestSetShopFence info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                #region List Data 추출
                List<double> lon_x = new List<double>();
                List<double> lat_y = new List<double>();
                List<int> shape_sequence = new List<int>();

                foreach (var item in info.shop_fences)
                {
                    int j = 0;
                    foreach (var points in item.fence._array)
                    {
                        shape_sequence.Add(j++);
                        lon_x.Add(points.x);
                        lat_y.Add(points.y);
                    }
                }
                #endregion


                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_GEOFENCE.UPDATE_SHOP_AREA",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "I";
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                        cmd.Parameters.Add(new OracleParameter("in_sigungu", OracleDbType.Varchar2)).Value = info.sigungu;
                        cmd.Parameters.Add(new OracleParameter("in_umd", OracleDbType.Varchar2)).Value = info.umd;
                        cmd.Parameters.Add(new OracleParameter("in_ri", OracleDbType.Varchar2)).Value = info.ri;

                        cmd.Parameters.Add(new OracleParameter("in_area_name", OracleDbType.Varchar2)).Value = info.fence_name;
                        cmd.Parameters.Add(new OracleParameter("in_amount", OracleDbType.Varchar2)).Value = info.amount;
                        cmd.Parameters.Add(new OracleParameter("in_type", OracleDbType.Varchar2)).Value = info.insert_type;
                        cmd.Parameters.Add(new OracleParameter("in_use_gbn", OracleDbType.Varchar2)).Value = info.use_gbn;

                        cmd.Parameters.Add(new OracleParameter("in_area_sequence", OracleDbType.Varchar2)).Value = info.fence_sequence;
                        cmd.Parameters.Add(new OracleParameter("in_shape_seq", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = shape_sequence.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_lon_x", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = lon_x.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_lat_y", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = lat_y.ToArray();

                        cmd.Parameters.Add(new OracleParameter("in_mod_code", info.mod_code));
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", info.mod_user));
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }

                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        [HttpPost("Shop/DeleteNew")]
        public async Task<Result<dynamic>> DeleteShopFenceNew(RequestDeleteShopArea info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_GEOFENCE.DELETE_SHOP_DELIVERY_AREA",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_area_sequence", OracleDbType.Varchar2)).Value = info.fence_sequence;
                        cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = info.sido;
                        cmd.Parameters.Add(new OracleParameter("in_sigungu", OracleDbType.Varchar2)).Value = info.sigungu;
                        cmd.Parameters.Add(new OracleParameter("in_umd", OracleDbType.Varchar2)).Value = info.umd;
                        cmd.Parameters.Add(new OracleParameter("in_ri", OracleDbType.Varchar2)).Value = info.ri;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {



                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 상점 배달지역 + 커스텀 지역 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("Shop/GetDeliveryFencce")]
        public async Task<Result<ShopFence>> GetShopDeliveryFence(RequestSetShopFence info)
        {
            Result<ShopFence> result = new Result<ShopFence>();

            try
            {
                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_GEOFENCE.GET_SHOP_DELIVERY_AREA",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<FenceInfoNew> fenceInfos = new List<FenceInfoNew>();
                                while (await reader.ReadAsync())
                                {
                                    //FencePoint point = new FencePoint()
                                    //{
                                    //    shape_sequence = Convert.ToInt32(reader["shape_sequence"].ToString()),
                                    //    lon_x = Convert.ToDouble(reader["lon_x"].ToString()),
                                    //    lat_y = Convert.ToDouble(reader["lat_y"].ToString())
                                    //};

                                    FenceInfoNew fenceInfo = new FenceInfoNew();
                                    {
                                        fenceInfo.shop_cd = reader["shop_cd"].ToString();
                                        //fenceInfo.master_slave_gbn = reader["mst_slv"].ToString();
                                        fenceInfo.full_addr = reader["full_addr"].ToString().TrimEnd();
                                        fenceInfo.sido = reader["sido"].ToString();
                                        fenceInfo.sigungu = reader["sigungu"].ToString();
                                        fenceInfo.umd = reader["umd"].ToString();
                                        fenceInfo.ri = reader["ri"].ToString();
                                        fenceInfo.area_name = reader["area_name"].ToString();
                                        fenceInfo.insert_type = reader["insert_type"].ToString();
                                        fenceInfo.use_gbn = reader["use_gbn"].ToString();
                                        fenceInfo.amount = reader["amount"].ToString();
                                        fenceInfo.shape_sequence = Convert.ToInt32(reader["SHAPE_SEQUENCE"].ToString());
                                        fenceInfo.lon_x = Convert.ToDouble(reader["lon_x"].ToString());
                                        fenceInfo.lat_y = Convert.ToDouble(reader["lat_y"].ToString());
                                        fenceInfo.area_sequence = Convert.ToInt32(reader["area_sequence"].ToString());
                                    };
                                    fenceInfos.Add(fenceInfo);
                                }

                                var umdGroup = fenceInfos.GroupBy(x => x.full_addr);

                                List<ShopFence> shopFences = new List<ShopFence>();

                                #region Polygon Data

                                foreach (var areaSeq in umdGroup)
                                {
                                    ShopFence shopFence = new ShopFence();



                                    shopFence.fence = new NaverPolygonArray();

                                    #region 네이버 폴리곤 데이터에 대한 데이터 생성

                                    List<NaverMapPoint> points = new List<NaverMapPoint>();
                                    foreach (var area in areaSeq)
                                    {
                                        shopFence.sido = area.sido;
                                        shopFence.sigungu = area.sigungu;
                                        shopFence.umd = area.umd;
                                        shopFence.ri = area.ri;
                                        shopFence.full_addr = area.full_addr;
                                        shopFence.fence_name = area.area_name;
                                        shopFence.use_fence = area.use_gbn;
                                        shopFence.insert_type = area.insert_type;
                                        shopFence.fence_amount = area.amount;
                                        shopFence.fence_seq = area.area_sequence;

                                        NaverMapPoint p = new NaverMapPoint()
                                        {
                                            _lng = area.lon_x,
                                            x = area.lon_x,
                                            _lat = area.lat_y,
                                            y = area.lat_y,
                                        };
                                        points.Add(p);
                                    }

                                    shopFence.fence._array = points;
                                    shopFence.fence.length = points.Count;

                                    #endregion


                                    #region 네이버 지도 폴리곤을 그리기 위해 포인트 리스트가 있어야 한다.

                                    List<List<double>> pointList = new List<List<double>>();
                                    foreach (var xy in areaSeq)
                                    {
                                        List<double> point = new List<double>();
                                        point.Add(xy.lon_x);
                                        point.Add(xy.lat_y);
                                        pointList.Add(point);
                                    }

                                    shopFence.areaPoints = pointList;

                                    #endregion


                                    shopFences.Add(shopFence);
                                }

                                #endregion

                                result.data = shopFences;
                            }
                            result.code = "00";
                            result.msg = "성공";
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        [HttpPost("Shop/Seq")]
        public async Task<ResultSingle<dynamic>> GetLastSequence(RequestSetShopFence info)
        {
            ResultSingle<dynamic> result = new ResultSingle<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_GEOFENCE.GET_LAST_SEQ_SHOP_AREA",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_last_num", OracleDbType.Varchar2, 10)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();
                        string number = cmd.Parameters["out_last_num"].Value.ToString();

                        if (code.Equals("00"))
                        {
                            result.data = number;
                        }
                        result.code = code;
                        result.msg = message;
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
    }




    /* 사용안함 리스트
    
    [HttpPost("Shop/Set")]
        public async Task<Result<dynamic>> SetShopFence(RequestSetShopFence info)
        {
            Result<dynamic> result = new Result<dynamic>();

            #region List Data 추출
            List<double> lon_x = new List<double>();
            List<double> lat_y = new List<double>();
            List<int> shape_sequence = new List<int>();
            List<int> area_sequence = new List<int>();
            List<string> area_name = new List<string>();
            List<string> area_amount = new List<string>();
            List<string> use_area = new List<string>();

            foreach (var item in info.shop_fences)
            {
                int j = 0;
                foreach (var points in item.fence._array)
                {
                    area_sequence.Add(item.area);
                    shape_sequence.Add(j++);
                    lon_x.Add(points.x);
                    lat_y.Add(points.y);
                    area_amount.Add(item.fence_amount);
                    area_name.Add(item.fence_name);
                    use_area.Add(item.use_fence);
                }
            }
            #endregion

            try
            {
                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_NAVER_TEST.SET_SHOP_AREA",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "I";
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;

                        cmd.Parameters.Add(new OracleParameter("in_area_seq", OracleDbType.Int32)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = area_sequence.ToArray();

                        cmd.Parameters.Add(new OracleParameter("in_shape_seq", OracleDbType.Int32)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = shape_sequence.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_lon_x", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = lon_x.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_lat_y", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = lat_y.ToArray();

                        cmd.Parameters.Add(new OracleParameter("in_name", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = area_name.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_amount", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = area_amount.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_use_area", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = use_area.ToArray();

                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        await cmd.ExecuteNonQueryAsync();

                        result.code = "00";
                        result.msg = "성공";
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

    // 요거 안쓰는거 같은데
        /// <summary>
        /// 상점 커스텀 지역 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("Shop/GetNew")]
        public async Task<Result<ShopFence>> GetShopFenceNew(RequestSetShopFence info)
        {
            Result<ShopFence> result = new Result<ShopFence>();

            try
            {
                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_NAVER_TEST.GET_SHOP_AREA_NEW",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<FenceInfoNew> fenceInfos = new List<FenceInfoNew>();
                                while (await reader.ReadAsync())
                                {
                                    //FencePoint point = new FencePoint()
                                    //{
                                    //    shape_sequence = Convert.ToInt32(reader["shape_sequence"].ToString()),
                                    //    lon_x = Convert.ToDouble(reader["lon_x"].ToString()),
                                    //    lat_y = Convert.ToDouble(reader["lat_y"].ToString())
                                    //};

                                    FenceInfoNew fenceInfo = new FenceInfoNew();
                                    {
                                        fenceInfo.shop_cd = reader["shop_cd"].ToString();
                                        fenceInfo.master_slave_gbn = reader["mst_slv"].ToString();
                                        fenceInfo.full_addr = reader["full_addr"].ToString().TrimEnd();
                                        fenceInfo.sido = reader["sido"].ToString();
                                        fenceInfo.sigungu = reader["sigungu"].ToString();
                                        fenceInfo.umd = reader["umd"].ToString();
                                        fenceInfo.area_name = reader["area_name"].ToString();
                                        fenceInfo.insert_type = reader["insert_type"].ToString();
                                        fenceInfo.use_gbn = reader["use_gbn"].ToString();
                                        fenceInfo.amount = reader["amount"].ToString();
                                        fenceInfo.shape_sequence = Convert.ToInt32(reader["SHAPE_SEQUENCE"].ToString());
                                        fenceInfo.lon_x = Convert.ToDouble(reader["lon_x"].ToString());
                                        fenceInfo.lat_y = Convert.ToDouble(reader["lat_y"].ToString());
                                        fenceInfo.area_sequence = Convert.ToInt32(reader["area_sequence"].ToString());
                                    };
                                    fenceInfos.Add(fenceInfo);
                                }

                                var umdGroup = fenceInfos.GroupBy(x => x.full_addr);

                                List<ShopFence> shopFences = new List<ShopFence>();

                                #region Polygon Data

                                foreach (var areaSeq in umdGroup)
                                {
                                    ShopFence shopFence = new ShopFence();



                                    shopFence.fence = new NaverPolygonArray();

                                    #region 네이버 폴리곤 데이터에 대한 데이터 생성

                                    List<NaverMapPoint> points = new List<NaverMapPoint>();
                                    foreach (var area in areaSeq)
                                    {
                                        shopFence.sido = area.sido;
                                        shopFence.sigungu = area.sigungu;
                                        shopFence.umd = area.umd;
                                        shopFence.full_addr = area.full_addr;
                                        shopFence.fence_name = area.area_name;
                                        shopFence.use_fence = area.use_gbn;
                                        shopFence.insert_type = area.insert_type;
                                        shopFence.fence_amount = area.amount;
                                        shopFence.fence_seq = area.area_sequence;
                                        
                                        NaverMapPoint p = new NaverMapPoint()
                                        {
                                            _lng = area.lon_x,
                                            x = area.lon_x,
                                            _lat = area.lat_y,
                                            y = area.lat_y,
                                        };
                                        points.Add(p);
                                    }

                                    shopFence.fence._array = points;
                                    shopFence.fence.length = points.Count;

                                    #endregion


                                    #region 네이버 지도 폴리곤을 그리기 위해 포인트 리스트가 있어야 한다.

                                    List<List<double>> pointList = new List<List<double>>();
                                    foreach (var xy in areaSeq)
                                    {
                                        List<double> point = new List<double>();
                                        point.Add(xy.lon_x);
                                        point.Add(xy.lat_y);
                                        pointList.Add(point);
                                    }

                                    shopFence.areaPoints = pointList;

                                    #endregion


                                    shopFences.Add(shopFence);
                                }

                                #endregion

                                result.data = shopFences;
                            }
                            result.code = "00";
                            result.msg = "성공";
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

    [HttpPost("Shop/Delete")]
        public async Task<Result<dynamic>> DeleteShopFence(RequestDeleteShopArea info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_NAVER_TEST.DELETE_SHOP_AREA",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_area_seq", OracleDbType.Varchar2)).Value = info.area_sequence;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {



                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
    [HttpPost("Shop/Get")]
        public async Task<Result<ShopFence>> GetShopFence(RequestSetShopFence info)
        {
            Result<ShopFence> result = new Result<ShopFence>();

            try
            {
                using (OracleConnection conn = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "JWCHO_NAVER_TEST.GET_SHOP_AREA",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Int32)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<FenceInfo> fenceInfos = new List<FenceInfo>();
                                while (await reader.ReadAsync())
                                {
                                    FenceInfo fenceInfo = new FenceInfo();
                                    fenceInfo.fence_seq = Convert.ToInt32(reader["area_sequence"].ToString());
                                    fenceInfo.shape_seq = Convert.ToInt32(reader["shape_sequence"].ToString());
                                    fenceInfo.lon_x = Convert.ToDouble(reader["lon_x"].ToString());
                                    fenceInfo.lat_y = Convert.ToDouble(reader["lat_y"].ToString());
                                    fenceInfo.shop_cd = Convert.ToInt32(reader["shop_cd"].ToString());
                                    fenceInfo.fence_name = reader["area_name"].ToString();
                                    fenceInfo.fence_amount = reader["amount"].ToString();
                                    fenceInfo.use_fence = reader["use_area"].ToString();
                                    fenceInfos.Add(fenceInfo);

                                }

                                var areaGroup = fenceInfos.GroupBy(x => x.fence_seq);
                                List<ShopFence> shopFences = new List<ShopFence>();

                                #region Polygon Data

                                foreach (var areaSeq in areaGroup)
                                {
                                    ShopFence shopFence = new ShopFence();

                                    shopFence.fence = new NaverPolygonArray();

                                    #region 네이버 폴리곤 데이터에 대한 데이터 생성

                                    List<NaverMapPoint> points = new List<NaverMapPoint>();
                                    foreach (var area in areaSeq)
                                    {
                                        shopFence.area = area.fence_seq;
                                        shopFence.fence_name = area.fence_name;
                                        shopFence.fence_amount = area.fence_amount;
                                        shopFence.use_fence = area.use_fence;

                                        NaverMapPoint p = new NaverMapPoint()
                                        {
                                            _lng = area.lon_x,
                                            x = area.lon_x,
                                            _lat = area.lat_y,
                                            y = area.lat_y,
                                        };
                                        points.Add(p);
                                    }

                                    shopFence.fence._array = points;
                                    shopFence.fence.length = points.Count;

                                    #endregion


                                    #region 네이버 지도 폴리곤을 그리기 위해 포인트 리스트가 있어야 한다.

                                    List<List<double>> pointList = new List<List<double>>();
                                    foreach (var xy in areaSeq)
                                    {
                                        List<double> point = new List<double>();
                                        point.Add(xy.lon_x);
                                        point.Add(xy.lat_y);
                                        pointList.Add(point);
                                    }

                                    shopFence.areaPoints = pointList;

                                    #endregion


                                    shopFences.Add(shopFence);
                                }

                                #endregion

                                result.data = shopFences;
                            }
                            result.code = "00";
                            result.msg = "성공";
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }




    #region json type. current not use
        [HttpPost("Set")]
        public async Task<Result<NaverGeoData>> SetNaverGeoFence(RequestNaverGeo info)
        {
            Result<NaverGeoData> result = new Result<NaverGeoData>();

            try
            {
                using (OracleConnection connection = new OracleConnection(dbString.Value.IsDaegu))
                {
                    await connection.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = connection,
                        CommandText = "JWCHO_NAVER_TEST.SET_NAVER_AREA",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Decimal)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_data_seq", OracleDbType.Decimal)).Value = info.data_seq;
                        cmd.Parameters.Add(new OracleParameter("in_data", OracleDbType.Varchar2)).Value = info.data;
                        cmd.Parameters.Add(new OracleParameter("in_mod_user", OracleDbType.Varchar2)).Value = info.mod_user;
                        cmd.Parameters.Add(new OracleParameter("in_mod_code", OracleDbType.Varchar2)).Value = info.mod_ucode;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;


                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<NaverGeoData> modelList = new List<NaverGeoData>();
                                while (await reader.ReadAsync())
                                {
                                    NaverGeoData model = new NaverGeoData
                                    {
                                        shop_cd = Convert.ToInt32(reader["shop_cd"].ToString()),
                                        data_seq = Convert.ToInt32(reader["data_seq"].ToString()),
                                        data = reader["data_area"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }

                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("Get")]
        public async Task<Result<NaverGeoData>> GetNaverGeoFence(RequestNaverGeo info)
        {
            Result<NaverGeoData> result = new Result<NaverGeoData>();

            using (OracleConnection connection = new OracleConnection(dbString.Value.IsDaegu))
            {
                await connection.OpenAsync();
                using (OracleCommand cmd = new OracleCommand
                {
                    Connection = connection,
                    CommandText = "JWCHO_NAVER_TEST.GET_NAVER_AREA",
                    CommandType = CommandType.StoredProcedure
                })
                {
                    cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                    cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                    cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        string code = cmd.Parameters["out_ret_code"].Value.ToString();
                        string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                        if (code.Equals("00"))
                        {
                            List<NaverGeoData> modelList = new List<NaverGeoData>();
                            while (await reader.ReadAsync())
                            {
                                NaverGeoData model = new NaverGeoData
                                {
                                    shop_cd = Convert.ToInt32(reader["shop_cd"].ToString()),
                                    data_seq = Convert.ToInt32(reader["data_seq"].ToString()),
                                    data = reader["data_area"].ToString(),
                                };
                                modelList.Add(model);
                            }
                            result.data = modelList;
                        }
                        result.code = code;
                        result.msg = message;
                    }
                }
            }

            return result;
        }
        #endregion
     * */
}
