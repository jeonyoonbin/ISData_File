﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.MappApi;
using PosWebApp.Models.Operate.Request;
using PosWebApp.Models.OptionGroupOptions;
using PosWebApp.Models.OrderArea;
using PosWebApp.Models.RequestDaeguroPos;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Models.Review.Responses;
using PosWebApp.Services.DgReview;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
#if JWT_TEST_CODE
    [Authorize]
#endif
    [Route("[controller]")]
    [ApiController]
    public class ShopController : ControllerBase
    {
        private readonly ILogger<ShopController> _logger;
        private readonly IDaeguDatabase db;
        private readonly ReviewApi _review;

        #region ctor

        public ShopController(ILogger<ShopController> logger, IDaeguDatabase daeguDb, ReviewApi review, IConfiguration configuration)
        {
            _logger = logger;
            db = new DaeguDatabase(Utils.oracleConnectString, configuration);
            _review = review;
        }
        #endregion

        #region Common

        [HttpGet("BankList")]
        public async Task<Result<BankList>> BankList()
        {
            Result<BankList> result = new Result<BankList>();
            try
            {
                result = await db.BankList();
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;

            }
            return result;
        }

        /// <summary>
        /// 가맹점 업종 코드
        /// </summary>
        /// <returns></returns>
        [HttpGet("BizItemList")]
        public async Task<Result<ShopBizItem>> BizItemList()
        {
            Result<ShopBizItem> result = new Result<ShopBizItem>();
            try
            {
                result = await db.ShopBizItemList();
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;

            }
            return result;
        }

        [HttpGet("BizTaxType")]
        public Result<TaxType> BizTaxType()
        {
            Result<TaxType> result = new Result<TaxType>();
            try
            {
                result = db.BizTaxType();
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;

            }
            return result;
        }

        [HttpGet("Date")]
        public async Task< ResultSingle<string>> GetSysDate()
        {
            ResultSingle<string> result = new ResultSingle<string>();

            try
            {
                result = await db.GetSysDate();
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        #endregion

        #region 주소

        [HttpGet("sido")]
        public async Task<Result<Sido>> GetSido()
        {
            Result<Sido> result = new Result<Sido>();

            try
            {
                result = await db.GetSido();
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("gungu")]
        public async Task<Result<Gungu>> GetSigungu(RequestSigungudong info)
        {
            Result<Gungu> result = new Result<Gungu>();

            try
            {
                result = await db.GetSigungu(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("umdr")]
        public async Task<Result<HDong>> GetUmdr(RequestSigungudong info)
        {
            Result<HDong> result = new Result<HDong>();

            try
            {
                result = await db.GetHdong(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("NewUmdr")]
        public async Task<Result<HDong>> GetUmdrNew(RequestSigungudong info)
        {
            Result<HDong> result = new Result<HDong>();
            // 시군구 정보에서 띄어쓰기가 없어야 한다.
            if (info.sigungu != null)
                info.sigungu = info.sigungu.Replace(" ", "");

            try
            {
                var b = db.GetUmdrB(info);
                var h = db.GetUmdrH(info);

                await Task.WhenAll(b, h);

                List<HDong> dongList = new List<HDong>();
                // 행정동에 Ri 정보 포함
                foreach (var item in h.Result.data)
                {
                    var foundItems = b.Result.data.FindAll(x => x.b_name.Equals(item.h_name));

                    if (foundItems != null && foundItems.Count > 0)
                    {
                        item.sub_link = foundItems;
                        foreach (var fItem in foundItems)
                        {
                            HDong dong = new HDong();
                            dong.sido = item.sido;
                            dong.sigungu = item.sigungu;
                            dong.h_name = item.h_name;
                            dong.h_code = item.h_code;
                            dong.lon = item.lon;
                            dong.lat = item.lat;
                            dong.b_name = fItem.b_name;
                            dong.b_code = fItem.b_code;
                            dong.b_ri_name = fItem.b_ri_name;
                            dong.humdr = string.Join(" ", fItem.b_name, fItem.b_ri_name);
                            dongList.Add(dong);
                        }
                    }
                    else
                    {
                        HDong dong = new HDong();
                        dong.sido = item.sido;
                        dong.sigungu = item.sigungu;
                        dong.h_name = item.h_name;
                        dong.h_code = item.h_code;
                        dong.lon = item.lon;
                        dong.lat = item.lat;
                        dong.humdr = item.h_name;
                        dongList.Add(dong);
                    }
                }

                result = h.Result;
                result.data = dongList;
                return result;
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        #endregion

        #region 출금

        /// <summary>
        /// 출금 정보 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("AccInfo")]
        public async Task<Result<ResponseShopAccountInfo>> GetShopAccountInfo(Request info)
        {
            Result<ResponseShopAccountInfo> result = new Result<ResponseShopAccountInfo>();

            try
            {
                result = await db.GetShopAccountInfo(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 예금주 확인 조회 결과가 "N"인 경우 예금주 확인 및 결과 등록
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("AccConfirm")]
        public async Task<CodeMsg> SetAccConfirmGbn(RequestSetAccConfirmGbn info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                result = await db.SetAccConfirmGbn(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 사입출금/이체시 sms 인증 추가
        /// 1 출금 가능 여부 확인
        /// 3 SMS 인증 번호 확인
        /// 5 SMS 인증 번호 발송 요청
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("SmsCheck")]
        public async Task<CodeMsg> GetShopTransSmsCheck(RequestTransSmsCheck info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                result = await db.GetShopTransSmsCheck(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("SetSmsCheck")]
        public async Task<CodeMsg> SetTransferSmsCheck(RequestSmsCheck info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                result = await db.SetTransferSmsCheck(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 적립금 입출 내역
        /// 1 : 리스트
        /// 3 : 적립금 내역
        /// 9 : 적립금 구분 코드
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("GetChargeList")]
        public async Task<Result<ResponseShopChargeList>> GetShopInfoChargeList(RequestAccShopChargeList info)
        {
            Result<ResponseShopChargeList> result = new Result<ResponseShopChargeList>();

            try
            {
                result = await db.GetShopInfoChargeList(info);

                long remain_amt = 0;
                foreach (var item in result.data)
                {
                    long.TryParse(item.in_amt, out long inAmount);
                    long.TryParse(item.out_amt, out long outAmount);

                    remain_amt = item.remain_amount += (remain_amt + inAmount - outAmount);
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 이체 요청
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("SetShopTransfer")]
        public async Task<CodeMsg> SetShopTransfer(RequestShopChargeList info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                result = await db.SetShopTransfer(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// SMS 인증 상태 체크
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("SmsStatus")]
        public async Task<Result<SmsConfirmStatus>> GetSmsConfirmStatus(Request info)
        {
            Result<SmsConfirmStatus> result = new Result<SmsConfirmStatus>();

            try
            {
                result = await db.GetSmsConfirmStatus(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        #endregion


        #region Shop Info / Login

        /// <summary>
        /// 로그인 페이지를 보여주기 위함 ( 데이터 정리 필요. 프로시져 교체 필요 )
        /// </summary>
        /// <returns></returns>
        [HttpPost("ShopLogin")]
        public async Task<Result<DaeguShopInfo>> ShopLogin(RequestLogin info)
        {
            Result<DaeguShopInfo> result = new Result<DaeguShopInfo>();

            try
            {
                result = await db.ShopLogin(info.id, info.password, "111", "222", "테스트테스트");
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
                Utils.SaveError(string.Join(" : ", HttpContext.Request.Path, HttpContext.Request.Method), e.Message);
            }

            return result;
        }


        /// <summary>
        /// 가맹점의 모든 정보를 가져온다. ( 사장님 사이트에서는 사용하지 않음
        /// </summary>
        /// <returns></returns>
        [HttpGet("InfoAll")]
        public async Task<Result<ShopInfo>> ShopInfoAll()
        {
            Result<ShopInfo> response = new Result<ShopInfo>();

            try
            {
                response = await db.ShopInfoAll("공주찜닭", "a1234");
                return response;
            }
            catch (Exception e)
            {
                response.code = "99";
                response.msg = e.Message;
                Utils.SaveError(string.Join(" : ", HttpContext.Request.Path, HttpContext.Request.Method), e.Message);
            }

            return response;
        }

        [HttpPost("LinkTo")]
        public async Task<Result<ShopSessionDefaultInfo>> GetShopFromMapp(RqeuestPosLink model)
        {
            Result<ShopSessionDefaultInfo> result = new Result<ShopSessionDefaultInfo>();

            try
            {
                result = await db.GetShopFromMapp(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("syncInfo")]
        public async Task<Result<SynchronizeShopInfo>> ShopAndPosSynchronizeInfo(Request info)
        {
            Result<SynchronizeShopInfo> result = new Result<SynchronizeShopInfo>();

            try
            {
                result = await db.ShopAndPosSynchronizeInfo(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        [HttpPost("Search/Shop")]
        public async Task<Result<ShopAllInfo>> SearchShopForMapp(RequestSearchShop info)
        {
            Result<ShopAllInfo> result = new Result<ShopAllInfo>();

            try
            {
                result = await db.SearchShopForMapp(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }
#if JWT_TEST_CODE
        [AllowAnonymous]
#endif
        [HttpPost("GetByShop")]
        public async Task<Result<CodeMsg>> GetByShop(RequestLogin model)
        {
            Result<CodeMsg> result = new Result<CodeMsg>();
            try
            {
                result = await db.GetByShop(model);
            }
            catch(Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
#if JWT_TEST_CODE
        [AllowAnonymous]
#endif
        /// <summary>
        /// 가맹점 기본 정보 저장 ( 세션 저장용 )
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Default")]
        public async Task<Result<ShopSessionDefaultInfo>> DefaultSessionInfo(RequestLogin model)
        {
            Result<ShopSessionDefaultInfo> result = new Result<ShopSessionDefaultInfo>();

            try
            {
                result = await db.ShopSessionInfo(model.id, model.password, model.shop_cd, model.ucode);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
                Utils.SaveError(string.Join(" : ", HttpContext.Request.Path, HttpContext.Request.Method), e.Message);
            }

            return result;
        }

        /// <summary>
        /// 공공앱 사장님 매장 정보
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("DefaultInfo")]
        public async Task<Result<ShopStoreInfo>> DefaultHomePage(Request info)
        {
            Result<ShopStoreInfo> result = new Result<ShopStoreInfo>();

            try
            {
                result = await db.ShopDefaultInfoNew(info);
                //result = await db.ShopDefaultInfo(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("DefaultInfo/Update")]
        public async Task<Result<ShopDefaultInfo>> DefaultHomPageUpdate(Request info)
        {
            Result<ShopDefaultInfo> result = new Result<ShopDefaultInfo>();

            try
            {
                result = await db.ShopDefaultInfoUpdate(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("Address")]
        public async Task<Result<ShopAddress>> Address(Request info)
        {
            Result<ShopAddress> result = new Result<ShopAddress>();

            try
            {
                result = await db.ShopAddress(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        [HttpPost("Address/Update")]
        public async Task<Result<ShopAddress>> AddressUpdate(RequestSetShopAddress info)
        {
            Result<ShopAddress> result = new Result<ShopAddress>();

            try
            {
                result = await db.ShopAddressUpdate(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 사업자 정보 조회
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("BizInfo")]
        public async Task<Result<ShopBizInfo>> ShopBizInfo(Request model)
        {
            Result<ShopBizInfo> result = new Result<ShopBizInfo>();

            try
            {
                result = await db.ShopBizInfo(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        [HttpPost("SetEmail")]
        public async Task<Result<ShopBizInfo>> ShopBizinfoEmail(RequestSetEmail model)
        {
            Result<ShopBizInfo> result = new Result<ShopBizInfo>();

            try
            {
                result = await db.ShopBizinfoEmail(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        /// <summary>
        /// 가맹점 사업자 정보 수정
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("BizInfo/Set")]
        public async Task<Result<ShopBizInfo>> SetShopBizInfo(RequestSetBizInfo model)
        {
            Result<ShopBizInfo> result = new Result<ShopBizInfo>();

            try
            {
                result = await db.SetShopBizInfo(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 공공앱 사장님 사이트 운영 정보
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Operate")]
        public async Task<Result<ShopOperateInfo>> ShopOperateInfo(Request model)
        {
            Result<ShopOperateInfo> result = new Result<ShopOperateInfo>();

            try
            {
                result = await db.ShopOperateInfo(model.shop_cd);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 공공앱 사장님 사이트 운영 정보 version2.0
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("OperateVerion2")]
        public async Task<Result<ShopOperateInfo_V2>> ShopOperateInfo_v2(Request model)
        {
            Result<ShopOperateInfo_V2> result = new Result<ShopOperateInfo_V2>();

            try
            {
                result = await db.ShopOperateInfo_v2(model.shop_cd);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("ReviewStatus")]
        public async Task<Result<ReviewStatus>> ShopReviewStatus(Request model)
        {
            Result<ReviewStatus> result = new Result<ReviewStatus>();

            try
            {
                result = await db.ShopReviewStatus(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 이동내역 조회(공공앱 기준), 2021/03/07
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MoveHist")]
        public async Task<Result<dynamic>> ShopMoveHist(Request model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.ShopMoveHist(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 POS Update 정보 저장. 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetShopPosInfo")]
        public async Task<Result<dynamic>> SetShopPosInfo(RequestSetShopPosInfo model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetShopPosInfo(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 POS Update 정보 조회.
        /// </summary>
        /// <param name="job_gbn"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        [HttpGet("PosInfo/{job_gbn}/{date}")]
        public async Task<Result<PosInfo>> GetShopPosInfo(string job_gbn, string date)
        {
            Result<PosInfo> result = new Result<PosInfo>();
            try
            {
                result = await db.GetShopPosInfo(job_gbn, date);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }
            return result;
        }

        /// <summary>
        /// 가맹점 POS Update 결과 저장. (2019/02/25 ) 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetShopPosUpdateInfo")]
        public async Task<Result<dynamic>> SetShopPosUpdateInfo(RequestSetShopPosUpdateInfo model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetShopPosUpdateInfo(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점정보 상세, 2015/01/12
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Detail")]
        public async Task<Result<ShopDetail>> ShopDetail(Request model)
        {
            Result<ShopDetail> result = new Result<ShopDetail>();

            try
            {
                result = await db.ShopDetail(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 공공앱 사장님 사이트 계좌 정보
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Account")]
        public async Task<Result<ShopAccount>> ShopAccount(Request model)
        {
            Result<ShopAccount> result = new Result<ShopAccount>();

            try
            {
                result = await db.ShopAccount(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 계좌 수정
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Account/Set")]
        public async Task<Result<ShopAccount>> SetShopAccount(RequestShopAccount model)
        {
            Result<ShopAccount> result = new Result<ShopAccount>();

            try
            {
                result = await db.SetShopAccount(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 영업동 리스트 전체 동 포함
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("ShopSector")]
        public async Task<Result<ShopBizSector>> GetShopSector(RequestGetShopSector model)
        {
            Result<ShopBizSector> result = new Result<ShopBizSector>();

            try
            {
                Result<ShopSector> resultItem = resultItem = await db.GetShopSector(model);
                if (!string.IsNullOrEmpty(model.sido) && !string.IsNullOrEmpty(model.sigungu))
                {
                    resultItem.data = resultItem.data.Where(x => x.sido.Equals(model.sido) && x.sigungu.Equals(model.sigungu)).ToList();
                }


                Dictionary<string, Dictionary<string, List<ShopSector>>> dicSido = new Dictionary<string, Dictionary<string, List<ShopSector>>>();
                foreach (var item in resultItem.data)
                {
                    if (dicSido.ContainsKey(item.sido))
                    {
                        if (dicSido[item.sido].ContainsKey(item.sigungu))
                        {
                            dicSido[item.sido][item.sigungu].Add(item);
                        }
                        else
                        {
                            dicSido[item.sido].Add(item.sigungu, new List<ShopSector>() { item });
                        }
                    }
                    else
                    {
                        Dictionary<string, List<ShopSector>> dicSigungu = new Dictionary<string, List<ShopSector>>();
                        dicSigungu.Add(item.sigungu, new List<ShopSector>() { item });
                        dicSido.Add(item.sido, dicSigungu);
                    }

                    Debug.WriteLine(string.Join(" ", item.sido, item.sigungu, item.umdr));

                }

                List<ShopBizSector> sectorList = new List<ShopBizSector>();
                foreach (var sidoname in dicSido)
                {
                    ShopBizSector sector = new ShopBizSector();
                    sector.sido = sidoname.Key;
                    sector.sigunguList = new List<ShopSigunguBizSector>();

                    foreach (var gunguname in sidoname.Value)
                    {
                        Debug.WriteLine(string.Join(" ", sidoname.Key, gunguname.Key));


                        ShopSigunguBizSector sigunguSector = new ShopSigunguBizSector();
                        sigunguSector.sigungu = gunguname.Key;

                        RequestSigungudong req = new RequestSigungudong()
                        {
                            job_gbn = "1",
                            sido = sidoname.Key,
                            sigungu = gunguname.Key
                        };
                        //var temp = await GetUmdrNew(req);
                        var temp = await GetUmdr(req);
                        sigunguSector.umdrList = new List<HDong>();
                        foreach (var dong_item in temp.data)
                        {
                            var exist = gunguname.Value.Find(x => x.umdr.Equals(dong_item.humdr));
                            if (exist != null)
                            {
                                dong_item.selected = true;
                            }
                            sigunguSector.umdrList.Add(dong_item);

                        }


                        sector.sigunguList.Add(sigunguSector);

                    }
                    sectorList.Add(sector);
                }
                result.data = sectorList;
                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("GetShopSectorRaw")]
        public async Task<Result<ShopSector>> GetShopSectorRaw(RequestGetShopSector model)
        {
            Result<ShopSector> result = new Result<ShopSector>();

            try
            {
                result = await db.GetShopSector(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 영업동 설정
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("ShopSector/Set")]
        public async Task<Result<ShopSector>> SetShopSector(RequestSetShopSector model)
        {
            Result<ShopSector> result = new Result<ShopSector>();

            try
            {
                result = await db.SetShopSector(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 영업동 설정_V2
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("ShopSector/Set_V2")]
        public async Task<Result<dynamic>> SetShopSector_V2(RequestUpdateOrderArea model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetShopSector_V2(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }


        /// <summary>
        /// 가맹점 영업동 설정 ( 시군구 단위 )
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("ShopSector/ListSet")]
        public async Task<Result<ShopSector>> SetShopSectorList(RequestSetShopSectorMulti model)
        {
            Result<ShopSector> result = new Result<ShopSector>();

            try
            {
                if (model.job_gbn.Equals("I"))
                    result = await db.SetShopSectorMulti(model);
                else if (model.job_gbn.Equals("U"))
                {
                    // 시군구 내역을 모두 삭제
                    result = await DeleteSectorList(model);
                    // 시군구 내역 전체 추가
                    model.job_gbn = "I";
                    result = await db.SetShopSectorMulti(model);
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("ShopSector/Delete")]
        public async Task<Result<ShopSector>> DeleteSectorList(RequestSetShopSectorMulti model)
        {
            Result<ShopSector> result = new Result<ShopSector>();

            try
            {
                result = await db.SetShopSector(new RequestSetShopSector
                {
                    job_gbn = "D_GUNGU",
                    sido = model.delete_sido,
                    sigungu = model.delete_sigungu,
                    cccode = model.cccode,
                    shop_cd = model.shop_cd
                });
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("UpdateAppMinAmt")]
        public async Task<Result<dynamic>> SetAppMinAmt(RequestAppMinAmt model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetAppMinAmt(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        [HttpPost("UpdateFreeOrderAmt")]
        public async Task<Result<dynamic>> SetFreeOrderAmt(RequestFreeOrderAmt model)
        {
            Result<dynamic> result = new Result<dynamic>();
            try
            {
                result = await db.SetFreeOrderAmt(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }
            return result;
        }

        [HttpPost("UpdateOrderCompTime")]
        public async Task<Result<dynamic>> SetOrderCompleteTime(RequestOrderCompleteTime model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetOrderCompleteTime(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("GetOrderTime")]
        public async Task<Result<ORDER_COMPLETE_TIME>> GetOrderCompleteTime(Request model)
        {
            Result<ORDER_COMPLETE_TIME> result = new Result<ORDER_COMPLETE_TIME>();

            try
            {
                result = await db.GetOrderCompleteTime(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        [HttpPost("UpdateSearchTag")]
        public async Task<Result<dynamic>> SetSearchTag(RequestUpdateSearchTag model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetSearchTag(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("SearchTag")]
        public async Task<Result<ShopSearchTag>> GetSearchTab(Request model)
        {
            Result<ShopSearchTag> result = new Result<ShopSearchTag>();

            try
            {
                result = await db.GetSearchTag(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }


        [HttpPost("SetStoreImage")]
        public async Task<Result<StoreImageUrl>> SetStoreImage(RequestSetImageUrl model)
        {
            Result<StoreImageUrl> result = new Result<StoreImageUrl>();

            try
            {
                result = await db.SetStoreImage(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("SetLogoImage")]
        public async Task<Result<StoreImageUrl>> SetLogoImage(RequestSetImageUrl model)
        {
            Result<StoreImageUrl> result = new Result<StoreImageUrl>();

            try
            {
                result = await db.SetLogoImage(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("SetSaleTime")]
        public async Task<Result<ShopSaleTime>> SetSaleTime(RequestSaleTime model)
        {
            Result<ShopSaleTime> result = new Result<ShopSaleTime>();

            try
            {
                result = await db.SetSaleTime(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("SetItemCodes")]
        public async Task<Result<ShopItemCodes>> SetITemCodes(RequestShopItemCodes model)
        {
            Result<ShopItemCodes> result = new Result<ShopItemCodes>();

            try
            {
                result = await db.SetITemCodes(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("PayType/Get")]
        public async Task<ResultSingle<ShopPayType>> GetShopPayType(Request model)
        {
            ResultSingle<ShopPayType> result = new ResultSingle<ShopPayType>();

            try
            {
                result = await db.GetShopPayType(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("PayType/Set")]
        public async Task<ResultSingle<ShopPayType>> SetShopPayType(RequestShopPayType model)
        {
            ResultSingle<ShopPayType> result = new ResultSingle<ShopPayType>();

            try
            {
                result = await db.SetShopPayType(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }


        #endregion

        #region 적립금

        /// <summary>
        /// 가맹점 계좌이체 요청
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("TransMoney")]
        public async Task<Result<dynamic>> ShopInfoTran(RequestShopInfoTran model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetShopInfoTran(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 적립금 입출내역
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("ShopInfoChargeList")]
        public async Task<Result<ShopInfoChargeList>> ShopInfoChargeList(RequestShopInfoChargeList model)
        {
            Result<ShopInfoChargeList> result = new Result<ShopInfoChargeList>();

            try
            {
                result = await db.ShopInfoChargeList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
                Utils.SaveError(string.Join(" : ", HttpContext.Request.Path, HttpContext.Request.Method), e.Message);
            }

            return result;
        }

        /// <summary>
        /// 가맹점적립금 계좌이체내역조회
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("AccountTrans")]
        public async Task<Result<ShopAccountTrans>> AccountTrans(RequestShopAccountTrans model)
        {
            Result<ShopAccountTrans> result = new Result<ShopAccountTrans>();

            try
            {
                result = await db.ShopAccountTrans(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점적립금 계좌이체 상세
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("AccountTransD")]
        public async Task<Result<ShopAccountTransD>> AccountTransD(RequestShopAccountTransD model)
        {
            Result<ShopAccountTransD> result = new Result<ShopAccountTransD>();

            try
            {
                result = await db.ShopAccountTransD(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 계좌 및 잔액 조회
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("TransRemainAmt")]
        public async Task<Result<ShopTransRemainAmt>> TransRemainAmt(Request model)
        {
            Result<ShopTransRemainAmt> result = new Result<ShopTransRemainAmt>();

            try
            {
                result = await db.GetTransRemainAmt(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 이체계좌 인증구분 수정
        /// 아마도 사장님 사이트에서는 계좌 관련 업무를 수행하지 않을 것 같음.
        /// TODO : 내부 구현 필요
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetAccConfirnGbn")]
        public async Task<Result<dynamic>> SetAccConfirnGbn(Request model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetAccConvirmGbn(model);
                result.code = "1000";
                result.msg = "내부 구현이 안되어 있습니다. 이체계좌 인증 구분 변경 테스트 시에 반드시 구현해야 합니다.";
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("ChargeOrderList")]
        public async Task<Result<ResponseShopInfoChargeOrderList>> GetShopInfoChargeOrderList(RequestShopInfoChargeOrderList model)
        {
            Result<ResponseShopInfoChargeOrderList> result = new Result<ResponseShopInfoChargeOrderList>();

            try
            {
                result = await db.GetShopInfoChargeOrderList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        #endregion

        #region 가맹점 휴무

        [HttpPost("GetShopHoliday")]
        public async Task<Result<ShopHoliday>> GetShopHoliday(Request model)
        {
            Result<ShopHoliday> result = new Result<ShopHoliday>();

            try
            {
                result = await db.GetShopHolidayTerm(model);

            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;

            }

            return result;
        }
        [HttpPost("SetShopHolidayTerm")]
        public async Task<Result<ShopHoliday>> SetShopHoliday(RequestSetHoliday info)
        {
            Result<ShopHoliday> result = new Result<ShopHoliday>();

            try
            {
                result = await db.SetShopHolidayTerm(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }



        #endregion

        #region 배달팁

        /// <summary>
        /// 가맹점 공휴일 및 배달팁 조회
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("RestList")]
        public async Task<Result<ShopRestList>> ShopRestList(RequestShopRestList model)
        {
            Result<ShopRestList> result = new Result<ShopRestList>();

            try
            {
                result = await db.ShopRestList(model);

            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;

            }


            return result;
        }

        /// <summary>
        /// 가맹점 공휴일 및 배달팁  관리
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetRest")]
        public async Task<Result<dynamic>> SetShopRest(RequestSetShopRest model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetShopRest(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 가맹점 배달팁 요금설정 조회
        /// 배달팁 구분 ( 1: 거리, 3: 주문금액, 5: 요일-일월화수목금토일 )
        /// 팁요금 ( 1: 거리기준, 3: 주문금액기준 )
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("DeliveryTipAmtList")]
        public async Task<Result<ShopInfoTipAmt>> ShopInfoTipAmtList(RequestShopInfoTipAmt model)
        {
            Result<ShopInfoTipAmt> result = new Result<ShopInfoTipAmt>();
            try
            {
                result = await db.ShopInfoTipAmtList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        [HttpPost("DeliveryTipAmtListV2")]
        public async Task<Result<ShopInfoTipAmt>> ShopInfoTipAmtListV2(RequestShopInfoTipAmt model)
        {
            Result<ShopInfoTipAmt> result = new Result<ShopInfoTipAmt>();
            try
            {
                result = await db.ShopInfoTipAmtListV2(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        /// <summary>
        /// 가맹점 가맹점 배달팁 요금설정 관리
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetDeliveryTipAmt")]
        public async Task<Result<dynamic>> SetShopInfoTipAmt(RequestSetShopInfoTipAmt model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetShopInfoTipAmt(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }
        [HttpPost("SetDeliveryTipAmtV2")]
        public async Task<Result<dynamic>> SetShopInfoTipAmt_V2(RequestSetShopInfoTipAmt_V2 model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetShopInfoTipAmt_V2(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }
        [HttpPost("SetDeliveryTipAmtList")]
        public async Task<Result<dynamic>> SetShipInfoTipAmtList(RequestSetShopInfoTipAmtList model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetShopInfoTipAmtMulti(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        #endregion

        #region 고객 오더
        /// <summary>
        /// 가맹점 주문조회(현재일기준 5일이내) , 2017/01/20
        /// 가맹점 주문 (PRCS_GBN  = '3' )
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("OrderList")]
        public async Task<Result<ShopOrder>> ShopOrderList(RequestShopOrderList model)
        {
            Result<ShopOrder> result = new Result<ShopOrder>();

            try
            {
                result = await db.ShopOrderList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 주문확인 및  취소
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("OrderState")]
        public async Task<Result<dynamic>> ShopOrderState(RequestOrderState model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.ShopOrderState(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("CustOrderDetail")]
        public async Task<Result<ShopOrderDetail>> CustOrderDetail(RequestOrderState model)
        {
            Result<ShopOrderDetail> result = new Result<ShopOrderDetail>();

            try
            {
                // 주문 상세를 호출하고
                result = await db.CustOrderDetail(model);
                // 주문 메뉴를 추가 호출 해준다. 
                var menuInfo = await db.CustOrderDetailWithMenuInfo(model);
                if (menuInfo.code.Equals("00"))
                {
                    var returnData = result.data.SingleOrDefault();
                    returnData.menu_info = menuInfo.data;
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("CustOrderDefaultDetail")]
        public async Task<Result<ShopOrder>> CustOrderDefaultDetail(RequestOrderState model)
        {
            Result<ShopOrder> result = new Result<ShopOrder>();

            try
            {
                result = await db.CustOrderDefaultDetail(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        [HttpPost("CustOrderDetail_V3")]
        public async Task<Result<ShopOrderDetail>> CustOrderDetail_V3(RequestOrderState model)
        {
            Result<ShopOrderDetail> result = new Result<ShopOrderDetail>();

            try
            {
                // 주문 상세를 호출하고
                result = await db.CustOrderDetail_V3(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }



        #endregion

        #region 가맹점 메뉴

        /// <summary>
        /// 주문 업종분류코드 , 2015/01/07
        /// </summary>
        /// <returns></returns>
        [HttpGet("BizItemCode")]
        public async Task<Result<ShopBizItemCode>> BizItemCode()
        {
            Result<ShopBizItemCode> result = new Result<ShopBizItemCode>();

            try
            {
                result = await db.ShopBizItemCode();
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 업종 가맹점별 메뉴 조회  , 2015/01/13
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SMenuList")]
        public async Task<Result<ShopSMenu>> CommSMenuList(RequestSMenuList model)
        {
            Result<ShopSMenu> result = new Result<ShopSMenu>();

            try
            {
                result = await db.CommShopSMenuList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 업종 가맹점별 메뉴상세 조회  , 2015/02/12
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SMenuDetail")]
        public async Task<Result<ShopSMenu>> CommSMenuDetail(RequestSMenuDetail model)
        {
            Result<ShopSMenu> result = new Result<ShopSMenu>();

            try
            {
                result = await db.CommShopSMenuDetail(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 업종별 메뉴그룹 조회  , 2015/01/12
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SMenuGroupList")]
        public async Task<Result<ShopSMenuGroup>> CommSMenuGroupList(RequestSMenuGroupList model)
        {
            Result<ShopSMenuGroup> result = new Result<ShopSMenuGroup>();

            try
            {
                result = await db.CommShopSMenuGroupList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 업종별 메뉴옵션 그룹 조회  , 2015/02/12
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SMenuGroupDetail")]
        public async Task<Result<ShopSMenuGroup>> CommSMenuGroupDetail(RequestSMenuGroupDetail model)
        {
            Result<ShopSMenuGroup> result = new Result<ShopSMenuGroup>();

            try
            {
                result = await db.CommShopSMenuGroupDetail(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 업종별 메뉴옵션 조회  , 2015/01/13
        /// </summary>
        /// <returns></returns>
        [HttpPost("SMenuOptionList")]
        public async Task<Result<ShopSMenuOption>> CommSMenuOptionList(RequestSMenuOptionList model)
        {
            Result<ShopSMenuOption> result = new Result<ShopSMenuOption>();

            try
            {
                result = await db.CommShopSMenuOptionList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 업종별 메뉴옵션 상세조회 , 2015/02/12
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SMenuOptionDetail")]
        public async Task<Result<ShopSMenuOption>> CommSMenuOptionDetail(RequestSMenuOptionDetail model)
        {
            Result<ShopSMenuOption> result = new Result<ShopSMenuOption>();

            try
            {
                result = await db.CommShopSMenuOptionDetail(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 업종별 메뉴상호 상세 조회  , 2015/02/10
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SShopDetail")]
        public async Task<Result<SShop>> CommShopDetail(RequestComShopDetail model)
        {
            Result<SShop> result = new Result<SShop>();

            try
            {
                result = await db.CommShopDetail(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 업종별 메뉴상호 조회
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SShopList")]
        public async Task<Result<SShop>> CommShopList(RequestComShopList model)
        {
            Result<SShop> result = new Result<SShop>();

            try
            {
                result = await db.CommShopList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점별 메뉴상세  조회  , 2015/02/12
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuDetail")]
        public async Task<Result<ShopMenuDetail>> GetMenuDetail(RequestMenuDetail model)
        {
            Result<ShopMenuDetail> result = new Result<ShopMenuDetail>();

            try
            {
                result = await db.GetMenuDetail(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        /// <summary>
        /// 가맹점별 메뉴 조회  , 2015/01/15
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuList")]
        public async Task<Result<SHOP_MENU>> GetMenuList(RequestMenuList model)
        {
            Result<SHOP_MENU> result = new Result<SHOP_MENU>();

            try
            {
                result = await db.GetMenuList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        /// <summary>
        /// 가맹점별 메뉴 조회  , 2015/04/08
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuListNew")]
        public async Task<Result<SHOP_MENU_NEW>> GetMenuListNew(RequestMenuList model)
        {
            Result<SHOP_MENU_NEW> result = new Result<SHOP_MENU_NEW>();

            try
            {
                var temp = await db.GetMenuListNew(model);

                var groups = temp.data.Where(x => x.otype.Equals("G")).ToList();

                foreach (var subItem in groups)
                {
                    var items = temp.data.Where(x => x.menu_group_cd.Equals(subItem.menu_group_cd) && x.otype.Equals("M")).ToList();
                    subItem.sub_menus = items;
                }

                result.code = temp.code;
                result.msg = temp.msg;
                result.data = groups;

                return result;
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        /// <summary>
        /// 가맹점 메뉴그룹 상세조회 , 2015/02/12
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuGroupDetail")]
        public async Task<Result<ShopMenuGroup>> GetMenuGroupDetail(RequestMenuGroupDetail model)
        {
            Result<ShopMenuGroup> result = new Result<ShopMenuGroup>();

            try
            {
                result = await db.GetMenuGroupDetail(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        /// <summary>
        /// 가맹점 메뉴그룹 조회 , 2015/01/15
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuGroupList")]
        public async Task<Result<ShopMenuGroup>> GetMenuGroupList(RequestMenuGroupList model)
        {
            Result<ShopMenuGroup> result = new Result<ShopMenuGroup>();

            try
            {
                result = await db.GetMenuGroupList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 그룹상세  조회 , 2015/02/12
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuOptionGroupDetail")]
        public async Task<Result<ShopMenuOptionGroup>> GetMenuOGroupDetail(RequestMenuOptionGroupDetail model)
        {
            Result<ShopMenuOptionGroup> result = new Result<ShopMenuOptionGroup>();

            try
            {
                result = await db.GetMenuOGroupDetail(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 그룹 조회 , 2015/01/15
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuOptionGroupList")]
        public async Task<Result<ShopMenuOptionGroup>> GetMenuOGroupList(RequestMenuOptionGroupList model)
        {
            Result<ShopMenuOptionGroup> result = new Result<ShopMenuOptionGroup>();

            try
            {
                result = await db.GetMenuOGroupList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 상세 조회 , 2015/02/12
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuOptionDetail")]
        public async Task<Result<ShopMenuOption>> GetMenuOptionDetail(RequestMenuOptionDetail model)
        {
            Result<ShopMenuOption> result = new Result<ShopMenuOption>();

            try
            {
                result = await db.GetMenuOptionDetail(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 상세 조회 , 2015/01/15
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuOptionList")]
        public async Task<Result<ShopMenuOption>> GetMenuOptionList(RequestMenuOptionList model)
        {
            Result<ShopMenuOption> result = new Result<ShopMenuOption>();

            try
            {
                result = await db.GetMenuOptionList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 상세 조회 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MenuOptionListNew")]
        public async Task<Result<ShopMenuOptionList>> GetMenuOptionListNew(RequestMenuOptionList model)
        {
            Result<ShopMenuOptionList> result = new Result<ShopMenuOptionList>();

            try
            {
                result = await db.GetMenuOptionListNew(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 메뉴 상태 변경
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetMenuStatus")]
        public async Task<Result<dynamic>> SetCommMenuStatus(RequestSetCommMenuStatus model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetCommMenuStatus(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴그룹 등록
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetMenuGroup")]
        public async Task<Result<dynamic>> SetMenuGroup(RequestSetMenuGroup model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetMenuGroup(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점별 메뉴 등록
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetMenuList")]
        public async Task<Result<dynamic>> SetMenuList(RequestSetMenuList model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetMenuList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("SetMenuLists")]
        public async Task<Result<dynamic>> SetMenuLists(RequestSetMenuLists model)
        {
            Result<dynamic> result = new Result<dynamic>();

            StringBuilder sb = new StringBuilder();
            try
            {
                foreach (var menu in model.menus)
                {
                    var menuResult = await SetMenuList(menu);

                    if (menuResult.code.Equals(00))
                        throw new Exception(string.Concat("메뉴 [ ", menu.menu_name, " ] 항목을 등록 하는데 실패 했습니다.", sb.ToString()));
                    sb.Append($"{ menu.menu_name } 성공 {Environment.NewLine}");
                }
                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 그룹 등록 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetMenuOptionGroup")]
        public async Task<dynamic> SetMenuOGroup(RequestSetOptionMenuGroup model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SET_MENU_OGROUP(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 메뉴옵션 상세 등록
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetMenuOption")]
        public async Task<dynamic> SetMenuOption(RequestSetMenuOption model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetMenuOption(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 메뉴 품절 / 판매중
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetMenuSoldout")]
        public async Task<Result<ResponseMenuSoldout>> SetMenuSoldOut(RequestMenuSoldOut model)
        {
            Result<ResponseMenuSoldout> result = new Result<ResponseMenuSoldout>();

            try
            {
                result = await db.SetMenuSoldOut(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 아이템 소팅
        /// </summary>
        /// <param name="sortList"></param>
        /// <returns></returns>
        [HttpPost("SortList")]
        public async Task<CodeMsg> SortListItem(RequestSortItem sortList)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                result = await db.SortListItem(sortList);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 메뉴 옵션 품절 / 판매중
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetMenuOptSoldout")]
        public async Task<Result<ResponseMenuOptionSoldout>> SetMenuOptionSoldout(RequestMenuOptionSoldout model)
        {
            Result<ResponseMenuOptionSoldout> result = new Result<ResponseMenuOptionSoldout>();

            try
            {
                result = await db.SetMenuOptionSoldout(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 대표 매뉴 리스트 조회 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("GetMajorMenu")]
        public async Task<Result<ResponseMajorMenu>> GetMajorMenu(Request info)
        {
            Result<ResponseMajorMenu> result = new Result<ResponseMajorMenu>();
            try
            {
                result = await db.GetMajorMenu(info);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("SetMajorMenu")]
        public async Task<Result<ResponseMajorMenu>> SetMajorMenu(RequestMajorMenu model)
        {
            Result<ResponseMajorMenu> result = new Result<ResponseMajorMenu>();

            try
            {
                result = await db.SetMajorMenu(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }






        #endregion

        #region 원산지

        /// <summary>
        /// 가맹점 원산지 조회
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("GetShopOrigin")]
        public async Task<Result<ShopFoodOrigins>> GetShopOrigin(Request model)
        {
            Result<ShopFoodOrigins> result = new Result<ShopFoodOrigins>();

            try
            {
                result = await db.GetShopOrigin(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 원산지 설정/수정
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetShopOrigin")]
        public async Task<Result<dynamic>> SetShopOrigin(RequestSetShopOrigin model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetShopOrigin(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        #endregion

        #region 소개글

        [HttpPost("GetShopIntro")]
        public async Task<Result<ShopIntro>> GetShopIntro(RequestSetShopOrigin model)
        {
            Result<ShopIntro> result = new Result<ShopIntro>();

            try
            {
                result = await db.GetShopIntro(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        /// <summary>
        /// 가맹점 소개글
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetShopIntro")]
        public async Task<Result<dynamic>> SetShopIntro(RequestSetShopOrigin model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.SetShopIntro(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        #endregion

        #region 매핑

        /// <summary>
        /// 가맹점 매핑 조회
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MappList")]
        public async Task<Result<ShopMapping>> GetMapping(RequestShopMapping model)
        {
            Result<ShopMapping> result = new Result<ShopMapping>();

            try
            {
                result = await db.GetMapping(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 매핑 설정 I, U. Type 1: 주문, 3: 배달
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("MappList/Set")]
        public async Task<Result<ShopMapping>> SetMapping(RequestShopMappingUpdate model)
        {
            Result<ShopMapping> result = new Result<ShopMapping>();

            try
            {
                result = await db.SetMapping(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("apicom/List")]
        public async Task<Result<API_COMPANY_INFO>> GetApiCompanyList(RequestApiCompanyInfo model)
        {
            Result<API_COMPANY_INFO> result = new Result<API_COMPANY_INFO>();

            try
            {
                result = await db.GetApiCompanyList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("apicom/Set")]
        public async Task<Result<API_COMPANY_INFO>> SetApiCompany(RequestApiCompanyInfo model)
        {
            Result<API_COMPANY_INFO> result = new Result<API_COMPANY_INFO>();

            try
            {
                result = await db.SetApiCompany(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }


        #endregion

        #region 깃발

        [HttpPost("Flag")]
        public async Task<Result<ShopFlag>> GetFlag(Request model)
        {
            Result<ShopFlag> result = new Result<ShopFlag>();

            try
            {
                result = await db.ShopFlag(model, "Y");
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("Flag/Set")]
        public async Task<Result<dynamic>> SetFlag(ShopFlagData model)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                result = await db.ShopCreateFlag(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        #endregion

        /// <summary>
        /// 리뷰 사용/미사용
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("use_review")]
        public async Task<Result<ReviewStatus>> SetReviewGBN(RequsetSetReviewGbn model)
        {
            Result<ReviewStatus> result = new Result<ReviewStatus>();

            try
            {
                result = await db.SetReviewGbn(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 비밀번호 변경
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("change/pass")]
        public async Task<CodeMsg> ChangePassword(RequestChangePassword model)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                //if(model.password.Length < 64)
                //{
                //    throw new Exception("암호화 양식이 다릅니다");
                //}
                result = await db.ChangePassword(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 아이디 변경
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("change/id")]
        public async Task<CodeMsg> ChangeID(RequestChangeId model)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                result = await db.ChangeId(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        #region 대구로POS 연동 API

        /// <summary>
        /// 가맹점 운영 상태 변경 ( 휴점/개점 )
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("SetRunning")]
        public async Task<ResultSingle<ResponseShopRunningStatus>> SetShopRunningStatus(RequestShopRunningStatus model)
        {
            ResultSingle<ResponseShopRunningStatus> result = new ResultSingle<ResponseShopRunningStatus>();

            try
            {
                result = await db.SetShopRunningStatus(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("SetBizNo")]
        public async Task<Result<ResponseShopBizNo>> SetBizNo(RequestShopBizno model)
        {
            Result<ResponseShopBizNo> result = new Result<ResponseShopBizNo>();

            try
            {
                result = await db.SetShopBizNo(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        #endregion

        #region 상점 통계 자료

        [HttpPost("statics")]
        public async Task<Result<ResponseShopManagerList>> GetShopManagerList(RequestShopManagerList model)
        {
            Result<ResponseShopManagerList> result = new Result<ResponseShopManagerList>();

            try
            {
                result = await db.GetShopManagerList(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("sales")]
        public async Task<Result<ResponseShopSalesList>> GetShopSalesList(RequestShopSalesList model)
        {
            Result<ResponseShopSalesList> result = new Result<ResponseShopSalesList>();

            try
            {
                result = await db.GetShopSalesList(model);

            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("sales_v2")]
        public async Task<Result<ResponseShopSalesList>> GetShopSalse_v2_List(RequestShopSalesList model)
        {
            Result<ResponseShopSalesList> result = new Result<ResponseShopSalesList>();

            try
            {
                result = await db.GetShopSalse_v2_List(model);

            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("Charge_v2")]
        public async Task<Result<ResponseShopSalesList>> GetShopCharge_v2_List(RequestShopSalesList model)
        {
            Result<ResponseShopSalesList> result = new Result<ResponseShopSalesList>();

            try
            {
                result = await db.GetShopCharge_v2_List(model);

            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        #endregion

        [HttpPost("OGnOptions/Get")]
        public async Task<ResultSingle<ResponseGetOGnOptions>> GetMenuOptionGroupAndOptions(RequestGetOGnOptions model)
        {
            ResultSingle<ResponseGetOGnOptions> result = new ResultSingle<ResponseGetOGnOptions>();

            try
            {
                result = await db.GetMenuOptionGroupAndOptions(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("OGnOptions/Set")]
        public async Task<Result<ResponseGetOGnOptions>> SetMenuOptionGroupAndOptions(RequestSetOGnOptions model)
        {
            Result<ResponseGetOGnOptions> result = new Result<ResponseGetOGnOptions>();

            try
            {
                result = await db.SetMenuOptionGroupAndOptions(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }


        #region System Inout Log

        [HttpPost("inout")]
        public async Task<CodeMsg> SetSystemInout(RequestSystemInout model)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                result = await db.SetShopInOut(model);
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        #endregion
    }

}
