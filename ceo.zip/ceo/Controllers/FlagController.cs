﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Database;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Flag;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

/// <summary>
/// 서울 기획팀 요청으로 Flag 관련 기능이 배달지역 설정으로 이동.
/// 컨트롤러는 이쪽을 그대로 유지하고 있으나 View 는 배달지역 설정을 사용
/// </summary>
namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class FlagController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly ILogger<FlagController> _logger;

        public FlagController(DgShopApiService api, ILogger<FlagController> logger)
        {
            dgShop = api;
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            Request req = new Request()
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };

            var address = await dgShop.Post<ShopAddress, Request>("Address", req);
            ViewBag.shopAddress = address.data.FirstOrDefault();

            return View();
        }

        public async Task<IActionResult> List()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            Request req = new Request()
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };
            var temp = await dgShop.Post<ShopFlag, Request>("Flag", req);

            if (temp.code.Equals("00"))
            {
                List<ShopFlagModel> modelList = new List<ShopFlagModel>();
                foreach (var item in temp.data)
                {
                    ShopFlagModel model = new ShopFlagModel()
                    {
                        ADDR = item.ADDR,
                        DP_LAT = item.DP_LAT,
                        DP_LON = item.DP_LON,
                        DP_SEQ = item.DP_SEQ,
                        DP_SHOP_NAME = item.DP_SHOP_NAME,
                        DP_TELNO = item.DP_TELNO,
                        MEMO = item.MEMO,
                        ROAD_ADDR = item.ROAD_ADDR,
                        USE_GBN = item.USE_GBN
                    };
                    modelList.Add(model);
                }

                return Ok(modelList);
            }

            return NoContent();
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(ShopFlagModel viewModel)
        {
            _logger.LogInformation("Create Store Flag", viewModel);

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ShopFlagData model = new ShopFlagData()
            {
                job_gbn = "I",
                updateUserCode = info.shop_cd.ToString(),
                updateUserName = info.shop_name,
                cccode = info.cccode,
                shopCode = info.shop_cd.ToString(),
                memo = viewModel.MEMO,

                displayShopName = !string.IsNullOrEmpty(viewModel.DP_SHOP_NAME) ? viewModel.DP_SHOP_NAME : info.shop_name,
                displayShopTelno = !string.IsNullOrEmpty(viewModel.DP_TELNO) ? viewModel.DP_TELNO : info.shop_telno,
                flagSequence = viewModel.DP_SEQ,
                lat = Convert.ToDouble(viewModel.DP_LAT),
                lon = Convert.ToDouble(viewModel.DP_LON),
                road = viewModel.ROAD_ADDR,
                addr = viewModel.ADDR,
                //type = viewModel.type,
                useGbn = viewModel.USE_GBN.Equals("Y") ? true : false
            };

            var temp = await dgShop.Post<dynamic, ShopFlagData>("Flag/Set", model);

            if (temp.code.Equals("00"))
            {
                return Ok(temp);
            }

            return Ok(temp);
        }
        public async Task<IActionResult> Edit(string id)
        {
            await Task.Delay(0);
            //string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            //ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            //info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //Request req = new Request()
            //{
            //    job_gbn = "1",
            //    cccode = info.cccode,
            //    shop_cd = info.shop_cd
            //};
            //var temp = await dgShop.Post<ShopFlag, Request>("Flag", req);

            //if (temp.code.Equals("00"))
            //{
            //    var item = temp.data.Find(x => x.DP_SEQ.Equals(id));

            //    ShopFlagModel model = new ShopFlagModel()
            //    {
            //        ADDR = item.ADDR,
            //        DP_LAT = item.DP_LAT,
            //        DP_LON = item.DP_LON,
            //        DP_SEQ = item.DP_SEQ,
            //        DP_SHOP_NAME = item.DP_SHOP_NAME,
            //        DP_TELNO = item.DP_TELNO,
            //        MEMO = item.MEMO,
            //        ROAD_ADDR = item.ROAD_ADDR,
            //        USE_GBN = item.USE_GBN
            //    };


            //}

            return ViewComponent("FlagEdit", new { id = id });
        }

        [HttpPost]
        public async Task<IActionResult> Edit(ShopFlagModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ShopFlagData data = new ShopFlagData()
            {
                job_gbn = "U",
                updateUserCode = info.shop_cd.ToString(),
                updateUserName = info.shop_name,
                cccode = info.cccode,
                shopCode = info.shop_cd.ToString(),
                memo = model.MEMO,

                displayShopName = !string.IsNullOrEmpty(model.DP_SHOP_NAME) ? model.DP_SHOP_NAME : info.shop_name,
                displayShopTelno = !string.IsNullOrEmpty(model.DP_TELNO) ? model.DP_TELNO : info.shop_telno,
                flagSequence = model.DP_SEQ,
                lat = Convert.ToDouble(model.DP_LAT),
                lon = Convert.ToDouble(model.DP_LON),
                road = model.ROAD_ADDR,
                addr = model.ADDR,
                useGbn = model.USE_GBN.Equals("Y") ? true : false
            };

            var temp = await dgShop.Post<dynamic, ShopFlagData>("Flag/Set", data);

            if (temp.code.Equals("00"))
            {
                return RedirectToAction("Index");
            }

            ModelState.AddModelError("", temp.msg);
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Delete(ShopFlagModel model)
        {
            _logger.LogInformation("Edit Store Flag", model);

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(model.DP_LON) || string.IsNullOrEmpty(model.DP_LAT))
            {
                return Ok(new
                {
                    code = "99",
                    message = "좌표 정보가 없습니다"
                });
            }

            try
            {
                ShopFlagData data = new ShopFlagData()
                {
                    job_gbn = "D",
                    updateUserCode = info.shop_cd.ToString(),
                    updateUserName = info.shop_name,
                    cccode = info.cccode,
                    shopCode = info.shop_cd.ToString(),
                    memo = model.MEMO,

                    displayShopName = !string.IsNullOrEmpty(model.DP_SHOP_NAME) ? model.DP_SHOP_NAME : info.shop_name,
                    displayShopTelno = !string.IsNullOrEmpty(model.DP_TELNO) ? model.DP_TELNO : "",
                    flagSequence = model.DP_SEQ,
                    lat = Convert.ToDouble(model.DP_LAT),
                    lon = Convert.ToDouble(model.DP_LON),
                    road = model.ROAD_ADDR,
                    addr = model.ADDR,
                    useGbn = false
                };

                var temp = await dgShop.Post<dynamic, ShopFlagData>("Flag/Set", data);

                if (temp.code.Equals("00"))
                {
                    //return RedirectToAction("Index");
                    _logger.LogInformation("Delete 성공");
                    return Ok(temp);
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.ToString());

                ModelState.AddModelError("", e.Message);
                return Ok(new
                {
                    code= "99",
                    message = e.Message
                });
            }
            return Ok(new
            {
                code = "99",
                message = "알 수 없는 오류입니다."
            });
        }

    }
}
