﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.ApiModels.Shop.Response;
using PosWebApp.Common;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Models.Store.Image;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.StoreImage;
using PosWebApp.ViewModels.ShopAlert;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ShopAlert : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly ShopStoreImageService admImage;
        public ShopAlert(DgShopApiService dgShop, ShopStoreImageService imgae)
        {
            this.dgShop = dgShop;
            this.admImage = imgae;
        }

        public async Task<IActionResult> Index(ShopAlertViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            Result<ResponseShopIntroList> result = new Result<ResponseShopIntroList>();
            /*
            * 알림
            */
            if (model.type == "1" || string.IsNullOrEmpty(model.type))
            {
                ViewBag.type = "1";
                return View();
            }
            /*
             * 리뷰
             */
            else if (model.type == "2")
            {

                ViewBag.type = "2";
                return View();
            }
            else
            {
                return View();
            }
        }
        public async Task<IActionResult> DetailList(string type)
        {
            return ViewComponent("ShopAlertList", new
            {
                type = type
            });
        }
        public async Task<IActionResult> AddAlert(ShopAlertViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var result = await dgShop.Post<ResponseShopIntroList, RequestShopIntroList>("/api/ShopManagement/GetShopIntroList", new RequestShopIntroList
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                IntroGbn = (model.type == "1" ? "I" : "R")
            });

            if(result.data.Count() == 0)
            {
                model.useYn = "Y";
            }
            else
            {
                model.useYn = "N";
            }

           
            model.status = "I";
            return PartialView("PartialAlert", model);
        }

        public async Task<IActionResult> DetailAdd(ShopAlertViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(model.seq))
            {
                return Ok(new
                {
                    code = 99,
                    Msg = "조회 실패하였습니다."
                });
            }

            var req = await dgShop.Post<ResponseShopIntroList, RequestShopIntroList>("/api/ShopManagement/GetShopIntroDetail", new RequestShopIntroList
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                IntroCd = model.seq
            });

            if (req.code.Equals("00"))
            {
                var single = req.data.SingleOrDefault();
                ShopAlertViewModel result = new ShopAlertViewModel()
                {
                    seq = model.seq,
                    type = model.type,
                    Contents = single.intro_contents,
                    status = "U",
                    useYn = single.use_gbn,
                    img1 = string.IsNullOrEmpty(single.intro_image) ? null : single.intro_image,
                    img2 = string.IsNullOrEmpty(single.intro_image2) ? null : single.intro_image2,
                };

                return PartialView("PartialAlert", result);
            }
            ModelState.AddModelError("", "조회 실패");
            return PartialView("PartialAlert", model);
        }
        [HttpPost]
        public async Task<IActionResult> AlertUpdate(ShopAlertViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(model.seq))
            {
                
                //입력임
                var req = await dgShop.Post<dynamic, RequestShopIntro>("/api/ShopManagement/SetShopIntro", new RequestShopIntro
                {
                    cccode = info.cccode,
                    shop_cd = info.shop_cd,
                    intro_cd = model.seq,
                    job_gbn = model.status,
                    use_gbn = model.useYn,
                    intro_contents = model.Contents,
                    intro_gbn = model.type == "1" ? "I" : "R",
                    mName = info.login_name,
                    mcode = info.login_code
                });


                string instailCode = null;
                if (req.code.Equals("00"))
                {
                    instailCode = req.msg;
                }
                else
                {
                    ModelState.AddModelError("", "저장중 에러가 발생했습니다.");
                    return PartialView("PartialAlert", model);
                }
                RequestStoreImageV2 codeRequest = new RequestStoreImageV2();

                if (model.iFile1 != null)
                {
                    codeRequest.div = "I";
                    codeRequest.intro_cd = instailCode;
                    codeRequest.sort = "1";
                    codeRequest.ucode = info.login_code.ToString();
                    codeRequest.uname = info.login_name;
                    var image = await admImage.Put<dynamic>("Intro/setShopInfoImage", codeRequest, model.iFile1);
                    if (!image.code.Equals("00"))
                    {
                        ModelState.AddModelError("", "1번 이미지 저장중 오류가 발생했습니다.");
                    }
                }

                if (model.iFile2 != null)
                {
                    codeRequest.div = "I";
                    codeRequest.intro_cd = instailCode;
                    codeRequest.sort = "2";
                    codeRequest.ucode = info.login_code.ToString();
                    codeRequest.uname = info.login_name;
                    var image = await admImage.Put<dynamic>("Intro/setShopInfoImage", codeRequest, model.iFile2);
                    if (!image.code.Equals("00"))
                    {
                        ModelState.AddModelError("", "2번 이미지 저장중 오류가 발생했습니다.");
                    }
                }

               
            }
            else
            {
                //수정
                var req = await dgShop.Post<dynamic, RequestShopIntro>("/api/ShopManagement/SetShopIntro", new RequestShopIntro
                {
                    cccode = info.cccode,
                    shop_cd = info.shop_cd,
                    intro_cd = model.seq,
                    job_gbn = model.status,
                    use_gbn = model.useYn,
                    intro_contents = model.Contents,
                    intro_gbn = model.type == "1" ? "I" : "R",
                    mName = info.login_name,
                    mcode = info.login_code
                });


                // admin Image Upload

                RequestStoreImageV2 codeRequest = new RequestStoreImageV2();
                if (model.iFile1 != null)
                {
                    codeRequest.div = "I";
                    codeRequest.intro_cd = model.seq;
                    codeRequest.sort = "1";
                    codeRequest.ucode = info.login_code.ToString();
                    codeRequest.uname = info.login_name;
                    var image = await admImage.Put<dynamic>("Intro/setShopInfoImage", codeRequest, model.iFile1);

                    if (!image.code.Equals("00"))
                    {
                        ModelState.AddModelError("", "1번 이미지 저장중 오류가 발생했습니다.");
                    }
                }

                if (model.iFile2 != null)
                {
                    codeRequest.div = "I";
                    codeRequest.intro_cd = model.seq;
                    codeRequest.sort = "2";
                    codeRequest.ucode = info.login_code.ToString();
                    codeRequest.uname = info.login_name;
                    var image = await admImage.Put<dynamic>("Intro/setShopInfoImage", codeRequest, model.iFile2);

                    if (!image.code.Equals("00"))
                    {
                        ModelState.AddModelError("", "2번 이미지 저장중 오류가 발생했습니다.");
                    }
                }

                if (req.code.Equals("00"))
                {
                    return PartialView("PartialAlert", model);
                }
                else
                {
                    ModelState.AddModelError("", "저장중 에러가 발생했습니다.");
                    return PartialView("PartialAlert", model);
                }
            }

            return PartialView("PartialAlert", model);
        }

        public async Task<IActionResult> DeletedAlert(ShopAlertViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            model.status = "D";


            if (string.IsNullOrEmpty(model.seq))
            {
                return Ok(new
                {
                    code = 99,
                    msg = "새로고침 후 이용부탁드립니다."
                });
            }
            else
            {
                var req = await dgShop.Post<dynamic, RequestShopIntro>("/api/ShopManagement/SetShopIntro", new RequestShopIntro
                {
                    cccode = info.cccode,
                    shop_cd = info.shop_cd,
                    intro_cd = model.seq,
                    job_gbn = model.status,
                    use_gbn = model.useYn,
                    intro_contents = model.Contents,
                    intro_gbn = model.type == "1" ? "I" : "R",
                    mName = info.login_name,
                    mcode = info.login_code
                });

                if (req.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        msg = "성공"
                    });
                }
                return Ok(new
                {
                    code = "99",
                    msg = "새로고침 후 이용부탁드립니다."
                });
            }
        }
        public async Task<IActionResult> OnAlert(ShopAlertViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            model.status = "U";

            if(string.IsNullOrEmpty(model.seq))
            {
                return Ok(new
                {
                    code = 99,
                    msg = "새로고침 후 이용부탁드립니다."
                });
            }
            else
            {
                //조회후 이용
                var alertInfo = await dgShop.Post<ResponseShopIntroList, RequestShopIntroList>("/api/ShopManagement/GetShopIntroDetail", new RequestShopIntroList
                {
                    cccode = info.cccode,
                    shop_cd = info.shop_cd,
                    IntroCd = model.seq
                });

                var shopAlertInfo = new ResponseShopIntroList();
                if (alertInfo.code.Equals("00"))
                {
                    shopAlertInfo = alertInfo.data.SingleOrDefault();
                }
                else
                {
                    return Ok(new
                    {
                        code = "99",
                        msg = "새로고침 후 이용부탁드립니다."
                    });
                }

                //수정
                var req = await dgShop.Post<dynamic, RequestShopIntro>("/api/ShopManagement/SetShopIntro", new RequestShopIntro
                {
                    cccode = info.cccode,
                    shop_cd = info.shop_cd,
                    intro_cd = model.seq,
                    job_gbn = model.status,
                    use_gbn = "Y",
                    intro_contents = shopAlertInfo.intro_contents,
                    intro_gbn = shopAlertInfo.intro_gbn,
                    mName = info.login_name,
                    mcode = info.login_code
                });

                if (req.code.Equals("00"))
                {
                    return Ok(new
                    {
                        code = "00",
                        msg = "성공"
                    });
                }
                else
                {
                    return Ok(new
                    {
                        code = "99",
                        msg = "새로고침 후 이용부탁드립니다."
                    });
                }
            }
        }

        public async Task<IActionResult> ImageDelete(ShopAlertViewModel model)
        {

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if (string.IsNullOrEmpty(model.seq))
            {
                return Ok(new
                {
                    code = "99",
                    msg = "조회할 데이터가 없습니다."
                });
            }
            else
            {
                //type ==  sort number chagne
                var msg = "성공";
                RequestStoreImageV2 codeRequest = new RequestStoreImageV2();

                if (model.type == "1")
                {
                    codeRequest.div = "D";
                    codeRequest.intro_cd = model.seq;
                    codeRequest.sort = model.type;
                    codeRequest.ucode = info.login_code.ToString();
                    codeRequest.uname = info.login_name;
                    var image = await admImage.Put<dynamic>("Intro/setShopInfoImage", codeRequest, model.iFile1);
                    if (!image.code.Equals("00"))
                    {
                        msg = "1번 이미지 저장중 오류가 발생했습니다.";
                        return Ok(new
                        {
                            code = "99",
                            msg = msg
                        });
                    }
                }

                if (model.type == "2")
                {
                    codeRequest.div = "D";
                    codeRequest.intro_cd = model.seq;
                    codeRequest.sort = model.type;
                    codeRequest.ucode = info.login_code.ToString();
                    codeRequest.uname = info.login_name;
                    var image = await admImage.Put<dynamic>("Intro/setShopInfoImage", codeRequest, model.iFile2);
                    if (!image.code.Equals("00"))
                    {
                        msg = "2번 이미지 저장중 오류가 발생했습니다.";
                        return Ok(new
                        {
                            code = "99",
                            msg = msg
                        });
                    }
                }


                return Ok(new
                {
                    code = "00",
                    msg = msg
                });
            }
        }
    }
}
