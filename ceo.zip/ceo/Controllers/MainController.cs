﻿using DocumentFormat.OpenXml.Office.CustomUI;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.ApiModels.Shop.Response;
using PosWebApp.Common;
using PosWebApp.Models.Pos;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.Reservation.Apply.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.Reservation;
using PosWebApp.ViewModels.Main;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class MainController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly ReservationService_T reservationService;
        private readonly string inspection;
        private readonly string ChildrenFlag;
        private readonly string shopMallFlag;
#if JWT_TEST_CODE
        private readonly ILoginService _loginService;
#endif
        public MainController(DgShopApiService api, IConfiguration configuration, ReservationService_T reservationService
#if JWT_TEST_CODE
    ,ILoginService loginService
#endif
            )
        {
            dgShop = api;
            this.reservationService = reservationService;
            inspection = configuration.GetValue<string>("inspection:flag");
            ChildrenFlag = configuration.GetValue<string>("inspection:ChildrenFlag");
            shopMallFlag = configuration.GetValue<string>("inspection:shopMallFlag");
#if JWT_TEST_CODE
            _loginService = loginService;
#endif
        }
        public async Task<IActionResult> Index()
        {

            if (inspection.Equals("Y"))
            {
                ViewBag.inspection = "Y";
            }
            else
            {
                ViewBag.inspection = "N";
            }

            if (ChildrenFlag.Equals("Y"))
            {
                ViewBag.ChildrenFlag = "Y";
            }
            else
            {
                ViewBag.ChildrenFlag = "N";
            }

            if (shopMallFlag.Equals("Y"))
            {
                ViewBag.shopMallFlag = "Y";
            }
            else
            {
                ViewBag.shopMallFlag = "N";
            }

#if DEBUG
            ViewBag.MainReview = false;
#else
            ViewBag.MainReview = true;
#endif
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //2022.07. 28
            var onlyReservation = info.shop_type;
            if(onlyReservation == "9")
            {
                return RedirectToAction("Index", "Reservation");
            }

            //2021.07.07 로그
            var req = await dgShop.Post<CodeMsg, RequestSystemInout>("inout", new RequestSystemInout
            {
                cccode = info.cccode,
                inout_gbn = "I",
                job_gbn = "",
                mac_address = "",
                user_id = info.login_name,
                pc_name = "테스트중",
                mcode = info.mcode,
                shop_cd = info.shop_cd,
                pc_ip = HttpContext.Connection.RemoteIpAddress.ToString(),
                pgm_name = "사장님사이트"
            });



            var shopAccountInfo = await dgShop.Post<ResponseShopAccountInfo, Request>("/api/ShopManagement/AccInfo", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });


            var currentDetailResult = await dgShop.Post<ResponseShopSalesList, RequestShopSalesList>("sales", new RequestShopSalesList
            {
                cccode = info.cccode,
                from_date = DateTime.Now.AddDays(-7).ToString("yyyyMMdd"),
                to_date = DateTime.Now.ToString("yyyyMMdd"),
                job_gbn = ((int)SalesType.CURRENT_DETAIL).ToString(),
                shop_cd = info.shop_cd,
                pack_order_yn = "%"
            });

            var result = new List<ChartWeekly>();
            var weekly = currentDetailResult.data;

            var days = weekly.GroupBy(x => x.order_date).ToDictionary(d => d.Key, d => d.ToList());
            foreach (var item in days.Keys)
            {
                ChartWeekly weely = new ChartWeekly();
                result.Add(weely);
                weely.order_date = item;
                weely.data = new salseCount();
                weely.SalseCount = new List<salseCount>();
                foreach (var data in days[item])
                {
                    weely.data.amount += Convert.ToInt32(data.amount);
                    weely.data.cancel_amount += Convert.ToInt32(data.cancel_amount);
                    weely.data.cancel_count += Convert.ToInt32(data.cancel_count);
                    weely.data.discount_amount += Convert.ToInt32(data.discount_amount);
                    weely.data.ok_amount += Convert.ToInt32(data.ok_amount);
                    weely.data.ok_count += Convert.ToInt32(data.ok_count);
                    weely.data.total_amount += Convert.ToInt32(data.total_amount);
                    weely.data.total_count += Convert.ToInt32(data.total_count);

                    salseCount statics = new salseCount()
                    {
                        amount = Convert.ToInt32(data.amount),
                        cancel_amount = Convert.ToInt32(data.cancel_amount),
                        cancel_count = Convert.ToInt32(data.cancel_count),
                        discount_amount = Convert.ToInt32(data.discount_amount),
                        ok_amount = Convert.ToInt32(data.ok_amount),
                        ok_count = Convert.ToInt32(data.ok_count),
                        total_amount = Convert.ToInt32(data.total_amount),
                        total_count = Convert.ToInt32(data.total_count)
                    };

                    weely.SalseCount.Add(statics);
                }
            }
            var operate = dgShop.Post<ShopOperateInfo_V2, Request>("Operate", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
            });

            var mainResult = new MainInfoViewModel();

            mainResult.name = info.shop_name;
            mainResult.real_remain_amt = shopAccountInfo.data.SingleOrDefault().remain_amt;
            if (shopAccountInfo.data.SingleOrDefault().multiShopYn.Equals("Y"))
            {
                mainResult.multiShopCd = info.multMasterCd;
                mainResult.multiShopYn = info.multshopYn;



                var multiShopList = await dgShop.Post<ResponseMultiShopList, RequestMulitShopList>("/api/ShopManagement/GetMulitShopSelectBox", new RequestMulitShopList
                {
                    shop_cd = info.shop_cd,
                    multiShopCd = info.multMasterCd
                });

                if (multiShopList.code.Equals("00"))
                {
                    ViewBag.multiList = new SelectList(multiShopList.data, "shopCd", "shopName", info.shop_cd);
                }
            }
            else
            {
                mainResult.multiShopCd = null;
                mainResult.multiShopYn = "N";
            }
           
            mainResult.absent_yn = operate.Result.data.SingleOrDefault().ABSENT_YN;
            return View(mainResult);
        }
        [HttpPost]
        public async Task<IActionResult> ChartWeekly()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var currentDetailResult = await dgShop.Post<ResponseShopSalesList, RequestShopSalesList>("sales", new RequestShopSalesList
            {
                cccode = info.cccode,
                from_date = DateTime.Now.AddDays(-7).ToString("yyyyMMdd"),
                to_date = DateTime.Now.ToString("yyyyMMdd"),
                job_gbn = ((int)SalesType.CURRENT_DETAIL).ToString(),
                shop_cd = info.shop_cd,
                pack_order_yn = "%"
            });


            var result = new List<ChartWeekly>();
            var weekly = currentDetailResult.data;

            var days = weekly.GroupBy(x => x.order_date).ToDictionary(d => d.Key, d => d.ToList());
            foreach (var item in days.Keys)
            {
                ChartWeekly weely = new ChartWeekly();
                result.Add(weely);
                weely.order_date = item.Substring(4, item.Length - 4).Insert(2, "-"); // 20210724 0724  07-24
                weely.data = new salseCount();
                weely.SalseCount = new List<salseCount>();
                foreach (var data in days[item])
                {
                    weely.data.amount += Convert.ToInt32(data.amount);
                    weely.data.cancel_amount += Convert.ToInt32(data.cancel_amount);
                    weely.data.cancel_count += Convert.ToInt32(data.cancel_count);
                    weely.data.discount_amount += Convert.ToInt32(data.discount_amount);
                    weely.data.ok_amount += Convert.ToInt32(data.ok_amount);
                    weely.data.ok_count += Convert.ToInt32(data.ok_count);
                    weely.data.total_amount += Convert.ToInt32(data.total_amount);
                    weely.data.total_count += Convert.ToInt32(data.total_count);

                    salseCount statics = new salseCount()
                    {
                        amount = Convert.ToInt32(data.amount),
                        cancel_amount = Convert.ToInt32(data.cancel_amount),
                        cancel_count = Convert.ToInt32(data.cancel_count),
                        discount_amount = Convert.ToInt32(data.discount_amount),
                        ok_amount = Convert.ToInt32(data.ok_amount),
                        ok_count = Convert.ToInt32(data.ok_count),
                        total_amount = Convert.ToInt32(data.total_amount),
                        total_count = Convert.ToInt32(data.total_count)
                    };

                    weely.SalseCount.Add(statics);
                }
            }


            return Json(result);

        }

        public IActionResult Notices()
        {
            return ViewComponent("InspectionNotice");
        }

        public IActionResult Children()
        {
            return ViewComponent("ChildrenSchoollunch");
        }
        public IActionResult NoticeDetail(string seq)
        {
            return ViewComponent("NoticeDetail", new
            {
                seq = seq
            });
        }


        [HttpPost]
        public async Task<IActionResult> ChildrenApplication(string confirm)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var childrenYn = await dgShop.Post<dynamic, RequestChildren>("/api/shopManagement/SetChildrenSchoolLunch", new  RequestChildren
            {
                job_gbn = "",
                shop_cd = info.shop_cd,
                childrenYn = confirm,
                mcode = info.mcode
            });

            if (childrenYn.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    msg = "성공"
                });
            }

            return Ok(new
            {
                code = childrenYn.code,
                msg = childrenYn.msg
            });
        }


        ///<summary>
        /// MultiShop selectBox selected
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> MoveShop(string code)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(code))
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "조회 실패"
                });
            }
            try
            {
                var IsMultiYn = await dgShop.Post<dynamic, RequestMultiShopCheck>("/api/shopManagement/SetMultiShopCheck", new RequestMultiShopCheck
                {
                    shop_cd = info.shop_cd,
                    mvShopCd = code
                });


                if (IsMultiYn.code.Equals("00"))
                {
                    // 멀티샵 정보리스트
                    var multiShopList = await dgShop.Post<ResponseMultiShopList, RequestMulitShopList>("/api/ShopManagement/GetMulitShopSelectBox", new RequestMulitShopList
                    {
                        shop_cd = info.shop_cd,
                        multiShopCd = info.multMasterCd,
                        passcheck = true
                    });

                    if (multiShopList.code.Equals("00"))
                    {
                        var multiListId = multiShopList.data.Where(x => x.shopCd.Equals(code)).ToList();

                        if (multiListId.Count() > 0)
                        {
                            var IsSHA256PASS = Utils.p_Sha256(multiListId[0].shopPass);


                            //세션 변경
                            var shopInfo = await dgShop.Post<ShopSessionDefaultInfo, RequestLoginInfo>("/api/ShopManagement/GetLogin", new RequestLoginInfo
                            {
                                job_gbn = "4",
                                shop_cd = Convert.ToInt32(code),
                                id = multiListId.First().shopId.ToString(),
                                password = IsSHA256PASS,
                                keys = "dlstjdepdlxj!23212"
                            });

                            var myShop = shopInfo.data.SingleOrDefault<ShopSessionDefaultInfo>(x => x.use_gbn.Equals("Y"));


                            var reser = await reservationService.Get<ResponseReservationApply>("apply?shopCode=" + myShop.shop_cd);

                            if (!reser.code.Equals("00"))
                            {
                                ModelState.AddModelError(string.Empty, "대구로 사용 미승인 상태입니다.");
                                return Ok(new
                                {
                                    code = "99",
                                    Msg = "대구로 사용 미승인 상태입니다."
                                });
                            }

                            //2023.03.16 멀티샵 infomation
                            var mulitShop = await dgShop.Post<ResponseShopAccountInfo, Request>("/api/ShopManagement/AccInfo", new Models.RequestModel.Request
                            {
                                cccode = myShop.cccode,
                                shop_cd = myShop.shop_cd
                            });

                            if (mulitShop.code.Equals("00"))
                            {
                                var mulitSingle = mulitShop.data.SingleOrDefault();

                                myShop.multMasterCd = mulitSingle.multiShopCd;
                                myShop.multshopYn = mulitSingle.multiShopYn;
                                myShop.representativeYn = mulitSingle.representativeYn;
                            }

                            myShop.login_code = myShop.shop_cd;
                            myShop.login_name = multiListId[0].shopId;
                            myShop.u_code = "S";
                            myShop.reservationYN = reser.data.SingleOrDefault().status;


                            var sessionString2 = JsonConvert.SerializeObject(myShop);
                            HttpContext.Session.SetString("shopDefaultInfo", sessionString2);
                        }
                    }
                }
            }
            catch(Exception e)
            {
                return Ok(new
                {
                    code = "99",
                    Msg = e.Message.ToString()
                });
            }


            return Ok(new
            {
                code = "00",
                Msg = "성공"
            });
        }
    }
}
