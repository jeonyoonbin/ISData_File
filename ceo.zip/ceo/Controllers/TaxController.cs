﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.ChangeRequest.Request;
using PosWebApp.Models.Tax.Request;
using PosWebApp.Models.Tax.Response;
using PosWebApp.Settings;

namespace PosWebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaxController : ControllerBase
    {
        public IOptions<DbStrings> DbString { get; }

        public TaxController(IOptions<DbStrings> dbString)
        {
            DbString = dbString;
        }

        #region 부가세 신고 자료 조회
        [HttpPost("GetTaxList")]
        public async Task<Result<ResponseTax>> GetTaxList(RequestTax info)
        {
            Result<ResponseTax> result = new Result<ResponseTax>();
            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.IsDaegu))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        CommandText = "PKG_IS_WEB_SHOP_V3.GET_TAX_LIST",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd.ToString();
                        cmd.Parameters.Add(new OracleParameter("in_meet_yn", OracleDbType.Varchar2)).Value = info.meetYn;
                        cmd.Parameters.Add(new OracleParameter("in_fr_date", OracleDbType.Varchar2)).Value = info.from;
                        cmd.Parameters.Add(new OracleParameter("in_to_date ", OracleDbType.Varchar2)).Value = info.to;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseTax> modelList = new List<ResponseTax>();
                                while (await reader.ReadAsync())
                                {
                                    modelList.Add(new ResponseTax((TaxType)Convert.ToInt32(info.job_gbn), reader));
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;

        }
        #endregion

        #region 부가세 신고 자료 요청
        #endregion
    }
}
