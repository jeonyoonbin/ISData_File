﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using PosWebApp.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    /// <summary>
    /// 입점 사이트에서 사용 되는 이미지 등록 절차.
    /// 메뉴 코드가 없으므로 메뉴에 적용할 수는 없다.
    /// 
    /// </summary>
    public class InchanController : Controller
    {
        private string path = @"C:\Files";
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost("PostFiles")]
        public async Task<IActionResult> PostFiles(List<IFormFile> files, string ccCode, string shop_cd, string kind)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                foreach (var formFile in files)
                {
                    if (formFile.Length > 0)
                    {
                        string extention = Path.GetExtension(formFile.FileName);

                        //CodeMsg result = await SetShopFileAsync(shop_cd, kind, extention);


                        var folerPath = Path.Combine(path, ccCode, shop_cd);

                        if(!Directory.Exists(folerPath))
                        {
                            Directory.CreateDirectory(folerPath);
                        }

                        //var filePath = Path.Combine(folerPath, result.msg);

                        //using var stream = System.IO.File.Create(filePath);

                        //await formFile.CopyToAsync(stream);
                    }
                }
                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "오류";
                Utils.SaveError("/admin/Shop : PostFiles", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        //private async Task<CodeMsg> SetShopFileAsync(string shop_cd, string kind, string extention)
        //{

        //    // 등록된 파일명이 있다면 정보를 가져와서 삭제한다.
        //    FileName filename = await GetFileName(shop_cd, kind);

        //    if (filename.fileName.Length > 0)
        //    {
        //        await DeleteFile(shop_cd, kind, filename.fileName);
        //    }

        //    CodeMsg result = new CodeMsg();

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
        //    OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_SHOP.SET_SHOP_FILE",
        //    };

        //    cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
        //    cmd.Parameters.Add("in_kind", OracleDbType.Varchar2, 2).Value = kind;
        //    cmd.Parameters.Add("in_extention", OracleDbType.Varchar2, 10).Value = extention;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();
        //        await cmd.ExecuteNonQueryAsync();

        //        result.code = cmd.Parameters["out_code"].Value.ToString();
        //        result.msg = cmd.Parameters["out_msg"].Value.ToString();

        //        await conn.CloseAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        Utils.SaveError("/admin/Shop : SetShopFile", ex.Message);
        //    }

        //    return result;
        //}

        //private async Task<FileName> GetFileName(string shop_cd, string kind)
        //{
        //    FileName filename = new FileName();

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
        //    OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_SHOP.GET_SHOP_FILE",
        //    };

        //    cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
        //    cmd.Parameters.Add("in_kind", OracleDbType.Varchar2, 2).Value = kind;
        //    cmd.Parameters.Add("out_file_name", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();
        //        await cmd.ExecuteNonQueryAsync();

        //        filename.fileName = cmd.Parameters["out_file_name"].Value.ToString();
        //        filename.code = cmd.Parameters["out_code"].Value.ToString();
        //        filename.msg = cmd.Parameters["out_msg"].Value.ToString();

        //        await conn.CloseAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        Utils.SaveError("/admin/Shop/getFileName : SetShopFile", ex.Message);
        //    }

        //    return filename;
        //}

        //[HttpGet("GetFileName")]
        //public async Task<IActionResult> Get(string shop_cd, string kind)
        //{
        //    FileName filename = await GetFileName(shop_cd, kind);

        //    return Ok(new { code = filename.code, msg = filename.msg, fileName = filename.fileName });
        //}

        //[HttpDelete]
        //public async Task<IActionResult> DeleteFile(string shop_cd, string kind, string file_name)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_SHOP.DELETE_SHOP_FILE",
        //    };

        //    cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 50).Value = shop_cd;
        //    cmd.Parameters.Add("in_kind", OracleDbType.Varchar2, 50).Value = kind;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();

        //        var rd = await cmd.ExecuteReaderAsync();

        //        Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        await rd.CloseAsync();
        //        await conn.CloseAsync();

        //        if (Rcode.Equals("00"))
        //        {
        //            System.IO.File.Delete(path + file_name);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Utils.SaveError("/admin/Shop/DeleteFile : Post", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}
    }
}
