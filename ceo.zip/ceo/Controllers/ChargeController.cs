﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Charge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class ChargeController : Controller
    {
        private readonly DgShopApiService dgShop;

        public ChargeController(DgShopApiService api)
        {
            dgShop = api;
        }
        public IActionResult Index(ChargeListViewModel model = null)
        {
            SelectList inOutSelectList = new SelectList(getIO(), "Value", "Text", "%");
            ViewBag.io = inOutSelectList;
            
            ViewBag.options = model.options;

            SelectList chargeSelectList = new SelectList(getChargeItem(), "Value", "Text", "%");
            ViewBag.charge = chargeSelectList;

            if(model== null)
            {
                return View(new ChargeListViewModel());
            }

            return View(model);
        }
        public async Task<IActionResult> Calculate(RequestShopSalesList model = null)
        {
            if (model.from_date == null)
            {
                model.from_date = DateTime.Now.ToString("yyyy-MM-dd");
                model.to_date = DateTime.Now.ToString("yyyy-MM-dd");
                model.options = "0";
            }
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var shopAccountInfo = await dgShop.Post<ResponseShopAccountInfo, Request>("/api/ShopManagement/AccInfo", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });
            var accountInfo = shopAccountInfo.data.SingleOrDefault();

            SelectList type = new SelectList(getType(), "Value", "Text", "%");
            ViewBag.Type = type;

            SelectList packOrderYN = new SelectList(getPackOrderYN(), "Value", "Text", "%");
            ViewBag.packOrderYN = packOrderYN;

            SelectList memo = new SelectList(getMemo(), "Value", "Text", "%");
            ViewBag.memo = memo;

            ViewBag.Amt = Utils.NumberFormat(accountInfo.remain_amt);

            return View(model);
        }
        #region 적립금 내역(쇼핑몰)
        public async Task<IActionResult> ShopMall(RequestShopSalesList model = null)
        {
            if(model.from_date == null)
            {
                model.from_date = DateTime.Now.ToString("yyyy-MM-dd");
                model.to_date = DateTime.Now.ToString("yyyy-MM-dd");
                model.options = "0";
            }
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var shopAccountInfo = await dgShop.Post<ResponseShopAccountInfo, Request>("/api/ShopManagement/AccInfo", new Request
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            var accountInfo = shopAccountInfo.data.SingleOrDefault();
            ViewBag.Amt = Utils.NumberFormat(accountInfo.remain_amt);

            return View(model);

        }
        public IActionResult shopMallFilter(RequestShopSalesList model)
        {
            return ViewComponent("ChargeShopMallList", new
            {
                model = model
            });
        }
        #endregion


        public IActionResult CalculateFilter(RequestShopSalesList model, int? pageNumber)
        {
            return ViewComponent("ChargeV2List", new
            {
                model = model,
                pageNumber = pageNumber
            });
        }


        private List<SelectListItem> getType()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "만나서결제(현금)",
                Value = "1"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "만나서결제(카드)",
                Value = "5"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "앱결제",
                Value = "3"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "행복페이",
                Value = "7"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "출금 계좌이체",
                Value = "10"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "사입",
                Value = "11"
            });
            return temp;
        }
        private List<SelectListItem> getPackOrderYN()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "배달",
                Value = "N"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "포장",
                Value = "Y"
            });

            return temp;
        }
        private List<SelectListItem> getMemo()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "운영사 취소",
                Value = "N"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "완료",
                Value = "Y"
            });

            return temp;
        }
        private List<SelectListItem> getIO()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "입금",
                Value = "I"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "출금",
                Value = "O"
            });
            return temp;
        }
        private List<SelectListItem> getChargeItem()
        {
            List<SelectListItem> temp = new List<SelectListItem>();
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "사입",
                Value = "1"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "이체",
                Value = "3"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "수수료",
                Value = "9"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "취소벌금",
                Value = "8"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "SMS충전",
                Value = "S"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "중개 수수료",
                Value = "P"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "카드 수수료",
                Value = "K"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "카드 결제액",
                Value = "G"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "쿠폰",
                Value = "U"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "마일리지",
                Value = "M"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "배달팁 할인",
                Value = "a"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "행복페이 할인",
                Value = "b"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "입점신청 충전",
                Value = "I"
            });
            temp.Add(new SelectListItem()
            {
                Selected = true,
                Text = "기타",
                Value = "E"
            });
            return temp;
        }
    }
}
