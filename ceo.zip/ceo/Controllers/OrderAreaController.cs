﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.OrderArea;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.NaverGeocode;
using PosWebApp.ViewModels.OrderArea;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class OrderAreaController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly NaverApi naverAPI;
        private readonly NLog.Logger nlogger;
        public OrderAreaController(DgShopApiService api, NaverApi naverApi)
        {
            dgShop = api;
            naverAPI = naverApi;
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }
        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            Request req = new Request()
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd
            };

            var address = await dgShop.Post<ShopAddress, Request>("Address", req);
            ViewBag.shopAddress = address.data.FirstOrDefault();

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> InputHGeoCode(string address)
        {
            if (string.IsNullOrEmpty(address))
            {
                return BadRequest(new
                {
                    code = "99",
                    Msg = "주소값을 입력해주세요"
                });
            }

            var temp = await naverAPI.Geocoding(address);
            AddressTotal addressTotal = new AddressTotal();
            int i = 0;
            foreach (var item in temp.addresses)
            {
                var geo = item;

                var reverse = await naverAPI.ReverseGeocoding(Convert.ToDouble(geo.x), Convert.ToDouble(geo.y));

                var adm = reverse.results.Find(x => x.name.Equals("admcode"));
                var addr = reverse.results.Find(x => x.name.Equals("addr"));
                var legal = reverse.results.Find(x => x.name.Equals("legalcode"));
                var road = reverse.results.Find(x => x.name.Equals("roadaddr"));


                addressTotal.SIDO_NAME = addr.region.area1.name;
                addressTotal.SIGUNGU_NAME = addr.region.area2.name;
                addressTotal.DONG_NAME = addr.region.area3.name;
                addressTotal.HDONG_NAME = adm == null ? "" : adm.region.area3.name;
                addressTotal.RI_NAME = addr.region.area4.name;
                addressTotal.JIBUN_FIRST = addr.land.number1;
                addressTotal.JIBUN_SECOND = addr.land.number2;

                if (road != null)
                {
                    addressTotal.ROAD_NAME = road.land.name;
                    addressTotal.BLD_FIRST = road.land.number1;
                    addressTotal.BLD_SECOND = road.land.number2;
                    addressTotal.BLD_DETAILNAME = road.land.addition0.value;
                }
                else
                {
                    addressTotal.ROAD_NAME = string.Empty;
                    addressTotal.BLD_FIRST = string.Empty;
                    addressTotal.BLD_SECOND = string.Empty;
                    addressTotal.BLD_DETAILNAME = string.Empty;
                }

                addressTotal.LON = Convert.ToDouble(geo.x);
                addressTotal.LAT = Convert.ToDouble(geo.y);

                var umdr = addressTotal.RI_NAME.Length > 0 ? string.Join(' ', addressTotal.DONG_NAME, addressTotal.RI_NAME) : addressTotal.DONG_NAME;

                var master_sub = addressTotal.JIBUN_SECOND.Length > 0 ? string.Join('-', addressTotal.JIBUN_FIRST, addressTotal.JIBUN_SECOND) : addressTotal.JIBUN_FIRST;

                var build_master_sub = addressTotal.BLD_SECOND.Length > 0 ? string.Join('-', addressTotal.BLD_FIRST, addressTotal.BLD_SECOND) : addressTotal.BLD_FIRST;

                addressTotal.jibunAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    umdr,
                    master_sub);


                addressTotal.roadAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    addressTotal.ROAD_NAME,
                    build_master_sub
                    );

                temp.addresses[i].roadAddress = addressTotal.roadAddress;

                i++;
            }



            return PartialView("ClickModalAddress", temp.addresses);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(AddDongModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            RequestSetShopSectorMulti multiData = new RequestSetShopSectorMulti()
            {
                job_gbn = "I",
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                sectorData = new List<RequestSetShopSector>()
            };

            var resultList = new RequestUpdateOrderArea();
            resultList.setbgn = new List<string>();
            resultList.dong = new List<string>();

            resultList.job_gbn = "1";
            resultList.cccode = info.cccode;
            resultList.shop_cd = info.shop_cd;
            resultList.sido = model.sido;
            resultList.gungu = model.sigungu;


            foreach (var item in model.dongList)
            {
                if (item.selected)
                {
                    resultList.setbgn.Add("I");
                    resultList.dong.Add(item.humdr);
                    //RequestSetShopSector sector = new RequestSetShopSector()
                    //{
                    //    job_gbn = "I",
                    //    cccode = info.cccode,
                    //    shop_cd = info.shop_cd,
                    //    dong = item.humdr,
                    //    sido = item.sido,
                    //    sigungu = item.sigungu

                    //};
                    //multiData.sectorData.Add(sector);


                }
            }
            var result = await dgShop.Post<dynamic, RequestUpdateOrderArea>("ShopSector/Set_V2", resultList);
            //var result = await dgShop.Post<ShopSector, RequestSetShopSectorMulti>("ShopSector/ListSet", multiData);

            if (result.code.Equals("00"))
            {
                var JsonBody = JsonConvert.SerializeObject(multiData);
                nlogger.Info($"OrderArea Success ====== JsonBody ===== {JsonBody}");
                return RedirectToAction("Index", "DeliveryAreaTip");
            }

            ModelState.AddModelError("", result.msg);

            return View();
        }

        public IActionResult Edit(string sido, string sigungu)
        {
            AddDongModel model = new AddDongModel()
            {
                sido = sido,
                sigungu = sigungu
            };

            return View(model);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(AddDongModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var checkTemp = new List<HDong>();


            var temp = await dgShop.Post<ShopBizSector, dynamic>("ShopSector", new RequestGetShopSector
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                sido = model.sido,
                sigungu = model.sigungu
            });

            foreach (var item in temp.data)
            {
                foreach (var i in item.sigunguList)
                {
                    checkTemp = i.umdrList;
                }
            }

            var resultList = new RequestUpdateOrderArea();
            resultList.setbgn = new List<string>();
            resultList.dong = new List<string>();

            for (var i = 0; i< checkTemp.Count(); i++)
            {
                if(!checkTemp[i].selected && model.dongList[i].selected) { 
                    resultList.setbgn.Add("I");
                    resultList.dong.Add(model.dongList[i].humdr);
                }
                if(checkTemp[i].selected && !model.dongList[i].selected) { 
                    resultList.setbgn.Add("D");
                    resultList.dong.Add(model.dongList[i].humdr);
                }
            }

            resultList.job_gbn = "1";
            resultList.cccode = info.cccode;
            resultList.shop_cd = info.shop_cd;
            resultList.sido = model.sido;
            resultList.gungu = model.sigungu;

            RequestSetShopSectorMulti updateSector = new RequestSetShopSectorMulti()
            {
                job_gbn = "U",
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                delete_sido = model.sido,
                delete_sigungu = model.sigungu,
                sectorData = new List<RequestSetShopSector>()
            };


            var result = await dgShop.Post<dynamic, RequestUpdateOrderArea>("ShopSector/Set_V2", resultList);

            //foreach (var item in model.dongList)
            //{
            //    if (item.selected) // 선택
            //    {
            //        RequestSetShopSector sector = new RequestSetShopSector()
            //        {
            //            job_gbn = "U",  // I List 
            //            cccode = info.cccode,
            //            shop_cd = info.shop_cd,
            //            dong = item.humdr,
            //            sido = item.sido,
            //            sigungu = item.sigungu

            //        };
            //        updateSector.sectorData.Add(sector);
            //    }
            //    else
            //    {

            //    }
            //}

            //var result = await dgShop.Post<ShopSector, RequestSetShopSectorMulti>("ShopSector/ListSet", updateSector);

            if (result.code.Equals("00"))
            {
                var JsonBody = JsonConvert.SerializeObject(resultList);
                nlogger.Info($"OrderArea Success ====== JsonBody ===== {JsonBody}");
                return RedirectToAction("Index", "DeliveryAreaTip");
            }

            return View(model);
        }

        public async Task<IActionResult> Delete(string sido, string sigungu)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            //RequestSetShopSectorMulti updateSector = new RequestSetShopSectorMulti()
            //{
            //    job_gbn = "D_GUNGU",
            //    cccode = info.cccode,
            //    shop_cd = info.shop_cd,
            //    delete_sido = sido,
            //    delete_sigungu = sigungu,
            //    sectorData = null
            //};

            //var result = await dgShop.Post<ShopSector, RequestSetShopSectorMulti>("ShopSector/Delete", updateSector);

            var resultList = new RequestUpdateOrderArea();
            resultList.setbgn = new List<string>();
            resultList.dong = new List<string>();

            resultList.job_gbn = "3";
            resultList.cccode = info.cccode;
            resultList.shop_cd = info.shop_cd;
            resultList.sido = sido;
            resultList.gungu = sigungu;
            resultList.setbgn.Add("none");
            resultList.dong.Add("none");

            var result = await dgShop.Post<dynamic, RequestUpdateOrderArea>("ShopSector/Set_V2", resultList);

            var JsonBody = JsonConvert.SerializeObject(resultList);
            nlogger.Info($"OrderArea Delete ====== JsonBody ===== {JsonBody}");
            return RedirectToAction("Index", "DeliveryAreaTip");
        }
        public IActionResult ReloadSigungu(string sido)
        {
            return ViewComponent("Sigungu", new { sido = sido });
        }
        public IActionResult ReloadDong(string sido, string sigungu)
        {
            return ViewComponent("UmdSelect", new { sido = sido, sigungu = sigungu });
        }
    }
}
