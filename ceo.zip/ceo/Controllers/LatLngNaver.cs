﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    public class LatLngNaver : Controller
    {
        private readonly IJSRuntime js;
        private readonly IJSObjectReference obJs;
        private string _result;
        private object resultList;
        public LatLngNaver(IJSRuntime js, IJSObjectReference objectReference)
        {
            this.js = js;
            this.obJs = objectReference;
        }

        //public async Task<IActionResult> GetPoint(string x, string y)
        //{

        //    var req = await TileIndex(x,y);

        //    return Ok(new
        //    {
        //        code = "00",
        //        Point = 
        //    });
        //}

        //private async Task TileIndex(string x, string y) => _result = await obJs.InvokeAsync<string>("NaverLatLngToPoint", );

    }
}
