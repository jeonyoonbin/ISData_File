﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.ApiModels.Shop.Request;
using PosWebApp.Common;
using PosWebApp.Database;
using PosWebApp.Models.Pos;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Models.Store;
using PosWebApp.Models.Store.CompleteTime;
using PosWebApp.Models.Store.Image;
using PosWebApp.Services.DgShop;
using PosWebApp.Services.StoreImage;
using PosWebApp.ViewModels;
using PosWebApp.ViewModels.Store;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class StoreController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly ShopStoreImageService admImage; 

        private readonly string storeImageUrl;
        private readonly string logoImageUrl;
        private readonly string introImageUrl;
        private readonly string domain;
       
        private readonly ILogger<StoreController> _logger;
        private readonly NLog.Logger nlogger;

        public StoreController(DgShopApiService api, ShopStoreImageService image, IConfiguration config, ILogger<StoreController> logger)
        {
            dgShop = api;
            admImage = image;

            storeImageUrl = config.GetValue<string>("upload:shopSignBoardPath");
            logoImageUrl = config.GetValue<string>("upload:shopLogoPath");
            introImageUrl = config.GetValue<string>("upload:storeImageURL");
            domain = config.GetValue<string>("upload:appDomain");
            _logger = logger;
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }
        /// <summary>
        ///  가맹점 기본(매장) 정보 ( 홈페이지 출력용 )
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> Index()
        {
            try
            {
                string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
                ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
                info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


                Request req = new Request()
                {
                    cccode = info.cccode,
                    shop_cd = info.shop_cd
                };
                var temp_v2 = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                   ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                   {
                       job_gbn = "1",
                       shop_cd = info.shop_cd,
                   });

                if (temp_v2.code.Equals("00"))
                    ViewBag.ShopStore = temp_v2.data.SingleOrDefault();

                var temp = await dgShop.Post<ShopStoreInfo, Request>("DefaultInfo", req);
                if (temp.code.Equals("00"))
                {
                    var shopDefaultInfo = temp.data.SingleOrDefault();
                    ViewBag.ShopDefault = shopDefaultInfo;

                    var stringItem = await GetItemJoin(shopDefaultInfo.item_cd);
                    var stringItem2 = await GetItemJoin(shopDefaultInfo.item_cd2);
                    var stringItem3 = await GetItemJoin(shopDefaultInfo.item_cd3);

                    List<string> categoryItemList = new List<string>();
                    categoryItemList.Add(stringItem);
                    categoryItemList.Add(stringItem2);
                    categoryItemList.Add(stringItem3);

                    for(var i = 0; i <categoryItemList.Count(); i++)
                    {
                        if (string.IsNullOrEmpty(categoryItemList[i]))
                        {
                            categoryItemList.RemoveAt(i);
                        }
                    }

                    /*카테고리 | 추가*/
                    ViewBag.shopItem = string.Join(" | ", categoryItemList);
                    /*
                     * owner Add
                     */
                    var bizinfo = await dgShop.Post<ShopBizInfo, Request>("BizInfo", new Models.RequestModel.Request
                    {
                        cccode = info.cccode,
                        shop_cd = info.shop_cd,
                        job_gbn = "1"
                    });

                    if (bizinfo.code.Equals("00"))
                    {
                        var shopBizInfo = bizinfo.data.SingleOrDefault();
                        ViewBag.ShopOwner = shopBizInfo.OWNER;
                    }

                    ViewData["StoreImage"] = string.Concat(storeImageUrl, shopDefaultInfo.app_logo_name);

                    if (!string.IsNullOrEmpty(shopDefaultInfo.app_file_name))
                    {
                        ViewData["StoreLogo"] = string.Concat(logoImageUrl, shopDefaultInfo.app_file_name);
                    }
                    else
                    {
                        ViewData["StoreLogo"] = "/img/image-gallery.png";
                    }
                    ViewBag.IsAddress = null;
                    ViewBag.IsCategory = null;

                    /*서비스 요청관리
                     * 주소, 카테고리 23. 02. 22 사용 중지
                     */
                    //RequestCommonAPI RSapi = new RequestCommonAPI(dgShop);

                    //var RSresult = await RSapi.RequestServiceList(new PosWebApp.Models.ChangeRequest.Request.RequestCommon
                    //{
                    //    shop_cd = info.shop_cd,
                    //    job_gbn = "1",
                    //    status = "%",
                    //    service_gbn = "%",
                    //    from = DateTime.Now.AddMonths(-6).ToString("yyyyMMdd"),
                    //    to = DateTime.Now.ToString("yyyyMMdd")
                    //});

                    //if (RSresult.code.Equals("00"))
                    //{
                    //    var addressService = RSresult.data.Where(x => x.service_gbn.Equals("200")).ToList();
                    //    var categoryService = RSresult.data.Where(x => x.service_gbn.Equals("201")).ToList();
                    //    if (addressService.Count() > 0)
                    //    {
                    //        //if(addressService.Where(x => x.status.Equals())
                    //        var jsonServiceData = addressService.OrderBy(x => x.mod_date).First().service_data;

                    //        if (addressService.OrderBy(x => x.mod_date).First().status.Equals("40") ||
                    //            addressService.OrderBy(x => x.mod_date).First().status.Equals("50") ||
                    //            addressService.OrderBy(x => x.mod_date).First().status.Equals("35"))
                    //        {
                    //            ViewBag.IsAddress = null;
                    //        }
                    //        else
                    //        {
                    //            ViewBag.IsAddress = JsonConvert.DeserializeObject<PosWebApp.Models.Common.ServiceCommon>(jsonServiceData);
                    //        }


                    //    }
                    //    else
                    //    {
                    //        ViewBag.IsAddress = null;
                    //    }
                    //    if (categoryService.Count() > 0)
                    //    {
                    //        var jsonServiceData = categoryService.OrderBy(x => x.mod_date).First().service_data;

                    //        if (categoryService.OrderBy(x => x.mod_date).First().status.Equals("40") ||
                    //            categoryService.OrderBy(x => x.mod_date).First().status.Equals("50") ||
                    //            categoryService.OrderBy(x => x.mod_date).First().status.Equals("35"))
                    //        {
                    //            ViewBag.IsCategory = null;
                    //        }
                    //        else
                    //        {
                    //            ViewBag.IsCategory = JsonConvert.DeserializeObject<PosWebApp.Models.Common.ServiceCommon>(jsonServiceData);
                    //        }


                    //    }
                    //    else
                    //    {
                    //        ViewBag.IsCategory = null;
                    //    }


                    //}
                }
            }
            catch (Exception e)
            {
                _logger.LogCritical(e.Message);
                throw;
            }

            return View();
        }

        /// <summary>
        ///  매장 전화번호 변경
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> MobileSet(string mobile)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(mobile))
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "수정할 데이타가 없습니다. 매장 전화번호 입력후 이용부탁드립니다."
                });
            }
            if(info.shop_telno.Replace("-","") == mobile.Replace("-", ""))
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "기존 입력된 전화번호와 동일 합니다."
                });
            }

            var temp = await dgShop.Post<dynamic, ApiModels.Shop.Request.RequestShopInfo>
                   ("/api/ShopManagement/SetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                   {
                       job_gbn = "8",
                       shop_cd = info.shop_cd,
                       mcode = info.login_code,
                       mName = info.login_name,
                       data1 = mobile.Replace("-","")
                   });

            if (temp.code.Equals("00"))
            {
                info.shop_telno = mobile.Replace("-", "");
                var NewsessionString = JsonConvert.SerializeObject(info);
                HttpContext.Session.SetString("shopDefaultInfo", NewsessionString);
                return Ok(new
                {
                    code = "00",
                    Msg = "성공"
                });
            }

            return Ok(new
            {
                code = "99",
                Msg = temp.msg
            });
        }

        #region 변경요청 이력 
        public async Task<IActionResult> ChangeRequestModal()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                   ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                   {
                       job_gbn = "1",
                       shop_cd = info.shop_cd,
                   });

            var result = new ApiModels.Shop.Response.ServiceReqeustShopInfo();
            if (temp.code.Equals("00"))
            {
                
                result = new ApiModels.Shop.Response.ServiceReqeustShopInfo(temp.data.SingleOrDefault());
            }

            return PartialView("_PartialChangeRequestModal", result);
        }
        #endregion

        #region 검색 태그
        public async Task<IActionResult> UpdateSearchTag()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var temp = await dgShop.Post<ShopSearchTag, Request>("SearchTag", new Request
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            if (temp.code.Equals("00"))
            {
                return View(new SearchTagViewModel()
                {
                    search_tag = temp.data.FirstOrDefault().search_tag
                });
            }

            return View(new SearchTagViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> UpdateSearchTag(SearchTagViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ShopStoreInfo, RequestUpdateSearchTag>("UpdateSearchTag", new RequestUpdateSearchTag
            {
                job_gbn = "U",
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                search_tag = model.search_tag,
                mod_code = info.login_code,
                mod_user = info.login_name

            });
            if (temp.code.Equals("00"))
            {
                return RedirectToAction("Index");
            }

            return View();
        }
        #endregion

        #region 최소 주문 금액

        public IActionResult UpdateAppMinAmt()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UpdateAppMinAmt(AppMinAmtViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestAppMinAmt req = new RequestAppMinAmt()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                mod_code = info.login_code,
                mod_name = info.login_name,
                app_min_amt = model.min_amt

            };
            var temp = await dgShop.Post<ShopStoreInfo, RequestAppMinAmt>("UpdateAppMinAmt", req);
            if (temp.code.Equals("00"))
            {

                return RedirectToAction("Index");
            }


            return View(model);
        }
        #endregion

        #region 배달비 무료 설정 ( 사용하지 않음. 2021.04.22 )

        public IActionResult UpdateFreeOrderAmt()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UpdateFreeOrderAmt(FreeOrderAmtViewModel model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            RequestFreeOrderAmt req = new RequestFreeOrderAmt()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                mod_code = info.login_code,
                mod_name = info.login_name,
                free_amount = model.free_amount

            };
            var temp = await dgShop.Post<ShopStoreInfo, RequestFreeOrderAmt>("UpdateFreeOrderAmt", req);
            if (temp.code.Equals("00"))
            {

                return RedirectToAction("Index");
            }
            return View(model);
        }
        #endregion

        #region 오더 완료 시간

        public async Task<IActionResult> UpdateOrderCompleteTime()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var temp = await dgShop.Post<ORDER_COMPLETE_TIME, Request>("GetOrderTime", new Request
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });

            if (temp.code.Equals("00"))
            {
                string[] timeData = temp.data.SingleOrDefault().accept_state.Split(',');

                var preset = GetOrderPreset();
                foreach (var item in preset)
                {
                    var exist = timeData.FirstOrDefault(x => x.Equals(item.Value));
                    item.Selected = exist != null ? true : false;
                }

                return View(preset);
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UpdateOrderCompleteTime(SelectedTime model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            StringBuilder sb = new StringBuilder();

            foreach (var item in model.OrderTime)
            {
                if (item.Selected == true) sb.Append($"{item.Value},");
            }

            RequestOrderCompleteTime req = new RequestOrderCompleteTime()
            {
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                mod_code = info.login_code,
                mod_name = info.login_name,
                order_comp_time = sb.ToString().TrimEnd(',') == "" ? "0" : sb.ToString().TrimEnd(',')

            };
            var temp = await dgShop.Post<ShopStoreInfo, RequestOrderCompleteTime>("UpdateOrderCompTime", req);
            if (temp.code.Equals("00"))
            {

                return RedirectToAction("Index");
            }
            return View(model);
        }

        public async Task<IActionResult> OrderPackingCompleteTime()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var order = await dgShop.Post<ORDER_COMPLETE_TIME, Request>("GetOrderTime", new Request
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd
            });


            var packing = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                   ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                   {
                       job_gbn = "6",
                       shop_cd = info.shop_cd,

                   });

            if (order.code.Equals("00"))
            {
                string[] timeData = order.data.SingleOrDefault().accept_state.Split(',');

                var preset = GetOrderPreset();
                foreach (var item in preset)
                {
                    var exist = timeData.FirstOrDefault(x => x.Equals(item.Value));
                    item.Selected = exist != null ? true : false;
                }

                ViewBag.order = preset;
            }

            if (packing.code.Equals("00"))
            {
                string[] timeData = packing.data.SingleOrDefault().toGoAcceptState.Split(',');

                var preset = GetOrderPreset();
                foreach (var item in preset)
                {
                    var exist = timeData.FirstOrDefault(x => x.Equals(item.Value));
                    item.Selected = exist != null ? true : false;
                }

                ViewBag.packing = preset;
            }
            return View();

        }

        [HttpPost]
        public async Task<IActionResult> PackingCompleteTime(SelectedTime model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            StringBuilder sb = new StringBuilder();

            foreach (var item in model.PackingTime)
            {
                if (item.Selected == true) sb.Append($"{item.Value},");
            }

            var temp = await dgShop.Post<dynamic, ApiModels.Shop.Request.RequestShopInfo>
                   ("/api/ShopManagement/SetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                   {
                       job_gbn = "6",
                       shop_cd = info.shop_cd,
                       mcode = info.login_code,
                       mName = info.login_name,
                       data1 = sb.ToString().TrimEnd(',') == "" ? "0" : sb.ToString().TrimEnd(',')
                   });
            if (temp.code.Equals("00"))
            {

                return RedirectToAction("Index");
            }
            return View(model);
        }
        public List<SelectListItem> GetOrderPreset()
        {
            List<int> presetTime = new List<int>() { 10, 20, 30, 40, 50, 60, 75,
                90, 120, 150 };
            List<SelectListItem> presetList = new List<SelectListItem>();
            foreach (var item in presetTime)
            {
                presetList.Add(new SelectListItem
                {
                    Text = string.Concat(item, "분"),
                    Value = item.ToString()
                });
            }
            return presetList;
        }
        #endregion

        #region 업종 코드 ( 최대 3개 )
        public async Task<IActionResult> UpdateItemCode(string item1, string item2, string item3)
        {
            var itemList = await dgShop.Get<ShopBizItemCode>("BizItemCode");

            ViewBag.item1 = new SelectList(itemList.data, "ITEM_CD", "ITEM_NAME", item1);
            ViewBag.item2 = new SelectList(itemList.data, "ITEM_CD", "ITEM_NAME", item2);
            ViewBag.item3 = new SelectList(itemList.data, "ITEM_CD", "ITEM_NAME", item3);

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UpdateItemCode(ItemCodeViewModel model)
        {
            if (string.IsNullOrEmpty(model.item1) || model.item1.Equals("--"))
            {
                ModelState.AddModelError("item1", "업종 선택 1은 필수 선택 항목입니다");
                return View();
            }

            if (model.item2.Equals("--")) model.item2 = null;
            if (model.item3.Equals("--")) model.item3 = null;

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            var itemList = await dgShop.Get<ShopBizItemCode>("BizItemCode");

            ViewBag.item1 = new SelectList(itemList.data, "ITEM_CD", "ITEM_NAME", model.item1);
            ViewBag.item2 = new SelectList(itemList.data, "ITEM_CD", "ITEM_NAME", model.item2);
            ViewBag.item3 = new SelectList(itemList.data, "ITEM_CD", "ITEM_NAME", model.item3);

            var temp = await dgShop.Post<ShopItemCodes, RequestShopItemCodes>("SetItemCodes", new RequestShopItemCodes()
            {
                job_gbn = "1",
                cccode = info.cccode,
                shop_cd = info.shop_cd,
                item_cd = model.item1,
                item_cd2 = model.item2,
                item_cd3 = model.item3,
                mod_code = info.login_code,
                mod_user = info.login_name
            });

            return Redirect("Index");
        }
        #endregion

        public async Task<IActionResult> TypeViewSet()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            var req = await dgShop.PostSingle<ShopPayType, Request>("PayType/Get", new Request
            {
                job_gbn = "I",
                shop_cd = info.shop_cd
            });

            if (req.code == "00")
            {
                string[] forData = req.data.app_pay_type.Split(","); // 1,3,5 -> stirng[length]
                int forLength = forData.Length;

                ShopPayTypeViewModel model = new ShopPayTypeViewModel();

                if (Array.Exists(forData, x => x == "1"))
                    model.meetToPay = true;
                if (Array.Exists(forData, x => x == "5"))
                    model.meetToCard = true;

                return View(model);
            }
            else
            {
                return StatusCode(400);
            }
        }
        [HttpPost]
        public async Task<IActionResult> TypeViewSet(ShopPayTypeViewModel model = null)
        {

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var payType = new List<string>();
            if (model.meetToPay.Equals(true))
                payType.Add("1");
            if (model.appType.Equals(true))
                payType.Add("3");
            if (model.meetToCard.Equals(true))
                payType.Add("5");

            var resultStringArray = string.Join(",", payType);

            Debug.WriteLine("{0}", resultStringArray);


            var req = await dgShop.PostSingle<ShopPayType, RequestShopPayType>("PayType/Set", new RequestShopPayType
            {
                job_gbn = "I",
                shop_cd = info.shop_cd,
                cccode = info.cccode,
                mcode = info.mcode,
                mod_name = info.login_name,
                mod_ucode = info.shop_cd.ToString(),
                pay_type = resultStringArray

            });


            if (req.code == "00")
            {
                return RedirectToAction("index");
            }


            return BadRequest(new
            {
                code = "99",
                Msg = "결제 방식 업데이트 에러"
            });


        }


        #region 매장 알림, 리뷰 알림 , 배달 알림
        public async Task<IActionResult> ModifyShopIntro()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var argument = new Dictionary<string, string>() {
                    { "shop_cd" ,info.shop_cd.ToString() },
                    { "image_gbn", "I"}
                };
            var query = QueryHelpers.AddQueryString("Image/getShopInfoImage", argument);

            var temp = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                    ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                    {
                        job_gbn = "1",
                        shop_cd = info.shop_cd,

                    });
            var shopImage = await admImage.Get<ApiModels.Shop.Response.ResponseShopImage>(query);
            //var shopImage = await dgShop.Post<ApiModels.Shop.Response.ResponseShopImage, ApiModels.Shop.Request.RequestShopImage>
            //        ("/api/ShopManagement/GetShopAlertImage", new ApiModels.Shop.Request.RequestShopImage
            //        {
            //            shop_cd = info.shop_cd,
            //            imageGbn = "I"
            //        });

            if (shopImage.code.Equals("00"))
            {
                ViewBag.shopImage = shopImage.data;
            }
            else
            {
                ViewBag.shopImage = new List<ApiModels.Shop.Response.ResponseShopImage>();
            }

            ViewBag.ImageURL = "image.daeguro.co.kr:40443" + "/intro-images" + "/ShopImage" + "/" + info.shop_cd + "/Thumb";

            var result = temp.data.SingleOrDefault();

            //var bytnshopIntro = Encoding.Unicode.GetBytes(result.shopIntro);

           // result.shopIntro = Encoding.Unicode.GetString(bytnshopIntro);
           // Debug.WriteLine(Encoding.ASCII.GetString(bytnshopIntro));
            return View(result);

        }
        [HttpPost]
        public async Task<IActionResult> ModifyShopIntro(string text)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            ApiModels.Shop.Response.ResponseShopInfo result = new ApiModels.Shop.Response.ResponseShopInfo();

            var utf8tounicode = PrintChars(text);

            var unicodeByte = Encoding.Unicode.GetBytes(text);


            var unicodeText = "";
            foreach (var i in utf8tounicode)
            {
                unicodeText += i;
            }
            //Debug.WriteLine(Encoding.Unicode.GetByteCount(u);
            //Debug.WriteLine(Encoding.Unicode.GetString(.));
            //result.shopIntro = string.Concat(utf8tounicode);
            //  result.shopIntro = unicodeText;
            result.shopIntro = text;

            //var AscIIcode = Encoding.ASCII.GetString(unicodeByte);

           // Debug.WriteLine(AscIIcode);

            var req = await dgShop.Post<dynamic, ApiModels.Shop.Request.RequestShopInfo>
                    ("/api/ShopManagement/SetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                    {
                        job_gbn = "4",
                        shop_cd = info.shop_cd,
                        mcode = info.login_code,
                        mName = info.login_name,
                        data1 = result.shopIntro
                    });


            var argument = new Dictionary<string, string>() {
                    { "shop_cd" ,info.shop_cd.ToString() },
                    { "image_gbn", "I"}
                };
            var query = QueryHelpers.AddQueryString("Image/getShopInfoImage", argument);
            if (req.code.Equals("00"))
            {
                ViewBag.Sucess = "Y";
                var temp = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                     ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                     {
                         job_gbn = "1",
                         shop_cd = info.shop_cd,

                     });

                //var shopImage = await dgShop.Post<ApiModels.Shop.Response.ResponseShopImage, ApiModels.Shop.Request.RequestShopImage>
                //        ("/api/ShopManagement/GetShopAlertImage", new ApiModels.Shop.Request.RequestShopImage
                //        {
                //            shop_cd = info.shop_cd,
                //            imageGbn = "I"
                //        });
                

                

                var shopImage = await admImage.Get<ApiModels.Shop.Response.ResponseShopImage>(query);

                if (shopImage.code.Equals("00"))
                {
                    ViewBag.shopImage = shopImage.data;
                }
                else
                {
                    ViewBag.shopImage = new List<ApiModels.Shop.Response.ResponseShopImage>();
                }

                ViewBag.ImageURL = "image.daeguro.co.kr:40443" + "/intro-images" + "/ShopImage" + "/" + info.shop_cd + "/Thumb";
                return View(temp.data.SingleOrDefault());
            }

            var errorShopImage = await admImage.Get<ApiModels.Shop.Response.ResponseShopImage>(query);

            if (errorShopImage.code.Equals("00"))
            {
                ViewBag.shopImage = errorShopImage.data;
            }
            else
            {
                ViewBag.shopImage = new List<ApiModels.Shop.Response.ResponseShopImage>();
            }

            ViewBag.ImageURL = "image.daeguro.co.kr:40443" + "/intro-images" + "/ShopImage" + "/" + info.shop_cd + "/Thumb";
            ModelState.AddModelError("shopIntro", req.msg);
            return View("ModifyShopIntro", result);
        }
        public async Task<IActionResult> ModifyShopReviewIntro()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            var argument = new Dictionary<string, string>() {
                    { "shop_cd" ,info.shop_cd.ToString() },
                    { "image_gbn", "R"}
                };
            var query = QueryHelpers.AddQueryString("Image/getShopInfoImage", argument);
            var temp = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                    ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                    {
                        job_gbn = "1",
                        shop_cd = info.shop_cd,
                    });
            var reviewImage = await admImage.Get<ApiModels.Shop.Response.ResponseShopImage>(query);
            //var reviewImage = await dgShop.Post<ApiModels.Shop.Response.ResponseShopImage, ApiModels.Shop.Request.RequestShopImage>
            //        ("/api/ShopManagement/GetShopAlertImage", new ApiModels.Shop.Request.RequestShopImage
            //        {
            //            shop_cd = info.shop_cd,
            //            imageGbn = "R"
            //        });

            if (reviewImage.code.Equals("00"))
            {
                ViewBag.reviewImage = reviewImage.data;
            }
            else
            {
                ViewBag.reviewImage = new List<ApiModels.Shop.Response.ResponseShopImage>();
            }
            ViewBag.ImageURL = "image.daeguro.co.kr:40443" + "/intro-images" + "/ReviewImage" + "/" + info.shop_cd + "/Thumb";
            return View(temp.data.SingleOrDefault());

        }
        [HttpPost]
        public async Task<IActionResult> ModifyShopReviewIntro(string text)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            ApiModels.Shop.Response.ResponseShopInfo result = new ApiModels.Shop.Response.ResponseShopInfo();
            result.shopReviewIntro = text;
            var argument = new Dictionary<string, string>() {
                    { "shop_cd" ,info.shop_cd.ToString() },
                    { "image_gbn", "R"}
                };
            var query = QueryHelpers.AddQueryString("Image/getShopInfoImage", argument);


            var req = await dgShop.Post<dynamic, ApiModels.Shop.Request.RequestShopInfo>
                    ("/api/ShopManagement/SetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                    {
                        job_gbn = "5",
                        shop_cd = info.shop_cd,
                        mcode = info.login_code,
                        mName = info.login_name,
                        data1 = text
                    });

            if (req.code.Equals("00"))
            {
                ViewBag.Sucuess = "Y";
                var temp = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                   ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                   {
                       job_gbn = "1",
                       shop_cd = info.shop_cd,
                   });

                //var reviewImage = await dgShop.Post<ApiModels.Shop.Response.ResponseShopImage, ApiModels.Shop.Request.RequestShopImage>
                //        ("/api/ShopManagement/GetShopAlertImage", new ApiModels.Shop.Request.RequestShopImage
                //        {
                //            shop_cd = info.shop_cd,
                //            imageGbn = "R"
                //        });

                var reviewImage = await admImage.Get<ApiModels.Shop.Response.ResponseShopImage>(query);

                if (reviewImage.code.Equals("00"))
                {
                    ViewBag.reviewImage = reviewImage.data;
                }
                else
                {
                    ViewBag.reviewImage = new List<ApiModels.Shop.Response.ResponseShopImage>();
                }
                ViewBag.ImageURL = "image.daeguro.co.kr:40443" + "/intro-images" + "/ReviewImage" + "/" + info.shop_cd + "/Thumb";
                return View(temp.data.SingleOrDefault());
            }


            //var errorReviewImage = await dgShop.Post<ApiModels.Shop.Response.ResponseShopImage, ApiModels.Shop.Request.RequestShopImage>
            //            ("/api/ShopManagement/GetShopAlertImage", new ApiModels.Shop.Request.RequestShopImage
            //            {
            //                shop_cd = info.shop_cd,
            //                imageGbn = "R"
            //            });

            var errorReviewImage = await admImage.Get<ApiModels.Shop.Response.ResponseShopImage>(query);

            if (errorReviewImage.code.Equals("00"))
            {
                ViewBag.reviewImage = errorReviewImage.data;
            }
            else
            {
                ViewBag.reviewImage = new List<ApiModels.Shop.Response.ResponseShopImage>();
            }

            ViewBag.ImageURL = "image.daeguro.co.kr:40443" + "/Intro" + "/reviewImage" + "/" + info.shop_cd;


            ModelState.AddModelError("shopReviewIntro", req.msg);
            return View(result);
        }
        public async Task<IActionResult> ModifyShopDeliveryIntro()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var temp = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                    ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                    {
                        job_gbn = "1",
                        shop_cd = info.shop_cd,
                    });

            return View(temp.data.SingleOrDefault());

        }
        [HttpPost]
        public async Task<IActionResult> ModifyShopDeliveryIntro(string text)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ApiModels.Shop.Response.ResponseShopInfo result = new ApiModels.Shop.Response.ResponseShopInfo();
            result.deliInfo = text;


            //if (result.deliInfo.Contains("\r\n"))
            //{
            //    var temp = text.Split("\r\n");
            //    if (temp.Count() > 5)
            //    {
            //        ModelState.AddModelError("deliInfo", "라인 갯수가 너무많습니다. 5번 이하로 작성부탁드립니다.");
            //        return View(result);
            //    }
            //}

            var req = await dgShop.Post<dynamic, ApiModels.Shop.Request.RequestShopInfo>
                    ("/api/ShopManagement/SetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                    {
                        job_gbn = "2",
                        shop_cd = info.shop_cd,
                        mcode = info.login_code,
                        mName = info.login_name,
                        data1 = text
                    });

            if (req.code.Equals("00"))
            {
                ViewBag.Sucess = "Y";
                var temp = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                    ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                    {
                        job_gbn = "1",
                        shop_cd = info.shop_cd,
                    });

                return View(temp.data.SingleOrDefault());
            }

            ModelState.AddModelError("deliInfo", req.msg);
            return View(result);
        }
        public async Task<IActionResult> InsIntro(string type)
        {
            IntroImage intro = new IntroImage();

            switch (type)
            {
                case "1":
                    intro.type = "1";
                    ViewBag.Title = "매장 알림 이미지 등록";
                    break;
                case "2":
                    intro.type = "2";
                    ViewBag.Title = "리뷰 알림 이미지 등록";
                    break;
            }
            await Task.Delay(0);

            return PartialView("IntroImage", intro);
        }
        #endregion

        #region 알림 이미지 업로드 :매장 1, 리뷰 2
        /// <summary>
        /// 알람 이미지 업로드
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<ResultSingle<string>> AlertImageUpload(IntroImage model, string type)
        {

            // string type  2 없음;
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            ResultSingle<string> result = new ResultSingle<string>();


            var ImageUpload = new ImageUtils();
            var isImage = new ResultSingle<string>();
            //var datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            var imageName = "Intro";
            var fileName = "";
#if DEBUG
            var imageURL = "https://172.16.10.75:45013";
#else
            var imageURL = logoImageUrl;
            //var imageURL = "https://192.168.30.109:45013/";
#endif

            RequestSetShopImage request = new RequestSetShopImage();

            try
            {
                //    //로그 넣어야됨
                if (string.IsNullOrEmpty(model.iFile.FileName))
                {
                    ModelState.AddModelError("", "이미지가 없습니다. 등록 후 이용해주세요.");
                    // return PartialView("MenuChange", menu);
                }
                else
                {
                    var nowTime = DateTime.Now.ToString("yyyyMMddHHmmss");
                    fileName = imageName + nowTime + ".jpg";
                    isImage = await ImageUpload.AlertFileUpload(info.shop_cd.ToString(), model.iFile, fileName, (model.type == "1" ? "ShopImage" : "ReviewImage"));
                    //isImage = new ResultSingle<dynamic>();
                    //isImage.code = "00";

                    if (isImage.code.Equals("00"))
                    {
                        nlogger.Info($"이미지등록...{fileName}");
                        request.fileName = fileName;
                        //request.imageFile = introImageUrl + "Intro/" + (type == "1" ? "ShopImage/" : "ReviewImage/") +
                        //              info.shop_cd + "/";


                        request.shop_cd = info.shop_cd;
                        request.imageGbn = (model.type == "1" ? "I" : "R");
                        request.job_gbn = "I";
                        //var ImageReq = await dgShop.Post<dynamic, RequestShopImage>("/api/ShopManagement/SetShopAlertImage", request);
                        var ImageReq = await dgShop.Post<dynamic, ApiModels.Shop.Request.RequestSetShopImage>
                    ("/api/ShopManagement/SetIntroImage", request);

                        if (ImageReq.code.Equals("00"))
                        {
                            nlogger.Info("이미지등록...성공");
                            result.data = null;
                            result.code = "00";
                            result.msg = "성공";
                            return result;
                        }
                        else
                        {
                            nlogger.Info($"이미지등록...실패 {ImageReq.msg}");

                            result.code = "98";
                            result.msg = ImageReq.msg;
                            return result;
                        }
                    }
                    else
                    {
                        nlogger.Info($"이미지등록...실패 {isImage.msg}");
                        ModelState.AddModelError("", "이미지 저장중 에러가 발생했습니다. 관리자에게 문의해주세요.");
                        result.code = "99";
                        result.msg = isImage.msg;
                        return result;
                    }
                }
            }
            catch (Exception e)
            {
                ViewBag.Error = e.Message;
                result.code = "99";
                result.msg = isImage.msg;
            }

            return result;
        }
        [HttpPost]
        public async Task<IActionResult> ShopIntroImageUpload(IntroImage request)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if (string.IsNullOrEmpty(request.iFile.FileName))
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "이미지가 존재하지않습니다."
                });
            }
            var codeRequest = new RequestStoreImage
            {
                div = "I",
                image_gbn = (request.type == "1" ? "I" : "R"),
                shop_cd = info.shop_cd.ToString(),
                ucode = info.login_code.ToString(),
                uname = info.login_name.ToString()
                
            };
             //var image = await AlertImageUpload(request, "1");
            var image = await admImage.Post<dynamic>("image/setShopInfoImage", codeRequest, request.iFile);

            if (image.code.Equals("00"))
            {
                return PartialView("IntroImage");
            }
            else
            {
                ModelState.AddModelError("", image.msg);
                return PartialView("IntroImage");
            }
            
        }
        [HttpPost]
        public async Task<IActionResult> ReviewIntroImageUpload(IntroImage request)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);


            if (string.IsNullOrEmpty(request.iFile.FileName))
            {
                return Ok(new
                {
                    code = "99",
                    Msg = "이미지가 존재하지않습니다."
                });
            }

            var image = await AlertImageUpload(request, "2");


            if (image.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    Msg = "성공"
                });
            }
            return Ok(new
            {
                code = "99",
                Msg = image.msg
            });
        }
        [HttpPost]
        public async Task<IActionResult> DeleteIntroImage(RequestSetShopImage model, string type)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (string.IsNullOrEmpty(model.seq) || string.IsNullOrEmpty(type))
            {
                return Ok(new
                {
                    code = "99",
                    data = "서비스 요청 에러입니다. 관리자에게 문의바랍니다."
                });
            }

            model.imageGbn = (type == "1" ? "I" : "R");
            model.shop_cd = info.shop_cd;
            model.job_gbn = "D";

            // var ImageReq = await dgShop.Post<dynamic, ApiModels.Shop.Request.RequestSetShopImage>
            //       ("/api/ShopManagement/SetIntroImage", model);
            var codeRequest = new RequestStoreImage
            {
                div = "D",
                image_gbn = model.imageGbn,
                shop_cd = info.shop_cd.ToString(),
                seqno = model.seq
            };

            var ImageReq = await admImage.Post<dynamic>("image/setShopInfoImage", codeRequest);
            if (ImageReq.code.Equals("00"))
            {
                return Ok(new
                {
                    code = "00",
                    data = "성공"
                });
            }
            else
            {
                return Ok(new
                {
                    code = "99",
                    data = ImageReq.msg
                });
            }
        }
        #endregion

        #region 포장 할인
        public async Task<IActionResult> PackingSale()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var packing = await dgShop.Post<ApiModels.Shop.Response.ResponseShopInfo, ApiModels.Shop.Request.RequestShopInfo>
                  ("/api/ShopManagement/GetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                  {
                      job_gbn = "1",
                      shop_cd = info.shop_cd,

                  });

            if (packing.code.Equals("00"))
            {
                var singleTemp = packing.data.SingleOrDefault();
                return View(singleTemp);
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> PackingSale(ApiModels.Shop.Response.ResponseShopInfo model)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            Utils utils = new Utils();

            if (string.IsNullOrEmpty(model.toGoMinAmt))
            {
                model.toGoMinAmt = "0";
            }
            if (string.IsNullOrEmpty(model.toGoDiscAmt))
            {
                model.toGoDiscAmt = "0";
            }
            if (string.IsNullOrEmpty(model.toGoMinDiscAmt))
            {
                model.toGoMinDiscAmt = "0";
            }
            if (!utils.MoneyCheck(model.toGoMinAmt.Replace(",", "")))
            {
                ModelState.AddModelError("toGoMinAmt", "최소주문 금액은 100원 단위 이상으로 설정 가능합니다.");
                return View(model);
            }
            if (!utils.MoneyCheck(model.toGoDiscAmt.Replace(",", "")))
            {
                ModelState.AddModelError("toGoDiscAmt", "포장 할인금액은 100원 단위 이상으로 설정 가능합니다.");
                return View(model);
            }


            //model.toGoDiscAmt = Convert.ToInt32(model.toGoDiscAmt.Replace(",", "")).ToString();
            //model.toGoMinAmt = Convert.ToInt32(model.toGoMinAmt.Replace(",", "")).ToString();
            var packing = await dgShop.Post<dynamic, ApiModels.Shop.Request.RequestShopInfo>
                   ("/api/ShopManagement/SetShopInfo", new ApiModels.Shop.Request.RequestShopInfo
                   {
                       job_gbn = "7",
                       shop_cd = info.shop_cd,
                       mcode = info.login_code,
                       mName = info.login_name,
                       data1 = model.toGoDiscAmt.Replace(",", ""),
                       data2 = model.toGoMinAmt.Replace(",", ""),
                       data3 = model.toGoMinDiscAmt.Replace(",", ""),
                   });

            if (packing.code.Equals("00"))
            {
                return RedirectToAction("index");
            }
            ModelState.AddModelError("toGoDiscAmt", packing.msg);
            return View(model);
        }
        #endregion


        public async Task<dynamic> GetItemJoin(string itemCode)
        {
            if (string.IsNullOrEmpty(itemCode))
            {
                return null;
            }

            var temp = await dgShop.Get<ShopBizItem>("BizItemList");

            var result = temp.data.Find(x => x.item_cd.Equals(itemCode));

            if (result == null)
            {
                return "";
            }
            return result.item_name;
        }
        public string[] PrintChars(string s)
        {
            string[] result = new string[s.Length];
            for(var i = 0; i < s.Length; i++)
            {
                result[i] = $"\\{(int)s[i]:x4}";
            }

            return result;
        }
        public char[] PrintChars2(string s)
        {
            char[] result = new char[s.Length];
            result = s.ToCharArray();
            for (var i = 0; i < s.Length; i++)
            {
                var strtobyte = Encoding.Unicode.GetBytes(s[i].ToString());
                

                // Console.WriteLine($"'\\u{(int)s[i]:x4}'");
            }

            return result;
        }
    }
}
