﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Database;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class MajorController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly string localurl;

        public MajorController(DgShopApiService api, IConfiguration configuration)
        {
            dgShop = api;
            localurl = configuration.GetValue<string>("api:local");
        }
        #region View 
        /// <summary>
        /// 대표 메뉴 리스트조회
        /// </summary>
        public async Task<IActionResult> Index()
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            var req = await dgShop.Post<ResponseMajorMenu, Request>("GetMajorMenu", new Request
            {
                cccode = info.cccode,
                job_gbn = "1",
                shop_cd = info.shop_cd,
                mcode = info.mcode
            });

            
            if(req.code == "00")
            {
                foreach (var item in req.data)
                {
                    item.file_name = string.Join('/', info.cccode, info.shop_cd, item.file_name);
                }

                return View(req.data);
            }
            ViewBag.msg = "값이 존재하지않거나, 값을 불러올수 없습니다. ";
            return View();
        }
        /// <summary>
        /// 대표 메뉴 추가 리스트 조회
        /// </summary>
        public async Task<IActionResult> Add(int? page)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if (page == null)
            {
                page = 1;
            }

            int pageSize = 10;
            var majorCount = await dgShop.Post<ResponseMajorMenu, Request>("GetMajorMenu", new Request
            {
                cccode = info.cccode,
                job_gbn = "1",
                shop_cd = info.shop_cd,
                mcode = info.mcode
            });
            if(majorCount.data.Count() >= 6)
            {
                // ViewBag.msg = majorCount.msg;
                ViewBag.Msg = "대표 메뉴 설정 최대 갯수 초과했습니다. 해제후 이용바랍니다.";
                return View(PaginatedList<ResponseMajorMenu>.Create(majorCount.data.AsQueryable<ResponseMajorMenu>(), page ?? 1, pageSize));
            }


            var req = await dgShop.Post<ResponseMajorMenu, Request>("GetMajorMenu", new Request
            {
                cccode = info.cccode,
                job_gbn = "2",
                shop_cd = info.shop_cd,
                mcode = info.mcode
            });

            if (req.code == "00")
            {
                ViewBag.MajorCount = majorCount.data.Count();
                return View(PaginatedList<ResponseMajorMenu>.Create(req.data.AsQueryable<ResponseMajorMenu>(), page ?? 1, pageSize));
            }
            ViewBag.msg = "값이 존재하지않거나, 값을 불러올수 없습니다. ";
            return View();
        }
        #endregion
        #region Setting 
        /// <summary>
        /// 대표 메뉴 설정
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> SetMajorMenu(ResponseMajorMenu majorModel)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            if(majorModel == null)
            {
                return BadRequest();
            }

            RequestMajorMenu requestModel = new RequestMajorMenu()
            {
                cccode = info.cccode,
                job_gbn = "",
                mcode = info.mcode,
                menu_cd = majorModel.menu_cd,
                mod_cd = info.login_code.ToString(),
                mod_name = info.login_name,
                m_main_yn = majorModel.m_main_yn,
                shop_cd = info.shop_cd
            };

            var req = await dgShop.Post<ResponseMajorMenu, RequestMajorMenu>("SetMajorMenu", requestModel);

            if(req.code == "00")
            {
                return Ok();
            }else
            {
                return BadRequest(new { 
                    code = req.code,
                    Msg = req.msg
                });
            }
        }
        #endregion
    }
}
