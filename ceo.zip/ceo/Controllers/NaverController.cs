﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using PosWebApp.Common;
using PosWebApp.Models.Naver;
using PosWebApp.Services.NaverGeocode;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class NaverController : ControllerBase
    {
        private readonly NaverApi api;

        public NaverController(NaverApi naverApi)
        {
            api = naverApi;
        }

        [HttpGet("geocode")]
        public async Task<dynamic> Geocode(string address)
        {
            var temp = await api.Geocoding(address);

            if (temp.addresses != null && temp.addresses.Count > 0)
            {
                var geo = temp.addresses[0];

                var reverse = await api.ReverseGeocoding(Convert.ToDouble(geo.x), Convert.ToDouble(geo.y));

                var adm = reverse.results.Find(x => x.name.Equals("admcode"));
                var addr = reverse.results.Find(x => x.name.Equals("addr"));
                var legal = reverse.results.Find(x => x.name.Equals("legalcode"));
                var road = reverse.results.Find(x => x.name.Equals("roadaddr"));

                AddressTotal addressTotal = new AddressTotal();
                addressTotal.SIDO_NAME = addr.region.area1.name;
                addressTotal.SIGUNGU_NAME = addr.region.area2.name;
                addressTotal.DONG_NAME = addr.region.area3.name;
                addressTotal.HDONG_NAME = adm == null ? "" : adm.region.area3.name;
                addressTotal.RI_NAME = addr.region.area4.name;
                addressTotal.JIBUN_FIRST = addr.land.number1;
                addressTotal.JIBUN_SECOND = addr.land.number2;

                if (road != null)
                {
                    addressTotal.ROAD_NAME = road.land.name;
                    addressTotal.BLD_FIRST = road.land.number1;
                    addressTotal.BLD_SECOND = road.land.number2;
                    addressTotal.BLD_DETAILNAME = road.land.addition0.value;
                }
                else
                {
                    addressTotal.ROAD_NAME = string.Empty;
                    addressTotal.BLD_FIRST = string.Empty;
                    addressTotal.BLD_SECOND = string.Empty;
                    addressTotal.BLD_DETAILNAME = string.Empty;
                }

                addressTotal.LON = Convert.ToDouble(geo.x);
                addressTotal.LAT = Convert.ToDouble(geo.y);

                var umdr = addressTotal.RI_NAME.Length > 0 ? string.Join(' ', addressTotal.DONG_NAME, addressTotal.RI_NAME) : addressTotal.DONG_NAME;

                var master_sub = addressTotal.JIBUN_SECOND.Length > 0 ? string.Join('-', addressTotal.JIBUN_FIRST, addressTotal.JIBUN_SECOND) : addressTotal.JIBUN_FIRST;

                var build_master_sub = addressTotal.BLD_SECOND.Length > 0 ? string.Join('-', addressTotal.BLD_FIRST, addressTotal.BLD_SECOND) : addressTotal.BLD_FIRST;

                addressTotal.jibunAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    umdr,
                    master_sub);

                addressTotal.roadAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    addressTotal.ROAD_NAME,
                    build_master_sub
                    );
                return addressTotal;
            }

            return null;
        }
      
        [HttpGet("hgeocode")]
        public async Task<dynamic> HGeocode(string address)
        {
            var temp = await api.Geocoding(address);

            if (temp.addresses != null && temp.addresses.Count > 0)
            {
                var geo = temp.addresses[0];

                var reverse = await api.ReverseGeocoding(Convert.ToDouble(geo.x), Convert.ToDouble(geo.y));

                var adm = reverse.results.Find(x => x.name.Equals("admcode"));
                var addr = reverse.results.Find(x => x.name.Equals("addr"));
                var legal = reverse.results.Find(x => x.name.Equals("legalcode"));
                var road = reverse.results.Find(x => x.name.Equals("roadaddr"));

                AddressTotal addressTotal = new AddressTotal();
                addressTotal.SIDO_NAME = addr.region.area1.name;
                addressTotal.SIGUNGU_NAME = addr.region.area2.name;
                addressTotal.DONG_NAME = addr.region.area3.name;
                addressTotal.RI_NAME = addr.region.area4.name;
                addressTotal.JIBUN_FIRST = addr.land.number1;
                addressTotal.JIBUN_SECOND = addr.land.number2;

                addressTotal.HDONG_NAME = adm == null ? "" : adm.region.area3.name;

                if (road != null)
                {
                    addressTotal.ROAD_NAME = road.land.name;
                    addressTotal.BLD_FIRST = road.land.number1;
                    addressTotal.BLD_SECOND = road.land.number2;
                    addressTotal.BLD_DETAILNAME = road.land.addition0.value;
                }
                else
                {
                    addressTotal.ROAD_NAME = string.Empty;
                    addressTotal.BLD_FIRST = string.Empty;
                    addressTotal.BLD_SECOND = string.Empty;
                    addressTotal.BLD_DETAILNAME = string.Empty;
                }


                addressTotal.LON = Convert.ToDouble(geo.x);
                addressTotal.LAT = Convert.ToDouble(geo.y);

                //  행정동이 없는 지역이 존재
                var umd = addressTotal.HDONG_NAME.Length > 0 ? addressTotal.HDONG_NAME : addressTotal.DONG_NAME;

                // 읍면동리 결합
                var umdr = addressTotal.RI_NAME.Length > 0 ? string.Join(
                    ' ',
                    umd,
                    addressTotal.RI_NAME) :
                    umd;

                // 지번 결합
                var master_sub = addressTotal.JIBUN_SECOND.Length > 0 ? string.Join('-', addressTotal.JIBUN_FIRST, addressTotal.JIBUN_SECOND) : addressTotal.JIBUN_FIRST;

                // 건물 번호 결합
                var build_master_sub = addressTotal.BLD_SECOND.Length > 0 ? string.Join('-', addressTotal.BLD_FIRST, addressTotal.BLD_SECOND) : addressTotal.BLD_FIRST;

                addressTotal.jibunAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    umdr,
                    master_sub);

                addressTotal.roadAddress = string.Join(
                    ' ',
                    addressTotal.SIDO_NAME,
                    addressTotal.SIGUNGU_NAME,
                    addressTotal.ROAD_NAME,
                    build_master_sub
                    );
                return addressTotal;
            }

            return null;
        }

        [HttpGet("reverse")]
        public async Task<dynamic> ReverseGeocode(double x, double y)
        {
            var reverse = await api.ReverseGeocoding(x, y);

            if (reverse != null)
            {
                if (reverse.results.Count > 0)
                {
                    var adm = reverse.results.Find(x => x.name.Equals("admcode"));
                    var addr = reverse.results.Find(x => x.name.Equals("addr"));
                    var legal = reverse.results.Find(x => x.name.Equals("legalcode"));
                    var road = reverse.results.Find(x => x.name.Equals("roadaddr"));

                    AddressTotal addressTotal = new AddressTotal();
                    addressTotal.SIDO_NAME = addr.region.area1.name;
                    addressTotal.SIGUNGU_NAME = addr.region.area2.name;
                    addressTotal.DONG_NAME = addr.region.area3.name;
                    addressTotal.RI_NAME = addr.region.area4.name;
                    
                    addressTotal.JIBUN_FIRST = addr.land.number1;
                    addressTotal.JIBUN_SECOND = addr.land.number2;

                    addressTotal.LON = x;
                    addressTotal.LAT = y;


                    if (road == null)
                    {
                        addressTotal.ROAD_NAME = string.Empty;
                        addressTotal.BLD_FIRST = string.Empty;
                        addressTotal.BLD_SECOND = string.Empty;
                        addressTotal.BLD_DETAILNAME = string.Empty;
                    }
                    else
                    {
                        addressTotal.ROAD_NAME = road.land.name;
                        addressTotal.BLD_FIRST = road.land.number1;
                        addressTotal.BLD_SECOND = road.land.number2;
                        addressTotal.BLD_DETAILNAME = road.land.addition0.value;
                    }
                    
                    addressTotal.HDONG_NAME = adm == null ? "" : adm.region.area3.name;

                    // 읍면동리 결합
                    var umdr = addressTotal.RI_NAME.Length > 0 ? string.Join(
                        ' ',
                        addressTotal.DONG_NAME,
                        addressTotal.RI_NAME) :
                        addressTotal.DONG_NAME;

                    // 지번 결합
                    var master_sub = addressTotal.JIBUN_SECOND.Length > 0 ? string.Join('-', addressTotal.JIBUN_FIRST, addressTotal.JIBUN_SECOND) : addressTotal.JIBUN_FIRST;

                    // 건물 번호 결합
                    var build_master_sub = addressTotal.BLD_SECOND.Length > 0 ? string.Join('-', addressTotal.BLD_FIRST, addressTotal.BLD_SECOND) : addressTotal.BLD_FIRST;

                    addressTotal.jibunAddress = string.Join(
                        ' ',
                        addressTotal.SIDO_NAME,
                        addressTotal.SIGUNGU_NAME,
                        umdr,
                        master_sub);

                    addressTotal.roadAddress = string.Join(
                        ' ',
                        addressTotal.SIDO_NAME,
                        addressTotal.SIGUNGU_NAME,
                        addressTotal.ROAD_NAME,
                        build_master_sub
                        );
                    return addressTotal;
                }
            }

            return null;
        }

        [HttpGet("hreverse")]
        public async Task<dynamic> HReverseGeocode(double x, double y)
        {
            var reverse = await api.ReverseGeocoding(x, y);

            if (reverse != null)
            {
                if (reverse.results.Count > 0)
                {
                    var adm = reverse.results.Find(x => x.name.Equals("admcode"));
                    var addr = reverse.results.Find(x => x.name.Equals("addr"));
                    var legal = reverse.results.Find(x => x.name.Equals("legalcode"));
                    var road = reverse.results.Find(x => x.name.Equals("roadaddr"));

                    AddressTotal addressTotal = new AddressTotal();
                    addressTotal.SIDO_NAME = addr.region.area1.name;
                    addressTotal.SIGUNGU_NAME = addr.region.area2.name;
                    addressTotal.DONG_NAME = addr.region.area3.name;
                    addressTotal.HDONG_NAME = adm.region.area3.name;
                    addressTotal.RI_NAME = addr.region.area4.name;
                    
                    addressTotal.JIBUN_FIRST = addr.land.number1;
                    addressTotal.JIBUN_SECOND = addr.land.number2;
                    
                    addressTotal.LON = x;
                    addressTotal.LAT = y;


                    if( road == null)
                    {
                        addressTotal.ROAD_NAME = string.Empty;
                        addressTotal.BLD_FIRST = string.Empty;
                        addressTotal.BLD_SECOND = string.Empty;
                        addressTotal.BLD_DETAILNAME = string.Empty;
                    }
                    else
                    {
                        addressTotal.ROAD_NAME = road.land.name;
                        addressTotal.BLD_FIRST = road.land.number1;
                        addressTotal.BLD_SECOND = road.land.number2;
                        addressTotal.BLD_DETAILNAME = road.land.addition0.value;
                    }

                    //  행정동이 없는 지역이 존재
                    var umd = addressTotal.HDONG_NAME.Length > 0 ? addressTotal.HDONG_NAME : addressTotal.DONG_NAME;

                    // 읍면동리 결합
                    var umdr = addressTotal.RI_NAME.Length > 0 ? string.Join(
                        ' ',
                        umd,
                        addressTotal.RI_NAME) :
                        umd;

                    // 지번 결합
                    var master_sub = addressTotal.JIBUN_SECOND.Length > 0 ? string.Join('-', addressTotal.JIBUN_FIRST, addressTotal.JIBUN_SECOND) : addressTotal.JIBUN_FIRST;

                    // 건물 번호 결합
                    var build_master_sub = addressTotal.BLD_SECOND.Length > 0 ? string.Join('-', addressTotal.BLD_FIRST, addressTotal.BLD_SECOND) : addressTotal.BLD_FIRST;

                    addressTotal.jibunAddress = string.Join(
                        ' ',
                        addressTotal.SIDO_NAME,
                        addressTotal.SIGUNGU_NAME,
                        umdr,
                        master_sub);

                    addressTotal.roadAddress = string.Join(
                        ' ',
                        addressTotal.SIDO_NAME,
                        addressTotal.SIGUNGU_NAME,
                        addressTotal.ROAD_NAME,
                        build_master_sub
                        );
                    return addressTotal;
                }
            }

            return null;
        }
    }
}
