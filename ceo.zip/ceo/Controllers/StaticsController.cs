﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Common;
using PosWebApp.Models.RequestModel;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using PosWebApp.ViewModels.Statics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UAParser;

namespace PosWebApp.Controllers
{
    [SessionDgShop]
    public class StaticsController : Controller
    {
        private readonly DgShopApiService dgShop;
        private readonly int detailRow = 8;
        private readonly int currentRow = 7;
        private readonly NLog.Logger nlogger;

        public StaticsController(DgShopApiService dgShop)
        {
            this.dgShop = dgShop;
            nlogger = NLog.LogManager.GetCurrentClassLogger();
        }

        public IActionResult Index(StaticsViewModel viewmodel = null)
        {
            if (viewmodel.from_date == null)
            {
                viewmodel.from_date = DateTime.Now.ToString("yyyy-MM-dd");
                viewmodel.to_date = DateTime.Now.ToString("yyyy-MM-dd");
                viewmodel.category = "일자별";
                viewmodel.option = "all";
            }

            if (viewmodel.day_gbn == 0)
            {
                viewmodel.day_gbn = 2;
            }

            return View(viewmodel);
        }
        public async Task<IActionResult> Sales(RequestShopSalesList model)
        {
            if (model.from_date == null)
            {
                model.from_date = DateTime.Now.ToString("yyyy-MM-dd");
                model.to_date = DateTime.Now.ToString("yyyy-MM-dd");
                model.options = "0";
            }
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            long salesTotal = 0;
            long realTotal = 0;
            RequestShopSalesList reqData = new RequestShopSalesList
            {
                cccode = info.cccode,
                from_date = model.from_date.Replace("-", ""),
                to_date = model.to_date.Replace("-", ""),
                job_gbn = ((int)SalesType.SALSE_V2).ToString(),
                shop_cd = info.shop_cd,
                pack_order_yn = model.pack_order_yn,
                app_order_gbn = null,
                pay_gbn = null
            };

            //var salesReq = await dgShop.Post<ResponseShopSalesList, RequestShopSalesList>("sales_v2", reqData);
            var salesReq = await dgShop.Post<ResponseShopSalesList, RequestShopSalesList>("/api/ShopManagement/sales_v3", reqData);
            foreach (var item in salesReq.data)
            {
                salesTotal += Convert.ToInt64(item.app_menu_amount) + (Math.Abs(Convert.ToInt64(item.meet_menu_amount))) + Convert.ToInt64(item.app_tip_amount) + Math.Abs(Convert.ToInt64(item.meet_tip_amount));
                realTotal += Convert.ToInt64(item.total_amount);
            }
            
           
            ViewBag.salesTotal = Utils.NumberFormat(salesTotal);
            ViewBag.realTotal = Utils.NumberFormat(realTotal);

            return View(model);
        }
        public async Task<IActionResult> SalesList(RequestShopSalesList model, int? pageNumber)
        {
            return ViewComponent("SalesList",new
            {
                model = model,
                pageNumber = pageNumber
            });
        }
        [HttpPost]
        public async Task<IActionResult> ExcelStatics(string from_date, string to_date, string option)
        {

            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);
            
            var fixupValue = "";

            int detailTotCount = 0;
            int detailOkCount = 0;
            int detailTotAmt = 0;
            int detailCancelConunt = 0;
            int detailCancelAmt = 0;
            int detailDisCountAmt = 0;
            int detailAmt = 0;

            if (!string.IsNullOrEmpty(option))
            {
                switch (option)
                {
                    case "all":
                        fixupValue = "%";
                        break;
                    case "d":
                        fixupValue = "N";
                        break;
                    case "f":
                        fixupValue = "Y";
                        break;
                    default:
                        fixupValue = "%";
                        break;

                }
            }
           
            try
            {
                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("매출");
                    worksheet.Cell(1, 1).Value = "대구로";
                    worksheet.Cell(1, 1).Style.Font.SetFontSize(23);
                    worksheet.Range(worksheet.Cell(1, 1), worksheet.Cell(2, 10)).Merge();
                    worksheet.Cell(1, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(1, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    worksheet.Cell(3, 1).Value = "매출 현황";
                    worksheet.Range(worksheet.Cell(3, 1), worksheet.Cell(3, 10)).Merge();
                    worksheet.Cell(3, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(3, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    worksheet.Cell(4, 1).Value = "조회일 :" + DateTime.Now.ToString("yyyy-MM-dd");
                    worksheet.Range(worksheet.Cell(4, 1), worksheet.Cell(4, 10)).Merge();
                    worksheet.Cell(4, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;

                    worksheet.Cell(5, 1).Value = "검색 기간 :" + from_date + "~" + to_date;
                    worksheet.Range(worksheet.Cell(5, 1), worksheet.Cell(5, 10)).Merge();
                    worksheet.Cell(5, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;

                    worksheet.Cell(1, 2).Value = "총거래 건수";
                    worksheet.Cell(1, 3).Value = "총 매출액";
                    worksheet.Cell(1, 4).Value = "실 매출액";

                    if (option.Equals("d") || option.Equals("all"))
                    {
                        /*리스트 해더*/
                        worksheet.Cell(currentRow, 1).Value = "주문유형";
                        worksheet.Cell(currentRow, 2).Value = "결제형태";
                        worksheet.Cell(currentRow, 3).Value = "매출구분";
                        worksheet.Cell(currentRow, 4).Value = "총 거래 건수";
                        worksheet.Cell(currentRow, 5).Value = "거래완료 건수";
                        worksheet.Cell(currentRow, 6).Value = "거래취소 건수";
                        worksheet.Cell(currentRow, 7).Value = "총 매출액";
                        worksheet.Cell(currentRow, 8).Value = "취소금액";
                        worksheet.Cell(currentRow, 9).Value = "할인 금액";
                        worksheet.Cell(currentRow, 10).Value = "실 매출액";

                        worksheet.Range(worksheet.Cell(currentRow, 1), worksheet.Cell(currentRow, 10)).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        worksheet.Range(worksheet.Cell(currentRow, 1), worksheet.Cell(currentRow, 10)).Style.Fill.BackgroundColor = XLColor.Black;
                        worksheet.Range(worksheet.Cell(currentRow, 1), worksheet.Cell(currentRow, 10)).Style.Font.SetFontColor(XLColor.White);
                    }
                    else if (option.Equals("f"))
                    {
                        worksheet.Cell(currentRow + 6, 1).Value = "주문유형";
                        worksheet.Cell(currentRow + 6, 2).Value = "결제형태";
                        worksheet.Cell(currentRow + 6, 3).Value = "매출구분";
                        worksheet.Cell(currentRow + 6, 4).Value = "총 거래 건수";
                        worksheet.Cell(currentRow + 6, 5).Value = "거래완료 건수";
                        worksheet.Cell(currentRow + 6, 6).Value = "거래취소 건수";
                        worksheet.Cell(currentRow + 6, 7).Value = "총 매출액";
                        worksheet.Cell(currentRow + 6, 8).Value = "취소금액";
                        worksheet.Cell(currentRow + 6, 9).Value = "할인 금액";
                        worksheet.Cell(currentRow + 6, 10).Value = "실 매출액";

                        worksheet.Range(worksheet.Cell(currentRow + 6, 1), worksheet.Cell(currentRow + 6, 10)).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        worksheet.Range(worksheet.Cell(currentRow + 6, 1), worksheet.Cell(currentRow + 6, 10)).Style.Fill.BackgroundColor = XLColor.Black;
                        worksheet.Range(worksheet.Cell(currentRow + 6, 1), worksheet.Cell(currentRow + 6, 10)).Style.Font.SetFontColor(XLColor.White);
                    }
                    /*리스트 해더 주문유형 */
                    if (option.Equals("d") || option.Equals("all"))
                    {
                        worksheet.Cell(8, 1).Value = "배 달";
                        worksheet.Range(worksheet.Cell(8, 1), worksheet.Cell(13, 1)).Merge();
                        worksheet.Cell(8, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        worksheet.Cell(8, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                    }
                    if (option.Equals("f") || option.Equals("all"))
                    {
                        worksheet.Cell(14, 1).Value = "포 장";
                        worksheet.Range(worksheet.Cell(14, 1), worksheet.Cell(19, 1)).Merge();
                        worksheet.Cell(14, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        worksheet.Cell(14, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                    }


                    if (option.Equals("d") || option.Equals("all"))
                    {
                        /*리스트 해더 결제형태*/
                        worksheet.Cell(8, 2).Value = "대구로앱";
                        worksheet.Range(worksheet.Cell(8, 2), worksheet.Cell(10, 2)).Merge();
                        worksheet.Cell(8, 2).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        worksheet.Cell(8, 2).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                        worksheet.Cell(11, 2).Value = "만나서";
                        worksheet.Range(worksheet.Cell(11, 2), worksheet.Cell(13, 2)).Merge();
                        worksheet.Cell(11, 2).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        worksheet.Cell(11, 2).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                        /*리스트 해더 매출구분*/

                        worksheet.Cell(8, 3).Value = "카드";
                        worksheet.Cell(9, 3).Value = "현금";
                        worksheet.Cell(10, 3).Value = "행복페이";
                        worksheet.Cell(11, 3).Value = "카드";
                        worksheet.Cell(12, 3).Value = "현금";
                        worksheet.Cell(13, 3).Value = "행복페이";

                        worksheet.Range(worksheet.Cell(8, 3), worksheet.Cell(13, 3)).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    }
                    if (option.Equals("f") || option.Equals("all"))
                    {
                        worksheet.Cell(14, 2).Value = "대구로앱";
                        worksheet.Range(worksheet.Cell(14, 2), worksheet.Cell(16, 2)).Merge();
                        worksheet.Cell(14, 2).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        worksheet.Cell(14, 2).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                        worksheet.Cell(17, 2).Value = "만나서";
                        worksheet.Range(worksheet.Cell(17, 2), worksheet.Cell(19, 2)).Merge();
                        worksheet.Cell(17, 2).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        worksheet.Cell(17, 2).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                        /*리스트 해더 매출구분*/

                        worksheet.Cell(14, 3).Value = "카드";
                        worksheet.Cell(15, 3).Value = "현금";
                        worksheet.Cell(16, 3).Value = "행복페이";
                        worksheet.Cell(17, 3).Value = "카드";
                        worksheet.Cell(18, 3).Value = "현금";
                        worksheet.Cell(19, 3).Value = "행복페이";

                        worksheet.Range(worksheet.Cell(14, 3), worksheet.Cell(19, 3)).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    }
                    #region Detail info
                    /*상세내역*/

                    var detailWorkSheet = workbook.AddWorksheet("매출상세내역");
                    detailWorkSheet.Cell(detailRow - 1, 1).Value = "매출일";
                    detailWorkSheet.Cell(detailRow - 1, 2).Value = "결제형태";
                    detailWorkSheet.Cell(detailRow - 1, 3).Value = "매출구분";
                    detailWorkSheet.Cell(detailRow - 1, 4).Value = "총 거래 건수";
                    detailWorkSheet.Cell(detailRow - 1, 5).Value = "거래완료 건수";
                    detailWorkSheet.Cell(detailRow - 1, 6).Value = "거래취소 건수";
                    detailWorkSheet.Cell(detailRow - 1, 7).Value = "총 매출액";
                    detailWorkSheet.Cell(detailRow - 1, 8).Value = "취소금액";
                    detailWorkSheet.Cell(detailRow - 1, 9).Value = "할인 금액";
                    detailWorkSheet.Cell(detailRow - 1, 10).Value = "실 매출액";

                    detailWorkSheet.Range(detailWorkSheet.Cell(detailRow - 1, 1), detailWorkSheet.Cell(detailRow - 1, 10)).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Range(detailWorkSheet.Cell(detailRow - 1, 1), detailWorkSheet.Cell(detailRow - 1, 10)).Style.Fill.BackgroundColor = XLColor.Black;
                    detailWorkSheet.Range(detailWorkSheet.Cell(detailRow - 1, 1), detailWorkSheet.Cell(detailRow - 1, 10)).Style.Font.SetFontColor(XLColor.White);
                    detailWorkSheet.Range(detailWorkSheet.Cell(detailRow - 1, 1), detailWorkSheet.Cell(detailRow - 1, 10)).Style
                        .Border.SetTopBorder(XLBorderStyleValues.Thin)
                        .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                        .Border.SetLeftBorder(XLBorderStyleValues.Thin)
                        .Border.SetRightBorder(XLBorderStyleValues.Thin);

                    var currentDetail = await dgShop.Post<ResponseShopSalesList, RequestShopSalesList>("sales", new RequestShopSalesList
                    {
                        cccode = info.cccode,
                        from_date = from_date.Replace("-", ""),
                        to_date = to_date.Replace("-", ""),
                        job_gbn = ((int)SalesType.CURRENT_DETAIL).ToString(),
                        shop_cd = info.shop_cd,
                        pack_order_yn = fixupValue
                    });
                    for (int i = 0; i < currentDetail.data.Count(); i++)
                    {
                        detailWorkSheet.Cell(detailRow + i, 1).Value = currentDetail.data[i].order_date;
                        detailWorkSheet.Cell(detailRow + i, 2).Value = currentDetail.data[i].app_pay_gbn_name;
                        detailWorkSheet.Cell(detailRow + i, 3).Value = currentDetail.data[i].pay_gbn_name;
                        detailWorkSheet.Cell(detailRow + i, 4).Value = currentDetail.data[i].total_count.Equals("") ? "" : currentDetail.data[i].total_count;
                        detailWorkSheet.Cell(detailRow + i, 5).Value = currentDetail.data[i].ok_count.Equals("") ? "" : currentDetail.data[i].ok_count;
                        detailWorkSheet.Cell(detailRow + i, 6).Value = currentDetail.data[i].cancel_count.Equals("") ? "" : currentDetail.data[i].cancel_count;
                        detailWorkSheet.Cell(detailRow + i, 7).Value = currentDetail.data[i].total_amount.Equals("") ? "" : currentDetail.data[i].total_amount;
                        detailWorkSheet.Cell(detailRow + i, 8).Value = currentDetail.data[i].cancel_amount.Equals("") ? "" : currentDetail.data[i].cancel_amount;
                        detailWorkSheet.Cell(detailRow + i, 9).Value = currentDetail.data[i].discount_amount.Equals("") ? "" : currentDetail.data[i].discount_amount;
                        detailWorkSheet.Cell(detailRow + i, 10).Value = currentDetail.data[i].amount.Equals("") ? "" : currentDetail.data[i].amount;


                        detailWorkSheet.Cell(detailRow + i, 4).Style.NumberFormat.Format = "#,##0";
                        detailWorkSheet.Cell(detailRow + i, 5).Style.NumberFormat.Format = "#,##0";
                        detailWorkSheet.Cell(detailRow + i, 6).Style.NumberFormat.Format = "#,##0";
                        detailWorkSheet.Cell(detailRow + i, 7).Style.NumberFormat.Format = "#,##0";
                        detailWorkSheet.Cell(detailRow + i, 8).Style.NumberFormat.Format = "#,##0";
                        detailWorkSheet.Cell(detailRow + i, 9).Style.NumberFormat.Format = "#,##0";
                        detailWorkSheet.Cell(detailRow + i, 10).Style.NumberFormat.Format = "#,##0";

                        detailWorkSheet.Range(detailWorkSheet.Cell(detailRow + i, 1), detailWorkSheet.Cell(detailRow + i, 10)).Style
                           .Border.SetTopBorder(XLBorderStyleValues.Thin)
                           .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                           .Border.SetLeftBorder(XLBorderStyleValues.Thin)
                           .Border.SetRightBorder(XLBorderStyleValues.Thin);

                        detailTotCount += Convert.ToInt32(currentDetail.data[i].total_count);
                        detailTotAmt += Convert.ToInt32(currentDetail.data[i].total_amount);
                        detailAmt += Convert.ToInt32(currentDetail.data[i].amount);
                        detailCancelAmt += Convert.ToInt32(currentDetail.data[i].cancel_amount);
                        detailCancelConunt += Convert.ToInt32(currentDetail.data[i].cancel_count);
                        detailOkCount += Convert.ToInt32(currentDetail.data[i].ok_count);
                        detailDisCountAmt += Convert.ToInt32(currentDetail.data[i].discount_amount);


                    }
                    detailWorkSheet.Cell(1, 1).Value = "대구로";
                    detailWorkSheet.Cell(1, 1).Style.Font.SetFontSize(23);
                    detailWorkSheet.Range(detailWorkSheet.Cell(1, 1), detailWorkSheet.Cell(2, 10)).Merge();
                    detailWorkSheet.Cell(1, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(1, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    detailWorkSheet.Cell(3, 1).Value = "매출 상세내역";
                    detailWorkSheet.Range(detailWorkSheet.Cell(3, 1), detailWorkSheet.Cell(3, 10)).Merge();
                    detailWorkSheet.Cell(3, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(3, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    detailWorkSheet.Cell(4, 1).Value = "조회일 :" + DateTime.Now.ToString("yyyy-MM-dd");
                    detailWorkSheet.Range(detailWorkSheet.Cell(4, 1), detailWorkSheet.Cell(4, 10)).Merge();
                    detailWorkSheet.Cell(4, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;

                    detailWorkSheet.Cell(5, 1).Value = "검색 기간 :" + from_date + "~" + to_date;
                    detailWorkSheet.Range(detailWorkSheet.Cell(5, 1), detailWorkSheet.Cell(5, 10)).Merge();
                    detailWorkSheet.Cell(5, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;

                    var TotalRow = currentDetail.data.Count();
                    detailWorkSheet.Cell(detailRow + (TotalRow), 1).Value = "총 합";
                    detailWorkSheet.Range(detailWorkSheet.Cell(detailRow + (TotalRow), 1), detailWorkSheet.Cell(detailRow + (TotalRow), 3)).Merge();
                    detailWorkSheet.Cell(detailRow + (TotalRow), 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(detailRow + (TotalRow), 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    detailWorkSheet.Cell(detailRow + (TotalRow), 4).Value = detailTotCount;
                    detailWorkSheet.Cell(detailRow + (TotalRow), 5).Value = detailOkCount;
                    detailWorkSheet.Cell(detailRow + (TotalRow), 6).Value = detailCancelConunt;
                    detailWorkSheet.Cell(detailRow + (TotalRow), 7).Value = detailTotAmt;
                    detailWorkSheet.Cell(detailRow + (TotalRow), 8).Value = detailCancelAmt;
                    detailWorkSheet.Cell(detailRow + (TotalRow), 9).Value = detailDisCountAmt;
                    detailWorkSheet.Cell(detailRow + (TotalRow), 10).Value = detailAmt;

                    detailWorkSheet.Cell(detailRow + (TotalRow), 4).Style.NumberFormat.Format = "#,##0";
                    detailWorkSheet.Cell(detailRow + (TotalRow), 5).Style.NumberFormat.Format = "#,##0";
                    detailWorkSheet.Cell(detailRow + (TotalRow), 6).Style.NumberFormat.Format = "#,##0";
                    detailWorkSheet.Cell(detailRow + (TotalRow), 7).Style.NumberFormat.Format = "#,##0";
                    detailWorkSheet.Cell(detailRow + (TotalRow), 8).Style.NumberFormat.Format = "#,##0";
                    detailWorkSheet.Cell(detailRow + (TotalRow), 9).Style.NumberFormat.Format = "#,##0";
                    detailWorkSheet.Cell(detailRow + (TotalRow), 10).Style.NumberFormat.Format = "#,##0";

                    detailWorkSheet.Range(detailWorkSheet.Cell(detailRow + (TotalRow), 1), detailWorkSheet.Cell(detailRow + (TotalRow), 10)).Style
                       .Border.SetTopBorder(XLBorderStyleValues.Thin)
                       .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                       .Border.SetLeftBorder(XLBorderStyleValues.Thin)
                       .Border.SetRightBorder(XLBorderStyleValues.Thin);

                    detailWorkSheet.Columns("A", "J").Width = 22;
                    detailWorkSheet.Rows().AdjustToContents();
                    #endregion
                    var totResult = await dgShop.Post<ResponseShopSalesList, RequestShopSalesList>("sales", new RequestShopSalesList
                    {
                        cccode = info.cccode,
                        from_date = from_date.Replace("-", ""),
                        to_date = to_date.Replace("-", ""),
                        job_gbn = ((int)SalesType.TOTAL).ToString(),
                        shop_cd = info.shop_cd,
                        pack_order_yn = fixupValue
                    });
                    var resultList = totResult.data.ToList();
                    for (int i = 1; i <= resultList.Count(); i++)
                    {
                        //worksheet.Cell(i + 3, 2).Value = resultList[i - 1].total_count.Equals("") ? "0" : resultList[i - 1].total_count;
                        //worksheet.Cell(i + 3, 3).Value = resultList[i - 1].total_amount.Equals("") ? "0" : resultList[i - 1].total_amount;
                        //worksheet.Cell(i + 1, 4).Value = resultList[i - 1].amount.Equals("") ? "0" : resultList[i - 1].amount;
                    }
                    var currentResult = await dgShop.Post<ResponseShopSalesList, RequestShopSalesList>("sales", new RequestShopSalesList
                    {
                        cccode = info.cccode,
                        from_date = from_date.Replace("-", ""),
                        to_date = to_date.Replace("-", ""),
                        job_gbn = ((int)SalesType.CURRENT).ToString(),
                        shop_cd = info.shop_cd,
                        pack_order_yn = fixupValue
                    });
                    var sortResult = currentResult.data;
                    var currentList = new List<StaticsListViewModel>();
                    StaticsListViewModel currentDictionary = new StaticsListViewModel();
                    #region current List databinding 
                    /*리스트 데이터 바인딩 */
                    foreach (var item in sortResult)
                    {

                        if (item.pack_order_name.Equals("배달"))
                        {
                            if (item.app_pay_gbn_name.Equals("대구로앱"))
                            {
                                if (item.pay_gbn_name.Equals("카드"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };

                                }
                                else if (item.pay_gbn_name.Equals("현금"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };


                                }
                                else if (item.pay_gbn_name.Equals("행복페이"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };

                                }
                            }
                            else if (item.app_pay_gbn_name.Equals("만나서"))
                            {
                                if (item.pay_gbn_name.Equals("카드"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };

                                }
                                else if (item.pay_gbn_name.Equals("현금"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };

                                }
                                else if (item.pay_gbn_name.Equals("행복페이"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };

                                }
                            }
                        }
                        else if (item.pack_order_name.Equals("포장"))
                        {
                            if (item.app_pay_gbn_name.Equals("대구로앱"))
                            {
                                if (item.pay_gbn_name.Equals("카드"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };

                                }
                                else if (item.pay_gbn_name.Equals("현금"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };

                                }
                                else if (item.pay_gbn_name.Equals("행복페이"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };

                                }
                            }
                            else if (item.app_pay_gbn_name.Equals("만나서"))
                            {
                                if (item.pay_gbn_name.Equals("카드"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };

                                }
                                else if (item.pay_gbn_name.Equals("현금"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };

                                }
                                else if (item.pay_gbn_name.Equals("행복페이"))
                                {
                                    currentDictionary.deliveryItems[item.pack_order_name].salseItems[item.app_pay_gbn_name].paysItems[(item.pay_gbn_name)] = new StaticsListItem
                                    {
                                        amount = item.amount,
                                        cancel_amount = item.cancel_amount,
                                        cancel_count = item.cancel_count,
                                        discount_amount = item.discount_amount,
                                        ok_amount = item.ok_amount,
                                        ok_count = item.ok_count,
                                        total_amount = item.total_amount,
                                        total_count = item.total_count
                                    };
                                }
                            }
                        }
                    }
                    /*리스트 데이터 출력 */
                    foreach (var item in currentDictionary.deliveryItems.Keys)
                    {
                        if (option.Equals("d") || option.Equals("all"))
                        {
                            if (item.Equals("배달"))
                            {
                                foreach (var delivery in currentDictionary.deliveryItems[item].salseItems.Keys)
                                {
                                    if (delivery.Equals("대구로앱"))
                                    {
                                        foreach (var pay in currentDictionary.deliveryItems[item].salseItems[delivery].paysItems)
                                        {
                                            if (pay.Key.Equals("카드"))
                                            {
                                                worksheet.Cell(8, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(8, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(8, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(8, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(8, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(8, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(8, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;

                                                worksheet.Cell(8, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(8, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(8, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(8, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(8, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(8, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(8, 10).Style.NumberFormat.Format = "#,##0";
                                            }
                                            else if (pay.Key.Equals("현금"))
                                            {
                                                worksheet.Cell(9, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(9, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(9, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(9, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(9, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(9, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(9, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;


                                                worksheet.Cell(9, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(9, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(9, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(9, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(9, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(9, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(9, 10).Style.NumberFormat.Format = "#,##0";
                                            }
                                            else if (pay.Key.Equals("행복페이"))
                                            {
                                                worksheet.Cell(10, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(10, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(10, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(10, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(10, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(10, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(10, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;

                                                worksheet.Cell(10, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(10, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(10, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(10, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(10, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(10, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(10, 10).Style.NumberFormat.Format = "#,##0";
                                            }
                                        }
                                    }
                                    else if (delivery.Equals("만나서"))
                                    {
                                        foreach (var pay in currentDictionary.deliveryItems[item].salseItems[delivery].paysItems)
                                        {
                                            if (pay.Key.Equals("카드"))
                                            {
                                                worksheet.Cell(11, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(11, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(11, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(11, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(11, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(11, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(11, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;

                                                worksheet.Cell(11, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(11, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(11, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(11, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(11, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(11, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(11, 10).Style.NumberFormat.Format = "#,##0";
                                            }
                                            else if (pay.Key.Equals("현금"))
                                            {
                                                worksheet.Cell(12, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(12, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(12, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(12, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(12, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(12, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(12, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;

                                                worksheet.Cell(12, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(12, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(12, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(12, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(12, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(12, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(12, 10).Style.NumberFormat.Format = "#,##0";
                                            }
                                            else if (pay.Key.Equals("행복페이"))
                                            {
                                                worksheet.Cell(13, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(13, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(13, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(13, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(13, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(13, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(13, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;

                                                worksheet.Cell(13, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(13, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(13, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(13, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(13, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(13, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(13, 10).Style.NumberFormat.Format = "#,##0";
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (option.Equals("f") || option.Equals("all"))
                        {
                            if (item.Equals("포장"))
                            {
                                foreach (var delivery in currentDictionary.deliveryItems[item].salseItems.Keys)
                                {
                                    if (delivery.Equals("대구로앱"))
                                    {
                                        foreach (var pay in currentDictionary.deliveryItems[item].salseItems[delivery].paysItems)
                                        {
                                            if (pay.Key.Equals("카드"))
                                            {
                                                worksheet.Cell(14, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(14, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(14, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(14, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(14, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(14, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(14, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;

                                                worksheet.Cell(14, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(14, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(14, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(14, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(14, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(14, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(14, 10).Style.NumberFormat.Format = "#,##0";
                                            }
                                            else if (pay.Key.Equals("현금"))
                                            {
                                                worksheet.Cell(15, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(15, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(15, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(15, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(15, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(15, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(15, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;

                                                worksheet.Cell(15, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(15, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(15, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(15, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(15, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(15, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(15, 10).Style.NumberFormat.Format = "#,##0";

                                            }
                                            else if (pay.Key.Equals("행복페이"))
                                            {
                                                worksheet.Cell(16, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(16, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(16, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(16, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(16, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(16, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(16, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;

                                                worksheet.Cell(16, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(16, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(16, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(16, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(16, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(16, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(16, 10).Style.NumberFormat.Format = "#,##0";
                                            }
                                        }
                                    }
                                    else if (delivery.Equals("만나서"))
                                    {
                                        foreach (var pay in currentDictionary.deliveryItems[item].salseItems[delivery].paysItems)
                                        {
                                            if (pay.Key.Equals("카드"))
                                            {
                                                worksheet.Cell(17, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(17, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(17, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(17, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(17, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(17, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(17, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;

                                                worksheet.Cell(17, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(17, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(17, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(17, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(17, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(17, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(17, 10).Style.NumberFormat.Format = "#,##0";
                                            }
                                            else if (pay.Key.Equals("현금"))
                                            {
                                                worksheet.Cell(18, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(18, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(18, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(18, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(18, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(18, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(18, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;

                                                worksheet.Cell(18, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(18, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(18, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(18, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(18, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(18, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(18, 10).Style.NumberFormat.Format = "#,##0";
                                            }
                                            else if (pay.Key.Equals("행복페이"))
                                            {
                                                worksheet.Cell(19, 4).Value = pay.Value.total_count.Equals("") ? "0" : pay.Value.total_count;
                                                worksheet.Cell(19, 5).Value = pay.Value.ok_count.Equals("") ? "0" : pay.Value.ok_count;
                                                worksheet.Cell(19, 6).Value = pay.Value.cancel_count.Equals("") ? "0" : pay.Value.cancel_count;
                                                worksheet.Cell(19, 7).Value = pay.Value.total_amount.Equals("") ? "0" : pay.Value.total_amount;
                                                worksheet.Cell(19, 8).Value = pay.Value.cancel_amount.Equals("") ? "0" : pay.Value.cancel_amount;
                                                worksheet.Cell(19, 9).Value = pay.Value.discount_amount.Equals("") ? "0" : pay.Value.discount_amount;
                                                worksheet.Cell(19, 10).Value = pay.Value.amount.Equals("") ? "0" : pay.Value.amount;

                                                worksheet.Cell(19, 4).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(19, 5).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(19, 6).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(19, 7).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(19, 8).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(19, 9).Style.NumberFormat.Format = "#,##0";
                                                worksheet.Cell(19, 10).Style.NumberFormat.Format = "#,##0";
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    #endregion
                    worksheet.Columns("A", "J").Width = 22;
                    worksheet.Rows().AdjustToContents();
                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();
                        return File(content,
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            string.Concat("매출현황_", DateTime.Now.ToString("yyyyMMddHHmmss"), ".xlsx"));
                    }
                }
            }
            catch (Exception e)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        public async Task<IActionResult> ExcelSales(string from_date, string to_date)
        {
            string sessionString = HttpContext.Session.GetString("shopDefaultInfo");
            ShopSessionDefaultInfo info = new ShopSessionDefaultInfo();
            info = JsonConvert.DeserializeObject<ShopSessionDefaultInfo>(sessionString);

            long salesTotal = 0;
            long realTotal = 0;
            long clientSalesTotal = 0;
            long minusTotal = 0;
            long meetToatal = 0;

            RequestShopSalesList reqData = new RequestShopSalesList
            {
                cccode = info.cccode,
                from_date = from_date.Replace("-", ""),
                to_date = to_date.Replace("-", ""),
                job_gbn = ((int)SalesType.SALSE_V2).ToString(),
                shop_cd = info.shop_cd,
                pack_order_yn = "%",
                app_order_gbn = null,
                pay_gbn = null
            };

            var JsonBody = JsonConvert.SerializeObject(reqData);
            nlogger.Info($"[ CEO Statics Excel Data ,Shopcd === {info.shop_cd} body ==== {JsonBody}");
            var salesReq = await dgShop.Post<ResponseShopSalesList, RequestShopSalesList>("/api/ShopManagement/sales_v3", reqData);
            if(salesReq.data.Count() == 0)
            {
                return BadRequest(new
                {
                    Msg = "조회 내용이 존재하지않습니다."
                });
            }
            foreach (var item in salesReq.data)
            {
                salesTotal += Convert.ToInt64(item.tot_amount) + Math.Abs(Convert.ToInt64(item.delivery_total_amount));
                realTotal += Convert.ToInt64(item.total_amount);
                clientSalesTotal += Convert.ToInt64(item.total_disc_amount);
                minusTotal += Convert.ToInt64(item.total_fee_amount);
                meetToatal += Convert.ToInt64(item.delivery_total_amount);
            }
            nlogger.Info($"[ CEO Statics Excel Start ,Shopcd === {info.shop_cd}");
            try
            {
                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("매출");
                    worksheet.Cell(1, 1).Value = "대구로";
                    worksheet.Cell(1, 1).Style.Font.SetFontSize(23);
                    worksheet.Range(worksheet.Cell(1, 1), worksheet.Cell(2, 10)).Merge();
                    worksheet.Cell(1, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(1, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    worksheet.Cell(3, 1).Value = "매출 현황";
                    worksheet.Range(worksheet.Cell(3, 1), worksheet.Cell(3, 10)).Merge();
                    worksheet.Cell(3, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Cell(3, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    worksheet.Cell(4, 1).Value = "조회일 :" + DateTime.Now.ToString("yyyy-MM-dd");
                    worksheet.Range(worksheet.Cell(4, 1), worksheet.Cell(4, 10)).Merge();
                    worksheet.Cell(4, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;

                    worksheet.Cell(5, 1).Value = "검색 기간 :" + from_date + "~" + to_date;
                    worksheet.Range(worksheet.Cell(5, 1), worksheet.Cell(5, 10)).Merge();
                    worksheet.Cell(5, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;

                    worksheet.Cell(6, 1).Value = "구분";
                    worksheet.Cell(6, 2).Value = "금액";
                    worksheet.Range(worksheet.Cell(6, 1), worksheet.Cell(6, 2)).Style
                        .Border.SetTopBorder(XLBorderStyleValues.Thin)
                        .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                        .Fill.SetBackgroundColor(XLColor.LightGray);
                    worksheet.Cell(7, 1).Value = "총 매출액";
                    worksheet.Cell(7, 2).Value = salesTotal;
                    worksheet.Cell(8, 1).Value = "총 정산금액";
                    worksheet.Cell(8, 2).Value = realTotal;

                    worksheet.Range(worksheet.Cell(8, 1), worksheet.Cell(8, 2)).Style
                        .Border.SetBottomBorder(XLBorderStyleValues.Thin);
                    worksheet.Cell(7, 2).Style.NumberFormat.Format = "#,##0";
                    worksheet.Cell(8, 2).Style.NumberFormat.Format = "#,##0";

                    worksheet.Cell(10, 1).Value = "(A) 매출금액";
                    worksheet.Cell(10, 2).Value = "(B) 고객할인비용";
                    worksheet.Cell(10, 2).Comment.AddText("사장님이 고객에게 제공한 할인쿠폰 금액과 포장할인 금액입니다.");
                    worksheet.Cell(10, 2).Comment.Style.Size.SetAutomaticSize();
                    worksheet.Cell(10, 3).Value = "(C) 차감금액";
                    worksheet.Cell(10, 3).Comment
                        .AddText("중개수수료 또는 카드결제 시 발생하는 수수료입니다.\n" +
                        "1. 중개수수료 : 주문금액의 2% (부가세별도)\n" +
                        "2. PG수수료 : 결제금액의 2.2% (부가세별도)");
                    worksheet.Cell(10, 3).Comment.Style.Size.SetAutomaticSize();
                    worksheet.Cell(10, 4).Value = "(D) 만나서결제금액";
                    worksheet.Cell(10, 5).Value = "실 매출액";

                    worksheet.Range(worksheet.Cell(10, 1), worksheet.Cell(10, 5)).Style
                        .Border.SetTopBorder(XLBorderStyleValues.Thin)
                       .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                       .Fill.SetBackgroundColor(XLColor.LightGray);

                    worksheet.Cell(11, 1).Value = salesTotal;
                    worksheet.Cell(11, 2).Value = clientSalesTotal;
                    worksheet.Cell(11, 3).Value = minusTotal;
                    worksheet.Cell(11, 4).Value = meetToatal;
                    worksheet.Cell(11, 5).Value = realTotal;

                    worksheet.Range(worksheet.Cell(11, 1), worksheet.Cell(11, 5)).Style
                       .Border.SetBottomBorder(XLBorderStyleValues.Thin);

                    worksheet.Cell(11, 1).Style.NumberFormat.Format = "#,##0";
                    worksheet.Cell(11, 2).Style.NumberFormat.Format = "#,##0";
                    worksheet.Cell(11, 3).Style.NumberFormat.Format = "#,##0";
                    worksheet.Cell(11, 4).Style.NumberFormat.Format = "#,##0";
                    worksheet.Cell(11, 5).Style.NumberFormat.Format = "#,##0";


                    var detailWorkSheet = workbook.AddWorksheet("상세");
                    detailWorkSheet.Cell(1, 1).Value = "정산내역";
                    detailWorkSheet.Cell(1, 1).Style.Font.SetFontSize(23);
                    detailWorkSheet.Range(detailWorkSheet.Cell(1, 1), detailWorkSheet.Cell(2, 2)).Merge();
                    detailWorkSheet.Cell(1, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(1, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    detailWorkSheet.Cell(1 , 3).Value = "검색 기간 :" + from_date +  " ~ " + to_date;
                    detailWorkSheet.Range(detailWorkSheet.Cell(1,3), detailWorkSheet.Cell(2, 4)).Merge();
                    detailWorkSheet.Cell(1, 3).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(1, 3).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    detailWorkSheet.Range(detailWorkSheet.Cell(3, 1), detailWorkSheet.Cell(5, 11)).Style
                        .Border.SetTopBorder(XLBorderStyleValues.Thin)
                        .Border.SetBottomBorder(XLBorderStyleValues.Thin);
                    detailWorkSheet.Cell(3, 1).Value = "일자";
                    detailWorkSheet.Range(detailWorkSheet.Cell(3, 1), detailWorkSheet.Cell(5, 1)).Merge();
                    detailWorkSheet.Cell(3, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(3, 1).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                   

                    detailWorkSheet.Cell(3, 2).Value = "이용서비스";
                    detailWorkSheet.Range(detailWorkSheet.Cell(3, 2), detailWorkSheet.Cell(5, 2)).Merge();
                    detailWorkSheet.Cell(3, 2).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(3, 2).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;


                    detailWorkSheet.Cell(3, 3).Value = "(A) 매출금액";
                    detailWorkSheet.Range(detailWorkSheet.Cell(3, 3), detailWorkSheet.Cell(3, 6)).Merge();
                    detailWorkSheet.Cell(3, 3).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

                    detailWorkSheet.Cell(4, 3).Value = "주문금액";
                    detailWorkSheet.Range(detailWorkSheet.Cell(4, 3), detailWorkSheet.Cell(4, 4)).Merge();
                    detailWorkSheet.Cell(4, 3).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(4, 3).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    detailWorkSheet.Cell(5, 3).Value = "앱 결제 주문금액";
                    detailWorkSheet.Cell(5, 4).Value = "만나서 결제 주문금액";

                    detailWorkSheet.Cell(4, 5).Value = "배달팁";
                    detailWorkSheet.Range(detailWorkSheet.Cell(4, 5), detailWorkSheet.Cell(4, 6)).Merge();
                    detailWorkSheet.Cell(4, 5).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

                    detailWorkSheet.Cell(5, 5).Value = "앱 결제 배달팁";
                    detailWorkSheet.Cell(5, 6).Value = "만나서 결제 배달팁";


                    detailWorkSheet.Cell(3, 7).Value = "(B) 고객할인비용";
                    detailWorkSheet.Range(detailWorkSheet.Cell(3, 7), detailWorkSheet.Cell(4, 8)).Merge();
                    detailWorkSheet.Cell(3, 7).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(3, 7).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                    detailWorkSheet.Cell(3, 7).Comment.AddText("사장님이 고객에게 제공한 할인쿠폰 금액과 포장할인 금액입니다.");
                    detailWorkSheet.Cell(3, 7).Comment.Style.Size.SetAutomaticSize();
                    detailWorkSheet.Cell(5, 7).Value = "사장님부담쿠폰";
                    detailWorkSheet.Cell(5, 8).Value = "포장 할인";


                    detailWorkSheet.Cell(3, 9).Value = "(C) 차감금액";
                    detailWorkSheet.Range(detailWorkSheet.Cell(3, 9), detailWorkSheet.Cell(4, 10)).Merge();
                    detailWorkSheet.Cell(3, 9).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(3, 9).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                    detailWorkSheet.Cell(3, 9).Comment
                        .AddText("중개수수료 또는 카드결제 시 발생하는 수수료입니다.\n" +
                        "1. 중개수수료 : 주문금액의 2% (부가세별도)\n" +
                        "2. PG수수료 : 결제금액의 2.2% (부가세별도)");
                    detailWorkSheet.Cell(3, 9).Comment.Style.Size.SetAutomaticSize();
                    detailWorkSheet.Cell(5, 9).Value = "중개 이용료";
                    detailWorkSheet.Cell(5, 10).Value = "결제정산수수료";

                    detailWorkSheet.Cell(3, 11).Value = "(D) 만나서결제금액";
                    detailWorkSheet.Range(detailWorkSheet.Cell(3, 11), detailWorkSheet.Cell(4, 12)).Merge();
                    detailWorkSheet.Cell(3, 11).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(3, 11).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    detailWorkSheet.Cell(5, 11).Value = "대구로 만나서결제 주문금액";
                    detailWorkSheet.Cell(5, 12).Value = "대구로 만나서결제 배달팁";

                    //detailWorkSheet.Cell(3, 10).Value = "(D) 만나서결졔금액";
                    //detailWorkSheet.Range(detailWorkSheet.Cell(3, 10), detailWorkSheet.Cell(5, 10)).Merge();
                    //detailWorkSheet.Cell(3, 10).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    //detailWorkSheet.Cell(3, 10).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;


                    detailWorkSheet.Cell(3, 13).Value = "금 액";
                    detailWorkSheet.Range(detailWorkSheet.Cell(3, 13), detailWorkSheet.Cell(5, 13)).Merge();
                    detailWorkSheet.Cell(3, 13).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    detailWorkSheet.Cell(3, 13).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;



                    detailWorkSheet.Range(detailWorkSheet.Cell(3, 1), detailWorkSheet.Cell(5, 13)).Style
                       .Border.SetTopBorder(XLBorderStyleValues.Thin)
                       .Border.SetRightBorder(XLBorderStyleValues.Thin)
                       .Border.SetBottomBorder(XLBorderStyleValues.Thin)
                       .Fill.SetBackgroundColor(XLColor.LightGray);

                    

                    /*
                     *  Detail Data Bindding 6, 1
                     * */
                    for(int i = 0; i < salesReq.data.Count(); i++)
                    {
                        detailWorkSheet.Cell((detailRow - 2) + i, 1).Value = Utils.ParseDataTimeComma(salesReq.data[i].order_date);
                        detailWorkSheet.Cell((detailRow - 2) + i, 1).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                        detailWorkSheet.Cell((detailRow - 2) + i, 2).Value = salesReq.data[i].pack_order_name;
                        detailWorkSheet.Cell((detailRow - 2) + i, 2).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                        detailWorkSheet.Cell((detailRow - 2) + i, 3).Value = salesReq.data[i].app_menu_amount;
                        detailWorkSheet.Cell((detailRow - 2) + i, 3).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                        detailWorkSheet.Cell((detailRow - 2) + i, 4).Value = Math.Abs(Convert.ToInt64(salesReq.data[i].meet_menu_amount));
                        detailWorkSheet.Cell((detailRow - 2) + i, 4).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                        detailWorkSheet.Cell((detailRow - 2) + i, 5).Value = salesReq.data[i].app_tip_amount;
                        detailWorkSheet.Cell((detailRow - 2) + i, 5).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                        detailWorkSheet.Cell((detailRow - 2) + i, 6).Value = Math.Abs(Convert.ToInt64(salesReq.data[i].meet_tip_amount));
                        detailWorkSheet.Cell((detailRow - 2) + i, 6).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                        detailWorkSheet.Cell((detailRow - 2) + i, 7).Value = salesReq.data[i].shop_coupon_amt;
                        detailWorkSheet.Cell((detailRow - 2) + i, 7).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                        detailWorkSheet.Cell((detailRow - 2) + i, 8).Value = salesReq.data[i].pack_disc_amt;
                        detailWorkSheet.Cell((detailRow - 2) + i, 8).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                        detailWorkSheet.Cell((detailRow - 2) + i, 9).Value = salesReq.data[i].app_fee_amount;
                        detailWorkSheet.Cell((detailRow - 2) + i, 9).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                        detailWorkSheet.Cell((detailRow - 2) + i, 10).Value = salesReq.data[i].pg_fee_amount;
                        detailWorkSheet.Cell((detailRow - 2) + i, 10).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                        //detailWorkSheet.Cell((detailRow - 2) + i, 10).Value = salesReq.data[i].delivery_total_amount;
                        //detailWorkSheet.Cell((detailRow - 2) + i, 10).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                        detailWorkSheet.Cell((detailRow - 2) + i, 11).Value = Convert.ToDouble(salesReq.data[i].meet_menu_amount);
                        detailWorkSheet.Cell((detailRow - 2) + i, 12).Value = Convert.ToDouble(salesReq.data[i].meet_tip_amount);
                        detailWorkSheet.Cell((detailRow - 2) + i, 13).Value = salesReq.data[i].total_amount;
                        detailWorkSheet.Cell((detailRow - 2) + i, 13).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);

                        if ( i == salesReq.data.Count() -1)
                        {
                            detailWorkSheet.Range(detailWorkSheet.Cell((detailRow - 2) + i, 1), detailWorkSheet.Cell((detailRow - 2) + i, 13)).Style
                                .Border.SetBottomBorder(XLBorderStyleValues.Thin);
                            detailWorkSheet.Range(detailWorkSheet.Cell(6, 3), detailWorkSheet.Cell((detailRow - 2) + i, 13)).Style
                                .NumberFormat.Format = "#,##0";

                            detailWorkSheet.Range("B5", "B" + i).SetAutoFilter();
                        }
                    }
                    detailWorkSheet.Columns("A", "O").Width = 22;
                    detailWorkSheet.Rows().Height = 16.5 ;
                    detailWorkSheet.Rows().AdjustToContents();
                    detailWorkSheet.SheetView.ZoomScale = 100;


                    worksheet.Columns("A", "J").Width = 22;
                    worksheet.Rows().AdjustToContents();
                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        nlogger.Info($"[ CEO Statics Excel End ,Shopcd === {info.shop_cd}");
                        return File(content,
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            string.Concat("매출현황_", DateTime.Now.ToString("yyyyMMddHHmmss"), ".xlsx"));
                    }
                }
            }
            catch (Exception e)
            {
                nlogger.Info($"[ CEO Statics Excel Fail ,Shopcd === {info.shop_cd}");
                return BadRequest();
            }
        }
    }
}
