﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using PosWebApp.Common;
using PosWebApp.Models.Event;
using PosWebApp.Models.RequestModel;
using PosWebApp.Settings;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        public IOptions<DbStrings> DbString { get; }

        public EventController(IOptions<DbStrings> dbString)
        {
            DbString = dbString;
        }


        /// <summary>
        /// 가맹점 자체 이벤트 마스터 리스트 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("Master/List")]
        public async Task<Result<ResponseShopEventList>> GetShopEventMstList(RequestShopEventList info)
        {
            Result<ResponseShopEventList> result = new Result<ResponseShopEventList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.GET_SHOP_EVENT_MST_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_use_gbn", OracleDbType.Varchar2)).Value = info.use_gbn;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if(code.Equals("00"))
                            {
                                List<ResponseShopEventList> modelList = new List<ResponseShopEventList>();

                                while(await reader.ReadAsync())
                                {
                                    ResponseShopEventList model = new ResponseShopEventList()
                                    {
                                        shop_cd = reader["shop_cd"].ToString(),
                                        shop_name = reader["shop_name"].ToString(),
                                        cccode = reader["cccode"].ToString(),
                                        ccname = reader["ccname"].ToString(),
                                        use_gbn = reader["use_gbn"].ToString(),
                                        order_date = reader["order_date"].ToString(),
                                        start_time = reader["fr_tm"].ToString(),
                                        end_time = reader["to_tm"].ToString(),
                                        insert_date = reader["ins_date"].ToString(),
                                        mod_name = reader["mod_name"].ToString(),
                                        mod_date = reader["mod_date"].ToString(),
                                        push_send_yn = reader["push_send_yn"].ToString(),
                                        event_title = reader["event_title_m"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 자체 이벤트 마스터 관리
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("Master/Set")]
        public async Task<CodeMsg> SetShopEventMst(RequestSetShopEvent info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using(OracleCommand cmd = new OracleCommand()
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.SET_SHOP_EVENT_MST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_fr_tm", OracleDbType.Varchar2)).Value = info.from_time;
                        cmd.Parameters.Add(new OracleParameter("in_to_tm", OracleDbType.Varchar2)).Value = info.to_time;
                        cmd.Parameters.Add(new OracleParameter("in_ins_name", OracleDbType.Varchar2)).Value = info.ins_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("in_event_title_m", OracleDbType.Varchar2)).Value = info.event_title;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 자체 이벤트 마스터 해제 관리
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("Master/UnSet")]
        public async Task<CodeMsg> SetShopEventMstNoUse(RequestShopEventNoUse info)
        {
            CodeMsg result = new CodeMsg();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.SET_SHOP_EVENT_MST_NO_USE",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_ins_name", OracleDbType.Varchar2)).Value = info.ins_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }


        /// <summary>
        /// 가맹점 자체 이벤트 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("List")]
        public async Task<Result<ResponseShopEventList>> GetShopEventList(RequestShopEventList info)
        {
            Result<ResponseShopEventList> result = new Result<ResponseShopEventList>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.GET_SHOP_EVENT_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_use_gbn", OracleDbType.Varchar2)).Value = info.use_gbn;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseShopEventList> modelList = new List<ResponseShopEventList>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseShopEventList model = new ResponseShopEventList()
                                    {
                                        shop_cd = reader["shop_cd"].ToString(),
                                        shop_name = reader["shop_name"].ToString(),
                                        cccode = reader["cccode"].ToString(),
                                        ccname = reader["ccname"].ToString(),
                                        event_seq = reader["event_seq"].ToString(),
                                        use_gbn = reader["use_gbn"].ToString(),
                                        menu_cd = reader["menu_cd"].ToString(),
                                        menu_name = reader["menu_name"].ToString(),
                                        menu_cost = reader["menu_cost"].ToString(),
                                        disc_menu_cost = reader["disc_menu_cost"].ToString(),
                                        order_date = reader["order_date"].ToString(),
                                        start_time = reader["fr_tm"].ToString(),
                                        end_time = reader["to_tm"].ToString(),
                                        event_amt_gbn = reader["event_amt_gbn"].ToString(),
                                        event_amt = reader["event_amt"].ToString(),
                                        insert_date = reader["ins_date"].ToString(),
                                        insert_name = reader["ins_name"].ToString(),
                                        mod_date = reader["mod_date"].ToString(),
                                        mod_name = reader["mod_name"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        /// <summary>
        /// 가맹점 자체 이벤트 상세 조회
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("Detail")]
        public async Task<Result<ResponseShopEventDetail>> GetShopEventDetail(RequestShopEventDetail info)
        {
            Result<ResponseShopEventDetail> result = new Result<ResponseShopEventDetail>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.GET_SHOP_EVENT_DETAIL",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_event_seq", OracleDbType.Varchar2)).Value = info.event_seq;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if (code.Equals("00"))
                            {
                                List<ResponseShopEventDetail> modelList = new List<ResponseShopEventDetail>();
                                while (await reader.ReadAsync())
                                {
                                    ResponseShopEventDetail model = new ResponseShopEventDetail
                                    {
                                        event_seq = Convert.ToInt32(reader["event_seq"].ToString()),
                                        event_gbn = reader["event_gbn"].ToString(),
                                        use_gbn = reader["use_gbn"].ToString(),
                                        menu_cd = reader["menu_cd"].ToString(),
                                        order_date = reader["order_date"].ToString(),
                                        from_time = reader["fr_tm"].ToString(),
                                        to_time = reader["to_tm"].ToString(),
                                        event_title = reader["event_title"].ToString(),
                                        event_con = reader["event_con"].ToString(),
                                        event_amt_gbn = reader["event_amt_gbn"].ToString(),
                                        event_amt = reader["event_amt"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;

                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }


        /// <summary>
        /// 가맹점 자체 이벤트 관리 등록 관리
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("Set")]
        public async Task<Result<dynamic>> SetShopEvent(RequestSetShopEvent info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.SET_SHOP_EVENT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Varchar2)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_event_amt_gbn", OracleDbType.Varchar2)).Value = info.event_amt_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_event_amt", OracleDbType.Varchar2)).Value = info.event_amt;
                        cmd.Parameters.Add(new OracleParameter("ins_name", OracleDbType.Varchar2)).Value = info.ins_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }

        /// <summary>
        /// 가맹점 자체 이벤트 해제 관리
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("UnSet")]
        public async Task<Result<dynamic>> SetShopEventNoUse(RequestShopEventNoUse info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.SET_SHOP_EVENT_NO_USE",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Int32)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_ins_name", OracleDbType.Varchar2)).Value = info.ins_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("Menus")]
        public async Task<Result<EventMenu>> GetShopMenuList(Request info)
        {
            Result<EventMenu> result = new Result<EventMenu>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using(OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.GET_SHOP_MENU_LIST",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string code = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message = cmd.Parameters["out_ret_msg"].Value.ToString();

                            if(code.Equals("00"))
                            {
                                List<EventMenu> modelList = new List<EventMenu>();

                                while(await reader.ReadAsync())
                                {
                                    EventMenu model = new EventMenu()
                                    {
                                        cccode = reader["cccode"].ToString(),
                                        shop_cd = reader["shop_cd"].ToString(),
                                        menu_group_cd = reader["menu_group_cd"].ToString(),
                                        menu_group_name = reader["menu_group_name"].ToString(),
                                        menu_cd = reader["menu_cd"].ToString(),
                                        menu_name = reader["menu_name"].ToString(),
                                        no_flag = reader["no_flag"].ToString(),
                                        menu_cost = reader["menu_cost"].ToString(),
                                    };
                                    modelList.Add(model);
                                }
                                result.data = modelList;
                            }
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("Push")]
        public async Task<Result<dynamic>> SendEventPush(Request info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using(OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.SET_SHOP_EVENT_PUSH_MSG",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("GetLiveEvent")]
        public async Task<ResultSingle<ResponseGetLiveEvent>> GetLiveEvent(RequestShopEventList info)
        {
            ResultSingle<ResponseGetLiveEvent> result = new ResultSingle<ResponseGetLiveEvent>();

           ResponseGetLiveEvent temp = new ResponseGetLiveEvent();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.GET_SHOP_LIVE_EVENT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_use_gbn", OracleDbType.Varchar2)).Value = info.use_gbn;
                        cmd.Parameters.Add(new OracleParameter("out_shop_name", OracleDbType.Varchar2, 100)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_shop_logo", OracleDbType.Varchar2, 100)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_event_yn", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_event_title", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_fr_time", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_to_time", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_remaining_time", OracleDbType.Int64, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_push_yn", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            string shop_name      = cmd.Parameters["out_shop_name"].Value.ToString();
                            string shop_logo      = cmd.Parameters["out_shop_logo"].Value.ToString();
                            string event_yn       = cmd.Parameters["out_ret_event_yn"].Value.ToString();
                            string event_title    = cmd.Parameters["out_ret_event_title"].Value.ToString();
                            string fr_time        = cmd.Parameters["out_ret_fr_time"].Value.ToString();
                            string to_time        = cmd.Parameters["out_ret_to_time"].Value.ToString();
                            string remaining_time = cmd.Parameters["out_remaining_time"].Value.ToString();
                            string push_yn        = cmd.Parameters["out_push_yn"].Value.ToString();
                            string code           = cmd.Parameters["out_ret_code"].Value.ToString();
                            string message        = cmd.Parameters["out_ret_msg"].Value.ToString();

                            
                            temp.shop_name = shop_name;
                            temp.shop_logo = shop_logo;
                            temp.event_yn = event_yn;
                            temp.event_title = event_title;
                            temp.fr_time = fr_time;
                            temp.to_time = to_time;
                            temp.remaining_time = remaining_time;
                            temp.push_yn = push_yn;
                            temp.MenuList = new List<ResponseShopEventList>();

                            if (code.Equals("00"))
                            {
                                List<ResponseShopEventList> modelList = new List<ResponseShopEventList>();

                                while (await reader.ReadAsync())
                                {
                                    ResponseShopEventList model = new ResponseShopEventList()
                                    {
                                        menu_cd = reader["menu_cd"].ToString(),
                                        menu_name = reader["menu_name"].ToString(),
                                        menu_cost = reader["menu_cost"].ToString(),
                                        event_amt = reader["disc_cost"].ToString(),
                                        event_amt_gbn = reader["event_amt_gbn"].ToString(),
                                        event_seq = reader["menu_seq"].ToString()
                                    };
                                    modelList.Add(model);
                                }
                                if (event_yn.Equals("Y") || event_yn.Equals("R"))
                                {
                                    temp.MenuList = modelList;
                                }
                            }
                            if (event_yn.Equals("E") || event_yn.Equals("N"))
                            {
                                List<ResponseShopEventList> modelList = new List<ResponseShopEventList>();
                                temp.MenuList = modelList;

                                
                            }
                            result.data = temp;
                            result.code = code;
                            result.msg = message;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        [HttpPost("SetLiveEvent")]
        public async Task<Result<dynamic>> SetLiveEvent(RequestLiveEvent info)
        {
            Result<dynamic> result = new Result<dynamic>();


            #region eventMenuSetList
            List<int> menuCd = new List<int>();
            List<string> eventGbn = new List<string>();
            List<long> eventAmt = new List<long>();
            List<int> SaleQnt = new List<int>();

            if(info.eventList != null) { 
                foreach(var item in info.eventList)
                {
                    menuCd.Add(Convert.ToInt32(item.menuCd));
                    eventGbn.Add(item.choice_event);
                    SaleQnt.Add(Convert.ToInt32(item.SaleQnt));
                    if (item.choice_event.Equals("3"))
                    {
                        eventAmt.Add(Convert.ToInt64(item.eventAmt.Replace("%", "")));
                    }
                    else
                    {
                        eventAmt.Add(Convert.ToInt64(item.eventAmt));
                    }
                }
            }else
            {
                menuCd.Add(1);
                eventGbn.Add("1");
                eventAmt.Add(1);
            }
            #endregion

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.SET_SHOP_LIVE_EVENT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_event_title_m", OracleDbType.Varchar2)).Value = info.event_title;
                        cmd.Parameters.Add(new OracleParameter("in_fr_tm", OracleDbType.Varchar2)).Value = info.start_time;
                        cmd.Parameters.Add(new OracleParameter("in_to_tm", OracleDbType.Varchar2)).Value = info.end_time;
                        cmd.Parameters.Add(new OracleParameter("in_ins_name", OracleDbType.Varchar2)).Value = info.ins_name;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = menuCd.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_event_amt_gbn", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = eventGbn.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_event_amt", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = eventAmt.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_sale_qnt", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = SaleQnt.ToArray();
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }
        /// <summary>
        /// 이벤트 중지
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("StopLiveEvent")]
        public async Task<Result<dynamic>> StopLiveEvent(RequestLiveEvent info)
        {
            Result<dynamic> result = new Result<dynamic>();


            #region eventMenuSetList
            List<int> menuCd = new List<int>();
            List<string> eventGbn = new List<string>();
            List<long> eventAmt = new List<long>();


            foreach (var item in info.eventList)
            {
                menuCd.Add(Convert.ToInt32(item.menuCd));
                eventGbn.Add("1");
                eventAmt.Add(Convert.ToInt64(item.eventAmt));
            }
            #endregion

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand
                    {
                        Connection = conn,
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.SET_SHOP_LIVE_EVENT",
                        CommandType = CommandType.StoredProcedure
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_event_title_m", OracleDbType.Varchar2)).Value = info.event_title;
                        cmd.Parameters.Add(new OracleParameter("in_fr_tm", OracleDbType.Varchar2)).Value = info.start_time;
                        cmd.Parameters.Add(new OracleParameter("in_to_tm", OracleDbType.Varchar2)).Value = info.end_time;
                        cmd.Parameters.Add(new OracleParameter("in_ins_name", OracleDbType.Varchar2)).Value = info.ins_name;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = menuCd.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_event_amt_gbn", OracleDbType.Varchar2)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = eventGbn.ToArray();
                        cmd.Parameters.Add(new OracleParameter("in_event_amt", OracleDbType.Double)
                        {
                            CollectionType = OracleCollectionType.PLSQLAssociativeArray
                        }).Value = eventAmt.ToArray();
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }


            return result;
        }
        /// <summary>
        /// 가맹점 자체 이벤트 해제 관리
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        [HttpPost("MenuDelete")]
        public async Task<Result<dynamic>> SetLiveMenuDelete(RequestShopEventNoUse info)
        {
            Result<dynamic> result = new Result<dynamic>();

            try
            {
                using (OracleConnection conn = new OracleConnection(DbString.Value.testDb150))
                {
                    await conn.OpenAsync();
                    using (OracleCommand cmd = new OracleCommand()
                    {
                        CommandText = "PKG_IS_SHOP_EVENT_STAMP.SET_SHOP_LIVE_EVENT_MENU",
                        CommandType = CommandType.StoredProcedure,
                        Connection = conn
                    })
                    {
                        cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = info.job_gbn;
                        cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = info.shop_cd;
                        cmd.Parameters.Add(new OracleParameter("in_menu_cd", OracleDbType.Int32)).Value = info.menu_cd;
                        cmd.Parameters.Add(new OracleParameter("in_ins_name", OracleDbType.Varchar2)).Value = info.ins_name;
                        cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 20)).Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 200)).Direction = ParameterDirection.Output;

                        await cmd.ExecuteNonQueryAsync();

                        result.code = cmd.Parameters["out_ret_code"].Value.ToString();
                        result.msg = cmd.Parameters["out_ret_msg"].Value.ToString();
                    }
                }
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
    }
}
