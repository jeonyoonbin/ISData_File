﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.jwt
{
    public interface IJwtAuthenticationManager
    {
        string Authenticate(string userId, string password);
    }
}
