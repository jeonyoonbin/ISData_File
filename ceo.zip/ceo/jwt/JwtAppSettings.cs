﻿namespace PosWebApp.jwt
{
    public class JwtAppSettings
    {
        public string Secret { get; set; }
    }
}
