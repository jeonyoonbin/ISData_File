﻿namespace PosWebApp.jwt
{
    public interface IRefreshTokenGenerator
    {
        string GenerateToken();
    }
}