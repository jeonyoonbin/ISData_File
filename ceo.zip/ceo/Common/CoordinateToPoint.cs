﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static PosWebApp.Common.GIS;

namespace PosWebApp.Common
{
    public class CoordinateToPoint
    {
        public static void ESPG4326(double lat, double lng, out double[] xy)
        {
            var cf = new ProjNet.CoordinateSystems.CoordinateSystemFactory();
            var f = new ProjNet.CoordinateSystems.Transformations.CoordinateTransformationFactory();
            var wgs84 = cf.CreateFromWkt(WKT.EPSG4326);
            var epsg = cf.CreateFromWkt(WKT.EPSG5179);

            var transformto3857 = f.CreateFromCoordinateSystems(wgs84, epsg);
            double[] fromPoint = { lat, lng };
            xy = transformto3857.MathTransform.Transform(fromPoint);

            double x = xy[0];
            double y = xy[1];

            Console.WriteLine(x);
            Console.WriteLine(y);



        }

        public static void ESPG5179(double lat, double lng, out double[] xy)
        {
            var cf = new ProjNet.CoordinateSystems.CoordinateSystemFactory();
            var f = new ProjNet.CoordinateSystems.Transformations.CoordinateTransformationFactory();
            var epsg = cf.CreateFromWkt(WKT.EPSG5179);
            var gcs_WGS84 = cf.CreateFromWkt(WKT.ESPG900913);

            var transformTo3857 = f.CreateFromCoordinateSystems(epsg, gcs_WGS84);
            double[] fromPoint = { lat, lng };
            xy = transformTo3857.MathTransform.Transform(fromPoint);
            double x = xy[0] * 360000f;
            double y = xy[1] * 360000f;

            var x1 = Math.Round(x);
            var y1 = Math.Round(y);
        }

        public static void ESPG5178(double lat, double lng, out double[] xy)
        {
            var cf = new ProjNet.CoordinateSystems.CoordinateSystemFactory();
            var f = new ProjNet.CoordinateSystems.Transformations.CoordinateTransformationFactory();
            var epsg = cf.CreateFromWkt(WKT.ESPG5178);
            var gcs_WGS84 = cf.CreateFromWkt(WKT.ESPG900913);
            var transformTo3857 = f.CreateFromCoordinateSystems(epsg, gcs_WGS84);
            double[] fromPoint = { lat, lng };
            xy = transformTo3857.MathTransform.Transform(fromPoint);

            double x = xy[0] * 360000f;
            double y = xy[1] * 360000f;
            var x1 = Math.Round(x);
            var y1 = Math.Round(y);
        }

        public static void ESPG900913(double lat, double lng, out double[] xy)
        {
            var cf = new ProjNet.CoordinateSystems.CoordinateSystemFactory();
            var f = new ProjNet.CoordinateSystems.Transformations.CoordinateTransformationFactory();
            var epsg = ProjNet.CoordinateSystems.ProjectedCoordinateSystem.WebMercator;
            var gcs_WGS84 = cf.CreateFromWkt(WKT.EPSG4326);

            var transformTo3857 = f.CreateFromCoordinateSystems(epsg, gcs_WGS84);
            double[] fromPoint = { lat, lng };
            xy = transformTo3857.MathTransform.Transform(fromPoint);
        }

        public static void WGS_TO_ESPG900913(double lat, double lng, out double[] xy)
        {
            var cf = new ProjNet.CoordinateSystems.CoordinateSystemFactory();
            var f = new ProjNet.CoordinateSystems.Transformations.CoordinateTransformationFactory();
            var epsg = ProjNet.CoordinateSystems.ProjectedCoordinateSystem.WebMercator; //cf.CreateFromWkt(WKT.ESPG900913);
            var gcs_WGS84 = cf.CreateFromWkt(WKT.EPSG4326);

            var transformTo3857 = f.CreateFromCoordinateSystems(gcs_WGS84, epsg);
            double[] fromPoint = { lat, lng };
            xy = transformTo3857.MathTransform.Transform(fromPoint);
        }
    }
}
