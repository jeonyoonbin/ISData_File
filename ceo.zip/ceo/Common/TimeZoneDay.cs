﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Common
{
    public class TimeZoneDay
    {

        public enum e_Days
        {
            월 = 2,
            화 = 3,
            수 = 4,
            목 = 5,
            금 = 6,
            토 = 7,
            일 = 8
        }
        public int DayValue { set; get; }
        public string DayName { get; set; }

        public static IEnumerable<TimeZoneDay> GetDayItems()
        {
            return Enum.GetValues(typeof(e_Days)).Cast<e_Days>().Select(x => new TimeZoneDay
            {
                DayValue = (int)x,
                DayName = x.ToString()
            });
        }
    }
}
