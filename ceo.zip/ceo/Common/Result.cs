﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace PosWebApp.Common
{
    public class Result<T>
    {
        public string code { get; set; }
        public string msg { get; set; }
        public List<T> data { get; set; }
    } 
}
