﻿using System.Runtime.Serialization;

namespace PosWebApp.Common
{
    public class ResultSingle<T>
    {
        public string code { get; set; }
        public string msg { get; set; }
        public T data { get; set; }
    }
}
