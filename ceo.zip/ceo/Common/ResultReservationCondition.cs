﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Common
{
    public class ResultReservationCondition<T>
    {
        public string code { get; set; }
        public string msg { get; set; }
        //total
        public int totalCnt { get; set; }
        //확정대기
        public int statuS10 { get; set; }
        //확정
        public int statuS12 { get; set; }
        //방문완료
        public int statuS30 { get; set; }
        //취소
        public int statuS40 { get; set; }
        //미방문
        public int statuS90 { get; set; }
        public List<T> data { get; set; }
    }
}
