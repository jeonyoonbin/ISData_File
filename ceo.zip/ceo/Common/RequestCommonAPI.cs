﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using PosWebApp.ActionFilter;
using PosWebApp.Models.ChangeRequest.Request;
using PosWebApp.Models.ChangeRequest.Response;
using PosWebApp.Models.ResponseModel;
using PosWebApp.Services.DgShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Common
{
    [SessionDgShop]
    public class RequestCommonAPI 
    {
        private readonly DgShopApiService dgShop;
        public RequestCommonAPI(DgShopApiService dgAPI)
        {
            dgShop = dgAPI;
        }
        public async Task<Result<ResponseCommon>> RequestServiceGBN(RequestCommon info)
        {
            Result<ResponseCommon> result = new Result<ResponseCommon>();

            if (string.IsNullOrEmpty(info.service_gbn))
            {
                result.code = "99";
                result.msg = "파라미터 값이 존재하지않습니다.";
            }

            try
            {
                var req = await dgShop.Post<ResponseCommon, RequestCommon>("/api/RequestService/GetRequestService", info);

                result = req;
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
        public async Task<Result<ResponseCommon>> RequestServiceList(RequestCommon info)
        {
            Result<ResponseCommon> result = new Result<ResponseCommon>();

            if (string.IsNullOrEmpty(info.service_gbn))
            {
                result.code = "99";
                result.msg = "파라미터 값이 존재하지않습니다.";
            }

            try
            {
                var req = await dgShop.Post<ResponseCommon, RequestCommon>("/api/RequestService/GetRequestServiceList", info);

                result = req;
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }

        public async Task<Result<ResponseServiceTypeCommon>> RequestServiceType(RequestServiceTypeCommon info)
        {
            Result<ResponseServiceTypeCommon> result = new Result<ResponseServiceTypeCommon>();

            if (string.IsNullOrEmpty(info.GbnCode))
            {
                result.code = "99";
                result.msg = "파라미터 값이 존재하지않습니다.";
            }

            try
            {
                var req = new Result<ResponseServiceTypeCommon>();
               
                req = await dgShop.Post<ResponseServiceTypeCommon, RequestServiceTypeCommon>("/api/RequestService/GetServiceTypeCommon", info);

                result = req;
            }
            catch (Exception e)
            {
                result.code = "99";
                result.msg = e.Message;
            }

            return result;
        }
    }
}
