﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Common
{
    public class ImageUtils
    {
#if DEBUG
        public string nasPath = @"D:\ASP\RequestServiceImage";
        public string nasAlertPath = @"D:\ASP\Intro";
#else
        public string nasPath = @"\\10.10.10.100\dgnas\Files\RequestServiceImage";
        public string nasAlertPath = @"\\10.10.10.100\dgnas\Files\Intro";
#endif

        public async Task<ResultSingle<string>> FileUpload(string shopCode, IFormFile ifile, string fileName, string type)
        {
            ResultSingle<string> result = new ResultSingle<string>();

            try
            {
                using(new ConnectToSharedFolder(nasPath))
                {
                    var datatime = DateTime.Now.ToString("yyyyMMdd");
                    var subPath = nasPath + "\\" + type ;
                    var folderPath = subPath + "\\" + datatime + "\\" + shopCode;


                    var path = MakePathToSaveContent(folderPath, fileName, false);

                    using (var ms = new MemoryStream())
                    {
                        await ifile.CopyToAsync(ms);
                        var fileBytes = ms.ToArray();
                        ProcessWrite(path, fileBytes);
                    }
                    result.data = datatime;
                }
                result.code = "00";
                result.msg = "성공";
            }
            catch(Exception e)
            {
                result.code = "99";
                result.data = e.ToString();
                result.msg = "실패";
            }
            return result;
        }
        ///<summary>
        /// file List upload
        /// </summary>
        public async Task<ResultSingle<string>> FileListUpload(string shopCode, List<IFormFile> ifile, List<string> fileNames, string type)
        {
            ResultSingle<string> result = new ResultSingle<string>();

            try
            {
                using (new ConnectToSharedFolder(nasPath))
                {
                    var datatime = DateTime.Now.ToString("yyyyMMdd");
                    var subPath = nasPath + "\\" + type;
                    var folderPath = subPath + "\\" + datatime + "\\" + shopCode;
                    string[] paths = new string[ifile.Count()];

                    int idx = 0;
                    foreach(var files in fileNames)
                    {
                        paths[idx] = MakePathToSaveContent(folderPath, files, false);
                        idx++;
                    }
                    // var path = MakePathToSaveContent(folderPath, fileName, false);

                    idx = 0;
                    if (ifile.Count() > 0)
                    {
                        foreach (var file in ifile)
                        {
                            using (var ms = new MemoryStream())
                            {
                        
                                await file.CopyToAsync(ms);
                                var fileBytes = ms.ToArray();
                                ProcessWrite(paths[idx], fileBytes);

                                idx++;

                                ms.Close();
                            }
                        }


                    }
                    result.data = datatime;
                }
                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception e)
            {
                result.code = "99";
                result.data = e.ToString();
                result.msg = "실패";
            }
            return result;
        }


        ///<summary>
        /// Alert Image Store
        /// </summary>
        public async Task<ResultSingle<string>> AlertFileUpload(string shopCode, IFormFile ifile, string fileName, string type)
        {
            ResultSingle<string> result = new ResultSingle<string>();

            try
            {
                using (new ConnectToSharedFolder(nasAlertPath))
                {
                    var datatime = DateTime.Now.ToString("yyyyMMdd");
                    var subPath = nasAlertPath + "\\" + type;
                    var folderPath = subPath + "\\" + shopCode;


                    var path = MakePathToSaveContent(folderPath, fileName, false);

                    using (var ms = new MemoryStream())
                    {
                        await ifile.CopyToAsync(ms);
                        var fileBytes = ms.ToArray();
                        ProcessWrite(path, fileBytes);
                    }
                    result.data = datatime;
                }
                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception e)
            {
                result.code = "99";
                result.data = e.ToString();
                result.msg = "실패";
            }
            return result;
        }
        /// <summary>
        /// DEFINE.CONTENT_FOLDER 하위에 입력된 파라미터 이름으로 폴더 생성
        /// </summary>
        /// <param name="manCode"> DEFINE.CONTENT_FOLDER 하위에 생성될 폴더 이름 </param>
        /// <returns></returns>
        public static string MakePathToSaveContent(string subPath, string fileName, bool isThumb)
        {
            string pathString = subPath;

            Directory.CreateDirectory(subPath);

            // Use Combine again to add the file name to the path.
            if (isThumb)
            {
                pathString = Path.Combine(pathString, "thumb_" + fileName /*+ ".jpg"*/);
            }
            else
            {
                pathString = Path.Combine(pathString, fileName /* + ".jpg"*/);
            }

            return pathString;
        }
        public static void ProcessWrite(string filePath, byte[] contentData)
        {
            if(contentData.Length > 0) { 
            using (FileStream sourceStream = new FileStream(filePath, FileMode.Create,
                FileAccess.Write, FileShare.None, bufferSize: 4096, useAsync: true))
                {
                    try
                    {
                        sourceStream.Write(contentData, 0, contentData.Length);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    sourceStream.Close();
                };
            }
        }
    }
}
