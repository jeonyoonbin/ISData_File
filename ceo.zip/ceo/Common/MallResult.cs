﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Common
{
    public class MallResult<T>
    {
        public string code { get; set; }
        public string msg { get; set; }
        public T data { get; set; }
    }
}