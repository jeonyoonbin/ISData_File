﻿using System;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Common
{
    public class SalesPagination<T> : List<T>
    {
        public int PageIndex { get; private set; }
        public int TotalPages { get; private set; }
        public string from { get; private set; }
        public string to { get; private set; }
        public int start { get; set; }
        public int end { get; set; }
        public int pageEnd { get; set; }
        public bool prev { get; set; }
        public bool next { get; set; }

        public SalesPagination(List<T> items, int count, int pageIndex, int pageSize, string from, string to)
        {
            //PageIndex = pageIndex;
            //TotalPages = (int)Math.Ceiling(count / (double)pageSize);
            //this.from = from;
            //this.to = to;
            if (pageSize == 10)
                calcPage(count, pageIndex, pageSize, from, to);
            else if (pageSize == 5)
                CalcPageMobile(count, pageIndex, pageSize, from, to);

            TotalPages = end;
            this.AddRange(items);
        }


        public bool HasPreviousPage
        {
            get
            {
                return (PageIndex > 1);
            }
        }
        public bool HasNextPage
        {
            get
            {
                return (PageIndex < TotalPages);
            }
        }
        private void calcPage(int count, int pageIndex, int pageSize, string from, string to)
        {
            PageIndex = pageIndex;
            this.from = from;
            this.to = to;

            int tempEnd = (int)(Math.Ceiling(PageIndex / (double)pageSize) * pageSize);
            pageEnd = (count / pageSize) + ((count % pageSize) > 0 ? 1 : 0);

            this.start = tempEnd - 9;

            if (tempEnd * 10 > count)
            {
                this.end = (int)(Math.Ceiling(count / (double)pageSize));
            }
            else
            {
                this.end = tempEnd;
            }

            this.prev = this.start != 1;
            this.next = this.end * pageSize < count;
        }
        private void CalcPageMobile(int count, int pageIndex, int pageSize, string from, string to)
        {
            PageIndex = pageIndex;
            this.from = from;
            this.to = to;

            int tempEnd = (int)(Math.Ceiling(PageIndex / (double)pageSize) * pageSize);
            pageEnd = (count / pageSize) + ((count % pageSize) > 0 ? 1 : 0);


            this.start = tempEnd - 4;

            if (tempEnd * 5 > count)
            {
                this.end = (int)(Math.Ceiling(count / (double)pageSize));
            }
            else
            {
                this.end = tempEnd;
            }

            this.prev = this.start != 1;
            this.next = this.end * pageSize < count;
        }
        public static SalesPagination<T> Create(IQueryable<T> source, int pageIndex, int pageSize, string from, string to)
        {
            var count = source.Count();
            var items = source.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            return new SalesPagination<T>(items, count, pageIndex, pageSize, from, to);
        }

        public static async Task<SalesPagination<T>> CreateAsync(IQueryable<T> source, int pageIndex, int pageSize, string from, string to)
        {
            var count = await source.CountAsync();
            var items = await source.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToListAsync();
            return new SalesPagination<T>(items, count, pageIndex, pageSize, from, to);
        }
    }
}
