﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Common
{
    public class ReviewPageList<T> : List<T>
    {
        public int start { get; set; }
        public int end { get; set; }
        public bool prev { get; set; }
        public bool next { get; set; }
        public int PageIndex { get; private set; }
        public int TotalPages { get; private set; }
        public double TotalCount { get;  set; }
        public List<T> ReviewList { get; set; }
        public ReviewPageList(List<T> items, double count, int pageIndex, int pageSize)
        {
            PageIndex = pageIndex;
            this.AddRange(items);
            int tempEnd = (int)(Math.Ceiling(PageIndex / (double)pageSize) * pageSize);

            TotalCount = count;
            ReviewList = items;
            this.start = tempEnd - 9;

            if (tempEnd * 10 > count)
            {
                this.end = (int)(Math.Ceiling(count / (double)pageSize));
            }
            else
            {
                this.end = tempEnd;
            }
            TotalPages = this.end;
            this.prev = this.start != 1;
            this.next = this.end * pageSize < count;
        }
        public bool HasPreviousPage
        {
            get
            {
                return (PageIndex > 1);
            }
        }
        public bool HasNextPage
        {
            get
            {
                return (PageIndex < TotalPages);
            }
        }
        public static ReviewPageList<T> Create(List<T> source, double count, int pageIndex, int pageSize)
        {
            
            var items = source.ToList();
            return new ReviewPageList<T>(items, count, pageIndex, pageSize);
        }
    }
}
