﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Settings
{
    public class DbStrings
    {
        public string IsDaegu { get; set; }
        public string testDb { get; set; }
        public string testDb150 { get; set; }


    }
}
