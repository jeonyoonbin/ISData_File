﻿namespace PosWebApp.Settings
{
    public class ApiStrings
    {
        public string admin { get; set; }
        public string daegu { get; set; }
        public string sync { get; set; }
        public string local { get; set; }
        public string daguroPos { get; set; }
        public string daeguroPosAdminApi { get; set; }
        public string address { get; set; }
        public string review { get; set; }
        public string review_running { get; set; }
        public string review_member_key { get; set; }
    }
}
