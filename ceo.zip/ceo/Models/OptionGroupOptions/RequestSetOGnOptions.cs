﻿using PosWebApp.Models.RequestModel;
using System.Collections.Generic;

namespace PosWebApp.Models.OptionGroupOptions
{
    public class RequestSetOGnOptions : Request
    {
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string option_group_use_yn { get; set; }
        public string min_count { get; set; }
        public string multi_count { get; set; }
        public string mod_user { get; set; }
        public List<RequestSetOGnOption> options { get; set; }
    }
    public class RequestSetOGnOption
    {
        public string work_gbn { get; set; }
        public string option_cd { get; set; }
        public string option_name { get; set; }
        public string option_memo { get; set; }
        public string option_cost { get; set; }
        public string option_use_yn { get; set; }
        public int sort_seq { get; set; }
        public string o_no_flag { get; set; }

    }
}
