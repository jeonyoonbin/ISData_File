﻿using PosWebApp.Models.RequestModel;

namespace PosWebApp.Models.OptionGroupOptions
{
    public class RequestGetOGnOptions : Request
    {
        public string optionGroupCd { get; set; }
    }
}
