﻿namespace PosWebApp.Models.Pos
{
    public class ShopOperateInfo_V2
    {
        public string SALE_FR_TIME { get; set; }
        public string SALE_TO_TIME { get; set; }
        public string ABSENT_YN { get; set; }
        public string HOLIDAY_TERM { get; set; }
    }
}
