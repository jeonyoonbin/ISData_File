﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Pos
{
    public class LoginModel
    {
        public string id { get; set; }
        [DataType(DataType.Password)]
        public string password { get; set; }
        public string returnUrl { get; set; }
    }
}
