﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Pos
{
    public class ShopFlagModel
    {

        public string SHOP_CD { get; set; }
        public string DP_SEQ { get; set; }
        public string CCCODE { get; set; }
        public string DP_SHOP_NAME { get; set; }
        public string DP_TELNO { get; set; }
        public string USE_GBN { get; set; }
        public string DP_LON { get; set; }
        public string DP_LAT { get; set; }
        public string ROAD_ADDR { get; set; }
        public string ADDR { get; set; }
        public string MEMO { get; set; }
        public string INS_UCODE { get; set; }
        public string INS_NAME { get; set; }
        public string INS_DATE { get; set; }
        public string MOD_UCODE { get; set; }
        public string MOD_NAME { get; set; }
        public string MOD_DATE { get; set; }



    }
}
