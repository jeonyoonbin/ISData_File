﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Pos
{
    public class ShopBizInfoModel
    {
        public string REG_NO { get; set; }
        public string BUSS_OWNER { get; set; }
        public string BUSS_CON { get; set; }
        public string BUSS_TYPE { get; set; }
        public string BUSS_ADDR { get; set; }
        public string BUSS_TAX_TYPE { get; set; }
    }
}
