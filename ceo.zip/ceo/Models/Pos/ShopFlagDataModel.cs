﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Pos
{
    public enum SHOP_FLAG_UPDATE_TYPE
    {
        INSERT,
        UPDATE,
        DELETE
    }
        

    public class ShopFlagDataModel
    {
        public string type { get; set; }
        public string flagSequence { get; set; }
        public string cccode { get; set; }
        public string shopCode { get; set; }
        public string displayShopName { get; set; }
        public string displayShopTelno { get; set; }
        public bool useGbn { get; set; }
        public double lon { get; set; }
        public double lat { get; set; }
        public string road { get; set; }
        public string buildNo { get; set; }
        public string memo { get; set; }
        public string updateUserCode { get; set; }
        public string updateUserName { get; set; }

    }
}
