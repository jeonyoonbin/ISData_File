﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Pos
{
    public class ShopDefaultInfoModel
    {
        public string 업종코드 { get; set; }
        public string 주요품목 { get; set; }
        public string 가맹점전화번호 { get; set; }
        public string 가맹점휴대전화 { get; set; }
        public string 가맹점EMAIL { get; set; }
        public string 대표자생년월일 { get; set; }
        public string 사용미사용 { get; set; }
        public string 가맹점단말기종류 { get; set; }
        public string 가맹점타입 { get; set; }
        public string 시도명 { get; set; }
        public string 시군구명 { get; set; }
        public string 동명도로명 { get; set; }
        public string 상세주소 { get; set; }
        public string 도로명 { get; set; }
        public string 건물번호 { get; set; }
        public string 가맹점등급 { get; set; }
        public string 가맹점로고URL { get; set; }
    }
}
