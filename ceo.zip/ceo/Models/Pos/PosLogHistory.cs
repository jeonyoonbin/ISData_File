﻿namespace PosWebApp.Models.Pos
{
    public class PosLogHistory
    {
        public string gubun { get; set; }
        public string shop_id { get; set; }
        public string shop_name { get; set; }
        public string shop_address { get; set; }
        public string shop_address_detail { get; set; }
        public string telno { get; set; }
        public string mobile { get; set; }
        public string regno { get; set; }
        public string login_version { get; set; }
    }
}
