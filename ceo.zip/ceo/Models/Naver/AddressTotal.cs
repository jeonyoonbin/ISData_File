﻿namespace PosWebApp.Models.Naver
{
    public class AddressTotal
    {
        public string BLD_NO { get; set; }
        public string DONG_CODE { get; set; }
        public string SIDO_NAME { get; set; }
        public string SIGUNGU_NAME { get; set; }
        public string DONG_NAME { get; set; }
        public string RI_NAME { get; set; }
        public string SAN_GBN { get; set; }
        public string JIBUN_FIRST { get; set; }
        public string JIBUN_SECOND { get; set; }
        public string ROAD_CODE { get; set; }
        public string ROAD_NAME { get; set; }
        public string UPDOWN_GBN { get; set; }
        public string BLD_FIRST { get; set; }
        public string BLD_SECOND { get; set; }
        public string BLD_NAME { get; set; }
        public string BLD_DETAILNAME { get; set; }
        public string UMD_NO { get; set; }
        public string HDONG_CODE { get; set; }
        public string HDONG_NAME { get; set; }
        public string ZIPCODE { get; set; }
        public string ISRT_DATE { get; set; }
        public string BIGO1 { get; set; }
        public string BIGO2 { get; set; }
        public double UTMK_X { get; set; }
        public double UTMK_Y { get; set; }
        public double LON { get; set; }
        public double LAT { get; set; }
        public double ENTER_UTMK_X { get; set; }
        public double ENTER_UTMK_Y { get; set; }
        public double ENTER_WGS_LON { get; set; }
        public double ENTER_WGS_LAT { get; set; }
        public string jibunAddress { get; set; }
        public string roadAddress { get; set; }
        public string IsEnter { get; set; } = "중심";
    }
}
