﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Common
{
    public enum e_Days
    {
        일요일 = 1,
        월요일,
        화요일,
        수요일,
        목요일,
        금요일,
        토요일
    }
    public class Days
    {
        public string name { get; set; }
        public int value { get; set; }

        public static IEnumerable<Days> GetDayItems()
        {
            return Enum.GetValues(typeof(e_Days)).Cast<e_Days>().Select(x => new Days
            {
                value = (int)x,
                name = x.ToString()
            });
        }
        public static dynamic getDayofWeek(string dayName)
        {
            return Enum.GetValues(typeof(e_Days)).Cast<e_Days>().ToDictionary(x => x.ToString(), y => (int)y);
        }
    }
}
