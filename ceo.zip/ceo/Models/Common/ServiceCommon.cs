﻿using Newtonsoft.Json;
using PosWebApp.Models.ChangeRequest.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Common
{
    public class ServiceCommon
    {

        /*공통*/
        public string image_url { get; set; }

        /*사업자*/
        public string a_reg_no { get; set; } //사업자 등록번호
        public string a_buss_owner { get; set; } //
        public string a_buss_con { get; set; } //업태
        public string a_buss_type { get; set; } //업종
        public string a_buss_addr { get; set; } //사업장 주소
        public string a_buss_tax_type { get; set; } //사업 유형 
        public string a_owner { get; set; } //  대표자명

        public string b_reg_no { get; set; } //사업자 등록번호
        public string b_buss_owner { get; set; } //
        public string b_buss_con { get; set; } //업태
        public string b_buss_type { get; set; } //업종
        public string b_buss_addr { get; set; } //사업장 주소
        public string b_buss_tax_type { get; set; } //사업 유형 
        public string b_owner { get; set; } //  대표자명


        /*매장 주소*/
        public string a_roadAdd { get; set; }
        public string a_jibun { get; set; }
        public string a_detail_address { get; set; }
        public string a_lat { get; set; }
        public string a_lon { get; set; }
        public string a_SIDO { get; set; }
        public string a_SIGUGUN { get; set; }
        public string a_DONGMYUN { get; set; }
        public string a_RI { get; set; }
        public string a_ROAD_NAME { get; set; }
        public string a_BUILDING_NUMBER { get; set; }
        public string a_BUILDING_NAME { get; set; }
        public string a_LAND_NUMBER { get; set; }
        public string a_POSTAL_CODE { get; set; }


        public string b_roadAdd { get; set; }
        public string b_jibun { get; set; }
        public string b_detail_address { get; set; }
        public string b_lat { get; set; }
        public string b_lon { get; set; }
        public string b_SIDO { get; set; }
        public string b_SIGUGUN { get; set; }
        public string b_DONGMYUN { get; set; }
        public string b_RI { get; set; }
        public string b_ROAD_NAME { get; set; }
        public string b_BUILDING_NUMBER { get; set; }
        public string b_BUILDING_NAME { get; set; }
        public string b_LAND_NUMBER { get; set; }
        public string b_POSTAL_CODE { get; set; }

        /* 카테고리 */
        public string b_item_cd { get; set; }   //전
        public string b_item_cd2 { get; set; }
        public string b_item_cd3 { get; set; }

        public string a_item_cd { get; set; }   //후
        public string a_item_cd2 { get; set; }
        public string a_item_cd3 { get; set; }

        /*메뉴 관리*/
        public string groupCd { get; set; }
        public string menuCd { get; set; }
        public string menuName { get; set; }
        public string imageName { get; set; }
        public string afterImageURL { get; set; }

        /*Logo image*/
        public string beforeImageURL { get; set; }

        /*매장 정보V2*/
        public string AfterShopName { get; set; }
        public string BeforeShopName { get; set; }
        public string AfterMobile { get; set; }
        public string BeforeMobile { get; set; }

        /*착한매장*/
        public string first { get; set; }
        public string second { get; set; }
        public List<kindSecond_Detail> seconDetail { get; set; }
        public string third { get; set; }


        /*해지 신청*/
        public string reason { get; set; }
        /*공통 이미지 url*/
        public List<string> fileNames { get; set; }
    }

    public class kindSecond_Detail
    {
        public string menucost { get; set; }
        public string deliveryTip { get; set; }
        public string shopCoupon { get; set; }
        public string packSale { get; set; }
        public string dontExist { get; set; }
    }
}
