﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Common
{
    [Flags]
    public enum e_orderStatus
    {
        접수 = 10,
        대기 = 20,
        가맹점접수확인 = 30,
        운행 = 35,
        완료 = 40,
        취소 = 50,
        결제대기 = 80

    }
    public class orderStatus
    {
        public string key { get; set; }
        public int value { get; set; }
        public static IEnumerable<orderStatus> GetStatusItems()
        {
            return Enum.GetValues(typeof(e_orderStatus)).Cast<e_orderStatus>().Select(x => new orderStatus
            {
                value = (int)x,
                key = x.ToString()
            });
        }
        public static string getStatusNames(int values)
        {
            return Enum.GetName(typeof(e_orderStatus), values);
        }
    }
}
