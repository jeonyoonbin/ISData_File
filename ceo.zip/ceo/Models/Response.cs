﻿namespace PosWebApp.Models
{
    public class Response
    {
        public string code { get; set; }
        public string message { get; set; }
    }
}
