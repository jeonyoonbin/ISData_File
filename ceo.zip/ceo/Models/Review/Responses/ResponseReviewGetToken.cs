﻿namespace PosWebApp.Models.Review.Responses
{
    public class ResponseReviewGetToken
    {
        public string member_company_code { get; set; }
    }
}
