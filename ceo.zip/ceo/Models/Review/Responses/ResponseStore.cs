﻿namespace PosWebApp.Models.Review.Responses
{
    public class ResponseStore
    {
        public string error { get; set; }
        public BodyStore store { get; set; }
    }
    public class BodyStore
    {
        public string store_idx { get; set; }
        public string store_code { get; set; }
        public string store_sub_idx { get; set; }
        public string store_name { get; set; }
        public string member_company_idx { get; set; }
        public string cc_code { get; set; }
        public string owner { get; set; }
        public string addr1 { get; set; }
        public string addr2 { get; set; }
        public string tel_num { get; set; }
        public string email { get; set; }
        public string use_yn { get; set; }
        public string store_notice { get; set; }
        public string notice_img_url_1 { get; set; }
        public string notice_img_url_2 { get; set; }
        public string notice_img_url_3 { get; set; }
        public string memo { get; set; }
        public string errorMessage { get; set; }
    }
}
