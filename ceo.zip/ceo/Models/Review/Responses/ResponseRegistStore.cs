﻿namespace PosWebApp.Models.Review.Responses
{
    public class ResponseRegistStore
    {
        public string statusCode { get; set; }
        public string body { get; set; }
        public string RET { get; set; }
        public string error { get; set; }
    }
}
