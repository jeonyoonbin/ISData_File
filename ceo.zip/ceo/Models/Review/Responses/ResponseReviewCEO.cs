﻿using DocumentFormat.OpenXml.Spreadsheet;
using PosWebApp.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Responses
{
    public class ResponseReviewCEO 
    {
        public meta meta { get; set; }
        public List<items> items { get; set; }
    }
    public class meta
    {
        public int totalCnt { get; set; }
        public int pageCnt { get; set; }
        public int totalPage { get; set; }
        public int pageNum { get; set; }
    }
    public class items
    {
        public string orderNo { get; set; }
        public string custCode { get; set; }
        public string custNickName { get; set; }
        public string myReviewYn { get; set; }
        public string content { get; set; }
        public string starScore { get; set; }
        public string orderMenu { get; set; }
        public string insertDate { get; set; }
        public string visibleGbn { get; set; }
        public string answerContent { get; set; }
        public string answerVisibleGbn { get; set; }
        public string answerInsertDate{ get; set; }
        public string img1 { get; set; }
        public string img2 { get; set; }
        public List<string> images { get; set; }
        public string isUse { get; set; }
        public string isUpdateable { get; set; }
        public string blindStandDt { get; set; }
        public string blindEndDt { get; set; }
        public string blindType { get; set; }
        public string reOrderCount { get; set; }
    }
}
