﻿using System.Collections.Generic;

namespace PosWebApp.Models.Review.Responses
{
    public class ResponseReviewList
    {
        public int count { get; set; }
        public List<string> resultdata { get; set; }

    }
    public class Review
    {
        public int review_type { get; set; }
        public int board_idx { get; set; }
        public int ref_board_idx { get; set; }
        public int ref_board_seq { get; set; }
        public string user_id { get; set; }
        public string subject { get; set; }
        public string content { get; set; }
        public string board_img_url_1 { get; set; }
        public string board_img_url_2 { get; set; }
        public string board_img_url_3 { get; set; }
        public string board_img_url_4 { get; set; }
        public string board_img_url_5 { get; set; }
        public string order_menu { get; set; }
        public string eval_score { get; set; }
        public string memo { get; set; }
        public string ins_date { get; set; }
        public string upd_date { get; set; }

    }
}
