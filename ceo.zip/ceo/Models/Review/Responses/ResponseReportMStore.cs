﻿using System.Collections.Generic;

namespace PosWebApp.Models.Review.Responses
{
    public class ResponseReportMStore
    {
        public int count { get; set; }
        public List<ReportMStoreBody> result_data { get; set; }
    }
    public class ReportMStoreBody
    {
        public string month { get; set; }
        public float tot_score { get; set; }
        public double answer_cnt { get; set; }
        public int tran_cnt { get; set; }
        public int photo_tran_cnt { get; set; }
        public int cnt_zero { get; set; }
        public int cnt_one { get; set; }
        public int cnt_two { get; set; }
        public int cnt_three { get; set; }
        public int cnt_four { get; set; }
        public int cnt_five { get; set; }
    }
}
