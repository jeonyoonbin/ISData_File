﻿using System.Collections.Generic;

namespace PosWebApp.Models.Review.Responses
{
    public class ResponseStoreList
    {
        public int count { get; set; }
        public List<Result_data> result_data { get; set; }

    }
    public class Result_data
    {
        public int store_idx { get; set; }
        public string store_code { get; set; }
        public string store_sub_idx { get; set; }
        public string cc_code { get; set; }
        public string store_name { get; set; }
    }
}
