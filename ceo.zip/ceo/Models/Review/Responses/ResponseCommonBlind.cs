﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Responses
{
    public class ResponseCommonBlind
    {
        public string orderNo { get; set; }
        public string status { get; set; }
        public string requestGbn { get; set; }
        public string blindReqDt { get; set; }
        public string blindReqCancelYn { get; set; }
        public string starScore { get; set; }
        public string custNickName { get; set; }
        public string content { get; set; }
        public string blindType { get; set; }
        public string blindCode { get; set; }
        public string blindName { get; set; }
        public string blindReason { get; set; }
        public string answerContent { get; set; }
        public string answerInsertDate { get; set; }
        public string insertDate { get; set; }
    }
}
