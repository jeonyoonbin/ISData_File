﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Responses
{
    public class ResponseReviewSelect
    {
        public int count { get; set; }
        public List<ReviewSelectBody> result_data { get; set; }
    }
    public class ReviewSelectBody
    {
        public int review_type { get; set; }
        public int board_idx { get; set; }
        public int ref_board_idx { get; set; }
        public int ref_board_seq { get; set; }
        public string user_id { get; set; }
        public string nick_name { get; set; }
        public string subject { get; set; }
        public string content { get; set; }
        public string board_img_url_1 { get; set; }
        public string board_img_url_2 { get; set; }
        public string board_img_url_3 { get; set; }
        public string board_img_url_4 { get; set; }
        public string board_img_url_5 { get; set; }
        public string order_menu { get; set; }
        public string order_num { get; set; }
        public double eval_score { get; set; }
        public string memo { get; set; }
        public string visible_opt { get; set; }
        public string ins_date { get; set; }
        public string upd_date { get; set; }

    }
}
