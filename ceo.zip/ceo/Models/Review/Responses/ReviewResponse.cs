﻿namespace PosWebApp.Models.Review.Responses
{
    public class Headers
    {
        public string AccessControllAllowOrigin { get; set; }
    }

    public class ReviewResponse<T>
    {
        public int statusCode { get; set; }
        public T body { get; set; }
        public Headers headers { get; set; }
    }
    public class ReviewResponse
    {
        public int statusCode { get; set; }
        public TokenBody body { get; set; }
        public Headers headers { get; set; }
    }
    public class TokenBody
    {
        public string error { get; set; }
        public string token { get; set; }
    }
}
