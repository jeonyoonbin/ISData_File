﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Responses
{
    public class ResponseReviewAnswer
    {
        public int total { get; set; }
        public int score1 { get; set; }
        public int score2 { get; set; }
        public int score3 { get; set; }
        public int score4 { get; set; }
        public int score5 { get; set; }
        
    }
}
