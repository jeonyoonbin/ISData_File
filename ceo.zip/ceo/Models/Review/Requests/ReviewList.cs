﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Requests
{
    public class ReviewList : ReviewRequest
    {
        public int page { get; set; }
    }
}
