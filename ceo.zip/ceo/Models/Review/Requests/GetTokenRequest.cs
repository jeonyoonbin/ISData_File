﻿namespace PosWebApp.Models.Review.Requests
{
    public class GetTokenRequest
    {
        public string token { get; set; }
    }
}
