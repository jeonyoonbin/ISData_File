﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Requests
{
    public class ReviewStoreList
    {
        public string member_company_code { get; set; } 
        public string type { get; set; }
        public string cc_code { get; set; } 
    }
}
