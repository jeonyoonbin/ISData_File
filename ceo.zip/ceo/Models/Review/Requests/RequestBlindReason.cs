﻿using PosWebApp.Models.RequestModel;
using PosWebApp.Models.Review.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Requests
{
    public class RequestBlindReason : Request
    {
        public string orderNo { get; set; }
        public string visibleGbn { get; set; }
        public string blindCode { get; set; } = "";
        public string blindReason { get; set; }
        public string blindEndDt { get; set; }
        public string modUcode { get; set; }
        public string modUName { get; set; }


    }
}
