﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Requests
{
    public class RequestReviewSelect
    {
        //public int store_idx { get; set; }
        public string store_code { get; set; }
        public string store_sub_idx { get; set; } = "00";
        public string cc_code { get; set; }
        //public int member_company_idx { get; set; }
        public string member_company_code { get; set; }
        public int page { get; set; }
        public string use_type { get; set; }
        public string visible_opt { get; set; }
        //public string user_id { get; set; }
       // public string img_only { get; set; }
        public string order_opt { get; set; }

    }
}
