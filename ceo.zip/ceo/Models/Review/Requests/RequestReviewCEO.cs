﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Requests
{
    public class RequestReviewCEO
    {
        public string shopCode { get; set; }
        public string pageCnt { get; set; }
        public string pageNum { get; set; }
        public string photoYn { get; set; }
        public string SortGbn { get; set; }
        public string JobGbn { get; set; }

    }
}
