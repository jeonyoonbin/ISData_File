﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Requests
{
    public class RequestReviewCeoAnswer
    {
        public string orderNo { set; get; }
        public string shopCode { set; get; }
        public string content { set; get; }
        public string modUcode { get; set; }
        public string modName { get; set; }
        public string answerVisibleGbn { set; get; }
    }
}
