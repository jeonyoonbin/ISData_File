﻿namespace PosWebApp.Models.Review.Requests
{
    public class RequestRegistStore
    {
        public string store_code { get; set; }
        public string store_sub_idx { get; set; } = "00";
        public string member_company_code { get; set; } = "daegu";
        public string cc_code { get; set; } = "";
        public string store_name { get; set; }
        public string owner { get; set; }
        public string addr1 { get; set; }
        public string addr2 { get; set; }
        public string tel_num { get; set; }
        public string email { get; set; }
        public string memo { get; set; }
        public string user_id { get; set; }
    }
}
