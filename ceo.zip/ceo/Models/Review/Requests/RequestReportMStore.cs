﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Requests
{
    public class RequestReportMStore
    {
        public string store_code { get; set; }
        public string store_sub_idx { get; set; } = "00";
        public string member_company_code { get; set; }
        // public int member_company_idx { get; set; }
        public string cc_code { get; set; }
    }
}
