﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review.Adm
{
    public class RequestBody
    {
        public string cmd { get; set; }
        public string body { get; set; }
    }
}
