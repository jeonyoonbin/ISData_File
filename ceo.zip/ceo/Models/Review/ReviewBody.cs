﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Review
{
    public class ReviewBody<T>
    {
        public string cmd { get; set; }
        public T body { get; set; }
        public string etc { get; set; }
    }
}
