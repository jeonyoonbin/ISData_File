﻿using PosWebApp.ApiModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.OrderArea
{
    public class RequestUpdateOrderArea : RequestCommon
    {
        public List<string> setbgn { get; set; }
        public string  sido { get; set; }
        public string  gungu { get; set; }
        public List<string> dong { get; set; }
    }
}
