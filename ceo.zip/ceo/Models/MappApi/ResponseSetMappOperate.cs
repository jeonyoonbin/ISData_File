﻿namespace PosWebApp.Models.MappApi
{
    public class ResponseSetMappOperate
    {
        public bool rest { get; set; }
    }
}
