﻿namespace PosWebApp.Models.MappApi
{
    public class RequestConnectionLog
    {
        public string in_job_gbn { get; set; }
        public string company_name { get; set; }
        public string company_store_code { get; set; }
        public string log_type { get; set; }
        public string ip { get; set; }
        public string mac { get; set; }
        public string memo { get; set; }
    }
}
