﻿namespace PosWebApp.Models.MappApi
{
    public class ResponseSetMappMenuSoldout
    {
        public string menu_group_code { get; set; }
        public string menu_code { get; set; }
        public bool soldout { get; set; }
    }
}
