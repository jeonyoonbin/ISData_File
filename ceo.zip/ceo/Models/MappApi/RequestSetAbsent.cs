﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.MappApi
{
    public class RequestSetAbsent
    {
        public string in_job_gbn { get; set; }
        public string company_name { get; set; }
        public string company_store_code { get; set; }
        public string absent_gbn { get; set; }
        public string absent_time { get; set; }
    }
}
