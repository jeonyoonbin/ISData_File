﻿namespace PosWebApp.Models.MappApi
{
    public class ResponseMappMenuList
    {
        public int sort_seq { get; set; }
        public string menu_group_code { get; set; }
        public string menu_group_name { get; set; }
        public string menu_code { get; set; }
        public string menu_name { get; set; }
        public bool soldout { get; set; }
    }
}
