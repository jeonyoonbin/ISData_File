﻿namespace PosWebApp.Models.MappApi
{
    public class ResponseUserAgreement
    {
        public string agreement { get; set; }
    }
}
