﻿namespace PosWebApp.Models.MappApi
{
    public class RequestSetMappMenuSoldout
    {
        public string job_gbn { get; set; }
        public string company_name { get; set; }
        public string company_code { get; set; }
        public string menu_code { get; set; }
        public bool soldout { get; set; }
    }
}
