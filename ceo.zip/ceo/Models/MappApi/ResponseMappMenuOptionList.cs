﻿namespace PosWebApp.Models.MappApi
{
    public class ResponseMappMenuOptionList
    {
        public int sort_seq { get; set; }
        public string menu_cd { get; set; }
        public string option_group_cd { get; set; }
        public string option_group_name { get; set; }
        public string option_cd { get; set; }
        public string option_name { get; set; }
        public bool soldout { get; set; }
    }
}
