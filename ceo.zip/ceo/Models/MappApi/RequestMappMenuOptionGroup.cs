﻿namespace PosWebApp.Models.MappApi
{
    public class RequestMappMenuOptionGroup
    {
        public string job_gbn { get; set; }
        public string company_name { get; set; }
        public string company_shop { get; set; }
        public string menu_code { get; set; }
    }
}
