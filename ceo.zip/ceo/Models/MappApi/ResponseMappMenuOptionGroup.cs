﻿namespace PosWebApp.Models.MappApi
{
    public class ResponseMappMenuOptionGroup
    {
        public int sort_seq { get; set; }
        public string menu_code { get; set; }
        public string option_group_code { get; set; }
        public string option_group_name { get; set; }
    }
}
