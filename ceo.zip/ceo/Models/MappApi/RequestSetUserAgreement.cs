﻿namespace PosWebApp.Models.MappApi
{
    public class RequestSetUserAgreement
    {
        public string job_gbn { get; set; }
        public string company_name { get; set; }
        public string company_store_code { get; set; }
        public string device_type { get; set; }
        public string device_info { get; set; }
        public string pos_id { get; set; }
    }
}
