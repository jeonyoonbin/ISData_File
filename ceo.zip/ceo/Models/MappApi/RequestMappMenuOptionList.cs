﻿namespace PosWebApp.Models.MappApi
{
    public class RequestMappMenuOptionList
    {
        public string job_gbn { get; set; }
        public string company_name { get; set; }
        public string company_shop { get; set; }
        public string option_group_code { get; set; }

    }
}
