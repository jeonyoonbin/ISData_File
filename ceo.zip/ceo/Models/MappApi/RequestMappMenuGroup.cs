﻿namespace PosWebApp.Models.MappApi
{
    public class RequestMappMenuGroup
    {
        public string job_gbn { get; set; }
        public string company_name { get; set; }
        public string company_shop { get; set; }

    }
}
