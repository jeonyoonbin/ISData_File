﻿using DocumentFormat.OpenXml.Office2013.PowerPoint.Roaming;
using System.Runtime.InteropServices;

namespace PosWebApp.Models.MappApi
{
    public class RequestSetMappOperate : SecurityCode
    { 
        public string job_gbn { get; set; }
        public string company_name { get; set; }
        public string company_shop { get; set; }
        public string absent_gbn { get; set; }
        public string absent_time { get; set; }
        public bool rest { get; set; }
    }
}