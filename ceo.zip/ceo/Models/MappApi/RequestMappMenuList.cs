﻿namespace PosWebApp.Models.MappApi
{
    public class RequestMappMenuList
    {
        public string job_gbn { get; set; }
        public string company_gbn { get; set; }
        public string company_shop { get; set; }
        public string menu_group_code { get; set; }
    }
}
