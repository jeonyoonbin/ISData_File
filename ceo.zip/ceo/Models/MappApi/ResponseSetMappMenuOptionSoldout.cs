﻿namespace PosWebApp.Models.MappApi
{
    public class ResponseSetMappMenuOptionSoldout
    {
        public string option_group_code { get; set; }
        public string option_code { get; set; }
        public bool soldout { get; set; }

    }
}
