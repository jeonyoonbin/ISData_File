﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.MappApi
{
    public class SecurityCode
    {
        public string key { get; set; }

    }
}
