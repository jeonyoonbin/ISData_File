﻿namespace PosWebApp.Models.MappApi
{
    public class RequestGetUserAgreement
    {
        public string job_gbn { get; set; }
        public string company_name { get; set; }
        public string company_store_code { get; set; }
    }
}
