﻿namespace PosWebApp.Models.MappApi
{
    public class RequestSetmappMenuOptionSoldout
    {
        public string job_gbn { get; set; }
        public string company_name { get; set; }
        public string company_shop { get; set; }
        public string option_code { get; set; }
        public bool soldout { get; set; }
    }
}
