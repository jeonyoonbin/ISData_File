﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Event
{
    public class RequestEventMenu
    {
        public string menu_cd { get; set; }
        public string menu_name { get; set; }
        public string menu_cost { get; set; }
        public string disc_cost { get; set; }
        public string event_amt_gbn { get; set; }
        public string menu_seq { get; set; }

    }
}
