﻿namespace PosWebApp.Models.Event
{
    public class ResponseShopEventList
    {
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string cccode { get; set; }
        public string ccname { get; set; }
        public string event_seq { get; set; }
        public string event_gbn { get; set; }
        public string use_gbn { get; set; }
        public string menu_cd { get; set; }
        public string menu_name { get; set; }
        public string menu_cost { get; set; }
        public string disc_menu_cost { get; set; }
        public string order_date { get; set; }
        public string start_time { get; set; }
        public string end_time { get; set; }
        public string event_amt_gbn { get; set; }
        public string event_amt { get; set; }
        public string event_title { get; set; }
        public string insert_name { get; set; }
        public string insert_date { get; set; }
        public string mod_name { get; set; }
        public string mod_date { get; set; }
        public string push_send_yn { get; set; }
    }
}
