﻿using PosWebApp.Models.RequestModel;
using PosWebApp.ViewModels.UnExpectedEvent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Event
{
    public class RequestLiveEvent : Request
    {
        public string start_time { get; set; }
        public string end_time { get; set; }
        public bool use_yn { get; set; }
        public string overUse_gbn { get; set; } = "N"; // MST overLap defualt N 
        public string event_title { get; set; }
        public string options { get; set; }
        public string ins_name { get; set; }
        public List<EventTableViewModel> eventList { get; set; }
    }
}
