﻿using PosWebApp.Models.RequestModel;

namespace PosWebApp.Models.Event
{
    public class RequestShopEventDetail : Request
    {
        public int event_seq { get; set; }
    }
}
