﻿using PosWebApp.Models.RequestModel;

namespace PosWebApp.Models.Event
{
    public class RequestShopEventNoUse : Request
    {
        public int menu_cd { get; set; }
        public string ins_name { get; set; }

    }
}
