﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Event
{
    public class EventSales
    {
        public bool sales { get; set; }
        public string eventAmt { get; set; }
        public List<EventMenu> MenuList { get; set; }
    }
}
