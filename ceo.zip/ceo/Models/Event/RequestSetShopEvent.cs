﻿using PosWebApp.Models.RequestModel;

namespace PosWebApp.Models.Event
{
    public class RequestSetShopEvent : Request
    {
        public string event_gbn { get; set; }
        public int menu_cd { get; set; }
        public string from_time { get; set; }
        public string to_time { get; set; }
        public string event_amt_gbn { get; set; }
        public string event_amt { get; set; }
        public string ins_name { get; set; }
        public string event_title { get; set; }
    }
}
