﻿using PosWebApp.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Event
{
    public class RequestShopEventList : Request
    {
        public string event_gbn { get; set; }
        public string use_gbn { get; set; }
        public string from_date { get; set; }
        public string to_date { get; set; }
    }
}
