﻿namespace PosWebApp.Models.Event
{
    public class EventMenu
    {
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string menu_group_cd { get; set; }
        public string menu_group_name { get; set; }
        public string menu_cd { get; set; }
        public string menu_name { get; set; }
        public string no_flag { get; set; }
        public string menu_cost { get; set; }
        public string cheackYN { get; set; }
        public string saleQnt { get; set; }

    }
}
