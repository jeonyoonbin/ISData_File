﻿namespace PosWebApp.Models.Event
{
    public class ResponseShopEventDetail
    {
        public int event_seq { get; set; }
        public string event_gbn { get; set; }
        public string use_gbn { get; set; }
        public string menu_cd { get; set; }
        public string order_date { get; set; }
        public string from_time { get; set; }
        public string to_time { get; set; }
        public string event_title { get; set; }
        public string event_con { get; set; }
        public string event_amt_gbn { get; set; }
        public string event_amt { get; set; }
        public string insert_name { get; set; }
        public string insert_date { get; set; }
        public string mod_name { get; set; }
        public string mod_date { get; set; }
    }
}
