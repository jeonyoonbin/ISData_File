﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Event
{
    public class ResponseGetLiveEvent
    {
        public string shop_name { get; set; }
        public string shop_logo { get; set; }
        public string event_yn { get; set; }
        public string event_title { get; set; }
        public string fr_time { get; set; }
        public string to_time { get; set; }
        public string remaining_time { get; set; }
        public string push_yn { get; set; }
        public List<ResponseShopEventList> MenuList { get; set; }
    }
}
