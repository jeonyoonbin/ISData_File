﻿using PosWebApp.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.RequestDaeguroPos
{
    public class RequestRegistAndMappDaeguroPos
    {
        public string app_name { get; set; } = "DAEGURO";
        public string app_type { get; set; } = "1";
        public RequestDaeguroPosRegistShop shop_info { get; set; }
    }
    public class RequestDaeguroPosRegistShop
    {
        public RequestDaeguroPosRegistShop()
        {

        }
        public RequestDaeguroPosRegistShop(SynchronizeShopInfo daeguroShopInfo)
        {
            this.job_gbn = "UPDATE";

            this.mcode = mcode;
            this.cccode = cccode;

            this.shop_name = daeguroShopInfo.shop_name;
            this.login_id = daeguroShopInfo.api_com_id;
            this.login_pw = daeguroShopInfo.api_com_pass; // default : eornfh
            this.owner = daeguroShopInfo.buss_owner;
            this.reg_no = daeguroShopInfo.reg_no;
            this.telno = daeguroShopInfo.telno;
            this.mobile = daeguroShopInfo.mobile;

            this.use_gbn = "Y";

            this.address = string.Join(' ', daeguroShopInfo.sido, daeguroShopInfo.sigungu, daeguroShopInfo.road, daeguroShopInfo.build_no);
            this.sido = daeguroShopInfo.sido;
            this.sigungu = daeguroShopInfo.sigungu;
            this.bdong = daeguroShopInfo.dong;
            this.address_detail = daeguroShopInfo.build_name;
            this.road = daeguroShopInfo.road;

            this.lon = string.IsNullOrEmpty(daeguroShopInfo.lon) ? 0 : Convert.ToDouble(daeguroShopInfo.lon);
            this.lat = string.IsNullOrEmpty(daeguroShopInfo.lat) ? 0 : Convert.ToDouble(daeguroShopInfo.lat);
            this.mod_ucode = "DAEGURO";

            this.account_bankcode = daeguroShopInfo.bank_code;
            this.account_no = daeguroShopInfo.acc_no;
            this.account_owner = daeguroShopInfo.acc_owner;

            this.shop_token = daeguroShopInfo.api_com_code;

        }

        public string job_gbn { get; set; }
        public string pos_no { get; set; }
        public string mcode { get; set; }
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string use_gbn { get; set; }
        public string login_id { get; set; }
        public string login_pw { get; set; }
        public string shop_name { get; set; }
        public string shop_key { get; set; }
        public string shop_manage { get; set; }
        public string address { get; set; }
        public string address_detail { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string bdong { get; set; }
        public string hdong { get; set; }
        public string ri { get; set; }
        public string road { get; set; }
        public double lon { get; set; }
        public double lat { get; set; }
        public string telno { get; set; }
        public string mobile { get; set; }
        public string reg_no { get; set; }
        public string owner { get; set; }
        public string zone_code { get; set; }
        public string mod_ucode { get; set; } = "DAEGURO";
        public string account_owner { get; set; }
        public string account_no { get; set; }
        public string account_bankcode { get; set; }
        public string shop_token { get; set; }
        public string shop_mac { get; set; }    // 사용안함


    }
}
