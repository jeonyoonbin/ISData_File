﻿namespace PosWebApp.Models.RequestDaeguroPos
{
    public class RqeuestPosLink
    {
        public string job_gbn { get; set; }
        public string mapp_type { get; set; }
        public string mapp_gbn { get; set; }
        public string mapp_code { get; set; }
    }
}
