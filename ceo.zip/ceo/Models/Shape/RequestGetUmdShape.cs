﻿namespace PosWebApp.Models.Shape
{
    public class RequestGetUmdShape
    {
        public string job_gbn { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umd { get; set; }
    }
}
