﻿namespace PosWebApp.Models.AdmAcc
{
    public class RequestAdmAccountConfirm
    {
        public string bank_code { get; set; }
        public string account_no { get; set; }
        public string account_owner { get; set; }
    }
}
