﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.AdmAcc
{
    public class RequestAdmAccountConfirmV2
    {
        public string bankCd{ get; set; }
        public string accountNo { get; set; }
        public string accountNm { get; set; }
        public string accountGb { get;} = "1";
        public string systemGb { get; } = "IS_DAEGU";
        public string mcode { get; } = "1";
        public string cccode { get; } = "1";
        public string ucode { get;} = "0";
    }
}
