﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation
{
    public class ReservationPage
    {
        public int page { get; set; }
        public int pageRows { get; set; }
    }
}
