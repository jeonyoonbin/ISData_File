﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Store.Request
{
    public class RequestReservationOwnerIntro
    {
        public string shopCd { get; set; }
        public string ccCode { get; set; }
        public string notice { get; set; }
        public string userID { get; set; }
    }
}
