﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Store.Request
{
    public class RequestReservationReviewIntro : RequestCommon
    {
        public string shopReviewIntro { get; set; }
    }
}
