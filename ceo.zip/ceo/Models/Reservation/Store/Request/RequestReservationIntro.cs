﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Store.Request
{
    public class RequestReservationIntro : RequestCommon
    {
        public string introduce { get; set; }
    }
}
