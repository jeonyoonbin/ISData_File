﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Store.Request
{
    public class RequestNonuAmount
    {
        public string shopCode { get; set; }
        public string userId { get; set; }
        public string menuCostShowGbn { get; set; }
    }
}
