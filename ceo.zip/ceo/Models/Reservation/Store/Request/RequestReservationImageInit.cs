﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Store.Request
{
    public class RequestReservationImageInit
    {
        public string ccCode { get; set; }
        public string shopCode { get; set; }
        public IFormFile file { get; set; }

    }
}
