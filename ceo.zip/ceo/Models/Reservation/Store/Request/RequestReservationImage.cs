﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Store.Request
{
    public class RequestReservationImage
    {
        public string type { get; set; }
        public string ccCode { get; set; }
        public string shopCode { get; set; }
        public int seq { get; set; }
        public string userId { get; set; }
    }
}
