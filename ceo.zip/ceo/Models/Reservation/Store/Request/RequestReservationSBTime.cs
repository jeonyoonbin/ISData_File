﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Store.Request
{
    public class RequestReservationSBTime
    {

        public string shopCode { get; set; }
        public string sbGbn { get; set; }
        public List<sbTimeUnit> sbTimeUnit { get; set; }
    }
    public class sbTimeUnit
    {
        public string dayGbn { get; set; }
        public string openTime { get; set; }
        public string closeTime { get; set; }
        public string closeGbn { get; set; }
    }
}
