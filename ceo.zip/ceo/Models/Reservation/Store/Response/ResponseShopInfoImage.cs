﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Store.Response
{
    public class ResponseShopInfoImage
    {
        public string seq { get; set; }
        public string noticeName { get; set; }
        public string fileName { get; set; }
        public string fileUrl { get; set; }
        public string sortSeq { get; set; }
        public string reviewFile1 { get; set; }
        public string reviewFile2 { get; set; }
    }
}
