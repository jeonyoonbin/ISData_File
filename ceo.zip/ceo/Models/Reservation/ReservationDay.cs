﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation
{
    public class ReservationDay
    {
        public string reserDate { get; set; }
        public string status10 { get; set; }
        public string status12 { get; set; }
        public string status30 { get; set; }
        public string status40 { get; set; }
        public string status90 { get; set; }

        public string text10 { get; set; }
        public string text12 { get; set; }
        public string text30 { get; set; }
        public string text40 { get; set; }
        public string text90 { get; set; }
    }
}
