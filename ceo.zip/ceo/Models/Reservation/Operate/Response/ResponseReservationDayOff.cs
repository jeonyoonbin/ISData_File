﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Operate.Response
{
    public class ResponseReservationDayOff
    {
        public string shopCode { get; set; }
        public string gbn { get; set; }
        public List<dayItems> list {get;set;}
        
    }
    public class dayItems
    {
        public int seq { get; set; }
        public string foDay { get; set; }
        public string toDay { get; set; }
    } 
}
