﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Operate.Response
{
    public class ResponseDaySearch
    {
        public string orderDate { get; set; }
        public string time { get; set; }
        public string reserYN { get; set; }
        public string cnt { get; set; }
        public string personCnt { get; set; }
        public string  shopCode { get; set; }
    }
}
