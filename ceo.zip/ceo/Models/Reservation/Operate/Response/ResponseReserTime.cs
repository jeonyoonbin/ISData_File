﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Operate.Response
{
    public class ResponseReserTime
    {
        public string dayGbn { get; set; }
        public string closeGbn { get; set; }
        public List<ReserTimeSub> reserTime { get; set; }
    }
    public class ReserTimeSub
    {
        public string time { get; set; }
        public string gbn { get; set; }
    }
}
