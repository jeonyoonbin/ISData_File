﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Operate.Response
{
    public class ResponseHourlyMaxPeople
    {
        public string casesCnt { get; set; }
        public string peopleCnt { get; set; }
    }
}
