﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Operate.Request
{
    public class RequestDaySearch
    {
        public string shopCode { get; set; }
        public string from { get; set; }
    }
}
