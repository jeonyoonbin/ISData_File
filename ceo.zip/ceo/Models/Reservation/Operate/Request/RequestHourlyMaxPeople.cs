﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Operate.Request
{
    public class RequestHourlyMaxPeople : RequestCommon
    {
        public string casesCnt { get; set; }
        public string peopleCnt { get; set; }
    }
}
