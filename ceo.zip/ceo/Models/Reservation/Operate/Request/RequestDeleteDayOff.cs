﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Operate.Request
{
    public class RequestDeleteDayOff
    {
        public string shopCode { get; set; }
        public string gbn { get; set; }
        public int seq { get; set; }
        public string foDay { get; set; }
        public string toDay { get; set; }
    }
}
