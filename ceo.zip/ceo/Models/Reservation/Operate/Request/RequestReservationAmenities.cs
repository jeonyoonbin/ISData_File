﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Operate.Request
{
    public class RequestReservationAmenities : RequestCommon
    {
        public string facilities_1 { get; set; }
        public string facilities_2 { get; set; }
        public string facilities_3 { get; set; }
        public string facilities_4 { get; set; }
        public string facilities_5 { get; set; }
        public string facilities_6 { get; set; }
        public string facilities_7 { get; set; }
        public string facilities_8 { get; set; }
        public string facilities_9 { get; set; }
        public string facilities_10 { get; set; }
    }
}
