﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Operate.Request
{
    public class RequestStatus
    {
        public string running { get; set; }
    }
}
