﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Operate.Request
{
    public class RequestReserTime
    {
        public string shopCode { get; set; }
        public string userId { get; set; }
        public List<ReserTimeItem> reserTimePostUnits { get; set; }
    }
    public class ReserTimeItem
    {
        public string dayGbn { get; set; }
        public string time { get; set; }
    }
}
