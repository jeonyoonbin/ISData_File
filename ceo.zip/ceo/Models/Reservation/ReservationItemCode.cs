﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation
{
    public class ReservationItemCode
    {
       public string code {get;set;}
       public string nameMain {get;set;}
    }
}
