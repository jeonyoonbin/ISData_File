﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Main
{
    public class RequestReservationIntro
    {
        public string shopCd { get; set; }
        public string uCode { get; set; }
        public string userName { get; set; }
        public string gbn { get; set; }
    }
}
