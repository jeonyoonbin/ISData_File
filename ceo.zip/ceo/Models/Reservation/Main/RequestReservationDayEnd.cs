﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Main
{
    public class RequestReservationDayEnd
    {
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string shopCode { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string ccCode { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string userId { get; set; } //수정자
        public string reserMagamGbn { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public bool reserMagamBool { get; set; }
    }
}
