﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.News.Response
{
    public class ResponseNewsSingle
    {
        public string shopCd { get; set; }
        public string seq { get; set; }
        public string title { get; set; }
        public string contents { get; set; }
        public string useGbn { get; set; }
        public string sortSeq { get; set; }
    }
}
