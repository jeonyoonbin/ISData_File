﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.News.Response
{
    public class ResponseReservationList
    {
        public int count { get; set; }
        public List<NewsList> list { get; set; }
    }
    public class NewsList
    {
        public int rNum { get; set; }
        public string shopCd { get; set; }
        public int seq { get; set; }
        public string title { get; set; }
        public string contents { get; set; }
        public string insertDate { get; set; }
        public string useGbn { get; set; }
        public int sortSeq { get; set; }
    }
}
