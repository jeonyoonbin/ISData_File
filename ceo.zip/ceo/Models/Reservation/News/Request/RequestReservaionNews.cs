﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.News.Request
{
    public class RequestReservaionNews
    {
        public string shopCd { get; set; }
        public string typeGbn { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public int seq { get; set; }
        public string title { get; set; }
        public string contents { get; set; }
        public string useGbn { get; set; }
    }
}
