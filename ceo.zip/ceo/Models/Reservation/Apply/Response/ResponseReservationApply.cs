﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Apply.Response
{
    public class ResponseReservationApply
    {
        public string gbn { get; set; }
        public string applyDate { get; set; }
        public string status { get; set; }
    }


    
}
