﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace PosWebApp.Models.Reservation
{
    public class RequestCommon
    {
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string shopCd { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string ccCode { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string userId { get; set; } //수정자

    }
}
