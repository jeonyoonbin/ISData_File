﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Condition.Response
{
    public class ResponseReservationData
    {
        public string shopCd { get; set; }
        public string orderNo { get; set; }
        public string reserDate { get; set; }
        public string reserTime { get; set; }
        public string custCode { get; set; }
        public string custId { get; set; }
        public string custName { get; set; }
        public string custTelno { get; set; }
        public string mobileNo { get; set; }
        public string mobileNo1 { get; set; }
        public string injengGbn { get; set; }
        public string personCnt { get; set; }
        public string status { get; set; }
        public string allocDate { get; set; }
        public string compDate { get; set; }
        public string cancelDate { get; set; }
        public string payGbn { get; set; }
        public string orderNoCard { get; set; }
        public string location { get; set; }
        public string memo { get; set; }
        public string isrtDate { get; set; }
        public string modDate { get; set; }
        public string modId { get; set; }
        public string modGbn { get; set; }

        public string myNumber { get; set; }
    }
}
