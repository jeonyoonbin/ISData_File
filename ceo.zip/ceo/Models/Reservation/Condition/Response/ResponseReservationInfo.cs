﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Condition.Response
{
    public class ResponseReservationInfo
    {
        //확정대기
        public string status10 { get; set; }
        //확정
        public string status12 { get; set; }
        //방문완료
        public string status30 { get; set; }
        //취소
        public string status40 { get; set; }
        //미방문
        public string status90 { get; set; }

    }
}
