﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Condition.Request
{
    public class RequestReservationInfo : RequestCommon
    {
        public string dateBegin { get; set; }
        public string dateEnd { get; set; }
    }
}
