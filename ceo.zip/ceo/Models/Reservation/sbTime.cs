﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation
{
    public class sbTime
    {
        public string shopCode { get; set; }
        public string sbGbn { get; set; }
        public string dayGbn { get; set; }
        public string openTime { get; set; }
        public string closeTime { get; set; }
        public string closeGbn { get; set; }
    }
}
