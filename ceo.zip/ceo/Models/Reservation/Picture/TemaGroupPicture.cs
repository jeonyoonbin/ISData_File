﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Picture
{
    public class TemaGroupPicture
    {
        public string temaName { get; set; }
        public string temaCode { get; set; }
    }
}
