﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Picture.Request
{
    public class RequestReservationSort
    {
        public string ccCode { get; set; }
        public string shopCode { get; set; }
        public string[] seq { get; set; }
    }
}
