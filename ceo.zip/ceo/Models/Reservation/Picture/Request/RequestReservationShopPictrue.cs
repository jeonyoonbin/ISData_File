﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Picture.Request
{
    public class RequestReservationShopPictrue : RequestCommon
    {
        public int seq { get; set; }
        public IFormFile file { get; set; }
        public byte[] imagebinary { get; set; }
        public int sortSeq { get; set; }
        public string temaName { get; set; }
        public string temaCode { get; set; }
        public string exposureGbn { get; set; }
    }
}
