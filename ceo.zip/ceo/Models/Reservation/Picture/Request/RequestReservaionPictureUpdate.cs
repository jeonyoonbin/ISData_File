﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Picture.Request
{
    public class RequestReservaionPictureUpdate : RequestCommon
    {
        public string shopCode { get; set; }
        public List<Pictureinfo> pictureInfos { get; set; }
    }
    public class Pictureinfo
    {
        public int seq { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public int sortSeq { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string temaCode { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string exposureGbn { get; set; }
    }
}
