﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.Picture.Response
{
    public class ResponseShopPictureList
    {
        public int count { get; set; }
        public List<PictureList> items { get; set; }
    }
    public class PictureList
    {
        public int seq { get; set; }
        public string noticeName { get; set; }
        public string fileName { get; set; }
        public string fileUrl { get; set; }
        public int sortSeq { get; set; }
        public string temaName { get; set; }
        public string temaCode { get; set; }
        public string exposureGbn { get; set; }
    }
}
