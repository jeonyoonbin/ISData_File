﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Reservation.items
{
    public class reservationDayOffItem
    {
        public string code { get; set; }
        public string nameMain { get; set; }
        public string name { get; set; }
        public string url { get; set; }
        public string useGbn { get; set; }
        public int sortSeq { get; set; }
        public string mainVisibleGbn { get; set; }
        public string gunguUseGbn { get; set; }
    }
}
