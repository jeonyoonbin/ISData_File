﻿namespace PosWebApp.Models.ResponseDaeguroPos
{
    public class ResponseDaeguroPosInsert : Response
    {
        public string shop_token { get; set; }
        public Pos_ShopInfo pos_shop_info { get; set; }
    }
    public class Pos_ShopInfo
    {
        public string gubun { get; set; } //pos no
        public string mcode { get; set; }
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string use_gbn { get; set; }
        public string login_id { get; set; }
        public string shop_name { get; set; }
        public string address { get; set; }
        public string address_detail { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string bdong { get; set; }
        public string hdong { get; set; }
        public string ri { get; set; }
        public string road { get; set; }
        public double lon { get; set; }
        public double lat { get; set; }
        public string telno { get; set; }
        public string mobile { get; set; }
        public string reg_no { get; set; }
        public string owner { get; set; }
        public string zone_code { get; set; }
        public string mod_ucode { get; set; }
    }
}
