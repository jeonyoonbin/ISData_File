﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseDaeguroPos
{
    public class MembershipList
    {
        public List<Membership> mList { get; set; }
        public string msg { get; set; }
        public string code { get; set; }
        public string message { get; set; }
        public string extras { get; set; }
    }
    public class Membership
    {
        public string mcode { get; set; }
        public string mname { get; set; }
        public string use_gbn { get; set; }
        public string memo { get; set; }
        public string update_path { get; set; }
        public string update_version { get; set; }
        public string update_path_mobile { get; set; }
    }
}
