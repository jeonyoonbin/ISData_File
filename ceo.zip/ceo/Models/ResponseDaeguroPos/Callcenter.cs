﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseDaeguroPos
{
    public class CenterList
    {
        public string code { get; set; }
        public string msg { get; set; }
        public string message { get; set; }
        public List<Callcenter> ccList { get; set; }
        //public string extras { get; set; }
    }

    public class Callcenter
    {
        public string cccode { get; set; }
        public string ccname { get; set; }
        public string use_gbn { get; set; }
        public string memo { get; set; }
    }
}
