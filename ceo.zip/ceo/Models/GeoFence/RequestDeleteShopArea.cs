﻿namespace PosWebApp.Models.GeoFence
{
    public class RequestDeleteShopArea
    {
        public string job_gbn { get; set; }
        public int shop_cd { get; set; }
        public int area_sequence { get; set; }
        public int fence_sequence { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umd { get; set; }
        public string ri { get; set; }
    }
}
