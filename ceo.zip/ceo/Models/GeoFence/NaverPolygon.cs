﻿using PosWebApp.Models.Shape;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PosWebApp.Models.GeoFence
{
    public class NaverPolygon
    {
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umd { get; set; }
        public string ri { get; set; }

        public int shop_cd { get; set; }
        public int area_sequence { get; set; }
        /// <summary>
        /// 구역 순번
        /// </summary>
        public int fence_sequence { get; set; }
        public int amount { get; set; }
        public string insert_type { get; set; }
        public string full_addr { get; set; }

        public int id { get; set; }
        public string name { get; set; }
        public string use_fence { get; set; }
        public List<NaverMapPoint> paths { get; set; }
        /// <summary>
        ///  geojson point type
        /// </summary>
        public List<List<double>> paths_origin { get; set; }
        

        public string fillColor { get; set; } = "blue";
        public string strokeColor { get; set; } = "blue";
        public double fillOpacity { get; set; } = 0.1;
        public int strokeWeight { get; set; } = 2;

        public string MakePathString()
        {
            List<string> geoPointList = new List<string>();

            foreach (var path in paths)
            {
                var geoPoint = string.Format($"[{path.x},{path.y}]");
                geoPointList.Add(geoPoint);
            }

            return string.Join(",", geoPointList);
        }

        public string ToPolygonString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"var {umd} = new naver.maps.Polygon");
            sb.AppendLine("({");

            sb.AppendLine($"\t{nameof(sido)}: '{sido}',");
            sb.AppendLine($"\t{nameof(sigungu)}: '{sigungu}',");
            sb.AppendLine($"\t{nameof(umd)}: '{umd}',");
            sb.AppendLine($"\t{nameof(paths)}: [ {MakePathString()} ],");
            sb.AppendLine($"\t{nameof(fillColor)}: '{fillColor}',");
            sb.AppendLine($"\t{nameof(strokeWeight)}: {strokeWeight},");
            sb.AppendLine($"\t{nameof(strokeColor)}: '{strokeColor}',");
            sb.AppendLine($"\t{nameof(fillOpacity)}: {fillOpacity},");

            sb.AppendLine($"{nameof(strokeWeight)}: {strokeWeight},");
            sb.Append("})");

            return sb.ToString();
        }
    }

    public class NaverPolygonArray
    {
        public List<NaverMapPoint> _array { get; set; }
        public int length { get; set; }
    }
    public class ShopFence
    {
        public int area { get; set; }
        public int fence_seq { get; set; }
        public string fence_name { get; set; }
        public string fence_amount { get; set; }
        public string use_fence { get; set; }
        public List<List<double>> areaPoints { get; set; }
        public NaverPolygonArray fence { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umd { get; set; }
        public string ri { get; set; }
        public string full_addr { get; set; }
        public string insert_type { get; set; }
    }
    public class FenceInfo
    {
        
        public int shop_cd { get; set; }
        public int fence_seq { get; set; }
        public int shape_seq { get; set; }
        public string fence_name { get; set; }
        public string fence_amount { get; set; }
        public string use_fence { get; set; }
        public double lon_x { get; set; }
        public double lat_y { get; set; }
    }

    /// <summary>
    /// 등록 된 상점의 Geofencing 좌표 정보를 가져온다
    /// </summary>
    public class FenceInfoNew
    {
        public string shop_cd { get; set; }
        public string master_slave_gbn { get; set; }
        public string full_addr { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umd { get; set; }
        public string ri { get; set; }
        public string area_name { get; set; }
        public string amount { get; set; }
        public string insert_type { get; set; }
        public string use_gbn { get; set; }
        public int area_sequence { get; set; }
        public int shape_sequence { get; set; }
        public double lon_x { get; set; }
        public double lat_y { get; set; }
        public List<FencePoint> points { get; set; }
    }
    public class FencePoint
    {
        public int shape_sequence { get; set; }
        public double lon_x { get; set; }
        public double lat_y { get; set; }
    }
}
