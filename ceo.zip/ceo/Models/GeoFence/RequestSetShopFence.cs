﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.GeoFence
{
    public class RequestSetShopFence
    {
        public string job_gbn { get; set; }
        public int shop_cd { get; set; }
        public int fence_sequence { get; set; }
        public string fence_name { get; set; }
        public List<ShopFence> shop_fences { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umd { get; set; }
        public string ri { get; set; }
        public string use_gbn { get; set; }
        public string insert_type { get; set; }
        public string amount { get; set; }

        public string mod_code { get; set; }
        public string mod_user { get; set; }
    }
}
