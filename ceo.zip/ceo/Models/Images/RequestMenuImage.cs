﻿using Microsoft.AspNetCore.Http;
using PosWebApp.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Images
{
    public class RequestMenuImage : Request
    {
        public string div { get; set; }
        public string menu_cd {get;set;}
        public string menu_name { get; set; }
        public string salesmanCode { get; set; }
        public string salesmanName { get; set; }
        public IFormFile formFile { get; set; }
    }
}
