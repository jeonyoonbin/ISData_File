﻿using PosWebApp.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Tax.Request
{
    public class RequestTax : RequestCommon
    {
        public string meetYn { get; set; }
        public string from { get; set; }
        public string to { get; set; }

    }
}
