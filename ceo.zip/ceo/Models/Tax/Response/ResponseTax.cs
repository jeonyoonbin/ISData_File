﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Tax.Response
{
    public enum TaxType
    {
        ETC = 1,
        ExcelSales = 3,
        ExcelPurchase = 5
    }
    public class ResponseTax
    {
        public ResponseTax(TaxType type, DbDataReader row)
        {
            switch (type)
            {
                case TaxType.ETC:
                    TaxTypeETC(row);
                    break;
                case TaxType.ExcelSales:
                    TaxTypeExcelSales(row);
                    break;
                case TaxType.ExcelPurchase:
                    TaxTypeExcelPurchase(row);
                    break;
            }
        }
        private void TaxTypeETC(DbDataReader reader)
        {
            card_amt = reader["card_amt"].ToString();
            card_vat_amt = reader["card_vat_amt"].ToString();
            total_card_amt = reader["total_card_amt"].ToString();
            cash_amt = reader["cash_amt"].ToString();
            cash_vat_amt = reader["cash_vat_amt"].ToString();
            total_cash_amt = reader["total_cash_amt"].ToString();
            etc_amt = reader["etc_amt"].ToString();
            etc_vat_amt = reader["etc_vat_amt"].ToString();
            total_etc_amt = reader["total_etc_amt"].ToString();
            meet_cash_amt = reader["meet_cash_amt"].ToString();
            meet_cash_vat_amt = reader["meet_cash_vat_amt"].ToString();
            total_meet_cash_amt = reader["total_meet_cash_amt"].ToString();
            meet_card_amt = reader["meet_card_amt"].ToString();
            meet_card_vat_amt = reader["meet_card_vat_amt"].ToString();
            total_meet_card_amt = reader["total_meet_card_amt"].ToString();
            pg_fee_amt = reader["pg_fee_amt"].ToString();
            pg_fee_vat_amt = reader["pg_fee_vat_amt"].ToString();
            pg_fee_cnt = reader["pg_fee_cnt"].ToString();
            total_pg_fee_amt = reader["total_pg_fee_amt"].ToString();
            app_fee_amt = reader["app_fee_amt"].ToString();
            app_fee_vat_amt = reader["app_fee_vat_amt"].ToString();
            app_fee_cnt = reader["app_fee_cnt"].ToString();
            total_app_fee_amt = reader["total_app_fee_amt"].ToString();
            from_date = reader["from_date"].ToString();
            to_date = reader["to_date"].ToString();
            buss_name = reader["buss_name"].ToString();
            buss_owner = reader["buss_owner"].ToString();
            regno = reader["regno"].ToString();
            insung_name = reader["insung_name"].ToString();
            insung_owner = reader["insung_owner"].ToString();
            insung_regno = reader["insung_regno"].ToString();
            inusng_telno = reader["inusng_telno"].ToString();
        }
        private void TaxTypeExcelSales(DbDataReader reader)
        {
            today_date = reader["today_date"].ToString();
            start_date = reader["start_date"].ToString();
            end_date = reader["end_date"].ToString();
            order_time = reader["order_time"].ToString();
            order_no = reader["order_no"].ToString();
            charge_gbn_name = reader["charge_gbn_name"].ToString();
            pay_gbn_name = reader["pay_gbn_name"].ToString();
            charge_amt = reader["charge_amt"].ToString();
            charge_vat_amt = reader["charge_vat_amt"].ToString();
            total_charge_amt = reader["total_charge_amt"].ToString();
        }
        private void TaxTypeExcelPurchase(DbDataReader reader)
        {
            today_date = reader["today_date"].ToString();
            start_date = reader["start_date"].ToString();
            end_date = reader["end_date"].ToString();
            order_time = reader["order_time"].ToString();
            order_no = reader["order_no"].ToString();
            charge_gbn_name = reader["charge_gbn_name"].ToString();
            pay_gbn_name = reader["pay_gbn_name"].ToString();
            app_no = reader["app_no"].ToString();
            charge_amt = reader["charge_amt"].ToString();
            charge_vat_amt = reader["charge_vat_amt"].ToString();
            total_charge_amt = reader["total_charge_amt"].ToString();
        }

        public string app_no { get; set; }
        public string today_date { get; set; }
        public string start_date { get; set; }
        public string end_date { get; set; }
        public string order_time { get; set; }
        public string order_no { get; set; }
        public string charge_gbn_name { get; set; }
        public string pay_gbn_name { get; set; }
        public string charge_amt { get; set; }
        public string charge_vat_amt { get; set; }
        public string total_charge_amt { get; set; }
        public string card_amt { get; set; }
        public string card_vat_amt { get; set; }
        public string total_card_amt { get; set; }
        public string cash_amt { get; set; }
        public string cash_vat_amt { get; set; }
        public string total_cash_amt { get; set; }
        public string etc_amt { get; set; }
        public string etc_vat_amt { get; set; }
        public string total_etc_amt { get; set; }
        public string meet_cash_amt { get; set; }
        public string meet_cash_vat_amt { get; set; }
        public string total_meet_cash_amt { get; set; }
        public string meet_card_amt { get; set; }
        public string meet_card_vat_amt { get; set; }
        public string total_meet_card_amt { get; set; }
        public string pg_fee_amt { get; set; }
        public string pg_fee_vat_amt { get; set; }
        public string total_pg_fee_amt { get; set; }
        public string pg_fee_cnt { get; set; }
        public string app_fee_amt { get; set; }
        public string app_fee_vat_amt { get; set; }
        public string total_app_fee_amt { get; set; }
        public string app_fee_cnt { get; set; }
        public string from_date { get; set; }
        public string to_date { get; set; }
        public string buss_name { get; set; }
        public string buss_owner { get; set; }
        public string regno { get; set; }
        public string insung_name { get; set; }
        public string insung_owner { get; set; }
        public string insung_regno { get; set; }
        public string inusng_telno { get; set; }
    }
}
