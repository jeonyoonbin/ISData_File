﻿namespace PosWebApp.Models.Tax
{
    public class RequestCommon
    {
        public string job_gbn { get; set; }
        public int mcode { get; set; }
        public string cccode { get; set; }
        public int shop_cd { get; set; }
    }
}
