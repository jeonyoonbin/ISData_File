﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Operate.Response
{
    public class ShopOperatInfoModel_V2
    {
        public string ABSENT_YN { get; set; }
        public string SHOP_ORIGIN_MARK { get; set; }
        public string REVIEW_USE_GBN { get; set; }
        public string TIP_SEQ { get; set; }
        public string TIP_DAY { get; set; }
        public string TIP_FR_STAND { get; set; }
        public string TIP_TO_STAND { get; set; }
        public string TIP_NEXT_DAY { get; set; }
    }
}
