﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.GIS
{
    public class NaverFeatureCollection : INaverFeaturecollection
    {
        public string type { get; set; }
        public List<NaverFeature> features { get; set; }
        public List<double> bbox { get; set; }
    }
    public class NaverFeatureCollectionMulti : INaverFeaturecollection
    {
        public string type { get; set; }
        public List<NaverFeatureMulti> features { get; set; }
        public List<double> bbox { get; set; }
    }
    public class NaverFeature
    {
        public string type { get; set; }
        public NaverGeometry geometry { get; set; }
        public NaverProperties properties { get; set; }
    }
    public class NaverFeatureMulti
    {
        public string type { get; set; }
        public NaverGeometryMulti geometry { get; set; }
        public NaverProperties properties { get; set; }
    }
    public class NaverGeometry
    {
        public string type { get; set; }
        public List<List<List<double>>> coordinates { get; set; }
    }
    public class NaverGeometryMulti
    {
        public string type { get; set; }
        public List<List<List<List<double>>>> coordinates { get; set; }
    }


    public class NaverProperties
    {
        public string strokeColor { get; set; } = "blue";
        public int strokeOpacity { get; set; } = 1;
        public int strokeWeight { get; set; } = 1;

        public string strokeStyle { get; set; } = "solid";

        public string fillColor { get; set; } = "blue";
        public double fillOpacity { get; set; } = 0.1;
        public bool visible { get; set; } = true;
        public string strokeLineCap { get; set; } = "butt";
        public string strokeLineJoin { get; set; } = "miter";
        public bool clickable { get; set; } = true;
        public int zIndex { get; set; } = 0;
        public string overlayType { get; set; } = "Polygon";
        public string code { get; set; }
        public string lcode { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umd { get; set; }
        public string ri { get; set; }
        public string BASE_DATE {get;set;}
        public string ADM_DR_CD {get;set;}
        public string ADM_DR_NM {get;set;}
        public string OBJECTID  {get;set;}
    }

    public class NaverGISConverter
    {
        public INaverFeaturecollection Collection { get; set; }
        
        public NaverGISConverter(string jsonString)
        {
            JObject rootObj = JObject.Parse(jsonString);

            var features = rootObj["features"];

            var feature = features[0];

            var polyType = feature["geometry"]["type"].ToString();

            
            if (polyType.Equals("Polygon"))
            {
                Collection = JsonConvert.DeserializeObject<NaverFeatureCollection>(jsonString);
            }
            else if (polyType.Equals("MultiPolygon"))
            {
                Collection = JsonConvert.DeserializeObject<NaverFeatureCollectionMulti>(jsonString);
            }
            else
            {
                Collection = null;
            }
        }
    }

    public interface INaverFeaturecollection
    {
        public string type { get; set; }
        public List<double> bbox { get; set; }

    }
}
