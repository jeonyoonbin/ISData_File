﻿using PosWebApp.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Auth
{
    public class AuthenticateResponse
    {
        public string id { get; set; }
        public string shopCode { get; set; }
        public string token { get; set; }

        public AuthenticateResponse(RequestLogin login, string token)
        {
            id = login.id;
            shopCode = login.shop_cd;
            this.token = token;
        }
    }
}
