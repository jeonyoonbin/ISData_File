﻿using System.Collections.Generic;

namespace PosWebApp.Models.RequestModel
{
    public class RequestSortItem : Request
    {
        /// <summary>
        /// 작업 구분
        /// </summary>
        public string div { get; set; }
        /// <summary>
        /// 아이템 코드 리스트 ( 정렬 된 리스트 )
        /// </summary>
        public List<int> item_codes { get; set; }
        /// <summary>
        /// 아이템 상위 코드 ( 정렬 된 리스트 )
        /// </summary>
        public string menu_cd { get; set; }

    }
}
