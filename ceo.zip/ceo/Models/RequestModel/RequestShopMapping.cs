﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopMapping : Request
    {
        public string api_use_gbn { get; set; }
        public string api_type { get; set; }
    }
}
