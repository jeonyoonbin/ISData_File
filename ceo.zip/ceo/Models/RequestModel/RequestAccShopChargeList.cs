﻿namespace PosWebApp.Models.RequestModel
{
    public enum AccShopChargeType { 
        IN_OUT_LIST = 1,
        IN_OUT_INFO = 3,
        IN_OUT_GBN_LIST = 9
    }

    public class RequestAccShopChargeList : Request
    {
        public string fr_date { get; set; }
        public string to_date { get; set; }
        public string io_gbn { get; set; }
        public string charge_gbn { get; set; }
        public string memo { get; set; }

    }
}
