﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopInfoChargeList : Request
    {
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public string ioType { get; set; }
        public string chargeType { get; set; }
        public string memo { get; set; }
    }
}
