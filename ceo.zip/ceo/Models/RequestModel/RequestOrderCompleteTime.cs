﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.RequestModel
{
    public class RequestOrderCompleteTime : Request
    {
        public string order_comp_time { get; set; }
        public int mod_code { get; set; }
        public string mod_name { get; set; }
    }
}
