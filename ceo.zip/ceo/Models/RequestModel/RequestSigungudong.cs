﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.RequestModel
{
    public class RequestSigungudong : Request
    {
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string bdong { get; set; }
        public string hdong { get; set; }
    }
}
