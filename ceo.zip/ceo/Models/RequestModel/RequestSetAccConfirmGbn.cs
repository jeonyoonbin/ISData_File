﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetAccConfirmGbn : Request
    {
        public string in_acc_confirm_gbn { get; set; }
    }
}
