﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestMenuOptionList : Request
    {
        public string menu_cd { get; set; }
        public string option_name { get; set; }
        public int option_group_cd { get; set; }
        public string use_yn { get; set; }
    }
}
