﻿namespace PosWebApp.Models.RequestModel
{
    public enum SmsTransType
    {
        출금가능유무 = 1,
        SMS인증번호확인 = 3,
        SMS인증번호발송요청 = 5
    }

    public class RequestTransSmsCheck : Request
    {
        public string sms_no { get; set; }
    }
}
