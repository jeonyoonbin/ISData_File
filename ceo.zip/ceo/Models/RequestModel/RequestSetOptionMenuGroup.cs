﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetOptionMenuGroup : Request
    {
        public string menu_cd { get; set; }
        public string group_cd { get; set; }
        public string group_name { get; set; }
        public string group_memo { get; set; }
        public string use_yn { get; set; }
        public string option_yn { get; set; }
        public string req_yn { get; set; }
        public string multi_yn { get; set; }
        /// <summary>
        /// 2021.04.09 최대 주문 가능 갯수 ( 3팀 제안 )
        /// </summary>
        public int multi_count { get; set; }
        /// <summary>
        /// 2021.04.09 최소 주문 가능 갯수 ( 3팀 제안 )
        /// </summary>
        public int min_count { get; set; }
        public string group_file_name { get; set; }
        public int sort_seq { get; set; }
        public string mod_name { get; set; }
    }
}
