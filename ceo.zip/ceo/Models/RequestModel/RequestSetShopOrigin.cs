﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetShopOrigin : Request
    {
        public string origin_mark { get; set; }
        public string shop_intro { get; set; }
        public int user_code { get; set; }
        public string user_name { get; set; }

    }
}
