﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSMenuDetail : Request
    {
        public string item_cd { get; set; }
        public string menu_cd { get; set; }
    }
}
