﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopRestList
    {
        public string job_gbn { get; set; }
        public string shop_cd { get; set; }
        public string rest_date { get; set; }
    }
}
