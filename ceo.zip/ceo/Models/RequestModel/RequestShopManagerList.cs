﻿namespace PosWebApp.Models.RequestModel
{
    public enum ShopManagerType
    {
        일자별 = 100,
        요일별 = 120,
        취소사유별 = 140,
        결제구분별 = 160
    }
    public class RequestShopManagerList : Request
    {
        public string from_date { get; set; }
        public string to_date { get; set; }
        public int day_gbn { get; set; }
    }
}
