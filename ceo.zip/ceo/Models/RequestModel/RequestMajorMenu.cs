﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.RequestModel
{
    public class RequestMajorMenu : Request
    {
        public string menu_cd { get; set; }
        public string m_main_yn { get; set; }
        public string mod_cd { get; set; }
        public string mod_name { get; set; }

    }
}
