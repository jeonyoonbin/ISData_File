﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetBizInfo : Request
    {
        public string reg_no { get; set; }
        public string owner { get; set; }
        /// <summary>
        /// 업태
        /// </summary>
        public string buss_con { get; set; }
        /// <summary>
        /// 업종
        /// </summary>
        public string buss_type { get; set; }
        public string address { get; set; }
        public string tax_type { get; set; }

    }
}
