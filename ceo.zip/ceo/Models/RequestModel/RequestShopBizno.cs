﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopBizno : Request
    {
        public string current_bizno { get; set; }
        public string bizno { get; set; }
        public string mod_code { get; set; }
        public string mod_user { get; set; }

    }
}
