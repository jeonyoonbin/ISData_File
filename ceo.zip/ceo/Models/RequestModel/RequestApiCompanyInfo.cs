﻿namespace PosWebApp.Models.RequestModel
{
    public enum MAPP_COM_TYPE
    {
        주문 = 1,
        POS_배달 = 3,
        /// <summary>
        /// All : 조회 용 필드
        /// </summary>
        All = 5 
    }
    /// <summary>
    /// 연동사 정보 
    /// </summary>
    public class RequestApiCompanyInfo : Request
    {
        public string sequence { get; set; }
        public string com_type { get; set; }
        public string com_gbn { get; set; }
        public string com_gbn_2 { get; set; }
        public string com_name { get; set; }
        public string com_token { get; set; }
        public string com_auth { get; set; }
        public int mod_code { get; set; }
        public string mod_user { get; set; }
    }
}
