﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetCommMenuStatus :Request
    {
        public string item_cd { get; set; }
        public string menu_group_type { get; set; }
        public string menu_cd { get; set; }
        public string option_cd { get; set; }
        public string group_cd { get; set; }
        public string use_yn { get; set; }
        public string mod_name { get; set; }
    }
}
