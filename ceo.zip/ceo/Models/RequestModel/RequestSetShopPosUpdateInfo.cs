﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.RequestModel
{
    public class RequestSetShopPosUpdateInfo
    {
        public string ver_info { get; set; }
        public string cccode { get; set; }
        public string shop_cd { get; set; }

    }
}
