﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestAppMinAmt : Request
    {
        public string app_min_amt { get; set; }
        public int mod_code { get; set; }
        public string mod_name { get; set; }
    }
}
