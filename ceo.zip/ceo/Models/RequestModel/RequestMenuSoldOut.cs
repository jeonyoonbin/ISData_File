﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.RequestModel
{
    public class RequestMenuSoldOut : Request
    {
        public string menu_cd { get; set; }
        public string soldout { get; set; }
        public string mod_code { get; set; }
        public string mod_user { get; set; }
    }
}
