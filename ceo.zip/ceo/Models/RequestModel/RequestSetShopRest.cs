﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetShopRest
    {
        public string job_gbn { get; set; }
        public string shop_cd { get; set; }
        public string rest_date { get; set; }
        public string rest_tip_amt { get; set; }
        public string memo { get; set; }
        public string user_code { get; set; }
        public string user_name { get; set; }
    }
}
