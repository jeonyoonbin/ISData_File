﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSystemInout :Request
    {
        public string mac_address { get; set; }
        public string pc_name { get; set; }
        public string pc_ip { get; set; }
        public string log_gbn { get; set; } = "CEO";
        public string inout_gbn { get; set; } // I, O, F
        public string user_id { get; set; }
        public string pgm_id { get; set; }
        public string pgm_name { get; set; }
    }
}
