﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSMenuOptionList : Request
    {
        public string item_cd { get; set; }
        public string menu_cd { get; set; }
        public string opt_group_cd { get; set; }
        public string option_name { get; set; }
        public string use_yn { get; set; }
    }
}
