﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestComShopList
    {
        public string job_gbn { get; set; }
        public string cccode { get; set; }
        public string item_cd { get; set; }
        public string group_type { get; set; }
        public string group_name { get; set; }
        public string use_yn { get; set; }
    }
}
