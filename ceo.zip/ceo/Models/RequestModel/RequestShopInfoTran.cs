﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopInfoTran : Request
    {
        public string mobile { get; set; }
        public string amt { get; set; }
        public string memo { get; set; }
        public string shop_password { get; set; }
    }
}
