﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetShopSector : Request
    {
        public string sido_code { get; set; }
        public string sido { get; set; }
        public string sigungu_code { get; set; }
        public string sigungu { get; set; }
        public string dong { get; set; }
    }
    
}
