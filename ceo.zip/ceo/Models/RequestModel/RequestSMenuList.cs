﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSMenuList : Request
    {
        public string item_cd { get; set; }
        public string group_cd { get; set; }
        public string menu_name { get; set; }
        public string use_yn { get; set; }
    }
}
