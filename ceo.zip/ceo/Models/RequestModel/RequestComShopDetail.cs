﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestComShopDetail
    {
        public string job_gbn { get; set; }
        public string cccode { get; set; }
        public string item_cd { get; set; }
        public string menu_group_cd { get; set; }
    }
}
