﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestFreeOrderAmt : Request
    {
        public string free_amount { get; set; }
        public int mod_code { get; set; }
        public string mod_name { get; set; }
    }
}
