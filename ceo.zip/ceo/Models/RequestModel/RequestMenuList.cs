﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestMenuList : Request
    {
        public string group_cd { get; set; }
        public string menu_name { get; set; }
        public string use_yn { get; set; }
    }
}
