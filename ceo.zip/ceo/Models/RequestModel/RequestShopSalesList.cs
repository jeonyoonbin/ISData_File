﻿namespace PosWebApp.Models.RequestModel
{
    public enum SalesType
    {
        TOTAL = 100,
        CURRENT = 110,
        CURRENT_DETAIL = 120,
        SALSE_V2 = 1000,
        CHARGE = 1001,
        SHOPMALL = 1002,
    }

    public class RequestShopSalesList : Request
    {
        public string pack_order_yn { get; set; } = "%";
        public string from_date { get; set; }
        public string to_date { get; set; }
        public string search { get; set; }
        public string options { get; set; }
        public string app_order_gbn { get; set; }
        public string pay_gbn { get; set; }
        public string type_gbn { get; set; } = "%";
        public string memo_gbn { get; set; } = "%";
        public string charge_gbn { get; set; } = "K,P";
        public int pageNumber { get; set; }
    }
}
