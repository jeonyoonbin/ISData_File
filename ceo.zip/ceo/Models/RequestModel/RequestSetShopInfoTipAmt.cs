﻿using System.Collections.Generic;

namespace PosWebApp.Models.RequestModel
{
    public class RequestSetShopInfoTipAmt
    {
        public string job_gbn { get; set; }
        public int shop_cd { get; set; }
        public int tip_seq { get; set; }
        public string tip_gbn { get; set; }
        public string tip_day { get; set; }
        public string tip_from_stand { get; set; }
        public string tip_to_stand { get; set; }
        public string tip_amt { get; set; }
        public string tip_amt_rate { get; set; }
        public string tip_next_day { get; set; }
        public int user_code { get; set; }
        public string user_name { get; set; }
    }

    public class RequestSetShopInfoTipAmtList
    {
        public string job_gbn { get; set; }
        public string shop_cd { get; set; }
        public string user_code { get; set; }
        public string user_name { get; set; }
        public List<RequestSetShopInfoTipAmtItem> itemList{ get; set; }

    }
    public class RequestSetShopInfoTipAmtItem
    {
        public int tip_seq { get; set; }
        public string tip_gbn { get; set; }
        public string tip_day { get; set; }
        public string tip_from_stand { get; set; }
        public string tip_to_stand { get; set; }
        public string tip_amt { get; set; }
        public string tip_amt_rate { get; set; }
        public string tip_next_day { get; set; }
    }
}
