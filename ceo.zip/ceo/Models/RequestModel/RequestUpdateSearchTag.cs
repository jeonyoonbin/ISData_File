﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestUpdateSearchTag : Request
    {
        public string search_tag { get; set; }
        public int mod_code { get; set; }
        public string mod_user { get; set; }
    }
}
