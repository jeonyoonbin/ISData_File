﻿namespace PosWebApp.Models.RequestModel
{
    public class RequsetSetReviewGbn : Request
    {
        public string use_gbn { get; set; }
        public int mod_code { get; set; }
        public string mod_user { get; set; }
    }
}
