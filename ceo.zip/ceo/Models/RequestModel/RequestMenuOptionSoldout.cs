﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestMenuOptionSoldout : Request
    {
        public int option_cd { get; set; }
        public string soldout { get; set; }
        public string mod_code { get; set; }
        public string mod_user { get; set; }
    }
}
