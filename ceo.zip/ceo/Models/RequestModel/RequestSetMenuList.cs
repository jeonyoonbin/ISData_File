﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetMenuList : Request
    {
        public string group_cd { get; set; }
        public string menu_cd { get; set; }
        public string menu_name { get; set; }
        public string menu_sname { get; set; }
        public string menu_cost { get; set; }
        public string menu_desc { get; set; }
        public int sort_seq { get; set; }
        public string file_name { get; set; }
        public string use_yn { get; set; }

        public string menu_alone_order { get; set; }
        public string menu_search_tag { get; set; }
        public string menu_main_yn { get; set; }
        public string m_menu_type { get; set; }

        public string mod_name { get; set; }
    }
}
