﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopRunningStatus : Request
    {
        public string runningStatus { get; set; }
        public string mod_code { get; set; }
        public string mod_user { get; set; }

    }
}
