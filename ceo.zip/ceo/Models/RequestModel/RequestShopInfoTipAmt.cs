﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopInfoTipAmt
    {
        public string job_gbn { get; set; }
        public int shop_cd { get; set; }
        public string tip_gbn { get; set; }
    }
}
