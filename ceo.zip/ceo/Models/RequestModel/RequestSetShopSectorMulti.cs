﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.RequestModel
{
    public class RequestSetShopSectorMulti : Request
    {
        public string delete_sido { get; set; }
        public string delete_sigungu { get; set; }
        public List<RequestSetShopSector> sectorData { get; set; }
    }
}
