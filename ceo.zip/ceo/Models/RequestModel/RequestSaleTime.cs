﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSaleTime : Request
    {
        public string from_time { get; set; }
        public string to_time { get; set; }
        public string next_day { get; set; }
        public int mod_code { get; set; }
        public string mod_user { get; set; }
    }
}
