﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestMenuOptionGroupList : Request
    {
        public string menu_cd { get; set; }
        public string group_name { get; set; }
        public string use_yn { get; set; }
        public string option_yn { get; set; }
    }
}
