﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.RequestModel
{
    public class RequestSetHoliday : Request
    {
        public string running { get; set; }
        public int day_of_holiday { get; set; }
    }
}
