﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestChangePassword : Request
    {
        public string id { get; set; }
        public string current { get; set; }
        public string password { get; set; }
        public int mod_code { get; set; }
        public string mod_user { get; set; }
        public string shopMallYn { get; set; }
    }
}
