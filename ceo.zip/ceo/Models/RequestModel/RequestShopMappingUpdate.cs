﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopMappingUpdate :Request
    {
        public int shop_map_seq { get; set; }
        public string api_use_yn { get; set; }
        public string api_type { get; set; }
        public string api_com_gbn { get; set; }
        public string api_com_code { get; set; }
        public string api_com_code_2 { get; set; }
        public string api_com_token { get; set; }
        public string api_com_auth { get; set; }
        public string api_com_id { get; set; }
        public string api_com_pass { get; set; }
        public string api_daily_token { get; set; }
        public string api_memo { get; set; }
        public int mod_code { get; set; }
        public string mod_name { get; set; }
    }
}
