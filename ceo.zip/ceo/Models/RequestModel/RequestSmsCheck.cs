﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSmsCheck : Request
    {
        public string sms_conf_no { get; set; }
    }
}
