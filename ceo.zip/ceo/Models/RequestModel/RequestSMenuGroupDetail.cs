﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSMenuGroupDetail : Request
    {
        public string item_cd { get; set; }
        public string menu_group_cd { get; set; }
    }
}
