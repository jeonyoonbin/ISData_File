﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestGetShopSector : Request
    {
        public string sido { get; set; }
        public string sigungu { get; set; }
    }
}
