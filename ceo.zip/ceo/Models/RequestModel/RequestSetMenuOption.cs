﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetMenuOption : Request
    {
        public string menu_cd { get; set; }
        public string option_cd { get; set; }
        public string group_cd { get; set; }
        public string option_name { get; set; }
        public string option_memo { get; set; }
        public string cost { get; set; }
        public string use_yn { get; set; }
        public string file_name { get; set; }
        public int sort_seq { get; set; }
        public string mod_name { get; set; }
    }
}
