﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopInfoChargeOrderList
    {
        public string job_gbn { get; set; }
        public string order_no { get; set; }
    }
}
