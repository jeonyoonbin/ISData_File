﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.RequestModel
{
    public enum ORDER_SEARCH_TYPE
    {
        최근 = 1,
        기간 = 3
    }
    public class RequestShopOrderList : Request
    {
        public string from_date { get; set; }
        public string to_date { get; set; }
        public string pageNum { get; set; }
        public string pageCnt { get; set; }
    }
}
