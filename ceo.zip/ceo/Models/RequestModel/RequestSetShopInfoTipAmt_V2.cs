﻿using System.Collections.Generic;

namespace PosWebApp.Models.RequestModel
{
    public class RequestSetShopInfoTipAmt_V2
    {
        public List<string> job_gbn { get; set; }
        public int shop_cd { get; set; }
        public List<int> tip_seq { get; set; }
        public List<string> tip_gbn { get; set; }
        public List<string> tip_day { get; set; }
        public List<string> tip_from_stand { get; set; }
        public List<string> tip_to_stand { get; set; }
        public List<string> tip_amt { get; set; }
        public List<string> tip_amt_rate { get; set; }
        public List<string> tip_next_day { get; set; }
        public int user_code { get; set; }
        public string user_name { get; set; }
    }
}
