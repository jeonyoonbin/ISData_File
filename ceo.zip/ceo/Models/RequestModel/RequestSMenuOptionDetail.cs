﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSMenuOptionDetail : Request
    {
        public string item_cd { get; set; }
        public string menu_cd { get; set; }
        public string option_cd { get; set; }
    }
}
