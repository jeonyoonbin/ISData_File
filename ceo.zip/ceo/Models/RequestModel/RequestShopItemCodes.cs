﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopItemCodes : Request
    {
        public string item_cd { get; set; }
        public string item_cd2 { get; set; }
        public string item_cd3 { get; set; }
        public int mod_code { get; set; }
        public string mod_user { get; set; }
    }
}
