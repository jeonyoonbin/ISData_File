﻿namespace PosWebApp.Models.RequestModel
{
    public enum CUST_ORDER_SEARCH_TYPE
    {
        기본내역 = 1,
        주문메뉴내역 = 3,
        주문메뉴와옵션메뉴내역 = 5,
        주문상세 = 10,
        CUST_ORDER_SEARCH_TYPE_MAX
    }

    public class RequestOrderState : Request
    {
        public string order_date { get; set; }
        public string order_no { get; set; }
        public string status { get; set; }
        public string memo { get; set; }
        public string mod_user { get; set; }
    }
}
