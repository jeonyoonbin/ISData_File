﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestMenuOptionDetail : Request
    {
        public int menu_cd { get; set; }
        public int opt_cd { get; set; }
    }
}
