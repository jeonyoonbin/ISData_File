﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopChargeList : Request
    {
        public string mobile { get; set; }
        public string amount { get; set; }
        public string memo { get; set; }
        public string pass { get; set; }
    }
}
