﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestMenuDetail : Request
    {
        public int group_cd { get; set; }
        public int menu_cd { get; set; }
    }
}
