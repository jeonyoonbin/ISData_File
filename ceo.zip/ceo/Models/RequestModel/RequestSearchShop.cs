﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSearchShop
    {
        public string job_gbn { get; set; }
        public string search_data { get; set; }
    }
}
