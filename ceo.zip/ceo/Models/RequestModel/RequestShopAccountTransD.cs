﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopAccountTransD
    {
        public string job_gbn { get; set; }
        public string trans_seqno { get; set; }
        public string trans_date { get; set; }
        public string trans_time { get; set; }
    }
}
