﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestMenuGroupDetail : Request
    {
        public int group_cd { get; set; }
    }
}
