﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetMenuGroup : Request
    {
        public int group_cd { get; set; }
        public string group_name { get; set; }
        public string group_memo { get; set; }
        public string use_yn { get; set; }
        public string option_yn { get; set; }
        public string group_file_name { get; set; }
        public int sort_seq { get; set; }
        public string main_img_yn { get; set; }
        public string mod_name { get; set; }
    }
}
