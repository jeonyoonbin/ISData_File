﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetImageUrl : Request
    {
        public string image_url { get; set; }
        public int mod_code { get; set; }
        public string mod_user { get; set; }
    }
}
