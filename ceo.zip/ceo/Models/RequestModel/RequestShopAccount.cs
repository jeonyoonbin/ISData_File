﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopAccount : Request
    {
        public string bank_code { get; set; }
        public string account { get; set; }
        public string owner { get; set; }
        public string pay_confirm { get; set; }
    }
}
