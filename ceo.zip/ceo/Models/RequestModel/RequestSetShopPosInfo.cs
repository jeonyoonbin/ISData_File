﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestSetShopPosInfo
    {
        public string job_gbn { get; set; }
        public string ver_info { get; set; }
        public string query_data { get; set; }
        public string memo { get; set; }
        public string update_gbn { get; set; }
    }
}
