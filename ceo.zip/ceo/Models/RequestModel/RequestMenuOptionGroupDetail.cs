﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestMenuOptionGroupDetail : Request
    {
        public string menu_cd { get; set; }
        public string option_group_cd { get; set; }
    }
}
