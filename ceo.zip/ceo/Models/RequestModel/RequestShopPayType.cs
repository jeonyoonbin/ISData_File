﻿namespace PosWebApp.Models.RequestModel
{
    public class RequestShopPayType : Request
    {
        public string pay_type { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }
}
