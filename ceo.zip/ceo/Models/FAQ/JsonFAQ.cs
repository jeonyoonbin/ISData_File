﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.FAQ
{
    public class JsonFAQ
    {
        public List<FAQ> faq { get; set; }
    }
    public class FAQ
    {
        public string title { get; set; }
        public List<ContentFAQ> data { get; set; }
    }
    public class ContentFAQ
    {
        public string subject { get; set; }
        public List<SubFAQ> content { get; set; }
    }
    public class SubFAQ
    {
        public string subtitle { get; set; }
        public string subcontent { get; set; }
    }

}
