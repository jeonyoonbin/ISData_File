﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopSector
    {
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string umdr { get; set; }
        public string sido_code { get; set; }
        public string sigungu_code { get; set; }
    }
}
