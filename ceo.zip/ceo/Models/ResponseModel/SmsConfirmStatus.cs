﻿namespace PosWebApp.Models.ResponseModel
{
    public class SmsConfirmStatus
    {
        public string confirm_no { get; set; }
        public string issue_date { get; set; }
        public string issue_time { get; set; }
        public string confirm_status { get; set; }

    }
}
