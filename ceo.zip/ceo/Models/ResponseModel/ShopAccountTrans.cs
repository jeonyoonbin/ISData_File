﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopAccountTrans
    {
        public string tran_seqno { get; set; }
        public string tran_date { get; set; }
        public string tran_time { get; set; }
        public string disp_tran_time { get; set; }
        public string cccode { get; set; }
        public string ccname { get; set; }
        public string order_date { get; set; }
        public string tran_amt { get; set; }
        public string memo { get; set; }
        public string user_name { get; set; }
        public string tran_res { get; set; }
    }
}
