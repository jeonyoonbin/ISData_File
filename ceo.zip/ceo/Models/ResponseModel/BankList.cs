﻿namespace PosWebApp.Models.ResponseModel
{
    public class BankList
    {
        public string bankcode { get; set; }
        public string bankname { get; set; }
        public string bankname1 { get; set; }
    }
}
