﻿namespace PosWebApp.Models.ResponseModel
{
    public class ResponseShopBizNo
    {
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string bizno { get; set; }
    }
}
