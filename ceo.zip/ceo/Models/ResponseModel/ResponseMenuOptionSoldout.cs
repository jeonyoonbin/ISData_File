﻿namespace PosWebApp.Models.ResponseModel
{
    public class ResponseMenuOptionSoldout
    {
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string menu_option_cd { get; set; }
        public string o_no_flag { get; set; }
    }
}
