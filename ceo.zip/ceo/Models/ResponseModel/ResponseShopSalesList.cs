﻿using PosWebApp.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class ResponseShopSalesList
    {
        public ResponseShopSalesList(SalesType salesType, DbDataReader row)
        {
            switch (salesType)
            {
                case SalesType.TOTAL:
                    SalesTypeTotal(row);
                    break;
                case SalesType.CURRENT:
                    SalesTypeCurrent(row);
                    break;
                case SalesType.CURRENT_DETAIL:
                    SalesTypeCurrentDetail(row);
                    break;
                case SalesType.SALSE_V2:
                    SalseTypeV2(row);
                    break;
                case SalesType.CHARGE:
                    ChargeBody(row);
                    break;
                case SalesType.SHOPMALL:
                    shopMallBody(row);
                    break;
            }
        }

        private void shopMallBody(DbDataReader row)
        {
            rnum = row["rnum"].ToString();
            charge_date = row["charge_date"].ToString();
            in_amt = row["in_amt"].ToString();
            out_amt = row["out_amt"].ToString();
            charge_amt = row["charge_amt"].ToString();
            shop_cd = row["shop_cd"].ToString();
        }

        private void SalesTypeTotal(DbDataReader row)
        {
            total_count = row["tot_cnt"].ToString();
            total_amount = row["tot_amt"].ToString();
            ok_count = row["ok_cnt"].ToString();
            ok_amount = row["ok_amt"].ToString();
            cancel_amount = row["cancel_amt"].ToString();
            cancel_count = row["cancel_cnt"].ToString();
            discount_amount = row["disc_amt"].ToString();
            amount = row["amount"].ToString();
        }
        private void SalesTypeCurrent(DbDataReader row)
        {
            app_pay_gbn = row["app_pay_gbn"].ToString();
            app_pay_gbn_name = row["앱유무"].ToString();
            pack_order_yn = row["pack_order_yn"].ToString();
            pack_order_name = row["포장유무"].ToString();
            pay_gbn = row["pay_gbn"].ToString();
            pay_gbn_name = row["결제구분"].ToString();

            total_count = row["tot_cnt"].ToString();
            total_amount = row["tot_amt"].ToString();
            ok_count = row["ok_cnt"].ToString();
            ok_amount = row["ok_amt"].ToString();
            cancel_amount = row["cancel_amt"].ToString();
            cancel_count = row["cancel_cnt"].ToString();
            discount_amount = row["disc_amt"].ToString();
            amount = row["amount"].ToString();
        }
        private void SalesTypeCurrentDetail(DbDataReader row)
        {
            order_date = row["order_date"].ToString();

            app_pay_gbn = row["app_pay_gbn"].ToString();
            app_pay_gbn_name = row["앱유무"].ToString();
            pack_order_yn = row["pack_order_yn"].ToString();
            pack_order_name = row["포장유무"].ToString();
            pay_gbn = row["pay_gbn"].ToString();
            pay_gbn_name = row["결제구분"].ToString();

            total_count = row["tot_cnt"].ToString();
            total_amount = row["tot_amt"].ToString();
            ok_count = row["ok_cnt"].ToString();
            ok_amount = row["ok_amt"].ToString();
            cancel_amount = row["cancel_amt"].ToString();
            cancel_count = row["cancel_cnt"].ToString();
            discount_amount = row["disc_amt"].ToString();
            amount = row["amount"].ToString();
        }
        private void SalseTypeV2(DbDataReader row)
        {
            order_date = row["order_date"].ToString();
            pack_order_yn = row["pack_order_yn"].ToString();
            pack_order_name = row["pack_order_yn_name"].ToString();
            tot_amount = row["tot_amt"].ToString();
            app_menu_amount = row["app_menu_amt"].ToString();
            app_tip_amount = row["app_tip_amt"].ToString();
            total_disc_amount = row["total_disc_amt"].ToString();
            shop_disc_amount = row["shop_disc_amt"].ToString();
            total_fee_amount = row["total_fee_amt"].ToString();
            app_fee_amount = row["app_fee_amt"].ToString();
            pg_fee_amount = row["pg_fee_amt"].ToString();

            meet_menu_amount = row["meet_menu_amt"].ToString();
            meet_tip_amount = row["meet_tip_amt"].ToString();
            //delivery_tip_amount = row["deli_tip_amt"].ToString();

            delivery_total_amount = row["deli_tot_amt"].ToString();
            total_amount = row["total_amt"].ToString();  //입금 금액
            live_disc_amt = row["live_disc_amt"].ToString();
            pack_disc_amt = row["pack_disc_amt"].ToString();
            shop_coupon_amt = row["shop_coupon_amt"].ToString();
        }
        private void ChargeBody(DbDataReader row)
        {

            order_date = row["order_date"].ToString();
            order_no = row["order_no"].ToString();
            status = row["status"].ToString();
            pack_order_yn = row["pack_order_yn"].ToString();
            pack_order_name = row["pack_order_yn_name"].ToString();
            tot_amount = row["tot_amt"].ToString();  // 매출금액
            menu_amount = row["menu_amt"].ToString();
            delivery_tip_amount = row["deli_tip_amt"].ToString();
            total_disc_amount = row["total_disc_amt"].ToString();
            shop_disc_amount = row["shop_disc_amt"].ToString();
            total_fee_amount = row["total_fee_amt"].ToString();
            app_fee_amount = row["app_fee_amt"].ToString();
            pg_fee_amount = row["pg_fee_amt"].ToString();
            delivery_total_amount = row["deli_tot_amt"].ToString();
            total_amount = row["total_amt"].ToString();  //입금 금액
            memo = row["memo"].ToString();
            app_pay_gbn_name = row["app_pay_gbn_name"].ToString();
            transfer_amt = row["transfer_amt"].ToString();
            live_disc_amt = row["live_disc_amt"].ToString();
            admin_amt = row["admin_amt"].ToString();
            pack_disc_amt = row["pack_disc_amt"].ToString();
        }
        public string order_date { get; set; }
        public string order_no { get; set; }
        public string app_pay_gbn { get; set; }
        public string app_pay_gbn_name { get; set; }
        public string pack_order_yn { get; set; }
        public string pack_order_name { get; set; }
        public string pay_gbn { get; set; }
        public string pay_gbn_name { get; set; }

        public string total_count { get; set; }
        public string total_amount { get; set; }
        public string ok_count { get; set; }
        public string ok_amount { get; set; }
        public string cancel_count { get; set; }
        public string cancel_amount { get; set; }
        public string discount_amount { get; set; }
        public string amount { get; set; }

        public string menu_amount { get; set; }
        public string app_menu_amount { get; set; }
        public string meet_menu_amount { get; set; }
        public string tot_amount { get; set; }
        public string delivery_tip_amount { get; set; }
        public string app_tip_amount { get; set; }
        public string meet_tip_amount { get; set; }
        public string total_disc_amount { get; set; }
        public string shop_disc_amount { get; set; }
        public string total_fee_amount { get; set; }
        public string app_fee_amount { get; set; }
        public string pg_fee_amount { get; set; }
        public string delivery_total_amount { get; set; }

        public string card_count { get; set; }
        public string card_amount { get; set; }
        public string memo { get; set; }
        public string status { get; set; }
        public string transfer_amt { get; set; }

        public string live_disc_amt { get; set; }
        public string admin_amt { get; set; }
        public string pack_disc_amt { get; set; }
        public string shop_coupon_amt { get; set; }


        public string rnum { get; set; }
        public string charge_date { get; set; }
        public string charge_time { get; set; }
        public string charge_gbn { get; set; }
        public string charge_gbn_name { get; set; }
        public string charge_amt { get; set; }
        public string io_gbn { get; set; }
        public string in_amt { get; set; }
        public string out_amt { get; set; }
        public string shop_cd { get; set; }
    }
}
