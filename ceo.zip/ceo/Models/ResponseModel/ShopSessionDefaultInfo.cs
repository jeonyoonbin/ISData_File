﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopSessionDefaultInfo
    {
        /// <summary>
        /// 타겟 가맹점 정보
        /// </summary>
        public string cccode { get; set; }
        public string ccname { get; set; }
        public int mcode { get; set; }
        public string group_id { get; set; }
        public string center_mobile { get; set; }
        public string center_telno { get; set; }
        public int shop_cd { get; set; }
        public string shop_name { get; set; }
        public string shop_id { get; set; }
        public string use_gbn { get; set; }
        public string shop_telno { get; set; }
        public string shop_mobile { get; set; }
        public string review_token { get; set; }
        public string shop_type { get; set; }

        /// <summary>
        /// 수정자 코드
        /// </summary>
        public int login_code { get; set; }
        /// <summary>
        /// 수정자 명
        /// </summary>
        public string login_name { get; set; }
        public string u_code { get; set; }

        /// <summary>
        ///  예약 유무
        /// </summary>
        public string reservationYN { get; set; }

        /// <summary>
        ///  쇼핑몰 회원 유무
        /// </summary>
        public string mallYN { get; set; }

        ///<summary>
        /// 구분자 
        ///</summary>
        public string loginGbn { get; set; }
        public string ucode { get; set; }
        public string uname { get; set; }


        ///<summary>
        /// 멀티샵 
        ///</summary>
        public string multMasterCd { get; set; }
        public string multshopYn { get; set; }
        public string representativeYn { get; set; }
    }
}
