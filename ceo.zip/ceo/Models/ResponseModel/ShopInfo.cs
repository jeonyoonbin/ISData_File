﻿using System;
using System.Data.Common;

namespace PosWebApp.Models.ResponseModel
{
    public class ShopInfo
    {
        public ShopInfo()
        {

        }
        public ShopInfo(DbDataReader row)
        {
            this.CCNAME = row["CCNAME"].ToString();
            this.MCODE = row["MCODE"].ToString();
            this.SHOP_ID = row["SHOP_ID"].ToString();
            this.GROUP_ID = row["GROUP_ID"].ToString();
            this.MOBILE = row["MOBILE"].ToString();
            this.TELNO = row["TELNO"].ToString();
            this.SHOP_CD = row["SHOP_CD"].ToString();
            this.CCCODE = row["CCCODE"].ToString();
            this.SHOP_NAME = row["SHOP_NAME"].ToString();
            this.TELNO1 = row["TELNO"].ToString();
            this.OWNER = row["OWNER"].ToString();
            this.ITEM_CD = row["ITEM_CD"].ToString();
            this.MAIN_ITEM = row["MAIN_ITEM"].ToString();
            this.ADDR1 = row["ADDR1"].ToString();
            this.ADDR2 = row["ADDR2"].ToString();
            this.ZIP_CODE = row["ZIP_CODE"].ToString();
            this.REG_NO = row["REG_NO"].ToString();
            this.USE_GBN = row["USE_GBN"].ToString();
            this.SORT_SEQ = Convert.ToInt32(row["SORT_SEQ"].ToString());
            this.OPEN_DT = row["OPEN_DT"].ToString();
            this.CLOSE_DT = row["CLOSE_DT"].ToString();
            this.V_BANK_CD = row["V_BANK_CD"].ToString();
            this.V_ACCOUNT = row["V_ACCOUNT"].ToString();
            this.BANKCODE = row["BANKCODE"].ToString();
            this.ACCOUNT_NO = row["ACCOUNT_NO"].ToString();
            this.ACC_OWNER = row["ACC_OWNER"].ToString();
            this.PAY_CONFIRM = row["PAY_CONFIRM"].ToString();
            this.MEMO = row["MEMO"].ToString();
            this.SHOP_ID = row["SHOP_ID"].ToString();
            this.SHOP_PASS = row["SHOP_PASS"].ToString();
            this.ORDER_WAIT_TIME = row["ORDER_WAIT_TIME"].ToString();
            this.ACC_RATE = row["ACC_RATE"].ToString();
            this.ACC_GBN = row["ACC_GBN"].ToString();
            this.ORDER_SMS_YN = row["ORDER_SMS_YN"].ToString();
            this.SALE_FR_TIME = row["SALE_FR_TIME"].ToString();
            this.SALE_TO_TIME = row["SALE_TO_TIME"].ToString();
            this.REMAIN_MINUS_YN = row["REMAIN_MINUS_YN"].ToString();
            this.REMAIN_AMT = row["REMAIN_AMT"].ToString();
            this.MOBILE1 = row["MOBILE"].ToString();
            this.PC_YN = row["PC_YN"].ToString();
            this.SALES_UCODE = row["SALES_UCODE"].ToString();
            this.CARD_USE_YN = row["CARD_USE_YN"].ToString();
            this.LON = row["LON"].ToString();
            this.LAT = row["LAT"].ToString();
            this.ABSENT_YN = row["ABSENT_YN"].ToString();
            this.HOLIDAY_TERM = row["HOLIDAY_TERM"].ToString();
            this.LOGIN_TIME = row["LOGIN_TIME"].ToString();
            this.ABSENT_SMS_DT = row["ABSENT_SMS_DT"].ToString();
            this.SHOP_TYPE = row["SHOP_TYPE"].ToString();
            this.MILEAGE_USE_YN = row["MILEAGE_USE_YN"].ToString();
            this.MILEAGE_AMT_GBN = row["MILEAGE_AMT_GBN"].ToString();
            this.MILEAGE_STD_AMT = row["MILEAGE_STD_AMT"].ToString();
            this.MILEAGE_REMAIN_AMT = row["MILEAGE_REMAIN_AMT"].ToString();
            this.MILEAGE_AMT = row["MILEAGE_AMT"].ToString();
            this.SIDO_NAME = row["SIDO_NAME"].ToString();
            this.GUNGU_NAME = row["GUNGU_NAME"].ToString();
            this.DONG_NAME = row["DONG_NAME"].ToString();
            this.LOC = row["LOC"].ToString();
            this.DDD = row["DDD"].ToString();
            this.COOK_WAIT_TIME = row["COOK_WAIT_TIME"].ToString();
            this.BASIC_LOC = row["BASIC_LOC"].ToString();
            this.BASIC_AMT = row["BASIC_AMT"].ToString();
            this.SHOP_LEVEL = row["SHOP_LEVEL"].ToString();
            this.AMT_TYPE = row["AMT_TYPE"].ToString();
            this.SHOP_GBN = row["SHOP_GBN"].ToString();
            this.QORDER_GBN = row["QORDER_GBN"].ToString();
            this.CARD_REMAIN_AMT = row["CARD_REMAIN_AMT"].ToString();
            this.U_PLUES_ID = row["U_PLUES_ID"].ToString();
            this.CARD_SUB_ID = row["CARD_SUB_ID"].ToString();
            this.CARD_KEY = row["CARD_KEY"].ToString();
            this.CARD_NAME = row["CARD_NAME"].ToString();
            this.MOTH_LIMIT_CNT = row["MOTH_LIMIT_CNT"].ToString();
            this.CALL_AMT = row["CALL_AMT"].ToString();
            this.ACC_DATE = row["ACC_DATE"].ToString();
            this.SHOP_FEE = row["SHOP_FEE"].ToString();
            this.MOTH_USE_CNT = row["MOTH_USE_CNT"].ToString();
            this.ORDER_ALARM_GBN = row["ORDER_ALARM_GBN"].ToString();
            this.ALLOC_SMS_GBN = row["ALLOC_SMS_GBN"].ToString();
            this.VAN_CD = row["VAN_CD"].ToString();
            this.ROAD_DEST_DONG = row["ROAD_DEST_DONG"].ToString();
            this.ROAD_DEST_ADDR = row["ROAD_DEST_ADDR"].ToString();
            this.PG_GBN = row["PG_GBN"].ToString();
            this.WEATHER_ADD_GBN = row["WEATHER_ADD_GBN"].ToString();
            this.JOIN_REMAIN_AMT = row["JOIN_REMAIN_AMT"].ToString();
            this.WEATHER_AMT = row["WEATHER_AMT"].ToString();
            this.WEATHER_AMT_TYPE = row["WEATHER_AMT_TYPE"].ToString();
            this.EMAIL = row["EMAIL"].ToString();
            this.PGM_AMT = row["PGM_AMT"].ToString();
            this.ACCEPT_STATE = row["ACCEPT_STATE"].ToString();
            this.ISCARD_USE_GBN = row["ISCARD_USE_GBN"].ToString();
            this.ISCARD_AMT = row["ISCARD_AMT"].ToString();
            this.ISCARD_CALC_GBN = row["ISCARD_CALC_GBN"].ToString();
            this.ISCARD_CALC_DATE = row["ISCARD_CALC_DATE"].ToString();
            this.LOGIN_POSS_GBN = row["LOGIN_POSS_GBN"].ToString();
            this.DIST_CALC_GBN = row["DIST_CALC_GBN"].ToString();
            this.CALL_AMT_TYPE = row["CALL_AMT_TYPE"].ToString();
            this.CALL_AMT_GBN = row["CALL_AMT_GBN"].ToString();
            this.DAY_LIMIT_CNT = row["DAY_LIMIT_CNT"].ToString();
            this.PG_KIND = row["PG_KIND"].ToString();
            this.RECEIPT_METHOD = row["RECEIPT_METHOD"].ToString();
            this.KGMOB_OTP = row["KGMOB_OTP"].ToString();
            this.SHOP_RIDER_YN = row["SHOP_RIDER_YN"].ToString();
            this.APP_ORDER_YN = row["APP_ORDER_YN"].ToString();
            this.APP_IN_DATE = row["APP_IN_DATE"].ToString();
            this.OWNER_BIRTH = row["OWNER_BIRTH"].ToString();
            this.APP_CALC_AMT = row["APP_CALC_AMT"].ToString();
            this.APP_CALC_GBN = row["APP_CALC_GBN"].ToString();
            this.APP_FILE_NAME = row["APP_FILE_NAME"].ToString();
            this.APP_MIN_AMT = row["APP_MIN_AMT"].ToString();
            this.APP_PAY_TYPE = row["APP_PAY_TYPE"].ToString();
            this.MOD_UCODE = row["MOD_UCODE"].ToString();
            this.MOD_NAME = row["MOD_NAME"].ToString();
            this.MOD_DATE = row["MOD_DATE"].ToString();
            this.PGM_AMT_TYPE = row["PGM_AMT_TYPE"].ToString();
            this.CASH_PAY_GBN = row["CASH_PAY_GBN"].ToString();
            this.ACC_CONFIRM_GBN = row["ACC_CONFIRM_GBN"].ToString();
            this.DEST_TELNO_GBN = row["DEST_TELNO_GBN"].ToString();
            this.BASIC_PAY_GBN = row["BASIC_PAY_GBN"].ToString();
            this.API_COM_CODE = row["API_COM_CODE"].ToString();
            this.API_COM_GBN = row["API_COM_GBN"].ToString();
            this.API_COM_CODE1 = row["API_COM_CODE1"].ToString();
            this.API_COM_GBN1 = row["API_COM_GBN1"].ToString();
            this.API_COM_CODE2 = row["API_COM_CODE2"].ToString();
            this.API_COM_GBN2 = row["API_COM_GBN2"].ToString();
            this.SHOP_CALC_GBN = row["SHOP_CALC_GBN"].ToString();
            this.SHOP_WITHHOLD_TAX_GBN = row["SHOP_WITHHOLD_TAX_GBN"].ToString();
            this.DAY_ADD_GBN = row["DAY_ADD_GBN"].ToString();
            this.DAY_ADD_AMT = row["DAY_ADD_AMT"].ToString();
            this.DAY_ADD_AMT_TYPE = row["DAY_ADD_AMT_TYPE"].ToString();
            this.S_CONTRACT_GBN = row["S_CONTRACT_GBN"].ToString();
            this.S_CONTRACT_END_DT = row["S_CONTRACT_END_DT"].ToString();
            this.FOOD_PACK_FEE_YN = row["FOOD_PACK_FEE_YN"].ToString();
            this.APP_LOGO_NAME = row["APP_LOGO_NAME"].ToString();
            this.BUSS_TYPE = row["BUSS_TYPE"].ToString();
            this.BUSS_CON = row["BUSS_CON"].ToString();
            this.BUSS_OWNER = row["BUSS_OWNER"].ToString();
            this.BUSS_ZIP_CODE = row["BUSS_ZIP_CODE"].ToString();
            this.BUSS_ADDR = row["BUSS_ADDR"].ToString();
            this.BUSS_TAX_TYPE = row["BUSS_TAX_TYPE"].ToString();
            this.AD_USE_GBN = row["AD_USE_GBN"].ToString();
            this.AD_FR_DATE = row["AD_FR_DATE"].ToString();
            this.AD_END_DATE = row["AD_END_DATE"].ToString();
            this.INS_UCODE = row["INS_UCODE"].ToString();
            this.INS_NAME = row["INS_NAME"].ToString();
            this.FREE_ORDER_AMT = row["FREE_ORDER_AMT"].ToString();
            this.SEARCH_TAG = row["SEARCH_TAG"].ToString();
            this.ALONE_ORDER = row["ALONE_ORDER"].ToString();
            this.STAMP_USE_GBN = row["STAMP_USE_GBN"].ToString();

        }
        public string CCNAME { get; set; }
        public string MCODE { get; set; }
        public string GROUP_ID { get; set; }
        public string MOBILE { get; set; }
        public string TELNO { get; set; }
        public string SHOP_CD { get; set; }
        public string CCCODE { get; set; }
        public string SHOP_NAME { get; set; }
        public string TELNO1 { get; set; }
        public string OWNER { get; set; }
        public string ITEM_CD { get; set; }
        public string MAIN_ITEM { get; set; }
        public string ADDR1 { get; set; }
        public string ADDR2 { get; set; }
        public string ZIP_CODE { get; set; }
        public string REG_NO { get; set; }
        public string USE_GBN { get; set; }
        public int SORT_SEQ { get; set; }
        public string OPEN_DT { get; set; }
        public string CLOSE_DT { get; set; }
        public string V_BANK_CD { get; set; }
        public string V_ACCOUNT { get; set; }
        public string BANKCODE { get; set; }
        public string ACCOUNT_NO { get; set; }
        public string ACC_OWNER { get; set; }
        public string PAY_CONFIRM { get; set; }
        public string MEMO { get; set; }
        public string SHOP_ID { get; set; }
        public string SHOP_PASS { get; set; }
        public string ORDER_WAIT_TIME { get; set; }
        public string ACC_RATE { get; set; }
        public string ACC_GBN { get; set; }
        public string ORDER_SMS_YN { get; set; }
        public string SALE_FR_TIME { get; set; }
        public string SALE_TO_TIME { get; set; }
        public string REMAIN_MINUS_YN { get; set; }
        public string REMAIN_AMT { get; set; }
        public string MOBILE1 { get; set; }
        public string PC_YN { get; set; }
        public string SALES_UCODE { get; set; }
        public string CARD_USE_YN { get; set; }
        public string LON { get; set; }
        public string LAT { get; set; }
        public string ABSENT_YN { get; set; }
        public string HOLIDAY_TERM { get; set; }
        public string LOGIN_TIME { get; set; }
        public string ABSENT_SMS_DT { get; set; }
        public string SHOP_TYPE { get; set; }
        public string MILEAGE_USE_YN { get; set; }
        public string MILEAGE_AMT_GBN { get; set; }
        public string MILEAGE_STD_AMT { get; set; }
        public string MILEAGE_REMAIN_AMT { get; set; }
        public string MILEAGE_AMT { get; set; }
        public string SIDO_NAME { get; set; }
        public string GUNGU_NAME { get; set; }
        public string DONG_NAME { get; set; }
        public string LOC { get; set; }
        public string DDD { get; set; }
        public string COOK_WAIT_TIME { get; set; }
        public string BASIC_LOC { get; set; }
        public string BASIC_AMT { get; set; }
        public string SHOP_LEVEL { get; set; }
        public string AMT_TYPE { get; set; }
        public string SHOP_GBN { get; set; }
        public string QORDER_GBN { get; set; }
        public string CARD_REMAIN_AMT { get; set; }
        public string U_PLUES_ID { get; set; }
        public string CARD_SUB_ID { get; set; }
        public string CARD_KEY { get; set; }
        public string CARD_NAME { get; set; }
        public string MOTH_LIMIT_CNT { get; set; }
        public string CALL_AMT { get; set; }
        public string ACC_DATE { get; set; }
        public string SHOP_FEE { get; set; }
        public string MOTH_USE_CNT { get; set; }
        public string ORDER_ALARM_GBN { get; set; }
        public string ALLOC_SMS_GBN { get; set; }
        public string VAN_CD { get; set; }
        public string ROAD_DEST_DONG { get; set; }
        public string ROAD_DEST_ADDR { get; set; }
        public string PG_GBN { get; set; }
        public string WEATHER_ADD_GBN { get; set; }
        public string JOIN_REMAIN_AMT { get; set; }
        public string WEATHER_AMT { get; set; }
        public string WEATHER_AMT_TYPE { get; set; }
        public string EMAIL { get; set; }
        public string PGM_AMT { get; set; }
        public string ACCEPT_STATE { get; set; }
        public string ISCARD_USE_GBN { get; set; }
        public string ISCARD_AMT { get; set; }
        public string ISCARD_CALC_GBN { get; set; }
        public string ISCARD_CALC_DATE { get; set; }
        public string LOGIN_POSS_GBN { get; set; }
        public string DIST_CALC_GBN { get; set; }
        public string CALL_AMT_TYPE { get; set; }
        public string CALL_AMT_GBN { get; set; }
        public string DAY_LIMIT_CNT { get; set; }
        public string PG_KIND { get; set; }
        public string RECEIPT_METHOD { get; set; }
        public string KGMOB_OTP { get; set; }
        public string SHOP_RIDER_YN { get; set; }
        public string APP_ORDER_YN { get; set; }
        public string APP_IN_DATE { get; set; }
        public string OWNER_BIRTH { get; set; }
        public string APP_CALC_AMT { get; set; }
        public string APP_CALC_GBN { get; set; }
        public string APP_FILE_NAME { get; set; }
        public string APP_MIN_AMT { get; set; }
        public string APP_PAY_TYPE { get; set; }
        public string MOD_UCODE { get; set; }
        public string MOD_NAME { get; set; }
        public string MOD_DATE { get; set; }
        public string PGM_AMT_TYPE { get; set; }
        public string CASH_PAY_GBN { get; set; }
        public string ACC_CONFIRM_GBN { get; set; }
        public string DEST_TELNO_GBN { get; set; }
        public string BASIC_PAY_GBN { get; set; }
        public string API_COM_CODE { get; set; }
        public string API_COM_GBN { get; set; }
        public string API_COM_CODE1 { get; set; }
        public string API_COM_GBN1 { get; set; }
        public string API_COM_CODE2 { get; set; }
        public string API_COM_GBN2 { get; set; }
        public string SHOP_CALC_GBN { get; set; }
        public string SHOP_WITHHOLD_TAX_GBN { get; set; }
        public string DAY_ADD_GBN { get; set; }
        public string DAY_ADD_AMT { get; set; }
        public string DAY_ADD_AMT_TYPE { get; set; }
        public string S_CONTRACT_GBN { get; set; }
        public string S_CONTRACT_END_DT { get; set; }
        public string FOOD_PACK_FEE_YN { get; set; }
        public string APP_LOGO_NAME { get; set; }
        public string BUSS_TYPE { get; set; }
        public string BUSS_CON { get; set; }
        public string BUSS_OWNER { get; set; }
        public string BUSS_ZIP_CODE { get; set; }
        public string BUSS_ADDR { get; set; }
        public string BUSS_TAX_TYPE { get; set; }
        public string AD_USE_GBN { get; set; }
        public string AD_FR_DATE { get; set; }
        public string AD_END_DATE { get; set; }
        public string INS_UCODE { get; set; }
        public string INS_NAME { get; set; }
        public string FREE_ORDER_AMT { get; set; }
        public string SEARCH_TAG { get; set; }
        public string ALONE_ORDER { get; set; }
        public string STAMP_USE_GBN { get; set; }

    }
}
