﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace PosWebApp.Models.ResponseModel
{
    public class ShopMenuOption
    {
        public ShopMenuOption()
        {

        }
        public ShopMenuOption(DataRow row)
        {
            this.cccode = row["cccode"].ToString();
            this.shop_cd = row["shop_cd"].ToString();
            this.menu_cd = row["menu_cd"].ToString();
            this.option_group_cd = row["option_group_cd"].ToString();
            this.option_group_name = row["option_group_name"].ToString();

            this.option_cd = row["option_cd"].ToString();
            this.option_name = row["option_name"].ToString();
            this.option_memo = row["option_memo"].ToString();
            this.ocost = row["ocost"].ToString();
            this.use_yn = row["use_yn"].ToString();
            this.sort_seq = Convert.ToInt32(row["sort_seq"].ToString());
            this.omenu_file_name = row["omenu_file_name"].ToString();
            this.o_no_flag = row["o_no_flag"].ToString() == "" ? "N" : row["o_no_flag"].ToString();
        }

        public ShopMenuOption(string job_gbn, DataRow row)
        {
            this.cccode = row["cccode"].ToString();
            this.shop_cd = row["shop_cd"].ToString();
            this.menu_cd = row["menu_cd"].ToString();
            this.option_group_cd = row["option_group_cd"].ToString();
            this.option_group_name = row["option_group_name"].ToString();
            this.o_no_flag = row["o_no_flag"].ToString() == "" ? "N" : row["o_no_flag"].ToString();

            if (job_gbn.Equals("1"))
            {
                this.option_cd = row["option_cd"].ToString();
                this.option_name = row["option_name"].ToString();
                this.option_memo = row["option_memo"].ToString();
                this.ocost = row["ocost"].ToString();
                this.use_yn = row["use_yn"].ToString();
                this.sort_seq = Convert.ToInt32(row["sort_seq"].ToString());
                this.omenu_file_name = row["omenu_file_name"].ToString();
            }
        }

        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string menu_cd { get; set; }
        public string option_group_cd { get; set; }
        public string option_group_name { get; set; }
        public string option_cd { get; set; }
        public string option_name { get; set; }
        public string option_memo { get; set; }
        [RegularExpression(@"^[0-9]*$",
            ErrorMessage = "숫자만 입력해주세요")]
        public string ocost { get; set; }
        public string use_yn { get; set; }
        public int sort_seq { get; set; }
        public string omenu_file_name { get; set; }
        public string  o_no_flag { get; set; }
    }
}
