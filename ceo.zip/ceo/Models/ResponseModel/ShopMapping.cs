﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopMapping
    {
        /// <summary>
        /// 공공앱 가맹점 코드
        /// </summary>
        public string SHOP_CD { get; set; }
        /// <summary>
        /// 공공앱 가맹점 명
        /// </summary>
        public string SHOP_NAME { get; set; }
        /// <summary>
        /// 매핑 시퀀스
        /// </summary>
        public string SHOP_MAP_SEQ { get; set; }
        /// <summary>
        /// 공공앱 영업점 코드
        /// </summary>
        public string CCCODE { get; set; }
        /// <summary>
        /// 사용/미사용
        /// </summary>
        public string API_USE_YN { get; set; }
        /// <summary>
        /// 연동사 형태 : 배달 / POS 
        /// </summary>
        public string API_TYPE { get; set; }
        /// <summary>
        /// 연동사 업체 명
        /// </summary>
        public string API_COM_GBN { get; set; }
        /// <summary>
        /// 연동사 의 가맹점 코드
        /// </summary>
        public string API_COM_CODE { get; set; }
        /// <summary>
        /// 연동사의 가맹점 코드2
        /// </summary>
        public string API_COM_CODE2 { get; set; }
        /// <summary>
        /// 연동사 가맹점의 인증 키
        /// </summary>
        public string API_COM_AUTH { get; set; }
        /// <summary>
        /// 연동사 가맹점의 토큰 ( Connection )
        /// </summary>
        public string API_COM_TOKEN { get; set; }
        /// <summary>
        /// 연동사 가맹점 ID
        /// </summary>
        public string API_COM_ID { get; set; }
        /// <summary>
        /// 연동사 가맹점 비밀번호
        /// </summary>
        public string API_COM_PASS { get; set; }
        /// <summary>
        /// 연동사 가맹점 일일 토큰 ( 24시간 또는 특정 시간에 따라 갱신 )
        /// </summary>
        public string API_DAILY_TOKEN { get; set; }
        /* 보류{get;set;} 2021/03/29
public string API_ETC_CODE1{get;set;}
public string API_ETC_CODE2{get;set;}
public string API_ETC_CODE3{get;set;}
public string API_ETC_CODE4{get;set;}
public string API_ETC_CODE5{get;set;}
public string API_ETC_CODE6{get;set;}
public string API_ETC_CODE7{get;set;}
public string API_ETC_CODE8{get;set;}
public string API_ETC_CODE9{get;set;}
public string API_ETC_CODE10{get;set;}
public string */
        public string INS_UCODE { get; set; }
        public string INS_NAME { get; set; }
        public string INS_DATE { get; set; }
        public string MOD_UCODE { get; set; }
        public string MOD_NAME { get; set; }
        public string MOD_DATE { get; set; }



    }
}
