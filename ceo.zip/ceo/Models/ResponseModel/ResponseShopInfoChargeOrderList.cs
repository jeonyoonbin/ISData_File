﻿namespace PosWebApp.Models.ResponseModel
{
    public class ResponseShopInfoChargeOrderList
    {
        public string seqno { get; set; }
        public string order_date { get; set; }
        public string order_no { get; set; }
        /// <summary>
        /// 메뉴 금액
        /// </summary>
        public string menu_amount { get; set; }
        /// <summary>
        /// 배달팁 금액
        /// </summary>
        public string delivery_tip_amount { get; set; }
        /// <summary>
        /// 총금액
        /// </summary>
        public string total_amount { get; set; }
        /// <summary>
        /// 할인총액 ( 쿠폰 + 마일리지 + 행복페이, 배달팁 할인 )
        /// </summary>
        public string disc_amount { get; set; }
        /// <summary>
        /// 결제금액
        /// </summary>
        public string amount { get; set; }
        /// <summary>
        /// 쿠폰 사용 금액
        /// </summary>
        public string coupon_amount { get; set; }
        /// <summary>
        /// 마일리지 사용 금액
        /// </summary>
        public string mileage_use_amount { get; set; }
        public string charge_date { get; set; }
        public string charge_gbn { get; set; }
        public string charge_gbn_name { get; set; }
        public string in_amount { get; set; }
        public string out_amount { get; set; }
        public string charge_amount { get; set; }
        public string memo { get; set; }
    }
}
