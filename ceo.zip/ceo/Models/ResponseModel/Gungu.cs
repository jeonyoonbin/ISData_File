﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class Gungu
    {
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string b_code { get; set; }
        public string h_code { get; set; }
    }
}
