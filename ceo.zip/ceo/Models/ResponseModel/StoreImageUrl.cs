﻿namespace PosWebApp.Models.ResponseModel
{
    public class StoreImageUrl
    {
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string image_url { get; set; }
    }
}
