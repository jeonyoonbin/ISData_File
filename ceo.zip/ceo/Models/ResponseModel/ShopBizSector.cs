﻿using System.Collections.Generic;

namespace PosWebApp.Models.ResponseModel
{
    public class ShopBizSector
    {
        public string sido { get; set; }
        public List<ShopSigunguBizSector> sigunguList { get; set; }
    }

    public class ShopSigunguBizSector
    {
        public string sigungu { get; set; }
        public List<HDong> umdrList { get; set; }
    }
}
