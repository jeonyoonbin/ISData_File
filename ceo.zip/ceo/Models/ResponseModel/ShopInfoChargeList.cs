﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopInfoChargeList
    {
        public string SEQNO { get; set; }
        public string MCODE { get; set; }
        public string CCCODE { get; set; }
        public string SHOP_CD { get; set; }
        public string ORDER_DATE { get; set; }
        public string ORDER_NO { get; set; }
        public string CHARGE_DATE { get; set; }
        public string CHARGE_GBN { get; set; }
        public string IN_AMT { get; set; }
        public string OUT_AMT { get; set; }
        public string CHARGE_AMT { get; set; }
        public string CHARGE_UCODE { get; set; }
        public string MEMO { get; set; }
        public string BANKCODE { get; set; }
        public string VACCOUNT { get; set; }
        public string CHARGE_ACC { get; set; }
        public string TRAN_MCODE { get; set; }
        public string TRAN_CCCODE { get; set; }
        public string SHOP_NAME { get; set; }
        public string USER_ID { get; set; }
        public string ACC_DATE { get; set; }
    }
}
