﻿using PosWebApp.Models.RequestModel;
using System.Data;

namespace PosWebApp.Models.ResponseModel
{
    public class ShopOrder
    {
        public ShopOrder()
        {

        }
        public ShopOrder(DataRow row, CUST_ORDER_SEARCH_TYPE type)
        {
            switch(type)
            {
                case CUST_ORDER_SEARCH_TYPE.기본내역:
                    {
                        NewOrderList(row);
                        //this.order_no = row["번호"].ToString();
                        //this.order_status = row["상태"].ToString();
                        //this.shop_name = row["가맹점상호"].ToString();
                        //this.ccode = row["고객코드"].ToString();
                        //this.cust_name = row["고객명"].ToString();
                        //this.telno = row["전화번호"].ToString();
                        //this.menu_amt = row["메뉴금액"].ToString();
                        //this.disc_amt = row["할인액"].ToString();
                        //this.tot_amt = row["주문금액"].ToString();
                        //this.amount = row["승인금액"].ToString();
                        //this.card_approval_gbn = row["카드승인유무"].ToString();
                        //this.prcs_gbn = row["처리구분"].ToString();
                        //this.pay_gbn = row["지급구분"].ToString();
                        //this.app_pay_gbn = row["현장결제구분"].ToString();
                        //this.order_time_date = row["날짜"].ToString();
                        //this.order_date = row["주문일자"].ToString();
                        //this.order_time = row["주문시각"].ToString();
                        //this.addr1 = row["출발지_구주소"].ToString();
                        //this.addr2 = row["출발지_신주소"].ToString();
                        //this.loc = row["약도"].ToString();
                        //this.memo = row["메모"].ToString();
                        //this.order_qty = row["총주문건수"].ToString();
                        //this.ok_qty = row["완료주문건수"].ToString();
                        //this.cancel_qty = row["취소주문건수"].ToString();
                        //this.last_ordered_date = row["최종주문일"].ToString();
                        //this.is_api_order = row["배달의뢰유무"].ToString();
                        //this.mileage = row["마일리지"].ToString();
                        //this.mileage_amount = row["마일리지적립액"].ToString();
                        //this.delivery_rider_info = row["배달기사"].ToString();
                        //this.dest_sido = row["도착시도"].ToString();
                        //this.dest_gungu = row["도착군구"].ToString();
                        //this.dest_dong = row["도착동"].ToString();
                        //this.dest_jibun = row["도착지지번"].ToString();
                        //this.road_dest_dong = row["도착지도로명"].ToString();
                        //this.road_dest_addr = row["도착지도로주소"].ToString();
                        //this.road_dest_building = row["도착지건물명"].ToString();
                        //this.dest_lon = row["도착지경도"].ToString();
                        //this.dest_lat = row["도착지위도"].ToString();
                        //this.coupon_no = row["쿠폰번호_가입"].ToString();
                        //this.coupon_amt = row["쿠폰금액_가입"].ToString();
                        //this.coupon_no2 = row["쿠폰번호_주문"].ToString();
                        //this.coupon_amt2 = row["쿠폰금액_주문"].ToString();
                        //this.delivery_tip_amt = row["배달팁금액"].ToString();
                        //this.delivery_rider_memo = row["기사전달메모"].ToString();
                        //this.pack_order_yn = row["포장오더구분"].ToString();
                        //this.delivery_shop_memo = row["가맹점전달메모"].ToString();
                    }
                    break;
                case CUST_ORDER_SEARCH_TYPE.주문상세:
                    {

                    }
                    break;

                default:
                    break;
            }
        }

        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string order_no { get; set; }
        public string order_status { get; set; }
        public string shop_name { get; set; }
        public string ccode { get; set; }
        public string cust_name { get; set; }
        public string telno { get; set; }
        public string menu_amt { get; set; }
        public string disc_amt { get; set; }
        public string tot_amt { get; set; }

        public string amount { get; set; }
        public string card_approval_gbn { get; set; }
        /// <summary>
        /// 처리구분
        /// 인성  : 1, 가맹점: 3, 고객앱: 'A'
        /// </summary>
        public string prcs_gbn { get; set; }
        /// <summary>
        /// 지급구분
        /// 1: 현금, 2: 카드, 3:외상, 4: 쿠폰(가맹점자체), 5: 마일리지, 7: 행복페이, 8: 제로페이, 9: 선결제, P: 휴대폰, B: 계좌이체
        /// </summary>
        public string pay_gbn { get; set; }
        public string cust_lon { get;  set; }
        public string cust_lat { get;  set; }
        public string cust_dong_addr { get;  set; }

        /// <summary>
        /// 현장결제구분
        /// 1: 현장(배달시 현금), 3: 앱결제, 5: 현장(배달시 카드)
        /// </summary>
        public string app_pay_gbn { get; set; }
        /// <summary>
        /// 날짜
        /// </summary>
        public string order_time_date { get; set; }
        /// <summary>
        /// 주문일자
        /// </summary>
        public string order_date { get; set; }
        /// <summary>
        /// 주문시간
        /// </summary>
        public string order_time { get; set; }
        public string status { get;  set; }
        public string status_name { get;  set; }
        public string addr1 { get; set; }
        public string addr2 { get; set; }
        public string loc { get; set; }
        public string memo { get; set; }
        public string order_qty { get; set; }
        public string ok_qty { get; set; }
        public string cancel_qty { get; set; }
        public string last_ordered_date { get; set; }
        public string is_api_order { get; set; }
        public string mileage { get; set; }
        public string mileage_amount { get; set; }
        public string delivery_rider_info { get; set; }
        public string dest_sido { get; set; }
        public string dest_gungu { get; set; }
        public string dest_dong { get; set; }
        public string dest_jibun { get; set; }
        public string road_dest_dong { get; set; }
        public string road_dest_addr { get; set; }
        public string road_dest_building { get; set; }
        public string dest_lon { get; set; }
        public string dest_lat { get; set; }
        public string coupon_no { get; set; }
        public string coupon_amt { get; set; }
        public string coupon_no2 { get; set; }
        public string coupon_amt2 { get; set; }
        public string delivery_tip_amt { get; set; }
        public string pack_order_yn { get; set; }
        public string pack_order_name { get;  set; }
        public string delivery_rider_memo { get; set; }
        public string delivery_shop_memo { get; set; }


        public void NewOrderList(DataRow row)
        {
            this.order_no       = row["order_no"].ToString();
            this.order_time     = row["order_time"].ToString();
            this.status         = row["status"].ToString();
            this.status_name    = row["status_name"].ToString();
            this.pack_order_yn  = row["pack_order_yn"].ToString();
            this.pack_order_name= row["pack_order_name"].ToString();
            this.tot_amt        = row["tot_amt"].ToString();
            this.app_pay_gbn  = row["app_pay_gbn"].ToString();
            this.pay_gbn        = row["pay_gbn"].ToString();
            this.cust_lon       = row["cust_lon"].ToString();
            this.cust_lat       = row["cust_lat"].ToString();
            this.cust_dong_addr = row["cust_dong_addr"].ToString();
        }
    }
}
