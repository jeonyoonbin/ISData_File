﻿namespace PosWebApp.Models.ResponseModel
{
    public class ResponseShopAccountInfo
    {
        public string remain_amt { get; set; }
        public string account_info { get; set; }
        public string bank_code { get; set; }
        public string account_no { get; set; }
        public string account_owner { get; set; }
        public string transfering_amt { get; set; }
        public string confirm_gbn { get; set; }
        public string transfer_sms_gbn { get; set; }
        public string real_remain_amt { get; set; }
        public string bank_name { get; set; }

        /*v2*/
        public string shopName { get; set; }
        public string absentYn { get; set; }
        public string multiShopYn { get; set; }
        public string multiShopCd { get; set; }
        public string representativeYn { get; set; }
    }
}
