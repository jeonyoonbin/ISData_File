﻿using System.Data;

namespace PosWebApp.Models.ResponseModel
{
    public class ShopSMenu
    {
        public ShopSMenu()
        {

        }
        public ShopSMenu(DataRow row)
        {
            this.cccode = row["cccode"].ToString();
            this.item_cd = row["item_cd"].ToString();
            this.sshop_cd = row["sshop_cd"].ToString();
            this.sshop_name = row["sshop_name"].ToString();
            this.menu_cd = row["menu_cd"].ToString();
            this.menu_name = row["menu_name"].ToString();
            this.menu_sname = row["menu_sname"].ToString();
            this.menu_group_cd = row["menu_group_cd"].ToString();
            this.menu_group_name = row["menu_group_name"].ToString();
            this.menu_cost = row["menu_cost"].ToString();
            this.menu_desc = row["menu_desc"].ToString();
            this.use_yn = row["use_yn"].ToString();
            int.TryParse(row["sort_seq"].ToString(), out int sortSeq);
            this.sort_seq = sortSeq;
            this.file_name = row["file_name"].ToString();
            this.isrt_date = row["isrt_date"].ToString();
            this.isrt_name = row["isrt_name"].ToString();
        }

        public string cccode { get; set; }
        public string item_cd { get; set; }
        public string sshop_cd { get; set; }
        public string sshop_name { get; set; }
        public string menu_cd { get; set; }
        public string menu_name { get; set; }
        public string menu_sname { get; set; }
        public string menu_group_cd { get; set; }
        public string menu_group_name { get; set; }
        public string menu_cost { get; set; }
        public string menu_desc { get; set; }
        public string use_yn { get; set; }
        public int sort_seq { get; set; }
        public string file_name { get; set; }
        public string isrt_date { get; set; }
        public string isrt_name { get; set; }
    }
}
