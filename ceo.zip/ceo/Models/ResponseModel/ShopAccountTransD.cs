﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopAccountTransD
    {
        public string tran_seqno { get; set; }
        public string tran_time { get; set; }
        public string mcode { get; set; }
        public string cccode { get; set; }
        public string ucode { get; set; }
        public string user_name { get; set; }
        public string mobile { get; set; }
        public string isrt_date { get; set; }
        public string tran_memo { get; set; }
        public string remain_amt { get; set; }
        public string tran_amt { get; set; }
        public string cc_account { get; set; }
        public string user_pass { get; set; }
        public string memo { get; set; }
        public string req_amt { get; set; }
        public string bankcode { get; set; }
        public string account_no { get; set; }
        public string acc_owner { get; set; }
        public string shop_cd { get; set; }
        public string acc_confirm_gbn { get; set; }
        public string shop_mobile { get; set; }
    }
}
