﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopDetail
    {
        public string cccode { get; set; }
        public string ccname { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string telno { get; set; }
        public string mobile { get; set; }
        public string sido { get; set; }
        public string gungu { get; set; }
        public string dong_name { get; set; }
        public string 상세위치 { get; set; }
        public string 출발지 { get; set; }
        public string 주소 { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
        public string memo { get; set; }
        public string cook_wait_time { get; set; }
        public string 영업시작시간 { get; set; }
        public string 영업종료시간 { get; set; }
        public string shop_gbn { get; set; }
        public string u_plues_id { get; set; }
        public string card_sub_id { get; set; }
        public string app_order_yn { get; set; }
        public string app_in_date { get; set; }
        public string app_calc_amt { get; set; }
        public string app_calc_gbn { get; set; }
        public string app_file_name { get; set; }
        public string app_min_amt { get; set; }
        public string app_pay_type { get; set; }
        public string sale_fr_time { get; set; }
        public string sale_to_time { get; set; }
        public string food_order_yn { get; set; }
        public string item_cd { get; set; }
    }
}
