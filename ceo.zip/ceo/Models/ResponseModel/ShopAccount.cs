﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class ShopAccount
    {
        public string BANKCODE { get; set; }
        public string ACCOUNT_NO { get; set; }
        public string ACC_OWNER { get; set; }
        public string PAY_CONFIRM { get; set; }
        public string ACC_CONFIRM_GBN { get; set; }
    }
}
