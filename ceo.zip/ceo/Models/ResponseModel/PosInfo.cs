﻿namespace PosWebApp.Models.ResponseModel
{
    public class PosInfo
    {
        public string ver_info { get; set; }
        public string ins_date { get; set; }
        public string query_data { get; set; }
        public string memo { get; set; }
        public string update_gbn { get; set; }
    }
}
