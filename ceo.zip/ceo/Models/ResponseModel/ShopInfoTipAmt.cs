﻿namespace PosWebApp.Models.ResponseModel
{
    public enum DELIVERY_TIP_GBN
    {
        /// <summary>
        /// 영업시간 배달팁
        /// </summary>
        영업시간 = 100,
        /// <summary>
        /// 설정시간별 배달팁
        /// TIP_DAY : 1 ~ 7, FR_STAND : 0900, TO_STAND : 2300
        /// </summary>
        시간대 = 7,
        /// <summary>
        /// 주문 금액별 배달팁
        /// TIP_DAY : 사용안함
        /// </summary>
        금액 = 3,
        /// <summary>
        /// 동별 배달팁
        /// TIP_DAY : 사용안함 FR_STAND : 동명, TO_STAND : 0
        /// </summary>
        동별 = 9
    }

    public class ShopInfoTipAmt
    {
        public string shop_cd { get; set; }
        public string status { get; set; }
        public string shop_name { get; set; }
        public string tip_seq { get; set; }
        public string tip_gbn { get; set; }
        public string tip_day { get; set; }
        public string tip_fr_stand { get; set; }
        public string tip_to_stand { get; set; }
        public string tip_amt { get; set; }
        public string tip_amt_rate { get; set; }
        public string tip_next_day { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string ins_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
        public string mod_date { get; set; }

    }
}
