﻿namespace PosWebApp.Models.ResponseModel
{
    public class OrderTimePreset
    {
        public string time_name { get; set; }
        public int time { get; set; }
        public bool selected { get; set; }
    }
}
