﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class SHOP_MENU_NEW
    {
        public SHOP_MENU_NEW()
        {
        }
        public SHOP_MENU_NEW(DataRow row)
        {
            this.pkey = row["pkey"].ToString();
            this.ckey = row["ckey"].ToString();
            this.cccode = row["cccode"].ToString();
            this.shop_cd = row["shop_cd"].ToString();
            this.menu_cd = row["menu_cd"].ToString();
            this.menu_group_cd = row["menu_group_cd"].ToString();
            this.o_name = row["o_name"].ToString();
            this.ocost = row["ocost"].ToString();
            this.sort_seq = row["sort_seq"].ToString();
            this.file_name = row["file_name"].ToString();
            this.otype = row["otype"].ToString();
            this.opt_count = row["opt_count"].ToString();
            this.menu_search_tag = row["m_search_tag"].ToString();
            this.menu_alone_order = row["m_alone_order"].ToString();
            this.menu_main_yn = row["m_main_yn"].ToString();
            this.m_menu_type = row["m_menu_type"].ToString();
        }

        public string pkey { get; set; }
        public string ckey { get; set; }
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string menu_cd { get; set; }
        public string menu_group_cd { get; set; }
        public string o_name { get; set; }
        public string ocost { get; set; }
        public string sort_seq { get; set; }
        public string file_name { get; set; }
        public string otype { get; set; }
        public string opt_count { get; set; }

        public string menu_search_tag { get; set; }
        public string menu_alone_order { get; set; }
        public string menu_main_yn { get; set; }
        public string m_menu_type { get; set; }
        /// <summary>
        /// group -> menu -> menu options etc. next point
        /// </summary>
        public List<SHOP_MENU_NEW> sub_menus { get; set; }
    }
}
