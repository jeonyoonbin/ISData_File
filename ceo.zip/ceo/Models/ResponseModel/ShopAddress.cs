﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopAddress
    {
        public double lon { get; set; }
        public double lat { get; set; }
        public string addr1 { get; set; }
        public string addr2 { get; set; }
        public string sido_name { get; set; }
        public string gungu_name { get; set; }
        public string dong_name { get; set; }
        public string road_dest_dong { get; set; }
        public string road_dest_addr { get; set; }
        public string dest_jibun { get; set; }
        public string road_dest_building { get; set; }
        public string loc { get; set; }
    }
}
