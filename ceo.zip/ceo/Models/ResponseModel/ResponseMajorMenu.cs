﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class ResponseMajorMenu
    {
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string menu_cd { get; set; }
        public string menu_name { get; set; }
        public string file_name { get; set; }
        public string m_main_yn { get; set; }
    }
}
