﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopStoreInfo
    {
        public string cccode { get; set; }
        public string ccname { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string telno { get; set; }
        public string mobile { get; set; }
        public string shop_type { get; set; }
        public string addr1 { get; set; }
        public string addr2 { get; set; }
        public string sido_name { get; set; }
        public string gungu_name { get; set; }
        public string dong_name { get; set; }
        public string road_dest_dong { get; set; }
        public string road_dest_addr { get; set; }
        public string dest_jibun { get; set; }
        public string road_dest_building { get; set; }
        public string loc { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
        public string memo { get; set; }
        public string cook_wait_time { get; set; }
        public string shop_gbn { get; set; }
        public string u_plues_id { get; set; }
        public string card_sub_id { get; set; }
        public string app_order_yn { get; set; }
        public string app_in_date { get; set; }
        public string app_calc_amt { get; set; }
        public string app_calc_gbn { get; set; }
        public string app_file_name { get; set; }
        public string app_min_amt { get; set; }
        public string app_pay_type { get; set; }
        public string sale_fr_time { get; set; }
        public string sale_to_time { get; set; }
        public string food_order_yn { get; set; }
        public string item_cd { get; set; }
        public string item_cd2 { get; set; }
        public string item_cd3 { get; set; }
        public string food_pack_fee_yn { get; set; }
        public string app_logo_name { get; set; }
        public string free_order_amt { get; set; }
        public string search_tag { get; set; }
        public string alone_order { get; set; }
        public string stamp_use_gbn { get; set; }
        public string accept_state { get; set; }    /// 가맹점 배달 완료 시간
        public string happy_pay { get; set; }

    }
}
