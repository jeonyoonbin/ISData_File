﻿namespace PosWebApp.Models.ResponseModel
{
    public class ORDER_COMPLETE_TIME
    {
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string accept_state { get; set; }
    }
}
