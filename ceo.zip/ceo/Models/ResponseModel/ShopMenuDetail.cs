﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class ShopMenuDetail
    {
        public ShopMenuDetail()
        {

        }
        public ShopMenuDetail(DataRow row)
        {
            this.cccode = row["cccode"].ToString();
            this.shop_cd = row["shop_cd"].ToString();
            //this.sshop_name = row["sshop_name"].ToString();
            this.menu_cd = row["menu_cd"].ToString();
            this.menu_name = row["menu_name"].ToString();
            this.menu_sname = row["menu_sname"].ToString();
            this.menu_group_cd = row["menu_group_cd"].ToString();
            this.menu_group_name = row["menu_group_name"].ToString();
            this.menu_cost = row["menu_cost"].ToString();
            this.menu_desc = row["menu_desc"].ToString();
            this.use_gbn = row["use_gbn"].ToString();
            this.sort_seq = Convert.ToInt32(row["sort_seq"].ToString());
            this.file_name = row["file_name"].ToString();


            this.alone_order = row["m_alone_order"].ToString();
            this.search_tag = row["m_search_tag"].ToString();
            this.main_yn = row["m_main_yn"].ToString();
            this.menu_type = row["m_menu_type"].ToString();

            this.isrt_date = row["isrt_date"].ToString();
            this.isrt_name = row["isrt_name"].ToString();
           // this.menu_group_sort_seq = Convert.ToInt32(row["mgroup_sort_seq"].ToString());
            //this.option_count = Convert.ToInt32(row["opt_count"].ToString());
            //this.item_cd = row["item_cd"].ToString();

        }

        public string cccode { get; set; }
        public string shop_cd { get; set; }
       // public string sshop_name { get; set; }
        public string menu_cd { get; set; }
        public string menu_name { get; set; }
        public string menu_sname { get; set; }
        public string menu_group_cd { get; set; }
        public string menu_group_name { get; set; }
        [RegularExpression(@"^[0-9]*$",
            ErrorMessage = "숫자만 입력해주세요")]
        public string menu_cost { get; set; }
        public string menu_desc { get; set; }
        public string use_gbn { get; set; }
        public int sort_seq { get; set; }
        public string file_name { get; set; }
        public IFormFile formFile { get; set; }
        public string alone_order { get; set; }
        public string search_tag { get; set; }
        public string main_yn { get; set; }
        public string menu_type { get; set; }

        public string isrt_date { get; set; }
        public string isrt_name { get; set; }
       // public int menu_group_sort_seq { get; set; }
        // public int option_count { get; set; }
        // public string item_cd { get; set; }
       // public List<MenuGroupList> groupLists { get; set; }
    }
}
