﻿using System.Data;

namespace PosWebApp.Models.ResponseModel
{
    public class ShopSMenuOption
    {
        public ShopSMenuOption()
        {

        }
        public ShopSMenuOption(DataRow row)
        {
            this.cccode = row["cccode"].ToString();
            this.item_cd = row["item_cd"].ToString();
            this.sshop_cd = row["sshop_cd"].ToString();
            this.menu_cd = row["menu_cd"].ToString();
            this.option_group_cd = row["option_group_cd"].ToString();
            this.option_group_name = row["option_group_name"].ToString();
            this.option_cd = row["option_cd"].ToString();
            this.option_name = row["option_name"].ToString();
            this.option_memo = row["option_memo"].ToString();
            this.ocost = row["ocost"].ToString();
            this.use_yn = row["use_yn"].ToString();
            int.TryParse(row["sort_seq"].ToString(), out int sortSeq);
            this.sort_seq = sortSeq;
            this.omenu_file_name = row["omenu_file_name"].ToString();
        }

        public string cccode { get; set; }
        public string item_cd { get; set; }
        public string sshop_cd { get; set; }
        public string menu_cd { get; set; }
        public string option_group_cd { get; set; }
        public string option_group_name { get; set; }
        public string option_cd { get; set; }
        public string option_name { get; set; }
        public string option_memo { get; set; }
        public string ocost { get; set; }
        public string use_yn { get; set; }
        public int sort_seq { get; set; }
        public string omenu_file_name { get; set; }

    }
}
