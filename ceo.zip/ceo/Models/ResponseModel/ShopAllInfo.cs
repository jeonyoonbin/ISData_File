﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    /// <summary>
    /// 매핑 등록 시 가맹점 조회 용으로 사용 됨
    /// </summary>
    public class ShopAllInfo
    {
        public string mcode { get; set; }
        public string ccname { get; set; }
        public string shop_name { get; set; }
        public string shop_id { get; set; }
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string telno { get; set; }
        public string address { get; set; }
        public string road { get; set; }
        public string mobile { get; set; }
        public string item_cd { get; set; }
        public string app_order_yn { get; set; }
        public string app_in_date { get; set; }
    }
}
