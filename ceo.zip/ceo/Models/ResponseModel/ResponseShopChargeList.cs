﻿namespace PosWebApp.Models.ResponseModel
{
    public class ResponseShopChargeList
    {
        public string seqno { get; set; }
        public string mcode { get; set; }
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string order_date { get; set; }
        public string order_no { get; set; }
        public string charge_date { get; set; }
        public string charge_gbn { get; set; }
        public string charge_gbn_name { get; set; }
        public string in_amt { get; set; }
        public string out_amt { get; set; }
        public string charge_amt { get; set; }
        public string charge_ucode { get; set; }
        public string memo { get; set; }
        public string bank_code { get; set; }
        public string vaccount { get; set; }
        public string charge_acc { get; set; }
        public string tran_mcode { get; set; }
        public string tran_cccode { get; set; }
        public string shop_name { get; set; }
        public string user_name { get; set; }
        public string acc_date { get; set; }
        public long remain_amount { get; set; }
    }
}
