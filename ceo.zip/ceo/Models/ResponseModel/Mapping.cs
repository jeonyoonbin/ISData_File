﻿namespace PosWebApp.Models.ResponseModel
{
    public class Mapping
    {
        public string shop_cd { get; set; }
        public string shop_map_seq { get; set; }
        public string cccode { get; set; }
        public string api_use_yn { get; set; }
        public string api_type { get; set; }
        public string api_com_gbn { get; set; }
        public string api_com_code { get; set; }
        public string api_com_code2 { get; set; }
        public string api_com_token { get; set; }
        public string api_com_auth { get; set; }
        public string api_com_id { get; set; }
        public string api_com_pass { get; set; }
        public string api_daily_token { get; set; }
        public string api_etc_code1 { get; set; }
        public string api_etc_code2 { get; set; }
        public string api_etc_code3 { get; set; }
        public string api_etc_code4 { get; set; }
        public string api_etc_code5 { get; set; }
        public string api_etc_code6 { get; set; }
        public string api_etc_code7 { get; set; }
        public string api_etc_code8 { get; set; }
        public string api_etc_code9 { get; set; }
        public string api_etc_code10 { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string ins_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
        public string mod_date { get; set; }

    }
}
