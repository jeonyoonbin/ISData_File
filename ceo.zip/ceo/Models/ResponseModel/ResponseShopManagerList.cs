﻿using PosWebApp.Models.RequestModel;
using System.Data;
using System.Data.Common;

namespace PosWebApp.Models.ResponseModel
{
    public class ResponseShopManagerList
    {
        public ResponseShopManagerList(ShopManagerType job_type, DbDataReader rows)
        {
            switch(job_type)
            {
                case ShopManagerType.요일별:
                    ctorDays(rows);
                    break;
                case ShopManagerType.일자별:
                    ctorDaily(rows);
                    break;
                case ShopManagerType.취소사유별:
                    ctorCancel(rows);
                    break;
                case ShopManagerType.결제구분별:
                    ctorPayType(rows);
                    break;
            }
        }

        /// <summary>
        /// 일자별 생성자
        /// </summary>
        private void ctorDaily(DbDataReader rows)
        {
            this.order_date = rows["order_date"].ToString();
            this.total_count = rows["tot_cnt"].ToString();
            this.ok_count = rows["ok_cnt"].ToString();
            this.menu_amount = rows["menu_amount"].ToString();
            this.ok_amount = rows["ok_amount"].ToString();
            this.cancel_count = rows["can_cnt"].ToString();
            this.cancel_rate = rows["can_rate"].ToString();
        }
        /// <summary>
        /// 요일별 생성자
        /// </summary>
        private void ctorDays(DbDataReader rows)
        {
            this.order_date = rows["order_date"].ToString();
            this.day_gbn = rows["day_gbn"].ToString();
            this.total_count = rows["tot_cnt"].ToString();
            this.ok_count = rows["ok_cnt"].ToString();
            this.menu_amount = rows["menu_amount"].ToString();
            this.ok_amount = rows["ok_amount"].ToString();
            this.cancel_count = rows["can_cnt"].ToString();
            this.cancel_rate = rows["can_rate"].ToString();
        }
        /// <summary>
        /// 취소 사유별 생성자
        /// </summary>
        private void ctorCancel(DbDataReader rows)
        {
            this.cancel_code = rows["cancel_code"].ToString();
            this.cancel_reason = rows["cancel_nm"].ToString();
            this.cancel_count = rows["can_cnt"].ToString();
        }
        /// <summary>
        /// 결제 구분 별 생성자
        /// </summary>
        private void ctorPayType(DbDataReader rows)
        {
            this.order_date = rows["order_date"].ToString();
            this.total_count = rows["tot_cnt"].ToString();
            this.total_amount = rows["tot_amt"].ToString();
            this.app_card_count = rows["app_card_cnt"].ToString();
            this.app_card_amount = rows["app_card_amt"].ToString();
            this.app_daegu_count = rows["app_daegu_cnt"].ToString();
            this.app_daegu_amount = rows["app_daegu_amt"].ToString();
            this.delivery_cash_count = rows["deli_cash_cnt"].ToString();
            this.delivery_cash_amount = rows["deli_cash_amt"].ToString();
            this.delivery_card_count = rows["deli_card_cnt"].ToString();
            this.delivery_card_amount = rows["deli_cadr_amt"].ToString();
        }

        /// <summary>
        /// 발생일자
        /// </summary>
        public string order_date { get; set; }
        /// <summary>
        /// 주문건수
        /// </summary>
        public string total_count { get; set; }
        /// <summary>
        /// 주문금액
        /// </summary>
        public string total_amount { get; set; }
        /// <summary>
        /// 완료건수
        /// </summary>
        public string ok_count { get; set; }
        /// <summary>
        /// 메뉴금액
        /// </summary>
        public string menu_amount { get; set; }
        /// <summary>
        /// 결제금액
        /// </summary>
        public string ok_amount { get; set; }
        /// <summary>
        /// 취소건수
        /// </summary>
        public string cancel_count { get; set; }
        /// <summary>
        /// 취소율
        /// </summary>
        public string cancel_rate { get; set; }
        /// <summary>
        /// 요일구분
        /// </summary>
        public string day_gbn { get; set; }
        /// <summary>
        /// 취소코드
        /// </summary>
        public string cancel_code { get; set; }
        /// <summary>
        /// 취소사유
        /// </summary>
        public string cancel_reason { get; set; }
        /// <summary>
        /// 앱카드결제건수
        /// </summary>
        public string app_card_count { get; set; }
        /// <summary>
        /// 앱카드결제금액
        /// </summary>
        public string app_card_amount { get; set; }
        /// <summary>
        /// 앱 행복페이 결제건수
        /// </summary>
        public string app_daegu_count { get; set; }
        /// <summary>
        /// 앱 행복페이 결제금액
        /// </summary>
        public string app_daegu_amount { get; set; }
        /// <summary>
        /// 현장 현금 건수
        /// </summary>
        public string delivery_cash_count { get; set; }
        /// <summary>
        /// 현장 현금 금액
        /// </summary>
        public string delivery_cash_amount { get; set; }
        /// <summary>
        /// 현장 카드 건수
        /// </summary>
        public string delivery_card_count { get; set; }
        /// <summary>
        /// 현장 카드 금액
        /// </summary>
        public string delivery_card_amount { get; set; }

    }
}
