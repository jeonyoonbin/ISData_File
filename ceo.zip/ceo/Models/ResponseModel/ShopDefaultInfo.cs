﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopDefaultInfo
    {
        public string ITEM_CD { get; set; }
        public string MAIN_ITEM { get; set; }
        public string TELNO { get; set; }
        public string MOBILE { get; set; }
        public string EMAIL { get; set; }
        public string OWNER_BIRTH { get; set; }
        public string USE_GBN { get; set; }
        public string PC_YN { get; set; }
        public string SHOP_TYPE { get; set; }
        public string SIDO_NAME { get; set; }
        public string GUNGU_NAME { get; set; }
        public string DONG_NAME { get; set; }
        public string LOC { get; set; }
        public string ROAD_DEST_DONG { get; set; }
        public string ROAD_DEST_ADDR { get; set; }
        public string SHOP_LEVEL { get; set; }
        public string APP_LOGO_NAME { get; set; }

    }
}
