﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopSaleTime
    {
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string from_time { get; set; }
        public string to_time { get; set; }
    }
}
