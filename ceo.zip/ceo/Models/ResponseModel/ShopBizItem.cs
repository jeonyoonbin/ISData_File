﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopBizItem
    {
        public string item_cd { get; set; }
        public string item_name { get; set; }
        public int sort_seq { get; set; }
    }
}
