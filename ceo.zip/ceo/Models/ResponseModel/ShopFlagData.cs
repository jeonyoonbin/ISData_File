﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopFlagData
    {
        public string job_gbn { get; set; }
        public string type { get; set; }
        public string flagSequence { get; set; }
        public string cccode { get; set; }
        public string shopCode { get; set; }
        public string displayShopName { get; set; }
        public string displayShopTelno { get; set; }
        public bool useGbn { get; set; }
        public double lon { get; set; }
        public double lat { get; set; }
        public string addr { get; set; }
        public string road { get; set; }
        public string memo { get; set; }
        public string updateUserCode { get; set; }
        public string updateUserName { get; set; }
    }
}
