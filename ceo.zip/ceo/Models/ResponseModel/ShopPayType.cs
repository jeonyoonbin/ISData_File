﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopPayType
    {
        public string shop_cd { get; set; }
        public string app_pay_type { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }
}
