﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopRestList
    {
        public string SHOP_CD { get; set; }
        public string SHOP_NAME { get; set; }
        public string REST_DT { get; set; }
        public string MEMO { get; set; }
        public string INS_UCODE { get; set; }
        public string INS_NAME { get; set; }
        public string INS_DATE { get; set; }
        public string MOD_UCODE { get; set; }
        public string MOD_NAME { get; set; }
        public string MOD_DATE { get; set; }

    }
}
