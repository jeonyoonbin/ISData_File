﻿using System;
using System.Data;

namespace PosWebApp.Models.ResponseModel
{
    public class ShopMenuGroup
    {
        public ShopMenuGroup()
        {

        }
        public ShopMenuGroup(DataRow row)
        {
            this.cccode = row["cccode"].ToString();
            this.menu_group_cd = row["menu_group_cd"].ToString();
            this.menu_group_name = row["menu_group_name"].ToString();
            this.menu_group_memo = row["menu_group_memo"].ToString();
            this.use_yn = row["use_yn"].ToString();
            this.option_yn = row["option_yn"].ToString();
            this.sort_seq = Convert.ToInt32(string.IsNullOrEmpty(row["sort_seq"].ToString()) ? "0" : row["sort_seq"].ToString());
            this.group_file_name = row["group_file_name"].ToString();
            this.main_img_yn = row["main_img_yn"].ToString();
        }

        public string cccode { get; set; }
        public string menu_group_cd { get; set; }
        public string menu_group_name { get; set; }
        public string menu_group_memo { get; set; }
        public string use_yn { get; set; }
        public string option_yn { get; set; }
        public int sort_seq { get; set; }
        public string group_file_name { get; set; }
        public string main_img_yn { get; set; }
    }
}
