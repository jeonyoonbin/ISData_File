﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PosWebApp.Models.ResponseModel
{
    public class TaxType
    {
        public int code { get; set; }
        public string type_name { get; set; }

        public static IEnumerable<TaxType> GetTaxTypes()
        {
            return Enum.GetValues(typeof(eTaxType)).Cast<eTaxType>().Select(x => new TaxType
            {
                code = (int)x,
                type_name = x.ToString()
            });
        }
        public static string GetTaxTypeName(string typeNumber)
        {
            try
            {
                int convert= Convert.ToInt32(typeNumber);

                var temp = GetTaxTypes().FirstOrDefault(x => x.code == convert);
                return temp.type_name;
            }
            catch(Exception e)
            {
                return eTaxType.일반.ToString();
            }
        }
    }
    public enum eTaxType
    {
        일반 = 1,
        간이 = 3,
        법인 = 5,
        면세 = 7
    }
}