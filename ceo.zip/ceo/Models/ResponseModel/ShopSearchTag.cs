﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopSearchTag
    {
        public string search_tag { get; set; }
    }
}
