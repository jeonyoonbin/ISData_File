﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopTransRemainAmt
    {
        public string remain_amt { get; set; }
        public string bank_info { get; set; }
        public string bankcode { get; set; }
        public string account_no { get; set; }
        public string acc_owner { get; set; }
        public string acc_confirm_gbn { get; set; }
        public string mobile { get; set; }
    }
}
