﻿namespace PosWebApp.Models.ResponseModel
{
    public class SynchronizeShopInfo
    {
        public string mcode { get; set; }
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string shop_id { get; set; }
        public string shop_name { get; set; }
        public string reg_no { get; set; }
        public string buss_owner { get; set; }
        public string telno { get; set; }
        public string mobile { get; set; }
        public string addr1 { get; set; }
        public string addr2 { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string dong { get; set; }
        public string jibun { get; set; }
        public string road { get; set; }
        public string build_no { get; set; }
        public string build_name { get; set; }

        public string api_com_id { get; set; }
        public string api_com_pass { get; set; }
        public string api_com_code { get; set; }
        public string api_com_gbn { get; set; }
        public string api_type { get; set; }
        public string acc_owner { get; set; }
        public string acc_no { get; set; }
        public string bank_code { get; set; }

    }
}
