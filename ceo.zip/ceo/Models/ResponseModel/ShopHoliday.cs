﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopHoliday
    {
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string running { get; set; }
        public string day_of_holiday { get; set; }
    }
}
