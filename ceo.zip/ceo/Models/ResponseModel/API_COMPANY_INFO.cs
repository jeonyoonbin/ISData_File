﻿namespace PosWebApp.Models.ResponseModel
{
    public class API_COMPANY_INFO
    {
        public string seq { get; set; }
        public string company_type { get; set; }
        public string company_gbn { get; set; }
        public string company_gbn_2 { get; set; }
        public string company_name { get; set; }
        public string company_token { get; set; }
        public string company_auth { get; set; }

    }
}
