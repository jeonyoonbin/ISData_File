﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class ShopFoodOrigins
    {
        public string content { get; set; }
    }
}
