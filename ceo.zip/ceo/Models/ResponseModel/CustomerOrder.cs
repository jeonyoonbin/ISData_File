﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class CustomerOrder
    {
        public string ORDER_NO { get; set; }
        public string SHOP_NAME { get; set; }
        public string STATUS { get; set; }
        public string CANCEL_REASON { get; set; }
        public string MENU_NAME { get; set; }
        public string MENU_AMT { get; set; }
        public string ORDER_AMT_TIP { get; set; }
        public string COUPON_AMT { get; set; }
        public string AMOUNT { get; set; }
        public string ORDER_NO1 { get; set; }
        public string ORDER_TIME { get; set; }
        public string SHOP_DONG_ADDR { get; set; }
        public string SHOP_ROAD_ADDR { get; set; }
        public string SHOP_ADDR_DETAIL { get; set; }
        public string LON { get; set; }
        public string LAT { get; set; }
        public string CUST_DONG_ADDR { get; set; }
        public string CUST_ROAD_ADDR { get; set; }
        public string CUST_ADDR_DETAIL { get; set; }
        public string PACK_ORDER_YN { get; set; }
        public string APP_PAY_GBN { get; set; }
        public string PAY_GBN { get; set; }
        public string RIDER_DELI_MEMO { get; set; }
        public string SHOP_DELI_MEMO { get; set; }

    }
}
