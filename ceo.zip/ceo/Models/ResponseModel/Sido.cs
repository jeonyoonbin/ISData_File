﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class Sido
    {
        public string sido { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
        public string b_code { get; set; }
    }
}
