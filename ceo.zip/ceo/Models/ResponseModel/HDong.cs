﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class HDong
    {
        public bool selected { get; set; }
        public string h_code { get; set; }
        public string b_code { get; set; }
        public string sido { get; set; }
        public string sigungu { get; set; }
        public string humdr { get; set; }
        public string b_name { get; set; }
        public string b_ri_name { get; set; }
        public string h_name { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
        public List<HDong> sub_link { get; set; }
    }
}
