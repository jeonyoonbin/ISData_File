﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class Sales
    {
        public int count
        {
            get
            {
                if (pay_from == null) return 0;
                return pay_from.Count;
            }
        }
        public List<SalesPayFrom> pay_from { get; set; }
        public string delivery_type { get; set; }
    }

    public class SalesPayFrom
    {
        public int count
        {
            get
            {
                if (pay_type == null) return 0;
                return pay_type.Count;
            }
        }
        public string pay_from { get; set; }
        public List<SalesPayType> pay_type { get; set; }

    }
    public class SalesPayType
    {
        
        public string pay_type { get; set; }
        public SalesStatics data { get; set; }
        public int count { get
            {
                if (data_list == null) return 0;
                return data_list.Count;
            }
        }
        public List<SalesStatics> data_list { get; set; }
    }
    public class SalesStatics
    {
        public int total_count { get; set; }
        public int total_amount { get; set; }
        public int ok_count { get; set; }
        public int ok_amount { get; set; }
        public int cancel_count { get; set; }
        public int cancel_amount { get; set; }
        public int discount_amount { get; set; }
        public int amount { get; set; }
    }
}
