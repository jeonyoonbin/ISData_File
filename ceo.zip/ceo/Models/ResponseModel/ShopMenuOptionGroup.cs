﻿using System;
using System.Data;

namespace PosWebApp.Models.ResponseModel
{
    public class ShopMenuOptionGroup
    {
        public ShopMenuOptionGroup()
        {

        }
        public ShopMenuOptionGroup(DataRow row)
        {
            cccode = row["cccode"].ToString();
            shop_cd = row["shop_cd"].ToString();
            menu_cd = row["menu_cd"].ToString();
            option_group_cd = row["option_group_cd"].ToString();
            option_group_name = row["option_group_name"].ToString();
            option_group_memo = row["option_group_memo"].ToString();
            use_yn = row["use_yn"].ToString();
            option_yn = row["option_yn"].ToString();
            req_yn = row["req_yn"].ToString();
            multi_yn = row["multi_yn"].ToString();
            multi_count = Convert.ToInt32(row["multi_count"].ToString());
            min_count = Convert.ToInt32(row["min_count"].ToString());
            sort_seq = Convert.ToInt32(row["sort_seq"].ToString());
            ogroup_file_name = row["ogroup_file_name"].ToString();
        }

        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string menu_cd { get; set; }
        public string option_group_cd { get; set; }
        public string option_group_name { get; set; }
        public string option_group_memo { get; set; }
        public string use_yn { get; set; }
        public string option_yn { get; set; }
        public string req_yn { get; set; }
        public string multi_yn { get; set; }
        /// <summary>
        /// 2021.04.09 최대 주문 가능 갯수 ( 3팀 제안 )
        /// </summary>
        public int multi_count { get; set; }
        /// <summary>
        /// 2021.04.09 최소 주문 가능 갯수 ( 3팀 제안)
        /// </summary>
        public int min_count { get; set; }
        public int sort_seq { get; set; }
        public string ogroup_file_name { get; set; }
    }
}
