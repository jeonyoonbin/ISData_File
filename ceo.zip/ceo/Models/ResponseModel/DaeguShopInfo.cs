﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ResponseModel
{
    public class DaeguShopInfo
    {
        public string GROUP_ID { get; set; }
        public string MCODE { get; set; }
        public string CCCODE { get; set; }
        public string CCNAME { get; set; }
        public string CENTER_MOBILE { get; set; }
        public string CENTER_CALLBACK_TELNO { get; set; }
        public string SHOP_CD { get; set; }
        public string SHOP_NAME { get; set; }
        public string SHOP_TELNO { get; set; }
        public string SIDO_NAME { get; set; }
        public string GUNGU_NAME { get; set; }
        public string DONG_NAME { get; set; }
        public string LON { get; set; }
        public string LAT { get; set; }
        public string REG_NO { get; set; }
        public string MULTI_SHOP_ID_YN { get; set; }
        public string APP_ORDER_YN { get; set; }
        public string NEW_CHAT_GBN { get; set; }
        public string OWNER { get; set; }
        public string ADDR { get; set; }
        public string API_COM_GBN { get; set; }
        public string API_COM_CODE { get; set; }
        public string API_POS_GBN { get; set; }
    }
}
