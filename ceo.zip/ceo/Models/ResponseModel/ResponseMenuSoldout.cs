﻿namespace PosWebApp.Models.ResponseModel
{
    public class ResponseMenuSoldout
    {
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string menu_cd { get; set; }
        public string no_flag { get; set; }
    }
}
