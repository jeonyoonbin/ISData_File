﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopBizItemCode
    {
        public string ITEM_CD { get; set; }
        public string ITEM_NAME { get; set; }
        public string ITEM_DESC { get; set; }
    }
}
