﻿namespace PosWebApp.Models.ResponseModel
{
    public class ReviewStatus
    {
        public string status { get; set; }
    }
}
