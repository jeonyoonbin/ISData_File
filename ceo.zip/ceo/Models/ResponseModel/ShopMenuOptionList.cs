﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopMenuOptionList
    {
        public string pkey { get; set; }
        public string ckey { get; set; }
        public string cccode { get; set; }
        public string shop_cd { get; set; }
        public string menu_cd { get; set; }
        public string option_group_cd { get; set; }
        public string option_cd { get; set; }
        public string option_name { get; set; }
        public string option_cost { get; set; }
        public int sort_seq { get; set; }
        public string option_type { get; set; }
        public string req_yn { get; set; }
        public string multi_yn { get; set; }
        public int multi_count { get; set; }
        public int option_count { get; set; }
        public int min_count { get; set; }
    }
}
