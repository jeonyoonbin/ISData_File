﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopItemCodes
    {
        public string item_cd { get; set; }
        public string item_cd2 { get; set; }
        public string item_cd3 { get; set; }
    }
}
