﻿namespace PosWebApp.Models.ResponseModel
{
    public class ShopBizInfo
    {
        public string REG_NO { get; set; }
        /// <summary>
        /// 과세 기준 소유자 ( 사용안함 2021.06.22 reason from 이인찬, 김성근 )
        /// </summary>
        public string BUSS_OWNER { get; set; }
        public string BUSS_CON { get; set; }
        public string BUSS_TYPE { get; set; }
        public string BUSS_ADDR { get; set; }
        public string BUSS_TAX_TYPE { get; set; }
        public string OWNER { get; set; }
        public string EMAIL { get; set; }
        public string[] emails { get; set; } 
    }
}
