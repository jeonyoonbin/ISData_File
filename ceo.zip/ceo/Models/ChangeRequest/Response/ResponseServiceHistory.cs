﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Response
{
    public class ResponseServiceHistory
    {
        public string job_gbn { get; set; }
        public string seq { get; set; }
        public string shop_cd { get; set; }
        public string stauts { get; set; }
        public string stauts_name { get; set; }
        public string service_gbn { set; get; }
        public string service_gbn_name { set; get; }
        public string insert_date { set; get; }
        public string mod_date { get; set; }
        public string answer_text { get; set; }
        public string service_data { set; get; }
        public string file_name { set; get; }
    }
}
