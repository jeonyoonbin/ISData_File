﻿using PosWebApp.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Response
{
    public enum ServiceType
    {
        bizinfo = 100,
        address = 200,
        category = 201,
        deliveryPOS = 202,
        MenuImageIn = 300,
        MenuImageOut = 301,
        Blind = 400
    }
    public class ResponseCommon
    {
        public string hist_seq { get; set; }
        public string seq { get; set; }
        public string shop_cd { get; set; }
        public string status { get; set; }
        public string status_name { get; set; }
        public string service_gbn { set; get; }
        public string service_gbn_name { get; set; }
        public string insert_date { get; set; }
        public string mod_date { set; get; }
        public string answer_text { set; get; }
        public string service_data { set; get; }
        public string file_name { set; get; }
        public ServiceCommon after_data { get; set; } 
        public ServiceCommon before_data { get; set; }
    }
}
