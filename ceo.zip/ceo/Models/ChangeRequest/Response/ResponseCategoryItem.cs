﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Response
{
    public class ResponseCategoryItem
    {
        public string item_cd { get; set; }
        public string item_cd2 { get; set; }
        public string item_cd3 { get; set; }
    }
}
