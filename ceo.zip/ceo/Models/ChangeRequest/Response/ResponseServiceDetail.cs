﻿namespace PosWebApp.Models.ChangeRequest.Response
{
    public class ResponseServiceDetail
    {
        public string kindShopYn { get; set; }
        public string kindShopCancelDt { get; set; }
        public string seq { get; set; }
        public string status { get; set; }
        public string statusName { get; set; }
        public string serviceGbn { get; set; }
        public string btnReqYn { get; set; }
        public string btnReqCancelYn { get; set; }
        public string btnDelYn { get; set; }
        public string btnDelCancelYn { get; set; }
        public string answerText { get; set; }
    }
}
