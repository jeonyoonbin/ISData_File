﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestCategory
    {
        public string a_item_cd { get; set; }
        public string a_item_cd2 { get; set; }
        public string a_item_cd3 { get; set; }

        public string b_item_cd { get; set; }
        public string b_item_cd2 { get; set; }
        public string b_item_cd3 { get; set; }
    }
}
