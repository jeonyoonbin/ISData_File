﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestCancal
    {
        public string type { get; set; }
        public string seq { get; set; }
        public string service { get; set; }
        public string menuCode { get; set; }
    }
}
