﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestServiceTypeCommon
    {
        public string GbnCode { get; set; }
        public string shopCode { get; set; }

    }
}
