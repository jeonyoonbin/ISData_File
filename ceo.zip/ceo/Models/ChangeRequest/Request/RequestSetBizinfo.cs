﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestSetBizinfo
    {
        public RequestSetBizinfo (RequestBizInfo after_bizInfo, RequestBizInfo before_bizinfo)
        {
            // 변경 후
            this.a_buss_addr = after_bizInfo.buss_addr;
            this.a_buss_con = after_bizInfo.buss_con;
            //this.buss_owner = bizInfo.buss_owner;
            this.a_buss_tax_type = after_bizInfo.buss_tax_type;
            this.a_buss_type = after_bizInfo.buss_type;
            this.a_owner = after_bizInfo.owner;
            this.a_reg_no = after_bizInfo.reg_no;
            //변경 전
            this.b_buss_addr = before_bizinfo.buss_addr;
            this.b_buss_con = before_bizinfo.buss_con;
            //this.buss_owner = bizInfo.buss_owner;
            this.b_buss_tax_type = before_bizinfo.buss_tax_type;
            this.b_buss_type = before_bizinfo.buss_type;
            this.b_owner = before_bizinfo.owner;
            this.b_reg_no = before_bizinfo.reg_no;
        }
        public RequestSetBizinfo()
        {

        }
        public string a_reg_no { get; set; } //사업자 등록번호
        public string a_buss_owner { get; set; } //
        public string a_buss_con { get; set; } //업태
        public string a_buss_type { get; set; } //업종
        public string a_buss_addr { get; set; } //사업장 주소
        public string a_buss_tax_type { get; set; } //사업 유형 
        public string a_owner { get; set; } //  대표자명
        public string image_url { get; set; }


        public string b_reg_no { get; set; } //사업자 등록번호
        public string b_buss_owner { get; set; } //
        public string b_buss_con { get; set; } //업태
        public string b_buss_type { get; set; } //업종
        public string b_buss_addr { get; set; } //사업장 주소
        public string b_buss_tax_type { get; set; } //사업 유형 
        public string b_owner { get; set; } //  대표자명

    }
}
