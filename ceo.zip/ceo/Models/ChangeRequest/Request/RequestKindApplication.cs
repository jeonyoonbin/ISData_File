﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestKindApplication
    {
        public string first { get; set; }
        public string second { get; set; }
        public string third { get; set; }
    }
}
