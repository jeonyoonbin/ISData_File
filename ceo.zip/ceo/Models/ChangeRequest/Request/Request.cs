﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class Request
    {
        public string job_gbn { get; set; }
        public int mcode { get; set; }
        public string cccode { get; set; }
        public int shop_cd { get; set; }
        public string status { get; set; }
        public string service_gbn { get; set; }
        public int seq { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }
}
