﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestMenuDel
    {
        public string groupCd { get; set; }
        public string menuCd { get; set; }
        public string menuName { get; set; }
        public string imageName { get; set; }
    }
}
