﻿namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestKindModal
    {
        public string first { get; set; }
        public bool menucost { get; set; }
        public bool deliveryTip { get; set; }
        public bool shopCoupon { get; set; }
        public bool packSale { get; set; }
        public bool dontExist { get; set; }
        public string thrid { get; set; }
    }
}
