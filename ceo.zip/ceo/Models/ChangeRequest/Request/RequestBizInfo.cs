﻿using PosWebApp.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PosWebApp.Models.RequestModel;
using Microsoft.AspNetCore.Http;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestBizInfo : Request
    {
        public string reg_no { get; set; } //사업자 등록번호
        public string buss_owner { get; set; } //
        public string buss_con { get; set; } //업태
        public string buss_type { get; set; } //업종
        public string buss_addr { get; set; } //사업장 주소
        public string buss_tax_type { get; set; } //사업 유형 
        public string owner { get; set; } //  대표자명
        public IFormFile reg_image { get; set; }
    }
}
