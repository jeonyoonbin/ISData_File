﻿using Microsoft.AspNetCore.Http;
using PosWebApp.ViewModels.ChangeRequestHistory.Menu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestMenuIns
    {
        public RequestMenuIns(SetMenuIns viewmodel)
        {
            this.groupCd = viewmodel.groupCd;
            this.menuCd = viewmodel.menuCd;
            this.imageName = viewmodel.imageName;
            this.menuName = viewmodel.menuName;
        }
        public string groupCd { get; set; }
        public string menuCd { get; set; }
        public string imageName { get; set; }
        public string menuName { get; set; }
        public string image_url { get; set; }
        public string afterImageURL { get; set; }
    }
}
