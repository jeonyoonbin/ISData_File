﻿using PosWebApp.ViewModels.ChangeRequestHistory.Address;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestAddress
    {
        public RequestAddress()
        {

        }
        public RequestAddress(AddressViewModel model)
        {
            this.a_roadAdd = model.roadAdd;
            this.a_jibun = model.jibun;
            this.a_detail_address = model.detail_address;
            this.a_lat = model.lat;
            this.a_lon = model.lon;
            this.a_SIDO = model.SIDO;
            this.a_SIGUGUN = model.SIGUGUN;
            this.a_DONGMYUN = model.DONGMYUN;
            this.a_RI = model.RI;
            this.a_ROAD_NAME = model.ROAD_NAME;
            this.a_BUILDING_NUMBER = model.BUILDING_NUMBER;
            this.a_BUILDING_NAME = model.BUILDING_NAME;
            this.a_LAND_NUMBER = model.LAND_NUMBER;
            this.a_POSTAL_CODE = model.POSTAL_CODE;
        }
        public string a_roadAdd { get; set; }
        public string a_jibun { get; set; }
        public string a_detail_address { get; set; }
        public string a_lat { get; set; }
        public string a_lon { get; set; }
        public string a_SIDO { get; set; }
        public string a_SIGUGUN { get; set; }
        public string a_DONGMYUN { get; set; }
        public string a_RI { get; set; }
        public string a_ROAD_NAME { get; set; }
        public string a_BUILDING_NUMBER { get; set; }
        public string a_BUILDING_NAME { get; set; }
        public string a_LAND_NUMBER { get; set; }
        public string a_POSTAL_CODE { get; set; }


        public string b_roadAdd { get; set; }
        public string b_jibun { get; set; }
        public string b_detail_address { get; set; }
        public string b_lat { get; set; }
        public string b_lon { get; set; }
        public string b_SIDO { get; set; }
        public string b_SIGUGUN { get; set; }
        public string b_DONGMYUN { get; set; }
        public string b_RI { get; set; }
        public string b_ROAD_NAME { get; set; }
        public string b_BUILDING_NUMBER { get; set; }
        public string b_BUILDING_NAME { get; set; }
        public string b_LAND_NUMBER { get; set; }
        public string b_POSTAL_CODE { get; set; }

    }
}
