﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestCommon : Request
    {
        public string service_gbn { set; get; }
        public int mod_ucode { set; get; }
        public string mod_name { set; get; }
        public string service_data { set; get; }
        public string existing { get; set; }
        public string file_name { set; get; }
        public string from { get; set; }
        public string to { get; set; }
        public string filter { get; set; }
    }
}
