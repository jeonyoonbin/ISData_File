﻿using PosWebApp.Models.Review.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.ChangeRequest.Request
{
    public class RequestBlindReason : Request
    {
        public string orderNo { get; set; }
        public string visibleGbn { get; set; }
        public string blindCode { get; set; } = "";
        public string blindReason { get; set; }
    }
}
