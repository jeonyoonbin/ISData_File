﻿using PosWebApp.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Charge
{
    public class RequestBodyCharge : Request
    {
        public string order_no { get; set; }
        public string order_date { get; set; }
        public string status { get; set; }
        public string pack_order_yn { get; set; }
        public string from_date { get; set; }
        public string to_date { get; set; }
    }
}
