﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Charge
{
    public class ResponseBodyChargecs
    {
        public string order_no { get; set; }
        public string order_date { get; set; }
        public string status { get; set; }
        public string pack_order_yn { get; set; }
        public string pack_order_yn_name { get; set; }
        public string tot_amt { get; set; }
        public string menu_amt { get; set; }
        public string deli_tip_amt { get; set; }
        public string total_disc_amt { get; set; }
        public string shop_disc_amt { get; set; }
        public string total_fee_amt { get; set; }
        public string app_fee_amt { get; set; }
        public string pg_fee_amt { get; set; }
        public string deli_tot_amt { get; set; }
        public string total_amt { get; set; }
        public string memo { get; set; }
    }
}
