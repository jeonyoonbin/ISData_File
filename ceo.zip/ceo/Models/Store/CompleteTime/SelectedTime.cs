﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Store.CompleteTime
{
    public class SelectedTime
    {
        public List<OrderTime> OrderTime { get; set; }
        public List<OrderTime> PackingTime { get; set; }
    }
    public class OrderTime
    {
        public bool Selected { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
    }
    public class PackingTime
    {
        public bool Selected { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
    }

}
