﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Store
{
    public class IntroImage
    {
        public string type { get; set; }
        public IFormFile iFile { get; set; }
    }
}
