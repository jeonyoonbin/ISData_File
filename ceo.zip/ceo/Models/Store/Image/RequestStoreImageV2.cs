﻿namespace PosWebApp.Models.Store.Image
{
    public class RequestStoreImageV2
    {
        public string div { get; set; }
        public string seqno { get; set; }
        public string intro_cd { get; set; }
        public string sort { get; set; }
        public string shop_cd { get; set; }
        public string image_gbn { get; set; }
        public string ucode { get; set; }
        public string uname { get; set; }
    }
}
