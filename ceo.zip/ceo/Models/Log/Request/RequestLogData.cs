﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Log.Request
{
    public class RequestLogData
    {
        public string logType { get; set; } = "logData";         // "loginData" 값넣어서
        public string name { get; set; }   // 디바이스 정보 또는 IP 정보
        public string version { get; set; }     // app version or curr version
        public string os { get; set; }  // app os or server os
        public string type { get; set; }   // APP, Server, Pos 구분 값
        public string subType { get; set; }     // 상세 구분값
        public string errorLevel { get; set; }  // Debug, ERROR, INFO,
        public string errorCode { get; set; }   // 오류 코드
        public string errorMessage { get; set; }        // 오류 메시지
        public string methodName { get; set; }   // 메소드 이름
        public string subMethodNam { get; set; }    // 서브 메소드 이름 
        public string paramData { get; set; }   // 파리미터 값
        public string dbPackage { get; set; }   // DB 패키지명
        public string status { get; set; }  // 상태 값
        public string returnData { get; set; }  // 
        public string comment { get; set; }// 비고
        public long date { get; set; }		// 발생 시간
    }
}
