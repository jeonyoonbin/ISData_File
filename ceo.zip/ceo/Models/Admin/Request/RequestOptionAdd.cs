﻿using System.Collections.Generic;

namespace PosWebApp.Models.Admin.Request
{
    public class RequestOptionAdd
    {
        public string job_gbn { get; set; }
        public string shopCd { get; set; }
        public string optionGroupCd { get; set; }
        public string optionCd { get; set; }
        public string optionName { get; set; }
        public string optionMemo { get; set; }
        public string cost { get; set; }
        public string useYn { get; set; }
        public string insertName { get; set; }
        public string noFlag { get; set; }
        public string adultOnly { get; set; }
    }
    public class RequestOptionList
    {
        public List<RequestOptionAdd> option_list { get; set; }
    }
}
