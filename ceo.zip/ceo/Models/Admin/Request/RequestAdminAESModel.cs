﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Admin.Request
{
    public class RequestAdminAESModel
    {
        public string uCode { get; set; }
        public string uName { get; set; }
        public string jobName { get; set; }
        public string shopCd { get; set; }
    }
}
