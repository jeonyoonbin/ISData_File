﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Admin.Request
{
    public class RequestOptionGroupUpdate
    {
        public string ShopCd { get; set; }
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string optionGroupMemo { get; set; }
        public string useYn { get; set; }
        public string insertName { get; set; }

    }
}
