﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Admin.Response
{
    public class ResponseMenuInfo
    {
        public string menuCd { get; set; }
        public string menuName { get; set; }
        public string menuGroupCd { get; set; }
        public string menuCost { get; set; }
        public string menuDesc { get; set; }
        public string useYn { get; set; }
        public string aloneOrder { get; set; }
        public string mainYn { get; set; }
        public string noFlag { get; set; }
        public string adultOnly { get; set; }
    }
}
