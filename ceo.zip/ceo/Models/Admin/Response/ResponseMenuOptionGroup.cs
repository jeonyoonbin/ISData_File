﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Admin.Response
{
    public class ResponseMenuOptionGroup
    {
        public string menuOptionGroupCd { get; set; }
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string optionNames { get; set; }
    }
}
