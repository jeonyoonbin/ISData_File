﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Admin.Response
{
    public class ResponseMenuList
    {
        public string menuCd { get; set; }
        public string name { get; set; }
        public string cost { get; set; }
        public string fileName { get; set; }
        public string aloneOrderYn { get; set; }
        public string mainMenuYn { get; set; }
        public string noFlag { get; set; }
        public string useGbn { get; set; }
        public string adultOnly { get; set; }
    }
}
