﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Admin.Response
{
    public class ResponseOptionList
    {
        public string cost { get; set; }
        public string fileName { get; set; }
        public string memo { get; set; }
        public string name { get; set; }
        public string optionCd { get; set; }
        public string useYn { get; set; }
        public string noFlag { get; set; }
    }
}
