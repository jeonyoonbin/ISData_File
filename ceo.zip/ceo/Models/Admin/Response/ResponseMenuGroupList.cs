﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Admin.Response
{
    public class ResponseMenuGroupList
    {
        public string menuGroupCd { get; set; }
        public string menuGroupName { get; set; }
        public string menuNames { get; set; }
    }
}