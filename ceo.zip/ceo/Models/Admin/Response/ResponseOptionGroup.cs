﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Models.Admin.Response
{
    public class ResponseOptionGroup
    {
        public string selected { get; set; }
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string optionNames { get; set; }
        public string minCount { get; set; }
        public string maxCount { get; set; }
        public string multiYn { get; set; }
    }
}
