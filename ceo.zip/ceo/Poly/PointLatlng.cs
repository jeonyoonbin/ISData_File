﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Poly
{
    public class PointLatlng
    {
        public PointLatlng(double y, double x)
        {
            this.y_start = y;
            this.x_start = x;
        }
        public double y_start { get; set; }
        public double x_start { get; set; }
    }
}
