'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "assets/AssetManifest.json": "707ccd50878215848942372942af0650",
"assets/assets/fonts/NotoSansKR-Regular.otf": "913f146b0200b19b17eb4de8b4427a9c",
"assets/assets/fonts/Roboto-Regular.otf": "4d3ab24dfb54485f2fcdd3950768b661",
"assets/assets/images/btn_menu.png": "918ccd37462c373e70439e8345fed9c0",
"assets/assets/images/btn_search_main.png": "53d8dcc34450874f352d0d316913991a",
"assets/assets/images/emptymenu.png": "d11e8b5488486811419a6487f61f9a97",
"assets/assets/images/ic_calendar.png": "934466f197be6c58a1346924271b5fbe",
"assets/assets/images/ic_calendar@2x.png": "97a266bba1d37f6c9dcf580811a5793d",
"assets/assets/images/ic_coupon_menu.png": "180ad54a3bb06b00902665075d4b2b5b",
"assets/assets/images/ic_coupon_menu@2x.png": "d8d7dbd65240cbcc672973c5b793621c",
"assets/assets/images/ic_coupon_menu_on.png": "eed10b258bd154e5dbb3b47d348fbd73",
"assets/assets/images/ic_coupon_menu_on@2x.png": "4bd31e9b25aa8540ebd1ebcea99375b1",
"assets/assets/images/ic_gallery.png": "fac6ccf88d08addb511fb22b621c2b09",
"assets/assets/images/ic_home_menu@2x.png": "778c64adc2e271ae0cd3307023b60408",
"assets/assets/images/ic_home_menu_on@2x.png": "09a951ba67e856bb8c47a4ccfb771a7d",
"assets/assets/images/ic_ios_share.png": "98d5f092caaf12696a8727eda15add88",
"assets/assets/images/ic_notice_menu.png": "6ccda9995d5160ed3b6c68a007b8c2a5",
"assets/assets/images/ic_notice_menu@2x.png": "4bf10e14b3d0ba79f915ddf3d95df982",
"assets/assets/images/ic_notice_menu_on.png": "2c0d111033781416e7e12dc046311c89",
"assets/assets/images/ic_notice_menu_on2@2x.png": "fbf80832bf48fe3eb1cf5ae9aaf0986d",
"assets/assets/images/ic_notice_menu_on@2x.png": "3dc4cdd5c59df4dd7f83fda6be10508a",
"assets/assets/images/ic_post_add_menu@2x.png": "0905f506c582d5f4cc688beb81124376",
"assets/assets/images/ic_post_add_menu_on@2x.png": "daa67ef9b43069bb51bbe6e2c45fd20e",
"assets/assets/images/ic_search.png": "1053b2983dd5945ec6a1965c34269ac1",
"assets/assets/images/ic_search@2x.png": "803ef4e8ed9e66422dd1cc7522bbfae4",
"assets/assets/images/ic_statistics_menu.png": "1e1decfec5f1be75caac608e54384df0",
"assets/assets/images/ic_statistics_menu@2x.png": "204d93ac4a20629068ccccd339c92844",
"assets/assets/images/ic_statistics_menu_on.png": "8fb87b91b0995d9df8870563311b4b79",
"assets/assets/images/ic_statistics_menu_on@2x.png": "7441ad6e78c6990127e2c312d2a6227b",
"assets/assets/images/ic_store_menu.png": "301344a8bd090e0a9947f14c181e7a0d",
"assets/assets/images/ic_store_menu@2x.png": "8bf41d9739026c856fb919ce79e4eacd",
"assets/assets/images/ic_store_menu_on.png": "26033c67862e5eaea2dcd355b9b81e4b",
"assets/assets/images/ic_store_menu_on2@2x.png": "875feb261b817dbdaf51db449d6b36a4",
"assets/assets/images/ic_store_menu_on@2x.png": "37c186d704bbdc8667f57e735166b7c0",
"assets/assets/images/logo_daeguro.png": "d8619bb280c0cfd1d4df7b8efcc91b25",
"assets/assets/images/order_tab_on@2x.png": "2b750f589956b2985839117ee74f27a2",
"assets/assets/images/reservation_tab_off@2x.png": "04134fc9fe984a4b319348bcd76b25d1",
"assets/FontManifest.json": "7f06028eabf0a23fe865f6549b0b1cf1",
"assets/fonts/MaterialIcons-Regular.otf": "95db9098c58fd6db106f1116bae85a0b",
"assets/NOTICES": "1e39387607ca470c50afc19ee7205104",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/packages/syncfusion_flutter_datagrid/assets/font/FilterIcon.ttf": "c17d858d09fb1c596ef0adbf08872086",
"assets/packages/syncfusion_flutter_datagrid/assets/font/UnsortIcon.ttf": "6d8ab59254a120b76bf53f167e809470",
"assets/shaders/ink_sparkle.frag": "0dd5134e4b18961376f9d82c0bf183a1",
"canvaskit/canvaskit.js": "2bc454a691c631b07a9307ac4ca47797",
"canvaskit/canvaskit.wasm": "bf50631470eb967688cca13ee181af62",
"canvaskit/profiling/canvaskit.js": "38164e5a72bdad0faa4ce740c9b8e564",
"canvaskit/profiling/canvaskit.wasm": "95a45378b69e77af5ed2bc72b2209b94",
"favicon.png": "3ab748149e25c1a0d9719c85d5d41603",
"faviconbak.png": "5dcef449791fa27946b3d35ad8803796",
"flutter.js": "f85e6fb278b0fd20c349186fb46ae36d",
"icons/Icon-192.png": "aab717dcaecf3304c59789e9c89a15eb",
"icons/Icon-192bak.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "5483c0574f60a5e02141cc31dc993c2e",
"icons/Icon-512bak.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-maskable-192.png": "aab717dcaecf3304c59789e9c89a15eb",
"icons/Icon-maskable-192bak.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "5483c0574f60a5e02141cc31dc993c2e",
"icons/Icon-maskable-512bak.png": "301a7604d45b3e739efc881eb04896ea",
"index.html": "42f847b7952d0cd6008470ea89a0ddbc",
"/": "42f847b7952d0cd6008470ea89a0ddbc",
"main.dart.js": "6f53403bcf2999b99fe4fe844b3b13c5",
"manifest.json": "cd1c013b316281f7e02aefad700c5749",
"splash/splash.js": "d6c41ac4d1fdd6c1bbe210f325a84ad4",
"splash/style.css": "4c3e6a90c58d749ca7ba05aa03948cdb",
"version.json": "0836e3d252cfa20b9c8eb3fae0f708a2"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "main.dart.js",
"index.html",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
