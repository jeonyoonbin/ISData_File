﻿using DG_App_Rest.Common;
using DG_App_Rest.Areas.Admin.Models;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.IO;
using ImageProcessor;
using ImageProcessor.Imaging.Formats;
using System.Drawing;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class TemaController : ControllerBase
    {
        /// <summary>
        /// Items(카테고리) 조회 (메인테마)
        /// </summary>
        /// <remarks>
        /// Items(카테고리) 조회 (메인테마)<br />
        /// thema_use_yn(테마사용여부)가 Y인 ITEM만 조회<br />
        /// <br />
        /// <br />
        /// [결과 값] <br />
        /// code : ITEM CODE <br />
        /// nameMain : ITEM NAME <br />
        /// sortSeq : 정렬순서<br />
        /// </remarks>
        #region [메인테마 목록 조회]
        [HttpGet("tema")]
        public async Task<IActionResult> Get_List()
        {
            List<ItemList> items = new List<ItemList>();

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.ITEM_CODE_LIST"
            };

            cmd.Parameters.Add(new OracleParameter("in_thema_use_yn", OracleDbType.Varchar2)).Value = "Y";

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 2000)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (rd.Read())
                {
                    ItemList i = new ItemList
                    {
                        code = rd["ITEM_CD"].ToString(),
                        nameMain = rd["ITEM_NAME"].ToString(),
                        name = rd["ITEM_DESC"].ToString(),
                        sortSeq = String.IsNullOrEmpty(rd["SORT_SEQ"].ToString()) ? 0 : Convert.ToInt32(rd["SORT_SEQ"].ToString())
                    };

                    items.Add(i);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/tema : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                data = items.Select(m => new
                {
                    m.code,
                    m.nameMain,
                    m.sortSeq
                })
            });
        }
        #endregion

        /* 메인테마 상세조회, 생성, 수정, 삭제 미사용
        /// <summary>
        /// 메인테마 한건 조회
        /// </summary>
        /// <remarks>
        /// 메인테마 한건 조회 <br />
        /// <br />
        /// [결과 값] <br />
        /// code : ITEM CODE <br />
        /// nameMain : ITEM NAME <br />
        /// name : ITEM NAME, ITEM DESC<br />
        /// url : 이미지 url<br />
        /// sortSeq : 정렬순서<br />
        /// useGbn : 사용유무(Y/N)<br />
        /// mainVisibleGbn : 앱메인화면 표기여부(Y/N)<br />
        /// gunguUseGbn : 군구사용여부(Y/N)<br />
        /// memo : 메모<br />
        /// </remarks>
        /// <param name="temaCode">메인테마코드</param>
        /// <returns></returns>
        #region [메인테마 한건 조회]
        [HttpGet("temaDetail")]
        public async Task<IActionResult> GetOne(string temaCode)
        {
            List<ItemList> items = new List<ItemList>();

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_RESER_TEMA.ITEM_CODE_LIST"
            };

            cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "2";
            cmd.Parameters.Add(new OracleParameter("in_item", OracleDbType.Varchar2)).Value = "0004";
            cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = temaCode;
            cmd.Parameters.Add(new OracleParameter("in_use_gbn", OracleDbType.Varchar2)).Value = string.Empty;

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("fetch_data", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (rd.Read())
                {
                    ItemList i = new ItemList
                    {
                        code = rd["ITEM_CD"].ToString(),
                        nameMain = rd["ITEM_NAME"].ToString(),
                        name = rd["ITEM_DESC"].ToString(),
                        url = rd["ITEM_URL"].ToString(),
                        sortSeq = String.IsNullOrEmpty(rd["SORT_SEQ"].ToString()) ? 0 : Convert.ToInt32(rd["SORT_SEQ"].ToString()),
                        useGbn = rd["USE_GBN"].ToString(),
                        mainVisibleGbn = rd["MAIN_VISIBLE_GBN"].ToString(),
                        gunguUseGbn = rd["GUNGU_USE_GBN"].ToString(),
                        memo = rd["MEMO"].ToString()
                    };

                    items.Add(i);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                data = items
            });
        }
        #endregion

        /// <summary>
        /// 메인테마 추가
        /// </summary>
        /// <remarks>
        /// 메인테마 추가<br />
        /// <br />
        /// [입력값]<br />
        /// temaName : 메인테마이름(40 Byte)<br />
        /// userId : 등록자(작업자) ID (40 Byte)<br />
        /// <br />
        /// [결과값]<br />
        /// temaCode : 메인테마코드<br />
        /// <br />
        /// </remarks>
        /// <param name="temaName">메인테마이름</param>
        /// <param name="userId">등록자(작업자)ID </param>
        /// <returns></returns>
        #region [메인테마 추가]
        [HttpPost("tema")]
        public async Task<IActionResult> Post(string temaName, string userId)
        {
            ItemList items = new ItemList();

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_RESER_TEMA.INSERT_RESER_MAIN_TEMA"
            };

            cmd.Parameters.Add(new OracleParameter("in_item_name", OracleDbType.Varchar2)).Value = temaName;
            cmd.Parameters.Add(new OracleParameter("in_user_id", OracleDbType.Varchar2)).Value = userId;

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();


                while (rd.Read())
                {
                    ItemList i = new ItemList
                    {
                        code = rd["ITEM_CD"].ToString(),
                        nameMain = rd["ITEM_NAME"].ToString()
                    };

                    items = i;
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                temaCode = items.code
            });
        }
        #endregion

        /// <summary>
        /// 메인테마 수정
        /// </summary>
        /// <remarks>
        /// 메인테마 수정<br />
        /// <br />
        /// [입력값]- 입력한 값만 수정됨<br />
        /// <br />
        /// mainName : 메인테마이름 (40 Byte) <br />
        ///            => 앱에서 메인 화면에서 이 명칭이 노출됨 <br />
        /// name : 설명 및 메인테마이름2 (4000 Byte)<br />
        ///            => 앱에서 메인 화면 외에 명칭리스트에서 해당 명칭이 노출됨<br />
        /// useGbn : 사용여부(Y/N) (1 Byte)<br />
        /// mainVisibleGbn : 앱메인화면표기여부(Y/N) (1 Byte)<br />
        /// gunguUseGbn : 군구사용여부(Y/N) (1 Byte) <br />
        /// memo : 메모 (4000 Byte)<br />
        /// </remarks>
        /// <param name="temaCode">메인테마코드</param>
        /// <param name="userId">수정자(작업자) ID (40 Byte)</param>
        /// <returns></returns>
        #region [메인테마 수정]
        [HttpPut("tema")]
        public async Task<IActionResult> Put(string temaCode, string userId, MainTemaPost mainTema)
        {

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_RESER_TEMA.UPDATE_RESER_MAIN_TEMA"
            };

            cmd.Parameters.Add(new OracleParameter("in_item", OracleDbType.Varchar2)).Value = "0004";
            cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = temaCode;
            cmd.Parameters.Add(new OracleParameter("in_item_name", OracleDbType.Varchar2)).Value = mainTema.mainName;
            cmd.Parameters.Add(new OracleParameter("in_item_desc", OracleDbType.Varchar2)).Value = mainTema.name;
            cmd.Parameters.Add(new OracleParameter("in_use_gbn", OracleDbType.Varchar2)).Value = mainTema.useGbn;
            cmd.Parameters.Add(new OracleParameter("in_main_visible_gbn", OracleDbType.Varchar2)).Value = mainTema.mainVisibleGbn;
            cmd.Parameters.Add(new OracleParameter("in_gungu_use_gbn", OracleDbType.Varchar2)).Value = mainTema.gunguUseGbn;
            cmd.Parameters.Add(new OracleParameter("in_user_id", OracleDbType.Varchar2)).Value = userId;
            cmd.Parameters.Add(new OracleParameter("in_memo", OracleDbType.Varchar2)).Value = mainTema.memo;

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg
            });
        }
        #endregion

        /// <summary>
        /// 메인테마 삭제
        /// </summary>
        /// <remarks>
        /// 메인테마 삭제<br />
        /// <br />
        /// </remarks>
        /// <param name="temaCode">메인테마코드</param>
        /// <returns></returns>
        #region [메인테마 삭제]
        [HttpDelete("tema")]
        public async Task<IActionResult> temaDelete(string temaCode)
        {

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_RESER_TEMA.DELETE_RESER_MAIN_TEMA"
            };

            cmd.Parameters.Add(new OracleParameter("in_item", OracleDbType.Varchar2)).Value = "0004";
            cmd.Parameters.Add(new OracleParameter("in_item_cd", OracleDbType.Varchar2)).Value = temaCode;

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg
            });
        }
        #endregion
        */

        /// <summary>
        /// 서브테마 목록 조회
        /// </summary>
        /// <remarks>
        /// 서브테마 목록 조회 <br />
        /// <br />
        /// [결과 값] <br />        
        /// temaCode : 메인테마코드<br />
        /// subtemaCode : 서브테마코드<br />
        /// temaName :서브테마이름<br />
        /// gungu : 군구명<br />
        /// useGbn : 사용여부(Y/N) <br />
        /// testYn : 테스트여부(Y/N) <br />
        /// sortSeq : 순서<br />
        /// </remarks>
        /// <param name="temaCode">메인테마코드(NOT NULL)</param>
        /// <param name="sido">시도명</param>
        /// <param name="gungu">군구명</param>
        /// <param name="useGbn">사용여부(Y/N)</param>
        /// <param name="testYn">테스트여부(Y/N)</param>
        /// <returns></returns>
        #region [서브테마 목록 조회]
        [HttpGet("subTema")]
        public async Task<IActionResult> getSubTema(string temaCode, string sido, string gungu, string useGbn, string testYn)
        {
            List<SubTema> items = new List<SubTema>();

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.GET_SUB_TEMA_LIST"
            };

            cmd.Parameters.Add(new OracleParameter("in_tema_code", OracleDbType.Varchar2)).Value = temaCode;
            cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = sido;
            cmd.Parameters.Add(new OracleParameter("in_gungu", OracleDbType.Varchar2)).Value = gungu;
            cmd.Parameters.Add(new OracleParameter("in_use_gbn", OracleDbType.Varchar2)).Value = useGbn;
            cmd.Parameters.Add(new OracleParameter("in_test_yn", OracleDbType.Varchar2)).Value = testYn;

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 2000)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (rd.Read())
                {
                    SubTema i = new SubTema
                    {
                        temaCode = rd["ITEM_CD"].ToString(),
                        subTemaCode = rd["THEMA_CD"].ToString(),
                        temaName = rd["THEMA_NAME"].ToString(),
                        sido = rd["SIDO"].ToString(),
                        gungu = rd["GUNGU"].ToString(),
                        temaMemo = rd["THEMA_MEMO"].ToString(),
                        useGbn = rd["USE_GBN"].ToString(),
                        testYn = rd["TEST_YN"].ToString(),
                        sortSeq = String.IsNullOrEmpty(rd["SORT_SEQ"].ToString()) ? 0 : Convert.ToInt32(rd["SORT_SEQ"].ToString()),
                        url = rd["FILE_IMG"].ToString(),
                        //lon = String.IsNullOrEmpty(rd["LON"].ToString()) ? 0 : Convert.ToDouble(rd["LON"].ToString()),
                        //lat = String.IsNullOrEmpty(rd["LAT"].ToString()) ? 0 : Convert.ToDouble(rd["LAT"].ToString()),
                        addr = rd["ADDR"].ToString()
                    };

                    items.Add(i);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/subTema : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                data = items.Select(m => new
                {
                    m.temaCode,
                    m.subTemaCode,
                    m.temaName,
                    m.gungu,
                    m.sortSeq,
                    m.useGbn
                })
            });
        }
        #endregion

        /// <summary>
        /// 서브테마 한건 조회
        /// </summary>
        /// <remarks>
        /// 서브테마 한건 조회 <br />
        /// <br />
        /// [결과 값] <br />        
        /// temaCode : 메인테마코드<br />
        /// subtemaCode : 서브테마코드<br />
        /// temaName :서브테마이름<br />
        /// sido : 시도명<br />
        /// gungu : 군구명<br />
        /// temaMemo : 서브테마설명<br />
        /// useGbn : 사용여부(Y/N) <br />
        /// openYn : 영업여부(Y/N) <br />
        /// testYn : 테스트여부(Y/N) <br />
        /// sortSeq : 순서<br />
        /// url :사진이미지경로<br />
        /// lon, lat : 위치좌표<br />
        /// addr : 주소 <br />
        /// memo : 메모 <br />
        /// </remarks>
        /// <param name="temaCode">메인테마코드</param>
        /// <param name="subTemaCode">서브테마코드</param>
        /// <returns></returns>
        #region [서브테마 한건 조회]
        [HttpGet("subTemaDetail")]
        public async Task<IActionResult> GetSubTemaDetail(string temaCode, string subTemaCode)
        {
            List<SubTema> items = new List<SubTema>();

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.GET_SUB_TEMA_DETAIL"
            };

            cmd.Parameters.Add(new OracleParameter("in_tema_code", OracleDbType.Varchar2)).Value = temaCode;
            cmd.Parameters.Add(new OracleParameter("in_sub_tema_code", OracleDbType.Varchar2,5)).Value = subTemaCode;

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (rd.Read())
                {
                    SubTema i = new SubTema
                    {
                        temaCode = rd["ITEM_CD"].ToString(),
                        subTemaCode = rd["THEMA_CD"].ToString(),
                        temaName = rd["THEMA_NAME"].ToString(),
                        sido = rd["SIDO"].ToString(),
                        gungu = rd["GUNGU"].ToString(),
                        temaMemo = rd["THEMA_MEMO"].ToString(),
                        useGbn = rd["USE_GBN"].ToString(),
                        openYn = rd["OPEN_YN"].ToString(),
                        testYn = rd["TEST_YN"].ToString(),
                        sortSeq = String.IsNullOrEmpty(rd["SORT_SEQ"].ToString()) ? 0 : Convert.ToInt32(rd["SORT_SEQ"].ToString()),
                        url = rd["FILE_IMG"].ToString(),
                        lon = rd["LON"].ToString(),
                        lat = rd["LAT"].ToString(),
                        addr = rd["ADDR"].ToString(),
                        memo = rd["MEMO"].ToString()
                    };

                    items.Add(i);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/subTemaDetail : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                data = items
            });
        }
        #endregion

        /// <summary>
        /// 서브테마에 등록된 가맹점 목록 조회
        /// </summary>
        /// <remarks>
        /// 서브테마에 등록된 가맹점 목록 조회 <br />
        /// <br />
        /// [전체조회] => jobGbn : 1 , searchInfo : 입력하지 않고 조회<br />
        /// [jobGbn] 1: 가맹점명, 3: 주소 => LIKE 검색<br />
        ///          2: 사업자번호 => 일치하는 사업자번호 검색<br />
        /// <br />
        /// [결과 값] <br />
        /// shopName : 가맹점명<br />
        /// shopCd : 상점코드<br />
        /// regNo :사업자번호<br />
        /// addr1 :구주소<br />
        /// addr2 :신주소<br />
        /// </remarks>
        /// <param name="jobGbn">1: 가맹점명 2: 사업자번호 3: 주소로 검색</param>
        /// <param name="subTemaCode">서브테마코드</param>
        /// <param name="searchInfo">검색할정보</param>
        /// <param name="page">조회할페이지</param>
        /// <param name="rows">한페이지 데이터수</param>
        /// <returns></returns>
        #region [서브테마에 등록된 가맹점 목록 조회]
        [HttpGet("temaShopList")]
        public async Task<IActionResult> GetTemaShopList(string jobGbn, string subTemaCode, string searchInfo, int page, int rows)
        {
            List<SubTemaShopList> items = new List<SubTemaShopList>();

            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            int Rcount = 0;


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.GET_SUB_TEMA_SHOP_LIST"
            };

            cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = jobGbn;
            cmd.Parameters.Add(new OracleParameter("in_sub_tema_code", OracleDbType.Varchar2, 5)).Value = subTemaCode;
            cmd.Parameters.Add(new OracleParameter("in_shop_search_info", OracleDbType.Varchar2)).Value = searchInfo;
            cmd.Parameters.Add(new OracleParameter("in_page", OracleDbType.Int32)).Value = page;
            cmd.Parameters.Add(new OracleParameter("in_rows", OracleDbType.Int32)).Value = rows;

            cmd.Parameters.Add(new OracleParameter("out_count", OracleDbType.Int32)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();
                Rcount = Convert.ToInt32(cmd.Parameters["out_count"].Value.ToString());

                while (rd.Read())
                {
                    SubTemaShopList i = new SubTemaShopList
                    {
                        shopName = rd["SHOP_NAME"].ToString(),
                        shopCd = rd["SHOP_CD"].ToString(),
                        regNo = rd["REG_NO"].ToString(),
                        addr1 = rd["ADDR1"].ToString(),
                        addr2 = rd["ADDR2"].ToString()
                    };

                    items.Add(i);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/temaShopList : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                count = Rcount,
                data = items
            });
        }
        #endregion


        /// <summary>
        /// 서브테마에 등록가능한 가맹점 목록 조회
        /// </summary>
        /// <remarks>
        /// 서브테마에 등록가능한 가맹점 목록 조회 <br />
        /// <br />
        /// * 서브테마에만 가맹점 등록 가능 <br />
        /// [결과 값] <br />
        /// shopName : 가맹점명<br />
        /// shopCd : 상점코드<br />
        /// regNo :사업자번호<br />
        /// addr1 :구주소<br />
        /// addr2 :신주소<br />
        /// </remarks>
        /// <param name="jobGbn">1: 가맹점명 2: 사업자번호 3: 주소로 검색</param>
        /// <param name="temaCode">메인테마코드(EX. 1033 : 전통시장)</param>
        /// <param name="searchInfo">검색할정보</param>
        /// <param name="page">조회할페이지</param>
        /// <param name="rows">한페이지 데이터수</param>
        /// <returns></returns>
        #region [서브테마에 등록가능한 가맹점 목록 조회]
        [HttpGet("temaEnable")]
        public async Task<IActionResult> GetTemaEnable(string jobGbn, string temaCode, string searchInfo, int page, int rows)
        {
            List<SubTemaShopList> items = new List<SubTemaShopList>();

            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            int Rcount = 0;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.GET_SHOP_LIST"
            };

            cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = jobGbn;
            cmd.Parameters.Add(new OracleParameter("in_tema_code", OracleDbType.Varchar2)).Value = temaCode;
            cmd.Parameters.Add(new OracleParameter("in_shop_search_info", OracleDbType.Varchar2)).Value = searchInfo;
            cmd.Parameters.Add(new OracleParameter("in_mcode", OracleDbType.Int32)).Value = 0;
            cmd.Parameters.Add(new OracleParameter("in_page", OracleDbType.Int32)).Value = page;
            cmd.Parameters.Add(new OracleParameter("in_rows", OracleDbType.Int32)).Value = rows;

            cmd.Parameters.Add(new OracleParameter("out_count", OracleDbType.Int32)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();
                Rcount = Convert.ToInt32(cmd.Parameters["out_count"].Value.ToString());

                while (rd.Read())
                {
                    SubTemaShopList i = new SubTemaShopList
                    {
                        shopName = rd["SHOP_NAME"].ToString(),
                        shopCd = rd["SHOP_CD"].ToString(),
                        regNo = rd["REG_NO"].ToString(),
                        addr1 = rd["ADDR1"].ToString(),
                        addr2 = rd["ADDR2"].ToString()
                    };

                    items.Add(i);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/temaEnable : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                count = Rcount,
                data = items
            });
        }
        #endregion

        /// <summary>
        /// 서브테마 추가
        /// </summary>
        /// <remarks>
        /// 서브테마 추가<br />
        /// => 서브테마 이름
        /// <br />
        /// [입력값]<br />
        /// temaName : 서브테마이름(50 Byte)<br />
        /// ucode : 작업자 코드 <br />
        /// <br />
        /// [결과값]<br />
        /// temaCode : 메인테마코드<br />
        /// subTemaCode : 등록된 서브테마코드<br />
        /// <br />
        /// </remarks>
        /// <param name="temaCode">메인테마코드</param>
        /// <param name="temaName">서브테마이름</param>
        /// <param name="ucode">작업자 코드 </param>
        /// <param name="testYn">테스트 여부 </param>
        /// <returns></returns>
        #region [서브테마 추가]
        [HttpPost("subTema")]
        public async Task<IActionResult> setSubTema(string temaCode, string temaName, string ucode, string testYn)
        {
            SubTema items = new SubTema();

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.INSERT_SUB_TEMA"
            };

            cmd.Parameters.Add(new OracleParameter("in_main_tema_code", OracleDbType.Varchar2)).Value = temaCode;
            cmd.Parameters.Add(new OracleParameter("in_tema_name", OracleDbType.Varchar2)).Value = temaName;
            cmd.Parameters.Add(new OracleParameter("in_user_id", OracleDbType.Varchar2)).Value = ucode;
            cmd.Parameters.Add(new OracleParameter("in_test_yn", OracleDbType.Varchar2)).Value = testYn;

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();


                while (rd.Read())
                {
                    SubTema i = new SubTema
                    {
                        temaCode = rd["ITEM_CD"].ToString(),
                        subTemaCode = rd["THEMA_CD"].ToString(),                       
                    };

                    items = i;
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/subTema : Post", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                temaCode = items.temaCode,
                subTemaCode = items.subTemaCode
            });
        }
        #endregion

        /// <summary>
        /// 서브테마 수정
        /// </summary>
        /// <remarks>
        /// 서브테마 수정<br />
        /// <br />
        /// [입력값] <br />
        /// <br />
        /// temaName : 서브테마이름(50 Byte) <br />        
        /// sido : 시도명 (20 Byte)<br />
        /// gungu : 군구명 (20 Byte)<br />
        /// temaMemo : 서브테마설명 (4000 Byte)<br />
        /// useGbn : 사용여부(Y/N) (1 Byte) <br />
        /// openYn : 영업여부(Y/N) (1 Byte) <br />
        /// testYn : 테스트여부(Y/N) (1 Byte) <br />
        /// lon, lat : 위치좌표<br />
        /// addr : 주소 (200 Byte) <br />
        /// memo : 메모 (2000 Byte)<br />
        /// <br />
        /// </remarks>
        /// <param name="subTemaCode">서브테마코드</param>
        /// <param name="temaCode">메인테마코드</param>
        /// <param name="ucode">수정자 코드 </param>
        /// <returns></returns>
        #region [서브테마 수정]
        [HttpPut("subTema")]
        public async Task<IActionResult> updateSubTema(string subTemaCode, string temaCode, string ucode, SubTemaPost subTema)
        {

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.UPDATE_SUB_TEMA"
            };

            cmd.Parameters.Add(new OracleParameter("in_tema_code", OracleDbType.Varchar2)).Value = subTemaCode;
            cmd.Parameters.Add(new OracleParameter("in_main_tema_code", OracleDbType.Varchar2)).Value = temaCode;
            cmd.Parameters.Add(new OracleParameter("in_tema_name", OracleDbType.Varchar2)).Value = subTema.temaName;
            cmd.Parameters.Add(new OracleParameter("in_sido", OracleDbType.Varchar2)).Value = subTema.sido;
            cmd.Parameters.Add(new OracleParameter("in_gungu", OracleDbType.Varchar2)).Value = subTema.gungu;
            cmd.Parameters.Add(new OracleParameter("in_tema_memo", OracleDbType.Varchar2)).Value = subTema.temaMemo;
            cmd.Parameters.Add(new OracleParameter("in_use_gbn", OracleDbType.Varchar2)).Value = subTema.useGbn;
            cmd.Parameters.Add(new OracleParameter("in_open_yn", OracleDbType.Varchar2)).Value = subTema.openYn;
            cmd.Parameters.Add(new OracleParameter("in_test_yn", OracleDbType.Varchar2)).Value = subTema.testYn;
            cmd.Parameters.Add(new OracleParameter("in_lon", OracleDbType.Varchar2)).Value = subTema.lon;
            cmd.Parameters.Add(new OracleParameter("in_lat", OracleDbType.Varchar2)).Value = subTema.lat;
            cmd.Parameters.Add(new OracleParameter("in_addr", OracleDbType.Varchar2)).Value = subTema.addr;
            cmd.Parameters.Add(new OracleParameter("in_user_id", OracleDbType.Varchar2)).Value = ucode;
            cmd.Parameters.Add(new OracleParameter("in_meno", OracleDbType.Varchar2)).Value = subTema.memo;

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/subTema : Put", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg
            });
        }
        #endregion

        /// <summary>
        /// 서브테마 삭제
        /// </summary>
        /// <remarks>
        /// 서브테마 삭제<br />
        /// <br /> 
        /// </remarks>
        /// <param name="subTemaCode">서브테마코드</param>
        /// <param name="temaCode">메인테마코드</param>
        /// <param name="ucode">작업자 코드</param>
        /// <returns></returns>
        #region [서브테마 삭제]
        [HttpDelete("subTema")]
        public async Task<IActionResult> subTemaDelete(string subTemaCode, string temaCode, string ucode)
        {

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.DELETE_SUB_TEMA"
            };

            cmd.Parameters.Add(new OracleParameter("in_tema_code", OracleDbType.Varchar2,5)).Value = subTemaCode;
            cmd.Parameters.Add(new OracleParameter("in_main_tema_code", OracleDbType.Varchar2)).Value = temaCode;
            cmd.Parameters.Add(new OracleParameter("in_user_id", OracleDbType.Varchar2)).Value = ucode;

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/subTema : Delete", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg
            });
        }
        #endregion



        /// <summary>
        /// 서브테마 가맹점 등록/해지
        /// </summary>
        /// <remarks>
        /// 서브테마 가맹점 등록/해지<br />
        /// <br />
        /// [테마 등록]<br />
        /// => SHOP_INFO_ADD테이블에 THEMA_CD 기입
        /// [테마 해지]<br />
        /// => SHOP_INFO_ADD테이블에 THEMA_CD NULL 처리
        /// </remarks>
        /// <param name="jobGbn">구분(1:등록,2:해지)</param>
        /// <param name="temaCode">메인테마코드</param>
        /// <param name="subTemaCode">서브테마코드</param>
        /// <param name="shopCd">상점코드</param>
        /// <param name="ucode">등록자(수정자) 코드</param>
        /// <returns></returns>
        #region [서브테마 가맹점 등록/해지]
        [HttpPut("temaUpdate")]
        public async Task<IActionResult> temaUpdate(string jobGbn, string temaCode, string subTemaCode, string shopCd, string ucode)
        {

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.UPDATE_SHOP_CD_TEMA"
            };

            cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = jobGbn;
            cmd.Parameters.Add(new OracleParameter("in_tema_code", OracleDbType.Varchar2)).Value = temaCode;
            cmd.Parameters.Add(new OracleParameter("in_sub_tema_code", OracleDbType.Varchar2, 5)).Value = subTemaCode;
            cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = shopCd;
            cmd.Parameters.Add(new OracleParameter("in_user_id", OracleDbType.Varchar2)).Value = ucode;

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/temaUpdate : Put", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg
            });
        }
        #endregion

        /*
        /// <summary>
        /// 가맹점에 등록된 테마 내역 조회
        /// </summary>
        /// <remarks>
        /// 가맹점에 등록된 테마 내역 조회 <br />
        /// <br />
        /// [결과 값] <br />
        /// gbn : M:메인테마, S: 서브테마<br />
        /// temaCode : 메인테마코드<br />
        /// subTemaCode :서브테마코드<br />
        /// temaName :테마이름<br />
        /// </remarks>
        /// <param name="shopCd">상점코드</param>
        /// <returns></returns>
        #region [가맹점에 등록된 테마 내역]
        [HttpGet("subTemaShop")]
        public async Task<IActionResult> GetsubTemaShop(string shopCd)
        {
            List<SubTemaShop> items = new List<SubTemaShop>();

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_RESER_TEMA.GET_RESER_SHOP_INFO_TEMA"
            };

            cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
            cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = shopCd;
                        
            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();            

                while (rd.Read())
                {
                    SubTemaShop i = new SubTemaShop
                    {
                        gbn = rd["GBN"].ToString(),
                        temaCode = rd["TEMA_CODE"].ToString(),
                        subTemaCode = rd["SUB_TEMA_CODE"].ToString(),
                        temaName = rd["TEMA_NAME"].ToString()
                    };

                    items.Add(i);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                data = items
            });
        }
        #endregion
        */


        /// <summary>
        /// 서브테마 변경이력 조회
        /// </summary>
        /// <remarks>
        /// 서브테마 변경이력 조회<br />
        /// <br />
        /// [결과 값] <br />
        /// memo: 변경내용<br />
        /// histDate :일자<br />
        /// </remarks>
        /// <param name="temaCode">메인테마코드</param>
        /// <param name="subTemaCode">서브테마코드</param>
        /// <returns></returns>
        #region [서브테마 변경이력]
        [HttpGet("subTemaHist")]
        public async Task<IActionResult> GetSubTemaHist(string temaCode, string subTemaCode)
        {
            List<TemaHist> items = new List<TemaHist>();

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.GET_SUB_TEMA_HIST"
            };

            cmd.Parameters.Add(new OracleParameter("in_tema_code", OracleDbType.Varchar2)).Value = temaCode;
            cmd.Parameters.Add(new OracleParameter("in_sub_tema_code", OracleDbType.Varchar2,5)).Value = subTemaCode;

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (rd.Read())
                {
                    TemaHist i = new TemaHist
                    {
                        memo = rd["MEMO"].ToString(),
                        histDate = rd["HIST_DATE"].ToString()
                    };

                    items.Add(i);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/subTemaHist : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                data = items
            });
        }
        #endregion

        /*
        /// <summary>
        /// 가맹점 테마 변경이력 조회
        /// </summary>
        /// <remarks>
        /// 가맹점 테마 변경이력 조회<br />
        /// <br />
        /// [결과 값] <br />
        /// memo: 변경내용<br />
        /// userId : 등록 및 수정자<br />
        /// histDate :일자<br />
        /// </remarks>
        /// <param name="shopCode">상점코드</param>
        /// <returns></returns>
        #region [메인테마 변경이력]
        [HttpGet("shopTemaHist")]
        public async Task<IActionResult> GetShopTemaHist(string shopCode)
        {
            List<TemaHist> items = new List<TemaHist>();

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_RESER_TEMA.GET_SHOP_TEMA_HIST"
            };

            cmd.Parameters.Add(new OracleParameter("in_job_gbn", OracleDbType.Varchar2)).Value = "1";
            cmd.Parameters.Add(new OracleParameter("in_shop_cd", OracleDbType.Varchar2)).Value = shopCode;  

            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_cursor", OracleDbType.RefCursor)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (rd.Read())
                {
                    TemaHist i = new TemaHist
                    {
                        memo = rd["MEMO"].ToString(),
                        userId = rd["USER_ID"].ToString(),
                        histDate = rd["HIST_DATE"].ToString()
                    };

                    items.Add(i);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                data = items
            });
        }
        #endregion

        
        /// <summary>
        /// 메인테마 정렬순서 수정
        /// </summary>
        /// <remarks>
        /// 메인테마 정렬순서 수정 <br />
        /// <br /> 
        /// 메인테마코드 입력<br />
        /// </remarks>
        /// <returns></returns>
        #region [메인테마 정렬순서 수정]
        [HttpPut("/tema/updateSort")]
        public async Task<IActionResult> temaUpdateSort(List<string> mainTemaCode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_RESER_TEMA.UPDATE_SORT_MAIN_TEMA"
            };

            OracleParameter dayGbnParam = new OracleParameter("in_cd_array", OracleDbType.Varchar2, null, ParameterDirection.Input);
            dayGbnParam.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            if (mainTemaCode.ToArray().Length == 0)
            {
                dayGbnParam.Value = new string[1] { null };
                dayGbnParam.Size = 0;
            }
            else
            {
                dayGbnParam.Value = mainTemaCode.ToArray();
                dayGbnParam.Size = mainTemaCode.ToArray().Length;
            }
            cmd.Parameters.Add(dayGbnParam);


            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var exe = await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/updateSort : Put", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg
            });
        }
        #endregion
        */


        /// <summary>
        /// 서브테마 정렬순서 수정
        /// </summary>
        /// <remarks>
        /// 서브테마 정렬순서 수정 <br />
        /// <br /> 
        /// temaCode: 메인테마코드<br />
        /// 서브테마코드 입력<br />
        /// </remarks>
        /// <param name="temaCode">메인테마코드</param>
        /// <returns></returns>
        #region [서브테마 정렬순서 수정]
        [HttpPut("/subTema/updateSort")]
        public async Task<IActionResult> subTemaUpdateSort(string temaCode, List<string> subTemaCode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.UPDATE_SORT_SUB_TEMA"
            };

            cmd.Parameters.Add(new OracleParameter("in_main_tema_code", OracleDbType.Varchar2)).Value = temaCode;
            OracleParameter dayGbnParam = new OracleParameter("in_cd_array", OracleDbType.Varchar2, null, ParameterDirection.Input);
            dayGbnParam.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            if (subTemaCode.ToArray().Length == 0)
            {
                dayGbnParam.Value = new string[1] { null };
                dayGbnParam.Size = 0;
            }
            else
            {
                dayGbnParam.Value = subTemaCode.ToArray();
                dayGbnParam.Size = subTemaCode.ToArray().Length;
            }
            cmd.Parameters.Add(dayGbnParam);


            cmd.Parameters.Add(new OracleParameter("out_ret_code", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;
            cmd.Parameters.Add(new OracleParameter("out_ret_msg", OracleDbType.Varchar2, 128)).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var exe = await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = "내부 오류가 발생하였습니다.";

                await Utils.SaveErrorAsync("/Tema/subTema/updateSort : Put", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg
            });
        }
        #endregion

        /// <summary>
        /// 서브테마 이미지 등록
        /// </summary>
        /// <remarks>
        /// 서브테마 이미지 등록
        /// <br/>
        /// [nas] 연결된 서버에서만 가능합니다. <br/>
        /// 한번에 하나씩 등록 가능합니다 <br/>
        /// <br/>
        /// <br/>
        /// [입력값] <br/>
        /// temaCode : 메인테마코드 <br/>
        /// subTemaCode : 서브테마코드 <br/>
        /// ucode: 등록자(수정자) 코드
        /// </remarks>
        #region [서브테마 이미지 등록]
        [HttpPut("/subTemaImage/insert")]
        public async Task<IActionResult> setSubTemaImage(string temaCode, string subTemaCode, string ucode, IFormFile formFile)
        {
            string temaPath = @"\\10.10.10.100\dgnas\Files\OrderTemaImage";
            string nasPath = @"\\10.10.10.100\dgnas\Files";

            CodeMsg codeMsg = new CodeMsg();

            try
            {
                if (formFile != null && formFile.Length > 0)
                {
                    var fileName = temaCode + "_" + subTemaCode + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".jpg";
                    codeMsg = await UpdateSubTemaImg(temaCode, subTemaCode, fileName, ucode);

                    if (codeMsg.code.Equals("00"))
                    {
                        string folerPath = temaPath;

                        // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            if (Directory.Exists(folerPath) == false)
                            {
                                Directory.CreateDirectory(folerPath);
                            }

                            //썸네일 폴더
                            if (Directory.Exists(folerPath + "\\Thumb") == false)
                            {
                                Directory.CreateDirectory(folerPath + "\\Thumb");
                            }

                            // 파일이 이미 존재하면 삭제한다.
                            if (System.IO.File.Exists(folerPath + "\\" + fileName))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPath + "\\" + fileName);
                            }

                            //누겟 imageProcessor 필요
                            using (ImageFactory imageFactory = new ImageFactory(preserveExifData: true))
                            {
                                var ima = imageFactory.Load(formFile.OpenReadStream()).Image;
                                int isizeW = 1280;
                                int isizeH = 720;
                                int quality = 100;

                                //오리지널 저장(w:1280/h:720/q:100)
                                if (ima.Width > ima.Height)
                                {
                                    if (ima.Width < 1280)
                                    {
                                        isizeW = ima.Width;
                                    }

                                    var ratio = (float)ima.Height / ima.Width;

                                    imageFactory.Load(formFile.OpenReadStream())
                                        .Format(new JpegFormat())
                                        .Resize(new Size(isizeW, (int)(isizeW * ratio)))
                                        .Quality(quality)
                                        .Save(folerPath + "\\" + fileName)
                                        .Quality(72)
                                        .Save(folerPath + "\\Thumb\\" + fileName);
                                }
                                else
                                {
                                    if (ima.Height < 720)
                                    {
                                        isizeH = ima.Height;
                                    }

                                    var ratio = (float)ima.Width / ima.Height;

                                    imageFactory.Load(formFile.OpenReadStream())
                                        .Format(new JpegFormat())
                                        .Resize(new Size((int)(isizeH * ratio), isizeH))
                                        .Quality(quality)
                                        .Save(folerPath + "\\" + fileName)
                                        .Quality(72)
                                        .Save(folerPath + "\\Thumb\\" + fileName);
                                }


                            }
                        }

                    }
                }
                else
                {
                    codeMsg.code = "01";
                    codeMsg.msg = "이미지 파일은 필수입니다.";

                }

            }
            catch (Exception ex)
            {
                codeMsg.code = "01";
                codeMsg.msg = "예외처리발생";

                await Utils.SaveErrorAsync("/subTemaImage/insert : Put", ex.Message);
            }


            return Ok(new { code = codeMsg.code, msg = codeMsg.msg });
        }
        #endregion

        /// <summary>
        /// 서브테마 이미지 삭제
        /// </summary>
        /// <remarks>
        /// 서브테마 이미지 삭제
        /// <br/>
        /// [nas] 연결된 서버에서만 가능합니다. <br/>
        /// <br/>
        /// [입력값] <br/>
        /// temaCode : 메인테마코드 <br/>
        /// subTemaCode : 서브테마코드 <br/>
        /// ucode: 등록자(수정자) 코드
        /// </remarks>
        #region [서브테마 이미지 삭제]
        [HttpDelete("/subTemaImage/delete")]
        public async Task<IActionResult> delSubTemaImage(string temaCode, string subTemaCode, string ucode)
        {
            string temaPath = @"\\10.10.10.100\dgnas\Files\OrderTemaImage";
            string nasPath = @"\\10.10.10.100\dgnas\Files";

            CodeMsg codeMsg = new CodeMsg();

            try
            {
                // 파일명 조회
                codeMsg = await getSubTemaImg(temaCode, subTemaCode);

                if (codeMsg.code.Equals("00"))
                {
                    string folerPath = temaPath;

                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        // 파일이 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath + "\\" + codeMsg.msg))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath + "\\" + codeMsg.msg);
                            //썸네일 삭제
                            if (System.IO.File.Exists(folerPath + "\\Thumb\\" + codeMsg.msg))
                            {
                                System.IO.File.Delete(folerPath + "\\Thumb\\" + codeMsg.msg);
                            }
                        }

                    }
                    // 테이블에서 이미지명 제거
                    codeMsg = await UpdateSubTemaImg(temaCode, subTemaCode, "", ucode);

                }

            }
            catch (Exception ex)
            {
                codeMsg.code = "01";
                codeMsg.msg = "예외처리발생";

                await Utils.SaveErrorAsync("/subTemaImage/delete : Delete", ex.Message);
            }


            return Ok(new { code = codeMsg.code, msg = codeMsg.msg });
        }
        #endregion


        #region [서브테마 이미지 조회]
        private async Task<CodeMsg> getSubTemaImg(string temaCode, string subTemaCode)
        {
            CodeMsg codeMsg = new CodeMsg();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.GET_SUB_TEMA_IMG",
            };

            cmd.Parameters.Add("in_tema_code", OracleDbType.Varchar2, 5).Value = subTemaCode;
            cmd.Parameters.Add("in_main_tema_code", OracleDbType.Varchar2, 4).Value = temaCode;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                codeMsg.code = cmd.Parameters["out_ret_code"].Value.ToString();
                codeMsg.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Tema : getSubTemaImg", ex.Message);
            }

            return codeMsg;
        }
        #endregion

        #region [서브테마 이미지 수정]
        private async Task<CodeMsg> UpdateSubTemaImg(string temaCode, string subTemaCode, string fileImg, string ucode)
        {
            CodeMsg codeMsg = new CodeMsg();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_TEMA.UPDATE_SUB_TEMA_IMG",
            };

            cmd.Parameters.Add("in_tema_code", OracleDbType.Varchar2, 5).Value = subTemaCode;
            cmd.Parameters.Add("in_main_tema_code", OracleDbType.Varchar2, 4).Value = temaCode;
            cmd.Parameters.Add("in_file_img", OracleDbType.Varchar2, 100).Value = fileImg;
            cmd.Parameters.Add("in_user_id", OracleDbType.Varchar2, 100).Value = ucode;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                codeMsg.code = cmd.Parameters["out_ret_code"].Value.ToString();
                codeMsg.msg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Tema : UpdateSubTemaImg", ex.Message);
            }

            return codeMsg;
        }
        #endregion

    }
}
