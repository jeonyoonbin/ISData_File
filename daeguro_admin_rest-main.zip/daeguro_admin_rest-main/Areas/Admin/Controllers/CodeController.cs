﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class CodeController : ControllerBase
    {
        /// <summary>
        /// 코드 목록 조회
        /// </summary>
        /// <remarks>
        /// system_gbn : 대구로 쿠폰 조회시 시스템 구분(D: 주문, F: 꽃배달) <br/>
        /// <br/>
        /// [response] <br/>
        /// ETC_CODE_GBN1 : 브랜드 및 브랜드 쿠폰 로고 경로 URL <br/>
        /// ETC_CODE_GBN2 : 브랜드 쿠폰 쿠폰 폰트 컬러 코드 <br/>
        /// ETC_CODE_GBN3 : 브랜드 및 브랜드 쿠폰 컬러 코드 <br/>
        /// ETC_CODE_GBN7 : 쿠폰 중복 사용 여부 (Y : 중복 가능, N : 중복 불가, T : 당일 중복 불가) <br/>
        /// ETC_CODE_GBN8 : 쿠폰 유의사항 <br/>
        /// ETC_CODE1 : 제휴쿠폰 사용 종료일 <br/>
        /// ETC_CODE2 : 제휴쿠폰 qr여부 <br/>
        /// ETC_CODE3 : 시스템구분(D 대구로/T 택시) <br/>
        /// PUB_GBN : 쿠폰 지급 구분 (A: 기본, C: 관리앱 지급, E: 현장 이벤트 지급) <br/>
        ///  <br/>
        /// </remarks>
        [HttpGet()]
        public async Task<IActionResult> Get(string systemGbn, string codeGrp, string useGbn, string testYn)
        {
            List<object> items = new();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("systemGbn", systemGbn);
            param.Add("codeGrp", codeGrp);
            param.Add("useGbn", useGbn);
            param.Add("test_yn", testYn);

            string sqlCodeGrp = string.IsNullOrEmpty(codeGrp) ? "CODE_GRP" : @$"'{codeGrp}'";
            string sqlSystemGbn = string.IsNullOrEmpty(systemGbn) ? "" : @$"AND ETC_CODE3 = '{systemGbn}'";

            string sql = @$"
                            SELECT nvl(CODE_GRP,' ') CODE_GRP,
                                   nvl(CODE,' ') CODE,
                                   nvl(CODE_NM,' ') CODE_NM,
                                   nvl(MEMO,' ') MEMO,
                                   nvl(ETC_AMT1,0) ETC_AMT1, -- 쿠폰 금액
                                   nvl(ETC_AMT2,0) ETC_AMT2,
                                   nvl(ETC_AMT3,0) ETC_AMT3,
                                   nvl(ETC_AMT4,0) ETC_AMT4,
                                   nvl(ETC_CODE_GBN1,' ') ETC_CODE_GBN1, -- 브랜드쿠폰 로고 url
                                   nvl(ETC_CODE_GBN2,' ') ETC_CODE_GBN2, -- 브랜드쿠폰 폰트컬러
                                   nvl(ETC_CODE_GBN3,' ') ETC_CODE_GBN3, -- 브랜드쿠폰 배경컬러
                                   nvl(ETC_CODE_GBN4,' ') ETC_CODE_GBN4,
                                   nvl(ETC_CODE_GBN5,' ') ETC_CODE_GBN5,
                                   nvl(ETC_CODE_GBN6,' ') ETC_CODE_GBN6,
                                   nvl(ETC_CODE_GBN7,' ') ETC_CODE_GBN7,
                                   nvl(ETC_CODE_GBN8,' ') ETC_CODE_GBN8,
                                   nvl(ETC_CODE_GBN9,' ') ETC_CODE_GBN9,
                                   nvl(ETC_CODE_GBN10,' ') ETC_CODE_GBN10,
                                   nvl(ETC_CODE1,' ') ETC_CODE1, -- 사용기한
                                   nvl(ETC_CODE2,' ') ETC_CODE2, -- 제휴쿠폰 qr여부
                                   nvl(ETC_CODE3,' ') ETC_CODE3, -- 시스템구분(D 대구로/T 택시)
                                   nvl(PUB_GBN,'A') PUB_GBN, -- 쿠폰 지급 구분 (A: 기본, C: 관리앱 지급, E: 현장 이벤트 지급)
                                   nvl(USE_GBN,'N') USE_GBN,
                                   nvl(TEST_YN,'N') TEST_YN,
                                   INS_DATE,
                                   INS_UCODE,
                                   nvl(INS_NAME,' ') INS_NAME,
                                   nvl(to_char(MOD_DATE,'YYYY-MM-DD'),' ') MOD_DATE,
                                   MOD_UCODE,
                                   nvl(MOD_NAME,' ') MOD_NAME
                              FROM ETC_CODE
                             WHERE pgm_group = 'O' and CODE_GRP = { sqlCodeGrp } 
                             AND nvl(USE_GBN,'N') like case when :useGbn is null then '%' else :useGbn end
                             AND nvl(TEST_YN,'N') like case when :test_yn is null then '%' else :test_yn end  
                             {sqlSystemGbn}
                             ORDER BY CODE
                        ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 코드 생성
        /// </summary>
        /// <remarks>
        /// ETC_CODE_GBN1(gbn1) : 브랜드 및 브랜드 쿠폰 로고 경로 URL <br/>
        /// ETC_CODE_GBN2(gbn2) : 브랜드 쿠폰 폰트 컬러 코드 <br/>
        /// ETC_CODE_GBN3(gbn3) : 브랜드 및 브랜드 쿠폰 컬러 코드 <br/>
        /// ETC_CODE_GBN7(value4) : 쿠폰 중복 사용 여부 (Y : 중복 가능, N : 중복 불가, T : 당일 중복 불가) <br/>
        /// ETC_CODE_GBN8(value5) : 쿠폰 유의사항 <br/>
        /// ETC_CODE1 : 제휴쿠폰 사용 종료일 <br/>
        /// ETC_CODE2 : 제휴쿠폰 qr여부 <br/>
        /// ETC_CODE3 : 시스템구분(D 대구로/T 택시/F 꽃배달) <br/>
        /// PUB_GBN : 쿠폰 지급 구분 (A: 기본, C: 관리앱 지급, E: 현장 이벤트 지급)
        /// </remarks>
        [HttpPost]
        public async Task<IActionResult> Post(Codes codes)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("codeGrp", codes.codeGrp);
            param.Add("code", codes.code);
            param.Add("codeName", codes.codeName);
            param.Add("memo", codes.memo);
            param.Add("amt1", codes.amt1);
            param.Add("amt2", codes.amt2);
            param.Add("amt3", codes.amt3);
            param.Add("amt4", codes.amt4);
            param.Add("etc_code_gbn_1", codes.gbn1); //로고 url
            param.Add("etc_code_gbn_2", codes.gbn2); 
            param.Add("etc_code_gbn_3", codes.gbn3);
            param.Add("value1", codes.value1);
            param.Add("value2", codes.value2);
            param.Add("value3", codes.value3);
            param.Add("value4", codes.value4);
            param.Add("value5", codes.value5); // etc_code_gbn_8: 쿠폰 유의사항 기입컬럼
            param.Add("etc_code1", codes.etc_code1);
            param.Add("etc_code2", codes.etc_code2);
            param.Add("etc_code3", codes.etc_code3);
            param.Add("pubGbn", codes.pubGbn);
            param.Add("useGbn", codes.useGbn);
            param.Add("test_yn", codes.testYn);
            param.Add("insUCode", codes.insUCode);
            param.Add("insName", codes.insName);


            List<string> items = new();
            string Rmsg;
            string Rcode;
            try
            {
                db.Open();

                string sql = $@"select count(1)
                            from etc_code
                            where mcode = 0
                              and pgm_group = 'O'
                              and CODE_GRP = :codeGrp
                              and code = :code";


                var yn = await db.QuerySingleAsync<int>(sql, param);

                if (yn > 0)
                {
                    return Ok(new { code = "99", msg = "이미 생성된 코드입니다." });
                }

                sql = @$"
                            INSERT INTO ETC_CODE (MCODE,
                                                  PGM_GROUP,
                                                  CODE_GRP,
                                                  CODE,
                                                  CODE_NM,
                                                  MEMO,
                                                  ETC_AMT1,
                                                  ETC_AMT2,
                                                  ETC_AMT3,
                                                  ETC_AMT4,
                                                  ETC_CODE_GBN1,  -- 로고
                                                  ETC_CODE_GBN2,  -- 폰트색상
                                                  ETC_CODE_GBN3,  -- 색상
                                                  ETC_CODE_GBN4,
                                                  ETC_CODE_GBN5,
                                                  ETC_CODE_GBN6,
                                                  ETC_CODE_GBN7,
                                                  ETC_CODE_GBN8,
                                                  ETC_CODE1,
                                                  ETC_CODE2,  --제휴쿠폰 qr여부
                                                  ETC_CODE3, 
                                                  PUB_GBN,
                                                  USE_GBN,
                                                  TEST_YN,
                                                  INS_UCODE,
                                                  INS_NAME,
                                                  INS_DATE)
                                 VALUES (0, 'O',
                                         :codeGrp,
                                         :code,
                                         :codeName,
                                         :memo,
                                         :amt1,
                                         :amt2,
                                         :amt3,
                                         :amt4,
                                         :etc_code_gbn_1,
                                         :etc_code_gbn_2,
                                         :etc_code_gbn_3,
                                         :value1,
                                         :value2,
                                         :value3,
                                         :value4,
                                         :value5,
                                         :etc_code1,
                                         :etc_code2, 
                                         :etc_code3, 
                                         :pubGbn,
                                         :useGbn,
                                         :test_yn,
                                         :insUCode,
                                         :insName,
                                         SYSDATE)
                            ";

                await db.ExecuteAsync(sql, param);

                //shop_status로 운영하는 가맹점만 해당쿠폰 가맹점 설정을 넣어주도록 수정
                //그외에도 특수한 상태의 가맹점이 포함될수 있어서 조건제거후 사용여부 추가, 2023.10.31
                if (codes.codeGrp == "BRAND_COUPON")
                {
                    sql = @$"
                            select shop_cd from shop_info
                            where franchise_cd = :etc_code1
                            and use_gbn = 'Y'
                            --and shop_status in ('10','30')
                        ";
                    var temp = await db.QueryAsync<string>(sql, param, commandType: CommandType.Text);
                    items = temp.ToList();

                    foreach (object e in items)
                    {

                        sql = @$"
                            INSERT INTO CHAIN_COUPON_SHOP(CHAIN_CODE, SHOP_CD, COUPON_TYPE, COUPON_NAME, USE_MAX_COUNT, INS_DATE, INS_UCODE, INS_NAME, USE_YN)
                                VALUES(:etc_code1, {e}, :code, :codeName, 0, SYSDATE, :insUCode, :insName, 'N')
                        ";

                        await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                    }
                }

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Code : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 코드 수정
        /// </summary>
        /// <remarks>
        /// ETC_CODE_GBN1(gbn1) : 브랜드 및 브랜드 쿠폰 로고 경로 URL <br/>
        /// ETC_CODE_GBN2(gbn2) : 브랜드 쿠폰 컬러 코드 <br/>
        /// ETC_CODE_GBN3(gbn3) : 브랜드 및 브랜드 쿠폰 컬러 코드 <br/>
        /// ETC_CODE_GBN7(value4) : 쿠폰 중복 사용 여부 (Y : 중복 가능, N : 중복 불가, T : 당일 중복 불가) <br/>
        /// ETC_CODE_GBN8(value5) : 쿠폰 유의사항 <br/>
        /// ETC_CODE1 : 제휴쿠폰 사용 종료일 <br/>
        /// ETC_CODE2 : 제휴쿠폰 qr여부 <br/>
        /// ETC_CODE3 : 시스템구분(D 대구로/T 택시) <br/>
        /// PUB_GBN : 쿠폰 지급 구분 (A: 기본, C: 관리앱 지급, E: 현장 이벤트 지급) 
        /// </remarks>
        [HttpPut]
        public async Task<IActionResult> Put(Codes codes)
        {

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("codeGrp", codes.codeGrp);
            param.Add("code", codes.code);
            param.Add("codeName", codes.codeName);
            param.Add("memo", codes.memo);
            param.Add("amt1", codes.amt1);
            param.Add("amt2", codes.amt2);
            param.Add("amt3", codes.amt3);
            param.Add("amt4", codes.amt4);
            param.Add("etc_code_gbn_1", codes.gbn1);
            param.Add("etc_code_gbn_2", codes.gbn2);
            param.Add("etc_code_gbn_3", codes.gbn3);
            param.Add("value1", codes.value1);
            param.Add("value2", codes.value2);
            param.Add("value3", codes.value3);
            param.Add("value4", codes.value4);
            param.Add("value5", codes.value5);
            param.Add("etc_code1", codes.etc_code1);
            param.Add("etc_code2", codes.etc_code2);
            param.Add("etc_code3", codes.etc_code3);
            param.Add("pubGbn", codes.pubGbn);
            param.Add("useGbn", codes.useGbn);
            param.Add("test_yn", codes.testYn);
            param.Add("modUCode", codes.modUCode);
            param.Add("modName", codes.modName);

            

            string sql = @$"
                            UPDATE ETC_CODE
                               SET CODE_NM = :codeName,
                                   MEMO = :memo,
                                   ETC_AMT1 = :amt1,
                                   ETC_AMT2 = :amt2,
                                   ETC_AMT3 = :amt3,
                                   ETC_AMT4 = :amt4,
                                   ETC_CODE_GBN1 = :etc_code_gbn_1, -- 로고
                                   ETC_CODE_GBN2 = :etc_code_gbn_2, -- 브랜드쿠폰 폰트 색상
                                   ETC_CODE_GBN3 = :etc_code_gbn_3, -- 색상
                                   ETC_CODE_GBN4 = :value1,
                                   ETC_CODE_GBN5 = :value2, 
                                   ETC_CODE_GBN6 = :value3,
                                   ETC_CODE_GBN7 = :value4,
                                   ETC_CODE_GBN8 = :value5,
                                   ETC_CODE1 = :etc_code1,
                                   ETC_CODE2 = :etc_code2, --제휴쿠폰 qr여부
                                   ETC_CODE3 = :etc_code3, 
                                   PUB_GBN = :pubGbn,
                                   USE_GBN = :useGbn,
                                   TEST_YN = :test_yn,
                                   MOD_UCODE = :modUCode,
                                   MOD_NAME = :modName,
                                   MOD_DATE = SYSDATE
                             WHERE MCODE = 0 AND PGM_GROUP = 'O' AND CODE_GRP = :codeGrp AND CODE = :code                            
                            ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();
                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                //제휴쿠폰의 경우 수정x
                //브랜드쿠폰의 경우 쿠폰명, 쿠폰가격 수정시 전체수정
                if (codes.codeGrp == "B2BCOUPON_TYPE")
                {
                    //sql = @$"
                    //        UPDATE B2B_COUPON_MST
                    //        SET S_ETC_GBN1 = :memo
                    //        WHERE COUPON_TYPE = :code
                    //        ";
                    //await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                } else if(codes.codeGrp == "BRAND_COUPON")
                {
                    /* 일괄수정기능 위험할수 있으므로 주석처리.
                    sql = @$"
                            UPDATE CHAIN_COUPON_MST
                            SET COUPON_NAME = :codeName,
                                COUPON_AMT = :amt1,
                                OTHER_AMT = :amt1 - ISD_AMT
                            WHERE COUPON_TYPE = :code
                            ";
                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                    sql = @$"
                            UPDATE CHAIN_COUPON_SHOP
                            SET COUPON_NAME = :codeName
                            WHERE COUPON_TYPE = :code
                            ";
                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                    */
                }

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Code : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 코드 삭제
        /// </summary>
        [HttpDelete]
        public async Task<IActionResult> Delete(string codeGrp, string code)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("codeGrp", codeGrp);
            param.Add("code", code);

            string sql = @$"
                            DELETE ETC_CODE WHERE MCODE = 0 AND PGM_GROUP = 'O' AND CODE_GRP = :codeGrp AND CODE = :code                         
                            ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();
                await db.ExecuteAsync(sql, param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpGet("getFoodSafety")]
        public async Task<IActionResult> getFoodSafety(string code)
        {
            object item = new();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("code", code);

            string sql = @$"
                            SELECT NVL(ETC_CODE_GBN9,' ') nutrition, NVL(ETC_CODE_GBN10,' ') allergy
                            FROM ETC_CODE WHERE MCODE = 0 AND PGM_GROUP = 'O' AND CODE_GRP = 'API' AND CODE = :code                         
                            ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();
                item = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 영양성분 알레르기 정보 수정
        /// </summary>
        [HttpPut("putFoodSafety")]
        public async Task<IActionResult> putFoodSafety(FoodSafety item)
        {

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("code", item.code);
            param.Add("nutrition", item.nutrition);
            param.Add("allergy", item.allergy);
            param.Add("mod_ucode", item.modUcode);
            param.Add("mod_name", item.modName);

            string sql = @$"
                            UPDATE ETC_CODE 
                            SET ETC_CODE_GBN9 = :nutrition,
                                ETC_CODE_GBN10 = :allergy,
                                MOD_DATE = SYSDATE,
                                MOD_UCODE = mod_ucode,
                                MOD_NAME = mod_name
                            WHERE MCODE = 0 AND PGM_GROUP = 'O' AND CODE_GRP = 'API' AND CODE = :code                         
                            ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();
                await db.ExecuteAsync(sql, param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg});
        }



        /// <summary>
        /// 가맹점 요청 구분 코드 조회
        /// </summary>        
        [HttpGet("getShopReqCategoryList")]
        public async Task<IActionResult> getShopReqCategoryList()
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<CodesShopReqCategory> items = new List<CodesShopReqCategory>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CODE.GET_SERVICE_REQ_CATEGORY_LIST",
            };
                        
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();                
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    CodesShopReqCategory m = new CodesShopReqCategory
                    {
                        gbn_code = rd["gbn_code"].ToString(),
                        gbn_name = rd["gbn_name"].ToString(),
                        use_gbn = rd["use_gbn"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["ins_name"].ToString(),
                        mod_date = rd["mod_date"].ToString(),
                        mod_ucode = rd["mod_ucode"].ToString(),
                        mod_name = rd["mod_name"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Code/getShopReqCategoryList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 가맹점 요청 구분 코드 등록
        /// </summary>  
        /// <remarks>
        /// gbn_name : 구분명 <br/>
        /// use_gbn : 사용구분(null인경우 N 기입) <br/>
        /// ucode : 등록자 ucode(필수) <br/>        
        /// </remarks>
        [HttpPost("setShopReqCategory/{ucode}")]
        public async Task<IActionResult> setShopReqCategory(string gbn_name, string use_gbn, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CODE.SET_SERVICE_REQ_CATEGORY",
            };
            
            cmd.Parameters.Add("in_gbn_name", OracleDbType.Varchar2, 100).Value = gbn_name;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Code/setShopReqCategory : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 요청 구분 코드 수정
        /// </summary>  
        /// <remarks>
        /// gbn_code : 구분코드(필수) <br/>
        /// gbn_name : 구분명 <br/>
        /// use_gbn : 사용구분(null인경우 N 기입) <br/>
        /// ucode : 수정자 ucode(필수) <br/>        
        /// </remarks>
        /// 
        [HttpPut("updateShopReqCategory")]
        public async Task<IActionResult> updateShopReqCategory(string gbn_code, string gbn_name, string use_gbn, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            if (string.IsNullOrEmpty(gbn_code))
            {
                return Ok(new { code = "99", msg = "구분 코드는 필수항목입니다." });
            }

            if (string.IsNullOrEmpty(ucode))
            {
                return Ok(new { code = "99", msg = "수정자 UCode는 필수항목입니다." });
            }
            

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CODE.UPDATE_SERVICE_REQ_CATEGORY",
            };

            cmd.Parameters.Add("in_gbn_code", OracleDbType.Int32).Value = gbn_code;
            cmd.Parameters.Add("in_gbn_name", OracleDbType.Varchar2, 100).Value = gbn_name;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Code/updateShopReqCategory : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }



        /// <summary>
        /// 가맹점 요청 내용 코드 조회
        /// </summary>        
        /// <remarks>
        /// gbn_code : 구분코드 <br/>        
        /// </remarks>
        [HttpGet("getShopReqTypeList")]
        public async Task<IActionResult> getShopReqTypeList(string gbn_code)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<CodesShopReqType> items = new List<CodesShopReqType>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CODE.GET_SERVICE_REQ_TYPE_LIST",
            };

            cmd.Parameters.Add("in_gbn_code", OracleDbType.Varchar2, 10).Value = gbn_code;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    CodesShopReqType m = new CodesShopReqType
                    {
                        gbn_code = rd["gbn_code"].ToString(),
                        gbn_name = rd["gbn_name"].ToString(),
                        type_code = rd["type_code"].ToString(),
                        type_name = rd["type_name"].ToString(),
                        use_gbn = rd["use_gbn"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["ins_name"].ToString(),
                        mod_date = rd["mod_date"].ToString(),
                        mod_ucode = rd["mod_ucode"].ToString(),
                        mod_name = rd["mod_name"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Code/getShopReqTypeList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        /// <summary>
        /// 가맹점 요청 내용 코드 등록
        /// </summary>  
        /// <remarks>
        /// gbn_code : 구분코드(필수) <br/> 
        /// type_code : 내용코드(필수) <br/>
        /// type_name : 내용명 <br/> 
        /// use_gbn : 사용구분(null인경우 N 기입) <br/>
        /// ucode : 등록자 ucode(필수) <br/>
        /// </remarks>
        [HttpPost("setShopReqType")]
        public async Task<IActionResult> setShopReqType(string gbn_code, string type_code, string type_name, string use_gbn, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            if(string.IsNullOrEmpty(gbn_code))
            {
                return Ok(new { code = "99", msg = "구분 코드는 필수항목입니다." });
            }

            if (string.IsNullOrEmpty(type_code))
            {
                return Ok(new { code = "99", msg = "내용 코드는 필수항목입니다." });
            }

            if (string.IsNullOrEmpty(ucode))
            {
                return Ok(new { code = "99", msg = "수정자 UCode는 필수항목입니다." });
            }

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CODE.SET_SERVICE_REQ_TYPE",
            };

            cmd.Parameters.Add("in_gbn_code", OracleDbType.Varchar2, 10).Value = gbn_code;
            cmd.Parameters.Add("in_type_code", OracleDbType.Varchar2, 10).Value = type_code;
            cmd.Parameters.Add("in_type_name", OracleDbType.Varchar2, 100).Value = type_name;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Code/setShopReqType : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 요청 내용 코드 수정
        /// </summary>  
        /// <remarks>
        /// gbn_code : 구분코드(필수) <br/>
        /// type_code : 내용코드(필수) <br/>
        /// type_name : 내용명(필수) <br/>
        /// use_gbn : 사용구분(null인경우 N 기입) <br/>
        /// ucode : 수정자 ucode(필수) <br/>
        /// </remarks>
        /// 
        [HttpPut("updateShopReqType")]
        public async Task<IActionResult> updateShopReqType(string gbn_code, string type_code, string type_name, string use_gbn, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            if (string.IsNullOrEmpty(gbn_code))
            {
                return Ok(new { code = "99", msg = "구분 코드는 필수항목입니다." });
            }

            if (string.IsNullOrEmpty(type_code))
            {
                return Ok(new { code = "99", msg = "내용 코드는 필수항목입니다." });
            }

            if (string.IsNullOrEmpty(type_name))
            {
                return Ok(new { code = "99", msg = "내용명은 필수항목입니다." });
            }

            if (string.IsNullOrEmpty(ucode))
            {
                return Ok(new { code = "99", msg = "수정자 UCode는 필수항목입니다." });
            }
            

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CODE.UPDATE_SERVICE_REQ_TYPE",
            };

            cmd.Parameters.Add("in_gbn_code", OracleDbType.Int32).Value = gbn_code;
            cmd.Parameters.Add("in_type_code", OracleDbType.Varchar2, 10).Value = type_code;
            cmd.Parameters.Add("in_type_name", OracleDbType.Varchar2, 100).Value = type_name;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Code/updateShopReqType : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

    }
}
