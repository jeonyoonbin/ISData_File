﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class MenuMultiController : ControllerBase
    {
        string productPath = @"\\10.10.10.100\dgnas\Files\ProductImage";
        //string productPath = @"\sy100";
        string nasPath = @"\\10.10.10.100\dgnas\Files";
        string testImagePath = @"E:\iis\Files\TestImage";

        /// <summary>
        /// 멀티 메뉴 이미지 조회
        /// </summary>
        /// <remarks>
        /// menu_cd : 메뉴코드 <br/>
        /// div : 구분(1. 메뉴이미지, 2. 메뉴설명이미지)(필수) <br/>
        /// <br/>
        /// 이미지 url <br/>
        /// 내부망 : https://admin.daeguro.co.kr/images/{cccode}/{shop_cd}/{file_name} <br/>
        /// 외부망 : https://image.daeguro.co.kr:40443/images/{cccode}/{shop_cd}/{file_name} <br/>
        /// 테스트 : https://dgpub.282.co.kr:8500/testimage/{cccode}/{shop_cd}/{file_name} <br/>
        /// </remarks>
        [HttpGet("{menu_cd}")]
        public async Task<IActionResult> Get(string menu_cd, string div)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<MenuMultiList> menues = new List<MenuMultiList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.GET_MENU_IMG_MULTI",
            };

            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = menu_cd;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    MenuMultiList m = new MenuMultiList
                    {
                        seq = rd["menu_image_seq"].ToString(),
                        file_name = rd["file_name"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["ins_name"].ToString(),
                        mod_date = rd["mod_date"].ToString(),
                        mod_ucode = rd["mod_ucode"].ToString(),
                        mod_name = rd["mod_name"].ToString(),
                    };

                    menues.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuMulti/{menu_cd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = menues });
        }


        /// <summary>
        /// 멀티 메뉴 이미지 등록
        /// </summary>
        /// <remarks>
        /// 확장자 jpg로 저장 <br/>
        /// cccode: 콜센터코드 <br/>
        /// shop_cd : 가맹점코드 <br/>
        /// menu_cd : 메뉴코드 <br/>
        /// div : 구분(1. 메뉴이미지, 2. 메뉴설명이미지)(필수) <br/>
        /// ucode : 등록자코드 <br/>
        /// uname : 등록자명 <br/>
        /// </remarks>
        [HttpPost]
        public async Task<IActionResult> Post(IFormFile formFile, string cccode, string shop_cd, string menu_cd, string div, string ucode, string uname)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                if (formFile != null && formFile.Length > 0)
                {
                    string dt = DateTime.Now.ToString("yyyyMMddHHmmss");

                    string fileName = menu_cd + "_" + dt + ".jpg";

                    ResultBasic result = await setImg(cccode, shop_cd, menu_cd, div, fileName, ucode, uname);

                    if (result.code.Equals("00") && Utils.serverGbn == "R") //운영서버의 경우
                    {
                        // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            string folerPath = productPath + "\\" + cccode + "\\" + shop_cd;

                            DirectoryInfo di = new DirectoryInfo(folerPath);

                            if (di.Exists == false)
                            {
                                di.Create();
                            }

                            folerPath = folerPath + "\\" + fileName;

                            // 파일이 이미 존재하면 삭제한다.
                            if (System.IO.File.Exists(folerPath))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPath);
                            }

                            //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                            using var stream = new FileStream(folerPath, FileMode.Create);

                            await formFile.CopyToAsync(stream);

                            stream.Close();
                            stream.Dispose();
                        }
                    }
                    else if (result.code.Equals("00") && Utils.serverGbn == "T") //테스트서버의 경우
                    {
                        string folerPath = testImagePath + "\\" + cccode + "\\" + shop_cd;
                        DirectoryInfo di = new DirectoryInfo(folerPath);

                        if (di.Exists == false)
                        {
                            di.Create();
                        }

                        folerPath = folerPath + "\\" + fileName;

                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath);
                        }

                        //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                        using var stream = new FileStream(folerPath, FileMode.Create);

                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();
                    }

                    }
                else
                {
                    Rcode = "99";
                    Rmsg = "등록할 이미지가 없습니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                Rcode = "00";
                Rmsg = "성공";


            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/MenuMulti : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }


        private async Task<ResultBasic> setImg(string cccode, string shop_cd, string menu_cd, string div, string file_name, string ins_ucode ,string ins_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.ADD_MENU_IMG_MULTI",
            };

            cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = cccode;
            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = menu_cd;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("in_file_name", OracleDbType.Varchar2, 100).Value = file_name;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = ins_ucode;
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 300).Value = ins_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString(); //등록 성공시 파일명 리턴

                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                result.code = "98";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync("/MenuMulti/setImg : Post", ex.Message);
            }

            return result;
        }


        /// <summary>
        /// 멀티 메뉴 이미지 수정
        /// </summary>
        /// <remarks>
        /// 확장자 jpg로 저장 <br/>
        /// cccode: 콜센터코드 <br/>
        /// shop_cd : 가맹점코드 <br/>
        /// seq : 멀티 메뉴 이미지 pk값 <br/>
        /// menu_cd : 메뉴코드 <br/>
        /// ucode : 수정자코드 <br/>
        /// uname : 수정자명 <br/>
        /// </remarks>
        [HttpPut]
        public async Task<IActionResult> Put(IFormFile formFile, string cccode, string shop_cd, string seq, string menu_cd, string ucode, string uname)
        {
            ResultBasic result = new ResultBasic();
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                if (formFile != null && formFile.Length > 0)
                {
                    string dt = DateTime.Now.ToString("yyyyMMddHHmmss");

                    string fileName = menu_cd + "_" + dt + ".jpg";

                    result = await updateImg(cccode, shop_cd, seq, fileName, ucode, uname);
                    string old_file_name = result.msg;
                    if (result.code.Equals("00") && Utils.serverGbn == "R") //운영서버의 경우
                    {
                        // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            string folerPathOld = productPath + "\\" + cccode + "\\" + shop_cd + "\\" + old_file_name;
                            string folerPath = productPath + "\\" + cccode + "\\" + shop_cd;

                            DirectoryInfo di = new DirectoryInfo(folerPath);

                            if (di.Exists == false)
                            {
                                di.Create();
                            }

                            folerPath = folerPath + "\\" + fileName;

                            // 기존파일 삭제
                            if (System.IO.File.Exists(folerPathOld))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPathOld);
                            }

                            //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                            using var stream = new FileStream(folerPath, FileMode.Create);

                            await formFile.CopyToAsync(stream);

                            stream.Close();
                            stream.Dispose();
                        }
                    }
                    else if (result.code.Equals("00") && Utils.serverGbn == "T") //테스트서버의 경우
                    {
                        string folerPathOld = testImagePath + "\\" + cccode + "\\" + shop_cd + "\\" + old_file_name;
                        string folerPath = testImagePath + "\\" + cccode + "\\" + shop_cd;
                        DirectoryInfo di = new DirectoryInfo(folerPath);

                        if (di.Exists == false)
                        {
                            di.Create();
                        }

                        folerPath = folerPath + "\\" + fileName;

                        // 기존파일 삭제
                        if (System.IO.File.Exists(folerPathOld))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPathOld);
                        }

                        //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                        using var stream = new FileStream(folerPath, FileMode.Create);

                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();
                    }

                }
                else
                {
                    Rcode = "99";
                    Rmsg = "수정할 이미지가 없습니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                Rcode = "00";
                Rmsg = "성공";


            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/MenuMulti : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }


        private async Task<ResultBasic> updateImg(string cccode, string shop_cd, string seq, string file_name, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.UPDATE_MENU_IMG_MULTI",
            };

            cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = cccode;
            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_seq", OracleDbType.Int32).Value = seq;
            cmd.Parameters.Add("in_file_name", OracleDbType.Varchar2, 100).Value = file_name;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 300).Value = mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString(); //수정 성공시 파일명 리턴

                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                result.code = "98";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync("/MenuMulti/updateImg : Put", ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 멀티 메뉴 이미지 삭제
        /// </summary>
        /// <remarks>
        /// menu_cd : 메뉴코드(필수) <br/>
        /// div : 구분(1. 메뉴이미지, 2. 메뉴설명이미지)(필수) <br/>
        /// seq : 멀티 메뉴 이미지 pk값 <br/>
        /// </remarks>
        [HttpDelete()]
        public async Task<ResultBasic> delete(string seq, string div, string menu_cd, string mod_ucode, string mod_name)
        {
            ResultBasic result = new ResultBasic();
            string folerPath = string.Empty;
            string Rposition = "/MenuMulti : Delete";

            try
            {

                result = await deleteImg(seq, div, menu_cd, mod_ucode, mod_name);

                if (result.code == "00" && Utils.serverGbn == "R")//운영서버
                {
                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        folerPath = productPath + "\\" + result.msg;
                        // 파일이 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath);
                        }
                    }
                }
                else if (result.code == "00" && Utils.serverGbn == "T")//테스트서버
                {
                    folerPath = testImagePath + "\\" + result.msg;
                    // 파일이 존재하면 삭제한다.
                    if (System.IO.File.Exists(folerPath))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        System.IO.File.Delete(folerPath);
                    }
                }
            }
            catch (Exception ex)
            {
                result.code = "99";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }


            return result;
        }

        private async Task<ResultBasic> deleteImg(string menu_image_seq, string div, string menu_cd, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/MenuMulti/deleteImg : Delete";

            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.DELETE_MENU_IMG_MULTI",
            };

            cmd.Parameters.Add("in_menu_image_seq", OracleDbType.Int32).Value = menu_image_seq;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = menu_cd;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 300).Value = mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString(); //기존 파일명(+경로) 리턴

                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                result.code = "98";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return result;
        }
    }
}
