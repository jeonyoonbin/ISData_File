﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        string eventPath = @"\\10.10.10.100\dgnas\Files\EventImage";
        string nasPath = @"\\10.10.10.100\dgnas\Files";
        string noticePath = @"\\10.10.10.100\dgnas\Files\noticeImage";
        string noticeAspPath = @"\\10.10.10.100\dgnas\Files\DgAppEvent";
        string testImagePath = @"E:\iis\Files\TestImage";
        string testPath = @"\sy100";

        #region[결제혜택]
        /// <summary>
        /// 결제수단 목록조회
        /// </summary>
        /// <remarks>
        /// app_pay_gbn : 앱 결제 구분 <br/> 
        /// use_gbn : 사용여부(Y/N) <br/>
        /// RESPONSE <br/>
        /// pay_gbn : 결제구분 <br/>
        /// app_pay_gbn : 앱 결제 구분 <br/> 
        /// pay_name : 결제수단명 <br/>
        /// use_gbn : 사용여부
        /// benefit_yn : 혜택 사용 여부(Y/N)
        /// notice_yn : 안내문 사용 여부(Y/N)
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string app_pay_gbn, string use_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/Payment : Get";

            List<PaymentList> itmes = new List<PaymentList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PAYMENT.GET_LIST",
            };

            cmd.Parameters.Add("in_app_pay_gbn", OracleDbType.Varchar2, 10).Value = app_pay_gbn;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    PaymentList item = new PaymentList
                    {
                        pay_gbn = rd["pay_gbn"].ToString(),
                        app_pay_gbn = rd["app_pay_gbn"].ToString(),
                        pay_name = rd["pay_name"].ToString(),
                        use_gbn = rd["use_gbn"].ToString(),
                        benefit_yn = rd["benefit_yn"].ToString(),
                        notice_yn = rd["notice_yn"].ToString(),
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = itmes });
        }

        /// <summary>
        /// 결제수단 상세조회
        /// </summary>
        /// <remarks>
        /// pay_gbn : 결제구분 <br/>
        /// app_pay_gbn : 앱 결제 구분 <br/> 
        /// pay_name : 결제수단명 <br/>
        /// use_gbn : 사용여부 <br/>
        /// login_yn : 로그인 필요 여부(Y/N) <br/>
        /// benefit_yn : 혜택 사용 여부(Y/N) <br/>
        /// notice_yn : 안내문 사용 여부(Y/N) <br/>
        /// notice : 안내문구 <br/>
        /// </remarks>
        [HttpGet("getDetail")]
        public async Task<IActionResult> getDetail(string pay_gbn, string app_pay_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/Payment/getDetail : Get";

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PAYMENT.GET_DETAIL",
            };

            cmd.Parameters.Add("in_pay_gbn", OracleDbType.Varchar2, 10).Value = pay_gbn;
            cmd.Parameters.Add("in_app_pay_gbn", OracleDbType.Varchar2, 10).Value = app_pay_gbn;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            PaymentDetail item = new PaymentDetail();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.pay_gbn = rd["pay_gbn"].ToString();
                item.app_pay_gbn = rd["app_pay_gbn"].ToString();
                item.pay_name = rd["pay_name"].ToString();
                item.use_gbn = rd["use_gbn"].ToString();
                item.login_yn = rd["login_yn"].ToString();
                item.benefit_yn = rd["benefit_yn"].ToString();
                item.notice_yn = rd["notice_yn"].ToString();                
                item.notice = rd["notice"].ToString();
                item.ins_date = rd["ins_date"].ToString();
                item.ins_ucode = rd["ins_ucode"].ToString();
                item.ins_name = rd["ins_name"].ToString();
                item.mod_date = rd["mod_date"].ToString();
                item.mod_ucode = rd["mod_ucode"].ToString();
                item.mod_name = rd["mod_name"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 결제수단 변경이력
        /// </summary>
        /// <remarks>
        /// pay_gbn : 결제구분 <br/>
        /// app_pay_gbn : 앱 결제 구분 <br/> 
        /// </remarks>
        [HttpGet("getHist")]
        public async Task<IActionResult> getHist(string pay_gbn, string app_pay_gbn)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/Payment/getHist : Get";

            List<HistoryList> itmes = new List<HistoryList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PAYMENT.GET_HIST",
            };

            cmd.Parameters.Add("in_pay_gbn", OracleDbType.Varchar2, 10).Value = pay_gbn;
            cmd.Parameters.Add("in_app_pay_gbn", OracleDbType.Varchar2, 10).Value = app_pay_gbn;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    HistoryList item = new HistoryList
                    {
                        no = rd["seq"].ToString(),
                        insertDate = rd["hist_date"].ToString(),
                        memo = rd["memo"].ToString(),
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }

        /// <summary>
        /// 결제수단 수정
        /// </summary>
        /// <remarks>   
        /// pay_gbn : 결제구분(필수) <br/>
        /// app_pay_gbn : 앱 결제 구분(필수) <br/>
        /// benefit_yn : 혜택 사용 여부(Y/N) <br/>
        /// notice_yn : 안내문 사용 여부(Y/N) <br/>
        /// notice : 안내문구 <br/>
        /// </remarks>
        [HttpPut("updatePayment")]
        public async Task<ResultBasic> updatePayment(PaymentPut item)
        {
            string Rposition = "/Payment/updatePayment";
            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PAYMENT.UPDATE_PAYMENT",
            };
                        
            cmd.Parameters.Add("in_pay_gbn", OracleDbType.Varchar2, 10).Value = item.pay_gbn;
            cmd.Parameters.Add("in_app_pay_gbn", OracleDbType.Varchar2, 1).Value = item.app_pay_gbn;
            cmd.Parameters.Add("in_benefit_yn", OracleDbType.Varchar2, 1).Value = item.benefit_yn;
            cmd.Parameters.Add("in_notice_yn", OracleDbType.Varchar2, 1).Value = item.notice_yn;            
            cmd.Parameters.Add("in_notice", OracleDbType.Varchar2, 2000).Value = item.notice;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = item.mod_ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return result;
        }
        #endregion[결제혜택]

        #region[결제장애공지]
        /// <summary>
        /// 결제수단 목록조회
        /// </summary>
        /// <remarks>
        /// RESPONSE <br/>
        /// pay_gbn : 결제구분 <br/>
        /// app_pay_gbn : 앱 결제 구분 <br/> 
        /// pay_name : 결제수단명 <br/>
        /// able_yn : 결제버튼 활성 여부(Y/N) <br/>
        /// disorder_msg : 결제 장애 메시지 <br/>
        /// </remarks>
        [HttpGet("getPaymentEm")]
        public async Task<IActionResult> getPaymentEm()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/Payment/getPaymentEm : Get";

            List<PaymentEm> itmes = new List<PaymentEm>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PAYMENT.GET_PAYMENT_EM",
            };

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    PaymentEm item = new PaymentEm
                    {
                        pay_gbn = rd["pay_gbn"].ToString(),
                        app_pay_gbn = rd["app_pay_gbn"].ToString(),
                        pay_name = rd["pay_name"].ToString(),
                        able_yn = rd["able_yn"].ToString(),
                        disorder_msg = rd["disorder_msg"].ToString(),
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = itmes });
        }

        /// <summary>
        /// 결제장애공지 수정
        /// </summary>
        /// <remarks>   
        /// pay_gbn : 결제구분(필수) <br/>
        /// app_pay_gbn : 앱 결제 구분(필수) <br/>
        /// able_yn : 결제버튼 활성 여부(Y/N) <br/>
        /// disorder_msg : 결제 장애 메시지 <br/>
        /// mod_ucode : 수정자 <br/>
        /// </remarks>
        [HttpPut("updatePaymentEm")]
        public async Task<ResultBasic> updatePaymentEm(IEnumerable<PaymentEmPut> item, string mod_ucode)
        {
            string Rposition = "/Payment/updatePaymentEm";
            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PAYMENT.UPDATE_PAYMENT_EM",
            };
            List<string> payGbns = new List<string>();
            List<string> appPayGbns = new List<string>();
            List<string> ables = new List<string>();
            List<string> disorderMsgs = new List<string>();


            foreach (var i in item)
            {
                payGbns.Add(i.pay_gbn);
                appPayGbns.Add(i.app_pay_gbn);
                ables.Add(i.able_yn);
                disorderMsgs.Add(i.disorder_msg);
            }

            var arrPayGbn = cmd.Parameters.Add("in_pay_gbn", OracleDbType.Varchar2, 10);
            arrPayGbn.Direction = ParameterDirection.Input;
            arrPayGbn.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrPayGbn.Value = payGbns.ToArray();
            arrPayGbn.Size = payGbns.Count();
            arrPayGbn.ArrayBindSize = payGbns.Select(_ => _.Length).ToArray();
            arrPayGbn.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, payGbns.Count()).ToArray();

            var arrAppPayGbn = cmd.Parameters.Add("in_app_pay_gbn", OracleDbType.Varchar2, 10);
            arrAppPayGbn.Direction = ParameterDirection.Input;
            arrAppPayGbn.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrAppPayGbn.Value = appPayGbns.ToArray();
            arrAppPayGbn.Size = appPayGbns.Count();
            arrAppPayGbn.ArrayBindSize = appPayGbns.Select(_ => _.Length).ToArray();
            arrAppPayGbn.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, appPayGbns.Count()).ToArray();

            var arrAble = cmd.Parameters.Add("in_able_yn", OracleDbType.Varchar2, 10);
            arrAble.Direction = ParameterDirection.Input;
            arrAble.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrAble.Value = ables.ToArray();
            arrAble.Size = ables.Count();
            arrAble.ArrayBindSize = ables.Select(_ => _.Length).ToArray();
            arrAble.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, ables.Count()).ToArray();

            var arrDisorderMsg = cmd.Parameters.Add("in_disorder_msg", OracleDbType.Varchar2, 10);
            arrDisorderMsg.Direction = ParameterDirection.Input;
            arrDisorderMsg.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrDisorderMsg.Value = disorderMsgs.ToArray();
            arrDisorderMsg.Size = disorderMsgs.Count();
            arrDisorderMsg.ArrayBindSize = disorderMsgs.Select(_ => _.Length).ToArray();
            arrDisorderMsg.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, disorderMsgs.Count()).ToArray();

            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = mod_ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return result;
        }
        #endregion[결제장애공지]
    }
}
