﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class MenuGroupController : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> Get(string shopCd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<MenuGroupList> menuGroupList = new List<MenuGroupList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_MENU_GROUP_LIST",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shopCd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    MenuGroupList s = new MenuGroupList
                    {
                        menuGroupCd = rd["MENU_GROUP_CD"].ToString(),
                        menuGroupName = rd["MENU_GROUP_NAME"].ToString(),
                        menuNames = rd["MENU_NAMES"].ToString(),
                        useYn = rd["USE_YN"].ToString(),
                        mainCount = rd["MAIN_COUNT"].ToString(),

                    };

                    menuGroupList.Add(s);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuGroup : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = menuGroupList });
        }

        [HttpPost]
        public async Task<IActionResult> Post(MenuGroup menuGroup)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.ADD_MENU_GROUP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = menuGroup.shopCd;
            cmd.Parameters.Add("in_group_name", OracleDbType.Varchar2, 50).Value = menuGroup.menuGroupName;
            cmd.Parameters.Add("in_group_memo", OracleDbType.Varchar2, 500).Value = menuGroup.menuGroupMemo;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 1).Value = menuGroup.useYn;
            cmd.Parameters.Add("in_insert_name", OracleDbType.Varchar2, 30).Value = menuGroup.insertName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuGroup : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpGet("{menu_group_cd}")]
        public async Task<IActionResult> GetMenuGroupDetail(string menu_group_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_MENU_GROUP_DETAIL",
            };

            cmd.Parameters.Add("in_menu_group_cd", OracleDbType.Int32).Value = menu_group_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            MenuGroup menuGroup = new MenuGroup();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                menuGroup.menuGroupCd = rd["MENU_GROUP_CD"].ToString();
                menuGroup.menuGroupName = rd["MENU_GROUP_NAME"].ToString();
                menuGroup.menuGroupMemo = rd["MENU_GROUP_MEMO"].ToString();
                menuGroup.useYn = rd["USE_YN"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuGroup/menu_group_cd : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = menuGroup });
        }


        [HttpPut]
        public async Task<IActionResult> Put(MenuGroup menuGroup)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.UPDATE_MENU_GROUP",
            };

            //cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = menuGroup.shopCd;
            cmd.Parameters.Add("in_group_cd", OracleDbType.Varchar2, 10).Value = menuGroup.menuGroupCd;
            cmd.Parameters.Add("in_group_name", OracleDbType.Varchar2, 50).Value = menuGroup.menuGroupName;
            cmd.Parameters.Add("in_group_memo", OracleDbType.Varchar2, 500).Value = menuGroup.menuGroupMemo;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Char, 1).Value = menuGroup.useYn;
            cmd.Parameters.Add("in_insert_name", OracleDbType.Varchar2, 30).Value = menuGroup.insertName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuGroup : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        
    }
}
