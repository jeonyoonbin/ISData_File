﻿using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class MenuOptionGroupController : ControllerBase
    {
        [HttpGet("{menu_cd}")]
        public async Task<IActionResult> GetOptionGroupList(string menu_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<OptionGroupList> optionGroupList = new List<OptionGroupList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_MENU_OPTION_GROUP",
            };

            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = menu_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    OptionGroupList m = new OptionGroupList
                    {
                        menuOptionGroupCd = rd["MENU_OPTION_GROUP_CD"].ToString(),
                        optionGroupCd = rd["OPTION_GROUP_CD"].ToString(),
                        optionGroupName = rd["OPTION_GROUP_NAME"].ToString(),
                        optionNames = rd["OPTION_NAMES"].ToString(),
                    };

                    optionGroupList.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuOptionGroup/{menu_cd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = optionGroupList });
        }


        [HttpDelete("{menu_option_group_cd}")]
        public async Task<IActionResult> Delete(string menu_option_group_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.DELETE_MENU_OPTION_GROUP",
            };

            cmd.Parameters.Add("in_menu_option_group_cd", OracleDbType.Int32).Value = menu_option_group_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuOptionGroup/{menu_option_group_cd} : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpPost]
        public async Task<IActionResult> Post(string menuCd, IEnumerable<string> optionGroupCd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.SET_MENU_OPTION_GROUP",
            };

            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = menuCd;
            cmd.Parameters.Add("in_count", OracleDbType.Int32).Value = optionGroupCd.Count();

            
            var arroptionGroupCd = cmd.Parameters.Add("in_option_group_cd", OracleDbType.Int32);
            arroptionGroupCd.Direction = ParameterDirection.Input;
            arroptionGroupCd.CollectionType = OracleCollectionType.PLSQLAssociativeArray;

            arroptionGroupCd.IsNullable = true;



            //arroptionGroupCd.ArrayBindSize = new int[optionGroupCd.Count()]; // Enumerable.Repeat(0, 0).ToArray();
            //arroptionGroupCd.ArrayBindStatus = new OracleParameterStatus[optionGroupCd.Count()];
            //arroptionGroupCd.Size = optionGroupCd.Count();
            //arroptionGroupCd.Value = optionGroupCd.ToArray();


            if (optionGroupCd.Count() > 0)
            {
                arroptionGroupCd.Value = optionGroupCd.ToArray();
                arroptionGroupCd.ArrayBindSize = optionGroupCd.Select(_ => _.Length).ToArray();
                arroptionGroupCd.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, optionGroupCd.Count()).ToArray();
                arroptionGroupCd.Size = optionGroupCd.Count();
            }
            else
            {
                
                arroptionGroupCd.ArrayBindSize = new int[0]; // Enumerable.Repeat(0, 0).ToArray();
                arroptionGroupCd.ArrayBindStatus = new OracleParameterStatus[] { OracleParameterStatus.Truncation };
                arroptionGroupCd.Size = 0;
                arroptionGroupCd.Value = System.DBNull.Value; // new OracleDecimal[] { OracleDecimal.Null };
            }

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/MenuOptionGroup : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

    }
}
