﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class OptionController : ControllerBase
    {
        [HttpGet("optionList/{option_group_cd}")]
        public async Task<IActionResult> GetOptionList(string option_group_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<OptionList> optionList = new List<OptionList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_MENU_OPTION_LIST",
            };

            cmd.Parameters.Add("in_option_group_cd", OracleDbType.Int32).Value = option_group_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    OptionList m = new OptionList
                    {
                        optionCd = rd["OPTION_CD"].ToString(),
                        name = rd["OPTION_NAME"].ToString(),
                        memo = rd["OPTION_MEMO"].ToString(),
                        fileName = rd["OMENU_FILE_NAME"].ToString(),
                        cost = rd["OCOST"].ToString(),
                        useYn = rd["USE_YN"].ToString(),
                        noFlag = rd["O_NO_FLAG"].ToString(),
                        adultOnly = rd["ADULT_ONLY"].ToString(),
                    };

                    optionList.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Option/optionList/{option_group_cd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = optionList });
        }


        [HttpPost]
        public async Task<IActionResult> Post(MenuOption menuOption)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.ADD_MENU_OPTION",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = menuOption.shopCd;
            cmd.Parameters.Add("in_group_cd", OracleDbType.Int32).Value = menuOption.optionGroupCd;
            cmd.Parameters.Add("in_option_name", OracleDbType.Varchar2, 50).Value = menuOption.optionName;
            cmd.Parameters.Add("in_option_memo", OracleDbType.Varchar2, 500).Value = menuOption.optionMemo;
            cmd.Parameters.Add("in_cost", OracleDbType.Int32).Value = menuOption.cost;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 1).Value = menuOption.useYn;
            cmd.Parameters.Add("in_no_flag", OracleDbType.Varchar2, 1).Value = menuOption.noFlag;
            cmd.Parameters.Add("in_adult_only", OracleDbType.Varchar2, 1).Value = menuOption.adultOnly;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 30).Value = menuOption.insertName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Option : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }



        [HttpPut]
        public async Task<IActionResult> Put(MenuOption menuOption)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.UPDATE_MENU_OPTION",
            };

            cmd.Parameters.Add("in_option_cd", OracleDbType.Int32).Value = menuOption.optionCd;
            cmd.Parameters.Add("in_option_name", OracleDbType.Varchar2, 50).Value = menuOption.optionName;
            cmd.Parameters.Add("in_option_memo", OracleDbType.Varchar2, 500).Value = menuOption.optionMemo;
            cmd.Parameters.Add("in_cost", OracleDbType.Int32).Value = menuOption.cost;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 1).Value = menuOption.useYn;
            cmd.Parameters.Add("in_no_flag", OracleDbType.Varchar2, 1).Value = menuOption.noFlag;
            cmd.Parameters.Add("in_adult_only", OracleDbType.Varchar2, 1).Value = menuOption.adultOnly;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 30).Value = menuOption.insertName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Option : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpDelete("{option_cd}")]
        public async Task<IActionResult> Delete(string option_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.DELETE_MENU_OPTION",
            };

            cmd.Parameters.Add("in_option_cd", OracleDbType.Int32).Value = option_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Option : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpGet("{option_cd}")]
        public async Task<IActionResult> Get(string option_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_MENU_OPTION_DETAIL",
            };

            cmd.Parameters.Add("in_option_cd", OracleDbType.Int32).Value = option_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            MenuOption menuOption = new MenuOption();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                menuOption.optionCd = rd["OPTION_CD"].ToString();
                menuOption.optionName = rd["OPTION_NAME"].ToString();
                menuOption.optionMemo = rd["OPTION_MEMO"].ToString();
                menuOption.cost = rd["OCOST"].ToString();
                menuOption.useYn = rd["USE_YN"].ToString();
                menuOption.noFlag = rd["O_NO_FLAG"].ToString();
                menuOption.adultOnly = rd["ADULT_ONLY"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Option/option_cd : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = menuOption });
        }
        
        /// <summary>
        /// 메뉴옵션 변경이력
        /// </summary>
        /// <remarks>
        /// OPTION_GROUP_NAME 옵션그룹명 <br/>
        /// OPTION_NAME 옵션명 <br/>
        /// MOD_TIME 변경일시 <br/>
        /// MOD_DESC 변경내용 <br/>
        /// </remarks>
        [HttpGet("history/{shop_cd}")]
        public async Task<IActionResult> history(string shop_cd, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT og.option_group_name, o.option_name, t2.mod_time, t2.mod_desc
                                FROM (select ROWNUM as NO, T1.*
                                from(select option_cd, mod_time, mod_desc from menu_option_list_log
                                where shop_cd = :shop_cd
                                order by logno desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2, menu_option_list o, menu_option_groupcd og
                                WHERE ((:in_page - 1) * :in_rows) < NO
                                and t2.option_cd = o.option_cd (+)
                                and o.option_group_cd = og.option_group_cd (+)
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = items.Count.ToString(), data = items });
        }
    }
}
