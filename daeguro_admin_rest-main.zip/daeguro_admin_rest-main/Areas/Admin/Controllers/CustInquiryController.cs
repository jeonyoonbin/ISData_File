﻿using Dapper;
using ClosedXML.Excel;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Linq;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [ApiController]
    [Route("/[controller]")]
    public class CustInquiryController : ControllerBase
    {
        string nasPath = @"\\10.10.10.100\dgnas\Files"; 
        string serviceRequestPath = @"\\10.10.10.100\dgnas\Files\RequestServiceImage\CanCellation";

        /// <summary>
        /// 고객소리함 서비스 목록
        /// </summary>
        /// <remarks>
        /// use_gbn 사용여부(Y/N) <br/>
        /// [response] <br/>
        /// service_gbn 서비스 구분 <br/>
        /// service_name 서비스명 <br/>
        /// use_gbn 사용여부(Y/N) <br/>
        /// </remarks>
        [HttpGet("getService")]
        public async Task<IActionResult> getService(string use_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("use_gbn", use_gbn);

                string sql = $@"select service_gbn ""service_gbn"", service_name ""service_name"", use_gbn ""use_gbn""
                                from CUST_INQUIRY_SERVICE
                                WHERE USE_GBN LIKE CASE WHEN :use_gbn IS NULL THEN '%' ELSE :use_gbn END
                                order by sort_seq
                ";

                db.Open();

                Rdata = await db.QueryAsync<object>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/CustInquiry/getService : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 고객소리함 문의구분
        /// </summary>
        /// <remarks>
        /// service_gbn 서비스구분 <br/>
        /// use_gbn 사용여부(Y/N) <br/>
        /// [response] <br/>
        /// inquiry_gbn 문의구분 <br/>
        /// inquiry_name 문의구분명 <br/>
        /// </remarks>
        [HttpGet("getType")]
        public async Task<IActionResult> getType(string service_gbn, string use_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("service_gbn", service_gbn);
                param.Add("use_gbn", use_gbn);

                string sql = $@" SELECT inquiry_gbn ""inquiry_gbn"", inquiry_name ""inquiry_name""
                                FROM(select inquiry_gbn, inquiry_name, to_number(inquiry_gbn) sort_seq
                                    from CUST_INQUIRY_TYPE
                                    where :service_gbn is null
                                    and use_gbn like case when :use_gbn is null then '%' else :use_gbn end
                                    group by inquiry_gbn, inquiry_name
                                    union all
                                    select inquiry_gbn, inquiry_name, sort_seq
                                    from CUST_INQUIRY_TYPE
                                    where service_gbn = :service_gbn
                                    and use_gbn like case when :use_gbn is null then '%' else :use_gbn end
                                    order by sort_seq)
                ";

                db.Open();

                Rdata = await db.QueryAsync<object>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/CustInquiry/getType : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 고객소리함 목록조회
        /// </summary>
        /// <remarks>
        /// service_gbn 서비스구분(빈값 : 전체) <br/>
        /// inquiry_gbn 문의구분(빈값 : 전체) <br/>
        /// keyword 내용검색 <br/>
        /// [response] <br/>
        /// seqno 건의번호  <br/>
        /// service_name 서비스 구분 <br/>
        /// inquiry_name 요청구분 <br/>
        /// contents 내용(일단 50글자 초과시 49자에서 자르고 ...처리) <br/>
        /// ins_date 요청시간 <br/>
        /// </remarks>
        [HttpGet("getList")]
        public async Task<IActionResult> getList(string service_gbn, string inquiry_gbn, string date_begin, string date_end, string keyword, string page, string rows)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<CustInquiryList> Rdata = new List<CustInquiryList>();

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))// 시작일 종료일 필수
            {
                Rcode = "99";
                Rmsg = "시작일 종료일은 필수입니다.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_CS.GET_CUST_INQUIRY_LIST",
                };

                cmd.Parameters.Add("in_service_gbn", OracleDbType.Varchar2, 50).Value = service_gbn;
                cmd.Parameters.Add("in_inquiry_gbn", OracleDbType.Varchar2, 2).Value = inquiry_gbn;
                cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
                cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 1000).Value = keyword;
                cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
                cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
                cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    CustInquiryList item = new CustInquiryList
                    {
                        seqno = rd["seqno"].ToString(),
                        service_name = rd["service_name"].ToString(),
                        inquiry_name = rd["inquiry_name"].ToString(),
                        contents = rd["contents"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                    };

                    Rdata.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = Rdata });
        }


        /// <summary>
        /// 고객소리함 엑셀출력
        /// </summary>
        /// <remarks>
        /// service_gbn 서비스구분(빈값 : 전체) <br/>
        /// inquiry_gbn 문의구분(빈값 : 전체) <br/>
        /// keyword 내용검색 <br/>
        /// ucode 작업자코드(필수) <br/>
        /// download_reason 다운로드 사유(필수) <br/>
        /// [response] <br/>
        /// seqno 건의번호 <br/>
        /// service_name 서비스 구분 <br/>
        /// inquiry_name 요청구분 <br/>
        /// inquiry_name 요청구분 <br/>
        /// inquiry_name 요청구분 <br/>
        /// contents 내용 <br/>
        /// ins_date 요청시간 <br/>
        /// 다운로드로그 추가 <br/>
        /// </remarks>
        [HttpGet("ExcelExport")]
        public async Task<IActionResult> ExcelExport(string service_gbn, string inquiry_gbn, string date_begin, string date_end, string keyword, string ucode, string download_reason)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/CustInquiry/ExcelExport";

            if (string.IsNullOrEmpty(ucode))
            {
                Rmsg = "조회자 코드는 필수입니다.";
            }
            else if (download_reason.Length < 10)
            {
                Rmsg = "다운로드 사유는 10글자 이상이어야 합니다.";
            }
            else if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))// 시작일 종료일 필수
            {
                Rmsg = "시작일 종료일은 필수입니다.";
            }

            if(!string.IsNullOrEmpty(Rmsg))
            {
                Rcode = "99";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_CS.EXPORT_CUST_INQUIRY_EXCEL",
                };

                cmd.Parameters.Add("in_service_gbn", OracleDbType.Varchar2, 50).Value = service_gbn;
                cmd.Parameters.Add("in_inquiry_gbn", OracleDbType.Varchar2, 2).Value = inquiry_gbn;
                cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
                cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 1000).Value = keyword;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                if (!Rcode.Equals("00"))
                {
                    Rcode = "99";
                    Rmsg = "조회실패";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("고객소리함");
                    var currentRow = 1;
                    var col = 1;
                    // 엑셀 데이터서식을 text로 설정
                    worksheet.Style.NumberFormat.Format = "@";

                    worksheet.Cell(currentRow, col++).Value = "건의번호";
                    worksheet.Cell(currentRow, col++).Value = "서비스 구분";
                    worksheet.Cell(currentRow, col++).Value = "요청구분";
                    worksheet.Cell(currentRow, col++).Value = "운영체제";
                    worksheet.Cell(currentRow, col++).Value = "기기 모델";
                    worksheet.Cell(currentRow, col++).Value = "앱버전";
                    worksheet.Cell(currentRow, col++).Value = "문의내용";
                    worksheet.Cell(currentRow, col++).Value = "요청일시";

                    while (await rd.ReadAsync())
                    {
                        currentRow++;
                        col = 1;

                        worksheet.Cell(currentRow, col++).Value = rd["seqno"].ToString();
                        worksheet.Cell(currentRow, col++).Value = rd["service_name"].ToString();
                        worksheet.Cell(currentRow, col++).Value = rd["inquiry_name"].ToString();
                        worksheet.Cell(currentRow, col++).Value = rd["os_version"].ToString();
                        worksheet.Cell(currentRow, col++).Value = rd["device_model"].ToString();
                        worksheet.Cell(currentRow, col++).Value = rd["app_version"].ToString();
                        worksheet.Cell(currentRow, col++).Value = rd["contents"].ToString();
                        worksheet.Cell(currentRow, col++).Value = rd["ins_date"].ToString();

                    }

                    worksheet.Columns().AdjustToContents();
                    //worksheet.Rows().AdjustToContents();

                    await rd.CloseAsync();
                    await conn.CloseAsync();

                    //엑셀파일 다운로드 로그 기록
                    string memo = "고객소리함 엑셀파일 다운로드 - " + (currentRow - 1).ToString() + "건\n" + Rmsg + "\n검색내용: " + keyword + "\n다운로드 사유: " + download_reason;
                    string pid = string.Empty;

                    if(Utils.serverGbn == "T")
                    {
                        pid = "284";
                    }
                    else if (Utils.serverGbn == "R")
                    {
                        pid = "285";
                    }

                    await Utils.setPrivacyLog(ucode, pid, "40", memo, Rposition);

                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        return File(content, "application/octet-stream", "CustInquiry.xlsx");
                    }
                }
            }
            catch (Exception ex)
            {

                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg});
        }

        /// <summary>
        /// 고객소리함 상세조회
        /// </summary>
        /// <remarks>
        /// service_gbn 서비스구분(빈값 : 전체) <br/>
        /// inquiry_gbn 문의구분(빈값 : 전체) <br/>
        /// keyword 내용검색 <br/>
        /// [response] <br/>
        /// seqno 건의번호  <br/>
        /// service_gbn 서비스 구분 <br/>
        /// service_name 서비스 구분명 <br/>
        /// inquiry_gbn 요청구분 <br/>
        /// inquiry_name 요청구분명 <br/>
        /// os_type 운영체제 종류 <br/>
        /// os_version 운영체제 버전 <br/>
        /// device_model 기기 모델 <br/>
        /// app_version 앱 버전 <br/>
        /// contents 내용 <br/>
        /// ins_date 요청시간 <br/>
        /// cust_code 회원번호(조회X 이미지경로용) <br/>
        /// img_file1,2,3,4,5 이미지 경로 <br/>
        ///  테스트 : https://dgpub.282.co.kr:8500/InquiryImage/{cust_code}/{img_file} <br/>
        ///  운영 : https://admin.daeguro.co.kr/inquiry-images/{cust_code}/{img_file} <br/>
        /// 조회로그 추가 <br/>
        /// </remarks>
        [HttpGet("getDetail")]
        public async Task<IActionResult> getDetail(string seqno, string ucode)
        {
            string Rposition = "/CustInquiry/getDetail : Get";
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            CustInquiryDetail Rdata = new CustInquiryDetail();

            if (string.IsNullOrEmpty(ucode))
            {
                Rcode = "99";
                Rmsg = "조회자 코드는 필수입니다.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_CS.GET_CUST_INQUIRY",
                };

                cmd.Parameters.Add("in_seqno", OracleDbType.Int32).Value = seqno;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();
                
                Rdata.seqno = rd["seqno"].ToString();
                Rdata.service_gbn = rd["service_gbn"].ToString();
                Rdata.service_name = rd["service_name"].ToString();
                Rdata.inquiry_gbn = rd["inquiry_gbn"].ToString();
                Rdata.inquiry_name = rd["inquiry_name"].ToString();
                Rdata.os_type = rd["os_type"].ToString();
                Rdata.os_version = rd["os_version"].ToString();
                Rdata.device_model = rd["device_model"].ToString();
                Rdata.app_version = rd["app_version"].ToString();
                Rdata.contents = rd["contents"].ToString();
                Rdata.ins_date = rd["ins_date"].ToString();
                Rdata.cust_code = rd["cust_code"].ToString();
                Rdata.img_file1 = rd["img_file1"].ToString();
                Rdata.img_file2 = rd["img_file2"].ToString();
                Rdata.img_file3 = rd["img_file3"].ToString();
                Rdata.img_file4 = rd["img_file4"].ToString();
                Rdata.img_file5 = rd["img_file5"].ToString();
                
                await rd.CloseAsync();
                await conn.CloseAsync();

                //조회로그 기록
                string pid = string.Empty;

                if (Utils.serverGbn == "T")
                {
                    pid = "284";
                }
                else if (Utils.serverGbn == "R")
                {
                    pid = "285";
                }

                await Utils.setPrivacyLog(ucode, pid, "10", seqno, Rposition);

            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

    }
}
