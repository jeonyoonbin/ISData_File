﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class B2BCouponController : ControllerBase
    {
        /// <summary>
        /// 제휴 쿠폰 관리 - 목록 조회
        /// </summary>
        /// <remarks>
        /// return data <br />
        /// pub: 발행/ giv: 고객발급/ use: 사용/ exp: 만료/ del: 폐기
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string couponType, string couponStatus, string keyword, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            string Rpub = string.Empty;
            string Rgiv = string.Empty;
            string Ruse = string.Empty;
            string Rexp = string.Empty;
            string Rdel = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_B2B_COUPON.GET_COUPON_LIST",
            };

            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_state", OracleDbType.Char, 2).Value = couponStatus;
            cmd.Parameters.Add("in_keyword", OracleDbType.Char, 50).Value = keyword;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_pub", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_giv", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_use", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_exp", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_del", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rpub = cmd.Parameters["out_pub"].Value.ToString();
                Rgiv = cmd.Parameters["out_giv"].Value.ToString();
                Ruse = cmd.Parameters["out_use"].Value.ToString();
                Rexp = cmd.Parameters["out_exp"].Value.ToString();
                Rdel = cmd.Parameters["out_del"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    CouponList m = new CouponList
                    {
                        couponType = rd["COUPON_TYPE"].ToString(),
                        couponName = rd["COUPON_NAME"].ToString(),
                        couponNo = rd["COUPON_NO"].ToString(),
                        randomNo = rd["RANDOM_NO"].ToString(),
                        barCode = rd["BARCODE"].ToString(),
                        status = rd["STATUS"].ToString(),
                        appCustCode = rd["APP_CUST_CODE"].ToString(),
                        custName = rd["CUST_NAME"].ToString(),
                        telNo = rd["TELNO"].ToString(),
                        useAppCustCode = rd["USE_APP_CUST_CODE"].ToString(),
                        useCustName = rd["USE_CUST_NAME"].ToString(),
                        useTelNo = rd["USE_TELNO"].ToString(),
                        orderDate = rd["ORDER_DATE"].ToString(),
                        orderNo = rd["ORDER_NO"].ToString(),
                        shopName = rd["SHOP_NAME"].ToString(),
                        useDate = rd["USE_DATE"].ToString(),
                        couponAmt = rd["COUPON_AMT"].ToString(),
                        linkUrl = rd["LINK_URL"].ToString(),
                        insDate = rd["INS_DATE"].ToString(),
                        insUCode = rd["INS_UCODE"].ToString(),
                        insName = rd["INS_NAME"].ToString(),
                        expDate = rd["EXP_DATE"].ToString(),
                        stDate = rd["ST_DATE"].ToString(),
                        confYN = rd["CONF_YN"].ToString(),
                        confDate = rd["CONF_DATE"].ToString(),
                        confUCode = rd["CONF_UCODE"].ToString(),
                        confName = rd["CONF_NAME"].ToString(),
                    };

                    coupons.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BCoupon : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, pub = Rpub, giv = Rgiv, use = Ruse, exp = Rexp, del = Rdel, data = coupons });
        }


        //b2b 쿠폰 변경이력 조회
        [HttpGet("history/{couponNo}")]
        public async Task<IActionResult> GetHistory(string couponNo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_B2B_COUPON.GET_COUPON_HISTORY",
            };

            cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 50).Value = couponNo;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<CouponHistory> couponHistories = new List<CouponHistory>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while(await rd.ReadAsync())
                { 
                    CouponHistory couponHistory = new CouponHistory
                    {
                        SeqNo = rd["SEQNO"].ToString(),
                        couponType = rd["COUPON_TYPE"].ToString(),
                        couponNo = rd["COUPON_NO"].ToString(),
                        histDate = rd["HIST_DATE"].ToString(),
                        memo = rd["MEMO"].ToString(),
                    };

                    couponHistories.Add(couponHistory);
                }
                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BCoupon/history/couponNo : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = couponHistories });
        }


        /// <summary>
        /// 제휴쿠폰 종류 조회
        /// </summary>
        [HttpGet("couponCode")]
        public async Task<IActionResult> GetCouponCode()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_B2B_COUPON.GET_COUPON_CODE",
            };

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<CouponCode> couponCodes = new List<CouponCode>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    CouponCode couponCode = new CouponCode
                    {
                        code = rd["CODE"].ToString(),
                        codeName = rd["CODE_NM"].ToString(),
                    };

                    couponCodes.Add(couponCode);
                }
                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BCoupon/couponCode : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = couponCodes });
        }


        /// <summary>
        /// 제휴쿠폰 종류별 하부 아이템 종류 조회
        /// </summary>
        [HttpGet("getCouponItemCode")]
        public async Task<IActionResult> getCouponItemCode(string couponType)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_coupon_type", couponType);


                string sql = $@"
                                  SELECT ITEM_CD, ITEM_NM
                                   FROM B2B_COUPON_ITEM 
                                   WHERE COUPON_TYPE = :in_coupon_type
                                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/B2BCoupon/getCouponItemCode : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        //b2b쿠폰 상세조회
        [HttpGet("{couponNo}")]
        public async Task<IActionResult> Get(string couponNo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_B2B_COUPON.GET_COUPON_DETAIL",
            };

            //OracleParameter op = new OracleParameter();
            //op.OracleDbType = OracleDbType.RefCursor;
            //op.Direction = ParameterDirection.Output;

            cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 50).Value = couponNo;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            CouponList coupon = new CouponList();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                coupon.couponType = rd["COUPON_TYPE"].ToString();
                coupon.couponName = rd["COUPON_NAME"].ToString();
                coupon.couponNo = rd["COUPON_NO"].ToString();
                coupon.randomNo = rd["RANDOM_NO"].ToString();
                coupon.barCode = rd["BARCODE"].ToString();
                coupon.status = rd["STATUS"].ToString();
                coupon.appCustCode = rd["APP_CUST_CODE"].ToString();
                coupon.custName = rd["CUST_NAME"].ToString();
                coupon.telNo = rd["TELNO"].ToString();
                coupon.useAppCustCode = rd["USE_APP_CUST_CODE"].ToString();
                coupon.useCustName = rd["USE_CUST_NAME"].ToString();
                coupon.useTelNo = rd["USE_TELNO"].ToString();
                coupon.orderDate = rd["ORDER_DATE"].ToString();
                coupon.orderNo = rd["ORDER_NO"].ToString();
                coupon.useDate = rd["USE_DATE"].ToString();
                coupon.couponAmt = rd["COUPON_AMT"].ToString();
                coupon.linkUrl = rd["LINK_URL"].ToString();
                coupon.insDate = rd["INS_DATE"].ToString();
                coupon.insUCode = rd["INS_UCODE"].ToString();
                coupon.insName = rd["INS_NAME"].ToString();
                coupon.expDate = rd["EXP_DATE"].ToString();
                coupon.confYN = rd["CONF_YN"].ToString();
                coupon.confDate = rd["CONF_DATE"].ToString();
                coupon.confUCode = rd["CONF_UCODE"].ToString();
                coupon.confName = rd["CONF_NAME"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BCoupon/couponNo : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = coupon });
        }


        /// <summary>
        /// 제휴쿠폰 생성
        /// </summary>
        /// <remarks>
        /// 제휴쿠폰 생성시 사용만료일 기입(expDate)
        /// </remarks>
        [HttpPost]
        public async Task<IActionResult> Post(string couponType, string itemType, string title, string expDate, int couponCount, int insertUcode, string insertName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_B2B_COUPON.SET_COUPON_MST",
            };

            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_item_type", OracleDbType.Varchar2, 20).Value = itemType;
            cmd.Parameters.Add("in_title", OracleDbType.Varchar2, 80).Value = title;
            cmd.Parameters.Add("in_exp_date", OracleDbType.Varchar2, 80).Value = expDate;
            cmd.Parameters.Add("in_coupon_cnt", OracleDbType.Int32).Value = couponCount;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = insertUcode;
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 50).Value = insertName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BCoupon : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 제휴쿠폰 일괄 승인 및 폐기
        /// </summary>
        [HttpPut]
        public async Task<IActionResult> Put(string couponType, string itemType, string couponCount, string oldStatus, string newStatus, string jobUcode, string jobName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_B2B_COUPON.SET_COUPON_MST_STATUS",
            };

            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_item_type", OracleDbType.Varchar2, 20).Value = itemType;
            cmd.Parameters.Add("in_coupon_cnt", OracleDbType.Int32).Value = couponCount;
            cmd.Parameters.Add("in_old_status", OracleDbType.Varchar2, 2).Value = oldStatus;
            cmd.Parameters.Add("in_new_status", OracleDbType.Varchar2, 2).Value = newStatus;

            cmd.Parameters.Add("in_job_ucode", OracleDbType.Int32).Value = jobUcode;
            cmd.Parameters.Add("in_job_name", OracleDbType.Varchar2, 50).Value = jobName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BCoupon : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        // b2b 쿠폰 발행/사용 현황
        [HttpGet("getCouponHistory")]
        public async Task<IActionResult> getCouponHistory(string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalCount = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = @"
                                SELECT t2.status,
                                   t2.coupon_name,
                                   t2.coupon_no,
                                   t2.order_no,
                                   t2.order_date,
                                   t2.ins_date,
                                   t2.st_date,
                                   t2.exp_date,
                                   t2.coupon_amt,
                                   t2.shop_name
                              FROM(SELECT ROWNUM AS RNUM,
                                           t1.*
                                      FROM(SELECT DECODE(a.status, '00', '대기', '10', '승인', '20', '발행(고객)', '30', '사용(고객)', '99', '폐기') status,
                                                   a.coupon_name,
                                                   a.coupon_no,
                                                   a.order_no,
                                                   a.order_date,
                                                   a.ins_date,
                                                   a.st_date,
                                                   a.exp_date,
                                                   a.coupon_amt,
                                                   c.shop_name
                                              FROM b2b_coupon_mst a,
                                                   (SELECT *
                                                      FROM dorder
                                                      where TEST_GBN = 'N'
                                                      AND NVL(CANCEL_CODE, '00') <> '30'
                                                     UNION ALL
                                                    SELECT *
                                                      FROM dorder_past
                                                      where TEST_GBN = 'N'
                                                      AND NVL(CANCEL_CODE, '00') <> '30') b,
                                                   shop_info c
                                             WHERE nvl(a.order_no, 0) = b.order_no(+)
                                               AND nvl(b.shop_cd, 0) = c.shop_cd(+)
                                               AND a.order_date BETWEEN: date_begin AND: date_end
                                               order by a.use_date desc
                                             ) t1
                                     WHERE ROWNUM <= (( : page - 1) * :row_count) + :row_count) t2
                             WHERE(( : page - 1) * :row_count) < RNUM
                ";


                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                sql = @"
                        SELECT count(*)
                        FROM b2b_coupon_mst 
                        WHERE order_date BETWEEN: date_begin AND: date_end
                ";

                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, data = items });
        }



        /// <summary>
        /// 제휴쿠폰 고객발행, 사용, 사용취소, 발행취소
        /// </summary>
        [HttpPut("setCouponAppCustomer")]
        public async Task<IActionResult> setCouponAppCustomer(string modUcode, string custCode, string couponType, string couponNo, string status)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RcouponNo = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_B2B_COUPON.SET_COUPON_APP_CUSTOMER",
            };

            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = modUcode;
            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_cust_code", OracleDbType.Int32).Value = custCode;
            cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 1000).Value = couponNo;
            cmd.Parameters.Add("in_new_status", OracleDbType.Varchar2, 2).Value = status;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_coupon", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["OUT_RET_CODE"].Value.ToString();
                Rmsg = cmd.Parameters["OUT_RET_MSG"].Value.ToString();
                RcouponNo = cmd.Parameters["OUT_RET_COUPON"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/B2BCoupon/setCouponAppCustomer : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, couponNo = RcouponNo });
        }



        /// <summary>
        /// 제휴쿠폰 사용기한 조회
        /// </summary>
        [HttpGet("getPeriod")]
        public async Task<IActionResult> getPeriod(string couponType)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            object item = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("coupon_type", couponType);

                string sql = @"
                                select nvl(etc_code1,' ') as exp_date
                                from etc_code
                                where code_grp = 'B2BCOUPON_TYPE'
                                AND code = :coupon_type
                ";

                item = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/B2BCoupon/getPeriod : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }


        /// <summary>
        /// 제휴쿠폰 count 및 사용기한 조회
        /// </summary>
        [HttpGet("getCount")]
        public async Task<IActionResult> getCount(string couponType)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> item = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("coupon_type", couponType);

                string sql = @"
                                select a.*, C.MEMO, C.ITEM_NM FROM(select coupon_type, s_etc_gbn2, max(exp_date) as exp_date,
                                COUNT(case when status in ('20','30') then 1 end) as total,
                                COUNT(case when status = '30' then 1 end) as use,
                                COUNT(case when status = '20' then 1 end) as left
                                from b2b_coupon_mst
                                group by coupon_type, s_etc_gbn2) A, ETC_CODE B, B2B_COUPON_ITEM C
                                WHERE A.COUPON_TYPE = B.CODE
                                AND A.s_etc_gbn2 = C.ITEM_CD
                                and a.coupon_type = :coupon_type
                                AND B.CODE_GRP = 'B2BCOUPON_TYPE'
                                and a.exp_date >= to_char(sysdate,'YYYYMMDD')
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);
                item = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/B2BCoupon/getCount : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

    }
}
