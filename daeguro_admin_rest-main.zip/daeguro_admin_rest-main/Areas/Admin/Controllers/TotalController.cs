﻿using ClosedXML.Excel;
using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class TotalController : ControllerBase
    {

        #region[전체현황]
        /// <summary>
        /// 전체현황 - 전체 가맹점 현황 *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// totalShopCount 전체 가맹점 <br/>
        /// newShopCount 신규 가맹점 <br/>
        /// useShopCount 운영 가맹점 <br/>
        /// stopShopCount 미윤영 가맹점 <br/>
        /// totalShopCountR 예약 전체 가맹점 <br/>
        /// newShopCountR 예약 신규 가맹점 <br/>
        /// useShopCountR 예약 운영 가맹점 <br/>
        /// stopShopCountR 예약 미윤영 가맹점 <br/>
        /// 집계테이블 꽃배달 분리, 주문과 합쳐서 조회처리
        /// </remarks>
        [HttpGet("getShopCount")]
        public async Task<IActionResult> getShopCount()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            ShopCount2 totalOrders = new ShopCount2();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                //param.Add("in_div", div);

                // 전체, 신규, 운영, 미운영
                string sql = @"
                                SELECT to_char(SUM(CASE WHEN shop_type_gbn in ('D','F') and SHOP_STATUS IS NULL THEN CNT END)) totalShopCount,
                                       to_char(SUM(CASE WHEN shop_type_gbn in ('D','F') and SHOP_STATUS = 'O' THEN CNT END)) newShopCount,
                                       to_char(SUM(CASE WHEN shop_type_gbn in ('D','F') and SHOP_STATUS = 'Y' THEN CNT END)) useShopCount,
                                       to_char(SUM(CASE WHEN shop_type_gbn in ('D','F') and SHOP_STATUS = 'N' THEN CNT END)) stopShopCount,
                                       to_char(SUM(CASE WHEN shop_type_gbn = 'R' and SHOP_STATUS IS NULL THEN CNT END)) totalShopCountR,
                                       to_char(SUM(CASE WHEN shop_type_gbn = 'R' and SHOP_STATUS = 'O' THEN CNT END)) newShopCountR,
                                       to_char(SUM(CASE WHEN shop_type_gbn = 'R' and SHOP_STATUS = 'Y' THEN CNT END)) useShopCountR,
                                       to_char(SUM(CASE WHEN shop_type_gbn = 'R' and SHOP_STATUS = 'N' THEN CNT END)) stopShopCountR
                                FROM(SELECT shop_type_gbn, SHOP_STATUS, SUM(SHOP_STATUS_CNT) CNT
                                    FROM DGR_SHOP_TOTAL
                                    where shop_type_gbn in ('D','R','F')
                                    GROUP BY shop_type_gbn, CUBE(SHOP_STATUS)
                                    UNION ALL
                                    SELECT 'D' shop_type_gbn, 'O' SHOP_STATUS, COUNT(1) CNT
                                    FROM SHOP_INFO A, CALLCENTER B
                                    WHERE A.CCCODE = B.CCCODE
                                    AND B.MCODE = 2
                                    AND (A.SHOP_TYPE LIKE '%5%' OR A.SHOP_TYPE LIKE '%7%')
                                    AND TO_CHAR(A.OPEN_DT, 'YYYY-MM-DD') = TO_CHAR(SYSDATE, 'YYYY-MM-DD')
                                    UNION ALL
                                    SELECT 'R' shop_type_gbn, 'O' SHOP_STATUS, COUNT(1) CNT
                                    FROM SHOP_INFO A, CALLCENTER B
                                    WHERE A.CCCODE = B.CCCODE
                                    AND B.MCODE = 2
                                    AND A.SHOP_TYPE LIKE '%9%'
                                    AND TO_CHAR(A.OPEN_DT, 'YYYY-MM-DD') = TO_CHAR(SYSDATE, 'YYYY-MM-DD'))
                ";

                totalOrders = await db.QuerySingleAsync<ShopCount2>(sql, param, commandType: CommandType.Text);

                //totalOrders = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = totalOrders });
        }

        /// <summary>
        /// 전체현황 - 주간 회원 현황 *집계테이블 사용
        /// </summary>
        [HttpGet("getWeekCustomer")]
        public async Task<IActionResult> getWeekCustomer()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();


                string sql = @"
                                select substr(daily_total_date,5,2) || '-' || substr(daily_total_date,7) insert_date,
                                       daily_total_date insert_day,
                                       install_cnt install_count,
                                       new_cust_cnt new_costomer_count
                                from dgr_cust_total
                                where daily_total_date between TO_CHAR (SYSDATE - 7, 'yyyyMMdd')
                                                           and TO_CHAR (SYSDATE - 1, 'yyyyMMdd')
                ";

                //string sql = @"
                //              SELECT /*+index_rs(a APP_CUSTOMER_IDX02) opt_param('optimizer_dynamic_sampling' 0) opt_param('_optimizer_use_feedback','false')*/
                //                     TO_CHAR (a.insert_date, 'MM-dd')
                //                         insert_date,
                //                     TO_CHAR (a.insert_date, 'YYYYMMDD')
                //                         insert_day,
                //                     COUNT (CASE WHEN cust_id_gbn = 'Z' THEN 1 ELSE NULL END)
                //                         install_count,
                //                     COUNT (CASE WHEN cust_id_gbn <> 'Z' THEN 1 ELSE NULL END)
                //                         new_costomer_count
                //                FROM (SELECT mcode, insert_date, cust_id_gbn, test_gbn FROM app_customer
                //                      UNION ALL
                //                      SELECT mcode,
                //                             insert_date,
                //                             cust_id_gbn,
                //                             test_gbn
                //                        FROM app_customer_deleted) a
                //               WHERE     a.test_gbn = 'R'
                //                     AND a.mcode = 2
                //                     --  AND To_char (a.insert_date, 'yyyyMMdd') BETWEEN To_char (SYSDATE - 7, 'yyyyMMdd') AND To_char (SYSDATE - 1, 'yyyyMMdd')
                //                     AND a.insert_date BETWEEN TO_DATE (TO_CHAR (SYSDATE - 7, 'yyyyMMdd'))
                //                                           AND   TO_DATE (
                //                                                     TO_CHAR (SYSDATE - 1, 'yyyyMMdd'))
                //                                               + 0.99999
                //            GROUP BY TO_CHAR (a.insert_date, 'MM-dd'), TO_CHAR (a.insert_date, 'YYYYMMDD')
                //            ORDER BY TO_CHAR (a.insert_date, 'YYYYMMDD')
                //";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 전체현황 - 주간 회원 현황V2 *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// system_gbn : 시스템 구분 (D: 대구로, T: 택시) (필수)
        /// </remarks>
        [HttpGet("getWeekCustomerV2")]
        public async Task<IActionResult> getWeekCustomerV2(string system_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                DynamicParameters param = new DynamicParameters();
                param.Add("in_system_gbn", system_gbn);
                db.Open();


                string sql = @"
                                select substr(daily_total_date,5,2) || '-' || substr(daily_total_date,7) insert_date,
                                       daily_total_date insert_day,
                                       install_cnt install_count,
                                       new_cust_cnt new_costomer_count
                                from dgr_cust_total_v2
                                where daily_total_date between TO_CHAR (SYSDATE - 7, 'yyyyMMdd')
                                                           and TO_CHAR (SYSDATE - 1, 'yyyyMMdd')
                                 and system_gbn = :in_system_gbn
                                order by daily_total_date
                ";

                var temp = await db.QueryAsync(sql,param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 전체현황 - 주간 주문 완료 현황O *집계테이블 사용 * 미사용
        /// </summary>
        [HttpGet("getWeekOrder")]
        public async Task<IActionResult> getWeekOrder()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();


                string sql = @"
                                select substr(daily_total_date,5,2) || '-' || substr(daily_total_date,7) order_date,
                                       daily_total_date order_day,
                                       order_cnt COUNT,
                                       success_cnt complete_count
                                from dgr_success_order_total2 -- 변경한 테이블
                                where daily_total_date between TO_CHAR (SYSDATE - 7, 'yyyyMMdd')
                                                           and TO_CHAR (SYSDATE - 1, 'yyyyMMdd')
                                order by daily_total_date                        
                ";

                //string sql = @"
                //                  SELECT /*+ leading(A) no_merge(a) no_push_pred(A) opt_param('optimizer_dynamic_sampling' 0) opt_param('_optimizer_use_feedback','false') */
                //                              TO_CHAR(a.order_time, 'MM-dd')
                //                             order_date,
                //                         TO_CHAR(a.order_time, 'YYYYMMDD')
                //                             order_day,
                //                         COUNT(
                //                             CASE WHEN NVL(A.cancel_code, '00') <> '30' THEN 1 ELSE NULL END)
                //                             COUNT,
                //                         COUNT(CASE WHEN a.status = '40' THEN 1 ELSE NULL END)
                //                             complete_count
                //                    FROM(select order_time, cancel_code, status, cccode, test_gbn from dorder
                //                           union all
                //                                                                                  select order_time, cancel_code, status, cccode, test_gbn from dorder_past) a,
                //                          callcenter b
                //                   WHERE a.cccode = b.cccode
                //                         AND b.mcode = 2
                //                         AND a.test_gbn = 'N'
                //                         AND a.order_time BETWEEN TO_DATE(TO_CHAR(SYSDATE - 7, 'yyyyMMdd') || ' 000000', 'YYYYMMDD HH24MISS')
                //                                              AND TO_DATE(TO_CHAR (SYSDATE -1, 'yyyyMMdd')|| ' 235959', 'YYYYMMDD HH24MISS')
                //                GROUP BY TO_CHAR(a.order_time, 'MM-dd'), TO_CHAR(a.order_time, 'YYYYMMDD')
                //                ORDER BY TO_CHAR(a.order_time, 'YYYYMMDD')
                //";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 전체현황 - 주간 주문/예약 완료 현황O *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// DT 월일(MM-DD) <br/>
        /// COUNT 주문건수 <br/>
        /// COMPLETE_COUNT 주문완료건수 <br/>
        /// R_COUNT 예약건수(예약일 기준) <br/>
        /// R_COMPLETE_COUNT 예약완료건수(예약일 기준) <br/>
        /// </remarks>
        [HttpGet("getWeekCntComp")]
        public async Task<IActionResult> getWeekCntComp()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                //am.Add("in_div", div);

                string sql = @"
                                select substr(a.daily_total_date,5,2) || '-' || substr(a.daily_total_date,7) dt,
                                       a.daily_total_date,
                                       a.order_cnt COUNT,
                                       a.success_cnt complete_count,
                                       b.order_cnt R_count,
                                       b.success_cnt R_complete_count
                                from dgr_success_order_total2 a, DGR_SUCCESS_RESER_ORDER_TOTAL b
                                where a.daily_total_date = b.daily_total_date
                                and a.daily_total_date between TO_CHAR (SYSDATE - 7, 'yyyyMMdd')
                                                         and TO_CHAR (SYSDATE - 1, 'yyyyMMdd')
                                order by a.daily_total_date
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);
                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 전체현황 - 금일현황O
        /// </summary>
        /// <remarks>
        /// * 누적회원 기준(test_gbn 구분X) <br/>
        /// TOTAL_MEMBER 누적회원 <br/>
        /// TODAY_APP_INSTALL 앱설치 <br/>
        /// TODAY_MEMBER 신규회원 <br/>
        /// TODAY_ORDER 주문건수 <br/>
        /// TODAY_SHOP_CONFIRM 주문 가맹점확인 건수 <br/>
        /// TODAY_COMPLETE_COUNT 주문완료건수 <br/>
        /// RESER_INS 예약신청 건수 <br/>
        /// RESER_SHOP_CONFIRM 예약확정 건수 <br/>
        /// TODAY_RESER 예약건수 <br/>
        /// RESER_COMPLETE_COUNT 예약완료건수 <br/>
        /// </remarks>
        [HttpGet("getTodayCount")]
        public async Task<IActionResult> getTodayCount()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();


                string sql = @"
                                select *
                                    from(select count(case when cust_id_gbn <> 'Z' then 1 end) total_member,
                                               count(case when insert_date between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second)
                                                               AND cust_id_gbn = 'Z' then 1 end) today_app_install,
                                               count(case when insert_date between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second)
                                                               AND cust_id_gbn <> 'Z' then 1 end) today_member               
                                        FROM (SELECT mcode,
                                                       insert_date,
                                                       cust_id_gbn,
                                                       test_gbn
                                                  FROM app_customer
                                                UNION ALL
                                                SELECT mcode,
                                                       insert_date,
                                                       cust_id_gbn,
                                                       test_gbn
                                                  FROM app_customer_deleted)
                                         WHERE     mcode = 2) a,
                                         (SELECT COUNT (*) today_order,
                                                 count(case when a.status = '30' then 1 end) today_shop_confirm,
                                                 count(case when a.status = '40' then 1 end) today_complete_count
                                          FROM dorder a, callcenter b
                                         WHERE     a.cccode = b.cccode
                                               AND b.mcode = 2
                                               AND test_gbn = 'N'
                                               AND a.status NOT IN ('80','20')
                                               AND CASE WHEN A.STATUS = '50' THEN A.CANCEL_CODE ELSE '00' END IN ('00','10','11','20','21','22','26')
                                               AND a.order_time between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second)) b,
                                          (SELECT COUNT (*) reser_ins,
                                                count(case when a.status = '12' then 1 end) reser_shop_confirm
                                          FROM reser_receipt_order a, callcenter b, shop_info c
                                         WHERE     a.shop_cd = c.shop_cd
                                               AND c.cccode = b.cccode
                                               AND b.mcode = 2
                                               AND a.isrt_date between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second))c,
                                          (SELECT COUNT (*) today_reser,
                                                count(case when a.status = '30' then 1 end) reser_complete_count
                                          FROM reser_receipt_order a, callcenter b, shop_info c
                                         WHERE     a.shop_cd = c.shop_cd
                                               AND c.cccode = b.cccode
                                               AND b.mcode = 2
                                               AND a.reser_date between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second))d
                                          where 1 = 1
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 전체현황 - 금일현황V2O
        /// </summary>
        /// <remarks>
        /// * 누적회원 기준(test_gbn 구분X) <br/>
        /// TOTAL_MEMBER_D 누적회원(주문) <br/>
        /// TOTAL_MEMBER_T 누적회원(택시) <br/>
        /// TODAY_APP_INSTALL_D 앱설치(주문) <br/>
        /// TODAY_APP_INSTALL_T 앱설치(택시) <br/>
        /// TODAY_MEMBER_D 신규회원(주문) <br/>
        /// TODAY_MEMBER_T 신규회원(택시) <br/>
        /// TODAY_ORDER 주문건수 <br/>
        /// TODAY_SHOP_CONFIRM 주문 가맹점확인 건수 <br/>
        /// TODAY_COMPLETE_COUNT 주문완료건수 <br/>
        /// RESER_INS 예약신청 건수 <br/>
        /// RESER_SHOP_CONFIRM 예약확정 건수 <br/>
        /// TODAY_RESER 예약건수 <br/>
        /// RESER_COMPLETE_COUNT 예약완료건수 <br/>
        /// </remarks>
        [HttpGet("getTodayCountV2")]
        public async Task<IActionResult> getTodayCountV2()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();


                string sql = @"
                                select *
                                    from(select count(case when cust_id_gbn <> 'Z' and system_gbn = 'D' then 1 end) total_member_d,
                                                count(case when cust_id_gbn <> 'Z' and system_gbn = 'T' then 1 end) total_member_t,
                                               count(case when insert_date between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second)
                                                               AND cust_id_gbn = 'Z' and system_gbn = 'D'  then 1 end) today_app_install_d,
                                               count(case when insert_date between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second)
                                                               AND cust_id_gbn = 'Z' and system_gbn = 'T'  then 1 end) today_app_install_t,
                                               count(case when insert_date between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second)
                                                               AND cust_id_gbn <> 'Z' and system_gbn = 'D' then 1 end) today_member_d,
                                               count(case when insert_date between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second)
                                                               AND cust_id_gbn <> 'Z' and system_gbn = 'T' then 1 end) today_member_t               
                                        FROM (SELECT mcode,
                                                       insert_date,
                                                       cust_id_gbn,
                                                       test_gbn,
                                                       system_gbn
                                                  FROM app_customer
                                                UNION ALL
                                                SELECT mcode,
                                                       insert_date,
                                                       cust_id_gbn,
                                                       test_gbn,
                                                       system_gbn
                                                  FROM app_customer_deleted)
                                         WHERE     mcode = 2) a,
                                         (SELECT COUNT (*) today_order,
                                                 count(case when a.status = '30' then 1 end) today_shop_confirm,
                                                 count(case when a.status = '40' then 1 end) today_complete_count
                                          FROM dorder a, callcenter b
                                         WHERE     a.cccode = b.cccode
                                               AND b.mcode = 2
                                               AND test_gbn = 'N'
                                               AND a.status NOT IN ('80','20')
                                               AND CASE WHEN A.STATUS = '50' THEN A.CANCEL_CODE ELSE '00' END IN ('00','10','11','20','21','22','26')
                                               AND a.order_time between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second)) b,
                                          (SELECT COUNT (*) reser_ins,
                                                count(case when a.status = '12' then 1 end) reser_shop_confirm
                                          FROM reser_receipt_order a, callcenter b, shop_info c
                                         WHERE     a.shop_cd = c.shop_cd
                                               AND c.cccode = b.cccode
                                               AND b.mcode = 2
                                               AND a.isrt_date between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second))c,
                                          (SELECT COUNT (*) today_reser,
                                                count(case when a.status = '30' then 1 end) reser_complete_count
                                          FROM reser_receipt_order a, callcenter b, shop_info c
                                         WHERE     a.shop_cd = c.shop_cd
                                               AND c.cccode = b.cccode
                                               AND b.mcode = 2
                                               AND a.reser_date between trunc(sysdate,'DD') and (trunc(sysdate + 1,'DD') - interval '1' second))d
                                          where 1 = 1
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 전체현황 - OS별 설치 현황 *집계테이블 사용
        /// </summary>
        [HttpGet("getTotalInstalled")]
        public async Task<IActionResult> getTotalInstalled()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> totalInstalled = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();


                // 누적 설치수
                string sql = @"
                                select os_type device_gbn, install_cnt count 
                                from DGR_OS_INSTALL_TOTAL
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalInstalled = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = totalInstalled });
        }

        /// <summary>
        /// 전체현황 - OS별 설치 현황V2 *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// system_gbn : 시스템 구분 (D: 대구로, T: 택시) (필수)
        /// </remarks>
        [HttpGet("getTotalInstalledV2")]
        public async Task<IActionResult> getTotalInstalledV2(string system_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> totalInstalled = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                DynamicParameters param = new DynamicParameters();
                param.Add("in_system_gbn", system_gbn);
                db.Open();


                // 누적 설치수
                string sql = @"
                                select os_type device_gbn, install_cnt count 
                                from DGR_OS_INSTALL_TOTAL_V2
                                where system_gbn = :in_system_gbn
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                totalInstalled = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = totalInstalled });
        }

        /// <summary>
        /// 전체현황 - 주문/예약현황(완료/취소) *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// DIV 구분(D:배달/포장, R:예약) <br/>
        /// 집계테이블 꽃배달 분리, 조회시 주문과 그룹바이 처리 <br/>
        /// </remarks>
        [HttpGet("getTotalOrders")]
        public async Task<IActionResult> getTotalOrders()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> totalOrders = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                // 누적 완료/취소 주문수
                string sql = @"
                                SELECT CASE WHEN DIV IN ('D','F') THEN 'D' ELSE DIV END DIV, 
                                       case when div IN ('D','F') and ORDER_STATUS = '40' then '완료'
                                            when div IN ('D','F') and ORDER_STATUS = '50' then '취소'
                                            when div = 'R' and ORDER_STATUS = '30' then '완료'
                                            when div = 'R' and ORDER_STATUS = '40' then '취소'
                                            when div = 'R' and ORDER_STATUS = '90' then '미방문' 
                                        end STATUS, 
                                        sum(ORDER_CNT) COUNT
                                FROM DGR_ORDER_TOTAL
                                GROUP BY CASE WHEN DIV IN ('D','F') THEN 'D' ELSE DIV END,
                                         case when div IN ('D','F') and ORDER_STATUS = '40' then '완료'
                                            when div IN ('D','F') and ORDER_STATUS = '50' then '취소'
                                            when div = 'R' and ORDER_STATUS = '30' then '완료'
                                            when div = 'R' and ORDER_STATUS = '40' then '취소'
                                            when div = 'R' and ORDER_STATUS = '90' then '미방문' 
                                        end
                                order by div
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalOrders = temp.ToList();


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = totalOrders });
        }


        /// <summary>
        /// 전체현황 - 연령별 가입 현황O *집계테이블 사용
        /// </summary>
        [HttpGet("getTotalYearMembers")]
        public async Task<IActionResult> getTotalYearMembers()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> totalYearMembers = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();


                // 누적 회원(연령대) 수
                string sql = @"
                                select  case when birthday < 1 then 1
                                            when birthday > 9 then 9
                                            else birthday end || '0대' YEAR, sum (join_cnt) count
                                from (select trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (join_age) + 1) /10) birthday,
                                            join_cnt
                                        from dgr_age_join_total2)
                                group by case when birthday < 1 then 1
                                            when birthday > 9 then 9
                                            else birthday end    
                            order by case when birthday < 1 then 1
                                            when birthday > 9 then 9
                                            else birthday end
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalYearMembers = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = totalYearMembers });
        }


        /// <summary>
        /// 전체현황 - 취소 현황O *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// div 구분(D:주문/배달, R:예약) <br/>
        /// 집계테이블 꽃배달 분리, 조회시 주문과 그룹바이 처리 <br/>
        /// </remarks>
        [HttpGet("getTotalCancel")]
        public async Task<IActionResult> getTotalCancel()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> totalCancel = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                // 누적 주문취소 사유별 건수
                string sql = @"
                                select 'D' div, b.code_nm cancel_code, sum(a.cancel_cnt) count
                                from DGR_CANCEL_TOTAL a, etc_code b
                                where a.cancel_code = b.code
                                and a.cancel_code in ('00','10','11','20','21','22','26')
                                and b.code_grp = '10'
                                and b.pgm_group = 'O'
                                group by b.code_nm
                                union all
                                select 'R' div, 
                                       case when cancel_code = '1' then '매장사정' 
                                            when cancel_code = '3' then '고객요청' 
                                            when cancel_code = '5' then '기타' end cancel_code,
                                       cancel_cnt count
                                from RESER_CANCEL_TOTAL
                                order by div, count desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalCancel = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = totalCancel });
        }

        #endregion

        #region[가맹점별 통계]
        /// <summary>
        /// 가맹점별 통계 - 업종별(기간조건:OPEN_DT 입점일)
        /// </summary>
        /// <remarks>
        /// 기간조건 형태 : YYYY-MM-DD
        /// </remarks>
        [HttpGet("getShopItem")]
        public async Task<IActionResult> GetShopItem(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";
                Rmsg = "조회 기간을 설정해 주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                select a.gungu_name, a.item_cd, count(1) as count
                                from shop_info a, callcenter b 
                                where a.cccode = b.cccode 
                                and b.mcode = 2 
                                and a.gungu_name is not null 
                                and a.item_cd is not null
                                and a.open_dt between to_date(:date_begin || ' 000000','YYYY-MM-DD HH24MISS') 
                                                  and to_date(:date_end || ' 235959','YYYY-MM-DD HH24MISS')
                                group by cube(a.gungu_name, a.item_cd )
                                order by a.gungu_name
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }



            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 가맹점별 통계 - 업종별 상세 데이터(기간조건:OPEN_DT 입점일)
        /// </summary>
        /// <remarks>
        /// 기간조건 형태 : YYYY-MM-DD
        /// </remarks>
        [HttpGet("getShopItemGungu/{gungu_name}")]
        public async Task<IActionResult> GetShopItemGungu(string gungu_name, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            if (string.IsNullOrEmpty(gungu_name))
            {
                Rcode = "01";
                Rmsg = "군구 이름을 입력해주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";
                Rmsg = "조회 기간을 설정해 주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("gungu_name", gungu_name);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);


                string sql = @"
                                select a.dong_name, a.item_cd, count(1) as count
                                from shop_info a, callcenter b 
                                where a.cccode = b.cccode 
                                and b.mcode = 2 
                                and a.dong_name is not null 
                                and a.item_cd is not null
                                and a.gungu_name = :gungu_name
                                and to_char(a.open_dt, 'YYYY-MM-DD') between :date_begin and :date_end
                                group by cube(a.dong_name, a.item_cd )
                                order by a.dong_name
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }



            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        // 일자별 구별 가맹점 입점현황
        /// <summary>
        /// 엑셀통계 - 군구별 가맹점(기간조건:OPEN_DT 입점일시)O -*엑셀 컨트롤러로 이동
        /// </summary>
        [HttpGet("getGunguShop")]
        public async Task<IActionResult> getGunguShop(int divKey, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            string sDiv = string.Empty;

            //없으면 전체 1: 간편입점 2: 관리앱 신청
            if (string.IsNullOrEmpty(divKey.ToString()) == false)
            {
                switch (divKey)
                {
                    case 1: sDiv = @"AND A.INS_UCODE = '-1' AND A.MEMO = '[간편입점신청]'"; break;
                    case 2: sDiv = @"AND (A.INS_UCODE <> '-1' OR A.MEMO <> '[간편입점신청]')"; break;
                }
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @$"
                                  SELECT TO_CHAR (a.open_dt, 'yyyyMMdd')     AS OPEN_DATE,
                                         decode(b.cccode, 5,'달서구', 6,'수성구',7,'동구',8,'서구', 9,'남구',10,'북구',11,'중구', 86, '달성군')  AS GUNGU_NAME,
                                         COUNT (*)                           AS COUNT
                                    FROM shop_info a, callcenter b
                                   WHERE     a.cccode = b.cccode
                                         AND b.mcode = 2
                                         {sDiv}
                                         AND a.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND TO_CHAR (a.open_dt, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                GROUP BY CUBE (TO_CHAR (a.open_dt, 'yyyyMMdd'),decode(b.cccode, 5,'달서구', 6,'수성구',7,'동구',8,'서구', 9,'남구',10,'북구',11,'중구', 86, '달성군'))
                                ORDER BY OPEN_DATE desc
                ";

                //string sql = @"
                //                  SELECT TO_CHAR (a.open_dt, 'yyyyMMdd')     AS OPEN_DATE,
                //                         a.gungu_name                        AS GUNGU_NAME,
                //                         COUNT (*)                           AS COUNT
                //                    FROM shop_info a, callcenter b
                //                   WHERE     a.cccode = b.cccode
                //                         AND b.mcode = 2
                //                         AND a.gungu_name IS NOT NULL
                //                         AND a.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                //                         AND TO_CHAR (a.open_dt, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                //                GROUP BY CUBE (TO_CHAR (a.open_dt, 'yyyyMMdd'), a.gungu_name)
                //                ORDER BY OPEN_DATE
                //";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        // 일자별 구별 가맹점 입점현황
        /// <summary>
        /// 가맹점별 통계 - 군구별(기간조건:OPEN_DT 입점일)
        /// </summary>
        [HttpGet("getGunguShopV2")]
        public async Task<IActionResult> getGunguShopV2(int divKey, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            string sDiv = string.Empty;

            //없으면 전체 1: 간편입점 2: 관리앱 신청
            if (string.IsNullOrEmpty(divKey.ToString()) == false)
            {
                switch (divKey)
                {
                    case 1: sDiv = @"AND A.INS_UCODE = '-1' AND A.MEMO = '[간편입점신청]'"; break;
                    case 2: sDiv = @"AND (A.INS_UCODE <> '-1' OR A.MEMO <> '[간편입점신청]')"; break;
                }
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @$"
                                  SELECT TEMP.OPEN_DATE,
                                           SUM(DECODE(TEMP.GUNGU_NAME, '달서구', TEMP.COUNT)) AS A, 
                                           SUM(DECODE(TEMP.GUNGU_NAME, '수성구', TEMP.COUNT)) AS B, 
                                           SUM(DECODE(TEMP.GUNGU_NAME, '동구', TEMP.COUNT)) AS C, 
                                           SUM(DECODE(TEMP.GUNGU_NAME, '서구', TEMP.COUNT)) AS D,
                                           SUM(DECODE(TEMP.GUNGU_NAME, '남구', TEMP.COUNT)) AS E,
                                           SUM(DECODE(TEMP.GUNGU_NAME, '북구', TEMP.COUNT)) AS F,
                                           SUM(DECODE(TEMP.GUNGU_NAME, '중구', TEMP.COUNT)) AS G,
                                           SUM(DECODE(TEMP.GUNGU_NAME, '달성군', TEMP.COUNT)) AS H
                                    FROM (
                                    SELECT TO_CHAR (a.open_dt, 'yyyyMMdd')     AS OPEN_DATE,
                                         decode(b.cccode, 5,'달서구', 6,'수성구',7,'동구',8,'서구', 9,'남구',10,'북구',11,'중구', 86, '달성군')  AS GUNGU_NAME,
                                         COUNT (*)                           AS COUNT
                                        FROM shop_info a, callcenter b
                                        WHERE     a.cccode = b.cccode
                                         AND b.mcode = 2
                                         {sDiv}
                                         AND a.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         and a.open_dt between to_date(:date_begin || ' 000000','YYYYMMDD HH24MISS') 
                                                  and to_date(:date_end || ' 235959','YYYYMMDD HH24MISS')
                                        GROUP BY CUBE (TO_CHAR (a.open_dt, 'yyyyMMdd'),decode(b.cccode, 5,'달서구', 6,'수성구',7,'동구',8,'서구', 9,'남구',10,'북구',11,'중구', 86, '달성군'))
                                        ORDER BY OPEN_DATE ) TEMP
                                    GROUP BY TEMP.OPEN_DATE
                                    ORDER BY case when TEMP.OPEN_DATE is not null then TEMP.OPEN_DATE else '20210808' end desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        // 일자별 카테고리별 가맹점 입점현황
        /// <summary>
        /// 엑셀 통계 - 카테고리별 가맹점(기간조건:OPEN_DT 입점일) -*엑셀 컨트롤러로 이동
        /// </summary>
        [HttpGet("getItemShop")]
        public async Task<IActionResult> getItemShop(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                SELECT NVL (T1.open_date, T2.open_date)     AS open_date,
                                         NVL (T1.item_name, T2.item_name)     AS item_name,
                                         NVL (T2.cnt, 0)                      AS COUNT
                                    FROM (SELECT w.open_date, x.item_name
                                            FROM (SELECT DISTINCT
                                                         TO_CHAR (a.open_dt, 'yyyyMMdd')     AS open_date
                                                    FROM shop_info a, callcenter b
                                                   WHERE     a.cccode = b.cccode
                                                         AND b.mcode = 2
                                                         AND a.item_cd IS NOT NULL
                                                         AND a.item_cd <> '9000'
                                                         AND a.open_dt >=
                                                             TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                         AND TO_CHAR (a.open_dt, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                 AND :date_end)
                                                 w,
                                                 item_mst x
                                           WHERE x.item_cd <> '9000') T1
                                         FULL OUTER JOIN
                                         (  SELECT TO_CHAR (a.open_dt, 'yyyyMMdd')     AS open_date,
                                                   c.item_name,
                                                   COUNT (*)                           AS cnt
                                              FROM shop_info a, callcenter b, item_mst c
                                             WHERE     a.cccode = b.cccode
                                                   AND b.mcode = 2
                                                   AND a.item_cd = c.item_cd(+)
                                                   AND a.item_cd IS NOT NULL
                                                   AND a.item_cd <> '9000'
                                                   AND a.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                   AND TO_CHAR (a.open_dt, 'yyyyMMdd') BETWEEN :date_begin
                                                                                           AND :date_end
                                          GROUP BY CUBE (TO_CHAR (a.open_dt, 'yyyyMMdd'), c.item_name)) T2
                                             ON T1.OPEN_DATE = T2.OPEN_DATE AND T1.item_name = T2.item_name
                                ORDER BY nvl(open_date,0) desc , item_name
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        // 일자별 카테고리별 가맹점 입점현황
        /// <summary>
        /// 가맹점별 통계 - 카테고리별(기간조건:OPEN_DT 입점일)
        /// </summary>
        /// <remarks>
        /// V 장보기 추가 <br/>
        /// </remarks>
        [HttpGet("getItemShopV2")]
        public async Task<IActionResult> getItemShopV2(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                               SELECT TEMP.OPEN_DATE,
                                       SUM(DECODE(TEMP.item_name, '1인분', TEMP.COUNT)) AS A, 
                                       SUM(DECODE(TEMP.item_name, '도시락/죽', TEMP.COUNT)) AS B, 
                                       SUM(DECODE(TEMP.item_name, '돈까스/일식', TEMP.COUNT)) AS C, 
                                       SUM(DECODE(TEMP.item_name, '반찬', TEMP.COUNT)) AS D,
                                       SUM(DECODE(TEMP.item_name, '분식', TEMP.COUNT)) AS E,
                                       SUM(DECODE(TEMP.item_name, '아시안/양식', TEMP.COUNT)) AS F,
                                       SUM(DECODE(TEMP.item_name, '야식', TEMP.COUNT)) AS G,
                                       SUM(DECODE(TEMP.item_name, '정육', TEMP.COUNT)) AS H,
                                       SUM(DECODE(TEMP.item_name, '족발/보쌈', TEMP.COUNT)) AS I,
                                       SUM(DECODE(TEMP.item_name, '중식', TEMP.COUNT)) AS J,
                                       SUM(DECODE(TEMP.item_name, '찜/탕', TEMP.COUNT)) AS K,
                                       SUM(DECODE(TEMP.item_name, '치킨/찜닭', TEMP.COUNT)) AS L,
                                       SUM(DECODE(TEMP.item_name, '카페/디저트', TEMP.COUNT)) AS M,
                                       SUM(DECODE(TEMP.item_name, '패스트푸드', TEMP.COUNT)) AS N,
                                       SUM(DECODE(TEMP.item_name, '펫', TEMP.COUNT)) AS O,
                                       SUM(DECODE(TEMP.item_name, '피자', TEMP.COUNT)) AS P,
                                       SUM(DECODE(TEMP.item_name, '한식', TEMP.COUNT)) AS Q,
                                       SUM(DECODE(TEMP.item_name, '특별관', TEMP.COUNT)) AS R,
                                       SUM(DECODE(TEMP.item_name, '전통시장', TEMP.COUNT)) AS S,
                                       SUM(DECODE(TEMP.item_name, '꽃배달', TEMP.COUNT)) AS T,
                                       SUM(DECODE(TEMP.item_name, '밀키트', TEMP.COUNT)) AS U,
                                       SUM(DECODE(TEMP.item_name, '장보기', TEMP.COUNT)) AS V,
                                       SUM(DECODE(TEMP.item_name, '', TEMP.COUNT)) AS Z       
                                FROM 
                                (SELECT NVL (T1.open_date, T2.open_date)     AS open_date,
                                         NVL (T1.item_name, T2.item_name)     AS item_name,
                                         NVL (T2.cnt, 0)                      AS COUNT
                                    FROM (SELECT w.open_date, x.item_name
                                            FROM (SELECT DISTINCT
                                                         TO_CHAR (a.open_dt, 'yyyyMMdd')     AS open_date
                                                    FROM shop_info a, callcenter b
                                                   WHERE     a.cccode = b.cccode
                                                         AND b.mcode = 2
                                                         AND a.item_cd IS NOT NULL
                                                         AND a.item_cd <> '9000'
                                                         AND a.open_dt >=
                                                             TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                             and a.open_dt between to_date(:date_begin || ' 000000','YYYYMMDD HH24MISS') 
                                                                               and to_date(:date_end || ' 235959','YYYYMMDD HH24MISS'))
                                                 w,
                                                 item_mst x
                                           WHERE x.item_cd <> '9000') T1
                                         FULL OUTER JOIN
                                         (  SELECT TO_CHAR (a.open_dt, 'yyyyMMdd')     AS open_date,
                                                   c.item_name,
                                                   COUNT (*)                           AS cnt
                                              FROM shop_info a, callcenter b, item_mst c
                                             WHERE     a.cccode = b.cccode
                                                   AND b.mcode = 2
                                                   AND a.item_cd = c.item_cd(+)
                                                   AND a.item_cd IS NOT NULL
                                                   AND a.item_cd <> '9000'
                                                   AND a.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                   and a.open_dt between to_date(:date_begin || ' 000000','YYYYMMDD HH24MISS') 
                                                                     and to_date(:date_end || ' 235959','YYYYMMDD HH24MISS')
                                          GROUP BY CUBE (TO_CHAR (a.open_dt, 'yyyyMMdd'), c.item_name)) T2
                                             ON T1.OPEN_DATE = T2.OPEN_DATE AND T1.item_name = T2.item_name
                                    ORDER BY open_date, item_name) TEMP
                                 GROUP BY TEMP.OPEN_DATE
                                 ORDER BY case when TEMP.OPEN_DATE is not null then TEMP.OPEN_DATE else '20210808' end desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        // 일자별 라이브이벤트 건수 및 매출액 조회
        /// <summary>
        /// 가맹점별 통계 - 라이브 이벤트 매출현황(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        /// <remarks>
        /// 할인전 메뉴금액 기준
        /// </remarks>
        [HttpGet("getDailyEventCount")]
        public async Task<IActionResult> getDailyEventCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT X.ORDER_DATE,
                                       COUNT(case when X.STATUS = '40' then 1 end) AS comp_cnt,
                                       SUM(case when X.STATUS = '40' then X.ORI_AMT end) AS comp_sum,
                                       COUNT(case when X.STATUS = '50' then 1 end) AS canc_cnt,
                                       SUM(case when X.STATUS = '50' then X.ORI_AMT end) AS canc_sum
                                  FROM (select * 
                                            from dorder AA
                                            , (select a.order_no, a.ori_amt, a.disc_amt
                                                    from shop_event_order a, callcenter b 
                                                    where a.cccode=b.cccode 
                                                    and b.mcode=2 
                                                    group by a.order_no, a.ori_amt, a.disc_amt) BB
                                        where AA.order_no = BB.order_no
                                        and AA.status in ('40','50')
                                        and case when AA.status = '50' then AA.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                        AND AA.ORDER_TIME BETWEEN to_date(:date_begin ||' 000000', 'YYYYMMDD HH24MISS')
                                                                                      AND to_date(:date_end ||' 235959', 'YYYYMMDD HH24MISS')
                                        UNION ALL
                                        select *
                                            from dorder_past AA
                                            , (select a.order_no, a. ori_amt, a.disc_amt
                                                from shop_event_order a, callcenter b 
                                                where a.cccode=b.cccode 
                                                and b.mcode=2 
                                                group by a.order_no, a.ori_amt, a.disc_amt) BB
                                        where AA.order_no=BB.order_no
                                        and AA.status in ('40','50')
                                        and case when AA.status = '50' then AA.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                        AND AA.ORDER_TIME BETWEEN to_date(:date_begin ||' 000000', 'YYYYMMDD HH24MISS')
                                                                                      AND to_date(:date_end ||' 235959', 'YYYYMMDD HH24MISS') ) X
                                 GROUP BY X.ORDER_DATE
                                 ORDER BY X.ORDER_DATE DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 가맹점별 통계 - 영업자별(기간조건:OPEN_DT 입점일)(미사용)
        /// </summary>
        /// <remarks>
        /// 기간조건 형태 : YYYY-MM-DD
        /// </remarks>
        [HttpGet("getShopSalesman")]
        public async Task<IActionResult> GetShopSalesman(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";
                Rmsg = "조회 기간을 설정해 주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                select a.gungu_name, a.salesman_name, count(1) as count
                                from shop_info a, callcenter b 
                                where a.cccode = b.cccode 
                                and b.mcode = 2 
                                and a.gungu_name is not null 
                                and a.salesman_name is not null
                                and a.open_dt between to_date(:date_begin || ' 000000','YYYY-MM-DD HH24MISS') 
                                                  and to_date(:date_end || ' 235959','YYYY-MM-DD HH24MISS')
                                group by cube(a.gungu_name, a.salesman_name )
                                order by a.gungu_name
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }



            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 가맹점별 통계 - 영업자별 상세 데이터(기간조건:OPEN_DT 입점일)(미사용)
        /// </summary>
        /// <remarks>
        /// 기간조건 형태 : YYYY-MM-DD
        /// </remarks>
        [HttpGet("getShopSalesmanGungu/{gungu_name}")]
        public async Task<IActionResult> GetShopSalesmanGungu(string gungu_name, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            if (string.IsNullOrEmpty(gungu_name))
            {
                Rcode = "01";
                Rmsg = "군구 이름을 입력해주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";
                Rmsg = "조회 기간을 설정해 주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("gungu_name", gungu_name);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);


                string sql = @"
                                  SELECT a.dong_name, a.salesman_name, COUNT (*) AS COUNT
                                    FROM shop_info a, callcenter b
                                   WHERE     a.cccode = b.cccode
                                         AND b.mcode = 2
                                         AND a.dong_name IS NOT NULL
                                         AND a.salesman_name IS NOT NULL
                                         AND a.gungu_name = :gungu_name
                                         AND TO_CHAR (a.open_dt, 'YYYY-MM-DD') BETWEEN :date_begin
                                                                                   AND :date_end
                                GROUP BY CUBE (a.dong_name, a.salesman_name)
                                ORDER BY a.dong_name
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }



            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        #endregion[가맹점별 통계]

        #region[가맹점별 통계 추가]
        /// <summary>
        /// 전체 가맹점 매출건수 통계자료O *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// gungu 군구 구분(빈값:전체, 달서구, 수성구, 동구, 서구, 남구, 북구, 중구, 달성군)<br/>
        /// div 검색구분(1:가맹점코드, 2:가맹점명)<br/>
        /// keyword 검색키워드 <br/>
        /// order 가맹점코드 정렬 방향 (빈값: 오름차순, r: 내림차순) <br/>
        /// [response] <br/>
        /// rnum 순번 <br/>
        /// shop_cd 가맹점코드 <br/>
        /// shop_name 가맹점명 <br/>
        /// gungu 구/군 <br/>
        /// tot_order_cnt 총 주문건수 <br/>
        /// comp_cnt 완료 건수 <br/>
        /// cancel_cnt 취소 건수 <br/>
        /// </remarks>
        [HttpGet("getShopOrderCnt")]
        public async Task<IActionResult> getShopOrderCnt(string date_begin, string date_end, string gungu, string div, string keyword, string order, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            List<ShopOrderCnt> Rdata = new List<ShopOrderCnt>();

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_SHOP_ORDER_CNT",
                };

                cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
                cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
                cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 10).Value = gungu;
                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
                cmd.Parameters.Add("in_order", OracleDbType.Varchar2, 2).Value = order;
                cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
                cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopOrderCnt item = new ShopOrderCnt
                    {
                        rnum = rd["RNUM"].ToString(),
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),
                        gungu = rd["GUNGU_NAME"].ToString(),
                        tot_order_cnt = rd["TOT_ORDER_CNT"].ToString(),
                        comp_cnt = rd["COMP_CNT"].ToString(),
                        cancel_cnt = rd["CANCEL_CNT"].ToString()
                    };

                    Rdata.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = Rdata });
        }

        /// <summary>
        /// 전체 가맹점 매출건수 통계자료 - 엑셀추출O *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// gungu 군구 구분(빈값:전체, 달서구, 수성구, 동구, 서구, 남구, 북구, 중구, 달성군)<br/>
        /// order 가맹점코드 정렬 방향 (빈값: 오름차순, r: 내림차순)
        /// </remarks>
        [HttpGet("getShopOrderCntExcel")]
        public async Task<IActionResult> getShopOrderCntExcel(string date_begin, string date_end, string gungu, string order)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_SHOP_ORDER_CNT",
                };

                cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
                cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
                cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 10).Value = gungu;
                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = null;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = null;
                cmd.Parameters.Add("in_order", OracleDbType.Varchar2, 2).Value = order;
                cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = null;
                cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = null;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add(date_begin + "-" + date_end);
                        var currentRow = 1;

                        worksheet.Cell(currentRow, 1).Value = "가맹점코드";
                        worksheet.Cell(currentRow, 2).Value = "가맹점명";
                        worksheet.Cell(currentRow, 3).Value = "구/군";
                        worksheet.Cell(currentRow, 4).Value = "총 주문건수";
                        worksheet.Cell(currentRow, 5).Value = "완료 건수";
                        worksheet.Cell(currentRow, 6).Value = "취소 건수";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;

                            worksheet.Cell(currentRow, 1).Value = rd["SHOP_CD"].ToString();
                            worksheet.Cell(currentRow, 2).Value = rd["SHOP_NAME"].ToString();
                            worksheet.Cell(currentRow, 3).Value = rd["GUNGU_NAME"].ToString();
                            worksheet.Cell(currentRow, 4).Value = rd["TOT_ORDER_CNT"].ToString();
                            worksheet.Cell(currentRow, 5).Value = rd["COMP_CNT"].ToString();
                            worksheet.Cell(currentRow, 6).Value = rd["CANCEL_CNT"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "전체 가맹점 매출건수 통계자료.xlsx");
                        }
                    }

                }


            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 전체 가맹점 매출액 통계자료O *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// gungu 군구 구분(빈값:전체, 달서구, 수성구, 동구, 서구, 남구, 북구, 중구, 달성군)<br/>
        /// div 검색구분(1:가맹점코드, 2:가맹점명)<br/>
        /// keyword 검색키워드 <br/>
        /// order 가맹점코드 정렬 방향 (빈값: 오름차순, r: 내림차순) <br/>
        /// [response] <br/>
        /// rnum 순번 <br/>
        /// shop_cd 가맹점코드 <br/>
        /// shop_name 가맹점명 <br/>
        /// gungu 구/군 <br/>
        /// tot_sales_amt 총 매출 <br/>
        /// comp_amt 완료 매출 <br/>
        /// cancel_amt 취소 매출 <br/>
        /// </remarks>
        [HttpGet("getShopOrderAmt")]
        public async Task<IActionResult> getShopOrderAmt(string date_begin, string date_end, string gungu, string order, string div, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            List<ShopOrderAmt> Rdata = new List<ShopOrderAmt>();

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_SHOP_ORDER_AMT",
                };

                cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
                cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
                cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 10).Value = gungu;
                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
                cmd.Parameters.Add("in_order", OracleDbType.Varchar2, 2).Value = order;
                cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
                cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopOrderAmt item = new ShopOrderAmt
                    {
                        rnum = rd["RNUM"].ToString(),
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),
                        gungu = rd["GUNGU_NAME"].ToString(),
                        tot_sales_amt = rd["TOT_SALES_AMT"].ToString(),
                        comp_amt = rd["COMP_AMT"].ToString(),
                        cancel_amt = rd["CANCEL_AMT"].ToString()
                    };

                    Rdata.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = Rdata });
        }

        /// <summary>
        /// 전체 가맹점 매출액 통계자료 - 엑셀추출O *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// gungu 군구 구분(빈값:전체, 달서구, 수성구, 동구, 서구, 남구, 북구, 중구, 달성군)<br/>
        /// order 가맹점코드 정렬 방향 (빈값: 오름차순, r: 내림차순)
        /// </remarks>
        [HttpGet("getShopOrderAmtExcel")]
        public async Task<IActionResult> getShopOrderAmtExcel(string date_begin, string date_end, string gungu, string order)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_SHOP_ORDER_AMT",
                };

                cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
                cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
                cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 10).Value = gungu;
                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = null;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = null;
                cmd.Parameters.Add("in_order", OracleDbType.Varchar2, 2).Value = order;
                cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = null;
                cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = null;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add(date_begin + "-" + date_end);
                        var currentRow = 1;

                        worksheet.Cell(currentRow, 1).Value = "가맹점코드";
                        worksheet.Cell(currentRow, 2).Value = "가맹점명";
                        worksheet.Cell(currentRow, 3).Value = "구/군";
                        worksheet.Cell(currentRow, 4).Value = "총 매출";
                        worksheet.Cell(currentRow, 5).Value = "완료 매출";
                        worksheet.Cell(currentRow, 6).Value = "취소 매출";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;

                            worksheet.Cell(currentRow, 1).Value = rd["SHOP_CD"].ToString();
                            worksheet.Cell(currentRow, 2).Value = rd["SHOP_NAME"].ToString();
                            worksheet.Cell(currentRow, 3).Value = rd["GUNGU_NAME"].ToString();
                            worksheet.Cell(currentRow, 4).Value = rd["TOT_SALES_AMT"].ToString();
                            worksheet.Cell(currentRow, 5).Value = rd["COMP_AMT"].ToString();
                            worksheet.Cell(currentRow, 6).Value = rd["CANCEL_AMT"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "전체 가맹점 매출금액 통계자료.xlsx");
                        }
                    }

                }


            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 기간별 미접속 가맹점 리스트
        /// </summary>
        /// <remarks>
        /// gungu 군구 구분(빈값:전체, 달서구, 수성구, 동구, 서구, 남구, 북구, 중구, 달성군)<br/>
        /// div 검색구분(1:가맹점코드, 2:가맹점명)<br/>
        /// keyword 검색키워드 <br/>
        /// order 가맹점코드 정렬 방향 (빈값: 오름차순, r: 내림차순) <br/>
        /// [response] <br/>
        /// rnum 순번 <br/>
        /// shop_cd 가맹점코드 <br/>
        /// shop_name 가맹점명 <br/>
        /// gungu 구/군 <br/>
        /// last_login 최종접속일 <br/>
        /// dd 미접속일(당일기준D+00) <br/>
        /// </remarks>
        [HttpGet("getShopLastLogin")]
        public async Task<IActionResult> getShopLastLogin(string gungu, string order, string div, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            List<ShopLastLogin> Rdata = new List<ShopLastLogin>();

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_SHOP_LAST_LOGIN",
                };

                cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 10).Value = gungu;
                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
                cmd.Parameters.Add("in_order", OracleDbType.Varchar2, 2).Value = order;
                cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
                cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopLastLogin item = new ShopLastLogin
                    {
                        rnum = rd["RNUM"].ToString(),
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),
                        gungu = rd["GUNGU_NAME"].ToString(),
                        last_login = rd["LAST_LOGIN"].ToString(),
                        dd = rd["DD"].ToString()
                    };

                    Rdata.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = Rdata });
        }

        /// <summary>
        /// 기간별 미접속 가맹점 리스트 - 엑셀추출
        /// </summary>
        /// <remarks>
        /// gungu 군구 구분(빈값:전체, 달서구, 수성구, 동구, 서구, 남구, 북구, 중구, 달성군)<br/>
        /// order 가맹점코드 정렬 방향 (빈값: 오름차순, r: 내림차순)
        /// </remarks>
        [HttpGet("getShopLastLoginExcel")]
        public async Task<IActionResult> getShopLastLoginExcel(string gungu, string order)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_SHOP_LAST_LOGIN",
                };

                cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 10).Value = gungu;
                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = null;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = null;
                cmd.Parameters.Add("in_order", OracleDbType.Varchar2, 2).Value = order;
                cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = null;
                cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = null;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add("기간별 미접속 가맹점 리스트");
                        var currentRow = 1;

                        worksheet.Cell(currentRow, 1).Value = "가맹점코드";
                        worksheet.Cell(currentRow, 2).Value = "가맹점명";
                        worksheet.Cell(currentRow, 3).Value = "구/군";
                        worksheet.Cell(currentRow, 4).Value = "최종접속일";
                        worksheet.Cell(currentRow, 5).Value = "미접속일(당일기준D+00)";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;

                            worksheet.Cell(currentRow, 1).Value = rd["SHOP_CD"].ToString();
                            worksheet.Cell(currentRow, 2).Value = rd["SHOP_NAME"].ToString();
                            worksheet.Cell(currentRow, 3).Value = rd["GUNGU_NAME"].ToString();
                            worksheet.Cell(currentRow, 4).Value = rd["LAST_LOGIN"].ToString();
                            worksheet.Cell(currentRow, 5).Value = rd["DD"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "기간별 미접속 가맹점 리스트.xlsx");
                        }
                    }

                }


            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 라이브 이벤트 사용 매장 리스트 *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// gungu 군구 구분(빈값:전체, 달서구, 수성구, 동구, 서구, 남구, 북구, 중구, 달성군)<br/>
        /// div 검색구분(1:가맹점코드, 2:가맹점명)<br/>
        /// keyword 검색키워드 <br/>
        /// order 가맹점코드 정렬 방향 (빈값: 오름차순, r: 내림차순) <br/>
        /// [response] <br/>
        /// rnum 순번 <br/>
        /// shop_cd 가맹점코드 <br/>
        /// shop_name 가맹점명 <br/>
        /// gungu 구/군 <br/>
        /// cnt 라이브 이벤트 사용횟수 <br/>
        /// </remarks>
        [HttpGet("getShopLiveEventCnt")]
        public async Task<IActionResult> getShopLiveEventCnt(string date_begin, string date_end, string gungu, string div, string keyword, string order, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            List<ShopLiveEventCnt> Rdata = new List<ShopLiveEventCnt>();

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_SHOP_LIVE_EVENT_CNT",
                };

                cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
                cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
                cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 10).Value = gungu;
                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
                cmd.Parameters.Add("in_order", OracleDbType.Varchar2, 2).Value = order;
                cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
                cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopLiveEventCnt item = new ShopLiveEventCnt
                    {
                        rnum = rd["RNUM"].ToString(),
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),
                        gungu = rd["GUNGU_NAME"].ToString(),
                        cnt = rd["CNT"].ToString()
                    };

                    Rdata.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = Rdata });
        }

        /// <summary>
        /// 라이브 이벤트 사용 매장 리스트 - 엑셀추출 *집계테이블 사용
        /// </summary>
        /// <remarks>
        /// gungu 군구 구분(빈값:전체, 달서구, 수성구, 동구, 서구, 남구, 북구, 중구, 달성군)<br/>
        /// order 가맹점코드 정렬 방향 (빈값: 오름차순, r: 내림차순)
        /// </remarks>
        [HttpGet("getShopLiveEventCntExcel")]
        public async Task<IActionResult> getShopLiveEventCntExcel(string date_begin, string date_end, string gungu, string order)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_SHOP_LIVE_EVENT_CNT",
                };

                cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
                cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
                cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 10).Value = gungu;
                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = null;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = null;
                cmd.Parameters.Add("in_order", OracleDbType.Varchar2, 2).Value = order;
                cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = null;
                cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = null;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add(date_begin + "-" + date_end);
                        var currentRow = 1;

                        worksheet.Cell(currentRow, 1).Value = "가맹점코드";
                        worksheet.Cell(currentRow, 2).Value = "가맹점명";
                        worksheet.Cell(currentRow, 3).Value = "구/군";
                        worksheet.Cell(currentRow, 4).Value = "라이브 이벤트 사용횟수";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;

                            worksheet.Cell(currentRow, 1).Value = rd["SHOP_CD"].ToString();
                            worksheet.Cell(currentRow, 2).Value = rd["SHOP_NAME"].ToString();
                            worksheet.Cell(currentRow, 3).Value = rd["GUNGU_NAME"].ToString();
                            worksheet.Cell(currentRow, 4).Value = rd["CNT"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "라이브 이벤트 사용 매장 리스트.xlsx");
                        }
                    }

                }


            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 리뷰안내알림, 매장알림 사용여부
        /// </summary>
        /// <remarks>
        /// div 검색구분(1:가맹점코드, 2:가맹점명)<br/>
        /// keyword 검색키워드 <br/>
        /// order 가맹점코드 정렬 방향 (빈값: 오름차순, r: 내림차순) <br/>
        /// [response] <br/>
        /// rnum 순번 <br/>
        /// shop_cd 가맹점코드 <br/>
        /// shop_name 가맹점명 <br/>
        /// r_yn 리뷰안내(Y/N) <br/>
        /// i_yn 사장님알림(Y/N) <br/>
        /// </remarks>
        [HttpGet("getShopIntroYn")]
        public async Task<IActionResult> getShopIntroYn(string div, string keyword, string order, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            List<ShopIntroYn> Rdata = new List<ShopIntroYn>();

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_SHOP_INTRO_YN",
                };

                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
                cmd.Parameters.Add("in_order", OracleDbType.Varchar2, 2).Value = order;
                cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
                cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopIntroYn item = new ShopIntroYn
                    {
                        rnum = rd["RNUM"].ToString(),
                        shop_cd = rd["SHOP_CD"].ToString(),
                        shop_name = rd["SHOP_NAME"].ToString(),
                        r_yn = rd["R_YN"].ToString(),
                        i_yn = rd["I_YN"].ToString()

                    };

                    Rdata.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = Rdata });
        }

        /// <summary>
        /// 주문 리뷰안내알림, 매장알림 사용여부 - 엑셀추출
        /// </summary>
        /// <remarks>
        /// order 가맹점코드 정렬 방향 (빈값: 오름차순, r: 내림차순)
        /// </remarks>
        [HttpGet("getShopIntroYnExcel")]
        public async Task<IActionResult> getShopIntroYnExcel(string order)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_SHOP_INTRO_YN",
                };

                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = null;
                cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = null;
                cmd.Parameters.Add("in_order", OracleDbType.Varchar2, 2).Value = order;
                cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = null;
                cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = null;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add("주문 리뷰안내알림, 매장알림 사용여부");
                        var currentRow = 1;

                        worksheet.Cell(currentRow, 1).Value = "가맹점코드";
                        worksheet.Cell(currentRow, 2).Value = "가맹점명";
                        worksheet.Cell(currentRow, 3).Value = "리뷰안내";
                        worksheet.Cell(currentRow, 4).Value = "사장님알림";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;

                            worksheet.Cell(currentRow, 1).Value = rd["SHOP_CD"].ToString();
                            worksheet.Cell(currentRow, 2).Value = rd["SHOP_NAME"].ToString();
                            worksheet.Cell(currentRow, 3).Value = rd["R_YN"].ToString();
                            worksheet.Cell(currentRow, 4).Value = rd["I_YN"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "주문 리뷰안내알림, 매장알림 사용여부.xlsx");
                        }
                    }

                }


            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion[가맹점별 통계 추가]

        #region[회원별 통계]
        // 일자별 회원현황(미사용)
        [HttpGet("getDailyMemberCount")]
        public async Task<IActionResult> getDailyMemberCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                              SELECT TO_CHAR (insert_date, 'yyyyMMdd')
                                         reg_date,
                                     DECODE (cust_id_gbn,
                                             'A', '공공앱',
                                             'G', '구글',
                                             'K', '카카오',
                                             'N', '네이버',
                                             'I', '애플',
                                             'Z', '비회원')
                                         cust_id_gbn,
                                     COUNT (*)
                                         COUNT
                                FROM (SELECT mcode, test_gbn, insert_date, cust_id_gbn FROM app_customer
                                      UNION ALL
                                      SELECT mcode,
                                             test_gbn,
                                             insert_date,
                                             cust_id_gbn
                                        FROM app_customer_deleted)
                               WHERE     mcode = 2
                                     -- AND insert_date > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                     AND cust_id_gbn <> 'Z'
                                     AND test_gbn = 'R'
                            GROUP BY CUBE (TO_CHAR (insert_date, 'yyyyMMdd'), cust_id_gbn)
                              HAVING TO_CHAR (insert_date, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                            ORDER BY TO_CHAR (insert_date, 'yyyyMMdd') desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 회원별 통계 - 일자별 회원가입수(기간조건:INSERT_DATE 가입일시)
        /// </summary>
        [HttpGet("getDailyMemberCountV2")]
        public async Task<IActionResult> getDailyMemberCountV2(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                              SELECT TEMP.REG_DATE,
                                       SUM(DECODE(TEMP.cust_id_gbn, '공공앱', TEMP.COUNT)) AS A, 
                                       SUM(DECODE(TEMP.cust_id_gbn, '구글', TEMP.COUNT)) AS B, 
                                       SUM(DECODE(TEMP.cust_id_gbn, '카카오', TEMP.COUNT)) AS C, 
                                       SUM(DECODE(TEMP.cust_id_gbn, '네이버', TEMP.COUNT)) AS D,
                                       SUM(DECODE(TEMP.cust_id_gbn, '애플', TEMP.COUNT)) AS E,
                                       SUM(DECODE(TEMP.cust_id_gbn, '비회원', TEMP.COUNT)) AS F
                                FROM
                                (SELECT TO_CHAR (insert_date, 'yyyyMMdd')
                                         reg_date,
                                     DECODE (cust_id_gbn,
                                             'A', '공공앱',
                                             'G', '구글',
                                             'K', '카카오',
                                             'N', '네이버',
                                             'I', '애플',
                                             'Z', '비회원')
                                         cust_id_gbn,
                                     COUNT (*)
                                         COUNT
                                    FROM (SELECT mcode, test_gbn, insert_date, cust_id_gbn FROM app_customer
                                      UNION ALL
                                      SELECT mcode,
                                             test_gbn,
                                             insert_date,
                                             cust_id_gbn
                                        FROM app_customer_deleted)
                                    WHERE     mcode = 2
                                     -- AND insert_date > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                     AND cust_id_gbn <> 'Z'
                                     AND test_gbn = 'R'
                                     AND INSERT_DATE  between to_date(:date_begin || ' 000000','YYYYMMDD HH24MISS') 
                                                          and to_date(:date_end || ' 235959','YYYYMMDD HH24MISS')
                                    GROUP BY (TO_CHAR (insert_date, 'yyyyMMdd'), cust_id_gbn))TEMP
                                GROUP BY TEMP.REG_DATE
                                ORDER BY TEMP.REG_DATE desc
                ";

                //string sql = @"
                //              SELECT TEMP.REG_DATE,
                //                       SUM(DECODE(TEMP.cust_id_gbn, '공공앱', TEMP.COUNT)) AS A, 
                //                       SUM(DECODE(TEMP.cust_id_gbn, '구글', TEMP.COUNT)) AS B, 
                //                       SUM(DECODE(TEMP.cust_id_gbn, '카카오', TEMP.COUNT)) AS C, 
                //                       SUM(DECODE(TEMP.cust_id_gbn, '네이버', TEMP.COUNT)) AS D,
                //                       SUM(DECODE(TEMP.cust_id_gbn, '애플', TEMP.COUNT)) AS E,
                //                       SUM(DECODE(TEMP.cust_id_gbn, '비회원', TEMP.COUNT)) AS F
                //                FROM
                //                (SELECT TO_CHAR (insert_date, 'yyyyMMdd')
                //                         reg_date,
                //                     DECODE (cust_id_gbn,
                //                             'A', '공공앱',
                //                             'G', '구글',
                //                             'K', '카카오',
                //                             'N', '네이버',
                //                             'I', '애플',
                //                             'Z', '비회원')
                //                         cust_id_gbn,
                //                     COUNT (*)
                //                         COUNT
                //                    FROM (SELECT mcode, test_gbn, insert_date, cust_id_gbn FROM app_customer
                //                      UNION ALL
                //                      SELECT mcode,
                //                             test_gbn,
                //                             insert_date,
                //                             cust_id_gbn
                //                        FROM app_customer_deleted)
                //                    WHERE     mcode = 2
                //                     -- AND insert_date > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                //                     AND cust_id_gbn <> 'Z'
                //                     AND test_gbn = 'R'
                //                    GROUP BY CUBE (TO_CHAR (insert_date, 'yyyyMMdd'), cust_id_gbn)
                //                    HAVING TO_CHAR (insert_date, 'yyyyMMdd') BETWEEN :date_begin AND :date_end)TEMP
                //                GROUP BY TEMP.REG_DATE
                //                ORDER BY TEMP.REG_DATE desc
                //";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }



        /// <summary>
        /// 회원별 통계 - 일자별 비회원수(기간조건:INSERT_DATE 가입일시) + (엑셀통계 일자별 비회원)
        /// </summary>
        [HttpGet("getDailyNonMemberCount")]
        public async Task<IActionResult> getDailyNonMemberCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                              SELECT TO_CHAR (a.insert_date, 'yyyyMMdd')
                                         insert_date,
                                     COUNT (CASE WHEN cust_id_gbn = 'Z' THEN 1 ELSE NULL END)
                                         count
                                FROM (SELECT mcode, insert_date, cust_id_gbn, test_gbn FROM app_customer
                                      UNION ALL
                                      SELECT mcode,
                                             insert_date,
                                             cust_id_gbn,
                                             test_gbn
                                        FROM app_customer_deleted) a
                               WHERE     a.test_gbn = 'R'
                                     AND a.mcode = 2
                                     -- AND a.insert_date >= TO_DATE('2021080917','yyyyMMddHH24')
                                     AND A.INSERT_DATE  between to_date(:date_begin || ' 000000','YYYYMMDD HH24MISS') 
                                                          and to_date(:date_end || ' 235959','YYYYMMDD HH24MISS')
                            GROUP BY TO_CHAR (a.insert_date, 'yyyyMMdd')
                            ORDER BY insert_date desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 회원별 통계 - 기간별 회원 주문실적(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        [HttpGet("getMemberOrderInfo")]
        public async Task<IActionResult> getMemberOrderInfo(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                SELECT ROWNUM
                                           DAY_COUNT,
                                       DECODE (ROWNUM,
                                               1, day1,
                                               2, day2,
                                               3, day3,
                                               4, day4,
                                               5, day5,
                                               6, day6,
                                               7, day7)
                                           order_count
                                  FROM (SELECT SUM (CASE WHEN (cnt = 1) THEN 1 ELSE 0 END)
                                                   day1,
                                               SUM (CASE WHEN (cnt = 2) THEN 1 ELSE 0 END)
                                                   day2,
                                               SUM (CASE WHEN (cnt = 3) THEN 1 ELSE 0 END)
                                                   day3,
                                               SUM (CASE WHEN (cnt = 4) THEN 1 ELSE 0 END)
                                                   day4,
                                               SUM (CASE WHEN (cnt = 5) THEN 1 ELSE 0 END)
                                                   day5,
                                               SUM (CASE WHEN (cnt = 6) THEN 1 ELSE 0 END)
                                                   day6,
                                               SUM (CASE WHEN (cnt > 6) THEN 1 ELSE 0 END)
                                                   day7
                                          FROM (  SELECT app_cust_code, COUNT (*) cnt
                                                    FROM (SELECT *
                                                            FROM is_daegu.dorder a, is_daegu.callcenter b
                                                           WHERE     a.cccode = b.cccode
                                                                 AND b.mcode = 2
                                                                 AND a.test_gbn = 'N'
                                                                 and a.status not in  ('80','20')
                                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                 AND a.order_time BETWEEN to_date(:date_begin || '000000','YYYYMMDDHH24MISS')
                                                                                                            AND to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                                          UNION
                                                          SELECT *
                                                            FROM is_daegu.dorder_past a, is_daegu.callcenter b
                                                           WHERE     a.cccode = b.cccode
                                                                 AND b.mcode = 2
                                                                 AND a.test_gbn = 'N'
                                                                 and a.status not in  ('80','20')
                                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                 AND a.order_time >=
                                                                     TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                 AND a.order_time BETWEEN to_date(:date_begin || '000000','YYYYMMDDHH24MISS')
                                                                                                            AND to_date(:date_end || '235959','YYYYMMDDHH24MISS'))
                                                GROUP BY app_cust_code))
                            CONNECT BY LEVEL <= 7
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 회원별 통계 - 기간별 회원 주문실적 v2
        /// </summary>
        /// <remarks>
        /// div_service   서비스 (A : 전체, D : 주문, T : 택시)(필수) <br/>
        /// div_status    주문상태(1 : 전체주문, 2 : 완료건만)(필수) <br/>
        /// div_dt        (주문) 기간기준(1 : 주문시간, 2 : 주문완료시간(회계기준))(필수) <br/>
        /// date_begin   (필수) <br/>
        /// date_end     (필수) <br/>
        /// [response] <br/>
        /// use_cnt 순수이용자수 <br/>
        /// cnt 순번 <br/>
        /// cust_cnt 가맹점코드 <br/>
        /// </remarks>
        [HttpGet("getMemberOrderInfoV2")]
        public async Task<IActionResult> getMemberOrderInfoV2(string div_service, string div_status, string div_dt, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            List<MemberOrderInfo> Rdata = new List<MemberOrderInfo>();

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_MEMBER_ORDER_INFO",
                };

                cmd.Parameters.Add("in_div_service", OracleDbType.Varchar2, 10).Value = div_service;
                cmd.Parameters.Add("in_div_status", OracleDbType.Varchar2, 10).Value = div_status;
                cmd.Parameters.Add("in_div_dt", OracleDbType.Varchar2, 10).Value = div_dt;
                cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
                cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    MemberOrderInfo item = new MemberOrderInfo
                    {
                        cnt = int.Parse(rd["DAY_COUNT"].ToString()),
                        cust_cnt = int.Parse(rd["ORDER_COUNT"].ToString())
                    };

                    Rdata.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

                var sum = 0;
                Rdata.ForEach(i => sum += (i.cnt == 0 ? 0 : i.cust_cnt));
                Rcount = sum.ToString();
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, use_cnt = Rcount, data = Rdata, total = int.Parse(Rcount) + Rdata[0].cust_cnt });
        }


        /// <summary>
        /// 회원별 통계 - 회원 주문 순위(기간조건:ORDER_TIME 주문시간/완료주문/탈퇴회원제외)
        /// </summary>
        [HttpGet("getMemberRank")]
        public async Task<IActionResult> getMemberRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  select rownum as rnum, t.*, a.telno, a.cust_name from(SELECT a.app_cust_code, COUNT (*) order_count
                                    FROM (SELECT * FROM dorder
                                          UNION ALL
                                          SELECT * FROM dorder_past) a,
                                         callcenter b
                                   WHERE     a.cccode = b.cccode
                                         AND b.mcode = 2
                                         AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                                    AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                         AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND a.status = '40'
                                         AND a.test_gbn = 'N'
                                   group by a.app_cust_code
                                   order by COUNT (*) desc) t, app_customer a
                                   where t.app_cust_code = a.cust_code
                                   and rownum <= 30
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }
        #endregion[회원별 통계]

        #region[주문별 통계]
        /// <summary>
        /// 주문별 통계 - 전체주문(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        /// <remarks>
        /// apply_gbn 주문유형 (빈값: 전체, D: 배달, P: 포장) <br/>
        /// cancel_code 취소사유(빈값: 전체, 00: 사유없음, 10: 고객본인취소, 11: 시간지연, 20: 가맹점취소, 21: 배달불가, 22: 메뉴품절, 26: POS서버 응답없음
        /// </remarks>
        [HttpGet("getTotalOrderInfo")]
        public async Task<IActionResult> getTotalOrderInfo(string gungu, string apply_gbn, string cancel_code, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("apply_gbn", apply_gbn);
                param.Add("cancel_code", cancel_code);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string keywordSql = string.Empty;

                if (string.IsNullOrEmpty(gungu) == false)
                {
                    keywordSql = $@"AND A.DEST_GUNGU = '{gungu}'";
                }

                string sql = $@"
                                select t1.*,  TRUNC (t1.OK_CNT / t1.CNT * 100, 1)     COMP_PER,
                                              TRUNC (t1.CANCEL_CNT / t1.CNT * 100, 1) CANCEL_PER
                                from
                                (SELECT TO_CHAR (z.ORDER_TIME, 'yyyyMMdd')
                                                       ORDER_DATE,
                                                   COUNT (z.ORDER_NO)
                                                       AS CNT,
                                                   SUM (z.TOT_AMT)
                                                       AS AMT,
                                                   SUM (CASE WHEN z.STATUS = '40' THEN 1 ELSE 0 END)
                                                       AS OK_CNT,
                                                   SUM (CASE WHEN z.STATUS = '40' THEN z.TOT_AMT ELSE 0 END)
                                                       AS OK_AMT,
                                                   SUM (CASE WHEN z.STATUS = '50' and 
                                                                  (:cancel_code is null OR z.cancel_code = :cancel_code) THEN 1 ELSE 0 END)
                                                       AS CANCEL_CNT,
                                                   SUM (CASE WHEN z.STATUS = '50' and 
                                                                  (:cancel_code is null OR z.cancel_code = :cancel_code) THEN z.TOT_AMT ELSE 0 END)
                                                       AS CANCEL_AMT,
                                                   SUM (CASE WHEN z.STATUS = '30' THEN 1 ELSE 0 END)
                                                       AS SHOP_CONFIRM,
                                                   SUM (CASE WHEN z.STATUS = '40' AND NVL(z.DISC_AMT,0) = 0 AND NVL(z.MILEAGE_USE_AMT,0) = 0  THEN 1 ELSE 0 END)
                                                       AS NO_DISCOUNT_OK,
                                                       SUM (CASE WHEN z.STATUS = '50' AND NVL(z.DISC_AMT,0) = 0 AND NVL(z.MILEAGE_USE_AMT,0) = 0  THEN 1 ELSE 0 END)
                                                       AS NO_DISCOUNT_CANCEL
                                    FROM (  SELECT a.*
                                              FROM DORDER A,
                                                   CALLCENTER C,
                                                   SHOP_INFO D
                                             WHERE     A.TEST_GBN = 'N'
                                                   AND A.CCCODE = C.CCCODE
                                                   AND C.MCODE = 2
                                                   and pack_order_yn like case when :apply_gbn is null then '%' 
                                                                               when :apply_gbn = 'D' then 'N' 
                                                                               when :apply_gbn = 'P' then 'Y' end
                                                   and a.status not in  ('80','20')
                                                   and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                   AND A.SHOP_CD = D.SHOP_CD
                                                   AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                   AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                       AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                                   {keywordSql}
                                           union all
                                           SELECT a.*
                                              FROM DORDER_PAST A,
                                                   CALLCENTER C,
                                                   SHOP_INFO D
                                             WHERE     A.TEST_GBN = 'N'
                                                   AND A.CCCODE = C.CCCODE
                                                   AND C.MCODE = 2
                                                   and pack_order_yn like case when :apply_gbn is null then '%' 
                                                                               when :apply_gbn = 'D' then 'N' 
                                                                               when :apply_gbn = 'P' then 'Y' end
                                                   and a.status not in  ('80','20')
                                                   and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                   AND A.SHOP_CD = D.SHOP_CD
                                                   AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                   AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                       AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                                   {keywordSql}
                                                   ) Z
                                GROUP BY TO_CHAR (Z.ORDER_TIME, 'yyyyMMdd')) t1
                                ORDER BY t1.ORDER_DATE DESC    
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 주문별 통계 - 카테고리별 주문(기간조건:ORDER_TIME 주문시간)O + (엑셀통계 - 카테고리별 주문O)/ 완료주문만
        /// </summary>
        [HttpGet("getCategoryOrderCount")]
        public async Task<IActionResult> getCategoryOrderCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                 select b.item_cd,
                                         nvl(a.count,0) count, 
                                         nvl(a.menu_amt,0) menu_amt, 
                                         nvl(a.deli_tip_amt,0) deli_tip_amt, 
                                         nvl(a.disc_use_amt,0) disc_use_amt, 
                                         b.item_name 
                                        from (SELECT item_cd,
                                       COUNT (*) COUNT,
                                       SUM (menu_amt) menu_amt,
                                       SUM (deli_tip_amt) deli_tip_amt,
                                       NVL (SUM (disc_amt), 0) disc_use_amt
                                  FROM (SELECT b.item_cd,
                                               a.menu_amt,
                                               a.deli_tip_amt,
                                               a.disc_amt
                                          FROM dorder a,
                                               shop_info b,
                                               callcenter d
                                         WHERE a.shop_cd = b.shop_cd
                                           AND a.cccode = d.cccode
                                           AND d.mcode = 2
                                           AND b.item_cd IS NOT NULL
                                           AND a.test_gbn = 'N'
                                           and a.status = '40'
                                           --and a.status not in  ('80','20')
                                           --and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                           AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                         UNION ALL
                                SELECT b.item_cd,
                                               a.menu_amt,
                                               a.deli_tip_amt,
                                               a.disc_amt
                                          FROM dorder_past a,
                                               shop_info b,
                                               callcenter d
                                         WHERE a.shop_cd = b.shop_cd
                                           AND a.cccode = d.cccode
                                           AND d.mcode = 2
                                           AND b.item_cd IS NOT NULL
                                           AND a.test_gbn = 'N'
                                           and a.status = '40'
                                           --and a.status not in  ('80','20')
                                           --and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                           AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                 GROUP BY CUBE (item_cd)) a full outer join item_mst b
                                 on b.item_cd = a.item_cd
                                 where nvl(b.item_cd,'0') not in('1030') -- 정육은 사용
                                 order by b.item_cd
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 주문별 통계 - 시간대별 주문(기간조건:ORDER_TIME 주문시간) + 엑셀통계 - 시간대별 주문O
        /// </summary>
        [HttpGet("getTimeOrderCount")]
        public async Task<IActionResult> getTimeOrderCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  select b.item_cd,
                                        a.hh,
                                        nvl(a.count,0)count,
                                        b.item_name 
                                from(SELECT item_cd, TO_CHAR (order_time, 'HH24') AS HH, COUNT (item_cd) COUNT
                                    FROM (SELECT a.order_time, b.item_cd
                                            FROM dorder a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in  ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                          UNION ALL
                                          SELECT a.order_time, b.item_cd
                                            FROM dorder_past a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in  ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                GROUP BY CUBE (item_cd, TO_CHAR (order_time, 'HH24'))
                                ORDER BY item_cd) a full outer join item_mst b
                                on b.item_cd = a.item_cd
                                where nvl(b.item_cd,'0') not in('1029','1030')
                                order by b.item_cd
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 주문별 통계 - 결제별 주문(status All)(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        /// <remarks>
        /// A: 만나서 현금, B: 앱 카드, C: 행복페이, D: 만나서 카드, E: 네이버페이, F: 카카오페이, G: 삼성페이, H: 토스결제, I: 모바일상품권, J: 신한PG, <br/>
        /// K: 아동급식, L: BC TOP 포인트, M: KB페이, N: 대구로페이, O: 페이코, Z: 합계
        /// </remarks>
        [HttpGet("getPayOrderCountV2")]
        public async Task<IActionResult> getPayOrderCountV2(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                SELECT TEMP.ORDER_DATE, 
                                       SUM(DECODE(TEMP.PAY_GBN, '만나서 현금', TEMP.COUNT,0)) AS A, 
                                       SUM(DECODE(TEMP.PAY_GBN, '앱 카드', TEMP.COUNT,0)) AS B, 
                                       SUM(DECODE(TEMP.PAY_GBN, '행복페이', TEMP.COUNT,0)) AS C, 
                                       SUM(DECODE(TEMP.PAY_GBN, '만나서 카드', TEMP.COUNT,0)) AS D,
                                       SUM(DECODE(TEMP.PAY_GBN, '네이버페이', TEMP.COUNT,0)) AS E,
                                       SUM(DECODE(TEMP.PAY_GBN, '카카오페이', TEMP.COUNT,0)) AS F,
                                       SUM(DECODE(TEMP.PAY_GBN, '삼성페이', TEMP.COUNT,0)) AS G,
                                       SUM(DECODE(TEMP.PAY_GBN, '토스결제', TEMP.COUNT,0)) AS H,
                                       SUM(DECODE(TEMP.PAY_GBN, '모바일상품권', TEMP.COUNT,0)) AS I,
                                       SUM(DECODE(TEMP.PAY_GBN, '신한PG', TEMP.COUNT,0)) AS J,
                                       SUM(DECODE(TEMP.PAY_GBN, '아동급식카드', TEMP.COUNT,0)) AS K,
                                       SUM(DECODE(TEMP.PAY_GBN, 'BC_TOP_POINT', TEMP.COUNT,0)) AS L,
                                       SUM(DECODE(TEMP.PAY_GBN, 'KB페이', TEMP.COUNT,0)) AS M,
                                       SUM(DECODE(TEMP.PAY_GBN, '대구로페이', TEMP.COUNT,0)) AS N,
                                       SUM(DECODE(TEMP.PAY_GBN, '페이코', TEMP.COUNT,0)) AS O,
                                       SUM(DECODE(TEMP.PAY_GBN, '', TEMP.COUNT)) AS Z
                                FROM (SELECT ORDER_DATE ,
                                       DECODE(PAY_DIV, '11', '만나서 현금', 
                                                       '32', '앱 카드', 
                                                       '37', '행복페이', 
                                                       '52', '만나서 카드', 
                                                       '3N', '네이버페이',
                                                       '3K','카카오페이',
                                                       '3S','삼성페이',
                                                       '3T','토스결제',
                                                       '3V','모바일상품권',
                                                       '3H','신한PG',
                                                       '3C','아동급식카드',
                                                       '3BC','BC_TOP_POINT',
                                                       '3M','KB페이',
                                                       '3D','대구로페이',
                                                       '3P','페이코') AS pay_gbn,
                                       COUNT(*) AS COUNT
                                  FROM (SELECT TO_CHAR(ORDER_TIME, 'yyyyMMdd') AS ORDER_DATE,
                                               APP_PAY_GBN || case when app_pay_gbn = '1' then '1'
                                                                   when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                   else PAY_GBN end AS PAY_DIV
                                          FROM DORDER A,
                                               CALLCENTER B,
                                               dorder_detail c
                                         WHERE A.CCCODE = B.CCCODE
                                           AND B.MCODE = 2
                                           and a.order_no = c.order_no
                                           and a.status not in  ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND TEST_GBN = 'N'
                                           AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                           AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                         UNION ALL
                                SELECT TO_CHAR(ORDER_TIME, 'yyyyMMdd') AS ORDER_DATE,
                                               APP_PAY_GBN || case when app_pay_gbn = '1' then '1'
                                                                   when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                   else PAY_GBN end AS PAY_DIV
                                          FROM DORDER_PAST A,
                                               CALLCENTER B,
                                               dorder_detail c
                                         WHERE A.CCCODE = B.CCCODE
                                           AND B.MCODE = 2
                                           and a.order_no = c.order_no
                                           and a.status not in  ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND TEST_GBN = 'N'
                                           AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                           AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                 GROUP BY CUBE(ORDER_DATE, PAY_DIV)
                                 ORDER BY ORDER_DATE DESC, PAY_GBN) TEMP
                                 WHERE TEMP.ORDER_DATE <> ' '
                                 GROUP BY TEMP.ORDER_DATE 
                                 ORDER BY TEMP.ORDER_DATE DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        // 취소사유별 현황(미사용)O
        [HttpGet("getCancelReason")]
        public async Task<IActionResult> getCancelReason(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  SELECT DECODE (cancel_code,
                                                 '00', '사유없음',
                                                 '10', '고객본인취소',
                                                 '11', '시간지연',
                                                 '12', '재접수',
                                                 '20', '가맹점취소',
                                                 '21', '배달불가',
                                                 '22', '메뉴품절',
                                                 '23', '가맹점휴무',
                                                 '24', '주소입력오류',
                                                 '25', '가맹점 정산 접수거부',
                                                 '26', 'POS서버 응답없음',
                                                 '30', '결재대기 자동취소',
                                                 '40', '예약주문 고객 취소',
                                                 '45', '예약주문 가맹점 취소')
                                             cancel_code,
                                         COUNT (cancel_code)
                                             COUNT
                                    FROM (SELECT * FROM dorder
                                          UNION
                                          SELECT * FROM dorder_past) a,
                                         callcenter b
                                   WHERE     b.mcode = 2
                                         AND a.test_gbn = 'N'
                                         and a.cancel_code in ('00','10','11','20','21','22','26')
                                         AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND a.order_date BETWEEN :date_begin AND :date_end
                                GROUP BY cancel_code
                                ORDER BY COUNT DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        // 일자별 군구별 주문현황
        /// <summary>
        /// 엑셀통계 - 군구별 주문(기간조건:ORDER_TIME 주문시간)O -*엑셀 컨트롤러로 이동
        /// </summary>
        [HttpGet("getGunguOrder")]
        public async Task<IActionResult> getGunguOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  SELECT ORDER_DATE, GUNGU AS GUNGU_NAME, COUNT (GUNGU) AS COUNT
                                    FROM (SELECT TO_CHAR (ORDER_TIME, 'YYYYMMDD')
                                                     ORDER_DATE,
                                                 CASE
                                                     WHEN PACK_ORDER_YN = 'Y'
                                                     THEN
                                                         '포장'
                                                     WHEN PACK_ORDER_YN = 'N' AND DEST_GUNGU IS NULL
                                                     THEN
                                                         '기타'
                                                     ELSE
                                                         DEST_GUNGU
                                                 END
                                                     AS GUNGU
                                            FROM DORDER A, CALLCENTER B
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 AND A.TEST_GBN = 'N'
                                                 AND ORDER_TIME > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 and a.status not in  ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                          UNION ALL
                                          SELECT TO_CHAR (ORDER_TIME, 'YYYYMMDD')
                                                     ORDER_DATE,
                                                 CASE
                                                     WHEN PACK_ORDER_YN = 'Y'
                                                     THEN
                                                         '포장'
                                                     WHEN PACK_ORDER_YN = 'N' AND DEST_GUNGU IS NULL
                                                     THEN
                                                         '기타'
                                                     ELSE
                                                         DEST_GUNGU
                                                 END
                                                     AS GUNGU
                                            FROM DORDER_PAST A, CALLCENTER B
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 AND A.TEST_GBN = 'N'
                                                 AND ORDER_TIME > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 and a.status not in  ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                GROUP BY CUBE (ORDER_DATE, GUNGU)
                                ORDER BY ORDER_DATE desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        // 일자별 군구별 주문현황
        /// <summary>
        /// 주문별 통계 - 군구별 주문(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        [HttpGet("getGunguOrderV2")]
        public async Task<IActionResult> getGunguOrderV2(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  SELECT TEMP.ORDER_DATE,
                                           SUM(DECODE(TEMP.GUNGU_NAME, '남구', TEMP.COUNT)) AS A, 
                                           SUM(DECODE(TEMP.GUNGU_NAME, '달서구', TEMP.COUNT)) AS B, 
                                           SUM(DECODE(TEMP.GUNGU_NAME, '달성군', TEMP.COUNT)) AS C, 
                                           SUM(DECODE(TEMP.GUNGU_NAME, '동구', TEMP.COUNT)) AS D,
                                           SUM(DECODE(TEMP.GUNGU_NAME, '북구', TEMP.COUNT)) AS E,
                                           SUM(DECODE(TEMP.GUNGU_NAME, '서구', TEMP.COUNT)) AS F,
                                           SUM(DECODE(TEMP.GUNGU_NAME, '수성구', TEMP.COUNT)) AS G,
                                           SUM(DECODE(TEMP.GUNGU_NAME, '중구', TEMP.COUNT)) AS H,
                                           SUM(DECODE(TEMP.GUNGU_NAME, '포장', TEMP.COUNT)) AS I
                                    FROM
                                    (SELECT ORDER_DATE, GUNGU AS GUNGU_NAME, COUNT (GUNGU) AS COUNT
                                    FROM (SELECT TO_CHAR (ORDER_TIME, 'YYYYMMDD')
                                                     ORDER_DATE,
                                                 CASE
                                                     WHEN PACK_ORDER_YN = 'Y'
                                                     THEN
                                                         '포장'
                                                     WHEN PACK_ORDER_YN = 'N' AND DEST_GUNGU IS NULL
                                                     THEN
                                                         '기타'
                                                     ELSE
                                                         DEST_GUNGU
                                                 END
                                                     AS GUNGU
                                            FROM DORDER A, CALLCENTER B
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 AND A.TEST_GBN = 'N'
                                                 AND ORDER_TIME > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 and a.status not in  ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                          UNION ALL
                                          SELECT TO_CHAR (ORDER_TIME, 'YYYYMMDD')
                                                     ORDER_DATE,
                                                 CASE
                                                     WHEN PACK_ORDER_YN = 'Y'
                                                     THEN
                                                         '포장'
                                                     WHEN PACK_ORDER_YN = 'N' AND DEST_GUNGU IS NULL
                                                     THEN
                                                         '기타'
                                                     ELSE
                                                         DEST_GUNGU
                                                 END
                                                     AS GUNGU
                                            FROM DORDER_PAST A, CALLCENTER B
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 AND A.TEST_GBN = 'N'
                                                 AND ORDER_TIME > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 and a.status not in  ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                    GROUP BY CUBE (ORDER_DATE, GUNGU)
                                    ORDER BY ORDER_DATE desc) TEMP
                                    GROUP BY TEMP.ORDER_DATE 
                                    ORDER BY case when TEMP.ORDER_DATE is not null then TEMP.ORDER_DATE else '20210808' end desc 
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        // 가맹점 주문량순위 리스트O(미사용)
        [HttpGet("getShopOrderRank")]
        public async Task<IActionResult> getShopOrderRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string keywordSql = string.Empty;

                string sql = $@"
                                  select rownum, a.*
                                    from
                                        (SELECT  Z.shop_name,
                                                    Z.CNT,
                                                    Z.OK_CNT,
                                                    Z.CANCEL_CNT,
                                                    i.telno,
                                                    TO_CHAR(i.open_dt,'yyyyMMdd') AS OPEN_DT
                                            FROM (  SELECT  d.shop_cd,
                                                            d.shop_name,
                                                            COUNT (A.ORDER_NO)
                                                                AS CNT,
                                                            SUM (CASE WHEN A.STATUS = '40' THEN 1 ELSE 0 END)
                                                                AS OK_CNT,
                                                            SUM (CASE WHEN A.STATUS = '50' THEN 1 ELSE 0 END)
                                                                AS CANCEL_CNT,
                                                            SUM (CASE WHEN A.STATUS = '30' THEN 1 ELSE 0 END)
                                                                AS SHOP_CONFIRM
                                                        FROM (SELECT * FROM DORDER
                                                            UNION ALL
                                                            SELECT * FROM DORDER_PAST) A,
                                                            CALLCENTER C,
                                                            SHOP_INFO D
                                                        WHERE   A.TEST_GBN = 'N'
                                                            AND A.CCCODE = C.CCCODE
                                                            AND C.MCODE = 2
                                                            and a.status not in  ('80','20')
                                                            and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                            AND A.SHOP_CD = D.SHOP_CD
                                                            AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                            AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                        AND :date_end
                                                    GROUP BY d.shop_cd, d.shop_name) Z, shop_info i
                                                    where z.shop_cd = i.shop_cd
                                        ORDER BY Z.cnt DESC) a
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        // 결제 구분(앱, 만나서) 주문일, 결제구분, 일반카드건수, 일반카드금액, 행복페이건수, 행복페이금액, 만나서카드건수, 만나서카드금액, 만나서현금건수, 만나서현금금액 + 페이류 추가
        /// <summary>
        /// 주문별 통계 - 일자별 결제(완료건만)(기간조건:ORDER_TIME 주문시간)
        /// </summary>
        /// <remarks>
        /// 결제금액 기준(AMOUNT)
        /// </remarks>
        [HttpGet("getDailyOrderPyaGbn")]
        public async Task<IActionResult> getDailyOrderPyaGbn(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT T1.ORDER_DATE
                                             주문일,
                                         case when T1.PAY_DIV = '11' then '만나서 현금'
                                              when T1.PAY_DIV = '32' then '앱 카드'
                                              when T1.PAY_DIV = '37' then '행복페이'
                                              when T1.PAY_DIV = '52' then '만나서 카드'
                                              when T1.PAY_DIV = '3N' then '네이버페이'
                                              when T1.PAY_DIV = '3K' then '카카오페이'
                                              when T1.PAY_DIV = '3S' then '삼성페이' 
                                              when T1.PAY_DIV = '3T' then '토스결제' 
                                              when T1.PAY_DIV = '3V' then '모바일상품권' 
                                              when T1.PAY_DIV = '3H' then '신한PG' 
                                              when T1.PAY_DIV = '3C' then '아동급식카드' 
                                              when T1.PAY_DIV = '3BC' then 'BC_TOP_POINT' 
                                              when T1.PAY_DIV = '3M' then 'KB페이' 
                                              when T1.PAY_DIV = '3D' then '대구로페이' 
                                              when T1.PAY_DIV = '3P' then '페이코' 
                                         end as 결제구분,
                                         COUNT (CASE WHEN T2.PAY_DIV = '32' THEN 1 END)
                                             AS 일반카드건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '32' THEN AMOUNT END)
                                             AS 일반카드금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '37' THEN 1 END)
                                             AS 행복페이건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '37' THEN AMOUNT END)
                                             AS 행복페이금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '52' THEN 1 END)
                                             AS 만나서카드건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '52' THEN AMOUNT END)
                                             AS 만나서카드금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '11' THEN 1 END)
                                             AS 만나서현금건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '11' THEN AMOUNT END)
                                             AS 만나서현금금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '3N' THEN 1 END)
                                             AS 네이버페이건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '3N' THEN AMOUNT END)
                                             AS 네이버페이금액,
                                        COUNT (CASE WHEN T2.PAY_DIV = '3K' THEN 1 END)
                                             AS 카카오페이건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '3K' THEN AMOUNT END)
                                             AS 카카오페이금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '3S' THEN 1 END)
                                             AS 삼성페이건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '3S' THEN AMOUNT END)
                                             AS 삼성페이금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '3T' THEN 1 END)
                                             AS 토스결제건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '3T' THEN AMOUNT END)
                                             AS 토스결제금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '3V' THEN 1 END)
                                             AS 모바일상품권건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '3V' THEN AMOUNT END)
                                             AS 모바일상품권금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '3H' THEN 1 END)
                                             AS 신한PG건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '3H' THEN AMOUNT END)
                                             AS 신한PG금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '3C' THEN 1 END)
                                             AS 아동급식카드건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '3C' THEN AMOUNT END)
                                             AS 아동급식카드금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '3BC' THEN 1 END)
                                             AS BC_TOP_POINT건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '3BC' THEN AMOUNT END)
                                             AS BC_TOP_POINT금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '3M' THEN 1 END)
                                             AS KB페이건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '3M' THEN AMOUNT END)
                                             AS KB페이금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '3D' THEN 1 END)
                                             AS 대구로페이건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '3D' THEN AMOUNT END)
                                             AS 대구로페이금액,
                                         COUNT (CASE WHEN T2.PAY_DIV = '3P' THEN 1 END)
                                             AS 페이코건수,
                                         SUM (CASE WHEN T2.PAY_DIV = '3P' THEN AMOUNT END)
                                             AS 페이코금액
                                    FROM(SELECT to_char(X.daily,'YYYYMMDD') ORDER_DATE, Y.PAY_DIV
                                        FROM(SELECT to_date('20210101','YYYYMMDD') + LEVEL - 1 AS daily
                                            FROM DUAL
                                            CONNECT BY LEVEL <= (to_date('30211231','YYYYMMDD') - to_date('20210101','YYYYMMDD') + 1)) X, 
                                            (SELECT APP_PAY_GBN || PAY_GBN AS PAY_DIV
                                            FROM PAYMENT_MNG
                                            UNION ALL
                                            SELECT '3BC' AS PAY_DIV
                                            FROM DUAL) Y
                                        WHERE X.daily between :date_begin and :date_end) T1,
                                        (SELECT TO_CHAR (ORDER_TIME, 'yyyyMMdd')     AS ORDER_DATE,
                                                 APP_PAY_GBN || case when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                     else PAY_GBN end AS PAY_DIV,
                                                 AMOUNT
                                            FROM DORDER A, CALLCENTER B, dorder_detail c
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 and a.order_no = c.order_no
                                                 AND NVL (CANCEL_CODE, '00') <> '30'
                                                 AND TEST_GBN = 'N'
                                                 AND STATUS = '40'
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                          UNION ALL
                                          SELECT TO_CHAR (ORDER_TIME, 'yyyyMMdd')     AS ORDER_DATE,
                                                 APP_PAY_GBN || case when app_pay_gbn = '1' then '1' -- 현금결제의 아이폰 오류데이터('12')를 걸러주기 위함
                                                                     when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                     else PAY_GBN end AS PAY_DIV, 
                                                 AMOUNT
                                            FROM DORDER_PAST A, CALLCENTER B, dorder_detail c
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 and a.order_no = c.order_no
                                                 AND NVL (CANCEL_CODE, '00') <> '30'
                                                 AND TEST_GBN = 'N'
                                                 AND STATUS = '40'
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')) T2
                                where T1.ORDER_DATE = T2.ORDER_DATE (+)
                                AND T1.pay_div = T2.pay_div (+)
                                AND T1.pay_div in ('11','32','37','52','3N','3K','3S','3T','3V','3H','3C','3BC','3M','3D','3P')
                                GROUP BY T1.ORDER_DATE, T1.PAY_DIV
                                ORDER BY 주문일 DESC, 결제구분
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 일자별 주문수(연령대별) 조회
        /// <summary>
        /// 주문별 통계 - 연령별 주문(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        [HttpGet("getDailyAgeToOrder")]
        public async Task<IActionResult> getDailyAgeToOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT TEMP.ORDER_DATE,
                                       nvl(SUM(DECODE(TEMP.birthday, '10대', TEMP.COUNT)),0) AS A,
                                       nvl(SUM(DECODE(TEMP.birthday, '10대', TEMP.COMP)),0) AS A_COMP, 
                                       nvl(SUM(DECODE(TEMP.birthday, '10대', TEMP.CANC)),0) AS A_CANC,
                                       nvl(SUM(DECODE(TEMP.birthday, '20대', TEMP.COUNT)),0) AS B, 
                                       nvl(SUM(DECODE(TEMP.birthday, '20대', TEMP.COMP)),0) AS B_COMP, 
                                       nvl(SUM(DECODE(TEMP.birthday, '20대', TEMP.CANC)),0) AS B_CANC,
                                       nvl(SUM(DECODE(TEMP.birthday, '30대', TEMP.COUNT)),0) AS C, 
                                       nvl(SUM(DECODE(TEMP.birthday, '30대', TEMP.COMP)),0) AS C_COMP, 
                                       nvl(SUM(DECODE(TEMP.birthday, '30대', TEMP.CANC)),0) AS C_CANC,
                                       nvl(SUM(DECODE(TEMP.birthday, '40대', TEMP.COUNT)),0) AS D,
                                       nvl(SUM(DECODE(TEMP.birthday, '40대', TEMP.COMP)),0) AS D_COMP, 
                                       nvl(SUM(DECODE(TEMP.birthday, '40대', TEMP.CANC)),0) AS D_CANC,
                                       nvl(SUM(DECODE(TEMP.birthday, '50대', TEMP.COUNT)),0) AS E,
                                       nvl(SUM(DECODE(TEMP.birthday, '50대', TEMP.COMP)),0) AS E_COMP, 
                                       nvl(SUM(DECODE(TEMP.birthday, '50대', TEMP.CANC)),0) AS E_CANC,
                                       nvl(SUM(DECODE(TEMP.birthday, '60대', TEMP.COUNT)),0) AS F,
                                       nvl(SUM(DECODE(TEMP.birthday, '60대', TEMP.COMP)),0) AS F_COMP, 
                                       nvl(SUM(DECODE(TEMP.birthday, '60대', TEMP.CANC)),0) AS F_CANC,
                                       nvl(SUM(DECODE(TEMP.birthday, '70대', TEMP.COUNT)),0) AS G,
                                       nvl(SUM(DECODE(TEMP.birthday, '70대', TEMP.COMP)),0) AS G_COMP, 
                                       nvl(SUM(DECODE(TEMP.birthday, '70대', TEMP.CANC)),0) AS G_CANC,
                                       nvl(SUM(DECODE(TEMP.birthday, '80대', TEMP.COUNT)),0) AS H,
                                       nvl(SUM(DECODE(TEMP.birthday, '80대', TEMP.COMP)),0) AS H_COMP, 
                                       nvl(SUM(DECODE(TEMP.birthday, '80대', TEMP.CANC)),0) AS H_CANC,
                                       nvl(SUM(DECODE(TEMP.birthday, '90대', TEMP.COUNT)),0) AS I,
                                       nvl(SUM(DECODE(TEMP.birthday, '90대', TEMP.COMP)),0) AS I_COMP, 
                                       nvl(SUM(DECODE(TEMP.birthday, '90대', TEMP.CANC)),0) AS I_CANC
                                FROM (
                                SELECT case when birthday < 1 then 1
                                            when birthday > 9 then 9
                                            else birthday end || '0대' AS birthday, COUNT (*) COUNT, 
                                                                COUNT(CASE WHEN STATUS = '40' THEN 1 END) AS COMP, 
                                                                COUNT(CASE WHEN STATUS = '50' THEN 1 END) AS CANC,
                                                                order_date
                                                        FROM (SELECT trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                                                     birthday, STATUS, order_date
                                                            FROM (SELECT cust_code,
                                                                            birthday
                                                                    FROM app_customer
                                                                    WHERE     mcode = 2
                                                                        AND test_gbn = 'R'
                                                                        -- AND insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                        AND birthday IS NOT NULL
                                                                    UNION ALL
                                                                    SELECT cust_code,
                                                                            birthday
                                                                    FROM app_customer_deleted
                                                                    WHERE     mcode = 2
                                                                        AND test_gbn = 'R'
                                                                        -- AND insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                        AND birthday IS NOT NULL) a, 
                                                                (select ccode, STATUS, TO_CHAR(ORDER_TIME,'YYYYMMDD') order_date from dorder
                                                                where ORDER_TIME between TO_DATE(:date_begin || ' 000000','YYYYMMDD HH24MISS') and TO_DATE(:date_end || ' 235959','YYYYMMDD HH24MISS')
                                                                    AND TEST_GBN = 'N'
                                                                    and status not in  ('80','20')
                                                                    and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                union all
                                                                select ccode, STATUS, TO_CHAR(ORDER_TIME,'YYYYMMDD') order_date from dorder_past
                                                                where ORDER_TIME between TO_DATE(:date_begin || ' 000000','YYYYMMDD HH24MISS') and TO_DATE(:date_end || ' 235959','YYYYMMDD HH24MISS')
                                                                    AND TEST_GBN = 'N'
                                                                    and status not in  ('80','20')
                                                                    and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26')) b
                                                            where a.cust_code = b.ccode
                                                            )
                                                GROUP BY CUBE (case when birthday < 1 then 1
                                                                    when birthday > 9 then 9
                                                                    else birthday end ), order_date
                                                ORDER BY order_date ) TEMP
                                GROUP BY TEMP.ORDER_DATE
                                ORDER BY TEMP.ORDER_DATE desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 주문별 통계 - 일자별 주문수(서비스별) 조회(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        /// <remarks>
        /// 집계 + 실시간 데이터 조합
        /// </remarks>
        [HttpGet("getDailyServiceToOrder")]
        public async Task<IActionResult> getDailyServiceToOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("in_date_begin", date_begin);
                param.Add("in_date_end", date_end);

                db.Open();

                string sql = string.Empty;

                sql = @"
                        select listagg(service_gbn,',') within group(order by sort_seq) as services
                        from shop_service_mst
                ";

                var services = await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);

                sql = $@"
                        select * 
                        from(select stat_date,
                                    service_gbn,
                                    tot_cnt,
                                    comp_cnt,
                                    cancel_cnt,
                                    tot_cnt - nvl(comp_cnt,0) - nvl(cancel_cnt,0) ing_cnt
                                from dgr_service_stat
                                where stat_date between :in_date_begin and :in_date_end
                                union all
                                select :in_date_end stat_date,
                                    b.service_gbn,
                                    count(1) tot_cnt,
                                    sum(case when a.status = '40' then 1 end) comp_cnt,
                                    sum(case when a.status = '50' then 1 end) cancel_cnt,
                                    sum(case when a.status not in ('40','50') then 1 end) ing_cnt
                                from dorder a, shop_info b, callcenter c
                                where a.shop_cd = b.shop_cd
                                and b.cccode = c.cccode
                                and c.mcode = 2
                                -- 새벽 5시 집계이므로 5시 이전 조회시 전일포함 조회
                                and a.order_time between to_date(to_char(case when to_char(sysdate,'HH24') < '05' then sysdate - 1 else sysdate end ,'YYYYMMDD'),'YYYYMMDD') and to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                AND   A.TEST_GBN = 'N'
                                AND   A.STATUS NOT IN ('80','20')
                                and   case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                group by b.service_gbn)
                        pivot (sum(tot_cnt) tot_cnt, sum(comp_cnt) comp_cnt, sum(cancel_cnt) cancel_cnt, sum(ing_cnt) ing_cnt for service_gbn in ({services}))
                        order by stat_date desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 주문별 통계 - 일자별 주문수(카테고리별) 조회(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        /// <remarks>
        /// 실시간 데이터 이용 <br/>
        /// 완료주문만, 주문완료건수, 결제완료금액(모상 사용금액 포함) <br/>
        /// </remarks>
        [HttpGet("getDailyCategoryOrder")]
        public async Task<IActionResult> getDailyCategoryOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("in_date_begin", date_begin);
                param.Add("in_date_end", date_end);

                db.Open();

                string sql = string.Empty;

                sql = @"
                        select listagg(item_cd,',') within group(order by sort_seq) as itemes
                        from item_mst
                        where item_cd not in('1030')
                ";

                var itemes = await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);

                sql = $@"
                        SELECT *
                        FROM(SELECT TO_CHAR(ORDER_TIME, 'yyyyMMdd') AS ORDER_DATE,
                                    C.item_cd,
                                    A.AMOUNT + nvl(A.VOUCHER_USE_AMT,0) AS AMOUNT
                            FROM DORDER A,
                                CALLCENTER B,
                                SHOP_INFO C
                            WHERE A.CCCODE = B.CCCODE
                            AND A.SHOP_CD = C.SHOP_CD
                            AND B.MCODE = 2
                            and a.status = '40'
                            AND TEST_GBN = 'N'
                            AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                            AND a.order_time BETWEEN to_date(:in_date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                AND to_date(:in_date_end || ' 235959', 'YYYYMMDD HH24MISS')
                            UNION ALL
                            SELECT TO_CHAR(ORDER_TIME, 'yyyyMMdd') AS ORDER_DATE,
                                    C.item_cd,
                                    A.AMOUNT + nvl(A.VOUCHER_USE_AMT,0) AS AMOUNT
                            FROM DORDER_PAST A,
                                CALLCENTER B,
                                SHOP_INFO C
                            WHERE A.CCCODE = B.CCCODE
                            AND A.SHOP_CD = C.SHOP_CD
                            AND B.MCODE = 2
                            and a.status = '40'
                            AND TEST_GBN = 'N'
                            AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                            AND a.order_time BETWEEN to_date(:in_date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                AND to_date(:in_date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                        pivot (COUNT(1) cnt, SUM(AMOUNT) amount for item_cd in ({itemes}))
                    ORDER BY ORDER_DATE DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// (미사용)주문별 통계 - 주문 미접수 콜(집계테이블 조회)
        /// </summary>
        /// <remarks>
        /// 테스트db에서 조회 불가 <br/>
        /// daily_total_date 집계일자 <br/>
        /// total_cnt 전체 발송건수 <br/>
        /// success_cnt 성공건수 <br/>
        /// fail_cnt 실패건수 <br/>
        /// </remarks>
        [HttpGet("getDailyVmsCall")]
        public async Task<IActionResult> getDailyVmsCall(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "99";
                Rmsg = "기간조건은 필수입니다.";
                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                select daily_total_date ""daily_total_date"", fail_cnt ""fail_cnt"", success_cnt ""success_cnt"", total_cnt ""total_cnt""
                                from lms.vms_call_hist
                                where daily_total_date between :date_begin and :date_end
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 주문별 통계 - 주문 미접수 콜(집계테이블 조회)
        /// </summary>
        /// <remarks>
        /// div 구분 (1 : 일별, 2 : 월별, 3 : 총합)(필수)
        /// </remarks>
        [HttpGet("getDailyVmsCallV2")]
        public async Task<IActionResult> getDailyVmsCallV2(string div, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<DailyVmsCall> Rdata = new List<DailyVmsCall>();

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

                using OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_TOTAL.GET_DAILY_VMS_CALL",
                };

                cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 10).Value = div;
                cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = date_begin;
                cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = date_end;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;


                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    DailyVmsCall item = new DailyVmsCall
                    {
                        dt = rd["dt"].ToString(),
                        success_cnt = rd["success_cnt"].ToString(),
                        s_receipt_cnt = rd["s_receipt_cnt"].ToString(),
                        s_cancel_cnt = rd["s_cancel_cnt"].ToString(),
                        fail_cnt = rd["fail_cnt"].ToString(),
                        f_receipt_cnt = rd["f_receipt_cnt"].ToString(),
                        f_cancel_cnt = rd["f_cancel_cnt"].ToString(),
                    };

                    Rdata.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        #endregion[주문별 통계]


        #region[쿠폰 통계]
        // 대구로 쿠폰 통계(미사용)
        [HttpGet("getDGRCoupon")]
        public async Task<IActionResult> getDGRCoupon(string coupon_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_coupon_name", coupon_name);

                string sql = @"
                                SELECT mon,
                                        sum(INS_CNT) as INS_CNT,
                                        sum(USE_CNT) as USE_CNT,
                                        sum(DIS_USE_CNT) as DIS_USE_CNT,
                                        sum(EXP_CNT) as EXP_CNT,
                                        sum(INS_AMT) as INS_AMT,
                                        sum(USE_AMT) as USE_AMT,
                                        sum(DIS_USE_AMT) as DIS_USE_AMT,
                                        sum(EXP_AMT) as EXP_AMT
                                FROM(
                                        SELECT mon, coupon_amt,
                                                COUNT(case when ins_c = mon then 1 end) AS INS_CNT,
                                                COUNT(case when use_c = mon then 1 end) AS USE_CNT,
                                                COUNT(case when dis_use_c = mon then 1 end) AS DIS_USE_CNT,
                                                COUNT(case when exp_c = mon then 1 end ) AS EXP_CNT,
                                                COUNT(case when ins_c = mon then 1 end) * coupon_amt as INS_AMT,
                                                COUNT(case when use_c = mon then 1 end) * coupon_amt as USE_AMT,
                                                COUNT(case when dis_use_c = mon then 1 end) * coupon_amt as DIS_USE_AMT,
                                                COUNT(case when exp_c = mon then 1 end) * coupon_amt as EXP_AMT
                                        FROM (SELECT substr(ins_date,1,6) AS mon, coupon_amt, substr(ins_date,1,6) AS ins_c, 
                                                to_char(use_date,'YYYYMM') AS use_c, 
                                                to_char(dis_use_date,'YYYYMM') AS dis_use_c, 
                                                substr(exp_date,1,6) AS exp_c
                                                FROM coupon_mst
                                                WHERE conf_yn = 'Y' 
                                                AND ins_date >= '2021080917'
                                                --and to_char(use_date, 'YYYYMMDD') between :date_begin and :date_end
                                                AND coupon_name not like '%테스트%'     --테스트쿠폰 제외
                                                AND (:in_coupon_name is null or
                                                        coupon_name like :in_coupon_name || '%')
                                            )
                                        GROUP BY mon, coupon_amt)
                                GROUP BY CUBE (mon)
                                ORDER BY mon desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Total/getDGRCoupon : Get", ex.Message);
            }



            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 쿠폰 통계 - 대구로 쿠폰 통계(일별) -- 미사용
        /// </summary>
        [HttpGet("getDailyDGRCoupon")]
        public async Task<IActionResult> getDailyDGRCoupon(string type, string coupon_type, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("in_type", type);
                param.Add("in_coupon_type", coupon_type);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT TEMP.daily,
                                       NVL(SUM(DECODE(TEMP.coupon_amt, '500', TEMP.type_date)),0) AS A,
                                       NVL(SUM(DECODE(TEMP.coupon_amt, '500', TEMP.type_date)*TEMP.coupon_amt),0) AS A2,
                                       NVL(SUM(DECODE(TEMP.coupon_amt, '2000', TEMP.type_date)),0) AS B,
                                       NVL(SUM(DECODE(TEMP.coupon_amt, '2000', TEMP.type_date)*TEMP.coupon_amt),0) AS B2,
                                       NVL(SUM(DECODE(TEMP.coupon_amt, '3000', TEMP.type_date)),0) AS C,
                                       NVL(SUM(DECODE(TEMP.coupon_amt, '3000', TEMP.type_date)*TEMP.coupon_amt),0) AS C2,
                                       NVL(SUM(DECODE(TEMP.coupon_amt, '5000', TEMP.type_date)),0) AS D,
                                       NVL(SUM(DECODE(TEMP.coupon_amt, '5000', TEMP.type_date*TEMP.coupon_amt)),0) AS D2,
                                       NVL(SUM(DECODE(TEMP.coupon_amt, '10000', TEMP.type_date)),0) AS E,
                                       NVL(SUM(DECODE(TEMP.coupon_amt, '10000', TEMP.type_date)*TEMP.coupon_amt),0) AS E2
                                 FROM 
                                        (select b.daily, a.coupon_amt, 
                                                (CASE  WHEN :in_type = 0 THEN count(case when a.ins_date = b.daily then 1 end)
                                                           WHEN :in_type = 1 THEN count(case when a.st_date = b.daily and a.status <> '00' and a.status <> '10' then 1 end)
                                                           WHEN :in_type = 2 THEN count(case when a.use_date = b.daily then 1 end)
                                                           WHEN :in_type = 3 THEN count(case when a.dis_use_date = b.daily then 1 end)
                                                           WHEN :in_type = 4 THEN count(case when a.exp_date = b.daily and a.status = '40' then 1 end) END) as type_date
                                        FROM (select 
                                               coupon_amt, 
                                               ins_date,
                                               st_date,
                                               to_char(use_date,'YYYYMMDD') as use_date,
                                               to_char(dis_use_date,'YYYYMMDD') as dis_use_date,
                                               exp_date,
                                               status
                                                from coupon_mst
                                                where conf_yn = 'Y'     --승인여부 Y
                                                and (CASE WHEN :in_type = 0 THEN ins_date
                                                          WHEN :in_type = 1 THEN st_date
                                                          WHEN :in_type = 2 THEN to_char(use_date,'YYYYMMDD')
                                                          WHEN :in_type = 3 THEN to_char(dis_use_date,'YYYYMMDD')
                                                          WHEN :in_type = 4 THEN exp_date END) between :date_begin and :date_end --쿠폰 상태별
                                                and coupon_name not like '%테스트%'     --테스트쿠폰 제외
                                                and (:in_coupon_type is null or     --쿠폰 이름으로 검색  
                                                        coupon_type = :in_coupon_type)) a,
                                                (SELECT daily FROM (SELECT to_date('20210101','YYYYMMDD') + LEVEL - 1 AS daily
                                                    FROM dual
                                                    CONNECT BY LEVEL <= (to_date('30211231','YYYYMMDD') - to_date('20210101','YYYYMMDD') + 1))
                                                    WHERE daily between :date_begin and :date_end
                                                    ) b --데이터가 없어도 0건으로 날짜 표기해주기 위함
                                 WHERE b.daily = (CASE WHEN :in_type = 0 THEN a.ins_date(+)
                                                          WHEN :in_type = 1 THEN a.st_date(+)
                                                          WHEN :in_type = 2 THEN a.use_date(+)
                                                          WHEN :in_type = 3 THEN a.dis_use_date(+)
                                                          WHEN :in_type = 4 THEN a.exp_date(+) END)
                                 GROUP BY CUBE (b.daily,a.coupon_amt)
                                 ORDER BY b.daily) TEMP
                                 GROUP BY TEMP.daily
                                 ORDER BY case when temp.daily is not null then TEMP.daily else to_date('20210808','YYYYMMDD') end desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Total/getDailyDGRCoupon : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 쿠폰 통계 - 대구로 쿠폰 통계(일별) 수정버전(기간조건: 쿠폰 상태 변경일시)
        /// </summary>
        /// <remarks>
        /// A 천원, B 2천원, C 3천원, D 5천원, E 만원, F 만오천원, G 2만원, H 3만원 <br/>
        /// 발행 F_INS <br/>
        /// 지급 E_PUB <br/>
        /// 사용 D_USED <br/>
        /// 만료 C_EXP = 발행후 만료건만 포함 <br/>
        /// 폐기 B_DIS_USE 지급후 폐기량만 포함 <br/>
        /// 잔여 A_LEFT(잔여=지급-사용-만료-폐기)
        /// </remarks>
        [HttpGet("getDailyDGRCouponV2")]
        public async Task<IActionResult> getDailyDGRCouponV2(string coupon_type, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("coupon_type", coupon_type);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();
                // dgr_coupon_total 테이블로 만든 대구로 쿠폰 통계
                string sql = $@"  
                                select daily, status, nvl(""1000_CNT"",0) as A1,  nvl(""1000_AMT"",0) as A2, nvl(""2000_CNT"",0) as B1, nvl(""2000_AMT"",0) as B2, 
                                                nvl(""3000_CNT"", 0) as C1,  nvl(""3000_AMT"", 0) as C2, nvl(""5000_CNT"", 0) as D1, nvl(""5000_AMT"", 0) as D2, 
                                                nvl(""10000_CNT"", 0) as E1, nvl(""10000_AMT"", 0) as E2, nvl(""15000_CNT"", 0) as F1, nvl(""15000_AMT"", 0) as F2,
                                                nvl(""20000_CNT"", 0) as G1, nvl(""20000_AMT"", 0) as G2, nvl(""30000_CNT"", 0) as H1, nvl(""30000_AMT"", 0) as H2
                                        from(
                                        SELECT * FROM(SELECT * FROM(SELECT B.DAILY, A.ins_cnt, A.pub_cnt, A.used_cnt, A.dis_use_cnt, A.EXP_CNT, A.LEFT_CNT, A.COUPON_AMT
                                    FROM(select total_date, ins_cnt, pub_cnt, used_cnt, (dis_use_pub_cnt) DIS_USE_CNT, (exp_pub_cnt) EXP_CNT, --발행후 만료만
                                       sum(pub_cnt) over(partition by coupon_amt order by total_date rows unbounded preceding)
                                       - sum(used_cnt) over(partition by coupon_amt order by total_date rows unbounded preceding)
                                       - sum(exp_pub_cnt) over(partition by coupon_amt order by total_date rows unbounded preceding)
                                       - sum(dis_use_pub_cnt) over(partition by coupon_amt order by total_date rows unbounded preceding) LEFT_CNT, coupon_amt --(잔여=지급-사용-만료-폐기)
                                                        from(
                                                            select total_date,
                                                            sum(ins_cnt) ins_cnt,
                                                            sum(pub_cnt) pub_cnt,
                                                            sum(used_cnt) used_cnt,
                                                            sum(dis_use_ins_cnt) dis_use_ins_cnt,
                                                            sum(dis_use_pub_cnt) dis_use_pub_cnt,
                                                            sum(exp_ins_cnt) exp_ins_cnt,
                                                            sum(exp_pub_cnt) exp_pub_cnt,
                                                            coupon_amt
                                                            from dgr_coupon_total
                                                            where coupon_type like case when: coupon_type is null then '%' else :coupon_type end
                                                            GROUP BY total_date, coupon_amt
                                                        )) A,
                                                        (SELECT daily FROM(SELECT to_date('30211231','YYYYMMDD') +-LEVEL  AS daily
                                                            FROM dual
                                                            CONNECT BY LEVEL <= (to_date('30211231', 'YYYYMMDD') - to_date('20210101', 'YYYYMMDD') + 1))
                                                            WHERE daily between: date_begin and :date_end) b
                                                            WHERE B.DAILY = A.TOTAL_DATE(+))
                                        UNPIVOT(COUPON_CNT FOR STATUS IN(INS_CNT AS 'F_INS', PUB_CNT AS 'E_PUB', USED_CNT AS 'D_USED', EXP_CNT AS 'C_EXP', DIS_USE_CNT AS 'B_DIS_USE', LEFT_CNT AS 'A_LEFT')))
                                pivot(sum(COUPON_CNT) cnt, sum(COUPON_CNT * coupon_amt) amt
                                        for coupon_amt in (1000, 2000, 3000, 5000, 10000,15000,20000,30000)))
                                        ORDER BY DAILY DESC, STATUS DESC
                            ";

                //string sql = @"
                //                SELECT TEMP.daily,
                //                       NVL(SUM(DECODE(TEMP.coupon_amt, '500', TEMP.type_date)),0) AS A,
                //                       NVL(SUM(DECODE(TEMP.coupon_amt, '500', TEMP.type_date)*TEMP.coupon_amt),0) AS A2,
                //                       NVL(SUM(DECODE(TEMP.coupon_amt, '2000', TEMP.type_date)),0) AS B,
                //                       NVL(SUM(DECODE(TEMP.coupon_amt, '2000', TEMP.type_date)*TEMP.coupon_amt),0) AS B2,
                //                       NVL(SUM(DECODE(TEMP.coupon_amt, '3000', TEMP.type_date)),0) AS C,
                //                       NVL(SUM(DECODE(TEMP.coupon_amt, '3000', TEMP.type_date)*TEMP.coupon_amt),0) AS C2,
                //                       NVL(SUM(DECODE(TEMP.coupon_amt, '5000', TEMP.type_date)),0) AS D,
                //                       NVL(SUM(DECODE(TEMP.coupon_amt, '5000', TEMP.type_date*TEMP.coupon_amt)),0) AS D2,
                //                       NVL(SUM(DECODE(TEMP.coupon_amt, '10000', TEMP.type_date)),0) AS E,
                //                       NVL(SUM(DECODE(TEMP.coupon_amt, '10000', TEMP.type_date)*TEMP.coupon_amt),0) AS E2
                //                 FROM 
                //                        (select b.daily, a.coupon_amt, 
                //                                (CASE  WHEN :in_type = 0 THEN count(case when a.ins_date = b.daily then 1 end)
                //                                           WHEN :in_type = 1 THEN count(case when a.st_date = b.daily and a.status <> '00' and a.status <> '10' then 1 end)
                //                                           WHEN :in_type = 2 THEN count(case when a.use_date = b.daily then 1 end)
                //                                           WHEN :in_type = 3 THEN count(case when a.dis_use_date = b.daily then 1 end)
                //                                           WHEN :in_type = 4 THEN count(case when a.exp_date = b.daily and a.status = '40' then 1 end) END) as type_date
                //                        FROM (select 
                //                               coupon_amt, 
                //                               ins_date,
                //                               st_date,
                //                               to_char(use_date,'YYYYMMDD') as use_date,
                //                               to_char(dis_use_date,'YYYYMMDD') as dis_use_date,
                //                               exp_date,
                //                               status
                //                                from coupon_mst
                //                                where conf_yn = 'Y'     --승인여부 Y
                //                                and (CASE WHEN :in_type = 0 THEN ins_date
                //                                          WHEN :in_type = 1 THEN st_date
                //                                          WHEN :in_type = 2 THEN to_char(use_date,'YYYYMMDD')
                //                                          WHEN :in_type = 3 THEN to_char(dis_use_date,'YYYYMMDD')
                //                                          WHEN :in_type = 4 THEN exp_date END) between :date_begin and :date_end --쿠폰 상태별
                //                                and coupon_name not like '%테스트%'     --테스트쿠폰 제외
                //                                and (:in_coupon_type is null or     --쿠폰 이름으로 검색  
                //                                        coupon_type = :in_coupon_type)) a,
                //                                (SELECT daily FROM (SELECT to_date('20210101','YYYYMMDD') + LEVEL - 1 AS daily
                //                                    FROM dual
                //                                    CONNECT BY LEVEL <= (to_date('30211231','YYYYMMDD') - to_date('20210101','YYYYMMDD') + 1))
                //                                    WHERE daily between :date_begin and :date_end
                //                                    ) b --데이터가 없어도 0건으로 날짜 표기해주기 위함
                //                 WHERE b.daily = (CASE WHEN :in_type = 0 THEN a.ins_date(+)
                //                                          WHEN :in_type = 1 THEN a.st_date(+)
                //                                          WHEN :in_type = 2 THEN a.use_date(+)
                //                                          WHEN :in_type = 3 THEN a.dis_use_date(+)
                //                                          WHEN :in_type = 4 THEN a.exp_date(+) END)
                //                 GROUP BY CUBE (b.daily,a.coupon_amt)
                //                 ORDER BY b.daily) TEMP
                //                 GROUP BY TEMP.daily
                //                 ORDER BY case when temp.daily is not null then TEMP.daily else to_date('20210808','YYYYMMDD') end desc
                //";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Total/getDailyDGRCouponV2 : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 쿠폰 통계 - 가맹점 이벤트쿠폰 통계(일별) (기간조건: 쿠폰 상태 변경일시)
        /// </summary>
        /// <remarks>
        /// [parameter] <br/>
        /// test_yn 테스트여부 (Y : 테스트 회원사, N : 운영 회원사) <br/>
        /// [response] <br/>
        /// setShopCnt 등록 가맹점 수 합계 <br/>
        /// pubCnt 지급 합계 <br/>
        /// useCnt 사용 합계 <br/>
        /// expCnt 만료 합계 <br/>
        /// duCnt 폐기 합계 <br/>
        /// usePt 사용률(사용/발행*100) <br/>
        /// data <br/>
        /// set_shop_cnt 등록 가맹점 수<br/>
        /// pub_cnt 지급<br/>
        /// use_cnt 사용<br/>
        /// exp_cnt 만료<br/>
        /// du_cnt 폐기<br/>
        /// left_cnt 잔여(잔여=지급-사용-만료-폐기)
        /// </remarks>
        [HttpGet("getDailySECoupon")]
        public async Task<IActionResult> getDailySECoupon(string test_yn, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<SECouponStat> Rdata = new List<SECouponStat>();

            int set_shop_cnt_t = 0;
            int pub_cnt_t = 0;
            int use_cnt_t = 0;
            int exp_cnt_t = 0;
            int du_cnt_t = 0;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("test_yn", test_yn);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = $@"  
                                SELECT a.DAILY, A.set_shop_cnt, A.pub_cnt, A.use_cnt, A.EXP_CNT, A.DU_CNT, A.LEFT_CNT
                                FROM(select stat_date DAILY, set_shop_cnt, pub_cnt, use_cnt, EXP_CNT, du_cnt,
                                            sum(pub_cnt) over(order by stat_date rows unbounded preceding)
                                            - sum(use_cnt) over(order by stat_date rows unbounded preceding)
                                            - sum(exp_cnt) over(order by stat_date rows unbounded preceding)
                                            - sum(du_cnt) over(order by stat_date rows unbounded preceding) LEFT_CNT --(잔여=지급-사용-만료-폐기)
                                    from (
                                         select stat_date,
                                                set_shop_cnt,
                                                pub_cnt,
                                                use_cnt,
                                                exp_cnt,
                                                du_cnt
                                         from shop_e_coupon_stat
                                         where test_yn = :test_yn 
                                    )) A
                                where a.DAILY between :date_begin and :date_end
                                ORDER BY DAILY DESC
                            ";


                var temp = await db.QueryAsync<SECouponStat>(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                //Rdata.Sum(i => i.set)
                foreach (var item in Rdata)
                {
                    set_shop_cnt_t += int.Parse(item.set_shop_cnt);
                    pub_cnt_t += int.Parse(item.pub_cnt);
                    use_cnt_t += int.Parse(item.use_cnt);
                    exp_cnt_t += int.Parse(item.exp_cnt);
                    du_cnt_t += int.Parse(item.du_cnt);
                }

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Total/getDailySECoupon : Get", ex.Message);
            }

            return Ok(new
            {
                code = Rcode,
                msg = Rmsg,
                setShopCnt = set_shop_cnt_t.ToString(),
                pubCnt = pub_cnt_t.ToString(),
                useCnt = use_cnt_t.ToString(),
                expCnt = exp_cnt_t.ToString(),
                duCnt = du_cnt_t.ToString(),
                usePt = pub_cnt_t == 0 ? "0" : ((int)(use_cnt_t / (double)pub_cnt_t * 100)).ToString(),
                data = Rdata
            });
        }

        /// <summary>
        /// 모바일 상품권 통계(일별) (기간조건: 쿠폰 상태 변경일시)
        /// </summary>
        /// <remarks>
        /// prsc_gbn : 처리 구분 (M: 인성자체상품권(대구로), A: 고객앱구매상품권(주문), B: 기업판매상품권(기업)) <br />
        /// NO: 미등록,  CC: 결제취소,  US: 등록완료, UD: 사용완료, RR: 환불요청, RC: 환불완료, ER: 등록기간만료, EP: 기간만료, DU: 회원탈퇴 <br/>
        /// RU: 환불후 재사용, RUD: 환불후 사용완료, REP: 환불후 기간만료<br/>
        /// tot_data : 기간별 집계, data : 일별 집계
        /// </remarks>
        [HttpGet("getDailyVoucher")]
        public async Task<IActionResult> getDailyVoucher(string prsc_gbn, string voucher_type, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> RtotData = new List<object>();
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("prsc_gbn", prsc_gbn);
                param.Add("voucher_type", voucher_type);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = $@"  
                                SELECT  X.*, 
                                        NVL(sum(Y.NO_CNT),0) NO_CNT, 
                                        NVL(sum(Y.NO_CNT),0) * X.VOUCHER_AMT NO_AMT,--미등록
                                        NVL(sum(Y.US_CNT),0) US_CNT,
                                        NVL(sum(Y.US_CNT),0) * X.VOUCHER_AMT US_AMT,--등록완료
                                        NVL(sum(Y.CC_CNT),0) CC_CNT,
                                        NVL(sum(Y.CC_CNT),0) * X.VOUCHER_AMT CC_AMT,--결제취소
                                        NVL(sum(Y.UD_CNT),0) UD_CNT,
                                        NVL(sum(Y.UD_CNT),0) * X.VOUCHER_AMT UD_AMT,--사용완료
                                        NVL(sum(Y.RR_CNT),0) RR_CNT,
                                        NVL(sum(Y.RR_CNT),0) * X.VOUCHER_AMT RR_AMT,--환불요청
                                        NVL(sum(Y.RC_CNT),0) RC_CNT,
                                        NVL(sum(Y.RC_CNT),0) * X.VOUCHER_AMT RC_AMT,--환불완료
                                        NVL(sum(Y.ER_CNT),0) ER_CNT,
                                        NVL(sum(Y.ER_CNT),0) * X.VOUCHER_AMT ER_AMT,--등록기간만료
                                        NVL(sum(Y.EP_CNT),0) EP_CNT,
                                        NVL(sum(Y.EP_CNT),0) * X.VOUCHER_AMT EP_AMT,--기간만료
                                        NVL(sum(Y.DU_CNT),0) DU_CNT,
                                        NVL(sum(Y.DU_CNT),0) * X.VOUCHER_AMT DU_AMT,--회원탈퇴
                                        NVL(sum(Y.RU_CNT),0) RU_CNT,
                                        NVL(sum(Y.RU_CNT),0) * X.VOUCHER_AMT RU_AMT,--환불후 재사용
                                        NVL(sum(Y.RUD_CNT),0) RUD_CNT,
                                        NVL(sum(Y.RUD_CNT),0) * X.VOUCHER_AMT RUD_AMT,--환불후 사용완료
                                        NVL(sum(Y.REP_CNT),0) REP_CNT,
                                        NVL(sum(Y.REP_CNT),0) * X.VOUCHER_AMT REP_AMT--환불후 기간만료
                                FROM(SELECT A.VOUCHER_TYPE, A.VOUCHER_NAME, A.VOUCHER_AMT
                                        FROM VOUCHER_CODE_SET A, VOUCHER_CODE_GRP B
                                        WHERE A.GROUP_CD = B.GROUP_CD
                                        --AND A.USE_YN = 'Y'
                                        --AND B.USE_YN = 'Y'
                                        AND B.PRSC_GBN LIKE CASE WHEN :prsc_gbn IS NULL THEN '%' ELSE :prsc_gbn END
                                        AND A.VOUCHER_TYPE LIKE CASE WHEN :voucher_type IS NULL THEN '%' ELSE :voucher_type END) X,
                                    VOUCHER_STAT Y
                                WHERE X.VOUCHER_TYPE = Y.VOUCHER_TYPE
                                AND Y.STAT_DATE between :date_begin and :date_end
                                group by X.VOUCHER_TYPE, X.VOUCHER_NAME, X.VOUCHER_AMT
                                ORDER BY X.VOUCHER_TYPE
                            ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                RtotData = temp.ToList();

                if (RtotData.Count == 0)
                {
                    sql = $@"  
                                select null VOUCHER_TYPE,
                                       ' '  VOUCHER_NAME,
                                       null VOUCHER_AMT,
                                       null NO_CNT,
                                       null NO_AMT,
                                       null US_CNT,
                                       null US_AMT,
                                       null CC_CNT,
                                       null CC_AMT,
                                       null UD_CNT,
                                       null UD_AMT,
                                       null RR_CNT,
                                       null RR_AMT,
                                       null RC_CNT,
                                       null RC_AMT,
                                       null ER_CNT,
                                       null ER_AMT,
                                       null EP_CNT,
                                       null EP_AMT,
                                       null DU_CNT,
                                       null DU_AMT,
                                       null RU_CNT,
                                       null RU_AMT,
                                       null RUD_CNT,
                                       null RUD_AMT,
                                       null REP_CNT,
                                       null REP_AMT
                                from dual
                            ";

                    temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                    RtotData = temp.ToList();
                }

                sql = $@"  
                                SELECT  X.*, 
                                        NVL(Y.NO_CNT,0) NO_CNT, 
                                        NVL(Y.NO_CNT,0) * X.VOUCHER_AMT NO_AMT,
                                        NVL(Y.US_CNT,0) US_CNT,
                                        NVL(Y.US_CNT,0) * X.VOUCHER_AMT US_AMT,
                                        NVL(Y.CC_CNT,0) CC_CNT,
                                        NVL(Y.CC_CNT,0) * X.VOUCHER_AMT CC_AMT,
                                        NVL(Y.UD_CNT,0) UD_CNT,
                                        NVL(Y.UD_CNT,0) * X.VOUCHER_AMT UD_AMT,
                                        NVL(Y.RR_CNT,0) RR_CNT,
                                        NVL(Y.RR_CNT,0) * X.VOUCHER_AMT RR_AMT,
                                        NVL(Y.RC_CNT,0) RC_CNT,
                                        NVL(Y.RC_CNT,0) * X.VOUCHER_AMT RC_AMT,
                                        NVL(Y.ER_CNT,0) ER_CNT,
                                        NVL(Y.ER_CNT,0) * X.VOUCHER_AMT ER_AMT,
                                        NVL(Y.EP_CNT,0) EP_CNT,
                                        NVL(Y.EP_CNT,0) * X.VOUCHER_AMT EP_AMT,
                                        NVL(Y.DU_CNT,0) DU_CNT,
                                        NVL(Y.DU_CNT,0) * X.VOUCHER_AMT DU_AMT,
                                        NVL(Y.RU_CNT,0) RU_CNT,
                                        NVL(Y.RU_CNT,0) * X.VOUCHER_AMT RU_AMT,--환불후 재사용
                                        NVL(Y.RUD_CNT,0) RUD_CNT,
                                        NVL(Y.RUD_CNT,0) * X.VOUCHER_AMT RUD_AMT,--환불후 사용완료
                                        NVL(Y.REP_CNT,0) REP_CNT,
                                        NVL(Y.REP_CNT,0) * X.VOUCHER_AMT REP_AMT--환불후 기간만료
                                FROM(select D.DAILY, C.VOUCHER_TYPE, C.VOUCHER_NAME, C.VOUCHER_AMT
                                    from(SELECT A.VOUCHER_TYPE, A.VOUCHER_NAME, A.VOUCHER_AMT, A.INS_DATE
                                        FROM VOUCHER_CODE_SET A, VOUCHER_CODE_GRP B
                                        WHERE A.GROUP_CD = B.GROUP_CD
                                        --AND A.USE_YN = 'Y'
                                        --AND B.USE_YN = 'Y'
                                        AND B.PRSC_GBN LIKE CASE WHEN :prsc_gbn IS NULL THEN '%' ELSE :prsc_gbn END
                                        AND A.VOUCHER_TYPE LIKE CASE WHEN :voucher_type IS NULL THEN '%' ELSE :voucher_type END) C,
                                        (SELECT TO_CHAR(daily,'YYYYMMDD') DAILY FROM(SELECT to_date('30211231','YYYYMMDD') +-LEVEL  AS daily
                                        FROM dual
                                        CONNECT BY LEVEL <= (to_date('30211231', 'YYYYMMDD') - to_date('20210101', 'YYYYMMDD') + 1))
                                        WHERE daily between :date_begin and :date_end) D
                                    WHERE TO_CHAR(C.INS_DATE,'YYYYMMDD') <= D.DAILY )X,
                                    VOUCHER_STAT Y
                                WHERE X.DAILY = Y.STAT_DATE(+)
                                AND X.VOUCHER_TYPE = Y.VOUCHER_TYPE(+)
                                ORDER BY X.DAILY DESC, X.VOUCHER_TYPE
                            ";

                temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Total/getDailyVoucher : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, tot_data = RtotData, data = Rdata });
        }
        #endregion[쿠폰 통계]

        #region[미사용]
        // 대구로 APP 운영현황 보고(미사용)
        [HttpGet("getDaeguroTotalInfoSum")]
        public async Task<IActionResult> getDaeguroTotalInfo()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> totalInstalled = new List<object>();
            List<object> totalYearMembers = new List<object>();
            List<object> totalOrders = new List<object>();
            List<object> totalCancel = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                //DynamicParameters param = new DynamicParameters();
                //param.Add("date_begin", date_begin);
                //param.Add("date_end", date_end);

                // 누적 설치수
                string sql = @"
                                  SELECT device_gbn, COUNT (*) COUNT
                                    FROM (SELECT mcode,
                                                 insert_date,
                                                 cust_id_gbn,
                                                 test_gbn,
                                                 device_gbn
                                            FROM app_customer
                                          UNION ALL
                                          SELECT mcode,
                                                 insert_date,
                                                 cust_id_gbn,
                                                 test_gbn,
                                                 device_gbn
                                            FROM app_customer_deleted)
                                   WHERE     mcode = 2
                                         AND device_gbn IS NOT NULL
                                         AND cust_id_gbn = 'Z'
                                         AND test_gbn = 'R'
                                         -- AND insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                GROUP BY device_gbn
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalInstalled = temp.ToList();

                // 누적 회원(연령대) 수
                sql = @"
                          SELECT case when birthday < 1 then 1
                                      when birthday > 9 then 9
                                      else birthday end || '0대' AS year, COUNT (*) COUNT
                            FROM (SELECT TO_CHAR (insert_date, 'YYYYMMDD')
                                             AS insert_date,
                                         trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                             birthday
                                    FROM (SELECT mcode,
                                                 insert_date,
                                                 birthday,
                                                 test_gbn
                                            FROM app_customer
                                          UNION ALL
                                          SELECT mcode,
                                                 insert_date,
                                                 birthday,
                                                 test_gbn
                                            FROM app_customer_deleted)
                                   WHERE     mcode = 2
                                         AND test_gbn = 'R'
                                         -- AND insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND birthday IS NOT NULL)
                        -- where birthday > 0 and birthday <10
                        GROUP BY case when birthday < 1 then 1
                                      when birthday > 9 then 9
                                      else birthday end
                        ORDER BY case when birthday < 1 then 1
                                      when birthday > 9 then 9
                                      else birthday end
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalYearMembers = temp.ToList();


                // 누적 완료/취소 주문수
                sql = @"
                          SELECT /*+ full(a)full(b) */ DECODE (a.status,  '40', '완료',  '50', '취소')     status,
                                 COUNT (*) COUNT
                            FROM (SELECT * FROM dorder
                                  UNION ALL
                                  SELECT * FROM dorder_past) a,
                                 callcenter b
                           WHERE     a.cccode = b.cccode
                                 AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                 AND b.mcode = 2
                                 AND a.test_gbn = 'N'
                                 AND a.status IN ('40', '50')
                        GROUP BY a.status
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalOrders = temp.ToList();

                // 누적 주문취소 사유별 건수
                sql = @"
                          SELECT DECODE (cancel_code,
                                         '00', '사유없음',
                                         '10', '고객본인취소',
                                         '11', '시간지연',
                                         '12', '재접수',
                                         '20', '가맹점취소',
                                         '21', '배달불가',
                                         '22', '메뉴품절',
                                         '23', '가맹점휴무',
                                         '24', '주소입력오류',
                                         '25', '가맹점 정산 접수거부',
                                         '26', 'POS서버 응답없음',
                                         '30', '결재대기 자동취소',
                                         '40', '예약주문 고객 취소',
                                         '45', '예약주문 가맹점 취소')
                                     cancel_code,
                                 COUNT (cancel_code)
                                     COUNT
                            FROM (SELECT * FROM dorder
                                  UNION
                                  SELECT * FROM dorder_past) a,
                                 callcenter b
                           WHERE     a.cccode = b.cccode
                                 AND b.mcode = 2
                                 AND NVL (a.cancel_code, '00') <> '30'
                                 AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                 AND a.test_gbn = 'N'
                                 AND a.cancel_code IS NOT NULL
                        GROUP BY cancel_code
                        ORDER BY COUNT DESC
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalCancel = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalOS = totalInstalled, totalYearMembers = totalYearMembers, totalOrders = totalOrders, totalCancel = totalCancel });
        }

        //[HttpGet("getShopCount")]
        //public async Task<IActionResult> Get()
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    ShopCount shopCount = new ShopCount();

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_TOTAL.GET_TOTAL_COUNT",
        //    };

        //    cmd.Parameters.Add("in_image_status_0", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("in_image_status_1", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("in_image_status_2", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("in_image_status_3", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("in_image_status_4", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("in_total_shop_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("in_new_shop_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("in_use_shop_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("in_stop_shop_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();
        //        var rd = await cmd.ExecuteReaderAsync();

        //        shopCount.imageStatus_0 = cmd.Parameters["in_image_status_0"].Value.ToString();
        //        shopCount.imageStatus_1 = cmd.Parameters["in_image_status_1"].Value.ToString();
        //        shopCount.imageStatus_2 = cmd.Parameters["in_image_status_2"].Value.ToString();
        //        shopCount.imageStatus_3 = cmd.Parameters["in_image_status_3"].Value.ToString();
        //        shopCount.imageStatus_4 = cmd.Parameters["in_image_status_4"].Value.ToString();
        //        shopCount.totalShopCount = cmd.Parameters["in_total_shop_count"].Value.ToString();
        //        shopCount.newShopCount = cmd.Parameters["in_new_shop_count"].Value.ToString();
        //        shopCount.useShopCount = cmd.Parameters["in_use_shop_count"].Value.ToString();
        //        shopCount.stopShopCount = cmd.Parameters["in_stop_shop_count"].Value.ToString();

        //        Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        await rd.CloseAsync();
        //        await conn.CloseAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/Menu/menu_cd : Get", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg, data = shopCount });
        //}


        //[HttpGet("getWeekSales")]
        //public async Task<IActionResult> getWeekSales()
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;
        //    List<object> items = new List<object>();

        //    try
        //    {
        //        using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
        //        db.Open();


        //        string sql = @"
        //                        SELECT TO_CHAR (TO_DATE (order_date), 'MM-dd') order_date, tot_amt
        //                            FROM (  SELECT a.order_date order_date, SUM (tot_amt) tot_amt
        //                                      FROM dorder a, callcenter b
        //                                     WHERE     a.cccode = b.cccode
        //                                           AND b.mcode = 2
        //                                           AND a.status = '40'
        //                                           AND a.test_gbn = 'N'
        //                                           AND a.order_date BETWEEN TO_CHAR (SYSDATE - 6, 'yyyyMMdd')
        //                                                      AND TO_CHAR (SYSDATE , 'yyyyMMdd')
        //                                  GROUP BY order_date
        //                                  UNION
        //                                  SELECT a.order_date order_date, SUM (tot_amt) tot_amt
        //                                      FROM dorder_past a, callcenter b
        //                                     WHERE     a.cccode = b.cccode
        //                                           AND b.mcode = 2
        //                                           AND a.status = '40'
        //                                           AND a.test_gbn = 'N'
        //                                           AND a.order_date BETWEEN TO_CHAR (SYSDATE - 6, 'yyyyMMdd')
        //                                                      AND TO_CHAR (SYSDATE , 'yyyyMMdd')
        //                                  GROUP BY order_date
        //                                  ORDER BY order_date DESC)
        //        ";

        //        var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

        //        items = temp.ToList();

        //        db.Close();

        //        Rcode = "00";
        //        Rmsg = "성공";
        //    }
        //    catch (Exception ex)
        //    {

        //        Rcode = "01";
        //        Rmsg = ex.Message;
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg, data = items });
        //}

        // 대구로 쿠폰 통계 - 월별
        //[HttpGet("getDGRCoupon/{mon}")]
        //public async Task<IActionResult> getDGRCouponMon(string mon, string coupon_name)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;
        //    List<object> items = new List<object>();

        //    if (string.IsNullOrEmpty(mon))
        //    {
        //        Rcode = "01";
        //        Rmsg = "조회하실 달을 입력해주세요.";

        //        return Ok(new { code = Rcode, msg = Rmsg, data = items });
        //    }

        //    try
        //    {
        //        using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
        //        db.Open();
        //        DynamicParameters param = new DynamicParameters();
        //        param.Add("in_date", mon);
        //        param.Add("in_coupon_name", coupon_name);

        //        string sql = @"
        //                        SELECT mon,coupon_amt,
        //                                COUNT(CASE WHEN ins_c = mon THEN 1 END) AS INS_CNT,
        //                                COUNT(CASE WHEN use_c = mon THEN 1 END) AS USE_CNT,
        //                                COUNT(CASE WHEN dis_use_c = mon THEN 1 END) AS DIS_USE_CNT,
        //                                COUNT(CASE WHEN exp_c = mon THEN 1 END) AS EXP_CNT,
        //                                COUNT(CASE WHEN ins_c = mon THEN 1 END) * coupon_amt as INS_AMT,
        //                                COUNT(CASE WHEN use_c = mon THEN 1 END) * coupon_amt as USE_AMT,
        //                                COUNT(CASE WHEN dis_use_c = mon THEN 1 END) * coupon_amt as DIS_USE_AMT,
        //                                COUNT(CASE WHEN exp_c = mon THEN 1 END) * coupon_amt as EXP_AMT
        //                        FROM (SELECT substr(ins_date,1,6) AS mon, coupon_amt, SUBSTR(ins_date,1,6) AS ins_c, 
        //                                substr(to_char(use_date,'YYYYMM'),1,6) AS use_c, 
        //                                substr(to_char(dis_use_date,'YYYYMM'),1,6) AS dis_use_c, 
        //                                substr(exp_date,1,6) AS exp_c
        //                                FROM coupon_mst
        //                                WHERE conf_yn = 'Y'
        //                                AND ins_date >= '2021080917'
        //                                --and to_char(use_date, 'YYYYMMDD') between :date_begin and :date_end
        //                                AND :in_date = to_char(conf_date,'YYYYMM')
        //                                AND coupon_name not like '%테스트%'     --테스트쿠폰 제외
        //                                AND (:in_coupon_name is null OR
        //                                        coupon_name like :in_coupon_name || '%' ))
        //                        GROUP BY mon,coupon_amt
        //                        ORDER BY coupon_amt
        //        ";

        //        var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

        //        items = temp.ToList();

        //        db.Close();

        //        Rcode = "00";
        //        Rmsg = "성공";
        //    }
        //    catch (Exception ex)
        //    {

        //        Rcode = "01";
        //        Rmsg = ex.Message;
        //        await Utils.SaveErrorAsync("/Total/getDGRCouponMon : Get", ex.Message);
        //    }



        //    return Ok(new { code = Rcode, msg = Rmsg, data = items });
        //}
        #endregion[미사용]

    }
}
