﻿using Dapper;
using ClosedXML.Excel;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Linq;
using DocumentFormat.OpenXml.Drawing.Charts;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [ApiController]
    [Route("/[controller]")]
    public class KindShopController : ControllerBase
    {
        private readonly ILogger<KindShopController> _logger;

        //string path = @"c:\Files\";

        public KindShopController(ILogger<KindShopController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// 착한매장 목록조회
        /// </summary>
        /// <remarks>        
        /// use_gbn : 가맹점 사용여부(Y/N)(필수) <br/>
        /// div : 구분: 1.전체, 2.브랜드(필수) <br/> 
        /// franchise_cd : 브랜드 코드 <br/>
        /// s_use_yn: 사용중 상태조회(Y/N) <br/>
        /// s_stop_yn : 임시중지 상태조회(Y/N) <br/>
        /// s_cancel_yn : 해지완료 상태조회(Y/N) <br/>
        /// keyword : 키워드검색(가맹점명) <br/>
        /// page : 페이지 <br/>
        /// row : 갯수 
        /// </remarks>
        [HttpGet("getKindShopList")]
        public async Task<IActionResult> getKindShopList(string use_gbn,  string div, string franchise_cd, string s_use_yn, string s_stop_yn, string s_cancel_yn, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<KindShop> itmes = new List<KindShop>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_KIND_SHOP.GET_LIST",
            };

            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("in_franchise_cd", OracleDbType.Varchar2, 10).Value = franchise_cd;
            cmd.Parameters.Add("in_s_use_yn", OracleDbType.Varchar2, 1).Value = s_use_yn;
            cmd.Parameters.Add("in_s_stop_yn", OracleDbType.Varchar2, 1).Value = s_stop_yn;
            cmd.Parameters.Add("in_s_cancel_yn", OracleDbType.Varchar2, 1).Value = s_cancel_yn;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 60).Value = keyword;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    KindShop item = new KindShop
                    {
                        shop_name = rd["SHOP_NAME"].ToString(),
                        shop_cd = rd["SHOP_CD"].ToString(),
                        kind_shop_status = rd["KIND_SHOP_STATUS"].ToString(),
                        kind_shop_cancel_dt = rd["KIND_SHOP_CANCEL_DT"].ToString(),
                        kind_shop_memo = rd["KIND_SHOP_MEMO"].ToString(),
                        use_gbn = rd["USE_GBN"].ToString(),
                        absent_yn = rd["ABSENT_YN"].ToString(),
                        insert_date = rd["INSERT_DATE"].ToString(),
                        comp_date = rd["COMP_DATE"].ToString(),
                        pos_install = rd["POS_INSTALL"].ToString(),
                        pos_login = rd["POS_LOGIN"].ToString(),
                        alloc_ucode = rd["ALLOC_UCODE"].ToString(),
                        alloc_uname = rd["ALLOC_UNAME"].ToString()
    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/KindShop/getKindShopList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }

        /// <summary>
        /// 착한매장 목록 엑셀출력
        /// </summary>
        /// <remarks>        
        /// use_gbn : 가맹점 사용여부(Y/N)(필수) <br/>
        /// div : 구분: 1.전체, 2.브랜드(필수) <br/> 
        /// franchise_cd : 브랜드 코드 <br/>
        /// s_use_yn: 사용중 상태조회(Y/N) <br/>
        /// s_stop_yn : 임시중지 상태조회(Y/N) <br/>
        /// s_cancel_yn : 해지완료 상태조회(Y/N) <br/>
        /// keyword : 키워드검색(가맹점명) <br/>
        /// </remarks>
        [HttpGet("exportKindShopList")]
        public async Task<IActionResult> exportKindShopList(string use_gbn, string div, string franchise_cd, string s_use_yn, string s_stop_yn, string s_cancel_yn, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<KindShop> itmes = new List<KindShop>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_KIND_SHOP.EXPORT_EXCEL_LIST",
            };

            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = use_gbn;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("in_franchise_cd", OracleDbType.Varchar2, 10).Value = franchise_cd;
            cmd.Parameters.Add("in_s_use_yn", OracleDbType.Varchar2, 1).Value = s_use_yn;
            cmd.Parameters.Add("in_s_stop_yn", OracleDbType.Varchar2, 1).Value = s_stop_yn;
            cmd.Parameters.Add("in_s_cancel_yn", OracleDbType.Varchar2, 1).Value = s_cancel_yn;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 60).Value = keyword;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                if (Rcode.Equals("00"))
                {

                    using (var workbook = new XLWorkbook())
                    {
                        var worksheet = workbook.Worksheets.Add("착한매장 목록");
                        var currentRow = 1;
                        var col = 1;

                        worksheet.Cell(currentRow, col++).Value = "상태";
                        worksheet.Cell(currentRow, col++).Value = "가맹점코드";
                        worksheet.Cell(currentRow, col++).Value = "가맹점명";
                        worksheet.Cell(currentRow, col++).Value = "신청일";
                        worksheet.Cell(currentRow, col++).Value = "승인일";
                        worksheet.Cell(currentRow, col++).Value = "해지일";
                        worksheet.Cell(currentRow, col++).Value = "사용";
                        worksheet.Cell(currentRow, col++).Value = "휴점";
                        worksheet.Cell(currentRow, col++).Value = "POS설치";
                        worksheet.Cell(currentRow, col++).Value = "POS로그인";
                        worksheet.Cell(currentRow, col++).Value = "검수자코드";
                        worksheet.Cell(currentRow, col++).Value = "검수자명";

                        while (await rd.ReadAsync())
                        {
                            currentRow++;
                            col = 1;

                            worksheet.Cell(currentRow, col++).Value = rd["KIND_SHOP_STATUS"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SHOP_CD"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["SHOP_NAME"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["INSERT_DATE"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["COMP_DATE"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["KIND_SHOP_CANCEL_DT"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["USE_GBN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["ABSENT_YN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["POS_INSTALL"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["POS_LOGIN"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["ALLOC_UCODE"].ToString();
                            worksheet.Cell(currentRow, col++).Value = rd["ALLOC_UNAME"].ToString();

                        }

                        worksheet.Columns().AdjustToContents();
                        //worksheet.Rows().AdjustToContents();

                        await rd.CloseAsync();
                        await conn.CloseAsync();

                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            // "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            return File(content, "application/octet-stream", "착한매장 목록.xlsx");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/KindShop/exportKindShopList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = itmes });
        }

        /// <summary>
        /// 착한매장 상태변경(미사용)
        /// </summary>
        /// <remarks>        
        /// shop_cd : 가맹점 코드(필수) <br/>
        /// status : 착한매장운영상태 (10: 사용중, 20: 일시중지, 30: 해지완료)(필수) <br/>
        /// ucode : 작업자코드(필수)
        /// </remarks>
        [HttpPut("setKindShop")]
        public async Task<IActionResult> setKindShop(string shop_cd, string status, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_KIND_SHOP.SET_STATUS",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_status", OracleDbType.Varchar2, 2).Value = status;            
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/KindShop/setKindShop : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 착한매장 변경이력 조회
        /// </summary>
        /// <remarks>        
        /// shop_cd : 가맹점 코드(필수) <br/>
        /// hist_gbn: 변경구분(빈값: 전체, O: 항목변경, M: 메모변경) 
        /// </remarks>
        [HttpGet("getKindShopHist")]
        public async Task<IActionResult> getKindShopHist(string shop_cd, string hist_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<KindShopHist> shops = new List<KindShopHist>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_KIND_SHOP.GET_HISTORY",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_hist_gbn", OracleDbType.Varchar2, 1).Value = hist_gbn;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    KindShopHist s = new KindShopHist
                    {                        
                        hist_date = rd["HIST_DATE"].ToString(),
                        memo = rd["MEMO"].ToString(),
                    };

                    shops.Add(s);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/KindShop/GetMultiShopHist : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = shops });
        }

        

    }
}
