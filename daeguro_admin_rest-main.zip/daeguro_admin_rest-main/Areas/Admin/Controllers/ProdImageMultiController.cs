﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ProdImageMultiController : ControllerBase
    {
        string multiProdImagePath = @"\\10.10.10.100\dgnas\Files\MultiProdImage";
        //string productPath = @"\sy100";
        string nasPath = @"\\10.10.10.100\dgnas\Files";
        string testImagePath = @"E:\iis\Files\TestImage";
        //string testImagePath = @"\sy100";

        #region[멀티 상품 이미지 관리]
        /// <summary>
        /// 멀티 상품 이미지 조회
        /// </summary>
        /// <remarks>
        /// prod_code : 상품코드(필수) <br/>
        /// div : 구분(1. 상품이미지, 2. 상품설명이미지, 3. 상품설명 html용 이미지)(필수) <br/>
        /// <br/>
        /// 이미지 url <br/>
        /// 운영 : https://image.daeguro.co.kr:40443/multi-prod-images/{prod_code}/{file_name} <br/>
        /// 테스트 : https://dgpub.282.co.kr:8500/testimage/{prod_code}/{file_name} <br/>
        /// </remarks>
        [HttpGet("{prod_code}")]
        public async Task<IActionResult> Get(string prod_code, string div)
        {
            string Rcount = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/ProdImageMulti/{prod_code} : Get";

            List<ProdMultiList> items = new List<ProdMultiList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_PROD_IMG_MULTI",
            };

            cmd.Parameters.Add("in_prod_code", OracleDbType.Int32).Value = prod_code;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ProdMultiList m = new ProdMultiList
                    {
                        seq = rd["prod_image_seq"].ToString(),
                        file_name = rd["file_name"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        ins_ucode = rd["ins_ucode"].ToString(),
                        ins_name = rd["ins_name"].ToString(),
                        mod_date = rd["mod_date"].ToString(),
                        mod_ucode = rd["mod_ucode"].ToString(),
                        mod_name = rd["mod_name"].ToString(),
                    };

                    items.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }


        /// <summary>
        /// 멀티 상품 이미지 등록
        /// </summary>
        /// <remarks>
        /// 확장자 그대로 저장 <br/>
        /// prod_code : 상품코드(필수) <br/>
        /// div : 구분(1. 상품이미지, 2. 상품설명이미지, 3. 상품설명 html용 이미지)(필수) <br/>
        /// ucode : 등록자코드 <br/>
        /// uname : 등록자명 <br/>
        /// </remarks>
        [HttpPost]
        public async Task<ResultBasic> Post(IFormFile formFile, string prod_code, string div, string ucode, string uname)
        {
            string fileName = string.Empty;
            ResultBasic result = new ResultBasic();
            string Rposition = "/ProdImageMulti : Post";

            try
            {
                if (formFile != null && formFile.Length > 0)
                {
                    // 확장자 가져오기
                    int dotIdx = formFile.FileName.LastIndexOf(".");

                    int extLength = formFile.FileName.Length - dotIdx;

                    string extention = formFile.FileName.Substring(dotIdx, extLength);

                    //.webp의 경우 조회가 안되어서 .jpg로 이름변경
                    if (extention == ".webp")
                    {
                        extention = ".jpg";
                    }

                    //string name = formFile.FileName.Substring(0, dotIdx);

                    string dt = DateTime.Now.ToString("yyyyMMddHHmmss");

                    //상품설명 html용 이미지 관리를 위해 파일명으로 관리예정
                    //파일명이 한글이라 수정이 번거로워서 되돌려달라 요청옴,2023.10.16
                    //fileName = name + "_" + dt + extention;
                    fileName = prod_code + "_" + dt + extention;

                    result = await setImg(prod_code, div, fileName, ucode, uname);

                    if (result.code.Equals("00") && Utils.serverGbn == "R") //운영서버의 경우
                    {
                        // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            string folerPath = multiProdImagePath + "\\" + prod_code;
                            DirectoryInfo di = new DirectoryInfo(folerPath);

                            if (di.Exists == false)
                            {
                                di.Create();
                            }

                            folerPath = folerPath + "\\" + fileName;

                            // 파일이 이미 존재하면 삭제한다.
                            if (System.IO.File.Exists(folerPath))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPath);
                            }

                            //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                            using var stream = new FileStream(folerPath, FileMode.Create);

                            await formFile.CopyToAsync(stream);

                            stream.Close();
                            stream.Dispose();
                        }

                    }
                    else if (result.code.Equals("00") && Utils.serverGbn == "T") //테스트서버의 경우
                    {
                        string folerPath = testImagePath + "\\" + prod_code;
                        DirectoryInfo di = new DirectoryInfo(folerPath);

                        if (di.Exists == false)
                        {
                            di.Create();
                        }

                        folerPath = folerPath + "\\" + fileName;

                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath);
                        }

                        //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                        using var stream = new FileStream(folerPath, FileMode.Create);

                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();
                    }

                }
                else
                {
                    result.code = "99";
                    result.msg = "등록할 이미지가 없습니다.";
                }

            }
            catch (Exception ex)
            {
                result.code = "01";
                result.msg = "예외처리발생" + ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }


            return result;
        }


        private async Task<ResultBasic> setImg(string prod_code, string div, string file_name, string ins_ucode ,string ins_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/ProdImageMulti/setImg : Post";

            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.ADD_PROD_IMG_MULTI",
            };
            
            cmd.Parameters.Add("in_prod_code", OracleDbType.Int32).Value = prod_code;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("in_file_name", OracleDbType.Varchar2, 100).Value = file_name;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = ins_ucode;
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 300).Value = ins_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString(); //등록 성공시 파일명 리턴

                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                result.code = "98";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return result;
        }


        /// <summary>
        /// 멀티 상품 이미지 수정
        /// </summary>
        /// <remarks>
        /// 확장자 그대로 저장 <br/>
        /// prod_code: 상품코드(필수) <br/>
        /// seq : 멀티 상품 이미지 pk값(필수) <br/>
        /// ucode : 수정자코드 <br/>
        /// uname : 수정자명 <br/>
        /// </remarks>
        [HttpPut]
        public async Task<ResultBasic> Put(IFormFile formFile, string seq, string prod_code,  string ucode, string uname)
        {
            string fileName = string.Empty;
            ResultBasic result = new ResultBasic();
            string Rposition = "/ProdImageMulti : Put";

            try
            {
                if (formFile != null && formFile.Length > 0)
                {
                    // 확장자 가져오기
                    int dotIdx = formFile.FileName.LastIndexOf(".");

                    int extLength = formFile.FileName.Length - dotIdx;

                    string extention = formFile.FileName.Substring(dotIdx, extLength);

                    //.webp의 경우 조회가 안되어서 .jpg로 이름변경
                    if (extention == ".webp")
                    {
                        extention = ".jpg";
                    }

                    //string name = formFile.FileName.Substring(0, dotIdx);

                    string dt = DateTime.Now.ToString("yyyyMMddHHmmss");

                    //상품설명 html용 이미지 관리를 위해 파일명으로 관리예정
                    //파일명이 한글이라 수정이 번거로워서 되돌려달라 요청옴,2023.10.16
                    //fileName = name + "_" + dt + extention;
                    fileName = prod_code + "_" + dt + extention;

                    result = await updateImg(seq, prod_code, fileName, ucode, uname);
                    string old_file_name = result.msg;

                    if (result.code.Equals("00") && Utils.serverGbn == "R") //운영서버의 경우
                    {
                        // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            string folerPathOld = multiProdImagePath + "\\" + prod_code + "\\" + old_file_name;
                            string folerPath = multiProdImagePath + "\\" + prod_code;
                            DirectoryInfo di = new DirectoryInfo(folerPath);

                            if (di.Exists == false)
                            {
                                di.Create();
                            }

                            folerPath = folerPath + "\\" + fileName;

                            // 기존파일 삭제
                            if (System.IO.File.Exists(folerPathOld))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPathOld);
                            }

                            //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                            using var stream = new FileStream(folerPath, FileMode.Create);

                            await formFile.CopyToAsync(stream);

                            stream.Close();
                            stream.Dispose();
                        }

                    }
                    else if (result.code.Equals("00") && Utils.serverGbn == "T") //테스트서버의 경우
                    {
                        string folerPathOld = testImagePath + "\\" + prod_code + "\\" + old_file_name;
                        string folerPath = testImagePath + "\\" + prod_code;
                        DirectoryInfo di = new DirectoryInfo(folerPath);

                        if (di.Exists == false)
                        {
                            di.Create();
                        }

                        folerPath = folerPath + "\\" + fileName;

                        // 기존파일 삭제
                        if (System.IO.File.Exists(folerPathOld))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPathOld);
                        }

                        //using var stream = System.IO.File.Create(folerPath + "\\" + fileName);

                        using var stream = new FileStream(folerPath, FileMode.Create);

                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();
                    }

                }
                else
                {
                    result.code = "99";
                    result.msg = "수정할 이미지가 없습니다.";
                }

            }
            catch (Exception ex)
            {
                result.code = "01";
                result.msg = "예외처리발생" + ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }


            return result;
        }


        private async Task<ResultBasic> updateImg(string prod_image_seq, string prod_code, string file_name, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/ProdImageMulti/updateImg : Put";

            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.UPDATE_PROD_IMG_MULTI",
            };

            cmd.Parameters.Add("in_prod_image_seq", OracleDbType.Int32).Value = prod_image_seq;
            cmd.Parameters.Add("in_prod_code", OracleDbType.Int32).Value = prod_code;
            cmd.Parameters.Add("in_file_name", OracleDbType.Varchar2, 100).Value = file_name;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 300).Value = mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString(); //수정 성공시 기존 파일명 리턴

                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                result.code = "98";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 멀티 상품 이미지 삭제
        /// </summary>
        /// <remarks>
        /// prod_code : 상품코드(필수) <br/>
        /// div : 구분(1. 상품이미지, 2. 상품설명이미지, 3. 상품설명 html용 이미지)(필수) <br/>
        /// seq : 다중 메뉴 이미지 pk값(필수) <br/>
        /// </remarks>
        [HttpDelete()]
        public async Task<ResultBasic> delete(string seq, string div, string prod_code, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            ResultBasic result = new ResultBasic();
            string folerPath = string.Empty;
            string Rposition = "/ProdImageMulti : Delete";

            try
            {

                result = await deleteImg(seq, div, prod_code, mod_ucode, mod_name);

                if (result.code == "00" && Utils.serverGbn == "R")//운영서버
                {
                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        folerPath = multiProdImagePath + "\\" + result.msg;
                        // 파일이 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath);
                        }
                    }
                }
                else if(result.code == "00" && Utils.serverGbn == "T")//테스트서버
                {
                    folerPath = testImagePath + "\\" + result.msg;
                    // 파일이 존재하면 삭제한다.
                    if (System.IO.File.Exists(folerPath))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        System.IO.File.Delete(folerPath);
                    }
                }
            }
            catch (Exception ex)
            {
                result.code = "99";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }


            return result;
        }

        private async Task<ResultBasic> deleteImg(string prod_image_seq, string div, string prod_code, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/ProdImageMulti/deleteImg : Delete";

            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.DELETE_PROD_IMG_MULTI",
            };

            cmd.Parameters.Add("in_prod_image_seq", OracleDbType.Int32).Value = prod_image_seq;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("in_prod_code", OracleDbType.Int32).Value = prod_code;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 300).Value = mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteNonQueryAsync();

                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString(); //기존 파일명 리턴

                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                result.code = "98";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return result;
        }
        #endregion[멀티 상품 이미지 관리]

        #region[상품 설명 html 관리]
        /// <summary>
        /// 상품 설명 html 불러오기
        /// </summary>
        /// <remarks>
        /// prod_code : 상품코드(필수) <br/>
        /// file_name : html 파일명(필수) <br/>
        /// </remarks>
        [HttpGet("getHtml")]
        public async Task<ResultPlus> getHtml(string prod_code, string file_name)
        {
            ResultBasic r = new ResultBasic();
            ResultPlus result = new ResultPlus();
            string Rposition = "/ProdImageMulti/getHtml : Get";

            try
            {
                if (Utils.serverGbn == "R") //운영서버의 경우
                {
                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        string folerPath = multiProdImagePath + "\\" + prod_code + "\\html\\" + file_name;

                        // 파일이 이미 존재하지 않으면 99리턴
                        if (!System.IO.File.Exists(folerPath))
                        {
                            result.code = "99";
                            result.msg = "파일이 존재하지 않습니다.";
                            return result;
                        }

                        result.item = System.IO.File.ReadAllText(folerPath);

                    }
                }
                else if (Utils.serverGbn == "T") //테스트서버의 경우
                {
                    string folerPath = testImagePath + "\\" + prod_code + "\\html\\" + file_name;

                    // 파일이 이미 존재하지 않으면 99리턴
                    if (!System.IO.File.Exists(folerPath))
                    {
                        result.code = "99";
                        result.msg = "파일이 존재하지 않습니다.";
                        return result;
                    }

                    result.item = System.IO.File.ReadAllText(folerPath);
                }

                result.code = "00";
                result.msg = "성공";

            }
            catch (Exception ex)
            {
                result.code = "01";
                result.msg = "예외처리발생" + ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }


            return result;
        }

        /// <summary>
        /// 상품 설명 html 등록
        /// </summary>
        /// <remarks>
        /// HTML 파일 서버에 저장 후 파일명 리턴 <br/>
        /// prod_code : 상품코드(필수) <br/>
        /// formFile : html 파일(필수) <br/>
        /// ucode : 등록자코드 <br/>
        /// uname : 등록자명 <br/>
        /// <br/>
        /// url <br/>
        /// 운영 : https://image.daeguro.co.kr:40443/multi-prod-images/{prod_code}/html/{file_name} <br/>
        /// 테스트 : https://dgpub.282.co.kr:8500/testimage/{prod_code}/html/{file_name} <br/>
        /// </remarks>
        [HttpPost("setHtml")]
        public async Task<ResultPlus> setHtml([FromForm] ProdHtmlPost item)
        {
            string fileName = string.Empty;
            ResultBasic r = new ResultBasic();
            ResultPlus result = new ResultPlus();
            string Rposition = "/ProdImageMulti/setHtml : Post";

            if (string.IsNullOrEmpty(item.prod_code))
            {
                result.code = "99";
                result.msg = "상품코드는 필수입니다.";
                return result;
            }

            try
            {
                if (item.formFile != null && item.formFile.Length > 0)
                {
                    // 확장자 가져오기
                    int dotIdx = item.formFile.FileName.LastIndexOf(".");

                    int extLength = item.formFile.FileName.Length - dotIdx;

                    string extention = item.formFile.FileName.Substring(dotIdx, extLength);

                    //string extention = ".html";
                    if(extention != ".html")
                    {
                        result.code = "99";
                        result.msg = "html 파일이 아닙니다.";
                        return result;
                    }

                    string dt = DateTime.Now.ToString("yyyyMMddHHmmss");

                    fileName = item.prod_code + "_" + dt + extention;

                    r = await _setHtml(item.prod_code, fileName, item.ucode, item.uname);

                    if (r.code.Equals("00") && Utils.serverGbn == "R") //운영서버의 경우
                    {
                        // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            string folerPath = multiProdImagePath + "\\" + item.prod_code;
                            DirectoryInfo di = new DirectoryInfo(folerPath);

                            if (di.Exists == false)
                            {
                                di.Create();
                            }

                            // 상품이미지 폴더내 html용 폴더 생성
                            folerPath = folerPath + "\\html";
                            di = new DirectoryInfo(folerPath);

                            if (di.Exists == false)
                            {
                                di.Create();
                            }

                            folerPath = folerPath + "\\" + fileName;

                            // 파일이 이미 존재하면 삭제한다.
                            if (System.IO.File.Exists(folerPath))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPath);
                            }

                            using var stream = new FileStream(folerPath, FileMode.Create);

                            await item.formFile.CopyToAsync(stream);

                            stream.Close();
                            stream.Dispose();

                            // string 텍스트를 파일로 만들때 사용
                            //await System.IO.File.AppendAllTextAsync(folerPath, item.html_contents);

                        }
                    }
                    else if (r.code.Equals("00") && Utils.serverGbn == "T") //테스트서버의 경우
                    {
                        string folerPath = testImagePath + "\\" + item.prod_code;
                        DirectoryInfo di = new DirectoryInfo(folerPath);

                        if (di.Exists == false)
                        {
                            di.Create();
                        }

                        // 상품이미지 폴더내 html용 폴더 생성
                        folerPath = folerPath + "\\html";
                        di = new DirectoryInfo(folerPath);

                        if (di.Exists == false)
                        {
                            di.Create();
                        }

                        folerPath = folerPath + "\\" + fileName;

                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(folerPath))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath);
                        }

                        using var stream = new FileStream(folerPath, FileMode.Create);

                        await item.formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();

                        // string 텍스트를 파일로 만들때 사용
                        //await System.IO.File.AppendAllTextAsync(folerPath, item.html_contents);
                    }

                    result.code = r.code;
                    result.msg = r.msg;
                    result.item = fileName;

                }
                else
                {
                    result.code = "99";
                    result.msg = "등록할 파일내용이 없습니다.";
                }

            }
            catch (Exception ex)
            {
                result.code = "01";
                result.msg = "예외처리발생" + ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }


            return result;
        }

        /// <summary>
        /// html 파일명 db업로드
        /// </summary>
        private async Task<ResultBasic> _setHtml(string prod_code, string file_name, string ucode, string uname)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/ProdImageMulti/_setHtml : Post";

            ResultBasic result = new ResultBasic();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("prod_code", prod_code);
            param.Add("file_name", file_name);
            param.Add("ucode", ucode);
            param.Add("uname", uname);

            string sql = @$"
                            update prod
                            set html = :file_name,
                                mod_date = sysdate,
                                mod_ucode = :ucode,
                                mod_name = :uname
                            where prod_code = :prod_code
                        ";

            try
            {
                db.Open();

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception ex)
            {
                result.code = "99";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return result;
        }


        #endregion[상품 설명 html 관리]

        #region[기타]
        /// <summary>
        /// 한글 멀티 상품 이미지명 일괄수정처리
        /// </summary>
        /// <remarks>
        /// </remarks>
        [HttpPut("updateKoreanImgName")]
        public async Task<ResultBasic> updateKoreanImgName(string ucode, string uname)
        {
            List<ProdMultiImg> list = new List<ProdMultiImg>();
            string fileName = string.Empty;
            ResultBasic result = new ResultBasic();
            string Rposition = "/ProdImageMulti/updateKoreanImgName";

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();

            string sql = @$"
                            select b.shop_cd, b.prod_image_seq, b.prod_code, b.file_name
                            from prod_image_multi b
                            where regexp_like(b.file_name,'[가-힝]')
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync<ProdMultiImg>(sql, param, commandType: CommandType.Text);
                list = temp.ToList();

                foreach(ProdMultiImg i in list)
                {
                    fileName = i.prod_code + i.file_name.Substring(i.file_name.Length - 19);

                    result = await updateImg(i.prod_image_seq, i.prod_code, fileName, ucode, uname);
                    string old_file_name = i.file_name;

                    if (result.code.Equals("00") && Utils.serverGbn == "R") //운영서버의 경우
                    {
                        // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            string folerPathOld = multiProdImagePath + "\\" + i.prod_code + "\\" + old_file_name;
                            string folerPath = multiProdImagePath + "\\" + i.prod_code;
                            DirectoryInfo di = new DirectoryInfo(folerPath);

                            if (di.Exists == false)
                            {
                                di.Create();
                            }

                            folerPath = folerPath + "\\" + fileName;

                            if (System.IO.File.Exists(folerPathOld))
                            {
                                System.IO.File.Move(folerPathOld, folerPath);
                            }
                            else
                            {
                                //이름변경할 파일이 실제로 없을때
                                result.code = "99";
                                result.msg = folerPathOld + " :해당위치에 파일이 존재하지 않습니다.";
                                await Utils.SaveErrorAsync(Rposition, result.msg);

                                return result;
                            }

                        }

                    }
                    else if (result.code.Equals("00") && Utils.serverGbn == "T") //테스트서버의 경우
                    {
                        string folerPathOld = testImagePath + "\\" + i.prod_code + "\\" + old_file_name;
                        string folerPath = testImagePath + "\\" + i.prod_code;
                        DirectoryInfo di = new DirectoryInfo(folerPath);

                        if (di.Exists == false)
                        {
                            di.Create();
                        }

                        folerPath = folerPath + "\\" + fileName;

                        if (System.IO.File.Exists(folerPathOld))
                        {
                            System.IO.File.Move(folerPathOld, folerPath);
                        }
                        else
                        {
                            //이름변경할 파일이 실제로 없을때
                            await Utils.SaveErrorAsync(Rposition, folerPathOld + " :해당위치에 파일이 존재하지 않습니다.");
                        }
                    }

                }

                db.Close();

                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception ex)
            {
                result.code = "99";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return result;
        }
        #endregion[기타]

    }
}
