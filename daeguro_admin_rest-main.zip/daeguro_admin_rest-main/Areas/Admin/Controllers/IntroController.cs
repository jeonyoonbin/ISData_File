﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using ImageProcessor;
using ImageProcessor.Imaging.Formats;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class IntroController : ControllerBase
    {

        /// <summary>
        /// 리뷰, 매장 알림말, 이미지 조회 rest
        /// </summary>
        /// <remarks>
        /// 사용 구분 Y만 조회 <br />
        /// intro_gbn : I 매장 알림, R 리뷰알림 <br />
        /// <br />
        /// seq: PK <br/>
        /// file_name:(원본) Intro + 업로드시간 + .jpg <br/>
        /// (썸네일) Thumb\\{file_name} <br/>
        /// ex)매장알림 이미지 "https://admin.daeguro.co.kr/intro-images/ShopImage/{shop_cd}/Thumb/{file_name}" <br />
        /// ex)리뷰알림 이미지 "https://admin.daeguro.co.kr/intro-images/ReviewImage/{shop_cd}/Thumb/{file_name}" <br />
        /// FILE_NAME_1: 첫번째 이미지 <br/>
        /// FILE_NAME_2: 두번째 이미지 <br/>
        /// </remarks>
        [HttpGet()]
        public async Task<IActionResult> getIntro(string shop_cd, string intro_gbn)
        {

            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_INTRO.GET_DETAIL",
            };

            cmd.Parameters.Add("in_push_cd", OracleDbType.Int32).Value = shop_cd;
            cmd.Parameters.Add("in_push_cd", OracleDbType.Varchar2, 2).Value = intro_gbn;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            Intro item = new Intro();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                
                if(rd.HasRows)
                {
                    await rd.ReadAsync();

                    item.intro_cd = rd["intro_cd"].ToString();
                    item.shop_cd = rd["shop_cd"].ToString();
                    item.intro_gbn = rd["intro_gbn"].ToString();
                    item.use_gbn = rd["use_gbn"].ToString();
                    item.file_name_1 = rd["file_name_1"].ToString();
                    item.file_name_2 = rd["file_name_2"].ToString();
                    item.intro_contents = rd["intro_contents"].ToString();

                    await rd.CloseAsync();
                }
                
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Intro : Get", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }


        /// <summary>
        /// 리뷰, 매장 알림이미지 업로드 및 삭제 rest
        /// </summary>
        /// <remarks>
        /// div : I 업로드, D: 삭제 <br/>
        /// intro_cd :  알림말 식별자 <br />
        /// sort (1,2) :  각 이미지는 2개까지 업로드 가능 <br />
        /// 오리지날과 썸네일 이미지 생성
        /// </remarks>
        [HttpPut("setShopInfoImage")]
        public async Task<IActionResult> setShopInfoImage(IFormFile formFile, string div, string intro_cd, string sort, string ucode, string uname)
        {
            string introPath = @"\\10.10.10.100\dgnas\Files\Intro";
            string nasPath = @"\\10.10.10.100\dgnas\Files";

            //string introPath = @"\sy100";

            Intro intro = new Intro();

            string sql = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            string folerPath = string.Empty;
            string fileName = string.Empty;

            if (string.IsNullOrEmpty(ucode))
            {
                return Ok(new { code = "99", msg = "수정자 정보가 올바르지 않습니다" });
            }


            try
            {

                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_intro_cd", intro_cd);
                param.Add("in_ucode", ucode);
                param.Add("in_uname", uname);
                param.Add("in_sort", sort);

                db.Open();

                sql = $@"   select *
                                    from shop_info_intro
                                    where INTRO_CD = :in_intro_cd
                                    ";



                intro = await db.QuerySingleAsync<Intro>(sql, param);

                if (div.Equals("I")) //입력
                {
                    if (formFile != null && formFile.Length > 0)
                    {
                        // 어떤 이미지를 올리는지 구분한다.
                        switch (intro.intro_gbn)
                        {
                            case "I":   // 매장 알림 이미지
                                {

                                    folerPath = introPath + "\\" + "ShopImage";
                                    fileName = "Intro" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + ".jpg";

                                    break;
                                }
                            case "R":   // 리뷰 알림 이미지
                                {
                                    folerPath = introPath + "\\" + "ReviewImage";
                                    fileName = "Intro" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + ".jpg";

                                    break;
                                }
                            default:
                                break;
                        }

                        string colName = string.Empty;
                        string memo = string.Empty;


                    // 경로 맨 뒤에 역슬러쉬가 없어야 한다.
                    using (new ConnectToSharedFolder(nasPath))
                        {
                            if (Directory.Exists(folerPath) == false)
                            {
                                Directory.CreateDirectory(folerPath);
                            }


                            folerPath = folerPath + "\\" + intro.shop_cd;


                            if (Directory.Exists(folerPath) == false)
                            {
                                Directory.CreateDirectory(folerPath);
                            }

                            //썸네일 폴더
                            if (Directory.Exists(folerPath + "\\Thumb") == false)
                            {
                                Directory.CreateDirectory(folerPath + "\\Thumb");
                            }

                            // 파일이 이미 존재하면 삭제한다.
                            if (System.IO.File.Exists(folerPath + "\\" + fileName))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(folerPath + "\\" + fileName);
                            }

                            //using var stream = new FileStream(folerPath + "\\" + fileName, FileMode.Create);

                            //await formFile.CopyToAsync(stream);

                            //stream.Close();
                            //stream.Dispose();

                            //누겟 imageProcessor 필요
                            using (ImageFactory imageFactory = new ImageFactory(preserveExifData: true))
                            {
                                var ima = imageFactory.Load(formFile.OpenReadStream()).Image;
                                int isizeW = 1280;
                                int isizeH = 720;
                                int quality = 100;

                                //오리지널 저장(w:1280/h:720/q:100)
                                if (ima.Width > ima.Height)
                                {
                                    if (ima.Width < 1280)
                                    {
                                        isizeW = ima.Width;
                                    }

                                    var ratio = (float)ima.Height / ima.Width;

                                    imageFactory.Load(formFile.OpenReadStream())
                                        .Format(new JpegFormat())
                                        .Resize(new Size(isizeW, (int)(isizeW * ratio)))
                                        .Quality(quality)
                                        .Save(folerPath + "\\" + fileName)
                                        .Quality(72)
                                        .Save(folerPath + "\\Thumb\\" + fileName);
                                }
                                else
                                {
                                    if (ima.Height < 720)
                                    {
                                        isizeH = ima.Height;
                                    }

                                    var ratio = (float)ima.Width / ima.Height;

                                    imageFactory.Load(formFile.OpenReadStream())
                                        .Format(new JpegFormat())
                                        .Resize(new Size((int)(isizeH * ratio), isizeH))
                                        .Quality(quality)
                                        .Save(folerPath + "\\" + fileName)
                                        .Quality(72)
                                        .Save(folerPath + "\\Thumb\\" + fileName);
                                }

                            }
                        }

                        param.Add("file_name", fileName);

                        if (sort == "1")
                        {
                            sql = $@"
                                        update shop_info_intro
                                        set file_name_1 = :file_name,
                                            mod_ucode = :in_ucode,
                                            mod_name = :in_uname,
                                            mod_date = sysdate
                                        where INTRO_CD = :in_intro_cd
                                        ";
                        } else if(sort == "2")
                        {
                            sql = $@"
                                        update shop_info_intro
                                        set file_name_2 = :file_name,
                                            mod_ucode = :in_ucode,
                                            mod_name = :in_uname,
                                            mod_date = sysdate
                                        where INTRO_CD = :in_intro_cd
                                        ";
                        }
                        

                        await db.ExecuteAsync(sql, param);


                    }
                    else
                    {
                        return Ok(new { code = "99", msg = "업로드할 이미지가 없습니다" });
                    }
                }
                else if (div.Equals("D")) //삭제
                {

                    string memo = string.Empty;

                    if (intro.intro_gbn.Equals("I"))
                    {
                        folerPath = introPath + "\\" + "ShopImage" + "\\" + intro.shop_cd;
                        memo = "[사장님 매장 알림 이미지 삭제] ";
                    }
                    else if (intro.intro_gbn.Equals("R"))
                    {
                        folerPath = introPath + "\\" + "ReviewImage" + "\\" + intro.shop_cd;
                        memo = "[사장님 리뷰 알림 이미지 삭제] ";
                    }

                    sql = @$"
                                SELECT case when :in_sort = '1' then FILE_NAME_1
                                            when :in_sort = '2' then FILE_NAME_2 end file_name
                                    FROM SHOP_INFO_INTRO
                                    WHERE INTRO_CD = :in_intro_cd
                                ";

                    fileName = await db.ExecuteScalarAsync<string>(sql, param);

                    memo = memo + "SEQ : " + sort + ", 이미지 URL : " + fileName + "[수정자: " + uname + "(" + ucode + ")]";
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        //파일 삭제
                        if (System.IO.File.Exists(folerPath + "\\" + fileName))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(folerPath + "\\" + fileName);
                            //썸네일 삭제
                            if (System.IO.File.Exists(folerPath + "\\Thumb\\" + fileName))
                            {
                                System.IO.File.Delete(folerPath + "\\Thumb\\" + fileName);
                            }

                        }

                    }

                    //테이블에서 항목 삭제
                    if (sort == "1")
                    {
                        sql = $@"
                                    update shop_info_intro
                                    set file_name_1 = null,
                                        mod_ucode = :in_ucode,
                                        mod_name = :in_uname,
                                        mod_date = sysdate
                                    where INTRO_CD = :in_intro_cd
                                    ";
                    }
                    else if (sort == "2")
                    {
                        sql = $@"
                                    update shop_info_intro
                                    set file_name_2 = null,
                                        mod_ucode = :in_ucode,
                                        mod_name = :in_uname,
                                        mod_date = sysdate
                                    where INTRO_CD = :in_intro_cd
                                    ";
                    }

                    await db.ExecuteAsync(sql, param);


                    //shop_info_hist에 삭제로그 남기기(알림이미지 로그도 트리거 처리하도록 수정필요)
                    //param.Add("shop_cd", intro.shop_cd);

                    //sql = @$"
                    //            SELECT CCCODE
                    //            FROM SHOP_INFO
                    //            WHERE SHOP_CD = :shop_cd
                    //        ";

                    //string cccode = await db.ExecuteScalarAsync<string>(sql, param);

                    //param.Add("cccode", cccode);
                    //param.Add("memo", memo);

                    //sql = $@"
                    //        insert into shop_info_hist(seqno, cccode, shop_cd, hist_date, memo)
                    //        values(SEQ_SHOP_INFO_HIST.NEXTVAL,:cccode, :shop_cd, sysdate, :memo)
                    //        ";

                    //await db.ExecuteAsync(sql, param);

                }

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = folerPath;
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Intro/setShopInfoImage : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 알림말 수정
        /// </summary>
        [HttpPut()]
        public async Task<IActionResult> Put(string intro_cd, string ucode, string uname, [FromBody] string contents)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_intro_cd", intro_cd);
            param.Add("in_contents", contents);
            param.Add("in_ucode", ucode);
            param.Add("in_uname", uname);

            string sql = $@"
                            update shop_info_intro
                            set INTRO_CONTENTS = :in_contents,
                                mod_ucode = :in_ucode,
                                mod_name = :in_uname,
                                mod_date = sysdate
                            where INTRO_CD = :in_intro_cd
                            ";

            try
            {

                db.Open();
                await db.ExecuteAsync(sql, param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Intro : Put", ex.Message);
                Rcode = "99";
                Rmsg = "실패";

            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        //매장,리뷰 알림 변경이력
        [HttpGet("history/{shop_cd}")]
        public async Task<IActionResult> history(string shop_cd, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_shop_cd", shop_cd);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT *
                                FROM (select ROWNUM as NO, T1.*
                                from(select seqno, hist_date, memo
                                    from shop_info_hist
                                    where shop_cd = :in_shop_cd
                                    and memo like '%사장님 __ 알림%'
                                    order by seqno desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2
                                WHERE ((:in_page - 1) * :in_rows) < NO
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = items.Count.ToString(), data = items });
        }
    }
}
