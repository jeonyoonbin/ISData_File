﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using System;
using System.Linq;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ProdThemaController : ControllerBase
    {
        string nasPath = @"\\10.10.10.100\dgnas\Files";
        string prodThemaPath = @"\\10.10.10.100\dgnas\Files\EtcImage\icon\prodThema";
        string testImagePath = @"E:\iis\Files\TestImage";

        /// <summary>
        /// 상품 테마 - 목록 조회
        /// </summary>
        /// <remarks>
        /// class_gbn 분류코드(필수)
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string class_gbn)
        {
            string Rcode;
            string Rmsg;
            List<ProdThemaList> items = new List<ProdThemaList>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("class_gbn", class_gbn);

            string sql = @$"
                            SELECT class_gbn,
                                   thema_code,
                                   name,
                                   use_gbn,
                                   sort_seq
                            FROM PROD_THEMA
                            WHERE class_gbn = :class_gbn
                            ORDER BY SORT_SEQ
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync<ProdThemaList>(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 상품 테마 - 상세 조회
        /// </summary>
        /// <remarks>
        /// thema_code 상품 테마 코드(필수) <br/>
        /// [response] <br/>
        /// class_gbn 분류코드 <br/>
        /// thema_code 상품 테마 코드 <br/>
        /// name 상품 테마명 <br/>
        /// use_gbn 사용여부(Y/N) <br/>
        /// test_yn 테스트여부(Y/N) <br/>
        /// img 배너이미지 파일명 <br/>
        /// memo 메모 <br/>
        /// </remarks>
        [HttpGet("getDetail")]
        public async Task<IActionResult> getDetail(string thema_code)
        {
            string Rcode;
            string Rmsg;
            ProdThema item = new ProdThema();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("thema_code", thema_code);

            string sql = @$"
                            SELECT class_gbn,
                                   thema_code,
                                   name,
                                   use_gbn,
                                   test_yn,
                                   img,
                                   memo
                            FROM PROD_THEMA
                            WHERE thema_code = :thema_code
                        ";

            try
            {
                db.Open();

                item = await db.QuerySingleAsync<ProdThema>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 상품 테마 등록
        /// </summary>
        /// <remarks>
        /// class_gbn 분류코드(필수) <br/>
        /// name 테마명 <br/>
        /// ucode 작업자코드(필수) <br/>
        /// </remarks>
        [HttpPost()]
        public async Task<IActionResult> Post(ProdCatPost item)
        {
            string Rcode;
            string Rmsg;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("class_gbn", item.class_gbn);
            param.Add("name", item.name);
            param.Add("ucode", item.ucode);

            string sql = @$"
                            insert into prod_thema(class_gbn, name, use_gbn, test_yn, ins_date, ins_ucode)
                            values(:class_gbn, :name, 'N', 'N', SYSDATE, :ucode)
                        ";

            try
            {
                db.Open();

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 상품 테마 수정
        /// </summary>
        /// <remarks>
        /// thema_code 상품 테마 코드(필수) <br/>
        /// name 테마명 <br/>
        /// use_gbn 사용여부(Y/N) <br/>
        /// test_yn 테스트여부(Y/N) <br/>
        /// ucode 작업자코드(필수) <br/>
        /// </remarks>
        [HttpPut()]
        public async Task<IActionResult> Put(ProdThemaPut item)
        {
            string Rcode;
            string Rmsg;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("thema_code", item.thema_code);
            param.Add("name", item.name);
            param.Add("use_gbn", item.use_gbn);
            param.Add("test_yn", item.test_yn);
            param.Add("memo", item.memo);
            param.Add("ucode", item.ucode);

            string sql = @$"
                            update prod_thema
                            set name = :name,
                                use_gbn = :use_gbn,
                                test_yn = :test_yn,
                                memo = :memo,
                                mod_date = sysdate,
                                mod_ucode = :ucode
                            where thema_code = :thema_code
                        ";

            try
            {
                db.Open();

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 상품 테마 이미지 업로드
        /// </summary>
        /// <remarks>
        /// thema_code 상품 테마 코드(필수) <br/>
        /// ucode 작업자코드(필수) <br/>
        /// </remarks>
        [HttpPost("uploadImg")]
        public async Task<IActionResult> uploadImg(IFormFile formFile, string thema_code, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string fileName = string.Empty;
            ResultBasic result = new ResultBasic();

            try
            {

                if (formFile != null && formFile.Length > 0)
                {
                    // 확장자 가져오기
                    int dotIdx = formFile.FileName.LastIndexOf(".");

                    int extLength = formFile.FileName.Length - dotIdx;

                    string extention = formFile.FileName.Substring(dotIdx, extLength);
                    string name = formFile.FileName.Substring(0, dotIdx);

                    string dt = DateTime.Now.ToString("yyyyMMddHHmmss");

                    // 업로드이미지명 그대로 저장
                    fileName = name + "_" + dt + extention;
                    //fileName = thema_code + "_" + dt + extention;

                    result = await _uploadImg(thema_code, fileName, ucode);


                    if (result.code == "00" && Utils.serverGbn == "R") //운영서버의 경우
                    {
                        // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            string folerPath = prodThemaPath + "\\" + fileName;
                            using var stream = System.IO.File.Create(folerPath);

                            await formFile.CopyToAsync(stream);

                            stream.Close();
                            stream.Dispose();
                        }
                    }
                    else if (result.code == "00" && Utils.serverGbn == "T") //테스트서버의 경우
                    {
                        string folerPath = testImagePath + "\\" + fileName;
                        using var stream = System.IO.File.Create(folerPath);

                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();
                    }

                    Rcode = result.code;
                    Rmsg = result.msg;

                }
                else
                {
                    Rcode = "99";
                    Rmsg = "업로드할 이미지가 없습니다.";
                }


            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/ProdThema/uploadImg : Post", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        private async Task<ResultBasic> _uploadImg(string thema_code, string img, string ucode)
        {
            ResultBasic result = new ResultBasic();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("thema_code", thema_code);
            param.Add("img", img);
            param.Add("ucode", ucode);

            string sql = @$"
                            update prod_thema
                            set img = :img,
                                mod_date = sysdate,
                                mod_ucode = :ucode
                            where thema_code = :thema_code
                        ";

            try
            {
                db.Open();

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception ex)
            {
                result.code = "99";
                result.msg = ex.Message;
            }

            return result;
        }

        /// <summary>
        /// 상품 테마 이미지 삭제
        /// </summary>
        /// <remarks>
        /// thema_code 상품 테마 코드(필수) <br/>
        /// fileName 삭제할 파일명(필수) <br/>
        /// ucode 작업자코드(필수) <br/>
        /// </remarks>
        [HttpDelete("deleteImg")]
        public async Task<IActionResult> deleteImg(string thema_code, string fileName, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            ResultBasic result = new ResultBasic();

            try
            {
                result = await _deleteImg(thema_code, fileName, ucode);

                if (result.code == "00")
                {
                    if (result.code == "00" && Utils.serverGbn == "R") //운영서버의 경우
                    {
                        // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                        using (new ConnectToSharedFolder(nasPath))
                        {
                            // 파일이 이미 존재하면 삭제한다.
                            if (System.IO.File.Exists(prodThemaPath + "\\" + fileName))
                            {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                System.IO.File.Delete(prodThemaPath + "\\" + fileName);
                            }
                        }
                    }
                    else if (result.code == "00" && Utils.serverGbn == "T") //테스트서버의 경우
                    {
                        // 파일이 이미 존재하면 삭제한다.
                        if (System.IO.File.Exists(testImagePath + "\\" + fileName))
                        {
                            System.GC.Collect();
                            System.GC.WaitForPendingFinalizers();
                            System.IO.File.Delete(testImagePath + "\\" + fileName);
                        }
                    }

                    Rcode = result.code;
                    Rmsg = result.msg;

                }
                else
                {
                    Rcode = result.code;
                    Rmsg = result.msg;
                }

            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/ProdThema/deleteImg : Delete", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        private async Task<ResultBasic> _deleteImg(string thema_code, string img, string ucode)
        {
            ResultBasic result = new ResultBasic();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("thema_code", thema_code);
            param.Add("img", img);
            param.Add("ucode", ucode);

            string sql = @$"
                            update prod_thema
                            set img = null,
                                mod_date = sysdate,
                                mod_ucode = :ucode
                            where thema_code = :thema_code
                            and img = :img
                        ";

            try
            {
                db.Open();

                var num = await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                if (num == 0)
                {
                    result.code = "98";
                    result.msg = "이미지 제거가 처리되지 않았습니다";
                    return result;
                }

                result.code = "00";
                result.msg = "성공";
            }
            catch (Exception ex)
            {
                result.code = "99";
                result.msg = ex.Message;
            }

            return result;
        }

        /// <summary>
        /// 순서변경
        /// </summary>
        [HttpPut("updateSort")]
        public async Task<IActionResult> updateSort(IEnumerable<string> items)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            string Rcode;
            string Rmsg;
            int i = 1;

            try
            {
                db.Open();
                foreach (string cd in items)
                {
                    DynamicParameters param = new DynamicParameters();
                    param.Add("cd", cd);
                    param.Add("seq", i);

                    string sql = @$"
                             update prod_thema
                                set sort_seq = :seq
                              where thema_code = :cd                           
                            ";

                    await db.ExecuteAsync(sql, param);

                    i++;
                }


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ProdThema/updateSort : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 상품 테마 - 변경이력 조회
        /// </summary>
        /// <remarks>
        /// cat_code 테마코드(필수)
        /// </remarks>
        [HttpGet("getHist")]
        public async Task<IActionResult> getHist(string thema_code)
        {
            string Rcode;
            string Rmsg;
            List<Hist> items = new List<Hist>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("thema_code", thema_code);

            string sql = @$"
                            SELECT seq,
                                   memo,
                                   hist_gbn,
                                   hist_date
                            FROM PROD_THEMA_HIST
                            WHERE thema_code = :thema_code
                            ORDER BY hist_date desc
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync<Hist>(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }
    }
}
