﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic.FileIO;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ProdController : ControllerBase
    {
        string multiProdImagePath = @"\\10.10.10.100\dgnas\Files\multiProdImage";
        string testImagePath = @"E:\iis\Files\TestImage";
        string nasPath = @"\\10.10.10.100\dgnas\Files";

        #region[상품그룹 관리]
        /// <summary>
        /// 상품그룹 목록조회
        /// </summary>
        [HttpGet("getProdGroupList")]
        public async Task<IActionResult> getProdGroupList(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<ProdGroupList> list = new List<ProdGroupList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_PROD_GROUP_LIST",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ProdGroupList s = new ProdGroupList
                    {
                        group_type = rd["GROUP_TYPE"].ToString(),
                        prod_group_cd = rd["PROD_GROUP_CD"].ToString(),
                        prod_group_name = rd["PROD_GROUP_NAME"].ToString(),
                        prod_names = rd["PROD_NAMES"].ToString(),
                        use_yn = rd["USE_YN"].ToString(),
                        main_count = rd["MAIN_COUNT"].ToString(),

                    };

                    list.Add(s);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Prod/getProdGroupList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = list });
        }

        /// <summary>
        /// 상품그룹 등록
        /// </summary>
        [HttpPost("setProdGroup")]
        public async Task<IActionResult> setProdGroup(ProdGroupPost item)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.ADD_PROD_GROUP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = item.shop_cd;
            cmd.Parameters.Add("in_group_name", OracleDbType.Varchar2, 50).Value = item.prod_group_name;
            cmd.Parameters.Add("in_group_memo", OracleDbType.Varchar2, 500).Value = item.prod_group_memo;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 1).Value = item.use_yn;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = item.ins_ucode;
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 30).Value = item.ins_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Prod/setProdGroup : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 상품그룹 단건조회
        /// </summary>
        [HttpGet("getProdGroupDetail/{group_cd}")]
        public async Task<IActionResult> GetProdGroupDetail(string group_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_PROD_GROUP_DETAIL",
            };

            cmd.Parameters.Add("in_group_cd", OracleDbType.Int32).Value = group_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            ProdGroup item = new ProdGroup();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.group_type = rd["GROUP_TYPE"].ToString();
                item.prod_group_cd = rd["PROD_GROUP_CD"].ToString();
                item.prod_group_name = rd["PROD_GROUP_NAME"].ToString();
                item.prod_group_memo = rd["PROD_GROUP_MEMO"].ToString();
                item.use_yn = rd["USE_YN"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Prod/getProdGroupDetail : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 상품그룹 수정
        /// </summary>
        [HttpPut("updateProdGroup")]
        public async Task<IActionResult> updateProdGroup(ProdGroupPut item)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.UPDATE_PROD_GROUP",
            };

            //cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = item.shopCd;
            cmd.Parameters.Add("in_group_cd", OracleDbType.Varchar2, 10).Value = item.prod_group_cd;
            cmd.Parameters.Add("in_group_name", OracleDbType.Varchar2, 50).Value = item.prod_group_name;
            cmd.Parameters.Add("in_group_memo", OracleDbType.Varchar2, 500).Value = item.prod_group_memo;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Char, 1).Value = item.use_yn;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = item.mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 30).Value = item.mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Prod/updateProdGroup : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion[상품그룹 관리]

        #region[상품 관리]
        /// <summary>
        /// 상품목록 조회
        /// </summary>
        /// <remarks>
        /// cat_code 카테고리별 조회조건(꽃배달, 장보기) <br/>
        /// prod_group_cd 상품그룹별 조회조건(전자관) <br/>
        /// keyword 상품명 검색기능 <br/>
        ///  <br/>
        /// </remarks>
        [HttpGet("getProdList")]
        public async Task<IActionResult> getProdList(string shop_cd, string cat_code, string prod_group_cd, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = @"/Prode/getProdList";

            List<ProdList> items = new List<ProdList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_PROD_LIST",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_cat_code", OracleDbType.Int32).Value = cat_code;
            cmd.Parameters.Add("in_prod_group_cd", OracleDbType.Int32).Value = prod_group_cd;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 300).Value = keyword;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ProdList i = new ProdList
                    {
                        cat_code = rd["cat_code"].ToString(),
                        cat_name = rd["cat_name"].ToString(),
                        prod_code = rd["prod_code"].ToString(),
                        name = rd["name"].ToString(),
                        cost = rd["cost"].ToString(),
                        disc_yn = rd["disc_yn"].ToString(),
                        disc_ratio = rd["disc_ratio"].ToString(),
                        amount = rd["amount"].ToString(),
                        file_name = rd["file_name"].ToString(),
                        multi_cnt = rd["multi_cnt"].ToString(),
                        main_yn = rd["MAIN_YN"].ToString(),
                        use_gbn = rd["USE_GBN"].ToString(),
                        no_flag = rd["NO_FLAG"].ToString(),
                        prod_group_cd = rd["PROD_GROUP_CD"].ToString(),
                        html = rd["HTML"].ToString(),
                    };

                    items.Add(i);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 상품상세 조회
        /// </summary>
        /// <remarks>
        /// prod_code 상품코드 <br/>
        /// name 상품명 <br/>
        /// ribbon_card_yn 리본/카드 사용여부(Y/N) <br/>
        /// cost 가격 <br/>
        /// amount 할인된 가격 <br/>
        /// disc_ratio 할인율 <br/>
        /// disc_mark_gbn 할인표기구분 (0: 할인문구, 3: 퍼센트) <br/>
        /// disc_st_dt 할인 시작일 <br/>
        /// disc_to_dt 할인 종료일 <br/>
        /// memo 메모 <br/>
        /// cat_code1 상품 카테고리1 <br/>
        /// cat_code2 상품 카테고리2 <br/>
        /// cat_code3 상품 카테고리3 <br/>
        /// thema_code1 상품 테마1  <br/>
        /// thema_code2 상품 테마2 <br/>
        /// thema_code3 상품 테마3 <br/>
        /// use_gbn 사용여부(Y/N) <br/>
        /// no_flag 품절여부(Y/N) <br/>
        /// main_yn 대표여부(Y/N) <br/>
        /// description 상품설명 <br/>
        /// mark1_yn 배찌1(정품생화) 사용여부(Y/N) <br/>
        /// mark2_yn 배찌2 사용여부(Y/N) <br/>
        /// mark2_txt 배찌2 문구(DEFAULT:특가) <br/>
        /// prod_group_cd 상품그룹코드 <br/>
        /// </remarks>
        [HttpGet("getProdDetail")]
        public async Task<IActionResult> getProdDetail(string prod_code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rpostion = @"/Prode/getProdDetail";

            ProdDetail item = new ProdDetail();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_PROD_DETAIL",
            };

            cmd.Parameters.Add("in_prod_code", OracleDbType.Int32).Value = prod_code;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.prod_code = rd["prod_code"].ToString();
                item.name = rd["name"].ToString();
                item.ribbon_card_yn = rd["ribbon_card_yn"].ToString();
                item.cost = rd["cost"].ToString();
                item.amount = rd["amount"].ToString();
                item.disc_ratio = rd["disc_ratio"].ToString();
                item.disc_mark_gbn = rd["disc_mark_gbn"].ToString();
                item.disc_st_dt = rd["disc_st_dt"].ToString();
                item.disc_to_dt = rd["disc_to_dt"].ToString();
                item.memo = rd["memo"].ToString();
                item.cat_code1 = rd["cat_code1"].ToString();
                item.cat_code2 = rd["cat_code2"].ToString();
                item.cat_code3 = rd["cat_code3"].ToString();
                item.thema_code1 = rd["thema_code1"].ToString();
                item.thema_code2 = rd["thema_code2"].ToString();
                item.thema_code3 = rd["thema_code3"].ToString();
                item.use_gbn = rd["use_gbn"].ToString();
                item.no_flag = rd["no_flag"].ToString();
                item.main_yn = rd["main_yn"].ToString();
                item.description = rd["description"].ToString();
                item.mark1_yn = rd["mark1_yn"].ToString();
                item.mark2_yn = rd["mark2_yn"].ToString();
                item.mark2_txt = rd["mark2_txt"].ToString();
                item.prod_group_cd = rd["prod_group_cd"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rpostion, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// (꽃배달,전자관)상품 등록
        /// </summary>
        /// <remarks>
        /// shop_cd 가맹점코드 <br/>
        /// name 상품명 <br/>
        /// ribbon_card_yn 리본/카드 사용여부(Y/N) (필수) <br/>
        /// cost 가격(필수) <br/>
        /// amount 할인된 가격(null 또는 숫자값) <br/>
        /// disc_ratio 할인율(null 또는 숫자값) <br/>
        /// disc_mark_gbn 할인표기구분 (0: 할인문구, 3: 퍼센트) <br/>
        /// disc_st_dt 할인 시작일 <br/>
        /// disc_to_dt 할인 종료일 <br/>
        /// memo 메모 <br/>
        /// prod_group_cd 상품그룹코드(꽃배달: 빈값, 전자관: 필수) <br/>
        /// cat_code1 상품 카테고리1(null 또는 숫자값) <br/>
        /// cat_code2 상품 카테고리2(null 또는 숫자값) <br/>
        /// cat_code3 상품 카테고리3(null 또는 숫자값) <br/>
        /// thema_code1 상품 테마1(null 또는 숫자값)  <br/>
        /// thema_code2 상품 테마2(null 또는 숫자값) <br/>
        /// thema_code3 상품 테마3(null 또는 숫자값) <br/>
        /// use_gbn 사용여부(Y/N) (필수) <br/>
        /// no_flag 품절여부(Y/N) (필수) <br/>
        /// main_yn 대표여부(Y/N) (필수) <br/>
        /// description 상품설명 <br/>
        /// mark1_yn 배찌1(정품생화) 사용여부(Y/N) <br/>
        /// mark2_yn 배찌2 사용여부(Y/N) <br/>
        /// mark2_txt 배찌2 문구(DEFAULT:특가) <br/>
        /// </remarks>
        [HttpPost("setProd")]
        public async Task<IActionResult> setProd(ProdPost item)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rpostion = @"/Prode/setProd";

            if (string.IsNullOrEmpty(item.cost))
            {
                Rcode = "99";
                Rmsg = "가격은 필수입니다.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            List<string> cat_code_l = new List<string>();
            cat_code_l.Add(item.cat_code1);
            cat_code_l.Add(item.cat_code2);
            cat_code_l.Add(item.cat_code3);
            //중복검사
            var dupls = cat_code_l.GroupBy(i => i)
                .Where(g => g.Count() > 1)
                .Select(i => i.Key);
            foreach (string i in dupls)
            {
                if (!string.IsNullOrEmpty(i)) // NULL이 아닌 중복값이 있는경우
                {
                    Rcode = "99";
                    Rmsg = "카테고리 중복설정은 불가합니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }
            }

            List<string> thema_code_l = new List<string>();
            thema_code_l.Add(item.thema_code1);
            thema_code_l.Add(item.thema_code2);
            thema_code_l.Add(item.thema_code3);
            //중복검사
            dupls = thema_code_l.GroupBy(i => i)
                .Where(g => g.Count() > 1)
                .Select(i => i.Key);
            foreach (string i in dupls)
            {
                if (!string.IsNullOrEmpty(i)) // NULL이 아닌 중복값이 있는경우
                {
                    Rcode = "99";
                    Rmsg = "테마 중복설정은 불가합니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }
            }

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
                OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_PROD.ADD_PROD_V2",
                };

                cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = item.shop_cd;
                cmd.Parameters.Add("in_name", OracleDbType.Varchar2, 100).Value = item.name;
                cmd.Parameters.Add("in_ribbon_card_yn", OracleDbType.Varchar2, 1).Value = item.ribbon_card_yn;
                cmd.Parameters.Add("in_cost", OracleDbType.Int32).Value = item.cost;
                cmd.Parameters.Add("in_amount", OracleDbType.Int32).Value = item.amount;
                cmd.Parameters.Add("in_disc_ratio", OracleDbType.Int32).Value = item.disc_ratio;
                cmd.Parameters.Add("in_disc_mark_gbn", OracleDbType.Varchar2, 1).Value = item.disc_mark_gbn;
                cmd.Parameters.Add("in_disc_st_dt", OracleDbType.Varchar2, 8).Value = item.disc_st_dt;
                cmd.Parameters.Add("in_disc_to_dt", OracleDbType.Varchar2, 8).Value = item.disc_to_dt;
                cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 500).Value = item.memo;
                cmd.Parameters.Add("in_prod_group_cd", OracleDbType.Int32).Value = item.prod_group_cd;
                var cat_code = cmd.Parameters.Add("in_cat_code", OracleDbType.Int32);
                cat_code.Direction = ParameterDirection.Input;
                cat_code.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                cat_code.Value = cat_code_l.ToArray();
                cat_code.Size = cat_code_l.Count();
                cat_code.ArrayBindSize = cat_code_l.Select(_ => _?.Length ?? 0).ToArray();
                cat_code.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, cat_code_l.Count()).ToArray();

                var thema_code = cmd.Parameters.Add("in_thema_code", OracleDbType.Int32);
                thema_code.Direction = ParameterDirection.Input;
                thema_code.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                thema_code.Value = thema_code_l.ToArray();
                thema_code.Size = thema_code_l.Count();
                thema_code.ArrayBindSize = thema_code_l.Select(_ => _?.Length ?? 0).ToArray();
                thema_code.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, thema_code_l.Count()).ToArray();
                cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = item.use_gbn;
                cmd.Parameters.Add("in_no_flag", OracleDbType.Varchar2, 1).Value = item.no_flag;
                cmd.Parameters.Add("in_main_yn", OracleDbType.Varchar2, 1).Value = item.main_yn;
                cmd.Parameters.Add("in_description", OracleDbType.Varchar2, 4000).Value = item.description;
                cmd.Parameters.Add("in_mark1_yn", OracleDbType.Varchar2, 1).Value = item.mark1_yn;
                cmd.Parameters.Add("in_mark2_yn", OracleDbType.Varchar2, 1).Value = item.mark2_yn;
                cmd.Parameters.Add("in_mark2_txt", OracleDbType.Varchar2, 10).Value = item.mark2_txt;
                cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = item.ins_ucode;
                cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 200).Value = item.ins_name;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rpostion, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// (꽃배달,전자관)상품 수정
        /// </summary>
        /// <remarks>
        /// shop_cd 가맹점코드 <br/>
        /// prod_code 상품코드 <br/>
        /// name 상품명 <br/>
        /// ribbon_card_yn 리본/카드 사용여부(Y/N) (필수) <br/>
        /// cost 가격(필수) <br/>
        /// amount 할인된 가격(null 또는 숫자값) <br/>
        /// disc_ratio 할인율(null 또는 숫자값) <br/>
        /// disc_mark_gbn 할인표기구분 (0: 할인문구, 3: 퍼센트) <br/>
        /// disc_st_dt 할인 시작일 <br/>
        /// disc_to_dt 할인 종료일 <br/>
        /// memo 메모 <br/>
        /// prod_group_cd 상품그룹코드(꽃배달: 빈값, 전자관: 필수) <br/>
        /// cat_code1 상품 카테고리1(null 또는 숫자값) <br/>
        /// cat_code2 상품 카테고리2(null 또는 숫자값) <br/>
        /// cat_code3 상품 카테고리3(null 또는 숫자값) <br/>
        /// thema_code1 상품 테마1(null 또는 숫자값)  <br/>
        /// thema_code2 상품 테마2(null 또는 숫자값) <br/>
        /// thema_code3 상품 테마3(null 또는 숫자값) <br/>
        /// use_gbn 사용여부(Y/N) (필수) <br/>
        /// no_flag 품절여부(Y/N) (필수) <br/>
        /// main_yn 대표여부(Y/N) (필수) <br/>
        /// description 상품설명 <br/>
        /// mark1_yn 배찌1(정품생화) 사용여부(Y/N) <br/>
        /// mark2_yn 배찌2 사용여부(Y/N) <br/>
        /// mark2_txt 배찌2 문구(DEFAULT:특가) <br/>
        /// </remarks>
        [HttpPost("updateProd")]
        public async Task<IActionResult> updateProd(ProdPut item)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rpostion = @"/Prode/updateProd";

            if (string.IsNullOrEmpty(item.cost))
            {
                Rcode = "99";
                Rmsg = "가격은 필수입니다.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            List<string> cat_code_l = new List<string>();
            cat_code_l.Add(item.cat_code1);
            cat_code_l.Add(item.cat_code2);
            cat_code_l.Add(item.cat_code3);
            //중복검사
            var dupls = cat_code_l.GroupBy(i => i)
                .Where(g => g.Count() > 1)
                .Select(i => i.Key);
            foreach (string i in dupls)
            {
                if (!string.IsNullOrEmpty(i)) // NULL이 아닌 중복값이 있는경우
                {
                    Rcode = "99";
                    Rmsg = "카테고리 중복설정은 불가합니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }
            }

            List<string> thema_code_l = new List<string>();
            thema_code_l.Add(item.thema_code1);
            thema_code_l.Add(item.thema_code2);
            thema_code_l.Add(item.thema_code3);
            //중복검사
            dupls = thema_code_l.GroupBy(i => i)
                .Where(g => g.Count() > 1)
                .Select(i => i.Key);
            foreach (string i in dupls)
            {
                if (!string.IsNullOrEmpty(i)) // NULL이 아닌 중복값이 있는경우
                {
                    Rcode = "99";
                    Rmsg = "테마 중복설정은 불가합니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }
            }

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.UPDATE_PROD_V2",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = item.shop_cd;
            cmd.Parameters.Add("in_prod_code", OracleDbType.Int32).Value = item.prod_code;
            cmd.Parameters.Add("in_name", OracleDbType.Varchar2, 100).Value = item.name;
            cmd.Parameters.Add("in_ribbon_card_yn", OracleDbType.Varchar2, 1).Value = item.ribbon_card_yn;
            cmd.Parameters.Add("in_cost", OracleDbType.Int32).Value = item.cost;
            cmd.Parameters.Add("in_amount", OracleDbType.Int32).Value = item.amount;
            cmd.Parameters.Add("in_disc_ratio", OracleDbType.Int32).Value = item.disc_ratio;
            cmd.Parameters.Add("in_disc_mark_gbn", OracleDbType.Varchar2, 1).Value = item.disc_mark_gbn;
            cmd.Parameters.Add("in_disc_st_dt", OracleDbType.Varchar2, 8).Value = item.disc_st_dt;
            cmd.Parameters.Add("in_disc_to_dt", OracleDbType.Varchar2, 8).Value = item.disc_to_dt;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 500).Value = item.memo;
            cmd.Parameters.Add("in_prod_group_cd", OracleDbType.Int32).Value = item.prod_group_cd;
            var cat_code = cmd.Parameters.Add("in_cat_code", OracleDbType.Int32);
            cat_code.Direction = ParameterDirection.Input;
            cat_code.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            cat_code.Value = cat_code_l.ToArray();
            cat_code.Size = cat_code_l.Count();
            cat_code.ArrayBindSize = cat_code_l.Select(_ => _?.Length ?? 0).ToArray();
            cat_code.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, cat_code_l.Count()).ToArray();
            var thema_code = cmd.Parameters.Add("in_thema_code", OracleDbType.Int32);
            thema_code.Direction = ParameterDirection.Input;
            thema_code.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            thema_code.Value = thema_code_l.ToArray();
            thema_code.Size = thema_code_l.Count();
            thema_code.ArrayBindSize = thema_code_l.Select(_ => _?.Length ?? 0).ToArray();
            thema_code.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, thema_code_l.Count()).ToArray();
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = item.use_gbn;
            cmd.Parameters.Add("in_no_flag", OracleDbType.Varchar2, 1).Value = item.no_flag;
            cmd.Parameters.Add("in_main_yn", OracleDbType.Varchar2, 1).Value = item.main_yn;
            cmd.Parameters.Add("in_description", OracleDbType.Varchar2, 4000).Value = item.description;
            cmd.Parameters.Add("in_mark1_yn", OracleDbType.Varchar2, 1).Value = item.mark1_yn;
            cmd.Parameters.Add("in_mark2_yn", OracleDbType.Varchar2, 1).Value = item.mark2_yn;
            cmd.Parameters.Add("in_mark2_txt", OracleDbType.Varchar2, 10).Value = item.mark2_txt;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = item.mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 200).Value = item.mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rpostion, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 상품 복사
        /// </summary>
        /// <remarks>
        /// prod_code : 복사대상 상품코드 <br/>
        /// * 대표메뉴 여부는 항상 N으로 복사 <br/>
        /// * 옵션 연결은 함께 복사되지 않음 <br/>
        /// </remarks>
        [HttpPost("copyProd")]
        public async Task<IActionResult> copyProd(string prod_code, string ins_ucode, string ins_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rpostion = @"/Prode/copyProd";

            if (string.IsNullOrEmpty(ins_ucode) || string.IsNullOrEmpty(ins_name))
            {
                Rcode = "99";
                Rmsg = "작업자는 필수입니다.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.COPY_PROD",
            };

            cmd.Parameters.Add("in_prod_code", OracleDbType.Int32).Value = prod_code;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = ins_ucode;
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 200).Value = ins_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                if (Rcode == "00" && Utils.serverGbn == "R")
                {
                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        string folerPath = multiProdImagePath + "\\" + prod_code;
                        string folerPathNew = multiProdImagePath + "\\" + Rmsg;

                        if (Directory.Exists(folerPath))
                        {
                            Directory.CreateDirectory(folerPathNew);
                            FileSystem.CopyDirectory(folerPath + "\\", folerPathNew, UIOption.AllDialogs);
                        }


                        //DirectoryInfo di = new DirectoryInfo(folerPath);

                        //if (di.Exists == true)
                        //{
                        //    var files = Directory.GetFiles(folerPath).ToList();

                        //    // 복사할 파일이 존재할 때만 디렉토리를 생성하고 복사를 진행한다.
                        //    if (files.Count > 0)
                        //    {
                        //        Directory.CreateDirectory(folerPathNew);
                        //    }

                        //    foreach (var file in files)
                        //    {
                        //        int iPos = file.LastIndexOf(@"\");
                        //        string file_name = file.Substring(iPos + 1, file.Length - (iPos + 1));
                        //        System.IO.File.Copy(file, folerPathNew + "\\" + file_name);
                        //    }
                        //}
                    }
                }
                else if (Rcode == "00" && Utils.serverGbn == "T")
                {
                    string folerPath = testImagePath + "\\" + prod_code;
                    string folerPathNew = testImagePath + "\\" + Rmsg;

                    if (Directory.Exists(folerPath))
                    {
                        Directory.CreateDirectory(folerPathNew);
                        FileSystem.CopyDirectory(folerPath + "\\", folerPathNew, UIOption.AllDialogs);
                    }

                    //DirectoryInfo di = new DirectoryInfo(folerPath);

                    //if (di.Exists == true)
                    //{
                    //    var files = Directory.GetFiles(folerPath).ToList();

                    //    // 복사할 파일이 존재할 때만 디렉토리를 생성하고 복사를 진행한다.
                    //    if (files.Count > 0)
                    //    {
                    //        Directory.CreateDirectory(folerPathNew);
                    //    }

                    //    foreach (var file in files)
                    //    {
                    //        int iPos = file.LastIndexOf(@"\");
                    //        string file_name = file.Substring(iPos + 1, file.Length - (iPos + 1));
                    //        System.IO.File.Copy(file, folerPathNew + "\\" + file_name);
                    //    }
                    //}

                }

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rpostion, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 상품 초기화
        /// </summary>
        /// <remarks>
        /// shop_cd : 가맹점코드 <br/>
        /// * 해당 가맹점의 모든 상품정보 제거 <br/>
        /// * 이미지파일제거X <br/>
        /// </remarks>
        [HttpDelete("initShopProd")]
        public async Task<IActionResult> initShopProd(string shop_cd, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rpostion = @"/Prod/initShopProd";

            if (string.IsNullOrEmpty(mod_ucode) || string.IsNullOrEmpty(mod_name))
            {
                Rcode = "99";
                Rmsg = "작업자는 필수입니다.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.INIT_SHOP_PROD",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 200).Value = mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rpostion, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 상품 관련항목 정렬
        /// </summary>
        /// <remarks>
        /// div ( 0: 상품그룹, 1: 상품, 2: 상품 연결 옵션그룹, 3: 상품 옵션, 4: 멀티 상품 이미지 )
        /// </remarks>
        [HttpPost("updateSort")]
        public async Task<IActionResult> updateSort(string div, IEnumerable<string> pk)
        {
            if (string.IsNullOrEmpty(pk.FirstOrDefault()))
            {
                return Ok(new { code = "99", msg = "정렬할 항목이 없습니다" });
            }

            // div ( 2 : 메뉴에 해당되는 옵션그룹 (menu_option_group.sort_no), 3: 메뉴 옵션 리스트, 4: 멀티 상품 이미지 )
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rpostion = @"/Prode/updateSort";

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.UPDATE_SORT_SEQ",
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 1).Value = div;

            var arr = cmd.Parameters.Add("in_cd_array", OracleDbType.Int32);
            arr.Direction = ParameterDirection.Input;
            arr.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr.Value = pk.ToArray();
            arr.Size = pk.Count();
            arr.ArrayBindSize = pk.Select(_ => _.Length).ToArray();
            arr.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, pk.Count()).ToArray();

            string msg = string.Empty;
            foreach (var item in pk)
            {
                msg = msg + item.ToString() + ",";
            }

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rpostion, ex.Message + "[ div: " + div + " ,arr: " + msg + " ]");
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 카테고리별 상품 정렬
        /// </summary>
        /// <remarks>
        /// cat_code : 카테고리 코드 <br/>
        /// pk : 상품 코드 배열 <br/>
        /// </remarks>
        [HttpPost("updateCatSort")]
        public async Task<IActionResult> updateCatSort(string cat_code, IEnumerable<string> pk)
        {
            if (string.IsNullOrEmpty(pk.FirstOrDefault()))
            {
                return Ok(new { code = "99", msg = "정렬할 항목이 없습니다" });
            }

            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rpostion = @"/Prode/updateCatSort";

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.UPDATE_CAT_SORT_SEQ",
            };

            cmd.Parameters.Add("in_cat_code", OracleDbType.Int32).Value = cat_code;

            var arr = cmd.Parameters.Add("in_prod_code", OracleDbType.Int32);
            arr.Direction = ParameterDirection.Input;
            arr.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr.Value = pk.ToArray();
            arr.Size = pk.Count();
            arr.ArrayBindSize = pk.Select(_ => _.Length).ToArray();
            arr.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, pk.Count()).ToArray();

            string msg = string.Empty;
            foreach (var item in pk)
            {
                msg = msg + item.ToString() + ",";
            }

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rpostion, ex.Message + "[ cat_code: " + cat_code + " ,arr: " + msg + " ]");
            }

            return Ok(new { code = Rcode, msg = Rmsg });


        }
        #endregion[상품 관리]

        #region[(장보기)상품 관리]
        /// <summary>
        /// (장보기)상품 등록
        /// </summary>
        /// <remarks>
        /// shop_cd 가맹점코드 <br/>
        /// name 상품명 <br/>
        /// cost 가격(필수) <br/>
        /// amount 할인된 가격(null 또는 숫자값) <br/>
        /// disc_ratio 할인율(null 또는 숫자값) <br/>
        /// disc_mark_gbn 할인표기구분 (0: 할인문구, 3: 퍼센트) <br/>
        /// disc_st_dt 할인 시작일 <br/>
        /// disc_to_dt 할인 종료일 <br/>
        /// memo 메모 <br/>
        /// cat_code1 상품 카테고리1(null 또는 숫자값) <br/>
        /// cat_code2 상품 카테고리2(null 또는 숫자값) <br/>
        /// cat_code3 상품 카테고리3(null 또는 숫자값) <br/>
        /// use_gbn 사용여부(Y/N) (필수) <br/>
        /// no_flag 품절여부(Y/N) (필수) <br/>
        /// main_yn 대표여부(Y/N) (필수) <br/>
        /// description 상품설명 <br/>
        /// mark2_yn 배찌2 사용여부(Y/N) <br/>
        /// mark2_txt 배찌2 문구(DEFAULT:특가) <br/>
        /// </remarks>
        [HttpPost("setBundleProd")]
        public async Task<IActionResult> setBundleProd(BundleProdPost item)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rpostion = @"/Prode/setProd";

            if (string.IsNullOrEmpty(item.cost))
            {
                Rcode = "99";
                Rmsg = "가격은 필수입니다.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            List<string> cat_code_l = new List<string>();
            cat_code_l.Add(item.cat_code1);
            cat_code_l.Add(item.cat_code2);
            cat_code_l.Add(item.cat_code3);
            //중복검사
            var dupls = cat_code_l.GroupBy(i => i)
                .Where(g => g.Count() > 1)
                .Select(i => i.Key);
            foreach (string i in dupls)
            {
                if (!string.IsNullOrEmpty(i)) // NULL이 아닌 중복값이 있는경우
                {
                    Rcode = "99";
                    Rmsg = "카테고리 중복설정은 불가합니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }
            }

            try
            {
                using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
                OracleCommand cmd = new OracleCommand
                {
                    Connection = conn,
                    CommandType = CommandType.StoredProcedure,
                    CommandText = "PKG_IS_ADMIN_PROD.ADD_BUNDLE_PROD",
                };

                cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = item.shop_cd;
                cmd.Parameters.Add("in_name", OracleDbType.Varchar2, 100).Value = item.name;
                //cmd.Parameters.Add("in_ribbon_card_yn", OracleDbType.Varchar2, 1).Value = item.ribbon_card_yn;
                cmd.Parameters.Add("in_cost", OracleDbType.Int32).Value = item.cost;
                cmd.Parameters.Add("in_amount", OracleDbType.Int32).Value = item.amount;
                cmd.Parameters.Add("in_disc_ratio", OracleDbType.Int32).Value = item.disc_ratio;
                cmd.Parameters.Add("in_disc_mark_gbn", OracleDbType.Varchar2, 1).Value = item.disc_mark_gbn;
                cmd.Parameters.Add("in_disc_st_dt", OracleDbType.Varchar2, 8).Value = item.disc_st_dt;
                cmd.Parameters.Add("in_disc_to_dt", OracleDbType.Varchar2, 8).Value = item.disc_to_dt;
                cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 500).Value = item.memo;
                var cat_code = cmd.Parameters.Add("in_cat_code", OracleDbType.Int32);
                cat_code.Direction = ParameterDirection.Input;
                cat_code.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                cat_code.Value = cat_code_l.ToArray();
                cat_code.Size = cat_code_l.Count();
                cat_code.ArrayBindSize = cat_code_l.Select(_ => _?.Length ?? 0).ToArray();
                cat_code.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, cat_code_l.Count()).ToArray();

                cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = item.use_gbn;
                cmd.Parameters.Add("in_no_flag", OracleDbType.Varchar2, 1).Value = item.no_flag;
                cmd.Parameters.Add("in_main_yn", OracleDbType.Varchar2, 1).Value = item.main_yn;
                cmd.Parameters.Add("in_description", OracleDbType.Varchar2, 4000).Value = item.description;
                //cmd.Parameters.Add("in_mark1_yn", OracleDbType.Varchar2, 1).Value = item.mark1_yn;
                cmd.Parameters.Add("in_mark2_yn", OracleDbType.Varchar2, 1).Value = item.mark2_yn;
                cmd.Parameters.Add("in_mark2_txt", OracleDbType.Varchar2, 10).Value = item.mark2_txt;
                cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = item.ins_ucode;
                cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 200).Value = item.ins_name;
                cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rpostion, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// (장보기)상품 수정
        /// </summary>
        /// <remarks>
        /// shop_cd 가맹점코드 <br/>
        /// prod_code 상품코드 <br/>
        /// name 상품명 <br/>
        /// cost 가격(필수) <br/>
        /// amount 할인된 가격(null 또는 숫자값) <br/>
        /// disc_ratio 할인율(null 또는 숫자값) <br/>
        /// disc_mark_gbn 할인표기구분 (0: 할인문구, 3: 퍼센트) <br/>
        /// disc_st_dt 할인 시작일 <br/>
        /// disc_to_dt 할인 종료일 <br/>
        /// memo 메모 <br/>
        /// cat_code1 상품 카테고리1(null 또는 숫자값) <br/>
        /// cat_code2 상품 카테고리2(null 또는 숫자값) <br/>
        /// cat_code3 상품 카테고리3(null 또는 숫자값) <br/>
        /// use_gbn 사용여부(Y/N) (필수) <br/>
        /// no_flag 품절여부(Y/N) (필수) <br/>
        /// main_yn 대표여부(Y/N) (필수) <br/>
        /// description 상품설명 <br/>
        /// mark2_yn 배찌2 사용여부(Y/N) <br/>
        /// mark2_txt 배찌2 문구(DEFAULT:특가) <br/>
        /// </remarks>
        [HttpPost("updateBundleProd")]
        public async Task<IActionResult> updateBundleProd(BundleProdPut item)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rpostion = @"/Prode/updateBundleProd ";

            if (string.IsNullOrEmpty(item.cost))
            {
                Rcode = "99";
                Rmsg = "가격은 필수입니다.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            List<string> cat_code_l = new List<string>();
            cat_code_l.Add(item.cat_code1);
            cat_code_l.Add(item.cat_code2);
            cat_code_l.Add(item.cat_code3);
            //중복검사
            var dupls = cat_code_l.GroupBy(i => i)
                .Where(g => g.Count() > 1)
                .Select(i => i.Key);
            foreach (string i in dupls)
            {
                if (!string.IsNullOrEmpty(i)) // NULL이 아닌 중복값이 있는경우
                {
                    Rcode = "99";
                    Rmsg = "카테고리 중복설정은 불가합니다.";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }
            }

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.UPDATE_BUNDLE_PROD",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = item.shop_cd;
            cmd.Parameters.Add("in_prod_code", OracleDbType.Int32).Value = item.prod_code;
            cmd.Parameters.Add("in_name", OracleDbType.Varchar2, 100).Value = item.name;
            //cmd.Parameters.Add("in_ribbon_card_yn", OracleDbType.Varchar2, 1).Value = item.ribbon_card_yn;
            cmd.Parameters.Add("in_cost", OracleDbType.Int32).Value = item.cost;
            cmd.Parameters.Add("in_amount", OracleDbType.Int32).Value = item.amount;
            cmd.Parameters.Add("in_disc_ratio", OracleDbType.Int32).Value = item.disc_ratio;
            cmd.Parameters.Add("in_disc_mark_gbn", OracleDbType.Varchar2, 1).Value = item.disc_mark_gbn;
            cmd.Parameters.Add("in_disc_st_dt", OracleDbType.Varchar2, 8).Value = item.disc_st_dt;
            cmd.Parameters.Add("in_disc_to_dt", OracleDbType.Varchar2, 8).Value = item.disc_to_dt;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 500).Value = item.memo;
            var cat_code = cmd.Parameters.Add("in_cat_code", OracleDbType.Int32);
            cat_code.Direction = ParameterDirection.Input;
            cat_code.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            cat_code.Value = cat_code_l.ToArray();
            cat_code.Size = cat_code_l.Count();
            cat_code.ArrayBindSize = cat_code_l.Select(_ => _?.Length ?? 0).ToArray();
            cat_code.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, cat_code_l.Count()).ToArray();
            
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = item.use_gbn;
            cmd.Parameters.Add("in_no_flag", OracleDbType.Varchar2, 1).Value = item.no_flag;
            cmd.Parameters.Add("in_main_yn", OracleDbType.Varchar2, 1).Value = item.main_yn;
            cmd.Parameters.Add("in_description", OracleDbType.Varchar2, 4000).Value = item.description;
            //cmd.Parameters.Add("in_mark1_yn", OracleDbType.Varchar2, 1).Value = item.mark1_yn;
            cmd.Parameters.Add("in_mark2_yn", OracleDbType.Varchar2, 1).Value = item.mark2_yn;
            cmd.Parameters.Add("in_mark2_txt", OracleDbType.Varchar2, 10).Value = item.mark2_txt;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = item.mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 200).Value = item.mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rpostion, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 가맹점 (장보기)상품 일괄 사용
        /// </summary>
        /// <remarks>
        /// 미사용인 장보기상품 일괄 사용처리
        /// </remarks>
        [HttpPut("useShopBundleProd")]
        public async Task<IActionResult> useShopBundleProd(string shop_cd, string mod_ucode, string mod_name)
        {
            string? Rcode = string.Empty;
            string? Rmsg = string.Empty;

            if (string.IsNullOrEmpty(shop_cd) ||
                string.IsNullOrEmpty(mod_ucode) ||
                string.IsNullOrEmpty(mod_name))
            {
                Rcode = "99";
                Rmsg = "필수입력값이 누락되었습니다.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            using OracleConnection conn = new(Utils.oracleConnectString);

            using OracleCommand cmd = new()
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.USE_SHOP_BUNDLE_PROD",
            };


            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 30).Value = mod_name;

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "98";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/useShopBundleProd : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion[(장보기)상품 관리]

        #region[상품 옵션그룹 연결 관리]
        /// <summary>
        /// 상품별 옵션 연결 시 옵션 그룹 조회
        /// </summary>
        /// <remarks>
        /// shopCd [가맹점 코드] <br />
        /// prodCd [상품 코드] <br />
        /// </remarks>
        [HttpGet("getOptGrpSelected")]
        public async Task<IActionResult> GetOptGrpSelected(string shopCd, string prodCd)
        {
            string? Rcode = string.Empty;
            string? Rmsg = string.Empty;

            List<OptGrpSelect> optGrpSeleted = new();

            using OracleConnection conn = new(Utils.oracleConnectString);

            using OracleCommand cmd = new()
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_OPTION_GRP_SELECT_LIST",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shopCd;
            cmd.Parameters.Add("in_prod_cd", OracleDbType.Int32).Value = prodCd;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    OptGrpSelect o = new()
                    {
                        selected = rd["SELECTED"].ToString(),
                        optGrpCd = rd["OPTION_GROUP_CD"].ToString(),
                        name = rd["NAME"].ToString(),
                        minCount = rd["MIN_COUNT"].ToString(),
                        multiCount = rd["MULTI_COUNT"].ToString(),
                        addYn = rd["ADD_YN"].ToString(),
                        useGbn = rd["USE_GBN"].ToString(),
                        optNames = rd["OPTION_NAMES"].ToString()

                    };

                    optGrpSeleted.Add(o);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Product/getOptGrpSelected : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = optGrpSeleted });
        }

        /// <summary>
        /// 상품 옵션 연결
        /// </summary>
        /// <remarks>
        /// shopCd [가맹점 코드] <br />
        /// prodCd [상품 코드] <br />
        /// optGrpCd [옵션그룹코드] <br />
        /// </remarks>
        [HttpPut("setProdOption")]
        public async Task<IActionResult> SetProdOption(SetProdOpt setProdOpt)
        {
            string? Rcode = string.Empty;
            string? Rmsg = string.Empty;

            if (setProdOpt.optGrpCd.Count() == 0)
            {
                Rcode = "99";
                Rmsg = "연결할 옵션그룹을 선택해주세요.";
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            using OracleConnection conn = new(Utils.oracleConnectString);

            using OracleCommand cmd = new()
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.SET_PROD_OPTION",
            };


            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = setProdOpt.shopCd;
            cmd.Parameters.Add("in_prod_cd", OracleDbType.Int32).Value = setProdOpt.prodCd;
            var optGrpCd = cmd.Parameters.Add("in_option_grp_cd", OracleDbType.Int32);
            optGrpCd.Direction = ParameterDirection.Input;
            optGrpCd.Value = setProdOpt.optGrpCd.ToArray();
            optGrpCd.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            optGrpCd.Size = setProdOpt.optGrpCd.Count();
            optGrpCd.ArrayBindSize = setProdOpt.optGrpCd.Select(_ => _.Length).ToArray();
            optGrpCd.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, setProdOpt.optGrpCd.Count()).ToArray();
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = setProdOpt.uCode;
            cmd.Parameters.Add("in_uname", OracleDbType.Varchar2, 10).Value = setProdOpt.uName;

            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "98";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/setProdOption : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 상품별 연결 옵션 조회
        /// </summary>
        /// <remarks>
        /// shopCd [가맹점 코드] <br />
        /// prodCd [상품 코드] <br />
        /// </remarks>
        [HttpGet("getProdOption")]
        public async Task<IActionResult> GetProdOption(string shopCd, string prodCd)
        {
            string? Rcode = string.Empty;
            string? Rmsg = string.Empty;

            List<GetProdOption> prodOption = new();

            using OracleConnection conn = new(Utils.oracleConnectString);

            using OracleCommand cmd = new()
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_LINK_OPTION_LIST",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shopCd;
            cmd.Parameters.Add("in_prod_cd", OracleDbType.Int32).Value = prodCd;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    GetProdOption o = new()
                    {
                        prodOptGrpCd = rd["PROD_OPTION_GROUP_CD"].ToString(),
                        optGrpCd = rd["OPTION_GROUP_CD"].ToString(),
                        OptGrpName = rd["OPTION_GROUP_NAME"].ToString(),
                        prodCd = rd["PROD_CODE"].ToString(),
                        sortNo = rd["SORT_NO"].ToString(),
                        optNames = rd["OPTION_NAMES"].ToString()

                    };

                    prodOption.Add(o);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Prod/getProdOption : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = prodOption });
        }

        /// <summary>
        /// 상품 옵션 연결 해제
        /// </summary>
        /// <remarks>
        /// shopCd [가맹점 코드] <br />
        /// prodCd [상품 코드] <br />
        /// optGrpCd [옵션 그룹 코드] <br />
        /// prodOptGrpCd [상품옵션 연결 코드] <br />
        /// </remarks>
        [HttpPut("deleteProdOption")]
        public async Task<IActionResult> DeleteProdOption(DeleteProdOption delProdOpt)
        {
            string? Rcode = string.Empty;
            string? Rmsg = string.Empty;


            using OracleConnection conn = new(Utils.oracleConnectString);

            using OracleCommand cmd = new()
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.DELETE_PROD_OPTION",
            };


            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = delProdOpt.shopCd;
            cmd.Parameters.Add("in_prod_cd", OracleDbType.Int32).Value = delProdOpt.prodCd;
            cmd.Parameters.Add("in_option_group_cd", OracleDbType.Int32).Value = delProdOpt.optGrpCd;
            cmd.Parameters.Add("in_prod_opt_grp_cd", OracleDbType.Int32).Value = delProdOpt.prodOptGrpCd;
            cmd.Parameters.Add("in_ucode", OracleDbType.Varchar2, 10).Value = delProdOpt.uCode;
            cmd.Parameters.Add("in_uname", OracleDbType.Varchar2, 10).Value = delProdOpt.uName;

            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Prod/deleteProdOption : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion[상품 옵션그룹 연결 관리]

        #region[상품 옵션그룹 관리]
        /// <summary>
        /// 상품 옵션그룹 목록조회
        /// </summary>
        /// <remarks>
        /// addYn : 추가상품여부(Y/N)
        /// </remarks>
        [HttpGet("Ogroup")]
        public async Task<IActionResult> getOgroupList(string shopCd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<ProdOGroup> optionGroups = new List<ProdOGroup>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_PROD_OGROUP_LIST",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = shopCd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {

                    ProdOGroup s = new ProdOGroup
                    {
                        optionGroupCd = rd["OPTION_GROUP_CD"].ToString(),
                        optionGroupName = rd["OPTION_GROUP_NAME"].ToString(),
                        minCount = rd["MIN_COUNT"].ToString(),
                        maxCount = rd["MULTI_COUNT"].ToString(),
                        addYn = rd["ADD_YN"].ToString(),
                        useGbn = rd["USE_GBN"].ToString(),
                        optionNames = rd["OPTION_NAMES"].ToString(),
                    };

                    optionGroups.Add(s);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/Ogroup : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = optionGroups });
        }

        /// <summary>
        /// 상품 옵션그룹 상세조회
        /// </summary>
        /// <remarks>
        /// addYn : 추가상품여부(Y/N)
        /// </remarks>
        [HttpGet("Ogroup/{option_group_cd}")]
        public async Task<IActionResult> getOgroup(string option_group_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_PROD_OGROUP_DETAIL",
            };

            cmd.Parameters.Add("in_group_cd", OracleDbType.Int32).Value = option_group_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            ProdOGroupDetail menuOption = new ProdOGroupDetail();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                menuOption.optionGroupCd = rd["OPTION_GROUP_CD"].ToString();
                menuOption.optionGroupName = rd["NAME"].ToString();
                menuOption.minCount = rd["MIN_COUNT"].ToString();
                menuOption.maxCount = rd["MULTI_COUNT"].ToString();
                menuOption.addYn = rd["ADD_YN"].ToString();
                menuOption.useGbn = rd["USE_GBN"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/Ogroup/{option_group_cd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = menuOption });
        }

        /// <summary>
        /// 상품 옵션그룹 등록
        /// </summary>
        /// <remarks>
        /// shopCd 가맹점코드 <br/>
        /// group_name 옵션그룹명 <br/>
        /// minCount 최소선택개수 : 1 이상 필수선택/ 0 선택 <br/>
        /// maxCount 최대선택개수 : 2이상 다중선택/ 1 택일 <br/>
        /// useGbn 사용여부(Y/N) <br/>
        /// <br/>
        /// *현재 2가지 세팅만 가능<br/>
        /// 필수옵션 : 최소 1, 최대 1, 추가상품여부 N <br/>
        /// 추가상품 : 최소 0, 최대 999, 추가상품여부 Y <br/>
        /// </remarks>
        [HttpPost("Ogroup")]
        public async Task<IActionResult> postOgroup(ProdOGroupPost menuOptionGroup)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.ADD_PROD_OGROUP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = menuOptionGroup.shopCd;
            cmd.Parameters.Add("in_group_name", OracleDbType.Varchar2, 100).Value = menuOptionGroup.optionGroupName;
            cmd.Parameters.Add("in_min_count", OracleDbType.Int32).Value = menuOptionGroup.minCount;
            cmd.Parameters.Add("in_max_count", OracleDbType.Int32).Value = menuOptionGroup.maxCount;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = menuOptionGroup.useGbn;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = menuOptionGroup.insUcode;
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 200).Value = menuOptionGroup.insName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/Ogroup : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 상품 옵션그룹 수정
        /// </summary>
        /// <remarks>
        /// optionGroupCd 옵션그룹코드 <br/>
        /// group_name 옵션그룹명 <br/>
        /// minCount 최소선택개수 : 1 이상 필수선택/ 0 선택 <br/>
        /// maxCount 최대선택개수 : 2이상 다중선택/ 1 택일 <br/>
        /// useGbn 사용여부(Y/N) <br/>
        /// <br/>
        /// *현재 2가지 세팅만 가능<br/>
        /// 필수옵션 : 최소 1, 최대 1, 추가상품여부 N <br/>
        /// 추가상품 : 최소 0, 최대 999, 추가상품여부 Y <br/>
        /// 
        /// </remarks>
        [HttpPut("Ogroup")]
        public async Task<IActionResult> putOgroup(ProdOGroupPut menuOptionGroup)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.UPDATE_PROD_OGROUP",
            };

            cmd.Parameters.Add("in_group_cd", OracleDbType.Int32).Value = menuOptionGroup.optionGroupCd;
            cmd.Parameters.Add("in_group_name", OracleDbType.Varchar2, 100).Value = menuOptionGroup.optionGroupName;
            cmd.Parameters.Add("in_min_count", OracleDbType.Varchar2, 500).Value = menuOptionGroup.minCount;
            cmd.Parameters.Add("in_max_count", OracleDbType.Varchar2, 500).Value = menuOptionGroup.maxCount;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = menuOptionGroup.useGbn;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = menuOptionGroup.modUcode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 200).Value = menuOptionGroup.modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/Ogroup : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 상품 옵션그룹 삭제
        /// </summary>
        /// <remarks>
        /// </remarks>
        [HttpDelete("Ogroup/{option_group_cd}")]
        public async Task<IActionResult> deleteOgroup(string option_group_cd, string modUcode, string modName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.DELETE_PROD_OGROUP",
            };

            cmd.Parameters.Add("in_option_group_cd", OracleDbType.Int32).Value = option_group_cd;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = modUcode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 200).Value = modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/Ogroup/{option_group_cd} : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 상품 옵션그룹 복사
        /// </summary>
        [HttpPost("Ogroup/copy")]
        public async Task<IActionResult> copyOgroup(string shop_cd, string option_group_cd, string ins_ucode, string ins_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.COPY_OGROUP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_option_group_cd", OracleDbType.Varchar2, 10).Value = option_group_cd;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = ins_ucode;
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 200).Value = ins_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/Ogroup/copy : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion[상품 옵션그룹 관리]

        #region[상품 옵션 관리]
        /// <summary>
        /// 상품 옵션 목록조회
        /// </summary>
        [HttpGet("Option")]
        public async Task<IActionResult> getOptionList(string option_group_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<ProdOption> optionList = new List<ProdOption>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_PROD_OPTION_LIST",
            };

            cmd.Parameters.Add("in_option_group_cd", OracleDbType.Int32).Value = option_group_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ProdOption m = new ProdOption
                    {
                        optionCd = rd["OPTION_CD"].ToString(),
                        name = rd["NAME"].ToString(),
                        memo = rd["OPTION_MEMO"].ToString(),
                        cost = rd["OCOST"].ToString(),
                        useGbn = rd["USE_GBN"].ToString(),
                        noFlag = rd["O_NO_FLAG"].ToString(),
                    };

                    optionList.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/Option : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = optionList });
        }

        /// <summary>
        /// 상품 옵션 상세조회
        /// </summary>
        [HttpGet("Option/{option_cd}")]
        public async Task<IActionResult> getOption(string option_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_PROD_OPTION_DETAIL",
            };

            cmd.Parameters.Add("in_option_cd", OracleDbType.Int32).Value = option_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            ProdOptionDetail menuOption = new ProdOptionDetail();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                menuOption.optionGroupCd = rd["OPTION_GROUP_CD"].ToString();
                menuOption.optionCd = rd["OPTION_CD"].ToString();
                menuOption.optionName = rd["NAME"].ToString();
                menuOption.optionMemo = rd["OPTION_MEMO"].ToString();
                menuOption.cost = rd["OCOST"].ToString();
                menuOption.useGbn = rd["USE_GBN"].ToString();
                menuOption.noFlag = rd["O_NO_FLAG"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/Option/{option_cd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = menuOption });
        }

        /// <summary>
        /// 상품 옵션 등록
        /// </summary>
        /// <remarks>
        /// shopCd 가맹점코드 <br/>
        /// optionGroupCd 옵션그룹코드 <br/>
        /// optionName 옵션명 <br/>
        /// cost 옵션금액 <br/>
        /// useGbn 사용여부(Y/N) <br/>
        /// noFlag 품절여부(Y/N) <br/>
        /// </remarks>
        [HttpPost("Option")]
        public async Task<IActionResult> postOption(ProdOptionPost menuOption)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.ADD_PROD_OPTION",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = menuOption.shopCd;
            cmd.Parameters.Add("in_group_cd", OracleDbType.Int32).Value = menuOption.optionGroupCd;
            cmd.Parameters.Add("in_option_name", OracleDbType.Varchar2, 100).Value = menuOption.optionName;
            cmd.Parameters.Add("in_option_memo", OracleDbType.Varchar2, 500).Value = menuOption.optionMemo;
            cmd.Parameters.Add("in_cost", OracleDbType.Int32).Value = menuOption.cost;
            cmd.Parameters.Add("in_use_Gbn", OracleDbType.Varchar2, 1).Value = menuOption.useGbn;
            cmd.Parameters.Add("in_no_flag", OracleDbType.Varchar2, 1).Value = menuOption.noFlag;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = menuOption.insUcode;
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 300).Value = menuOption.insName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/Option : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 상품 옵션 수정
        /// </summary>
        /// <remarks>
        /// optionCd 옵션코드 <br/>
        /// optionName 옵션명 <br/>
        /// cost 옵션금액 <br/>
        /// useGbn 사용여부(Y/N) <br/>
        /// noFlag 품절여부(Y/N) <br/>
        /// </remarks>
        [HttpPut("Option")]
        public async Task<IActionResult> putOption(ProdOptionPut menuOption)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.UPDATE_PROD_OPTION",
            };

            cmd.Parameters.Add("in_option_cd", OracleDbType.Int32).Value = menuOption.optionCd;
            cmd.Parameters.Add("in_option_name", OracleDbType.Varchar2, 100).Value = menuOption.optionName;
            cmd.Parameters.Add("in_option_memo", OracleDbType.Varchar2, 500).Value = menuOption.optionMemo;
            cmd.Parameters.Add("in_cost", OracleDbType.Int32).Value = menuOption.cost;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = menuOption.useGbn;
            cmd.Parameters.Add("in_no_flag", OracleDbType.Varchar2, 1).Value = menuOption.noFlag;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = menuOption.modUcode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 300).Value = menuOption.modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/Option : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 상품 옵션 삭제
        /// </summary>
        /// <remarks>
        /// group_cd 옵션그룹코드 <br/>
        /// option_cd 옵션코드 <br/>
        /// </remarks>
        [HttpDelete("Option")]
        public async Task<IActionResult> deleteOption(string group_cd, string option_cd, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.DELETE_PROD_OPTION",
            };

            cmd.Parameters.Add("in_group_cd", OracleDbType.Int32).Value = group_cd;
            cmd.Parameters.Add("in_option_cd", OracleDbType.Int32).Value = option_cd;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 300).Value = mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Prod/Option : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        //메뉴옵션 변경이력/ 상품관련 변경이력 하나의 프로시저로 조회하게 만들기
        [HttpGet("history/{shop_cd}")]
        private async Task<IActionResult> getOGroupHistory(string shop_cd, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT *
                                FROM (select ROWNUM as NO, T1.*
                                from(select mod_time, mod_desc from menu_option_list_log
                                where shop_cd = :shop_cd
                                order by logno desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2
                                WHERE ((:in_page - 1) * :in_rows) < NO
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = items.Count.ToString(), data = items });
        }
        #endregion[상품 옵션 관리]

        #region[변경이력]
        /// <summary>
        /// 상품 옵션/옵션그룹 변경 이력 조회
        /// </summary>
        /// <remarks>
        /// *** optGrpCd 또는 optionCd 둘 중 하나만 넣어도 조회 가능(둘 다 들어와도 상관은 없습니다.) <br />
        /// optGrpCd [옵션 그룹 코드] <br />
        /// optionCd [옵션 코드] <br />
        /// </remarks>
        [HttpGet("getOptionHist")]
        public async Task<IActionResult> GetOptionHist(string optGrpCd, string optionCd)
        {
            string? Rcode = string.Empty;
            string? Rmsg = string.Empty;

            List<OptionHist> optionHist = new();

            using OracleConnection conn = new(Utils.oracleConnectString);

            using OracleCommand cmd = new()
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_PROD_OPTION_HIST",
            };

            cmd.Parameters.Add("in_option_group_cd", OracleDbType.Int32).Value = optGrpCd;
            cmd.Parameters.Add("in_option_cd", OracleDbType.Int32).Value = optionCd;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    OptionHist o = new()
                    {
                        seq = rd["SEQ"].ToString(),
                        optGrpCd = rd["OPTION_GROUP_CD"].ToString(),
                        optionCd = rd["OPTION_CD"].ToString(),
                        histGbn = rd["HIST_GBN"].ToString(),
                        histDate = rd["HIST_DATE"].ToString(),
                        memo = rd["MEMO"].ToString()

                    };

                    optionHist.Add(o);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Product/getOptionHist : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = optionHist });
        }

        /// <summary>
        /// 상품 변경이력
        /// </summary>
        /// <remarks>
        /// prod_code : 상품코드(필수) <br/>
        /// hist_gbn : 변경구분: 빈값 전체, 1 상품, 2 옵션그룹 연결, 3 카테고리연결, 4 테마연결 <br/> 
        /// </remarks>
        [HttpGet("getProdHist")]
        public async Task<IActionResult> getProdHist(string prod_code, string hist_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/Prod/getProdHist : Get";

            List<Hist> itmes = new List<Hist>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_PROD.GET_PROD_HIST",
            };

            cmd.Parameters.Add("in_prod_code", OracleDbType.Int32).Value = prod_code;
            cmd.Parameters.Add("in_hist_gbn", OracleDbType.Varchar2, 1).Value = hist_gbn;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    Hist item = new Hist
                    {
                        seq = rd["seq"].ToString(),
                        hist_date = rd["hist_date"].ToString(),
                        hist_gbn = rd["hist_gbn"].ToString(),
                        memo = rd["memo"].ToString(),
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = itmes });
        }
        #endregion[변경이력]

    }
}
