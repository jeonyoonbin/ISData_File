﻿using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Dapper;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class AgentController : ControllerBase
    {
        private readonly ILogger<AgentController> _logger;

        public AgentController(ILogger<AgentController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> Get(int mCode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<AgentList> agents = new List<AgentList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_AGENT.GET_AGENT_LIST",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mCode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    AgentList m = new AgentList
                    {
                        ccCode = rd["CCCODE"].ToString(),
                        ccName = rd["CCNAME"].ToString(),
                        cLevel = rd["CLEVEL"].ToString(),
                        ddd = rd["DDD"].ToString(),
                        telNo = rd["TELNO"].ToString(),
                        faxNo = rd["FAXNO"].ToString(),
                        regNo = rd["REG_NO"].ToString(),
                        useGbn = rd["USE_GBN"].ToString(),
                        remainAmt = rd["REMAIN_AMT"].ToString(),
                        addr = rd["ADDR"].ToString(),
                        owner = rd["OWNER"].ToString()
                    };

                    agents.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Agent : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = agents });
        }





        [HttpGet("{cccode}")]
        public async Task<IActionResult> Get(string cccode, string ucode)
        {
            string Rposition = "/Agent/cccode : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_AGENT.GET_AGENT",
            };

            //OracleParameter op = new OracleParameter();
            //op.OracleDbType = OracleDbType.RefCursor;
            //op.Direction = ParameterDirection.Output;

            cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = cccode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            Agent agent = new Agent();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                agent.ccCode = rd["CCCODE"].ToString();
                agent.ccName = rd["CCNAME"].ToString();
                agent.cLevel = rd["CLEVEL"].ToString();
                agent.useGbn = rd["USE_GBN"].ToString();
                agent.remainAmt = rd["REMAIN_AMT"].ToString();
                agent.ddd = rd["DDD"].ToString();
                agent.telNo = rd["TELNO"].ToString();
                agent.faxNo = rd["FAXNO"].ToString();
                agent.owner = rd["OWNER"].ToString();
                agent.mobile = rd["MOBILE"].ToString();
                agent.zipCode = rd["ZIP_CODE"].ToString();
                agent.addr1 = rd["ADDR1"].ToString();
                agent.addr2 = rd["ADDR2"].ToString();
                agent.email = rd["EMAIL"].ToString();
                agent.bussType = rd["BUSS_TYPE"].ToString();
                agent.bussCon = rd["BUSS_CON"].ToString();
                agent.regNo = rd["REG_NO"].ToString();
                agent.bankCode = rd["BANKCODE"].ToString();
                agent.accountNo = rd["ACCOUNT_NO"].ToString();
                agent.accOwner = rd["ACC_OWNER"].ToString();
                agent.insert_Date = rd["ISRT_DT"].ToString();
                agent.closed_Date = rd["UNUSE_DT"].ToString();
                agent.memo = rd["MEMO"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

                //조회 로그 기록
                await Utils.setPrivacyLog(ucode, "3", "10", agent.ccName + " - 이름, 전화번호, 주소, 계좌번호", Rposition);

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = agent });
        }

        [HttpPost]
        public async Task<IActionResult> Post(Agent agent)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_AGENT.SET_AGENT",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = agent.mCode;
            cmd.Parameters.Add("in_cccode", OracleDbType.Int32).Value = agent.ccCode;
            cmd.Parameters.Add("in_ccname", OracleDbType.Varchar2, 50).Value = agent.ccName;
            cmd.Parameters.Add("in_clevel", OracleDbType.Varchar2, 1).Value = agent.cLevel;
            cmd.Parameters.Add("in_use_gbn", OracleDbType.Varchar2, 1).Value = agent.useGbn;
            cmd.Parameters.Add("in_ddd", OracleDbType.Varchar2, 4).Value = agent.ddd;
            cmd.Parameters.Add("in_telno", OracleDbType.Varchar2, 20).Value = agent.telNo;
            cmd.Parameters.Add("in_faxno", OracleDbType.Varchar2, 20).Value = agent.faxNo;
            cmd.Parameters.Add("in_owner", OracleDbType.Varchar2, 20).Value = agent.owner;
            cmd.Parameters.Add("in_mobile", OracleDbType.Varchar2, 20).Value = agent.mobile;
            cmd.Parameters.Add("in_zip_code", OracleDbType.Varchar2, 6).Value = agent.zipCode;
            cmd.Parameters.Add("in_addr1", OracleDbType.Varchar2, 40).Value = agent.addr1;
            cmd.Parameters.Add("in_addr2", OracleDbType.Varchar2, 60).Value = agent.addr2;
            cmd.Parameters.Add("in_email", OracleDbType.Varchar2, 40).Value = agent.email;
            cmd.Parameters.Add("in_buss_type", OracleDbType.Varchar2, 20).Value = agent.bussType;
            cmd.Parameters.Add("in_buss_con", OracleDbType.Varchar2, 20).Value = agent.bussCon;
            cmd.Parameters.Add("in_reg_no", OracleDbType.Varchar2, 10).Value = agent.regNo;
            cmd.Parameters.Add("in_bankcode", OracleDbType.Varchar2, 2).Value = agent.bankCode;
            cmd.Parameters.Add("in_account_no", OracleDbType.Varchar2, 20).Value = agent.accountNo;
            cmd.Parameters.Add("in_acc_owner", OracleDbType.Varchar2, 20).Value = agent.accOwner;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 50).Value = agent.memo;
            cmd.Parameters.Add("in_userCode", OracleDbType.Int32).Value = agent.userCode;
            cmd.Parameters.Add("in_userName", OracleDbType.Varchar2, 50).Value = agent.userName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Agent : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg});
        }
    }
}
