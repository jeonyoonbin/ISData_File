﻿using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ShopDivController : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_ITEM_MST",
            };

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<ShopDiv> shopDiv = new List<ShopDiv>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopDiv b = new ShopDiv
                    {
                        itemCd = rd["ITEM_CD"].ToString(),
                        itemName = rd["ITEM_NAME"].ToString()
                    };

                shopDiv.Add(b);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopDiv/ : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = shopDiv });
        }

        
    }
}
