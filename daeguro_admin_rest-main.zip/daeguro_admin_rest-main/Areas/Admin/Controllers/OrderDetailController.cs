﻿using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [ApiController]
    [Route("admin/[controller]")]
    public class OrderDetailController : ControllerBase
    {
        [HttpGet("{orderNo}")]
        public async Task<IActionResult> Get(string orderNo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<OrderDetailMenu> orderMenu = new List<OrderDetailMenu>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_ADMIN_ORDER.GET_ORDER_DETAIL",
            };

            cmd.Parameters.Add("in_order_no", OracleDbType.Int32).Value = int.Parse(orderNo);
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor_menu", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            OrderDetail orderDetail = new OrderDetail();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    OrderDetailMenu m = new OrderDetailMenu
                    {
                        menuName = rd["MENU_NAME"].ToString(),
                        orderCost = rd["ORDER_COST"].ToString(),
                        orderQty = rd["ORDER_QTY"].ToString(),
                        orderAmt = rd["ORDER_AMT"].ToString(),
                    };

                    orderMenu.Add(m);
                }

                orderDetail.orderDetials = orderMenu;

                await rd.NextResultAsync();

                while (await rd.ReadAsync())
                {
                    orderDetail.deliAmt = rd["DELI_AMT"].ToString();
                    orderDetail.totalAmt = rd["TOT_AMT"].ToString();
                    orderDetail.addr = rd["ADDR"].ToString();
                    orderDetail.status = rd["STATUS"].ToString();
                    orderDetail.payGbn = rd["PAY_GBN"].ToString();
                    orderDetail.shopConfirmDate = rd["SHOP_CONFIRM_DT"].ToString();
                    orderDetail.orderTime = rd["ORDER_TIME"].ToString();
                    orderDetail.deliDate = rd["DELI_DT"].ToString();
                    orderDetail.memo = rd["MEMO"].ToString();
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                Utils.SaveError("admin/OrderDetail/orderNo : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = orderDetail });
        }
    }
}
