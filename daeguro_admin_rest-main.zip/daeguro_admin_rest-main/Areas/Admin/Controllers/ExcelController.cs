﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ExcelController : ControllerBase
    {
        #region[대구로 통계(통합)]

        #region[가맹점]

        // 일자별 구별 가맹점 입점현황
        /// <summary>
        /// 엑셀통계 - 군구별 가맹점(기간조건:OPEN_DT 입점일시) -*엑셀 컨트롤러로 이동
        /// </summary>
        [HttpGet("getGunguShop")]
        public async Task<IActionResult> getGunguShop(int divKey, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            string sDiv = string.Empty;

            //없으면 전체 1: 간편입점 2: 관리앱 신청
            if (string.IsNullOrEmpty(divKey.ToString()) == false)
            {
                switch (divKey)
                {
                    case 1: sDiv = @"AND A.INS_UCODE = '-1' AND A.MEMO = '[간편입점신청]'"; break;
                    case 2: sDiv = @"AND (A.INS_UCODE <> '-1' OR A.MEMO <> '[간편입점신청]')"; break;
                }
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @$"
                                  SELECT TO_CHAR (a.open_dt, 'yyyyMMdd')     AS OPEN_DATE,
                                         decode(b.cccode, 5,'달서구', 6,'수성구',7,'동구',8,'서구', 9,'남구',10,'북구',11,'중구', 86, '달성군')  AS GUNGU_NAME,
                                         COUNT (*)                           AS COUNT
                                    FROM shop_info a, callcenter b
                                   WHERE     a.cccode = b.cccode
                                         AND b.mcode = 2
                                         {sDiv}
                                         AND a.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND TO_CHAR (a.open_dt, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                GROUP BY CUBE (TO_CHAR (a.open_dt, 'yyyyMMdd'),decode(b.cccode, 5,'달서구', 6,'수성구',7,'동구',8,'서구', 9,'남구',10,'북구',11,'중구', 86, '달성군'))
                                ORDER BY OPEN_DATE desc
                ";

                //string sql = @"
                //                  SELECT TO_CHAR (a.open_dt, 'yyyyMMdd')     AS OPEN_DATE,
                //                         a.gungu_name                        AS GUNGU_NAME,
                //                         COUNT (*)                           AS COUNT
                //                    FROM shop_info a, callcenter b
                //                   WHERE     a.cccode = b.cccode
                //                         AND b.mcode = 2
                //                         AND a.gungu_name IS NOT NULL
                //                         AND a.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                //                         AND TO_CHAR (a.open_dt, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                //                GROUP BY CUBE (TO_CHAR (a.open_dt, 'yyyyMMdd'), a.gungu_name)
                //                ORDER BY OPEN_DATE
                //";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        // 일자별 카테고리별 가맹점 입점현황
        /// <summary>
        /// 엑셀 통계 - 카테고리별 가맹점(기간조건:OPEN_DT 입점일) -*엑셀 컨트롤러로 이동
        /// </summary>
        [HttpGet("getItemShop")]
        public async Task<IActionResult> getItemShop(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                SELECT NVL (T1.open_date, T2.open_date)     AS open_date,
                                         NVL (T1.item_name, T2.item_name)     AS item_name,
                                         NVL (T2.cnt, 0)                      AS COUNT
                                    FROM (SELECT w.open_date, x.item_name
                                            FROM (SELECT DISTINCT
                                                         TO_CHAR (a.open_dt, 'yyyyMMdd')     AS open_date
                                                    FROM shop_info a, callcenter b
                                                   WHERE     a.cccode = b.cccode
                                                         AND b.mcode = 2
                                                         AND a.item_cd IS NOT NULL
                                                         AND a.item_cd <> '9000'
                                                         AND a.open_dt >=
                                                             TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                         AND TO_CHAR (a.open_dt, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                 AND :date_end)
                                                 w,
                                                 item_mst x
                                           WHERE x.item_cd <> '9000') T1
                                         FULL OUTER JOIN
                                         (  SELECT TO_CHAR (a.open_dt, 'yyyyMMdd')     AS open_date,
                                                   c.item_name,
                                                   COUNT (*)                           AS cnt
                                              FROM shop_info a, callcenter b, item_mst c
                                             WHERE     a.cccode = b.cccode
                                                   AND b.mcode = 2
                                                   AND a.item_cd = c.item_cd(+)
                                                   AND a.item_cd IS NOT NULL
                                                   AND a.item_cd <> '9000'
                                                   AND a.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                   AND TO_CHAR (a.open_dt, 'yyyyMMdd') BETWEEN :date_begin
                                                                                           AND :date_end
                                          GROUP BY CUBE (TO_CHAR (a.open_dt, 'yyyyMMdd'), c.item_name)) T2
                                             ON T1.OPEN_DATE = T2.OPEN_DATE AND T1.item_name = T2.item_name
                                ORDER BY nvl(open_date,0) desc , item_name
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 엑셀통계 - 메뉴 미등록 가맹점
        /// </summary>
        [HttpGet("getNoMenuShop")]
        public async Task<IActionResult> getNoMenuShop()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                    SELECT a.shop_cd AS 가맹점번호,
                                           a.shop_name AS 가맹점명,
                                           a.telno AS 휴대폰,
                                           a.owner AS 대표명,
                                           a.reg_no AS 사업자번호,
                                           a.gungu_name AS 군구명,
                                           a.operator_name AS 오퍼레이터,
                                           TO_CHAR(a.open_dt, 'yyyyMMdd') AS 등록일
                                      FROM shop_info a,
                                           callcenter b
                                     WHERE a.cccode = b. cccode
                                       AND b.mcode = 2
                                       AND a.open_dt >= to_date ('2021080917', 'YYYYMMDDHH24')
                                       AND SF_SHOP_CHECK_ITEM('2', a.shop_cd) = 'Y'
                                     ORDER BY shop_cd desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 대표이미지 미비 가맹점
        /// </summary>
        [HttpGet("getNoShopImg")]
        public async Task<IActionResult> getNoShopImg()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT a.shop_cd AS 가맹점번호,
                                       a.shop_name AS 가맹점명,
                                       a.telno AS 휴대폰,
                                       a.owner AS 대표명,
                                       a.reg_no AS 사업자번호,
                                       a.salesman_name AS 영업사원,
                                       TO_CHAR(a.open_dt, 'yyyyMMdd') AS 등록일
                                  FROM shop_info a,
                                       callcenter b
                                 WHERE a.cccode = b. cccode
                                   AND b.mcode = 2
                                   AND a.open_dt >= to_date ('2021080917', 'YYYYMMDDHH24')
                                   AND a.shop_image_yn = 'N'
                                 ORDER BY shop_cd desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 첨부파일 미비 가맹점
        /// </summary>
        [HttpGet("getNoFileShop")]
        public async Task<IActionResult> getNoFileShop()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT a.shop_cd AS 가맹점번호,
                                       a.shop_name AS 가맹점명,
                                       a.telno AS 휴대폰,
                                       a.owner AS 대표명,
                                       a.reg_no AS 사업자번호,
                                       decode(a.buss_image_yn, 'Y', 'O', 'N', 'X') AS 사업자등록증,
                                       decode(a.idcard_image_yn, 'Y', 'O', 'N', 'X') AS 신분증,
                                       decode(a.bank_image_yn, 'Y', 'O', 'N', 'X') AS 통장사본,
                                       a.salesman_name AS 영업사원,
                                       TO_CHAR(a.open_dt, 'yyyyMMdd') AS 등록일
                                  FROM shop_info a,
                                       callcenter b
                                 WHERE a.cccode = b. cccode
                                   AND b.mcode = 2
                                   AND a.open_dt >= to_date ('2021080917', 'YYYYMMDDHH24')
                                   AND (a.buss_image_yn = 'N'
                                            OR a.idcard_image_yn = 'N'
                                            OR a.bank_image_yn = 'N')
                                 ORDER BY shop_cd desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 휴점상태 가맹점
        /// </summary>
        [HttpGet("getAbsentShop")]
        public async Task<IActionResult> getAbsentShop()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT a.shop_cd AS 가맹점번호,
                                       a.shop_name AS 가맹점명,
                                       a.telno AS 휴대폰,
                                       a.owner AS 대표명,
                                       a.reg_no AS 사업자번호,
                                       TO_CHAR(a.open_dt, 'yyyyMMdd') AS 등록일
                                  FROM shop_info a,
                                       callcenter b
                                 WHERE a.cccode = b. cccode
                                   AND b.mcode = 2
                                   AND a.absent_yn = 'N'
                                   AND a.open_dt >= to_date ('2021080917', 'YYYYMMDDHH24')
                                 ORDER BY shop_cd desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 앱미승인 가맹점
        /// </summary>
        [HttpGet("getOrderYnShop")]
        public async Task<IActionResult> getOrderYnShop()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT a.shop_cd AS 가맹점번호,
                                       a.shop_name AS 가맹점명,
                                       a.telno AS 휴대폰,
                                       a.owner AS 대표명,
                                       a.reg_no AS 사업자번호,
                                       TO_CHAR(a.open_dt, 'yyyyMMdd') AS 등록일
                                  FROM shop_info a,
                                       callcenter b
                                 WHERE a.cccode = b. cccode
                                   AND b.mcode = 2
                                   AND a.app_order_yn = 'N'
                                   AND a.open_dt >= to_date ('2021080917', 'YYYYMMDDHH24')
                                 ORDER BY shop_cd desc
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 기간별 주문실적( 0, 5, 10, 15, 20, 25, 30, 35, 40 , 45회 이상 )O
        /// </summary>
        [HttpGet("getShopCount")]
        public async Task<IActionResult> getShopCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT 0
                                           DAY_COUNT,
                                       (SELECT COUNT (*)
                                          FROM shop_info w, callcenter x
                                         WHERE     shop_cd NOT IN
                                                       (SELECT DISTINCT shop_cd
                                                          FROM (SELECT cccode,
                                                                       shop_cd,
                                                                       status,
                                                                       cancel_code,
                                                                       test_gbn,
                                                                       order_time
                                                                  FROM dorder
                                                                UNION ALL
                                                                SELECT cccode,
                                                                       shop_cd,
                                                                       status,
                                                                       cancel_code,
                                                                       test_gbn,
                                                                       order_time
                                                                  FROM dorder_past) a
                                                         WHERE a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                               AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                          AND :date_end
                                                               AND a.test_gbn = 'N'
                                                               and a.status not in  ('80','20')
                                                               and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26'))
                                               AND w.cccode = x.cccode
                                               AND x.mcode = 2
                                               AND w.app_order_yn = 'Y'
                                               AND w.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                               AND to_char(w.open_dt,'YYYYMMDD') <= :date_end)
                                           ORDER_COUNT
                                  FROM DUAL
                                UNION ALL
                                    SELECT ROWNUM
                                               DAY_COUNT,
                                           DECODE (ROWNUM,
                                                   1, day1,
                                                   2, day2,
                                                   3, day3,
                                                   4, day4,
                                                   5, day5,
                                                   6, day6,
                                                   7, day7,
                                                   8, day8,
                                                   9, day9,
                                                   10, day10)
                                               order_count
                                      FROM (SELECT SUM (CASE WHEN (cnt BETWEEN 1 AND 5) THEN 1 ELSE 0 END)
                                                       day1,
                                                   SUM (CASE WHEN (cnt BETWEEN 6 AND 10) THEN 1 ELSE 0 END)
                                                       day2,
                                                   SUM (CASE WHEN (cnt BETWEEN 11 AND 15) THEN 1 ELSE 0 END)
                                                       day3,
                                                   SUM (CASE WHEN (cnt BETWEEN 16 AND 20) THEN 1 ELSE 0 END)
                                                       day4,
                                                   SUM (CASE WHEN (cnt BETWEEN 21 AND 25) THEN 1 ELSE 0 END)
                                                       day5,
                                                   SUM (CASE WHEN (cnt BETWEEN 26 AND 30) THEN 1 ELSE 0 END)
                                                       day6,
                                                   SUM (CASE WHEN (cnt BETWEEN 31 AND 35) THEN 1 ELSE 0 END)
                                                       day7,
                                                   SUM (CASE WHEN (cnt BETWEEN 36 AND 40) THEN 1 ELSE 0 END)
                                                       day8,
                                                   SUM (CASE WHEN (cnt BETWEEN 41 AND 45) THEN 1 ELSE 0 END)
                                                       day9,
                                                   SUM (CASE WHEN (cnt > 45) THEN 1 ELSE 0 END)
                                                       day10
                                              FROM (  SELECT shop_cd, COUNT (*) cnt
                                                        FROM (SELECT *
                                                                FROM is_daegu.dorder a, is_daegu.callcenter b
                                                               WHERE     a.cccode = b.cccode
                                                                     AND b.mcode = 2
                                                                     AND a.test_gbn = 'N'
                                                                     and a.status not in  ('80','20')
                                                                     and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                     AND a.order_time >=
                                                                         TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                                AND :date_end
                                                              UNION
                                                              SELECT *
                                                                FROM is_daegu.dorder_past a, is_daegu.callcenter b
                                                               WHERE     a.cccode = b.cccode
                                                                     AND b.mcode = 2
                                                                     AND a.test_gbn = 'N'
                                                                     and a.status not in  ('80','20')
                                                                     and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                     AND a.order_time >=
                                                                         TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                                AND :date_end)
                                                    GROUP BY shop_cd))
                                CONNECT BY LEVEL <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 기간별 주문실적2( 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10회 이상 )O
        /// </summary>
        [HttpGet("getShopCount2")]
        public async Task<IActionResult> getShopCount2(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT 0
                                           DAY_COUNT,
                                       (SELECT COUNT (*)
                                          FROM shop_info w, callcenter x
                                         WHERE     shop_cd NOT IN
                                                       (SELECT DISTINCT shop_cd
                                                          FROM (SELECT cccode,
                                                                       shop_cd,
                                                                       cancel_code,
                                                                       test_gbn,
                                                                       status,
                                                                       order_time
                                                                  FROM dorder
                                                                UNION ALL
                                                                SELECT cccode,
                                                                       shop_cd,
                                                                       cancel_code,
                                                                       test_gbn,
                                                                       status,
                                                                       order_time
                                                                  FROM dorder_past) a
                                                         WHERE a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                               AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                          AND :date_end
                                                               AND a.test_gbn = 'N'
                                                               and a.status not in  ('80','20')
                                                               and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26'))
                                               AND w.cccode = x.cccode
                                               AND x.mcode = 2
                                               AND w.app_order_yn = 'Y'
                                               AND w.open_dt >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                               AND to_char(w.open_dt,'YYYYMMDD') <= :date_end)
                                           ORDER_COUNT
                                  FROM DUAL
                                UNION ALL
                                    SELECT ROWNUM
                                               DAY_COUNT,
                                           DECODE (ROWNUM,
                                                   1, day1,
                                                   2, day2,
                                                   3, day3,
                                                   4, day4,
                                                   5, day5,
                                                   6, day6,
                                                   7, day7,
                                                   8, day8,
                                                   9, day9,
                                                   10, day10)
                                               order_count
                                      FROM (SELECT SUM (CASE WHEN (cnt = 1) THEN 1 ELSE 0 END)
                                                       day1,
                                                   SUM (CASE WHEN (cnt = 2) THEN 1 ELSE 0 END)
                                                       day2,
                                                   SUM (CASE WHEN (cnt = 3) THEN 1 ELSE 0 END)
                                                       day3,
                                                   SUM (CASE WHEN (cnt = 4) THEN 1 ELSE 0 END)
                                                       day4,
                                                   SUM (CASE WHEN (cnt = 5) THEN 1 ELSE 0 END)
                                                       day5,
                                                   SUM (CASE WHEN (cnt = 6) THEN 1 ELSE 0 END)
                                                       day6,
                                                   SUM (CASE WHEN (cnt = 7) THEN 1 ELSE 0 END)
                                                       day7,
                                                   SUM (CASE WHEN (cnt = 8) THEN 1 ELSE 0 END)
                                                       day8,
                                                   SUM (CASE WHEN (cnt = 9) THEN 1 ELSE 0 END)
                                                       day9,
                                                   SUM (CASE WHEN (cnt >= 10) THEN 1 ELSE 0 END)
                                                       day10
                                              FROM (  SELECT shop_cd, COUNT (*) cnt
                                                        FROM (SELECT *
                                                                FROM is_daegu.dorder a, is_daegu.callcenter b
                                                               WHERE     a.cccode = b.cccode
                                                                     AND b.mcode = 2
                                                                     AND a.test_gbn = 'N'
                                                                     and a.status not in  ('80','20')
                                                                     and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                     AND a.order_time >=
                                                                         TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                                AND :date_end
                                                              UNION
                                                              SELECT *
                                                                FROM is_daegu.dorder_past a, is_daegu.callcenter b
                                                               WHERE     a.cccode = b.cccode
                                                                     AND b.mcode = 2
                                                                     AND a.test_gbn = 'N'
                                                                     and a.status not in  ('80','20')
                                                                     and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                     AND a.order_time >=
                                                                         TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                                                                                                                AND :date_end)
                                                    GROUP BY shop_cd))
                                CONNECT BY LEVEL <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 취소율 순위O
        /// </summary>
        [HttpGet("getShopCancelOrderRank")]
        public async Task<IActionResult> getShopCancelOrderRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @$"
                                 SELECT rownum, a.*
                                    FROM (  SELECT a.* , round(a.취소/a.총주문,2)*100 as 취소율
                                            FROM (
                                                select shop_cd, shop_name,
                                                        COUNT(shop_cd) AS 총주문,
                                                        COUNT(CASE WHEN status = '40' then 1 end) AS 완료,
                                                        COUNT(CASE WHEN status = '50' then 1 end) AS 취소
                                                FROM (select a.STATUS, c.shop_cd, c.shop_name FROM dorder a, callcenter b, shop_info c
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        and a.status not in  ('80','20')
                                                        and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                        AND a.shop_cd = c.shop_cd
                                                      UNION ALL
                                                      select a.STATUS, c.shop_cd, c.shop_name FROM dorder_past a, callcenter b, shop_info c
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        and a.status not in  ('80','20')
                                                        and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                        AND a.shop_cd = c.shop_cd )
                                                group by shop_cd, shop_name)a 
                                            order by round(a.취소/a.총주문,2)*100 desc, a.취소 desc) a
                                        where a.취소율 >= 50
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }

        /// <summary>
        /// 엑셀통계 - 시간지연 취소율 순위O
        /// </summary>
        [HttpGet("getShopDelayCancelOrderRank")]
        public async Task<IActionResult> getShopDelayCancelOrderRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @$"
                                 SELECT to_char(b.open_dt,'YYYYMMDD') as open_dt , b.shop_name, a.*
                                    FROM (  SELECT a.* , round(a.시간지연취소/a.총주문,2)*100 as 취소율
                                            FROM (
                                                select shop_cd,
                                                        COUNT(shop_cd) AS 총주문,
                                                        COUNT(CASE WHEN status = '40' then 1 end) AS 완료,
                                                        COUNT(CASE WHEN status = '50' then 1 end) AS 취소,
                                                        COUNT(CASE WHEN status = '50' and cancel_code = '11' then 1 end) AS 시간지연취소
                                                FROM (select a.STATUS, a.shop_cd, a.cancel_code FROM dorder a, callcenter b
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        and a.status not in  ('80','20')
                                                        and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                      UNION ALL
                                                      select a.STATUS, a.shop_cd, a.cancel_code FROM dorder_past a, callcenter b
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        and a.status not in  ('80','20')
                                                        and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26'))
                                                group by shop_cd)a 
                                            order by round(a.시간지연취소/a.총주문,2)*100 desc, a.시간지연취소 desc) a, shop_info b
                                        where a.shop_cd = b.shop_cd
                                        and a.취소율 >= 50
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }


        /// <summary>
        /// 엑셀통계 - 가맹점취소 취소율 순위O
        /// </summary>
        [HttpGet("getShopOwnerCancelOrderRank")]
        public async Task<IActionResult> getShopOwnerCancelOrderRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @$"
                                 SELECT to_char(b.open_dt,'YYYYMMDD') as open_dt , b.shop_name, a.*
                                    FROM (  SELECT a.* , round(a.가맹점취소/a.총주문,2)*100 as 취소율
                                            FROM (
                                                select shop_cd,
                                                        COUNT(shop_cd) AS 총주문,
                                                        COUNT(CASE WHEN status = '40' then 1 end) AS 완료,
                                                        COUNT(CASE WHEN status = '50' then 1 end) AS 취소,
                                                        COUNT(CASE WHEN status = '50' and cancel_code = '20' then 1 end) AS 가맹점취소
                                                FROM (select a.STATUS, a.shop_cd, a.cancel_code FROM dorder a, callcenter b
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        and a.status not in  ('80','20')
                                                        and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                      UNION ALL
                                                      select a.STATUS, a.shop_cd, a.cancel_code FROM dorder_past a, callcenter b
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        and a.status not in  ('80','20')
                                                        and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26'))
                                                group by shop_cd)a 
                                            order by round(a.가맹점취소/a.총주문,2)*100 desc, a.가맹점취소 desc) a, shop_info b
                                        where a.shop_cd = b.shop_cd
                                        and a.취소율 >= 50
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }

        /// <summary>
        /// 엑셀통계 - 가맹점 순위(상위, 하위)O
        /// </summary>
        /// <remarks>
        /// div: 1 완료수 많은/ 2 완료기준 매출액 많은/3 취소수 많은/ 4 완료기준 매출액 적은 <br/>
        /// 매출액 기준(TOT_AMT : 메뉴주문금액 + 배달팁)
        /// </remarks>
        [HttpGet("getShopRank10")]
        public async Task<IActionResult> getShopRank10(string div, string cccode, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("div", div);
                param.Add("cccode", cccode);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string desc = (div == "4") ? "" : "desc";

                string sql = @$"
                                select rownum rnum, a.*
                                from(select case when :div in (2,4) then sum(a.tot_amt) else count(a.order_no) end as 값, b.shop_name 가맹점명,  b.shop_cd
                                from (select * from dorder union all select * from dorder_past) a, shop_info b, callcenter c
                                where a.shop_cd = b.shop_cd
                                and b.cccode = c.cccode
                                and c.mcode = 2
                                and b.cccode like case when :cccode is null then '%' else :cccode end  
                                and b.app_order_yn = 'Y'
                                and a.status = case when :div = 3 then '50' else '40' end
                                AND a.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND a.TEST_GBN = 'N'
                                and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                and a.order_time between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                group by b.shop_name, b.shop_cd
                                order by case when :div in (2,4) then sum(a.tot_amt) else count(a.order_no) end {desc} ) a
                                where rownum <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }
        #endregion

        #region[주문]
        /// <summary>
        /// 엑셀전용 - 전체주문(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        [HttpGet("getTotalOrderInfo")]
        public async Task<IActionResult> getTotalOrderInfo(string gungu, string kind_shop_yn, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("kind_shop_yn", kind_shop_yn);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string keywordSql = string.Empty;

                if (string.IsNullOrEmpty(gungu) == false)
                {
                    keywordSql = $@"AND A.DEST_GUNGU = '{gungu}'";
                }

                string sql = string.Empty;

                if (kind_shop_yn == "Y")
                {
                    sql = $@"select t1.*,  TRUNC (t1.OK_CNT / t1.CNT * 100, 1)     COMP_PER, null reser_in_cnt
                             from
                                (SELECT TO_CHAR (z.ORDER_TIME, 'yyyyMMdd')
                                            ORDER_DATE,
                                        COUNT (z.ORDER_NO)
                                            AS CNT,
                                        SUM (z.TOT_AMT)
                                            AS AMT,
                                        SUM (CASE WHEN z.STATUS = '40' THEN 1 ELSE 0 END)
                                            AS OK_CNT,
                                        SUM (CASE WHEN z.STATUS = '40' THEN z.TOT_AMT ELSE 0 END)
                                            AS OK_AMT,
                                        SUM (CASE WHEN z.STATUS = '50' THEN 1 ELSE 0 END)
                                            AS CANCEL_CNT,
                                        SUM (CASE WHEN z.STATUS = '50' THEN z.TOT_AMT ELSE 0 END)
                                            AS CANCEL_AMT,
                                        SUM (CASE WHEN z.STATUS = '30' THEN 1 ELSE 0 END)
                                            AS SHOP_CONFIRM,
                                        SUM (CASE WHEN z.STATUS = '40' AND NVL(z.DISC_AMT,0) = 0 AND NVL(z.MILEAGE_USE_AMT,0) = 0  THEN 1 ELSE 0 END)
                                            AS NO_DISCOUNT_OK,
                                            SUM (CASE WHEN z.STATUS = '50' AND NVL(z.DISC_AMT,0) = 0 AND NVL(z.MILEAGE_USE_AMT,0) = 0  THEN 1 ELSE 0 END)
                                            AS NO_DISCOUNT_CANCEL
                                FROM (  SELECT a.*
                                        FROM DORDER A,
                                            CALLCENTER C,
                                            SHOP_INFO D,
                                            dorder_disc_detail e
                                        WHERE     A.TEST_GBN = 'N'
                                            AND A.CCCODE = C.CCCODE
                                            AND C.MCODE = 2
                                            and a.order_no = e.order_no
                                            and e.disc_code = '40'
                                            and a.status not in  ('80','20')
                                            and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                            AND A.SHOP_CD = D.SHOP_CD
                                            AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                            AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                            {keywordSql}
                                        union all
                                        SELECT a.*
                                        FROM DORDER_PAST A,
                                            CALLCENTER C,
                                            SHOP_INFO D,
                                            dorder_disc_detail e
                                        WHERE     A.TEST_GBN = 'N'
                                            AND A.CCCODE = C.CCCODE
                                            AND C.MCODE = 2
                                            and a.order_no = e.order_no
                                            and e.disc_code = '40'
                                            and a.status not in  ('80','20')
                                            and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                            AND A.SHOP_CD = D.SHOP_CD
                                            AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                            AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                            {keywordSql}
                                                ) Z
                                GROUP BY TO_CHAR (Z.ORDER_TIME, 'yyyyMMdd')) t1
                            ORDER BY t1.ORDER_DATE DESC   ";
                }
                else
                {
                    sql = $@"
                            select t1.*,  TRUNC (t1.OK_CNT / t1.CNT * 100, 1)     COMP_PER, case when r.reser_in_cnt is null then 0 else r.reser_in_cnt end reser_in_cnt
                            from
                                (SELECT TO_CHAR (z.ORDER_TIME, 'yyyyMMdd')
                                            ORDER_DATE,
                                        COUNT (z.ORDER_NO)
                                            AS CNT,
                                        SUM (z.TOT_AMT)
                                            AS AMT,
                                        SUM (CASE WHEN z.STATUS = '40' THEN 1 ELSE 0 END)
                                            AS OK_CNT,
                                        SUM (CASE WHEN z.STATUS = '40' THEN z.TOT_AMT ELSE 0 END)
                                            AS OK_AMT,
                                        SUM (CASE WHEN z.STATUS = '50' THEN 1 ELSE 0 END)
                                            AS CANCEL_CNT,
                                        SUM (CASE WHEN z.STATUS = '50' THEN z.TOT_AMT ELSE 0 END)
                                            AS CANCEL_AMT,
                                        SUM (CASE WHEN z.STATUS = '30' THEN 1 ELSE 0 END)
                                            AS SHOP_CONFIRM,
                                        SUM (CASE WHEN z.STATUS = '40' AND NVL(z.DISC_AMT,0) = 0 AND NVL(z.MILEAGE_USE_AMT,0) = 0  THEN 1 ELSE 0 END)
                                            AS NO_DISCOUNT_OK,
                                            SUM (CASE WHEN z.STATUS = '50' AND NVL(z.DISC_AMT,0) = 0 AND NVL(z.MILEAGE_USE_AMT,0) = 0  THEN 1 ELSE 0 END)
                                            AS NO_DISCOUNT_CANCEL
                                FROM (  SELECT a.*
                                        FROM DORDER A,
                                            CALLCENTER C,
                                            SHOP_INFO D
                                        WHERE     A.TEST_GBN = 'N'
                                            AND A.CCCODE = C.CCCODE
                                            AND C.MCODE = 2
                                            and a.status not in  ('80','20')
                                            and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                            AND A.SHOP_CD = D.SHOP_CD
                                            AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                            AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                            {keywordSql}
                                        union all
                                        SELECT a.*
                                        FROM DORDER_PAST A,
                                            CALLCENTER C,
                                            SHOP_INFO D
                                        WHERE     A.TEST_GBN = 'N'
                                            AND A.CCCODE = C.CCCODE
                                            AND C.MCODE = 2
                                            and a.status not in  ('80','20')
                                            and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                            AND A.SHOP_CD = D.SHOP_CD
                                            AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                            AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                            {keywordSql}
                                            ) Z
                            GROUP BY TO_CHAR (Z.ORDER_TIME, 'yyyyMMdd')) t1, 
                            (select to_char(a.isrt_date, 'yyyyMMdd') isrt_date, count(*) reser_in_cnt
                            from reser_receipt_order a,
                                    CALLCENTER C,
                                    SHOP_INFO D
                            where a.shop_cd = d.shop_cd
                            and d.cccode = c.cccode
                            and c.mcode = 2
                            and a.isrt_date BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                            group by to_char(a.isrt_date, 'yyyyMMdd')) r
                        where t1.ORDER_DATE = r.isrt_date(+)
                        ORDER BY t1.ORDER_DATE DESC      
                    ";
                }


                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 주문별 통계,엑셀통계 - 일자별 주문취소 사유(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        [HttpGet("getDailyOrderCancelReason")]
        public async Task<IActionResult> getDailyOrderCancelReason(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT TO_CHAR (a.order_time, 'yyyyMMdd')
                                             AS order_date,
                                             c.code_nm as cancel_code,
                                         COUNT (*)
                                             COUNT
                                    FROM (SELECT order_time,
                                                 cancel_code,
                                                 cccode,
                                                 test_gbn,
                                                 status
                                            FROM dorder
                                            where test_gbn = 'N'
                                            AND status = '50'
                                            and cancel_code in ('00','10','11','20','21','22','26')
                                            AND order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                            AND order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                              AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                          UNION ALL
                                          SELECT order_time,
                                                 cancel_code,
                                                 cccode,
                                                 test_gbn,
                                                 status
                                            FROM dorder_past
                                            where test_gbn = 'N'
                                            AND status = '50'
                                            and cancel_code in ('00','10','11','20','21','22','26')
                                            AND order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                            AND order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                              AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')) a,
                                         callcenter b,
                                         etc_code c
                                   WHERE     a.cccode = b.cccode
                                         AND b.mcode = 2
                                         AND c.pgm_group = 'O'
                                         AND c.code_grp = '10'
                                         AND a.cancel_code = c.code
                                GROUP BY TO_CHAR (a.order_time, 'yyyyMMdd'), CUBE (code_nm)
                                ORDER BY order_date DESC
                ";

                //string sql = @"
                //                  SELECT TO_CHAR (a.order_time, 'yyyyMMdd')
                //                             AS order_date,
                //                         DECODE (cancel_code,
                //                                 '00', '사유없음',
                //                                 '10', '고객본인취소',
                //                                 '11', '시간지연',
                //                                 '12', '재접수',
                //                                 '20', '가맹점취소',
                //                                 '21', '배달불가',
                //                                 '22', '메뉴품절',
                //                                 '23', '가맹점휴무',
                //                                 '24', '주소입력오류',
                //                                 '25', '가맹점 정산 접수거부',
                //                                 '26', 'POS서버 응답없음',
                //                                 '30', '결재대기 자동취소',
                //                                 '40', '예약주문 고객 취소',
                //                                 '45', '예약주문 가맹점 취소')
                //                             cancel_code,
                //                         COUNT (*)
                //                             COUNT
                //                    FROM (SELECT order_time,
                //                                 NVL (cancel_code, '00')     AS cancel_code,
                //                                 cccode,
                //                                 test_gbn,
                //                                 status
                //                            FROM dorder
                //                          UNION ALL
                //                          SELECT order_time,
                //                                 NVL (cancel_code, '00')     AS cancel_code,
                //                                 cccode,
                //                                 test_gbn,
                //                                 status
                //                            FROM dorder_past) a,
                //                         callcenter b
                //                   WHERE     a.cccode = b.cccode
                //                         AND b.mcode = 2
                //                         AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                //                         AND a.test_gbn = 'N'
                //                         AND NVL (a.cancel_code, '00') <> '30'
                //                         AND a.status = '50'
                //                         AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin
                //                                                                    AND :date_end
                //                GROUP BY TO_CHAR (a.order_time, 'yyyyMMdd'), CUBE (cancel_code)
                //                ORDER BY order_date DESC
                //";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 주문별 통계 - 카테고리별 주문(기간조건:ORDER_TIME 주문시간)O + (엑셀통계 - 카테고리별 주문O)
        /// </summary>
        [HttpGet("getCategoryOrderCount")]
        public async Task<IActionResult> getCategoryOrderCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                 select b.item_cd,
                                         nvl(a.count,0) count, 
                                         nvl(a.menu_amt,0) menu_amt, 
                                         nvl(a.deli_tip_amt,0) deli_tip_amt, 
                                         nvl(a.disc_use_amt,0) disc_use_amt, 
                                         b.item_name 
                                        from (SELECT item_cd,
                                       COUNT (*) COUNT,
                                       SUM (menu_amt) menu_amt,
                                       SUM (deli_tip_amt) deli_tip_amt,
                                       NVL (SUM (disc_amt), 0) disc_use_amt
                                  FROM (SELECT b.item_cd,
                                               a.menu_amt,
                                               a.deli_tip_amt,
                                               a.disc_amt
                                          FROM dorder a,
                                               shop_info b,
                                               callcenter d
                                         WHERE a.shop_cd = b.shop_cd
                                           AND a.cccode = d.cccode
                                           AND d.mcode = 2
                                           AND b.item_cd IS NOT NULL
                                           AND a.test_gbn = 'N'
                                           and a.status not in  ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                           AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                         UNION ALL
                                SELECT b.item_cd,
                                               a.menu_amt,
                                               a.deli_tip_amt,
                                               a.disc_amt
                                          FROM dorder_past a,
                                               shop_info b,
                                               callcenter d
                                         WHERE a.shop_cd = b.shop_cd
                                           AND a.cccode = d.cccode
                                           AND d.mcode = 2
                                           AND b.item_cd IS NOT NULL
                                           AND a.test_gbn = 'N'
                                           and a.status not in  ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                           AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                 GROUP BY CUBE (item_cd)) a full outer join item_mst b
                                 on b.item_cd = a.item_cd
                                 where nvl(b.item_cd,'0') not in('1030') -- 정육은 사용
                                 order by b.item_cd
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 주문별 통계 - 시간대별 주문(기간조건:ORDER_TIME 주문시간) + (엑셀통계 - 시간대별 주문O)
        /// </summary>
        [HttpGet("getTimeOrderCount")]
        public async Task<IActionResult> getTimeOrderCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  select b.item_cd,
                                        a.hh,
                                        nvl(a.count,0)count,
                                        b.item_name 
                                from(SELECT item_cd, TO_CHAR (order_time, 'HH24') AS HH, COUNT (item_cd) COUNT
                                    FROM (SELECT a.order_time, b.item_cd
                                            FROM dorder a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in  ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                          UNION ALL
                                          SELECT a.order_time, b.item_cd
                                            FROM dorder_past a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in  ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                GROUP BY CUBE (item_cd, TO_CHAR (order_time, 'HH24'))
                                ORDER BY item_cd) a full outer join item_mst b
                                on b.item_cd = a.item_cd
                                where nvl(b.item_cd,'0') not in('1029','1030')
                                order by b.item_cd
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 엑셀통계 - 일자별 결제V2(통합)
        /// </summary>
        /// <remarks>
        /// div 1 주문완료(결제액), 2 배달완료(결제액), 3 완료취소(할인제외X), 4 완료취소(결제액), 5 주문완료(주문금액) <br/>
        /// 기간조건:ORDER_TIME 주문시간/ COMP_DT 완료시간(배달완료)
        /// 결제금액 기준 AMOUNT/ 주문금액 기준 TOT_AMT <br/>
        /// </remarks>
        [HttpGet("getDailyOrderPyaGbnV2")]
        public async Task<IActionResult> getDailyOrderPyaGbnV2(string div, string date_begin, string date_end)
        {
            string sqlDt = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("div", div);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                // 인덱스 문제로 이부분만 다이나믹 쿼리 처리
                if (div == "2")
                {
                    sqlDt = "a.comp_dt";
                }
                else
                {
                    sqlDt = "a.order_time";
                }

                db.Open();

                string sql = @$"
                                  select x.order_date,
                                           x.app_pay_gbn,
                                           x.pay_gbn,
                                           count(*) cnt,
                                           sum(amount) amount 
                                    from (SELECT TO_CHAR ({sqlDt}, 'yyyyMMdd')     AS ORDER_DATE,
                                                 APP_PAY_GBN,
                                                 case when a.pay_gbn = '2' and c.card_point_yn = 'Y' then c.card_point_gbn
                                                      else a.pay_gbn end pay_gbn,
                                                 CASE WHEN :div in (3,5) then TOT_AMT 
                                                      when a.pay_gbn = 'V' then a.voucher_use_amt
                                                      ELSE AMOUNT END AMOUNT
                                            FROM DORDER A, CALLCENTER B, dorder_detail c
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND a.order_no = c.order_no
                                                 AND B.MCODE = 2
                                                 AND TEST_GBN = 'N'
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND STATUS in ('40',case when :div in('3','4') then '50' end)
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND {sqlDt}
                                                                  BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                          UNION ALL
                                          SELECT TO_CHAR ({sqlDt}, 'yyyyMMdd')     AS ORDER_DATE,
                                                 APP_PAY_GBN,
                                                 case when app_pay_gbn = '1' then '1' -- 현금결제의 아이폰 오류데이터('12')를 걸러주기 위함
                                                      when a.pay_gbn = '2' and c.card_point_yn = 'Y' then c.card_point_gbn
                                                      else a.pay_gbn end AS pay_gbn,
                                                 CASE WHEN :div in (3,5) then TOT_AMT 
                                                      when a.pay_gbn = 'V' then a.voucher_use_amt
                                                      ELSE AMOUNT END AMOUNT
                                            FROM DORDER_PAST A, CALLCENTER B, dorder_detail c
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND a.order_no = c.order_no
                                                 AND B.MCODE = 2
                                                 AND TEST_GBN = 'N'
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND STATUS in ('40',case when :div in('3','4') then '50' end)
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND {sqlDt} 
                                                                  BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')) x
                                    group by x.order_date, x.app_pay_gbn, x.pay_gbn
                                    order by x.order_date desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 일자별 연령별 주문수O
        /// </summary>
        /// <remarks>
        /// 엑셀통계 - 일자별 연령별 주문수 겸 대구시 요청자료용 일자별 연령 주문수 
        /// </remarks>
        [HttpGet("getDailyAgeToOrder")]
        public async Task<IActionResult> getDailyAgeToOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT X.ORDER_DATE,
                                        X.YEAR,
                                        X.COUNT,
                                        X.COMP,
                                        X.CANC
                                    FROM (SELECT case when birthday is null then 0
                                                      when birthday < 1 then 1
                                                      when birthday > 9 then 9
                                                      else birthday end || '0대' AS year, COUNT (*) COUNT, 
                                                                COUNT(CASE WHEN STATUS = '40' THEN 1 END) AS COMP, 
                                                                COUNT(CASE WHEN STATUS = '50' THEN 1 END) AS CANC,
                                                                order_date
                                                        FROM (SELECT trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                                                        birthday, STATUS, order_date
                                                            FROM (SELECT cust_code,
                                                                            birthday
                                                                    FROM app_customer
                                                                    UNION ALL
                                                                    SELECT cust_code,
                                                                            birthday
                                                                    FROM app_customer_deleted) a, 
                                                                (select ccode, STATUS, to_char(order_time,'YYYYMMDD') order_date from dorder a, callcenter b
                                                                where a.cccode = b.cccode
                                                                    AND b.mcode = 2
                                                                    AND a.order_time between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                                                    AND a.TEST_GBN = 'N'
                                                                    and a.status not in  ('80','20')
                                                                    and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                union all
                                                                select ccode, STATUS, to_char(order_time,'YYYYMMDD') order_date from dorder_past a, callcenter b
                                                                where a.cccode = b.cccode
                                                                    AND b.mcode = 2
                                                                    AND a.order_time between to_date(case when :date_begin = '20210809' then '20210809170000' else :date_begin || '000000' end
                                                                            , 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                                                    AND a.TEST_GBN = 'N'
                                                                    and a.status not in  ('80','20')
                                                                    and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')) b
                                                            where a.cust_code = b.ccode
                                                            )
                                                GROUP BY case when birthday is null then 0
                                                              when birthday < 1 then 1
                                                              when birthday > 9 then 9
                                                              else birthday end, order_date) X
                                GROUP BY X.ORDER_DATE, X.YEAR, X.COUNT, X.COMP, X.CANC
                                ORDER BY X.ORDER_DATE desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 일자별 주문(완료,최소) 주문일, 상태, 수량, 총음식금액, 총배달팁, 첫주문쿠폰, 재구매쿠폰, 이벤트쿠폰(추가), 마일리지, 행복페이 할인
        /// <summary>
        /// 주문별 통계 - 일자별 완료 및 취소(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        [HttpGet("getDailyOrderCompletedCanceled")]
        public async Task<IActionResult> getDailyOrderCompletedCanceled(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                    SELECT X.ORDER_DATE AS 주문일,
                                           DECODE(X.STATUS, '40', '완료', '50', '취소') AS 상태,
                                           COUNT(X.STATUS) AS 수량,
                                           SUM(X.MENU_AMT) AS 총음식금액,
                                           SUM(X.DELI_TIP_AMT) AS 총배달팁,
                                           --SUM(X.MENU_AMT + X.DELI_TIP_AMT) AS 총금액,
                                           SUM(Y.COUPON_AMT) AS 첫주문쿠폰,
                                           SUM(Z.COUPON_AMT) AS 재구매쿠폰,
                                           SUM(x.coupon - nvl(y.coupon_amt,0) - nvl(z.coupon_amt,0)) AS 이벤트쿠폰,
                                           --SUM(x.shop_coupon_amt) AS 가맹점자체쿠폰,
                                           SUM(X.MILEAGE_USE_AMT) AS 마일리지,
                                           SUM(W.DISC_USE_AMT) AS 행복페이할인,
                                           SUM(x.to_go_disc_amt) AS 포장할인
                                           --SUM(X.DISC_AMT) AS 총할인액,
                                           --SUM(X.TOT_AMT - X.DISC_AMT) AS 결제금액
                                      FROM (SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                   ORDER_NO,
                                                   STATUS,
                                                   MENU_AMT,
                                                   DELI_TIP_AMT,
                                                   MILEAGE_USE_AMT,
                                                   TOT_AMT,
                                                   DISC_AMT,
                                                   to_go_disc_amt,
                                                   (a.coupon_amt + a.coupon_amt2) as coupon,
                                                   shop_coupon_amt
                                              FROM DORDER A,
                                                   CALLCENTER B
                                             WHERE A.CCCODE = B.CCCODE
                                               AND MCODE = 2
                                               AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                               AND STATUS IN ('40', '50')
                                               and case when A.status = '50' then A.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                               AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                    AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                               AND TEST_GBN = 'N'
                                             UNION ALL
                                    SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                   ORDER_NO,
                                                   STATUS,
                                                   MENU_AMT,
                                                   DELI_TIP_AMT,
                                                   MILEAGE_USE_AMT,
                                                   TOT_AMT,
                                                   DISC_AMT,
                                                   to_go_disc_amt,
                                                   (a.coupon_amt + a.coupon_amt2) as coupon,
                                                   shop_coupon_amt
                                              FROM DORDER_PAST A,
                                                   CALLCENTER B
                                             WHERE A.CCCODE = B.CCCODE
                                               AND MCODE = 2
                                               AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                               AND STATUS IN ('40', '50')
                                               and case when A.status = '50' then A.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                               AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                    AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                               AND TEST_GBN = 'N') X,
                                           (SELECT *
                                              FROM COUPON_MST
                                             WHERE COUPON_TYPE = 'IS_C100') Y,
                                           (SELECT *
                                              FROM COUPON_MST
                                             WHERE COUPON_TYPE = 'IS_C400') Z,
                                           (SELECT ORDER_NO,
                                                   DISC_USE_AMT
                                              FROM DORDER_DISC_DETAIL
                                             WHERE DISC_CODE = '20') W
                                     WHERE X.ORDER_NO = Y.ORDER_NO (+)
                                       AND X.ORDER_NO = Z.ORDER_NO (+)
                                       AND X.ORDER_NO = W.ORDER_NO (+)
                                     GROUP BY X.ORDER_DATE, X.STATUS
                                     ORDER BY 주문일 DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 일자별 주문(완료,최소) 엑셀 통계용
        /// <summary>
        /// 엑셀통계 - 일자별 완료 및 취소(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        [HttpGet("getDailyOrderCompletedCanceled2")]
        public async Task<IActionResult> getDailyOrderCompletedCanceled2(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT X.ORDER_DATE AS 주문일,
                                           DECODE(X.STATUS, '40', '완료', '50', '취소') AS 상태,
                                           COUNT(X.STATUS) AS 수량,
                                           SUM(X.MENU_AMT) AS 총음식금액,
                                           SUM(X.DELI_TIP_AMT) AS 총배달팁,
                                           SUM(X.MENU_AMT + X.DELI_TIP_AMT) AS 총금액,
                                           SUM(Y.COUPON_AMT) AS 첫주문쿠폰,
                                           SUM(Z.COUPON_AMT) AS 재구매쿠폰,
                                           SUM(x.coupon - nvl(y.coupon_amt,0) - nvl(z.coupon_amt,0)) AS 이벤트쿠폰,
                                           SUM(x.shop_coupon_amt) AS 가맹점자체쿠폰,
                                           SUM(X.MILEAGE_USE_AMT) AS 마일리지,
                                           SUM(X.v_amount) AS 모바일상품권결제금액,
                                           SUM(X.VOUCHER_USE_AMT) AS 모바일상품권,
                                           SUM(W.DISC_USE_AMT) AS 행복페이할인,
                                           SUM(W2.DISC_USE_AMT) AS 배달팁할인,
                                           SUM(W3.DISC_USE_AMT) AS 대구로할인,
                                           SUM(W4.DISC_USE_AMT) AS 착한매장할인,
                                           SUM(W5.DISC_USE_AMT) AS 아동급식할인,
                                           SUM(W6.DISC_USE_AMT) AS 대구로페이할인,
                                           SUM(W7.DISC_USE_AMT) AS 장보기배달팁할인,
                                           SUM(x.to_go_disc_amt) AS 포장할인,
                                           SUM(X.DISC_AMT) AS 총할인액,
                                           SUM(X.TOT_AMT - X.DISC_AMT) AS 결제금액
                                      FROM (SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                   ORDER_NO,
                                                   STATUS,
                                                   MENU_AMT,
                                                   DELI_TIP_AMT,
                                                   MILEAGE_USE_AMT,
                                                   case when pay_gbn = 'V' then VOUCHER_USE_AMT end v_amount,
                                                   case when pay_gbn <> 'V' then VOUCHER_USE_AMT end VOUCHER_USE_AMT,
                                                   TOT_AMT,
                                                   DISC_AMT,
                                                   to_go_disc_amt,
                                                   (a.coupon_amt + a.coupon_amt2) as coupon,
                                                   shop_coupon_amt
                                              FROM DORDER A,
                                                   CALLCENTER B
                                             WHERE A.CCCODE = B.CCCODE
                                               AND MCODE = 2
                                               AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                               AND STATUS IN ('40', '50')
                                               and case when A.status = '50' then A.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                               AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                    AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                               AND TEST_GBN = 'N'
                                             UNION ALL
                                    SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                   ORDER_NO,
                                                   STATUS,
                                                   MENU_AMT,
                                                   DELI_TIP_AMT,
                                                   MILEAGE_USE_AMT,
                                                   case when pay_gbn = 'V' then VOUCHER_USE_AMT end v_amount,
                                                   case when pay_gbn <> 'V' then VOUCHER_USE_AMT end VOUCHER_USE_AMT,
                                                   TOT_AMT,
                                                   DISC_AMT,
                                                   to_go_disc_amt,
                                                   (a.coupon_amt + a.coupon_amt2) as coupon,
                                                   shop_coupon_amt
                                              FROM DORDER_PAST A,
                                                   CALLCENTER B
                                             WHERE A.CCCODE = B.CCCODE
                                               AND MCODE = 2
                                               AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                               AND STATUS IN ('40', '50')
                                               and case when A.status = '50' then A.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                               AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                    AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                               AND TEST_GBN = 'N') X,
                                           (SELECT *
                                              FROM COUPON_MST
                                             WHERE COUPON_TYPE = 'IS_C100') Y,
                                           (SELECT *
                                              FROM COUPON_MST
                                             WHERE COUPON_TYPE = 'IS_C400') Z,
                                           (SELECT ORDER_NO,DISC_USE_AMT
                                              FROM DORDER_DISC_DETAIL
                                              where disc_code = '20') W,
                                            (SELECT ORDER_NO,DISC_USE_AMT
                                              FROM DORDER_DISC_DETAIL
                                              where disc_code = '10') W2,
                                            (SELECT ORDER_NO,DISC_USE_AMT
                                              FROM DORDER_DISC_DETAIL
                                              where disc_code = '30') W3,
                                            (SELECT ORDER_NO,DISC_USE_AMT
                                              FROM DORDER_DISC_DETAIL
                                              where disc_code = '40') W4,
                                            (SELECT ORDER_NO,DISC_USE_AMT
                                              FROM DORDER_DISC_DETAIL
                                              where disc_code = '50') W5,
                                            (SELECT ORDER_NO,DISC_USE_AMT
                                              FROM DORDER_DISC_DETAIL
                                              where disc_code = '60') W6,
                                            (SELECT ORDER_NO,DISC_USE_AMT
                                              FROM DORDER_DISC_DETAIL
                                              where disc_code = '70') W7
                                     WHERE X.ORDER_NO = Y.ORDER_NO (+)
                                       AND X.ORDER_NO = Z.ORDER_NO (+)
                                       AND X.ORDER_NO = W.ORDER_NO (+)
                                       AND X.ORDER_NO = W2.ORDER_NO (+)
                                       AND X.ORDER_NO = W3.ORDER_NO (+)
                                       AND X.ORDER_NO = W4.ORDER_NO (+)
                                       AND X.ORDER_NO = W5.ORDER_NO (+)
                                       AND X.ORDER_NO = W6.ORDER_NO (+)
                                       AND X.ORDER_NO = W7.ORDER_NO (+)
                                     GROUP BY X.STATUS,rollup(X.ORDER_DATE)
                                     ORDER BY 주문일 DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 결제별 주문(기간조건:ORDER_TIME 주문시간)O
        /// </summary>
        [HttpGet("getPayOrderCount")]
        public async Task<IActionResult> getPayOrderCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                SELECT ORDER_DATE ,
                                       case when pay_div = '11' then '만나서 현금'
                                            when pay_div = '32' then '앱 카드'
                                            when pay_div = '37' then '행복페이'
                                            when pay_div = '52' then '만나서 카드'
                                            when pay_div = '3N' then '네이버페이'
                                            when pay_div = '3K' then '카카오페이'
                                            when pay_div = '3S' then '삼성페이' 
                                            when pay_div = '3T' then '토스결제' 
                                            when pay_div = '3V' then '모바일상품권' 
                                            when pay_div = '3H' then '신한PG'  
                                            when pay_div = '3C' then '아동급식카드'  
                                            when pay_div = '3BC' then 'BC_TOP_POINT'  
                                            when pay_div = '3M' then 'KB페이'  
                                            when pay_div = '3D' then '대구로페이' 
                                            when pay_div = '3P' then '페이코' 
                                       end AS pay_gbn,
                                       COUNT(*) AS COUNT
                                  FROM (SELECT TO_CHAR(ORDER_TIME, 'yyyyMMdd') AS ORDER_DATE,
                                               APP_PAY_GBN || case when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                   else PAY_GBN end AS PAY_DIV
                                          FROM DORDER A,
                                               CALLCENTER B,
                                               dorder_detail c
                                         WHERE A.CCCODE = B.CCCODE
                                           AND B.MCODE = 2
                                           and a.order_no = c.order_no
                                           and a.status not in  ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND TEST_GBN = 'N'
                                           AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                           AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                         UNION ALL
                                SELECT TO_CHAR(ORDER_TIME, 'yyyyMMdd') AS ORDER_DATE,
                                               APP_PAY_GBN || case when app_pay_gbn = '1' then '1'
                                                                   when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                   else PAY_GBN end AS PAY_DIV
                                          FROM DORDER_PAST A,
                                               CALLCENTER B,
                                               dorder_detail c
                                         WHERE A.CCCODE = B.CCCODE
                                           AND B.MCODE = 2
                                           and a.order_no = c.order_no
                                           and a.status not in  ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND TEST_GBN = 'N'
                                           AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                           AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                 GROUP BY CUBE(ORDER_DATE, PAY_DIV)
                                 ORDER BY ORDER_DATE DESC, PAY_GBN
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        // 일자별 군구별 주문현황
        /// <summary>
        /// 엑셀통계 - 군구별 주문(기간조건:ORDER_TIME 주문시간)O -*엑셀 컨트롤러로 이동
        /// </summary>
        [HttpGet("getGunguOrder")]
        public async Task<IActionResult> getGunguOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  SELECT ORDER_DATE, GUNGU AS GUNGU_NAME, COUNT (GUNGU) AS COUNT
                                    FROM (SELECT TO_CHAR (ORDER_TIME, 'YYYYMMDD')
                                                     ORDER_DATE,
                                                 CASE
                                                     WHEN PACK_ORDER_YN = 'Y'
                                                     THEN
                                                         '포장'
                                                     WHEN PACK_ORDER_YN = 'N' AND DEST_GUNGU IS NULL
                                                     THEN
                                                         '기타'
                                                     ELSE
                                                         DEST_GUNGU
                                                 END
                                                     AS GUNGU
                                            FROM DORDER A, CALLCENTER B
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 AND A.TEST_GBN = 'N'
                                                 AND ORDER_TIME > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 and a.status not in  ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                          UNION ALL
                                          SELECT TO_CHAR (ORDER_TIME, 'YYYYMMDD')
                                                     ORDER_DATE,
                                                 CASE
                                                     WHEN PACK_ORDER_YN = 'Y'
                                                     THEN
                                                         '포장'
                                                     WHEN PACK_ORDER_YN = 'N' AND DEST_GUNGU IS NULL
                                                     THEN
                                                         '기타'
                                                     ELSE
                                                         DEST_GUNGU
                                                 END
                                                     AS GUNGU
                                            FROM DORDER_PAST A, CALLCENTER B
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 AND A.TEST_GBN = 'N'
                                                 AND ORDER_TIME > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 and a.status not in  ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                GROUP BY CUBE (ORDER_DATE, GUNGU)
                                ORDER BY ORDER_DATE desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 엑셀통계 - 일회용품 사용 현황(기간조건설정불가:ORDER_TIME 주문시간)O
        /// </summary>
        [HttpGet("getUseDisposablePrd")]
        public async Task<IActionResult> getUseDisposablePrd()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                //param.Add("date_begin", date_begin);
                //param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT ORDER_DATE,
                                       COUNT(*) AS TOTAL_COUNT,
                                       COUNT(CASE WHEN NVL(SHOP_DELI_MEMO,'@') NOT LIKE '%수저포크 X%' THEN 1 ELSE NULL END) AS USE_COUNT,
                                       COUNT(CASE WHEN SHOP_DELI_MEMO LIKE '%수저포크 X%' THEN 1 ELSE NULL END) AS NOT_USE_COUNT
                                  FROM (SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                               SHOP_DELI_MEMO
                                          FROM DORDER A,
                                               CALLCENTER B
                                         WHERE A.CCCODE = B.CCCODE
                                           AND B.MCODE = 2
                                           AND A.ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           and a.status not in  ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND A.TEST_GBN = 'N'
                                         UNION ALL
                                SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                               SHOP_DELI_MEMO
                                          FROM DORDER_PAST A,
                                               CALLCENTER B
                                         WHERE A.CCCODE = B.CCCODE
                                           AND B.MCODE = 2
                                           AND A.ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           and a.status not in  ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND A.TEST_GBN = 'N')
                                 GROUP BY ORDER_DATE
                                 ORDER BY ORDER_DATE DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 배달 거리별 주문수(전체기간)O
        /// </summary>
        [HttpGet("getArrivalDistance")]
        public async Task<IActionResult> getArrivalDistance()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                //param.Add("date_begin", date_begin);
                //param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT /*+ rule */ (COUNT(CASE WHEN DISTANCE < 0.5 THEN 1 ELSE NULL END)) AS DIV_05,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 0.5 AND 0.9 THEN 1 ELSE NULL END)) AS DIV_05_09,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 1.0 AND 1.4 THEN 1 ELSE NULL END)) AS DIV_10_14,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 1.5 AND 1.9 THEN 1 ELSE NULL END)) AS DIV_15_19,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 2.0 AND 2.4 THEN 1 ELSE NULL END)) AS DIV_20_24,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 2.5 AND 2.9 THEN 1 ELSE NULL END)) AS DIV_25_29,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 3.0 AND 3.4 THEN 1 ELSE NULL END)) AS DIV_30_34,
                                       (COUNT(CASE WHEN DISTANCE BETWEEN 3.5 AND 3.9 THEN 1 ELSE NULL END)) AS DIV_35_39,
                                       (COUNT(CASE WHEN DISTANCE >= 4.0 THEN 1 ELSE NULL END)) AS DIV_40
                                  FROM (SELECT (select SF_CALC_DISTANCE(C.LON, C.LAT, A.DEST_LON, A.DEST_LAT) from dual) AS DISTANCE
                                          FROM DORDER A,
                                               CALLCENTER B,
                                               SHOP_INFO C
                                         WHERE A.CCCODE = B.CCCODE
                                           AND A.SHOP_CD = C.SHOP_CD
                                           AND B.MCODE = 2
                                           AND A.ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           and a.status not in  ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND A.TEST_GBN = 'N'
                                         UNION ALL
                                SELECT /*+ rule */ (select SF_CALC_DISTANCE(C.LON, C.LAT, A.DEST_LON, A.DEST_LAT) from dual) AS DISTANCE
                                          FROM DORDER_PAST A,
                                               CALLCENTER B,
                                               SHOP_INFO C        
                                         WHERE A.CCCODE = B.CCCODE
                                           AND A.SHOP_CD = C.SHOP_CD
                                           AND B.MCODE = 2
                                           AND A.ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           and a.status not in  ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                           AND A.TEST_GBN = 'N')
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        #endregion

        #region[회원]

        /// <summary>
        /// 엑셀통계 - 일자별 가입 및 탈퇴 회원수
        /// </summary>
        [HttpGet("getDailyMemberJoinDel")]
        public async Task<IActionResult> getDailyMemberJoinDel(string date_begin, string date_end, string system_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("system_gbn", system_gbn);

                db.Open();

                string sql = string.Empty;

                if (system_gbn == null)
                {
                    sql = @$"
                            SELECT DT,
                                    CASE
                                        WHEN CUST_ID_GBN = 'A' THEN '공공앱'
                                        WHEN CUST_ID_GBN = 'G' THEN '구글'
                                        WHEN CUST_ID_GBN = 'I' THEN '아이폰'
                                        WHEN CUST_ID_GBN = 'K' THEN '카카오'
                                        WHEN CUST_ID_GBN = 'N' THEN '네이버'
                                        WHEN CUST_ID_GBN = 'Z' THEN '비회원'
                                        ELSE CUST_ID_GBN
                                    END AS 구분 ,
                                    COUNT(CASE WHEN GBN = 'I' THEN DT END) AS 가입,
                                    COUNT(CASE WHEN GBN = 'O' THEN DT END) AS 탈퇴
                                FROM (SELECT TO_CHAR(INSERT_DATE, 'YYYYMMDD') AS DT,
                                            'I' GBN,
                                            CUST_ID_GBN
                                        FROM APP_CUSTOMER
                                        WHERE MCODE = 2
                                        AND CUST_ID_GBN <> 'Z'
                                        and test_gbn = 'R'
                                        -- AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                        AND INSERT_DATE BETWEEN to_date(:date_begin,'YYYYMMDD') AND to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                        UNION ALL
                            SELECT TO_CHAR(INSERT_DATE, 'YYYYMMDD') AS DT,
                                            'I' GBN,
                                            CUST_ID_GBN
                                        FROM APP_CUSTOMER_DELETED
                                        WHERE MCODE = 2
                                        AND CUST_ID_GBN <> 'Z'
                                        and test_gbn = 'R'
                                        -- AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                        AND INSERT_DATE BETWEEN to_date(:date_begin,'YYYYMMDD') AND to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                        UNION ALL
                            SELECT TO_CHAR(DEL_DATE, 'YYYYMMDD') AS DT,
                                            'O' GBN,
                                            CUST_ID_GBN
                                        FROM APP_CUSTOMER_DELETED
                                        WHERE MCODE = 2
                                        AND TEST_GBN = 'R'
                                        AND CUST_ID_GBN <> 'Z'
                                        -- AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                        AND DEL_DATE BETWEEN to_date(:date_begin,'YYYYMMDD') AND to_date(:date_end || '235959', 'YYYYMMDDHH24MISS'))
                                GROUP BY DT, CUBE(CUST_ID_GBN)
                                ORDER BY DT DESC, CUST_ID_GBN
                ";
                }
                else
                {
                    sql = @$"
                            SELECT DT,
                                    CASE
                                        WHEN CUST_ID_GBN = 'A' THEN '공공앱'
                                        WHEN CUST_ID_GBN = 'G' THEN '구글'
                                        WHEN CUST_ID_GBN = 'I' THEN '아이폰'
                                        WHEN CUST_ID_GBN = 'K' THEN '카카오'
                                        WHEN CUST_ID_GBN = 'N' THEN '네이버'
                                        WHEN CUST_ID_GBN = 'Z' THEN '비회원'
                                        ELSE CUST_ID_GBN
                                    END AS 구분 ,
                                    COUNT(CASE WHEN GBN = 'I' THEN DT END) AS 가입,
                                    COUNT(CASE WHEN GBN = 'O' THEN DT END) AS 탈퇴
                                FROM (SELECT TO_CHAR(INSERT_DATE, 'YYYYMMDD') AS DT,
                                            'I' GBN,
                                            CUST_ID_GBN
                                        FROM APP_CUSTOMER
                                        WHERE MCODE = 2
                                        AND SYSTEM_GBN = :system_gbn
                                        AND CUST_ID_GBN <> 'Z'
                                        and test_gbn = 'R'
                                        -- AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                        AND INSERT_DATE BETWEEN to_date(:date_begin,'YYYYMMDD') AND to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                        UNION ALL
                            SELECT TO_CHAR(INSERT_DATE, 'YYYYMMDD') AS DT,
                                            'I' GBN,
                                            CUST_ID_GBN
                                        FROM APP_CUSTOMER_DELETED
                                        WHERE MCODE = 2
                                        AND SYSTEM_GBN = :system_gbn
                                        AND CUST_ID_GBN <> 'Z'
                                        and test_gbn = 'R'
                                        -- AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                        AND INSERT_DATE BETWEEN to_date(:date_begin,'YYYYMMDD') AND to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                        UNION ALL
                            SELECT TO_CHAR(DEL_DATE, 'YYYYMMDD') AS DT,
                                            'O' GBN,
                                            CUST_ID_GBN
                                        FROM APP_CUSTOMER_DELETED
                                        WHERE MCODE = 2
                                        AND SYSTEM_GBN = :system_gbn
                                        AND TEST_GBN = 'R'
                                        AND CUST_ID_GBN <> 'Z'
                                        -- AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                        AND DEL_DATE BETWEEN to_date(:date_begin,'YYYYMMDD') AND to_date(:date_end || '235959', 'YYYYMMDDHH24MISS'))
                                GROUP BY DT, CUBE(CUST_ID_GBN)
                                ORDER BY DT DESC, CUST_ID_GBN
                ";
                }



                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 회원별 통계 - 일자별 비회원수(기간조건:INSERT_DATE 가입일시) + (엑셀통계 일자별 비회원)
        /// </summary>
        [HttpGet("getDailyNonMemberCount")]
        public async Task<IActionResult> getDailyNonMemberCount(string date_begin, string date_end, string system_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("system_gbn", system_gbn);

                string sql = @"
                              SELECT TO_CHAR (a.insert_date, 'yyyyMMdd')
                                         insert_date,
                                     COUNT (*)
                                         count
                                FROM (SELECT system_gbn, mcode, insert_date, cust_id_gbn, test_gbn FROM app_customer
                                      UNION ALL
                                      SELECT system_gbn,
                                             mcode,
                                             insert_date,
                                             cust_id_gbn,
                                             test_gbn
                                        FROM app_customer_deleted) a
                               WHERE     a.test_gbn = 'R'
                                     AND a.mcode = 2
                                     and a.cust_id_gbn = 'Z'
                                     and a.system_gbn like case when :system_gbn is null then '%' else :system_gbn end
                                     -- AND a.insert_date >= TO_DATE('2021080917','yyyyMMddHH24')
                                     AND A.INSERT_DATE  between to_date(:date_begin || ' 000000','YYYYMMDD HH24MISS') 
                                                          and to_date(:date_end || ' 235959','YYYYMMDD HH24MISS')
                            GROUP BY TO_CHAR (a.insert_date, 'yyyyMMdd')
                            ORDER BY insert_date desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 엑셀통계 - 마일리지 내역
        /// </summary>
        [HttpGet("getMileageHistory")]
        public async Task<IActionResult> getMileageHistory(string divKey, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            string sDate = string.Empty;
            string sUnionAll = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                //1 적립일자 2 주문시간 3 배달완료시간 기준
                switch (divKey)
                {
                    case "1":
                        {
                            sDate = "a.log_date";
                            break;
                        }
                    case "2":
                        {
                            sDate = "case when b.order_time is null then a.log_date else b.order_time end";
                            break;
                        }
                    case "3":
                        {
                            sDate = "case when b.deli_dt is null then a.log_date else b.deli_dt end";
                            break;
                        }
                    default:
                        break;
                }

                date_begin = $@"{date_begin.Substring(4, 2)}/{date_begin.Substring(6, 2)}/{date_begin.Substring(0, 4)}";

                DateTime dtBegin = Convert.ToDateTime(date_begin);

                date_end = $@"{date_end.Substring(4, 2)}/{date_end.Substring(6, 2)}/{date_end.Substring(0, 4)}";

                DateTime dtEnd = Convert.ToDateTime(date_end);

                DateTime dtToday = Convert.ToDateTime(DateTime.Now.AddDays(-2).ToString("MM/dd/yyyy"));

                if (dtBegin >= dtToday || dtEnd >= dtToday)
                {
                    sUnionAll = @$"
                                    UNION ALL
                                                  SELECT a.order_no as 주문번호,a.app_cust_code as 회원코드, c.cust_name as 회원명,
                                        {sDate} as 적립일시,
                                        a.mileage_amt as 적립금액,
                                        (case when a.log_gbn = '3' then b.mileage_use_amt else 0 end) as 사용금액,
                                        a.memo as 메모,
                                        d.shop_name as 사용처
                                    FROM app_cust_mileage_log  a,
                                         dorder b,
                                         (select cust_code, cust_name from app_customer where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                         union all select cust_code, cust_name from app_customer_deleted where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                         ) c,
                                         shop_info d
                                        where a.order_no = b.order_no (+)
                                        and a.app_cust_code = c.cust_code
                                        and nvl(a.shop_cd,'0') = d.shop_cd (+)
                                        AND {sDate} >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND TO_CHAR ({sDate}, 'yyyyMMdd') BETWEEN :date_begin
                                                                                AND :date_end
                                ";
                }

                string sql = $@"
                                SELECT * FROM(SELECT a.order_no as 주문번호,a.app_cust_code as 회원코드, c.cust_name as 회원명,
                                        {sDate} as 적립일시,
                                        a.mileage_amt as 적립금액,
                                        (case when a.log_gbn = '3' then b.mileage_use_amt else 0 end) as 사용금액,
                                        a.memo as 메모,
                                        d.shop_name as 사용처
                                    FROM app_cust_mileage_log  a,
                                         dorder_past b,
                                         (select cust_code, cust_name from app_customer where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                         union all select cust_code, cust_name from app_customer_deleted where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        ) c,
                                         shop_info d
                                        where a.order_no = b.order_no (+)
                                        and a.app_cust_code = c.cust_code
                                        and nvl(a.shop_cd,'0') = d.shop_cd (+)
                                        AND {sDate} >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND TO_CHAR ({sDate}, 'yyyyMMdd') BETWEEN :date_begin
                                                                                AND :date_end
                                        {sUnionAll})
                                  order by 적립일시
                                ";

                //string sql = @"
                //                 SELECT * FROM (SELECT a.order_no AS 주문번호,
                //                        a.log_date AS 적립일시,
                //                        d.cust_name AS 회원명,
                //                        d.cust_code AS 회원코드,
                //                        a.mileage_amt AS 적립금액,
                //                        (case when a.log_gbn = '3' then b.mileage_use_amt else 0 end) AS 사용금액,
                //                        c.shop_name AS 사용처,
                //                        a.memo AS 메모
                //                    FROM app_cust_mileage_log  a,
                //                        dorder                b,
                //                        shop_info             c,
                //                        (select mcode, cust_code, cust_name from app_customer 
                //                        union all 
                //                        select mcode, cust_code, cust_name from app_customer_deleted)  d,
                //                        callcenter            e
                //                    WHERE     a.order_no = b.order_no
                //                        AND b.shop_cd = c.shop_cd
                //                        AND c.cccode = e.cccode
                //                        AND e.mcode = 2
                //                        AND d.mcode = 2
                //                        and b.status <> '50'
                //                        AND a.app_cust_code = d.cust_code
                //                        AND b.TEST_GBN = 'N'
                //                        AND NVL(b.cancel_code,'00')<>'30'
                //                        AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                //                        AND TO_CHAR (a.log_date, 'yyyyMMdd') BETWEEN :date_begin
                //                                                                AND :date_end
                //                UNION ALL
                //                SELECT a.order_no,
                //                        a.log_date,
                //                        d.cust_name,
                //                        d.cust_code,
                //                        a.mileage_amt,
                //                        (case when a.log_gbn = '3' then b.mileage_use_amt else 0 end),
                //                        c.shop_name,
                //                        a.memo
                //                    FROM app_cust_mileage_log  a,
                //                        dorder_past            b,
                //                        shop_info             c,
                //                        (select mcode, cust_code, cust_name from app_customer 
                //                        union all 
                //                        select mcode, cust_code, cust_name from app_customer_deleted)  d,
                //                        callcenter            e        
                //                    WHERE     a.order_no = b.order_no
                //                        AND b.shop_cd = c.shop_cd
                //                        AND c.cccode = e.cccode
                //                        AND e.mcode = 2
                //                        AND d.mcode = 2
                //                        and b.status <> '50'
                //                        AND a.app_cust_code = d.cust_code
                //                        AND b.TEST_GBN = 'N'
                //                        AND NVL(b.cancel_code,'00')<>'30'
                //                        AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                //                        AND TO_CHAR (a.log_date, 'yyyyMMdd') BETWEEN :date_begin
                //                                                                AND :date_end)
                //                ORDER BY 적립일시 DESC
                //";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 엑셀통계 - 마일리지 내역(기간별 마일리지 총액)
        /// </summary>
        [HttpGet("getTotalMileage")]
        public async Task<IActionResult> getTotalMileage(string divKey, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            string sDate = string.Empty;
            string sUnionAll = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                //1 적립일자 2 주문시간 3 배달완료시간 기준
                switch (divKey)
                {
                    case "1":
                        {
                            sDate = "a.log_date";
                            break;
                        }
                    case "2":
                        {
                            sDate = "case when b.order_time is null then a.log_date else b.order_time end";
                            break;
                        }
                    case "3":
                        {
                            sDate = "case when b.deli_dt is null then a.log_date else b.deli_dt end";
                            break;
                        }
                    default:
                        break;
                }

                string sql = @$"
                                SELECT a.memo as 메모, sum(a.mileage_amt) as 금액
                                    FROM app_cust_mileage_log  a,
                                         dorder_past b,
                                         (select cust_code, cust_name from app_customer where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                         union all select cust_code, cust_name from app_customer_deleted where mcode = 2 AND TEST_GBN = 'R' 
                                         -- AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        ) c,
                                         shop_info d
                                        where a.order_no = b.order_no (+)
                                        and a.app_cust_code = c.cust_code
                                        and nvl(a.shop_cd,'0') = d.shop_cd (+)
                                        AND {sDate} >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND TO_CHAR ({sDate}, 'yyyyMMdd') BETWEEN :date_begin
                                                                                AND :date_end
                                                                                group by rollup(a.memo)
                                                                                order by a.memo
                                ";

                //string sql = @$"
                //                select sum(a.mileage_amt) 
                //                from app_cust_mileage_log a, 
                //                    (select cust_code, cust_name from app_customer where mcode = 2 AND TEST_GBN = 'R' AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                //                    union all 
                //                    select cust_code, cust_name from app_customer_deleted where mcode = 2 AND TEST_GBN = 'R' AND INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')) b
                //                where a.app_cust_code = b.cust_code   
                //                  AND a.log_date >= TO_DATE('2021080917','YYYYMMDDHH24')
                //                  and a.log_date <= TO_DATE(:in_to_dt||' 235959', 'YYYYMMDD HH24MISS')
                //";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);
                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 쿠폰내역
        /// </summary>
        [HttpGet("getCouponHistory")]
        public async Task<IActionResult> getCouponHistory(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                 SELECT A.COUPON_NAME AS 쿠폰명,
                                         A.COUPON_AMT AS 쿠폰금액,
                                         A.ST_DATE AS 지급일시,
                                         A.EXP_DATE AS 만기일시,
                                         DECODE (a.status, '00', '대기', '10', '승인', '20', '미사용', '30', '사용', '99', '만료') as 사용여부,
                                         B.CUST_NAME AS 회원명,
                                         A.APP_CUST_CODE AS 회원코드,
                                         D.SHOP_NAME AS 사용처,
                                         decode (a.status, '30', a.coupon_amt) as 사용금액
                                    FROM COUPON_MST  A,
                                         (select cust_code, cust_name from APP_CUSTOMER union all select cust_code, cust_name from APP_CUSTOMER_deleted) B,
                                         (SELECT * FROM DORDER 
                                         WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND TEST_GBN = 'N'
                                        AND NVL(CANCEL_CODE,'00') <> '30'
                                         UNION ALL 
                                         SELECT * FROM DORDER_PAST
                                         WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND TEST_GBN = 'N'
                                        AND NVL(CANCEL_CODE,'00') <> '30') C,
                                        SHOP_INFO D
                                   WHERE     A.APP_CUST_CODE = B.CUST_CODE(+)
                                         AND A.order_no = C.order_no(+)
                                         AND C.SHOP_CD = D.SHOP_CD (+)
                                         AND A.ST_DATE BETWEEN :date_begin AND :date_end
                                ORDER BY A.coupon_type, a.status desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }


        /// <summary>
        /// 엑셀통계 - 기간별 주문실적O
        /// </summary>
        /// <remarks>
        /// 회원별 이용 ( 0회 ~ 10회 이상 )/ div: 1 주문전체, 2 완료건만 <br/>
        /// 주문기간 기준 + 종료일 당일가입 회원까지만
        /// </remarks>
        [HttpGet("getAppCustomerCount")]
        public async Task<IActionResult> getAppCustomerCount(string date_begin, string date_end, string div)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("div", div);

                db.Open();

                string sql = @"
                                SELECT 0
                                           DAY_COUNT,
                                       (SELECT COUNT (*)
                                          FROM (SELECT mcode,
                                                       test_gbn,
                                                       cust_id_gbn,
                                                       insert_date,
                                                       cust_code
                                                  FROM app_customer
                                                UNION ALL
                                                SELECT mcode,
                                                       test_gbn,
                                                       cust_id_gbn,
                                                       insert_date,
                                                       cust_code
                                                  FROM app_customer_deleted) a
                                         WHERE     a.mcode = 2
                                               AND a.test_gbn = 'R'
                                               AND a.cust_id_gbn <> 'Z'
                                               -- AND a.insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                               AND to_char(a.insert_date,'YYYYMMDD') <= :date_end
                                               AND NOT EXISTS
                                                       (SELECT b.ccode
                                                          FROM (SELECT * FROM dorder B
                                                                WHERE case when :div = 2 then b.status else '40' end = '40' -- div에따라 전체주문기준, 완료기준
                                                               AND b.order_time >=
                                                                   TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                               AND b.order_time BETWEEN to_date(:date_begin,'yyyymmdd')
                                                                                    AND to_date(:date_end || '235959','yyyymmddhh24miss')
                                                               AND b.test_gbn = 'N'
                                                               and b.status not in  ('80','20')
                                                               and case when b.status = '50' then b.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                UNION ALL
                                                                SELECT/*+ full(b) parallel(b 4) */ * FROM dorder_past B
                                                                WHERE case when :div = 2 then b.status else '40' end = '40' -- div에따라 전체주문기준, 완료기준
                                                               AND b.order_time >=
                                                                   TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                               AND b.order_time BETWEEN to_date(:date_begin,'yyyymmdd')
                                                                                    AND to_date(:date_end || '235959','yyyymmddhh24miss')
                                                               AND b.test_gbn = 'N'
                                                               and b.status not in  ('80','20')
                                                               and case when b.status = '50' then b.cancel_code else '00' end in ('00','10','11','20','21','22','26')) b
                                                         WHERE     a.cust_code = b.ccode
                                                               ))
                                           ORDER_COUNT
                                  FROM DUAL
                                UNION ALL
                                    SELECT ROWNUM
                                               DAY_COUNT,
                                           DECODE (ROWNUM,
                                                   1, day1,
                                                   2, day2,
                                                   3, day3,
                                                   4, day4,
                                                   5, day5,
                                                   6, day6,
                                                   7, day7,
                                                   8, day8,
                                                   9, day9,
                                                   10, day10)
                                               order_count
                                      FROM (SELECT SUM (CASE WHEN (cnt = 1) THEN 1 ELSE 0 END)     day1,
                                                   SUM (CASE WHEN (cnt = 2) THEN 1 ELSE 0 END)     day2,
                                                   SUM (CASE WHEN (cnt = 3) THEN 1 ELSE 0 END)     day3,
                                                   SUM (CASE WHEN (cnt = 4) THEN 1 ELSE 0 END)     day4,
                                                   SUM (CASE WHEN (cnt = 5) THEN 1 ELSE 0 END)     day5,
                                                   SUM (CASE WHEN (cnt = 6) THEN 1 ELSE 0 END)     day6,
                                                   SUM (CASE WHEN (cnt = 7) THEN 1 ELSE 0 END)     day7,
                                                   SUM (CASE WHEN (cnt = 8) THEN 1 ELSE 0 END)     day8,
                                                   SUM (CASE WHEN (cnt = 9) THEN 1 ELSE 0 END)     day9,
                                                   SUM (CASE WHEN (cnt > 9) THEN 1 ELSE 0 END)     day10
                                              FROM (  SELECT ccode, COUNT (*) cnt
                                                        FROM (SELECT a.*
                                                                FROM (select * from dorder A
                                                                 WHERE a.test_gbn = 'N'
                                                                 and case when :div = 2 then a.status else '40' end = '40' -- div에따라 전체주문기준, 완료기준
                                                                 AND a.order_time >=
                                                                     TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                 and a.status not in  ('80','20')
                                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                 AND a.order_time BETWEEN to_date(:date_begin,'yyyymmdd')
                                                                                      AND to_date(:date_end || '235959','yyyymmddhh24miss')
                                                                union all 
                                                                select/*+ full(a) parallel(a 4) */ * from dorder_past A
                                                                WHERE a.test_gbn = 'N'
                                                                 and case when :div = 2 then a.status else '40' end = '40' -- div에따라 전체주문기준, 완료기준
                                                                 AND a.order_time >=
                                                                     TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                 and a.status not in  ('80','20')
                                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                 AND a.order_time BETWEEN to_date(:date_begin,'yyyymmdd')
                                                                                      AND to_date(:date_end || '235959','yyyymmddhh24miss')) a, 
                                                                (SELECT mcode,
                                                                       test_gbn,
                                                                       cust_id_gbn,
                                                                       insert_date,
                                                                       cust_code
                                                                  FROM app_customer
                                                                UNION ALL
                                                                SELECT mcode,
                                                                       test_gbn,
                                                                       cust_id_gbn,
                                                                       insert_date,
                                                                       cust_code
                                                                  FROM app_customer_deleted) c
                                                               WHERE a.ccode = c.cust_code
                                                                     AND c.mcode = 2
                                                                     AND c.cust_id_gbn <> 'Z'
                                                                     AND c.test_gbn = 'R'
                                                                     -- AND c.insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                              )
                                                    GROUP BY ccode))
                                CONNECT BY LEVEL <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 연령별 주문실적O
        /// </summary>
        [HttpGet("getAgeToOrder")]
        public async Task<IActionResult> getAgeToOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();


                if (date_begin.Equals("20210809"))
                {
                    date_begin = "2021080917";
                }
                else
                {
                    date_begin = date_begin + "00";
                }

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT case when birthday is null then 0
                                            when birthday < 1 then 1
                                            when birthday > 9 then 9
                                            else birthday end || '0대' AS year, COUNT (*) COUNT, 
                                       COUNT(CASE WHEN STATUS = '40' THEN 1 END) AS COMP, 
                                       COUNT(CASE WHEN STATUS = '50' THEN 1 END) AS CANC
                                FROM (SELECT trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                             birthday, STATUS
                                    FROM (SELECT cust_code,
                                                 birthday
                                            FROM app_customer
                                          UNION ALL
                                          SELECT cust_code,
                                                 birthday
                                            FROM app_customer_deleted) a, 
                                                (select ccode,STATUS from dorder
                                                where ORDER_TIME between 
                                                    TO_DATE(:date_begin,'YYYYMMDDHH24') and 
                                                    TO_DATE(:date_end || 235959,'YYYYMMDDHH24MISS')
                                                  AND TEST_GBN = 'N'
                                                  and status not in  ('80','20')
                                                  and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                union all
                                                select ccode,STATUS from dorder_past
                                                where ORDER_TIME between 
                                                    TO_DATE(:date_begin,'YYYYMMDDHH24') and 
                                                    TO_DATE(:date_end || 235959,'YYYYMMDDHH24MISS')
                                                  AND TEST_GBN = 'N'
                                                  and status not in  ('80','20')
                                                  and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26')) b
                                    where a.cust_code = b.ccode
                                   )
                        GROUP BY case when birthday is null then 0
                                      when birthday < 1 then 1
                                      when birthday > 9 then 9
                                      else birthday end
                        ORDER BY case when birthday is null then 0
                                      when birthday < 1 then 1
                                      when birthday > 9 then 9
                                      else birthday end
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - OS별 설치
        /// </summary>
        [HttpGet("getInstalled")]
        public async Task<IActionResult> getInstalled(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @$"
                                 SELECT to_char(insert_date,'YYYYMMDD') ins_date, 
                                        count(case when device_gbn = 'A' then 1 end) android, 
                                        count(case when device_gbn = 'I' then 1 end) IOS, 
                                        count(*) total
                                    FROM (SELECT mcode,
                                                 insert_date,
                                                 cust_id_gbn,
                                                 test_gbn,
                                                 device_gbn
                                            FROM app_customer
                                          UNION ALL
                                          SELECT mcode,
                                                 insert_date,
                                                 cust_id_gbn,
                                                 test_gbn,
                                                 device_gbn
                                            FROM app_customer_deleted)
                                   WHERE     mcode = 2
                                         AND device_gbn IS NOT NULL
                                         AND cust_id_gbn = 'Z'
                                         AND test_gbn = 'R'
                                         AND insert_date between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                GROUP BY to_char(insert_date,'YYYYMMDD')
                                order by to_char(insert_date,'YYYYMMDD') desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 연령별 가입
        /// </summary>
        [HttpGet("getCustomerAge")]
        public async Task<IActionResult> getCustomerAge(string date_begin, string date_end, string system_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("system_gbn", system_gbn);

                db.Open();

                string sql = string.Empty;

                if (system_gbn == null)
                {
                    sql = @$"
                            SELECT  insert_date, 
                                    count(case when birthday <= 1 then 1 end) as year10,
                                    count(case when birthday = 2 then 1 end) as year20,
                                    count(case when birthday = 3 then 1 end) as year30,
                                    count(case when birthday = 4 then 1 end) as year40,
                                    count(case when birthday = 5 then 1 end) as year50,
                                    count(case when birthday = 6 then 1 end) as year60,
                                    count(case when birthday = 7 then 1 end) as year70,
                                    count(case when birthday >= 8 then 1 end) as year80,
                                    count(case when birthday is null then 1 end) as nodata,
                                    count(1) as total
                            FROM (SELECT TO_CHAR (insert_date, 'YYYYMMDD')
                                             AS insert_date,
                                         trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                             birthday
                                    FROM (SELECT mcode,
                                                 insert_date,
                                                 birthday,
                                                 test_gbn,
                                                 CUST_ID_GBN
                                            FROM app_customer
                                            WHERE     mcode = 2
                                             AND test_gbn = 'R'
                                             AND CUST_ID_GBN <> 'Z'
                                             AND insert_date between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                          UNION ALL
                                          SELECT mcode,
                                                 insert_date,
                                                 birthday,
                                                 test_gbn,
                                                 CUST_ID_GBN
                                            FROM app_customer_deleted
                                            WHERE     mcode = 2
                                             AND test_gbn = 'R'
                                             AND CUST_ID_GBN <> 'Z'
                                             AND insert_date between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS'))
                                   )
                            GROUP BY insert_date
                            ORDER BY insert_date DESC
                     ";
                }
                else
                {
                    sql = @$"
                            SELECT  insert_date, 
                                    count(case when birthday <= 1 then 1 end) as year10,
                                    count(case when birthday = 2 then 1 end) as year20,
                                    count(case when birthday = 3 then 1 end) as year30,
                                    count(case when birthday = 4 then 1 end) as year40,
                                    count(case when birthday = 5 then 1 end) as year50,
                                    count(case when birthday = 6 then 1 end) as year60,
                                    count(case when birthday = 7 then 1 end) as year70,
                                    count(case when birthday >= 8 then 1 end) as year80,
                                    count(case when birthday is null then 1 end) as nodata,
                                    count(1) as total
                            FROM (SELECT TO_CHAR (insert_date, 'YYYYMMDD')
                                             AS insert_date,
                                         trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                             birthday
                                    FROM (SELECT mcode,
                                                 insert_date,
                                                 birthday,
                                                 test_gbn,
                                                 CUST_ID_GBN
                                            FROM app_customer
                                            WHERE     mcode = 2
                                             AND SYSTEM_GBN = :system_gbn
                                             AND test_gbn = 'R'
                                             AND CUST_ID_GBN <> 'Z'
                                             AND insert_date between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                          UNION ALL
                                          SELECT mcode,
                                                 insert_date,
                                                 birthday,
                                                 test_gbn,
                                                 CUST_ID_GBN
                                            FROM app_customer_deleted
                                            WHERE     mcode = 2
                                             AND SYSTEM_GBN = :system_gbn
                                             AND test_gbn = 'R'
                                             AND CUST_ID_GBN <> 'Z'
                                             AND insert_date between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS'))
                                   )
                            GROUP BY insert_date
                            ORDER BY insert_date DESC
                     ";
                }

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 엑셀통계 - 회원 주문순위O
        /// </summary>
        /// <remarks>
        /// div: 1 완료수 많은/ 2 완료금액 많은/ 3 주문수 많은/ 4 주문금액 많은 <br/>
        /// 금액기준 (TOT_AMT: 메뉴주문금액 + 배달팁금액)
        /// </remarks>
        [HttpGet("getCustomerRank10")]
        public async Task<IActionResult> getCustomerRank10(string div, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("div", div);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();


                string sql = @$"
                                select rownum rnum, a.*
                                from(select case when :div in (2,4) then sum(a.tot_amt) else count(1) end as 값, b.cust_name 회원명, b.cust_code
                                from (select * from dorder union all select * from dorder_past) a, 
                                (select cust_code, cust_name from app_customer where cust_id_gbn <> 'Z' and test_gbn = 'R' and mcode = 2
                                union all 
                                select cust_code, cust_name from app_customer_deleted where cust_id_gbn <> 'Z' and test_gbn = 'R' and mcode = 2) b, callcenter c
                                where a.app_cust_code = b.cust_code
                                and a.status in ('40', case when :div in (3,4) then '50' end)
                                and a.cccode = c.cccode
                                and c.mcode = 2
                                AND a.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND a.TEST_GBN = 'N'
                                and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26') 
                                and a.order_time between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                group by b.cust_code, b.cust_name
                                order by case when :div in (2,4) then sum(a.tot_amt) else count(a.order_no) end desc ) a
                                where rownum <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 일자별 성별 가입수
        /// </summary>
        [HttpGet("getDailyGenderToJoin")]
        public async Task<IActionResult> getDailyGenderToJoin(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);

                db.Open();

                string sql = @$"
                                SELECT dt, 
                                       case when system_gbn = 'D' then '대구로'
                                            when system_gbn = 'T' then '택시' end system_gbn, 
                                       case when GENDER = 'F' then '여성'
                                            when GENDER = 'M' then '남성'
                                            when GENDER = 'Z' then '성별미선택' end gender, COUNT(*) cnt
                                FROM(
                                    SELECT to_char(insert_date,'YYYYMMDD') dt, system_gbn, GENDER, MCODE
                                    FROM APP_CUSTOMER
                                    WHERE CUST_ID_GBN <> 'Z'
                                    AND TEST_GBN = 'R'
                                    AND INSERT_DATE BETWEEN TO_DATE(:in_fr_date,'YYYYMMDD') AND TO_DATE(:in_to_date || '235959', 'YYYYMMDDHH24MISS')
                                    UNION ALL
                                    SELECT to_char(insert_date,'YYYYMMDD') dt, system_gbn, GENDER, MCODE
                                    FROM APP_CUSTOMER_DELETED
                                    WHERE CUST_ID_GBN <> 'Z'
                                    AND TEST_GBN = 'R'
                                    AND INSERT_DATE BETWEEN TO_DATE(:in_fr_date,'YYYYMMDD') AND TO_DATE(:in_to_date || '235959', 'YYYYMMDDHH24MISS')
                                )
                                where mcode = 2 -- 테스트계정 확인시 주석
                                GROUP BY dt,system_gbn, GENDER
                                order by dt desc,system_gbn, GENDER
                ";



                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        #endregion

        #region[쿠폰]
        /// <summary>
        /// 브랜드 목록 조회
        /// </summary>
        [HttpGet("getChainList")]
        public async Task<IActionResult> getChainList()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            string sql = @$"
                            select code, code_nm from etc_code
                            where code_grp = 'API'
                            and pgm_group = 'O'
                            and use_gbn = 'Y'
                            and test_yn = 'N'
                            order by code_nm
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 브랜드별 쿠폰목록 조회
        /// </summary>
        [HttpGet("getChainCouponList")]
        public async Task<IActionResult> getChainCouponList(string chainCode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_chain_code", chainCode);

            string sql = @$"
                            select code, code_nm, memo
                            from etc_code 
                            where code_grp = 'BRAND_COUPON' 
                            AND use_gbn = 'Y'
                            and etc_code1 like case when :in_chain_code is null then '%' else :in_chain_code end
                            -- order by code_nm
                            order by etc_code1 desc, code desc
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 브랜드별 쿠폰 상태별 건수 조회
        /// </summary>
        [HttpGet("getChainCouponCnt")]
        public async Task<IActionResult> getChainCouponCnt(string coupon_type, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_coupon_type", coupon_type);
            param.Add("in_date_begin", date_begin);
            param.Add("in_date_end", date_end);

            string sql = @$"
                            select X.DT, NVL(a.cnt,0) 지급, NVL(b.cnt,0) 사용
                            from(SELECT to_char(to_date(:in_date_begin,'YYYYMMDD') + LEVEL - 1,'YYYYMMDD') AS DT
                                FROM dual
                                CONNECT BY LEVEL <= (to_date(:in_date_end,'YYYYMMDD') - to_date(:in_date_begin,'YYYYMMDD') + 1))X,
                                (select to_char(publish_date,'YYYYMMDD') dt, count(*) cnt
                                from chain_coupon_mst
                                where coupon_type = :in_coupon_type
                                and publish_date BETWEEN TO_DATE(:in_date_begin,'YYYYMMDD') AND TO_DATE(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                group by to_char(publish_date,'YYYYMMDD')) a,
                                (select to_char(use_date,'YYYYMMDD') dt, count(*) cnt
                                from chain_coupon_mst
                                where coupon_type = :in_coupon_type
                                and use_date BETWEEN TO_DATE(:in_date_begin,'YYYYMMDD') AND TO_DATE(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                group by to_char(use_date,'YYYYMMDD')) b
                            where X.DT =  a.dt (+)
                            AND X.DT = b.dt (+)
                            order by X.DT DESC
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }
        #endregion[쿠폰]

        #endregion


        #region[친구초대 통계]
        /// <summary>
        /// 친구초대 통계
        /// </summary>
        [HttpGet("getInviteFriendsTotal")]
        public async Task<IActionResult> getInviteFriendsTotal(string date_begin, string date_end, string gender)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("in_gender", gender);

                db.Open();

                string sql = @$"
                                select ins_date, 
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then be_share_cust_cnt end),0) be_share_cust_cnt, --공유한 회원수
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then shared_cust_cnt end),0) shared_cust_cnt,  --공유받은 회원수
                                       nvl(trunc(avg(case when age_grp <> 0 and gender_grp <> 'A' then first_order_interval end),2),0) first_order_interval, --첫주문 평균시간
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then event_page_contact_cnt end),0) event_page_contact_cnt, --페이지접속
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then code_copy_cnt end),0) code_copy_cnt, --복사버튼
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then share_cnt end),0) share_cnt, --공유버튼
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then code_input_page_cnt end),0) code_input_page_cnt, --받은코드 입력화면
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then miss_input_cnt end),0) miss_input_cnt, --코드 오입력 
                                       nvl(sum(case when age_grp <> 0 and gender_grp <> 'A' then condition_mismatch end),0) condition_mismatch, --회원조건미일치 
                                       nvl(sum(case when age_grp = 0 and gender_grp = 'A' then event_page_contact_cnt end),0) z_event_page_contact_cnt --페이지접속(비회원)
                                from INVITE_EVENT_TOTAL
                                where ins_date between :date_begin and :date_end
                                and gender_grp like case when :in_gender is null then '%' else :in_gender end
                                group by ins_date
                                order by ins_date desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 친구초대 통계(연령별)
        /// </summary>
        [HttpGet("getInviteFriendsAgeTotal")]
        public async Task<IActionResult> getInviteFriendsAgeTotal(string date_begin, string date_end, string gender)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("in_gender", gender);

                db.Open();

                string sql = @$"
                                select age_grp, 
                                       SUM(be_share_cust_cnt) be_share_cust_cnt, --공유한 회원수
                                       SUM(shared_cust_cnt) shared_cust_cnt, --공유받은 회원수
                                       nvl(trunc(AVG(first_order_interval),2),0) first_order_interval, --첫주문 평균시간
                                       sum(event_page_contact_cnt) event_page_contact_cnt, --페이지 접속
                                       SUM(code_copy_cnt) code_copy_cnt, --복사버튼
                                       SUM(share_cnt) share_cnt, --공유버튼
                                       SUM(code_input_page_cnt) code_input_page_cnt, --받은코드 입력화면
                                       SUM(miss_input_cnt) miss_input_cnt, --코드 오입력
                                       SUM(condition_mismatch) condition_mismatch --회원조건 미일치
                                from INVITE_EVENT_TOTAL
                                where ins_date between :date_begin and :date_end
                                and gender_grp like case when :in_gender is null then '%' else :in_gender end
                                AND GENDER_GRP <> 'A'
                                AND AGE_GRP <> 0
                                group by age_grp
                                ORDER BY AGE_GRP DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 친구초대 순위
        /// </summary>
        /// <remarks>
        /// 쿼리시 회원명, 전화번호 블러처리
        /// </remarks>
        [HttpGet("getInviteFriendsRank")]
        public async Task<IActionResult> getInviteFriendsRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @$"
                                select * from(select rownum, x.*, substr(y.cust_name,1,1) || '*' || substr(y.cust_name,3) cust_name, 
                                        substr(y.telno,1,3) || '-****-' || substr(y.telno,8) as telno
                                from(select invite_cust_cd, count(*) cnt
                                    from INVITE_FRIEND_EVENT_CHECK
                                    where ins_date between :date_begin and :date_end
                                    group by invite_cust_cd
                                    order by count(*) desc) x, 
                                    (select cust_code, cust_name, telno 
                                    from app_customer 
                                    union all 
                                    select cust_code, cust_name, telno 
                                    from app_customer_deleted) y
                                where x.invite_cust_cd = y.cust_code
                                order by x.cnt desc)
                                where rownum <= 100
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }
        #endregion

        #region[라이브이벤트 통계엑셀]
        /// <summary>
        /// 라이브이벤트 진행 가맹점(횟수 높은 가맹점 순)O
        /// </summary>
        [HttpGet("getEventShopHist")]
        public async Task<IActionResult> getEventShopHist(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                select c.shop_name as 가맹점명, e.진행횟수, a.첫진행, NVL(b.총주문,0) AS 총주문, NVL(b.완료,0) AS 완료, NVL(b.취소,0) AS 취소
                                from (select a.shop_cd,
                                min(case when a.memo like '%이벤트 일자%' then substr(a.memo, -8)end) as 첫진행
                                from shop_event_mst_hist a
                                group by shop_cd) a,
                                (select c.shop_cd, 
                                count(1) as 총주문, count(case when c.status = '40' then 1 end) as 완료, count(case when c.status = '50' then 1 end) as 취소
                                from (select order_no, cccode from shop_event_order group by order_no, cccode) b, 
                                (select * from dorder 
                                where ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND TEST_GBN = 'N'
                                and status not in ('80','20')
                                and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26') 
                                union all 
                                select * from dorder_past
                                where ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND TEST_GBN = 'N'
                                and status not in ('80','20')
                                and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26') ) c, callcenter d
                                where b.order_no = c.order_no
                                and b.cccode = d.cccode
                                and d.mcode = 2
                                and c.order_time between to_date(:date_begin || ' 000000','YYYYMMDD HH24MISS') and to_date(:date_end || ' 235959','YYYYMMDD HH24MISS')
                                group by shop_cd) b,
                                shop_info c,
                                (select a.shop_cd, count(1) as 진행횟수 
                                from shop_event_mst_hist a, shop_info b, callcenter c
                                where a.shop_cd = b.shop_cd
                                and b.cccode = c.cccode
                                and a.memo like '%이벤트 일자%'
                                and substr(a.memo, -8) between :date_begin and :date_end
                                and c.mcode = 2
                                and b.app_order_yn = 'Y'
                                group by a.shop_cd) e
                                where a.shop_cd = b.shop_cd (+)
                                and a.shop_cd = c.shop_cd
                                and a.shop_cd = e.shop_cd
                                and 진행횟수 > 0
                                order by 진행횟수 desc, 총주문 desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }



        /// <summary>
        /// 라이브이벤트 진행누적 수
        /// </summary>
        [HttpGet("getEventShopRank")]
        public async Task<IActionResult> getEventShopRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();


                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                select 0 day_count,(select count(*)
                                                    from shop_info b, callcenter c
                                                    where b.cccode = c.cccode
                                                    and c.mcode = 2
                                                    and b.app_order_yn = 'Y'
                                                    and shop_cd not in (select distinct a.shop_cd
                                                                        from shop_event_mst_hist a, shop_info b, callcenter c
                                                                        where a.shop_cd = b.shop_cd
                                                                        and b.cccode = c.cccode
                                                                        and a.memo like '%이벤트 일자%'
                                                                        and substr(a.memo, -8) between :date_begin and :date_end
                                                                        and c.mcode = 2
                                                                        and b.app_order_yn = 'Y')) as shop_count
                                from dual                                        
                                union all
                                SELECT ROWNUM
                                       DAY_COUNT,
                                   DECODE (ROWNUM,
                                           1, day1,
                                           2, day2,
                                           3, day3,
                                           4, day4,
                                           5, day5,
                                           6, day6,
                                           7, day7,
                                           8, day8,
                                           9, day9,
                                           10, day10)
                                       shop_count
                                FROM(SELECT nvl(SUM (CASE WHEN (cnt = 1) THEN 1 ELSE 0 END),0)
                                           day1,
                                       nvl(SUM (CASE WHEN (cnt = 2) THEN 1 ELSE 0 END),0)
                                           day2,
                                       nvl(SUM (CASE WHEN (cnt = 3) THEN 1 ELSE 0 END),0)
                                           day3,
                                       nvl(SUM (CASE WHEN (cnt = 4) THEN 1 ELSE 0 END),0)
                                           day4,
                                       nvl(SUM (CASE WHEN (cnt = 5) THEN 1 ELSE 0 END),0)
                                           day5,
                                       nvl(SUM (CASE WHEN (cnt = 6) THEN 1 ELSE 0 END),0)
                                           day6,
                                       nvl(SUM(CASE WHEN (cnt = 7) THEN 1 ELSE 0 END),0)
                                           day7,
                                       nvl(SUM (CASE WHEN (cnt = 8) THEN 1 ELSE 0 END),0)
                                           day8,
                                      nvl (SUM (CASE WHEN (cnt = 9) THEN 1 ELSE 0 END),0)
                                           day9,
                                       nvl(SUM (CASE WHEN (cnt >= 10) THEN 1 ELSE 0 END),0)
                                           day10 from(select a.shop_cd, count(1) as cnt 
                                                        from shop_event_mst_hist a, shop_info b, callcenter c
                                                        where a.shop_cd = b.shop_cd
                                                        and b.cccode = c.cccode
                                                        and a.memo like '%이벤트 일자%'
                                                        and substr(a.memo, -8) between :date_begin and :date_end
                                                        and c.mcode = 2
                                                        and b.app_order_yn = 'Y'
                                                        group by a.shop_cd))
                                CONNECT BY LEVEL <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 라이브이벤트 사용 누적회원 수O
        /// </summary>
        [HttpGet("getEventCustomerRank")]
        public async Task<IActionResult> getEventCustomerRank(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();


                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                select 0 day_count,(select count(1) 
                                from app_customer a, 
                                    (select app_cust_code ,order_no, order_time ,cccode
                                    from dorder 
                                    where TEST_GBN = 'N'
                                    and status not in ('80','20')
                                    and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                    union all 
                                    select app_cust_code ,order_no, order_time, cccode
                                    from dorder_past
                                    where TEST_GBN = 'N'
                                    and status not in ('80','20')
                                    and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26')) b,
                                    callcenter c  
                                where  a.cust_code = b.app_cust_code
                                        and b.cccode = c.cccode
                                        AND a.MCODE = 2
                                        AND a.CUST_ID_GBN <> 'Z'
                                        AND a.TEST_GBN = 'R'
                                        -- AND a.INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        and c.mcode = 2
                                        and b.app_cust_code not in (select b.app_cust_code
                                                                    from shop_event_order a, 
                                                                    (select app_cust_code ,order_no, order_time
                                                                    from dorder 
                                                                    where TEST_GBN = 'N'
                                                                    and status not in ('80','20')
                                                                    and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                                    union all 
                                                                    select app_cust_code ,order_no, order_time
                                                                    from dorder_past
                                                                    where TEST_GBN = 'N'
                                                                    and status not in ('80','20')
                                                                    and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26')) b
                                                                    where a.order_no = b.order_no
                                                                    and b.order_time between to_date(:date_begin || '000000','YYYYMMDD HH24MISS') and to_date(:date_end || '235959','YYYYMMDD HH24MISS')
                                                                    group by b.app_cust_code)) as count 
                                from dual   
                                union all               
                                SELECT ROWNUM
                                       DAY_COUNT,
                                   DECODE (ROWNUM,
                                           1, day1,
                                           2, day2,
                                           3, day3,
                                           4, day4,
                                           5, day5,
                                           6, day6,
                                           7, day7,
                                           8, day8,
                                           9, day9,
                                           10, day10)
                                       count
                                FROM(SELECT nvl(SUM (CASE WHEN (cnt = 1) THEN 1 ELSE 0 END),0)
                                           day1,
                                       nvl(SUM (CASE WHEN (cnt = 2) THEN 1 ELSE 0 END),0)
                                           day2,
                                       nvl(SUM (CASE WHEN (cnt = 3) THEN 1 ELSE 0 END),0)
                                           day3,
                                       nvl(SUM (CASE WHEN (cnt = 4) THEN 1 ELSE 0 END),0)
                                           day4,
                                       nvl(SUM (CASE WHEN (cnt = 5) THEN 1 ELSE 0 END),0)
                                           day5,
                                       nvl(SUM (CASE WHEN (cnt = 6) THEN 1 ELSE 0 END),0)
                                           day6,
                                       nvl(SUM(CASE WHEN (cnt = 7) THEN 1 ELSE 0 END),0)
                                           day7,
                                       nvl(SUM (CASE WHEN (cnt = 8) THEN 1 ELSE 0 END),0)
                                           day8,
                                      nvl (SUM (CASE WHEN (cnt = 9) THEN 1 ELSE 0 END),0)
                                           day9,
                                       nvl(SUM (CASE WHEN (cnt >= 10) THEN 1 ELSE 0 END),0)
                                           day10 from  (select b.app_cust_code, count(1) as cnt
                                                        from shop_event_order a, 
                                                        (select app_cust_code ,order_no, order_time ,cccode
                                                        from dorder 
                                                        where TEST_GBN = 'N'
                                                        and status not in ('80','20')
                                                        and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                        union all 
                                                        select app_cust_code ,order_no, order_time, cccode
                                                        from dorder_past
                                                        where TEST_GBN = 'N'
                                                        and status not in ('80','20')
                                                        and case when status = '50' then cancel_code else '00' end in ('00','10','11','20','21','22','26')) b,
                                                        callcenter c
                                                        where a.order_no = b.order_no
                                                        and b.cccode = c.cccode
                                                        and c.mcode = 2
                                                        and b.order_time between to_date(:date_begin || '000000','YYYYMMDD HH24MISS') and to_date(:date_end || '235959','YYYYMMDD HH24MISS')
                                                        group by b.app_cust_code))
                                CONNECT BY LEVEL <= 10
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        //  시간별 검색 불가능
        /// <summary>
        /// 라이브이벤트 평균 시간대(가맹점)
        /// </summary>
        [HttpGet("getTimeEventCount")]
        public async Task<IActionResult> getTimeEventCount()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                db.Open();

                string sql = @"
                                SELECT item_cd, HH, COUNT(item_cd) COUNT
                                    FROM (SELECT case when a.memo like '%시작 시간%' then substr(a.memo,-4,2) else substr(a.memo,-9,2) end as HH, b.item_cd
                                            FROM shop_event_mst_hist a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND b.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 and b.app_order_yn = 'Y'
                                                 and (a.memo like '%이벤트 시간%' or a.memo like '%시작 시간%'))
                                GROUP BY CUBE (item_cd, HH)
                                ORDER BY item_cd
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 라이브이벤트 사용 시간대(회원)O
        /// </summary>
        [HttpGet("getTimeEventOrderCount")]
        public async Task<IActionResult> getTimeEventOrderCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();


                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT item_cd, TO_CHAR (order_time, 'HH24') AS HH, COUNT (item_cd) COUNT
                                    FROM (SELECT a.order_time, b.item_cd
                                            FROM dorder a, shop_info b, callcenter c, (select order_no from shop_event_order group by order_no) d
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 and a.order_no = d.order_no
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end
                                          UNION ALL
                                          SELECT a.order_time, b.item_cd
                                            FROM dorder_past a, shop_info b, callcenter c, (select order_no from shop_event_order group by order_no) d
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 and a.order_no = d.order_no
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end)
                                GROUP BY CUBE (item_cd, TO_CHAR (order_time, 'HH24'))
                                ORDER BY item_cd
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 기간별 검색 불가능
        /// <summary>
        /// 라이브이벤트 평균 할인액
        /// </summary>
        [HttpGet("getEventDiscRank")]
        public async Task<IActionResult> getEventDiscRank()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                db.Open();

                string sql = @"
                                select a.rnum as 순위, TO_NUMBER(a.amt) as 할인액, TO_NUMBER(b.per) as 할인율
                                from
                                    (select rownum as rnum, amt 
                                    from(select substr(a.memo, 25) as amt
                                        from shop_event_hist a, shop_info b, callcenter c
                                        where a.memo like '이벤트 할인구분:->정액%'
                                        and a.shop_cd = b.shop_cd
                                        and b.cccode = c.cccode
                                        and b.app_order_yn = 'Y'
                                        and c.mcode = 2
                                        group by substr(a.memo, 25)
                                        order by count(substr(a.memo, 25)) desc)
                                    where rownum < 6) a,
                                    (select rownum as rnum, per
                                    from(select substr(a.memo, 25) as per
                                        from shop_event_hist a, shop_info b, callcenter c
                                        where a.memo like '이벤트 할인구분:->정율%'
                                        and a.shop_cd = b.shop_cd
                                        and b.cccode = c.cccode
                                        and b.app_order_yn = 'Y'
                                        and c.mcode = 2
                                        group by substr(a.memo, 25)
                                        order by count(substr(a.memo, 25)) desc)
                                    where rownum < 6) b
                                where a.rnum = b.rnum
                                UNION ALL
                                select  0 순위, 
                                        round(avg(CASE WHEN a.memo like '이벤트 할인구분:->정액%' THEN substr(a.memo, 25) END),2) as 할인액, 
                                        round(avg(CASE WHEN a.memo like '이벤트 할인구분:->정율%' THEN substr(a.memo, 25) END),2) as 할인율
                                from shop_event_hist a, shop_info b, callcenter c
                                where a.shop_cd = b.shop_cd
                                and b.cccode = c.cccode
                                and b.app_order_yn = 'Y'
                                and c.mcode = 2
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 일자별 라이브이벤트 건수 및 매출액 조회O
        /// </summary>
        [HttpGet("getDailyEventCount")]
        public async Task<IActionResult> getDailyEventCount(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT X.ORDER_DATE,
                                       DECODE(X.STATUS, '40', '완료', '50', '취소') AS status,
                                       COUNT(X.STATUS) AS count,
                                       SUM(X.ORI_AMT) AS sum
                                  FROM (select * 
                                            from dorder AA
                                            , (select a.order_no, a.ori_amt, a.disc_amt
                                                    from shop_event_order a, callcenter b 
                                                    where a.cccode=b.cccode 
                                                    and b.mcode=2 
                                                    group by a.order_no, a.ori_amt, a.disc_amt) BB
                                        where AA.order_no = BB.order_no
                                        and AA.status in ('40','50')
                                        and case when AA.status = '50' then AA.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                        AND AA.ORDER_TIME BETWEEN to_date(:date_begin ||' 000000', 'YYYYMMDD HH24MISS')
                                                                                      AND to_date(:date_end ||' 235959', 'YYYYMMDD HH24MISS')
                                        UNION ALL
                                        select *
                                            from dorder_past AA
                                            , (select a.order_no, a. ori_amt, a.disc_amt
                                                from shop_event_order a, callcenter b 
                                                where a.cccode=b.cccode 
                                                and b.mcode=2 
                                                group by a.order_no, a.ori_amt, a.disc_amt) BB
                                        where AA.order_no=BB.order_no
                                        and AA.status in ('40','50')
                                        and case when AA.status = '50' then AA.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                        AND AA.ORDER_TIME BETWEEN to_date(:date_begin ||' 000000', 'YYYYMMDD HH24MISS')
                                                                                      AND to_date(:date_end ||' 235959', 'YYYYMMDD HH24MISS') ) X
                                 GROUP BY X.ORDER_DATE, X.STATUS
                                 ORDER BY X.ORDER_DATE DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }
        #endregion


        #region[대구로통계(회계)]
        /// <summary>
        /// 일자별 가맹점 적립금 내역(회계기준--배달완료)
        /// </summary>
        /// <remarks>
        /// date_begin : 해당 일자 <br />
        /// page : 1페이지당 5000건씩 조회 <br />
        /// 결제실패 취소건도 모두 포함
        /// </remarks>
        [HttpGet("getDailyShopBreakdown")]
        public async Task<IActionResult> getDailyShopBreakdown(string date_begin, string page) //page를 이용해서 5000건씩 조회
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            string mall_left = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("in_fr_dt", date_begin);
                param.Add("page", page);

                db.Open();

                string sql = @"
                                SELECT tt.*
                              FROM (SELECT ROWNUM AS RNUM,
                                           te.*
                                    FROM ( select t4.shop_cd, t4.shop_name,t3.pre_amt, t3.amt, t1.카드결제금액, t1.쿠폰, t1.마일리지사용금액, t1.행복페이할인액, t1.배달팁할인액, t1.중계수수료, t1.pg수수료, t1.카드결제금액c, t1.쿠폰c, t1.마일리지사용금액c, t1.행복페이할인액c, t1.배달팁할인액c, t1.중계수수료c, t1.pg수수료c , 
                                                  t2.mall_item_o_amt, t2.mall_deli_o_amt, t2.mall_item_i_amt, t2.mall_deli_i_amt,
                                                  t2.welcome_amt, t2.withdraw_amt, t2.withdraw_fee, t2.사입
                             from (SELECT shop_cd,
                                     nvl(COUNT(CASE WHEN STATUS = '40' THEN 1 END),0) AS COMP, 
                                     nvl(COUNT(CASE WHEN STATUS = '50' THEN 1 END),0) AS CANC,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN TOT_AMT ELSE 0 END),0) AS SUM_TOT_AMT,
                                     nvl(SUM(CASE WHEN STATUS = '40' and app_pay_gbn = '3' THEN AMOUNT ELSE 0 END ),0) AS 카드결제금액,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN COUPON_AMT ELSE 0 END),0) AS 쿠폰,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN MILEAGE_USE_AMT ELSE 0 END),0) AS 마일리지사용금액,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN happy_disc_amt ELSE 0 END),0) AS 행복페이할인액,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN deli_disc_amt ELSE 0 END),0) AS 배달팁할인액,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN DISC_AMT ELSE 0 END ),0) AS SUM_DISC_AMT,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN PGM_AMT ELSE 0 END ),0) AS 중계수수료,
                                     nvl(SUM(CASE WHEN STATUS = '40' THEN PG_PGM_AMT ELSE 0 END ),0) AS pg수수료,
                                     nvl(SUM(CASE WHEN STATUS = '50' and app_pay_gbn = '3' THEN AMOUNT ELSE 0 END ),0) AS 카드결제금액c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN COUPON_AMT ELSE 0 END),0) AS 쿠폰c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN MILEAGE_USE_AMT ELSE 0 END),0) AS 마일리지사용금액c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN happy_disc_amt ELSE 0 END),0) AS 행복페이할인액c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN deli_disc_amt ELSE 0 END),0) AS 배달팁할인액c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN DISC_AMT ELSE 0 END ),0) AS SUM_DISC_AMTc,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN PGM_AMTC ELSE 0 END ),0) AS 중계수수료c,
                                     nvl(SUM(CASE WHEN STATUS = '50' THEN PG_PGM_AMTC ELSE 0 END ),0) AS pg수수료c
                                     FROM(  SELECT     case when a.status = '50' and zz.new_status = '40' and to_char(z.hist_time,'YYYYMMDD') >= :in_fr_dt then '40'
                                                            when a.status = '40' and zz.new_status = '50' then '50' else A.STATUS end as status,
                                                     A.shop_cd,
                                                     A.order_date,
                                                     A.pay_gbn,
                                                     A.APP_PAY_GBN,
                                                     A.TOT_AMT,      
                                                     NVL(A.COUPON_AMT,0) + NVL(A.COUPON_AMT2,0)     AS COUPON_AMT,
                                                     A.MILEAGE_USE_AMT,
                                                     NVL(X.happy_disc_amt,0)                          AS happy_disc_amt,
                                                     NVL(X.deli_disc_amt,0)                          AS deli_disc_amt,
                                                     A.DISC_AMT,
                                                     A.AMOUNT,
                                                     NVL(Y.PGM_AMT,0)                               AS PGM_AMT,
                                                     NVL(Y.PGM_AMTC,0)                               AS PGM_AMTC,
                                                     NVL(Y.PG_PGM_AMT,0)                            AS PG_PGM_AMT,
                                                     NVL(Y.PG_PGM_AMTC,0)                            AS PG_PGM_AMTC,
                                                     z.order_no 
                                            FROM    DORDER A, SHOP_INFO B, CALLCENTER D,
                                            (   SELECT     ORDER_DATE, 
                                                            ORDER_NO,
                                                            SUM(case when disc_code = '20' then DISC_USE_AMT end) AS happy_disc_amt,
                                                            SUM(case when disc_code = '10' then DISC_USE_AMT end) AS deli_disc_amt
                                                FROM       DORDER_DISC_DETAIL
                                               -- WHERE      ORDER_DATE    BETWEEN to_char(to_date(:in_fr_dt,'YYYYMMDD') - 1,'YYYYMMDD') AND to_char(to_date(:in_fr_dt,'YYYYMMDD') + 1,'YYYYMMDD')
                                                GROUP BY   ORDER_DATE, 
                                                            ORDER_NO ) X,
                                            ( SELECT  ORDER_DATE, 
                                                    ORDER_NO ,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'P' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT END ELSE 0 END ) AS PGM_AMT,     -- 중개수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'P' THEN CASE WHEN IO_GBN = 'O' THEN CHARGE_AMT END ELSE 0 END ) AS PGM_AMTC,     -- 중개수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'K' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT END ELSE 0 END ) AS PG_PGM_AMT,   -- PG수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'K' THEN CASE WHEN IO_GBN = 'O' THEN CHARGE_AMT END ELSE 0 END ) AS PG_PGM_AMTC   -- PG수수료
                                            FROM    INSUNG_CALC 
                                            WHERE      CHARGE_DATE    BETWEEN TO_DATE(:in_fr_dt ||' 000000', 'YYYYMMDD HH24MISS')  AND  TO_DATE(:in_fr_dt ||' 235959', 'YYYYMMDD HH24MISS')
                                            AND     CHARGE_GBN  IN ( 'P', 'K' )  
                                            GROUP BY   ORDER_DATE, 
                                                        ORDER_NO ) Y,
                                            (select order_no, 
                                                    order_date,
                                                    hist_time,
                                                    sum(order_no) 
                                            from dorder_hist 
                                            where old_status = '40' and new_status = '50'
                                            and hist_time BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS') +30
                                            group by order_no, order_date, hist_time) z,
                                            (select new_status,
                                                    old_status,
                                                    order_no, 
                                                    order_date,
                                                    hist_time,
                                                    sum(order_no) 
                                            from dorder_hist 
                                            where (old_status = '40' and new_status = '50') or (old_status in ('35','30','50') and new_status = '40')
                                            and hist_time BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS') +30
                                            group by new_status, old_status, order_no, order_date, hist_time) zz
                                            WHERE   A.CCCODE        = B.CCCODE
                                            AND     A.SHOP_CD       = B.SHOP_CD
                                            AND     A.CCCODE        = D.CCCODE
                                            AND     D.MCODE         = 2
                                            AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND     case when a.status = '40' and zz.new_status = '40' and zz.old_status <> '50' then a.comp_dt -- 일반 완료건
                                                         when a.status = '40' and zz.new_status = '40' and zz.old_status = '50' then zz.hist_time  -- 관리앱 취소 -> 완료
                                                         when a.status = '40' and zz.new_status = '50' then a.cancel_dt -- 관리앱 완료 -> 취소(이후 다시 완료처리한 건)
                                                                 when a.status = '50' and zz.new_status = '40' and to_char(z.hist_time,'YYYYMMDD') >= :in_fr_dt then zz.hist_time -- 현재 취소이나 당시 완료건
                                                                 when a.status = '50' and zz.new_status = '50' and to_char(z.hist_time,'YYYYMMDD') = :in_fr_dt then  a.cancel_dt end -- 관리앱 완료 -> 취소
                                                                 BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS')
                                            AND     A.PRCS_GBN      = 'A'
                                            AND     A.TEST_GBN = 'N'
                                            --AND     NVL(CANCEL_CODE, '00') <> '30'  
                                            AND     ZZ.ORDER_DATE   = A.ORDER_DATE  (+)                       
                                            AND     ZZ.ORDER_NO     = A.ORDER_NO    (+)
                                            AND     ZZ.ORDER_DATE   = X.ORDER_DATE  (+)                       
                                            AND     ZZ.ORDER_NO     = X.ORDER_NO    (+) 
                                            AND     ZZ.ORDER_DATE   = Y.ORDER_DATE  (+) 
                                            AND     ZZ.ORDER_NO     = Y.ORDER_NO    (+)
                                            AND     ZZ.ORDER_NO     = Z.ORDER_NO    (+)
                                            AND     ZZ.ORDER_DATE   = Z.ORDER_DATE  (+)
                                    UNION ALL
                                        SELECT     case when a.status = '50' and zz.new_status = '40' and to_char(z.hist_time,'YYYYMMDD') >= :in_fr_dt then '40'
                                                            when a.status = '40' and zz.new_status = '50' then '50' else A.STATUS end as status,
                                                     A.shop_cd,
                                                     A.order_date,
                                                     A.pay_gbn,
                                                     A.APP_PAY_GBN,
                                                     A.TOT_AMT,      
                                                     NVL(A.COUPON_AMT,0) + NVL(A.COUPON_AMT2,0)     AS COUPON_AMT,
                                                     A.MILEAGE_USE_AMT,
                                                     NVL(X.happy_disc_amt,0)                          AS happy_disc_amt,
                                                     NVL(X.deli_disc_amt,0)                          AS deli_disc_amt,
                                                     A.DISC_AMT,
                                                     A.AMOUNT,
                                                     NVL(Y.PGM_AMT,0)                               AS PGM_AMT,
                                                     NVL(Y.PGM_AMTC,0)                               AS PGM_AMTC,
                                                     NVL(Y.PG_PGM_AMT,0)                            AS PG_PGM_AMT,
                                                     NVL(Y.PG_PGM_AMTC,0)                            AS PG_PGM_AMTC,
                                                     z.order_no 
                                            FROM    DORDER_PAST A, SHOP_INFO B, CALLCENTER D,
                                            (   SELECT     ORDER_DATE, 
                                                            ORDER_NO,
                                                            SUM(case when disc_code = '20' then DISC_USE_AMT end) AS happy_disc_amt,
                                                            SUM(case when disc_code = '10' then DISC_USE_AMT end) AS deli_disc_amt
                                                FROM       DORDER_DISC_DETAIL
                                               -- WHERE      ORDER_DATE    BETWEEN to_char(to_date(:in_fr_dt,'YYYYMMDD') - 1,'YYYYMMDD') AND to_char(to_date(:in_fr_dt,'YYYYMMDD') + 1,'YYYYMMDD')
                                                GROUP BY   ORDER_DATE, 
                                                            ORDER_NO ) X,
                                            ( SELECT  ORDER_DATE, 
                                                    ORDER_NO ,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'P' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT END ELSE 0 END ) AS PGM_AMT,     -- 중개수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'P' THEN CASE WHEN IO_GBN = 'O' THEN CHARGE_AMT END ELSE 0 END ) AS PGM_AMTC,     -- 중개수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'K' THEN CASE WHEN IO_GBN = 'I' THEN CHARGE_AMT END ELSE 0 END ) AS PG_PGM_AMT,   -- PG수수료
                                                    SUM(CASE WHEN CHARGE_GBN  = 'K' THEN CASE WHEN IO_GBN = 'O' THEN CHARGE_AMT END ELSE 0 END ) AS PG_PGM_AMTC   -- PG수수료
                                            FROM    INSUNG_CALC 
                                            WHERE      CHARGE_DATE    BETWEEN TO_DATE(:in_fr_dt ||' 000000', 'YYYYMMDD HH24MISS')  AND  TO_DATE(:in_fr_dt ||' 235959', 'YYYYMMDD HH24MISS')
                                            AND     CHARGE_GBN  IN ( 'P', 'K' )  
                                            GROUP BY   ORDER_DATE, 
                                                        ORDER_NO ) Y,
                                            (select order_no, 
                                                    order_date,
                                                    hist_time,
                                                    sum(order_no) 
                                            from dorder_hist 
                                            where old_status = '40' and new_status = '50'
                                            and hist_time BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS') +30
                                            group by order_no, order_date, hist_time) z,
                                            (select new_status,
                                                    old_status,
                                                    order_no, 
                                                    order_date,
                                                    hist_time,
                                                    sum(order_no) 
                                            from dorder_hist 
                                            where (old_status = '40' and new_status = '50') or (old_status in ('35','30','50') and new_status = '40')
                                            and hist_time BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS') +30
                                            group by new_status, old_status, order_no, order_date, hist_time) zz
                                            WHERE   A.CCCODE        = B.CCCODE
                                            AND     A.SHOP_CD       = B.SHOP_CD
                                            AND     A.CCCODE        = D.CCCODE
                                            AND     D.MCODE         = 2
                                            AND     A.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND     case when a.status = '40' and zz.new_status = '40' and zz.old_status <> '50' then a.comp_dt -- 일반 완료건
                                                         when a.status = '40' and zz.new_status = '40' and zz.old_status = '50' then zz.hist_time  -- 관리앱 취소 -> 완료
                                                         when a.status = '40' and zz.new_status = '50' then a.cancel_dt -- 관리앱 완료 -> 취소(이후 다시 완료처리한 건)
                                                                 when a.status = '50' and zz.new_status = '40' and to_char(z.hist_time,'YYYYMMDD') >= :in_fr_dt then zz.hist_time -- 현재 취소이나 당시 완료건
                                                                 when a.status = '50' and zz.new_status = '50' and to_char(z.hist_time,'YYYYMMDD') = :in_fr_dt then  a.cancel_dt end -- 관리앱 완료 -> 취소
                                                                 BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDDHH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDDHH24MISS')
                                            AND     A.PRCS_GBN      = 'A'
                                            AND     A.TEST_GBN = 'N'
                                            --AND     NVL(CANCEL_CODE, '00') <> '30'  
                                            AND     ZZ.ORDER_DATE   = A.ORDER_DATE  (+)                       
                                            AND     ZZ.ORDER_NO     = A.ORDER_NO    (+)
                                            AND     ZZ.ORDER_DATE   = X.ORDER_DATE  (+)                       
                                            AND     ZZ.ORDER_NO     = X.ORDER_NO    (+) 
                                            AND     ZZ.ORDER_DATE   = Y.ORDER_DATE  (+) 
                                            AND     ZZ.ORDER_NO     = Y.ORDER_NO    (+)
                                            AND     ZZ.ORDER_NO     = Z.ORDER_NO    (+)
                                            AND     ZZ.ORDER_DATE   = Z.ORDER_DATE  (+)) 
                                            group by shop_cd) t1,
                                            (select shop_cd,
                                                    SUM(CASE WHEN charge_gbn = 'E' and io_gbn = 'O' THEN charge_amt ELSE 0 END ) AS mall_item_o_amt, -- 대구로몰 상품 대금 출금액
                                                    SUM(CASE WHEN charge_gbn = 'F' and io_gbn = 'O' THEN charge_amt ELSE 0 END ) AS mall_deli_o_amt, -- 대구로몰 배송비 출금액
                                                    SUM(CASE WHEN charge_gbn = 'E' and io_gbn = 'I' THEN charge_amt ELSE 0 END ) AS mall_item_i_amt, -- 대구로몰 상품 대금 입금액
                                                    SUM(CASE WHEN charge_gbn = 'F' and io_gbn = 'I' THEN charge_amt ELSE 0 END ) AS mall_deli_i_amt, -- 대구로몰 배송비 입금액
                                                    SUM(CASE WHEN memo = '가맹점 입점신청 지급' THEN charge_amt ELSE 0 END ) AS welcome_amt,     -- 입점지원금
                                                    SUM(CASE WHEN memo like '계좌이체요청 %' THEN charge_amt ELSE 0 END ) AS withdraw_amt, -- 출금금액
                                                    SUM(CASE WHEN memo like '계좌이체요청 출금%' THEN 200 
                                                             WHEN memo like '계좌이체요청 실패%' THEN 200 * -1  ELSE 0 END ) AS withdraw_fee, -- 출금수수료 한건당 200원
                                                    SUM(CASE WHEN charge_gbn = '1' THEN charge_amt ELSE 0 END ) AS 사입 -- 사입
                                                     from shop_infocharge 
                                                     where CHARGE_DATE BETWEEN TO_DATE(:in_fr_dt||'000000','YYYYMMDD HH24MISS') AND  TO_DATE(:in_fr_dt||'235959','YYYYMMDD HH24MISS')
                                                     group by shop_cd) t2,
                                             (select shop_cd, 
                                                    sum(case when charge_date < to_date(:in_fr_dt || '000000','YYYYMMDD HH24MISS') then (case when io_gbn = 'I' then charge_amt else -1 * charge_amt end) end) as pre_Amt,
                                                    sum(case when io_gbn = 'I' then charge_amt else -1 * charge_amt end) as amt 
                                                    from shop_infocharge
                                                    where charge_date <= to_date(:in_fr_dt || ' 235959','YYYYMMDD HH24MISS')
                                                    group by shop_cd) t3,
                                           (select a.shop_cd, a.shop_name from shop_info a, callcenter b where a.cccode = b.cccode and b.mcode = 2) t4
                                          where t4.shop_cd = t1.shop_cd (+)
                                          and t4.shop_cd = t2.shop_cd (+)
                                          and t4.shop_cd = t3.shop_cd (+)
                                          order by t3.shop_cd ) te
                            WHERE ROWNUM <= (( :page - 1) * 5000) + 5000) tt
                            WHERE (( :page - 1) * 5000) < RNUM
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                sql = $@"   select sum(case when a.io_gbn = 'I' then charge_amt else charge_amt * -1 end) amt
                            from callcentercharge a
                            where a.mcode = 4
                            and charge_date <= to_date(:in_fr_dt || '235959','YYYYMMDDHH24MISS')";

                if (page == "3")
                {
                    mall_left = await db.QuerySingleAsync<string>(sql, param, commandType: CommandType.Text);
                }

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata, mall_left = mall_left });
        }

        /// <summary>
        /// 일자별 가맹점 적립금 내역V2(회계기준--배달완료)
        /// </summary>
        /// <remarks>
        /// date_begin : 해당 일자 <br />
        /// page : 1페이지당 5000건씩 조회 <br />
        /// 결제실패 취소건도 모두 포함
        /// </remarks>
        [HttpGet("getDailyShopBreakdownV2")]
        public async Task<IActionResult> getDailyShopBreakdownV2(string date_begin, string page) //page를 이용해서 5000건씩 조회
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            string mall_left = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("in_fr_dt", date_begin);
                param.Add("page", page);

                db.Open();

                string sql = @"
                              SELECT tt.*
                              FROM (SELECT ROWNUM AS RNUM,
                                           te.*
                                    FROM ( select t4.shop_cd, t4.shop_name,t3.pre_amt, t3.amt, t1.카드결제금액, t1.장보기주문금액, t1.쿠폰, t1.마일리지사용금액, t1.행복페이할인액, t1.배달팁할인액, t1.아동급식할인액, t1.대구로페이할인액, t1.중개수수료, t1.PG수수료, 
                                                  t1.카드결제금액c, t1.장보기주문금액C, t1.쿠폰c, t1.마일리지사용금액c, t1.행복페이할인액c, t1.배달팁할인액c, t1.아동급식할인액c, t1.대구로페이할인액c, t1.중개수수료c, t1.PG수수료c , 
                                                  t1.mall_item_o_amt, t1.mall_deli_o_amt, t1.mall_item_i_amt, t1.mall_deli_i_amt,
                                                  t1.welcome_amt, t1.withdraw_amt, t1.withdraw_fee, t1.사입, t1.사입C, t1.상품권사용액, t1.상품권사용액C
                             from (SELECT shop_cd,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'G' and IO_GBN = 'I' THEN CHARGE_AMT ELSE 0 END ) AS 카드결제금액,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'B' and IO_GBN = 'I' THEN CHARGE_AMT ELSE 0 END ) AS 장보기주문금액,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'U' and IO_GBN = 'I' THEN CHARGE_AMT ELSE 0 END ) AS 쿠폰,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'M' and IO_GBN = 'I' THEN CHARGE_AMT ELSE 0 END ) AS 마일리지사용금액,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'b' and IO_GBN = 'I' THEN CHARGE_AMT ELSE 0 END ) AS 행복페이할인액,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'a' and IO_GBN = 'I' THEN CHARGE_AMT ELSE 0 END ) AS 배달팁할인액,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'c' and IO_GBN = 'I' THEN CHARGE_AMT ELSE 0 END ) AS 아동급식할인액,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'd' and IO_GBN = 'I' THEN CHARGE_AMT ELSE 0 END ) AS 대구로페이할인액,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'P' and IO_GBN = 'O' THEN CHARGE_AMT ELSE 0 END ) AS 중개수수료,   
                                                    SUM(CASE WHEN CHARGE_GBN  = 'K' and IO_GBN = 'O' THEN CHARGE_AMT ELSE 0 END ) AS PG수수료,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'G' and IO_GBN = 'O' THEN CHARGE_AMT ELSE 0 END ) AS 카드결제금액C,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'B' and IO_GBN = 'O' THEN CHARGE_AMT ELSE 0 END ) AS 장보기주문금액C,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'U' and IO_GBN = 'O' THEN CHARGE_AMT ELSE 0 END ) AS 쿠폰C,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'M' and IO_GBN = 'O' THEN CHARGE_AMT ELSE 0 END ) AS 마일리지사용금액C,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'b' and IO_GBN = 'O' THEN CHARGE_AMT ELSE 0 END ) AS 행복페이할인액C,
                                                    SUM(CASE WHEN CHARGE_GBN  = 'a' and IO_GBN = 'O' THEN CHARGE_AMT ELSE 0 END ) AS 배달팁할인액C,   
                                                    SUM(CASE WHEN CHARGE_GBN  = 'c' and IO_GBN = 'O' THEN CHARGE_AMT ELSE 0 END ) AS 아동급식할인액C,  
                                                    SUM(CASE WHEN CHARGE_GBN  = 'd' and IO_GBN = 'O' THEN CHARGE_AMT ELSE 0 END ) AS 대구로페이할인액C,    
                                                    SUM(CASE WHEN CHARGE_GBN  = 'P' and IO_GBN = 'I' THEN CHARGE_AMT ELSE 0 END ) AS 중개수수료C,  
                                                    SUM(CASE WHEN CHARGE_GBN  = 'K' and IO_GBN = 'I' THEN CHARGE_AMT ELSE 0 END ) AS PG수수료C,
                                                    SUM(CASE WHEN charge_gbn  = 'E' and io_gbn = 'O' THEN charge_amt ELSE 0 END ) AS mall_item_o_amt, -- 대구로몰 상품 대금 출금액
                                                    SUM(CASE WHEN charge_gbn  = 'F' and io_gbn = 'O' THEN charge_amt ELSE 0 END ) AS mall_deli_o_amt, -- 대구로몰 배송비 출금액
                                                    SUM(CASE WHEN charge_gbn  = 'E' and io_gbn = 'I' THEN charge_amt ELSE 0 END ) AS mall_item_i_amt, -- 대구로몰 상품 대금 입금액
                                                    SUM(CASE WHEN charge_gbn  = 'F' and io_gbn = 'I' THEN charge_amt ELSE 0 END ) AS mall_deli_i_amt, -- 대구로몰 배송비 입금액
                                                    SUM(CASE WHEN memo = '가맹점 입점신청 지급' THEN charge_amt ELSE 0 END ) AS welcome_amt,     -- 입점지원금
                                                    SUM(CASE WHEN memo like '계좌이체요청 %' THEN charge_amt ELSE 0 END ) AS withdraw_amt, -- 출금금액
                                                    SUM(CASE WHEN memo like '계좌이체요청 출금%' THEN 200 
                                                             WHEN memo like '계좌이체요청 실패%' THEN 200 * -1  ELSE 0 END ) AS withdraw_fee, -- 출금수수료 한건당 200원
                                                    SUM(CASE WHEN charge_gbn = '1' and io_gbn = 'I' THEN charge_amt ELSE 0 END ) AS 사입, 
                                                    SUM(CASE WHEN charge_gbn = '1' and io_gbn = 'O' THEN charge_amt ELSE 0 END ) AS 사입C, 
                                                    SUM(CASE WHEN charge_gbn = 'Q' and io_gbn = 'I' THEN charge_amt ELSE 0 END ) AS 상품권사용액,
                                                    SUM(CASE WHEN charge_gbn = 'Q' and io_gbn = 'O' THEN charge_amt ELSE 0 END ) AS 상품권사용액C
                                            FROM    shop_infocharge 
                                            WHERE      CHARGE_DATE    BETWEEN TO_DATE(:in_fr_dt ||' 000000', 'YYYYMMDD HH24MISS')  AND  TO_DATE(:in_fr_dt ||' 235959', 'YYYYMMDD HH24MISS')
                                            GROUP BY   shop_cd) t1,
                                            (select shop_cd, 
                                                    sum(case when charge_date < to_date(:in_fr_dt || '000000','YYYYMMDD HH24MISS') then (case when io_gbn = 'I' then charge_amt else -1 * charge_amt end) end) as pre_Amt,
                                                    sum(case when io_gbn = 'I' then charge_amt else -1 * charge_amt end) as amt 
                                                    from shop_infocharge
                                                    where charge_date <= to_date(:in_fr_dt || ' 235959','YYYYMMDD HH24MISS')
                                                    group by shop_cd) t3,
                                           (select a.shop_cd, a.shop_name from shop_info a, callcenter b where a.cccode = b.cccode and b.mcode = 2) t4
                                          where t4.shop_cd = t1.shop_cd (+)
                                          and t4.shop_cd = t3.shop_cd (+)
                                          order by t3.shop_cd ) te
                            WHERE ROWNUM <= (( :page - 1) * 5000) + 5000) tt
                            WHERE (( :page - 1) * 5000) < RNUM
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                sql = $@"   select sum(case when a.io_gbn = 'I' then charge_amt else charge_amt * -1 end) amt
                            from callcentercharge a
                            where a.mcode = 4
                            and charge_date <= to_date(:in_fr_dt || '235959','YYYYMMDDHH24MISS')";

                if (page == "3")
                {
                    mall_left = await db.QuerySingleAsync<string>(sql, param, commandType: CommandType.Text);
                }

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata, mall_left = mall_left });
        }

        /// <summary>
        /// 마일리지 선입선출 대장 v2
        /// </summary>
        /// <remarks>
        /// * 전일내역까지 조회가능 <br />
        /// cust_gbn 가입구분 : 1. 가입, 3. 해지, %. 전체 <br />
        /// keyword 고객코드 <br />
        /// [response] <br />
        /// 가입구분 CUST_GBN_NM <br />
        /// 고객코드 CUST_CODE <br />
        /// 고객명 CUST_NAME <br />
        /// 마일리지 잔액 CUST_MILEAGE <br />
        /// 대장잔액 LOG_CUST_MILEAGE <br />
        /// 충전건수 IN_CNT <br />
        /// 충전합계 IN_AMT <br />
        /// 주문충전건수 ORDER_IN_CNT <br />
        /// 주문충전금액 ORDER_IN_AMT <br />
        /// 판매충전건수 SALE_IN_CNT <br />
        /// 판매충전금액 SALE_IN_AMT <br />
        /// 택시충전건수 TAXI_IN_CNT <br />
        /// 택시충전금액 TAXI_IN_AMT <br />
        /// 주문차감금액 ORDER_OUT_AMT <br />
        /// 택시차감금액 TAXI_OUT_AMT <br />
        /// 차감합계 OUT_AMT <br />
        /// 탈퇴마일리지 TERMINATE_AMT <br />
        /// <br />
        /// sumData 합계정보 <br />
        /// 마일리지 잔액부터 탈퇴마일리지까지 SUM_칼럼명 표기
        /// </remarks>
        [HttpGet("getMileageInOut2")]
        public async Task<IActionResult> getMileageInOut2(string date_begin, string date_end, int mcode, string cust_gbn, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalCount = string.Empty;

            List<object> items = new List<object>();
            List<object> sumItems = new List<object>();

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";
                Rmsg = "조회 기간을 설정해 주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_mcode", mcode);
                param.Add("in_cust_gbn", cust_gbn);
                param.Add("in_keyword", keyword);
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = @"
                                 SELECT T2.*
                                  FROM (SELECT to_char(ROWNUM) AS RNUM, T1.*
                                          FROM (  SELECT    M.MCODE,
                                                             M.MNAME,
                                                             X.CUST_GBN,
                                                             CASE WHEN X.CUST_GBN = '1' THEN '가입' ELSE '해지' END CUST_GBN_NM,
                                                             X.CUST_CODE,
                                                             SF_CHANGE_MASKING('NAME', X.CUST_NAME ) AS CUST_NAME,
                                                             X.CUST_MILEAGE,
                                                             Y.IN_AMT - Y.OUT_AMT AS LOG_CUST_MILEAGE, 
                                                             Y.IN_CNT, 
                                                             Y.IN_AMT,
                                                             Y.ORDER_IN_CNT,
                                                             Y.ORDER_IN_AMT,
                                                             Y.SALE_IN_CNT,
                                                             Y.SALE_IN_AMT,
                                                             Y.TAXI_IN_CNT,
                                                             Y.TAXI_IN_AMT,  
                                                             Y.ORDER_OUT_AMT,
                                                             Y.TAXI_OUT_AMT,              
                                                             Y.OUT_AMT,
                                                             nvl(Q.TERMINATE_AMT,0) TERMINATE_AMT
                                                   FROM ( 
                                                          SELECT  A.MCODE,
                                                                  '1' AS CUST_GBN,
                                                                  A.CUST_CODE,
                                                                  A.CUST_NAME,
                                                                  A.MILEAGE  AS CUST_MILEAGE
                                                          FROM   APP_CUSTOMER A
                                                          WHERE  CUST_ID_GBN <> 'Z'
                                                          AND    A.MCODE   = :in_mcode
                                                          AND   TEST_GBN = 'R' 
                                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                                          UNION ALL
                                                          SELECT A.MCODE,
                                                                 '3' AS CUST_GBN,
                                                                 A.CUST_CODE,
                                                                 A.CUST_NAME,
                                                                 A.MILEAGE  AS CUST_MILEAGE
                                                          FROM   APP_CUSTOMER_DELETED A
                                                          WHERE  CUST_ID_GBN <> 'Z'
                                                          AND   TEST_GBN = 'R' 
                                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                                          AND    A.MCODE   = :in_mcode
                                                           ) X, 
                                                        (SELECT   /*+ full(A) parallel(A 4) */     
                                                                   APP_CUST_CODE,                                                                
                                                                   SUM(1)                                         AS IN_CNT  ,
                                                                   SUM(MILEAGE_AMT )                             AS IN_AMT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'T' THEN 1 ELSE 0 END)                   AS TAXI_IN_CNT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'T' THEN MILEAGE_AMT ELSE 0 END)       AS TAXI_IN_AMT  ,
                                                                   0                    AS ORDER_OUT_AMT  ,
                                                                   0                    AS TAXI_OUT_AMT  ,
                                                                   0                    AS OUT_AMT
                                                          FROM APP_CUST_MILEAGE_REMAIN2
                                                          where  LOG_GBN       = '1'
                                                          AND    LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                          and    LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                          GROUP BY APP_CUST_CODE
                                                         UNION ALL 
                                                            SELECT       APP_CUST_CODE,                                
                                                               0                            AS IN_CNT  ,
                                                               0                            AS IN_AMT  ,
                                                               0                            AS ORDER_IN_CNT  ,
                                                               0                            AS ORDER_IN_AMT  ,
                                                               0                            AS SALE_IN_CNT  ,
                                                               0                            AS SALE_IN_AMT  ,
                                                               0                            AS TAXI_IN_CNT  ,
                                                               0                            AS TAXI_IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' THEN NVL(charge_amt,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'T' THEN NVL(charge_amt,0) ELSE 0 END)    AS TAXI_OUT_AMT  ,
                                                           SUM(NVL(charge_amt,0))                                                AS OUT_AMT
                                                          FROM    APP_CUST_MILEAGE_REMAIN2 B  
                                                          WHERE  B.LOG_GBN = '3'
                                                          AND    B.memo like '%(선입/선출차감)'
                                                          AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                          and    b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                          and    b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')                                
                                                          GROUP BY B.APP_CUST_CODE
                                                              UNION ALL 
                                                            SELECT APP_CUST_CODE,                                
                                                                   -1                           AS IN_CNT  ,
                                                                   SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                                   0                            AS ORDER_IN_CNT  ,
                                                                   0                            AS ORDER_IN_AMT  ,
                                                                   -1                           AS SALE_IN_CNT  ,
                                                                   SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                                   0                            AS TAXI_IN_CNT  ,
                                                                   0                            AS TAXI_IN_AMT  ,
                                                                   0                            AS ORDER_OUT_AMT  ,
                                                                   0                            AS TAXI_OUT_AMT  ,
                                                                   0                            AS OUT_AMT 
                                                                   from(      
                                                                    SELECT A.APP_CUST_CODE, 
                                                                           B.LOGNO ,                            
                                                                           B.MEMO,
                                                                           B.system_gbn,
                                                                           B.order_no,                            
                                                                           A.CHARGE_AMT
                                                                  FROM     APP_CUST_MILEAGE_REMAIN2 A, APP_CUST_MILEAGE_REMAIN2 B
                                                                  WHERE a.memo = to_char(b.logno)
                                                                  --AND a.memo not like '%(선입/선출차감)'
                                                                  and b.log_gbn = '1'
                                                                  AND      A.log_gbn = '3'
                                                                  AND      A.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                  and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                  ) D
                                                      GROUP BY D.APP_CUST_CODE ) Y,
                                                      (select APP_CUST_CODE, SUM(charge_amt) * -1 AS TERMINATE_AMT from app_cust_mileage_remain2
                                                         where memo like '회원탈퇴, (선입/선출차감)'
                                                         and to_char(log_date,'YYYYMMDDHH24') >= '2021080917'
                                                         GROUP BY APP_CUST_CODE) Q,
                                                         MEMBERSHIP M
                                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                                           AND X.CUST_CODE = Q.APP_CUST_CODE(+)
                                                           AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                                           AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                                           AND  X.MCODE  = M.MCODE
                                                           AND (:in_keyword IS NULL OR (X.cust_code = :in_keyword))) T1
                                                         WHERE ROWNUM <= ((:page - 1) * :row_count) + :row_count) T2
                                                 WHERE ((:page - 1) * :row_count) < RNUM
                                ";

                // 쿼리 값을 받을 임시 변수 temp 선언
                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                // 선언해놓은 list 변수에 쿼리 결과가 있는 temp 변수값을 ToList로 입력.
                items = temp.ToList();

                sql = @"
                        select count(*)
                                    FROM ( 
                                          SELECT  A.MCODE,
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND    A.MCODE   = :in_mcode
                                          AND   TEST_GBN = 'R' 
                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          UNION ALL
                                          SELECT A.MCODE,
                                                 '3' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER_DELETED A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          AND    A.MCODE   = :in_mcode
                                           ) X, 
                                        (SELECT   /*+ full(A) parallel(A 4) */     
                                                           APP_CUST_CODE,                                                                
                                                           SUM(1)                                         AS IN_CNT  ,
                                                           SUM(MILEAGE_AMT )                             AS IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'T' THEN 1 ELSE 0 END)                   AS TAXI_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'T' THEN MILEAGE_AMT ELSE 0 END)       AS TAXI_IN_AMT  ,
                                                           0                    AS ORDER_OUT_AMT  ,
                                                           0                    AS TAXI_OUT_AMT  ,
                                                           0                    AS OUT_AMT
                                                  FROM APP_CUST_MILEAGE_REMAIN2
                                                  where  LOG_GBN       = '1'
                                                  AND    LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                  and    LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                  GROUP BY APP_CUST_CODE
                                                 UNION ALL 
                                                    SELECT       APP_CUST_CODE,                                
                                                       0                            AS IN_CNT  ,
                                                       0                            AS IN_AMT  ,
                                                       0                            AS ORDER_IN_CNT  ,
                                                       0                            AS ORDER_IN_AMT  ,
                                                       0                            AS SALE_IN_CNT  ,
                                                       0                            AS SALE_IN_AMT  ,
                                                       0                            AS TAXI_IN_CNT  ,
                                                       0                            AS TAXI_IN_AMT  ,
                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' THEN NVL(charge_amt,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                   SUM(CASE WHEN SYSTEM_GBN = 'T' THEN NVL(charge_amt,0) ELSE 0 END)    AS TAXI_OUT_AMT  ,
                                                   SUM(NVL(charge_amt,0))                                                AS OUT_AMT
                                                  FROM    APP_CUST_MILEAGE_REMAIN2 B  
                                                  WHERE  B.LOG_GBN = '3'
                                                  AND    B.memo like '%(선입/선출차감)'
                                                  AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                  and    b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                  and    b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')                                
                                                  GROUP BY B.APP_CUST_CODE
                                                      UNION ALL 
                                                    SELECT APP_CUST_CODE,                                
                                                           -1                           AS IN_CNT  ,
                                                           SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                           0                            AS ORDER_IN_CNT  ,
                                                           0                            AS ORDER_IN_AMT  ,
                                                           -1                           AS SALE_IN_CNT  ,
                                                           SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                           0                            AS TAXI_IN_CNT  ,
                                                           0                            AS TAXI_IN_AMT  ,
                                                           0                            AS ORDER_OUT_AMT  ,
                                                           0                            AS TAXI_OUT_AMT  ,
                                                           0                            AS OUT_AMT 
                                                           from(      
                                                            SELECT A.APP_CUST_CODE, 
                                                                   B.LOGNO ,                            
                                                                   B.MEMO,
                                                                   B.system_gbn,
                                                                   B.order_no,                            
                                                                   A.CHARGE_AMT
                                                          FROM     APP_CUST_MILEAGE_REMAIN2 A, APP_CUST_MILEAGE_REMAIN2 B
                                                          WHERE a.memo = to_char(b.logno)
                                                          --AND a.memo not like '%(선입/선출차감)'
                                                          and b.log_gbn = '1'
                                                          AND      A.log_gbn = '3'
                                                          AND      A.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                          ) D
                                              GROUP BY D.APP_CUST_CODE ) Y
                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                           AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                           AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                           AND (:in_keyword IS NULL OR (X.cust_code = :in_keyword))
                ";

                // Total Count
                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                sql = @"
                         SELECT nvl(COUNT(*),0) AS COUNT,
                                nvl(SUM(CUST_MILEAGE),0) AS SUM_CUST_MILEAGE,
                                nvl(SUM(IN_AMT),0) - nvl(SUM(OUT_AMT),0) AS SUM_LOG_CUST_MILEAGE,
                                nvl(SUM(IN_CNT),0) AS SUM_IN_CNT,
                                nvl(SUM(IN_AMT),0) AS SUM_IN_AMT,
                                nvl(SUM(ORDER_IN_CNT),0) AS SUM_ORDER_IN_CNT,
                                nvl(SUM(ORDER_IN_AMT),0) AS SUM_ORDER_IN_AMT,
                                nvl(SUM(SALE_IN_CNT),0) AS SUM_SALE_IN_CNT,
                                nvl(SUM(SALE_IN_AMT),0) AS SUM_SALE_IN_AMT,
                                nvl(SUM(TAXI_IN_CNT),0) AS SUM_TAXI_IN_CNT,
                                nvl(SUM(TAXI_IN_AMT),0) AS SUM_TAXI_IN_AMT,
                                nvl(SUM(ORDER_OUT_AMT),0) AS SUM_ORDER_OUT_AMT,
                                nvl(SUM(TAXI_OUT_AMT),0) AS SUM_TAXI_OUT_AMT,
                                nvl(SUM(OUT_AMT),0) AS SUM_OUT_AMT,
                                nvl(SUM(TERMINATE_AMT),0) AS SUM_TERMINATE_AMT
                                FROM ( 
                                          SELECT  A.MCODE,
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND    A.MCODE   = :in_mcode
                                          AND   TEST_GBN = 'R' 
                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          UNION ALL
                                          SELECT A.MCODE,
                                                 '3' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER_DELETED A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          AND    A.MCODE   = :in_mcode
                                           ) X, 
                                        (SELECT   /*+ full(A) parallel(A 4) */     
                                                           APP_CUST_CODE,                                                                
                                                           SUM(1)                                         AS IN_CNT  ,
                                                           SUM(MILEAGE_AMT )                             AS IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'T' THEN 1 ELSE 0 END)                   AS TAXI_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'T' THEN MILEAGE_AMT ELSE 0 END)       AS TAXI_IN_AMT  ,
                                                           0                    AS ORDER_OUT_AMT  ,
                                                           0                    AS TAXI_OUT_AMT  ,
                                                           0                    AS OUT_AMT
                                                  FROM APP_CUST_MILEAGE_REMAIN2
                                                  where  LOG_GBN       = '1'
                                                  AND    LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                  and    LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                  GROUP BY APP_CUST_CODE
                                                 UNION ALL 
                                                    SELECT       APP_CUST_CODE,                                
                                                       0                            AS IN_CNT  ,
                                                       0                            AS IN_AMT  ,
                                                       0                            AS ORDER_IN_CNT  ,
                                                       0                            AS ORDER_IN_AMT  ,
                                                       0                            AS SALE_IN_CNT  ,
                                                       0                            AS SALE_IN_AMT  ,
                                                       0                            AS TAXI_IN_CNT  ,
                                                       0                            AS TAXI_IN_AMT  ,
                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' THEN NVL(charge_amt,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                   SUM(CASE WHEN SYSTEM_GBN = 'T' THEN NVL(charge_amt,0) ELSE 0 END)    AS TAXI_OUT_AMT  ,
                                                   SUM(NVL(charge_amt,0))                                                AS OUT_AMT
                                                  FROM    APP_CUST_MILEAGE_REMAIN2 B  
                                                  WHERE  B.LOG_GBN = '3'
                                                  AND    B.memo like '%(선입/선출차감)'
                                                  AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                  and    b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                  and    b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')                                
                                                  GROUP BY B.APP_CUST_CODE
                                                      UNION ALL 
                                                    SELECT APP_CUST_CODE,                                
                                                           -1                           AS IN_CNT  ,
                                                           SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                           0                            AS ORDER_IN_CNT  ,
                                                           0                            AS ORDER_IN_AMT  ,
                                                           -1                           AS SALE_IN_CNT  ,
                                                           SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                           0                            AS TAXI_IN_CNT  ,
                                                           0                            AS TAXI_IN_AMT  ,
                                                           0                            AS ORDER_OUT_AMT  ,
                                                           0                            AS TAXI_OUT_AMT  ,
                                                           0                            AS OUT_AMT 
                                                           from(      
                                                            SELECT A.APP_CUST_CODE, 
                                                                   B.LOGNO ,                            
                                                                   B.MEMO,
                                                                   B.system_gbn,
                                                                   B.order_no,                            
                                                                   A.CHARGE_AMT
                                                          FROM     APP_CUST_MILEAGE_REMAIN2 A, APP_CUST_MILEAGE_REMAIN2 B
                                                          WHERE a.memo = to_char(b.logno)
                                                          --AND a.memo not like '%(선입/선출차감)'
                                                          and b.log_gbn = '1'
                                                          AND      A.log_gbn = '3'
                                                          AND      A.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                          ) D
                                              GROUP BY D.APP_CUST_CODE ) Y,
                                              (select APP_CUST_CODE, SUM(charge_amt) * -1 AS TERMINATE_AMT from app_cust_mileage_remain2
                                                 where memo like '회원탈퇴, (선입/선출차감)'
                                                 and to_char(log_date,'YYYYMMDDHH24') >= '2021080917'
                                                 GROUP BY APP_CUST_CODE) Q
                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                           AND X.CUST_CODE = Q.APP_CUST_CODE(+)
                                           AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                           AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                           AND (:in_keyword IS NULL OR (X.cust_code = :in_keyword))
                ";

                // 합계 쿼리
                var sumTemp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                sumItems = sumTemp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Excel/getMileageInOut2 : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, data = items, sumData = sumItems });
        }

        /// <summary>
        /// 관리앱 마일리지(판매) 선입선출 대장, 대구로 통계(회계) v2
        /// </summary>
        /// <remarks>
        /// (이전테이블 조회)<br />
        /// sale_gbn 판매구분 <br />
        /// cust_gbn 가입구분 : 1. 가입, 3. 해지
        /// </remarks>
        [HttpGet("getSaleMileageInOut2")]
        public async Task<IActionResult> getSaleMileageInOut2(string date_begin, string date_end, int mcode, string sale_gbn, string cust_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();	// Object 타입으로 list 선언 (쿼리 결과물 담아서 리턴해주는 용도)

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";	// 에러코드
                Rmsg = "조회 기간을 설정해 주세요.";   // 에러메시지

                // return Ok <= 외부로 리턴해줄 때 Ok라고 적고 보내주는 것들 나열해주면 된다고 함.
                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_mcode", mcode);
                param.Add("in_sale_gbn", sale_gbn);
                param.Add("in_cust_gbn", cust_gbn);

                string sql = @"
                                 SELECT  /*+ use_hash(X Y) no_merge(X) no_merge(Y) */    M.MCODE,
                                 M.MNAME,
                                 Y.MEMO,
                                 y.gbn,
                                 TO_DATE(:in_fr_date,'YYYYMMDD')    AS FR_DATE,
                                 TO_DATE(:in_to_date,'YYYYMMDD')   AS TO_DATE,
                                 SUM(Y.REMAIN_AMT)     AS LOG_CUST_MILEAGE, 
                                 SUM(Y.IN_CNT)          AS IN_CNT , 
                                 SUM(Y.IN_AMT)          AS IN_AMT,
                                 SUM(Y.ORDER_IN_CNT)    AS ORDER_IN_CNT,
                                 SUM(Y.ORDER_IN_AMT)    AS ORDER_IN_AMT,
                                 SUM(Y.SALE_IN_CNT)     AS SALE_IN_CNT,
                                 SUM(Y.SALE_IN_AMT)     AS SALE_IN_AMT,
                                 SUM(Y.TAXI_IN_CNT)     AS TAXI_IN_CNT,
                                 SUM(Y.TAXI_IN_AMT)     AS TAXI_IN_AMT,
                                 SUM(Y.ORDER_OUT_AMT)   AS ORDER_OUT_AMT,
                                 SUM(Y.TAXI_OUT_AMT)    AS TAXI_OUT_AMT,             
                                 SUM(Y.OUT_AMT)         AS OUT_AMT
                                   FROM ( 
                                           SELECT  CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE, -- 당시 mcode 2였으나 현재 mcode 1에다가 테스트계정으로 바꾸어서 따로 추가함
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A 
                                          where   cust_code = 30490
                                          union all
                                          SELECT  CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE,
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                           AND   cust_code not in (select cust_code from (select cust_code, memo,
                                                        row_number() over (partition by cust_code order by hist_date desc) as num
                                                        from app_customer_hist -- 특정 시점에 mcode 2로 추가된 회원
                                                        where memo like '%회원사구분 :%'
                                                        and hist_date > to_date('20220224092010','YYYYMMDDHH24MISS'))
                                                        where memo like '%회원사구분 :대구 공공앱->테스트 회원사%'
                                                        and num = 1)
                                           and cust_code <> 30490
                                          UNION ALL
                                          SELECT CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE,
                                                 '3' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER_DELETED A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                           UNION ALL
                                          SELECT CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE,
                                                 '1' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                           and cust_code <> 30490
                                          AND   cust_code in (select x.cust_code from (select cust_code, memo from (select cust_code, memo,
                                                        row_number() over (partition by cust_code order by hist_date desc) as num
                                                        from app_customer_hist -- 조회 시점에 mcode 1로 빠진 회원
                                                        where memo like '%회원사구분 :%'
                                                        and hist_date > to_date('20220224092010','YYYYMMDDHH24MISS'))
                                                        where num = 1) x,
                                                        (select cust_code, memo from (select cust_code, memo,
                                                        row_number() over (partition by cust_code order by hist_date desc) as num
                                                        from app_customer_hist -- 특정 시점에 mcode 2이었던 회원
                                                        where memo like '%회원사구분 :%'
                                                        and hist_date <= to_date('20220224092010','YYYYMMDDHH24MISS'))
                                                        where num = 1) y
                                                        where x.cust_code = y.cust_code (+)
                                                        and x.memo like '%회원사구분 :대구 공공앱->테스트 회원사%'
                                                        and (y.memo is null or y.memo not like '%회원사구분 :대구 공공앱->테스트 회원사%'))) X, 
                                                ( SELECT                   X.APP_CUST_CODE, 
                                                                           X.LOGNO ,                               
                                                                           X.MEMO,  
                                                                           case when x.system_gbn = 'T' then 'T'
                                                                                when x.system_gbn = 'D' and x.order_no is null then 'A'
                                                                                when x.system_gbn = 'D' and x.order_no is not null then 'D' end gbn,                
                                                                           SUM(NVL(X.IN_AMT,0) - NVL(X.OUT_AMT,0))   AS REMAIN_AMT,            
                                                                           SUM(X.IN_CNT)            AS IN_CNT  ,
                                                                           SUM(X.IN_AMT )           AS IN_AMT  ,
                                                                           SUM(X.ORDER_IN_CNT)      AS ORDER_IN_CNT  ,
                                                                           SUM(X.ORDER_IN_AMT)      AS ORDER_IN_AMT   ,
                                                                           SUM(X.SALE_IN_CNT)       AS SALE_IN_CNT    ,
                                                                           SUM(X.SALE_IN_AMT)       AS SALE_IN_AMT    ,
                                                                           SUM(X.TAXI_IN_CNT)       AS TAXI_IN_CNT    ,
                                                                           SUM(X.TAXI_IN_AMT)       AS TAXI_IN_AMT    ,
                                                                           SUM(X.ORDER_OUT_AMT)     AS ORDER_OUT_AMT  ,
                                                                           SUM(X.TAXI_OUT_AMT)      AS TAXI_OUT_AMT   ,
                                                                           SUM(X.OUT_AMT)           AS OUT_AMT                
                                                                 FROM (
                                                                   SELECT   /*+ full(A) parallel(A 4) */     
                                                                           A.APP_CUST_CODE, 
                                                                           A.LOGNO ,                             
                                                                           case when a.system_gbn = 'T' then regexp_replace(a.memo,'[0-9|-]') else a.memo end MEMO , 
                                                                           a.system_gbn, 
                                                                           a.order_no,                            
                                                                           SUM(1)                                          AS IN_CNT  ,
                                                                           SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'T' THEN 1 ELSE 0 END)                   AS TAXI_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'T' THEN A.MILEAGE_AMT ELSE 0 END)       AS TAXI_IN_AMT  ,
                                                                           0                                                                    AS ORDER_OUT_AMT  ,
                                                                           0                                                                    AS TAXI_OUT_AMT  ,
                                                                           0                                                                    AS OUT_AMT
                                                                  FROM     APP_CUST_MILEAGE_REMAIN A
                                                                  WHERE    A.LOG_GBN       = '1'
                                                                  AND      CASE WHEN A.SYSTEM_GBN = 'D' AND A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                  AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  and      a.logno <> '1226512'
                                                                  --and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                  --and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                  GROUP BY A.APP_CUST_CODE, 
                                                                           A.LOGNO,
                                                                           a.system_gbn,
                                                                           a.order_no,
                                                                           case when a.system_gbn = 'T' then regexp_replace(a.memo,'[0-9|-]') else a.memo end
                                                                  UNION ALL 
                                                                    SELECT APP_CUST_CODE, 
                                                                           LOGNO ,                               
                                                                           MEMO,  
                                                                           SYSTEM_GBN, 
                                                                           order_no,                                
                                                                           -1                           AS IN_CNT  ,
                                                                           SUM(-1 * charge_amt )       AS IN_AMT  ,
                                                                           0                            AS ORDER_IN_CNT  ,
                                                                           0                            AS ORDER_IN_AMT  ,
                                                                           -1                           AS SALE_IN_CNT  ,
                                                                           SUM(-1 * charge_amt)        AS SALE_IN_AMT  ,
                                                                           0                            AS TAXI_IN_CNT  ,
                                                                           0                            AS TAXI_IN_AMT  ,
                                                                           0                            AS ORDER_OUT_AMT  ,
                                                                           0                            AS TAXI_OUT_AMT  ,
                                                                           0                            AS OUT_AMT 
                                                                           from(      
                                                                            SELECT A.APP_CUST_CODE, 
                                                                                   A.LOGNO ,                            
                                                                                   c.MEMO,
                                                                                   c.system_gbn,
                                                                                   c.order_no,                            
                                                                                   A.CHARGE_AMT
                                                                          FROM     APP_CUST_MILEAGE_REMAIN A, 
                                                                                    ( SELECT logno, system_gbn, memo, order_no
                                                                                      FROM  APP_CUST_MILEAGE_REMAIN
                                                                                      WHERE logno = 685327 
                                                                                      AND   LOG_GBN = '1') C
                                                                          WHERE a.logno = c.logno
                                                                          and A.LOG_GBN       = '3' 
                                                                          and a.logno = 685327 -- in (select logno from APP_CUST_MILEAGE_REMAIN where log_gbn = '3' and memo like '달서구 안심식당 인증이벤트')
                                                                          AND      CASE WHEN C.SYSTEM_GBN = 'D' AND A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                          AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                          )
                                                                  GROUP BY APP_CUST_CODE, 
                                                                           LOGNO,
                                                                           MEMO,
                                                                           system_gbn,
                                                                           order_no
                                                                  UNION ALL
                                                                    SELECT APP_CUST_CODE, 
                                                                            LOGNO,
                                                                            MEMO ,
                                                                            system_gbn,
                                                                            order_no,
                                                                            0   AS IN_CNT  ,
                                                                            0   AS IN_AMT  ,
                                                                            0   AS ORDER_IN_CNT  ,
                                                                            0   AS ORDER_IN_AMT  ,
                                                                            0   AS SALE_IN_CNT  ,
                                                                            0   AS SALE_IN_AMT  ,
                                                                            0   AS TAXI_IN_CNT  ,
                                                                            0   AS TAXI_IN_AMT  ,
                                                                            SUM(ORDER_OUT_AMT)       AS ORDER_OUT_AMT  ,
                                                                            SUM(TAXI_OUT_AMT)       AS TAXI_OUT_AMT  ,
                                                                            SUM(NVL(OUT_AMT,0))    AS OUT_AMT     
                                                                     FROM ( 
                                                                        SELECT  B.APP_CUST_CODE, 
                                                                                B.LOGNO,
                                                                                A.MEMO ,
                                                                                A.SYSTEM_GBN,
                                                                                A.order_no,
                                                                                0   AS IN_CNT  ,
                                                                                0   AS IN_AMT  ,
                                                                                0   AS ORDER_IN_CNT  ,
                                                                                0   AS ORDER_IN_AMT  ,
                                                                                0   AS SALE_IN_CNT  ,
                                                                                0   AS SALE_IN_AMT  ,
                                                                                0   AS TAXI_IN_CNT  ,
                                                                                0   AS TAXI_IN_AMT  ,
                                                                                CASE WHEN b.system_gbn = 'D' THEN NVL(B.CHARGE_AMT,0) ELSE 0 END AS ORDER_OUT_AMT  ,
                                                                                CASE WHEN b.system_gbn = 'T' THEN NVL(B.CHARGE_AMT,0) ELSE 0 END     AS TAXI_OUT_AMT  ,
                                                                                NVL(B.CHARGE_AMT,0)                                                AS OUT_AMT
                                                                      FROM      APP_CUST_MILEAGE_REMAIN B,
                                                                                (SELECT LOGNO,
                                                                                        SYSTEM_GBN, 
                                                                                        order_no,
                                                                                        case when system_gbn = 'T' then regexp_replace(memo,'[0-9|-]') else memo end MEMO
                                                                                  FROM  APP_CUST_MILEAGE_REMAIN
                                                                                  WHERE LOG_GBN = '1') A
                                                                      WHERE B.LOGNO = A.LOGNO
                                                                      AND B.LOG_GBN = '3' --and b.memo like '%(선입/선출차감)'
                                                                      --and case when b.log_date > to_date(:the_time,'YYYYMMDDHH24MISS') then b.memo else '1' end <> '회원탈퇴, (선입/선출차감)'
                                                                      --AND       CASE WHEN A.SYSTEM_GBN = 'D' AND B.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                      AND       B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                                      and      b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                      and      b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')                                
                                                                      )
                                                                      GROUP BY  APP_CUST_CODE, 
                                                                                LOGNO,
                                                                                MEMO,
                                                                                SYSTEM_GBN,
                                                                                order_no) X 
                                                                   GROUP BY    X.APP_CUST_CODE, 
                                                                               X.LOGNO ,                               
                                                                               X.MEMO,
                                                                               case when x.system_gbn = 'T' then 'T'
                                                                                    when x.system_gbn = 'D' and x.order_no is null then 'A'
                                                                                    when x.system_gbn = 'D' and x.order_no is not null then 'D' end) Y,  MEMBERSHIP M    
                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                           AND    X.CUST_GBN  LIKE :in_cust_gbn 
                                           AND    ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                           AND    X.MCODE    = M.MCODE 
                                          GROUP BY M.MCODE,
                                                   M.MNAME,
                                                   Y.MEMO,
                                                   y.gbn
                                           ORDER BY y.gbn
                                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Excel/getSaleMileageInOut2 : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 관리앱 마일리지(판매) 선입선출 대장, 대구로 통계(회계) v3
        /// </summary>
        /// <remarks>
        /// * 전일내역까지 조회가능 <br />
        /// sale_gbn 판매구분 : Y,N,% <br />
        /// cust_gbn 가입구분 : 1. 가입, 3. 해지, %. 전체 <br />
        /// [response] <br />
        /// 시작일 FR_DATE <br />
        /// 종료일 TO_DATE <br />
        /// 구분 GBN_NM <br />
        /// 판매내역 CUST_MILEAGE <br />
        /// 대장잔액 LOG_CUST_MILEAGE <br />
        /// 충전건수 IN_CNT <br />
        /// 충전합계 IN_AMT <br />
        /// 주문충전건수 ORDER_IN_CNT <br />
        /// 주문충전금액 ORDER_IN_AMT <br />
        /// 판매충전건수 SALE_IN_CNT <br />
        /// 판매충전금액 SALE_IN_AMT <br />
        /// 택시충전건수 TAXI_IN_CNT <br />
        /// 택시충전금액 TAXI_IN_AMT <br />
        /// 주문차감금액 ORDER_OUT_AMT <br />
        /// 택시차감금액(사용) TAXI_OUT_AMT1 <br />
        /// 택시차감금액(적립금반납) TAXI_OUT_AMT2 <br />
        /// 차감합계 OUT_AMT <br />
        /// <br />
        /// </remarks>
        [HttpGet("getSaleMileageInOut3")]
        public async Task<IActionResult> getSaleMileageInOut3(string date_begin, string date_end, int mcode, string sale_gbn, string cust_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();	// Object 타입으로 list 선언 (쿼리 결과물 담아서 리턴해주는 용도)

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";	// 에러코드
                Rmsg = "조회 기간을 설정해 주세요.";   // 에러메시지

                // return Ok <= 외부로 리턴해줄 때 Ok라고 적고 보내주는 것들 나열해주면 된다고 함.
                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_mcode", mcode);
                param.Add("in_sale_gbn", sale_gbn);
                param.Add("in_cust_gbn", cust_gbn);

                string sql = @"
                                 SELECT  /*+ use_hash(X Y) no_merge(X) no_merge(Y) */    M.MCODE,
                                 M.MNAME,
                                 Y.MEMO,
                                 y.gbn,
                                 case when y.gbn = 'A' then '판매'
                                      when y.gbn = 'D' then '주문'
                                      when y.gbn = 'T' then '택시' end GBN_NM,
                                 TO_DATE(:in_fr_date,'YYYYMMDD')    AS FR_DATE,
                                 TO_DATE(:in_to_date,'YYYYMMDD')   AS TO_DATE,
                                 SUM(Y.REMAIN_AMT)     AS LOG_CUST_MILEAGE, 
                                 SUM(Y.IN_CNT)          AS IN_CNT , 
                                 SUM(Y.IN_AMT)          AS IN_AMT,
                                 SUM(Y.ORDER_IN_CNT)    AS ORDER_IN_CNT,
                                 SUM(Y.ORDER_IN_AMT)    AS ORDER_IN_AMT,
                                 SUM(Y.SALE_IN_CNT)     AS SALE_IN_CNT,
                                 SUM(Y.SALE_IN_AMT)     AS SALE_IN_AMT,
                                 SUM(Y.TAXI_IN_CNT)     AS TAXI_IN_CNT,
                                 SUM(Y.TAXI_IN_AMT)     AS TAXI_IN_AMT,
                                 SUM(Y.ORDER_OUT_AMT)   AS ORDER_OUT_AMT,
                                 SUM(Y.TAXI_OUT_AMT1)    AS TAXI_OUT_AMT1,   
                                 SUM(Y.TAXI_OUT_AMT2)    AS TAXI_OUT_AMT2,            
                                 SUM(Y.OUT_AMT)         AS OUT_AMT
                                   FROM ( SELECT  :in_mcode MCODE,
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND    A.MCODE   = :in_mcode
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          UNION ALL
                                          SELECT :in_mcode MCODE,
                                                 '3' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER_DELETED A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          AND    A.MCODE   = :in_mcode
                                           ) X, 
                                                ( SELECT                   X.APP_CUST_CODE, 
                                                                           X.LOGNO ,                               
                                                                           X.MEMO,  
                                                                           case when x.system_gbn = 'T' then 'T'
                                                                                when x.system_gbn = 'D' and x.order_no is null then 'A'
                                                                                when x.system_gbn = 'D' and x.order_no is not null then 'D' end gbn,                
                                                                           SUM(NVL(X.IN_AMT,0) - NVL(X.OUT_AMT,0))   AS REMAIN_AMT,            
                                                                           SUM(X.IN_CNT)            AS IN_CNT  ,
                                                                           SUM(X.IN_AMT )           AS IN_AMT  ,
                                                                           SUM(X.ORDER_IN_CNT)      AS ORDER_IN_CNT  ,
                                                                           SUM(X.ORDER_IN_AMT)      AS ORDER_IN_AMT   ,
                                                                           SUM(X.SALE_IN_CNT)       AS SALE_IN_CNT    ,
                                                                           SUM(X.SALE_IN_AMT)       AS SALE_IN_AMT    ,
                                                                           SUM(X.TAXI_IN_CNT)       AS TAXI_IN_CNT    ,
                                                                           SUM(X.TAXI_IN_AMT)       AS TAXI_IN_AMT    ,
                                                                           SUM(X.ORDER_OUT_AMT)     AS ORDER_OUT_AMT  ,
                                                                           SUM(X.TAXI_OUT_AMT1)      AS TAXI_OUT_AMT1   ,
                                                                           SUM(X.TAXI_OUT_AMT2)      AS TAXI_OUT_AMT2   ,
                                                                           SUM(X.OUT_AMT)           AS OUT_AMT                
                                                                 FROM (
                                                                   SELECT   /*+ full(A) parallel(A 4) */     
                                                                           A.APP_CUST_CODE, 
                                                                           A.LOGNO ,                             
                                                                           case when a.system_gbn = 'T' then regexp_replace(a.memo,'[0-9|-]') else a.memo end MEMO , 
                                                                           a.system_gbn, 
                                                                           a.order_no,                            
                                                                           SUM(1)                                          AS IN_CNT  ,
                                                                           SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'T' THEN 1 ELSE 0 END)                   AS TAXI_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'T' THEN A.MILEAGE_AMT ELSE 0 END)       AS TAXI_IN_AMT  ,
                                                                           0                                                                    AS ORDER_OUT_AMT  ,
                                                                           0                                                                    AS TAXI_OUT_AMT1  ,
                                                                           0                                                                    AS TAXI_OUT_AMT2  ,
                                                                           0                                                                    AS OUT_AMT
                                                                  FROM     APP_CUST_MILEAGE_REMAIN2 A
                                                                  WHERE    A.LOG_GBN       = '1'
                                                                  AND      CASE WHEN A.SYSTEM_GBN = 'D' AND A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                  AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                  --and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                  GROUP BY A.APP_CUST_CODE, 
                                                                           A.LOGNO,
                                                                           a.system_gbn,
                                                                           a.order_no,
                                                                           case when a.system_gbn = 'T' then regexp_replace(a.memo,'[0-9|-]') else a.memo end
                                                                  UNION ALL 
                                                                    SELECT APP_CUST_CODE, 
                                                                           LOGNO ,                               
                                                                           MEMO,  
                                                                           SYSTEM_GBN, 
                                                                           order_no,                                
                                                                           -1                           AS IN_CNT  ,
                                                                           SUM(-1 * charge_amt )       AS IN_AMT  ,
                                                                           0                            AS ORDER_IN_CNT  ,
                                                                           0                            AS ORDER_IN_AMT  ,
                                                                           -1                           AS SALE_IN_CNT  ,
                                                                           SUM(-1 * charge_amt)        AS SALE_IN_AMT  ,
                                                                           0                            AS TAXI_IN_CNT  ,
                                                                           0                            AS TAXI_IN_AMT  ,
                                                                           0                            AS ORDER_OUT_AMT  ,
                                                                           0                            AS TAXI_OUT_AMT1  ,
                                                                           0                            AS TAXI_OUT_AMT2  ,
                                                                           0                            AS OUT_AMT 
                                                                           from(      
                                                                            SELECT A.APP_CUST_CODE, 
                                                                                   B.LOGNO ,                            
                                                                                   B.MEMO,
                                                                                   B.system_gbn,
                                                                                   B.order_no,                            
                                                                                   A.CHARGE_AMT
                                                                          FROM     APP_CUST_MILEAGE_REMAIN2 A, APP_CUST_MILEAGE_REMAIN2 B
                                                                          WHERE a.memo = to_char(b.logno)
                                                                          --AND a.memo not like '%(선입/선출차감)'
                                                                          and b.log_gbn = '1'
                                                                          AND      A.log_gbn = '3'
                                                                          AND      CASE WHEN B.SYSTEM_GBN = 'D' AND B.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                          AND      A.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                          )
                                                                  GROUP BY APP_CUST_CODE, 
                                                                           LOGNO,
                                                                           MEMO,
                                                                           system_gbn,
                                                                           order_no
                                                                  UNION ALL
                                                                    SELECT  B.APP_CUST_CODE, 
                                                                                B.LOGNO,
                                                                                A.MEMO ,
                                                                                A.SYSTEM_GBN,
                                                                                A.order_no,
                                                                                0   AS IN_CNT  ,
                                                                                0   AS IN_AMT  ,
                                                                                0   AS ORDER_IN_CNT  ,
                                                                                0   AS ORDER_IN_AMT  ,
                                                                                0   AS SALE_IN_CNT  ,
                                                                                0   AS SALE_IN_AMT  ,
                                                                                0   AS TAXI_IN_CNT  ,
                                                                                0   AS TAXI_IN_AMT  ,
                                                                                SUM(CASE WHEN b.system_gbn = 'D' THEN NVL(B.CHARGE_AMT,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                                                SUM(CASE WHEN b.system_gbn = 'T' 
                                                                                         and b.memo like  '택시 [%] 에서 사용, (선입/선출차감)' THEN NVL(B.CHARGE_AMT,0) ELSE 0 END)     AS TAXI_OUT_AMT1  ,
                                                                                SUM(CASE WHEN b.system_gbn = 'T'
                                                                                         and b.memo not like  '택시 [%] 에서 사용, (선입/선출차감)' THEN NVL(B.CHARGE_AMT,0) ELSE 0 END)     AS TAXI_OUT_AMT2  ,
                                                                                SUM(NVL(B.CHARGE_AMT,0))                                                AS OUT_AMT
                                                                      FROM      APP_CUST_MILEAGE_REMAIN2 B,
                                                                                (SELECT LOGNO,
                                                                                        SYSTEM_GBN, 
                                                                                        order_no,
                                                                                        case when system_gbn = 'T' then regexp_replace(memo,'[0-9|-]') else memo end MEMO
                                                                                  FROM  APP_CUST_MILEAGE_REMAIN2
                                                                                  WHERE LOG_GBN = '1') A
                                                                      WHERE B.LOGNO = A.LOGNO
                                                                      AND B.LOG_GBN = '3'
                                                                      AND B.memo like '%(선입/선출차감)'
                                                                      AND       B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                                      and      b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                      and      b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')     
                                                                      GROUP BY  B.APP_CUST_CODE, 
                                                                                B.LOGNO,
                                                                                A.MEMO ,
                                                                                A.SYSTEM_GBN,
                                                                                A.order_no) X 
                                                                   GROUP BY    X.APP_CUST_CODE, 
                                                                               X.LOGNO ,                               
                                                                               X.MEMO,
                                                                               case when x.system_gbn = 'T' then 'T'
                                                                                    when x.system_gbn = 'D' and x.order_no is null then 'A'
                                                                                    when x.system_gbn = 'D' and x.order_no is not null then 'D' end) Y,  MEMBERSHIP M    
                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                           AND    X.CUST_GBN  LIKE :in_cust_gbn 
                                           AND    ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                           AND    X.MCODE    = M.MCODE 
                                          GROUP BY M.MCODE,
                                                   M.MNAME,
                                                   Y.MEMO,
                                                   y.gbn
                                           ORDER BY y.gbn
                                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Excel/getSaleMileageInOut3 : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        #endregion


        #region[대구시 요청자료]

        /// <summary>
        /// 대구시 요청자료 - 시간대별 연령 통계O
        /// </summary>
        [HttpGet("getTimeOrderAge")]
        public async Task<IActionResult> getTimeOrderAge(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  SELECT TO_CHAR (order_time, 'HH24') AS HH, COUNT (*) COUNT, 
                                          count(case when birthday <= 1 then 1 end) as a,
                                          count(case when birthday = 2 then 1 end) as b,
                                          count(case when birthday = 3 then 1 end) as c,
                                          count(case when birthday = 4 then 1 end) as d,
                                          count(case when birthday = 5 then 1 end) as e,
                                          count(case when birthday = 6 then 1 end) as f,
                                          count(case when birthday = 7 then 1 end) as g,
                                          count(case when birthday = 8 then 1 end) as h,
                                          count(case when birthday >= 9 then 1 end) as i,
                                          count(case when birthday is null then 1 end) as j
                                    FROM (SELECT a.order_time, ccode
                                            FROM dorder a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end
                                          UNION ALL
                                          SELECT a.order_time, ccode
                                            FROM dorder_past a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end) a, 
                                          (select cust_code, trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                                                        birthday from app_customer 
                                          union all 
                                          select cust_code, trunc((to_number(to_char(SYSDATE,'yyyy')) - TO_NUMBER (SUBSTR (birthday, 1, 4)) + 1) /10)
                                                                        birthday from app_customer_deleted) b
                                where a.ccode = b.cust_code
                                GROUP BY CUBE (TO_CHAR (order_time, 'HH24'))
                                ORDER BY (TO_CHAR (order_time, 'HH24'))
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 대구시 요청자료 - 시간대별 성별 통계O
        /// </summary>
        [HttpGet("getTimeOrderGender")]
        public async Task<IActionResult> getTimeOrderGender(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  SELECT TO_CHAR (order_time, 'HH24') AS HH, COUNT (*) COUNT,
                                          count(case when gender = 'M' then 1 end) as male,
                                          count(case when gender = 'F' then 1 end) as female, 
                                          count(case when gender = 'Z' then 1 end) as other, --성별 미선택
                                          count(case when gender is null then 1 end) as a
                                    FROM (SELECT a.order_time, ccode
                                            FROM dorder a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end
                                          UNION ALL
                                          SELECT a.order_time, ccode
                                            FROM dorder_past a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end) a, 
                                          (select cust_code, gender from app_customer 
                                          union all 
                                          select cust_code, gender from app_customer_deleted) b
                                where a.ccode = b.cust_code
                                GROUP BY CUBE (TO_CHAR (order_time, 'HH24'))
                                ORDER BY (TO_CHAR (order_time, 'HH24'))
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 대구시 요청자료 - 시간대별 군구별 통계O
        /// </summary>
        [HttpGet("getTimeOrderCategory")]
        public async Task<IActionResult> getTimeOrderCategory(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                string sql = @"
                                  SELECT TO_CHAR (order_time, 'HH24') AS HH, COUNT (*) COUNT, 
                                          count(case when dest_gungu = '달서구' then 1 end) as 달서구,
                                          count(case when dest_gungu = '달성군' then 1 end) as 달성군,
                                          count(case when dest_gungu = '수성구' then 1 end) as 수성구,
                                          count(case when dest_gungu = '남구' then 1 end) as 남구,
                                          count(case when dest_gungu = '서구' then 1 end) as 서구,
                                          count(case when dest_gungu = '중구' then 1 end) as 중구,
                                          count(case when dest_gungu = '동구' then 1 end) as 동구,
                                          count(case when dest_gungu = '북구' then 1 end) as 북구,
                                          count(case when dest_gungu is null then 1 end) as 포장
                                    FROM (SELECT a.order_time, a.dest_gungu
                                            FROM dorder a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end
                                          UNION ALL
                                          SELECT a.order_time, a.dest_gungu
                                            FROM dorder_past a, shop_info b, callcenter c
                                           WHERE     a.shop_cd = b.shop_cd
                                                 AND a.cccode = c.cccode
                                                 AND c.mcode = 2
                                                 AND a.order_time >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.test_gbn = 'N'
                                                 and a.status not in ('80','20')
                                                 and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                 AND TO_CHAR (A.ORDER_TIME, 'yyyyMMdd') BETWEEN :date_begin
                                                              AND :date_end)
                                GROUP BY CUBE (TO_CHAR (order_time, 'HH24'))
                                ORDER BY (TO_CHAR (order_time, 'HH24'))
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 대구시 요청자료 - 일자별 성별 주문수O
        /// </summary>
        [HttpGet("getDailyGenderToOrder")]
        public async Task<IActionResult> getDailyGenderToOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT order_date,  
                                       sum(case when gender is null then 1 end) nodata,
                                       sum(case when gender = 'M' then 1 end) male,
                                       sum(case when gender = 'F' then 1 end) female,
                                       sum(case when gender = 'Z' then 1 end) other -- 성별 미선택
                                FROM (SELECT gender, STATUS, order_date
                                    FROM (SELECT cust_code,
                                                    gender
                                            FROM app_customer
                                            UNION ALL
                                            SELECT cust_code,
                                                    gender
                                            FROM app_customer_deleted) a, 
                                        (select ccode, STATUS, to_char(order_time,'YYYYMMDD') order_date from dorder a, callcenter b
                                        where a.cccode = b.cccode
                                            AND b.mcode = 2
                                            AND a.order_time between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            AND a.TEST_GBN = 'N'
                                            and a.status not in ('80','20')
                                            and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                        union all
                                        select ccode, STATUS, to_char(order_time,'YYYYMMDD') order_date from dorder_past a, callcenter b
                                        where a.cccode = b.cccode
                                            AND b.mcode = 2
                                            AND a.order_time between to_date(case when :date_begin = '20210809' then '20210809170000' else :date_begin || '000000' end
                                                                            , 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            AND a.TEST_GBN = 'N'
                                            and a.status not in ('80','20')
                                            and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')) b
                                    where a.cust_code = b.ccode
                                    )
                                GROUP BY order_date
                                order by order_date desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 대구시 요청자료 - 일자별 군구별 주문수O
        /// </summary>
        [HttpGet("getDailyGunguToOrder")]
        public async Task<IActionResult> getDailyGunguToOrder(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT order_date,
                                       count(case when dest_gungu = '달서구' then 1 end) as 달서구,
                                          count(case when dest_gungu = '달성군' then 1 end) as 달성군,
                                          count(case when dest_gungu = '수성구' then 1 end) as 수성구,
                                          count(case when dest_gungu = '남구' then 1 end) as 남구,
                                          count(case when dest_gungu = '서구' then 1 end) as 서구,
                                          count(case when dest_gungu = '중구' then 1 end) as 중구,
                                          count(case when dest_gungu = '동구' then 1 end) as 동구,
                                          count(case when dest_gungu = '북구' then 1 end) as 북구,
                                          count(case when dest_gungu is null then 1 end) as 포장
                                FROM (select ccode, dest_gungu, to_char(order_time,'YYYYMMDD') order_date from dorder a, callcenter b
                                        where a.cccode = b.cccode
                                            AND b.mcode = 2
                                            AND a.order_time between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            AND a.TEST_GBN = 'N'
                                            and a.status not in ('80','20')
                                            and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                        union all
                                        select ccode, dest_gungu, to_char(order_time,'YYYYMMDD') order_date from dorder_past a, callcenter b
                                        where a.cccode = b.cccode
                                            AND b.mcode = 2
                                            AND a.order_time between to_date(:date_begin || '000000', 'YYYYMMDDHH24MISS') and to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                            AND a.order_time >= to_date('2021080917','YYYYMMDDHH24')
                                            AND a.TEST_GBN = 'N'
                                            and a.status not in ('80','20')
                                            and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')) 
                                GROUP BY order_date
                                order by order_date desc
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        #endregion

        #region[가맹점 카드단말기 신청여부vba]
        /// <summary>
        /// 가맹점 카드단말기 신청여부vba
        /// </summary>
        [HttpGet("getShopCardReaderYn")]
        public async Task<IActionResult> getShopCardReaderYn(string yn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("yn", yn);
                //param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                select c.child_meal_recruit_date, a.shop_cd, a.shop_name, c.child_meal_recruit_yn
                                from shop_info a, callcenter b, shop_info_add c
                                where a.cccode = b.cccode
                                and b.mcode = 2 
                                and a.shop_cd = c.shop_cd
                                and c.child_meal_recruit_date is not null
                                and nvl(c.child_meal_recruit_yn,'%') like :yn
                                order by c.child_meal_recruit_date desc
                            ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 가맹점 카드단말기 신청2vba
        /// </summary>
        [HttpGet("getShopCardReader2")]
        public async Task<IActionResult> getShopCardReader2(string sub_gbn, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_sub_gbn", sub_gbn);
                param.Add("in_date_begin", date_begin);
                param.Add("in_date_end", date_end);

                db.Open();

                string sql = @"
                                select /*+ index(a card_terminal_sub_pk)*/
                                       a.sub_seq, a.sub_date,
                                       case when a.sub_gbn = '00' then '신규신청'
                                            when a.sub_gbn = '01' then '변경신청'
                                            when a.sub_gbn = '02' then 'A/S문의'
                                            when a.sub_gbn = '03' then '기타문의'
                                            when a.sub_gbn = '90' then '관심없어요' end sub_gbn, 
                                       b.shop_cd, b.shop_name
                                from card_terminal_sub a, shop_info b, callcenter c
                                where a.shop_cd = b.shop_cd
                                and b.cccode = c.cccode
                                and c.mcode = 2
                                and a.sub_date between to_date(:in_date_begin,'YYYYMMDD') and to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                and a.sub_gbn like :in_sub_gbn
                            ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }
        #endregion[가맹점 카드단말기 신청여부vba]

        #region[가맹점 자체할인쿠폰 사용 주문 통계vba]
        /// <summary>
        /// 해당기간 이벤트 진행중 가맹점 주문 건수,금액 및 가맹점자체쿠폰 사용여부 vba
        /// </summary>
        [HttpGet("getSECouponOrderCnt")]
        public async Task<IActionResult> getSECouponOrderCnt(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_date_begin", date_begin);
                param.Add("in_date_end", date_end);

                db.Open();

                string sql = @"
                                select x.shop_cd, z.shop_name,
                                        count(case when x.status = '40' then 1 end) comp_cnt,
                                        sum(case when x.status = '40' then tot_amt end) comp_amt, --완료 주문금액
                                        count(case when x.status = '40' and x.shop_coupon_no is not null then 1 end) comp_sec_cnt, --가맹점쿠폰 사용 완료 주문건수
                                        sum(case when x.status = '40' and x.shop_coupon_no is not null then tot_amt end) comp_sec_amt, --가맹점쿠폰 사용 완료 주문금액
                                        count(case when x.status = '50' then 1 end) canc_cnt,
                                        sum(case when x.status = '50' then tot_amt end) canc_amt, --취소 주문금액
                                        count(case when x.status = '50' and x.shop_coupon_no is not null then 1 end) canc_sec_cnt,
                                        sum(case when x.status = '50' and x.shop_coupon_no is not null then tot_amt end) canc_sec_amt --가맹점쿠폰 사용 취소 주문금액
                                from(select a.*
                                    from dorder a, callcenter c
                                    where a.cccode = c.cccode
                                    and c.mcode = 2
                                    and a.test_gbn = 'N'
                                    --and a.shop_cd = :in_shop_cd
                                    and a.order_time between to_date(:in_date_begin,'YYYYMMDD') and to_date(:in_date_end || '235959', 'YYYYMMDDHH24MISS')
                                    and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                    union all
                                    select a.*
                                    from dorder_past a, callcenter c
                                    where a.cccode = c.cccode
                                    and c.mcode = 2
                                    and a.test_gbn = 'N'
                                    --and a.shop_cd = :in_shop_cd
                                    and a.order_time between to_date(:in_date_begin,'YYYYMMDD') and to_date(:in_date_end || '235959', 'YYYYMMDDHH24MISS')
                                    and a.order_time > to_date('2021080917','YYYYMMDDHH24')
                                    and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')) x,
                                    (select distinct b.shop_cd
                                    from(SELECT to_char(daily,'YYYYMMDD') dt FROM (SELECT to_date('20210101','YYYYMMDD') + LEVEL - 1 AS daily
                                        FROM dual
                                        CONNECT BY LEVEL <= (to_date('30211231','YYYYMMDD') - to_date('20210101','YYYYMMDD') + 1))
                                        WHERE daily between :in_date_begin and :in_date_end) a, shop_event_coupon_settings b
                                        where a.dt between b.display_st_date and b.display_end_date) Y,
                                    shop_info Z
                                where x.shop_cd = y.shop_cd
                                AND x.shop_cd = Z.shop_cd
                                group by x.shop_cd, Z.shop_name
                            ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 가맹점 일별 주문 건수,금액 및 가맹점자체쿠폰 사용여부, 이벤트 여부 vba
        /// </summary>
        [HttpGet("getDailySECouponOrderCnt")]
        public async Task<IActionResult> getDailySECouponOrderCnt(string in_date_begin, string in_date_end, string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_shop_cd", shop_cd);
                param.Add("in_date_begin", in_date_begin);
                param.Add("in_date_end", in_date_end);

                db.Open();

                string sql = @"
                                select t1.*,
                                       (select count(*)
                                       from shop_event_coupon_settings
                                       where shop_cd = t1.shop_cd
                                       and use_gbn = 'Y'
                                       and t1.dt between display_st_date and display_end_date) use_gbn_Y,
                                       (select count(*)
                                       from shop_event_coupon_settings
                                       where shop_cd = t1.shop_cd
                                       and use_gbn = 'N'
                                       and t1.dt between display_st_date and display_end_date) use_gbn_N
                                from(select x.shop_cd, y.shop_name, to_char(x.order_time,'YYYYMMDD') dt, 
                                           count(case when x.status = '40' then 1 end) comp_cnt,
                                           sum(case when x.status = '40' then tot_amt end) comp_amt, --완료 주문금액
                                           count(case when x.status = '40' and x.shop_coupon_no is not null then 1 end) comp_sec_cnt, --가맹점쿠폰 사용 완료 주문건수
                                           sum(case when x.status = '40' and x.shop_coupon_no is not null then tot_amt end) comp_sec_amt, --가맹점쿠폰 사용 완료 주문금액
                                           count(case when x.status = '50' then 1 end) canc_cnt,
                                           sum(case when x.status = '50' then tot_amt end) canc_amt, --취소 주문금액
                                           count(case when x.status = '50' and x.shop_coupon_no is not null then 1 end) canc_sec_cnt,
                                           sum(case when x.status = '50' and x.shop_coupon_no is not null then tot_amt end) canc_sec_amt --가맹점쿠폰 사용 취소 주문금액
                                    from(select a.*
                                        from dorder a, callcenter c
                                        where a.cccode = c.cccode
                                        and c.mcode = 2
                                        and a.test_gbn = 'N'
                                        and a.shop_cd = :in_shop_cd
                                        and a.order_time between to_date(:in_date_begin,'YYYYMMDD') and to_date(:in_date_end || '235959', 'YYYYMMDDHH24MISS')
                                        and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                        union all
                                        select a.*
                                        from dorder_past a, callcenter c
                                        where a.cccode = c.cccode
                                        and c.mcode = 2
                                        and a.test_gbn = 'N'
                                        and a.shop_cd = :in_shop_cd
                                        and a.order_time between to_date(:in_date_begin,'YYYYMMDD') and to_date(:in_date_end || '235959', 'YYYYMMDDHH24MISS')
                                        and a.order_time > to_date('2021080917','YYYYMMDDHH24')
                                        and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')) x,
                                        shop_info y
                                    where x.shop_cd = y.shop_cd
                                    group by x.shop_cd, y.shop_name, to_char(x.order_time,'YYYYMMDD')) t1
                                order by t1.dt desc
                            ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }
        #endregion[가맹점 자체할인쿠폰 사용 주문 통계vba]

        #region[전통시장 통계vba]
        /// <summary>
        /// 시장 목록조회(드롭다운)
        /// </summary>
        [HttpGet("subTema")]
        public async Task<IActionResult> getSubTema(string temaCode, string useGbn, string testYn)
        {
            string Rcode;
            string Rmsg;
            List<Object> items = new List<Object>();

            string mcode = string.Empty;

            if (testYn == "Y")
            {
                mcode = "1";
            }
            else if (testYn == "N")
            {
                mcode = "2";
            }

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_mcode", mcode);
            param.Add("in_use_gbn", useGbn);

            string sql = @$"
                            select a.m_shop_cd ""subTemaCode"", b.shop_name ""temaName""
                            from trad_shop a, shop_info b, callcenter c
                            where a.m_shop_cd = b.shop_cd
                            and b.cccode = c.cccode
                            and c.mcode = :in_mcode
                            and b.use_gbn = :in_use_gbn
                            order by b.shop_name
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 일별 전통시장별 주문 vba
        /// </summary>
        /// <remarks>
        /// * 모든 종류의 취소주문을 포함
        /// </remarks>
        [HttpGet("getDailySubThemaOrder")]
        public async Task<IActionResult> getDailySubThemaOrder(string date_begin, string date_end, string thema_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_date_begin", date_begin);
                param.Add("in_date_end", date_end);
                param.Add("in_thema_cd", thema_cd);

                db.Open();

                string sql = @"
                                SELECT THEMA_CD , THEMA_NAME , DT , COUNT(*) AS CNT, COUNT(CASE WHEN STATUS = '40' THEN 1 END) AS COMP_CNT, COUNT(CASE WHEN STATUS = '50' THEN 1 END) AS CANCEL_CNT
                                from(SELECT X.SHOP_CD THEMA_CD, X.SHOP_NAME THEMA_NAME, TO_CHAR(A.ORDER_TIME,'YYYYMMDD') AS DT, A.STATUS
                                    FROM dorder A,
                                         CALLCENTER C,
                                         SHOP_INFO B,
                                         SHOP_INFO X,
                                         SHOP_INFO_ADD Z
                                    WHERE A.SHOP_CD = B.SHOP_CD
                                    AND   B.SHOP_CD = Z.SHOP_CD
                                    AND   A.CCCODE = C.CCCODE
                                    and   A.TEST_GBN = 'N'
                                    AND   A.ORDER_TIME BETWEEN to_date(:in_date_begin,'YYYYMMDD') AND to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                    AND   C.MCODE = '2'
                                    AND   Z.M_SHOP_CD = X.SHOP_CD
                                    AND   Z.M_SHOP_CD LIKE CASE WHEN :in_thema_cd IS NULL THEN '%' ELSE :in_thema_cd END
                                    AND   (B.ITEM_CD = '1033' OR B.ITEM_CD2 = '1033' OR B.ITEM_CD3 = '1033')
                                    union all
                                    SELECT X.SHOP_CD THEMA_CD, X.SHOP_NAME THEMA_NAME, TO_CHAR(A.ORDER_TIME,'YYYYMMDD') AS DT, A.STATUS
                                    FROM dorder_past A,
                                         CALLCENTER C,
                                         SHOP_INFO B,
                                         SHOP_INFO X,
                                         SHOP_INFO_ADD Z
                                    WHERE A.SHOP_CD = B.SHOP_CD
                                    AND   B.SHOP_CD = Z.SHOP_CD
                                    AND   A.CCCODE = C.CCCODE
                                    and   A.TEST_GBN = 'N'
                                    AND   A.ORDER_TIME BETWEEN to_date(:in_date_begin,'YYYYMMDD') AND to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                    AND   C.MCODE = '2'
                                    AND   Z.M_SHOP_CD = X.SHOP_CD
                                    AND   Z.M_SHOP_CD LIKE CASE WHEN :in_thema_cd IS NULL THEN '%' ELSE :in_thema_cd END
                                    AND   (B.ITEM_CD = '1033' OR B.ITEM_CD2 = '1033' OR B.ITEM_CD3 = '1033')
                                    )
                                GROUP BY THEMA_CD, THEMA_NAME, DT
                                ORDER BY THEMA_CD, DT
                            ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 일별 (전통시장)가맹점별 주문 vba
        /// </summary>
        /// <remarks>
        /// * 모든 종류의 취소주문을 포함
        /// </remarks>
        [HttpGet("getDailySubThemaShopOrder")]
        public async Task<IActionResult> getDailySubThemaShopOrder(string date_begin, string date_end, string thema_cd, string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_thema_cd", thema_cd);
                param.Add("in_shop_cd", shop_cd);
                param.Add("in_date_begin", date_begin);
                param.Add("in_date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT  DT , THEMA_CD , THEMA_NAME , SHOP_CD, SHOP_NAME, COUNT(*) AS CNT, COUNT(CASE WHEN STATUS = '40' THEN 1 END) AS COMP_CNT, COUNT(CASE WHEN STATUS = '50' THEN 1 END) AS CANCEL_CNT
                                from(SELECT X.SHOP_CD THEMA_CD, X.SHOP_NAME THEMA_NAME, B.SHOP_CD, B.SHOP_NAME, TO_CHAR(A.ORDER_TIME,'YYYYMMDD') AS DT, A.STATUS
                                    FROM dorder A,
                                         CALLCENTER C,
                                         SHOP_INFO B,
                                         SHOP_INFO X,
                                         SHOP_INFO_ADD Z
                                    WHERE A.SHOP_CD = B.SHOP_CD
                                    AND   B.SHOP_CD = Z.SHOP_CD
                                    AND   A.CCCODE = C.CCCODE
                                    and   A.TEST_GBN = 'N'
                                    AND   A.ORDER_TIME BETWEEN to_date(:in_date_begin,'YYYYMMDD') AND to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                    AND   C.MCODE = '2'
                                    AND   Z.M_SHOP_CD LIKE CASE WHEN :in_thema_cd IS NULL THEN '%' ELSE :in_thema_cd END
                                    AND   B.SHOP_CD LIKE CASE WHEN :in_shop_cd IS NULL THEN '%' ELSE :in_shop_cd END
                                    AND   Z.M_SHOP_CD = X.SHOP_CD
                                    AND   (B.ITEM_CD = '1033' OR B.ITEM_CD2 = '1033' OR B.ITEM_CD3 = '1033')
                                    union all
                                    SELECT X.SHOP_CD THEMA_CD, X.SHOP_NAME THEMA_NAME, B.SHOP_CD, B.SHOP_NAME, TO_CHAR(A.ORDER_TIME,'YYYYMMDD') AS DT, A.STATUS
                                    FROM dorder_past A,
                                         CALLCENTER C,
                                         SHOP_INFO B,
                                         SHOP_INFO X,
                                         SHOP_INFO_ADD Z
                                    WHERE A.SHOP_CD = B.SHOP_CD
                                    AND   B.SHOP_CD = Z.SHOP_CD
                                    AND   A.CCCODE = C.CCCODE
                                    and   A.TEST_GBN = 'N'
                                    AND   A.ORDER_TIME BETWEEN to_date(:in_date_begin,'YYYYMMDD') AND to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                    AND   C.MCODE = '2'
                                    AND   Z.M_SHOP_CD LIKE CASE WHEN :in_thema_cd IS NULL THEN '%' ELSE :in_thema_cd END
                                    AND   B.SHOP_CD LIKE CASE WHEN :in_shop_cd IS NULL THEN '%' ELSE :in_shop_cd END
                                    AND   Z.M_SHOP_CD = X.SHOP_CD
                                    AND   (B.ITEM_CD = '1033' OR B.ITEM_CD2 = '1033' OR B.ITEM_CD3 = '1033'))
                                GROUP BY DT, THEMA_CD, THEMA_NAME,SHOP_CD, SHOP_NAME 
                                ORDER BY THEMA_CD, DT
                            ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// (전통시장)가맹점별 주문 vba
        /// </summary>
        /// <remarks>
        /// * 모든 종류의 취소주문을 포함
        /// </remarks>
        [HttpGet("getSubThemaShopOrder")]
        public async Task<IActionResult> getSubThemaShopOrder(string date_begin, string date_end, string thema_cd, string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_thema_cd", thema_cd);
                param.Add("in_shop_cd", shop_cd);
                param.Add("in_date_begin", date_begin);
                param.Add("in_date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT X.SHOP_CD THEMA_CD, X.SHOP_NAME THEMA_NAME, 
                                       A.ORDER_NO, B.SHOP_CD, B.SHOP_NAME, 
                                       A.ORDER_TIME,
                                       to_char(A.ORDER_TIME,'YYYY.MM.DD HH24:MI') ORDER_TIME2,
                                       H.pay_name || case when a.app_pay_gbn = '3' then '(앱)' else '(현장)' end AS PAY_GBN,
                                       CASE WHEN A.STATUS = '10' THEN '접수'
                                            WHEN A.STATUS = '20' THEN '대기'
                                            WHEN A.STATUS = '30' THEN '가맹점접수확인'
                                            WHEN A.STATUS = '35' THEN '운행'
                                            WHEN A.STATUS = '40' THEN '완료'
                                            WHEN A.STATUS = '50' THEN '취소'
                                            WHEN A.STATUS = '80' THEN '결제대기' END
                                        || CASE WHEN A.CANCEL_CODE IS NOT NULL THEN ' : ' || D.CODE_NM END AS STATUS,
                                       A.CANCEL_REASON,
                                       CASE WHEN A.PACK_ORDER_YN = 'Y' THEN '포장'
                                            WHEN A.PACK_ORDER_YN = 'N' THEN '배달' END AS DELI_PACK_GBN,
                                       A.MENU_AMT,
                                       A.DELI_TIP_AMT,
                                       A.TOT_AMT,
                                       A.DISC_AMT,
                                       A.AMOUNT,
                                       A.CCODE,
                                       NVL(G.COUPON_NAME,F.COUPON_NAME) COUPON,
                                       CASE WHEN A.PACK_ORDER_YN = 'N' THEN SUBSTR(A.ADDR2,1,REGEXP_INSTR(A.ADDR2,'로 |길 ',1,1,0)) || REGEXP_REPLACE(SUBSTR(A.ADDR2,REGEXP_INSTR(A.ADDR2,'로 |길 ',1,1,0) + 1),'[0-9|가-힝]','*') END ADDR2,
                                       --SUBSTR(A.ADDR1,1,REGEXP_INSTR(A.ADDR1,'동 |읍 |면 ',1,1,0)) || REGEXP_REPLACE(SUBSTR(A.ADDR1,REGEXP_INSTR(A.ADDR1,'동 |읍 |면 ',1,1,0) + 1),'[0-9|가-힝]','*') ADDR1,
                                       CASE WHEN A.PACK_ORDER_YN = 'N' AND A.DEST_DONG LIKE '% %' THEN REGEXP_SUBSTR(A.DEST_DONG,'[^ ]+ |[^ ]+',1,1) || REGEXP_REPLACE(REGEXP_SUBSTR(A.DEST_DONG,'[^ ]+',1,2),'[0-9|가-힝]','*') ELSE A.DEST_DONG END DEST_DONG,
                                       E.INSERT_DATE,
                                       to_char(E.INSERT_DATE,'YYYY.MM.DD HH24:MI') INSERT_DATE2
                                FROM dorder A,
                                     CALLCENTER C,
                                     SHOP_INFO B,
                                     ETC_CODE D,
                                     APP_CUSTOMER E,
                                     COUPON_MST F,
                                     CHAIN_COUPON_MST G,
                                     SHOP_INFO X,
                                     SHOP_INFO_ADD Z,
                                     payment_mng H
                                WHERE A.SHOP_CD = B.SHOP_CD
                                AND   B.SHOP_CD = Z.SHOP_CD
                                and   a.pay_gbn = H.pay_gbn
                                and   a.app_pay_gbn = H.app_pay_gbn
                                AND   A.CCODE = E.CUST_CODE (+)
                                AND   A.CANCEL_CODE = D.CODE (+)
                                AND   A.COUPON_NO = F.COUPON_NO (+)
                                AND   A.COUPON_NO2 = G.COUPON_NO (+)
                                AND   NVL(D.PGM_GROUP,'O') = 'O'
                                AND   NVL(D.CODE_GRP,'10') = '10'
                                AND   A.CCCODE = C.CCCODE
                                and   A.TEST_GBN = 'N'
                                AND   A.ORDER_TIME BETWEEN to_date(:in_date_begin,'YYYYMMDD') AND to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                AND   C.MCODE = '2'
                                AND   Z.M_SHOP_CD LIKE CASE WHEN :in_thema_cd IS NULL THEN '%' ELSE :in_thema_cd END
                                AND   B.SHOP_CD LIKE CASE WHEN :in_shop_cd IS NULL THEN '%' ELSE :in_shop_cd END
                                AND   Z.M_SHOP_CD = X.SHOP_CD
                                AND   (B.ITEM_CD = '1033' OR B.ITEM_CD2 = '1033' OR B.ITEM_CD3 = '1033')
                                union all
                                SELECT /*+FULL(DORDER_PAST)PARALLEL(DORDER_PAST 4)*/
                                       X.SHOP_CD THEMA_CD, X.SHOP_NAME THEMA_NAME, 
                                       A.ORDER_NO, B.SHOP_CD, B.SHOP_NAME, 
                                       A.ORDER_TIME,
                                       to_char(A.ORDER_TIME,'YYYY.MM.DD HH24:MI') ORDER_TIME2,
                                       H.pay_name || case when a.app_pay_gbn = '3' then '(앱)' else '(현장)' end AS PAY_GBN,
                                       CASE WHEN A.STATUS = '10' THEN '접수'
                                            WHEN A.STATUS = '20' THEN '대기'
                                            WHEN A.STATUS = '30' THEN '가맹점접수확인'
                                            WHEN A.STATUS = '35' THEN '운행'
                                            WHEN A.STATUS = '40' THEN '완료'
                                            WHEN A.STATUS = '50' THEN '취소'
                                            WHEN A.STATUS = '80' THEN '결제대기' END
                                        || CASE WHEN A.CANCEL_CODE IS NOT NULL THEN ' : ' || D.CODE_NM END AS STATUS,
                                       A.CANCEL_REASON,
                                       CASE WHEN A.PACK_ORDER_YN = 'Y' THEN '포장'
                                            WHEN A.PACK_ORDER_YN = 'N' THEN '배달' END AS DELI_PACK_GBN,
                                       A.MENU_AMT,
                                       A.DELI_TIP_AMT,
                                       A.TOT_AMT,
                                       A.DISC_AMT,
                                       A.AMOUNT,
                                       A.CCODE,
                                       NVL(G.COUPON_NAME,F.COUPON_NAME) COUPON,
                                       CASE WHEN A.PACK_ORDER_YN = 'N' THEN SUBSTR(A.ADDR2,1,REGEXP_INSTR(A.ADDR2,'로 |길 ',1,1,0)) || REGEXP_REPLACE(SUBSTR(A.ADDR2,REGEXP_INSTR(A.ADDR2,'로 |길 ',1,1,0) + 1),'[0-9|가-힝]','*') END ADDR2,
                                       --SUBSTR(A.ADDR1,1,REGEXP_INSTR(A.ADDR1,'동 |읍 |면 ',1,1,0)) || REGEXP_REPLACE(SUBSTR(A.ADDR1,REGEXP_INSTR(A.ADDR1,'동 |읍 |면 ',1,1,0) + 1),'[0-9|가-힝]','*') ADDR1,
                                       CASE WHEN A.PACK_ORDER_YN = 'N' AND A.DEST_DONG LIKE '% %' THEN REGEXP_SUBSTR(A.DEST_DONG,'[^ ]+ |[^ ]+',1,1) || REGEXP_REPLACE(REGEXP_SUBSTR(A.DEST_DONG,'[^ ]+',1,2),'[0-9|가-힝]','*') ELSE A.DEST_DONG END DEST_DONG,
                                       E.INSERT_DATE,
                                       to_char(E.INSERT_DATE,'YYYY.MM.DD HH24:MI') INSERT_DATE2
                                FROM dorder_past A,
                                     CALLCENTER C,
                                     SHOP_INFO B,
                                     ETC_CODE D,
                                     APP_CUSTOMER E,
                                     COUPON_MST F,
                                     CHAIN_COUPON_MST G,
                                     SHOP_INFO X,
                                     SHOP_INFO_ADD Z,
                                     payment_mng H
                                WHERE A.SHOP_CD = B.SHOP_CD
                                AND   B.SHOP_CD = Z.SHOP_CD
                                and   a.pay_gbn = H.pay_gbn
                                and   a.app_pay_gbn = H.app_pay_gbn
                                AND   A.CCODE = E.CUST_CODE (+)
                                AND   A.CANCEL_CODE = D.CODE (+)
                                AND   A.COUPON_NO = F.COUPON_NO (+)
                                AND   A.COUPON_NO2 = G.COUPON_NO (+)
                                AND   NVL(D.PGM_GROUP,'O') = 'O'
                                AND   NVL(D.CODE_GRP,'10') = '10'
                                AND   A.CCCODE = C.CCCODE
                                and   A.TEST_GBN = 'N'
                                AND   A.ORDER_TIME BETWEEN to_date(:in_date_begin,'YYYYMMDD') AND to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                AND   C.MCODE = '2'
                                AND   Z.M_SHOP_CD LIKE CASE WHEN :in_thema_cd IS NULL THEN '%' ELSE :in_thema_cd END
                                AND   B.SHOP_CD LIKE CASE WHEN :in_shop_cd IS NULL THEN '%' ELSE :in_shop_cd END
                                AND   Z.M_SHOP_CD = X.SHOP_CD
                                AND   (B.ITEM_CD = '1033' OR B.ITEM_CD2 = '1033' OR B.ITEM_CD3 = '1033')
                                ORDER BY THEMA_CD, ORDER_TIME
                            ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }
        #endregion[전통시장 통계vba]

        #region[밀키트 통계vba]
        /// <summary>
        /// 일별 (밀키트)가맹점별 주문 vba
        /// </summary>
        /// <remarks>
        /// * 모든 종류의 취소주문을 포함
        /// </remarks>
        [HttpGet("getDailyMealkitShopOrder")]
        public async Task<IActionResult> getDailyMealkitShopOrder(string date_begin, string date_end, string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_shop_cd", shop_cd);
                param.Add("in_date_begin", date_begin);
                param.Add("in_date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT  DT , SHOP_CD, SHOP_NAME, COUNT(*) AS CNT, COUNT(CASE WHEN STATUS = '40' THEN 1 END) AS COMP_CNT, COUNT(CASE WHEN STATUS = '50' THEN 1 END) AS CANCEL_CNT
                                from(SELECT B.SHOP_CD, B.SHOP_NAME, TO_CHAR(A.ORDER_TIME,'YYYYMMDD') AS DT, A.STATUS
                                    FROM dorder A,
                                         CALLCENTER C,
                                         SHOP_INFO B
                                    WHERE A.SHOP_CD = B.SHOP_CD
                                    AND   A.CCCODE = C.CCCODE
                                    and   A.TEST_GBN = 'N'
                                    AND   A.ORDER_TIME BETWEEN to_date(:in_date_begin,'YYYYMMDD') AND to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                    AND   C.MCODE = '2'
                                    and   b.service_gbn = '6'
                                    AND   B.SHOP_CD LIKE CASE WHEN :in_shop_cd IS NULL THEN '%' ELSE :in_shop_cd END
                                    union all
                                    SELECT B.SHOP_CD, B.SHOP_NAME, TO_CHAR(A.ORDER_TIME,'YYYYMMDD') AS DT, A.STATUS
                                    FROM dorder_past A,
                                         CALLCENTER C,
                                         SHOP_INFO B
                                    WHERE A.SHOP_CD = B.SHOP_CD
                                    AND   A.CCCODE = C.CCCODE
                                    and   A.TEST_GBN = 'N'
                                    AND   A.ORDER_TIME BETWEEN to_date(:in_date_begin,'YYYYMMDD') AND to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                    AND   C.MCODE = '2'
                                    and   b.service_gbn = '6'
                                    AND   B.SHOP_CD LIKE CASE WHEN :in_shop_cd IS NULL THEN '%' ELSE :in_shop_cd END)
                                GROUP BY DT,SHOP_CD, SHOP_NAME 
                                ORDER BY DT, SHOP_NAME
                            ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// (밀키트)가맹점별 주문 vba
        /// </summary>
        /// <remarks>
        /// * 모든 종류의 취소주문을 포함
        /// </remarks>
        [HttpGet("getMealkitShopOrder")]
        public async Task<IActionResult> getMealkitShopOrder(string date_begin, string date_end, string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_shop_cd", shop_cd);
                param.Add("in_date_begin", date_begin);
                param.Add("in_date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT A.ORDER_NO, B.SHOP_CD, B.SHOP_NAME, 
                                       A.ORDER_TIME,
                                       to_char(A.ORDER_TIME,'YYYY.MM.DD HH24:MI') ORDER_TIME2,
                                       to_char(A.comp_dt,'YYYY.MM.DD HH24:MI') comp_dt,
                                       case when A.PAY_GBN = '2' and I.card_point_yn = 'Y' 
                                            then 'BC TOP 포인트' else H.pay_name end
                                        || case when a.app_pay_gbn = '3' then '(앱)' else '(현장)' end AS PAY_GBN,
                                       CASE WHEN A.STATUS = '10' THEN '접수'
                                            WHEN A.STATUS = '20' THEN '대기'
                                            WHEN A.STATUS = '30' THEN '가맹점접수확인'
                                            WHEN A.STATUS = '35' THEN '운행'
                                            WHEN A.STATUS = '40' THEN '완료'
                                            WHEN A.STATUS = '50' THEN '취소'
                                            WHEN A.STATUS = '80' THEN '결제대기' END
                                        || CASE WHEN A.CANCEL_CODE IS NOT NULL THEN ' : ' || D.CODE_NM END AS STATUS,
                                       A.CANCEL_REASON,
                                       CASE WHEN A.PACK_ORDER_YN = 'Y' THEN '포장'
                                            WHEN A.PACK_ORDER_YN = 'N' THEN '배달' END AS DELI_PACK_GBN,
                                       A.MENU_AMT,
                                       A.DELI_TIP_AMT,
                                       A.TOT_AMT,
                                       A.DISC_AMT,
                                       A.AMOUNT,
                                       A.CCODE,
                                       NVL(G.COUPON_NAME,F.COUPON_NAME) COUPON,
                                       CASE WHEN A.PACK_ORDER_YN = 'N' THEN SUBSTR(A.ADDR2,1,REGEXP_INSTR(A.ADDR2,'로 |길 ',1,1,0)) || REGEXP_REPLACE(SUBSTR(A.ADDR2,REGEXP_INSTR(A.ADDR2,'로 |길 ',1,1,0) + 1),'[0-9|가-힝]','*') END ADDR2,
                                       --SUBSTR(A.ADDR1,1,REGEXP_INSTR(A.ADDR1,'동 |읍 |면 ',1,1,0)) || REGEXP_REPLACE(SUBSTR(A.ADDR1,REGEXP_INSTR(A.ADDR1,'동 |읍 |면 ',1,1,0) + 1),'[0-9|가-힝]','*') ADDR1,
                                       CASE WHEN A.PACK_ORDER_YN = 'N' AND A.DEST_DONG LIKE '% %' THEN REGEXP_SUBSTR(A.DEST_DONG,'[^ ]+ |[^ ]+',1,1) || REGEXP_REPLACE(REGEXP_SUBSTR(A.DEST_DONG,'[^ ]+',1,2),'[0-9|가-힝]','*') ELSE A.DEST_DONG END DEST_DONG,
                                       E.INSERT_DATE,
                                       to_char(E.INSERT_DATE,'YYYY.MM.DD HH24:MI') INSERT_DATE2,
                                       nvl2(R.order_seqno,'Y','N') review_yn,
                                       R.content_text
                                FROM dorder A,
                                     CALLCENTER C,
                                     SHOP_INFO B,
                                     ETC_CODE D,
                                     APP_CUSTOMER E,
                                     COUPON_MST F,
                                     CHAIN_COUPON_MST G,
                                     payment_mng H,
                                     dorder_detail I,
                                     app_review R
                                WHERE A.SHOP_CD = B.SHOP_CD
                                and   A.order_no = I.order_no
                                and   a.pay_gbn = H.pay_gbn
                                and   a.app_pay_gbn = H.app_pay_gbn
                                AND   A.CCODE = E.CUST_CODE (+)
                                AND   A.CANCEL_CODE = D.CODE (+)
                                AND   A.COUPON_NO = F.COUPON_NO (+)
                                AND   A.COUPON_NO2 = G.COUPON_NO (+)
                                and   A.order_no = R.order_seqno (+)
                                AND   NVL(D.PGM_GROUP,'O') = 'O'
                                AND   NVL(D.CODE_GRP,'10') = '10'
                                AND   A.CCCODE = C.CCCODE
                                AND   B.CCCODE = C.CCCODE
                                and   A.TEST_GBN = 'N'
                                AND   A.ORDER_TIME BETWEEN to_date(:in_date_begin,'YYYYMMDD') AND to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                AND   C.MCODE = '2'
                                and   b.service_gbn = '6'
                                AND   B.SHOP_CD LIKE CASE WHEN :in_shop_cd IS NULL THEN '%' ELSE :in_shop_cd END
                                union all
                                SELECT /*+FULL(DORDER_PAST)PARALLEL(DORDER_PAST 4)*/
                                       A.ORDER_NO, B.SHOP_CD, B.SHOP_NAME, 
                                       A.ORDER_TIME,
                                       to_char(A.ORDER_TIME,'YYYY.MM.DD HH24:MI') ORDER_TIME2,
                                       to_char(A.comp_dt,'YYYY.MM.DD HH24:MI') comp_dt,
                                       case when A.PAY_GBN = '2' and I.card_point_yn = 'Y' 
                                            then 'BC TOP 포인트' else H.pay_name end
                                        || case when a.app_pay_gbn = '3' then '(앱)' else '(현장)' end AS PAY_GBN,
                                       CASE WHEN A.STATUS = '10' THEN '접수'
                                            WHEN A.STATUS = '20' THEN '대기'
                                            WHEN A.STATUS = '30' THEN '가맹점접수확인'
                                            WHEN A.STATUS = '35' THEN '운행'
                                            WHEN A.STATUS = '40' THEN '완료'
                                            WHEN A.STATUS = '50' THEN '취소'
                                            WHEN A.STATUS = '80' THEN '결제대기' END
                                        || CASE WHEN A.CANCEL_CODE IS NOT NULL THEN ' : ' || D.CODE_NM END AS STATUS,
                                       A.CANCEL_REASON,
                                       CASE WHEN A.PACK_ORDER_YN = 'Y' THEN '포장'
                                            WHEN A.PACK_ORDER_YN = 'N' THEN '배달' END AS DELI_PACK_GBN,
                                       A.MENU_AMT,
                                       A.DELI_TIP_AMT,
                                       A.TOT_AMT,
                                       A.DISC_AMT,
                                       A.AMOUNT,
                                       A.CCODE,
                                       NVL(G.COUPON_NAME,F.COUPON_NAME) COUPON,
                                       CASE WHEN A.PACK_ORDER_YN = 'N' THEN SUBSTR(A.ADDR2,1,REGEXP_INSTR(A.ADDR2,'로 |길 ',1,1,0)) || REGEXP_REPLACE(SUBSTR(A.ADDR2,REGEXP_INSTR(A.ADDR2,'로 |길 ',1,1,0) + 1),'[0-9|가-힝]','*') END ADDR2,
                                       --SUBSTR(A.ADDR1,1,REGEXP_INSTR(A.ADDR1,'동 |읍 |면 ',1,1,0)) || REGEXP_REPLACE(SUBSTR(A.ADDR1,REGEXP_INSTR(A.ADDR1,'동 |읍 |면 ',1,1,0) + 1),'[0-9|가-힝]','*') ADDR1,
                                       CASE WHEN A.PACK_ORDER_YN = 'N' AND A.DEST_DONG LIKE '% %' THEN REGEXP_SUBSTR(A.DEST_DONG,'[^ ]+ |[^ ]+',1,1) || REGEXP_REPLACE(REGEXP_SUBSTR(A.DEST_DONG,'[^ ]+',1,2),'[0-9|가-힝]','*') ELSE A.DEST_DONG END DEST_DONG,
                                       E.INSERT_DATE,
                                       to_char(E.INSERT_DATE,'YYYY.MM.DD HH24:MI') INSERT_DATE2,
                                       nvl2(R.order_seqno,'Y','N') review_yn,
                                       R.content_text
                                FROM dorder_past A,
                                     CALLCENTER C,
                                     SHOP_INFO B,
                                     ETC_CODE D,
                                     APP_CUSTOMER E,
                                     COUPON_MST F,
                                     CHAIN_COUPON_MST G,
                                     payment_mng H,
                                     dorder_detail I,
                                     app_review R
                                WHERE A.SHOP_CD = B.SHOP_CD
                                and   A.order_no = I.order_no
                                and   a.pay_gbn = H.pay_gbn
                                and   a.app_pay_gbn = H.app_pay_gbn
                                AND   A.CCODE = E.CUST_CODE (+)
                                AND   A.CANCEL_CODE = D.CODE (+)
                                AND   A.COUPON_NO = F.COUPON_NO (+)
                                AND   A.COUPON_NO2 = G.COUPON_NO (+)
                                and   A.order_no = R.order_seqno (+)
                                AND   NVL(D.PGM_GROUP,'O') = 'O'
                                AND   NVL(D.CODE_GRP,'10') = '10'
                                AND   A.CCCODE = C.CCCODE
                                AND   B.CCCODE = C.CCCODE
                                and   A.TEST_GBN = 'N'
                                AND   A.ORDER_TIME BETWEEN to_date(:in_date_begin,'YYYYMMDD') AND to_date(:in_date_end || '235959','YYYYMMDDHH24MISS')
                                AND   C.MCODE = '2'
                                and   b.service_gbn = '6'
                                AND   B.SHOP_CD LIKE CASE WHEN :in_shop_cd IS NULL THEN '%' ELSE :in_shop_cd END
                                ORDER BY ORDER_TIME
                            ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }
        #endregion[밀키트 통계vba]

        #region[회원비회원체크 및 마일리지 사입]
        // 회원 비회원 여부 확인 엑셀
        [HttpGet("getCustomerYn")]
        public async Task<IActionResult> getCustomerYn(string telno)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object Rdata = string.Empty;


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("telno", telno);

                //string sql = @$"
                //                select decode(count(1), 0,'비회원',1,'회원') as customer
                //                from app_customer
                //                where use_gbn = '1' and telno = :telno
                //";

                string sql = @$"
                                select c.telno, c.cust_name, a.customer, nvl(c.mileage,0) as mileage_sum, b.memo, sum(nvl(b.mileage_amt,0)) as mileage
                                    from (select telno, decode(nvl(count(1),0), 0,'비회원',1,'회원') as customer, sum(cust_code) as cust_code
                                from app_customer where use_gbn = '1' AND MCODE = 2 AND CUST_ID_GBN <> 'Z' AND TEST_GBN = 'R' and telno = :telno) a, app_cust_mileage_log b , app_customer c
                                where a.cust_code = b.app_cust_code(+)
                                and b.app_cust_code = c.cust_code(+)
                                group by c.telno, c.cust_name, a.customer, c.mileage, b.memo
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 회원 비회원 여부 확인 엑셀(기본)
        [HttpGet("getCustomerYnV2")]
        public async Task<IActionResult> getCustomerYnV2(string telno)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object Rdata = string.Empty;


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("telno", telno);

                string sql = @$"
                                select decode(count(1), 0,'비회원',1,'회원') as customer
                                from app_customer
                                where use_gbn = '1' and telno = :telno
                                and mcode = 2
                                and test_gbn = 'R'
                ";
                ;

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 값 받아서 마일리지 충전하는 rest
        [HttpPut("chargeMileage")]
        public async Task<IActionResult> chargeMileage(string[] telno, string type, string req_mileage, string mileage_memo, string payer_id, string payer_nm)
        {


            if (string.IsNullOrEmpty(type))
            {
                return Ok(new { code = "99", msg = "타입을 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(req_mileage))
            {
                return Ok(new { code = "99", msg = "신청마일리지를 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(mileage_memo))
            {
                return Ok(new { code = "99", msg = "메모를 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(payer_nm) || string.IsNullOrEmpty(payer_id))
            {
                return Ok(new { code = "99", msg = "지급자를 제대로 설정해주세요." });
            }


            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object Rdata = string.Empty;

            string sql = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            db.Open();

            using var transaction = db.BeginTransaction();

            try
            {

                DynamicParameters param = new DynamicParameters();
                param.Add("type", type);
                param.Add("req_mileage", req_mileage);
                param.Add("mileage_memo", mileage_memo);
                param.Add("payer_id", payer_id);
                param.Add("payer_nm", payer_nm);

                string[] cust_cd = new string[telno.Length];
                // 각 전화번호의 회원코드 구하기
                int n = 0;
                foreach (string e in telno)
                {
                    sql = $@" SELECT TO_CHAR(CUST_CODE) FROM APP_CUSTOMER WHERE USE_GBN = '1' AND MCODE = 2 AND CUST_ID_GBN <> 'Z' AND TEST_GBN = 'R' AND TELNO = '{e}'";
                    //sql = $@" SELECT TO_CHAR(CUST_CODE) FROM APP_CUSTOMER WHERE TELNO = '{e}'";
                    cust_cd[n] = (string)await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);
                    if (string.IsNullOrEmpty(cust_cd[n]))
                    {
                        return Ok(new { code = "99", msg = e + " - 이 전화번호는 회원이 아닙니다." });
                    }
                    n++;
                }


                //대구_마일리지지급 테이블에 내역 추가
                sql = $@"INSERT INTO 대구_마일리지지급(순번, 타입, 전화번호, 신청마일리지, 마일리지메모, 지급자ID, 지급자명) SELECT SEQ_MILEAGE_IMSI.NEXTVAL, A.* FROM((";

                foreach (string e in telno)
                {
                    sql = sql + $@" SELECT :type as 타입, '{e}' as 전화번호, :req_mileage as 신청마일리지, trim(:mileage_memo) as 마일리지메모, :payer_id as 지급자ID, :payer_nm as 지급자명 FROM DUAL UNION ALL";
                }

                sql = sql.Substring(0, sql.Length - 9);
                sql = sql + $@") A)";


                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                //APP_CUST_MILEAGE_LOG 테이블에 마일리지 지급내역 추가
                sql = $@"INSERT INTO APP_CUST_MILEAGE_LOG(  LOGNO, 
                                                            ORDER_DATE, 
                                                            LOG_DATE, 
                                                            UCODE, 
                                                            USER_ID, 
                                                            USER_NAME, 
                                                            MILEAGE_AMT,  
                                                            LOG_GBN, 
                                                            MEMO,
                                                            APP_CUST_CODE, 
                                                            ORI_REMAIN_AMT ) 
                        SELECT  SEQ_APP_CUST_MILEAGE_LOG.NEXTVAL as LOGNO, 
                                SF_GETTODAY as ORDER_DATE, 
                                SYSDATE as LOG_DATE,
                                0 as UCODE, 
                                :payer_nm as USER_ID, 
                                :payer_nm as USER_NAME, 
                                :req_mileage as MILEAGE_AMT, 
                                CASE WHEN :req_mileage < 0 THEN '3' ELSE '1' END  as LOG_GBN, -- 1:적립 , 3:차감 
                                trim(:mileage_memo) as MEMO,
                                A.* FROM( (";

                foreach (string e in telno)
                {
                    sql = sql + $@" SELECT CUST_CODE as APP_CUST_CODE, MILEAGE as ORI_REMAIN_AMT FROM APP_CUSTOMER WHERE TELNO = '{e}' UNION ALL";
                }

                sql = sql.Substring(0, sql.Length - 9);
                sql = sql + $@") A)";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                Object num = new Object();
                var t = 0;

                //DAILY_APP_CUSTOMER 테이블에 현재 마일리지 내역 기록하고 마일리지 지급완료
                foreach (string e in cust_cd)
                {
                    sql = @$"SELECT to_char(COUNT(1)) FROM DAILY_APP_CUSTOMER WHERE APP_CUST_CODE = {e}";

                    num = await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);

                    if (Int32.Parse(num.ToString()) > 0)
                    {
                        sql = $@"UPDATE DAILY_APP_CUSTOMER SET MILEAGE_AMT = NVL(MILEAGE_AMT,0) + :req_mileage,
                                                                               MILEAGE_DATE = SF_GETTODAY WHERE APP_CUST_CODE = {e}";
                    }
                    else
                    {
                        sql = $@"INSERT INTO DAILY_APP_CUSTOMER ( APP_CUST_CODE, MILEAGE_DATE, MILEAGE_AMT )
                                                 VALUES ( {e} , SF_GETTODAY, :req_mileage )";
                    }

                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                    if (int.Parse(req_mileage) > 0)
                    {
                        sql = $@"UPDATE 대구_마일리지지급
                                SET    고객코드    = {e}, 
                                       작업유무    = '마일리지 지급완료',
                                       작업일자    = SYSDATE
                                WHERE  전화번호    = '{telno[t]}'  
                                AND  타입      = :type";
                    }
                    else
                    {
                        sql = $@"UPDATE 대구_마일리지지급
                                SET    고객코드    = {e}, 
                                       작업유무    = '마일리지 차감완료',
                                       작업일자    = SYSDATE
                                WHERE  전화번호    = '{telno[t]}'  
                                AND  타입      = :type";
                    }

                    t++;

                    await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                }

                transaction.Commit();
                //transaction.Rollback();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                Rcode = "99";
                Rmsg = ex.Message;

            }

            db.Close();
            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// cust_code로 마일리지 사입 사출
        /// </summary>
        [HttpPut("chargeMileage2")]
        public async Task<IActionResult> chargeMileage2(string cust_code, string system_gbn, string type, string req_mileage, string mileage_memo, string payer_id, string payer_nm)
        {

            if (string.IsNullOrEmpty(system_gbn))
            {
                return Ok(new { code = "99", msg = "시스템구분을 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(type))
            {
                return Ok(new { code = "99", msg = "타입을 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(req_mileage))
            {
                return Ok(new { code = "99", msg = "신청마일리지를 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(mileage_memo))
            {
                return Ok(new { code = "99", msg = "메모를 제대로 설정해주세요." });
            }
            if (string.IsNullOrEmpty(payer_nm) || string.IsNullOrEmpty(payer_id))
            {
                return Ok(new { code = "99", msg = "지급자를 제대로 설정해주세요." });
            }


            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object Rdata = string.Empty;

            string sql = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            db.Open();

            using var transaction = db.BeginTransaction();

            try
            {

                DynamicParameters param = new DynamicParameters();
                param.Add("cust_code", cust_code);
                param.Add("system_gbn", system_gbn);
                param.Add("type", type);
                param.Add("req_mileage", req_mileage);
                param.Add("mileage_memo", mileage_memo);
                param.Add("payer_id", payer_id);
                param.Add("payer_nm", payer_nm);

                string telno = string.Empty;
                // 각 전화번호의 회원코드 구하기

                sql = $@" SELECT telno FROM APP_CUSTOMER WHERE USE_GBN = '1' AND CUST_ID_GBN <> 'Z' AND CUST_CODE = :cust_code";
                //sql = $@" SELECT TO_CHAR(CUST_CODE) FROM APP_CUSTOMER WHERE TELNO = '{e}'";
                telno = (string)await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);
                if (string.IsNullOrEmpty(telno))
                {
                    return Ok(new { code = "99", msg = "회원이 아닙니다." });
                }

                param.Add("telno", telno);

                //대구_마일리지지급 테이블에 내역 추가
                sql = $@"INSERT INTO 대구_마일리지지급(순번, 타입, 전화번호, 신청마일리지, 마일리지메모, 지급자ID, 지급자명) 
                        VALUES (SEQ_MILEAGE_IMSI.NEXTVAL, :type, :telno, :req_mileage, trim(:mileage_memo), :payer_id, :payer_nm)";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                //APP_CUST_MILEAGE_LOG 테이블에 마일리지 지급내역 추가
                sql = $@"INSERT INTO APP_CUST_MILEAGE_LOG(  LOGNO, 
                                                            ORDER_DATE, 
                                                            LOG_DATE, 
                                                            system_gbn, 
                                                            UCODE, 
                                                            USER_ID, 
                                                            USER_NAME, 
                                                            MILEAGE_AMT,  
                                                            LOG_GBN, 
                                                            MEMO,
                                                            APP_CUST_CODE, 
                                                            ORI_REMAIN_AMT ) 
                        VALUES (SEQ_APP_CUST_MILEAGE_LOG.NEXTVAL, 
                                SF_GETTODAY, 
                                SYSDATE,
                                :system_gbn,
                                0, 
                                :payer_nm, 
                                :payer_nm, 
                                :req_mileage, 
                                CASE WHEN :req_mileage < 0 THEN '3' ELSE '1' END, -- 1:적립 , 3:차감 
                                trim(:mileage_memo),
                                :cust_code,
                                (select MILEAGE from APP_CUSTOMER where cust_code = :cust_code))";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                Object num = new Object();

                //DAILY_APP_CUSTOMER 테이블에 현재 마일리지 내역 기록하고 마일리지 지급완료

                sql = @$"SELECT to_char(COUNT(1)) FROM DAILY_APP_CUSTOMER WHERE APP_CUST_CODE = :cust_code";

                num = await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);

                if (Int32.Parse(num.ToString()) > 0)
                {
                    sql = $@"UPDATE DAILY_APP_CUSTOMER SET MILEAGE_AMT = NVL(MILEAGE_AMT,0) + :req_mileage,
                                                                            MILEAGE_DATE = SF_GETTODAY WHERE APP_CUST_CODE = :cust_code";
                }
                else
                {
                    sql = $@"INSERT INTO DAILY_APP_CUSTOMER ( APP_CUST_CODE, MILEAGE_DATE, MILEAGE_AMT )
                                                VALUES ( :cust_code , SF_GETTODAY, :req_mileage )";
                }

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                if (int.Parse(req_mileage) > 0)
                {
                    sql = $@"UPDATE 대구_마일리지지급
                            SET    고객코드    = :cust_code, 
                                    작업유무    = '마일리지 지급완료',
                                    작업일자    = SYSDATE
                            WHERE  전화번호    = :telno  
                            AND  타입      = :type";
                }
                else
                {
                    sql = $@"UPDATE 대구_마일리지지급
                            SET    고객코드    = :cust_code, 
                                    작업유무    = '마일리지 차감완료',
                                    작업일자    = SYSDATE
                            WHERE  전화번호    = :telno  
                            AND  타입      = :type";
                }

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                transaction.Commit();
                //transaction.Rollback();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                Rcode = "99";
                Rmsg = ex.Message;

            }

            db.Close();
            return Ok(new { code = Rcode, msg = Rmsg });
        }
        #endregion


        #region[미사용]

        // 가맹점(시간지연취소건) 엑셀 --미사용예정
        [HttpGet("getDelayCancelShop")]
        public async Task<IActionResult> getDelayCancelShop(string date_begin, string date_end, string gungu)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("gungu", gungu);

                string gunguSql = string.Empty; ;

                if (gungu is not null)
                {
                    gunguSql = @"AND A.GUNGU_NAME = :gungu";
                }

                string sql = @$"
                                 SELECT rownum, a.*,
                                        SF_CHECK_POS_INSTALL (A.SHOP_CD)
                                           AS POS_INSTALL,
                                        SF_CHECK_POS_LOGIN (A.SHOP_CD)
                                           AS POS_LOGIN
                                    from(SELECT * from(SELECT A.GUNGU_NAME,
                                             A.SHOP_CD,
                                             A.SHOP_NAME,
                                             TO_CHAR(A.OPEN_DT,'YYYYMMDD') AS OPEN_DT,
                                             A.TELNO,
                                             A.ABSENT_YN,
                                             C.cancel_reason,
                                             NVL(sum (case when c.status = '50' AND  NVL(CANCEL_CODE,'00') = '11' then 1 end),0) as CANCELCNT
                                        FROM SHOP_INFO        A,
                                             CALLCENTER       B,
                                             (SELECT * FROM DORDER 
                                             WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND TEST_GBN = 'N'
                                            AND NVL(CANCEL_CODE,'00') = '11'
                                            AND order_date BETWEEN :date_begin
                                                                                     AND :date_end
                                             UNION ALL 
                                             SELECT * FROM DORDER_PAST
                                             WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND TEST_GBN = 'N'
                                            AND NVL(CANCEL_CODE,'00') = '11'
                                            AND order_date BETWEEN :date_begin
                                                                                     AND :date_end) C                                          
                                       WHERE A.CCCODE = B.CCCODE
                                       AND B.MCODE = 2
                                       AND A.SHOP_CD = C.SHOP_CD
                                       and C.SHOP_CD = A.SHOP_CD
                                       {gunguSql} 
                                       GROUP BY A.GUNGU_NAME,
                                             A.SHOP_CD,
                                             A.SHOP_NAME,
                                             TO_CHAR(A.OPEN_DT,'YYYYMMDD'),
                                             A.TELNO,
                                             A.ABSENT_YN,
                                             C.cancel_reason)
                                       where CANCELCNT > 0
                                       ORDER BY CANCELCNT DESC) a
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }

        // 가맹점(가맹점취소건) 엑셀--미사용예정
        [HttpGet("getShopCancelShop")]
        public async Task<IActionResult> getShopCancelShop(string date_begin, string date_end, string gungu)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("gungu", gungu);

                string gunguSql = string.Empty;

                if (gungu is not null)
                {
                    gunguSql = @"AND A.GUNGU_NAME = :gungu";
                }

                string sql = @$"
                                 SELECT rownum, a.*, 
                                        SF_CHECK_POS_INSTALL (A.SHOP_CD)
                                           AS POS_INSTALL,
                                        SF_CHECK_POS_LOGIN (A.SHOP_CD)
                                           AS POS_LOGIN
                                    from(SELECT * from(SELECT A.GUNGU_NAME,
                                             A.SHOP_CD,
                                             A.SHOP_NAME,
                                             TO_CHAR(A.OPEN_DT,'YYYYMMDD') AS OPEN_DT,
                                             A.TELNO,
                                             A.ABSENT_YN,
                                             C.cancel_reason,
                                             NVL(sum (case when c.status = '50' AND  NVL(CANCEL_CODE,'00') = '20' then 1 end),0) as CANCELCNT
                                        FROM SHOP_INFO        A,
                                             CALLCENTER       B,
                                             (SELECT * FROM DORDER 
                                             WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND TEST_GBN = 'N'
                                            AND NVL(CANCEL_CODE,'00') = '20'
                                            AND order_date BETWEEN :date_begin
                                                                                     AND :date_end
                                             UNION ALL 
                                             SELECT * FROM DORDER_PAST
                                             WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND TEST_GBN = 'N'
                                            AND NVL(CANCEL_CODE,'00') = '20'
                                            AND order_date BETWEEN :date_begin
                                                                                     AND :date_end) C                                          
                                       WHERE A.CCCODE = B.CCCODE
                                       AND B.MCODE = 2
                                       AND A.SHOP_CD = C.SHOP_CD
                                       and C.SHOP_CD = A.SHOP_CD
                                       {gunguSql} 
                                       GROUP BY A.GUNGU_NAME,
                                             A.SHOP_CD,
                                             A.SHOP_NAME,
                                             TO_CHAR(A.OPEN_DT,'YYYYMMDD'),
                                             A.TELNO,
                                             A.ABSENT_YN,
                                             C.cancel_reason)
                                       where CANCELCNT > 0
                                       ORDER BY CANCELCNT DESC) a
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }

        // 가맹점(주문순위 역순) 엑셀--미사용예정
        [HttpGet("getShopOrderRankReverse")]
        public async Task<IActionResult> getShopOrderRankReverse(string date_begin, string date_end, string gungu)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("gungu", gungu);

                string gunguSql = string.Empty;

                if (gungu is not null)
                {
                    gunguSql = @"AND C.GUNGU_NAME = :gungu";
                }

                string sql = @$"
                                 SELECT rownum, a.*
                                    FROM (  SELECT * 
                                            FROM (
                                                select gungu_name, shop_cd, shop_name, telno, to_char(open_dt,'YYYYMMDD') as open_dt, absent_yn,
                                                        COUNT(shop_cd) AS 총주문
                                                FROM (select c.gungu_name, a.STATUS, c.shop_cd, c.shop_name, c.telno, c.open_dt, c.absent_yn FROM dorder a, callcenter b, shop_info c
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        AND NVL (a.CANCEL_CODE, '00') <> '30'
                                                        AND a.shop_cd = c.shop_cd
                                                        {gunguSql} 
                                                      UNION ALL
                                                      select c.gungu_name, a.STATUS, c.shop_cd, c.shop_name, c.telno, c.open_dt, c.absent_yn FROM dorder_past a, callcenter b, shop_info c
                                                        WHERE a.cccode = b.cccode
                                                        AND b.MCODE = 2 
                                                        AND a.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                        AND a.TEST_GBN = 'N'
                                                        AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN :date_begin AND :date_end
                                                        AND NVL (a.CANCEL_CODE, '00') <> '30'
                                                        AND a.shop_cd = c.shop_cd
                                                        {gunguSql})
                                                group by gungu_name, shop_cd, shop_name, telno, open_dt, absent_yn)
                                            order by 총주문) a
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = items.Count.ToString(), data = items });
        }

        // 대구로 APP 시범서비스 운영현황 보고(미사용)
        [HttpGet("getDaeguroTotalInfo")]
        public async Task<IActionResult> getDaeguroTotalInfo()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> totalInstalled = new List<object>();
            List<object> osInstalled = new List<object>();
            List<object> totalYearMembers = new List<object>();
            List<object> yearMembers = new List<object>();
            List<object> totalOrders = new List<object>();
            List<object> orders = new List<object>();
            List<object> totalCancel = new List<object>();
            List<object> cancels = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                //DynamicParameters param = new DynamicParameters();
                //param.Add("date_begin", date_begin);
                //param.Add("date_end", date_end);

                // 누적 설치수
                string sql = @"
                                  SELECT device_gbn, COUNT (*) COUNT
                                    FROM (SELECT mcode,
                                                 insert_date,
                                                 cust_id_gbn,
                                                 test_gbn,
                                                 device_gbn
                                            FROM app_customer
                                          UNION ALL
                                          SELECT mcode,
                                                 insert_date,
                                                 cust_id_gbn,
                                                 test_gbn,
                                                 device_gbn
                                            FROM app_customer_deleted)
                                   WHERE     mcode = 2
                                         AND device_gbn IS NOT NULL
                                         AND cust_id_gbn = 'Z'
                                         AND insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND test_gbn = 'R'
                                GROUP BY device_gbn
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalInstalled = temp.ToList();

                // 당일, 전일 설치수
                sql = @"
                          SELECT TO_CHAR (insert_date, 'YYYYMMDD')     insert_date,
                                 device_gbn,
                                 COUNT (*)                             COUNT
                            FROM (SELECT mcode,
                                         device_gbn,
                                         insert_date,
                                         cust_id_gbn,
                                         test_gbn
                                    FROM app_customer
                                  UNION ALL
                                  SELECT mcode,
                                         device_gbn,
                                         insert_date,
                                         cust_id_gbn,
                                         test_gbn
                                    FROM app_customer_deleted)
                           WHERE     mcode = 2
                                 AND device_gbn IS NOT NULL
                                 AND cust_id_gbn = 'Z'
                                 AND test_gbn = 'R'
                                 AND TO_CHAR (insert_date, 'yyyyMMdd') BETWEEN TO_CHAR (SYSDATE - 2,
                                                                                        'yyyyMMdd')
                                                                           AND TO_CHAR (SYSDATE - 1,
                                                                                        'yyyyMMdd')
                        GROUP BY TO_CHAR (insert_date, 'YYYYMMDD'), device_gbn
                        ORDER BY insert_date DESC
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                osInstalled = temp.ToList();


                // 누적 회원(연령대) 수
                sql = @"
                          SELECT birthday || '0대' AS year, COUNT (*) COUNT
                            FROM (SELECT TO_CHAR (insert_date, 'YYYYMMDD')
                                             AS insert_date,
                                         SUBSTR (TO_CHAR (2021 - TO_NUMBER (SUBSTR (birthday, 1, 4))),
                                                 1,
                                                 1)
                                             birthday
                                    FROM (SELECT mcode, insert_date, birthday FROM app_customer
                                          UNION ALL
                                          SELECT mcode, insert_date, birthday FROM app_customer_deleted)
                                   WHERE     mcode = 2
                                         AND insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND test_gbn = 'R'
                                         AND birthday IS NOT NULL)
                        GROUP BY birthday
                        ORDER BY birthday
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalYearMembers = temp.ToList();

                // 당일, 전일 회원(연령대) 수
                sql = @"
                          SELECT insert_date, birthday || '0대' AS year, COUNT (*)
                            FROM (SELECT TO_CHAR (insert_date, 'YYYYMMDD')
                                             AS insert_date,
                                         SUBSTR (TO_CHAR (2021 - TO_NUMBER (SUBSTR (birthday, 1, 4))),
                                                 1,
                                                 1)
                                             birthday
                                    FROM (SELECT mcode, insert_date, birthday, test_gbn FROM app_customer
                                          UNION ALL
                                          SELECT mcode, insert_date, birthday, test_gbn FROM app_customer_deleted)
                                   WHERE     mcode = 2
                                         AND birthday IS NOT NULL
                                         AND test_gbn = 'R'
                                         AND insert_date >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND TO_CHAR (insert_date, 'yyyyMMdd') BETWEEN TO_CHAR (
                                                                                           SYSDATE - 2,
                                                                                           'yyyyMMdd')
                                                                                   AND TO_CHAR (
                                                                                           SYSDATE - 1,
                                                                                           'yyyyMMdd'))
                        GROUP BY insert_date, birthday
                        ORDER BY insert_date DESC, birthday
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                yearMembers = temp.ToList();


                // 누적 완료/취소 주문수
                sql = @"
                          SELECT /*+ full(a)full(b) */ DECODE (a.status,  '40', '완료',  '50', '취소')     status,
                                 COUNT (*) COUNT
                            FROM (SELECT * FROM dorder
                                  UNION ALL
                                  SELECT * FROM dorder_past) a,
                                 callcenter b
                           WHERE     a.cccode = b.cccode
                                 AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                 AND b.mcode = 2
                                 AND a.test_gbn = 'N'
                                 AND a.status IN ('40', '50')
                        GROUP BY a.status
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalOrders = temp.ToList();

                // 당일, 전일 완료/취소 주문수
                sql = @"
                          SELECT /*+ full(a)full(b) */ a.order_date,
                                 DECODE (a.status,  '40', '완료',  '50', '취소')     status,
                                 COUNT (*) COUNT
                            FROM (SELECT * FROM dorder
                                  UNION ALL
                                  SELECT * FROM dorder_past) a,
                                 callcenter b
                           WHERE     a.cccode = b.cccode
                                 AND b.mcode = 2
                                 AND a.test_gbn = 'N'
                                 AND a.status IN ('40', '50')
                                 AND a.order_date BETWEEN TO_CHAR (SYSDATE - 2, 'yyyyMMdd')
                                                      AND TO_CHAR (SYSDATE - 1, 'yyyyMMdd')
                        GROUP BY a.order_date, a.status
                        ORDER BY a.order_date DESC
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                orders = temp.ToList();

                // 누적 주문취소 사유별 건수
                sql = @"
                          SELECT /*+ full(a)full(b) */ DECODE (cancel_code,
                                         '00', '사유없음',
                                         '10', '고객본인취소',
                                         '11', '시간지연',
                                         '12', '재접수',
                                         '20', '가맹점취소',
                                         '21', '배달불가',
                                         '22', '메뉴품절',
                                         '23', '가맹점휴무',
                                         '24', '주소입력오류',
                                         '25', '가맹점 정산 접수거부',
                                         '26', 'POS서버 응답없음',
                                         '30', '결재대기 자동취소',
                                         '40', '예약주문 고객 취소',
                                         '45', '예약주문 가맹점 취소')
                                     cancel_code,
                                 COUNT (cancel_code)
                                     COUNT
                            FROM (SELECT * FROM dorder
                                  UNION ALL
                                  SELECT * FROM dorder_past) a,
                                 callcenter b
                           WHERE     a.cccode = b.cccode
                                 AND b.mcode = 2
                                 AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                 AND a.test_gbn = 'N'
                                 AND NVL (a.cancel_code, '00') <> '30'
                                 AND a.cancel_code IS NOT NULL
                        GROUP BY cancel_code
                        ORDER BY COUNT DESC
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                totalCancel = temp.ToList();

                // 당일, 전일 주문취소 사유별 건수
                sql = @"
                          SELECT /*+ full(a)full(b) */ order_date,
                                 DECODE (cancel_code,
                                         '00', '사유없음',
                                         '10', '고객본인취소',
                                         '11', '시간지연',
                                         '12', '재접수',
                                         '20', '가맹점취소',
                                         '21', '배달불가',
                                         '22', '메뉴품절',
                                         '23', '가맹점휴무',
                                         '24', '주소입력오류',
                                         '25', '가맹점 정산 접수거부',
                                         '26', 'POS서버 응답없음',
                                         '30', '결재대기 자동취소',
                                         '40', '예약주문 고객 취소',
                                         '45', '예약주문 가맹점 취소')
                                     cancel_code,
                                 COUNT (cancel_code)
                                     COUNT
                            FROM (SELECT * FROM dorder
                                  UNION ALL
                                  SELECT * FROM dorder_past) a,
                                 callcenter b
                           WHERE     a.cccode = b.cccode
                                 AND b.mcode = 2
                                 AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                 AND a.test_gbn = 'N'
                                 AND NVL (a.cancel_code, '00') <> '30'
                                 AND a.cancel_code IS NOT NULL
                                 AND TO_CHAR (a.order_time, 'yyyyMMdd') BETWEEN TO_CHAR (SYSDATE - 2,
                                                                                         'yyyyMMdd')
                                                                            AND TO_CHAR (SYSDATE - 1,
                                                                                         'yyyyMMdd')
                        GROUP BY order_date, cancel_code
                        ORDER BY order_date DESC
                ";

                temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                cancels = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalOS = totalInstalled, os = osInstalled, totalYearMembers = totalYearMembers, yearMembers = yearMembers, totalOrders = totalOrders, orders = orders, totalCancel = totalCancel, cancels = cancels });
        }


        // 일자별 회원/비회원(미사용)
        [HttpGet("getDailyMemberCount")]
        public async Task<IActionResult> getDailyMemberCount()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                  SELECT INSERT_DATE
                                             AS 가입일,
                                         CASE
                                             WHEN CUST_GBN = '1' THEN '비회원'
                                             WHEN CUST_GBN = '2' THEN '회원'
                                             ELSE CUST_GBN
                                         END
                                             AS 구분,
                                         COUNT (CUST_GBN)
                                             AS 수량
                                    FROM (SELECT TO_CHAR (INSERT_DATE, 'YYYYMMDD')       AS INSERT_DATE,
                                                 DECODE (CUST_ID_GBN, 'Z', '1', '2')     CUST_GBN
                                            FROM (SELECT mcode, insert_date, cust_id_gbn FROM app_customer
                                                  UNION ALL
                                                  SELECT mcode, insert_date, cust_id_gbn
                                                    FROM app_customer_deleted)
                                           WHERE     MCODE = 2
                                                 AND TEST_GBN = 'R'
                                                 AND INSERT_DATE > TO_DATE ('2021080917', 'YYYYMMDDHH24'))
                                GROUP BY INSERT_DATE, CUST_GBN
                                ORDER BY 가입일 DESC
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 일자별 가입회원 수 : 계정구분(미사용)
        [HttpGet("getDailyMemberDiv")]
        public async Task<IActionResult> getDailyMemberDiv()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT INSERT_DATE AS 가입일 ,
                                       CASE
                                           WHEN CUST_ID_GBN = 'A' THEN '공공앱'
                                           WHEN CUST_ID_GBN = 'G' THEN '구글'
                                           WHEN CUST_ID_GBN = 'I' THEN '아이폰'
                                           WHEN CUST_ID_GBN = 'K' THEN '카카오'
                                           WHEN CUST_ID_GBN = 'N' THEN '네이버'
                                           WHEN CUST_ID_GBN = 'Z' THEN '비회원'
                                           ELSE CUST_ID_GBN
                                       END AS 구분 ,
                                       COUNT(INSERT_DATE) AS 수량
                                  FROM (SELECT TO_CHAR(INSERT_DATE, 'YYYYMMDD') AS INSERT_DATE,
                                               CUST_ID_GBN
                                          FROM APP_CUSTOMER
                                         WHERE MCODE = 2
                                           AND CUST_ID_GBN <> 'Z'
                                           AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                         UNION ALL
                                SELECT TO_CHAR(INSERT_DATE, 'YYYYMMDD') AS INSERT_DATE,
                                               CUST_ID_GBN
                                          FROM APP_CUSTOMER_DELETED
                                         WHERE MCODE = 2
                                           AND CUST_ID_GBN <> 'Z'
                                           AND INSERT_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24'))
                                 GROUP BY INSERT_DATE, CUST_ID_GBN
                                HAVING COUNT(CUST_ID_GBN) > 0
                                 ORDER BY INSERT_DATE DESC, CUST_ID_GBN
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 일자별 탈퇴 회원 수(미사용)
        [HttpGet("getDailyMemberDel")]
        public async Task<IActionResult> getDailyMemberDel(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                SELECT TO_CHAR(DEL_DATE, 'YYYYMMDD') AS DEL_DATE,
                                       COUNT(*) COUNT
                                  FROM APP_CUSTOMER_DELETED
                                 WHERE MCODE = 2
                                   AND CUST_ID_GBN <> 'Z'
                                   AND DEL_DATE > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                   AND TO_CHAR(DEL_DATE, 'YYYYMMDD') BETWEEN :date_begin AND :date_end
                                 GROUP BY TO_CHAR(DEL_DATE,
                                               'YYYYMMDD')
                                 ORDER BY DEL_DATE
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 일자별 성별(미사용)
        [HttpGet("getDailyMemberGender")]
        public async Task<IActionResult> getDailyMemberGender()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                  SELECT INSERT_DATE
                                             AS 가입일,
                                         CASE
                                             WHEN GENDER = 'F' THEN '여성'
                                             WHEN GENDER = 'M' THEN '남성'
                                             WHEN GENDER IS NULL THEN 'NULL'
                                             ELSE GENDER
                                         END
                                             AS 성별,
                                         COUNT (GENDER)
                                             AS 수량
                                    FROM (SELECT TO_CHAR (INSERT_DATE, 'YYYYMMDD')     AS INSERT_DATE,
                                                 NVL (GENDER, '알수없음')          AS GENDER
                                            FROM (SELECT mcode,
                                                         insert_date,
                                                         cust_id_gbn,
                                                         gender,
                                                         test_gbn
                                                    FROM app_customer
                                                  UNION ALL
                                                  SELECT mcode,
                                                         insert_date,
                                                         cust_id_gbn,
                                                         gender,
                                                         test_gbn
                                                    FROM app_customer_deleted)
                                           WHERE     MCODE = 2
                                                 AND CUST_ID_GBN <> 'Z'
                                                 AND TEST_GBN = 'R'
                                                 AND INSERT_DATE > TO_DATE ('2021080917', 'YYYYMMDDHH24'))
                                GROUP BY INSERT_DATE, GENDER
                                  HAVING COUNT (GENDER) > 0
                                ORDER BY INSERT_DATE DESC, GENDER
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 일자별 나이별(미사용)
        [HttpGet("getDailyMemberAge")]
        public async Task<IActionResult> getDailyMemberAge()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                  SELECT INSERT_DATE            가입일,
                                         BIRTHDAY || '0대'     AS 연령,
                                         COUNT (BIRTHDAY)       AS 수량
                                    FROM (SELECT TO_CHAR (INSERT_DATE, 'YYYYMMDD')
                                                     AS INSERT_DATE,
                                                 SUBSTR (TO_CHAR (2021 - TO_NUMBER (SUBSTR (BIRTHDAY, 1, 4))),
                                                         1,
                                                         1)
                                                     AS BIRTHDAY,
                                                 CASE WHEN NVL (BIRTHDAY, 1) = 1 THEN 1 ELSE 0 END
                                                     AS BIRTHDAY_NULL
                                            FROM (SELECT mcode,
                                                         insert_date,
                                                         birthday,
                                                         cust_id_gbn,
                                                         test_gbn
                                                    FROM app_customer
                                                  UNION ALL
                                                  SELECT mcode,
                                                         insert_date,
                                                         birthday,
                                                         cust_id_gbn,
                                                         test_gbn
                                                    FROM app_customer_deleted)
                                           WHERE     MCODE = 2
                                                 AND INSERT_DATE BETWEEN TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                     AND TRUNC (SYSDATE)
                                                 AND CUST_ID_GBN <> 'Z'
                                                 AND TEST_GBN = 'R')
                                GROUP BY INSERT_DATE, BIRTHDAY
                                  HAVING COUNT (BIRTHDAY) > 0
                                ORDER BY INSERT_DATE DESC, BIRTHDAY
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // OS별 회원(미사용)
        [HttpGet("getDailyMemberOS")]
        public async Task<IActionResult> getDailyMemberOS()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                              SELECT INSERT_DATE
                                         AS 가입일,
                                     DECODE (DEVICE_GBN,  'A', '안드로이드',  'I', '아이폰')
                                         AS OS,
                                     COUNT (DEVICE_GBN)
                                         AS 수량
                                FROM (SELECT TO_CHAR (INSERT_DATE, 'YYYYMMDD') AS INSERT_DATE, DEVICE_GBN
                                        FROM (SELECT mcode,
                                                     insert_date,
                                                     cust_id_gbn,
                                                     test_gbn,
                                                     device_gbn
                                                FROM app_customer
                                              UNION ALL
                                              SELECT mcode,
                                                     insert_date,
                                                     cust_id_gbn,
                                                     test_gbn,
                                                     device_gbn
                                                FROM app_customer_deleted)
                                       WHERE     MCODE = 2
                                             AND INSERT_DATE BETWEEN TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                                 AND TRUNC (SYSDATE)
                                             AND CUST_ID_GBN = 'Z'
                                             AND TEST_GBN = 'R'
                                             AND DEVICE_GBN IN ('A', 'I'))
                            GROUP BY INSERT_DATE, DEVICE_GBN
                            ORDER BY INSERT_DATE DESC
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 전체건수O(미사용)
        [HttpGet("getOrderCount")]
        public async Task<IActionResult> getOrderCount()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT ORDER_DATE AS 주문일,
                                       DECODE(STATUS, '10', '접수', '20', '대기', '30', '가맹점접수확인', '35', '운행', '40', '완료', '50', '취소', '80', '결제대기') AS 상태,
                                       COUNT(STATUS) AS 수량
                                  FROM (SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                               STATUS
                                          FROM DORDER A,
                                               CALLCENTER B
                                         WHERE A.CCCODE = B.CCCODE
                                           AND MCODE = 2
                                           AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           and a.status not in ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26') 
                                           AND TEST_GBN = 'N'
                                         UNION ALL
                                SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                               STATUS
                                          FROM DORDER_PAST A,
                                               CALLCENTER B
                                         WHERE A.CCCODE = B.CCCODE
                                           AND MCODE = 2
                                           AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                           and a.status not in ('80','20')
                                           and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26') 
                                           AND TEST_GBN = 'N')
                                 GROUP BY ORDER_DATE, STATUS
                                 ORDER BY 주문일 DESC
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 취소사유현황O(미사용)
        [HttpGet("getCancelReason")]
        public async Task<IActionResult> getCancelReason()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                  SELECT DECODE (cancel_code,
                                                 '00', '사유없음',
                                                 '10', '고객본인취소',
                                                 '11', '시간지연',
                                                 '12', '재접수',
                                                 '20', '가맹점취소',
                                                 '21', '배달불가',
                                                 '22', '메뉴품절',
                                                 '23', '가맹점휴무',
                                                 '24', '주소입력오류',
                                                 '25', '가맹점 정산 접수거부',
                                                 '26', 'POS서버 응답없음',
                                                 '30', '결재대기 자동취소',
                                                 '40', '예약주문 고객 취소',
                                                 '45', '예약주문 가맹점 취소')
                                             cancel_code,
                                         COUNT (cancel_code)
                                             COUNT
                                    FROM (SELECT * FROM dorder
                                          UNION
                                          SELECT * FROM dorder_past) a,
                                         callcenter b
                                   WHERE     a.cccode = b.cccode
                                         AND b.mcode = 2
                                         AND a.order_time > TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                         AND a.test_gbn = 'N'
                                         and a.status not in ('80','20')
                                         and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26') 
                                         AND a.cancel_code IS NOT NULL
                                GROUP BY cancel_code
                                ORDER BY COUNT DESC
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        // 일자별 취소사유O(미사용)
        [HttpGet("getDailyCancelReason")]
        public async Task<IActionResult> getDailyCancelReason()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                string sql = @"
                                SELECT ORDER_DATE AS 주문일,
                                       CODE_NM AS 취소사유,
                                       CANCEL_CNT AS 수량
                                  FROM (SELECT ORDER_DATE,
                                               NVL(CANCEL_CODE, '00') AS CANCEL_CODE,
                                               COUNT( NVL(CANCEL_CODE, '00')) AS CANCEL_CNT
                                          FROM (SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                       CANCEL_CODE
                                                  FROM DORDER A,
                                                       CALLCENTER B
                                                 WHERE A.CCCODE = B.CCCODE
                                                   AND B.MCODE = 2
                                                   AND STATUS = '50'
                                                   and a.cancel_code in ('00','10','11','20','21','22','26') 
                                                   AND TEST_GBN = 'N'
                                                   AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24')
                                                 UNION ALL
                                SELECT TO_CHAR(ORDER_TIME, 'YYYYMMDD') AS ORDER_DATE,
                                                       CANCEL_CODE
                                                  FROM DORDER_PAST A,
                                                       CALLCENTER B
                                                 WHERE A.CCCODE = B.CCCODE
                                                   AND B.MCODE = 2
                                                   AND STATUS = '50'
                                                   and a.cancel_code in ('00','10','11','20','21','22','26') 
                                                   AND TEST_GBN = 'N'
                                                   AND ORDER_TIME > TO_DATE('2021080917', 'YYYYMMDDHH24'))
                                         GROUP BY ORDER_DATE, NVL(CANCEL_CODE, '00')) A,
                                       (SELECT CODE,
                                               CODE_NM
                                          FROM ETC_CODE
                                         WHERE MCODE = 0
                                           AND PGM_GROUP = 'O'
                                           AND CODE_GRP = '10'
                                           AND USE_GBN = 'Y') B
                                 WHERE A.CANCEL_CODE = B.CODE(+)
                                 ORDER BY 주문일 DESC
                ";

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                Rdata = temp.ToList();



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        // 성별 가입수(미사용)
        [HttpGet("getCustomerGender")]
        public async Task<IActionResult> getCustomerGender(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @$"
                                 SELECT INS_DATE,
                                        SUM(CASE WHEN GENDER = 'F' THEN 1 END) AS FEMALE,
                                        SUM(CASE WHEN GENDER = 'M' THEN 1 END) AS MALE,
                                        SUM(CASE WHEN GENDER IS NULL THEN 1 END) AS NODATA,
                                        SUM(1) AS TOTAL
                                FROM(SELECT TO_CHAR(INSERT_DATE,'yyyymmdd') AS INS_DATE, GENDER
                                    FROM APP_CUSTOMER
                                    WHERE MCODE = 2
                                    AND CUST_ID_GBN <> 'Z'
                                    AND TEST_GBN = 'R'
                                    UNION ALL
                                    SELECT TO_CHAR(INSERT_DATE,'yyyymmdd') AS INS_DATE, GENDER
                                    FROM APP_CUSTOMER_DELETED
                                    WHERE MCODE = 2
                                    AND CUST_ID_GBN <> 'Z'
                                    AND TEST_GBN = 'R')
                                WHERE INS_DATE BETWEEN TO_DATE(:date_begin||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:date_end||' 235959', 'YYYYMMDD HH24MISS')
                                GROUP BY INS_DATE
                                ORDER BY INS_DATE DESC
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 주문별 통계,엑셀통계 - 일자별 결제(완료건만)(기간조건:ORDER_TIME 주문시간)(미사용)
        /// </summary>
        /// <remarks>
        /// 결제금액 기준(AMOUNT)
        /// </remarks>
        [HttpGet("getDailyOrderPyaGbn")]
        public async Task<IActionResult> getDailyOrderPyaGbn(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT ORDER_DATE
                                             주문일,
                                         case when pay_div = '11' then '만나서 현금'
                                              when pay_div = '32' then '앱 카드'
                                              when pay_div = '37' then '행복페이'
                                              when pay_div = '52' then '만나서 카드'
                                              when pay_div = '3N' then '네이버페이'
                                              when pay_div = '3K' then '카카오페이'
                                              when pay_div = '3S' then '삼성페이' 
                                              when pay_div = '3T' then '토스결제' 
                                              when pay_div = '3V' then '모바일상품권' 
                                              when pay_div = '3H' then '신한PG' 
                                              when pay_div = '3C' then '아동급식카드' 
                                              when pay_div = '3BC' then 'BC_TOP_POINT' 
                                              when pay_div = '3M' then 'KB페이' 
                                         end as 결제구분,
                                         COUNT (CASE WHEN PAY_DIV = '32' THEN 1 END)
                                             AS 일반카드건수,
                                         SUM (CASE WHEN PAY_DIV = '32' THEN AMOUNT END)
                                             AS 일반카드금액,
                                         COUNT (CASE WHEN PAY_DIV = '37' THEN 1 END)
                                             AS 행복페이건수,
                                         SUM (CASE WHEN PAY_DIV = '37' THEN AMOUNT END)
                                             AS 행복페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '52' THEN 1 END)
                                             AS 만나서카드건수,
                                         SUM (CASE WHEN PAY_DIV = '52' THEN AMOUNT END)
                                             AS 만나서카드금액,
                                         COUNT (CASE WHEN PAY_DIV = '11' THEN 1 END)
                                             AS 만나서현금건수,
                                         SUM (CASE WHEN PAY_DIV = '11' THEN AMOUNT END)
                                             AS 만나서현금금액,
                                         COUNT (CASE WHEN PAY_DIV = '3N' THEN 1 END)
                                             AS 네이버페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3N' THEN AMOUNT END)
                                             AS 네이버페이금액,
                                        COUNT (CASE WHEN PAY_DIV = '3K' THEN 1 END)
                                             AS 카카오페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3K' THEN AMOUNT END)
                                             AS 카카오페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '3S' THEN 1 END)
                                             AS 삼성페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3S' THEN AMOUNT END)
                                             AS 삼성페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '3T' THEN 1 END)
                                             AS 토스결제건수,
                                         SUM (CASE WHEN PAY_DIV = '3T' THEN AMOUNT END)
                                             AS 토스결제금액,
                                         COUNT (CASE WHEN PAY_DIV = '3V' THEN 1 END)
                                             AS 모바일상품권건수,
                                         SUM (CASE WHEN PAY_DIV = '3V' THEN AMOUNT END)
                                             AS 모바일상품권금액,
                                         COUNT (CASE WHEN PAY_DIV = '3H' THEN 1 END)
                                             AS 신한PG건수,
                                         SUM (CASE WHEN PAY_DIV = '3H' THEN AMOUNT END)
                                             AS 신한PG금액,
                                         COUNT (CASE WHEN PAY_DIV = '3C' THEN 1 END)
                                             AS 아동급식카드건수,
                                         SUM (CASE WHEN PAY_DIV = '3C' THEN AMOUNT END)
                                             AS 아동급식카드금액,
                                         COUNT (CASE WHEN PAY_DIV = '3BC' THEN 1 END)
                                             AS BC_TOP_POINT건수,
                                         SUM (CASE WHEN PAY_DIV = '3BC' THEN AMOUNT END)
                                             AS BC_TOP_POINT금액,
                                         COUNT (CASE WHEN PAY_DIV = '3M' THEN 1 END)
                                             AS KB페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3M' THEN AMOUNT END)
                                             AS KB페이금액
                                    FROM (SELECT TO_CHAR (ORDER_TIME, 'yyyyMMdd')     AS ORDER_DATE,
                                                 APP_PAY_GBN || case when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                     else PAY_GBN end AS PAY_DIV,
                                                 AMOUNT
                                            FROM DORDER A, CALLCENTER B, dorder_detail c
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 and a.order_no = c.order_no
                                                 AND NVL (CANCEL_CODE, '00') <> '30'
                                                 AND TEST_GBN = 'N'
                                                 AND STATUS = '40'
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                          UNION ALL
                                          SELECT TO_CHAR (ORDER_TIME, 'yyyyMMdd')     AS ORDER_DATE,
                                                 APP_PAY_GBN || case when app_pay_gbn = '1' then '1' -- 현금결제의 아이폰 오류데이터('12')를 걸러주기 위함
                                                                     when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                     else PAY_GBN end AS PAY_DIV, 
                                                 AMOUNT
                                            FROM DORDER_PAST A, CALLCENTER B, dorder_detail c
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 and a.order_no = c.order_no
                                                 AND NVL (CANCEL_CODE, '00') <> '30'
                                                 AND TEST_GBN = 'N'
                                                 AND STATUS = '40'
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                      AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                where pay_div in ('11','32','37','52','3N','3K','3S','3T','3V','3H','3C','3BC','3M')
                                GROUP BY ORDER_DATE, PAY_DIV
                                ORDER BY 주문일 DESC, 결제구분
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 일자별 결제 배달완료(comp_dt)기준(완료건만)(미사용)
        /// </summary>
        /// <remarks>
        /// 결제금액 기준(AMOUNT)
        /// </remarks>
        [HttpGet("getDailyOrderPyaGbnDeliTime")]
        public async Task<IActionResult> getDailyOrderPyaGbnDeliTime(string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);

                db.Open();

                string sql = @"
                                  SELECT COMP_DT
                                             주문일,
                                         case when pay_div = '11' then '만나서 현금'
                                              when pay_div = '32' then '앱 카드'
                                              when pay_div = '37' then '행복페이'
                                              when pay_div = '52' then '만나서 카드'
                                              when pay_div = '3N' then '네이버페이'
                                              when pay_div = '3K' then '카카오페이'
                                              when pay_div = '3S' then '삼성페이' 
                                              when pay_div = '3T' then '토스결제' 
                                              when pay_div = '3V' then '모바일상품권' 
                                              when pay_div = '3H' then '신한PG'  
                                              when pay_div = '3C' then '아동급식카드' 
                                              when pay_div = '3BC' then 'BC_TOP_POINT' 
                                              when pay_div = '3M' then 'KB페이' 
                                         end as 결제구분,
                                         COUNT (CASE WHEN PAY_DIV = '32' THEN 1 END)
                                             AS 일반카드건수,
                                         SUM (CASE WHEN PAY_DIV = '32' THEN AMOUNT END)
                                             AS 일반카드금액,
                                         COUNT (CASE WHEN PAY_DIV = '37' THEN 1 END)
                                             AS 행복페이건수,
                                         SUM (CASE WHEN PAY_DIV = '37' THEN AMOUNT END)
                                             AS 행복페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '52' THEN 1 END)
                                             AS 만나서카드건수,
                                         SUM (CASE WHEN PAY_DIV = '52' THEN AMOUNT END)
                                             AS 만나서카드금액,
                                         COUNT (CASE WHEN PAY_DIV = '11' THEN 1 END)
                                             AS 만나서현금건수,
                                         SUM (CASE WHEN PAY_DIV = '11' THEN AMOUNT END)
                                             AS 만나서현금금액,
                                         COUNT (CASE WHEN PAY_DIV = '3N' THEN 1 END)
                                             AS 네이버페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3N' THEN AMOUNT END)
                                             AS 네이버페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '3K' THEN 1 END)
                                             AS 카카오페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3K' THEN AMOUNT END)
                                             AS 카카오페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '3S' THEN 1 END)
                                             AS 삼성페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3S' THEN AMOUNT END)
                                             AS 삼성페이금액,
                                         COUNT (CASE WHEN PAY_DIV = '3T' THEN 1 END)
                                             AS 토스결제건수,
                                         SUM (CASE WHEN PAY_DIV = '3T' THEN AMOUNT END)
                                             AS 토스결제금액,
                                         COUNT (CASE WHEN PAY_DIV = '3V' THEN 1 END)
                                             AS 모바일상품권건수,
                                         SUM (CASE WHEN PAY_DIV = '3V' THEN AMOUNT END)
                                             AS 모바일상품권금액,
                                         COUNT (CASE WHEN PAY_DIV = '3H' THEN 1 END)
                                             AS 신한PG건수,
                                         SUM (CASE WHEN PAY_DIV = '3H' THEN AMOUNT END)
                                             AS 신한PG금액,
                                         COUNT (CASE WHEN PAY_DIV = '3C' THEN 1 END)
                                             AS 아동급식카드건수,
                                         SUM (CASE WHEN PAY_DIV = '3C' THEN AMOUNT END)
                                             AS 아동급식카드금액,
                                         COUNT (CASE WHEN PAY_DIV = '3BC' THEN 1 END)
                                             AS BC_TOP_POINT건수,
                                         SUM (CASE WHEN PAY_DIV = '3BC' THEN AMOUNT END)
                                             AS BC_TOP_POINT금액,
                                         COUNT (CASE WHEN PAY_DIV = '3M' THEN 1 END)
                                             AS KB페이건수,
                                         SUM (CASE WHEN PAY_DIV = '3M' THEN AMOUNT END)
                                             AS KB페이금액
                                    FROM (SELECT TO_CHAR (comp_dt, 'yyyyMMdd')     AS comp_dt,
                                                 APP_PAY_GBN || case when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                     else PAY_GBN end AS PAY_DIV, 
                                                 AMOUNT
                                            FROM DORDER A, CALLCENTER B, dorder_detail c
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 and a.order_no = c.order_no
                                                 AND TEST_GBN = 'N'
                                                 AND STATUS = '40'
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND to_char(A.comp_dt, 'YYYYMMDD') BETWEEN :date_begin
                                                                                            AND :date_end
                                          UNION ALL
                                          SELECT TO_CHAR (comp_dt, 'yyyyMMdd')     AS comp_dt,
                                                 APP_PAY_GBN || case when app_pay_gbn = '1' then '1' -- 현금결제의 아이폰 오류데이터('12')를 걸러주기 위함
                                                                     when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                     else PAY_GBN end AS PAY_DIV, 
                                                 AMOUNT
                                            FROM DORDER_PAST A, CALLCENTER B, dorder_detail c
                                           WHERE     A.CCCODE = B.CCCODE
                                                 AND B.MCODE = 2
                                                 and a.order_no = c.order_no
                                                 AND TEST_GBN = 'N'
                                                 AND STATUS = '40'
                                                 AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                 AND to_char(A.comp_dt, 'YYYYMMDD') BETWEEN :date_begin
                                                                                            AND :date_end)
                                GROUP BY comp_dt, PAY_DIV
                                ORDER BY 주문일 DESC, 결제구분
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        /// <summary>
        /// 엑셀통계 - 일자별 결제 합(기간조건:ORDER_TIME 주문시간)O(미사용)
        /// </summary>
        /// <remarks>
        /// 완료 취소값을 모두 합한 값. <br/>
        /// div: 0 - 할인금액 차감 (실제결제금액:AMOUNT) / 1 - 할인금액 제외없이 (TOT_AMT)
        /// </remarks>
        [HttpGet("getDailyOrderPyaGbnSum")]
        public async Task<IActionResult> getDailyOrderPyaGbnSum(string date_begin, string date_end, string div)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("div", div);

                db.Open();

                string sql = @"
                                  SELECT ORDER_DATE
                                                 주문일,
                                             case when pay_div = '11' then '만나서 현금'
                                                  when pay_div = '32' then '앱 카드'
                                                  when pay_div = '37' then '행복페이'
                                                  when pay_div = '52' then '만나서 카드'
                                                  when pay_div = '3N' then '네이버페이'
                                                  when pay_div = '3K' then '카카오페이'
                                                  when pay_div = '3S' then '삼성페이' 
                                                  when pay_div = '3T' then '토스결제' 
                                                  when pay_div = '3V' then '모바일상품권' 
                                                  when pay_div = '3H' then '신한PG'  
                                                  when pay_div = '3C' then '아동급식카드' 
                                                  when pay_div = '3BC' then 'BC_TOP_POINT' 
                                                  when pay_div = '3M' then 'KB페이' 
                                             end as 결제구분,
                                             COUNT (CASE WHEN PAY_DIV = '32' THEN 1 END)
                                                 AS 일반카드건수,
                                             SUM (CASE WHEN PAY_DIV = '32' THEN TOT_AMT END)
                                                 AS 일반카드금액,
                                             COUNT (CASE WHEN PAY_DIV = '37' THEN 1 END)
                                                 AS 행복페이건수,
                                             SUM (CASE WHEN PAY_DIV = '37' THEN TOT_AMT END)
                                                 AS 행복페이금액,
                                             COUNT (CASE WHEN PAY_DIV = '52' THEN 1 END)
                                                 AS 만나서카드건수,
                                             SUM (CASE WHEN PAY_DIV = '52' THEN TOT_AMT END)
                                                 AS 만나서카드금액,
                                             COUNT (CASE WHEN PAY_DIV = '11' THEN 1 END)
                                                 AS 만나서현금건수,
                                             SUM (CASE WHEN PAY_DIV = '11' THEN TOT_AMT END)
                                                 AS 만나서현금금액,
                                             COUNT (CASE WHEN PAY_DIV = '3N' THEN 1 END)
                                                 AS 네이버페이건수,
                                             SUM (CASE WHEN PAY_DIV = '3N' THEN TOT_AMT END)
                                                 AS 네이버페이금액,
                                             COUNT (CASE WHEN PAY_DIV = '3K' THEN 1 END)
                                                 AS 카카오페이건수,
                                             SUM (CASE WHEN PAY_DIV = '3K' THEN TOT_AMT END)
                                                 AS 카카오페이금액,
                                             COUNT (CASE WHEN PAY_DIV = '3S' THEN 1 END)
                                                 AS 삼성페이건수,
                                             SUM (CASE WHEN PAY_DIV = '3S' THEN TOT_AMT END)
                                                 AS 삼성페이금액,
                                             COUNT (CASE WHEN PAY_DIV = '3T' THEN 1 END)
                                                 AS 토스결제건수,
                                             SUM (CASE WHEN PAY_DIV = '3T' THEN TOT_AMT END)
                                                 AS 토스결제금액,
                                             COUNT (CASE WHEN PAY_DIV = '3V' THEN 1 END)
                                                 AS 모바일상품권건수,
                                             SUM (CASE WHEN PAY_DIV = '3V' THEN TOT_AMT END)
                                                 AS 모바일상품권금액,
                                             COUNT (CASE WHEN PAY_DIV = '3H' THEN 1 END)
                                                 AS 신한PG건수,
                                             SUM (CASE WHEN PAY_DIV = '3H' THEN TOT_AMT END)
                                                 AS 신한PG금액,
                                             COUNT (CASE WHEN PAY_DIV = '3C' THEN 1 END)
                                                 AS 아동급식카드건수,
                                             SUM (CASE WHEN PAY_DIV = '3C' THEN TOT_AMT END)
                                                 AS 아동급식카드금액,
                                             COUNT (CASE WHEN PAY_DIV = '3BC' THEN 1 END)
                                                 AS BC_TOP_POINT건수,
                                             SUM (CASE WHEN PAY_DIV = '3BC' THEN TOT_AMT END)
                                                 AS BC_TOP_POINT금액,
                                             COUNT (CASE WHEN PAY_DIV = '3M' THEN 1 END)
                                                 AS KB페이건수,
                                             SUM (CASE WHEN PAY_DIV = '3M' THEN TOT_AMT END)
                                                 AS KB페이금액
                                        FROM (SELECT TO_CHAR (ORDER_TIME, 'yyyyMMdd')     AS ORDER_DATE,
                                                     APP_PAY_GBN || case when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                         else PAY_GBN end AS PAY_DIV, 
                                                     CASE WHEN :div = 0 then AMOUNT ELSE TOT_AMT END TOT_AMT
                                                FROM DORDER A, CALLCENTER B, dorder_detail c
                                               WHERE     A.CCCODE = B.CCCODE
                                                     AND B.MCODE = 2
                                                     and a.order_no = c.order_no
                                                     and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                     AND TEST_GBN = 'N'
                                                     AND STATUS in ('40','50')
                                                     AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                     AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                          AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                              UNION ALL
                                              SELECT TO_CHAR (ORDER_TIME, 'yyyyMMdd')     AS ORDER_DATE,
                                                     APP_PAY_GBN || case when app_pay_gbn = '1' then '1' -- 현금결제의 아이폰 오류데이터('12')를 걸러주기 위함
                                                                         when a.PAY_GBN = '2' and c.card_point_yn = 'Y' then c.card_point_gbn 
                                                                         else PAY_GBN end AS PAY_DIV,
                                                     CASE WHEN :div = 0 then AMOUNT ELSE TOT_AMT END TOT_AMT
                                                FROM DORDER_PAST A, CALLCENTER B, dorder_detail c
                                               WHERE     A.CCCODE = B.CCCODE
                                                     AND B.MCODE = 2
                                                     and a.order_no = c.order_no
                                                     and case when a.status = '50' then a.cancel_code else '00' end in ('00','10','11','20','21','22','26')
                                                     AND TEST_GBN = 'N'
                                                     AND STATUS in ('40','50')
                                                     AND ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                     AND a.order_time BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                          AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                                    GROUP BY ORDER_DATE, PAY_DIV
                                    ORDER BY 주문일 DESC, 결제구분
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

        #endregion

    }
}
