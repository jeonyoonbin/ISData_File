﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Diagnostics;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [ApiController]
    [Route("/[controller]")]
    public class OrderController : ControllerBase
    {
        /// <summary>
        /// 주문 관리 - 목록 조회(기간조건: ORDER_TIME 주문시간)
        /// </summary>
        /// <remarks>
        /// serviceGbn 서비스 구분(빈값: 전체, 0: 주문(음식), 1: 특별관, 2: 꽃배달) <br/>
        /// divKey 검색어 구분(1:주문번호/2:전화번호/3:가맹점명/4:사업자번호/5:취소사유(CANCEL_TYPE)) <br/>
        /// 결제수단이 BC탑포인트인 경우 PAY_GBN: 'BC'(DB 저장값과는 다름) <br/>
        /// trad_yn 시장여부(빈값:전체, Y:시장, N:가맹점) <br/>
        /// pay_gbn 결제수단조건 <br/>
        /// </remarks>
        [HttpGet("getOrderList")]
        public async Task<IActionResult> getOrderList(string mCode, string serviceGbn, string dateBegin, string dateEnd, string state, string divKey, string keyword, string shop_cd, string cust_code, string trad_yn, string pay_gbn, string page, string rows)
        {
            if (string.IsNullOrEmpty(mCode))
            {
                return Ok(new { code = "99", msg = "mCode는 필수입니다." });
            }

            if (string.IsNullOrEmpty(dateBegin) || string.IsNullOrEmpty(dateEnd) || Convert.ToDateTime($@"{dateBegin.Substring(4, 2)}/{dateBegin.Substring(6, 2)}/{dateBegin.Substring(0, 4)}") > Convert.ToDateTime($@"{dateEnd.Substring(4, 2)}/{dateEnd.Substring(6, 2)}/{dateEnd.Substring(0, 4)}"))
            {
                return Ok(new { code = "99", msg = "기간을 제대로 설정해주세요." });
            }

            if (string.IsNullOrEmpty(page) || string.IsNullOrEmpty(rows))
            {
                return Ok(new { code = "99", msg = "페이징 정보를 제대로 설정해주세요." });
            }

            //Stopwatch stopWatch = new Stopwatch();

            //stopWatch.Start();
            string Rcount = string.Empty;
            string TotalCount = "0";
            string sTerm = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("mCode", mCode);
            param.Add("service_gbn", serviceGbn);
            param.Add("dateBegin", dateBegin);
            param.Add("dateEnd", dateEnd);
            param.Add("state", state);
            param.Add("shop_cd", shop_cd);
            param.Add("cust_code", cust_code);
            param.Add("trad_yn", trad_yn);
            param.Add("pay_gbn", pay_gbn);
            param.Add("keyword", keyword);
            param.Add("page", page);
            param.Add("row_count", rows);

            string sql = @"
                            SELECT
                            (SELECT COUNT (*)
                                      FROM DORDER A, SHOP_INFO B, CALLCENTER D
                                     WHERE     A.SHOP_CD = B.SHOP_CD AND B.CCCODE = D.CCCODE
                                           AND D.MCODE = :mCode
                                           AND B.service_gbn = :service_gbn)
                            +
                                    (SELECT COUNT (*)
                                      FROM DORDER_PAST A, SHOP_INFO B, CALLCENTER D
                                     WHERE     A.SHOP_CD = B.SHOP_CD AND B.CCCODE = D.CCCODE
                                           AND D.MCODE = :mCode
                                           AND B.service_gbn = :service_gbn)
                            FROM DUAL
                        ";


            string Rcode;
            string Rmsg;
            try
            {
                db.Open();

                // var TotalorderCount = await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);

                // TotalCount = TotalorderCount.ToString();

                string sService = string.Empty;

                if (string.IsNullOrEmpty(serviceGbn) == false)
                {
                    sService = "AND B.service_gbn = :service_gbn";
                }

                string sState = string.Empty;

                if (string.IsNullOrEmpty(state) == false)
                {
                    sState = "AND A.STATUS = :state";
                }

                string sShopCd = string.Empty;

                if (string.IsNullOrEmpty(shop_cd) == false)
                {
                    sShopCd = "AND A.SHOP_CD = :shop_cd";
                }

                string sCustCode = string.Empty;

                if (string.IsNullOrEmpty(cust_code) == false)
                {
                    sCustCode = "AND A.APP_CUST_CODE = :cust_code";
                }

                string sPayGbn = string.Empty;

                if (string.IsNullOrEmpty(pay_gbn) == false)
                {
                    sPayGbn = "and case when A.PAY_GBN = '2' and f.card_point_yn = 'Y' then f.card_point_gbn else a.pay_gbn end = :pay_gbn";
                }

                string sTradYn = string.Empty;

                if (string.IsNullOrEmpty(trad_yn) == false)
                {
                    //sTradYn = @"and case when: trad_yn = 'Y' then A.SHOP_CD
                    //                     when :trad_yn = 'N' then '0' end LIKE NVL(G.M_SHOP_CD, '0')";
                    if (trad_yn == "Y")
                    {
                        sTradYn = "and a.shop_cd = g.m_shop_cd";
                    }
                    else if(trad_yn == "N")
                    {
                        sTradYn = "and g.m_shop_cd is null";
                    }    
                }

                dateBegin = $@"{dateBegin.Substring(4, 2)}/{dateBegin.Substring(6, 2)}/{dateBegin.Substring(0, 4)}";

                DateTime dtBegin = Convert.ToDateTime(dateBegin);

                dateEnd = $@"{dateEnd.Substring(4, 2)}/{dateEnd.Substring(6, 2)}/{dateEnd.Substring(0, 4)}";

                DateTime dtEnd = Convert.ToDateTime(dateEnd);

                DateTime dtToday = Convert.ToDateTime(DateTime.Now.AddDays(-2).ToString("MM/dd/yyyy"));


                string hint = string.Empty;

                if ((dtEnd - dtBegin).Days >= 30) // 한달간격 이상인 경우 풀패러랠 힌트 추가
                {
                    hint = "/*+ full(A) parallel(A 4) */";
                }


                string sKeyword = string.Empty;
                if (string.IsNullOrEmpty(keyword) == false)
                {
                    switch (divKey)
                    {
                        case "1":
                            {
                                sKeyword = "AND A.ORDER_NO = :keyword";
                                break;
                            }
                        case "2":
                            {
                                sKeyword = "AND A.TELNO LIKE '%' || :keyword || '%'";
                                break;
                            }
                        case "3":
                            {
                                sKeyword = "AND B.SHOP_NAME LIKE '%' || :keyword || '%'";
                                break;
                            }
                        case "4":
                            {
                                sKeyword = "AND B.REG_NO = :keyword";
                                break;
                            }
                        case "5":
                            {
                                sKeyword = "AND e.code_nm like '%' || :keyword || '%'";
                                break;
                            }
                        default:
                            break;
                    }
                }
                

                sql = @$"
                        SELECT
                                (SELECT COUNT (*)
                                  FROM DORDER A, SHOP_INFO B, CALLCENTER D,
                                        (SELECT code, CODE_NM
                                            FROM   IS_DAEGU.ETC_CODE
                                            WHERE  MCODE = 0
                                            AND PGM_GROUP = 'O'
                                            AND CODE_GRP = '10'
                                            AND USE_GBN = 'Y'
                                            union all
                                            select '0', null
                                            from dual) E, dorder_detail f,
                                        TRAD_SHOP G
                                 WHERE     A.SHOP_CD = B.SHOP_CD
                                       and a.order_no = f.order_no
                                       AND B.CCCODE = D.CCCODE
                                       AND D.MCODE = :mCode
                                       --AND A.TEST_GBN = 'N'
                                       --AND NVL (A.CANCEL_CODE, '00') <> '30'
                                       and nvl(a.cancel_code,'0') = e.code
                                       AND A.SHOP_CD = G.M_SHOP_CD (+)
                                       AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                       and A.ORDER_TIME between to_date(:dateBegin || ' 000000','YYYYMMDD HH24MISS') and to_date(:dateEnd || ' 235959','YYYYMMDD HH24MISS')
                                       { sService }
                                       { sState }
                                       { sShopCd }
                                       { sCustCode }
                                       { sTradYn }
                                       { sPayGbn }
                                       { sKeyword }
                                )
                        +
                                (SELECT {hint} COUNT (*)
                                  FROM DORDER_PAST A, SHOP_INFO B, CALLCENTER D,
                                        (SELECT code, CODE_NM
                                        FROM   IS_DAEGU.ETC_CODE
                                        WHERE  MCODE = 0
                                            AND PGM_GROUP = 'O'
                                            AND CODE_GRP = '10'
                                            AND USE_GBN = 'Y'
                                            union all
                                            select '0', null
                                            from dual) E, dorder_detail f,
                                        TRAD_SHOP G
                                 WHERE     A.SHOP_CD = B.SHOP_CD
                                       and a.order_no = f.order_no
                                       AND B.CCCODE = D.CCCODE
                                       AND D.MCODE = :mCode
                                       --AND A.TEST_GBN = 'N'
                                       --AND NVL (A.CANCEL_CODE, '00') <> '30'
                                       and nvl(a.cancel_code,'0') = e.code
                                       AND A.SHOP_CD = G.M_SHOP_CD (+)
                                       AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                       and A.ORDER_TIME between to_date(:dateBegin || ' 000000','YYYYMMDD HH24MISS') and to_date(:dateEnd || ' 235959','YYYYMMDD HH24MISS')
                                       { sService }
                                       { sState }
                                       { sShopCd }
                                       { sCustCode }
                                       { sTradYn }
                                       { sPayGbn }
                                       { sKeyword }
                                )
                        FROM DUAL
                      ";

                var OrderCount = await db.ExecuteScalarAsync(sql, param, commandType: CommandType.Text);

                Rcount = OrderCount.ToString();

                string sUnionAll = string.Empty;

                if (dtBegin <= dtToday || dtEnd <= dtToday)
                {
                    sUnionAll = @$"
                                    UNION ALL
                                                  SELECT A.ORDER_NO,
                                                         B.service_gbn,
                                                         case when A.PAY_GBN = '2' and
                                                                   f.card_point_yn = 'Y' then f.card_point_gbn else a.pay_gbn end pay_gbn,
                                                         A.ORDER_TIME,
                                                         B.TELNO
                                                             AS SHOP_TELNO,
                                                         B.REG_NO,
                                                         B.SHOP_NAME,
                                                         B.SHOP_CD,
                                                         A.AMOUNT
                                                             AS ORDER_AMOUNT,
                                                         A.STATUS,
                                                         TO_CHAR(A.APP_CUST_CODE) as APP_CUST_CODE,
                                                         A.TELNO
                                                             AS CUSTOMER_TELNO,
                                                         A.CANCEL_CODE,
                                                         e.code_nm as cancel_type,
                                                         A.CANCEL_reason,
                                                         A.TUID,
                                                         C.CARD_NAME,
                                                         C.APP_NO,
                                                         C.AMOUNT
                                                             AS CARD_AMOUNT,
                                                         CASE
                                                             WHEN NVL (A.DISC_AMT, 0) > 0
                                                             THEN
                                                                 'Y'
                                                             ELSE
                                                                 'N'
                                                         END
                                                             DIRECT_PAY,
                                                         A.CCODE,
                                                         A.API_COM_CODE,
                                                         A.PACK_ORDER_YN,
                                                         --A.RIDER_DELI_MEMO,
                                                         --A.SHOP_DELI_MEMO,
                                                         A.APP_PAY_GBN,
                                                         b.remain_amt,
                                                         CASE WHEN G.M_SHOP_CD IS NULL THEN 'N' ELSE 'Y' END TRAD_YN
                                                    FROM DORDER_PAST   A,
                                                         SHOP_INFO     B,
                                                         CARD_PG_DETAIL C,
                                                         CALLCENTER    D,
                                                         (SELECT code, CODE_NM
                                                          FROM   IS_DAEGU.ETC_CODE
                                                          WHERE  MCODE = 0
                                                             AND PGM_GROUP = 'O'
                                                             AND CODE_GRP = '10'
                                                             AND USE_GBN = 'Y'
                                                             union all
                                                             select '0', null
                                                             from dual) E,
                                                             dorder_detail f,
                                                             TRAD_SHOP G
                                                   WHERE     A.SHOP_CD = B.SHOP_CD
                                                         and a.order_no = f.order_no
                                                         AND TO_CHAR(A.ORDER_NO) = C.ORDER_NO(+)
                                                         AND B.CCCODE = D.CCCODE
                                                         AND D.MCODE = :mCode
                                                         --AND A.TEST_GBN = 'N'
                                                         --AND NVL (A.CANCEL_CODE, '00') <> '30'
                                                         and nvl(a.cancel_code,'0') = e.code
                                                         AND A.SHOP_CD = G.M_SHOP_CD (+)
                                                         AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                         and A.ORDER_TIME between to_date(:dateBegin || ' 000000','YYYYMMDD HH24MISS') and to_date(:dateEnd || ' 235959','YYYYMMDD HH24MISS')
                                                         { sService }
                                                         { sState }
                                                         { sShopCd }
                                                         { sCustCode }
                                                         { sTradYn }
                                                         { sPayGbn }
                                                         { sKeyword }
                                ";
                }

                sql = @$"
                        SELECT /*+ opt_param('optimizer_dynamic_sampling' 0) opt_param('_optimizer_use_feedback','false') */ T2.*,
                                 (select system_gbn from dorder_detail where order_no = T2.ORDER_NO) system_gbn
                          FROM (SELECT ROWNUM AS RNUM,
                                 T1.ORDER_NO,
                                 SF_GET_SERVICE_GBN(T1.service_gbn) service_gbn,
                                 T1.PAY_GBN,
                                 T1.ORDER_TIME,
                                 T1.SHOP_TELNO,
                                 T1.REG_NO,
                                 T1.SHOP_NAME,
                                 T1.SHOP_CD,
                                 T1.ORDER_AMOUNT,
                                 T1.STATUS,
                                 t1.CANCEL_TYPE,
                                 T1.CANCEL_reason,
                                 T1.APP_CUST_CODE,
                                 T1.CUSTOMER_TELNO,
                                 T1.TUID,
                                 T1.CARD_NAME,
                                 T1.APP_NO,
                                 T1.CARD_AMOUNT,
                                 T1.DIRECT_PAY,
                                 (SELECT CUST_ID_GBN
                                  FROM   IS_DAEGU.APP_CUSTOMER
                                  WHERE  CUST_CODE = T1.CCODE)     AS CUST_ID_GBN,
                                 (SELECT IS_DAEGU.Sf_check_pos_install (T1.SHOP_CD)FROM DUAL) AS POS_INSTALL,
                                 (SELECT IS_DAEGU.Sf_check_pos_login (T1.SHOP_CD)FROM DUAL)   AS POS_LOGIN,
                                 T1.API_COM_CODE,
                                 T1.PACK_ORDER_YN,
                                 --T1.RIDER_DELI_MEMO,
                                 --T1.SHOP_DELI_MEMO,
                                 T1.APP_PAY_GBN,
                                 T1.remain_amt,
                                 T1.TRAD_YN
                                  FROM (  SELECT *
                                            FROM (SELECT /*+ index(C CARD_PG_DETAIL_IDX03) */ A.ORDER_NO,
                                                         B.service_gbn,
                                                         case when A.PAY_GBN = '2' and
                                                                   f.card_point_yn = 'Y' then f.card_point_gbn else a.pay_gbn end pay_gbn,
                                                         A.ORDER_TIME,
                                                         B.TELNO
                                                             AS SHOP_TELNO,
                                                         B.REG_NO,
                                                         B.SHOP_NAME,
                                                         B.SHOP_CD,
                                                         A.AMOUNT
                                                             AS ORDER_AMOUNT,
                                                         A.STATUS,
                                                         TO_CHAR(A.APP_CUST_CODE) as APP_CUST_CODE,
                                                         A.TELNO
                                                             AS CUSTOMER_TELNO,
                                                         A.CANCEL_CODE,
                                                         e.code_nm as cancel_type,
                                                         A.CANCEL_reason,
                                                         A.TUID,
                                                         C.CARD_NAME,
                                                         C.APP_NO,
                                                         C.AMOUNT
                                                             AS CARD_AMOUNT,
                                                         CASE
                                                             WHEN NVL (A.DISC_AMT, 0) > 0
                                                             THEN
                                                                 'Y'
                                                             ELSE
                                                                 'N'
                                                         END
                                                             DIRECT_PAY,
                                                         A.CCODE,
                                                         A.API_COM_CODE,
                                                         A.PACK_ORDER_YN,
                                                         --A.RIDER_DELI_MEMO,
                                                         --A.SHOP_DELI_MEMO,
                                                         A.APP_PAY_GBN,
                                                         b.remain_amt,
                                                         CASE WHEN G.M_SHOP_CD IS NULL THEN 'N' ELSE 'Y' END TRAD_YN
                                                    FROM DORDER        A,
                                                         SHOP_INFO     B,
                                                         CARD_PG_DETAIL C,
                                                         CALLCENTER    D,
                                                         (SELECT code, CODE_NM
                                                          FROM   IS_DAEGU.ETC_CODE
                                                          WHERE  MCODE = 0
                                                             AND PGM_GROUP = 'O'
                                                             AND CODE_GRP = '10'
                                                             AND USE_GBN = 'Y'
                                                             union all
                                                             select '0', null
                                                             from dual) E,
                                                             dorder_detail f,
                                                             TRAD_SHOP G
                                                   WHERE     A.SHOP_CD = B.SHOP_CD
                                                         and a.order_no = f.order_no
                                                         AND TO_CHAR(A.ORDER_NO) = C.ORDER_NO(+)
                                                         AND B.CCCODE = D.CCCODE
                                                         AND D.MCODE = :mCode
                                                         --AND A.TEST_GBN = 'N'
                                                         --AND NVL (A.CANCEL_CODE, '00') <> '30'
                                                         and nvl(a.cancel_code,'0') = e.code
                                                         AND A.SHOP_CD = G.M_SHOP_CD (+)
                                                         AND A.ORDER_TIME >= TO_DATE ('2021080917', 'YYYYMMDDHH24')
                                                         and A.ORDER_TIME between to_date(:dateBegin || ' 000000','YYYYMMDD HH24MISS') and to_date(:dateEnd || ' 235959','YYYYMMDD HH24MISS')
                                                         { sService }
                                                         { sState }
                                                         { sShopCd }
                                                         { sCustCode }
                                                         { sTradYn }
                                                         { sPayGbn }
                                                         { sKeyword }
                                                  { sUnionAll }
                                        )
                                        ORDER BY ORDER_NO DESC) T1
                                 WHERE ROWNUM <= ((:page - 1) * :row_count) + :row_count) T2
                         WHERE ((:page - 1) * :row_count) < RNUM
                        ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                //stopWatch.Stop();

                //sTerm = stopWatch.ElapsedMilliseconds.ToString();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            //return Ok(new { sql = sql.Replace("\r\n", ""), Term = sTerm, code = Rcode, msg = Rmsg, total_count = TotalCount, count = Rcount, data = items });
            return Ok(new { code = Rcode, msg = Rmsg, total_count = TotalCount, count = Rcount, data = items });
        }


        //[HttpGet]
        //public async Task<IActionResult> Get(int mCode, string dateBegin, string dateEnd, string state, int divKey, string keyword, string shop_cd, string cust_code, int page, int rows)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;
        //    string Rcount = string.Empty;
        //    string TotalCount = string.Empty;

        //    List<OrderList> items = new List<OrderList>();

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_ORDER.GET_ORDER_LIST",
        //    };

        //    cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mCode;
        //    cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = dateBegin;
        //    cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = dateEnd;
        //    cmd.Parameters.Add("in_state", OracleDbType.Char, 2).Value = state;
        //    cmd.Parameters.Add("in_div_key", OracleDbType.Int32).Value = divKey;
        //    cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 20).Value = keyword;
        //    cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = shop_cd;
        //    cmd.Parameters.Add("in_cust_code", OracleDbType.Int32).Value = cust_code;
        //    cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
        //    cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
        //    cmd.Parameters.Add("out_total_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();
        //        var rd = await cmd.ExecuteReaderAsync();

        //        TotalCount = cmd.Parameters["out_total_count"].Value.ToString();
        //        Rcount = cmd.Parameters["out_count"].Value.ToString();
        //        Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        while (await rd.ReadAsync())
        //        {


        //            OrderList item = new OrderList
        //            {
        //                orderNo = rd["ORDER_NO"].ToString(),
        //                payGbn = rd["PAY_GBN"].ToString(),
        //                orderTime = rd["ORDER_TIME"].ToString(),
        //                shopTelNo = rd["SHOP_TELNO"].ToString(),
        //                regNo = rd["REG_NO"].ToString(),
        //                shopName = rd["SHOP_NAME"].ToString(),
        //                shopCd = rd["SHOP_CD"].ToString(),
        //                orderAmount = rd["ORDER_AMOUNT"].ToString(),
        //                status = rd["STATUS"].ToString(),
        //                cancelType = rd["CANCEL_TYPE"].ToString(),
        //                customerTelNo = rd["CUSTOMER_TELNO"].ToString(),
        //                tuid = rd["TUID"].ToString(),
        //                cardName = rd["CARD_NAME"].ToString(),
        //                appNo = rd["APP_NO"].ToString(),
        //                cardAmount = rd["CARD_AMOUNT"].ToString(),
        //                directPay = rd["DIRECT_PAY"].ToString(),
        //                custIdGbn = rd["CUST_ID_GBN"].ToString(),
        //                posInstalled = rd["POS_INSTALL"].ToString(),
        //                posLogined = rd["POS_LOGIN"].ToString(),
        //                apiComCode = rd["API_COM_CODE"].ToString(),
        //                packOrderYn = rd["PACK_ORDER_YN"].ToString(),
        //            };

        //            items.Add(item);
        //        }

        //        await rd.CloseAsync();
        //        await conn.CloseAsync();

        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("admin/Order : Get", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg, total_count = TotalCount, count = Rcount, data = items });
        //}
        /*
        /// <summary>
        /// 주문 상세조회
        /// </summary>
        /// <remarks>
        /// shopCouponNo 가맹점 자체쿠폰번호 <br/>
        /// shopCouponAmt 가맹점 자체쿠폰 사용금액 <br/>
        /// voucherNo 모바일상품권 번호 <br/>
        /// voucherUseAmt 모바일상품권 사용금액 <br/>
        /// </remarks>
        [HttpGet("{orderNo}")]
        public async Task<IActionResult> Get(string orderNo, string ucode)
        {
            string Rposition = "/OrderDetail/{orderNo} : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rmenu = string.Empty;

            //List<OrderDetailMenu> orderMenu = new List<OrderDetailMenu>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_ORDER.GET_ORDER_DETAIL",
            };

            cmd.Parameters.Add("in_order_no", OracleDbType.Int32).Value = int.Parse(orderNo);
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            //cmd.Parameters.Add("out_menu", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_status_history_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            OrderDetail orderDetail = new OrderDetail();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                //menu = cmd.Parameters["out_menu"].Value.ToString();

                //Rmenu = Rmenu.Replace("\r\n", string.Empty).Replace("\\", string.Empty);

                await rd.ReadAsync();

                orderDetail.serviceGbn = rd["service_gbn"].ToString();
                orderDetail.addr1 = rd["ADDR1"].ToString();
                orderDetail.addr2 = rd["ADDR2"].ToString();
                orderDetail.loc = rd["LOC"].ToString();
                orderDetail.telNo = rd["TELNO"].ToString();
                orderDetail.shopCd = rd["SHOP_CD"].ToString();
                orderDetail.shopName = rd["SHOP_NAME"].ToString();
                orderDetail.regNo = rd["REG_NO"].ToString();
                orderDetail.shopAddr = rd["SHOP_ADDR"].ToString();
                orderDetail.shopLoc = rd["SHOP_LOC"].ToString();
                orderDetail.orderNo = rd["ORDER_NO"].ToString();

                //JsonSerializerOptions jso = new JsonSerializerOptions();
                //jso.Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;


                //orderDetail.menuDesc = System.Text.Json.JsonSerializer.Serialize( rd["MENU_DESC"].ToString(), jso);


                orderDetail.menuDesc = rd["MENU_DESC"].ToString().Replace("\r\n", string.Empty);
                orderDetail.deliTipAmt = rd["DELI_TIP_AMT"].ToString();
                orderDetail.menuAmt = rd["MENU_AMT"].ToString();
                orderDetail.couponName = rd["COUPON_NAME"].ToString();
                orderDetail.couponNo = rd["COUPON_NO"].ToString();
                orderDetail.couponAmt = rd["COUPON_AMT"].ToString();
                orderDetail.couponName2 = rd["COUPON_NAME2"].ToString();
                orderDetail.couponNo2 = rd["COUPON_NO2"].ToString();
                orderDetail.couponAmt2 = rd["COUPON_AMT2"].ToString();
                orderDetail.shopCouponNo = rd["shop_coupon_no"].ToString();
                orderDetail.shopCouponAmt = rd["shop_coupon_amt"].ToString();
                orderDetail.voucherNo = rd["voucher_no"].ToString();
                orderDetail.voucherUseAmt = rd["voucher_use_amt"].ToString();
                orderDetail.mileage = rd["MILEAGE_USE_AMT"].ToString();
                orderDetail.eventDisc = rd["EVENT_DISC"].ToString();
                orderDetail.beforeAmount = rd["BEFORE_AMOUNT"].ToString();
                orderDetail.amount = rd["AMOUNT"].ToString();
                orderDetail.cardName = rd["CARD_NAME"].ToString();
                orderDetail.appNo = rd["APP_NO"].ToString();
                orderDetail.cardNo = rd["CARD_NO"].ToString();
                orderDetail.appDate = rd["APP_DATE"].ToString();
                orderDetail.orderTime = rd["ORDER_TIME"].ToString();
                orderDetail.shopConfirmTime = rd["SHOP_CONFIRM_DT"].ToString();
                orderDetail.deliAllocTime = rd["DELI_ALLOC_DATE"].ToString();
                orderDetail.completeTime = rd["COMP_DT"].ToString();
                orderDetail.cancelTime = rd["CANCEL_DT"].ToString();

                orderDetail.riderDeliMemo = rd["RIDER_DELI_MEMO"].ToString();
                orderDetail.shopDeliMemo = rd["SHOP_DELI_MEMO"].ToString();
                orderDetail.appPayGbn = rd["APP_PAY_GBN"].ToString();

                orderDetail.toGoDiscAmt = rd["TO_GO_DISC_AMT"].ToString();

                orderDetail.geofenceYn = rd["GEOFENCE_YN"].ToString();
                orderDetail.destLon = rd["DEST_LON"].ToString();
                orderDetail.destLat = rd["DEST_LAT"].ToString();

                orderDetail.item_cd = rd["item_cd"].ToString();
                orderDetail.item_cd2 = rd["item_cd2"].ToString();
                orderDetail.item_cd3 = rd["item_cd3"].ToString();

                orderDetail.child_meal_disc = rd["child_meal_disc"].ToString();

                await rd.NextResultAsync();

                List<OrderStatusHistory> items = new List<OrderStatusHistory>();

                while (await rd.ReadAsync())
                {
                    OrderStatusHistory m = new OrderStatusHistory
                    {
                        status = rd["new_status"].ToString(),
                        regTime = rd["hist_time"].ToString(),
                        modUser = rd["mod_user"].ToString(),
                        modDesc = rd["mod_desc"].ToString(),
                    };

                    items.Add(m);
                }

                orderDetail.statusHistories = items;

                await rd.CloseAsync();
                await conn.CloseAsync();

                //조회 로그 기록
                await Utils.setPrivacyLog(ucode, "32", "10", orderNo + " - 전화번호, 주소, 카드번호", Rposition);

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = orderDetail });
        }

        */

        /// <summary>
        /// 주문 상세조회(꽃배달 추가)
        /// </summary>
        /// <remarks>
        /// shopCouponNo 가맹점 자체쿠폰번호 <br/>
        /// shopCouponAmt 가맹점 자체쿠폰 사용금액 <br/>
        /// voucherNo 모바일상품권 번호 <br/>
        /// voucherUseAmt 모바일상품권 사용금액 <br/>
        /// -- 꽃배달 <br/>
        /// custName 주문하신분 성함 <br/>
        /// telno 주문하신분 연락처 <br/>
        /// senderName 보내는분 성함 <br/>
        /// senderTelno 보내는분 연락처(미사용/예비칼럼) <br/>
        /// receiverName 받으시는분 성함 <br/>
        /// receiverTelno 받으시는분 연락처 <br/>
        /// reserDate 배송예약일시  <br/>
        /// 카드결제 할부, 23.10.24 추가됨. 이전주문에서는 빈값 <br/>
        /// installment_yn 할부여부 <br/>
        /// installment_months 할부 개월 수 <br/>
        /// </remarks>
        [HttpGet("{orderNo}")]
        public async Task<IActionResult> Get_v2(string orderNo, string ucode)
        {
            string Rposition = "/OrderDetail/{orderNo} : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rmenu = string.Empty;

            //List<OrderDetailMenu> orderMenu = new List<OrderDetailMenu>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_ORDER.GET_ORDER_DETAIL",
            };

            cmd.Parameters.Add("in_order_no", OracleDbType.Int32).Value = int.Parse(orderNo);
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            //cmd.Parameters.Add("out_menu", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_status_history_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            OrderDetail orderDetail = new OrderDetail();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                //menu = cmd.Parameters["out_menu"].Value.ToString();

                //Rmenu = Rmenu.Replace("\r\n", string.Empty).Replace("\\", string.Empty);

                await rd.ReadAsync();

                orderDetail.serviceGbn = rd["service_gbn"].ToString();
                orderDetail.addr1 = rd["ADDR1"].ToString();
                orderDetail.addr2 = rd["ADDR2"].ToString();
                orderDetail.loc = rd["LOC"].ToString();
                orderDetail.custName = rd["CUST_NAME"].ToString();
                orderDetail.telNo = rd["TELNO"].ToString();
                orderDetail.senderName = rd["SENDER_NAME"].ToString();
                orderDetail.senderTelno = rd["SENDER_TELNO"].ToString();
                orderDetail.receiverName = rd["RECEIVER_NAME"].ToString();
                orderDetail.receiverTelno = rd["RECEIVER_TELNO"].ToString();
                orderDetail.reserDate = rd["RESER_DATE"].ToString();
                orderDetail.shopCd = rd["SHOP_CD"].ToString();
                orderDetail.shopName = rd["SHOP_NAME"].ToString();
                orderDetail.regNo = rd["REG_NO"].ToString();
                orderDetail.shopAddr = rd["SHOP_ADDR"].ToString();
                orderDetail.shopLoc = rd["SHOP_LOC"].ToString();
                orderDetail.orderNo = rd["ORDER_NO"].ToString();

                //JsonSerializerOptions jso = new JsonSerializerOptions();
                //jso.Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;


                //orderDetail.menuDesc = System.Text.Json.JsonSerializer.Serialize( rd["MENU_DESC"].ToString(), jso);


                orderDetail.menuDesc = rd["MENU_DESC"].ToString().Replace("\r\n", string.Empty);
                orderDetail.deliTipAmt = rd["DELI_TIP_AMT"].ToString();
                orderDetail.menuAmt = rd["MENU_AMT"].ToString();
                orderDetail.couponName = rd["COUPON_NAME"].ToString();
                orderDetail.couponNo = rd["COUPON_NO"].ToString();
                orderDetail.couponAmt = rd["COUPON_AMT"].ToString();
                orderDetail.couponName2 = rd["COUPON_NAME2"].ToString();
                orderDetail.couponNo2 = rd["COUPON_NO2"].ToString();
                orderDetail.couponAmt2 = rd["COUPON_AMT2"].ToString();
                orderDetail.shopCouponNo = rd["shop_coupon_no"].ToString();
                orderDetail.shopCouponAmt = rd["shop_coupon_amt"].ToString();
                orderDetail.voucherNo = rd["voucher_no"].ToString();
                orderDetail.voucherUseAmt = rd["voucher_use_amt"].ToString();
                orderDetail.mileage = rd["MILEAGE_USE_AMT"].ToString();
                orderDetail.eventDisc = rd["EVENT_DISC"].ToString();
                orderDetail.beforeAmount = rd["BEFORE_AMOUNT"].ToString();
                orderDetail.amount = rd["AMOUNT"].ToString();
                orderDetail.cardName = rd["CARD_NAME"].ToString();
                orderDetail.appNo = rd["APP_NO"].ToString();
                orderDetail.cardNo = rd["CARD_NO"].ToString();
                orderDetail.appDate = rd["APP_DATE"].ToString();
                orderDetail.orderTime = rd["ORDER_TIME"].ToString();
                orderDetail.shopConfirmTime = rd["SHOP_CONFIRM_DT"].ToString();
                orderDetail.deliAllocTime = rd["DELI_ALLOC_DATE"].ToString();
                orderDetail.completeTime = rd["COMP_DT"].ToString();
                orderDetail.cancelTime = rd["CANCEL_DT"].ToString();

                orderDetail.riderDeliMemo = rd["RIDER_DELI_MEMO"].ToString();
                orderDetail.shopDeliMemo = rd["SHOP_DELI_MEMO"].ToString();
                orderDetail.appPayGbn = rd["APP_PAY_GBN"].ToString();

                orderDetail.toGoDiscAmt = rd["TO_GO_DISC_AMT"].ToString();

                orderDetail.geofenceYn = rd["GEOFENCE_YN"].ToString();
                orderDetail.destLon = rd["DEST_LON"].ToString();
                orderDetail.destLat = rd["DEST_LAT"].ToString();

                orderDetail.item_cd = rd["item_cd"].ToString();
                orderDetail.item_cd2 = rd["item_cd2"].ToString();
                orderDetail.item_cd3 = rd["item_cd3"].ToString();

                orderDetail.child_meal_disc = rd["child_meal_disc"].ToString();

                orderDetail.installment_yn = rd["installment_yn"].ToString();
                orderDetail.installment_months = rd["installment_months"].ToString();

                await rd.NextResultAsync();

                List<OrderStatusHistory> items = new List<OrderStatusHistory>();

                while (await rd.ReadAsync())
                {
                    OrderStatusHistory m = new OrderStatusHistory
                    {
                        status = rd["new_status"].ToString(),
                        regTime = rd["hist_time"].ToString(),
                        modUser = rd["mod_user"].ToString(),
                        modDesc = rd["mod_desc"].ToString(),
                    };

                    items.Add(m);
                }

                orderDetail.statusHistories = items;

                await rd.CloseAsync();
                await conn.CloseAsync();

                //조회 로그 기록
                await Utils.setPrivacyLog(ucode, "32", "10", orderNo + " - 이름, 전화번호, 주소, 카드번호", Rposition);

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = orderDetail })  ;
        }

        [HttpPut]
        public async Task<IActionResult> Put(OrderUpdate update)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_ORDER.DORDER_STATUS_UPDATE",
            };

            cmd.Parameters.Add("in_order_no", OracleDbType.Int32).Value = int.Parse(update.orderNo);
            cmd.Parameters.Add("in_status", OracleDbType.Char, 2).Value = update.status;
            cmd.Parameters.Add("in_rider_info", OracleDbType.Varchar2, 100).Value = update.riderInfo;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = update.modCode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 50).Value = update.modName;
            cmd.Parameters.Add("in_cancel_code", OracleDbType.Varchar2, 10).Value = update.cancelCode;
            cmd.Parameters.Add("in_cancel_reason", OracleDbType.Varchar2, 50).Value = update.cancelReason;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 2000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();

                ///* 알림톡 적용시 주석해제
                if(update.status == "50" && Rcode == "00") // 주문취소 성공시 알림톡 발송
                {
                    ResultBasic result = await BiztalkHelper.BiztalkOrderSend(int.Parse(update.orderNo));

                    if (result.code != "0") //카카오톡 전송 실패시 확인필요
                    {
                        await Utils.SaveErrorAsync("/BiztalkHelper/BiztalkOrderSend", result.code + " // " + result.msg);
                    }
                }
                //*/
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Order : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg});
        }

        /// <summary>
        /// 주문취소 비즈톡 테스트
        /// </summary>
        [HttpGet("testBiztalk")]
        public async Task<ResultBasic> testBiztalk(int order_no)
        {
            ResultBasic result = await BiztalkHelper.BiztalkOrderSend(order_no);

            if (result.code != "0") //카카오톡 전송 실패시 확인필요
            {
                await Utils.SaveErrorAsync("/BiztalkHelper/BiztalkOrderSend", result.code + " // " + result.msg);
            }

            return result;
        }

        /// <summary>
        /// 카드 승인취소
        /// </summary>
        /// <remarks>
        /// ucode: 수정자 ucode 필수
        /// </remarks>
        [HttpPut("setCardApprovalGbn/{order_no}")]
        public async Task<IActionResult> setCardApprovalGbn(int order_no, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            if (string.IsNullOrEmpty(ucode))
            {
                return Ok(new { code = "99", msg = "수정자 ucode는 필수입니다." });
            }

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_ORDER.SET_CARD_APPROVAL_GBN",
            };

            cmd.Parameters.Add("in_order_no", OracleDbType.Int32).Value = order_no;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();

                if(Rcode != "00")
                {
                    await Utils.SaveErrorAsync("admin/Order/setCardApprovalGbn/{order_no} : Put", Rmsg);
                }

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("admin/Order/setCardApprovalGbn/{order_no} : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        //가맹점 주문취소사유 요약
        [HttpGet("getCancelReasons/{shop_cd}")]
        public async Task<IActionResult> getCancelReasons(string shop_cd, string date_begin, string date_end)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("shop_cd", shop_cd);
            param.Add("date_begin", date_begin);
            param.Add("date_end", date_end);

            object temp = new object();

            try
            {
                db.Open();
                //CANCLE_CODE 취소사유코드
                string sql = @$"
                            select NVL(sum (case when cancel_code = '10' then 1 end),0) as cust_cancel,
                                    NVL(sum (case when cancel_code = '20' then 1 end),0) as shop_cancel,
                                    NVL(sum (case when cancel_code = '11' then 1 end),0) as delay_cancel
                            from (SELECT * FROM DORDER 
                                 WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND TEST_GBN = 'N'
                                AND NVL(CANCEL_CODE,'00') <> '30'
                                AND order_time BETWEEN to_date(:date_begin,'YYYYMMDD')
                                                   AND to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                AND shop_cd = :shop_cd
                                 UNION ALL 
                                 SELECT * FROM DORDER_PAST
                                 WHERE ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                AND TEST_GBN = 'N'
                                AND NVL(CANCEL_CODE,'00') <> '30'
                                AND order_time BETWEEN to_date(:date_begin,'YYYYMMDD')
                                                   AND to_date(:date_end || '235959', 'YYYYMMDDHH24MISS')
                                AND shop_cd = :shop_cd)
                        ";


                temp = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = temp });
        }


        /// <summary>
        /// 완료->취소 주문 조회(기간조건: ORDER_TIME 주문시간)
        /// </summary>
        /// <remarks>
        /// 결제수단이 BC탑포인트인 경우 PAY_GBN: 'BC'(DB 저장값과는 다름) <br/>
        /// </remarks>
        [HttpGet("getCompleteToCancelOrderList")]
        public async Task<IActionResult> getCompleteToCancelOrderList(int mCode, string service_gbn, string dateBegin, string dateEnd, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            string TotalCount = string.Empty;

            List<OrderList> items = new List<OrderList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_ORDER.GET_COMPL_TO_CANC_ORDER_LIST",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mCode;
            cmd.Parameters.Add("in_service_gbn", OracleDbType.Varchar2, 1).Value = service_gbn;
            cmd.Parameters.Add("in_date_begin", OracleDbType.Varchar2, 8).Value = dateBegin;
            cmd.Parameters.Add("in_date_end", OracleDbType.Varchar2, 8).Value = dateEnd;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_total_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                TotalCount = cmd.Parameters["out_total_count"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {


                    OrderList item = new OrderList
                    {
                        orderNo = rd["ORDER_NO"].ToString(),
                        payGbn = rd["PAY_GBN"].ToString(),
                        orderTime = rd["ORDER_TIME"].ToString(),
                        shopTelNo = rd["SHOP_TELNO"].ToString(),
                        regNo = rd["REG_NO"].ToString(),
                        serviceGbn = rd["service_gbn"].ToString(),
                        shopName = rd["SHOP_NAME"].ToString(),
                        shopCd = rd["SHOP_CD"].ToString(),
                        orderAmount = rd["ORDER_AMOUNT"].ToString(),
                        status = rd["STATUS"].ToString(),
                        cancelType = rd["CANCEL_TYPE"].ToString(),
                        cancelReason = rd["CANCEL_REASON"].ToString(),
                        custCode = rd["CUST_CODE"].ToString(),
                        customerTelNo = rd["CUSTOMER_TELNO"].ToString(),
                        tuid = rd["TUID"].ToString(),
                        cardName = rd["CARD_NAME"].ToString(),
                        appNo = rd["APP_NO"].ToString(),
                        cardAmount = rd["CARD_AMOUNT"].ToString(),
                        directPay = rd["DIRECT_PAY"].ToString(),
                        custIdGbn = rd["CUST_ID_GBN"].ToString(),
                        posInstalled = rd["POS_INSTALL"].ToString(),
                        posLogined = rd["POS_LOGIN"].ToString(),
                        apiComCode = rd["API_COM_CODE"].ToString(),
                        packOrderYn = rd["PACK_ORDER_YN"].ToString(),
                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("admin/Order/getCompleteToCancelOrderList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, total_count = TotalCount, count = Rcount, data = items });
        }


        //주문 카드결제 상태
        [HttpGet("getCardApprovalGbn/{order_no}")]
        public async Task<IActionResult> getCardApprovalGbn(string order_no)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("order_no", order_no);

            object temp = new object();

            try
            {
                db.Open();

                string sql = @$"
                            select order_no, card_approval_gbn
                            from dorder
                            where order_no = :order_no
                            union all
                            select order_no, card_approval_gbn
                            from dorder_past
                            where order_no = :order_no
                        ";


                temp = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception)
            {
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = temp });
        }

        /// <summary>
        /// 주문 완료취소 적립금 체크
        /// </summary>
        /// <remarks>
        /// order_no : 주문번호
        /// job_gbn: 작업구분(40 완료처리, 50 완료주문 취소처리)
        /// </remarks>
        [HttpGet("amtCheck/{order_no}")]
        public async Task<IActionResult> amtCheck(string order_no, string job_gbn)
        {
            string Ryn = string.Empty;
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            if (string.IsNullOrEmpty(order_no) || string.IsNullOrEmpty(job_gbn))
            {
                return Ok(new { code = "99", msg = "필수값이 누락되었습니다." });
            }

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_ORDER.AMT_CHECK",
            };

            cmd.Parameters.Add("in_order_no", OracleDbType.Int32).Value = order_no;
            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 10).Value = job_gbn;
            cmd.Parameters.Add("out_yn", OracleDbType.Varchar2, 1).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Ryn = cmd.Parameters["out_yn"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();

                if (Rcode != "00")
                {
                    await Utils.SaveErrorAsync("admin/Order/amtCheck/{order_no} : Get", Rmsg);
                }

            }
            catch (Exception ex)
            {
                Rcode = "98";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("admin/Order/amtCheck/{order_no} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, yn = Ryn });
        }

        //[HttpGet("detailMenu/{orderNo}")]
        //public async Task<IActionResult> GetDetailMenu(string orderNo)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    List<OrderDetailMenu> agents = new List<OrderDetailMenu>();

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_ORDER.GET_ORDER_DETAIL_MENU",
        //    };

        //    cmd.Parameters.Add("in_order_no", OracleDbType.Int32).Value = int.Parse(orderNo);
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();
        //        var rd = await cmd.ExecuteReaderAsync();

        //        while (await rd.ReadAsync())
        //        {
        //            Rcode = cmd.Parameters["out_code"].Value.ToString();
        //            Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //            OrderDetailMenu m = new OrderDetailMenu
        //            {
        //                menuName = rd["MENU_NAME"].ToString(),
        //                orderCost = rd["ORDER_COST"].ToString(),
        //                orderQty = rd["ORDER_QTY"].ToString(),
        //                orderAmt = rd["ORDER_AMT"].ToString(),
        //            };

        //            agents.Add(m);
        //        }

        //        await rd.CloseAsync();
        //        await conn.CloseAsync();

        //    }
        //    catch (Exception ex)
        //    {
        //        Utils.SaveError("shop/OrderDetailMenu/orderNo : Get", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg, data = agents });

        //}



    }
}
