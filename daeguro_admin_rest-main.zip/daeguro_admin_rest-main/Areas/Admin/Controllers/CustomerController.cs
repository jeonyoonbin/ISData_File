﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        /// <summary>
        /// 회원목록 조회
        /// </summary>
        /// <remarks>
        /// divKey : 0 전체, 1 가입회원, 2 탈퇴회원 <br/>
        /// div : 1 회원명, 2 회원번호, 3 전화번호, 4 메모로 keyword 검색
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(int divKey, string div, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalCount = string.Empty;
            string Rmileage = string.Empty;
            string Rcoupon = string.Empty;
            string Rcustomer = string.Empty;


            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("div", div);
                param.Add("keyword", keyword);
                param.Add("page", page);
                param.Add("row_count", rows);

                string divSql = string.Empty;
                string keywordSql = string.Empty;

                switch (divKey)
                {
                    case 0: divSql = @"(select cust_code, 
                                            cust_name,
                                            telno,
                                            cust_id,
                                            cust_password,
                                            insert_date,
                                            null as del_date,
                                            mileage,
                                            cust_id_gbn,
                                            mcode,
                                            memo,
                                            test_gbn
                                        from app_customer 
                                        UNION ALL 
                                        select cust_code,
                                            cust_name,
                                            telno,
                                            cust_id,
                                            cust_password,
                                            insert_date,
                                            del_date,
                                            nvl(mileage,0) mileage,
                                            cust_id_gbn,
                                            mcode,
                                            memo,
                                            test_gbn
                                        from app_customer_deleted)"; break;
                    case 1: divSql = @"(select c.*, '' as del_date from app_customer c)"; break;
                    case 2: divSql = @"(select cust_code,
                                            cust_name,
                                            telno,
                                            cust_id,
                                            cust_password,
                                            insert_date,
                                            del_date,
                                            nvl(mileage,0) mileage,
                                            cust_id_gbn,
                                            mcode,
                                            memo,
                                            test_gbn
                                        from app_customer_deleted)"; break;
                }

                if (string.IsNullOrEmpty(keyword) == false)
                {
                    keywordSql = $@"and ( case when :div = '1' then cust_name 
                                               when :div = '3' then telno
                                               when :div = '4' then memo
                                               else '%{keyword}%' end like '%{keyword}%') 
                                    and case when :div = '2' then to_char(cust_code) else '{keyword}' end = '{keyword}'";
                }

                //string sql = $@"
                //                SELECT t2.cust_code,
                //                       t2.cust_name,
                //                       t2.telno,
                //                       t2.cust_id,
                //                       t2.cust_password, 
                //                       t2.cust_id_gbn,
                //                       t2.insert_date,
                //                       t2.del_date,
                //                       NVL (t2.order_count, 0)     order_count,
                //                       NVL (t2.order_amt, 0)       order_amt,
                //                       NVL (t2.mileage_amt, 0)     mileage_amt,
                //                       t2.memo
                //                  FROM (SELECT ROWNUM AS rnum, t1.*
                //                          FROM (  SELECT a.cust_code,
                //                                         a.cust_name,
                //                                         a.telno,
                //                                         a.cust_id,
                //                                         a.cust_password,
                //                                         a.cust_id_gbn,
                //                                         a.insert_date,
                //                                         a.del_date,
                //                                           (SELECT COUNT (*)
                //                                              FROM dorder
                //                                             WHERE     app_cust_code = a.cust_code
                //                                                   AND status = '40')
                //                                         + (SELECT COUNT (*)
                //                                              FROM dorder_past
                //                                             WHERE     app_cust_code = a.cust_code
                //                                                   AND status = '40')
                //                                             order_count,
                //                                           (SELECT NVL (SUM (tot_amt), 0)
                //                                              FROM dorder
                //                                             WHERE     app_cust_code = a.cust_code
                //                                                   AND status = '40')
                //                                         + (SELECT NVL (SUM (tot_amt), 0)
                //                                              FROM dorder_past
                //                                             WHERE     app_cust_code = a.cust_code
                //                                                   AND status = '40')
                //                                             order_amt,
                //                                         a.mileage mileage_amt,
                //                                        a.memo
                //                                    FROM {divSql} a
                //                                   WHERE cust_id_gbn <> 'Z'
                //                                   AND mcode = 2
                //                                   AND test_gbn = 'R'
                //                                   AND insert_date >= to_date('2021080917','YYYYMMDDHH24')
                //                                   { keywordSql }
                //                                ORDER BY cust_code DESC) t1
                //                         WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                //                 WHERE (( :page - 1) * :row_count) < rnum
                //";

                string sql = $@"
                                SELECT t2.cust_code,
                                       t2.cust_name,
                                       t2.telno,
                                       t2.cust_id,
                                       t2.cust_password,
                                       t2.cust_id_gbn,
                                       t2.insert_date,
                                       t2.del_date,
                                       (SELECT Count (*)
                                          FROM   is_daegu.dorder
                                          WHERE  app_cust_code = t2.cust_code
                                             AND status = '40') + (SELECT Count (*)
                                                                   FROM   is_daegu.dorder_past
                                                                   WHERE  app_cust_code = t2.cust_code
                                                                      AND status = '40') order_count,
                                         (SELECT Nvl (Sum (tot_amt), 0)
                                          FROM   is_daegu.dorder
                                          WHERE  app_cust_code = t2.cust_code
                                             AND status = '40') + (SELECT Nvl (Sum (tot_amt), 0)
                                                                   FROM   is_daegu.dorder_past
                                                                   WHERE  app_cust_code = t2.cust_code
                                                                      AND status = '40') order_amt,
                                       (select count(*)
                                       from reser_receipt_order
                                       where cust_code = t2.cust_code
                                       and status = '30' ) reser_count,                              
                                       Nvl (t2.mileage_amt, 0) mileage_amt,
                                       t2.memo
                                FROM   (SELECT ROWNUM AS rnum,
                                               t1.*
                                        FROM   (SELECT   a.cust_code,
                                                         a.cust_name,
                                                         a.telno,
                                                         a.cust_id,
                                                         a.cust_password,
                                                         a.cust_id_gbn,
                                                         a.insert_date,
                                                         a.del_date,
                                                         a.mileage  mileage_amt,
                                                         a.memo
                                                FROM     {divSql} a
                                                WHERE    cust_id_gbn <> 'Z'
                                                     AND mcode = 2
                                                     AND test_gbn = 'R'
                                                     -- AND insert_date >= To_date('2021080917','YYYYMMDDHH24')
                                                   { keywordSql }
                                                ORDER BY cust_code DESC) t1
                                         WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                                 WHERE (( :page - 1) * :row_count) < rnum
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                RtotalCount = await db.ExecuteScalarAsync<string>($@"select count(*) from {divSql} where cust_id_gbn <> 'Z' AND mcode = 2 AND test_gbn = 'R' { keywordSql }", param, commandType: CommandType.Text);

                // 현황
                Rmileage = await db.ExecuteScalarAsync<string>($@"SELECT SUM (mileage) FROM {divSql} WHERE cust_id_gbn <> 'Z' AND mcode = 2 AND test_gbn = 'R' ", commandType: CommandType.Text);
                Rcoupon = await db.ExecuteScalarAsync<string>($@"SELECT NVL(SUM (coupon_amt),0) FROM coupon_mst a, {divSql} b WHERE a.APP_CUST_CODE = b.CUST_CODE AND b.cust_id_gbn <> 'Z' AND b.mcode = 2 AND b.test_gbn = 'R' AND status = '20'", commandType: CommandType.Text);
                Rcustomer = await db.ExecuteScalarAsync<string>($@"SELECT COUNT (*) FROM {divSql} WHERE cust_id_gbn <> 'Z' AND mcode = 2 AND test_gbn = 'R' ", commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, itemCount = items.Count.ToString(), mileage = Rmileage, coupon = Rcoupon, customer = Rcustomer, data = items });
        }


        [HttpGet("joinInfo/{cust_code}")]
        public async Task<IActionResult> GetJoinInfo(string cust_code, string ucode)
        {
            string Rposition = "/Customer/joinInfo/{cust_code}";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = new object();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("cust_code", cust_code);

                param.Add("in_ucode", ucode);

                string sql = @" 
                                select cust_name, telno, cust_id, cust_other_id, cust_password, birthday, insert_date, del_date, retire_date,
                            sido_name || ' ' || gungu_name || ' ' || dong_name || ' ' || ri_name || ' ' || jibun_num || ' ' || addr_detail as old_addr,
                            sido_name || ' ' || gungu_name || ' ' || road_name || ' ' || road_num || ' ' || addr_detail as new_addr,
                            decode(cust_id_gbn, 'A', '공공앱', 'G', '구글', 'K', '카카오', 'N', '네이버', 'I', '애플', 'Z', '비회원') cust_id_gbn,
                            memo
                            from (
                                select cust_code, 
                                        cust_name,
                                        telno,
                                        cust_id,
                                        cust_other_id,
                                        cust_password,
                                        insert_date,
                                        mileage,
                                        cust_id_gbn,
                                        mcode,
                                        addr_detail,
                                        road_num,
                                        road_name,
                                        gungu_name,
                                        sido_name,
                                        jibun_num,
                                        ri_name,
                                        dong_name,
                                        retire_date,
                                        null as del_date,
                                        birthday,
                                        memo
                                    from app_customer 
                                    UNION ALL 
                                    select cust_code,
                                        cust_name,
                                        telno,
                                        cust_id,
                                        cust_other_id,
                                        cust_password,
                                        insert_date,
                                        nvl(mileage,0) mileage,
                                        cust_id_gbn,
                                        2 as mcode,
                                        addr_detail,
                                        road_num,
                                        road_name,
                                        gungu_name,
                                        sido_name,
                                        jibun_num,
                                        ri_name,
                                        dong_name,
                                        sysdate as retire_date,
                                        del_date,
                                        birthday,
                                        memo
                                    from app_customer_deleted
                            )
                                where cust_code = :cust_code
                ";

                db.Open();

                Rdata = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);

                var data = Rdata as IReadOnlyDictionary<string, object>;

                db.Close();

                //조회 로그 기록
                await Utils.setPrivacyLog(ucode, "36", "10", data["CUST_NAME"] + " - 이름, 생년월일, 전화번호, 이메일주소, 주소, 비밀번호", Rposition);

                Rcode = "00";
                Rmsg = "성공";

            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }

       

        [HttpGet("mileage/{cust_code}")]
        public async Task<IActionResult> GetMileage(string cust_code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalMileage = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("cust_code", cust_code);

                string sql = @" select a.order_date, a.order_no, b.shop_name, b.reg_no, a.log_date,
                                decode(a.log_gbn, '0', '이월', '1', '적립', '3', '차감', '5', '추천포인트') log_gbn,
                                a.mileage_amt,
                                a.memo
                                from app_cust_mileage_log a, shop_info b 
                                where a.shop_cd = b.shop_cd (+)
                                and a.app_cust_code = :cust_code
                                order by log_date desc
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                RtotalMileage = await db.ExecuteScalarAsync<string>(@"select mileage from (select mileage,cust_code from app_customer union all select mileage,cust_code from app_customer_deleted) where cust_code = :cust_code", param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalMileage = RtotalMileage, data = items });
        }

        /// <summary>
        /// 회원 쿠폰조회
        /// </summary>
        /// <remarks>
        /// cust_code 회원번호(필수) <br/>
        /// status 쿠폰상태 <br/>
        /// coupon_no 쿠폰번호 <br/>
        /// <br/>
        /// 조회칼럼 <br/>
        /// DIV 쿠폰분류(대구로, 제휴, 브랜드)
        /// </remarks>
        [HttpGet("coupon/{cust_code}")]
        public async Task<IActionResult> GetCoupon(string cust_code, string status, string coupon_no)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object Rdata = new object();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("cust_code", cust_code);
                param.Add("status", status);
                param.Add("coupon_no", coupon_no);

                string order_sql = string.Empty;
                string status_sql = string.Empty;

                if (status.Equals("20"))
                {
                    order_sql = "order by ins_date desc";
                }
                else if (status.Equals("30"))
                {
                    order_sql = "order by use_date desc";
                }
                else if (status.Equals("40"))
                {
                    order_sql = "order by exp_date desc";
                }
                else if (status.Equals("99"))
                {
                    order_sql = "order by dis_use_date desc";
                }
                else
                {
                    order_sql = "order by ins_date desc";
                }
                

                string sql = $@" select '대구로' DIV, coupon_type, coupon_name, coupon_no, ins_date, use_date, exp_date, coupon_amt, 
                                        case when PUBLISH_DATE is null then ST_DATE else TO_CHAR(PUBLISH_DATE,'YYYYMMDD') END ST_DATE, TO_CHAR(DIS_USE_DATE,'YYYYMMDD') DIS_USE_DATE,
                                decode(status, '00', '대기', '10', '승인', '20', '발행(고객)', '30', '사용(고객)', '40', '만료', '99', '폐기') status
                                from coupon_mst
                                where app_cust_code = :cust_code
                                and status like case when :status is null then '%' else :status end
                                and coupon_no like case when :coupon_no is null then '%' else :coupon_no end
                                UNION ALL
                                select '제휴' DIV, coupon_type, coupon_name, coupon_no, ins_date, use_date, exp_date, coupon_amt, 
                                        case when PUBLISH_DATE is null then ST_DATE else TO_CHAR(PUBLISH_DATE,'YYYYMMDD') END ST_DATE, TO_CHAR(DIS_USE_DATE,'YYYYMMDD') DIS_USE_DATE,
                                decode(status, '00', '대기', '10', '승인', '20', '발행(고객)', '30', '사용(고객)', '40', '만료', '99', '폐기') status
                                from B2B_coupon_mst
                                where app_cust_code = :cust_code
                                and status like case when :status is null then '%' else :status end
                                and coupon_no like case when :coupon_no is null then '%' else :coupon_no end
                                UNION ALL
                                select '브랜드' DIV, coupon_type, coupon_name, coupon_no, ins_date, use_date, exp_date, coupon_amt, 
                                        case when PUBLISH_DATE is null then ST_DATE else TO_CHAR(PUBLISH_DATE,'YYYYMMDD') END ST_DATE, TO_CHAR(DIS_USE_DATE,'YYYYMMDD') DIS_USE_DATE,
                                decode(status, '00', '대기', '10', '승인', '20', '발행(고객)', '30', '사용(고객)', '40', '만료', '99', '폐기') status
                                from CHAIN_coupon_mst
                                where app_cust_code = :cust_code
                                and status like case when :status is null then '%' else :status end
                                and coupon_no like case when :coupon_no is null then '%' else :coupon_no end
                                { order_sql }
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                Rdata = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = Rdata });
        }


        /// <summary>
        /// 사용자 기기정보
        /// </summary>
        [HttpGet("getDevice/{cust_code}")]
        public async Task<IActionResult> getDvice(string cust_code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object item = string.Empty;

            string name = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("cust_code", cust_code);

                string sql = @"
                                select * from(select seq, cust_code, login_date, device_gbn, 
                                       nvl(app_version,' ') app_version, nvl(os_version,' ') os_version, nvl(device_model,' ') device_model 
                                from app_cust_login_hist
                                where cust_code = :cust_code
                                order by login_date desc)
                                where rownum = 1
                ";

                item = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Customer/{cust_code} : Get", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 회원 정보 수정
        /// </summary>
        /// <remarks>
        /// cust_id, cust_id_gbn, cust_other_id, 전화번호, 메모 수정 <br/>
        /// cust_id_gbn 아이디구분(A:공공앱/G:구글/K:카카오/N:네이버/I:애플/Z:비회원) <br/>
        /// cust_other_id 타사로그인 식별코드 <br/>
        /// tel_no 전화번호 <br/>
        /// * cust_id_gbn과 cust_other_id의 경우 값을 넣지 않으면 기존값 유지 <br/>
        /// </remarks>
        [HttpPut("joinInfo/{cust_code}")]
        public async Task<IActionResult> joinInfo(string cust_code, string cust_id, string cust_id_gbn, string cust_other_id, string tel_no, string memo, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("cust_id", cust_id);
                param.Add("cust_id_gbn", cust_id_gbn);
                param.Add("cust_other_id", cust_other_id);
                param.Add("tel_no", tel_no);
                param.Add("memo", memo);
                param.Add("mod_ucode", mod_ucode);
                param.Add("mod_name", mod_name);
                param.Add("cust_code", cust_code);

                string sql = $@"
                                update app_customer set 
                                        cust_id = :cust_id, 
                                        cust_id_gbn = nvl(:cust_id_gbn,cust_id_gbn), 
                                        cust_other_id = :cust_other_id, 
                                        telno = :tel_no, 
                                        memo = :memo, 
                                        mod_date = sysdate, 
                                        mod_ucode = :mod_ucode, 
                                        mod_name = :mod_name 
                                where cust_code = :cust_code
                                ";

                //app_customer_deleted는 모드네임 칼럼이 없음
                string sqlD = $@"
                                update app_customer_deleted set 
                                        cust_id = :cust_id, 
                                        cust_id_gbn = nvl(:cust_id_gbn,cust_id_gbn), 
                                        cust_other_id = :cust_other_id,
                                        telno = :tel_no, 
                                        memo = :memo, 
                                        mod_date = sysdate, 
                                        mod_ucode = :mod_ucode 
                                where cust_code = :cust_code
                                ";

                db.Open();
                await db.ExecuteAsync(sql, param);
                await db.ExecuteAsync(sqlD, param);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Customer/joinInfo/{cust_code} : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 회원 탈퇴
        /// </summary>
        [HttpPut("retire/{cust_code}")]
        public async Task<IActionResult> retire(string cust_code, string retire_memo, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rposition = "/Customer/retire/{cust_code} : Put";


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("cust_code", cust_code);
                param.Add("retire_memo", retire_memo);
                param.Add("mod_ucode", mod_ucode);
                param.Add("mod_name", mod_name);

                db.Open();
                string sql = $@"update app_customer 
                                set use_gbn = 2, 
                                    retire_date = sysdate, 
                                    retire_memo = :retire_memo,
                                    mod_date = sysdate,
                                    mod_ucode = :mod_ucode,
                                    mod_name = :mod_name
                                where cust_code = :cust_code";

                await db.ExecuteAsync(sql, param);
                db.Close();

                //회원탈퇴 로그기록(log_gbn:30)
                await Utils.setPrivacyLog(mod_ucode, "217", "30", "회원탈퇴 처리 - " + cust_code + ", 사유: " + retire_memo, Rposition);

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 회원정보 변경이력
        /// </summary>
        [HttpGet("getHist/{cust_code}")]
        public async Task<IActionResult> getHist(string cust_code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<HistoryList> hist = new List<HistoryList>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("cust_code", cust_code);

                db.Open();
                string sql = $@"select hist_seq no, hist_date insertDate, memo || ' [작업자:' || mod_name || '(' || mod_ucode || ')]' memo
                                from app_customer_hist
                                where cust_code = :cust_code
                                order by hist_date desc";

                var temp = await db.QueryAsync<HistoryList>(sql, param);

                hist = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Customer/getHist/{cust_code} : Get", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg, data = hist });
        }

        /// <summary>
        /// 친구조대 내역 조회
        /// </summary>
        /// <remarks>
        /// referral_code : 해당 회원의 친구추천코드 <br/>
        /// invite_cnt : 추천한 회원수 <br/>
        /// <br/>
        /// invited 추천받은 회원 정보, invite[]  추천한 회원 리스트 <br/>
        ///  - my_referral_code : 코드번호 <br/>
        ///  - cust_code : 회원번호 <br/>
        ///  - cust_name : 회원명 <br/>
        ///  - telno : 연락처 <br/>
        ///  - ins_date : 입력일자
        /// </remarks>
        [HttpGet("getInviteLog/{cust_code}")]
        public async Task<IActionResult> GegetInviteLogtDetail(string cust_code)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rreferral = string.Empty;
            string Rcnt = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CUSTOMER.GET_INVITE_LOG",
            };

            cmd.Parameters.Add("in_cust_code", OracleDbType.Int32).Value = cust_code;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_referral_code", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cnt", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor2", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            InviteCust item = new InviteCust();

            List<InviteCust> subItems = new List<InviteCust>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
                Rreferral = cmd.Parameters["out_referral_code"].Value.ToString();
                if (Rreferral == "null")
                {
                    Rreferral = "";
                }
                Rcnt = cmd.Parameters["out_cnt"].Value.ToString();

                await rd.ReadAsync();
                if (rd.HasRows) //첫번째 sys_refcursor에 값이 없으면 넘기는 처리를 해줘야 두번째 sys_refcursor를 받을 수 있다
                {
                    item.my_referral_code = rd["my_referral_code"].ToString();
                    item.cust_code = rd["cust_code"].ToString();
                    item.cust_name = rd["cust_name"].ToString();
                    item.telno = rd["telno"].ToString();
                    item.ins_date = rd["ins_date"].ToString();
                }
                else
                {
                    await rd.NextResultAsync();

                    while (await rd.ReadAsync())
                    {
                        InviteCust subItem = new InviteCust
                        {
                            my_referral_code = rd["my_referral_code"].ToString(),
                            cust_code = rd["cust_code"].ToString(),
                            cust_name = rd["cust_name"].ToString(),
                            telno = rd["telno"].ToString(),
                            ins_date = rd["ins_date"].ToString(),

                        };

                        subItems.Add(subItem);
                    }
                }
                

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Customer/getInviteLog{cust_code} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, 
                            data = new {referral_code = Rreferral,
                                        invited = item,
                                        invite_cnt = Rcnt,
                                        invite = subItems.ToArray() }
                });
        }






        /// <summary>
        /// 마케팅푸시 동의자 전화번호 목록 txt 출력
        /// </summary>
        /// <remarks>
        /// in_dt : YYYYMMDDHH24MISS 기준
        /// </remarks>
        [HttpGet("custTelnoTxtExport")]
        public async Task<IActionResult> custTelnoTxtExport(string in_dt)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            string txt = string.Empty;
            List<string> items = new List<string>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_dt", in_dt);


                string sql = $@"
                                    select a.telno from app_customer a, app_customer_add b
                                    where a.cust_code = b.cust_code (+)
                                    and a.mcode = 2
                                    AND a.CUST_ID_GBN <> 'Z'
                                    AND a.TEST_GBN = 'R'
                                    and a.use_gbn = '1'
                                    and nvl(b.push_event_yn, a.push_marketing_yn) = 'Y'
                                    and a.insert_date < to_date(:in_dt,'YYYYMMDDHH24MISS')
                                    --and a.INSERT_DATE >= TO_DATE('20210809 17','YYYYMMDD HH24')
                                ";

                db.Open();

                var result = await db.QueryAsync<string>(sql, param, commandType: CommandType.Text);
                items = result.ToList();
                db.Close();

                using (var stream = new MemoryStream())
                {
                    string first = "핸드폰번호	이름	회신번호	기타1	기타2	기타3	기타4	기타5\n";
                    byte[] _data = Encoding.Default.GetBytes(first);
                    stream.Write(_data, 0, _data.Length);

                    _data = Encoding.Default.GetBytes(String.Join(Environment.NewLine, items.ToArray()));
                    stream.Write(_data, 0, _data.Length);

                    //application/octet-stream
                    return File(stream.ToArray(), "text/plain", $"회원정보양식.txt");
                }

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Customer/custTelnoTxtExport : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        

    }
}