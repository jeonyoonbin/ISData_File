﻿using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class AddressController : ControllerBase
    {
        [HttpGet("sido/")]
        public async Task<IActionResult> Get()
        {
            string Rcode = "00";
            string Rmsg = "성공";

            List<SiDoList> sidoList = new List<SiDoList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_API_POS.GET_SIDO_SEARCH_DAWUL",
            };

            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();


                while (await rd.ReadAsync())
                {
                    SiDoList m = new SiDoList
                    {
                        sidoName = rd["B_LARGE"].ToString(),
                    };

                    sidoList.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("admin/Address/sido : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = sidoList });
        }

        


        [HttpGet("gungu/{sido}")]
        public async Task<IActionResult> Get(string sido)
        {
            string Rcode = "00";
            string Rmsg = "성공";

            List<GunguList> gunguList = new List<GunguList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_API_POS.GET_GUNGU_SEARCH_DAWUL",
            };

            cmd.Parameters.Add("in_sido", OracleDbType.Varchar2, 20).Value = sido;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                while (await rd.ReadAsync())
                {
                    GunguList m = new GunguList
                    {
                        gunGuName = rd["B_MIDDLE"].ToString(),
                    };

                    gunguList.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("admin/Address/gungu/{sido} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = gunguList });
        }


        [HttpGet("dong/{sido}/{gungu}")]
        public async Task<IActionResult> Get(string sido, string gungu)
        {
            string Rcode = "00";
            string Rmsg = "성공";

            List<DongList> dongList = new List<DongList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_API_POS.GET_DONG_SEARCH_NEW_DAWUL",
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 1).Value = "1";
            cmd.Parameters.Add("in_sido", OracleDbType.Varchar2, 20).Value = sido;
            cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 20).Value = gungu;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                while (await rd.ReadAsync())
                {
                    DongList m = new DongList
                    {
                        dongName = rd["H_SMALL"].ToString(),
                    };

                    dongList.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("admin/Address/dong/{sido}/{gungu} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = dongList });
        }

        [HttpGet("ri/{sido}/{gungu}/{dong}")]
        public async Task<IActionResult> Get(string sido, string gungu, string dong)
        {
            string Rcode = "00";
            string Rmsg = "성공";

            List<RiList> riList = new List<RiList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_API_POS.GET_RI_SEARCH_NEW_DAWUL",
            };

            cmd.Parameters.Add("in_sido", OracleDbType.Varchar2, 20).Value = sido;
            cmd.Parameters.Add("in_gungu", OracleDbType.Varchar2, 20).Value = gungu;
            cmd.Parameters.Add("in_dong", OracleDbType.Varchar2, 20).Value = dong;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                while (await rd.ReadAsync())
                {
                    RiList m = new RiList
                    {
                        riName = rd["B_DETAIL"].ToString(),
                    };

                    riList.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("admin/Address/ri/{sido}/{gungu}/{dong} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = riList });
        }
    }
}
