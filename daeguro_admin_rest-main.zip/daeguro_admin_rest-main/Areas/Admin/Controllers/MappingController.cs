﻿using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class MappingController : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> Get(string usgGbn, string apiType, string shopName, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<MappingList> items = new List<MappingList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MAPPING.GET_API_MAP_LIST",
            };

            cmd.Parameters.Add("in_api_use_gbn", OracleDbType.Varchar2, 1).Value = usgGbn;
            cmd.Parameters.Add("in_api_type", OracleDbType.Varchar2, 1).Value = apiType;
            cmd.Parameters.Add("in_shop_name", OracleDbType.Varchar2, 50).Value = shopName;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    MappingList item = new MappingList
                    {
                        shopMapSeq = rd["SHOP_MAP_SEQ"].ToString(),
                        shopName = rd["SHOP_NAME"].ToString(),
                        companyName = rd["COMPANY_NAME"].ToString(),
                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Mapping : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }


        [HttpGet("checkApiMap/{shop_cd}")]
        public async Task<IActionResult> CheckApiMap(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MAPPING.CHECK_API_MAP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ApiCompany/checkApiMap/{shop_cd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg , count = Rcount});
        }


        [HttpGet("{shop_map_seq}")]
        public async Task<IActionResult> Get(string shop_map_seq)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            ApiMap item = new ApiMap();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MAPPING.GET_API_MAP_DETAIL",
            };

            cmd.Parameters.Add("in_shop_map_seq", OracleDbType.Varchar2, 10).Value = shop_map_seq;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    item.shopCd = rd["SHOP_CD"].ToString();
                    item.shopName = rd["SHOP_NAME"].ToString();
                    item.shopMapSeq = rd["SHOP_MAP_SEQ"].ToString();
                    item.apiUseYn = rd["API_USE_YN"].ToString();
                    item.apiType = rd["API_TYPE"].ToString();
                    item.apiComGbn = rd["API_COM_GBN"].ToString();
                    item.apiComCode = rd["API_COM_CODE"].ToString();
                    item.apiComCode2 = rd["API_COM_CODE2"].ToString();
                    item.apiComToken = rd["API_COM_TOKEN"].ToString();
                    item.apiComAuth = rd["API_COM_AUTH"].ToString();
                    item.apiComId = rd["API_COM_ID"].ToString();
                    item.apiComPass = rd["API_COM_PASS"].ToString();
                    item.apiDailyToken = rd["API_DAILY_TOKEN"].ToString();
                    item.apiMemo = rd["API_MEMO"].ToString();
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ApiCompany/{shop_map_seq} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }


        [HttpPost]
        public async Task<IActionResult> Post(ApiMap param)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MAPPING.ADD_API_MAP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = param.shopCd;
            cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = param.ccCode;
            cmd.Parameters.Add("in_api_use_yn", OracleDbType.Varchar2, 1).Value = param.apiUseYn;
            cmd.Parameters.Add("in_api_type", OracleDbType.Varchar2, 1).Value = param.apiType;
            cmd.Parameters.Add("in_api_com_gbn", OracleDbType.Varchar2, 15).Value = param.apiComGbn;
            cmd.Parameters.Add("in_api_com_code", OracleDbType.Varchar2, 30).Value = param.apiComCode;
            cmd.Parameters.Add("in_api_com_code2", OracleDbType.Varchar2, 30).Value = param.apiComCode2;
            cmd.Parameters.Add("in_api_com_token", OracleDbType.Varchar2, 200).Value = param.apiComToken;
            cmd.Parameters.Add("in_api_com_auth", OracleDbType.Varchar2, 200).Value = param.apiComAuth;
            cmd.Parameters.Add("in_api_com_id", OracleDbType.Varchar2, 50).Value = param.apiComId;
            cmd.Parameters.Add("in_api_com_pass", OracleDbType.Varchar2, 100).Value = param.apiComPass;
            cmd.Parameters.Add("in_api_daily_token", OracleDbType.Varchar2, 200).Value = param.apiDailyToken;
            cmd.Parameters.Add("in_api_memo", OracleDbType.Varchar2, 500).Value = param.apiMemo;
            cmd.Parameters.Add("in_user_code", OracleDbType.Int32).Value = param.userCode;
            cmd.Parameters.Add("in_user_name", OracleDbType.Varchar2, 50).Value = param.userName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Mapping : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpPut]
        public async Task<IActionResult> Put(ApiMap param)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MAPPING.UPDATE_API_MAP",
            };

            cmd.Parameters.Add("in_shop_map_seq", OracleDbType.Int32).Value = param.shopMapSeq;
            cmd.Parameters.Add("in_api_use_yn", OracleDbType.Varchar2, 1).Value = param.apiUseYn;
            cmd.Parameters.Add("in_api_type", OracleDbType.Varchar2, 1).Value = param.apiType;
            cmd.Parameters.Add("in_api_com_gbn", OracleDbType.Varchar2, 15).Value = param.apiComGbn;
            cmd.Parameters.Add("in_api_com_code", OracleDbType.Varchar2, 30).Value = param.apiComCode;
            cmd.Parameters.Add("in_api_com_code2", OracleDbType.Varchar2, 30).Value = param.apiComCode2;
            cmd.Parameters.Add("in_api_com_token", OracleDbType.Varchar2, 200).Value = param.apiComToken;
            cmd.Parameters.Add("in_api_com_auth", OracleDbType.Varchar2, 200).Value = param.apiComAuth;
            cmd.Parameters.Add("in_api_com_id", OracleDbType.Varchar2, 50).Value = param.apiComId;
            cmd.Parameters.Add("in_api_com_pass", OracleDbType.Varchar2, 100).Value = param.apiComPass;
            cmd.Parameters.Add("in_api_daily_token", OracleDbType.Varchar2, 200).Value = param.apiDailyToken;
            cmd.Parameters.Add("in_api_memo", OracleDbType.Varchar2, 500).Value = param.apiMemo;
            cmd.Parameters.Add("in_user_code", OracleDbType.Int32).Value = param.userCode;
            cmd.Parameters.Add("in_user_name", OracleDbType.Varchar2, 50).Value = param.userName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Mapping : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

    }
}
