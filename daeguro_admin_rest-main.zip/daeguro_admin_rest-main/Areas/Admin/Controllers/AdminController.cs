﻿using Dapper;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        /// <summary>
        /// 관리앱 버전정보
        /// </summary>
        /// <remarks>
        /// app_gbn 구분/ W : 관리앱, M : 모바일 관리앱, E : 외부 사용자용 관리앱, R: 대구로 대표사이트
        /// </remarks>
        [HttpGet("getVersion/{app_gbn}")]
        public async Task<IActionResult> getVersion(string app_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object item = string.Empty;

            string name = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("app_gbn", app_gbn);

                string sql = @"
                                select * from admin_app_version
                                where app_gbn = :app_gbn
                ";

                item = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Admin/getVersion/{app_gbn} : Get", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }


        /// <summary>
        /// 관리앱 버전 생성/수정
        /// </summary>
        /// <remarks>
        /// app_gbn 앱 구분 (W : 관리앱, M : 모바일 관리앱(vie), E : 외부 사용자용 관리앱, R: 대구로 대표사이트), F : 모바일 관리앱(FLUTTER)
        /// </remarks>
        [HttpPut("setVersion/{app_gbn}")]
        public async Task<IActionResult> setVersion(string app_gbn, string version, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("app_gbn", app_gbn);
                param.Add("version", version);
                param.Add("ucode", ucode);

                string sql = @"
                                merge into admin_app_version a
                                using dual
                                on (app_gbn = :app_gbn)
                                when matched then
                                    update set app_version = :version,
                                               mod_ucode = :ucode,
                                               mod_date = sysdate
                                when not matched then
                                    insert (app_gbn, app_version, mod_date, mod_ucode)
                                    values (:app_gbn, :version, sysdate, :ucode)
                                ";

                db.Open();
                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Admin/setVersion/{app_gbn} : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }

    }
}