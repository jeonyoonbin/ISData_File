﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;


namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class PrivacyLogController : ControllerBase
    {
        /// <summary>
        /// 개인정보 조회로그
        /// </summary>
        /// <remarks>
        /// divKey : 검색구분(1. 사용자명(전부일치), 2. 프로그램명, 3. 포지션)
        /// </remarks>
        [HttpGet("Old")]
        public async Task<IActionResult> Get(string divKey, string keyword, string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            string RtotalCount = string.Empty;

            if(divKey != "1")// 사용자명이 아닐때만 부분일치 조회 가능
            {
                keyword = "%" + keyword + "%";
            }

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            
            DynamicParameters param = new DynamicParameters();
            param.Add("divKey", divKey);
            param.Add("keyword", keyword);
            param.Add("date_begin", date_begin);
            param.Add("date_end", date_end);
            param.Add("page", page);
            param.Add("row_count", rows);

            try
            {

                db.Open();

                string sql = @$"
                                SELECT COUNT(*)
                                FROM admin_privacy_log
                            ";
                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

               
                sql = @$"
                            SELECT COUNT(*)
                            FROM admin_privacy_log a, 
                                ( select 'W' app_gbn, id, name
                                  from program_info
                                  union all
                                  select 'F' app_gbn, id, name
                                  from mobile_program_info) b, users c
                            WHERE a.app_gbn = b.app_gbn
                              and a.pid = b.id 
                              and a.ucode = c.ucode
                            and TO_CHAR(a.log_time,'YYYYMMDD') BETWEEN :date_begin AND :date_end
                            and case when :keyword is null then nvl(:keyword,'%')
                                     when :divkey = 1  then c.user_name
                                     when :divkey = 2  then b.name
                                     when :divkey = 3  then a.position
                                end like nvl(:keyword,'%')
                            
                        ";
                Rcount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);


                sql = @$"
                            SELECT T2.seq, T2.ucode, T2.user_name, T2.log_time, T2.app_gbn, T2.pid, T2.pname, T2.log_gbn, T2.position, T2.content,
                                    (select /*+ index_desc (admin_login_log, admin_login_log_pk) */ip
                                    from admin_login_log
                                    where ip is not null
                                    and ucode = T2.ucode
                                    and rownum = 1) ip
                              FROM (SELECT ROWNUM AS RNUM,
                                           T1.*
                                      FROM (SELECT/*+ index_desc (a admin_privacy_log_pk) */ a.seq, to_char(a.ucode) as ucode, c.user_name, a.log_time, a.app_gbn, to_char(a.pid) pid, b.name as pname, a.log_gbn, a.position, a.content
                                              FROM admin_privacy_log a, 
                                              (select 'W' app_gbn, id, name
                                              from program_info
                                              union all
                                              select 'F' app_gbn, id, name
                                              from mobile_program_info) b, users c
                                              WHERE a.app_gbn = b.app_gbn
                                              and a.pid = b.id 
                                              and a.ucode = c.ucode
                                              and TO_CHAR(a.log_time,'YYYYMMDD') BETWEEN :date_begin AND :date_end
                                              and case when :keyword is null then nvl(:keyword,'%')
                                                       when :divkey = 1  then c.user_name
                                                       when :divkey = 2  then b.name
                                                       when :divkey = 3  then a.position
                                                  end like nvl(:keyword,'%')) T1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) T2
                             WHERE (( :page - 1) * :row_count) < RNUM
                        ";


                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/PrivacyLog : Get", ex.Message);
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, count = Rcount, data = items });
        }

        /// <summary>
        /// 앱별 프로그램명 검색
        /// </summary>
        /// <remarks>
        /// app_gbn 앱 구분(W: 관리앱, F: 모바일 관리앱)(필수) <br/>
        /// [response] <br/>
        /// id 프로그램id <br/>
        /// name 프로그램명 <br/>
        /// </remarks>
        [HttpGet("getProgramNameList")]
        public async Task<IActionResult> getProgramNameList(string app_gbn, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<ProgramNameList> items = new List<ProgramNameList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_LOG.GET_PROGRAM_NAME_LIST",
            };

            cmd.Parameters.Add("in_app_gbn", OracleDbType.Varchar2, 1).Value = app_gbn;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 100).Value = keyword;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ProgramNameList item = new ProgramNameList
                    {
                        id = rd["id"].ToString(),
                        name = rd["name"].ToString(),
                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/PrivacyLog/getProgramNameList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 개인정보 조회로그V2
        /// </summary>
        /// <remarks>
        /// app_gbn 앱구분(W: 관리앱, F: 모바일관리앱)(필수) <br/>
        /// pid : 프로그램코드(빈값: 전체/app_gbn에 종속됨) <br/>
        /// log_gbn : 로그구분 (빈값: 전체, 10: 조회, 20: 개인정보해지, 30: 회원탈퇴, 40: 다운로드) <br/>
        /// divKey : 검색구분(1. 사용자명(전부일치), 3. 포지션)(필수) <br/>
        /// </remarks>
        [HttpGet("")]
        public async Task<IActionResult> GetV2(string app_gbn, string pid, string log_gbn, string divKey, string keyword, string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            string RtotalCount = string.Empty;

            if (divKey != "1")// 사용자명이 아닐때만 부분일치 조회 가능
            {
                keyword = "%" + keyword + "%";
            }

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_app_gbn", app_gbn);
            param.Add("in_log_gbn", log_gbn);
            param.Add("in_pid", pid);
            param.Add("divKey", divKey);
            param.Add("keyword", keyword);
            param.Add("date_begin", date_begin);
            param.Add("date_end", date_end);
            param.Add("page", page);
            param.Add("row_count", rows);

            try
            {

                db.Open();

                string sql = @$"
                                SELECT COUNT(*)
                                FROM admin_privacy_log
                            ";
                //RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);


                sql = @$"
                            SELECT count(*)
                            FROM admin_privacy_log a, users c
                            WHERE a.ucode = c.ucode
                            and a.log_time BETWEEN to_date(:date_begin,'YYYYMMDD') AND to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                            and a.app_gbn = :in_app_gbn
                            and a.pid like case when :in_pid is null then '%' else :in_pid end
                            and a.log_gbn like case when :in_log_gbn is null then '%' else :in_log_gbn end
                            and case when :keyword is null then nvl(:keyword,'%')
                                    when :divkey = 1  then c.user_name
                                    when :divkey = 3  then a.position
                                end like nvl(:keyword,'%')
                            
                        ";
                Rcount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);


                sql = @$"
                            SELECT T2.seq, T2.ucode, T2.user_name, T2.log_time, T2.app_gbn, to_char(T2.pid) pid, p.pname, T2.log_gbn, T2.position, T2.content,
                                    (select /*+ index_desc (admin_login_log, admin_login_log_pk) */ip
                                    from admin_login_log
                                    where log_time < T2.log_time
                                    and ucode = T2.ucode
                                    and rownum = 1) ip
                              FROM (SELECT ROWNUM AS RNUM,
                                           T1.*
                                      FROM (SELECT /*+ index_desc (a admin_privacy_log_pk) */ a.seq, to_char(a.ucode) as ucode, c.user_name, a.log_time, a.app_gbn, a.pid, a.log_gbn, a.position, a.content
                                              FROM admin_privacy_log a, users c
                                              WHERE a.ucode = c.ucode
                                              and a.log_time BETWEEN to_date(:date_begin,'YYYYMMDD') AND to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                              and a.app_gbn = :in_app_gbn
                                              and a.pid like case when :in_pid is null then '%' else :in_pid end
                                              and a.log_gbn like case when :in_log_gbn is null then '%' else :in_log_gbn end
                                              and case when :keyword is null then nvl(:keyword,'%')
                                                       when :divkey = 1  then c.user_name
                                                       when :divkey = 3  then a.position
                                                  end like nvl(:keyword,'%')) T1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) T2,
                                     (select 'W' app_gbn, id, name pname
                                      from program_info
                                      union all
                                      select 'F' app_gbn, id, name pname
                                      from mobile_program_info) P
                             WHERE (( :page - 1) * :row_count) < RNUM
                             and T2.app_gbn = P.app_gbn
                             and T2.pid = P.id
                        ";


                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/PrivacyLog/GetV2 : Get", ex.Message);
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = "0", count = Rcount, data = items });
        }

    }
}
