﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ShopSectorController : ControllerBase
    {
        [HttpGet("{shop_cd}")]
        public async Task<IActionResult> Get(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_SHOP_SECTOR",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            
            List<SiGuDong> siguDongList = new List<SiGuDong>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while(await rd.ReadAsync())
                {
                    SiGuDong siGuDong = new SiGuDong();
                    siGuDong.siguName = rd["SIGU_NAME"].ToString();
                    siGuDong.dongName = rd["DONG_NAME"].ToString();
                    siguDongList.Add(siGuDong);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopSector/shop_cd : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = siguDongList });
        }

        [HttpPost]
        public async Task<IActionResult> Post(string shopCd, string sidoName, string gunguName, IEnumerable<string> dongName, string ucode, string uname)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;


            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.SET_SHOP_SECTOR_MULTI",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shopCd;
            cmd.Parameters.Add("in_sido_name", OracleDbType.Varchar2, 20).Value = sidoName;
            cmd.Parameters.Add("in_gungu_name", OracleDbType.Varchar2, 20).Value = gunguName;

            var arrDongName = cmd.Parameters.Add("in_dong_name", OracleDbType.Varchar2, 20);
            arrDongName.Direction = ParameterDirection.Input;
            arrDongName.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrDongName.Value = dongName.ToArray();
            arrDongName.Size = dongName.Count();
            arrDongName.ArrayBindSize = dongName.Select(_ => _.Length).ToArray();
            arrDongName.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, dongName.Count()).ToArray();

            cmd.Parameters.Add("in_ucode", OracleDbType.Varchar2, 20).Value = ucode;
            cmd.Parameters.Add("in_uname", OracleDbType.Varchar2, 20).Value = uname;

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopSector : Post", ex.Message);
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpDelete]
        public async Task<IActionResult> Delete(string shopCd, string sidoName, string gunguName, string ucode, string uname)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.DELETE_SHOP_SECTOR",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shopCd;
            cmd.Parameters.Add("in_sido_name", OracleDbType.Varchar2, 20).Value = sidoName;
            cmd.Parameters.Add("in_gungu_name", OracleDbType.Varchar2, 20).Value = gunguName;
            cmd.Parameters.Add("in_ucode", OracleDbType.Varchar2, 20).Value = ucode;
            cmd.Parameters.Add("in_uname", OracleDbType.Varchar2, 20).Value = uname;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopSector : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        //배달지 변경이력
        [HttpGet("history/{shop_cd}")]
        public async Task<IActionResult> history(string shop_cd, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT *
                                FROM (select ROWNUM as NO, T1.*
                                from(select hist_date, memo from shop_sector_hist
                                where shop_cd = :shop_cd
                                order by seq desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2
                                WHERE ((:in_page - 1) * :in_rows) < NO
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = items.Count.ToString(), data = items });
        }


        
        /// <summary>
        /// 배달지 지오펜스 여부 조회
        /// </summary>
        [HttpGet("getGeofenceYn/{shop_cd}")]
        public async Task<IActionResult> getGeofenceYn(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string yn = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);

                string sql = @" SELECT NVL((select geofence_yn
                                            from shop_info_add
                                            where shop_cd = :shop_cd),'N') 
                                FROM DUAL
                ";

                db.Open();

                yn = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = yn });
        }

        /// <summary>
        /// 배달지 지오펜스 여부 설정
        /// </summary>
        /// <remarks>
        /// ucode, uname을 받아 값 수정후 shop_sector_hist에 변경이력 기록
        /// </remarks>
        [HttpPost("setGeofenceYn/{shop_cd}")]
        public async Task<IActionResult> setGeofenceYn(string shop_cd, string yn, string ucode, string uname)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);
                param.Add("yn", yn);
                param.Add("ucode", ucode);
                param.Add("uname", uname);

                

                db.Open();

                string sql = @"select count(*) from shop_info_add where shop_cd = :shop_cd";

                int num = await db.ExecuteScalarAsync<int>(sql, param, commandType: CommandType.Text);

                // shop_info_add에 있으면 update 없으면 insert 처리
                if (num > 0)
                {
                    sql = @" update shop_info_add
                         set geofence_yn = :yn
                         where shop_cd = :shop_cd
                        ";
                }
                else
                {
                    sql = @" insert into shop_info_add(shop_cd, cccode, geofence_yn)
                         values (:shop_cd,(select cccode from shop_info where shop_cd = :shop_cd), :yn)
                        ";
                }

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

                
                // 배달지 설정 변경 shop_sector_hist에 로그 기록
                sql = @" insert into shop_sector_hist(shop_cd, memo, hist_date)
                         values (:shop_cd, '배달지 지오펜스 여부 변경, ' || :yn || ',[작업자:' || :uname ||',' || :ucode || ']', sysdate)
                ";

                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);



                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

    }
}
