﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [SwaggerTag("쿠폰")]
    //[Produces("application/json")]
    [ApiController]
    public class CouponController : ControllerBase
    {
        /// <summary>
        /// 대구로 쿠폰 관리 - 목록 조회
        /// </summary>
        /// <remarks>
        /// return data <br />
        /// pub: 발행/ giv: 고객발급/ use: 사용/ exp: 만료/ del: 폐기
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string couponType, string couponStatus, string keyword, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            string Rpub = string.Empty;
            string Rgiv = string.Empty;
            string Ruse = string.Empty;
            string Rexp = string.Empty;
            string Rdel = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_COUPON.GET_COUPON_LIST",
            };

            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_state", OracleDbType.Char, 2).Value = couponStatus;
            cmd.Parameters.Add("in_keyword", OracleDbType.Char, 50).Value = keyword;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_pub", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_giv", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_use", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_exp", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_del", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rpub = cmd.Parameters["out_pub"].Value.ToString();
                Rgiv = cmd.Parameters["out_giv"].Value.ToString();
                Ruse = cmd.Parameters["out_use"].Value.ToString();
                Rexp = cmd.Parameters["out_exp"].Value.ToString();
                Rdel = cmd.Parameters["out_del"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    CouponList m = new CouponList
                    {
                        couponType = rd["COUPON_TYPE"].ToString(),
                        couponName = rd["COUPON_NAME"].ToString(),
                        couponNo = rd["COUPON_NO"].ToString(),
                        randomNo = rd["RANDOM_NO"].ToString(),
                        barCode = rd["BARCODE"].ToString(),
                        status = rd["STATUS"].ToString(),
                        appCustCode = rd["APP_CUST_CODE"].ToString(),
                        custName = rd["CUST_NAME"].ToString(),
                        telNo = rd["TELNO"].ToString(),
                        useAppCustCode = rd["USE_APP_CUST_CODE"].ToString(),
                        useCustName = rd["USE_CUST_NAME"].ToString(),
                        useTelNo = rd["USE_TELNO"].ToString(),
                        orderDate = rd["ORDER_DATE"].ToString(),
                        orderNo = rd["ORDER_NO"].ToString(),
                        shopCd = rd["SHOP_CD"].ToString(),
                        shopName = rd["SHOP_NAME"].ToString(),
                        serviceGbn = rd["SERVICE_GBN"].ToString(),
                        useDate = rd["USE_DATE"].ToString(),
                        couponAmt = rd["COUPON_AMT"].ToString(),
                        linkUrl = rd["LINK_URL"].ToString(),
                        insDate = rd["INS_DATE"].ToString(),
                        insUCode = rd["INS_UCODE"].ToString(),
                        insName = rd["INS_NAME"].ToString(),
                        expDate = rd["EXP_DATE"].ToString(),
                        stDate = rd["ST_DATE"].ToString(),
                        confYN = rd["CONF_YN"].ToString(),
                        confDate = rd["CONF_DATE"].ToString(),
                        confUCode = rd["CONF_UCODE"].ToString(),
                        confName = rd["CONF_NAME"].ToString(),
                    };

                    coupons.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Coupon : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, pub = Rpub, giv = Rgiv, use = Ruse, exp = Rexp, del = Rdel, data = coupons });
        }


        [HttpGet("history/{couponNo}")]
        public async Task<IActionResult> GetHistory(string couponNo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_COUPON.GET_COUPON_HISTORY",
            };

            cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 50).Value = couponNo;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<CouponHistory> couponHistories = new List<CouponHistory>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while(await rd.ReadAsync())
                { 
                    CouponHistory couponHistory = new CouponHistory
                    {
                        SeqNo = rd["SEQNO"].ToString(),
                        couponType = rd["COUPON_TYPE"].ToString(),
                        couponNo = rd["COUPON_NO"].ToString(),
                        histDate = rd["HIST_DATE"].ToString(),
                        memo = rd["MEMO"].ToString(),
                    };

                    couponHistories.Add(couponHistory);
                }
                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Coupon/history/couponNo : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = couponHistories });
        }


        [HttpGet("couponCode")]
        public async Task<IActionResult> GetCouponCode()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_COUPON.GET_COUPON_CODE",
            };

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<CouponCode> couponCodes = new List<CouponCode>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    CouponCode couponCode = new CouponCode
                    {
                        code = rd["CODE"].ToString(),
                        codeName = rd["CODE_NM"].ToString(),
                    };

                    couponCodes.Add(couponCode);
                }
                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Coupon/couponCode : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = couponCodes });
        }

        /// <summary>
        /// 쿠폰 코드 목록
        /// </summary>
        /// <remarks>
        /// systemGbn 시스템 구분(D대구로,T택시,F꽃배달) <br/>
        /// pubGbn 쿠폰지급 구분(A:전체(기본),C:관리앱지급,E:현장이벤트지급) <br/>
        /// testYn 테스트 구분(Y,N)
        /// </remarks>
        [HttpGet("getCouponCodeR")]
        public async Task<IActionResult> getCouponCodeR(string systemGbn, string pubGbn, string testYn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("system_gbn",systemGbn);
            param.Add("pub_gbn", pubGbn);
            param.Add("test_yn", testYn);

            string desc = string.Empty;

            if (pubGbn == "C") //관리앱 지급인 경우만 쿠폰명 정렬
            {
                desc = "order by code_nm";
            }
            else
            {
                desc = "order by ins_date desc";
            }

            string sql = @$"
                            select code ""code"", code_nm ""codeName"", nvl(etc_amt3,0) ""limit""
                            from etc_code
                            where code_grp = 'COUPON_TYPE'
                            and pgm_group = 'O'
                            and use_gbn = 'Y'
                            and nvl(etc_code3,'%') like case when :system_gbn is null then '%' else :system_gbn end
                            and nvl(pub_gbn,'%') like case when :pub_gbn is null then '%' else :pub_gbn end
                            and nvl(test_yn,'%') like case when :test_yn is null then '%' else :test_yn end
                            {desc}
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        [HttpGet("{couponNo}")]
        public async Task<IActionResult> Get(string couponNo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_COUPON.GET_COUPON_DETAIL",
            };

            //OracleParameter op = new OracleParameter();
            //op.OracleDbType = OracleDbType.RefCursor;
            //op.Direction = ParameterDirection.Output;

            cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 50).Value = couponNo;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            CouponList coupon = new CouponList();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                coupon.couponType = rd["COUPON_TYPE"].ToString();
                coupon.couponName = rd["COUPON_NAME"].ToString();
                coupon.couponNo = rd["COUPON_NO"].ToString();
                coupon.randomNo = rd["RANDOM_NO"].ToString();
                coupon.barCode = rd["BARCODE"].ToString();
                coupon.status = rd["STATUS"].ToString();
                coupon.appCustCode = rd["APP_CUST_CODE"].ToString();
                coupon.custName = rd["CUST_NAME"].ToString();
                coupon.telNo = rd["TELNO"].ToString();
                coupon.useAppCustCode = rd["USE_APP_CUST_CODE"].ToString();
                coupon.useCustName = rd["USE_CUST_NAME"].ToString();
                coupon.useTelNo = rd["USE_TELNO"].ToString();
                coupon.orderDate = rd["ORDER_DATE"].ToString();
                coupon.orderNo = rd["ORDER_NO"].ToString();
                coupon.useDate = rd["USE_DATE"].ToString();
                coupon.couponAmt = rd["COUPON_AMT"].ToString();
                coupon.linkUrl = rd["LINK_URL"].ToString();
                coupon.insDate = rd["INS_DATE"].ToString();
                coupon.insUCode = rd["INS_UCODE"].ToString();
                coupon.insName = rd["INS_NAME"].ToString();
                coupon.expDate = rd["EXP_DATE"].ToString();
                coupon.confYN = rd["CONF_YN"].ToString();
                coupon.confDate = rd["CONF_DATE"].ToString();
                coupon.confUCode = rd["CONF_UCODE"].ToString();
                coupon.confName = rd["CONF_NAME"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Coupon/couponNo : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = coupon });
        }


        /// <summary>
        /// 대구로 쿠폰 생성
        /// </summary>
        /// <remarks>
        /// isdAmt : 인성부담금
        /// </remarks>
        [HttpPost]
        public async Task<IActionResult> Post(string couponType, string couponCount, string isdAmt, string exp_date, string insertUcode, string insertName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_COUPON.SET_COUPON_MST",
            };

            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_coupon_cnt", OracleDbType.Int32).Value = couponCount;
            cmd.Parameters.Add("in_isd_amt", OracleDbType.Int32).Value = isdAmt;
            cmd.Parameters.Add("in_exp_date", OracleDbType.Varchar2, 8).Value = exp_date;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = insertUcode;
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 50).Value = insertName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Coupon : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 대구로 쿠폰 일괄 상태변경
        /// </summary>
        [HttpPut]
        public async Task<IActionResult> Put(string couponType, string couponCount, string oldStatus, string newStatus, string jobUcode, string jobName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_COUPON.SET_COUPON_MST_STATUS",
            };

            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_coupon_cnt", OracleDbType.Int32).Value = couponCount;
            cmd.Parameters.Add("in_old_status", OracleDbType.Varchar2, 2).Value = oldStatus;
            cmd.Parameters.Add("in_new_status", OracleDbType.Varchar2, 2).Value = newStatus;

            cmd.Parameters.Add("in_job_ucode", OracleDbType.Int32).Value = jobUcode;
            cmd.Parameters.Add("in_job_name", OracleDbType.Varchar2, 50).Value = jobName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Coupon : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        // 쿠폰 발행/사용 현황
        [HttpGet("getCouponHistory")]
        public async Task<IActionResult> getCouponHistory(string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalCount = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = @"
                                SELECT t2.status,
                                   t2.coupon_name,
                                   t2.coupon_no,
                                   t2.order_no,
                                   t2.order_date,
                                   t2.ins_date,
                                   t2.st_date,
                                   t2.exp_date,
                                   t2.coupon_amt,
                                   t2.shop_name
                              FROM (SELECT ROWNUM AS RNUM,
                                           t1.*
                                      FROM (SELECT DECODE (a.status, '00', '대기', '10', '승인', '20', '발행(고객)', '30', '사용(고객)', '99', '폐기') status,
                                                   a.coupon_name,
                                                   a.coupon_no,
                                                   a.order_no,
                                                   a.order_date,
                                                   a.ins_date,
                                                   a.st_date,
                                                   a.exp_date,
                                                   a.coupon_amt,
                                                   c.shop_name
                                              FROM coupon_mst a,
                                                   (SELECT *
                                                      FROM dorder
                                                     UNION ALL
                                                    SELECT *
                                                      FROM dorder_past) b,
                                                   shop_info c,
                                                   callcenter d
                                             WHERE a.order_no = b.order_no
                                               AND b.shop_cd = c.shop_cd
                                               AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                               AND b.TEST_GBN = 'N'
                                               AND NVL(b.CANCEL_CODE,'00') <> '30'
                                               AND c.cccode = d.cccode
                                               AND d.MCODE = 2
                                               AND b.order_date BETWEEN :date_begin AND :date_end
                                             ORDER BY b.order_no) t1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                             WHERE (( :page - 1) * :row_count) < RNUM
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                sql = @"
                        SELECT count(*)
                          FROM coupon_mst a,
                               (SELECT *
                                  FROM dorder
                                 UNION ALL
                                SELECT *
                                  FROM dorder_past) b,
                               shop_info c,
                               callcenter d
                         WHERE a.order_no = b.order_no
                           AND b.shop_cd = c.shop_cd
                           AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                           AND b.TEST_GBN = 'N'
                           AND NVL(b.CANCEL_CODE,'00') <> '30'
                           AND c.cccode = d.cccode
                           AND d.MCODE = 2
                           AND b.order_date BETWEEN :date_begin AND :date_end
                ";

                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, data = items });
        }



        /// <summary>
        /// 개별 대구로 쿠폰 상태변경 및 폐기
        /// </summary>
        /// <remarks>
        /// jobGbn이 5일때는 개별 푸시메시지X
        /// </remarks>
        [HttpPut("setCouponAppCustomer")]
        public async Task<IActionResult> setCouponAppCustomer(string jobGbn, string custCode, string couponType, string couponNo, string newStatus, string orderNo, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RcouponNo = string.Empty;
            string procedure = string.Empty;

            string gbn = string.Empty;
            if(jobGbn == "5")
            {
                gbn = jobGbn;
                jobGbn = "3";
            }

            if (newStatus == "99")
            {
                procedure = "PKG_IS_ADMIN_COUPON.SET_COUPON_DISPOSAL";
            }
            else
            {
                procedure = "PKG_IS_ADMIN_COUPON.SET_COUPON_APP_CUSTOMER";
            }

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = procedure,
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 1).Value = jobGbn;  // 1: 쿠폰타입으로 등록, 3 : 쿠폰번호로 등록
            cmd.Parameters.Add("in_cust_code", OracleDbType.Int32).Value = custCode;
            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 1000).Value = couponNo;
            cmd.Parameters.Add("in_new_status", OracleDbType.Varchar2, 2).Value = newStatus;
            cmd.Parameters.Add("in_order_no", OracleDbType.Int32).Value = orderNo;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_coupon", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["OUT_RET_CODE"].Value.ToString();

                if (Rcode.Equals("00"))
                {
                    Rmsg = "성공";

                    //쿠폰발급 성공이면 push_msg 전송
                    if(newStatus.Equals("20") && gbn != "5")
                    {
                        await PushController.sendCouponFcm(custCode, "D", couponType,null);
                    }
                    
                }
                else
                {
                    Rmsg = cmd.Parameters["OUT_RET_MSG"].Value.ToString();

                    await Utils.SaveErrorAsync("/Coupon/setCouponAppCustomer : Put", Rmsg);
                }
                
                RcouponNo = cmd.Parameters["OUT_RET_COUPON"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Coupon/setCouponAppCustomer : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, couponNo = RcouponNo });
        }


        /// <summary>
        /// 통합 쿠폰 로그 조회
        /// </summary>
        /// <remarks>
        /// 대구로쿠폰, 제휴쿠폰, 브랜드쿠폰의 생성, 발급, 에러 로그 조회
        /// <br />
        /// <br />
        /// 결과 값 <br />
        /// TYPE_GBN : N: 생성, I: 발급, E: 에러 <br />
        /// DIV : 쿠폰종류 D: 대구로쿠폰, C: 브랜드쿠폰, B: 제휴쿠폰 <br />
        /// </remarks>
        /// <param name="div"></param>
        /// <param name="type_gbn"></param>
        /// <param name="divKey">1: USER_NAME, 2: MSG, 3: POSITION</param>
        /// <param name="keyword"></param>
        /// <param name="date_begin"></param>
        /// <param name="date_end"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        /// 
        // <response code="201">Returns the newly created item</response>
        [HttpGet("getCouponHist")]
        //[ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> getCouponHist(string div, string type_gbn, string divKey, string keyword, string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            string RtotalCount = string.Empty;

            string sDiv = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("div", div);
            param.Add("type_gbn", type_gbn);
            param.Add("divKey", divKey);
            param.Add("keyword", "%" + keyword + "%");
            param.Add("date_begin", date_begin);
            param.Add("date_end", date_end);
            param.Add("page", page);
            param.Add("row_count", rows);

            try
            {

                db.Open();

                string sql = @$"
                                SELECT COUNT(*)
                                FROM coupon_hist
                            ";
                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);


                sql = @$"
                            SELECT COUNT(*)
                            FROM coupon_hist a, users b
                            WHERE a.ins_ucode = b.ucode (+)
                            and TO_CHAR(a.hist_date,'YYYYMMDD') BETWEEN :date_begin AND :date_end
                            and a.div like case when :div is null then '%' else :div end
                            and a.type_gbn like case when :type_gbn is null then '%' else :type_gbn end
                            and case when :divkey = 1  then b.user_name
                                    when :divkey = 2  then a.msg
                                    when :divkey = 3  then a.position
                                end like :keyword
                            
                        ";
                Rcount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);


                sql = @$"
                            SELECT to_char(T2.seq) as seq, T2.type_gbn, T2.div, T2.hist_date , T2.position, T2.msg, to_char(T2.ins_ucode) as ins_ucode, T2.user_name, T2.parameter
                              FROM (SELECT ROWNUM AS RNUM,
                                           T1.*
                                      FROM (SELECT a.*, b.user_name
                                            FROM coupon_hist a, users b
                                            WHERE a.ins_ucode = b.ucode (+)
                                            and TO_CHAR(a.hist_date,'YYYYMMDD') BETWEEN :date_begin AND :date_end
                                            and a.div like case when :div is null then '%' else :div end
                                            and a.type_gbn like case when :type_gbn is null then '%' else :type_gbn end
                                            and case when :divkey = 1  then b.user_name
                                                    when :divkey = 2  then a.msg
                                                    when :divkey = 3  then a.position
                                                end like :keyword
                                            ORDER BY SEQ DESC) T1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) T2
                             WHERE (( :page - 1) * :row_count) < RNUM 
                        ";


                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Coupon/getCouponHist : Get", ex.Message);
                Rcode = "99";
                Rmsg = "실패";
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, count = Rcount, data = items });
        }


        /// <summary>
        /// event_winner_list의 회원에게 대구로 쿠폰 지급(쿠폰생성X) + 푸시발송
        /// </summary>
        /// <remarks>
        /// 푸시 대량발송 처리 추가 <br/>
        /// 타이틀, 메시지 비우면 기본값으로 푸시전송 <br/>
        /// title = coupon_name + "이 도착하였습니다." <br/>
        /// push_msg = "(광고)지금 대구로에서 할인받아 주문하세요~\n*수신거부: 설정에서 변경가능" <br/>
        /// </remarks>
        [HttpPut("givingCoupon")]
        public async Task<IActionResult> givingCoupon(string coupon_type, int cnt, string title,[FromBody]string push_msg)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<string> cust = new List<string>();
            List<string> coupon = new List<string>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("coupon_type", coupon_type);
            param.Add("cnt", cnt);

            
            try
            {
                string sql = @$"
                            select cust_code from event_winner_list where cust_code is not null
                        ";

                db.Open();

                var temp = await db.QueryAsync<string>(sql, param, commandType: CommandType.Text);

                cust = temp.ToList();

                sql = @$"
                            select coupon_no from coupon_mst where status = '10' and coupon_type = :coupon_type and rownum <= :cnt
                        ";

                temp = await db.QueryAsync<string>(sql, param, commandType: CommandType.Text);

                coupon = temp.ToList();

                db.Close();

                if (cust.Count != cnt)
                {
                    return Ok(new { code = "99", msg = "지급대상자 수가 다릅니다. :" + cust.Count });
                }

                if (coupon.Count != cnt)
                {
                    return Ok(new { code = "99", msg = "쿠폰 갯수가 모자랍니다. :" + coupon.Count });
                }

                for (int i = 0; i < cnt; i++)
                {
                    await setCouponAppCustomer("5", cust[i], coupon_type, coupon[i], "20", null, "233");
                }

                await PushController.sendCouponFcmList(DateTime.Now.ToString("yyyyMMdd"), cnt.ToString(), "D", coupon_type, null, title, push_msg);

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }
    }
}
