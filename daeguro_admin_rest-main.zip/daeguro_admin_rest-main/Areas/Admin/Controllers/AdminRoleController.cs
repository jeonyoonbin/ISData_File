﻿using Dapper;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [SwaggerTag("관리앱 권한 관리")]
    [ApiController]
    public class AdminRoleController : ControllerBase
    {
        /// <summary>
        /// 관리앱 권한 조회
        /// </summary>
        /// <remarks>
        /// ucode : 사용자 코드 <br/>
        /// pid : 프로그램 ID <br/>
        /// sidebar_yn : 사이드바 여부
        /// </remarks>
        [HttpGet()]
        public async Task<IActionResult> Get(string ucode, string pid, string sidebar_yn)
        {
            List<object> items = new();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("ucode", ucode);
            param.Add("pid", pid);
            param.Add("sidebar_yn", sidebar_yn);

            string sql = @$"
                            select t.seq, a.id, a.name, case when a.menudepth in ('0','1') then 'Y' else 'N' end SIDEBAR_YN, 
                                   nvl(t.READ_YN,'N') READ_YN, nvl(t.UPDATE_YN,'N') UPDATE_YN, nvl(t.CREATE_YN,'N') CREATE_YN, nvl(t.DELETE_YN,'N') DELETE_YN, nvl(t.DOWNLOAD_YN,'N') DOWNLOAD_YN
                            from program_info a, sidebar_menu d,
                            (select b.seq, b.id, B.READ_YN, B.UPDATE_YN, B.CREATE_YN, B.DELETE_YN, B.DOWNLOAD_YN 
                            from ADMIN_ROLE B, USERS C
                            WHERE B.UCODE = C.UCODE
                            AND C.UCODE = :ucode) t
                            where a.id = d.id (+)
                            and a.id = t.id (+)
                            and nvl(a.pid,0) like case when :pid is null then '%' else :pid end
                            and (case when :sidebar_yn = 'Y' then a.menudepth else '0' end) in ('0','1')
                            and (case when :sidebar_yn = 'N' then nvl(a.menudepth,'2') else '2' end) not in ('0','1')
                            order by a.id
                        ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 관리앱 사이드바 조회
        /// </summary>
        [HttpGet("getSidebar")]
        public async Task<IActionResult> getSidebar(string ucode, string menudepth)
        {
            List<object> items = new();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("ucode", ucode);
            param.Add("in_menudepth", menudepth);

            string sql = @$"
                            SELECT d.sort_seq, A.ID, A.NAME, a.MENUDEPTH, A.ICON, A.URL, A.VISIBLE, A.PID, B.READ_YN
                            FROM PROGRAM_INFO A, ADMIN_ROLE B, USERS C, sidebar_menu d
                            WHERE a.id = d.id
                            and A.ID = B.ID
                            and a.visible = 'Y'
                            --AND B.READ_YN = 'Y'
                            AND B.UCODE = C.UCODE
                            AND C.UCODE = :ucode
                            and a.menudepth in ('0','1')
                            and a.menudepth like case when :in_menudepth is null then '%' else :in_menudepth end
                            order by d.sort_seq
                        ";

            string Rcode;
            string Rmsg;
            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        [HttpPut]
        public async Task<IActionResult> Put(string id, string ucode, string read_yn, string update_yn, string create_yn, string delete_yn, string download_yn, string mod_ucode)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("id", id);
            param.Add("ucode", ucode);
            param.Add("read_yn", read_yn);
            param.Add("update_yn", update_yn);
            param.Add("create_yn", create_yn);
            param.Add("delete_yn", delete_yn);
            param.Add("download_yn", download_yn);
            param.Add("mod_ucode", mod_ucode);


            List<string> items = new();
            string Rmsg;
            string Rcode;
            try
            {
                db.Open();

                string sql = $@"select count(*)
                                from ADMIN_ROLE
                                where ucode = :ucode
                                and id = :id";


                var yn = await db.QuerySingleAsync<int>(sql, param);

                if (yn > 0)
                {
                    //수정
                    sql = @$"
                            update ADMIN_ROLE
                            set read_yn = :read_yn,
                                update_yn = :update_yn,
                                create_yn = :create_yn,
                                delete_yn = :delete_yn,
                                download_yn = :download_yn,
                                mod_ucode = :mod_ucode
                            where id = :id
                            and ucode = :ucode
                            ";

                    await db.ExecuteAsync(sql, param);

                    //수정 로그는 트리거에서 기록
                    //sql = @"insert into admin_role_hist(ucode, id, memo, hist_date, mod_ucode, div)
                    //        values (:ucode, :id,'조회: ' || :read_yn || ', 추가: ' || :create_yn || ', 수정: ' || :update_yn || ', 삭제: ' || :delete_yn || ', 다운로드: ' || :download_yn, sysdate, :mod_ucode, 'E')";

                    //await db.ExecuteAsync(sql, param);
                }
                else
                {
                    //생성
                    sql = @$"
                            insert into ADMIN_ROLE(id, ucode, read_yn, update_yn, create_yn, delete_yn, download_yn)
                            values (:id, :ucode, :read_yn, :update_yn, :create_yn, :delete_yn, :download_yn)
                            ";

                    await db.ExecuteAsync(sql, param);
                }

                

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/AdminRole : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 사용자 권한 복사
        /// </summary>
        /// <remarks>
        /// fr_ucode : 복사할 사용자코드 <br />
        /// to_ucode : 복사 받을 사용자코드 <br />
        /// mod_ucode : 복사작업자 사용자코드
        /// </remarks>
        [HttpPut("copyRole")]
        public async Task<IActionResult> copyRole(string fr_ucode, string to_ucode, string mod_ucode)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);


            DynamicParameters param = new DynamicParameters();
            param.Add("fr_ucode", fr_ucode);
            param.Add("to_ucode", to_ucode);
            param.Add("mod_ucode", mod_ucode);


            List<string> items = new();
            string Rmsg;
            string Rcode;

            db.Open();

            using var transaction = db.BeginTransaction();

            try
            {
                
                string sql = $@"delete from admin_role
                                where ucode = :to_ucode";


                await db.QueryAsync(sql, param);

                sql = $@"insert into admin_role(id, read_yn, create_yn, update_yn, delete_yn, download_yn, ucode, mod_ucode)
                         select id, read_yn, create_yn, update_yn, delete_yn, download_yn, :to_ucode, :mod_ucode  from admin_role
                         where ucode = :fr_ucode";


                await db.QueryAsync(sql, param);

                transaction.Commit();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/AdminRole/copyRole : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 프로그램별 일괄 권한관리
        /// </summary>
        /// <remarks>
        /// id : 프로그램 id <br />
        /// working : 근무구분 (1:재직,3:휴직,5:퇴직) null가능 <br />
        /// mod_ucode : 수정자 코드
        /// </remarks>
        [HttpPut("setAll")]
        public async Task<IActionResult> setAll(string id, string working, string read_yn, string update_yn, string create_yn, string delete_yn, string download_yn, string mod_ucode)
        {
            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("id", id);
            param.Add("working", working);
            param.Add("read_yn", read_yn);
            param.Add("update_yn", update_yn);
            param.Add("create_yn", create_yn);
            param.Add("delete_yn", delete_yn);
            param.Add("download_yn", download_yn);
            param.Add("mod_ucode", mod_ucode);


            List<int> items = new();
            string Rmsg;
            string Rcode;

            string sql;

            try
            {
                db.Open();

                sql = @" select ucode from users
                         where working like case when :working is null then '%' else :working end 
                        ";

                var temp = await db.QueryAsync<int>(sql, param);
                items = temp.ToList();

                foreach (var ucode in items)
                {
                    param.Add("ucode", ucode);

                    sql = $@"select count(*)
                                from ADMIN_ROLE
                                where ucode = :ucode
                                and id = :id";


                    var yn = await db.QuerySingleAsync<int>(sql, param);

                    if (yn > 0)
                    {
                        //수정
                        sql = @$"
                            update ADMIN_ROLE
                            set read_yn = :read_yn,
                                update_yn = :update_yn,
                                create_yn = :create_yn,
                                delete_yn = :delete_yn,
                                download_yn = :download_yn,
                                mod_ucode = :mod_ucode
                            where id = :id
                            and ucode = :ucode
                            ";

                        await db.ExecuteAsync(sql, param);
                    }
                    else
                    {
                        //생성
                        sql = @$"
                            insert into ADMIN_ROLE(id, ucode, read_yn, update_yn, create_yn, delete_yn, download_yn)
                            values (:id, :ucode, :read_yn, :update_yn, :create_yn, :delete_yn, :download_yn)
                            ";

                        await db.ExecuteAsync(sql, param);
                    }
                }

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/AdminRole/setAll : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        //[HttpDelete]
        //public async Task<IActionResult> Delete(string seq, string mod_ucode)
        //{
        //    using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

        //    DynamicParameters param = new DynamicParameters();
        //    param.Add("seq", seq);
        //    param.Add("mod_ucode", mod_ucode);

        //    string Rcode;
        //    string Rmsg;

        //    string Rucode;
        //    string Rid;
        //    try
        //    {
        //        db.Open();


        //        string sql = @$"
        //                    insert into admin_role_hist(ucode, id, memo, hist_date, mod_ucode, div)
        //                    select ucode, id,'조회: ' || read_yn || ', 추가: ' || create_yn || ', 수정: ' || update_yn || ', 삭제: ' || delete_yn || ', 다운로드: ' || download_yn, sysdate, :mod_ucode, 'D'
        //                    from admin_role
        //                    where seq = :seq                   
        //                    ";

        //        await db.ExecuteAsync(sql, param);

        //        sql = @$"
        //                    DELETE ADMIN_ROLE WHERE seq = :seq                      
        //                    ";

        //        await db.ExecuteAsync(sql, param);

        //        db.Close();

        //        Rcode = "00";
        //        Rmsg = "성공";
        //    }
        //    catch (Exception ex)
        //    {
        //        Rcode = "99";
        //        Rmsg = "실패";
        //        await Utils.SaveErrorAsync("/AdminRole : Delete", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}


        /// <summary>
        /// 권한관리 변경이력
        /// </summary>
        /// <remarks>
        /// 로그관리 - 권한관리 변경이력 <br />
        /// div : 1. 사용자, 2. 수정자, 3. 프로그램명
        /// </remarks>
        [HttpGet("getRoleHist")]
        public async Task<IActionResult> getRoleHist(string dateBegin, string dateEnd, string div, string keyword, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            string RtotalCount = string.Empty;
            string RCount = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("div", div);
                param.Add("keyword", "%" + keyword + "%");
                param.Add("date_begin", dateBegin);
                param.Add("date_end", dateEnd);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT *
                                FROM (select ROWNUM as NO, T1.*
                                from(select a.ucode, d.user_name, a.id, b.name, a.memo, a.hist_date, a.mod_ucode, 
                                case when c.user_name is null then '시스템' else c.user_name end as mod_name 
                                from admin_role_hist a, program_info b, users c, users d
                                where  a.hist_date between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                and a.id = b.id (+)
                                and a.ucode = d.ucode (+)
                                and a.mod_ucode = c.ucode (+)
                                and nvl(d.user_name,'%') like case when :div = 1 then :keyword else '%' end
                                and nvl(c.user_name,'%') like case when :div = 2 then :keyword else '%' end
                                and nvl(b.name,'%') like case when :div = 3 then :keyword else '%' end
                                order by a.hist_seq desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2
                                WHERE ((:in_page - 1) * :in_rows) < NO
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                sql = @" select count(*)
                                from admin_role_hist a, program_info b, users c, users d
                                where  a.hist_date between to_date(:date_begin || '000000','YYYYMMDDHH24MISS') and to_date(:date_end || '235959','YYYYMMDDHH24MISS')
                                and nvl(d.user_name,'%') like case when :div = 1 then :keyword else '%' end
                                and nvl(c.user_name,'%') like case when :div = 2 then :keyword else '%' end
                                and nvl(b.name,'%') like case when :div = 3 then :keyword else '%' end
                                and a.id = b.id (+)
                                and a.ucode = d.ucode (+)
                                and a.mod_ucode = c.ucode (+)
                ";

                RCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                sql = @" select count(*)
                         from admin_role_hist
                ";

                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, total_count = RtotalCount, count = RCount, data = items });
        }

    }
}
