﻿using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class AgentCodeController : ControllerBase
    {
        /// <summary>
        /// 콜센터 관리 - 목록 조회
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Get(int mCode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<AgentCode> agents = new List<AgentCode>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_AGENT.GET_AGENT_CODE",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mCode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    AgentCode m = new AgentCode
                    {
                        ccCode = rd["CCCODE"].ToString(),
                        ccName = rd["CCNAME"].ToString(),
                    };

                    agents.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("admin/AgentCode : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = agents });
        }
    }
}
