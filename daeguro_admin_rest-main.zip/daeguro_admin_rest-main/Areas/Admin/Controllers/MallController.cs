﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [SwaggerTag("폐쇄몰")]
    [ApiController]
    public class MallController : ControllerBase
    {

        private static string MD5Encoding(string input)
        {
            var mdHass = MD5.Create();
            byte[] bytes = mdHass.ComputeHash(Encoding.UTF8.GetBytes(input));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                sb.Append(bytes[i].ToString("x2"));
            }
            string result = sb.ToString().ToUpper();

            sb.Clear();

            return result;
        }

        /// <summary>
        /// 폐쇄몰 회원 여부 체크
        /// </summary>
        [HttpPost("existCheck")]
        public static async Task<ResultMall> existCheck(string mcode, string user_id, string password)
        {
            //string url = @$"https://mallapi.283.co.kr/api/V1/users/exist/";
            string url = @$"https://api.daeguromall.com/api/V1/users/exist/";
            string apiKey = string.Empty;

            if (mcode == "2" || //운영 회원사
                user_id == "공주찜닭" ||
                user_id == "롯데리아" ||
                user_id == "99569007" ||
                user_id == "sk" ||
                user_id == "47906348" ||
                user_id == "78742108"
                ) 
            {
                apiKey = Utils.mallKey;
            } 
            else if (mcode == "1") //테스트 회원사
            {
                apiKey = Utils.mallKeyT;
            }

            HttpClient httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Add("method", "GET");
            httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", Utils.base64Encoding(apiKey));

            MallExist mallExist = new MallExist();
            ResultMall mallResult = new ResultMall();
            

            try
            {
                mallExist.user_id = user_id;
                mallExist.password = MD5Encoding(password);

                var payload = mallExist;

                var stringPayload = JsonConvert.SerializeObject(payload);

                HttpContent httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");

                HttpResponseMessage httpResponse = await httpClient.PostAsync(url, httpContent);

                string responseStr = await httpResponse.Content.ReadAsStringAsync();

                mallResult = JsonConvert.DeserializeObject<ResultMall>(responseStr);

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Mall/existCheck : Get", ex.Message);
                mallResult.code = "99";
                mallResult.msg = ex.Message;
                
            }

            return mallResult;
        }

        /// <summary>
        /// 폐쇄몰 회원 등록
        /// </summary>
        [HttpPost("signUp")]
        public static async Task<ResultMall> signUp(MallUser mallUser, string gbn)
        {
            //string url = @$"https://mallapi.283.co.kr/api/V1/users/setup/";
            string url = @$"https://api.daeguromall.com/api/V1/users/setup/";
            string apiKey = string.Empty;

            if (mallUser.mcode == "2" || //운영 회원사
                mallUser.user_id == "공주찜닭" ||
                mallUser.user_id == "롯데리아" ||
                mallUser.user_id == "99569007" ||
                mallUser.user_id == "sk" ||
                mallUser.user_id == "47906348" ||
                mallUser.user_id == "78742108"
                )
            {
                apiKey = Utils.mallKey;
            }
            else if (mallUser.mcode == "1") //테스트 회원사
            {
                apiKey = Utils.mallKeyT;
            }

            HttpClient httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Add("method", "POST");
            httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", Utils.base64Encoding(apiKey));

            ResultMall mallResult = new ResultMall();

            if (string.IsNullOrEmpty(gbn) || (gbn != "D" && gbn != "P"))
            {
                mallResult.code = "99";
                mallResult.msg = "잘못된 경로의 호출입니다";
                await Utils.SaveErrorAsync("/Mall/signUp : Post", mallResult.msg);
                return mallResult;
            }

            try
            {
                mallUser.password = MD5Encoding(mallUser.password);

                var payload = mallUser;

                var stringPayload = JsonConvert.SerializeObject(payload);

                HttpContent httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");

                HttpResponseMessage httpResponse = await httpClient.PostAsync(url, httpContent);

                string responseStr = await httpResponse.Content.ReadAsStringAsync();

                mallResult = JsonConvert.DeserializeObject<ResultMall>(responseStr);

                // 등록내역 기록
                await Utils.SaveTempLogAsync("/Mall/signUp : Post", mallResult.code + "/" + mallResult.msg + "/" + stringPayload);
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Mall/signUp : Post", ex.Message);
                mallResult.code = "99";
                mallResult.msg = ex.Message;

            }

            return mallResult;
        }

        /// <summary>
        /// 폐쇄몰 회원 수정
        /// </summary>
        [HttpPut("modUser")]
        public static async Task<ResultMall> modUser(MallUser mallUser, string gbn)
        {
            //string url = @$"https://mallapi.283.co.kr/api/V1/users/setup/";
            string url = @$"https://api.daeguromall.com/api/V1/users/setup/";
            string apiKey = string.Empty;

            if (mallUser.mcode == "2" || //운영 회원사
               mallUser.user_id == "공주찜닭" ||
               mallUser.user_id == "롯데리아" ||
               mallUser.user_id == "99569007" ||
               mallUser.user_id == "sk" ||
               mallUser.user_id == "47906348" ||
               mallUser.user_id == "78742108"
               )
            {
                apiKey = Utils.mallKey;
            }
            else if (mallUser.mcode == "1") //테스트 회원사
            {
                apiKey = Utils.mallKeyT;
            }

            HttpClient httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Add("method", "PUT");
            httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", Utils.base64Encoding(apiKey));

            ResultMall mallResult = new ResultMall();

            if (string.IsNullOrEmpty(gbn) || (gbn != "D" && gbn != "P"))
            {
                mallResult.code = "99";
                mallResult.msg = "잘못된 경로의 호출입니다";
                await Utils.SaveErrorAsync("/Mall/modUser : Put", mallResult.msg);
                return mallResult;
            }

            try
            {
                mallUser.password = MD5Encoding(mallUser.password);

                var payload = mallUser;

                var stringPayload = JsonConvert.SerializeObject(payload);

                HttpContent httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");

                HttpResponseMessage httpResponse = await httpClient.PostAsync(url, httpContent);

                string responseStr = await httpResponse.Content.ReadAsStringAsync();

                mallResult = JsonConvert.DeserializeObject<ResultMall>(responseStr);

                // 수정내역 기록
                await Utils.SaveTempLogAsync("/Mall/modUser : Put", mallResult.code + "/" + mallResult.msg + "/" + stringPayload);
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Mall/modUser : Put", ex.Message);
                mallResult.code = "99";
                mallResult.msg = ex.Message;

            }

            return mallResult;
        }

        //폐쇄몰 유저정보 등록 및 수정용 정보 조회
        [HttpGet("getShopInfoForMall")]
        public static async Task<MallUser> getShopInfoForMall(string shop_cd)
        {

            MallUser item = new MallUser();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shop_cd);

                db.Open();

                //대구로몰 필수 이용약관에 동의한 경우만 데이터 조회
                string sql = @$"
                            select case when count(*) = 2 then 'Y' else 'N' end
                            from dgr_tos_agre_log
                            where agre_yn = 'Y'
                            and shop_cd = :shop_cd
                            and tos_seq in (9,10)
                        ";

                string yn = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                if (yn == "Y")
                {
                    sql = @$"
                         select b.mcode,
                                a.shop_id user_id,
                                a.shop_pass password,
                                a.shop_name user_name,
                                a.mobile tel_no,
                                a.email,
                                a.shop_cd fk_shop_cd,
                                a.sido_name sido,
                                a.gungu_name gugun,
                                a.dong_name dong,
                                case when a.addr2 is null then a.addr1 else a.addr2 end address,
                                a.loc address_detail,
                                a.lon address_lon,
                                a.lat address_lat,
                                nvl((select item_name from item_mst where item_cd = a.item_cd),'카테고리 미선택') memo
                        from shop_info a, callcenter b
                        where a.cccode = b.cccode
                        and a.shop_cd = :shop_cd
                    ";

                    item = await db.QuerySingleAsync<MallUser>(sql, param, commandType: CommandType.Text);

                }
                else
                {
                    item.user_id = "N";
                }


                db.Close();
            }
            catch (Exception ex)
            {

            }

            return item;
        }

        //카테고리명 조회
        public static async Task<string> getItemName(string item_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string item_name = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("in_item_cd", item_cd);

                string sql = $@"
                                select nvl((select item_name
                                    from item_mst
                                    where item_cd = :in_item_cd),'카테고리 미선택')
                                from dual
                                ";

                item_name = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ShopInfo/getItemName : Get", ex.Message);
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return item_name;
        }

    }
}
