﻿using Dapper;
using ClosedXML.Excel;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.AspNetCore.Http;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [ApiController]
    [Route("/[controller]")]
    public class NoticeEmController : ControllerBase
    {
        string noticEmPath = @"\\10.10.10.100\dgnas\Files\AppAlertImage";

        string nasPath = @"\\10.10.10.100\dgnas\Files";

        /// <summary>
        /// 긴급공지 목록 조회
        /// </summary>
        /// <remarks>
        /// use : 진입구분(0:사용불가, 1:정상진입, 2:팝업후 정상진입.) <br/>
        /// 팝업 미사용시 use 1 <br/>
        /// title: 제목 <br/>
        /// device_gbn: 노출 디바이스 구분(1: 전체, 2: 안드로이드, 3: 아이폰) <br/>
        /// android_ver: 안드로이드 권장버전 <br/>
        /// android_min: 안드로이드 최소버전 <br/>
        /// ios_ver: 아이폰 권장버전 <br/>
        /// ios_min: 아이폰 최소버전 <br/>
        /// ins_date: 등록일시 <br/>
        /// ins_ucode: 등록자 코드 <br/>
        /// ins_name: 등록자명 <br/>
        /// mod_date: 수정일시 <br/>
        /// mod_ucode: 수정자 코드 <br/>
        /// mod_name: 수정자명
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string use, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<NoticeEmList> itmes = new List<NoticeEmList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_NOTICE.GET_NOTICE_EM_LIST",
            };

            cmd.Parameters.Add("in_use", OracleDbType.Varchar2, 1).Value = use;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    NoticeEmList item = new NoticeEmList
                    {
                        seq = rd["SEQ"].ToString(),
                        use = rd["USE"].ToString(),
                        title = rd["TITLE"].ToString(),
                        device_gbn = rd["DEVICE_GBN"].ToString(),
                        android_ver = rd["ANDROID_VER"].ToString(),
                        android_min = rd["ANDROID_MIN"].ToString(),
                        ios_ver = rd["IOS_VER"].ToString(),
                        ios_min = rd["IOS_MIN"].ToString(),
                        ins_date = rd["INS_DATE"].ToString(),
                        ins_ucode = rd["INS_UCODE"].ToString(),
                        ins_name = rd["INS_NAME"].ToString(),
                        mod_date = rd["MOD_DATE"].ToString(),
                        mod_ucode = rd["MOD_UCODE"].ToString(),
                        mod_name = rd["MOD_NAME"].ToString()
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/NoticeEm : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }



        /// <summary>
        /// 긴급공지 상세 조회
        /// </summary>
        /// <remarks>
        /// use : 진입구분(0:사용불가, 1:정상진입, 2:팝업후 정상진입. 팝업을 사용 안할때는 1, 사용할때는 0 or 2로 설정되어야 함) <br/>
        /// title: 제목 <br/>
        /// contents : 내용 <br/>
        /// url : 이미지 클릭시 이동될 url <br/>
        /// img_url: 이미지 url 가로3:세로4비율 <br/>
        /// device_gbn: 노출 디바이스 구분(1: 전체, 2: 안드로이드, 3: 아이폰) <br/>
        /// android_ver: 안드로이드 권장버전 <br/>
        /// android_min: 안드로이드 최소버전 <br/>
        /// ios_ver: 아이폰 권장버전 <br/>
        /// ios_min: 아이폰 최소버전 <br/>
        /// ins_date: 등록일시 <br/>
        /// ins_ucode: 등록자 코드 <br/>
        /// ins_name: 등록자명 <br/>
        /// mod_date: 수정일시 <br/>
        /// mod_ucode: 수정자 코드 <br/>
        /// mod_name: 수정자명
        /// </remarks>
        [HttpGet("{seq}")]
        public async Task<IActionResult> Get(int seq)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_NOTICE.GET_NOTICE_EM_DETAIL",
            };

            //OracleParameter op = new OracleParameter();
            //op.OracleDbType = OracleDbType.RefCursor;
            //op.Direction = ParameterDirection.Output;

            cmd.Parameters.Add("in_seq", OracleDbType.Int32).Value = seq;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            NoticeEmDetail item = new NoticeEmDetail();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.seq = rd["SEQ"].ToString();
                item.use = rd["USE"].ToString();
                item.title = rd["TITLE"].ToString();
                item.contents = rd["CONTENTS"].ToString();
                item.url = rd["URL"].ToString();
                item.img_url = rd["IMG_URL"].ToString();
                item.device_gbn = rd["DEVICE_GBN"].ToString();
                item.android_ver = rd["ANDROID_VER"].ToString();
                item.android_min = rd["ANDROID_MIN"].ToString();
                item.ios_ver = rd["IOS_VER"].ToString();
                item.ios_min = rd["IOS_MIN"].ToString();
                item.ins_date = rd["INS_DATE"].ToString();
                item.ins_ucode = rd["INS_UCODE"].ToString();
                item.ins_name = rd["INS_NAME"].ToString();
                item.mod_date = rd["MOD_DATE"].ToString();
                item.mod_ucode = rd["MOD_UCODE"].ToString();
                item.mod_name = rd["MOD_NAME"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/NoticeEm/seq : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }




        /// <summary>
        /// 긴급공지 등록
        /// </summary>
        /// <remarks>
        /// 등록과 수정에 동일 모델을 사용하여 불필요한 파라미터가 섞여 있습니다(NoticeEm) <br/>
        /// <br/>
        /// use : 진입구분(0:사용불가, 1:정상진입, 2:팝업후 정상진입. 팝업을 사용 안할때는 1, 사용할때는 0 or 2로 설정되어야 함) <br/>
        /// title: 제목 <br/>
        /// contents : 내용 <br/>
        /// url : 이미지 클릭시 이동될 url <br/>
        /// device_gbn: 노출 디바이스 구분(1: 전체, 2: 안드로이드, 3: 아이폰) <br/>
        /// android_ver: 안드로이드 권장버전 <br/>
        /// android_min: 안드로이드 최소버전 <br/>
        /// ios_ver: 아이폰 권장버전 <br/>
        /// ios_min: 아이폰 최소버전 <br/>
        /// ucode: 등록자 코드 
        /// </remarks>
        //[HttpPost]
        //public async Task<IActionResult> Post(IFormFile formFile, [FromForm] NoticeEm noticeEm)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    try
        //    {
        //        if (formFile != null && formFile.Length > 0)
        //        {
        //            noticeEm.seq = await setNoticeEm("Y", noticeEm);

        //            if (noticeEm.seq.Equals("0"))
        //            {
        //                Rcode = "99";
        //                Rmsg = "긴급공지 등록 실패";
        //                return Ok(new { code = Rcode, msg = Rmsg });
        //            }

        //            // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
        //            using (new ConnectToSharedFolder(nasPath))
        //            {
        //                string folerPath = noticEmPath + "\\" + noticeEm.seq + ".jpg";
        //                using var stream = System.IO.File.Create(folerPath);

        //                await formFile.CopyToAsync(stream);

        //                stream.Close();
        //                stream.Dispose();
        //            }
                    
        //        }
        //        else
        //        {
        //            noticeEm.seq = await setNoticeEm("N", noticeEm);

        //            if (noticeEm.seq.Equals("0"))
        //            {
        //                Rcode = "99";
        //                Rmsg = "긴급공지 등록 실패";
        //                return Ok(new { code = Rcode, msg = Rmsg });
        //            }
        //        }

        //        Rcode = "00";
        //        Rmsg = "성공";


        //    }
        //    catch (Exception ex)
        //    {
        //        Rcode = "01";
        //        Rmsg = "예외처리발생";
        //        await Utils.SaveErrorAsync("/NoticeEm : Post", ex.Message);
        //    }


        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}


        //private async Task<string> setNoticeEm(string img_yn, NoticeEm noticeEm)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    noticeEm.seq = string.Empty;

        //    using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

        //    DynamicParameters param = new DynamicParameters();
        //    param.Add("use", noticeEm.use);
        //    param.Add("title", noticeEm.title);
        //    param.Add("contents", noticeEm.contents);
        //    param.Add("url", noticeEm.url);
        //    param.Add("img_yn", img_yn);
        //    param.Add("device_gbn", noticeEm.device_gbn);
        //    param.Add("android_ver", noticeEm.android_ver);
        //    param.Add("android_min", noticeEm.android_min);
        //    param.Add("ios_ver", noticeEm.ios_ver);
        //    param.Add("ios_min", noticeEm.ios_min);
        //    param.Add("ins_ucode", noticeEm.ucode);

        //    string sql = @"
        //                        insert into em_notice(use, 
        //                                              title, 
        //                                              contents, 
        //                                              url, 
        //                                              img_url, 
        //                                              device_gbn, 
        //                                              android_ver, 
        //                                              android_min, 
        //                                              ios_ver, 
        //                                              ios_min, 
        //                                              ins_date,
        //                                              ins_ucode)
        //                        values (:use, 
        //                                :title, 
        //                                :contents, 
        //                                :url, 
        //                                case when :img_yn = 'Y' then 
        //                                                (select last_number
        //                                                from user_sequences
        //                                                where sequence_name = 'EM_NOTICE_SEQ') || '.jpg' 
        //                                    else null end, 
        //                                :device_gbn, 
        //                                :android_ver, 
        //                                :android_min, 
        //                                :ios_ver, 
        //                                :ios_min, 
        //                                sysdate,
        //                                :ins_ucode)
        //                ";

        //    db.Open();
        //    using var transaction = db.BeginTransaction();

        //    try
        //    {
        //        await db.ExecuteAsync(sql, param, commandType: CommandType.Text);

        //        sql = $@"
        //                  select last_number - 1
        //                from user_sequences
        //                where sequence_name = 'EM_NOTICE_SEQ'
        //                ";
        //        noticeEm.seq =  await db.ExecuteScalarAsync<string>(sql, commandType: CommandType.Text);

        //        transaction.Commit();
        //        db.Close();

        //        Rcode = "00";
        //        Rmsg = "성공";
        //    }
        //    catch (Exception ex)
        //    {
        //        transaction.Rollback();
        //        Rcode = "99";
        //        Rmsg = ex.Message;
        //        noticeEm.seq = "0";
        //        await Utils.SaveErrorAsync("/NoticeEm/setNoticeEm : Post", ex.Message);
        //    }


        //    return noticeEm.seq;
        //}


        /// <summary>
        /// 긴급공지 수정
        /// </summary>
        /// <remarks>
        /// 등록과 수정에 동일 모델을 사용하여 불필요한 파라미터가 섞여 있습니다(NoticeEm) <br/>
        /// <br/>
        /// use : 진입구분(0:사용불가, 1:정상진입, 2:팝업후 정상진입. 팝업을 사용 안할때는 1, 사용할때는 0 or 2로 설정되어야 함) <br/>
        /// title: 제목 <br/>
        /// contents : 내용 <br/>
        /// url : 이미지 클릭시 이동될 url <br/>
        /// device_gbn: 노출 디바이스 구분(1: 전체, 2: 안드로이드, 3: 아이폰) <br/>
        /// android_ver: 안드로이드 권장버전 <br/>
        /// android_min: 안드로이드 최소버전 <br/>
        /// ios_ver: 아이폰 권장버전 <br/>
        /// ios_min: 아이폰 최소버전 <br/>
        /// ucode: 수정자 코드 
        /// </remarks>
        [HttpPut]
        public async Task<IActionResult> Put(IFormFile formFile, [FromForm] NoticeEm noticeEm)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                if (formFile != null && formFile.Length > 0)
                {
                    Rcode = await updateNoticeEm("Y", noticeEm);

                    if (Rcode.Equals("99"))
                    {
                        Rcode = "99";
                        Rmsg = "긴급공지 수정 실패";
                        return Ok(new { code = Rcode, msg = Rmsg });

                    }

                    // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        string folerPath = noticEmPath + "\\" + noticeEm.seq + ".jpg";
                        using var stream = System.IO.File.Create(folerPath);

                        await formFile.CopyToAsync(stream);

                        stream.Close();
                        stream.Dispose();
                    }

                }
                else
                {
                    Rcode = await updateNoticeEm("N", noticeEm);

                    if (Rcode.Equals("99"))
                    {
                        Rcode = "99";
                        Rmsg = "긴급공지 수정 실패";
                        return Ok(new { code = Rcode, msg = Rmsg });
                    }

                }

                Rcode = "00";
                Rmsg = "성공";

            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = "예외처리발생";
                await Utils.SaveErrorAsync("/NoticeEm : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg });
        }


        private async Task<string> updateNoticeEm(string img_yn, NoticeEm noticeEm)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("seq", noticeEm.seq);
                param.Add("use", noticeEm.use);
                param.Add("title", noticeEm.title);
                param.Add("contents", noticeEm.contents);
                param.Add("url", noticeEm.url);
                param.Add("img_yn", img_yn);
                param.Add("device_gbn", noticeEm.device_gbn);
                param.Add("android_ver", noticeEm.android_ver);
                param.Add("android_min", noticeEm.android_min);
                param.Add("ios_ver", noticeEm.ios_ver);
                param.Add("ios_min", noticeEm.ios_min);
                param.Add("mod_ucode", noticeEm.ucode);

                string sql = @"
                                update em_notice
                                set use = :use,
                                    title = :title,
                                    contents = :contents,
                                    url = :url,
                                    img_url = case when :img_yn = 'Y' then :seq || '.jpg' else img_url end,
                                    device_gbn = :device_gbn,
                                    android_ver = :android_ver,
                                    android_min = :android_min,
                                    ios_ver = :ios_ver,
                                    ios_min = :ios_min,
                                    mod_ucode = :mod_ucode,
                                    mod_date = sysdate
                                where seq = :seq
                                ";

                db.Open();
                await db.ExecuteAsync(sql, param, commandType: CommandType.Text); 
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/NoticeEm/updateNoticeEm : Put", ex.Message);
            }


            return Rcode;
        }

        /// <summary>
        /// 긴급공지 이미지 삭제
        /// </summary>
        [HttpPut("deleteNoticeEmImg")]
        public async Task<IActionResult> deleteNoticeEmImg(string seq, string mod_ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("seq", seq);
                param.Add("mod_ucode", mod_ucode);

                string sql = @"
                                update em_notice
                                set img_url = null,
                                    mod_date = sysdate,
                                    mod_ucode = :mod_ucode
                                where seq = :seq
                                and img_url is not null
                                ";

                db.Open();
                int n = await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                db.Close();

                if (n == 0)
                {
                    Rcode = "99";
                    Rmsg = "삭제할 이미지가 없습니다";
                    return Ok(new { code = Rcode, msg = Rmsg });
                }

                // 경로 끝에 \이 있으면 네트워크 경로를 못 찾음!!!
                using (new ConnectToSharedFolder(nasPath))
                {
                    string folerPath = noticEmPath + "\\" + seq + ".jpg";

                    // 파일이 존재하면 삭제한다.
                    if (System.IO.File.Exists(folerPath))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        System.IO.File.Delete(folerPath);
                    }

                }

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/NoticeEm/deleteNoticeEmImg : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg }); ;
        }

        /// <summary>
        /// 결제장애 공지 조회
        /// </summary>
        /// <remarks>
        /// disorder_divice_gbn : 결제장애 디바이스 구분(1:전체, 2: 안드로이드, 3: 아이폰) <br/>
        /// card_yn 카드 결제버튼 활성여부 <br/>
        /// happy_pay_yn 행복페이 결제버튼 활성여부 <br/>
        /// kakao_yn 카카오페이 결제버튼 활성여부 <br/>
        /// naver_yn 네이버페이 결제버튼 활성여부 <br/>
        /// samsung_yn 삼성페이 결제버튼 활성여부 <br/>
        /// meet_cash_yn 만나서 현금 결제버튼 활성여부 <br/>
        /// meet_card_yn 만나서 카드 결제버튼 활성여부 <br/>
        /// zero_pay_yn 제로페이 결제버튼 활성여부 <br/>
        /// onnuri_vc_yn 온누리 상품권 결제버튼 활성여부 <br/>
        /// toss_yn 토스 결제버튼 활성여부 <br/>
        /// apple_pay_yn 애플 페이 결제버튼 활성여부 <br/>
        /// shinhan_pg_yn 신한PG 결제버튼 활성여부 <br/>
        /// child_card_yn 아동급식카드 결제버튼 활성여부 <br/>
        /// non_mem_card_yn 비회원 카드 결제버튼 활성여부 <br/>
        /// </remarks>
        [HttpGet("getPayEm")]
        public async Task<IActionResult> getPayEm(int seq)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_NOTICE.GET_PAY_EM_DETAIL",
            };

            //OracleParameter op = new OracleParameter();
            //op.OracleDbType = OracleDbType.RefCursor;
            //op.Direction = ParameterDirection.Output;

            cmd.Parameters.Add("in_seq", OracleDbType.Int32).Value = seq;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            NoticePayEmDetail item = new NoticePayEmDetail();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                item.seq = rd["SEQ"].ToString();
                item.disorder_divice_gbn = rd["disorder_divice_gbn"].ToString();
                item.card_yn = rd["card_yn"].ToString();
                item.card_msg = rd["card_msg"].ToString();
                item.happy_pay_yn = rd["happy_pay_yn"].ToString();
                item.happy_pay_msg = rd["happy_pay_msg"].ToString();
                item.kakao_yn = rd["kakao_yn"].ToString();
                item.kakao_msg = rd["kakao_msg"].ToString();
                item.naver_yn = rd["naver_yn"].ToString();
                item.naver_msg = rd["naver_msg"].ToString();
                item.samsung_yn = rd["samsung_yn"].ToString();
                item.samsung_msg = rd["samsung_msg"].ToString();
                item.meet_cash_yn = rd["meet_cash_yn"].ToString();
                item.meet_cash_msg = rd["meet_cash_msg"].ToString();
                item.meet_card_yn = rd["meet_card_yn"].ToString();
                item.meet_card_msg = rd["meet_card_msg"].ToString();
                item.zero_pay_yn = rd["zero_pay_yn"].ToString();
                item.zero_pay_msg = rd["zero_pay_msg"].ToString();
                item.onnuri_vc_yn = rd["onnuri_vc_yn"].ToString();
                item.onnuri_vc_msg = rd["onnuri_vc_msg"].ToString();
                item.toss_yn = rd["toss_yn"].ToString();
                item.toss_msg = rd["toss_msg"].ToString();
                item.apple_pay_yn = rd["apple_pay_yn"].ToString();
                item.apple_pay_msg = rd["apple_pay_msg"].ToString();
                item.shinhan_pg_yn = rd["shinhan_pg_yn"].ToString();
                item.shinhan_pg_msg = rd["shinhan_pg_msg"].ToString();
                item.child_card_yn = rd["child_card_yn"].ToString();
                item.child_card_msg = rd["child_card_msg"].ToString();
                item.non_mem_card_yn = rd["non_mem_card_yn"].ToString();
                item.non_mem_card_msg = rd["non_mem_card_msg"].ToString();
                item.ins_date = rd["ins_date"].ToString();
                item.ins_ucode = rd["INS_UCODE"].ToString();
                item.ins_name = rd["INS_NAME"].ToString();
                item.mod_date = rd["MOD_DATE"].ToString();
                item.mod_ucode = rd["MOD_UCODE"].ToString();
                item.mod_name = rd["MOD_NAME"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/NoticeEm/seq : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }

        /// <summary>
        /// 결제장애 공지 수정
        /// </summary>
        /// <remarks>
        // disorder_divice_gbn : 결제장애 디바이스 구분(1:전체, 2: 안드로이드, 3: 아이폰) <br/>
        /// card_yn 카드 결제버튼 활성여부 <br/>
        /// happy_pay_yn 행복페이 결제버튼 활성여부 <br/>
        /// kakao_yn 카카오페이 결제버튼 활성여부 <br/>
        /// naver_yn 네이버페이 결제버튼 활성여부 <br/>
        /// samsung_yn 삼성페이 결제버튼 활성여부 <br/>
        /// meet_cash_yn 만나서 현금 결제버튼 활성여부 <br/>
        /// meet_card_yn 만나서 카드 결제버튼 활성여부 <br/>
        /// zero_pay_yn 제로페이 결제버튼 활성여부 <br/>
        /// onnuri_vc_yn 온누리 상품권 결제버튼 활성여부 <br/>
        /// toss_yn 토스 결제버튼 활성여부 <br/>
        /// apple_pay_yn 애플 페이 결제버튼 활성여부 <br/>
        /// shinhan_pg_yn 신한PG 결제버튼 활성여부 <br/>
        /// child_card_yn 아동급식카드 결제버튼 활성여부 <br/>
        /// non_mem_card_yn 비회원 카드 결제버튼 활성여부 <br/>
        /// </remarks>
        [HttpPut("updatePayEm")]
        public async Task<IActionResult> updatePayEm(NoticePayEm noticePayEm)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("seq", noticePayEm.seq);
                //param.Add("disorder_divice_gbn", noticePayEm.disorder_divice_gbn);
                param.Add("card_yn", noticePayEm.card_yn);
                param.Add("card_msg", noticePayEm.card_msg);
                param.Add("happy_pay_yn", noticePayEm.happy_pay_yn);
                param.Add("happy_pay_msg", noticePayEm.happy_pay_msg);
                param.Add("kakao_yn", noticePayEm.kakao_yn);
                param.Add("kakao_msg", noticePayEm.kakao_msg);
                param.Add("naver_yn", noticePayEm.naver_yn);
                param.Add("naver_msg", noticePayEm.naver_msg);
                param.Add("samsung_yn", noticePayEm.samsung_yn);
                param.Add("samsung_msg", noticePayEm.samsung_msg);
                param.Add("meet_cash_yn", noticePayEm.meet_cash_yn);
                param.Add("meet_cash_msg", noticePayEm.meet_cash_msg);
                param.Add("meet_card_yn", noticePayEm.meet_card_yn);
                param.Add("meet_card_msg", noticePayEm.meet_card_msg);
                param.Add("zero_pay_yn", noticePayEm.zero_pay_yn);
                param.Add("zero_pay_msg", noticePayEm.zero_pay_msg);
                param.Add("onnuri_vc_yn", noticePayEm.onnuri_vc_yn);
                param.Add("onnuri_vc_msg", noticePayEm.onnuri_vc_msg);
                param.Add("toss_yn", noticePayEm.toss_yn);
                param.Add("toss_msg", noticePayEm.toss_msg);
                param.Add("apple_pay_yn", noticePayEm.apple_pay_yn);
                param.Add("apple_pay_msg", noticePayEm.apple_pay_msg);
                param.Add("shinhan_pg_yn", noticePayEm.shinhan_pg_yn);
                param.Add("shinhan_pg_msg", noticePayEm.shinhan_pg_msg);
                param.Add("child_card_yn", noticePayEm.child_card_yn);
                param.Add("child_card_msg", noticePayEm.child_card_msg);
                param.Add("non_mem_card_yn", noticePayEm.non_mem_card_yn);
                param.Add("non_mem_card_msg", noticePayEm.non_mem_card_msg);
                param.Add("mod_ucode", noticePayEm.ucode);

                string sql = @"
                                update em_notice
                                set disorder_divice_gbn = :disorder_divice_gbn,
                                    card_yn = :card_yn,
                                    card_msg = :card_msg,
                                    happy_pay_yn = :happy_pay_yn,
                                    happy_pay_msg = :happy_pay_msg,
                                    kakao_yn = :kakao_yn,
                                    kakao_msg = :kakao_msg,
                                    naver_yn = :naver_yn,
                                    naver_msg = :naver_msg,
                                    samsung_yn = :samsung_yn,
                                    samsung_msg = :samsung_msg,
                                    meet_cash_yn = :meet_cash_yn,
                                    meet_cash_msg = :meet_cash_msg,
                                    meet_card_yn = :meet_card_yn,
                                    meet_card_msg = :meet_card_msg,
                                    zero_pay_yn = :zero_pay_yn,
                                    zero_pay_msg = :zero_pay_msg,
                                    onnuri_vc_yn = :onnuri_vc_yn,
                                    onnuri_vc_msg = :onnuri_vc_msg,
                                    toss_yn = :toss_yn,
                                    toss_msg = :toss_msg,
                                    apple_pay_yn = :apple_pay_yn,
                                    apple_pay_msg = :apple_pay_msg,
                                    shinhan_pg_yn = :shinhan_pg_yn,
                                    shinhan_pg_msg = :shinhan_pg_msg,
                                    child_card_yn = :child_card_yn,
                                    child_card_msg = :child_card_msg,
                                    non_mem_card_yn = :non_mem_card_yn,
                                    non_mem_card_msg = :non_mem_card_msg,
                                    mod_ucode = :mod_ucode,
                                    mod_date = sysdate
                                where seq = :seq
                                ";

                db.Open();
                await db.ExecuteAsync(sql, param, commandType: CommandType.Text);
                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/NoticeEm/updatePayEm : Put", ex.Message);
            }


            return Ok(new { code = Rcode, msg = Rmsg }); ;
        }


    }
}
