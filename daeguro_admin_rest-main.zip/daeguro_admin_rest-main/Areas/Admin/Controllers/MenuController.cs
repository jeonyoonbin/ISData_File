﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        string productPath = @"\\10.10.10.100\dgnas\Files\ProductImage";
        string testImagePath = @"E:\iis\Files\TestImage";
        string nasPath = @"\\10.10.10.100\dgnas\Files";

        /// <summary>
        /// 메뉴목록 조회
        /// </summary>
        /// <remarks>
        /// 멀티이미지 메뉴일 경우 menu_image_multi에서 이미지 호출 <br/>
        /// keyword 메뉴명 검색기능 추가, 2023.07.25 <br/>
        /// 이하내용 전자관때 추가예정 <br/>
        /// discYn 할인여부 <br/>
        /// discRatio 할인률 <br/>
        /// amount 할인적용금액 <br/>
        /// </remarks>
        [HttpGet("menuList/{menuGroupCd}")]
        public async Task<IActionResult> GetMenuList(string menuGroupCd, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<MenuList> menues = new List<MenuList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.GET_MENU_LIST",
            };

            cmd.Parameters.Add("in_menu_group_cd", OracleDbType.Int32).Value = menuGroupCd;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 300).Value = keyword;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    MenuList m = new MenuList
                    {
                        menuCd = rd["MENU_CD"].ToString(),
                        Name = rd["MENU_NAME"].ToString(),
                        cost = rd["MENU_COST"].ToString(),
                        fileName = rd["FILE_NAME"].ToString(),
                        multiCnt = rd["multi_cnt"].ToString(),
                        aloneOrderYn = rd["M_ALONE_ORDER"].ToString(),
                        mainMenuYn = rd["M_MAIN_YN"].ToString(),
                        useGbn = rd["USE_GBN"].ToString(),
                        noFlag = rd["NO_FLAG"].ToString(),
                        adultOnly = rd["ADULT_ONLY"].ToString(),
                        singleOrderYn = rd["single_order_yn"].ToString(),
                        menuEventYn = rd["MENU_EVENT_YN"].ToString(),
                        //discYn = rd["disc_yn"].ToString(),
                        //discRatio = rd["disc_ratio"].ToString(),
                        //amount = rd["amount"].ToString(),
                    };

                    menues.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu/menuList/{menuGroupCd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = menues });
        }


        [HttpGet("menuNameList")]
        public async Task<IActionResult> GetMenuNameList(string shopCd, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<string> items = new List<string>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_MENU_NAME_LIST",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shopCd;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 20).Value = keyword;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    items.Add(rd["MENU_NAME"].ToString());
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu/menuNameList/{shopCd} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 메뉴생성
        /// </summary>
        /// <remarks>
        /// singleOrderYn 주류 단독주문가능여부(Y/N)
        /// </remarks>
        [HttpPost]
        public async Task<IActionResult> Post(ShopMenu shop)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            // 프론트 업데이트 미적용 예외처리
            //if (string.IsNullOrEmpty(shop.singleOrderYn))
            //{
            //    Rcode = "99";
            //    Rmsg = "주류단독주문가능여부 값이 비었습니다.";
            //    return Ok(new { code = Rcode, msg = Rmsg });
            //}

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.ADD_MENU",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = shop.shopCd;
            cmd.Parameters.Add("in_group_cd", OracleDbType.Varchar2, 10).Value = shop.groupCd;
            cmd.Parameters.Add("in_menu_name", OracleDbType.Varchar2, 100).Value = shop.menuName;
            cmd.Parameters.Add("in_menu_cost", OracleDbType.Int32).Value = shop.menuCost;
            cmd.Parameters.Add("in_menu_desc", OracleDbType.Varchar2, 500).Value = shop.menuDesc;
            //cmd.Parameters.Add("in_m_alone_order", OracleDbType.Varchar2, 1).Value = shop.aloneOrder;
            cmd.Parameters.Add("in_m_main_yn", OracleDbType.Varchar2, 1).Value = shop.mainYn;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 1).Value = shop.useYn;
            cmd.Parameters.Add("in_no_flag", OracleDbType.Varchar2, 1).Value = shop.noFlag;
            cmd.Parameters.Add("in_adult_only", OracleDbType.Varchar2, 1).Value = shop.adultOnly;
            cmd.Parameters.Add("in_multi_img_yn", OracleDbType.Varchar2, 1).Value = shop.multiImgYn;
            cmd.Parameters.Add("in_single_order_yn", OracleDbType.Varchar2, 1).Value = shop.singleOrderYn;
            cmd.Parameters.Add("in_insert_name", OracleDbType.Varchar2, 30).Value = shop.insertName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        /// <summary>
        /// 메뉴 관련항목 정렬
        /// </summary>
        /// <remarks>
        /// div ( 0 : 메뉴그룹, 1 : 메뉴, 2 : 메뉴 옵션그룹 (menu_option_group.sort_no), 3: 메뉴 옵션그룹 리스트, 4: 메뉴 다중 이미지 )
        /// </remarks>
        [HttpPost("updateSort")]
        public async Task<IActionResult> updateSort(string div, IEnumerable<string> pk)
        {
            if (string.IsNullOrEmpty(pk.FirstOrDefault()) )
            {
                return Ok(new { code = "99", msg = "정렬할 항목이 없습니다" });
            }

            // div ( 0 : 메뉴그룹, 1 : 메뉴, 2 : 메뉴에 해당되는 옵션그룹 (menu_option_group.sort_no), 3: 메뉴 옵션그룹 리스트, 4: 메뉴 다중 이미지 )
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.UPDATE_SORT_SEQ",
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 1).Value = div;

            var arr = cmd.Parameters.Add("in_cd_array", OracleDbType.Int32);
            arr.Direction = ParameterDirection.Input;
            arr.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arr.Value = pk.ToArray();
            arr.Size = pk.Count();
            arr.ArrayBindSize = pk.Select(_ => _.Length).ToArray();
            arr.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, pk.Count()).ToArray();

            string msg = string.Empty;
            foreach (var item in pk)
            {
                msg = msg + item.ToString() + ",";
            }

            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu/updateSort : Post", ex.Message + "[ div: " + div + " ,arr: " + msg + " ]");
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 메뉴수정
        /// </summary>
        /// <remarks>
        /// singleOrderYn 주류 단독주문가능여부(Y/N)
        /// </remarks>
        [HttpPut]
        public async Task<IActionResult> Put(ShopMenu shop)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            // 프론트 업데이트 미적용 예외처리
            //if (string.IsNullOrEmpty(shop.singleOrderYn))
            //{
            //    Rcode = "99";
            //    Rmsg = "주류단독주문가능여부 값이 비었습니다.";
            //    return Ok(new { code = Rcode, msg = Rmsg });
            //}

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.UPDATE_MENU",
            };

            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = shop.menuCd;
            cmd.Parameters.Add("in_menu_name", OracleDbType.Varchar2, 100).Value = shop.menuName;
            cmd.Parameters.Add("in_menu_cost", OracleDbType.Int32).Value = shop.menuCost;
            cmd.Parameters.Add("in_menu_desc", OracleDbType.Varchar2, 500).Value = shop.menuDesc;
            cmd.Parameters.Add("in_use_yn", OracleDbType.Varchar2, 1).Value = shop.useYn;
            cmd.Parameters.Add("in_no_flag", OracleDbType.Varchar2, 1).Value = shop.noFlag;
            cmd.Parameters.Add("in_adult_only", OracleDbType.Varchar2, 1).Value = shop.adultOnly;
            //cmd.Parameters.Add("in_m_alone_order", OracleDbType.Varchar2, 1).Value = shop.aloneOrder;
            cmd.Parameters.Add("in_m_main_yn", OracleDbType.Varchar2, 1).Value = shop.mainYn;
            cmd.Parameters.Add("in_multi_img_yn", OracleDbType.Varchar2, 1).Value = shop.multiImgYn;
            cmd.Parameters.Add("in_single_order_yn", OracleDbType.Varchar2, 1).Value = shop.singleOrderYn;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 30).Value = shop.insertName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        [HttpPut("copyMenu")]
        public async Task<IActionResult> Put(int menu_cd, string insert_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.COPY_MENU",
            };

            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = menu_cd;
            cmd.Parameters.Add("in_insert_name", OracleDbType.Varchar2, 30).Value = insert_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 메뉴 상세조회
        /// </summary>
        /// <remarks>
        /// singleOrderYn 주류 단독주문가능여부(Y/N)
        /// </remarks>
        [HttpGet("{menu_cd}")]
        public async Task<IActionResult> Get(string menu_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_MENU_DETAIL",
            };

            cmd.Parameters.Add("in_menu_cd", OracleDbType.Varchar2, 10).Value = menu_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            Menu menu = new Menu();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();


                menu.menuCd = rd["MENU_CD"].ToString();
                menu.menuName = rd["MENU_NAME"].ToString();
                menu.menuGroupCd = rd["MENU_GROUP_CD"].ToString();
                menu.menuCost = rd["MENU_COST"].ToString();
                menu.menuDesc = rd["MENU_DESC"].ToString();
                menu.useYn = rd["USE_GBN"].ToString();
                menu.aloneOrder = rd["M_ALONE_ORDER"].ToString();
                menu.mainYn = rd["M_MAIN_YN"].ToString();
                menu.noFlag = rd["NO_FLAG"].ToString();
                menu.adultOnly = rd["ADULT_ONLY"].ToString();
                menu.multiImgYn = rd["multi_img_yn"].ToString();
                menu.singleOrderYn = rd["SINGLE_ORDER_YN"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu/menu_cd : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = menu });
        }

        /// <summary>
        /// 가맹점 전체 메뉴 초기화
        /// </summary>
        [HttpDelete("removeMenuOption")]
        public async Task<IActionResult> removeMenuOption(string shop_cd)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.REMOVE_MENU_OPTION",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu/removeMenuOption : Delete", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 메뉴 전체복사
        /// </summary>
        [HttpPost("copyMenuOption")]
        public async Task<IActionResult> copyMenuOption(string source_cccode, string source_shop_cd, string dest_cccode, string dest_shop_cd, string insert_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.COPY_MENU_OPTION",
            };

            cmd.Parameters.Add("in_s_shop_cd", OracleDbType.Varchar2, 10).Value = source_shop_cd;
            cmd.Parameters.Add("in_d_shop_cd", OracleDbType.Varchar2, 10).Value = dest_shop_cd;
            cmd.Parameters.Add("in_insert_name", OracleDbType.Varchar2, 30).Value = insert_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();


                #region  파일 복사
                if (Rcode.Equals("00"))
                {
                    // 경로 맨 뒤에 역슬래쉬가 없어야 한다.
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        // 소스 이미지 경로
                        string sourcePath = $@"{productPath}\{source_cccode}\{source_shop_cd}";
                        string destPath = $@"{productPath}\{dest_cccode}\{dest_shop_cd}";

                        if (Directory.Exists(sourcePath))
                        {
                            // 복사에서 제외될 파일명들
                            var excluedeFiles = new List<string>(new[] { "shop.jpg", "buss.jpg", "bank.jpg", "idcard.jpg" });

                            var file_Files = Directory.GetFiles(sourcePath, "*.*").Where(file => !excluedeFiles.Any<string>((file_name) => file.EndsWith(file_name, StringComparison.CurrentCultureIgnoreCase))).ToList();

                            // 복사할 파일이 존재할 때만 디렉토리를 생성하고 복사를 진행한다.
                            if (file_Files.Count > 0)
                            {
                                if (Directory.Exists($@"{productPath}\{dest_cccode}") == false)
                                {
                                    Directory.CreateDirectory($@"{productPath}\{dest_cccode}");
                                }

                                if (Directory.Exists($@"{productPath}\{dest_cccode}\{dest_shop_cd}") == false)
                                {
                                    Directory.CreateDirectory($@"{productPath}\{dest_cccode}\{dest_shop_cd}");
                                }


                                foreach (string list_file in file_Files)
                                {
                                    int iPos = list_file.LastIndexOf(@"\");
                                    string file_name = list_file.Substring(iPos + 1, list_file.Length - (iPos + 1));

                                    try
                                    {
                                        // 파일이 이미 존재하면 삭제한다.
                                        if (System.IO.File.Exists($@"{destPath}\{file_name}"))
                                        {
                                            System.GC.Collect();
                                            System.GC.WaitForPendingFinalizers();
                                            System.IO.File.Delete($@"{destPath}\{file_name}");
                                        }

                                        System.IO.File.Copy(list_file, $@"{destPath}\{file_name}");
                                    }
                                    catch (Exception ex)
                                    {
                                        await Utils.SaveErrorAsync("/Menu/copyMenuOption : Post - 파일존재 확인 후 카피부분", ex.Message);
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu/copyMenuOption : Post", ex.Message + " || {source_cccode: " + source_cccode + ", source_shop_cd: " + source_shop_cd + ", dest_cccode: " + dest_cccode + ", dest_shop_cd: " + dest_shop_cd + ", insert_name: " + insert_name + "}");
                return Ok(new { code = 01, msg = "이미지 복사 실패" });
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpGet("shopNameList")]
        public async Task<IActionResult> GetShopNameList(int mcode, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<ShopCodeName> items = new List<ShopCodeName>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_SHOP.GET_SHOP_NAME_LIST",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mcode;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 50).Value = keyword;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ShopCodeName item = new ShopCodeName
                    {
                        ccCode = rd["CCCODE"].ToString(),
                        shopCd = rd["SHOP_CD"].ToString(),
                        shopName = rd["SHOP_NAME"].ToString(),
                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu/shopNameList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        // 메뉴작성 완료여부
        [HttpPut("setMenuComplete")]
        public async Task<IActionResult> setMenuComplete(string shopCd, string menuCompleteYn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("shop_cd", shopCd);
                param.Add("menu_complete_yn", menuCompleteYn);

                string sql = @"
                                update shop_info
                                set MENU_COMPLETE = :menu_complete_yn
                                where shop_cd = :shop_cd
                                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 메뉴 그룹이동
        /// </summary>
        /// <remarks>
        /// shop_cd 대상메뉴의 가맹점코드 <br/>
        /// menu_cd 대상메뉴 코드 <br/>
        /// to_group_cd 이동할 그룹 코드 <br/>
        /// </remarks>
        [HttpPut("moveGroup")]
        public async Task<IActionResult> moveGroup(string shop_cd, string menu_cd, string to_group_cd, string mod_ucode, string mod_name)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.MOVE_GROUP",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = shop_cd;
            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = menu_cd;
            cmd.Parameters.Add("in_to_group_cd", OracleDbType.Int32).Value = to_group_cd;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 200).Value = mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu/moveGroup : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 메뉴 단건 다른가맹점(다중)으로 복사(옵션포함)
        /// </summary>
        /// <remarks>
        /// source_cccode 복사할 메뉴 콜센터코드 <br/>
        /// source_shop_cd 복사할 메뉴 가맹점코드 <br/>
        /// dest_cccode 붙여넣을 콜센터코드 리스트 <br/>
        /// dest_shop_cd 붙여넣을 가맹점코드 리스트 <br/>
        /// menu_cd 복사할 메뉴코드 <br/>
        /// </remarks>
        [HttpPost("copyMenuToOtherShop")]
        public async Task<IActionResult> copyMenuToOtherShop(CopyMenuTo item)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<string> items = new List<string>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_MENU.COPY_MENU_TO_OTHER_SHOP",
            };

            cmd.Parameters.Add("in_s_shop_cd", OracleDbType.Varchar2, 10).Value = item.source_shop_cd;
            var arrCccode = cmd.Parameters.Add("in_d_cccode", OracleDbType.Varchar2, 10);
            arrCccode.Direction = ParameterDirection.Input;
            arrCccode.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrCccode.Value = item.dest_cccode.ToArray();
            arrCccode.Size = item.dest_cccode.Count();
            arrCccode.ArrayBindSize = item.dest_cccode.Select(_ => _.Length).ToArray();
            arrCccode.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, item.dest_cccode.Count()).ToArray();

            var arrShopCd = cmd.Parameters.Add("in_d_shop_cd", OracleDbType.Varchar2, 10);
            arrShopCd.Direction = ParameterDirection.Input;
            arrShopCd.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrShopCd.Value = item.dest_shop_cd.ToArray();
            arrShopCd.Size = item.dest_shop_cd.Count();
            arrShopCd.ArrayBindSize = item.dest_shop_cd.Select(_ => _.Length).ToArray();
            arrShopCd.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, item.dest_shop_cd.Count()).ToArray();
            cmd.Parameters.Add("in_menu_cd", OracleDbType.Int32).Value = item.menu_cd;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = item.mod_ucode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 30).Value = item.mod_name;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    items.Add(rd["file_name"].ToString());
                }

                await rd.CloseAsync();
                await conn.CloseAsync();


                var cccode = item.dest_cccode.ToList();
                var shop_cd = item.dest_shop_cd.ToList();
                
                #region  파일 복사
                if (Rcode.Equals("00") && Utils.serverGbn == "R")
                {
                    // 경로 맨 뒤에 역슬래쉬가 없어야 한다.
                    using (new ConnectToSharedFolder(nasPath))
                    {
                        for (int i = 0; i < items.Count; i++)
                        {
                            // 소스 이미지 경로
                            string sourcePath = $@"{productPath}\{item.source_cccode}\{item.source_shop_cd}";
                            string destPath = $@"{productPath}\{cccode[i]}\{shop_cd[i]}";

                            if (Directory.Exists(sourcePath))
                            {
                                var file_Files = Directory.GetFiles(sourcePath, "*.*").Where(file => items.Any<string>((file_name) => file.EndsWith(file_name, StringComparison.CurrentCultureIgnoreCase))).ToList();

                                // 복사할 파일이 존재할 때만 디렉토리를 생성하고 복사를 진행한다.
                                if (file_Files.Count > 0)
                                {
                                    if (Directory.Exists($@"{productPath}\{cccode[i]}") == false)
                                    {
                                        Directory.CreateDirectory($@"{productPath}\{cccode[i]}");
                                    }

                                    if (Directory.Exists($@"{productPath}\{cccode[i]}\{shop_cd[i]}") == false)
                                    {
                                        Directory.CreateDirectory($@"{productPath}\{cccode[i]}\{shop_cd[i]}");
                                    }


                                    foreach (string list_file in file_Files)
                                    {
                                        int iPos = list_file.LastIndexOf(@"\");
                                        string file_name = list_file.Substring(iPos + 1, list_file.Length - (iPos + 1));

                                        try
                                        {
                                            // 파일이 이미 존재하면 삭제한다.
                                            if (System.IO.File.Exists($@"{destPath}\{file_name}"))
                                            {
                                                System.GC.Collect();
                                                System.GC.WaitForPendingFinalizers();
                                                System.IO.File.Delete($@"{destPath}\{file_name}");
                                            }

                                            System.IO.File.Copy(list_file, $@"{destPath}\{file_name}");
                                        }
                                        catch (Exception ex)
                                        {
                                            await Utils.SaveErrorAsync("/Menu/copyMenuToOtherShop : Post - 파일존재 확인 후 카피부분", ex.Message);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else if (Rcode.Equals("00") && Utils.serverGbn == "T")
                {
                    for (int i = 0; i < items.Count; i++)
                    {
                        // 소스 이미지 경로
                        string sourcePath = $@"{testImagePath}\{item.source_cccode}\{item.source_shop_cd}";
                        string destPath = $@"{testImagePath}\{cccode[i]}\{shop_cd[i]}";

                        if (Directory.Exists(sourcePath))
                        {
                            var file_Files = Directory.GetFiles(sourcePath, "*.*").Where(file => items.Any<string>((file_name) => file.EndsWith(file_name, StringComparison.CurrentCultureIgnoreCase))).ToList();

                            // 복사할 파일이 존재할 때만 디렉토리를 생성하고 복사를 진행한다.
                            if (file_Files.Count > 0)
                            {
                                if (Directory.Exists($@"{testImagePath}\{cccode[i]}") == false)
                                {
                                    Directory.CreateDirectory($@"{testImagePath}\{cccode[i]}");
                                }

                                if (Directory.Exists($@"{testImagePath}\{cccode[i]}\{shop_cd[i]}") == false)
                                {
                                    Directory.CreateDirectory($@"{testImagePath}\{cccode[i]}\{shop_cd[i]}");
                                }


                                foreach (string list_file in file_Files)
                                {
                                    int iPos = list_file.LastIndexOf(@"\");
                                    string file_name = list_file.Substring(iPos + 1, list_file.Length - (iPos + 1));

                                    try
                                    {
                                        // 파일이 이미 존재하면 삭제한다.
                                        if (System.IO.File.Exists($@"{destPath}\{file_name}"))
                                        {
                                            System.GC.Collect();
                                            System.GC.WaitForPendingFinalizers();
                                            System.IO.File.Delete($@"{destPath}\{file_name}");
                                        }

                                        System.IO.File.Copy(list_file, $@"{destPath}\{file_name}");
                                    }
                                    catch (Exception ex)
                                    {
                                        await Utils.SaveErrorAsync("/Menu/copyMenuToOtherShop : Post - 파일존재 확인 후 카피부분", ex.Message);
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/Menu/copyMenuToOtherShop : Post", ex.Message 
                    + " || {source_cccode: " + item.source_cccode + ", source_shop_cd: " + item.source_shop_cd + ", dest_cccode: " + item.dest_cccode + ", dest_shop_cd: " + item.dest_shop_cd
                    + ", menu_cd: " + item.menu_cd + ", mod_ucode: " + item.mod_ucode + ", mod_name: " + item.mod_name + "}");
                return Ok(new { code = 01, msg = "메뉴복사 실패" });
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

    }
}
