﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ChildMealController : ControllerBase
    {

        #region[아동급식 연계]
        /// <summary>
        /// 아동급식 중복 가맹점 목록 조회
        /// </summary>
        /// <remarks>
        /// 파라미터 <br/>
        /// comp_yn : 처리여부(Y/N) (필수) <br/>
        /// div : 검색구분(1 사업자번호, 2 가맹점명) <br/>
        /// keyword : 검색 키워드 <br/>
        ///  <br/>
        /// 결과값 <br/>
        /// ins_date : 중복생성일자 <br/>
        /// reg_no : 사업자번호 <br/>
        /// shop_cd : 가맹점코드 <br/>
        /// shop_name : 가맹점명 <br/>
        /// child_meal_yn : 아동급식가맹점 여부(Y/N) <br/>
        /// child_meal_cd : 서비스로 조회한 아동급식가맹점 코드 <br/>
        /// mod_date : 중복수정일자 <br/>
        /// mod_ucode : 중복수정자코드 <br/>
        /// mod_name : 중복수정자명 <br/>
        /// </remarks>
        [HttpGet("getDupList")]
        public async Task<IActionResult> getDupList(string comp_yn, string div, string keyword, string page, string rows)
        {
            string position = "/ChildMeal/getDupList : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            if (div == "2" && !string.IsNullOrEmpty(keyword))// 가맹점명 검색시 부분일치검색
            {
                keyword = "%" + keyword + "%";
            }

            List<ChildMealDup> itmes = new List<ChildMealDup>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CHILD_MEAL.GET_DUP_LIST",
            };

            cmd.Parameters.Add("in_comp_yn", OracleDbType.Varchar2, 1).Value = comp_yn;
            cmd.Parameters.Add("in_div", OracleDbType.Varchar2, 1).Value = div;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 200).Value = keyword;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ChildMealDup item = new ChildMealDup
                    {
                        seq = rd["seq"].ToString(),
                        ins_date = rd["ins_date"].ToString(),
                        reg_no = rd["reg_no"].ToString(),
                        shop_cd = rd["shop_cd"].ToString(),
                        shop_name = rd["shop_name"].ToString(),
                        child_meal_yn = rd["child_meal_yn"].ToString(),
                        child_meal_cd = rd["sh_child_meal_cd"].ToString(), // 서비스에 기록된 코드만 조회
                        //sh_child_meal_cd = rd["sh_child_meal_cd"].ToString(),
                        mod_date = rd["mod_date"].ToString(),
                        mod_ucode = rd["mod_ucode"].ToString(),
                        mod_name = rd["mod_name"].ToString()
                    };

                    itmes.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(position, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = itmes });
        }

        /// <summary>
        /// 아동급식 연동 수정
        /// </summary>
        /// <remarks>
        /// reg_no 사업자번호(필수)
        /// shop_cd 가맹점코드(필수)
        /// child_meal_cd 아동급식코드(필수)
        /// child_meal_yn 아동급식여부(필수)
        /// ucode 작업자코드(필수)
        /// </remarks>
        [HttpPut("setLink")]
        public async Task<IActionResult> setLink(SetChildMeal input)
        {
            string position = "/ChildMeal/setLink : Put";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            // 신한 연동처리
            SHChildMealYnReq shReq = new SHChildMealYnReq();
            shReq.CHECK_DT = DateTime.Now.ToString("yyyyMMdd"); // 상태변경 일자
            shReq.MCHT_NO = input.child_meal_cd; // 신한 가맹점번호(아동급식코드)
            shReq.BRNO = input.reg_no; // 사업자번호
            shReq.MCHT_NM = input.shop_name; // 가맹점명
            shReq.DRO_LINK_YN = input.child_meal_yn; // 연계여부(Y/N)

            SHChildMealYnResult shResult = new SHChildMealYnResult();
            shResult.COMMON_HEAD = new SHCommonHeadResult();

            shResult = await setSHLink(shReq);

            if(shResult.COMMON_HEAD.CODE != "0000")
            {
                Rcode = "99";
                Rmsg = "신한연동 실패/" + shResult.COMMON_HEAD.MSG;
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            //대구로 연동처리
            ResultBasic result = new ResultBasic();
            result = await setDGRLink(input.shop_cd, input.child_meal_yn == "Y"? input.child_meal_cd : null, input.child_meal_yn, input.mod_ucode);

            if (result.code != "00")
            {
                Rcode = "99";
                Rmsg = "대구로연동 실패/" + result.msg;
                await Utils.SaveErrorAsync(position, Rmsg + "/" + JsonConvert.SerializeObject(input));
                return Ok(new { code = Rcode, msg = Rmsg });
            }

            Rcode = "00";
            Rmsg = "성공";
            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// (대구로)아동급식 연동 수정
        /// </summary>
        /// <remarks>
        /// shop_cd 가맹점코드(필수)
        /// child_meal_cd 아동급식코드
        /// child_meal_yn 아동급식여부(필수)
        /// ucode 작업자코드(필수)
        /// </remarks>
        [HttpPut("setDGRLink")]
        public async Task<ResultBasic> setDGRLink(string shop_cd, string child_meal_cd, string child_meal_yn, string ucode)
        {
            string position = "/ChildMeal/setDGRLink : Put";
            ResultBasic result = new ResultBasic();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_CHILD_MEAL.SET_LINK",
            };

            cmd.Parameters.Add("in_shop_cd", OracleDbType.Int32).Value = shop_cd;
            cmd.Parameters.Add("in_child_meal_cd", OracleDbType.Varchar2, 20).Value = child_meal_cd;
            cmd.Parameters.Add("in_child_meal_yn", OracleDbType.Varchar2, 1).Value = child_meal_yn;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                result.code = cmd.Parameters["out_code"].Value.ToString();
                result.msg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                result.code = "98";
                result.msg = ex.Message;
                await Utils.SaveErrorAsync(position, ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 신한, 대구로 아동급식가맹점 연계여부 상태변경
        /// </summary>
        [HttpPost("setSHLink")]
        public async Task<SHChildMealYnResult> setSHLink(SHChildMealYnReq input)
        {
            string position = "/ChildMeal/setSHLink : Post";
            string url = string.Empty;

            if (Utils.serverGbn == "T")
            {
                url = @$"https://dev-api-kidsmeal.daegu.go.kr/link/api/drLinkyn/";//(테스트서버경로)
            }
            else if (Utils.serverGbn == "R")
            {
                url = @$"https://kidsmeal.daegu.go.kr:7819/link/api/drLinkyn"; //(운영서버경로)
            }
            SHChildMealYn item = new SHChildMealYn();
            item.COMMON_HEAD = new SHCommonHead();
            item.COMMON_HEAD.AGENCY_CD = "DGM";
            item.REQ_REC = input;

            SHChildMealYnResult result = new SHChildMealYnResult();
            result.COMMON_HEAD = new SHCommonHeadResult();
            result.REP_REC = new SHChildMealYnRep();

            try
            {
                var payload = item;

                var stringPayload = JsonConvert.SerializeObject(payload);

                HttpContent httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");

                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", Utils.posKey);

                HttpResponseMessage httpResponse = await httpClient.PostAsync(url, httpContent);

                string responseStr = await httpResponse.Content.ReadAsStringAsync();

                result = JsonConvert.DeserializeObject<SHChildMealYnResult>(responseStr);

                await Utils.SaveTempLogAsync(position, result.COMMON_HEAD.CODE + "/" + stringPayload);// 호출내역 기록

                if (result.COMMON_HEAD.CODE != "0000")
                {
                    await Utils.SaveErrorAsync(position, result.COMMON_HEAD.MSG + "/reqData:" + stringPayload);
                }

            }
            catch (Exception ex)
            {
                result.COMMON_HEAD.CODE = "99";
                result.COMMON_HEAD.MSG = ex.Message;
                await Utils.SaveErrorAsync(position, ex.Message);
            }

            return result;
        }
        #endregion[아동급식 연계]
    }
}
